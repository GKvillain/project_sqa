package com.fasterxml.jackson.databind.type;
import org.junit.Test;
import static org.junit.Assert.*;
public class ReferenceType_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 7, "\uda9c\udd83\ud9de\udd89\ud979\udc24\ud8a2\udc07\ud841\udda7\ud9be\udefa\ud9ef\udde8\udb70\udd81", "\u12d3\uc904\ub892\u2543\u7fa7\u6442\u46ac\u0a6a\u7d22\u957b", "\udbbb\udf8d\udb51\ude37\udab9\udd4c\ud9f7\udfdd\ud87a\udcbf\ud904\uddae\udb61\udc08\ud816\ude4f\udb15\udc8b\uda0e\udc5d\ud8c7\udd66\ud805\udd7f\ud8cf\udf93\ud8c2\udee7\udbe7\uddcb\ud897\udeec\ud9d7\udf63\ud954\udd65\udadc\udde7\uda28\uddff\ud84d\ude15\udb19\uddc6\uda16\udf00",
        57, 86062, -221291569, 2037885848210631547L, 8088L, false, true, (char) 19651, (char) 61875,
        Double.longBitsToDouble(0x3fe898b75d080479L), Double.longBitsToDouble(0x3fc0aa5a49aa8170L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 7, "\ud92a\udd8a\ud9de\udd89\ud979\udc24\ud8a2\udc07\ud841\udda7\ud9be\udefa\ud9ef\udde8\udb70\udd81", "\u12d3\uc904\ub892\u2543\u7fa7\u6442\u46ac\u0a6a\u7d22\u957b", "\udbbb\udf8d\ue3f3\udab9\udca0\ud9f7\udfdd\ud87a\udcbf\ud904\uddae\udb61\udc08\ud816\ude4f\udb15\udc8b\uda96\udc61\ud8c7\udd66\udb15\udd87\ud98d\udf6a\ud8c2\udee7\udbe7\uddcb\ud897\udeec\ud9d7\udf63\ud954\udd65\udadc\udde7\uda28\uddff\ud84d\ude15\udb19\uddc6\uda16\udf00",
        57, 86062, -221291569, 2037885848210631547L, 8088L, false, true, (char) 19651, (char) 61875,
        Double.longBitsToDouble(0x3fe898b75d080479L), Double.longBitsToDouble(0x3fc0aa5a49aa8170L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 7, "\uda9c\udd83\ud9de\udd89\ud979\udc24\ud8a2\udc07\ud841\udda7\ud9be\udefa\ud9ef\udde8\udb70\udd81", "\u12d3\uc904\ub892\u2543\u7fa7\u6442\u46ac\u0a6a\u7d22\u957b", "\udbbb\udf8d\udb51\ude37\udab9\udd4c\ud9f7\udfdd\035\000\udb3f\udc3f\ud816\ude4f\udb15\udc8b\uda0e\udc5d\ud8c7\udd66\u0e7f\ud8cf\udf93\ud8c2\udee7\udbe7\uddcb\ud897\udeec\ud9d7\udf63\ud954\udd65\udadc\udde7\uda28\uddff\ud84d\ude15\udb19\uddc6\uda16\udf00",
        57, 86062, -221291569, 20273215148589056L, 8088L, false, true, (char) 19651, (char) 61875,
        Double.longBitsToDouble(0x3fe898b75d080479L), Double.longBitsToDouble(0x3fc0aa5a49aa8170L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 5, 13, "\uda94\ude00\u29aa\ud979\udc24\ud8a2\udc07\ud984\udf95\udbe2\udc6d\udac7\ude85\udb70\udd59\uda5e\ude5b\ud94d\udfba\ud990\ude09\ud97a\ude26\ud987\udca8\u018a", "\u46ac\u0a6a\u7d22\u60bb\u1400\u0fc7\ud041\u6609\u4131", "\ud904\uddae\udb61\udc08\ud816\ude4f\udaf0\ude38\uda0e\udc5d\ud8c7\udd66\ud805\udd7f\udae0\udca8\ud8df\ude34\udbe7\uddcb\ud897\udeec\ud9d7\udf63\udb5f\udf64\udadc\ude2a\uda28\uddff\ud9ab\udda3\udb36\udfb3\uda16\udf00\ud886\udc0e\ud898\udf7b",
        16, 84274, -820390277, 5171516922305816120L, 55346L, true, false, (char) 47033, (char) 31152,
        Double.longBitsToDouble(0x3fc0aa5a55868170L), Double.longBitsToDouble(0x3feccd77fcb42abcL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 7, "\uda9c\udd83\udb1a\udfc6\ud978\udfbc\ud8a1\udf88\uda61\udc74\ud9be\ude5c\ud9ef\udde8\udb70\udd81", "\uc189\uc894\ub892\u2543\u7fa7\u6442\ud7bb\ud6b3\u0c92\ud56e", "\udbbb\udf8d\udb51\ude37\udab9\udd4c\ud9f7\udfdd\ud87a\udcbf\ud904\uddae\udb61\udc08\ud816\ude4f\udb15\udc8b\ud86c\udc94\ud9ef\ude7f\udb42\udf1f\ud8cf\udf93\ud8c2\udee7\udbe7\uddcb\ud897\udeec\ud9d7\udf63\ud954\udd65\udbcf\udf80\uda28\uddff\ud84d\ude15\udb19\uddc6\udac0\udef5",
        57, 56339, -221291569, 2037885848210631547L, 8088L, true, true, (char) 19554, (char) 63000,
        Double.longBitsToDouble(0x3fe898b75d330479L), Double.longBitsToDouble(0x3fd019ed24d54110L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 5, 7, "\uda9c\udd83\ud9de\udd89\ud979\udc24\ud8a2\udc07\ud841\udda7\ud9be\udefa\ud9ef\udde8\udb70\udd81", "\u12d3\uc904\ub7a8\u2543\u8809\u6442\u46ac\u0a6a\u7d22\u957b", "\udbbb\udf8d\ud823\udfc0\udb1a\udeea\udb10\udd4c\ud87a\udcbf\udb2f\udc01\udacf\udc3b\uda1d\udd71\ud9bd\udc15\u78e5\udade\udf11\ud805\udd7f\udab4\ude94\ud8c2\udee7\udbe7\uddcb\ud897\udeec\ud9d7\udf63\ud954\udd65\udadc\udde7\uda28\uddff\ud84d\ude15\udb19\uddc6\uda16\udf00",
        57, 86062, -221291569, 2037885848218044795L, 8088L, false, true, (char) 19651, (char) 61875,
        Double.longBitsToDouble(0x3fe898b75d080479L), Double.longBitsToDouble(0x3fc0aa5a49aa8170L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 7, "\uda9c\udd83\ud9de\udd89\ud979\udc24\ud8a2\udc07\ud841\udda7\ud9be\udefa\ud9ef\udde8\udb70\udd81", "\u12d3\uc904\ub892\u2543\u7fa7\u6442\u46ac\u0a6a\u7d22\u957b", "\udbbb\udf8d\udb51\ude37\udab9\udd4c\ud9f7\udfdd\ud87a\udcbf\ud904\uddae\udb61\udc08\ud816\ude4f\udb15\udc8b\uda0e\udc5d\ud8c7\udd66\ud805\udd7f\ud8cf\udf93\ud8c2\udee7\udbe7\uddcb\ud897\udeec\ud9d7\udf63\ud954\udd65\udadc\udde7\uda28\uddff\ud84d\ude15\udb19\uddc6\uda16\udf00",
        57, 86062, -221291569, 2037885848210631547L, -24621L, false, true, (char) 19651, (char) 61875,
        Double.longBitsToDouble(0x3fe898b75d080479L), Double.longBitsToDouble(0x3fc0aa5a49aa8170L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.type.ReferenceType|getGenericSignature|java.lang.StringBuilder|new:com.fasterxml.jackson.databind.type.ReferenceType:java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|_narrow|java.lang.Class|new:com.fasterxml.jackson.databind.type.ReferenceType:java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|buildCanonicalName||new:com.fasterxml.jackson.databind.type.ReferenceType:java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|construct|java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object|static",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|containedType|int|new:com.fasterxml.jackson.databind.type.ReferenceType:java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|containedTypeCount||new:com.fasterxml.jackson.databind.type.ReferenceType:java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|containedTypeName|int|new:com.fasterxml.jackson.databind.type.ReferenceType:java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|equals|java.lang.Object|new:com.fasterxml.jackson.databind.type.ReferenceType:java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|getErasedSignature|java.lang.StringBuilder|new:com.fasterxml.jackson.databind.type.ReferenceType:java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|getParameterSource||new:com.fasterxml.jackson.databind.type.ReferenceType:java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|getReferencedType||new:com.fasterxml.jackson.databind.type.ReferenceType:java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|isReferenceType||new:com.fasterxml.jackson.databind.type.ReferenceType:java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|toString||new:com.fasterxml.jackson.databind.type.ReferenceType:java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|withContentTypeHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.ReferenceType:java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|withContentValueHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.ReferenceType:java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|withStaticTyping||new:com.fasterxml.jackson.databind.type.ReferenceType:java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|getGenericSignature|java.lang.StringBuilder|new:com.fasterxml.jackson.databind.type.ReferenceType:java.lang.Class,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
