package com.fasterxml.jackson.databind.deser;
import org.junit.Test;
import static org.junit.Assert.*;
public class BasicDeserializerFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 3, "\uda66\udf5a\ud8a2\udc7a\udb8b\udf7b\ud896\udd2c\ud857\udd67\udb3c\udf45\ud91b\udd5e\udbf8\udd4f\udaed\udebb\udae2\udff6\udaaf\udd98\ud939\udfe1\uda9d\udeaa\udbfd\ude83\uda32\udfb4\udb7b\udd3b\uda2f\udcce\ud973\udda0\udbd6\udc9a\ud880\udf58", "\u89cd\u00c8\ub931\u6726\u50f7\uae4d\u671f\ub91b\u1638\u4a86\u6b54\u5243\u84c7\uc7b8\u6c59\ucd66\uc106\u626f\u4e1f\u63fd\u8198\ua5c4", "\ud825\udc46\udae7\ude3f\ud8f6\udd60\ud83c\udcbd",
        7, 97464, 1096112349, 6708341918550175284L, -7618L, true, false, (char) 59519, (char) 45296,
        Double.longBitsToDouble(0x3fe54855547b2f68L), Double.longBitsToDouble(0x3fce0aadc74e86dcL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 3, "\uda66\udf5a\ud8a2\udc7a\udb8b\udf7b\ud896\udd2c\ud857\udd67\udb3c\udf45\ud91b\udd5e\udbf8\udd4f\udaed\udebb\udae2\udff6\udaaf\udd98\ud939\udfe1\uda9d\udeaa\udbfd\ude83\uda32\udfb4\udb7b\udd3b\uda2f\udcce\ud973\udda0\udbd6\udc9a\ud880\udf58", "\u89cd\u00c8\ub931\u6726\u50f7\uae4d\u671f\ub91b\u1638\u4a86\u6b54\u5243\u84c7\uc7b8\u6c59\ucd66\uc106\u626f\u4e1f\u63fd\u8198\ua5c4", "\ud825\udc46\udae7\ude3f\ud8f6\udd60\ud83c\udcbd",
        7, 97464, 1096112349, 6708341918550175284L, -7618L, true, false, (char) 59519, (char) 45296,
        Double.longBitsToDouble(0x3fe54855547b2f68L), Double.longBitsToDouble(0x3fe07eae39d3a1b7L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 10, 10, 10, "\uda74\udf3e\ud8a2\udc7a\udb8b\udf7b\ud896\udd2c\ud857\udd67\udb3c\udf45\ud91b\udd5e\udbf8\udd4f\udaed\udebb\ud9bd\udcca\udae3\udc50\ud939\udfe1\uda8b\udfaa\udbfd\ude83\uda32\udfb4\udb7b\udd3b\uda2f\udcce\ud973\udda0\udbd6\udc9a\ud880\udf58", "\u89e4\u321f\ub931\u6726\u50f7\uae4d\u671f\u6a75\ud670\u4a86\u6b54\u5243\u84c7\uc7b8\u6c59\u9d18\uc106\u626f\u4e1f\u63fd\uca38\ud188", "\ud825\udc46\uda3e\udf6b\ud8da\udc1c\udb0c\udee2",
        50, 97537, 1096112349, 6708341918550175284L, -7618L, true, false, (char) 59519, (char) 45296,
        Double.longBitsToDouble(0x3fe54855547b2f68L), Double.longBitsToDouble(0x3fce0aadc74e86dcL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 14, 13, 3, "\uda66\udf5a\ud8a2\udc7a\udb8b\udf7b\ud896\udd2c\ud857\udd67\udb3c\udf45\ud91b\udd5e\udbf8\udd4f\udaed\udebb\udae2\udff6\udaaf\udd98\ud939\udfe1\uda9d\udeaa\udbfd\ude83\uda43\udcf8\udb7b\udd3b\uda2f\udcce\ud973\udda0\udbd6\udc9a\ud880\udf58", "\u89cd\u00c8\ub931\u6726\u50f7\uae4d\u671f\ub91b\u1638\u4a86\ucfa1\u8ca2\u84b1\uc7b8\u6c59\ucd66\uc106\u626f\u4e1f\u63fd\u8198\ua5c4", "\ud825\udc46\udae7\ude3f\ud8f6\udd60\ud83c\udcbd",
        7, 97464, 1096112349, 6708341918550175284L, -7618L, true, false, (char) 59519, (char) 45296,
        Double.longBitsToDouble(0x3fe54855547b2f68L), Double.longBitsToDouble(0x3fce0aadc74e86dcL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 7, "\uda66\udf5a\ud8a2\udc7a\udb8b\udf7b\ud896\udd2c\ud857\udd67\udb3c\udf45\ud91b\udd5e\udbf8\udd4f\udbd0\uddc4\udae2\udff6\udaaf\udd98\ud939\udfe1\uda9d\udeaa\udbfd\ude83\uda32\udfb4\udb7b\udd3b\udbfd\udf57\ud973\udda0\udbd6\udc9a\ud82c\uddee", "\u89cd\u00c8\ub931\u6726\u50f7\uae4d\u671f\u094d\u7ed8\u4a86\u6b54\u5243\u84c7\uc7b8\u6c59\ucd66\uc106\u626f\u4e1f\u63fd\u7f40\u722a", "\ud825\udc46\udae7\ude4d\ud8f6\udd60\ud83c\udcbd\udaba\ude9b",
        54, 59349, 1561907567, -284942612057953106L, 20593L, true, false, (char) 52194, (char) 30302,
        Double.longBitsToDouble(0x3fdd3a1b7a2f28c4L), Double.longBitsToDouble(0x3fd67450971807ccL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 15, 13, 5, "\uda66\udf5a\udada\ude76\ud9c9\udc8d\ud9f5\udf53\ud85b\uddc8\udb3c\udf45\ud91b\udd5e\udbf8\udd4f\udb03\udf84\udaba\udd13\udaaf\udd98\ud939\udfe1\ud81c\udd28\ud9a7\udf57\udb70\ude14\udafc\ude27\ud913\ude23\udb27\udc28\ud89b\udfe5\ud880\udf58", "\u5ac8\uc038\ub931\uc4f6\u10ca\uca4b\u1444\u1e9c\u8b96\u2939\u29b7\u2ad3\u8425\uc7b8\u6c59\ub19a\uc106\u626f\u4e1f\u63fd\u8198\ua5c4", "\ud825\udc46\u2d32\ud8f6\udd60\ud9f1\udef8",
        23, 63770, 1096112349, 6708234168491028020L, -7594L, true, false, (char) 32786, (char) 41430,
        Double.longBitsToDouble(0x3fe642b3647b2f68L), Double.longBitsToDouble(0x3fce0aadc74e86dcL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 2, 10, "\uda74\udf3e\ud8a2\udc7a\udb8b\udf7b\ud896\udd2c\ud857\udd67\udb3c\udf45\ud8c0\udf70\udaed\udd69\udaed\udebb\ud9bd\udcca\udae3\udc50\ud939\udfe1\uda8b\udfaa\udbfd\ude83\uda32\udfb4\udb7b\udd3b\uda2f\udcce\ud973\udda0\udbd6\udc9a\ud9b2\udf71", "\u89e4\u321f\ub931\u6726\u50f7\uae4d\u671f\u6a75\ud670\u4a86\u6b54\u5243\u84c7\uc7b8\u6c59\u9d18\uc106\u626f\u4e1f\u63fd\uca38\ud188", "\ud825\udc46\uda3e\udf6b\ud8da\udc1c\udb0c\udee2",
        50, 97537, 1096112349, 6708341918550175284L, -7618L, true, false, (char) 59519, (char) 45296,
        Double.longBitsToDouble(0x3fe54855547b2f68L), Double.longBitsToDouble(0x3fce0aadc74e86dcL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 10, 10, 10, "\uda74\udf3e\udb4c\udd55\udafa\uded5\ud897\udd0c\ud857\udd67\udb3c\udf45\ud925\udf90\ud881\udd9a\udb0d\ude96\udae7\udcbf\udae3\udc50\ud939\udfe1\ud9ce\uddab\ud9fc\udc33\ud8a8\udc5b\ud87d\udd3a\uda9d\udd42\udb70\udc7f\u315d\uda32\uded9\ud84d\udc54\ud95f\udde2\udafb\udfca\ud8fd\ude12\uda92\udff4\ud8fe\udfa5\udbbb\ude59\uef9f\ue017\ud90f\udce6\ud9cf\udf8b", "\u521e\ua30c\uc7c1\u4418\uaa90\u0e06", "\udbaf\udcba\ud941\udc8c\udba2\udccf\ud90f\udebe\udb26\udf73\ud825\udc46\uda3e\udf6b\ud8da\udc1c\uda57\ude07\udaa5\udf4c\ud912\udd12\uda8a\udf31\ud9ef\udeeb\ud804\ude60\udb2e\udc26\ud858\uddbc\ud851\ude8c\ud9f1\ude40\ud8c6\udce5\udb5d\udf4c\ud90f\udcd5\uda57\udf61\ud883\udcc9\udb8f\udc64\ud847\udfcd\udbed\udd13\ud951\udced\uef1e\ud90c\udc00\ud9cd\udf76\udb65\udce7\udaf8\udd0e\uda4e\ude14\udb56\udc0e\ud96e\ude20\ud987\ude30\ud990\udd2b\udbd3\udd97\ud963\udcb5\ud835\udef1\udaf2\udc55",
        7, 76557, -489014477, -1206008753043846553L, -26248L, true, true, (char) 31463, (char) 29274,
        Double.longBitsToDouble(0x3fb4d8f933af1c38L), Double.longBitsToDouble(0x3feac501be24d28dL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 10, 12, 12, "\uda74\udf3e\ud8a2\udc7a\udb8b\udf7b\ud896\udd2c\ud857\udd67\udb3c\udf45\ud91b\udd5e\udbf8\udd4f\udaed\udebb\ud9bd\udcca\udae3\udc50\ud939\udfe1\uda8b\udfaa\udbfd\ude83\uda32\udfb4\udb7b\udd3b\uda2f\udcce\ud973\udda0\udbd6\udc9a\ud880\udf58", "\u89e4\u321f\ub931\u6726\u50f7\uae4d\u671f\u6a75\ud670\u4a86\u6b54\u5243\u84c7\uc7b8\u6c59\u9d18\uc106\u626f\u4e1f\u63fd\uca38\ud188", "\ud825\udc46\uda3e\udf6b\ud8da\udc1c\udb0c\udee2",
        50, 97537, 1096112349, 6708341918550175284L, -7618L, true, false, (char) 59519, (char) 45296,
        Double.longBitsToDouble(0x3fe54855547b2f68L), Double.longBitsToDouble(0x3fce0abe274e86dcL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 11, 6, 7, "\uda74\udf3e\ud806\ude6c\ud96b\udd0e\ud896\udd2c\ud857\udd67\udb3c\udf45\ud91b\udd5e\udbf8\udd4f\udaed\udebb\udbd4\udf80\udae2\udfdb\ud939\udfe1\uda8b\udfaa\udbfd\ude83\uda32\udfb4\udb7b\udd3b\uda2f\udcce\ud973\udda0\udbd6\udc9a\ud880\udf58", "\u89e4\u321f\ub931\u6726\u50f7\uae4d\u671f\u6a75\ud670\u4a86\u6b54\u5243\u84c7\uc7b8\u6c59\u9d18\uc106\u626f\u4e1f\u63fd\uca38\ud188", "\ud825\udc46\uda3e\udf6b\ud8da\udc1c\udb0c\udee2",
        50, 97537, 1096112349, 6708341918550175284L, -77815L, true, false, (char) 45150, (char) 8744,
        Double.longBitsToDouble(0x3fd2c89dba5cb40eL), Double.longBitsToDouble(0x3fd58cd27d3743f4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 7, 10, "\uda74\udf3e\ud8a2\udc7a\udb8b\udf7b\ud896\udd2c\ud857\udd67\udb3c\udf45\ud91b\udd5e\udbf8\udd4f\udaed\udebb\ud9bd\udcca\udae3\udc50\ud939\udfe1\uda8b\udfaa\udbfd\ude83\uda32\udfb4\udb7b\udd3b\uda2f\udcce\ud973\udda0\udbd6\udc9a\ud880\udf58", "\u89e4\u321f\ub931\u6726\u50f7\uae4d\u671f\u6a75\ud670\u4a86\u6b54\u5243\u84c7\uc7b8\u6c59\u9d18\uc106\u626f\u4e1f\u63fd\uca38\ud188", "\ud825\udc46\uda3e\udf6b\uda95\udce0\udb0c\udee2",
        50, 97537, 1096112349, 6708341918550175284L, -7618L, true, false, (char) 57994, (char) 29139,
        Double.longBitsToDouble(0x3fe54856547b2f68L), Double.longBitsToDouble(0x3fce0aadc4d686dcL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 9, 2, "\ud807\ude70\u286c\udb95\uddd5\udaaf\udc78\ud857\udd67\udb48\uddc0\ud91b\udd5e\udbf8\udd4f\udaf5\udc78\ud9bd\udcca\udae3\udc50\ud939\udfe1\uda8b\udfaa", "\u4097\u9174\u74b4\ucdc0\uc5c0\ub517\ucd04\u89e4\u321f\ub931\u97f4\u50f7\u509c\u8d6a\u6ad1\uaf9c\u4af1", "\ud97b\udc75\ud920\udcd5\ud9d8\udd43",
        11, 36834, -32654146, 3441280122389697969L, 36545L, true, false, (char) 49018, (char) 6887,
        Double.longBitsToDouble(0x3fdd95444681ad9eL), Double.longBitsToDouble(0x3fc0d95733c0a058L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 10, 10, "\uda74\udf3e\ud8a2\udc7a\udb8b\udf7b\ud896\udd2c\ud857\udd67\udb3c\udf45\ud91b\udd5e\udb46\udd56\uda18\udccf\udb16\udd05\udae3\udcb1\ud939\udfe1\uda8b\udfaa\udbfd\ude83\uda32\udfb4\uda40\udef7\uda28\udcab\ud973\udda0\udbd6\udc9a", "\u0532\u89e4\u321f\ub931\u6726", "\ud918\udf53\uda06\udebe\ud84e\udcaa\udb86\udcd5\udab1\udc4a\udab2\udd94\udb44\udda2",
        2, 49420, -1290343845, 6952789545172450494L, -7223L, false, true, (char) 49894, (char) 6899,
        Double.longBitsToDouble(0x3fe275e136751c72L), Double.longBitsToDouble(0x3feecb159bb83612L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 14, 14, 3, "\uda66\udf5a\ud8a2\udc7a\udb8b\udf7b\ud896\udd2c\ud857\udd67\udb3c\udf45\ud91b\udd5e\udbf8\udd4f\udaed\udebb\udae2\udff6\udaaf\udd98\ud939\udfe1\uda1b\udea3\udbfd\ude83\uda43\udcf8\udb7b\udd3b\uda2f\udcce\ud973\udda0\udbd6\udc9a\ud880\udf58", "\u89cd\u00c8\ub931\u6726\u50f7\uae4d\u671f\ub91b\u1638\u4a86\ucfa1\u032d\u84b1\uc7b8\u6c59\ucd66\uc106\u626f\u4e1f\u63fd\u8198\ua5c4", "\ud825\udc46\udae7\ude3f\ud8f6\udd60\ud83c\udcbd",
        7, 97464, 1096112238, 5128293187735760436L, -7618L, true, false, (char) 59519, (char) 45296,
        Double.longBitsToDouble(0x3fe54855547b2f68L), Double.longBitsToDouble(0x3fce0aadc74e86dcL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 13, 13, 3, "\uda66\udf5a\ud8a2\udc7a\udb8b\udf7b\ud896\udd2c\ud857\udd67\udb3c\udf45\ud91b\udd5e\udbf8\udd4f\udaed\udebb\udae2\udff6\udaaf\udd98\ud939\udfe1\udb57\udf25\ud89b\udd07\ud922\ude38\udb8f\ude84\uda2f\udcce\ud973\udda0\udbd6\udc9a\ud880\udf58", "\u89cd\u00c8\ub931\u4d14\u7fb0\u378f\u671f\ub91b\u7fa1\u43da\ucfa1\u8ca2\u5b49\ua7b8\u6c59\ucd66\uc675\u626f\u4ef8\u63fd\u2040\u9394", "\udb26\udc69\udae7\ude3f\ud8f6\udd60\ud83c\udcbd\udaba\ude9b\udbae\ude29\uda40\uddf1\ud943\ude78",
        11, 22006, -840433183, -4503394866807036161L, -77815L, true, false, (char) 10846, (char) 57409,
        Double.longBitsToDouble(0x3fe3ee4b6811beffL), Double.longBitsToDouble(0x3fdedc433429ff5aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 15, 15, 5, "\uda66\udf5a\udada\ude76\ud9c9\udc8d\ud9f5\udf53\ud85b\uddc8\udb3c\udf45\ud91b\udd5e\udbf8\udd4f\udb03\udf84\ud981\uddad\udaaf\udd98\ud939\udfe1\ud81c\udd28\ud9a7\udf57\ud8ba\ude9a\udafc\ude04\ud913\ude23\udb27\udc28\ud89b\udfe5\ud880\udf58", "\u3ec5\u9b0d\u3725\uc4f6\u10ca\uca4b\u1444\u1e9c\u8b96\u2939\u29b7\u2ad3\u8425\uc7b8\u6c59\ub19a\uc106\u74e7\u4e1f\u63fd\u8198\ua5c4", "\ud825\udc46\u2d32\ud8f6\udd60\ud9f1\udef8",
        23, 63770, 1096112349, -8558782750829859243L, -7594L, true, false, (char) 32786, (char) 48085,
        Double.longBitsToDouble(0x3fef333b24514bb0L), Double.longBitsToDouble(0x3fce0aadc74e86dcL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 11, 11, 7, "\uda74\udf3e\ud806\ude6c\ud96b\udd0e\ud896\udd2c\ud857\udd67\udb3c\udf45\ud91b\udd5e\udbf8\udd4f\udaed\udebb\udbd4\udf80\uda79\udcb0\ud939\udfe1\uda8b\udfaa\udbfd\ude83\uda32\udfb4\ud845\udd40\uda2f\udcb1\ud973\udda0\udbd6\udc9a\ud880\udf58", "\u89e4\u321f\ub931\u687f\u50f7\u28f4\u76aa\u6a5c\ud670\u4a86\u6b54\u5243\u84c7\uc7b8\u6c59\u9d18\uc106\u626f\u4e1f\u63fd\uca38\ud188", "\ud825\udc46\uda3e\udf6b\ud8da\udc1c\udb0c\udee2",
        50, 97537, 1096112349, 6708341918550175284L, 52007L, false, false, (char) 15545, (char) 6185,
        Double.longBitsToDouble(0x3fe54855547b2f68L), Double.longBitsToDouble(0x3fe782ab73a28686L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 3, "\uda66\udf5a\ud8a2\udc7a\udb8b\udf7b\ud896\udd2c\ud857\udd67\udb3c\udf45\ud91b\udd5e\udbf8\udd4f\udaed\udebb\udae2\udff6\udaaf\udd98\ud939\udfe1\uda9d\udeaa\udbfd\ude83\uda32\udfb4\udb7b\udd3b\uda2f\udcce\ud973\udd0f\udbd6\udc9a\ud880\udf58", "\ua71b\u00d6\ub931\u6726\u50f7\uae4d\u671f\u3fa1\u579e\u9319\u6b54\u5243\u84c7\uc7b8\u6c59\ucd66\uc106\u626f\u4e1f\u63fd\u8198\ua5c4", "\ud825\udc46\udae7\ude3f\ud8f6\udd60\ud83c\udcbd",
        7, 97464, 1096112349, 6708341918550175284L, -7618L, true, false, (char) 59519, (char) 45296,
        Double.longBitsToDouble(0x3fe54855547b2f68L), Double.longBitsToDouble(0x3fce0aadc74e86dcL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 12, 12, 12, "\udb43\udfb5\ud8a2\udc43\udb8b\udf7b\ud896\udd2c\udb09\udfe0", "\u023c\u98af\u9ef7\ua1e5\u8c07\u154d", "\udb87\udd72\udb0f\udf79",
        56, 36634, 227056268, 3716890211245572540L, -28831L, true, false, (char) 32947, (char) 50527,
        Double.longBitsToDouble(0x3fca54bf7d7231fcL), Double.longBitsToDouble(0x3fbbd0d335c71aa8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_addExplicitAnyCreator|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.impl.CreatorCollector,com.fasterxml.jackson.databind.deser.impl.CreatorCandidate|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_addDeserializerConstructors|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.deser.impl.CreatorCollector,java.util.Map|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_addDeserializerFactoryMethods|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.deser.impl.CreatorCollector,java.util.Map|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_addExplicitDelegatingCreator|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.impl.CreatorCollector,com.fasterxml.jackson.databind.deser.impl.CreatorCandidate|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_addExplicitPropertyCreator|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.impl.CreatorCollector,com.fasterxml.jackson.databind.deser.impl.CreatorCandidate|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_checkIfCreatorPropertyBased|com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_checkImplicitlyNamedConstructors|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.deser.impl.CreatorCollector,java.util.List|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_constructDefaultValueInstantiator|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_createEnumKeyDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCreatorsFromProperties|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomArrayDeserializer|com.fasterxml.jackson.databind.type.ArrayType,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.JsonDeserializer|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomBeanDeserializer|com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomCollectionDeserializer|com.fasterxml.jackson.databind.type.CollectionType,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.JsonDeserializer|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomCollectionLikeDeserializer|com.fasterxml.jackson.databind.type.CollectionLikeType,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.JsonDeserializer|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomEnumDeserializer|java.lang.Class,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomMapDeserializer|com.fasterxml.jackson.databind.type.MapType,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.KeyDeserializer,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.JsonDeserializer|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_addExplicitAnyCreator|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.impl.CreatorCollector,com.fasterxml.jackson.databind.deser.impl.CreatorCandidate|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
