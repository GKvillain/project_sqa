package com.fasterxml.jackson.databind.ser.impl;
import org.junit.Test;
import static org.junit.Assert.*;
public class WritableObjectId_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 2, "\ud93f\udda6\ud8a5\udc7d\udb1e\uddc8\ud96e\udfb2\ud90e\udefe\udb54\udf49\udb51\udedd\ud922\ude1d\ud8e2\ude2d\udbe3\udc59\udab7\udee1", "\u115b\u7c1d", "\udb5c\udd72\ud885\udc9e\ud83a\ude9e\uc309\udaea\udf37\ud983\udc25\ud9eb\ude25\udbf0\udc2d\udaba\udda2\udbe4\udc11",
        44, 42958, -450794362, -4385112693343660568L, -2267L, true, true, (char) 16563, (char) 40181,
        Double.longBitsToDouble(0x3fbd7e0a739424a8L), Double.longBitsToDouble(0x3fe4a8bc6c715a35L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 0, "\ud8e5\ude05\ud8a5\udc7d\udb1e\uddc8\ud96e\udfb2\ud90e\udefe\udb54\udf49\udb51\udedd\ud919\udf9a", "\uc480\u6947\u04a3\u290f\u2597\u405a\u781b\u76f7\u05c2\uc800\u6213\uc058\uc61f", "\udaba\udda2\udbe4\udc11\ud8b4\udd75\ud8a3\udf67\uda70\udef0\udb8f\udfa6\ud9a7\udfa0\uda5f\udcb6\uda68\uddaa\udb44\udcd7",
        2, 25689, -2070568843, 1697186848578019989L, 45245L, false, false, (char) 3474, (char) 61502,
        Double.longBitsToDouble(0x3fe9993a8664f704L), Double.longBitsToDouble(0x3fd358e7764999f2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.ser.impl.WritableObjectId:@?\012",
        Z.run(T, 1, 2, 0, 2, "\ud93f\udda6\ud8a5\udc7d\udb1e\uddc8\ud96e\udfb2\ud90e\udefe\ud88e\udf86\udb68\udfc0\ud922\ude1d\ud8e2\ude2d\udbe3\udc59\udab7\udee1", "\u115b\u7c1d", "\udb5c\udd72\ud885\udc9e\ud83a\ude9e\uc309\udaea\udf37\ud983\udc25\ud9eb\ude25\udbf0\udc2d\udaba\udda2\udbe4\udc11",
        44, 42958, -450794362, -4385112693343660568L, -2267L, true, true, (char) 16563, (char) 40181,
        Double.longBitsToDouble(0x3fbd7e0a739424a8L), Double.longBitsToDouble(0x3fe4a8bc6c715a35L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.impl.WritableObjectId:@?\012",
        Z.run(T, 1, 3, 1, 2, "\ud99d\uddb5\ud88f\udfbd\udb1e\uddc8\ud96e\udfb2\ud90e\udefe\udb54\udf49\ud947\udf38\ud922\ude1d\ud8e2\ude2d\udbe3\udc59", "\u04a3\u115b\u7c1d\u897b\u781b\u76f7\u05c2", "\udaea\udf37\ud983\udc25\ud91e\udd21\udb2f\udf2e\udae9\udff1\udbe4\udc11\ud8b4\udd75\ud8a3\udf67\uda70\udef0\udb8f\udfa6\uda0e\ude54\ud809\udd52\uda4d\udcaa\udb44\udcd7\udae4\udf08\udb0a\udc1a\ud81c\udd2f\ud92f\udfd5\udbab\udfe5\ud931\udd60\ud867\uddca\uda83\udc63\udb06\udc8e\ud937\udedd\u7692\udbfb\udfed\ud9a9\udef6\uda9b\ude0f\udb2b\udfc3\udb24\udd1e\ud825\udcd5\udb05\udf53\uda68\udef7\ud9f7\udee4\udaba\udf0f\udb59\udd7d\ud882\udff0\ud800\udda5\ud8d3\udd5d\ud9cd\udc33\ud9c5\udc37\udb72\ude29\ud932\udccb\uda39\udc4f",
        5, 47845, 1922499561, -6360164324000103276L, -85983L, true, false, (char) 18675, (char) 18049,
        Double.longBitsToDouble(0x3fe80a810d95f853L), Double.longBitsToDouble(0x3fdc87069de54f60L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.impl.WritableObjectId:@?\012",
        Z.run(T, 1, 3, 1, 2, "\udb00\udc71\u6844\ud9eb\uddfa\ud96f\udc00\ud8fe\udccc\ud96e\udc93\ud87e\udc5e\uda65\udf0b\udb74\udd14\ud92b\udd4e\udb20\udd43", "\ucaca\u0513\u9728\u781b\u76f7\u05c2\u553d\u0649\ubf44\ucd7a\uc95b\ua1a9\u593d\u086f\u19f4\u95a6\u5e3d\u831c\u0882\uc9aa\u7315\u9842\u7968", "\ud9cf\ude97\udbc5\udf7a",
        47, 43314, -1124488379, -7829611107034689688L, 41818L, true, false, (char) 34768, (char) 11092,
        Double.longBitsToDouble(0x3fefae47a87435faL), Double.longBitsToDouble(0x3fed054be3fc4f7dL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.impl.WritableObjectId:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 2, "\ud93f\udda6\ud8a5\udc7d\udb1e\uddc8\ud80f\udedd\ud90e\udefe\udb54\udf49\udb51\udedd\ud922\ude1d\ud8e2\ude2d\udbe3\udc59\udab7\udee1", "\u117f\u7c1d", "\udb5c\udd72\ud88d\udefd\ud83a\ude71\uc309\udaea\udf37\ud983\udc25\ud9eb\ude25\udbf0\udc2d\udac7\udeac\udbe4\udc11",
        44, 42958, -450794362, -4385112695722945048L, -2267L, true, true, (char) 16563, (char) 40181,
        Double.longBitsToDouble(0x3fbd7e0a7bc59ca8L), Double.longBitsToDouble(0x3fe408bf0c715ad4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.impl.WritableObjectId:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 0, "\ud8e5\ude05\udb92\ude92\udbd6\udc90\ud8cb\udcfa\ud91e\ude39\udb35\udf20\udba2\ude26\u0e81\ud811\udec5\udbe3\udc59\ud92e\ude56", "\u5c9d\u6885", "\udb56\udc9f\ud885\udc9e\ud934\udcbb\udb18\udc2f\ud997\udd11\ud998\udd78\udbd8\udf30\udbef\udff4\udab9\udc9d\udbe4\udc11",
        19, 10029, -440920303, -4385112693343660568L, -25611L, false, false, (char) 37229, (char) 41108,
        Double.longBitsToDouble(0x3fe04c1c4a93bdabL), Double.longBitsToDouble(0x3fe9993a8564f704L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.ser.impl.WritableObjectId:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 2, "\ud93f\udda6\ud8a5\udc7d", "\u35b9\u5536\u56f8\u3ad3", "\ud9fc\udc0b\uda1d\udc16\udaae\udd4c\ud858\udf50\ud8e5\udf7b\udad9\ude3e\uda29\ude23\udb5c\udd72\ud885\udc9e\ud83a\ude9e\udb35\udfac\udb0b\udc9d\ud983\udc08",
        10, 18894, -5893720, -9189674661542291522L, -6682L, true, true, (char) 39180, (char) 59120,
        Double.longBitsToDouble(0x3fe1dd5447517b32L), Double.longBitsToDouble(0x3fe464913a91c464L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.ser.impl.WritableObjectId:@?\0121=new com.fasterxml.jackson.databind.ser.impl.WritableObjectId:@?\012",
        Z.run(T, 2, 2, 3, 2, "\ud92e\udc6f\ud8a5\udc7d\udb1e\uddc8\ud96e\udfb2\ud90e\udefe\ud88e\udf86\ud91e\udffb\ud922\ude1d\u674a\udbea\udc59\udab7\udee1\udb6c\udf74\udb4c\udc00\ud9e0\udca7\udaa5\udf7b\udad9\ude3e\uda29\ude23\udb5c\udd72\ud885\udc9e\ud83a\ude9e\uc309\udb52\uddeb\ud983\udc25", "\u122e\u8760\u44a2\u4517\u5990\u31bb\u0882\u8474\u8c3e\u7538\u77e6\uae2a\u92e9\u4ad1\u1d7f\ucc0a\u45f6\u459f\u70d4\u7dbf\ub12c\u911f\u27cd\u3718\ua7d7\u8903\u8ad6\u78ba\u0844\ua63a\u20e6\u940d\u85fd\uaefc\ub70d\u9097", "\ud89f\udc54\ud9d3\ude52\udb9a\udd74\ud9c6\udc7c\ud823\udf27\udbdb\ude9c\ua849",
        43, 45538, -206603965, -7316387685274547237L, 32834L, false, true, (char) 49329, (char) 51920,
        Double.longBitsToDouble(0x3feb001b5ed93adeL), Double.longBitsToDouble(0x3fd359eb848ee712L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.ser.impl.WritableObjectId:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.ser.impl.WritableObjectId:@?\012",
        Z.run(T, 2, 2, 2, 3, "\ud8bb\udde3\ud88f\udfa6\udb0a\udcfe\ud96f\udc5f\ud90e\udefe\udb54\udf49\ud947\udf38\ud922\ude1d\udb1d\ude88\udaf8\udf3b", "\u04a3\u732c\u9536\u59c1\ua93d\u76f7\u423a", "\ud9f9\udecd\ud9a1\udc7d\uff87\ud80c\ude33\udae9\udff1\u8013\ud8b4\udd75\ud8a3\udf67\uf7d1\uda95\udd82\uda2b\ude51\ud91b\udfc4\ud8de\udddd\udb67\udee0\ud9f8\udf51\udb09\udfac\ud81c\udd2f\ud92f\udfd5\uda38\udfea\ud931\udd60\udb9d\udeac\uda83\udc63\udaff\udc8e\ud937\udedd\u7692\uda5b\udf5c\udb00\uddea\udb33\ude12\ud8a3\uddff\ud818\udd77\u62e8\udb05\udf74\uda68\udef7\ud9f7\udee4\udaba\udf0f\udb59\udd7d\uda36\udda9\udb85\ude69\ud8d3\udd5d\ud9cd\udc33\ud9c5\udc37\udb72\ude29\ud932\udccb\uda39\udc4f",
        5, 99525, -1756729893, -6360163875763223404L, 24947L, false, false, (char) 18675, (char) 10468,
        Double.longBitsToDouble(0x3fe83a810de03253L), Double.longBitsToDouble(0x3fda37069de54f60L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.impl.WritableObjectId:@?\0121=new com.fasterxml.jackson.databind.ser.impl.WritableObjectId:@?\012",
        Z.run(T, 2, 3, 3, 2, "\ud99d\uddb5\ud88f\udfbd\udb1e\uddc8\ud96e\udfb2\ud90e\udefe\ud9e1\ude49\ud91b\udd08\ud8cb\udc46\uda36\uddff\udbe3\udc59", "\u04a3\u7130\u92b5\uc29a\u781b\u76f7\u05c2", "\udaea\udf37",
        33, 4986, 867195939, -7609104985905208498L, 65242L, true, true, (char) 55390, (char) 39180,
        Double.longBitsToDouble(0x3f9ac351c31a19e0L), Double.longBitsToDouble(0x3fea8b7c3da49227L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 2, "\ud93f\udda6\ud8a5\udc7d\udab6\udfd3\udba7\udebe\ud90e\udefe\udb54\udf49\ud8ff\uddd9\ud922\ude1d\ud8e2\ude2d\udbe3\udc59\udab7\udee1", "\u115b\u7c1d", "\udb5c\udd72\ud885\udc9e\ud83a\ude9e\udb65\udfff\udac5\udd75\ud983\udc25\udbef\ude27\udbf0\udc2d\udaba\udda2\udbe4\udc11",
        44, 42958, 1254452358, 1932648327781930329L, 63269L, true, false, (char) 5598, (char) 62639,
        Double.longBitsToDouble(0x3fbd7e0a739424a8L), Double.longBitsToDouble(0x3fe4a8bc6cf7ae35L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ser.impl.WritableObjectId|generateId|java.lang.Object|new:com.fasterxml.jackson.databind.ser.impl.WritableObjectId:com.fasterxml.jackson.annotation.ObjectIdGenerator",
    "M|com.fasterxml.jackson.databind.ser.impl.WritableObjectId|writeAsField|com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.ser.impl.ObjectIdWriter|new:com.fasterxml.jackson.databind.ser.impl.WritableObjectId:com.fasterxml.jackson.annotation.ObjectIdGenerator",
    "M|com.fasterxml.jackson.databind.ser.impl.WritableObjectId|writeAsId|com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.ser.impl.ObjectIdWriter|new:com.fasterxml.jackson.databind.ser.impl.WritableObjectId:com.fasterxml.jackson.annotation.ObjectIdGenerator",
    "C|com.fasterxml.jackson.databind.ser.impl.WritableObjectId|<init>|com.fasterxml.jackson.annotation.ObjectIdGenerator",
    "M|com.fasterxml.jackson.databind.ser.impl.WritableObjectId|generateId|java.lang.Object|new:com.fasterxml.jackson.databind.ser.impl.WritableObjectId:com.fasterxml.jackson.annotation.ObjectIdGenerator",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
