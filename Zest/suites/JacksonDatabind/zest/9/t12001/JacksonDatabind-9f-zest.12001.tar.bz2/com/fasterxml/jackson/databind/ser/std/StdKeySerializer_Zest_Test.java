package com.fasterxml.jackson.databind.ser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class StdKeySerializer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 3, "\udb81\udd2d\ud853\udc29\udba6\ude4d\ud86e\udc7f\ud823\udfca\ud906\ude28\uda6e\udd19\uda1c\udfe9\ud931\udc7d\udb79\uddba\udb7e\uddc0\udb98\ude96\ud89e\ude1c\udafc\udd94\ud9a6\udecf\ud849\ude32\ud949\udc29\u95d1\udbae\udc20\ud8a7\ude9c\uda6d\ude33\udb5d\udd27", "\u0848\u948e\u0bfd\u6fa4\uc3cc\u1f7b\u66cf\uaa6c\u8680\u5928\ub115\uad66\u31f1\u09cd\ud25b\u6737\u5197\u5733\u143c\uab01\ub0a4\u27a8\u2f73\u928f\u024c\u4e0e", "\udb8f\udf7b",
        11, 35958, -614782639, -2496542307470652229L, -90067L, false, true, (char) 21416, (char) 22468,
        Double.longBitsToDouble(0x3fd744b6a45cd8b8L), Double.longBitsToDouble(0x3fd24a6819618ec0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 0, "\udb81\udd2d\ud853\udc29\udba6\ude4d\ud86e\udc7f\ud823\udfca\ud906\ude28\uda6e\udd19\uda1c\udfe9\ud931\udc7d\udb79\uddba\udb7e\uddc03\000\000\ud9a6\ude41\ud849\ude32\ud949\udc29\u95d1\udbae\udc20\ud8a7\ude9c\uda6d\ude33\udb5d\udd27", "\u0848\u948e\u0bfd\u6fa4\u8b31\u1f7b\u66cf\uaa6c\u8680\u5928\ub115\uad66\u31f1\u09cd\ud25b\u6737\u5197\u5733\u143c\uab01\ub0a4\u27a8\u2f73\u928f\u024c\u4e0e", "\udb8f\udf7b",
        11, 35958, -614782639, -2496542307470652229L, -90067L, false, true, (char) 21416, (char) 22468,
        Double.longBitsToDouble(0x3fd744b6a45cd8b8L), Double.longBitsToDouble(0x3ec032c31c000000L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 3, "\udb81\udd2d\ud853\udc29\udba6\ude4d\ud86e\udc7f\ud823\udfcag\000\000\ud931\udc7d\udb79\uddba\udb7e\uddc0\udb98\ude96\ud89e\ude1c\udafc\udd94\ud9a6\udecf\ud849\ude32\udb32\uddbe\000\udb99\ude6b\ud8a7\ude9c\u0089\udb54\udc69", "\u0848\u948e\u0bfd\u6fa4\uc3cc'\u2a37\uaa6c\u8680\u501b\ub115\uad66\u009e\u090e\ud25b\u009c\u8f68\u5733\u143c\uab01\ub0a4\u27a8\u2f73\u928f\u024c\u4e0e", "\udb8f\udf7b",
        11, 35958, -614782639, -2496542307470652229L, -90067L, false, true, (char) 21416, (char) 22468,
        Double.longBitsToDouble(0x3fd744b6a45cd8b8L), Double.longBitsToDouble(0x3fd24a68100000c0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 1, 3, 3, 3, "\udabb\ude6a\ud853\udc4d\udba6\ude4d\ud86e\udc7f\ud823\udfca\ud906\ude28\uda6e\udd19\uda1c\udfe9\ud931\udc7d\ud9a8\udd64\udb7e\uddc0\udb98\ude96\ud89e\ude1c\udafc\udd94\ud9a6\udecf\ud849\ude32\ud8b3\ude9f\ud800\udd1b\udbae\udc20\ud8a7\ude9c\uda6d\ude33\udbfc\udd16", "\u0848\u948e\u0bfd\u6fa4\uc3cc\u1f7b\u47ff\u871b\u9c49\u68d9\uabea\u1d68\u06c5\u09a7\ud25b\u8441\u4c6d\u56f7\u143c\uab01\ub0a4\u27a8", "\udb62\uddc0\uda14\ude8b\ud969\udc8d\ud800\udf5e\udb8f\udf7b\ud8b9\udc5c",
        29, 93297, -388621056, 2001490634609770816L, -49188L, true, true, (char) 22468, (char) 24798,
        Double.longBitsToDouble(0x3fe17362e524a681L), Double.longBitsToDouble(0x3fc618ec19c396a8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=new com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 3, 3, 3, "\udb81\udd2d\ud853\udc29\udba6\ude4d\udab5\ude23\ud8ec\udf1d\udbe8\udfed\ud96d\uddeb\uda28\udee7\ud930\udf99\udb72\ude2e\udb7e\uddc0\udb98\ude96\ud89e\ude1c\udafc\udd94\ud99d\udc2a\ud826\ude43\ud949\udc29\u95d1\uda2f\udf6c\ud8a7\ude9c\uda6d\ude33\udb5d\udd27", "\u0848\u948e\u0bfd\u6fa4\uc3cc\u1f7b\u66cf\uaa6c\u05c0\u5923\ub115\u8a92\uc196\u87f4\u1beb\u7bf5\u5197\u6112\u302d\uab01\u73c8\u27a8\u2f73\u928f\u024c\u4e0e", "\udb8f\udf7b",
        11, 35958, -614782639, -2496542307470652229L, -90067L, false, true, (char) 55976, (char) 22382,
        Double.longBitsToDouble(0x3fd744b6a45cd85eL), Double.longBitsToDouble(0x3fd24a6819618ec0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 3, "\udb81\udd2d\ud853\udc29\udba6\ude4d\ud86e\udc7f\ud823\udfcag\000\000\ud931\udc7d\udb79\uddba\udb7e\uddc0\udb98\ude96\ud89e\ude1c\udafc\udd94\ud9a6\udecf\udaf0\udc65\udb32\uddbe\000\udb99\ude6b\ud8a7\ude9c\ud98a\udc8d\udb54\udc69", "\u0848\u948e\u0bfd\u6fa4\uc3cc'\u2a37\uaa6c\u8680\u501b\ub115\uad66\u009e\u090e\ud25b\u009c\u8f68\u5733\u143c\uab01\ub0a4\u27a8\u2f73\u928f\u024c\u4e0e", "\udb8f\udf7b",
        11, 93142, -992527851, -2496542307470652229L, -90067L, false, true, (char) 21416, (char) 22468,
        Double.longBitsToDouble(0x3fd744b6a45cd8b8L), Double.longBitsToDouble(0x3fd24a68100000c0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 1, 3, 0, 3, "\udb81\udd2d\ud853\udc29\udba6\ude4d\u887a\ud823\udfcag\000\000\ud931\udc7d\udb79\uddba\udb7e\uddc0\udb98\ude96\ud89e\ude1c\udafc\udd94\ud9a6\udecf\ud849\ude32\udb32\uddbe\000\udb99\ude6b\ud8a7\ude9c\u0089\udb54\udc69", "\u0848\u948e\u0bfd\u6fa4\uc3cc'\ud6a6\uc168\u8680\u501b\ub115\uad66\u009e\u090e\ud25b\u009c\u8f68\u5733\u143c\uab01\ub0a4\u27a8\u2f73\u928f\u024c\u4dcf", "\udbe4\udce5",
        19, 24656, -614782700, -2496542307470652229L, -90067L, false, true, (char) 21416, (char) 22468,
        Double.longBitsToDouble(0x3fd744b6a45cd8b8L), Double.longBitsToDouble(0x3fd24a68100000c0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=new com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 3, 3, 1, "\udab4\udf76\ud853\udc29\udba6\ude4d\udab5\ude23\ud947\udd0b\uda11\udce2\ud96d\uddeb\uda28\udee7\ud848\udc63\ud914\uded3\udb7e\uddc0\udaa2\ude9a\uda6e\uddfb\udb56\udc19\ud99d\udc2a", "\u51bb\u97aa\u0a67\ucb61\u8e1c\u79d5\u7368\u81c4", "\ud8b4\ude08\ud8c5\ude2b\ud90a\udc73\uda23\udf22",
        31, 86279, -344766793, 3414327122060088570L, -13191L, true, false, (char) 40289, (char) 9385,
        Double.longBitsToDouble(0x3fe6aa1fda797ec3L), Double.longBitsToDouble(0x3fea085c85d9543aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 3, "\ud9a3\ude8d\udb44\udc56\udba6\ude6a\ud86e\udc7f\ud92d\udeaf\u00cc\000\000\ud931\udc7d\ud99d\udceb", "\u875b\u13d8\u0507", "\000\udbcb\udcb2\ud8a7\ude9c\ud9c9\udee6\udb54\udc69\ud8a2\udd93\ud9d9\udfcd\udbab\uded6\ud922\udf3b\udb77\udcd1\ud8b4\ude08\uda85\udf91H\uda14\ude8a\udbb9\udd08\ud9dd\udefa\ub111\udbac\udc95\uda57\udda5\u009e\udb78\udeec",
        40, -844, 1124073472, 6102256364318408327L, 22204L, true, false, (char) 7173, (char) 18439,
        Double.longBitsToDouble(0x3fdb4909738397c2L), Double.longBitsToDouble(0x3fe461f99000003dL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 3, "\udb81\udd2d\ud853\udc29\udba6\ude4d\u887a\ud823\udfcag\000\000\ud931\udc7d\udb79\uddba\udb7e\uddc0\udb98\ude96\ud89e\ude1c\udafc\udd94\ud9a6\udecf\ud849\ude32\udb32\udd35\000\udb99\ude6b\ud8a7\ude9c\u0089\udb54\udc69", "\u0848\u948e\u0bfd\u6fa4\uc3cc\u00b6\ud6a6\uc168\u8680\u501b\ub115\uad66\u009e\u090e\ub8e1\u725b\u6cf2\u95c2\u143c\uab01\ub0a4\u27a8\u2f73\u928f\u0330\u4dcf", "\udbe4\udce5",
        19, 24656, -614782700, -2496542307470652229L, -90067L, false, true, (char) 21416, (char) 22468,
        Double.longBitsToDouble(0x3fd744b6a45cd8b8L), Double.longBitsToDouble(0x3fd24a68100000c0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 3, "\udb81\udd2d\ud853\udc29\udba6\ude4d\ud86e\udc7f\ud823\udfca\ud906\ude28\uda6e\udd19\uda1c\udfe9\ud931\udc7d\udb79\uddba\uda0d\udc08\ud934\udc05\ud81c\ude6a\ud8dc\uddcb\uda53\udc67\udb38\udf10\ud949\udc29\u95d1\udbae\udc20\ud8a7\ude9c\uda6d\ude33\udb5d\udd27", "\ua944\u9e7e\uacc8\u6fa4\uc3cc\u1f7b\u66cf\uaa6c\u8680\u5928\ub115\ub8a8\u31eb\u09cd\ud25b\u6737\u5197\ucb15\u451f\u183e\ub0a4\ua122\u2f73\u928f\u024c\u4e0e", "\udb8f\udf7b",
        11, 35958, -614782639, -2496542307470652229L, -90067L, false, true, (char) 21416, (char) 22468,
        Double.longBitsToDouble(0x3fd744b6a45cd8b8L), Double.longBitsToDouble(0x3fd24a6819618ec0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 3, "\ud9a3\ude8d\udb44\udc56\udba6\ude6a\ud86e\udc7f\ud92d\udeaf\u00cc\000\000\ud931\udc7d\ud99d\udceb", "\u875b\u13d8\u0507", "\000\udbcb\udcb2\ud8a7\ude9c\ud9c9\udee6\udb54\udc69\ud8a2\udd93\ud9d9\udfcd\ud8ef\uddb8\ud836\uddff\ud938\udde5\ud8b4\ude08\uda85\udf91H\uda14\ude8a\udbb9\udd08\ud9dd\udefa\ub111\udbac\udc95\uda57\udda5\u009e\udb78\udeec",
        40, -844, 1124073472, 6102256362978283143L, 22204L, true, false, (char) 7173, (char) 18439,
        Double.longBitsToDouble(0x3fdb4909738397c2L), Double.longBitsToDouble(0x3fe461f99100003dL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ser.std.StdKeySerializer|serialize|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.std.StdKeySerializer:",
    "M|com.fasterxml.jackson.databind.ser.std.StdKeySerializer|acceptJsonFormatVisitor|com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ser.std.StdKeySerializer:",
    "M|com.fasterxml.jackson.databind.ser.std.StdKeySerializer|getSchema|com.fasterxml.jackson.databind.SerializerProvider,java.lang.reflect.Type|new:com.fasterxml.jackson.databind.ser.std.StdKeySerializer:",
    "C|com.fasterxml.jackson.databind.ser.std.StdKeySerializer|<init>|",
    "M|com.fasterxml.jackson.databind.ser.std.StdKeySerializer|serialize|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.std.StdKeySerializer:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
