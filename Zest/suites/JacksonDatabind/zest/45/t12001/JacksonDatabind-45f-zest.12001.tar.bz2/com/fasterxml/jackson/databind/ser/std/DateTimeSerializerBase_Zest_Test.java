package com.fasterxml.jackson.databind.ser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class DateTimeSerializerBase_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 9, 5, 9, "\ud850\udd95", "\u7251\uc10e\u2fbc\uce8e\u9794\u87dd\u1a7a\ucdbc\u424e\ub62e\u244f\u34c0\ubcd2\u81fa\u26ad", "\ud80d\udea7\ud95d\udd61\udad6\udc8d\ud8ea\udf0e\ud874\udf80\ud995\udd7c\ud91e\uddfb\ueb61\uda83\udfa3\udaa3\udc6a\udba9\uddf6\udb9d\udc32\udbd3\udf7a\ud815\udeb2\ud8c6\udcda\udaba\udfea",
        29, 80374, 2096700747, -6118788535448523500L, 8576L, false, false, (char) 55299, (char) 54553,
        Double.longBitsToDouble(0x3fe313570abda342L), Double.longBitsToDouble(0x3fecc041f754c5acL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 9, 5, 9, "\ud850\udd95", "\u7251\uc10e\u2fbc\uce8e\u9794\u87dd\u1a7a\ucdbc\u424e\ub62e\u08c0\u352d\ubcd2\u81fa\u26ad", "\ud80d\udea7\ud95d\udd61\udad6\udc8d\ud8ea\udf0e\ud874\udf80\ud995\udd7c\ud91e\uddfb\ueb61\uda83\udfa3\udaa3\udc6a\udba9\uddf6\udb9d\udc32\udbd3\udf7a\ud815\udeb2\ud8c6\udcda\udaba\udfea",
        29, 80374, 2096700747, -6118788535448523500L, 8576L, false, false, (char) 55299, (char) 54553,
        Double.longBitsToDouble(0x3fe313570abda342L), Double.longBitsToDouble(0x3fecc041f754c5acL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 0, 1, 9, "\ud850\udd95", "\u7251\u049e\u4978\uce8e\u9794\u87dd\u1a7a\ucdbc\u3454\ub642\u244f\u49b2\ubd01\u0527\u2724", "\ud80d\udea7\ud98b\udd58\udad6\udc8d\ud8ea\udf0e\udacc\udf8c\ud8ea\udfcd\udb05\ude67\ud864\uddc2\ud8fa\udcbd\uda03\udd09\udbc9\udef4\udbaa\udc7d\udbd3\udf7a\ud815\udeb2\ud8c6\udcda\uda7a\udcea",
        29, 72038, -131946273, -8223121037867635436L, 41150L, true, false, (char) 55299, (char) 54553,
        Double.longBitsToDouble(0x3fe313570add44afL), Double.longBitsToDouble(0x3fec9e283071377dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 7, 1, 7, "\udbc8\uded1\ud8a2\udddc\uda8b\udecb\ud9d6\udfee", "\uce8e\u9794\u87dd\u1a7a\ucdbc\u35e9\ud106", "\ud912\udfa3\udbcf\ude25",
        16, 18027, -1019620171, -1837010319529574696L, 52761L, false, false, (char) 14721, (char) 51032,
        Double.longBitsToDouble(0x3fc4f1fe0dadf294L), Double.longBitsToDouble(0x3fd63fa4f0975754L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 9, 7, 9, "\udaa1\ude16", "\u7251\uc10e\u2fbc\uce8e\u9794\u87dd\u0e53\u5f47\ud0ac\u3719\u244f\uae9f", "\udb4f\udd7f\udb3b\udde8\udbd7\udc2e\udb52\udd14\ud957\udcb0\ud892\udd0a\udb5c\udfd0\udbc6\udf46\ud98a\uddb5\ud91e\uddfb\ueb61\uda83\udfa3\udaa3\udc6a\udba9\uddf6\udb9d\udc32\udbd3\udf7a\ud815\udeb2\uda60\udd99\udb67\uded4",
        -2, 83772, 2092500746, -6118788535448523500L, 8576L, false, false, (char) 55299, (char) 54553,
        Double.longBitsToDouble(0x3fe313570dbda342L), Double.longBitsToDouble(0x3fe84b05de331021L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 6, 9, "\ud8e9\udfa2", "\u7232\u0153\u2fb1\u628e\u9794\u2792\ua536\ucdbc", "\ud81b\udf6a\ud815\udd03\ud912\udfa3\udbcf\ude25\udb4f\udd7f\ud885\ude17\ud5b3\ud88d\udc33\uda6d\ude2b",
        42, 60365, -1789335684, -6229744740173040083L, 59773L, false, false, (char) 56179, (char) 15045,
        Double.longBitsToDouble(0x3fef92fc2a38cb84L), Double.longBitsToDouble(0x3fc548cdd315b400L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 1, 8, 9, "\ud8cd\uddaa", "\uaa8c\uc10e\u2fbc\uce8e\u9794\u87dd\u1a7a\ucdbc\u424e\ub62e\u244f\u34c0\ubca9\u81fa\u26ad", "\ud80d\udea7\ud94f\udd61\udad6\udc8d\ud8ea\udf0e\ud874\udf80\ud995\udd7c\ud91e\ude32\ueb61\uda83\udfa3\udaa3\udc6a\udba9\uddf6\udb9d\udc32\udbd3\udf7a\ud815\udeb2\ud8c6\udcda\ud94b\udc2f",
        57, 58442, 2096700747, -6118788535448523500L, 8576L, false, false, (char) 55299, (char) 54553,
        Double.longBitsToDouble(0x3fe313570887792fL), Double.longBitsToDouble(0x3fd27496339bf870L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 1, 5, 9, "\ud850\udd95", "\u7251", "\uda12\ude18\uda25\udd21\udbb4\udc97\udb28\udf00\ud9d0\udfb4\ud900\udef0\ud9b1\udeb6\udaee\ude44\ud815\udd03\uda47\ude5d\udbcf\ude25\udb4f\udd7f\udb3b\udde8\ud9c1\udd5b\udabc\udeff",
        54, 91730, 1789613253, -2666255258601027075L, 10237L, true, false, (char) 40072, (char) 15347,
        Double.longBitsToDouble(0x3fd11f9b37e4bf0aL), Double.longBitsToDouble(0x3fe23e5c22771bd1L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 5, 9, "\ud850\udd95", "\u72c0\uc10e\u2fbc\uce8e\u9794\u87dd\uc737\u485d\u424e\ub62e\u244f\u34c0\ua226\u81fa\u4de6", "\ud816\uddb0\udaf9\uddce\ud8e0\udff1\ud884\udc54\ud935\udd53\ud995\udd26\ud91e\uddfb\uda27\ude16\udb80\uddc9\udaba\udebf\uda44\udf04\uda96\udf9b\ud8cd\ude40\ud880\udfef\ud8c6\udcda\udaba\udfea",
        29, 80374, 2096700747, -3957060714369350892L, -25675L, false, false, (char) 57155, (char) 54597,
        Double.longBitsToDouble(0x3fecc4309f54c5acL), Double.longBitsToDouble(0x3fcf36d5a01353e8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 8, 5, 9, "\ud850\udd95", "\u7251", "\uda12\ude18\uda25\udd21\udbb4\udc97\udbe8\udf00\ud9d0\udfb4\ud900\udef0\ud9b1\udeb6\udaee\ude44\ud815\udd03\ud912\udfa3\udbcf\ude25\udb4f\udd7f\udb3b\udde8\ud9c1\udd5b\ud80d\udea7\ud9f1\udf6a\uda72\ude94",
        1, 46224, -21762672, -8146791115668336344L, 10237L, true, false, (char) 56674, (char) 15373,
        Double.longBitsToDouble(0x3fd11f9b37e4bf0aL), Double.longBitsToDouble(0x3fe23e5c24771bd1L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 6, 9, "\ud850\udd95", "\u7251\uc10e\u2fbc\uce8e\u9794\u87dd\u1a7a\ucdbc\u424e\ub62e\u8e7a\u34cf\ubcd2\u81fa\u26ad", "\ud80d\udea7\ud95d\udd61\udad6\udc8d\ud8ea\udf0e\ud874\udf80\ud995\udd7c\ud91e\uddfb\ueb61\uda83\udfa3\udaa3\udc6a\udba9\uddf6\udb9d\udc32\udbd3\udf7a\ud815\udeb2\ud8c6\udcda\udaba\udfea",
        29, 80374, 2096700747, -6118788535448523500L, 8576L, false, false, (char) 55299, (char) 54553,
        Double.longBitsToDouble(0x3fe313570abda342L), Double.longBitsToDouble(0x3fecc041f754c5acL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 3, 9, 7, "\ud985\udcfd", "\u7251\uc10e\u2fbc\uce8e\uafdb\u87dd\u1a7a\ucdbc\u424e\u1131\u241f\u34c0\ubcd2\u81fa\u26ad", "\ud80d\udea7\ud95d\udd61\udad6\udc8d\ud8ea\udf0e\ud874\udf80\ud995\udd7c\ud91e\uddfb\ueb61\uda83\udfa3\udaa3\udc6a\ub202\ud8b1\udc43\uda11\udc10\udb60\udce2\udb51\udd13\ud907\ude10",
        29, 47862, -754113955, -6101101666850067180L, -20996L, true, true, (char) 55299, (char) 54553,
        Double.longBitsToDouble(0x3fe313570e9fa342L), Double.longBitsToDouble(0x3fe0e04ac89a7169L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 6, 5, 9, "\ud850\udd95", "\u327f\ucae2\u2fbc\u55aa\ua845\u55fd\ua3a9\ucd10\u424e\ub62e\u244f\u34c0\ubcd2\u81fa\u26ad", "\ud80d\udea7\ud957\udc61\udad6\udc8d\ud8ea\udf0e\ud874\udf80\ud995\udd7c\ud91e\uddfb\udad0\udfd3\udb23\uddbc\udaeb\udce0\udbef\uddd1\ud81b\udc51\u3b90\udae5\uddda\ud945\ude41\udabb\udc8c",
        29, 80374, 2060197195, -6118787792419181292L, 8576L, false, false, (char) 55299, (char) 54553,
        Double.longBitsToDouble(0x3fe313570abda342L), Double.longBitsToDouble(0x3fecc041f754c5acL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 1, 6, 8, "\ud829\udf01\ud912\ude28\uda8b\ude40\ud804\udc9d", "\uce8e\u9794\u432e\u7e39\u270e\uc48a\ud106\u6739\u3481\ubcd2\u81fa\ua89f\u01f8\u4cad\u8da1\u98b2\ub729\u10cd\u44d7\u54ea\u9bd4\u5882\u8cac\ua56e\u558d\u74ba\ucfdc\uac2d\u7375\u1151\u123d\uc184\u4013\ud692", "\ud8cf\udd05\ud820\udc09\uda07\udd55\ud813\udd66\uda8f\udf50\u5ec8\udafb\ude94\uda5a\udd5d\uda34\udf53\u3183\udaf6\ude2a\udb0c\ude2d\ud94d\uddfd\uda7a\ude71\ud860\udfe4\udbe2\uddcb\uda7c\ude40\ud93a\udc1e\uda19\udd09\uda39\ude2a\udb37\udf78",
        31, 46752, 1382565520, 7227855407535062599L, 470L, true, false, (char) 5578, (char) 49864,
        Double.longBitsToDouble(0x3fddcc5191443ffcL), Double.longBitsToDouble(0x3fe6815dac26fd8eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=void |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 9, 1, 1, "\ud8e9\udfa2\ud836\udc5d\ud86b\ude0d\ud9d6\udff1\uda27\udd60\udbc4\ude26\ud9f7\ude18\ud840\udd17\ud92f\udcf4\ud8e4\udf01\ud9d0\udfb4", "\u95ce\u34c0\ubcd2\u81fa", "\ud8fe\udc7c\udaea\uddc1\uda48\udd74",
        42, 47015, 1664839619, 4493547663702968840L, -71479L, true, false, (char) 29639, (char) 53520,
        Double.longBitsToDouble(0x3fb757c2888fcd98L), Double.longBitsToDouble(0x3feda01c2a383664L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 5, 9, "\ud850\udd95", "\u848f\uc10e\u2fbc\uce8e\u9794\u87dd\uc737\u485d", "\udaee\ude44\ud815\udd03\ud835\udd73\udbcf\ude25\ud8a3\udd92",
        33, 17053, 734048028, 2511165538993297276L, 3738L, false, true, (char) 51032, (char) 45080,
        Double.longBitsToDouble(0x3fdf253b0f71faaeL), Double.longBitsToDouble(0x3fb2eaeabc4d33e8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 9, 9, 3, "\ud850\udd95\ud890\uddc9", "\uc10e\u2fbc\uce8e\u9794\u87dd\u2f38\u488f\u424e\ub62e\u244f\u34c0\ua226\uaa2f\u4e3a\u8bfd\u98ba\u1af7\u6c53\ubcb2\u2fb7\u4a07\u4a19\u42a5\u0458\u26cb\u2bc4\u4634\u408e\u7eb0\u093b\u5b8d\uab3f\ub26a\u04fa\u61ab\u0129\u3be8\u82d1\u0d6e", "\udbf7\udc47\udbf0\uddc5\uda56\udd75\ud816\udc28\udb1e\udf01\udbde\ude6f\uda91\udffc\udb77\uddc1\uda11\udc61",
        35, 49261, -75115778, -6795123085522993347L, 22230L, true, false, (char) 14940, (char) 15043,
        Double.longBitsToDouble(0x3fcaf2e9f5b28968L), Double.longBitsToDouble(0x3fea8ef155190330L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 9, 0, 6, "\ud850\udd95", "", "",
        -5, -1000, -1644167168, -1070219023104343925L, -100000L, false, false, (char) 23420, (char) 15023,
        Double.longBitsToDouble(0x3fe2338b544635e5L), Double.longBitsToDouble(0x3e0fc8f380000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=void |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 9, 1, 9, "\ud850\udd95", "\u21dd\ud701\u2fbc\uce8e\u9794\u87dd\uc737\u485d\u41fe\ub62e\u244f\u34c0\ua226\u81fa\u4de6", "\ud816\uddb0\udaf9\uddce\ud8e0\udff1\ud89f\ude22\ud923\udd6f\ud995\udd26\ud91e\uddfb\uda27\ude16\udb80\uddc9\udaba\udebf\uda44\udf04\uda96\udf9b\ud8cd\ude40\ud880\udfef\ud8ae\uddda\udaba\udfea",
        29, 80374, 2096700747, -3957060714369350892L, -25675L, false, false, (char) 57155, (char) 54597,
        Double.longBitsToDouble(0x3fecc4309f54c5acL), Double.longBitsToDouble(0x3fcf36d5a01353e8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=void |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 9, 1, 9, "\ud850\udd95", "\u72c0\uc10e\u2fbc\uce8e\u9794\u6849\u1c37\ua9af\u424e\ub62e\u244f\u34c0\ua226\u9aac\u37e3", "\ud8d4\uddaf\udaf9\uddce\ud8e0\udff1\ud877\udc54\ud935\udd53",
        17, 57381, -441442008, -191611951004340296L, 83144L, true, false, (char) 57866, (char) 57693,
        Double.longBitsToDouble(0x3fe1fbe7cb14c915L), Double.longBitsToDouble(0x3fd75fe5c27984f2L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 9, 8, 9, "\ud850\udd95", "\u72c0\uc10e\u2fbc\uce8e\u9794\u87dd\u614b\u485d\u424e\ub62e\u244f\u34c0\ua226\u1588\u95c3", "\udbec\udefb\udaf9\udd4a\ud8e0\udff1\ud884\udc54\udbce\uddc2\ud995\udd26\ud91e\uddfb\uda27\ude16\udb80\uddc9\udaba\udebf\uda44\udf04\uda96\udf9b\ud8cd\ude40\ud880\udfef\ud8c6\udcda\udaba\udfea",
        29, 80374, 2096700747, -3957060714369350892L, -25675L, false, false, (char) 57155, (char) 54597,
        Double.longBitsToDouble(0x3fecc4309f2ef140L), Double.longBitsToDouble(0x3fcf36d5a01353e8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 6, 8, 1, "\ud8e9\udfa2\uda9a\udc55", "\u07bb\u2fb1\u628e\u82c2\u2792\ua536\ucdbc\ucfd5\u3ad6\u95e6\u34c0\ubcd2\u81fa\u0344\u6458\u9620\ub9a1\u8fc6\ubc36\u0b81\u455f\ud3b3\u5e3d\ud4a9\u6969\u34bb\u1720\uba0b\ud0e5\u253d", "\ud9b9\udf0d\ud919\ude69\ud94f\udcaa\udafc\ude23\uda41\ude5d\ud9ce\udc9c\ud9e4\udcf0\udac8\udc59\ud80b\uddd0",
        48, 94883, 360961778, 2502258063819859483L, 15131L, false, false, (char) 54725, (char) 20288,
        Double.longBitsToDouble(0x3fe6f111f09c9bddL), Double.longBitsToDouble(0x3fec414be0bc51d8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 3, 6, 9, "\udb10\udc09", "\u2574\u142b\u2fbc\uce8e\u9794\u6665\uc7a0\u485d", "\udaee\ude44\uda6e\udd70\udb63\udfe3\uda28\udca8\uda86\ude41",
        33, 49837, 164423000, -5695915358263440713L, -9773L, true, true, (char) 53716, (char) 41823,
        Double.longBitsToDouble(0x3fdf253b0f71faaeL), Double.longBitsToDouble(0x3fdf06fb2e2bb7beL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=java.lang.Long:0 |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 3, 3, 2, "\ud850\udd95\u00f7\udac5\uddc2\u270e\000\000", "\u87dd", "\udbc2\udfbf\ud9b1\udeb6\udaee\ude44\ud815\udd03\ud985\uddc5\ud86a\udc1d\ud9dc\udf99\udb09\udd83\udb98\ude14\u8981\uda20\udd4b\ud9f9\udc1a\udb48\udcbe\ud89a\udcdf\ud927\ude21",
        13, 98480, 502057325, -6693331550577790328L, -1472L, true, false, (char) 56081, (char) 13746,
        Double.longBitsToDouble(0x3fcd416de4a493ecL), Double.longBitsToDouble(0x3fe5a7e80699536fL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 9, 0, 6, "\ud850\udd95", "\u7251\uc10e\u2fbc\uce8e\u9794\u87dd\u1a7a\ucdbc\u424e\ub62e\u244f\u34c0\ubcd2\u81fa\u26ad", "\ud80d\udea7\ud95d\udd61\udad6\udc8d\ud8ea\udf0e\ud874\udf80\ud995\udd7c\ud91e\uddfb\ueb61\uda83\udfa3\udaa3\udc6a\udba9\uddf6\udb9d\udc32\udbd3\udf7a\ud815\udeb2\ud8c6\udcda\udaba\udfea",
        29, 80374, 2096700747, -6118788535448523500L, 8576L, false, false, (char) 55299, (char) 54553,
        Double.longBitsToDouble(0x3fe313570abda342L), Double.longBitsToDouble(0x3fecc041f754c5acL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 6, 6, 6, "\ud850\udd95", "", "",
        -5, -1000, -1644167168, -1026500241760714613L, -74370L, false, false, (char) 54192, (char) 29227,
        Double.longBitsToDouble(0x3e0fc8f380000000L), Double.longBitsToDouble(0x3fe19104ffd6fb8dL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|createContextual|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|_acceptJsonFormatVisitor|com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper,com.fasterxml.jackson.databind.JavaType,boolean|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|_asTimestamp|com.fasterxml.jackson.databind.SerializerProvider|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|_timestamp|java.lang.Object|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|acceptJsonFormatVisitor|com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper,com.fasterxml.jackson.databind.JavaType|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|getSchema|com.fasterxml.jackson.databind.SerializerProvider,java.lang.reflect.Type|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|isEmpty|com.fasterxml.jackson.databind.SerializerProvider,java.lang.Object|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|isEmpty|java.lang.Object|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|serialize|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|withFormat|java.lang.Boolean,java.text.DateFormat|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|createContextual|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
