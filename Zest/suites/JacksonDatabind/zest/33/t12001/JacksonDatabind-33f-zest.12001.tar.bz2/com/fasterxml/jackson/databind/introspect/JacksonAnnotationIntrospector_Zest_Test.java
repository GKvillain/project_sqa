package com.fasterxml.jackson.databind.introspect;
import org.junit.Test;
import static org.junit.Assert.*;
public class JacksonAnnotationIntrospector_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 6, "\ud941\udca6\uda25\udcb2\udb05\udd96\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud8e2\udd4d", "\u4697\u139b\u2ffa\ubc65\u4601\ub698\u565a", "\ud960\udf2b\udbb1\udecf\ud885\ude81\udbe9\udca5\ud9eb\udc35\udb08\udeef\udb1c\uddb6\udbb9\udcaa\ud904\udc2c\udbbd\uddc0\udb83\udc17\ub8a1\ud86e\udfe4\ud863\udcfa\uda05\udf1a\udb7b\uddc0\uad3e\udaaa\udef4\udb57\udead",
        17, 55307, 378945262, -8548716883653555000L, -88806L, true, true, (char) 21817, (char) 3268,
        Double.longBitsToDouble(0x3fd16f8f7d02eae0L), Double.longBitsToDouble(0x3fecbc43d96548c5L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 15, "\ud9c3\ude6b\ud8fa\uddc2\udb1c\udd5b\ud98c\ude61\udae0\udc1d\ud8da\uddca\ud8e2\udd4d\udb9f\udcdb\udafb\udc15\udb0a\udeee\udb96\udcf9\ud8a2\udc10\ud9a6\udc4d\ud8b7\ude75\uda25\ude81\ud95f\uddc2\udac7\ude2c\ud92d\udce4\udac6\udcd4\ud822\ude9c\udaec\uded4\udaec\udc98\ud9da\ude13", "\u8d57\u0abe\u770d\u355b\uae18\u6ca6\ub5a6\u69d8\uaad0\u0887\u56b2\u184c\u84c2\u30e6\u21b3\uc6ad\uc890", "\ud87b\ude09\ud851\udc08\ud96f\udcdd\udbfd\udfea\ud86c\udefe\uda98\udcc8\udb71\udeb5",
        32, 61961, 1220926359, 3532310181610156472L, 76865L, false, true, (char) 47984, (char) 29112,
        Double.longBitsToDouble(0x3fe6581f37db8378L), Double.longBitsToDouble(0x3faad9b5f0718850L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 6, "\ud941\udca6\uda25\udcb2\udb05\udd96\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud9dd\udd8b", "\u4697\u139b\u2ffa\ubc65\u4601\ub698\u565a\u75b6\uabe2\uacf2\uad00\u32c4\ucd09\u0fbd\ucbc9\u22fd\u7bec\u06a5\u9bab\u355b\u6b40\u23bc\ub633\u69d8\uaad0\u0887\ubd08\u415d\uaf43\u6a51\uae98\uc70b\uc890", "\udbf3\udd25\udafd\udcc9\udbb8\udf0d\udbfd\udfea\ud86c\udefe\uda98\udcc8\udb71\udeb5\udb07\udc01\udb75\udf75\udb8b\udfe0\uda2f\udf53\ud89f\udd57\udb84\udcfa\udba7\udf04\udbbe\udf51\ud8b9\udca9\udbce\ude66\ud873\udfe4\ud884\udcb3\ud821\ude7b\uda2d\udc7d\ud8ac\ude8b\ud93c\udebf",
        15, 99056, -1292596158, 3454105046953901811L, -56922L, false, true, (char) 51804, (char) 5567,
        Double.longBitsToDouble(0x3f8d8138bd364c40L), Double.longBitsToDouble(0x3fd195f87193a992L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 5, 11, "\ud941\udca6\uda25\udcb2\udb05\udd96\uda29\udde2\ud8df\udf2e\udaf1\ude33\udadd\udd2c", "\u4697\u139b\u0f32\ud362\u63e4\u19d1\ubd18", "\ud960\udf2b\ud9ae\uddee\udad8\udd90\udbe9\udca5\ud83a\udf3c\udb13\udc36\udbbc\ude9c\udba5\udf44\ud997\udc3c\uda42\udc37\udbc1\ude18\ud9aa\udcaf\ud932\udd5c\ud863\udcfa\uda05\udf1a\udb7b\uddc0",
        -2, 41848, -1436687581, -576433542441328021L, 87210L, true, false, (char) 56052, (char) 35256,
        Double.longBitsToDouble(0x3fe12cc66218ab38L), Double.longBitsToDouble(0x3fb84b6e22374c30L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 6, "\ud941\udd2c\uda25\udcb2\udb05\udd96\udb74\udfcb\ud843\udebb\udaf1\ude35\ud8e2\udd4d", "\uc841\u139b\u2ffa\ubc65\u4601\ub698\uc78f", "\ud960\udf2b\udbc7\udccf\ud885\ude81\udbe9\udca5\ud9eb\udc35\udb08\udeef\udb1c\uddb6\udbb9\udcaa\ud904\udc2c\udbbd\uddc0\udb83\udc17\ud8a6\udc9c\ud86e\udfe4\ud863\udcfa\uda05\udf1a\udb7b\uddc0\uad3e\udaaa\udef4\udb57\udead",
        17, 55307, 378945262, -8548716883653555000L, -48263L, true, false, (char) 3409, (char) 43545,
        Double.longBitsToDouble(0x3fb1ba618e9db0b8L), Double.longBitsToDouble(0x3feb289ea3d8d4cdL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 6, "\ud922\udcef\udb0c\udfef\udb05\udd87\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud8e2\udd4d\ud9cd\udc61", "\u139b\u2ffa\ubc65\u4601\ub698\u565a\u3ebc\u5724\uad00\u3319\u32c4\ucd09\u0fbd\u5f0f\u51ac\u7bec\u06a5\u9bab\u355b\u6b40\u1293", "\udb7b\uddc0\uad3e\udaaa\udef4\udb57\udead\ud916\udc46\udb87\udec9",
        1, 74819, -1871573816, -4638765033045842151L, -88806L, true, true, (char) 21817, (char) 3268,
        Double.longBitsToDouble(0x3f96f8f777b2a160L), Double.longBitsToDouble(0x3fecd17861112fe4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 6, "\ud941\udca6\uda25\udcb2\u5d81\udb74\udfcb\ud847\udfbb\udb21\udf6e\udb13\udc34\uda1a\udffd\ud9ce\ude1e\udb0a\udf99\udb96\udcf9\udb65\udfb2\ud813\udcc5\ud8a9\udddc", "\u6ac0\u9677\u79d7\uac92\u32c4\u209f\uc453\u3331\u5410\u7c42\u98a7\u401f\u981b\u8f49", "\ud872\udc51\ud863\udd0b\ud86c\udff5\uda11\udd4f\udb0f\udd2b\udad9\udeae\udb90\uded9\udafa\udc42\udaf0\ude45\uda6d\ude0a\u21f2\udbc6\udddf\udb87\ude45\ud8e8\udf7b\ud8ca\udc55\uda1c\udffc\udae6\udf3c\u1aa9\udb71\udeb5\udb33\udf19\ud8a3\udff7\ua30e\udadc\udf8d\ud908\udc55\ud99c\udc79\uda9f\udc46\udb8e\ude71\uc003\ud88c\ude3a\udb48\udfa8\ud82d\ude15\ud85f\ude5b\uda1e\udf66\ud979\udeaa\u8d06\udbaf\udf22",
        12, 52799, 241414954, 2584987278092978052L, 99817L, true, false, (char) 53124, (char) 5104,
        Double.longBitsToDouble(0x3fda4f94454a75bcL), Double.longBitsToDouble(0x3fdf43a4e2684c64L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\u4697\u139b\u2ffa\ubc65\u4601\ub698\u565a}\ud941\udca6\uda25\udcb2\udb05\udd96\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud8e2\udd4d |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 8, "\ud941\udca6\uda25\udcb2\udb05\udd96\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud8e2\udd4d", "\u4697\u139b\u2ffa\ubc65\u4601\ub698\u565a", "\ud960\udf2b\udbb1\udecf\ud885\ude81\udbe9\udca5\ud9eb\udc35\udb08\udeef\udb1c\uddb6\udbb9\udcaa\ud904\udc2c\udbbd\uddc0\udb83\udc17\ub8a1\ud86e\udfe4\ud863\udcfa\uda05\udf1a\udb7b\uddc0\uad3e\udaaa\udef4\udb57\udead",
        -3, 55307, 378945262, -8548716883653555000L, -84990L, true, false, (char) 48588, (char) 13505,
        Double.longBitsToDouble(0x3fd6513d4e41eb46L), Double.longBitsToDouble(0x3fd16f8f7d02eae0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 5, 6, "\ud941\udca6\udabd\udc9f\ud807\udef9\uda92\udcf4\ud888\udc51\udaf1\ude4f\ud8e2\udd4d", "\u4697\u139b\u2ffa\ubc65\u4601\ub698\u565a", "\uda97\udffb\udb0f\udc13\ud885\ude81\udbe9\udca5\ud9eb\udc35",
        13, 84937, -952834772, 5532341369463123528L, -22705L, false, true, (char) 8104, (char) 2028,
        Double.longBitsToDouble(0x3fee78979e5bbe93L), Double.longBitsToDouble(0x3fdb1936425e458eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 6, "\ud941\udca6\uda25\udcb2\udb05\udd96\udb91\udecb\ud839\uddbb\udaf1\ude35\ud8e2\udd4d", "\u4697\u139b\u26f9\ubc65\u4601\ub698\u565a", "\ud960\udf2b",
        23, 23671, 1277256317, -4647110582721063045L, 37940L, false, true, (char) 31502, (char) 52905,
        Double.longBitsToDouble(0x3fdc4b579c154bfaL), Double.longBitsToDouble(0x3fdcc634d9bcf3aeL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 6, "\udb26\udc03\ub825\uda0c\uddb4\udb74\udfb5\ud839\uddbb\ud882\udfca\udb29\udef1", "\u4697\u139b\u2ffa\ubc65\u4601\ub698\u1e1f\u75b6\ua40c\u25e3", "\udbf5\udd7b\ud9eb\udc35\udb08\udeef\udb1c\uddb6\udbb9\udcaa",
        26, 90336, 733833604, -6485977382157165046L, -47543L, false, true, (char) 43967, (char) 28583,
        Double.longBitsToDouble(0x3fe35fc0fb64cf32L), Double.longBitsToDouble(0x3fdc8c89c99112b8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 1, 0, 5, "\ud941\udca6\uda25\udcb2\udb05\udd96\udaf1\uddea\ud839\uddbb\udaf1\ude35\ud8e2\udd4d", "\u4697\u139b\u2ffa\ubc65\u4601\ub698\u565a", "\ud960\udf2b\udbb1\udecf\ud885\ude81\udbe9\udca5\ud9eb\udc35\udb08\udeef\udb1c\uddb6\udbb9\udcaa\ud904\udc2c\udbbd\uddc0\udb83\udc17\ub8a1\ud86e\udfe4\ud863\udcfa\uda05\udf1a\udb7b\uddc0\uad3e\udaaa\udef4\udb57\udead",
        17, 55307, 378945262, -8548716883653555000L, -88806L, true, true, (char) 21817, (char) 3268,
        Double.longBitsToDouble(0x3fd16f8f7d02eae0L), Double.longBitsToDouble(0x3fecbc43d96548c5L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 6, "\ud8a4\udd15\uda25\udcb2\udb05\udd96\ud9c9\udc35\uda47\uddfc\udaff\ude4e\ud8e2\udd4d", "\u4697\u139b\u2ffa\ubc65\u4601\ub698\u565a", "\ud960\udf2b\udbb1\udecf\ud885\ude81\udbe9\udca5\ud9eb\udc35\udb08\udeef\udb1c\uddb6\udbb9\udcaa\ud904\udc2c\uda1d\udebf\udb8e\udd42\ub8a1\ud86e\udfe4\ud863\udcfa\uda05\udf1a\udb7b\uddc0\uad3e\udaaa\udef4\udb57\udead",
        17, 55307, 378945262, -8548716883653555000L, 11592L, false, false, (char) 58519, (char) 8174,
        Double.longBitsToDouble(0x3fd65138be41eb46L), Double.longBitsToDouble(0x3fd16f8f7d02eae0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 6, "\ud941\udca6\uda25\udcb2\udb05\udd96\udb74\udfcb\ud839\uddbb\ud9e8\udcf5\ud969\udf7c", "\u4697\u139b\u2ffa\ubc65\u4601\ub698\u565a", "\ud960\udf21\udbb1\udecf\ud885\ude81\udbe9\udca5\ud9eb\udc35\ud8ae\udc01\ud957\udf6e\udbb9\udcaa\ud904\udc2c\udbbd\uddc0\udb83\udc17\ub8a1\ud86e\udfe4\ud863\udcfa\uda05\udf1a\udb7b\ude1b\udbce\udd03\udaaa\udef4\udb57\udead",
        17, 55307, 378945262, -8548716883653555000L, -74860L, true, false, (char) 48588, (char) 2027,
        Double.longBitsToDouble(0x3fd6513d4e41eb46L), Double.longBitsToDouble(0x3fe8ad4f868175c3L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\u4697\u139b\u2ffa\ubc65\u12a3\ua6fb\uad33}\ud941\udca6\uda25\udcb2\udb05\udd96\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud8e2\udd4d |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 6, "\ud941\udca6\uda25\udcb2\udb05\udd96\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud8e2\udd4d", "\u4697\u139b\u2ffa\ubc65\u12a3\ua6fb\uad33", "\ud960\udf2b\udbb1\udecf\ud885\ude81\udbe9\udca5\udbed\udfbe\ud91a\uddc5\udb1c\uddb6\uda47\udd92\ud922\uddf8\udbcc\ude9a\udb83\udc17\ub8a1\ud86e\udfe4\ud863\udcfa\uda05\udf1a\udb7b\uddc0\uad3e\udaaa\udef4\udb57\udead",
        17, 55307, 378945262, -8548716883653555000L, 27350L, false, false, (char) 3597, (char) 43545,
        Double.longBitsToDouble(0x3fb1ba618e9db0b8L), Double.longBitsToDouble(0x3fd6513d4e41eb46L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 13, 6, "\ud86d\udc4f\u5efb\ud9de\udca3\u076a\ud839\uddc3\udaf1\ude35\udb74\uddb6\udb9f\udcdb\udafb\udc15\udb0a\udeee\udb96\udcf9\ud8a1\ude10\ud9a6\udc4d\uda16\ude75", "\u760b\uabe2\uacf2\u3126\uc05c\uccc0\u0fbd\ucbc9", "\udb7e\udd49\ud86d\ude77\udb83\udc46",
        46, 51498, 2044136908, 2734578729383756419L, 22044L, true, false, (char) 43941, (char) 26063,
        Double.longBitsToDouble(0x3fe77251534a1696L), Double.longBitsToDouble(0x3fc9112b8f2241c8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 7, 4, "\ud941\udea6\udb37\udc1b\udbd0\udee4\udb74\udfcb\ud839\uddbb", "\u3981\u17ea\u472b\u139b\u2ffa\ubc65\u4601", "\udac7\ude2c\ud9f3\udc75\ud960\udf2b\udbb1\udecf\ud885\ude81\udbe9\udca5\ud865\udf9b\ud9ba\ude6c",
        29, 47364, 1288098726, -645089759114486908L, -25770L, true, true, (char) 12515, (char) 19985,
        Double.longBitsToDouble(0x3fecad7a1344d84cL), Double.longBitsToDouble(0x3feb6b75f023721fL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 3, 3, 11, "\ud941\udca6\udb45\udd63\ud8be\uded2\udb74\udf46\ud839\uddbb\udaf1\ude35\ud8e2\udd4d", "\u9ab5\u4a39\u1629\u9ebc\u4518\u73ed\u5a16", "\ud960\udc98\udbb1\udecf",
        41, 94495, -768908183, -1984732529041689345L, 62666L, false, false, (char) 24721, (char) 22956,
        Double.longBitsToDouble(0x3fe0552fe9cc634dL), Double.longBitsToDouble(0x3fe699fa3a7fb388L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.List |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 2, 5, 6, "\ud941\udca6\uda25\udcb2\udb05\udd96\udb74\udfcb\ue085\uda2e\ude32\ud91e\udd3a", "\u2170\uade3\u2f62\ubc65\u4601\ub698\u565a\u75b6\u9776\u7a95\uad00\u32c4\ucd09\u0fbd", "\ud803\udcaf",
        4, 71127, -1286761852, -6485772696900739574L, -37400L, false, false, (char) 2509, (char) 22145,
        Double.longBitsToDouble(0x3fecd677ccc8891aL), Double.longBitsToDouble(0x3fee44839219bf9fL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 6, "\ud909\udca8\uda4c\udd86\udb05\udd96\ud9e6\udc24\udb50\udd4b\ud94b\udd9e\ud844\ude12", "\uc8f2\u8d93\u2ffa\ubc65\u4601\ub698\ud566\u75b6\uabe2\uacf2\uad00\u32c4\u8746\u0fbd\ucbc9\u22fd\u7bec\u06a5\u9bab\u355b\u237d\u4bcb\u48ff\u57ce\uaad0\u0887\u2986\u415d\u654c\uaa3a\u6437\u9e8a\u1f17", "\udbf3\udd25\udafd\udcc9\udbb8\udf0d\udbfd\udfea\udbd3\ude30\u40c5\uda06\udf70\udbba\udd4e\ue71c\udb8b\udfe0\uda2f\udf53\ud89f\udd57\ud83b\udc8b\ud9e6\udc84\udb16\udc4e\ud8b4\uddf0\udba3\udc1c\uda46\udd0d\ud91b\udf5f\ud821\ude3f\uda2d\udc7d\ud8ac\ude8b\ud93c\udebf",
        15, 99056, -1292596158, 3454105046953901811L, -56971L, false, true, (char) 51804, (char) 47623,
        Double.longBitsToDouble(0x3f8df150bd364c40L), Double.longBitsToDouble(0x3fd3ed687c9a8c56L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Class:char |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:{\u7962\u139b\u2ffa}\ud941\udca6\ud916\udc8a\ud9f5\uddea\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud9dd\udd8b |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 2, 11, 6, "\ud941\udca6\ud916\udc8a\ud9f5\uddea\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud9dd\udd8b", "\u7962\u139b\u2ffa", "\uda25\ude30\ud95f\uddc2\udac7\ude2c\ud9e3\udcc9",
        -1, 7053, 1612691671, -7140621600327464799L, -15178L, false, true, (char) 21207, (char) 31502,
        Double.longBitsToDouble(0x3fd84f70cbde577aL), Double.longBitsToDouble(0x3fe0552fedcc634dL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 6, "\ud941\udca6\uda25\udcb2\uda08\udd58\udb74\udfe6\ud839\uddbb\udaf1\ude35\ud9dd\udd8b", "\u4697\u139b\u1442\u1b7d\u4601\ub698\u565a\u75b6\uabe2\uacf2\uad00\u32c4\ucd09\u0fbd\ucbc9\u22fd\u7bec\u06a5\u9bab\u355b\u6b40\u23bc\ub633\u9ee1\uaad0\u0887\u1bbe\u415d\uaf43\u6a51\ua82e\uc6b8\uc890", "\udbf3\udd25\udafd\udcc9\udbb8\udf0d\udbfd\udfea\ud8a0\ude58\uda32\uddec\uda73\udc96\udb07\udc00\udb75\udf75\udb8b\udfe0\uda2f\udf53\ud89f\udd57\udb84\udcfa\udba7\udf04\ud912\udd5c\ud8b9\udca9\udbce\ude66\ud873\udfe4\ud884\udcb3\ud8e7\udd3e\uda27\udda4\ud8ac\ude8b\ud93c\udebf",
        15, 99056, -1292596158, 3454105046953901811L, -56922L, false, true, (char) 51804, (char) 5567,
        Double.longBitsToDouble(0x3f8d8138bd364c40L), Double.longBitsToDouble(0x3fd195f87193a992L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Integer |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 15, 6, "\ud941\udca6\uda25\udcb2\udb05\udd96\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud9dd\udd8b", "\u4697\u139b\u54a9\ubc65\u4601\ub698\u565a\u75b6\u3038\u273b\u25f8\uae81\u6e44\u0fbd\ucbc9\u22fd\u7bec\u06a5\u9bab\u355b\u6b40\u23bc\ub633\u69d8\uaad0\u0887\ubd08\u415d\uaf43\u6a51\uae98\uc70b\uc890", "\udbf3\udd25\udafd\udcc9\udbb8\udf0d\udbfd\udfea\ud86c\udefe\uda98\udcc8\udb71\udeb5\udb07\udc01\udb75\udf75\udb8b\udfe0\uda2f\udf53\ud89f\udd57\udb84\udcfa\udba7\udf04\udbbe\udf51\ud8b9\udca9\udbce\ude66\ud873\udfe4\ud884\udcb3\ud821\ude7b\uda2d\udc7d\ud8ac\ude8b\ud93c\udebf",
        15, 99056, -1292596158, 3454105046953901811L, -56922L, false, true, (char) 51804, (char) 5567,
        Double.longBitsToDouble(0x3f8d8138bd364c40L), Double.longBitsToDouble(0x3fd195f87193a992L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 4, 4, 6, "\ud941\udca6\uda25\udcb2\udb37\udd96\udb74\udfcb\ud839\uddbb\ud9c7\udc4f\ud9dd\udd8b", "\u7beb\u9663\u0d0b\ubc65\u4601\ub698\u565a\u75b6\uabe2\uacf2\uad00\u32c4\ucd09\u214d\uaf24\u22fd\u7bec\ubac9\u45a4\uc0f4\u6b40\u23bc\ub633\u69d8\uaad0\u0887\ubd08\u415d\u39a8\u053b\uae98\uc70b\ucc5a", "\udbf3\udd25\udafd\udcc9\ud81f\udfc1\udbc1\udd1f\ud8d3\udff7\udb2a\udc33\udba7\udc21\udb07\udc01\udb75\udf75\udb8b\udfe0\uda2f\udf53\ud89f\udd57\uda9d\ude06\udac7\udf31\ud8e5\udc46\ud9c2\uddef\udbce\uddda",
        30, 68957, -970733084, -5642833197671285962L, 47187L, true, false, (char) 41344, (char) 31249,
        Double.longBitsToDouble(0x3fe19d014da5c819L), Double.longBitsToDouble(0x3f8d8138bd364c40L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\ud941\udca6\uda25\udcb2\udb05\udd96\uda29\udde2\ud8df\udf2e\udaf1\ude33\udadd\udd2c |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 11, "\ud941\udca6\uda25\udcb2\udb05\udd96\uda29\udde2\ud8df\udf2e\udaf1\ude33\udadd\udd2c", "\u4cdb\u139b\u0f32\ud362\u63e4\u19d1\u9c26", "\ud960\udf2b\ud9ae\uddee\udad8\udd90\udbe9\udca5\ud83a\udf3c\udb13\udc36\udbbc\ude9c\udba5\udf44\ud997\udc3c\uda42\udc37\udbc1\ude18\udb90\udfe1\ud932\udce7\ud863\udcfa\uda05\udf1a\udb7b\uddc0",
        -2, 41848, -1436687581, -576433542441328021L, 87210L, true, false, (char) 56052, (char) 35256,
        Double.longBitsToDouble(0x3fe12cc66218ab38L), Double.longBitsToDouble(0x3fb84b6e044873a0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 11, "\ud941\udca6\uda25\udcb2\udb05\udd96\uda29\udde2\ud8df\udf2e\udaf1\ude33\udadd\udd2c", "\u4697\u139b\u0633\ud362\u63e4\u19d1\ubd18", "\ud960\udf2b\ud9ae\uddee\udad8\udd90\ud98a\udf96\ud9c6\udf9b\udaf7\udc80\udbbc\ude9c\udba5\udf44\ud997\udc3c\uda42\udc37\udbc1\ude18\ud9aa\udcaf\ud8b3\udf3d\uda0b\ude6f\ud86d\udc2d\udb7b\ude02",
        -2, 41848, -1436687581, -576433542441328021L, 87210L, true, false, (char) 56052, (char) 35256,
        Double.longBitsToDouble(0x3fe12cc66218ab38L), Double.longBitsToDouble(0x3fb84b6e22374c30L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Comparable |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 11, "\ud941\udca6\uda25\udcb2\udb05\udd96\uda29\udde2\ud8df\udf2e\udaf1\ude33\udadd\udd2c", "\u4697\u139b\uab7a\ud39e\u63e4\u19d1\ubd18", "\ud960\udf2b\ud9ae\uddee\udad8\udd90\udbc2\ude11\udac3\udea8\udb13\udc36\udbbc\ude9c\udba5\udf44\ud997\udc3c\uda42\udc37\udbc1\ude18\ud9aa\udcaf\ud932\udd5c\ud863\udcfa\ucf12\ud917\udc2d",
        22, 42005, -1436687581, -6572027264959367752L, 87210L, true, false, (char) 56052, (char) 35256,
        Double.longBitsToDouble(0x3fe12cc66218ab38L), Double.longBitsToDouble(0x3fb84b6e1129f9f0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 9, 6, "\ud941\udd2c\uda25\udc98\udb05\udd96\udb74\udfcb\ud843\udebb\udaf1\ude35\uda62\udcad", "\uaa82\u1ab7\u2ffa\ubc65\u4601\ub698\u821b", "\ud84a\udf40\udaae\udf78\ud885\ude81\udb63\udca2\ud9eb\udc35\udb08\udeef\udb1c\uddb6\udbb9\udcaa\ud904\udc2c\udbdc\udfc0\udb83\udc17\ud8a6\udc9c\ud86e\udfe4\ud863\udcfa\uda05\udf1a\udb7b\uddc0\ud9e3\udf73\ud893\uddd9\ud841\udf03",
        38, 55325, 378945262, -8548716883653555000L, -48263L, true, false, (char) 3409, (char) 59416,
        Double.longBitsToDouble(0x3fb1ba618e9db0b8L), Double.longBitsToDouble(0x3fe3a1bcab3f16c9L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.List |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 6, "\ud941\udd2c\uda25\udcb2\udb05\udd96\udb74\udfcb\ud843\udebb\udaf1\ude35\ud8e2\udd4d", "\uc841\u139b\u4b68\ud389\u3c2c\ub698\uc78f", "\ud867\ude23",
        4, 59359, 894453578, -6075608888410340408L, 37940L, false, true, (char) 14606, (char) 24825,
        Double.longBitsToDouble(0x3fee995dee57d352L), Double.longBitsToDouble(0x3fed12c5dcde2deaL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:\ud922\udcef\udb0c\udfef\udb05\udd87\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud8e2\udd4d\ud9cd\udc61 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 1, 11, 6, "\ud922\udcef\udb0c\udfef\udb05\udd87\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud8e2\udd4d\ud9cd\udc61", "\u869a\u2ffa\ubc65\u4601\ub698\u565a\u3ebc\u5724\uad00\u3319\u32c4\ucd09\u0fbd\u5f0f\u51ac\u7bec\u06a5\u9bab\u350c\u6b40\u1293", "\uda87\udccb\uad3e\udaaa\udef4\udb57\udead\ud916\udc46\udb55\udc7f",
        17, 74819, -1871573816, -4638765029422553319L, -53896L, true, false, (char) 48588, (char) 2027,
        Double.longBitsToDouble(0x3fd6513d4e41eb46L), Double.longBitsToDouble(0x3f96f8f777b2a160L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 13, 6, "\ud922\udcef\udb0c\udfef\udb05\udd87\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud8e2\udd4d\ud9cd\udc61", "\u139b\u2ffa\ubc65\u4601\ub698\u565a\u3ebc\u5724\uad00\u3319\u32c4\ucd09\u0fbd\u5f0f\u51ac\u7bec\u06a5\u9bab\u355b\u6b40\u1293", "\udb7b\uddc0\uad3e\udaaa\udef4\udb57\udead\ud916\udc46\udb87\udec9",
        1, 74819, -1871573816, -4638765033045842151L, -88806L, true, true, (char) 21817, (char) 3268,
        Double.longBitsToDouble(0x3f96f8f777b2a160L), Double.longBitsToDouble(0x3fecd17861112fe4L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 12, 6, "\ud801\udf58\ud82d\udfee\udb33\udef0\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud8e2\udd4d\ud9cd\udc61", "\u139b\u2ffa\ubc65\u4601\ub698\u565a\u3ebc\u40ae\u09db\u2c05\ucf30\u585b\u0fbd\u5f0f\u51ac\u7bec\u06a5\u4bac\u355b\ud01b\u7a94", "\udb7b\uddc0\uad3e\udaaa\udef4\udb57\udead\ud916\udc46\udb87\udec9",
        1, 74819, -1871573816, -4638765033045842151L, -63462L, true, true, (char) 624, (char) 15479,
        Double.longBitsToDouble(0x3fd2ad1ef7672aaaL), Double.longBitsToDouble(0x3fecd17861112fe4L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 1, 1, 14, "\ud922\udcef\udb0c\udfef\udb05\udd87\udabb\ude10\ud839\uddbb\udaf1\ude35\ud8e2\udd4d\ud9cd\udc61", "\u139b\u2ffa\ubc65\u2ec9\u2094\u8f75\u3ebc\u5724\uad00\u3319\u32c4\ucd09\u0fbd\u5f0f\u51ac\uc5ab\u962a\u9bab\u355b\u6b40\u1293", "\ud82e\udd8b\udbaa\udc27\ud86a\udcd7\uda3d\udc44\ud9b6\udcb5\ud91f\udf7d",
        31, 74819, -1871573816, -4638765033045842151L, -88806L, true, true, (char) 21817, (char) 3268,
        Double.longBitsToDouble(0x3f96f8f777b2a160L), Double.longBitsToDouble(0x3fecd17861112fe4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=java.lang.Class:java.lang.Object |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 1, 2, 6, "\ud933\uded4\ud84d\udcf8\udbc4\udfe3\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud8e2\udd4d\u8957\udaab\uddad\ud94b\ude80\udb96\udcf9\ud8a2\udc10\ud9a6\udc4d\uda23\udecc\uda25\ude76\ud95f\uddc2\uda17\udd35\ud9bf\udc98\ud960\udf39\ud84d\udce2\ud885\ude81\udbe9\udca5\ud9eb\udc35\u275f\udae2\udc3b\udbb9\udcaa\ud904\udc2c\uda94\ude4c\udb83\udc17\ub8a1", "\u69d8\uaad0", "\udb57\udead",
        17, 55307, 362168046, -8569229333926638392L, -88806L, true, true, (char) 21817, (char) 3268,
        Double.longBitsToDouble(0x3f96f8f777b2a160L), Double.longBitsToDouble(0x3fecd17861112fe4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 5, 6, "\ud941\udca6\uda25\udcb2\u5d81\udb74\udfcb\ud847\udfbb\udb21\udf6e\udb13\udc34", "\u4742\u139b\ub8a4", "\udb3d\udf14\ud8cf\uddec\ud9a4\uddc9\ud9d7\udc48\udbcd\ude02\udbb1\ude61\ud885\ude81\uda5b\udc69\udab4\udc09\uda6f\udc02\ud841\udf22\udbb9\udd00\udb9b\udeb9\uda36\udefb\ud92e\udc08\udae5\udf7e\ud86f\udf59\ud863\udcfa\ud872\udc51\ud863\udd0b\uda02\ude18\ud8e7\uddcd\udb0f\udd2b\ud8c7\uddb5\udb90\uded9\udafa\udc42\udaf0\ude45\uda6d\ude0a\u21f2\udbc6\udddf\udb87\ude45",
        5, 32177, -1231548336, -8054035017101132979L, -74138L, false, false, (char) 51780, (char) 12966,
        Double.longBitsToDouble(0x3fe583ddbe3e1af4L), Double.longBitsToDouble(0x3fecd5fc8092c316L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName: |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 0, "", "", "",
        48, 67612, 1671725934, -726419346464702211L, -38131L, false, true, (char) 481, (char) 14854,
        Double.longBitsToDouble(0x3fddadb008da9c80L), Double.longBitsToDouble(0x3fe5547700000071L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\ud941\udca6\uda25\udcb2X\udb74\udfcb\u3f07\000\000 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 8, "\ud941\udca6\uda25\udcb2X\udb74\udfcb\u3f07\000\000", "", "\ud8a2\udc10",
        39, 41871, 1312860634, -8151281760916603222L, 90168L, true, false, (char) 47445, (char) 49820,
        Double.longBitsToDouble(0x3fc4200000000000L), Double.longBitsToDouble(0x3e44b32138000000L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\u4697\u139b\u2ffa\ubc65\u4601\ub698\u565a}\ud941\udd49\uda25\udcb2\udb05\udd96\udb74\udfcb\ud839\uddbb\udbb5\ude37\ud8e2\udd4d |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 8, "\ud941\udd49\uda25\udcb2\udb05\udd96\udb74\udfcb\ud839\uddbb\udbb5\ude37\ud8e2\udd4d", "\u4697\u139b\u2ffa\ubc65\u4601\ub698\u565a", "\ud960\udf2b\udbb1\udecf\ud885\ude81\udbe9\udca5\ud9eb\udc35\udb08\udeef\udb1c\uddb6\udbb9\udcaa\ud904\udc2c\udbbd\uddc0\udb83\udc17\ub8a1\ud86e\udfe4\ud863\udcfa\uda05\ude56\udb7b\uddc0\uad3e\udaaa\udef4\udb57\udead",
        -3, 55307, 378945262, -8548716883653555000L, -84990L, true, false, (char) 48588, (char) 13505,
        Double.longBitsToDouble(0x3fd6513d4e41eb46L), Double.longBitsToDouble(0x3fd16f8f7d02eae0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\u4697\u139b\u71e6\ubc65\u4601\ub698\u565a}\ud941\udca6\uda25\udcb2\udb05\udd96\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud8e2\udd4d |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:{\u4697\u139b\u71e6\ubc65\u4601\ub698\u565a}\ud941\udca6\uda25\udcb2\udb05\udd96\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud8e2\udd4d |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 11, 11, 8, "\ud941\udca6\uda25\udcb2\udb05\udd96\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud8e2\udd4d", "\u4697\u139b\u71e6\ubc65\u4601\ub698\u565a", "\ud960\udf2b\udbb1\udecf\ud885\ude81\udbe9\udca5\ud9eb\udc35\udb08\udeef\udb1c\uddb6\udbb9\udcaa\ud904\udc2c\udbbd\uddc0\udb83\udc17\ub8a1\ud86e\udfe4\ud863\udcfa\uda05\udf1a\udb7b\uddc0\uad3e\udaaa\udef4\udb57\udead",
        -3, 55307, 378945262, -8548716883653555000L, -84990L, true, false, (char) 48588, (char) 13505,
        Double.longBitsToDouble(0x3fd6513d4e41eb46L), Double.longBitsToDouble(0x3fd16f8f7d02eae0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Class:[I |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=java.lang.Class:[I |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 2, 2, 6, "\ud941\udca6\uda25\udcb2\udb05\udd96\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud9dd\udd8b", "\u4697\u139b\u54a9\ubc65\u4601\ub698\u565a\u75b6\u3038\u4b2a\u19b8\uae81\u5ce5\u9d42\ucbc9\u04ed\u7c15\u06a5\u9bab\u355b\u1fb3\u3d56\ub633\u69d8\uaad0\u0887\ubd08\u415d\uaf43\u3db7\u7410\uc70b\uc890", "\udbf3\uddd4\udafd\udcc9\udbb8\udf0d\udbef\udc15\ud86c\udefe\uda98\udcc8\udb71\udeb5\udb07\udc01\udb75\udf75\udb8b\udfe0\uda2f\udf53\ud927\ude67\udbf5\udc76\udba7\udf04\udbbe\udf51\ud8b9\udd6e\udbce\ude66\ud873\udfe4\ud884\udcb3\ud821\ude7b\uda0b\ude25\ud8f1\udcb1\ud828\udcc9",
        19, 98924, -1292596158, 3454105046953901811L, -56922L, false, true, (char) 51804, (char) 5567,
        Double.longBitsToDouble(0x3f8d8138bd364c40L), Double.longBitsToDouble(0x3fd195f87193a992L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 2, 2, 6, "\ud941\udca6\uda25\udcb2\u5d81\udb74\udfcb\ud847\udfbb\udb21\udf6e\udb13\udc34", "\u4742\u139b\ub8a4", "\udb3d\udf14\ud8cf\uddec\ud9a4\uddc9\ud9d7\udc48\udbcd\ude02\udbb1\ude61\ud885\ude81\uda5b\udc69\udab4\udc09\uda6f\udc02\ud841\udf22\udbb9\udd00\udb9b\udeb9\uda36\udefb\ud92e\udc08\udae5\udf7e\ud86f\udf59\ud863\udcfa\ud872\udc51\ud863\udd0b\uda02\ude18\ud8e7\uddcd\udb0f\udd2b\ud8c7\uddb5\udb90\uded9\udafa\udc42\udaf0\ude45\uda6d\ude0a\u21f2\udbc6\udddf\udb87\ude45",
        5, 32177, -1231548336, -8054035017101132979L, -74138L, false, false, (char) 51780, (char) 12966,
        Double.longBitsToDouble(0x3fe583ddbe3e1af4L), Double.longBitsToDouble(0x3fecd5fc8092c316L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\udb16\udc0a |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:\udb16\udc0a |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 11, 11, 0, "\udb16\udc0a", "\000\u30b8\u3137\ub995", "\udb0a\udeee\udb96\udcf9\ud8a2\udc10\ud9a6\udc4d\udb4b\udec0\ud9d1\udcfe\udb2e\udf5f",
        47, 28912, 1567753572, -5323262633467923773L, 18156L, false, false, (char) 60302, (char) 52382,
        Double.longBitsToDouble(0x3fdf508c78b30db0L), Double.longBitsToDouble(0x3fd5e33ab13bfc5cL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\ud941\udca6\ud936\udd5b\uaf0c\udb74\udfcb\u3f07\000\000 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:\ud941\udca6\ud936\udd5b\uaf0c\udb74\udfcb\u3f07\000\000 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 11, 11, 8, "\ud941\udca6\ud936\udd5b\uaf0c\udb74\udfcb\u3f07\000\000", "", "\ud8a2\udc10",
        -3, 23869, -1403824083, 185034206149288632L, 90168L, true, false, (char) 47445, (char) 7515,
        Double.longBitsToDouble(0x3fea918f33a1bfd3L), Double.longBitsToDouble(0x3fec9a0e658915daL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName: |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName: |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 11, 11, 0, "", "", "",
        -5, -1000, 0, 0L, -100000L, false, true, (char) 481, (char) 39430,
        Double.longBitsToDouble(0x3e4a5cd400000000L), Double.longBitsToDouble(0x3fe5564b78000071L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 6, "\ud941\udca6\uda25\udcb2\udb05\udd96\udb74\udfcb\ud839\uddbb\udaf1\ude35\ud8e2\udd4d", "\u4697\u139b\u2ffa\ubc65\u4601\ub698\u565a", "\ud960\udf2b\udbb1\udecf\ud885\ude81\udbe9\udca5\ud9eb\udc35\udb08\udeef\udb1c\uddb6\udbb9\udcaa\ud904\udc2c\udbbd\uddc0\udb83\udc17\ub8a1\ud86e\udfe4\ud863\udcfa\uda05\udf1a\udb7b\uddc0\uad3e\udaaa\udef4\udb57\udead",
        17, 55307, 378945262, -8548716883653555000L, -88806L, true, true, (char) 21817, (char) 3268,
        Double.longBitsToDouble(0x3fd16f8f7fa0fcd0L), Double.longBitsToDouble(0x3fea25e2296548c5L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|findNameForSerialization|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_classIfExplicit|java.lang.Class|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_classIfExplicit|java.lang.Class,java.lang.Class|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_constructNoTypeResolverBuilder||new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_constructStdTypeResolverBuilder||new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_constructVirtualProperty|com.fasterxml.jackson.databind.annotation.JsonAppend$Attr,com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedClass,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_constructVirtualProperty|com.fasterxml.jackson.databind.annotation.JsonAppend$Prop,com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedClass|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_findFilterId|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_findSortAlpha|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_findTypeResolver|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_isIgnorable|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_propertyName|java.lang.String,java.lang.String|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|findAndAddVirtualProperties|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.util.List|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|findAutoDetectVisibility|com.fasterxml.jackson.databind.introspect.AnnotatedClass,com.fasterxml.jackson.databind.introspect.VisibilityChecker|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|findContentDeserializer|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|findContentSerializer|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|findNameForSerialization|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
