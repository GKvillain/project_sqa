package com.fasterxml.jackson.databind.deser;
import org.junit.Test;
import static org.junit.Assert.*;
public class BasicDeserializerFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 6, "\ud926\udcd9\udb1a\udc7e\ud9e2\udcc3\udb57\udd85\udbc7\udcce\ud90a\udfd9\ud941\udd06\ud90c\ude40", "\u3b96\u1ccc\uafe9\ubb2b\uaed1\u24be", "\udb47\ude59",
        0, 94878, -452276174, -4567721450625517608L, 60496L, false, false, (char) 35918, (char) 23768,
        Double.longBitsToDouble(0x3fe1f887969545a9L), Double.longBitsToDouble(0x3fca3b95d28e8f68L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 6, "\ud926\udcd9\udb1a\udc7e\ud9e2\udcc3\udb57\udd85\udbc7\udcce\ud90a\udfd9\ud941\udd06\ud90c\ude40", "\u3b96\u1ccc\uafe9\ubb2b\uaed1\u24be", "\udb47\ude59",
        0, 94878, -452276174, -4567721450625517608L, 1648L, false, false, (char) 35918, (char) 23768,
        Double.longBitsToDouble(0x3fe1f887969545a9L), Double.longBitsToDouble(0x3fca3b95d28e8f68L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 7, 6, "\ud926\udcd9\ud9ca\uddd5\u8ee9\uda80\udc9c\udbc7\udcce\ud90a\udfe5\ud941\udd06\ud806\udc7d", "\u267d\ud464\uafe9\ubb2b\uaed1\u24be", "\udb3a\udf59",
        0, 55109, -452276070, 1413058856383052487L, -13382L, true, true, (char) 31314, (char) 26234,
        Double.longBitsToDouble(0x3fd376e27cf2b21cL), Double.longBitsToDouble(0x3fea9721fbde94fcL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 1, 9, 11, 6, "\ud926\udcd9\udb1a\udc7e\ud9e2\udcc3\udb57\udd85\udbc7\udcce\ud90a\udfd9\ud941\udd06\ud90c\ude40", "\u3b96\u1ccc\uafe9\ubb2b\uaed1\u24be", "\udb47\ude59",
        0, 94878, 2098941234, -4553378102397847592L, 61335L, false, false, (char) 9545, (char) 8498,
        Double.longBitsToDouble(0x3fdf033d4c710f9aL), Double.longBitsToDouble(0x3fe13b7139b13b27L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 12, 6, "\udaf6\udca0\udb2c\ude49\ud9e2\udcc3\udb57\udd2c\udbc7\udcce\ud84c\uddd4\udbf0\udf91\ud8fa\uddb3", "\u3aff\u75b0\uad90", "\ud908\udfc1\ud809\uddbb\ud92a\udd9c\udb3d\udfb4\udaa5\udde0\uc059\ud907\ude9b\uda20\udfb5\udb10\ude68\udaa4\udedc\ud821\udc27",
        28, 8111, 869538730, 4630389743856068152L, 39697L, true, false, (char) 10888, (char) 13696,
        Double.longBitsToDouble(0x3fc471bb488d57dcL), Double.longBitsToDouble(0x3feb8b07b5b37af1L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 7, 6, "\ud926\udcd9\udb1a\udc7e\ud9e2\udcc3\udb57\udd85\udbc7\udcce\ud90a\udfd9\ud941\udd06\ud90c\ude40", "\u3b96\u1ccc\uafe9\ubb2b\uaed1\u24be", "\udb47\ude59\uda17\udc98",
        4, 826, -1063505525, -7023161481528567308L, -77978L, false, false, (char) 8498, (char) 42692,
        Double.longBitsToDouble(0x3fe1c20216276e27L), Double.longBitsToDouble(0x3fbdcec9c3343ca8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 7, 6, "\ud926\udcd9\udb1a\udc7e\ud9e2\udcc3\udb57\udd85\uda15\udcb4\ud899\udd47\ud934\uddbd\ud90c\ude40", "\u3b96\u1ccc\uafe9\ubb2b\uaed1\u24be", "\ud9a6\udf32",
        14, 94878, -452591085, -4567721450625517608L, 60496L, false, false, (char) 35918, (char) 23768,
        Double.longBitsToDouble(0x3fe1f887969545a9L), Double.longBitsToDouble(0x3fee8ee574a7a3b3L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 1, 11, 7, 6, "\ud926\udcd9\udb1a\udc7e\ud8f5\udf6c\udb48\udc7d\udbc7\udcce\ud90a\udfd9\ud941\udd06\ud90c\ude40", "\u3b96\u1ccc\uafe9\ubb2b\uaed1\u24be", "\udb47\ude59",
        0, 94878, -452276174, -4567721450625517608L, 60496L, false, false, (char) 35918, (char) 23768,
        Double.longBitsToDouble(0x3fe1f887969545a9L), Double.longBitsToDouble(0x3fca3b95d28e8f68L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 7, 0, "\udbf8\uddb2\uda88\udcae\ud843\udc78\udb57\udd85\udbc7\udcce\ud90a\udfd9\ud941\udc34\ud90c\ude40", "\u3b96\u1ccc\uc47f\u65e9", "\ud809\uddbb\ud92a\udd9c\udb71\udf0e",
        49, 94878, -284504014, 5539355788298279284L, 60496L, false, true, (char) 36105, (char) 23768,
        Double.longBitsToDouble(0x3fe64887963b5f07L), Double.longBitsToDouble(0x3f9eaba5d4a4fb40L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 3, 3, "\ud926\udcd9\udb1a\udc7e\ud9e2\udcc3\udb57\udd85\udbc7\udcce\ud90a\udfd9\ud941\udd06\ud90c\ude40", "\u3b96\u1ccc\uafe9\ubb2b\uaed1\u24be", "\udb47\ude59",
        0, 33486, -450955958, -7031471920070245751L, 60496L, false, false, (char) 35918, (char) 23768,
        Double.longBitsToDouble(0x3fe1f8cf969545a9L), Double.longBitsToDouble(0x3fca3b95d28f5228L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 7, 6, "\ud926\udcd9\ud819\udc3d\uda74\udc53\ud920\ude53\udabb\udd50\ud90a\udfd9\ud941\udd06\ud90c\ude40", "\u3b96\u1ccc\uafe9\ubb2b\uaed1\u24be", "\ud935\udf50",
        40, 94878, -452276174, -4567721448870004580L, -73446L, true, false, (char) 3765, (char) 37817,
        Double.longBitsToDouble(0x3fe7819ea6384042L), Double.longBitsToDouble(0x3fe13b7139b13b27L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 8, 10, 6, "\udbb8\udd42\ud9cd\udc1d\ud9f6\uddfe\udb57\udd85\udbc7\udcce\ud90a\udfd9\udb9f\ude15\ud90c\udde2\udad6\ude1c\ud9a4\udc95\uda36\udf7f\udbe3\uded1\ud89e\udc81\ud979\udf47\udbed\ude8a\ud908\udfc1\ud809\uddbb\uc580\udb47\ude59\uda79\udde0\u64ee\ud907\udea2\uda02\udfe6\ud94f\udd45\ud87b\ude7e\ud821\udc27", "\u6117\u2719\ub0c5\u9c42\u7dc6\u8acf\u9825\u539a\u2a2c", "\udb83\uddbb\ud982\udeba\ud95a\udd9f\ud901\ude70\ud81a\ude45\uda7a\ude03\uda7b\udeaf\uda50\ude18\ud915\udf1c\udb1b\udf86\udbcb\udc83\udac3\udcfe\udbed\ude2d\udb83\udd6e\udb11\udfac",
        22, 47596, -951483058, 2531820970576357102L, 95270L, false, true, (char) 4656, (char) 61071,
        Double.longBitsToDouble(0x3fe004906461db81L), Double.longBitsToDouble(0x3fcb9f6b042f1ad4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 13, 11, 6, "\ud926\udcd9\udb1a\udc7e\ud9e2\udcc3\udb57\udd85\udbc7\udcce\ud90a\udfd9\ud941\udd06\ud90c\ude40", "\u3b96\u7435\u4fb5\ub4ab\uaf8a\uc0e3", "\udb47\ude59",
        0, 94878, 2098941234, -4553378102397847592L, 61335L, false, false, (char) 9545, (char) 8529,
        Double.longBitsToDouble(0x3fdf033d4c710f9aL), Double.longBitsToDouble(0x3fe93b7139b1d1afL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 1, 15, 10, 6, "\ud926\udcd9\udb1a\udc7e\ud9e2\udcc3\udb57\udd85\udbc7\udcce\ud90a\udfd9\ud9ef\udd26\ud905\udff9", "\u3b96\u1ccc\uafe9\ubb2b\uaed1\uab8f", "\udb47\ude59\udaa5\udde0\uc059\ud995\udc91\uda96\udf04\uda30\ude19\ud87b\ude7e\udb1f\ude66\uc3de\ud9c5\ude64\udba3\udeb7\uda69\udeda\udbcd\uded3",
        12, 49913, 1220082831, -9197675533240620704L, 42034L, false, false, (char) 22036, (char) 4582,
        Double.longBitsToDouble(0x3fd5f69de924e792L), Double.longBitsToDouble(0x3facf08f4b89b5f0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 11, 11, 6, "\ud887\udc8a\ud884\udf34\uda6f\udf2b\u6d81", "\ub90c\uab9e\u3d85", "\udbe3\uded1\udbff\ude52\udbbf\udec6\uda96\udee1\uda3b\udf1b\uda94\udea2\ud92a\udd9c",
        40, 31325, -452855003, -258371938575291200L, 16401L, true, false, (char) 26618, (char) 17126,
        Double.longBitsToDouble(0x3fd87c94e45cc404L), Double.longBitsToDouble(0x3fe091f98eecddc8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 12, 12, 6, "\udaf6\udca0\udb2c\ude49\ud9e2\udcc3\ud8a7\udd34\udbc7\udcce\ud84c\uddd4\udbf0\udf91\ud8fa\uddb3", "\u3aff\u75b0\uad90", "\ud908\udfc1\ud809\uddbb\ud92a\udd9c\udb3d\udfb4\udaa5\udde0\uc059\ud907\ude9b\uda20\udfb5\udb10\ude68\udaa4\udedc\ud821\udc27",
        28, 84057, 414348465, 4630388846219011720L, 39697L, true, false, (char) 60987, (char) 35455,
        Double.longBitsToDouble(0x3fe7e8d814f77e02L), Double.longBitsToDouble(0x3fee156b2db37af1L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 8, 12, 6, "\ud9b4\udd9f\udbcd\udeff\udaa6\udf90\ud919\udfbb\ud891\udc63\ud9b8\udc0c\udbf0\udf91\udbd7\uddb4", "\u15e6\u75b0\uad90", "\uda92\udfa7\ud809\uddbb\ud892\uddaf\udb3d\udfb4\udaa5\udde0\uc059\ud907\ude9b\uda20\udfb5\udb10\ude68\udaa4\udedc\udbe1\udd9e",
        57, 90999, 128104116, 4630388858555934264L, 22513L, true, false, (char) 50077, (char) 13696,
        Double.longBitsToDouble(0x3fd9a8dda446abeeL), Double.longBitsToDouble(0x3feb8b07b5b37af1L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 1, "\udaf6\udca0\uda83\udf75\udb87\udfac\udb57\udd6a\udbc7\udcce\ud84c\uddd4\udbf0\udf91\ud8fa\uddb3", "\u7f25\u0bb9\uad90", "\ud908\udfc1\ud976\udfbb\ud92a\udd9c\udb3d\udfb4\udaa5\udde0\uc059\ud907\ude9b\uda20\udfb5\udb10\ude68\udaa4\udedc\udb49\ude7b",
        31, 92572, -1494124946, 4630388854797837880L, 39697L, true, false, (char) 10888, (char) 15405,
        Double.longBitsToDouble(0x3fe16c6ed7700f19L), Double.longBitsToDouble(0x3feb8fcb455f7af1L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 10, 10, 6, "\ud926\udcd9\udb1a\udc7e\ud9e2\udcc3\udb5d\udc85\uda15\udcb4\ud899\udd47\ud934\uddbd\ud90c\ude40", "\u3b96\uc39d\u30ce\ubbf7\u3c73\ua40e", "\ud8b9\uddca",
        28, 75825, -452591085, -4567721450625517608L, 60296L, false, false, (char) 35918, (char) 23768,
        Double.longBitsToDouble(0x3fe1f887969545a9L), Double.longBitsToDouble(0x3fee8ee574a7a3b3L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 9, 9, 12, "\udbf8\uddb2\uda88\udcae\ud843\udc78\udb57\udd85\udbc7\udcce\ud90a\udfd9\ud9f4\udecd\ud90c\udd95", "\u3b96\u5b2b\uc47f\u2dee\uc471\u0ef0\u1780\ud4ed\u5d9a\uaf3b\u1377\uac18\u79da\u6554\u06d7\u48eb\ub542\uc825\u9912\u2719\ua8a3", "\uda9e\udc62\ud95c\udd42\ud8ca\ude77\ud912\udd54\udbe1\udf9d\ud90b\udd5f\ud801\udf00\ud8c3\udf22\ud8d9\udc15\uda39\udd50\u3c16\udafe\uddb1\ud9f3\udfaa\uda4f\ude85\ud9f8\udcdc",
        20, 66996, 615626394, -6531545220483572373L, 7898L, false, false, (char) 62510, (char) 6478,
        Double.longBitsToDouble(0x3fe5acfd6eb88de5L), Double.longBitsToDouble(0x3fee522e8c8e17c6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 8, 8, 12, "\uda9b\udc61\uda88\udcae\ud843\udc78\udb57\udd49", "\u1356\uab9e\u959c", "\udbe3\uded1\ud8e2\udf85\udbfa\ude99\udb73\uddd2\udbb6\uddfb\uc79e\ud923\udec7\udbc3\udeb9\ud968\udd63\u692e\u6c79\udb02\ude5e\udb9d\udc39\ud908\udfe1\udafe\ude87\udaf8\ude33\ud93e\ude71\ud9ca\udc31\ud9fa\ude71\udb6e\udfc6\ud83e\udcc1\udaae\udfeb\uda9e\udc62\ud88a\udd39\ud8bc\ude70\udb2b\udff7\ud852\udce8\ud844\ude2d\ud805\udfc2\ud972\ude8b\ud9e7\udfd4\ud8a1\uddd5\udb23\udcd1\ud968\uded1\u4d4d\ud8e8\udd19\ud88b\udf5f\udbb2\udf79\udab8\ude2e\u5f71\udab7\udca7\udb86\udee8\ud80d\udf0d\ud809\udc4c\uc6f2\ud8bb\ude67\uda16\uddfa\ud8e6\udca2\uda19\ude6f\ud9fc\uddea\udad5\udde1\ud91e\udc7e\udbf6\udc19\ud9aa\udd03\udbfd\ude5c\u048d\ud9c2\udea8\ud9bd\udda5\ud98a\udf6b\ud92d\udf49\ud999\udd49\udb9d\udc16\ud80d\udcd6\ud910\uddb8\udbaf\udeb3\ud82c\udec0\ud93f\uddba\udbe6\udcc2\udba7\udc93\uda00\udc2c",
        15, 84391, 1090337271, -3053630573620119080L, 26303L, true, true, (char) 26181, (char) 43434,
        Double.longBitsToDouble(0x3fd8db793724b3f0L), Double.longBitsToDouble(0x3fc3ab1d6d5d2bd4L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 14, 14, 14, "\ucd41\ud8b8\udde1\ud974\udf9d\ud920\ude53\udabb\udd50\ud90a\udfd9\ud941\udd06\ud90c\ude40", "\u3b96\u1ccc\uafe9\ubb2b\ucc0f\u24be", "\ud935\udf50\udba1\ude80\ud842\udc42\udb25\udcb9\udac7\udc0d\ud888\udd08\udad6\ude10\udbad\udec3\ud8f6\udd69\ud94b\udf71\udba3\ude61\uda89\udfe5\udb47\udcb5\ud982\udda3\ud98d\udc84\udb35\udfcd\ud872\udd5a\ud87b\udfc1\ud89b\udc6f\ud802\ude0e\udad2\udd85\uda24\udf56\ud827\udef6\udb69\udea4\udbd3\udda3\udb20\udf96\ud90f\uddcb\udbb4\udc03\udb5b\udf46\ud9e9\ude14\ud9f2\udf74\udba9\udd46\udb7d\udc84",
        8, 90894, -999684849, 5916215936484409490L, 79885L, false, false, (char) 61864, (char) 41340,
        Double.longBitsToDouble(0x3fb9b927f879d7d0L), Double.longBitsToDouble(0x3feeb06f2574d2f3L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 13, 13, 6, "\ud926\udcd9\udb1a\udc7e\ud9e2\udcc3\udb57\udd85\udbc7\udcce\ud90a\udfd9\ud941\udd06\ud90c\ude40\udad6\ude1c\ud9a4\udc95\uda36\udf7f\ud9b6\udeb9\udaf4\udf4e\udaf6\udec5\ud97c\udcea\ud82c\udd93", "\u6761", "\ud995\udc91\uda96\udf04\uda30\ude19\ud87b\ude7e\ud9e5\udc29\ud8f6\udd36\ud9c5\udf40\udba3\uded6\uda67\udd24\udb47\udcb5\ud8cc\udc6c\uda12\ude19\ud8b7\udec5\udba3\udd37\ud956\udde2\udafa\udcd9\udb93\udc49\udbeb\ude5b",
        5, 10197, -546955926, -6135559547201572098L, -92702L, true, false, (char) 36227, (char) 21072,
        Double.longBitsToDouble(0x3fe78a45c3385422L), Double.longBitsToDouble(0x3fe98c967e1e7e37L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 15, 15, 4, "\udaf6\udca0", "\uc09a\ub80c\u380d\u9938\u6311\u2f07", "\uda6c\udf4c\ud82c\udd4c",
        44, 2556, -1944606811, 15426916152095838L, -40901L, false, false, (char) 58247, (char) 33241,
        Double.longBitsToDouble(0x3fcc996e52024f40L), Double.longBitsToDouble(0x3fdb0c9c53c9102cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 13, 6, "\udbd4\udca9\udb1a\udc7e\ud9e2\udcc3\udb57\udd85\udbc7\udcce\ud8a3\udd25\uda4b\ude36\udaec\udc96", "\u3b96\u1ccc\uafe9\ubb2b\uaed1\u24be", "\udb47\ude59",
        0, 94878, -452276174, -4567721450625517608L, -5040L, true, false, (char) 35918, (char) 23768,
        Double.longBitsToDouble(0x3faf887969545a90L), Double.longBitsToDouble(0x3fca3b95d28e8f68L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|createKeyDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_addDeserializerConstructors|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.deser.impl.CreatorCollector,java.util.Map|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_addDeserializerFactoryMethods|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.deser.impl.CreatorCollector,java.util.Map|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_checkIfCreatorPropertyBased|com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_checkImplicitlyNamedConstructors|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.deser.impl.CreatorCollector,java.util.List|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_constructDefaultValueInstantiator|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_createEnumKeyDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCreatorsFromProperties|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomArrayDeserializer|com.fasterxml.jackson.databind.type.ArrayType,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.JsonDeserializer|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomBeanDeserializer|com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomCollectionDeserializer|com.fasterxml.jackson.databind.type.CollectionType,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.JsonDeserializer|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomCollectionLikeDeserializer|com.fasterxml.jackson.databind.type.CollectionLikeType,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.JsonDeserializer|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomEnumDeserializer|java.lang.Class,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomMapDeserializer|com.fasterxml.jackson.databind.type.MapType,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.KeyDeserializer,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.JsonDeserializer|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomMapLikeDeserializer|com.fasterxml.jackson.databind.type.MapLikeType,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.KeyDeserializer,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.JsonDeserializer|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomReferenceDeserializer|com.fasterxml.jackson.databind.type.ReferenceType,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.JsonDeserializer|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|createKeyDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
