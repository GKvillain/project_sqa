package com.fasterxml.jackson.databind.deser.impl;
import org.junit.Test;
import static org.junit.Assert.*;
public class BeanPropertyMap_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ArrayStoreException\012",
        Z.run(T, 2, 10, 5, 14, "\ud9d0\udd74\ud875\udf4d", "\u94e5\u6d1c\ub0d0\u3efe\u94e7\u074a\uab6b\ubba2\ud74e\ua5b4", "\ud8a7\udd32\ud9a1\udeed\ud9ac\udd8d\udba2\udfec\udbf8\udd4a\udbad\udc2c\udbba\udd12\udb60\udd25\udb96\udc57\u1286\ud963\udfe6\ud93b\udfd9",
        31, 40062, -1105179210, 5136023954715224973L, -50162L, true, true, (char) 59763, (char) 61737,
        Double.longBitsToDouble(0x3feba44687fa9cf0L), Double.longBitsToDouble(0x3fe06608874e27b4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ArrayStoreException\012",
        Z.run(T, 2, 10, 5, 14, "\ud9d0\udd74\ud875\udf4d\udae8\udfa4\udbed\ude4c\udbb9\udee8\uf4fc\ud932\udc7b\ud8b3\udfd7", "\uab6b\ubba2\u098a\u70ec\u391a\u70bd", "\ud9ac\udd8d\udba2\udfec\udbf8\udd4a\udbad\udc2c\udbba\udd12\udb60\udd25\udb96\udc57\ud9e3\udf75\ud987\udefb\ud93b\udfd9\udad8\udeb0\uda51\udfd1",
        8, 83763, 850570125, -1609355348462747574L, -26750L, true, false, (char) 60338, (char) 53910,
        Double.longBitsToDouble(0x3f898221bfe87600L), Double.longBitsToDouble(0x3fe9fd189ed5ff50L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ArrayStoreException\012",
        Z.run(T, 2, 9, 5, 14, "\ud9d0\udd74\ud875\udf4d", "\u5392\u6d1c\ub0d0\u3efe\ub5d5\u074a\uab6b\ubba2\ud74e\ua5b4", "\ud8a7\udd32\ud9a1\udeed\ud9ac\udd8d\udba2\udfec",
        49, 98278, -1434579593, -7462635948839905993L, -74366L, true, false, (char) 43624, (char) 61468,
        Double.longBitsToDouble(0x3fdb6e55a3277c40L), Double.longBitsToDouble(0x3fef1d52fbd6f580L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.ArrayStoreException\012",
        Z.run(T, 2, 1, 5, 14, "\ud9d0\udd74\ud875\udf4d", "\u94e5\u6d1c\ub0d0\u3efe\u94e7\u074a\uab6b\ubba2\ud74e\ua5b4", "\ud9db\udd5e\udbe5\ude5d\ud9ac\udd8d\udba2\udfec\udbf8\udd4a\udbad\udc2c\udbba\udd12\udb60\udd25\udb96\udc57\u1286\ud963\udfe6\ud93b\udfd9",
        31, 40062, -1105179210, 5136023954715224973L, -50162L, true, true, (char) 59763, (char) 61737,
        Double.longBitsToDouble(0x3fdf388d0a261a62L), Double.longBitsToDouble(0x3fe1f4164f4e27b4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 5, 14, "\ud9d0\udd74\ud875\udf4d", "\u94e5\u6d1c\ub0d0\u3efe\u94e7\u074a\uab6b\ubba2\ud74e\ua5b4", "\ud8a7\udd32\ud9a1\udeed\ud9ac\udd8d\ud9dd\ude88\udbf8\udd4a\udaa3\udd47\udbba\udef0\uda38\udfd1\udba2\udd08\u1286\ud963\udfe6\ud93b\udfd9",
        31, 40062, -1095021130, 9047212897494052945L, -50162L, true, true, (char) 59763, (char) 61737,
        Double.longBitsToDouble(0x3feba44687fa9cf0L), Double.longBitsToDouble(0x3fe3de08874e27b4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:16\0121=!java.lang.ArrayStoreException\012",
        Z.run(T, 2, 11, 6, 14, "\ud9fa\udc49\udb37\uddfb\udb34\udfb3\ud8b0\udc43\ud9c9\udf5c\uf4fc\udb89\udff0\udb69\udd4d\ud982\udf78", "\ubba2\ud74e\u5646\ub5a8\u64ec\u1cd7\ud6d0\u801c", "\ud907\udd2e\ud909\udfa2\ud995\udcbf\ud921\udf9a\udb58\udd90\ud966\udfe6\ud93b\udfd9\udad8\udeb0\udbdc\udcfb\udb25\udddd\u523e\udb3b\udcfd\uea85\ud8de\ude0e\ud82d\ude84\udbd3\udf12",
        8, 31986, -1999606101, -7138124647873112070L, 82094L, true, true, (char) 41825, (char) 55598,
        Double.longBitsToDouble(0x3fd3af752734ee80L), Double.longBitsToDouble(0x3fe793669e252fb2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:32\0121=!java.lang.ArrayStoreException\012",
        Z.run(T, 2, 11, 5, 14, "\u0e87\ud862\udc34", "\u94e5\u6d1c\ub0d0\u4745\u4352\u06bd\u261a\ubba2\ud74e\ua5b4", "\ud8a7\udd55\ud814\udc64\u7333\udba2\udf3c\udbf8\udd4a\udbad\udc2c\udbba\udd12\udb60\udd25\ud9e9\udc89\udbbd\ude18\ud964\udc74\ud93b\udfd9\udad8\udeb0\udbdc\udcfb\ud890\uddd4\ud91d\udec6\udb65\ude89\uea85\ud8ff\udd90\ud86e\udfda\ud8e7\udf09\udaf9\udfe2\uda2b\ude30\udb8d\udfa4\uda03\udd9d\ud9db\udc44\u9463\ud953\udcbe",
        18, 5830, -297377529, 2047385161899304560L, -57453L, true, false, (char) 32223, (char) 49685,
        Double.longBitsToDouble(0x3fe909592f837c42L), Double.longBitsToDouble(0x3fceeec651ea56b0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:64\0121=!java.lang.ArrayStoreException\012",
        Z.run(T, 2, 11, 13, 3, "\uda87\ude41\ud875\udf4d", "\u94e5\u6d1c\ub0d0\u3efe\u70c1\ubb2b\u074b\u5ade\ua48e\ua5b4", "\uda9a\udd6c\udbc0\udf2a\ud9ac\udd8d\udba2\udfec\uda7b\udc0b\udbad\udc4c\ud84a\ude16\udb60\udd25\udb96\udc57\u1286\ud963\udfe6\ud93b\udfd9",
        31, 75526, -871914314, -1892644994691585139L, -50162L, true, false, (char) 5609, (char) 61737,
        Double.longBitsToDouble(0x3feba446864610f0L), Double.longBitsToDouble(0x3fec7da72f747d18L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ArrayStoreException\012",
        Z.run(T, 2, 3, 3, 4, "\ud9d0\udd74\ud875\udf4d", "\u94e5\u6d1c\ub0d0\u3efe\u94e7\u074a\uab6b\ubba2\ub49b\ua5b4", "\ud934\uddfc\ud828\udf5d\ud9ce\udf51\udba2\udfec\udbf8\udd4a\udbad\udc2c\udbba\udd12\udb60\udd25\udb96\udc57\ud9ef\ude9b\uda7a\udf34\ud93b\udfd9",
        31, 40062, -1105179210, 5136023954715224973L, 87738L, true, false, (char) 19523, (char) 46314,
        Double.longBitsToDouble(0x3fe86608874e27b2L), Double.longBitsToDouble(0x3fd0e6788bb1d32aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:8\0121=!java.lang.ArrayStoreException\012",
        Z.run(T, 2, 11, 5, 5, "\ud84c\udf55\ud875\udf2a\udae8\udfa4", "\u6d1c", "\ud812\ude70\ud90f\ude37\ud9fd\udf1d\ud9c4\udd05\177\udbce\udcf6\ud8f5\udeb0\ud981\udeae",
        -5, 97529, 1498003756, -225018461383382747L, 27707L, true, true, (char) 29736, (char) 49917,
        Double.longBitsToDouble(0x3fdb952a8300ce3cL), Double.longBitsToDouble(0x3fee3cb09a8eed8eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:16\0121=!java.lang.ArrayStoreException\012",
        Z.run(T, 2, 11, 10, 10, "\ud975\udf86\udab9\udf25\udae8\udf28\udbed\ude4c\udbb9\udee8\uf4fc\ud932\udc7b\ud8b3\udfd7", "\u61fa\ubba2\u098a\uccf9\u391a\u60e3\u51dc\u2a5e\u84f5\u51cb\u8d1f", "\udb60\udd25\udb96\udc57\uda1b\udcf0\ud92a\udd0d\uda12\udfc1\udad4\uddb0\uda51\udfd1",
        8, 83763, 850570125, -1609355348462747574L, -26750L, true, true, (char) 35777, (char) 53770,
        Double.longBitsToDouble(0x3fed147dc80b3ae3L), Double.longBitsToDouble(0x3fdb301c1edbfea0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:64\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 14, "\ud9d0\udd74\ud875\udf4d\udae8\udfa4\udbed\ude4c\udbb9\udee8\udbb6\ude58\ud92e\ude35\ud8b3\udfda\ud982\udf78\udad7\udf37\ud9fc\udcfd\uaffc\udaa4\udcd4\uda45\udd3d\ud820\udcc4\udae6\ude3d\ud9db\udd5e\udbe5\ude5d\udbd3\udd21\uda08\udfd7", "\u5d28", "\u1286\ud963\udfe6\ud93b\udfd9\udad8\udeb0\udbdc\udcfb\ud890\uddd4\ud98c\udf5f\udb65\ude89\uea85\ud8ff\udd90\ud86e\udfda\ud8e7\udf09\uda61\udff5",
        51, 91754, 221318643, -9022674800517066434L, 57676L, false, false, (char) 30849, (char) 50028,
        Double.longBitsToDouble(0x3fee661839220463L), Double.longBitsToDouble(0x3fe787e558c2ce0eL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:128\0121=!java.lang.ArrayStoreException\012",
        Z.run(T, 2, 11, 6, 14, "\ud9fa\udc49\udb37\uddfb\udb34\udfb3\uda70\udcad\ud8f4\udd7e\ud872\udfbb\udb89\udff0\udb69\udd4d\ud9b3\udf78", "\ubba2\ud74e\u5646\ub5a8\u64ec\u1cd7\ud6d0\u801c", "\ud9b0\udf16\ud91a\udfe1\ud995\udcbf\ud921\udf9a\udb58\udd90\ud966\udfe6\ud93b\udfd9\udad8\udeb0\ud870\ude25\udb25\ude0c\u523e\udb3b\udcfd\uea85\ud9e3\udeb1\ud9f5\udef5\udad4\udc41",
        55, 32048, -1999606101, -7138124647873112070L, 82094L, true, true, (char) 41825, (char) 55598,
        Double.longBitsToDouble(0x3fd3af752734ee80L), Double.longBitsToDouble(0x3fe793669e02adb2L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:16\0121=!java.lang.ArrayStoreException\012",
        Z.run(T, 2, 11, 8, 10, "\ud9fa\udc49\udb37\uddfb\udb34\udfb3\ud89d\ude47\ud9c9\udf5c\uf4fc\udb89\udff0\udb69\udd4d\udbc9\udd48", "\ubba2\ud74e\u82b6\u6c13\u3da9\u1cd7\ud6d0\u801c", "\ud907\udd2e\ud909\udfa2\ud995\udcbf\ud921\udf9a\ud938\udc40\ud967\udc4b\uc013\udac9\uddf7\udaec\udd83\udb25\udd8b\u523e\udb3b\udcfd\uea85\ud8de\ude0e\ud8f5\ude88\udbd3\udf12",
        8, 31986, -1999606101, -7138124647873112070L, 82094L, true, true, (char) 41825, (char) 55598,
        Double.longBitsToDouble(0x3fd3af752734ee80L), Double.longBitsToDouble(0x3fe793669e252fb2L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Integer:32\012",
        Z.run(T, 1, 11, 6, 14, "\ud9fa\udc49\udb37\uddfb\udb34\udfb3\ud8b0\udc43\ud9c9\udf5c\uf4fc\udb89\udff0\udb69\udd4d\ud982\udf78", "\ubba2", "\ud8f5\ude2e\ud8d8\udfda\udbb7\udfba\ud9a1\udeed\ud8d1\ude81",
        22, 76945, 134892725, -5395747707110824109L, -94457L, false, false, (char) 56826, (char) 43624,
        Double.longBitsToDouble(0x3fee1bd5c1b68a4eL), Double.longBitsToDouble(0x3fea5df61a0175ebL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:16\0121=java.lang.Integer:16\012",
        Z.run(T, 2, 11, 11, 14, "\ud9fa\udc49\udb37\uddfb\udb34\udfb3\ud8ee\udc42\uda18\udec6\udb70\udcd5\udb56\udf0d\udbf9\udc5d\ue287", "\u5d2e\u391c\u53a7\u4eb8\u64ec\u1e98\u704f\u52c2", "\ud907\udd2e\ud9bc\udc9a\udb21\udea0\ud836\udf1c\ud81a\udcb0\ud966\udfe6\udac3\udfdd\udbb0\udc3e\ud81c\udc98\ud919\uddfa\udb6b\udda7\uda4c\udd8e\udb89\udea2\ud8de\udde5\ud82d\ude84\udbd3\udf12",
        8, 4850, -1999606101, 5597093025081614315L, 82094L, true, true, (char) 11965, (char) 39366,
        Double.longBitsToDouble(0x3fd3af75a734ee80L), Double.longBitsToDouble(0x3fe793669f9a7cc3L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:32\0121=java.lang.Integer:32\012",
        Z.run(T, 2, 11, 11, 14, "\ud9fa\udc49\udbb7\uddfb\udb34\udfb3\ud8b0\udc43\ud83b\udf54\uf4fc\udbb0\udf7a\udb69\udd4d\ud982\udf78", "\uce00\u69df\ud058\ub559", "\ud9a1\udeed\ud888\udf28",
        22, 54796, -1811264331, -2154415391498204591L, 51378L, false, true, (char) 53250, (char) 10655,
        Double.longBitsToDouble(0x3fe47477b870e55aL), Double.longBitsToDouble(0x3fdc9aaae40350a8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:128\0121=java.lang.Integer:128\012",
        Z.run(T, 2, 11, 11, 14, "\ud93f\ude1d\udb37\uddfb\udb34\udfb3\ud8b0\udc43\ud9c9\udf5c\uf4fc\uda66\udd1e\udb69\udd4d\ud9a7\udc68", "\ubba2\u26b6\ud4f6\u2e42\u64ec\u5192\u1546\u3f8f", "\u865c\ud909\udfa2\ud995\udcbf\ud921\udf9a\udb58\udd90\ud966\udfe6\ud93b\udfd9\ud950\udeac\udbdc\udcfb\udbb9\udfa8\u1dcc\udb5e\udc3a\ud817\udcff\ud8de\ude0e\ud82d\ude84\udbd3\udf12",
        56, 68554, -855077613, 8711787027350165498L, 21790L, true, false, (char) 6472, (char) 18568,
        Double.longBitsToDouble(0x3fed730d439a771cL), Double.longBitsToDouble(0x3fe793669cdfe1b2L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:8\0121=java.lang.Integer:8\012",
        Z.run(T, 2, 11, 11, 3, "\udbab\udd13\ud8ed\uddcf", "\u94e5\u6d1c", "\uda52\udce0\udb99\udd03\uda52\udfb1\ud984\udd98\udbb7\udd9c\uda45\udd3d",
        -1, 55701, -1361531339, -7268376335720483742L, 58526L, true, false, (char) 59510, (char) 40199,
        Double.longBitsToDouble(0x3fe1b8f78d4c59c3L), Double.longBitsToDouble(0x3fe8c518653510adL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.ArrayStoreException\012",
        Z.run(T, 2, 10, 5, 14, "\ud9d0\udd74\ud875\udf4d\udae8\udfa4", "\u52bd", "\ud982\udf78\udad7\udf16\ud9fc\udcfd\uaffc\udaa4\udcd4\uda45\udd3d\ud8f5\udeb0\ud981\udeae\ud8a7\udd32\ud9a1\ude8a\ud99b\udc7e\ud99f\uddba\udbe7\udf84\udbad\udc2c",
        53, 28875, -1386851017, 5956034315273659426L, -95976L, false, false, (char) 13073, (char) 34595,
        Double.longBitsToDouble(0x3fe9da3a33d632aaL), Double.longBitsToDouble(0x3fb2ba6ab766b670L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|remove|com.fasterxml.jackson.databind.deser.SettableBeanProperty|new:com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap:boolean,java.util.Collection",
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|_find2|java.lang.String,int,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap:boolean,java.util.Collection",
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|_findFromOrdered|com.fasterxml.jackson.databind.deser.SettableBeanProperty|new:com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap:boolean,java.util.Collection",
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|_findIndexInHash|java.lang.String|new:com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap:boolean,java.util.Collection",
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|_hashCode|java.lang.String|new:com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap:boolean,java.util.Collection",
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|_rename|com.fasterxml.jackson.databind.deser.SettableBeanProperty,com.fasterxml.jackson.databind.util.NameTransformer|new:com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap:boolean,java.util.Collection",
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|assignIndexes||new:com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap:boolean,java.util.Collection",
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|construct|java.util.Collection,boolean|static",
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|find|int|new:com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap:boolean,java.util.Collection",
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|find|java.lang.String|new:com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap:boolean,java.util.Collection",
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|findDeserializeAndSet|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object,java.lang.String|new:com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap:boolean,java.util.Collection",
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|findSize|int|static",
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|getPropertiesInInsertionOrder||new:com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap:boolean,java.util.Collection",
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|getPropertyName|com.fasterxml.jackson.databind.deser.SettableBeanProperty|new:com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap:boolean,java.util.Collection",
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|init|java.util.Collection|new:com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap:boolean,java.util.Collection",
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|iterator||new:com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap:boolean,java.util.Collection",
    "M|com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap|remove|com.fasterxml.jackson.databind.deser.SettableBeanProperty|new:com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap:boolean,java.util.Collection",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
