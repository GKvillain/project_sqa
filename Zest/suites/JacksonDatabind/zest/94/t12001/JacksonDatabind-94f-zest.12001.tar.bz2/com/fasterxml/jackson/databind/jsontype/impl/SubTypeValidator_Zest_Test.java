package com.fasterxml.jackson.databind.jsontype.impl;
import org.junit.Test;
import static org.junit.Assert.*;
public class SubTypeValidator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:@?\0121=com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:@?\012",
        Z.run(T, 2, 1, 1, 0, "\udb2c\udd0a\ud982\udc50\uda85\udf90\ud9c8\udfb8\udbe9\ude8e\ud968\udf96\ud86e\udd38\udb88\udf37\ud867\udfbc\ud83e\ude0f\u3a1f\uda92\udfbb\udb3f\uddad", "\u36cf\u6711\u4886\u8a1e\u11af\ub834\u82c7\u3bcf\u4a96\ub8c8\ubfa4\ub21e\u24a1\uca6c\u873e\u0305\ubf08\u49ec\uc9f3\u562d", "\u11ba\udac8\udfe7\udbd0\udd8b\ud916\udfef\udac3\udf5a\ud830\udc52\udbca\ude94\udbd8\udf1d\ud946\udcd4\udbfd\ude29\ud9e0\udef3\uda92\udfbf\ud96a\ude1b\ud85c\ude8b\uda5f\uddd4\ud9cd\udc67",
        28, 6400, 1033308673, 7003284863376207491L, -83777L, true, false, (char) 32426, (char) 32205,
        Double.longBitsToDouble(0x3fcb21bdb2515a3cL), Double.longBitsToDouble(0x3fb75bbe669672b8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:@?\0121=com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:@?\012",
        Z.run(T, 2, 1, 1, 0, "\udb2c\udd0a\ud982\udc50\uda85\udf90\ud9c8\udfb8\udbe9\ude8e\ud968\udf96\ud86e\udd38\udb88\udf37\ud8db\udd96\ud882\ude4d\ud89b\udcba\uda92\udfe8\udb3f\uddad", "\u36cf\u1840\u4886\u8a1e\u669a\u1a28\ua6ff\u3b28\u51e2\ub89e\ubfa4\ub21e\u24a1\uca6c\u873e\u0305\ubf08\u49ec\uc9f3\u562d", "\u11ba\udac8\udfe7\udbd0\udd8b\ud916\udfef\udac3\udf5a\ud830\udc52\ud92a\udee5\u31b1\udadd\ude5f\udb62\ude3f\ud9e1\udc89\ud956\udf21\udbc6\ude1e\ud85c\ude58\udb25\ude50\ud9fa\ude21",
        28, 6400, 1033308673, 7003284863376207491L, -83777L, true, false, (char) 32426, (char) 32205,
        Double.longBitsToDouble(0x3fcb21bdb2515a3cL), Double.longBitsToDouble(0x3fb75bbe669672b8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\udb2c\udd0a\ud982\udc50\udbaa\udc08\udbab\ude1b\udbe5\udc03\ud991\udf6a\ud86e\udd38\udb88\udf37\ud867\udfbc\ud83e\ude0f\u3a1f\udbcf\udd7a\ud85f\udcdb", "\u36cf\u6711\u4886\u8a1e\u11af\ub834\u82c7\u3bcf\u132d\u0523\u0e3e\ub21e\u24a1\uca6c\u873e\u0305\ubf08\u49ec\uc9f3\u562d\ucad5\u644d\uc436\uc824\u6b9e", "\ud8e6\udc49\udbca\ude94\udbd8\udf1d\ud8ce\udef7\ud8ef\udc7d\ud894\udd1a\uda92\udfbf\ud96a\ude1b\ud85c\ude8b\ud8f1\udc3d\ud9cd\udc67\ud8eb\udd66\ud9b5\udd6a\ud887\udda2\ud8e2\udc34",
        34, 45031, 390086634, 5508553621805644088L, 98873L, false, false, (char) 63317, (char) 52009,
        Double.longBitsToDouble(0x3fbd054a105d85f0L), Double.longBitsToDouble(0x3fd48cf268ec747cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:@?\0121=com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:@?\012",
        Z.run(T, 2, 2, 1, 0, "\udb2c\udd0a\ud982\udc50\uda85\udf90\ud9c8\udfb8\udbe9\ude8e\ud968\udf96\ud86e\udd38\udb88\udf37\ud867\udfbc\ud83e\ude0f\u3a1f\uda92\udfbb\udb3f\uddad", "\u36cf\u6711\u4886\u8a1e\u11af\ub834\u82c7\u3bcf\u4a96\ub8c8\ubfa4\ub21e\u24a1\uca6c", "\ud916\udfd8\uda5b\udf4b\udbd9\udd89\udb0d\udfb7\uda96\uddb0\udad9\udd58\u11ba\udac8\udfe7\udbd0\udd8b\ud916\udfef\udbc9\udc8e\udb69\udfc7\ud80b\udf77\udbad\udd57\ud946\udcd4",
        34, 67909, -1454952228, -2539110796609489972L, -43045L, true, true, (char) 29145, (char) 61120,
        Double.longBitsToDouble(0x3fe3d1ecbe836130L), Double.longBitsToDouble(0x3feb3b73475f056aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:@?\0121=com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:@?\012",
        Z.run(T, 2, 1, 1, 0, "\udb2c\udd0a\ud982\udc50\uda85\udf90\ud9c8\udfb8\udbe9\ude8e\ud968\udf96\ud86e\udd38\udb88\udf37\ud867\udfbc\ud83e\ude0f\ud897\udda2\uda92\udfbb\udb3f\uddad", "\u36cf\u6711\u4886\u8398\u2943\ub834\u82c7", "\u9fb4",
        5, 87768, -1337023723, -3018910950966802700L, -17579L, true, false, (char) 21147, (char) 38485,
        Double.longBitsToDouble(0x3fc96d25a6d43ce4L), Double.longBitsToDouble(0x3fe37e31fea9f400L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\udb2c\udd0a\ud982\udc50\uda78\uddef\uda02\udf96\udb03\uded4\ud968\udef8\ud86e\udd38\udb88\udf37\ud867\udf56\ufa0f\u4f2b\uda92\udfbb\udb39\udd29", "\u36cf\u6711\u4886\u8a1e\u11af\u14f3\uc92e\u3bcf\u4a96\ub8c8\ubfa4\ub21e\u9630\uca2a\u873e\u0305\uc362\u49ec\uc9f3\ub75a", "\ud9eb\udd6a\udac8\udfe7\udbd0\udd8b\ud916\udfef\udac3\udf5a\ud830\udc52\udbca\ude94\udbd8\udf1d\uda32\udd83\ud972\udeee\ud9cb\ude64\uda92\udfbf\ud96a\ude1b\ud98f\udf53\uda5f\uddaf\ud9cd\udc67\ud8e4\udf42\udb62\udc54\udb67\ude32",
        42, 13179, 90845031, 1675408739918827605L, 5443L, false, false, (char) 4215, (char) 63317,
        Double.longBitsToDouble(0x3fca59caf5d2aa38L), Double.longBitsToDouble(0x3fca2a5802e6b134L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 0, "\udb2c\udd0a\ud972\udd7c\uda85\udf90\ud9c8\udfb8\ud842\udf6d\udbf6\udd85\ud86e\udd38\udb88\udf37\ud867\udfbc\ud83e\ude0f\u3a1f\uda92\udfbb\udb3f\uddad", "\u36cf\u6772\ub540\u8a1e\u11af\ub834\u82c7\u3bcf\u4a96\ub8c8\ubf1f\ub21e\u24a1\uca6c\u873e\u0305\ubf08\u49ec\uc9f3\u562d", "\u11ba\udac8\udfe7\udbd0\udd8b\ud916\udfef\udac3\udf5a\ud830\udc52\udbca\ude94\udbd8\udf1d\ud946\udcd4\udbfd\ude29\ud9e0\udef3\uda92\udfbf\ud96a\ude1b\ud84c\udcaf\uda5f\uddd4\ud9cd\udc67",
        28, 6400, 1033308673, 7003284863376207491L, -83777L, true, false, (char) 32426, (char) 32205,
        Double.longBitsToDouble(0x3fcb21bdb2515a3cL), Double.longBitsToDouble(0x3fb75bbe669672b8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:@?\0121=new com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:@?\012",
        Z.run(T, 2, 2, 2, 0, "\udb2c\udd0a\ud982\udc50\uda85\udf90\ud9c8\udfb8\udbe9\ude8e\ud968\udf96\ud86e\udd38\udb88\udf37\ud867\udfbc\ud83e\ude0f\u3a1f\uda92\udfbb\udb3f\uddad", "\uc719\u6711\u8eba\u3965\u11af\ub834\u82c7\u3bcf\u4a96\ub8c8\ubfa4\ub21e\u24a1\uca6c\u873e\u0305\ubf08\u3dc5\u10cd\u64f5", "\u11ba\udac8\udfe7\udbd0\udd8b\ud916\udfef\udac3\udf5a\ud830\udc52\udbca\ude94\udbd8\udf1d\ud946\udcd4\udbfd\ude29\ud9c9\udd28\uda92\udfbf\ud96a\ude1b\ud85c\ude8b\uda5f\uddd4\ud9cd\udc67",
        28, 6400, 1033308673, -6184302774635155837L, -83777L, true, false, (char) 32426, (char) 11821,
        Double.longBitsToDouble(0x3fe4dab8931e3f99L), Double.longBitsToDouble(0x3fb74638e69672b8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:@?\012",
        Z.run(T, 1, 1, 1, 0, "\udb2c\udd0a\ud982\udc50\uda85\udf90\ud9c8\udfb8\udbe9\ude8e\ud968\udf96\ud86e\udd38\ud826\udf46\ud867\udfbc\ud83e\ude0f\u3a1f\uda92\udfbb\udb3f\uddad", "\u36cf\u6711\u4886\u8a1e\u11af\ub834\u82c7\u3bcf\u4a96\ub8c8\ubfa4\ub21e\u24a1\uca6c\u873e\u0305\uc820\uc0fa\uca33\u562d", "\u11ba\udac8\udfe7\udbd0\udd8b\ud916\udfef\udac3\udf5a\ud830\udc52\udbca\ude94\udbd8\udf1d\ud946\udcd4\udbfd\ude29\ud9e0\udef3\uda92\udfbf\ud96a\ude1b\ud85c\ude8b\uda5f\uddd4\ud9cd\udc67",
        28, 6400, 1033308673, 7003284863376207491L, -83777L, true, false, (char) 32426, (char) 32205,
        Double.longBitsToDouble(0x3fcb21bdb2515a3cL), Double.longBitsToDouble(0x3fb75bbe669672b8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "\udb2c\udd0a\ud982\udc50\uda85\udf90\ud9c8\udfb8\udbe9\ude8e\ud968\udf96\ud86e\udd38\udb88\udf37\ud867\udfbc\ud83e\ude0f\u3a1f\uda92\udfbb\udb3f\uddad", "\u36cf\u6711\u4886\u8a1e\u11af\ub834\u82c7\u3bcf\u4a96\ub8c8\ubfa4\ub21e\u24a1\uca6c\u873e\u0305\ubf08\u49ec\uc9f3\uc821", "\u11ba\udac8\udfe7\udbd0\udd8b\ud916\udfef\udac3\udf5a\ud830\udc52\udbca\ude94\udbd8\udf1d\ud946\udcd4\udbfd\ude29\ud9e0\udef3\uda92\udfbf\ud96a\ude1b\ud85c\ude8b\uda5f\uddd4\ud9cd\udc67",
        28, 6400, 1033308673, 7003284863376207491L, -83777L, true, false, (char) 32426, (char) 32205,
        Double.longBitsToDouble(0x3fcb21bdb2515a3cL), Double.longBitsToDouble(0x3fb75bbe669672b8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 1, "\udb2c\udd0a\ud982\udc50\udbaa\udc08\udbab\ude1b\udbe5\udc03\ud991\udf6a\ud86e\udd38\udb88\udf37\ud867\udfbc\ud83e\ude0f\u3a1f\udbcf\udd7a\ud85f\udcdb", "\u36cf\u6711\u4886\u8a1e\u11af\ub834\u875c\u3bcf\u132d\u0523\u0e3e\ub21e\u24a1\u8dbb\u873e\u0305\ubf08\u49ec\uc9f3\u562d\ucad5\u644d\uc436\uc824\u6b9e", "\udad0\udec0\udbca\udec1\udbd8\udf1d\ud8ce\udef7\ud906\udff9\ud894\udcee\uda92\udfbf\u113d\udb44\udfe2\udafa\udd50\ud9ff\udc1f\ud8eb\udd66\ud9b5\udd6a\ud887\udda2\ud8e2\udc34",
        34, 45031, 390086634, 5508553621805644088L, 98873L, false, false, (char) 63317, (char) 52009,
        Double.longBitsToDouble(0x3fbd054a105d85f0L), Double.longBitsToDouble(0x3fd48cf268ec747cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator|validateSubType|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator|instance||static",
    "C|com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator|<init>|",
    "M|com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator|validateSubType|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
