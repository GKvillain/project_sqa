package com.fasterxml.jackson.databind.type;
import org.junit.Test;
import static org.junit.Assert.*;
public class CollectionType_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.ArrayList]\012",
        Z.run(T, 1, 4, 18, 13, "\udaae\udec9", "\u3f90\u7974\u00ec", "\ud8ab\udf38\ud85e\udd5f\udae5\udfc3\udb85\udfc3\u9827\ud842\udedb\ud86c\udf04\ud9d1\udd72\ud914\udf9b\ud98a\udf21\ud86d\udc55\ud9e4\uded2\ud92e\udefb\uda58\uded6\ud9be\udf68\ud896\udc66\uda96\uded1\ud983\ude18\ud8ab\udc47\udb30\ude7f\ud8d1\udef0\uda53\udee7\ud99f\udd40\ud8d2\udeb3\udad8\uddd4\ud944\udc6c\udb19\udc40\ud971\udefd\uda39\udc1d\ud8fb\uddf1\ud9f7\udcfe\ud841\ude50\uda99\udf07\ud9d0\udcfa\ud813\ude58\ub65d\ud9af\udfb5\udad1\udfbe\ud9c2\uded9\ud9af\udcae\ud943\udf4e\ud822\udf9c\ud87f\ude81\ud9ef\ude65\uda33\udcfb",
        9, 88043, 336007122, -3928834535132508701L, 29732L, false, true, (char) 58576, (char) 51937,
        Double.longBitsToDouble(0x3fe26a5644872ee2L), Double.longBitsToDouble(0x3febf68aaa78774bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.ArrayList]\012",
        Z.run(T, 1, 4, 18, 13, "\udaae\udec9", "\u3f90\u7974\u00ec", "\ud9db\udf60\uda0f\udd3c\udae5\udfc3\udb85\udfc3\u9827\ud889\udf7f\ud961\udc73\uda2c\udf2d\udaaf\udd9f\ud98a\udf21\ud86d\udc55\ud9e4\uded2\ud9a0\udd54\uda58\uded6\ud9be\udf68\ud896\udc66\uda96\uded1\ud983\ude18\ud8ab\udc47\udb30\ude7f\ud8d1\udef0\uda53\udee7\ud99f\udd40\ud8d2\udeb3\udad8\uddd4\ud944\udc6c\udb19\udc40\ud971\udefd\uda39\udc1d\ud8fb\uddf1\ud9f7\udcfe\ud841\ude50\uda99\udf07\ud9d0\udcfa\ud813\ude58\ub65d\ud9af\udfb5\udad1\udfbe\ud9c2\uded9\ud9af\udcae\ud943\udf4e\ud822\udf9c\ud87f\ude81\ud9ef\ude65\uda33\udcfb",
        9, 88043, 336007122, -3928834535132508701L, 29732L, false, true, (char) 40438, (char) 26794,
        Double.longBitsToDouble(0x3fe26a5644872ee2L), Double.longBitsToDouble(0x3febf68aaa78014bL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Comparable]\012",
        Z.run(T, 1, 4, 18, 13, "\udaae\udec9", "\u2ac5", "\ud98e\ude1e\udb36\udf75\ud8ab\udf38\ud85e\udd5f\ud904\uddf2\udb85\udfc3\u9827",
        22, 26933, -1322814952, -4105235872156593626L, 37251L, false, true, (char) 3190, (char) 48764,
        Double.longBitsToDouble(0x3fe1d01f88754bddL), Double.longBitsToDouble(0x3fd88a0542bc9ae4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Number]\012",
        Z.run(T, 1, 4, 18, 12, "\u5c4b", "\u3f90\u7974\u00ec", "\ud8ab\udf38\ud956\udf1b\udae5\udf78\udb85\udfc3\u9827\ud842\udedb\ud86c\ude67\udbe8\udf0a\ud914\udf9b\ud98a\udf21\ud86d\udc55\ud9e4\uded2\ud92e\udefb\uda58\uded6\ud87a\ude5e\ud8ec\udc51\uda96\uded1",
        21, 64574, -231521456, 7352320862811052377L, -92925L, false, false, (char) 5675, (char) 37351,
        Double.longBitsToDouble(0x3fdfac3aaaaaaa22L), Double.longBitsToDouble(0x3fea0b98d9342d9fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 18, 13, "\udaae\udec9", "\u3f90\u7974\u00ec", "\udb9a\udda7\ud85e\udd91\udae5\udfc3\udb85\udfc3\u9827\ud842\udedb\ud86c\udf04\ud9d1\udd72\ud914\udf9b\ud98a\udf21\ud86d\udc55\ud9e4\uded2\ud92e\udefb\uda58\uded6\ud9be\udf68\ud896\udc66\uda96\uded1\ud983\ude18\ud8ab\udc47\udb30\ude7f\ud8d1\udef0\uda53\udee7\ud99f\udd40\ud8d2\udeb3\udad8\uddd4\ud944\udc6c\udb19\udc40\ud971\udefd\uda39\udc1d\ud8fb\uddf1\ud9f7\udcfe\ud841\ude50\uda99\udf07\ud9d0\udcfa\ud813\ude58\ub65d\ud9af\udfb5\udad1\udfbe\ud9c2\uded9\ud9af\udcae\ud943\udf4e\ud822\udf9c\ud87f\ude81\ud9ef\ude65\uda33\udcfb",
        9, 88043, 336007122, -3928834535132508701L, 29732L, false, true, (char) 58576, (char) 5571,
        Double.longBitsToDouble(0x3fe26a5074872ee2L), Double.longBitsToDouble(0x3febf68aaa78774bL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Long]\012",
        Z.run(T, 1, 4, 18, 0, "\udaae\udec9", "\u3f90", "\udb90\udc9f\udb36\udf75h\ud85e\udd02",
        40, 50425, 518260309, 4337423079217130752L, -52314L, false, false, (char) 29287, (char) 18534,
        Double.longBitsToDouble(0x3fed752e904df428L), Double.longBitsToDouble(0x3fe96d1a7e3a03f1L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 11, 5, "\ud9b1\ude8b", "\u3f90\u7974\u00ec", "\ud8ab\udf38\ud85e\udd5f\udae5\udfc3\udb85\udfc3\u9827\ud842\udedb\ud86c\udf04\ud9d1\udd72\ud914\udf9b\ud98a\udf21\ud86d\udc55\ud960\udc2f\000\000\ud8dc\udc2d\ud896\udc66\uda96\uded1\ud983\ude18\ud8ab\udc47\udb30\ude2f\ud8d1\udef0\uda53\udee7\ud99f\udd40\ud8d2\udeb3\udad8\uddd4\ud944\udc6c\udb19\udc40\ud971\udefd\uda39\udc1d\ud8fb\uddf1\ud9f7\udcfe\ud841\ude50\uda99\udf07\ud9d0\udcfa\ud813\ude58\ub65d\ud9af\udfb5\udad1\udfbe\ud9c2\uded9\ud9af\udcae\ud943\udf4e\uda15\udfd6\u34c6\ud9ef\ude65\uda33\udcfb",
        9, 88043, 336007122, -3928834535132508701L, 29732L, false, true, (char) 58576, (char) 51937,
        Double.longBitsToDouble(0x3fe26a5644872ee2L), Double.longBitsToDouble(0x3febf68aaa78774bL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 13, "\udaae\udec9", "\u80f9\u4c5e\u00ec\u1da2\u5d42\ub734\ucee3\uc6e7\u8854\u8af1\u7ea6\u831b\u1ca5", "\ud86d\udc55",
        18, 81222, -1555097523, 284038132207054394L, -2088L, false, true, (char) 60661, (char) 41746,
        Double.longBitsToDouble(0x3fc0de3c8d8f5a2cL), Double.longBitsToDouble(0x3fe518fd2ee80113L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Comparable]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 18, 13, "\udaae\udec9", "\u3f90\u323d\u1d96", "\ud8ab\udf38\ud883\ude5f\udae5\udfc3\udb5c\udc30\u9827\udad9\udc0b\ud86b\ude57\ud9d1\udd72\ud906\udc9b\ud83a\udfeb\ud86d\udc4c\ud9e4\uded2\ud92e\udeb9\uda58\uded6\ud9be\udf68",
        8, 14125, -65839736, -6253898057416228016L, -70677L, false, true, (char) 64878, (char) 15946,
        Double.longBitsToDouble(0x3fea0b98d9342d9fL), Double.longBitsToDouble(0x3fe105c4a352bf50L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 6, 13, "\udaae\udec9", "\u3f90\u7974\u00ec", "\ud8ab\udf38\ud85e\udd5f\udae5\udfc3\udb85\udfc3\u9827\udb21\udfb2\ud993\udc04\ud9d1\udd72\ud914\udf9b\ud98a\udf21\ud86d\udc55\ud9e4\uded2\ud807\udfb4\udb5a\udcad\ud9be\udf68\ud896\udc66\uda96\uded1\ud983\ude18\ud8ab\udc47\udb30\ude7f\ud8d1\udef0\uda53\udee7\ud9c6\udfc0\ud8d2\udeb3\udad8\uddd4\ud944\udc6c\udb19\udc40\ud971\udefd\uda39\udc1d\ud8af\udfcc\ud9f7\udcfe\ud841\ude50\uda99\udf07\ud9d0\udcfa\ud813\ude58\ub65d\ud9af\udfb5\ud87a\udd97\ud9c2\udec0\ud9af\udcae\ud943\udf4e\uda75\udff1\ud87f\ude81\ud9ef\ude65\uda33\udcfb",
        9, 52906, -228011566, 5395768876172637468L, 29732L, false, true, (char) 58576, (char) 28814,
        Double.longBitsToDouble(0x3fe26a55fc872ee2L), Double.longBitsToDouble(0x3febf68aaa78774bL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 12, 13, "\udaae\udec9", "\ud445\u794e\u00ec", "\ud8ab\udf38\ud85e\udd5f\udae5\udfc3\udb85\udfc3\u9827\ud842\udedb\ud86c\udf04\ud9d1\udd72\ud914\udf9b\ud98a\udf21\ud86d\udc55\ud9e4\uded2\ud92e\udefb\uda58\uded6\ud9be\udf68\ud896\udc66\uda96\uded1\ud983\ude18\ud8ab\udc47\udb30\ude7f\u6335\ud92f\udc2d\ud99f\udce1\ud8d2\udeb3\udad8\uddd4\ud944\udc6c\udb19\udc40\ud971\udefd\uda39\udc1d\ud8fb\uddf1\ud9f7\udcfe\ud969\ude97\ud87c\udf6a\ud9d0\udcfa\ud813\ude58\ub65d\ud9af\udfb5\udad1\udfbe\ud9c2\uded9\ud9af\udcae\ud943\udf4e\ud822\udf9c\ud87f\ude81\ud9ef\ude65\uda33\udcfb",
        -1, 88043, 336007122, -3928834535132508701L, 29732L, false, true, (char) 58576, (char) 51799,
        Double.longBitsToDouble(0x3fe26a5644872ee2L), Double.longBitsToDouble(0x3febf68aaa78774bL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 11, 13, "\udaae\udec9", "\u3f90\u7974\u00ec", "\ud8ab\udf38\ud85e\udd5f\udae5\udfc3\udb85\udfc3\u9827\ud842\udedb\ud86c\udf04\ud9d1\udd72\ud914\udf9b\ud98a\udf21\ud86d\udc55\ud9e4\uded2\ud92e\udefb\uda58\uded6\ud9be\udf64\ud875\udc66\uda96\uded1\ud983\ude18\ud8ab\udc47\udb30\ude7f\ud8d1\udef0\uda53\udee7\ud99f\udd40\ud8d2\udeb3\udad8\uddd4\ud944\udc6c\udb19\udc40\ud971\udefd\uda39\udc1d\ud8fb\uddf1\ud9f7\udcfe\ud84e\udf50\uda99\udf07\ud9d0\udcfa\ud813\ude58\ub65d\ud9af\udfb5\udad1\udfbe\uda61\udf08\ud93b\udd64\ud943\udfb0\ud822\udf9c\ud87f\ude81\ud9ef\ude65\uda33\udcfb",
        -4, 88043, 336007122, -3928834535132508701L, 29732L, false, true, (char) 58576, (char) 51937,
        Double.longBitsToDouble(0x3fe26a5644872ee2L), Double.longBitsToDouble(0x3febf68aaa78774bL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 17, 13, "\udaae\udec9", "\u3f90\u7974\u00ec", "\ud8ab\udf38\ud85e\udd5f\udae5\udfc3\ud961\ude92\uea34\ud842\udedb\ud86c\udf04\ud9d1\udd72\ud914\udf9b\ud98a\udf21\ud86d\udc55\ud9e4\uded2\ud92e\udefb\uda58\uded6\ud9be\udf68\ud896\udc66\uda96\udefa\ud983\ude18\ud8ab\udc47\udb30\ude7f\ud8d1\udef0\uda53\udee7\ud977\udda7\ud81e\udc3d\ud863\ude37\ud955\udd9d\udb19\udc40\ud971\udefd\uda39\udc1d\ud8fb\uddf1\ud9f7\udcfe\ud8af\udc55\ud904\udedc\udb20\udcf8\ud813\ude58\ub65d\ud9af\udfb5\udad1\udfbe\ud9c2\uded9\uda0b\udf95\ud943\udf4e\ud822\udf9c\ud87f\ude81\ud9ef\ude65\uda33\udcfb",
        9, 88043, 336007122, -3928834535132508701L, 29732L, false, false, (char) 58753, (char) 58941,
        Double.longBitsToDouble(0x3fe26a5644872ee2L), Double.longBitsToDouble(0x3febf68aaa78774bL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 7, 13, "\udaae\udec9", "\ub509", "\ud843\udd29\ud989\udecd\ud9e9\udd25\ud85e\udd79",
        40, 50425, 968670549, 8148367535125252892L, 49830L, true, false, (char) 62659, (char) 18534,
        Double.longBitsToDouble(0x3fe87d2e9498f40dL), Double.longBitsToDouble(0x3fe96d1a7e3a03f1L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 18, 13, "\udaae\udec9", "\u3f90\u7974\u00ec", "\ud8ab\udf38\ud85e\udd5f\udae5\udfc3\udb85\udfc3\u9827\ud842\udedb\ud86c\udf04\ud9d1\udd72\ud914\udf9b\udb61\udcbc\ud86d\udc55\ud9e4\uded2\ud92e\udefb\uda58\uded6\ud9be\udf68\ud896\udc66\uda96\uded1\uf916\ud8ab\udc06\udb30\ude7f\ud8d1\udef0\uda53\udee7\ud99f\udd40\ud8d2\udeb3\udad8\uddd4\ud944\udc6c\uda16\udc68\ud971\ude86\uda39\udc1d\ud8fb\uddf1\ud9f7\udcfe\ud841\ude50\uda99\udf07\ud9d0\udcfa\ud813\ude58\ub65d\ud9af\udfb5\udad1\udfbe\ud9c2\uded9\ud9af\udcae\ud943\udf4e\ud822\udf9c\ud87f\ude81\ud9ef\ude65\uda33\udcfb",
        9, 67227, 1858430712, -3928834535132508701L, 29732L, false, true, (char) 58576, (char) 51937,
        Double.longBitsToDouble(0x3fe26a5644872ee2L), Double.longBitsToDouble(0x3febf68aaa78774bL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Long]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 18, 13, "\udaae\udec9", "\u3f90\u7974\u4046", "\ud8ab\udf38\ud85e\udd5f\udae5\udfc3\udb85\udfc3\u9827\ud842\udedb\ud86c\udf04\ud9d1\udd72\ud914\udf9b\ud98a\udf21\ud86d\udc55\ud9e4\uded2\ud92e\udefb\uda58\uded6\ud9be\udf68\ud896\udc66\uda96\uded1\ud983\ude18\ud8ab\udc47\udb30\ude7f\ud8d1\udef0\uda53\udee7\ud99f\udd40\ud8d2\udeb3\udad8\uddd4\ud944\udc6c\udb19\udc40\udbd2\ude6f\uda39\udc1d\ud8fb\uddf1\ud9f7\udcfe\ud841\ude50\uda99\udf07\ud935\udfb1\ud813\ude58\ub65d\u8935\udac6\udedc\ud9c2\uded9\ud9af\udcae\ud943\udf4e\ud822\udf9c\ud87f\ude81\ud9ef\ude65\udb02\ude63",
        -2, 88043, 336007122, -3928834535132508701L, 29732L, false, true, (char) 58576, (char) 51937,
        Double.longBitsToDouble(0x3fe26a5644872ee2L), Double.longBitsToDouble(0x3febf68aaa78774bL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class [Ljava.lang.String;]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 18, 13, "\ud947\udf00", "\u26dc\u7974\u00ec\u1da2\u5d42\ub734\u7e6b\u9f74\u016d\u8af1", "\ud9d1\udd72",
        6, 71534, 809757053, -6498104773937968210L, 89651L, false, false, (char) 40274, (char) 8668,
        Double.longBitsToDouble(0x3fd5e4d726a1534aL), Double.longBitsToDouble(0x3feeff91997963bdL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.String]\012",
        Z.run(T, 1, 5, 18, 13, "\udaae\udec9", "\u3f90\u7974\u9ca9", "\ud8ab\udf38\ud85e\udd5f\udae5\udfc3\udb85\udfc3\u9827\ud842\udedb\ud86c\udf04\ud9d1\udd72\ud914\udf9b",
        14, 39053, -1512957917, -853348920245413811L, 26522L, true, false, (char) 8668, (char) 44752,
        Double.longBitsToDouble(0x3fea854d28dff233L), Double.longBitsToDouble(0x3fd59668f6c7ad16L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 3, 13, "\udaae\udec9", "\u3f90\u5b0f\u6df6", "\ud8ab\udf38\ud85e\udd5f\udae5\udfc3\udb85\udfc3\u9827\ud842\udedb\ud86c\udf04",
        43, 71826, -1997909466, 3477880060723206179L, -40685L, true, true, (char) 61994, (char) 40274,
        Double.longBitsToDouble(0x3fd7ea0542bc9ae4L), Double.longBitsToDouble(0x3fea854d28dff233L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Long]\012",
        Z.run(T, 1, 5, 18, 13, "\uda19\uddc2", "\u3f90", "\udb90\udc9f\udb36\udf75\udb9a\udda7\ud85e\udd91",
        40, 50425, 518194773, 4337423079217131005L, -52314L, false, false, (char) 29287, (char) 18534,
        Double.longBitsToDouble(0x3fed752e90e1f428L), Double.longBitsToDouble(0x3fe96d1db63a03f1L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 6, 1, "\udaae\udec9\ud8c6\udc7f", "\u7974\u00ec\u1da2\u5d42\u39e4\u7e9d\u9f74\u016d\uae26\u906c\u2107\u52a8\ua317\u2502\u42b1\u5d41\uada4\u4a71", "\uda96\uded1\ud99b\udd26\ud8ab\udc47\udb30\ude7f\ud8d1\udef0\uda53\udee7\ud99f\udd40\ud8d2\udeb3\uda40\ude61\udb16\udfd6\udb19\udc40\ud971\udefd\uda39\udc1d\ud8fb\uddf1\ud9f7\udcfe\ud841\ude50\uda99\udf07\ud9d0\udcfa\ud813\ude58\ub65d\uda4e\udfb6\udad1\udfbe\ud9c2\uded9\udada\udcc7\ud8c5\udda3\udbb1\ude55\udbbd\udfe7\ud9fe\udc06\udb87\udefe\u016b\ud963\udcf9\udb32\udc28\ud902\udf03\u9a36\ud964\udc61\ud895\udfa6\ud84a\udcc0\udafd\udc1b\ud925\udd13\uda2c\udc25\udbc8\udd7e",
        4, 53736, -427717056, 1654604820856686882L, -43480L, false, false, (char) 45475, (char) 16465,
        Double.longBitsToDouble(0x3fec12988f253565L), Double.longBitsToDouble(0x3fe794cedf050002L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 20, 14, 11, "\udaae\udec9\027\u80b8", "\ub297\u1da2\u4cd2\u96b4\u7e0e\u9f74\u8e70\u8af1\u7ea6\u821e\u1ca5\ua317\u2502\u42b1\u5d41\uada4", "\udb45\udc9e\udbcb\udfc0\ud9f3\udc01\udae2\udfa6\uda1a\ude7d\ud920\udfca\uda76\uddc9\ud88a\ude31\udbb3\udd01\ud8ca\udd62\uda93\udc8b\uda07\ude4d\ud8e4\udf27\ud851\udc7d\uda7a\udcc3\ud812\udc7f\udb0b\udf57",
        55, 26949, 1071441531, -3910880352092089973L, -80059L, true, false, (char) 55637, (char) 25081,
        Double.longBitsToDouble(0x3fe203677515f208L), Double.longBitsToDouble(0x3fe7d3e17d6bb90dL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Object]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 0, "\udb4e\udd91", "\u3f90", "\udb90\udc9f\udb36\udf75h\ud944\udf15",
        17, 59317, 516057618, 4337423079217130752L, -52314L, false, false, (char) 41456, (char) 18534,
        Double.longBitsToDouble(0x3fdf7edd209be850L), Double.longBitsToDouble(0x3fc55469fb90a40cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 20, 17, "\ud86d\udda9\udba4\udec2\ub36b\udb89\uddfa\udb4c\uddc4\ud98c\uddea\udb90\udc9f\udab2\ude73\uda71\udf4e\udb73\udd5b\ud831\udf47\udb85\udfc3\udb9c\udf28\ud82e\udfcb\ud86c\ude07\ud9d1\udd72\udabb\udd72\ud98a\udf21\ud86d\udc55\ud9e4\uded2\ud92e\udefb", "\u2c72\u0ef4\u472a\u88e5\u992b\ubb1b\ucd34\ub641\u172a\u1367\u271c\ub38a\u0f05\ubf9d\u9e60\u4a6d\u4a36", "\ud911\udf0a\ud931\udc84\ud8f0\ude5c\udaa0\udf63\ud90b\udc85\ud8f2\udd47\udaf7\ude96\udab7\udc3b\ud864\udfd2\ud82f\ude8d\udbb5\udd49\ud91e\ude71\ud984\ude16\ud8e3\udc94\udbd2\udfab\uda11\udf0c\ud855\udfe3\uda1b\udefb\ud80c\udcf1\uda23\udf46\ud8c2\uddaa\udb5e\udd2f\udb97\ude48\u632a\ud9a6\udfdb",
        8, 26628, -667488870, -4998519600296535270L, 73599L, false, true, (char) 64707, (char) 36717,
        Double.longBitsToDouble(0x3fe9dda2f8a35b61L), Double.longBitsToDouble(0x3fd719131cb2894cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.ArrayList]\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.ArrayList]\012",
        Z.run(T, 2, 20, 20, 10, "\uda9c\udd6d", "\u4551", "\uda98\udf4c\udb36\udf75\u40fd\udadd\udfa6\ue3c2\uda76\udef6",
        23, 86007, -1786169621, 2699500521047672250L, 17308L, true, false, (char) 61721, (char) 3190,
        Double.longBitsToDouble(0x3fe9687a7e3a03f1L), Double.longBitsToDouble(0x3feb2424f9648d5bL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Comparable]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 18, "\udaae\udec9", "\u3f90\u323d\u1d96", "\ud8ab\udf38\ud883\ude5f\ud984\udef2\udb5c\udc18\u9827\udad9\udc0b\ud86b\ude57\ud9d1\udd72\ud906\udc9b\ud83a\udfeb\ud86d\udc4c\ud9e4\uded2\ud8aa\udeb7\uda58\uded6\ud9be\udf68",
        8, 14125, -65839736, -6253898057416228016L, -70677L, false, true, (char) 64878, (char) 15946,
        Double.longBitsToDouble(0x3fea0b98dc152d9fL), Double.longBitsToDouble(0x3fe102176b52bf50L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.List]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 0, "", "\u5f89", "\udaf8\ude3e\ud807\udd97\uda91\ude28\ud8ab\uded0\ud883\ude5f\udae5\udfc3\udb5c\udc30\u9827\udad9\udc0b\000\000\ud903\udde1\ud83a\udfeb\ud86d\udc4c",
        18, 81156, 5183565, 284038132207054394L, -99837L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e37480000000000L), Double.longBitsToDouble(0x3fea0b98d9342d9fL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Object]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 12, 13, "\ud8fa\udde3", "\u3f0f\uc36b\uc2c8", "\ud8ab\udf38\ud883\udeec\udaa2\uddf2\udb5c\udc30\u9827\udad9\udc0b\ud86b\ude57\ud9da\udd5f\ud8ba\udccb\ud83a\udfeb\ud86d\udc4c\ud8e8\uded4\ud92e\udeb9\uda58\uded6\ud9be\udf68\udb2e\udd53\uda1e\uddc7",
        17, 16890, -231521456, -6272075403153909264L, 79048L, true, true, (char) 37264, (char) 62243,
        Double.longBitsToDouble(0x3fe103be3b52bf50L), Double.longBitsToDouble(0x3fe6a87fc2220c8bL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.Date]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 17, 3, "\udaae\udec9", "\u0ea1\u323d\u1d96\u8bf8\u5ca8\ub734\u3b6c\u9f74\u31d9\u8af1\u7dc5\u7e6e\u1ca5\u9c5c\u2b0a\u42a8\u5d41\u61b4\u4a71\ud7d8\uc1eb", "\uda70\udfbc",
        24, 92431, -695477927, 2280382043669119651L, -70677L, false, true, (char) 53018, (char) 15920,
        Double.longBitsToDouble(0x3fea0b98d9342d9fL), Double.longBitsToDouble(0x3fe105c4a252bf50L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.Date]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 19, 13, "\udbbe\udc6a\ud8c6\udc7f\u815b\udb89\udd47\ud857\uddc9\udada\udf3e\ud807\udd97", "\u3b6c\u9f74\u31d9", "\ud86b\ude57\uda35\udd63\ud942\udfda\ud83a\udfeb\ud86d\udc4c\u7a92\ud92e\udec7\uda58\uded6\ud9be\udf68\ud896\udc66\uda23\udcd6\udb21\udd10\uda70\udfbc",
        24, 92431, -695477927, 2280382043669119651L, -70677L, false, true, (char) 64878, (char) 15946,
        Double.longBitsToDouble(0x3fe2ba18d9342d9fL), Double.longBitsToDouble(0x3fe105c4a352bf50L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 16, 13, "\uda76\udd7b", "\u3f90\u83c2\u4697", "\ud8ab\udf38\ud883\ude5f\ud9cd\udd6c\ud93e\udfa3\u9827\udad9\udc0b\udbfa\udd59\ud9d1\udd72\ud9a4\uddf0\ud952\ude82\ud8ad\udea8\udac4\udf4f\ud948\udc78\uda58\uded6\ud9be\udf68\ud896\udc66\uda96\uded1\udb21\udd4c\uda70\udfbc\udb30\ude7f\udb0e\udc18\uda35\udfac\ud99f\udd40\ud8d2\udeb3\udad8\uddd4\uda6b\udf91\uda93\ude0d\ud948\udd55",
        41, 41353, -1198225100, -4661082538326312110L, -40998L, false, true, (char) 47215, (char) 3749,
        Double.longBitsToDouble(0x3fc1ec360d06a180L), Double.longBitsToDouble(0x3fd3fee9799b3da0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Integer]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 15, 8, "\udaae\udec9\ud8c6\udc7f\u815b\udb89\uddfa\ud857\uddc9\udaf8\ude3e\ud807\udd97\udb36\udedb\ud8ab\udf38\ud883\ude5f\udae5\udfc3\udb5c\udc30\u9827\udaeb\udee6\ud86b\ude57\ud9d1\udd72\ud906\udc9b\ud83a\udfeb\ud86d\udc4c\ud9e4\uded2\ud92e\udeb9\uda58\uded6\ud9be\udf68\ud896\udc66", "\u99fc", "\uda53\udee7\ud99f\udd40\ud8d2\udeb3\ud816\udeb4\u3d46\ud96f\udfa6\ud95e\udfdd\uda44\uddb1",
        43, 37900, -1085242848, -3240696923094673887L, -54214L, false, false, (char) 47336, (char) 3015,
        Double.longBitsToDouble(0x3fe971d68eeeefacL), Double.longBitsToDouble(0x3fbfd95c709dc490L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.ArrayList]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 8, "\ud947\udf00", "\000\000", "",
        -5, -1000, 0, 0L, 6319L, true, true, (char) 21841, (char) 17850,
        Double.longBitsToDouble(0x3fe131b0380000eaL), Double.longBitsToDouble(0x3e3d752800000000L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 20, 15, 3, "\udaae\udec9", "\u3f90", "\ud9f7\ude53\udb56\ude4a\udbad\udde3\uda18\udcff",
        13, 34889, 518260309, 339302416384L, -100000L, false, false, (char) 35050, (char) 6179,
        Double.longBitsToDouble(0x3fed752e904df428L), Double.longBitsToDouble(0x3fe96d1a78000000L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Integer]\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Integer]\012",
        Z.run(T, 2, 5, 5, 9, "\ud8fa\udde3", "\ub16d\uba79\ua2d9", "\ud8ab\udf38\ud883\udeec\udaa2\uddf2\ud817\ude4e\ud989\udccd\udb07\udf0b\ud86b\ude57\ud9da\udd5f\ud998\udc9a\ud83b\udca3\udb54\udc4c\udae8\udfd4\udae9\uddd8\uda58\uded6\udabb\udfa6\ud9cc\ude53\udb64\udd19",
        1, 16890, -231521456, -2366039454742019740L, -27718L, true, true, (char) 37264, (char) 62243,
        Double.longBitsToDouble(0x3fe103be3b52bf50L), Double.longBitsToDouble(0x3fe6a87fc2220c8bL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.ArrayList]\012",
        Z.run(T, 1, 4, 18, 13, "\udaae\udec9", "\u3f90\u7974\u00ec", "\ud8ab\udf38\ud85e\udd5f\udae5\udfc3\udb85\udfc3\u9827\ud842\udedb\ud86c\udf04\ud9d1\udd72\ud914\udf9b\ud98a\udf21\ud86d\udc55\ud9e4\uded2\ud92e\udefb\uda58\uded6\ud9be\udf68\ud896\udc66\uda96\uded1\ud983\ude18\ud8ab\udc47\udb30\ude7f\ud8d1\udef0\uda53\udee7\ud99f\udd40\ud8d2\udeb3\udad8\uddd4\ud9cf\udf51\udb18\udfd0\ud971\udefd\uda39\udc1d\ud8fb\uddf1\ud9f7\udcfe\ud841\ude50\uda99\udf07\ud9d0\udcfa\ud813\ude58\ub65d\ud9af\udfb5\udad1\udfbe\ud9c2\uded9\ud9af\udcae\ud943\udf4e\ud822\udf9c\ud87f\ude81\ud9ef\ude65\uda33\udcfb",
        9, 88043, 336007122, -3928834535132508701L, 29732L, false, true, (char) 58576, (char) 51937,
        Double.longBitsToDouble(0x3fe26a5644872ee2L), Double.longBitsToDouble(0x3febf68aaa78774bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.type.CollectionType|construct|java.lang.Class,com.fasterxml.jackson.databind.JavaType|static",
    "M|com.fasterxml.jackson.databind.type.CollectionType|construct|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;,com.fasterxml.jackson.databind.JavaType|static",
    "M|com.fasterxml.jackson.databind.type.MapType|construct|java.lang.Class,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JavaType|static",
    "M|com.fasterxml.jackson.databind.type.MapType|construct|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JavaType|static",
    "M|com.fasterxml.jackson.databind.type.SimpleType|_buildSuperClass|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings|static",
    "M|com.fasterxml.jackson.databind.type.SimpleType|construct|java.lang.Class|static",
    "M|com.fasterxml.jackson.databind.type.CollectionType|_narrow|java.lang.Class|new:com.fasterxml.jackson.databind.type.CollectionType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.CollectionType|refine|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;|new:com.fasterxml.jackson.databind.type.CollectionType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.CollectionType|toString||new:com.fasterxml.jackson.databind.type.CollectionType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.CollectionType|withContentType|com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.type.CollectionType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.CollectionType|withContentTypeHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.CollectionType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.CollectionType|withContentValueHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.CollectionType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.CollectionType|withStaticTyping||new:com.fasterxml.jackson.databind.type.CollectionType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.CollectionType|withTypeHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.CollectionType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.CollectionType|withValueHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.CollectionType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "C|com.fasterxml.jackson.databind.type.CollectionType|<init>|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;,com.fasterxml.jackson.databind.JavaType,java.lang.Object,java.lang.Object,boolean",
    "M|com.fasterxml.jackson.databind.type.CollectionType|construct|java.lang.Class,com.fasterxml.jackson.databind.JavaType|static",
    "M|com.fasterxml.jackson.databind.type.CollectionType|construct|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;,com.fasterxml.jackson.databind.JavaType|static",
    "M|com.fasterxml.jackson.databind.type.MapType|construct|java.lang.Class,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JavaType|static",
    "M|com.fasterxml.jackson.databind.type.MapType|construct|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JavaType|static",
    "M|com.fasterxml.jackson.databind.type.SimpleType|_buildSuperClass|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings|static",
    "M|com.fasterxml.jackson.databind.type.SimpleType|construct|java.lang.Class|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
