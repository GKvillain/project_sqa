package com.fasterxml.jackson.databind.deser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class JdkDeserializers_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.JdkDeserializers:@?\0121=null\012",
        Z.run(T, 2, 1, 0, 1, "\udbba\udf2b\ud82d\udeeb\u3592\ud88f\udf00\udb59\udca8\ud864\udece\ud8cf\udc09", "\u5eee\uc86e\uc16d\ubcb7\u4d7c\u6956\u0147\u1a46\u22be\u466d\u5066\u0fca", "\ud92c\udef5\udb5a\ude37\ud9f8\ude52\ud83b\udf3e",
        48, 29356, 1570184046, 6014634534664832020L, 33024L, true, true, (char) 5749, (char) 62590,
        Double.longBitsToDouble(0x3f94eb0d90e6f360L), Double.longBitsToDouble(0x3fea37936ece3590L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.JdkDeserializers:@?\0121=null\012",
        Z.run(T, 2, 1, 0, 1, "\udbba\udf2b\uda0e\udf41\u3592\u66a1\udb59\udca8\ud864\udece\ud8cf\udc09", "\u5eee\uc86e\uc16d\ubcb7\u4d7c\u6956\u0147\u1a46\u22be\u466d\u5066\u0fca", "\uda0a\udcc4\udb6d\udcb1\ud9f8\ude52\ud83b\udf3e",
        48, 29356, 1570184046, 6014634534664832020L, 33024L, true, true, (char) 5749, (char) 62590,
        Double.longBitsToDouble(0x3f94eb0d90e6f360L), Double.longBitsToDouble(0x3fea37936ece3590L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.JdkDeserializers:@?\0121=new com.fasterxml.jackson.databind.deser.std.JdkDeserializers:@?\012",
        Z.run(T, 2, 1, 1, 1, "\udbba\udf2b\ud82d\udeeb\u3592\ud88f\udf00\udb59\udca8\ud864\udece\ud8cf\udc09", "\u5eee\uc86e\uc16d\ubcb7\u4d7c\u6956\u0147\u1a46\u9c99\uaa6f\ua8c4\u7aa1", "\ud92e\udfa1\udb5a\ude37\uda77\ude4f",
        46, 48123, 1656733356, 6743889440308081209L, 40698L, false, false, (char) 48520, (char) 5749,
        Double.longBitsToDouble(0x3fa95426014eb0d0L), Double.longBitsToDouble(0x3fc0e6f37d1bc9b4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.JdkDeserializers:@?\0121=null\012",
        Z.run(T, 2, 1, 0, 1, "\udbba\udf2b", "\u9aa1\u3856\ubc77", "\udbb7\udda6\udb63\ude45\udabb\udcfe\ud879\udfd1\uda31\udf95\ud977\udd59\udb6d\udf3e\ud90c\udf66\uda4f\udd31\udb31\udca8\ud819\udecd\ud882\udeb5\ud80c\udebd\udaa4\udc3d\ud871\uded8\ud92c\udef5\udb5a\ude37\ud9f8\ude52\ud83b\udf3e\ue7b3",
        28, 37046, 1400391230, 900302195651126682L, -73329L, true, true, (char) 43134, (char) 19234,
        Double.longBitsToDouble(0x3fc0e6f37d1bc9b4L), Double.longBitsToDouble(0x3fe671ac80c0e956L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 1, "\udbba\udf26\ud82d\udeeb\u3592\ud88f\udf00\udb59\udca8\ud864\udece\ud8cf\udc09", "\u5eee\uc86e\u52e6\uacd5\u4d7c\u6956\u0147\u1a46\u22be\u466d\u5066\u0fca", "\udbee\udd00\udb5a\ude37\ud9f8\ude52\ud83b\udf3e\ud843\udc97\udb15\udc7d\udbd0\udcf1\ud8ea\udf29",
        20, 44442, -353240992, -5004739637763286039L, 4419L, true, false, (char) 39347, (char) 52317,
        Double.longBitsToDouble(0x3fdc075b0da90f7aL), Double.longBitsToDouble(0x3fedc6ec61149e52L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.JdkDeserializers:@?\012",
        Z.run(T, 1, 1, 0, 1, "\udbba\udf2b\ud963\ude17\u3592\ud88f\udf00\udb59\udca8\ud864\udece\ud8cf\udc09", "\u5eee\u6578\u12d7\ubcb7\u408c\u6956\u0147\u1a46\u22be\u466d\u5066\u0fca", "\ud92c\udef5\udb5a\ude37",
        39, 74566, 1392435123, 7115615583782509422L, 23387L, false, false, (char) 50676, (char) 11595,
        Double.longBitsToDouble(0x3fea31f196ce3590L), Double.longBitsToDouble(0x3fdf4338807fc818L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.JdkDeserializers:@?\0121=new com.fasterxml.jackson.databind.deser.std.JdkDeserializers:@?\012",
        Z.run(T, 2, 1, 1, 1, "\udbba\udf2b\ud82d\udeeb\u3592\ud88f\udf00\udb59\udca8\ud864\udece\udb43\udde4", "\u5eee\uc86e\uc16d\ubcb7\u4d7c", "\uda4f\udd31\udb31\udca8\ud819\udecd\ud882\udeb5\ud80c\udebd\uda2f\udcc3\ud8a8\udde8\ud92c\udef5\udb5a\ude37\ud9f8\ude52\ud83b\udf3e\ud843\udc97",
        26, 37046, 1400391230, 900302195651126682L, -73329L, true, true, (char) 62590, (char) 19234,
        Double.longBitsToDouble(0x3fc0e6f37d1bc9b4L), Double.longBitsToDouble(0x3fe671ac80d29dbbL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.JdkDeserializers:@?\012",
        Z.run(T, 1, 1, 0, 1, "\udbba\udf2b\ud82d\udeeb\udbda\udc91\ud88f\udf00\udb59\udca8\ud864\udece\ud8cf\udc09", "\u36ee\uc86e\uc16d\ubcb7\u4d7c\u821f\u9cfa\u0877\ua8b9\u50b3\u5066\u0fca", "\ud936\udcd1\udbc2\udceb\ud9dc\udff8\ud83b\udf3e\ud843\udc97\udb15\udc7d\udbd0\udcf1\ud8ea\udf29\ud9db\udcd0\ud84c\udebb\ud961\udf90\ud9ec\ude9b\udb7f\udebd\udbda\udef5\udba6\udf5a\ud8e4\udfba",
        3, 41906, -1897614523, -8866557935253166621L, -64525L, false, false, (char) 64870, (char) 28885,
        Double.longBitsToDouble(0x3fe22f208de19618L), Double.longBitsToDouble(0x3fe90992a4efd660L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 0, "", "\000", "\000\000\000\udbb7\udd64\udb63\ude45\udabb\udcfe\ud879\udfd1\uda31\udf95\udb13\udf4d\udb6d\udf3e\ud916\udd32\uda4f\udd31\uda7e\udd9f\ud819\udecd\ud882\udeb5\ud80c\udebd\uda2f\udcc3",
        45, 29207, -651838334, -4525416111313919810L, -82018L, false, false, (char) 0, (char) 43690,
        Double.longBitsToDouble(0x3f4d5e2000000000L), Double.longBitsToDouble(0x3de4eb0000000000L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.JdkDeserializers:@?\0121=null\012",
        Z.run(T, 2, 1, 0, 1, "\udb3c\udc4c\ud82d\udeeb\u3592\ud8f8\ude04\udb59\udc50\ud864\udece\ud946\ude16", "\u5eee\uc86e\uc16d\ubcb7\u4d7c\u6956\u0147\u5419\u24f7\u1755\u5066\u0fca", "\ud92c\udef5\udb5a\ude37\ud9f8\ude52\ud83b\udf3e",
        48, 29356, 1570184046, 6014634535033930772L, 33024L, false, true, (char) 36089, (char) 62697,
        Double.longBitsToDouble(0x3f94eb0d90e6f360L), Double.longBitsToDouble(0x3fea37936ece3590L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.JdkDeserializers:@?\0121=null\012",
        Z.run(T, 2, 1, 0, 1, "\udbba\udf2b", "\u9aa1\u3856\ubc77", "\u4c03\udb63\ude45\udabb\udcfe\ud879\udfd1\uda31\udf95\ud977\udd59\udb6d\udf3e\ud90c\udf66\ud809\udd2e\udb31\udca8\ud819\udecd\ud882\udf3b\uac48\udaa4\udc3d\ud871\udf0d\ud92c\udef5\uda9b\udef8\ud9f8\udf14\ud83b\udf3e\u9780",
        17, 37046, 1400391230, 900302197706112410L, 97245L, false, false, (char) 11298, (char) 39347,
        Double.longBitsToDouble(0x3fe6706480c0e956L), Double.longBitsToDouble(0x3feb0b493ef4e46eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.std.JdkDeserializers|find|java.lang.Class,java.lang.String|static",
    "C|com.fasterxml.jackson.databind.deser.std.JdkDeserializers|<init>|",
    "M|com.fasterxml.jackson.databind.deser.std.JdkDeserializers|find|java.lang.Class,java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
