package com.fasterxml.jackson.databind.deser;
import org.junit.Test;
import static org.junit.Assert.*;
public class BeanDeserializerFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 10, "\uda78\udd69\udb79\udd1d\udbbe\ude27\ud930\udd97\udafb\udec9\uda10\udd00\udb4d\ude55", "\u311f\u0347\uc2d5\u635e", "\uda2a\udce6\udbd6\udd7c\uda51\udebc\uda4b\udc3a\uda5f\udea3\uda99\udca3",
        28, 68118, 1699698772, -2497982450810171935L, 40193L, false, true, (char) 33660, (char) 38274,
        Double.longBitsToDouble(0x3fd7521a9c5f1956L), Double.longBitsToDouble(0x3febc3ebcc105a7aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 9, 3, "\uf46b\udb79\udd08\udbbe\ude27\ud930\udd97\udafb\udec9\uda10\udd00\udb4d\ude55\u0fcb\udb36\ude9d\udabf\udc6a\uda77\udfd8\uda76\udf1d\udb0f\udea6", "\u0c78\u2c54\u6756\u8205\u2617\u7203", "\ud989\ude4c\u0827\uda7d\udef8\ud83e\udd94\ud841\udcc2\udb9a\ude07\ud827\uded7\udb44\udfe3\ud81c\udea9\udbed\udd93\udb5e\udd8d\ud803\udea8\uda34\udf65\ud89c\udf05\udbb1\udcfa\uda57\ude69\ud844\udffe\ud94d\udc7d",
        2, 64630, 966534231, -746972475226659543L, -77654L, false, true, (char) 12460, (char) 44268,
        Double.longBitsToDouble(0x3fc94ed4fba376ecL), Double.longBitsToDouble(0x3fe60c49e6705db4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 10, "\uda78\udd69\udb79\udd1d\udbbe\ude27\ud930\udd97\udafb\udec9\uda10\udd00\udb4d\ude55", "\u311f\u0347\uc2d5\u635e", "\uda2a\udce6\udbd6\udd7c\uda51\udebc\uda4b\udc3a\uda5f\udea3\uda99\udca3",
        28, 68118, 84, -2498090417698058783L, 40193L, false, true, (char) 33660, (char) 38274,
        Double.longBitsToDouble(0x3fd7521a9c5f1956L), Double.longBitsToDouble(0x3febc3ebcc105a7aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 10, "\uda78\udd69\udb79\udd1d\udbbe\ude27\ud930\udd97\udafb\udec9\ud94c\udcfe\udb4d\ude55", "\u311f\u0347\uc2d5\u635e", "\uda2a\udce6\udbd6\udd7c\uda51\udebc\uda4b\udc3a\uda5f\udea3\uda99\udca3",
        28, 60024, 889600580, 7238750950872892844L, 60610L, false, true, (char) 33660, (char) 17594,
        Double.longBitsToDouble(0x3fd756eaec5f1956L), Double.longBitsToDouble(0x3febc3ebcc105a7aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 10, "\uda78\udd69\udb37\udfbb\udad1\ude77\ud892\udc72\ud953\uddfd\uda10\udd00\udbfd\udd6c", "\u642c\ud5a5\uc2d5\u635e", "\uda2a\udce6\uda22\udf97\uda51\udf1c\uda4b\udc3a\uda5f\udea3",
        57, 40004, 819494470, -4994809991009056779L, 4641L, true, true, (char) 19482, (char) 6487,
        Double.longBitsToDouble(0x3fd6713613446090L), Double.longBitsToDouble(0x3fe17c655f787d79L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 10, "\uda78\udd69\udb79\udd2a\udbbe\ude27", "\u5dbb\u71b3\u73ed\u8eb3", "\uda76\udf1d\udb0f\udea6\udb1f\udc54\udb91\udc82\uda2a\udce6\udbd6\udd7c\uda51\udebc",
        0, 46736, -158280398, 4853579967970543563L, -9326L, true, true, (char) 48396, (char) 20706,
        Double.longBitsToDouble(0x3fda406761fa94feL), Double.longBitsToDouble(0x3fcd0c7345d486a4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 6, 3, "\ud9a4\udefe\udb34\udc01\udbec\udf1e\ud8e8\udfd4\udafb\udec9\uda10\udd00\ud8ef\udf39", "\u2e60\u1468\uc2d5\ud519\u2f46\u42fb\u8014\u05ec\u577c\u4d4b\u2617\u7203\u8c74\u5904\u3754\ua13c\uc0e6\u4664\ubc3a\u33ee\u8f09\u21cd\ua0c4\u8ae5\u82b4\u6003\u37bb\u48b4\u18bf\uccec\u98af\u148c\ucb55\u4d65\u9f4b\u028f\u2eda\uc158\u5f81\u4888\u71ed\u6d9c", "\udb55\udcc0\ud887\ude65\uda79\udc7d\udaa9\udff4\ud9f0\udfdc",
        5, 61015, -423049911, 4725228383710245394L, 46476L, true, false, (char) 57034, (char) 4587,
        Double.longBitsToDouble(0x3fea5cef08ae6c31L), Double.longBitsToDouble(0x3fa291d97a657d00L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 6, 10, "\uda78\udd69\udb79\udd1d\udbbe\ude27\ud930\udd97\udbf2\ude83\uda10\udca0\udb4d\ude55", "\u31dd\u034b\u7871\u044e", "\ud8c8\udf9f",
        29, 86778, -950342143, -4979842497710598862L, -25554L, false, true, (char) 19247, (char) 43830,
        Double.longBitsToDouble(0x3fdc1244c7425a72L), Double.longBitsToDouble(0x3fda40676d2ba1d8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 14, 5, 10, "\uda78\udd69\udb79\udd1d\udbbe\ude27\ud930\udd97\udafb\udec9\uda10\udd00\udb4d\ude55\ud868\ude9b\udb36\ude9d\udabf\udc6a\uda77\udfd8\uda76\udf1d\udb0f\udea6\udb1f\udc54\udb91\udc82\uda2a\udce6\udbd6\udd7c\uda51\udebc\ud825\udd07\uda5f\udea3\ud9a1\udca7\uda43\udefd\ud889\udd86\ud989\ude4c\u0827\uda7c\udc04\udafc\udd6b\ud965\udd4d\udabb\udce8\udbc0\udc88", "\u8ae5\u08e1\u6986\u3783\ua628\u2090", "\ud8bc\udd34\ud9e3\udd92\ud841\udcdd\uda0e\ude2d\uda38\udf5c\ud8a2\udfdc\udac7\udf1d\ud95c\ude06\udb24\udd70\udb62\udfa6\u2988",
        57, 91026, -2001845860, -4212529864157694730L, 18717L, true, false, (char) 3039, (char) 20253,
        Double.longBitsToDouble(0x3fe728b256325b8bL), Double.longBitsToDouble(0x3fc019f492dd9bb8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 5, "\uda78\udd69\uda20\udf30\ud90a\udf45\ud930\udd97\udafb\udec9\udb84\udf1b\udbba\udf01\ud868\ude9b\udb36\ude9d\udabf\udc6a", "\u635e\u3fde\u6847", "\uda51\udebc\uda4b\udc3a\uda5f\udea3\uda99\udca3",
        28, 68118, 1699698772, -2497982450810171935L, 40193L, false, true, (char) 33660, (char) 38274,
        Double.longBitsToDouble(0x3fd7521a9c5f1956L), Double.longBitsToDouble(0x3febc3ebcc105a7aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 10, "\uda78\udd69\udb79\udd1d\udbbe\ude27\ud930\udd97\udafb\udec9\uda10\udd00\udb4d\ude55", "\u311f\u0347\u1653\u635e", "\uda2a\udce6\udbd6\udd7c\uda51\udebc\uda4b\udc3a\uda5f\udea3\udb2f\udf20\ud88b\udd3c\udb7e\udd83\ud989\ude4c\udb08\ude09\uda7b\udf45\udafc\udf6b\udbbe\ude1b\udbae\udd6f\uda8d\udedb\udaf6\udefd\udbba\udc20\udbed\udd93\udaa8\uddd5\ud9cf\udf7a\uda6f\udd87",
        6, 74674, -828027833, 5996533814624657610L, 29093L, true, true, (char) 40203, (char) 47637,
        Double.longBitsToDouble(0x3fbd804ac1c9ca88L), Double.longBitsToDouble(0x3fe1c7dfd469ebbfL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 10, "\uda78\udd69\udb79\udd1d\udbbe\ude27\ud930\udd97\udafb\udec9\uda10\udd00\udb4d\ude55", "\u311f\u0347\uc2d5\u635e", "\uda2a\udd33\udbd6\udd7c\uda51\udebc\uda4b\udc3a\uda5f\udea3\uda99\udca3\ud88b\udd3c",
        23, 69772, -581606862, 2615691850606024897L, -77171L, false, true, (char) 51903, (char) 43950,
        Double.longBitsToDouble(0x3fd54f859a8134ceL), Double.longBitsToDouble(0x3fdd00324b768ff0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addBeanProps|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addInjectables|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addObjectIdReader|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addReferenceProperties|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|buildBeanDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|buildBuilderBasedDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|buildThrowableDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|checkIllegalTypes|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|constructAnySetter|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.AnnotatedMember|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|constructBeanDeserializerBuilder|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|constructSettableProperty|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|constructSetterlessProperty|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|createBeanDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|createBuilderBasedDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription,java.lang.Class|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|filterBeanProps|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder,java.util.List,java.util.Set|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|findStdDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addBeanProps|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
