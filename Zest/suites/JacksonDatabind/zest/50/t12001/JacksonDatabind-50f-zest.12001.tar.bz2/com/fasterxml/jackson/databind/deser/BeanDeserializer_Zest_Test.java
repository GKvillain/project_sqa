package com.fasterxml.jackson.databind.deser;
import org.junit.Test;
import static org.junit.Assert.*;
public class BeanDeserializer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 7, 1, "\ud9dc\udcc1\ud8ff\uddcf\ud98f\udc7a\uda54\udf9f\ud894\udeaf\ud80a\udecd\uda49\udf45\ud9b4\udf47\udaff\udf06\udb7e\udc44\ud8f7\uddc8\udbfc\udebe\ud99e\ude93\udb59\udf43\udad6\ude9c\udad0\udda2\ud882\ude40", "\u9c6b\u7a9a\u1b1e\u2c19\u555b\u7a65\u0df6", "\udb5e\udff2\ud93d\ude3b\uda43\udeab\udaf3\ude66\udb8f\udebc",
        41, 77129, 1886617106, 2766463532167637138L, -61032L, true, false, (char) 21131, (char) 46289,
        Double.longBitsToDouble(0x3fa6fba825843160L), Double.longBitsToDouble(0x3fef9656a30d34dbL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 7, 1, "\ud9dc\udcc1\ud8e9\uddcf\ud98f\udc7a\uda54\udf9f\ud894\udeaf\ud80a\udecd\uda49\udf45\ud9b4\udf47\udaff\udf06\udb7e\udc44\ud8f7\uddc8\udbfc\udebe\ud99e\ude93\udb59\udf43\udad6\ude9c\udad0\udda2\ud882\ude40", "\u9c6b\uc9fc\u1b1e\u2c19\u555b\u7a65\u0df6", "\udb5e\udff2\ud93d\ude3b",
        45, 86657, -1382409320, 4519328693527941457L, -70323L, false, false, (char) 14926, (char) 63389,
        Double.longBitsToDouble(0x3fe4edbb19c288c9L), Double.longBitsToDouble(0x3fe274741c2df750L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 7, 1, "\ud9dc\udcc1\ud8ff\uddcf\ud98f\udc7a\uda54\udf9f\ud894\udeaf\ud80a\udecd\uda49\udf45\ud9b4\udf47\udaff\udf06\udb7e\udc44\ud8f7\uddc8\udbfc\udebe\ud99e\ude93\udb59\udf43\udad6\ude9c\udad0\udda2\ud882\ude40", "\u9c6b\u7a9a\u1b1e", "\udb2b\udcac\udacf\udeeb\uda8a\udf84\uda0e\udeee\udb5e\udff2\ud928\ude3b\uda43\udeab\udaf3\ude66\udb8f\udebc\ud880\ude33\ud939\udc7b\ud9e3\udcb2\ud8a5\ude30\ud913\ude26\udb1c\udcc4\uda0a\udf80\ud9e0\udf96\udb90\udf11",
        22, 6149, 1003758168, 4267826299677533162L, 46136L, false, false, (char) 15459, (char) 14816,
        Double.longBitsToDouble(0x3fe5319928f68713L), Double.longBitsToDouble(0x3fea411b6eaa51a8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 11, 1, "\ud9dc\udcc1\ud8ff\uddcf\ud98f\udc7a\uda54\udf9f\ud894\udeaf\ud80a\udecd\uda49\udf45\ud9b4\udf47\udaff\udf06\udb7e\udc44\ud8f7\uddc8\udbfc\udebe\ud99e\ude93\udb59\udf43\udad6\ude9c\udad0\udda2\ud882\ude40", "\u9c6b\u7a9a\u1b1e\u2c19\u209d\u4947\u8f04", "\udb5e\udff2\ud93d\ude3b\u66f7\udaf3\ude6d\udb8f\udebc",
        41, 82569, 786542479, 2738458227978840210L, -61032L, true, false, (char) 21131, (char) 46289,
        Double.longBitsToDouble(0x3fa6c52825843160L), Double.longBitsToDouble(0x3fef9656a30d34dbL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 1, "\udada\udfe2\ud8ff\uddcf\ud98f\udc7a\uda54\udf9f\ud894\udeaf\ud80a\udecd\uda49\udf45\uda88\ude58\udb15\udcd3", "\u5bff\u9ddb\u8f9b\u47df\u17f2\u1b6c\u270f\u8598\u9c6b\u7a9a\u43df\u2c19\u555b\u7a65\u0df6\u319b\u43fe\u7bdd\u8cf5\uc738\u60bf\u51ef\ud0d5\ud015\u1b59\ua16d\u1fe3\u2a70\u91b8\u7552\u1b41\u3c02\u53b0\u1b53\u0e98\ucca6", "\udbfa\uddd1\udb79\ude67",
        18, 47563, -1089621610, 7910652241912553602L, -99722L, false, false, (char) 51746, (char) 5786,
        Double.longBitsToDouble(0x3fddb6b2604a1166L), Double.longBitsToDouble(0x3fe55ad1ab27b2f5L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 6, 1, "\udbe7\udfc4\ud91d\udf5c\uba46\udbb6\ude7f\uda68\udd24\ud98f\udc1e\ud8ee\udd52\ud9b5\udd47\udaff\udf06\udb7e\udc44\ud8f7\uddc8\udbfc\udebe\ud99e\ude93\udb59\udf43\udad6\ude9c\uda96\uddc4\ud882\ude40", "\u9c6b\u7a9a\u1b1e\u2c19\u555b\u7a65\u0df6", "\udb5e\udff2",
        0, 93740, 273292657, -5937402818033391999L, -66738L, true, true, (char) 8552, (char) 43238,
        Double.longBitsToDouble(0x3fee447eaa9db763L), Double.longBitsToDouble(0x3fdc288c9c9d1d06L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 7, 1, "\ud9dc\udcc1\udb89\udc30\udad0\ude43\uda54\udf9f\ud894\udeaf\ud80a\udecd\uda49\udf45\ud9b4\udf47\udaff\udf06\udb7e\udc44\ud8f7\uddc8\ud846\udf83\ud99e\uddd4\udb59\udf43\udad6\ude9c\udad0\udda2\ud882\ude40", "\u9c6b\u7a9a\u1b1e\u2c19\u555b\u7a65\u0df6", "\udb5e\udff2\ud93d\ude3b\uda43\udeab\udaf3\ude66\udb8f\udebc",
        41, 77129, 675166482, 2766463532167637138L, -61032L, true, false, (char) 21131, (char) 46289,
        Double.longBitsToDouble(0x3fa6fba825843160L), Double.longBitsToDouble(0x3fef9656a30d34dbL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|_deserializeUsingPropertyBased|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|handleUnresolvedReference|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.deser.SettableBeanProperty,com.fasterxml.jackson.databind.deser.impl.PropertyValueBuffer,com.fasterxml.jackson.databind.deser.UnresolvedForwardReference|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|_creatorReturnedNullException||new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|_deserializeOther|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.core.JsonToken|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|_deserializeWithErrorWrapping|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.deser.SettableBeanProperty|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|_missingToken|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|asArrayDeserializer||new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|deserializeFromNull|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|deserializeFromObject|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|deserializeUsingPropertyBasedWithExternalTypeId|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|deserializeUsingPropertyBasedWithUnwrapped|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|deserializeWithExternalTypeId|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|deserializeWithExternalTypeId|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|deserializeWithUnwrapped|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|_deserializeUsingPropertyBased|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializer|handleUnresolvedReference|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.deser.SettableBeanProperty,com.fasterxml.jackson.databind.deser.impl.PropertyValueBuffer,com.fasterxml.jackson.databind.deser.UnresolvedForwardReference|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
