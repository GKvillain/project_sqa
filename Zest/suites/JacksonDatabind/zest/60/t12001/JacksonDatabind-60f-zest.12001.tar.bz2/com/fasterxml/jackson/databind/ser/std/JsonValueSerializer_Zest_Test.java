package com.fasterxml.jackson.databind.ser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class JsonValueSerializer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 3, 9, "\ud9ba\udf4d\ud9f2\ude7d", "\u211d\uc9cb\u7e3d\u3120\u31a4\u1df3\u409e", "\udb95\udda7\udb51\udc23\uda11\udd22\udb89\udfee\udb42\udfec",
        41, 53824, 1258576165, -8080042600988374079L, 9734L, false, false, (char) 19727, (char) 62668,
        Double.longBitsToDouble(0x3fe25fb56294d936L), Double.longBitsToDouble(0x3fee82c51ed43854L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 7, 0, "\ud8ef\udc06\udb61\ude33", "\u55b9\u42b7\u4a94", "\ud8b3\udd93\ud987\udfb9",
        33, 79579, 1001859698, 3247173984456965962L, 25968L, true, false, (char) 59150, (char) 13487,
        Double.longBitsToDouble(0x3fa229bf65ee6b00L), Double.longBitsToDouble(0x3fd9a4110497559cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 10, 9, "\ud990\ude98\udb60\uddfe", "\u211d\u186a\u75e7\u3120\u31a4\u1df3\u409e\u8e58", "\udb51\udc23\udb48\ude9e\udb89\udfee\ud8b5\udfeb\ud83a\udc35\udabb\udfc7",
        10, 44480, -552563775, -2209923829380290726L, -8427L, false, false, (char) 39027, (char) 44840,
        Double.longBitsToDouble(0x3fd401adf5c1363eL), Double.longBitsToDouble(0x3fd91b8929d7e742L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 3, 9, "\udbde\udf3f\ud9d3\udca9", "\u211d\uc9cb\u7e3d\u3120\u31a4\u1df3\u409e", "\udb95\udda7\udb51\udc23\uda11\udd22\udb89\udfee\udb42\udfec",
        41, 53824, 1258576165, -8080042600988374079L, 9734L, false, false, (char) 19727, (char) 62668,
        Double.longBitsToDouble(0x3fc31ed58a536478L), Double.longBitsToDouble(0x3fee82c51ed43854L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 1, 9, "\ud9ba\udf4d\ud9f2\ude7d", "\u211d\uc9cb\u7e3d\u3120\ub4ab\u1df3\u409e", "\udb95\udda7\udb51\udc23\uda11\udd22\udb89\udfee\udb42\udfec",
        41, 53824, 1258576165, -8080042600988374079L, 9734L, false, false, (char) 19727, (char) 62668,
        Double.longBitsToDouble(0x3fe25fb56294d936L), Double.longBitsToDouble(0x3fe682c51ed43854L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object\012",
        Z.run(T, 1, 2, 3, 6, "\ud8e0\udf4d\ud9f2\ude7d", "\u211d\u1afc\ubea2\u67a0\u31a4\u1df6\u559a", "\ud82d\udd05\udb43\udee8\uda11\uddb4\udb89\udfee\udb42\udfec",
        41, 53824, 1258576165, -8080042600988374079L, 9734L, false, false, (char) 19726, (char) 19405,
        Double.longBitsToDouble(0x3fe1f236052e6504L), Double.longBitsToDouble(0x3fd84f178da87072L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 3, 9, "\ud9ba\udf4d\ud9f2\ude7d", "\u211d\uc9cb\u7e3d\u3120\u31a4\u1df3\u409e", "\udb95\udda7\udb51\udc23\uda11\udd22\udb89\udfee\udb42\udfec",
        41, 53824, 1258576165, -8080042601793680447L, 70797L, false, false, (char) 19727, (char) 62668,
        Double.longBitsToDouble(0x3fe25fb56294d936L), Double.longBitsToDouble(0x3fee82c51ed43854L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.Date\012",
        Z.run(T, 1, 2, 7, 9, "\ud815\udea3\ud8d0\udfc9\ud98a\udd8d\uda32\udfa6\udbb0\udd6a\udbe1\udd5f\ud9a1\udd36\udb3c\uddbb\udae8\udc56\uda43\udcd0\udb62\udfeb\ud974\ude3e\ud828\udf4e\udbc9\udd50", "\u3443\u7639\u4821\u291f\u1a0e\u6b12", "\udbe7\udf34\ud949\ude6a\udbbb\udc34\uda47\udf6a\ud8a7\udfaa\ud985\uddbe\ud9ad\ude19",
        24, 84972, 2017782761, -2626586294740206250L, 52695L, true, false, (char) 60072, (char) 2601,
        Double.longBitsToDouble(0x3fe6ed5a6e2601b6L), Double.longBitsToDouble(0x3fe1b8f1da30cadbL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.List\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 6, "\ud8f3\ude35\ud9f0\udd51", "\u211d\u4a09\ubea2\u9473\u31a4\ubcc6\u8469", "\ud971\udd07\udb43\udee8\uda11\uddb4\udb59\udd0e\udb10\ude06\uda2f\udfae\udb3e\udd6e\ud99f\ude9d\ud903\uddef\udaaa\udd84\udb49\udffa\uda6e\udc3c\udb81\udf1c\ud94d\udc16\ud993\udee8",
        18, 44982, 943300996, 2266567164173524639L, -87627L, false, true, (char) 29075, (char) 60319,
        Double.longBitsToDouble(0x3faf4faa6f7cea80L), Double.longBitsToDouble(0x3fe272162ab8201bL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 3, 9, "\ud9ba\udf4d\ud9f2\ude7d", "\u211d\uc9cb\u7e3d\u3120\u31a4\u1df3\u409e", "\udb95\udda7\udb51\udc23\uda11\udd22\uda24\udf59\ud81c\udcfb",
        41, 53824, 1258576165, -8080042600988374079L, -86945L, true, false, (char) 38710, (char) 22501,
        Double.longBitsToDouble(0x3fda74e33c2db6b4L), Double.longBitsToDouble(0x3fe62ed5a2bf22b7L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Class:int\0121=java.lang.Class:int\012",
        Z.run(T, 2, 2, 2, 9, "\ud815\udea3\udbc1\udc41\ud98a\udd0a\uda32\udfa6\ud8a3\udca2\udb37\udc51\ud8e9\udc22\uda4b\udcd1\udad3\udf7a", "\u8b86\ua381\ub3a1\u809c\u0e7d\u7bf4\u7593\u4821\u291f\u42a5\ua9c7\u871a\ua29c\u2b20\u9988\u3db1\ua8d2\u6e54\u6705\u8fd9\u0239\u32da", "\u031e",
        2, 20097, -580500120, -6291452921930810163L, 29152L, false, false, (char) 20253, (char) 44939,
        Double.longBitsToDouble(0x3fc01ee64e5eda58L), Double.longBitsToDouble(0x3fceda90d592f9f8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object\0121=java.lang.Class:java.lang.Object\012",
        Z.run(T, 2, 2, 2, 9, "\ud815\udea3\udbc1\udc41\ud98a\udd0a\uda32\udfa6\ud8a3\udca2\udb37\udc51\ud8e9\udc22\uda4b\udcd1\udad3\udf7a", "\u8b86\ua381\ub3a1\u809c\u0e7d\u7bf4\u7593\u4821\u291f\u42a5", "\uebab\udbde\udcfa\ud949\ude6a\udbbb\udc34\uda47\udf6a\ud8a7\udfaa\ud927\uddca\ud9ad\ude19\ud8d2\udc40\ud80d\udfcd\ud983\udebe",
        31, 58038, -964813388, -8896109509592596752L, 29152L, false, false, (char) 20253, (char) 44939,
        Double.longBitsToDouble(0x3fc01ee64e5eda58L), Double.longBitsToDouble(0x3fceda90d592f9f8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ser.std.JsonValueSerializer|serializeWithType|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.jsontype.TypeSerializer|new:com.fasterxml.jackson.databind.ser.std.JsonValueSerializer:com.fasterxml.jackson.databind.introspect.AnnotatedMethod,com.fasterxml.jackson.databind.JsonSerializer",
    "M|com.fasterxml.jackson.databind.ser.std.JsonValueSerializer|_acceptJsonFormatVisitorForEnum|com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper,com.fasterxml.jackson.databind.JavaType,java.lang.Class|new:com.fasterxml.jackson.databind.ser.std.JsonValueSerializer:com.fasterxml.jackson.databind.introspect.AnnotatedMethod,com.fasterxml.jackson.databind.JsonSerializer",
    "M|com.fasterxml.jackson.databind.ser.std.JsonValueSerializer|_notNullClass|java.lang.Class|static",
    "M|com.fasterxml.jackson.databind.ser.std.JsonValueSerializer|acceptJsonFormatVisitor|com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ser.std.JsonValueSerializer:com.fasterxml.jackson.databind.introspect.AnnotatedMethod,com.fasterxml.jackson.databind.JsonSerializer",
    "M|com.fasterxml.jackson.databind.ser.std.JsonValueSerializer|createContextual|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty|new:com.fasterxml.jackson.databind.ser.std.JsonValueSerializer:com.fasterxml.jackson.databind.introspect.AnnotatedMethod,com.fasterxml.jackson.databind.JsonSerializer",
    "M|com.fasterxml.jackson.databind.ser.std.JsonValueSerializer|getSchema|com.fasterxml.jackson.databind.SerializerProvider,java.lang.reflect.Type|new:com.fasterxml.jackson.databind.ser.std.JsonValueSerializer:com.fasterxml.jackson.databind.introspect.AnnotatedMethod,com.fasterxml.jackson.databind.JsonSerializer",
    "M|com.fasterxml.jackson.databind.ser.std.JsonValueSerializer|isNaturalTypeWithStdHandling|java.lang.Class,com.fasterxml.jackson.databind.JsonSerializer|new:com.fasterxml.jackson.databind.ser.std.JsonValueSerializer:com.fasterxml.jackson.databind.introspect.AnnotatedMethod,com.fasterxml.jackson.databind.JsonSerializer",
    "M|com.fasterxml.jackson.databind.ser.std.JsonValueSerializer|serialize|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.std.JsonValueSerializer:com.fasterxml.jackson.databind.introspect.AnnotatedMethod,com.fasterxml.jackson.databind.JsonSerializer",
    "M|com.fasterxml.jackson.databind.ser.std.JsonValueSerializer|toString||new:com.fasterxml.jackson.databind.ser.std.JsonValueSerializer:com.fasterxml.jackson.databind.introspect.AnnotatedMethod,com.fasterxml.jackson.databind.JsonSerializer",
    "M|com.fasterxml.jackson.databind.ser.std.JsonValueSerializer|withResolved|com.fasterxml.jackson.databind.BeanProperty,com.fasterxml.jackson.databind.JsonSerializer,boolean|new:com.fasterxml.jackson.databind.ser.std.JsonValueSerializer:com.fasterxml.jackson.databind.introspect.AnnotatedMethod,com.fasterxml.jackson.databind.JsonSerializer",
    "C|com.fasterxml.jackson.databind.ser.std.JsonValueSerializer|<init>|com.fasterxml.jackson.databind.introspect.AnnotatedMethod,com.fasterxml.jackson.databind.JsonSerializer",
    "C|com.fasterxml.jackson.databind.ser.std.JsonValueSerializer|<init>|com.fasterxml.jackson.databind.ser.std.JsonValueSerializer,com.fasterxml.jackson.databind.BeanProperty,com.fasterxml.jackson.databind.JsonSerializer,boolean",
    "M|com.fasterxml.jackson.databind.ser.std.JsonValueSerializer|serializeWithType|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.jsontype.TypeSerializer|new:com.fasterxml.jackson.databind.ser.std.JsonValueSerializer:com.fasterxml.jackson.databind.introspect.AnnotatedMethod,com.fasterxml.jackson.databind.JsonSerializer",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
