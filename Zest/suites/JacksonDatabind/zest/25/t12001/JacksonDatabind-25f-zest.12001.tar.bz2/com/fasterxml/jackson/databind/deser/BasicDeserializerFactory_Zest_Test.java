package com.fasterxml.jackson.databind.deser;
import org.junit.Test;
import static org.junit.Assert.*;
public class BasicDeserializerFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 10, 8, "\ud8a7\uddf7\uda0d\ude61\ud9aa\udedd\udb09\udf07\udb43\udf9b", "\u5c36\ub79f\u7a14\ub53e\uc32d\u5cbb\u5cec\u795e\ub86a\ub23a\u894f\uc0ee\u8b5a\ubb41", "\ud947\udc27\ud952\udc01\ud872\udedf\udb21\udd0d\udab3\udfea\udba8\ude69\udae9\udf34\udb69\udff6\ud873\ude5f\udaa2\ude5f",
        11, 84071, -287693538, 1341410441151149802L, -14221L, false, true, (char) 60868, (char) 25066,
        Double.longBitsToDouble(0x3fec6c1cb5a41c41L), Double.longBitsToDouble(0x3fe34a4bef31c2bcL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 10, 8, "\ud8a7\uddf7\uda0d\ude61/\000\udb43\udee9", "\u5c36\ub79f\u6aab\000\000\u5bb3\u5cec\u795e\ub86a\ub23a\u894f\uc0ee\u8b5a\ubb41", "\ud947\udc27\ud952\udc01\ud872\udedf\udb21\udd0d\udab3\udfea\udba8\ude69\udae9\udf34\udb69\udff6\ud873\ude5f\udaa2\ude5f",
        11, 59391, -287703010, 1341410441151149802L, -14240L, false, true, (char) 60864, (char) 25066,
        Double.longBitsToDouble(0x3fec6c1cb5a41c41L), Double.longBitsToDouble(0x3fe34a4bef31c2bcL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 10, 8, "\uda84\uddc2\uda0d\ude61\ud9aa\udedd\ud8c7\udce2\udb3e\ude9b\ud981\udfab\udbec\ude28\udb78\udf38\udb02\udeb0\uda9b\ude4f\ud802\ude82\u0d00\ud863\uddfc\uda8c\udcbf\ud80a\udce0\udb60\udf33\ud968\udd04", "\u8b5a\ubb41\u6f83\ua3dc\u4071\uc10e\u80a3\u07a5", "\udae9\udf34\udb69\udff6\udb33\udee0\ud9b2\udcdd\ud926\udd6a\ud983\uddf5\u8b6a\udb10\ude49\ud9b7\udd35\ud9ba\udff6\udb3a\udc65\udb53\udecd\ud8c0\udc59\ud80e\udc2d\ud912\udf37",
        -1, 44597, -2129837918, 5787971139128185293L, 27147L, true, false, (char) 52519, (char) 48287,
        Double.longBitsToDouble(0x3fca3e4deecb0720L), Double.longBitsToDouble(0x3fe22dfa219cdea9L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 1, 13, 11, 8, "\000\uda0d\ude13\ud9aa\udedd\udb09\udf07\udb43\udf9b", "\u5c36\ub79f\u7a14\ub53e\000\u5cb4\u5cec\u795e\ub86a\ub23a\u1b62\uc0ee\u8b5a\ubb41", "\ud947\udc27\ud952\udc01\ud872\udedfz\000\000\000",
        31, 38418, 0, 0L, 54192L, false, false, (char) 0, (char) 39443,
        Double.longBitsToDouble(0x3fe950b3a800b604L), Double.longBitsToDouble(0x3fe80000078d8396L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 1, 12, 10, 8, "\ud913\udf48\uda0d\udeda\ud9aa\udedd\udb09\udf07\udb43\udf9b", "\u5c36\ub79f\u7a14\ub53e\uc32d\u5cbb\u5cec\u795e\ub86a\ub23a\u894f\u32b6\u8b5a\ubb41", "\ud947\udc27\ud952\udc01\ud872\udedf\udb21\udd0d\ud8b8\udc16\udba8\udde5\udae9\udf34\udb69\udff6\ud873\ude5f\udaa2\ude5f",
        11, 94783, -1363880197, 1341410441151149802L, -14221L, false, false, (char) 60868, (char) 20349,
        Double.longBitsToDouble(0x3fe69e3d15a41c41L), Double.longBitsToDouble(0x3fe34a4bee31c2bcL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 10, 8, "\ud8a7\uddf7\uda0d\ude61\ud9aa\udedd\udb09\udf07\udb43\udf9b", "\u5c36\ub052\u116b\ub53e\uc32d\u5cbb", "\udb60\udf33\uf63e",
        11, 63810, -1146395561, -711789782714446571L, -90111L, true, true, (char) 28721, (char) 34881,
        Double.longBitsToDouble(0x3fe422f51fb617c6L), Double.longBitsToDouble(0x3fe6816ee6d24a8dL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 11, 8, "\ud8a7\ude8a\uda0d\ude61\ud9aa\udedd\udb09\udf07\udb43\udf9b", "\u5c36\ub79f\u7a14\ub53e\u0cb1\u915b\u5cec\u795e", "\ud903\udfb7\udba8\ude4f",
        9, 13527, -1098019563, -1636070112455304865L, -93859L, false, true, (char) 62758, (char) 6012,
        Double.longBitsToDouble(0x3fe6816ee6d24a8dL), Double.longBitsToDouble(0x3fdfa8ba97ea9528L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 1, 15, 10, 8, "\ud8a7\uddf7\uda0d\ude61\ud85f\uddb9\udb09\udf07\udb43\udf9b", "\u5bd6\ub79f\u7a14\ub53e\uc32d\u5cbb\u5cec\u795e\ub86a\ub23a\u894f\uc0ee\u8b5a\ubb41", "\ud947\udc27\udbbd\uddd6\udb49\udd4d\ud864\udebc\udabf\uddc5\udba8\ude69\udae9\udf34\udb69\udff6\ud873\ude5f\udaa2\ude5f",
        11, 84071, -287693538, 1341410441151149802L, -14221L, false, true, (char) 61075, (char) 25066,
        Double.longBitsToDouble(0x3fec6c1cb5a41c41L), Double.longBitsToDouble(0x3fe34a4bef31c2bcL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 7, 8, "\ud86a\udc38\udb21\udc42\ud9aa\udf28\udb09\udf07\udb43\udf9b\ud998\udf16\udbec\ude28\udb78\udf38\ud970\udce8\udac8\udf8f\ud802\ude82\udafd\udd2e\udaa6\udc22\uda8c\udcbf\ud80a\udce0\udb60\udf33\uf63e\ud9bc\uddb4\ud96d\udc0d\ud84c\udc50\udbe3\ude61\uda6c\udeb1\ud97d\udf5e\ud94b\ude9b\ud8ff\ude6a\ud86d\udef1\udb21\udce5\udab3\udfea\udb8b\ude69\udae9\udf34\udb69\udff6\ud873\ude5f\udbf4\udc07\udba6\udee1", "\u0d49", "\udb3a\udc65\udb53\udecd\ud8c0\udc59\ud80e\udc2d\ud9db\udc59\udaf8\udc9e\u7e08\ud8b3\udf28\uda28\ude21\uda40\udc97\ud808\udcf5\udadb\udf53",
        0, 39229, 1195573228, 7473390368233735798L, -10325L, false, false, (char) 55238, (char) 519,
        Double.longBitsToDouble(0x3fe17d75d78473feL), Double.longBitsToDouble(0x3fd5503b846a0a40L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 1, 14, 3, 11, "\ud8a7\uddf7\uda0d\ude61\udbed\ude8c\ud0ba", "\uc8c1\u5c36\ub7f9\u7a14\ubf4a\u993a\u5cbb\ua7ad\u4b08\u877c\u9f7b\u8907\uc0ee\u8b5a\u8f99\u6504\ud74b\u3e62\uc10e\u80a3\u07a5\u52be\ud659\u598e\u1319\u1d90", "\ud8be\udce8\ud905\udc1b\udb5b\udec8\ud9b7\udd35",
        39, 79035, -1323383885, 1197663881928662381L, 83162L, true, false, (char) 25627, (char) 13023,
        Double.longBitsToDouble(0x3fe4c0f58768936bL), Double.longBitsToDouble(0x3fe29565b45c0511L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 1, 11, 10, 8, "\ud8a7\uddf7\uda21\udc61\ud9aa\udedd\ud9d2\udfd2\udb33\udcc8", "\u5c36\ub79f\ucea3", "\ud838\udd9d\udbc9\udd5f\u927a\udb60\udf33\uf63e\ud903\udfb7\udba8\ude4f\ud84c\udc50\ud3de\uda56\udd93\ud9b4\udd90\uda93\udd0c\ud92f\udd6f\ud872\udedf\udb21\udd0d\udab3\udfea\udba8\ude69\udae9\udf34\udb69\udff6",
        -5, 18693, 1766638591, -2592407595472247522L, -14221L, false, true, (char) 60868, (char) 59370,
        Double.longBitsToDouble(0x3fcec8075690708cL), Double.longBitsToDouble(0x3fe34a4bef31c2bcL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 13, 0, "\ud8a7\uddf7\uda0d\ude61\ud9aa\udedd\ud971\ude3f\ud8ba\udd7c", "\u5c05\ub79f\u7a14", "\udb03\udc79\ud913\udc97\uca60\udb60\udf33\uf63e\ud903\udfb7\udba8\ude4f\ud84c\udc50\udbe3\ude61\uda6c\udd39\ud870\ude78\ud947\udc2f\ud952\udc01\ud872\udedf\udb21\udd0d\udab3\udfea\udba8\ude69\udae9\udf34\udb69\udff6\ud873\ude5f\udaa2\ude5f\uda5c\ude33\ud8be\udce8\ud905\udc1b\udb5b\udec8\ud9b7\udd35\ud8e1\udeec\udb3a\udc65\udb53\udecd\ud8c0\udc59\ud80e\udc2d",
        8, 75460, -1027849623, -3453303029986906977L, 54004L, false, true, (char) 31750, (char) 45103,
        Double.longBitsToDouble(0x3fea80eb4150e423L), Double.longBitsToDouble(0x3fec8e49f45b66a5L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 10, 8, "\ud8f6\udc22\uda0d\ude61/\000\udb43\udee9", "\u5ae8\uc1c7\uce0b\u3add\u00a4\u5bb3\u5cec\u9676\u75e0\ub23a\u894f\uc0ee\u8b5a\u9d64", "\ud947\udc27\ud856\uddc6\udb8f\udf4a\ud89e\udd30\ud9e8\udcfb\udba8\ude36\udae9\udf34\udb69\udff6\ud873\ude5f\udaa2\ude5f",
        13, 59391, -287703010, 1341410441182481130L, 86483L, false, true, (char) 35814, (char) 10734,
        Double.longBitsToDouble(0x3fcb82e6d67b4728L), Double.longBitsToDouble(0x3fdf75f392c98182L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 14, 11, 16, "\uda84\uddc2\uda0d\ude61\ud9aa\udedd\ud8c7\udce2\udb3e\ude9b\ud981\udfab\udbec\ude28\ub0b4\ud81e\udf41\uda9b\ude4f\ud802\ude82\u0d00\ud861\uddfc\uda4e\udcc0\udb9d\udd7e\udb60\udf33\ud968\udd04", "\u8b5a\ubb41\u6f83\u2ea6\u4071\uc10e\u80a3\u07a5", "\udae9\udf34\udb69\udff6\udb33\udee0\ud9b2\udcdd\ud926\udd6a\ud983\uddf5\u8b6a\udb10\ude49\ud9b7\udd35\ud9ba\udff6\udb3a\udc65\udb53\udecd\ud8c0\udc59\ud80e\udc2d\ud912\udf37",
        -1, 88677, -2129804152, 5787971139128185293L, 27147L, true, false, (char) 52519, (char) 48287,
        Double.longBitsToDouble(0x3fca3e4deecb0720L), Double.longBitsToDouble(0x3fe46eda219cde14L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 14, 14, 3, "\u8899\uda0d\ude13\uda28\udf12\ud9b9\udc81\udb43\udf9b", "\u5c36\ub79f\u7a14\u3a94\u7d8a\u5cb4\u5cec\u795e\ub86a\ub23a\u1b62\uc0ee\u8b5a\ubb41", "\ud947\udc27\ud96c\udd8d\ud855\udd4e\ud17a\000\ud88a\udf04\ua58e",
        31, 38418, 1547567104, -571266530524790784L, 54192L, false, false, (char) 0, (char) 39443,
        Double.longBitsToDouble(0x3fe950b3a800b604L), Double.longBitsToDouble(0x3fe80000078d8396L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 18, 4, "\ud913\udf48\uda0d\udeda\ud9aa\udedd\udb09\udf07\udb43\udf9b", "\ua888\u83c6\u886c\ub53e\uc32d\u5d74\u5cec\u795e\u5f89\ub20b\u894f\u32b6\u3b6e\u60e7", "\ud947\udc27\ud952\udc01\ud872\udedf\udb21\udd0d\ud8b8\udc16\udba8\udde5\udae9\udf34\udb69\udff6\ud873\ude5f\udaa2\ude5f",
        11, 94783, -726345989, -6541306930331093336L, -14225L, true, false, (char) 61796, (char) 20349,
        Double.longBitsToDouble(0x3fefe63d144b959dL), Double.longBitsToDouble(0x3fba6f8298a523d8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 3, 11, "\ud8a7\ude9b\uda0d\ude61\ud89a\udf43\ud960\udd6e", "\u1210\u5c36\ub7f9\u2205\ubf4a\u993a\u7661\ua7ad\u4b08\u883a\u9f7b", "\ud84c\udc50\udba9\udf64\ud915\udeb4\ud9b4\udcde\udb25\ude47\ud952\udc01\ud872\udedf\udb21\udd0d\udaee\ude68\udb8c\udeb2\u1523",
        34, 97933, -450743299, 5930330309339867424L, 54192L, true, false, (char) 15687, (char) 39608,
        Double.longBitsToDouble(0x3fe1d8abacf5b11eL), Double.longBitsToDouble(0x3fd6ddb9e50b0558L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 1, 16, "\uda75\udcc6\uda0d\ude61\ud9aa\udedd\035\ud8ca\udcb8\ud969\udd31\udbec\ude28\ub0b4\ud81e\udf41\uda9b\ude4f\ud802\ude82\u0d00\ud861\uddfc\ud922\udfc4\udb9d\udd7e\udb60\udf33\ud968\udd04", "\u8b5a\u5512\u06cf\u2e38", "\ud872\udedf\udb21\udd0d\ud937\udd45\udb9a\udfba\udae9\udf34\udb69\udff6\ud994\udc0a\udb97\udd33\uda35\udd2c\ud9dd\udcd9\ud94a\udf64\udafa\uddbf\ud9b7\udd35\ud9ba\udff6\udb3a\udc65\udb53\udecd\ud8c0\udc59\ud80e\udc2d\ud912\udf37\uda9b\udc75",
        12, 82848, 1347617046, -4183050424511981456L, 31369L, false, true, (char) 48287, (char) 24385,
        Double.longBitsToDouble(0x3fed960e46bb1d44L), Double.longBitsToDouble(0x3fd9cde147660c7cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 3, 16, "\uda84\uddc2\uda0d\ude61\ud9aa\udedd\ud8c7\udce2\udb3e\ude9b\ud981\udfab\udbec\ude28\ub0b4\ud81e\udf41\udaaf\udc4f\ud802\ude82\u0d00\ud861\uddfc\uda4e\udcc0\uda8c\udff6\udbc3\udedd\ud8ab\udee2", "\u8b5a\ua41a\u8196\u7f55\u75f3\uc10e\uc4b4\u4e3c", "\udae9\udf34\udb69\udff6\udb33\udee0\ud9b2\udcdd\ud926\udd6a\ud983\uddf5\u8b6a\udb10\ude49\ud9b7\udd35\ud9ba\udff6\udb3a\udc65\udb53\udecd\ud8c0\udc59\ud80e\udc2d\ud912\udf37",
        -1, 88677, -2129804152, 5787971139128185293L, 27147L, true, false, (char) 52519, (char) 48287,
        Double.longBitsToDouble(0x3fca3e4deecb0720L), Double.longBitsToDouble(0x3fe46eda219cde14L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 11, 11, 16, "\uda84\uddc2\uda0d\ude61\ud9aa\udedd\ud8c7\udce2\udb3e\ude9b\ud981\udfab\udbec\ude28\ub0b4\ud81e\udf41\uda9b\ude4f\ud802\ude82\u0d00\ud861\uddfc\uda4e\udcc0\udb9d\udd7e\udb60\udf33\ud968\udd04", "\u8b5a\ubb41\u6f83\u2ea6\u4071\uc10e\u80a3\u07a5", "\udae9\udf34\udb69\udff6\udb33\udee0\ud9b2\udcdd\ud926\udd6a\ud983\uddf5\u8b6a\udb10\ude49\ud9b7\udd35\ud9ba\udff6\udb3a\udc65\udb53\udecd\ud8c0\udc59\ud80e\udc2d\ud912\udf37",
        -1, 88677, -2129804152, 5787971139128185293L, 27147L, true, false, (char) 52519, (char) 48287,
        Double.longBitsToDouble(0x3fca3e4deecb0720L), Double.longBitsToDouble(0x3fe46eda219cde14L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 12, 12, 4, "\ud913\udf48\ud978\udd50\ud935\ude55", "\u1e4d\u7225\ua05b\ua49e\u8916\u63ef\uc32d\u6fb9", "\ud84b\udc82\ud893\udcbb",
        56, 75668, -734800041, -717826380723811051L, -24667L, true, false, (char) 834, (char) 27973,
        Double.longBitsToDouble(0x3fe6803cb9594a8dL), Double.longBitsToDouble(0x3fdfa8b187ea9528L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 0, 14, "\u1932\uda0d\ude16\ud9aa\udedd\udb09\udf07\udb43\udf9b\ud998\udf16\udbec\ude28", "\u7a14\ub53e\uc32d\u5cbb\u5cec\u795e\ub86a\ub23a\u894f\uabee\u8b5a\ubb41\u6f83\ud7fd\u4071\uc10e\u80a3\u07a5\ubab1\u6e11\u1398\u84ef\u925e\u541d\u48cc\u2063\u18cb\u6457\ub582\u6c1f\u1a09\u6660\u6ae5\u2c0e\ua909\u3cbe\u71cc", "\udb80\udf3f\udbf3\ude8d",
        59, 89974, 1746405781, -8271847960618112387L, 78683L, true, false, (char) 38484, (char) 43602,
        Double.longBitsToDouble(0x3fe1f10ac2abab4bL), Double.longBitsToDouble(0x3fe5b85c9ad47737L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 13, 13, 4, "\ud913\udf48\uda0d\udeda\ud9aa\udedd\udb09\udf07\udb43\udf9b", "\ua888\u6967\u69cb\u6222\u8931\u1efb\u60b6\u795e\u5f89\ub20b\u894f\u32b6\u3b6e\u60e7", "\ud947\udc27\ud8a1\uddc8\ud860\udd88\udb21\udd0d\ud8b8\udc16\udba8\udde5\udae9\udf34\udb69\udff6\ud873\ude5f\udac4\ude02",
        11, 94783, -726363074, -6541306930331093336L, -14225L, true, false, (char) 61796, (char) 20349,
        Double.longBitsToDouble(0x3fefe63d144b959dL), Double.longBitsToDouble(0x3fa85f05314a47b0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\0121=null |this=com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:@?\012",
        Z.run(T, 2, 15, 15, 10, "\uda75\udd77\uda0d\ude61\ud9aa\udedd\035\ud8ca\udcb8\ud969\udd31\udbec\ude28\ud8b6\udcb8\ud869\udfcb\ud936\udd46\ud802\ude82\u0d00\ud861\uddfc\ud922\udfc4\udb9d\udd7e\udb60\udf33\ud968\udd04\ud9d2\udc93\ud932\udfc9", "\u06cf\u2e38\u4071\uc10e\ub156\u07a5\u78c8\ucc08\u19db\u84ef\u677d\u71a3\u8287\u0a38\u861c\ua9e3\ub582\u3496\uaed5\ua3c6\u6a4e\u2c0e\u9a71\u193c", "\udb78\ude24\ud89d\ude61\ud8ac\udfd2\udb6c\udcd1\udb49\uddf4\udb91\udc61\ud939\udd9e",
        49, 59234, 1142179515, 493911514852587699L, -69479L, true, true, (char) 32120, (char) 43367,
        Double.longBitsToDouble(0x3fe618b56abfa6beL), Double.longBitsToDouble(0x3fd73c5f2748aa74L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|modifyTypeByAnnotation|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JavaType|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|modifyTypeByAnnotation|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.TypeDeserializerBase|_findDeserializer|com.fasterxml.jackson.databind.DeserializationContext,java.lang.String|new:com.fasterxml.jackson.databind.jsontype.impl.AsArrayTypeDeserializer:com.fasterxml.jackson.databind.jsontype.impl.AsArrayTypeDeserializer,com.fasterxml.jackson.databind.BeanProperty",
    "M|com.fasterxml.jackson.databind.module.SimpleAbstractTypeResolver|findTypeMapping|com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.module.SimpleAbstractTypeResolver:",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_addDeserializerConstructors|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.deser.impl.CreatorCollector,java.util.Map|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_addDeserializerFactoryMethods|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.deser.impl.CreatorCollector,java.util.Map|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_checkIfCreatorPropertyBased|com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_checkImplicitlyNamedConstructors|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.deser.impl.CreatorCollector,java.util.List|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_constructDefaultValueInstantiator|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_createEnumKeyDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCreatorsFromProperties|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomArrayDeserializer|com.fasterxml.jackson.databind.type.ArrayType,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.JsonDeserializer|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomBeanDeserializer|com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomCollectionDeserializer|com.fasterxml.jackson.databind.type.CollectionType,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.JsonDeserializer|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomCollectionLikeDeserializer|com.fasterxml.jackson.databind.type.CollectionLikeType,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.JsonDeserializer|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|_findCustomEnumDeserializer|java.lang.Class,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.BeanDescription|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.BasicDeserializerFactory|modifyTypeByAnnotation|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JavaType|fld:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:instance",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|modifyTypeByAnnotation|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.TypeDeserializerBase|_findDeserializer|com.fasterxml.jackson.databind.DeserializationContext,java.lang.String|new:com.fasterxml.jackson.databind.jsontype.impl.AsArrayTypeDeserializer:com.fasterxml.jackson.databind.jsontype.impl.AsArrayTypeDeserializer,com.fasterxml.jackson.databind.BeanProperty",
    "M|com.fasterxml.jackson.databind.module.SimpleAbstractTypeResolver|findTypeMapping|com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.module.SimpleAbstractTypeResolver:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
