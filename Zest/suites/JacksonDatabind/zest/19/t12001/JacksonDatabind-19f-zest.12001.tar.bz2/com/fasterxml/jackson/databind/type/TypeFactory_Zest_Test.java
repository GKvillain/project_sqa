package com.fasterxml.jackson.databind.type;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 2, 0, "\uda50\uddb4\udb36\ude04\ud80c\udc91\uda65\udf43\ud859\uddfa\udbad\udd1f", "\u393b\u5049\u7df1\u1940\ubed2\ud4da\u730a\ua065\u99ec", "\ud9ce\udf2c\ud8e2\uddfc\ud8cf\udd45\ua1fa\udb6d\udfad\ub450\udb20\udfb0\udb95\udcd5\ud9ae\udc31\ud917\udf01\uda70\udef3\udbed\uddf0\uda52\udd49\udbf5\udeb5\udb8b\udfac\ud9f7\udd9d\ud85d\udfc2\udaaa\udc57\ud803\udcd3\udb54\udf25\ud8fa\udcce\uda4d\uddd8\ud984\udc29\ud900\udd8f",
        37, 59497, 1947854735, 2689485612772683700L, 2392L, false, false, (char) 38869, (char) 62021,
        Double.longBitsToDouble(0x3fc6363250907998L), Double.longBitsToDouble(0x3fab69588cdd5f70L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 2, 0, "\uda50\uddb4\udb36\ude04\ud80c\udc91\uda65\udf43\ud859\uddfa\udbad\udd1f", "\u393b\u5049\u7df1\u1940\ubed2\ud4da\u730a\ua065\u99ec", "\ud96b\udc9f\ud8e2\uddfc\ud8cf\udd45\ua1fa\udb6d\udfad\ub450\udb20\udfb0\udb95\udcd5\ud9ae\udc31\ud917\udf01\uda70\udef3\udbed\uddf0\uda52\udd49\udbf5\udeb5\udbd4\udc66\ud9f7\udd9d\ud85d\udfc2\udaaa\udc57\ud803\udcd3\ud8e9\udd83\udb78\udc40\ud9f1\udd38\ud8e3\udfbe\ud936\udea0",
        37, 59497, 1947854735, 2689485612772683700L, 31719L, true, true, (char) 38869, (char) 62021,
        Double.longBitsToDouble(0x3fc6363250907998L), Double.longBitsToDouble(0x3fe9b69588cdd5c6L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Object] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 15, 5, 0, "\uda50\uddb4\udb36\ude04\ud80c\udc91\udbef\udce8\ud982\uddac", "\u8034\u393b\u5049\u1df1\u18c1\ubed2\ud589", "\ud870\udc18\uda54\udfdc\udbaa\ude31\ud9b6\ude62\ud8e2\uddfc\uda7c\ude1b\ua1fa\udb6d\udfad\ub450\u8b52\ud818\udcc8\ud9ae\udc31\ud917\udf01",
        -4, 59974, 1345156240, 7079610193800336572L, -58398L, true, true, (char) 5389, (char) 47202,
        Double.longBitsToDouble(0x3fbdaf47dc81bda0L), Double.longBitsToDouble(0x3fc3cc608684a8c4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 12, 11, "\uda50\uddb4\udb36\ude04\uda30\udd64\uda90\udec0\ud859\uddfa\ud9d3\udeb3\ud942\uddf4\udb30\udf0f\ud9f6\udcb8\uda7a\ude73\udb68\udfa6\ud96d\ude3a\uda2b\ude26\ud818\udda8\udae6\udf28\ud85e\udf86\ud92a\uded8\ud84b\udd98\ud9d4\uddb1\ud9ce\udf2c\ud8e2\uddfc\ud8cf\udd45", "\u3fde\u82a8\u9f22\u553f\uc9ec\uc3a6\uca2c\u3b0d\u3b44\u06a6\u3281", "\ud803\udcd3\udb54\udf25\udbfd\udd2a\uda30\udf7e\ud825\udf39\ud954\udc29\udad5\udc61\ud805\udcc6\uda2b\ude66\ud826\udf1d\uda98\ude86\ud99d\udf0d\udae2\udf20",
        42, 11398, -1315820694, 2190500600862540836L, -83821L, false, false, (char) 44704, (char) 19094,
        Double.longBitsToDouble(0x3fdea5b8126069f0L), Double.longBitsToDouble(0x3fdde9be4ac5923cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 2, 0, "\uda50\uddb4\udb36\ude04\ud80c\udc91\uda65\udf43\ud859\uddfa\udbad\udd1f", "\u393b\u5049\u7df1\u1940\u89e2\000\u58b5\ua065\u99ec", "\ud9ce\udf2c\ud8e2\uddfc\ud8cf\udd45\ua1fa\udb6d\udfad\ub450\udb20\udfb0\udb95\udcd5\ud9ae\udc31\ud917\udf01\uda70\udef3\ud83b\udcd6\uda52\udcb9\udbf5\udeb5\udb8b\udfac\ud9f7\udd9d\ud85d\udfc2\udaaa\udc57\ud803\udcd3\udb54\udf25\ud8fa\udcce\uda4d\uddd8\ud984\udc29\ud900\udd8f",
        37, 59497, 1947854735, 2689485612772683700L, 2392L, false, false, (char) 38869, (char) 62021,
        Double.longBitsToDouble(0x3fc6363250907998L), Double.longBitsToDouble(0x3fab69588cdd5f70L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_mapType|java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_arrayListSuperInterfaceChain|com.fasterxml.jackson.databind.type.HierarchicType|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_collectionType|java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_constructType|java.lang.reflect.Type,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_doFindSuperInterfaceChain|com.fasterxml.jackson.databind.type.HierarchicType,java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_findSuperClassChain|java.lang.reflect.Type,java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_findSuperInterfaceChain|java.lang.reflect.Type,java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_findSuperTypeChain|java.lang.Class,java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromArrayType|java.lang.reflect.GenericArrayType,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromClass|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromParamType|java.lang.reflect.ParameterizedType,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromParameterizedClass|java.lang.Class,java.util.List|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromVariable|java.lang.reflect.TypeVariable,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromWildcard|java.lang.reflect.WildcardType,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_hashMapSuperInterfaceChain|com.fasterxml.jackson.databind.type.HierarchicType|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_resolveVariableViaSubTypes|com.fasterxml.jackson.databind.type.HierarchicType,java.lang.String,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_mapType|java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
