package com.fasterxml.jackson.databind.deser;
import org.junit.Test;
import static org.junit.Assert.*;
public class DefaultDeserializationContext_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 1, 3, "\udb82\udd1d", "\u2486\u53b4\u3256\u7659\u652b\u4863\u897b\u2461\u87b0\u9fb6\u14a7\u77ea\u270d\u150e\u085c\u7e52\ub078\u559e\u4967\u6752\u62c3\ud5bc\uc867\u903d\u8705\ud06e\ud096\u6848\u6c51\uc467\u4b48\u49a2", "\ud8e9\udd20\uda37\udcc9",
        8, 23067, 31094651, -9122552030718377680L, 65755L, false, true, (char) 9738, (char) 44117,
        Double.longBitsToDouble(0x3fe5181967b30314L), Double.longBitsToDouble(0x3fc0f0cac4719798L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 1, 5, "\udb82\udd1d\udbf6\udd7c\ubf3b\udbd2\uddb9\udacd\ude2c\ud847\ude80\ud8a1\udd99\ud974\ude52\udbb0\uddb7", "\u87b0", "\udac9\udc6a\udbcb\udc55\udb81\uddaf\udbe0\udf53",
        58, 65366, 521232588, 4976925686530533698L, -15185L, true, false, (char) 44477, (char) 38396,
        Double.longBitsToDouble(0x3fd2c00c5b3fc200L), Double.longBitsToDouble(0x3fd007c00bc019caL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 11, 3, "\udb82\udd1d", "\u2486\u53b4\u6e9a\u7659\u652b\u4863\u897b\u2461\u87b0\u9fb6\u14a7\u77ea\u270d\u150e\u085c\u7e52\ub078\u559e\u4967\u6752\u62c3\ud5bc\uc867\u903d\u8705\ud06e\ud096\u6848\u6c51\uc467\u4b48\u49a2", "\ud8e9\udd20\uda37\udcc9",
        8, 23067, 31094651, -9122552030706777808L, 65755L, false, true, (char) 9738, (char) 44117,
        Double.longBitsToDouble(0x3fe5181967b30314L), Double.longBitsToDouble(0x3fc0f0cac4719798L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 3, "\udb82\udd1d", "\uc0f6\u45f6\u47aa\ub520\u6553\u5df7\u897b\u2461\ub69c\u81e8\u15cf\ub065", "\ud815\udc42",
        48, 65366, 521232588, 4976925685501537346L, 47789L, true, false, (char) 44989, (char) 36077,
        Double.longBitsToDouble(0x3fea6585ad90cbb4L), Double.longBitsToDouble(0x3fd007c00bc019caL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 3, "\udb82\udd1d", "\u2486\u53b4\u3256\u7659\u652b\u10bd\u897b\u2461\u87b0\u9fb6\u14a7\u77ea\u270d\u150e\u085c\u7e52\ub078\u559e\u4967\u6752\u62c3\ud5bc\uc867\u903d\u8705\ud06e\ud096\u6848\u6c51\uc467\u4b48\u49a2", "\ud8e9\udd20\uda37\udcc9",
        8, 23067, 31094651, -9122552030718377680L, 65755L, false, true, (char) 9738, (char) 44117,
        Double.longBitsToDouble(0x3fe5181967b30314L), Double.longBitsToDouble(0x3fc0f0cac4719798L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 3, "\udb82\udd1d", "\u2486\u53b4\u3256\u7659\u652b\u10c2\u3a46\u2461\u87b0\u9fb6\u14a7\u77ea\u270d\u150e\u085c\u7e52\ub078\u566e\u9d0f\u7a01\u52e3\uc7b7\ub250\u903d\u8705\ud06e\ud096\u6848\u6c51\ub41a\u4b48\u49a2", "\ud8e9\udd20\uda37\udcc9",
        8, 23067, 31094651, -9102013153511522000L, 65755L, false, true, (char) 9738, (char) 44117,
        Double.longBitsToDouble(0x3fe5181967b30314L), Double.longBitsToDouble(0x3fc0f0cac4719798L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 1, 3, "\udb82\udd1d", "\u2486\u8bde\u3256\u7659\u652b\u4863\u897b\u2461\u87b0\u9fb6\u14a7\u77ea\u270d\u150e\u50d4\u7e52\u0727\u96d7\uc723\u67e1\u62c3\ud5bc\uc867\u901a\u8705\ud06e\ud096\u6848\u3e64\u33f4\u4342\u8497", "\ud8e9\udd20\uda37\udcc9",
        10, 29305, -1574686836, -9122372183257824976L, 65755L, false, true, (char) 9738, (char) 44117,
        Double.longBitsToDouble(0x3fe5181967b30314L), Double.longBitsToDouble(0x3fb44c1588e32f30L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.DefaultDeserializationContext|findObjectId|java.lang.Object,com.fasterxml.jackson.annotation.ObjectIdGenerator|new:com.fasterxml.jackson.databind.deser.DefaultDeserializationContext$Impl:com.fasterxml.jackson.databind.deser.DeserializerFactory",
    "M|com.fasterxml.jackson.databind.deser.DefaultDeserializationContext|findObjectId|java.lang.Object,com.fasterxml.jackson.annotation.ObjectIdGenerator,com.fasterxml.jackson.annotation.ObjectIdResolver|new:com.fasterxml.jackson.databind.deser.DefaultDeserializationContext$Impl:com.fasterxml.jackson.databind.deser.DeserializerFactory",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|deserializeSetAndReturn|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.DefaultDeserializationContext|checkUnresolvedObjectId||new:com.fasterxml.jackson.databind.deser.DefaultDeserializationContext$Impl:com.fasterxml.jackson.databind.deser.DeserializerFactory",
    "M|com.fasterxml.jackson.databind.deser.DefaultDeserializationContext|copy||new:com.fasterxml.jackson.databind.deser.DefaultDeserializationContext$Impl:com.fasterxml.jackson.databind.deser.DeserializerFactory",
    "M|com.fasterxml.jackson.databind.deser.DefaultDeserializationContext|createInstance|com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.InjectableValues|new:com.fasterxml.jackson.databind.deser.DefaultDeserializationContext$Impl:com.fasterxml.jackson.databind.deser.DeserializerFactory",
    "M|com.fasterxml.jackson.databind.deser.DefaultDeserializationContext|deserializerInstance|com.fasterxml.jackson.databind.introspect.Annotated,java.lang.Object|new:com.fasterxml.jackson.databind.deser.DefaultDeserializationContext$Impl:com.fasterxml.jackson.databind.deser.DeserializerFactory",
    "M|com.fasterxml.jackson.databind.deser.DefaultDeserializationContext|keyDeserializerInstance|com.fasterxml.jackson.databind.introspect.Annotated,java.lang.Object|new:com.fasterxml.jackson.databind.deser.DefaultDeserializationContext$Impl:com.fasterxml.jackson.databind.deser.DeserializerFactory",
    "M|com.fasterxml.jackson.databind.deser.DefaultDeserializationContext|with|com.fasterxml.jackson.databind.deser.DeserializerFactory|new:com.fasterxml.jackson.databind.deser.DefaultDeserializationContext$Impl:com.fasterxml.jackson.databind.deser.DeserializerFactory",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|deserializeAndSet|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|getAnnotation|java.lang.Class|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|getMember||new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|set|java.lang.Object,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|setAndReturn|java.lang.Object,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|withName|com.fasterxml.jackson.databind.PropertyName|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|withValueDeserializer|com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.DefaultDeserializationContext|findObjectId|java.lang.Object,com.fasterxml.jackson.annotation.ObjectIdGenerator|new:com.fasterxml.jackson.databind.deser.DefaultDeserializationContext$Impl:com.fasterxml.jackson.databind.deser.DeserializerFactory",
    "M|com.fasterxml.jackson.databind.deser.DefaultDeserializationContext|findObjectId|java.lang.Object,com.fasterxml.jackson.annotation.ObjectIdGenerator,com.fasterxml.jackson.annotation.ObjectIdResolver|new:com.fasterxml.jackson.databind.deser.DefaultDeserializationContext$Impl:com.fasterxml.jackson.databind.deser.DeserializerFactory",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|deserializeSetAndReturn|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
