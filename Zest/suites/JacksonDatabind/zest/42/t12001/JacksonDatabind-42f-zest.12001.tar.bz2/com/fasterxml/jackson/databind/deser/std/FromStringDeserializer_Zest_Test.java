package com.fasterxml.jackson.databind.deser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class FromStringDeserializer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 4, 3, 1, "\udba1\ude11\ud830\uded4\ud860\udcc9\ud8c4\udd5f\uda62\udf44\udbc0\udee7\uda66\udc15", "\uaf24\u296d\u9c19\u89b1\u3550\u1492\ua993", "\u6e91\ud844\udc6e\udbc1\uddeb\udba6\udf26\ud891\udefe\ud96c\udfb7\ud9a1\udea5\udb33\uddca\ue3cc\uda18\uddbf\uda78\udfbf\ud9d1\uded2\uf1bd",
        42, 7789, -1793905789, -7344387354561736150L, 77277L, false, true, (char) 57345, (char) 23368,
        Double.longBitsToDouble(0x3feaa30fbcc0650fL), Double.longBitsToDouble(0x3fed248d2c3d4f4eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!H:norecv\012",
        Z.run(T, 1, 1, 5, 0, "\ud819\uddb3\ud830\udf3c\ud860\udcc9\ud8c4\udd5f\uda62\udf44\udbc0\udee7\uda66\udc15", "\u0d6d\u296d\u5c59\ucbb0\ucc0e\u1492\ua993", "\u6e91\ud844\udc6e\udbc1\uddeb\udbab\udce7\udbee\udd95\udbc3\udc93\ud866\udc35\udb33\uddca\ue3cc\uda18\uddbf\uda78\udfbf\ud9d1\uded2\udab0\udc77",
        27, 7755, -1793905789, -6500165834080906734L, 77277L, false, true, (char) 57345, (char) 23368,
        Double.longBitsToDouble(0x3fed4b0fbcc0650fL), Double.longBitsToDouble(0x3fed248d2c3d4f4eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 4, 3, 1, "\udba1\ude11\ud830\uded4\ud860\udcc9\ud8c4\udd5f\uda62\udf44\udbc0\udee7\uda66\udc15", "\uaf24\u296d\u9c19\u89b1\u3550\u1492\ua993", "\u6e91\ud844\udc6e\udbc1\uddeb\udba6\udf26\ud891\udefe\ud96c\udfb7\ud9a1\udea5\u0492\000\ud9e3\udf10\uda78\udfbf\ud9d1\uded2\uf1bd",
        5, -1000, 0, -7344388028871601622L, 77277L, false, true, (char) 57345, (char) 23368,
        Double.longBitsToDouble(0x3feaa30fbcc0650fL), Double.longBitsToDouble(0x3f4234b0f4000000L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!H:norecv\012",
        Z.run(T, 1, 0, 5, 1, "\udb59\udd6e\udb8e\udcf8\ud96c\udc6d\udac8\udda6\uda8c\udff9\udbc0\udf04\uda66\udc15", "\uaf24\u296d\u9c19\u2d8c\u3550\u1492\ua993", "\u6e91\ud844\udc6e\udbc1\uddeb\udba6\udf26\ud891\udefe\ud96c\udfb7\ud9a1\udea5\udb33\uddca\ue3cc\uda18\uddbf\udaa5\udcbf\ud9d1\uded2\uf1bd",
        42, 7789, -1793905789, -7344387354561736150L, 77277L, false, true, (char) 57345, (char) 23368,
        Double.longBitsToDouble(0x3feaa30fbcc0650fL), Double.longBitsToDouble(0x3fed248d2c3d4f4eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=[Ljava.lang.Class;:[[class java.io.File, class java.net.URL, class java.net.URI, class java.lang.Class, class com.fasterxml.jackson.databind.JavaType, class java.util.Currency, class java.util.regex.Pattern, class java.util.Locale, class java.nio.charset.Charset, class java.util.TimeZone, class java.net.InetAddress, c...\012",
        Z.run(T, 1, 5, 3, 1, "\udba1\ude11\ud830\udef7\uda1d\ude6e\ud96a\udf20\udaad\uddec\u8882\udb5a\udf60", "\uaf24\u296d\ubbed\u7fbd", "\udada\ude27\udb3b\udd94\ud8dd\ude12\ud9f0\udcd9\ud844\udc6e\udbac\udf57\udba6\udf26\ud891\udefe\ud96c\udfb7\ud9a1\udea5\udb33\uddca",
        53, 8736, 1694383564, -4764400797880439659L, 99283L, false, false, (char) 40912, (char) 54527,
        Double.longBitsToDouble(0x3fcc1fdc9b1995c0L), Double.longBitsToDouble(0x3fea924e528fb572L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null\0121=!H:norecv\012",
        Z.run(T, 2, 4, 3, 1, "\udba1\ude11\ud830\uded4\ud860\udcc9\ud8c4\udd5f\uda62\udf44\udbc0\udee7\uda66\udc15", "\uaf24\u296d\u1c1c\ub435\u0538\u80bd\ua993", "\u6e91\ud844\udc6e\udbc1\uddeb\udba6\udf26\ud891\udefe\ud96c\udfb7\ud9a1\udea5\udb33\uddca\ue3cc\uda18\uddbf\uda78\udfbf\ud9d1\uded2\uf1bd",
        42, 7789, -1793905789, -7344387354561736150L, 77277L, false, true, (char) 57345, (char) 23368,
        Double.longBitsToDouble(0x3feaa30fbcc0650fL), Double.longBitsToDouble(0x3fed248d2c3d4f4eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=[Ljava.lang.Class;:[[class java.io.File, class java.net.URL, class java.net.URI, class java.lang.Class, class com.fasterxml.jackson.databind.JavaType, class java.util.Currency, class java.util.regex.Pattern, class java.util.Locale, class java.nio.charset.Charset, class java.util.TimeZone, class java.net.InetAddress, c...\012",
        Z.run(T, 1, 5, 3, 5, "\udb64\udc12\ud830\uded4\ud860\udcc9\ud8c4\udd5f\uda5a\ude44\udbc0\udee7\uda66\udc15", "\u650a\ud199\u9c46\u89b1\u3550\ua322\u8ea3", "\udbf7\ude1f\ud844\udc6e\udbab\ude4f\ud962\udfa3\ud89d\udece\ud96c\udfb7\ud990\udd99\udb77\udfed\ud895\udf4a\uda18\uddbf",
        24, 12168, -2043341419, 7401709857381603309L, 37248L, true, false, (char) 17692, (char) 57345,
        Double.longBitsToDouble(0x3fcde76b22b02f20L), Double.longBitsToDouble(0x3fe896fb17a45198L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null\0121=!H:norecv\012",
        Z.run(T, 2, 4, 3, 1, "\udba1\ude11\ud830\uded4\udb74\udf8d\uda78\udd86\uda62\udf44\udbc0\udee7\udb5f\ude32", "\u32ef\u345a\uccfc\u53a5\u464e\uaceb\ua993\u1c6a", "\ud853\udc6e\udbc1\uddeb\udba6\ude6d\ud815\udeff\ud950\uded9\ud9a1\udea5",
        33, 24606, 2011222703, -8809588650863696404L, 26422L, false, true, (char) 61597, (char) 17692,
        Double.longBitsToDouble(0x3fe47dab97ef3b59L), Double.longBitsToDouble(0x3fe4a357bb275c76L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null\0121=[Ljava.lang.Class;:[[class java.io.File, class java.net.URL, class java.net.URI, class java.lang.Class, class com.fasterxml.jackson.databind.JavaType, class java.util.Currency, class java.util.regex.Pattern, class java.util.Locale, class java.nio.charset.Charset, class java.util.TimeZone, class java.net.InetAddress, c...\012",
        Z.run(T, 2, 4, 5, 4, "\ud9cd\uddee", "\ube8c\u8f53\u35e3\u7e6d\u62b4\u7e93\u0987\u296d\u97dd\u18fa", "\udada\udeca",
        29, 74601, -1651385250, -6418740329745711365L, 2132L, false, false, (char) 33978, (char) 544,
        Double.longBitsToDouble(0x3fd975fb5570c9fcL), Double.longBitsToDouble(0x3fdb3bde1fa9754cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[Ljava.lang.Class;:[[class java.io.File, class java.net.URL, class java.net.URI, class java.lang.Class, class com.fasterxml.jackson.databind.JavaType, class java.util.Currency, class java.util.regex.Pattern, class java.util.Locale, class java.nio.charset.Charset, class java.util.TimeZone, class java.net.InetAddress, c...\0121=[Ljava.lang.Class;:[[class java.io.File, class java.net.URL, class java.net.URI, class java.lang.Class, class com.fasterxml.jackson.databind.JavaType, class java.util.Currency, class java.util.regex.Pattern, class java.util.Locale, class java.nio.charset.Charset, class java.util.TimeZone, class java.net.InetAddress, c...\012",
        Z.run(T, 2, 5, 5, 2, "\ud819\uddb3\ud902\udc5d\uf061\ud8c4\udd5f\uda62\udf44\udbc0\udee7\uda66\udc15", "\u8c3d", "\ud8f9\udd01\ud913\udeb4\uda08\udfb0\udada\udeca",
        29, 85225, -443425698, -6418740328235761925L, -81331L, false, true, (char) 33978, (char) 56836,
        Double.longBitsToDouble(0x3fe0912271e10db7L), Double.longBitsToDouble(0x3fc2a4aeff52e8b8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 4, 4, 1, "\udac5\udc1b\ud9df\udef5\udb4c\udc22\u4131\uda83\udd3e\ud925\udd24\udb5a\udf60\uda1c\uddd5\uda2f\udd00\ud8c6\udfdf\ud830\udce9\ud98e\udc88\uda54\udc78\ud908\udd7a\udb6b\ude77\udada\ude27\ud995\udd71\uda94\ude12\ud9f0\udfd2\udb01\udd69\udbac\udf57\ud810\udd3a\ud895\udcf4\udb28\ude76\ud853\udf1e\udae2\udf70\ud845\udc6e\uda18\udde0\uda78\udfbf\ud9d1\uded2\uda8d\udcc5\ud921\udc61\ud94a\uded2\udadc\udd54\ud8e2\udd90\ud8c1\udd62\u49ee\ud8ba\ude97\ud8f5\udeed\udb9d\udd57", "\u4fdd\u6c5a\ub48c\u853e\u8fdf\u51ef\ucdd4", "\ud9f2\udc90\udb72\udf6e",
        2, 26892, 1457769355, -8695080686605542608L, -89122L, false, true, (char) 1552, (char) 13743,
        Double.longBitsToDouble(0x3fd58ee6e41137c0L), Double.longBitsToDouble(0x3fd9852d080b3b40L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Ljava.lang.Class;:[[class java.io.File, class java.net.URL, class java.net.URI, class java.lang.Class, class com.fasterxml.jackson.databind.JavaType, class java.util.Currency, class java.util.regex.Pattern, class java.util.Locale, class java.nio.charset.Charset, class java.util.TimeZone, class java.net.InetAddress, c...\0121=[Ljava.lang.Class;:[[class java.io.File, class java.net.URL, class java.net.URI, class java.lang.Class, class com.fasterxml.jackson.databind.JavaType, class java.util.Currency, class java.util.regex.Pattern, class java.util.Locale, class java.nio.charset.Charset, class java.util.TimeZone, class java.net.InetAddress, c...\012",
        Z.run(T, 2, 5, 5, 2, "\ud95d\uddb2\ud902\udc9e\uf061\ud9f8\udd59\uda62\udf44\udbc0\udee7\uda66\udc15", "\u4504", "\udbc1\udcad\udbc6\udd07\uda69\udce9\ud93d\udfce",
        23, 85225, 1586617438, -5614460540568805L, -48305L, false, false, (char) 46388, (char) 802,
        Double.longBitsToDouble(0x3feff0a5e25a2b8cL), Double.longBitsToDouble(0x3fe2992271e10db7L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 4, 4, 1, "\ud94d\udff3\ud9df\udf31\ud990\udc24\u4131\u3e66\ud891\udc32\udb58\uddeb\uda1c\uddd5\uda2f\udd00\ud8c6\udfdf\ud830\udce9\ud98e\udc88\uda54\udc78\ud908\udd7a\udb6b\ude77\udada\ude27\ud995\udd71\uda94\ude12\ud9f0\udfd2\udaa6\udf7b\udbbd\udd90\ud8e4\ude40\ud895\udcf4", "\u53a8\u4050\u80e4\u857e\u745a\u8067\u6e84\u7c64\u4b25\u16a2\ua706\ud1b2\uc8a4\u9593\u8f7c\u7fd9\u557e\u322d", "\udb7b\udc31\ud955\udf04\u94e0\ud8c4\udd66\udb71\udf0f\uda29\udfb9\ud9f2\udc90\udb72\udf6e\ud9f0\uddb4\ud8d4\udc91\udbb9\ude1b\ud9b7\udee5\udbc9\ude4d\ud8ae\udc25\uda62\udcf7\udad8\ude88",
        24, 58911, -1679805096, 5967315718463601048L, 55682L, true, true, (char) 11414, (char) 64213,
        Double.longBitsToDouble(0x3fc3c932d22352e0L), Double.longBitsToDouble(0x3fe247fc2738f924L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 4, 0, 0, "\udba1\ude11", "\u3e00\u5df0", "\udaaa\udd12\uda4e\ude21\udbc4\udfde\ud845\udfb8\uda52\udc8a\uda10\udcec\udbd7\udf9c\000\udada\uddef\udb3b\udd94\ud8ed\udcff\u6e91\ud844\udc6e\udbc1\uddeb\udba6\udf26\ud891\udefe\ud96c\udfb7",
        25, 99938, 0, 8638134984432827852L, -78645L, false, true, (char) 16037, (char) 26431,
        Double.longBitsToDouble(0x3fe4eca89a2a9a13L), Double.longBitsToDouble(0x3fef07f3d47d3c21L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.std.FromStringDeserializer|_deserializeFromEmptyString||fac:com.fasterxml.jackson.databind.deser.std.FromStringDeserializer:findDeserializer:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.FromStringDeserializer|_deserialize|java.lang.String,com.fasterxml.jackson.databind.DeserializationContext|fac:com.fasterxml.jackson.databind.deser.std.FromStringDeserializer:findDeserializer:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.FromStringDeserializer|_deserializeEmbedded|java.lang.Object,com.fasterxml.jackson.databind.DeserializationContext|fac:com.fasterxml.jackson.databind.deser.std.FromStringDeserializer:findDeserializer:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.FromStringDeserializer|deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|fac:com.fasterxml.jackson.databind.deser.std.FromStringDeserializer:findDeserializer:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.FromStringDeserializer|findDeserializer|java.lang.Class|static",
    "M|com.fasterxml.jackson.databind.deser.std.FromStringDeserializer|types||static",
    "M|com.fasterxml.jackson.databind.deser.std.FromStringDeserializer|_deserializeFromEmptyString||fac:com.fasterxml.jackson.databind.deser.std.FromStringDeserializer:findDeserializer:java.lang.Class",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
