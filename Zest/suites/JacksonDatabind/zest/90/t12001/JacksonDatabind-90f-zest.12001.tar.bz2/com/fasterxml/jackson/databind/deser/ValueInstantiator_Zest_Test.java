package com.fasterxml.jackson.databind.deser;
import org.junit.Test;
import static org.junit.Assert.*;
public class ValueInstantiator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\012",
        Z.run(T, 1, 11, 4, 14, "\udb17\udf58\ud9c0\udc73\udb37\ude97\uda56\udf76", "\ua988\u76d4\u5335\u83ac\u3418\u00ca\u588a\u5f19\ud78c", "\uda50\udec9\ud8b4\udebf\udacb\udd24\ud99c\udfd1\udb69\udfb4\udac4\udcdc\u82eb\ud935\ude26\ud9a8\udcf6\ud810\udccd",
        19, 63484, -1700046828, -3598796588877713983L, -90773L, true, true, (char) 25825, (char) 39150,
        Double.longBitsToDouble(0x3fe8abb6d57d09e2L), Double.longBitsToDouble(0x3fed0de391f27c6eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\012",
        Z.run(T, 1, 11, 4, 14, "\udb17\udf58\ud98b\udc72\udb37\ude97\uda56\udf76", "\ua988\u76d4\u5335\u83ac\u3418\u00ca\u588a\u5f19\ud78c", "\uda50\udec9\ud8b4\udebf\udacb\udd24\ud99c\udfd1\udb69\udfb4\udac4\udcdc\u82eb\ud935\ude26\ud9a8\udcf6\uda9b\udd0d",
        19, -1000, 0, -3602879702616871487L, -90773L, true, true, (char) 25825, (char) 39150,
        Double.longBitsToDouble(0x3fe8abb6d57d09e2L), Double.longBitsToDouble(0x3ebc880000000000L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 10, 4, "\udb17\udf58\ud9c0\udc73\udb37\ude97\uda56\udf76\udb35\uddce\ud9c4\udc57\ud89e\udcab\udb36\udf9c\ud845\udf68\ud871\udc0c\ud82e\udeb5\udaa3\udf65", "\ud78c\u7ef8", "\ud8b4\udebf\udacb\udd24\ud99c\udfd1\udb69\udfb4\udac4\udcdc",
        37, 8572, 191772746, -3572309187188953323L, 2975L, false, true, (char) 27650, (char) 16052,
        Double.longBitsToDouble(0x3fbfeb18b80a8f68L), Double.longBitsToDouble(0x3fe8abb6d57d09e2L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 4, 14, "\000\000\ud94e\udc06", "\u2af7", "\ud845\udf68\ud871\udc0c\ud82e\udeb5\udaa3\udf65\udbdc\udcde\udb34\ude50\ud8fb\udf6f\ud94b\udd19\u22b5\uda50\udec9\udbd5\udfb0\udacb\udd24\ud99c\udfd1\000\udac4\udc58\u82eb\ud935\ude26\ud9a8\udcf6\udac2\udcc6\uda26\udd4a\ud8e9\udc25\ud87a\uddfd\udb62\udd92\ud84c\ude78\udae8\udc2d\ud831\udf93\013\udbe9\udcd3\u4701",
        45, -875, 2087627681, 8627878679957663239L, -39963L, true, true, (char) 29650, (char) 14346,
        Double.longBitsToDouble(0x3fee90bb77760526L), Double.longBitsToDouble(0x3fbdde6680be1160L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 4, 16, "\ud969\udd7d\ud9c0\udc73\udb37\ude97\uda56\udf76\udb35\uddce\ud982\udd57\udbca\udfbe", "\u10ad\u3418\u00ca", "\ud8fb\udf6f\ud94b\udd19",
        6, 7205, 335255910, 9014322776897091450L, -15644L, true, true, (char) 55265, (char) 62745,
        Double.longBitsToDouble(0x3fedc85b7790ce6cL), Double.longBitsToDouble(0x3fba276f00a194e8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 4, 14, "\udb17\udf58\ud9c0\udc73", "\uc2a9\u6d06\ua988\u76d4\u5335", "\udaa3\udf65\udbdc\udcde\udb34\ude50\ud8fb\udf6f\ud94b\udd19\u22b5\uda50\udec9\ud8b4\udebf\udacb\udd24\ud99c\udfd1\udb69\udfb4\udac4\udcdc",
        37, 8572, 191772746, -3572309187188953323L, 2975L, false, true, (char) 27650, (char) 54706,
        Double.longBitsToDouble(0x3fbfeb18b80a8f68L), Double.longBitsToDouble(0x3fe8abb6d57d09e2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 3, 13, "\udac7\udcdd\ud9c0\udc73\udb5b\ude0b\uda56\udf76\udb35\uddce\ud9c4\udc57\udb5c\udcaa", "\ud5dc\uc00b\uc022\ua80c\u5f19\ud78c\u7ef8\u08b8", "\udbd2\udc54\udba9\udc48\udb69\udf3b",
        0, 95071, -1127281380, 823657671502371769L, -30759L, false, false, (char) 7229, (char) 10960,
        Double.longBitsToDouble(0x3fbe74a02eae4290L), Double.longBitsToDouble(0x3fc29319e1feb068L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\012",
        Z.run(T, 1, 10, 4, 14, "\ud878\ude29\000\udb37\ude51", "\000\ua918\u76d4\u0252\u83ac\uc4fb", "\udafd\udf5d\000\ud926\udf72\u22b5\uda50\udec9\ud8b4\udebf\udacb\udd24\uae7a\000\000\ud94a\udedf",
        20, 73672, -831743047, -7080521639810760676L, -2098L, true, true, (char) 54782, (char) 27650,
        Double.longBitsToDouble(0x3fd0b3ca80ff58c4L), Double.longBitsToDouble(0x3f347b5800000000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\012",
        Z.run(T, 1, 0, 2, 14, "\udb17\udf58\ud9c0\udc73\udb37\ude97\uda56\udf76", "\ua988\u76d4\u5335\u83ac\u3418\u00ca\u588a\u5f19\ud78c", "\uda50\udec9\ud8b4\udebf\udacb\udd24\ud82b\udc19\udb54\ude7a\udac4\udcdc\u82eb\udae1\udf40\ud9a8\udd97\ud810\udccd",
        19, 63484, -1700046828, -3598796588877713983L, -90773L, true, true, (char) 25825, (char) 39150,
        Double.longBitsToDouble(0x3fe8abb6d57d09e2L), Double.longBitsToDouble(0x3fed0de391f27c6eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 1, 14, "\udb17\udf58\ud9c0\udc73\udb37\ude97\ud926\udda9", "\ua988\u76d4\u3e1e", "\uda8e\udf7a\udbdc\udcf0\udb34\ude50\ud8fb\udf6f\ud94b\udd19\u22b5\udaa7\udf3b\udaeb\uddeb\udaa4\ude30\ud99c\udfd1\udb69\udfb4\udac4\udcdc",
        37, 8572, 191772746, -3572309187188953323L, 2975L, false, true, (char) 27650, (char) 54706,
        Double.longBitsToDouble(0x3fbfeb18b80a8f68L), Double.longBitsToDouble(0x3fe8abb6d57d09e2L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\012",
        Z.run(T, 2, 11, 4, 14, "\ud991\udce2\ud9b4\udd36\udb37\udf29\ud8cd\udf2c", "\ua988\u76d4\u8c19\ua0a7\u33a7\u00ca\u588a\u5f19\ud78c", "\uda50\udec9\ud8b4\udebf\udacb\udd24\ud99c\udfd1\udb69\udfb4\udac4\udcdc\u82eb\ud935\ude26\udb0d\udf69\ud805\udeae",
        39, 63484, -1185250028, -3598877467406864959L, -83087L, true, true, (char) 25825, (char) 39150,
        Double.longBitsToDouble(0x3fe8abb6d57d09e2L), Double.longBitsToDouble(0x3fed0de391f27c6eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 14, "\udb17\udf58\ud9c0\udc73\udb37\ude97\uda56\udf76", "\ua988\ua346\u5335\u83ac\u1522\u45ca\ub6fe\u5f19\u6b1a\u20dc\u4fd4\uc70b\ube4b", "\udb69\udfb4\udac4\udcdc\u82eb\ud935\ude26\ud9a8\udcf6",
        3, 59623, 849171484, -7301645528766447214L, -78480L, true, false, (char) 54706, (char) 25825,
        Double.longBitsToDouble(0x3fea428f681125d8L), Double.longBitsToDouble(0x3fe5ec7c0b2a14beL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 7, 5, "\udb17\udf58\ud9c0\udc73\udb37\ude97\uda56\udf76\udb35\uddce\ud9c4\udc57\udb51\udda4\u9b15\udab1\udd3d\ud88d\udd17", "\u415b\u5eec\ud78c\u7ef8\u3585\u7f07\u34f3\uce64\u21e7\uc6da\u745f\ub385\uba79\u25d6\u10f7\u0a9f\u1819\ucffa\u7660\u4adb\u5570\u479c\u924f\u72d2\u5bde\u56cc\u3d6c\u90c3\ucd20\u0322\u9f69\u9dcc\ubcbb\ucb85\u3265\u88e4\u05d8\u06fc", "\ud8c5\uddc1\udbfc\udc5c\ud995\udf78\uda28\ude02\uda99\udea5\ud881\ude3e\udb6f\ude72\ud9e4\udf9e\ud8c4\udffb\uda2a\udf00\udb27\ude7c\uda58\udd30\uda7a\ude99\ud886\udd0b\uda91\ude99\ud955\udff9\udb75\udd81\ud845\udc7a\udb53\udf44\ud8a0\udfb9\udb76\udc7f\ud9cf\udd77\ud9c7\ude84\udaa2\uded6\udb48\udd23",
        48, 52185, 912576840, -511858084046959279L, -76887L, false, false, (char) 28947, (char) 63424,
        Double.longBitsToDouble(0x3fe9a31e5baf3b55L), Double.longBitsToDouble(0x3fd7f56b9c7f47aeL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 2, 14, "\udb17\udf58\udad4\udc7d\ud85b\uded1\ud96b\udc61", "\ua2dd\u6fef\u5335\u83ac\u46ef\uae81\u4e38\uc193", "\ud8a8\udeda\udbe3\udef6\ud8c5\udca9\udb92\udf27\uda6b\udc3d\uda99\udd00\udae4\udc8c\u82eb\ud935\ude6f\udb67\uddd6\ud957\udd91\udb09\udc75",
        39, 85172, -45514350, -5400258226267154731L, 70251L, false, false, (char) 32494, (char) 7542,
        Double.longBitsToDouble(0x3fd8a29f7a8378e4L), Double.longBitsToDouble(0x3fdca74e006c5490L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 6, 3, "\uda52\udc95\uda06\uded6\ud811\udf3f\udab9\udf22", "\u4f3d\u76d4\u5335\u83ac\u3418\u00ca\u588a\u5f19", "\u22b5\uda50\udec9\ud8b4\udebf",
        13, 19474, -2038565154, -799026626157998627L, 16662L, true, true, (char) 48513, (char) 61912,
        Double.longBitsToDouble(0x3f94329d32535560L), Double.longBitsToDouble(0x3fdc1ce0e7e1aa1cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 0, 16, "\udb17\udf58\ud9c0\udc73\udb37\ude97\uda56\udf76", "\ua988\ud6dd\u431d\u8359\u3418\u00ca\u588a\u5f19\ud78c", "\uda50\udec9\ud8b4\udebf\udacb\udd24\ud99c\udfd1\udb69\udfb4\udac4\udcdc\u82eb\ud935\ude26\ud9a8\udcf6",
        41, 59791, 849171484, -7301645528766447214L, -78480L, true, false, (char) 54706, (char) 25825,
        Double.longBitsToDouble(0x3fe00a8f6b1576daL), Double.longBitsToDouble(0x3fd7d09e274378e4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 13, 11, "\udb17\udf58\ud99f\ude63\udabe\udfe9\uda86\uddfc", "\ua988\u76d4\u5335\u83ac\uc676\u1545\ub88a\u5f19\ud78c", "\uda50\udec9\udbe1\udffe\udb92\udf62\ud997\udd4a\udb69\udfb4\udac1\udea8\ud864\ude50\ud84a\udd7e\ud9a8\udd15\ud810\udccd",
        19, 63484, -1700046828, -3598796587490906687L, 49377L, true, true, (char) 10735, (char) 16223,
        Double.longBitsToDouble(0x3fed0de391f27c6eL), Double.longBitsToDouble(0x3fe0bf17a6dd0b9aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\012",
        Z.run(T, 2, 11, 4, 14, "\udb17\udf58\uda53\udefd\udb37\ude97\udbb8\udeab", "\u38f0\u96a0\u4df9\u7af1\u3418\u00ca\u16fb\u5e52\u2b0f\ua976\u50f0", "\udacb\udd24\udb65\udeda\udb69\udee4\udac4\udcdc\u82eb\ud935\ude26\ud9a8\udcf6\ud810\udccd\uda73\udf60",
        16, 89344, -1230194532, -3094336352863933456L, 70251L, true, false, (char) 52967, (char) 54604,
        Double.longBitsToDouble(0x3fe837eebbd1ebf4L), Double.longBitsToDouble(0x3fecd608a3466f91L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 15, 3, "\udb17\udf58\ud9c0\udc73\udb37\ude97\uda56\udf76\udb35\uddce\ud9c4\udc57\ud89e\udcab\udb36\udf9c\ud845\udf68\ud871\udc0c\ud82e\udeb5\udaa3\udf65", "\u1394\u7ef8", "\udaf0\udc58\uda8a\udc36\ud99d\udc0e\udb69\udfb4\udac4\udcdc",
        37, 7692, 191772700, -3572309187188953323L, 59011L, false, true, (char) 27650, (char) 16052,
        Double.longBitsToDouble(0x3fbfeb18a80a8f68L), Double.longBitsToDouble(0x3fe88e32d7843cf6L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\012",
        Z.run(T, 2, 0, 10, 4, "\udb17\udf58\ud9c0\udc73\udb37\ude97\uda56\udf76\u230d\udb3b\udd1a\udbe1\ude2e\ud8af\ude6c\ud869\udf64\ud871\udc0c\ud8ac\udeb4\udaa3\udf65", "\u4312\u3c46", "\ud8b4\udf13\udba5\udebd\ud899\uddce\ud9a6\udcae\uda4a\ude18",
        34, 16017, 191772746, -3572309187188953323L, -40208L, false, true, (char) 15312, (char) 33022,
        Double.longBitsToDouble(0x3f868fee42e96a40L), Double.longBitsToDouble(0x3fca758c5c0547b4L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 5, "\uda24\udc3a\udbe4\udd0a\udb5d\udc48\udab3\udf23\ud846\udf39\u91b7\ud9cb\uddb2", "\u736e\u8790\u2302", "\ud8f8\udd29\ud94b\udd19\u22b5",
        31, 67177, 2098852971, 7251067503606887363L, 69661L, false, false, (char) 34562, (char) 22134,
        Double.longBitsToDouble(0x3fd70ce3894bbfc4L), Double.longBitsToDouble(0x3fd53df17865cda0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 14, 15, "\udb17\udf58\ud9c0\udc73", "\uc2a9\u6d06\ub616\u8686\u4466", "\ud8fa\udc39\udb94\udc82\udb12\udcff\ud8fb\udf75\ud94b\udd19\u22b5\uda50\udec9\ud9ae\udfd0\udacb\udd24\ud99c\udfd1\udb67\udd51\u7e57",
        10, 27307, 191772746, 7358208583302917256L, 24866L, false, true, (char) 15312, (char) 33022,
        Double.longBitsToDouble(0x3fd3b89bc976f180L), Double.longBitsToDouble(0x3fd52d8fd3bf7916L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\012",
        Z.run(T, 2, 16, 0, 10, "\ud878\ude29\000\udb37\ude51\uda56\udf76\ud93b\udd52\udbec\udf7b\ud8b0\udf21\uda7b\udd9c\udbe8\udd59\ud871\udc0c\udba6\udff1\udb64\udf28\udbdc\udd64\udafd\udf5d\000\ud926\udf72\u22b5\uda50\udec9\ud8b4\udebf\udacb\udd24\uae7a\000\000\ud81f\udfcb\udab7\uddc7\ud9d8\udcae\udaa3\udf76\ud8a1\ude38\uda39\udfcf\ud8e4\ude1b\ud9fd\udea0\ud84c\udf39\ud9c0\udcef\udb0c\ude73\uda0b\udc14\u5d53\000\ud971\udce1\udbf3\ude3a\uda84\udeaf\ud92c\udd0b\udadf\ude4c\ud8bf\udeb5\ufb0f\udb48\udca6", "\u9f16\u8dab", "\ud941\udc72\u7507\ud894\udf85\ud963\udf28\udbbf\udcbc\udabc\udda0\u599d\udaf8\udc37\udbdc\udf06\ud974\udf45",
        50, 27908, 501378611, 1865871210985794980L, -13860L, false, false, (char) 40917, (char) 31913,
        Double.longBitsToDouble(0x3fe8a11cb8d05296L), Double.longBitsToDouble(0x3fd40c2bf427fcf2L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 12, 0, "\ud91b\udeda\ud91b\udf4b\udbd1\udefc\udb16\udfe0\u08a4\ud895\ude45\ud8b1\udc6e\uda5e\udeb1", "\u99c9\u541a\u589c\u48d2\u9e8f\ua350\u5073\u54f4", "\ud8a1\udf3f\ud94b\ude8e\ud88a\udc00\uda3a\udf2e\ud935\ude3f\uda57\udc4e\u2e9b\ud944\udfc8\ud971\udd40\ud8e4\ude1b\udb80\ude28\ud97b\uded3",
        -1, 13635, -1402824437, 5903453295216045569L, -26870L, true, true, (char) 55300, (char) 4509,
        Double.longBitsToDouble(0x3fd3bb42cfe3697cL), Double.longBitsToDouble(0x3fe937ea13df2a90L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 7, 5, "", "\u5cb3", "\ud9bb\udf5c\udb51\udda4\u9b15\udab1\udd3d\ud88d\udd17\ud82e\udeb5",
        27, 85411, 2097142470, 8708528260750545319L, 28734L, false, true, (char) 711, (char) 55265,
        Double.longBitsToDouble(0x3fb2af33ddc85b70L), Double.longBitsToDouble(0x3f95ce6c00000000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:@?\012",
        Z.run(T, 1, 10, 4, 14, "\udb17\udf58\ud9c0\udc73\udb37\ude97\uda56\udf76", "\ua988\u76d4\u5335\u83ac\u3418\u00ca\u588a\u5f19\ud78c\u7ef8\u4fd4\uc70b\ube4b\ua4ea\u21e7\uc6da\u745f", "\udbd4\udfdc\ud813\udc60\uda26\udd4a\uda4d\udf17\ud8e4\ude1b\ud9fd\udea0",
        -2, 58744, 1017652235, -6025085077570078593L, -14773L, true, true, (char) 14611, (char) 56928,
        Double.longBitsToDouble(0x3fd80c49160d8054L), Double.longBitsToDouble(0x3fea79c7c07aed7bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.ValueInstantiator|canInstantiate||new:com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.StdValueInstantiator|canInstantiate||new:com.fasterxml.jackson.databind.deser.std.StdValueInstantiator:com.fasterxml.jackson.databind.deser.std.StdValueInstantiator",
    "M|com.fasterxml.jackson.databind.deser.ValueInstantiator|_createFromStringFallbacks|com.fasterxml.jackson.databind.DeserializationContext,java.lang.String|new:com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.ValueInstantiator|canCreateFromBoolean||new:com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.ValueInstantiator|canCreateFromDouble||new:com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.ValueInstantiator|canCreateFromInt||new:com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.ValueInstantiator|canCreateFromLong||new:com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.ValueInstantiator|canCreateFromObjectWith||new:com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.ValueInstantiator|canCreateFromString||new:com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.ValueInstantiator|canCreateUsingArrayDelegate||new:com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.ValueInstantiator|canCreateUsingDefault||new:com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.ValueInstantiator|canCreateUsingDelegate||new:com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.ValueInstantiator|createFromBoolean|com.fasterxml.jackson.databind.DeserializationContext,boolean|new:com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.ValueInstantiator|createFromDouble|com.fasterxml.jackson.databind.DeserializationContext,double|new:com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.ValueInstantiator|createFromInt|com.fasterxml.jackson.databind.DeserializationContext,int|new:com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.ValueInstantiator|createFromLong|com.fasterxml.jackson.databind.DeserializationContext,long|new:com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.ValueInstantiator|canInstantiate||new:com.fasterxml.jackson.databind.deser.ValueInstantiator$Base:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.StdValueInstantiator|canInstantiate||new:com.fasterxml.jackson.databind.deser.std.StdValueInstantiator:com.fasterxml.jackson.databind.deser.std.StdValueInstantiator",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
