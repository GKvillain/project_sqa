package com.fasterxml.jackson.databind.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class StdDateFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\012",
        Z.run(T, 1, 7, 7, 6, "\udb4b\udd8a\udaef\udc8f\udb3e\udc38", "\ucc3c\u3dd1\u75c3\u02bf\u35db", "\ud8a3\udf6e\ud9bd\udd0d\udb24\ude10\uda9e\ude4e\u9c50\ud916\udcdc",
        19, 30360, -650182869, -3574284072988304419L, 44171L, true, true, (char) 31512, (char) 64149,
        Double.longBitsToDouble(0x3fc7113a00942e74L), Double.longBitsToDouble(0x3fc41ca70f3fc1fcL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\012",
        Z.run(T, 1, 7, 7, 6, "\udb4b\udd8a\udaef\udc8f\udb3e\udc38", "\ucc3c\u3dd1\u75c3\u02bf\u35db", "\ud8a3\udf6e\ud9bd\udd0d\udb24\ude10\uda9e\ude4e\u9c50\ud916\udcdc",
        19, 30360, -650182869, 2680958528008461168L, 44171L, true, true, (char) 31512, (char) 64149,
        Double.longBitsToDouble(0x3fc7113a00942e74L), Double.longBitsToDouble(0x3fc41ca70f3fc1fcL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 6, "\udb4b\udd8a\udaef\udc8f\ubf91", "\ucc3c\ua7d9\000\000\000", "\u00df",
        -5, -1000, -1009057792, -8315321544322972110L, -2952L, true, true, (char) 28881, (char) 7234,
        Double.longBitsToDouble(0x3f45e65147167c00L), Double.longBitsToDouble(0x3fedc0c7a4d5a2a1L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 12, 9, "\udb4b\udd2f\udaef\udc8f\udb3e\udc38", "\u5c5a\u6fb0\ucc11\uafc0\u95c1\u0468", "\ud9bd\udd0d\uda24\udcab\uda6f\udfbf\udabf\udd9a\ud999\ude31\ud803\udfe6\udaa1\udd79\ud92f\udce2\uda8d\udca6\udbbf\udf19\udad8\udeb3\udb09\udd9e\ud97d\ude37\ud9a2\udfcb",
        32, 65609, -690956715, 836931448701745189L, -54802L, false, false, (char) 48868, (char) 49637,
        Double.longBitsToDouble(0x3fe359d14d937a38L), Double.longBitsToDouble(0x3fe45cd376de21bdL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\udb4b\udd8a\udaef\udc8f\ud8b4\udc33", "\ucc3c\u3dd1\u75c3\u02bf\u35db", "\ud8a3\udf6e\ud9bd\udd0d\udb24\ude10\uda9e\ude4e\u9c50\ud916\udcdc",
        19, 30360, -650182869, -3574284072988304419L, 44171L, false, false, (char) 31466, (char) 64149,
        Double.longBitsToDouble(0x3fc7113a00942e74L), Double.longBitsToDouble(0x3fc41ca70f3fc1fcL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 9, 2, "\udb4b\udd8a\udac9\ude2f", "\u906b\ucc3c\u3dd1\u75c3\u02bf\u0c2f\u0447", "\ud9bd\udd0d\udab6\udf28\udb52\udde0\ud825\udfd2\ud916\udcdc\ud803\udfe6\udb9e\udd1d\ud92f\udd8a\uda8d\udca6\udbbf\udf19\ud918\udc71\ud9e3\uddc9\ud97d\ude37\ud9a2\udfcb",
        27, 52434, -1982802347, 836931448701745189L, -10863L, true, true, (char) 17329, (char) 7223,
        Double.longBitsToDouble(0x3fdebed7ceda236cL), Double.longBitsToDouble(0x3fe0e372e359a585L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 7, 6, "\udb15\udd2b\uda58\udd44\udb3e\udc38", "\ucc3c\u3dd1\u75c3\u02bf\u35db", "\ud983\udf1b\ud9e6\udd48\udb2e\ude5f\uda80\ude79\udbaf\ude1a\ud916\udcdc",
        19, 74944, -650182869, -3574284072988304419L, 60790L, true, false, (char) 60040, (char) 33730,
        Double.longBitsToDouble(0x3fde80038f9fe0feL), Double.longBitsToDouble(0x3fe6fb1bb0f5b2cbL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\012",
        Z.run(T, 1, 4, 7, 6, "\udb4b\udd8a\ud9ff\udd17\udb3e\udc38", "\ucc3c\u8b55\ubdbd\u45ad\u7553", "\ud8a3\udf6e\ud9bd\udd0d\uda34\ude98\uda9e\ude4a\u9550\ud916\udcdc\ud803\udfe6\udaa1\udd79\ud92f\udce2\udb1c\udf41\udbbf\udf19\ud8b9\udf53\ud9e3\ude60\ud97d\ude37\ud9a2\udfcb\ud8b0\uddd0\u0da4\ud877\udf95\udb50\ude6a\udbf5\ude90\ud845\udfb6\uda14\udca3\ud85f\ude0a",
        43, 3569, 1740950106, -4125805344237840726L, -67736L, false, false, (char) 39964, (char) 64242,
        Double.longBitsToDouble(0x3fe0849c90b489aaL), Double.longBitsToDouble(0x3fdd92d6b00016f4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=sun.util.calendar.ZoneInfo:sun.util.calendar.ZoneInfo[id=\"GMT\",offset=0,dstSavings=0,useDaylight=false,transitions=0,lastRule=null]\012",
        Z.run(T, 1, 6, 7, 6, "\uda5a\ude4a\udaef\udcc4\udb3e\udc38", "\u59c2\u5b8e\u74ec\u3d69\u07df", "\ud9ac\udfeb\udb99\udddc\ubedb\uda9e\ude0b\u9c50\ud916\udcdc\ua9e6\udaa1\udd79\ud92f\udce2\uda8d\udca6\ud81d\udd28",
        57, 48225, -1573774240, 6744591056795794952L, -45131L, false, false, (char) 28839, (char) 32459,
        Double.longBitsToDouble(0x3fee7d88474bd2a1L), Double.longBitsToDouble(0x3fd077f421185baaL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 14, 1, "\udb24\udf9d\ud892\ude57\udb3e\udc38", "\ucc3c\u3dd1\u75c3\u02bf\u35db", "\ud8a3\udf6e\ud9bd\udd0d\udb24\ude10\uda9e\ude4e\u9c50\ud916\udcdc\ud803\udfe6\udba0\ude7a\u2ab1\uda8d\udca6",
        47, 18818, 418694225, -6727819599931913003L, 2890L, true, false, (char) 40584, (char) 20076,
        Double.longBitsToDouble(0x3fc41ca70f3fc13cL), Double.longBitsToDouble(0x3fc833115d0d7918L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 14, "\ud9d5\udc25\udaef\udc8f\ubf4a\ud9fb\uddfc\ud928\udd90\ud985\udd1f\ua7d9\ud957\udc56\ud995\ude38\ud8b1\udeb5\uda11\udce0\ud957\udc2b\u00df\000\000\ud83d\udf11\uda16\udc3f\ud916\udcd5\ud812\udca9\udaa1\udd79\udb63\udf9c\udbb6\udf7c\udbd9\uddbf\ud8df\udc8f\ud9e3\uddc9\ud97d\ude37", "\ub32d\ubc58\uba3c\u9910\u4490\u14d5\u1c9b\u9671\u80d2\u23c6\ub8b1\u0e67\u4280\ub365\ua685\ud2f7\u7af7\ubc02\u20a0\u6746\ub482\u06c1\u2fa0\u5602\u1ebf", "\udb9c\udcd8\udafd\udee4\ud96b\udf71\udb0f\udef4\udaf3\ude5a",
        19, 40688, -128494898, -597074879506782538L, 84762L, false, false, (char) 5061, (char) 7435,
        Double.longBitsToDouble(0x3fe3920bb7ae2cb1L), Double.longBitsToDouble(0x3fc61c7dd1f43710L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\012",
        Z.run(T, 1, 12, 7, 6, "\udb4b\udd8a\udaef\udc8f\ubf91", "\ucc3c\ua7d9\000\000\000", "\u00df",
        -5, -1000, -1009057792, -8315321544322972110L, -2952L, true, true, (char) 28881, (char) 7234,
        Double.longBitsToDouble(0x3f45e65147167c00L), Double.longBitsToDouble(0x3fedc0c7a4d5a2a1L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 7, 6, "\ud968\udc79\ud92f\udfaf\udab8\udf96", "\uc97c\ua7d9\000\000\u2cbd", "\u00df",
        -5, 30304, -1020476014, -8315321544322972110L, -68488L, true, false, (char) 61883, (char) 7354,
        Double.longBitsToDouble(0x3f45e65147167c00L), Double.longBitsToDouble(0x3fedc0c7a4d5a2a1L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 13, 6, "\udb4b\udd8a\udaef\udc8f\ubf91", "\ucc3c\ua7d9\000\000\000", "\udba2\udf14",
        57, -778, -1009057792, -8315321544322972110L, -2952L, true, true, (char) 28881, (char) 7234,
        Double.longBitsToDouble(0x3f45e65147167c00L), Double.longBitsToDouble(0x3fedc0c7a4aea2a1L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 13, 7, 4, "\ud88f\udd42\ud8a5\udd9a\uda0d\udd1f\ud9fb\uddfc", "\ua7d9\000\000\000\000\u736f\u00df\000\u22a6\u77d9\u930c\u0ae8\u1a65\u3219\u642a\u580b\u850a\u6cb6", "\ua0f0\ud854\uddf1\u4a1b",
        44, 54196, 778286762, 2230071236597645841L, 92205L, false, false, (char) 23811, (char) 57601,
        Double.longBitsToDouble(0x3fdf961952f94632L), Double.longBitsToDouble(0x3fc330a47d252c50L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\012",
        Z.run(T, 1, 10, 7, 6, "\ud9f5\udef5\udbf5\uddcc\ud91f\udcb3\ud996\uddab\ud8a3\udc14\ud960\udc2c\udbc1\udebc\ud95b\udcbe\udad3\udd87\udb53\udf84\ud9c4\udc08\ud9c7\udc44\udbac\udf30[\u63f3\uda69\udc74\u9c50\ud891\ude39\ud803\udf19\ud839\uddc5\ud80b\udf45\ud828\udf57\udbbf\udf19\uda63\udcd4\ud9e3\ude1a\ud97c\udd37\udbf9\udee2\udb91\udf00\uda09\udcd3\ud972\udfca\udbe8\udc35\udbe5\ude76\udbef\uddf5\ub11f\ud9ec\udf0d\ud8fc\ude28\udba4\udc7c\udbc8\uddde", "\u9516\ub6c2\ud4b3\uc4d8\u8e9d\u05ba\ud1d2\u6d0b\u50d1\ua8b2\u0771\u8dee\u7049", "\ud856\udf9b\ud93a\ude2f\ud94a\udfe1\ud92a\ude40",
        20, 72236, -1225205280, 212678084247559516L, -9523L, true, true, (char) 35358, (char) 7703,
        Double.longBitsToDouble(0x3fd6138f8154ea30L), Double.longBitsToDouble(0x3fe79856cc86b581L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=sun.util.calendar.ZoneInfo:sun.util.calendar.ZoneInfo[id=\"GMT\",offset=0,dstSavings=0,useDaylight=false,transitions=0,lastRule=null]\012",
        Z.run(T, 1, 6, 2, 6, "\uda24\udc29\ud90a\ude71\ubf91\ud9fb\uddfc\ud928\udd90\udb38\udcf7\ua7d9\u0088\u6c0d\uce74\u62bc", "\u4cfb\000\u50b7\u9257\u7656\u8ce6\ua165\u5e0b\u757f\ucbcd\u224f\ua79e\u540e\u08ed", "\uda76\udf1f\ud8f9\udfd3\uda8b\udf35\uda4a\udd03\ud8fd\udf1b\uda56\ude81\ud96c\udf0b\ud8d8\udc3f\ud9b1\udc65\ud99f\uddde\udb02\ude7e\ud8c0\udc19\ud896\ude5c\ud9b5\udcb5\u24f6\ud81e\udd09",
        30, 13423, -1549926469, -2898683472950746825L, -70109L, true, false, (char) 896, (char) 53343,
        Double.longBitsToDouble(0x3fea781521a5ab4fL), Double.longBitsToDouble(0x3fe2dd5b98a1e034L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 7, 6, "\udb4b\udd8a\udaef\udc8f\ubf91", "\ud2f3\u1d8a\u673e\u63d7\000", "\u00df\000\000",
        58, 6333, -1569061326, 4953334997183986456L, -34464L, true, false, (char) 5292, (char) 28534,
        Double.longBitsToDouble(0x3f74c3889e3c5000L), Double.longBitsToDouble(0x3fed5faa1d71d8feL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 12, 9, "\udb4b\udd2f\udafe\udc8f\udb3e\udc38", "\u5c5a\u6fb0\ucc11\uafc0\u95c1\u0468", "\ud9bd\udd0d\uda24\udcab\uda6f\udfbf\udabf\udd9a\ud999\ude31\ud803\udfe6\udaa1\udd79\ud92f\udce2\uda8d\udca6\udbbf\udf19\udad8\udeb3\udb09\udd9e\ud97d\ude37\ud9a2\udfcb",
        32, 65609, -690956715, 836931448709803045L, -54802L, false, false, (char) 48868, (char) 49637,
        Double.longBitsToDouble(0x3fe359d14d937a38L), Double.longBitsToDouble(0x3fe45cd376de21bdL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 12, 9, "\udb4b\udd2f\udaef\udc8f\udb3e\udc38", "\u4cc0\u6fb0\ucc11\uafc0\u95c1\u0468", "\ud9bd\udd0d\uda24\udcab\uda6f\udfbf\udabf\udd9a\udb1b\ude32\ud8c2\udee2\u9a7c\ud84c\udf30\uda7f\udd5f\udbc5\udf05\udad8\udeb3\udb09\udd9e\ud97d\ude37\ud9a2\udfcb",
        22, 13675, 1747390166, 859100808914169783L, -87826L, false, false, (char) 48868, (char) 49637,
        Double.longBitsToDouble(0x3fe359d14d937a38L), Double.longBitsToDouble(0x3feee4d376de21bdL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\012",
        Z.run(T, 1, 8, 12, 0, "\udb4b\udd2f\udaef\udc8f\udb3e\udc38", "\u7081\u2801\ua37a\u7a25\u9560\u0468", "\ud99e\udd0d\uda24\udcab\uda6f\udfbf\udbe2\ude75\uda81\udcfa\ud81f\udf67\uda86\udc00\udbfd\udfca\ud980\udf91\ud892\udd8f\udab6\ude03\udb09\udd9e\ud97d\ude37\ud9a2\udfcb",
        32, 65609, -690956715, -5046458515601621007L, -54802L, true, false, (char) 16703, (char) 49637,
        Double.longBitsToDouble(0x3fe359d14d937a38L), Double.longBitsToDouble(0x3fec5cd376de21bdL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US) |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\012",
        Z.run(T, 1, 2, 12, 9, "\udb4b\udd2f\udaee\udfee\udb3e\udc38", "\u5c5a\u6fb0\u48d0\u1082\u95c1\u0468", "\ud9aa\udfc0\uda24\udcab\uda6f\udfbf\udabf\udd9a\ud999\ude31\ud803\udfe6\udaa1\udd79\ud92f\udce2\uda8d\udca6\udbbf\udf19\udad8\udeb3\udb09\udd9e\ud97d\ude37\ud9a2\udfcb",
        32, 65609, -690956715, 836931448701745189L, -54802L, false, false, (char) 48868, (char) 49637,
        Double.longBitsToDouble(0x3fe359d14d937a38L), Double.longBitsToDouble(0x3fe45cd376de21bdL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 12, 0, "", "\000", "",
        11, -559, 0, 11370L, -100000L, false, false, (char) 56490, (char) 1670,
        Double.longBitsToDouble(0x3fb2e19598061800L), Double.longBitsToDouble(0x3fec51522bd9a549L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 0, "\udb4b\udd8a\udaef\udc8f\ud8b4\udc33\uda11\udca4\ud824\ude57\ud985\udd1f\udbfb\uddc1\udbd9\udce3\ud99c\udcbe\u9821\uda79\udc55\uda7f\udda5\ud8a3\udf6e\ud9bd\udd0d\udb24\ude10\uda9e\ude4e\u9c50\ud916\udcdc\ud803\udfe6\udaa1\udd79\ud92f\udce2\uda8d\udca6\udbbf\udf19\ud918\udc71\ud9e3\uddc9\ud97d\ude37\ud8b9\udcd7\uda08\udfff\ud97e\udf0d\ud931\udd93\ud8b8\udd67\udbf5\ude90\ud845\udfb6\udb7a\udef7\ud9f6\udc29\ud899\udfc1\ud976\udfeb\ud9ba\udf02", "\u0b6f\uc07f\u817c\u6294\u6e4a\u31ed\ua1a4\u3758\ub4a3\ub0dd\u5e65\u4d7e\uc7ef\u666e\ubf40", "\ud9aa\udca7\udb70\udcd9\udbf0\udf54\udbaf\udd8e\udbdc\udef8\uda94\udcb2\ud884\uddac\udaad\ude25",
        55, 96488, -995455297, 7761638014358442747L, 99023L, true, true, (char) 15654, (char) 33925,
        Double.longBitsToDouble(0x3fd136593abaa174L), Double.longBitsToDouble(0x3fe4a7ec5b80c355L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 0, 0, "\udb4b\udd8a\udaef\udc8f\ud8b4\udc33", "\ucc3c\u1390\uc607\u02bf\u35db", "\uda03\udee9\ud9f9\ude10\uda5b\udca5\udbcf\udfb8\udb72\udccc\ud99e\udfc1",
        2, 63168, -640088432, -3574284072988304419L, -75113L, true, false, (char) 28510, (char) 37,
        Double.longBitsToDouble(0x3fef577806552441L), Double.longBitsToDouble(0x3fe996a9021b7b6aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 0, 0, "\udb4b\udd8a\udaef\udc8f\ud8b4\udc33", "\ucc3c\u3dd1\u369e\u02bf\u35db", "\ud8a3\udf6e\ud9bd\udd0d\udb24\ude10\uda9e\ude4e\u9c50\ud916\udcdc",
        19, 30360, -650182869, -3574284072988304419L, 44171L, false, false, (char) 31466, (char) 64149,
        Double.longBitsToDouble(0x3fc7113a00942e74L), Double.longBitsToDouble(0x3fc41ca70f3fc1fcL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 14, 2, "\udb4b\udd8a\udac9\ude2f", "\u906b\ucc3c\u3dd1\u75c3\u02bf\u0c2f\u0447", "\ud9bd\udd0d\udab6\udf28\udb52\udde0\ud825\udfd2\ud916\udcdc\ud803\udfe6\udb9e\udd1d\ud92f\udd8a\uda8d\udca6\udbbf\udf19\ud918\udc71\ud9e3\uddc9\ud97d\ude37\ud9a2\udfcb",
        27, 52434, -1982802347, 836931448701745189L, -10863L, true, true, (char) 17329, (char) 7223,
        Double.longBitsToDouble(0x3fdebed7ceda236cL), Double.longBitsToDouble(0x3fe0e372e359a585L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\0121=java.text.SimpleDateFormat:@?\012",
        Z.run(T, 2, 8, 8, 1, "\udb9b\udcaa\ud9e5\ude8d\ud9dd\udc30", "\ucc3c\u4047\u7597\u02bf", "\udbd6\ude2b\ud8a3\udf6e\ud9bd\udd0d\udb24\ude10\uda9e\ude4e\u9c50\ud916\udcdc\ud803\udfe6\uda42\udfea\ud941\udece\uda6d\udfe9\u0618\ud9a1\udf6b\ud8da\ude70\uda8c\udd4c\ud964\udd11",
        31, 10356, -1982802259, -3232154377739944611L, -47825L, true, false, (char) 5813, (char) 16832,
        Double.longBitsToDouble(0x3fc0e362d30ebd5cL), Double.longBitsToDouble(0x3fedc04aae57e0f8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\0121=!java.text.ParseException\012",
        Z.run(T, 2, 8, 13, 0, "\udb24\udf9d\ud892\ude57\udb3e\udc38", "\ucc3c\ucd84\u6177\u1a3c\u35db\u0e31\u6bf2", "\udb24\ude10\uda9e\ude4e\u9c50\ud925\udcdc\ud803\udfe6\udba0\ude7a\u2ab1\uda8d\udca6\udbbf\udf19\ud918\udc71",
        35, 66432, 690343125, 3328701411375550954L, 91304L, false, true, (char) 17881, (char) 37918,
        Double.longBitsToDouble(0x3fa94c457435e460L), Double.longBitsToDouble(0x3fe9e783cf465b33L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 14, 1, "\udb24\udf9d\ud892\ude57\udb3e\udc38", "\ucc3c\u3dd1\u75c3\u02bf\u75db", "\u00db\ud9bd\udd0d\udb24\ude10\uda7e\udc3e\ud85b\ude04\udb66\udc16\u8541\udba0\ude7a\ud9fc\udcc8\uda6b\udd57",
        47, 18818, 418694225, -6727819599931913003L, 2890L, true, false, (char) 1161, (char) 20076,
        Double.longBitsToDouble(0x3fec573549372635L), Double.longBitsToDouble(0x3fe7e12bd4da7094L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 14, 1, "\ud80c\ude37\udb0a\udf8e\udb3e\udc38", "\ucc3c\u3dd1\u75c3\u02bf\u35db", "\ud8a3\udf6e\ud9bd\udc78\ud9c5\udc8c\u2603\u9c50\ud80d\udddb\ud91c\udc25\udba0\ude7a\u2ab1\uda8d\udca6",
        47, 18818, 418694225, -6727819599931913027L, 2890L, true, false, (char) 40584, (char) 20076,
        Double.longBitsToDouble(0x3fc41ca70f3fc13cL), Double.longBitsToDouble(0x3fc833115d0d7918L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 14, 1, "\udb24\udf9d\u2674\000", "\u44d5\u3cf8\u75c3\u02bf\ubf56", "\ud8a3\udf6e",
        6, 79390, -1009003046, -8315321544322972110L, 59768L, false, false, (char) 28910, (char) 59970,
        Double.longBitsToDouble(0x3fef157990000000L), Double.longBitsToDouble(0x3fedc0c7a4d5a2a1L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US) |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\0121=java.text.SimpleDateFormat:@?\012",
        Z.run(T, 2, 2, 5, 1, "\udb24\udf9d\ud892\ude57\udb3e\udc38", "\ucc3c\u3dd1\u75c3\u02bf\u35db", "\udafd\ude1b\ud96c\udf57\uda0c\udc05\uda8d\udfe5\udb12\udcf2\ud9f4\udd4a\ud916\ude3e\udb62\udc0d\u77fa\uda8d\udca6",
        47, 49002, -1683304847, -7088017654981241000L, 2890L, true, true, (char) 40584, (char) 20076,
        Double.longBitsToDouble(0x3fda0e53879fe0faL), Double.longBitsToDouble(0x3fd5d988aba54180L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 14, 1, "\u6759", "\000\ub877\ucc3c", "\000",
        -5, 30163, -1075404871, 1906726743776353451L, -34682L, true, true, (char) 154, (char) 16723,
        Double.longBitsToDouble(0x3f9800bd9f1417c0L), Double.longBitsToDouble(0x3fec9ecadbddce65L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 13, 7, 4, "\000", "\u4065\u906b\u44d5\000\000\000\000", "\u00df",
        -5, 64840, -579682099, 43360142984478720L, -100000L, false, false, (char) 25626, (char) 56641,
        Double.longBitsToDouble(0x3ea30f9fd3a00000L), Double.longBitsToDouble(0x3fc7031e93540000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\012",
        Z.run(T, 2, 12, 12, 6, "\ud9f5\udef5\udbf5\uddcc\ud91f\udcb3\ud996\uddab\ud8a3\udc14\ud960\udc2c\udbc1\udebc\ud95b\udcbe\udad3\udd87\udb53\udf84\ud9c4\udc08\ud9c7\udc44\udbac\udf30[\u63f3\uda69\udc74\udab7\udc77\ud891\uded8\ud803\udf19\udacb\ude2e\ud80b\udf45\ud828\udf57\udbbf\udf19\ud942\udc65\uda82\udcc6\ud97c\udd67\udbf9\udee2\udb91\udf00\uda09\udcd3\ud972\udfca\udbe8\udc35\udbe5\ude76\udbef\uddf5\ub11f\ud9ec\udf0d\ud8fc\ude28\ud9fe\udd6a\uda22\udd5b", "\u9516\ub6c2\ud4b3\uc4d8\u8e9d\u05ba\ud1d2\u62b3\u5332\u0196\u8781\u8dee\u7049", "\udaeb\udca4\ud93a\ude58\ud94a\udfe1\ud92a\ude40",
        20, 22740, 1387563353, 2285215368976145756L, -9523L, true, true, (char) 35358, (char) 7703,
        Double.longBitsToDouble(0x3fd6138f8154ea30L), Double.longBitsToDouble(0x3fe79856c8c97481L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 12, 9, "\udb4b\udd2f\udaef\udc8f\udb3e\udc38", "\u4cc0\u6fb0\ucc11\uafc0\u95c1\u0468", "\u00ab\ud99e\udccf\uda6f\udfbf\udabf\udd9a\udb1b\ude32\ud8c2\udee2\u9a7c\ud84c\udf30\uda7f\udd5f\udbc5\udf05\udad8\udeb3\udb09\udd9e\ud97d\ude37\ud9a2\udfcb",
        22, 13675, 1747386368, 859100808914169783L, -87826L, false, false, (char) 48868, (char) 49637,
        Double.longBitsToDouble(0x3fe359d14d937a38L), Double.longBitsToDouble(0x3feee4d376de21bdL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 9, "\udb4b\udd2f\udaef\udc8f\udb3e\udc38", "\u4cc0\u6fb0\ucc11\uafc0\u95c1\u0468", "\ud9bd\udd0d\uda24\udcab\uda6f\udfbf\udabf\udd9a\udb1b\ude32\ud8c2\udee2\u9a7c\ud84c\udf30\uda7f\udd5f\udbc5\udf05\udad8\udeb3\udb09\udd9e\ud97d\ude37\ud9a2\udfcb",
        22, 13675, 1747390166, 859100808914169783L, -87826L, false, false, (char) 48868, (char) 49637,
        Double.longBitsToDouble(0x3fe359d14d937a38L), Double.longBitsToDouble(0x3feee4d376de21bdL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 10, 8, "\udb4b\udd2f\udaef\udc8f\udb3e\udc38", "\u4cc0\u6fb0\u2c8d\uafc0\u95c1\u0468", "\ud9bd\udd0d\uda24\udcab\uda6f\udfbf\udabf\udd9a\udb1b\ude32\ud8c2\udee2\u9a7c\ud84c\udf30\uda7f\udd5f\udbc5\udf05\udad8\udeb3\udb09\udd9e\ud97d\ude37\ud9a2\udfcb",
        22, 13675, 1747390166, -4686551071126824264L, -87826L, false, false, (char) 48868, (char) 49637,
        Double.longBitsToDouble(0x3fe359d14d937a38L), Double.longBitsToDouble(0x3feee4d376de21bdL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 15, 4, "\udb4b\udd8a\udaef\udc8f\ud8b4\udc33\uda11\udca4\ud824\ude57\ud985\udd1f\udae6\udf59\udbd1\udc90\ud99c\udcbe\u9821\uda79\udc55\uda7f\udda5\ud8a3\udf6e\ud9bd\udd0d\udb24\ude10\uda9e\ude4e\u9c50\ud916\udcdc\ud803\udfe6\udaa1\udd79\ud92f\udce2\uda8d\udca6\udbbf\udf19\ud918\udc71\ud9e3\uddc9\ud958\udd98\ud8b9\udcd7\uda08\udfff\ud97e\udf0d\ud931\udd93\ud8b8\udd67\udbf5\ude90\ud845\udfb6\uda19\udf85\ud9f6\udc22\ud88f\udcc1\ud976\udfeb\ud9ba\udf02", "\u0b6f\uc07f\u817c\u6294\u6e4a\u31ed\ua1a4\u3758\ub4a3\ub0dd\u5e65\u4d7e\uc7ef\u666e\ubf40", "\ud9aa\udca7\udb70\udcd9\udbf0\udf54\udbaf\udd8e\udbdc\udef8\uda94\udcb2\ud884\uddac\udaad\ude25",
        55, 96488, -995455297, 7761638014358442747L, 99023L, true, true, (char) 15654, (char) 33925,
        Double.longBitsToDouble(0x3fd136593930a174L), Double.longBitsToDouble(0x3fe4a1116b80c355L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 9, "\udb4b\udd2f\udaef\udc8f\ud956\udfa5", "\u826b\u715f\ucc11\uafc0\u95c1\ua5e3\ua893~\u8990\u8f42\u6c02\u2536\u5821\uc004\u46d7\u2313", "\ua025\udb39\udc22\ud97d\ude37\udb1b\udc07\udb31\ude71\udbe5\udc3d\ud9f6\udd96\udbd0\udc98\ud982\udfc3\ud9fe\udc53\udb8c\uddbd\udb5a\udd85\ud91f\udde0\ud8d0\udd5a\ud922\ude5d\ud82a\uddcd\ud99f\uddd1\udb24\udd22\uda94\ude7c\udbf9\udfa8",
        -3, 9786, -1443287561, -1931430751290843575L, 91194L, true, false, (char) 12287, (char) 22916,
        Double.longBitsToDouble(0x3fea3af076372bd4L), Double.longBitsToDouble(0x3fd991e3e9bcb088L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 9, "\udb4b\udd2f\udaef\udc8f\udaaa\udd34\udb99\ude25\ud928\udd90\udb6c\udd16\udbd1\udfa1", "\u95c1", "\udb69\udf31\ud966\udec1\uda24\udcab\uda6f\udfbf\udabf\udd9a\udb1b\ude32",
        41, 74720, 1987398709, -3574256890140281911L, 45036L, false, true, (char) 28534, (char) 38810,
        Double.longBitsToDouble(0x3fe31c3dced6dbcbL), Double.longBitsToDouble(0x3fed13413fb70becL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 9, "\udb4b\udd2f\udaef\udc8f\udb3e\udc38", "\u4cc0\u6fb0\ucc11\uafc0\u95c1\u0468", "\ud9bd\udd0d\uda24\udcab\uda6f\udfbf\udabf\udd9a\udb1b\ude32\ud8c2\udee2\u9a7c",
        44, 21988, -1355664439, -6334638459001124492L, 44171L, true, false, (char) 22904, (char) 60065,
        Double.longBitsToDouble(0x3fed13413fb70becL), Double.longBitsToDouble(0x3feaa26ca072cd0fL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 9, "\udb4b\udd2f\u00af\udb3e\udc38", "\u4cc0\u6df7\ucc11\uafc0\u95c1\u0468", "\ud986\udd0d\u00d7\uda6f\udfbf\udabf\udd9a\u008a\ud8c2\ude09\u9a7c\udba1\udc3b\000\000\ud960\uded0\udb09\udd9e\ud97d\ude37\ud9a2\udfcb",
        15, 13675, 1747390166, 697086275328L, -87826L, false, false, (char) 48868, (char) 49637,
        Double.longBitsToDouble(0x3fe359d14d937a38L), Double.longBitsToDouble(0x3fcb934ddb7886f4L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\012",
        Z.run(T, 1, 7, 7, 2, "\ucd77\udaef\udc2f\udb3e\udc38", "\u1921\u3dd1\uc90f\u78ff\u881f", "\ud8a3\udf6e\ud9bd\udd0d\ud80a\ude09\uda9e\ude4e\u9c50\ud916\udcdc\ud803\udfe6\udaa1\udd79\ud92f\udce2\uda8d\udca6\udbbf\udf19\ud8a6\udd85\u8c22\uda99\ude3a\ud9a2\udf18\ud8fa\udc97\udbe9\ude0c\ud9b7\udf56\ud8b8\udd67\udbf5\ude90\ud845\udfb6",
        9, -174, 615937814, -47133867658387164L, -11161L, true, false, (char) 6102, (char) 1284,
        Double.longBitsToDouble(0x3fdf5cb7b83714d2L), Double.longBitsToDouble(0x3fe13a1a5a62f394L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 14, 0, "", "\000", "",
        53, 89656, 246, -1157627904L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e38000000000000L), Double.longBitsToDouble(0x3fe000000000a57aL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US) |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\0121=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US) |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\012",
        Z.run(T, 2, 2, 2, 1, "\udb24\udf9d\ud892\ude57\udb3e\udc38", "\ucc3c\u3dd1\u75c3\u02bf\u35db", "\ufb37\udb87\udffc\udb21\uddfd\uda9e\ude4e\u9c50\ud916\udcdc\ud803\udfe6\udba0\ude7a\u2ab1\uda8d\udca6",
        47, 18818, 418694225, -6727819599931913003L, 2890L, true, false, (char) 40584, (char) 20076,
        Double.longBitsToDouble(0x3fc41ca70f3fc13cL), Double.longBitsToDouble(0x3fc833115d0d7918L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 12, 9, "\udb0a\udd0f\udac9\udef0\ud8cc\udd5f", "\u5c5a\u6fb0\ud47e\uafc0\u95c1", "\udb69\udf31\ud9bd\udd0d\uda24\udcab\ud859\udfb4\udabf\udd9a\ud999\ude31",
        19, 30360, 1161756459, -6909223554377818893L, 17107L, false, true, (char) 15734, (char) 41662,
        Double.longBitsToDouble(0x3fe713ba91d9accfL), Double.longBitsToDouble(0x3fc71ada009537c0L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 14, 1, "\udb24\udf9d\uda27\udf045", "\uce15\u3cf8\u75c3\u02bf\ubf56", "\ud8a3\udf6e",
        6, 79390, -1009003046, -8315321543403181262L, 59768L, false, false, (char) 28910, (char) 59970,
        Double.longBitsToDouble(0x3fef157990000000L), Double.longBitsToDouble(0x3fedc02514d5a2a1L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\0121=java.text.SimpleDateFormat:@?\012",
        Z.run(T, 2, 10, 10, 4, "\udb4b\udd8a\udaef\udc8f\udb56\udf5f\uda11\udc04\ud824\ude57\uda26\ude3e\udae6\udf59\udbd1\udc90\ud99c\udcbe\u9821\uda16\udee4\udaa1\udd54\ud924\ude15\ud9bd\udd0d\udb24\ude10\uda9e\ude4e\u9c50\ud916\udcdc\ud803\udfe6\udaa1\udd79\ud9fc\udd22\uda8d\udd03\udbbf\udf19\ud918\udc71\ud9e3\uddc9\ud958\udd98\ud8b9\udcd7\uda08\udfff\ud97e\udf0d\ud931\udd93\ud8b8\udd67\udbf5\ude90\ud845\udfb6\uda19\udf85\ud9f6\udc22\ud88f\udcc1\ud976\udfeb\ud9ba\udf02", "\u0b6f\uc07f\u817c\u6294\u6e4a\u31ed\ua1a4\u3758\ub4a3\ub0dd\u4dcd\u4d7e\uc7ef\u666e\ubf40", "\ud9aa\udca7\udb70\udcd9\udbf0\udf54\udbaf\udd8e\ud9d2\udef3\uda94\udcb2\ud884\uddac\udaad\ude25",
        55, 96488, -995455297, 7761638014358442747L, -58673L, true, true, (char) 15654, (char) 33925,
        Double.longBitsToDouble(0x3fd136593930a174L), Double.longBitsToDouble(0x3fe4a1116b80c355L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 8, 5, "\ud858\ude6d\u7684\udb3e\udc38\udb99\ude25\ud877\udf58", "\ucc11\uafc0\u95c1\u0468\ua488\ud79e\u4066\u00d7\u6c02\u25db", "\u9a7c",
        56, -1000, 0, -6341068274151339660L, 44171L, false, false, (char) 22904, (char) 60065,
        Double.longBitsToDouble(0x3fc44d04fc000000L), Double.longBitsToDouble(0x3feaa6cca072cd0fL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\0121=java.text.SimpleDateFormat:@?\012",
        Z.run(T, 2, 10, 10, 4, "\udb4b\udd8a\udaef\udc8f\udb56\udf5f\uda11\udc04\ud824\ude57\uda72\ude44\udae6\udf59\udbd1\udc90\ud99c\udcbe\u9821\uda16\udee4\udaa1\udd54\ud924\ude15\ud9bd\udd0d\udb24\ude10\uda9e\ude4e\u9c50\ud916\udcdc\u9474\ud9d7\udde4\udb88\uddd5\uda8d\udd03\udbbf\udf19\ud918\udc71\ud9e3\uddc9\ud958\udd98\ud8b9\udcd7\uda08\udfff\ud97e\udf0d\ud931\udd93\ud8b8\udd67\udbf5\ude90\ud845\udfb6\uda19\udf85\ud9f6\udc22\ud88f\udcc1\ud976\udfeb\ud9ba\udf02", "\uc033\uc07f\u817c\u6294\u6e4a\u31ed\ua1a4\u3758\ub4a3\ub0dd\u4dcd\u4d7e\uc7ef\u666e\ubf40", "\ud9aa\udca7\ud9f7\udd3b\udb99\udf23\udbaf\udd8e\ud9d2\udef3\uda94\udcb2\ud884\uddac\uda63\udc81",
        17, 96395, -995455297, 7761638014358442747L, -58673L, true, true, (char) 15654, (char) 33925,
        Double.longBitsToDouble(0x3fd136593930a174L), Double.longBitsToDouble(0x3fe4a1116b80c355L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 14, 0, "3\uda93\uddd4\ud9e3\udcdd\udbe1\udccc\ud815\udec2\ud94c\udfd1\ud82c\udc52\ud8d7\udfe7\u008c\u73ef\ud8de\udc39\uda29\udfb4\udbbf\udd23\udaeb\udfefZ\000\ud86c\udd93\uda25\udde9\ud839\uddb8\udb40\ude5b\u7517\udb23\ude3f\ud90d\udd7f\ud8e6\udf57\ud9f6\udeb2\uda3b\udf74", "\ua517\u69e2\u9ce5\uc9d5\u96a5\u4fd4\u17d2\u9bff\u6dc8\u6d7a\u5801\u2ced\u637d\ud662\ud496\u3c69\ub578\u691b\u1f6a\u66a8\ub7d8\ud588", "\u603f\ud99c\udf72\udae4\udcaf\udb10\udf7b\udbd8\udc57\udbcb\udcee\u5984\ud965\udc41\ud9ef\udc45\udaa0\ude15\udbfa\udea0\udae8\udef1\udb49\uddcc\ud984\udd52\ud918\udec6\ud8b0\udce2\ud8d2\ude7b\ud80b\ude3a\ud901\udd98\udb84\udd0f\uda8a\ude17\ud83a\udc7c\ud89e\udd24\ud9b9\udd34\uda7e\udcda\ud94e\udf91",
        41, 78728, 1201003806, -1229288579536301134L, 98367L, true, false, (char) 49206, (char) 55332,
        Double.longBitsToDouble(0x3fe7c097d632aab5L), Double.longBitsToDouble(0x3f9c118078421da0L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 14, 0, "3\uda93\uddd4\u32d8\udbe1\udccc\ud815\udec2\ud94c\udfd1\ud82c\udc52\ud8d7\udfe7\u008c\udb36\udf1b\ud8de\udc1f\uda29\udfb4\udbbf\udd23\udaeb\udfefZ\000\ud86c\udd93\uda25\udde9\ud839\uddb8\udb40\ude5b\u7517\udb23\ude3f\ud90d\udd7f\ud8e6\udf57\ud9f6\udeb2\uda3b\udf74", "\ua517\u69e2\u9ce5\uc9d5\u96a5\u4fd4\u17d2\u9bff\u6dc8\u6d7a\u5801\u2ced\u637d\u3617\ud496\u3c69\ub578\u691b\uca44\u52ff\u87b7\ud513", "\u603f\ud99c\udf72\udae4\udcaf\udb10\udf7b\udbd8\udc57\udbcb\udcee\u5984\ud965\udc41\ud9ef\udc45\udaa0\ude15\udbfa\udea0\udae8\udef1\udb49\uddcc\ud984\udd52\ud918\udec6\ud8b0\udce2\ud8d2\ude7b\ud80b\ude3a\ud901\udd98\udb84\udd0f\uda8a\ude17\ud83a\udc7c\ud89e\udd24\ud9b9\udd34\uda7e\udcda\ud94e\udf91",
        41, 78728, 1201003806, -1229288579536301134L, 98367L, true, false, (char) 32567, (char) 55305,
        Double.longBitsToDouble(0x3fe7c097d632aab5L), Double.longBitsToDouble(0x3f9c118078421da0L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\012",
        Z.run(T, 1, 7, 7, 6, "\udb4b\udd8a\udaef\udc8f\udb3e\udc38", "\ucc3c\u1f17\u75c3\u02bf\u35db", "\ud8a3\udf6e\ud9bd\udd0d\udb24\ude10\uda9e\ude4e\u9c50\ud916\udcdc",
        19, 30360, -650182869, -3574284072988304419L, 44171L, true, true, (char) 31512, (char) 64149,
        Double.longBitsToDouble(0x3fc7113a00942e74L), Double.longBitsToDouble(0x3fc41ca70f3fc1fcL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 9, "\udb4b\udd2f\u00af", "\u32cb", "\uda29\udecb\ud8f6\udf1f\ud828\ude18\uda79\udc55\uda7f\udda5\udb69\ude52\ud986\udd0d\u00d7\uda6f\udfbf\udabf\udd9a\ud8d7\ude8b\ud8c2\ude09",
        10, 59661, 33298, -1476395008L, -87606L, false, false, (char) 26594, (char) 50162,
        Double.longBitsToDouble(0x3fe6b6de58a26827L), Double.longBitsToDouble(0x3e3aa25d68000000L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\0121=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\012",
        Z.run(T, 2, 8, 14, 0, "2", "\000\000\ud2d3", "\000\u73ef",
        -5, 85936, 7532460, 0L, -97184L, false, false, (char) 44666, (char) 64619,
        Double.longBitsToDouble(0x3fe95fed3442f884L), Double.longBitsToDouble(0x3fdf04dfb5ad2938L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\0121=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\012",
        Z.run(T, 2, 14, 14, 0, "2", "\u4fc6\000\ud2d3", "\000\u73ef",
        7, 46757, -1850927310, 2028281958906589484L, 24919L, true, false, (char) 49274, (char) 1488,
        Double.longBitsToDouble(0x3fefaeb045904516L), Double.longBitsToDouble(0x3fdf04dcb5ad2938L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\0121=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\012",
        Z.run(T, 2, 8, 13, 0, "2", "\000\u3837\u9cdc", "\000\u73ef",
        -5, 7984, 1691370757, 270582939648L, -97184L, false, false, (char) 44666, (char) 64619,
        Double.longBitsToDouble(0x3fe95fed3442f884L), Double.longBitsToDouble(0x3fdf04dfb5ad2938L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\0121=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\012",
        Z.run(T, 2, 13, 13, 0, "2", "\u1aaa\uaf89\u6ef6", "\udb89\ude1e\u73ef",
        -5, 7984, 1691370757, 270582939648L, -97184L, false, false, (char) 44666, (char) 64619,
        Double.longBitsToDouble(0x3fe95fed3442f884L), Double.longBitsToDouble(0x3fdf04dfb5ad2938L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\012",
        Z.run(T, 1, 7, 1, 3, "\udbe9\udd91\ud824\udea1\udb11\udc2d\udae1\ude32\ud8fe\udd5a\uda91\udebf\ud859\udeee\ud9f7\udc6e\ud8d8\ude0a\u4a87\uda5a\udea1\udb9f\udc85\udb4a\udd87\udb94\udeb3", "\u9257\u0ae8\uad51", "\uda8d\udca6\udbbf\udf19",
        -2, 9452, -1566442568, 8513435885531701653L, -45131L, false, false, (char) 43319, (char) 46087,
        Double.longBitsToDouble(0x3fb0df73e7b10ad0L), Double.longBitsToDouble(0x3facc00291f3aac0L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.text.SimpleDateFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 14, 0, "3\uda93\uddd4\u06f5\udbe1\udccc\ud815\udec2\ud94c\udfd1\ud82c\udc52\ud896\udfc7\ud981\udc92\u73ef\ud8de\udc39\uda29\udfb4\udbbf\udd23\udaeb\udfefZ\000\ud86c\udd93\uda25\udde9\ud839\uddb8\udb40\ude5b\u7517\udb23\ude3f\ud90d\udd7f\ud8e6\udf57\ud9f6\udeb2\uda3b\udf74", "\ua517\u69e2\u9ce5\uc9d5\u96a5\u4fd4\u17d2\u9bff\u6dc8\u6d7a\u5801\u2ced\u637d\ud662\ud496\u3c69\ub578\u691b\u1f6a\u66a8\ub7d8\ud588", "\u603f\ud99c\udf72\udae4\udcaf\udb10\udf7b\udbd8\udc57\udbcb\udcee\u5984\ud877\udf2c\ud86a\udc18\udaa0\udde8\udbfa\udea0\udae8\udef1\udb49\uddcc\ud984\udd52\ud918\udec6\ud8b0\udce2\ud8d2\ude7b\ud80b\ude3a\ud901\udd98\udb84\udd0f\uda8a\ude17\ud83a\udca9\ud89e\udd24\ud9b9\udd34\uda7e\udcda\ud94e\udf91",
        41, 78728, 1201003806, -1229288579536301134L, 98367L, true, false, (char) 49206, (char) 55332,
        Double.longBitsToDouble(0x3fe7c097d632aab5L), Double.longBitsToDouble(0x3f9c118078421da0L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.util.StdDateFormat:DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 14, 0, "3\uda93\uddd4\u06f5\udbe1\udccc\ud815\udec2\ud94c\udfd1\ud82c\udc52\ud896\udfc7\ud981\udc92\u73ef\ud8de\udc39\uda29\udfb4\udbbf\udd23\udaeb\udf98Z\000\ud86c\udd93\uda25\udde9\ud839\uddb8\udb40\ude5b\ud981\ude18\udb23\ude3f\ud90d\udd7f\ud8e6\udf57\ud9f6\udeb2\uda3b\udf74", "\ua517\u69e2\u9ce5\uc9d5\u96a5\u4fd4\u17d2\u9bff\u6dc8\u6d7a\u5801\u6d15\u637d\ud662\ud496\u3c69\ub578\u691b\u16c3\u0eb5\u6225\u31c4", "\u603f\ud99c\udf72\udbb5\udd82\udb10\udf7b\udbd8\udc57\udbcb\udcee\u5984\ud9f3\udf83\ud86a\udc6e\udaa0\udde8\udbfa\udea0\udae8\udef1\udb49\uddcc\ud984\udd52\ud918\udec6\ud8b0\udce2\ud8d2\ude7b\ud80b\ude3a\ud901\udd98\udb84\udd0f\uda8a\ude17\ud83a\udca9\ud89e\udd24\ud9b9\udd34\uda7e\udcda\ud94e\udf91\udb2c\udc80\ud9b0\udd3b\udbe8\udd55\uda69\udf8b",
        12, 95917, 741821249, 9186130428132525791L, 876L, false, false, (char) 19954, (char) 45345,
        Double.longBitsToDouble(0x3f9c118078421da0L), Double.longBitsToDouble(0x3fe7404aa5e60265L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 13, 14, 13, "-", "\u4065\u414c\u97f1\000\u592f\u744e\000", "\u00df",
        -5, 64840, -579682099, -9117761246137880574L, 58571L, true, false, (char) 25618, (char) 56641,
        Double.longBitsToDouble(0x3ea30f9fd3a00000L), Double.longBitsToDouble(0x3fefa8c7a4d519e1L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|parseAsISO8601|java.lang.String,java.text.ParsePosition|new:com.fasterxml.jackson.databind.util.StdDateFormat:",
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|_cloneFormat|java.text.DateFormat,java.lang.String,java.util.TimeZone,java.util.Locale|static",
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|clone||new:com.fasterxml.jackson.databind.util.StdDateFormat:",
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|format|java.util.Date,java.lang.StringBuffer,java.text.FieldPosition|new:com.fasterxml.jackson.databind.util.StdDateFormat:",
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|getBlueprintISO8601Format||static",
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|getBlueprintRFC1123Format||static",
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|getDefaultTimeZone||static",
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|getISO8601Format|java.util.TimeZone|static",
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|getISO8601Format|java.util.TimeZone,java.util.Locale|static",
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|getRFC1123Format|java.util.TimeZone|static",
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|getRFC1123Format|java.util.TimeZone,java.util.Locale|static",
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|hasTimeZone|java.lang.String|static",
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|looksLikeISO8601|java.lang.String|new:com.fasterxml.jackson.databind.util.StdDateFormat:",
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|parse|java.lang.String|new:com.fasterxml.jackson.databind.util.StdDateFormat:",
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|parse|java.lang.String,java.text.ParsePosition|new:com.fasterxml.jackson.databind.util.StdDateFormat:",
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|parseAsRFC1123|java.lang.String,java.text.ParsePosition|new:com.fasterxml.jackson.databind.util.StdDateFormat:",
    "M|com.fasterxml.jackson.databind.util.StdDateFormat|parseAsISO8601|java.lang.String,java.text.ParsePosition|new:com.fasterxml.jackson.databind.util.StdDateFormat:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
