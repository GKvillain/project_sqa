package com.fasterxml.jackson.databind.introspect;
import org.junit.Test;
import static org.junit.Assert.*;
public class JacksonAnnotationIntrospector_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 10, 10, "\udbcf\udca6\udbf3\udd03\udb02\udffe\ud9a1\udde7", "\ud189\ucf4d\u197d\u0903\ub2cb\uc0ce\ud30b\u52c2\u34bd\ua426\u4486\uca3d\u4161\u86d8", "\u6240\ud915\udfac\u584d\udbd6\udf52\ud827\uddf4\ud9cd\udc9c\uda2c\ude78",
        48, 69075, -371438086, 7545977150180332418L, -68665L, false, true, (char) 35572, (char) 17782,
        Double.longBitsToDouble(0x3feaed5fda138cd3L), Double.longBitsToDouble(0x3fea50738c83a230L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 0, "\udbcf\udca6\udbf3\udd037\ud9a1\udde7", "\ud189", "\ud846\udecd",
        16, 34578, 3239, 6285507064901923442L, -50225L, false, false, (char) 35206, (char) 44569,
        Double.longBitsToDouble(0x3fd057a82fb5ac04L), Double.longBitsToDouble(0x3fae9a07163de430L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 10, 10, "\ud843\udef2\ud91d\udc5d\ud969\ude0f\uda67\udd17\ud840\udfcc\udbf4\ude1c\ud880\udce5\u5d32\udb9f\udc31\ud846\udecd\ud81d\udd3c\ud8a0\uded8\udad5\ude8f\udbf0\udc83\udac7\udc97\ud89f\udcb3", "\u4161\u86d8\ube24\u37c9", "\u584d\udbe4\udd52\ud827\uddf4\ud9cd\udc9c\uda23\udd78\uda7e\udd36\ud8de\udcc6\udbf7\udcab",
        52, 74554, 1057477258, -2995885070294881426L, -70483L, true, true, (char) 48870, (char) 32187,
        Double.longBitsToDouble(0x3fc07446187d34b4L), Double.longBitsToDouble(0x3fd6b5cd5b0d5672L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 10, 10, "\udbcf\udca6\udbf3\udd03\udb02\udffe\ud9a1\udde7", "\ud189\ucf4d\u197d\u0903\ub2cb\uc0ce\ud30b\u52c2\u34bd\ua426\u0786\u045f\u4161\u86d8", "\u6240\ud915\udfac\u584d\udbd6\udf52\ud827\uddf4\ud9cd\udc9c\uda2c\ude78",
        -4, -1000, 0, 0L, -68665L, false, true, (char) 35572, (char) 17782,
        Double.longBitsToDouble(0x3feaed5fda138cd3L), Double.longBitsToDouble(0x3fea50738c83a230L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 10, 10, "\udbcf\udca6\udbf3\udd03\udb02\udffe\ud9a1\udde7\ud97f\udc72\u0a33\ud880\udce5\u5d32", "\u44cc\uc0ce", "\udac7\udc97",
        17, 15497, 309648478, 6157396036610445809L, 41156L, true, false, (char) 57254, (char) 11590,
        Double.longBitsToDouble(0x3fb4f63d6a1259d0L), Double.longBitsToDouble(0x3fcb459e7778717cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Integer |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 2, 3, 2, "\udabf\udc91\uda9f\udca7\udb1b\udc9a\ud99e\udd4d\ud97f\udc72\u0a33", "\uabd2\ud34b\ub608\ub9fc\u77da\u137a\u34bd\ua3b7\u4486\uca3d\u4161", "\ud92e\udeeb\u6240\ud915\udfac\udb4a\udd05\udbd6\udf52\ud827\uddf4\ud9cd\udc9c\uda2c\ude78\udb2a\udd6b\ud8de\udc3b",
        1, 38834, -541682814, 3221240907415452287L, 73262L, false, false, (char) 3013, (char) 41153,
        Double.longBitsToDouble(0x3fea5073a483a230L), Double.longBitsToDouble(0x3fdcd481f3053a96L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 10, "\udbcf\udca6\ud934\udf03\ud952\udefb\udb71\udda2", "\ud0e8\u6eac\u1986\u0903\ub2cb\uc0ce\ud30b\u52c2\u34bd\uc858\u4486\uca3d\u609a\u86d8", "\u6240\ud915\udff6\ud991\udca9\udbd6\udfbc\udb5d\udd8e\udbeb\udfd5\ud903\udfd5",
        32, 69075, -371438086, 6681286021725206161L, -68665L, false, true, (char) 22004, (char) 17782,
        Double.longBitsToDouble(0x3feaed5fda138cd3L), Double.longBitsToDouble(0x3fe218738c83d038L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.String |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 6, "\udbcf\udca6\udbf3\udd03\udb63\udf6e\ud9a1\udde7\ud98e\udea8\ud963\udd03", "\u570f\u5e60\ud5f8\uc0ce\ud30b\u52c2\u34bd\ub826\u4486\uca3d", "\ud9e2\ude8b\ud92e\udeeb",
        14, 37443, -654982502, -1387932964036564106L, 87870L, false, true, (char) 20452, (char) 64240,
        Double.longBitsToDouble(0x3fe1ef4ee38268b8L), Double.longBitsToDouble(0x3fe456fdb3673f07L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 10, 10, "\udbcf\udca6\udbf3\udd03\udb02\udffe\ud9a1\udde7", "\ud189\ucf4d\u197d", "\ud8a0\uded9\udad5\ude8f\udbf0\udc83\udac7\udc97\ud89f\udcb3\ud818\ude55\ud9a5\udd74\ud986\udc06\ud8bd\udcde\ud9e2\ude8b\udbb7\udcaf\u620f",
        23, 1498, -1992859053, -6734100294038127882L, 7980L, true, true, (char) 64240, (char) 54791,
        Double.longBitsToDouble(0x3fec1345c28adffdL), Double.longBitsToDouble(0x3fe339f83b6ed66cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Integer |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=java.lang.Class:java.lang.Integer |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 1, 2, 0, "\udbcf\udca6\udbf3\udd03\udb02\udffe\ud886\udd05", "\uc950\ucf8f\u197d\u0903\ub2cb\uc0ce\ud30b\uab31\u66ea\u2155\u4462\uca3d\u4161\u86d8\u5b40\u358c\u9c40\ua380\ua454\u4cbb\u7d83\u4872\u6990\u199e\u8340\u83bc\u9ade", "\udaf7\udff3\uda2b\udff6\ud90c\udd94\ud9bb\udfbf\udb85\udf30\udbb2\uddd9\uda04\udf9e\ud89a\udee1\ud810\udf98\ud8fd\udc93\ud8a7\uddd1\udbfa\udda1\ud949\ude31\ud906\udc71\ud9e3\udda7\ud8c2\udfe7\ud8cf\udfcd\ud870\ude33\ud91f\uddc0\ud804\udcee\ud835\ude60\udb93\udff9\ud96b\udc8f\ud892\udd85\ud9e3\udc91\u8177\udb03\udff8\uda15\udc4c\udb05\udce0",
        57, 57687, -1552254234, 4379996953511330948L, -3405L, false, true, (char) 36365, (char) 34868,
        Double.longBitsToDouble(0x3fe0bb3cab9e47d2L), Double.longBitsToDouble(0x3fd8bcb068983f14L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\u6193\ucf4d\u197d\u0903\ub2cb\uc0ce\u6a1d\u54dd\u34bd\ua426\u4486\uca3d\u4161\u8715}\udbcf\udca6\udbf3\udd03\udb02\udffe\ud9a1\udde7 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 11, 10, 10, "\udbcf\udca6\udbf3\udd03\udb02\udffe\ud9a1\udde7", "\u6193\ucf4d\u197d\u0903\ub2cb\uc0ce\u6a1d\u54dd\u34bd\ua426\u4486\uca3d\u4161\u8715", "\u6240\ud915\udfac\u584d\udbd6\udf52\ud827\uddf4\ud9cd\udc9c\uda2c\ude78",
        12, 69075, -371438086, 7545977017036346242L, -68665L, false, true, (char) 35572, (char) 17782,
        Double.longBitsToDouble(0x3feaed5fda138cd3L), Double.longBitsToDouble(0x3fea50738ab7623aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 10, 10, "\udbcf\udca6\udbf3\udd03", "\u4f73\u8d6e\ub784\u1ba7\u9ec0\u17b7\ubdda\u3f53\ud301\ua79f", "\ud818\ude55\ud9a5\udd74",
        22, 99670, -704490235, 3750979356336533874L, 15354L, true, false, (char) 44415, (char) 40321,
        Double.longBitsToDouble(0x3fdde1c0034bf020L), Double.longBitsToDouble(0x3feaa4b7fdb46f8bL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 8, 1, "\udbc2\udfbf", "\u9e3a", "\ud906\udc98\u5d32\udb9f\udc31\udac6\udecd\ud817\udc3c\udb5e\ude37\udad5\ude2b\udb8e\uddff\udb68\udc69\ud873\udcd7\ud852\udc2c\ud9a5\udd74\ud807\udf46\ud8ae\udd25",
        46, 16346, -301609717, -3842694856171320165L, -78358L, false, false, (char) 43229, (char) 11748,
        Double.longBitsToDouble(0x3fd1e0f651c9aa16L), Double.longBitsToDouble(0x3fcdd06f03b5ad30L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 14, 8, "\uda3c\ude48\ud8fe\ude3c\ud8f3\udf47\uda68\udca6", "\u8c43\ucf4d\u197d\uc528\ub2cb\u5b39\u86bd\u5334\u5caa\ua753\u327c\u6d5a\u6c69\u8693", "\ud8e2\ude44\ud933\udc1b\u584d\ud992\udfcf\ud826\udc27\ud9cd\udc49\uda2c\ude78",
        10, 90092, -371438299, 7545977149576352642L, -68665L, true, true, (char) 35572, (char) 17782,
        Double.longBitsToDouble(0x3feaed5fda16c3d3L), Double.longBitsToDouble(0x3fdd3b671d36b028L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 10, "\udbcf\udca6\u3fff\udb02\udffe\ud943\udfb8", "\ud189\ucf4d\u197d\u0903\ub2cb\u24f4\ud326\u52c2\u34bd\ua426\u45a8\uca3d\u4161\u86d8\u5b40\u358c\u9c40", "\udbd6\udf52\ud827\uddf4\ud9cd\udc9c\uda2c\ude78\u3120\u41fb\udbf7\udc0e\udb86\udc68\udb96\udd9a\udba3\ude40\udaf7\udff3",
        13, 2599, -1409577805, -8299277192284027447L, 74973L, true, true, (char) 53650, (char) 54058,
        Double.longBitsToDouble(0x3fdde4c39f14afcaL), Double.longBitsToDouble(0x3fb5dc1929f9a060L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\udbcf\udca6\udbf3\udd03\udb02\udffe\ud9a1\udde7 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 10, "\udbcf\udca6\udbf3\udd03\udb02\udffe\ud9a1\udde7", "\ud189\ucf4d\u197d\u0903\ub2cb\uc0ce\ud30b\u52c2\u34bd\ua426\u4486\uca3d\u4161\u86d8", "\u6240\ud915\udfac\u584d\udbd6\udf52\ud827\uddf4\ud9cd\udc9c\uda2c\ude78",
        48, 6755, -371422576, 7545977150180332418L, -68665L, false, true, (char) 35572, (char) 17782,
        Double.longBitsToDouble(0x3feaed5fda138cd3L), Double.longBitsToDouble(0x3fea50738c83a230L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Class:char |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 15, 11, "\udbcf\udca6\uda43\uddfe\ud949\udf59\uff96\ud97f\udc72\u0a33", "\u197d\u0903\ub2cb\ubf9e\u651e\u649a\u0f28\ua426\u4486\u368c\u8b09\u9a4e\u5338\u358c", "\ud899\ude49\udbd6\udf52\ud948\ude63\ud888\udf00\uda29\udfb4\udbf6\udcaa\uda87\udf84\ud847\udfb6",
        55, 16236, 502368171, -2995980448147084434L, -4835L, true, true, (char) 31757, (char) 32187,
        Double.longBitsToDouble(0x3fc0782609402968L), Double.longBitsToDouble(0x3fea665290c9af6fL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\u53fd\u5319}\udbcb\udef6\udade\uddf9\ud869\udcb7\udab9\udddb\ud895\udd4e\ud915\udef4\ud8a4\udc76\udbf0\udd0d\udb9f\udc31\ud846\udecd |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 10, "\udbcb\udef6\udade\uddf9\ud869\udcb7\udab9\udddb\ud895\udd4e\ud915\udef4\ud8a4\udc76\udbf0\udd0d\udb9f\udc31\ud846\udecd", "\u53fd\u5319", "\ud818\ude55\udbd6\ude2d",
        53, 99670, -704490235, 3750979356336540733L, 15354L, true, false, (char) 13485, (char) 40321,
        Double.longBitsToDouble(0x3fdde1c00bcf8cbcL), Double.longBitsToDouble(0x3fdabb239bf559ecL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Class:int |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 13, 5, "\udbcf\udca6\udabe\udc48\ud800\ude79\ud8c2\udefb", "\uc810\ucf4d\u1190\ubcb7\ub99c", "\ud955\udfcd\udac7\udc94\u37a0\ud835\uddd3\u6447\udb37\udc04\udad4\udd4f\udb5d\udd96\udb01\udd15\u6240\uda10\ude2b\uda71\udec0\ud83b\udcdc\ud996\udcef\udb9d\udf5d\uda13\udcec\udad9\udfcd\ud8b4\udd0b\ud8c0\udf31\ud865\udf08",
        2, 56036, 791947111, -3817847580976378711L, -68313L, false, false, (char) 3645, (char) 39842,
        Double.longBitsToDouble(0x3fb2be5e34195698L), Double.longBitsToDouble(0x3fa06d11c72667f0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:{\u168a}\udbcf\udca6\udbf3\udd037\ud9a1\udde7 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 3, 11, 0, "\udbcf\udca6\udbf3\udd037\ud9a1\udde7", "\u168a", "\ud846\udecd",
        16, 34578, 3239, 6285507064901923442L, -93071L, false, false, (char) 24198, (char) 44569,
        Double.longBitsToDouble(0x3fd057a82fb5ac04L), Double.longBitsToDouble(0x3fae9a07163de430L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.List |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 10, "\ud843\udef2\ud91d\udc5d\ud9e0\udfec\udb5f\udd1d\ud840\udfcc\udbf4\ude1c\ud81c\udc52\ud8e6\uddd3\udb9e\udf7b\ud846\udecd\ud81d\udd3c\ud8a0\uded8\udad5\ude8f\udbf0\udc83\ub0be\ud9a2\udc73", "\u0956\ub71a\u3b5b\u37c9\u9da7\u837f\ua454", "\udacb\ude3f\ud8ab\udc95\udbd5\udfdb\ud8de\udcc6",
        4, 32760, -1699316350, 4257867908965476457L, -31185L, true, false, (char) 46936, (char) 48870,
        Double.longBitsToDouble(0x3f6adb8c83a2c800L), Double.longBitsToDouble(0x3fe0fa69696b5cd5L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 10, "\uda23\udc82\udaf1\udf42\udb13\ude98\ud8c6\uded8\ud85c\udf47\u7ad2\ud880\udee7\u5d32\udb9f\udc31\ud846\udecd\ud81d\udd3c\ud8a0\uded8\udad5\ude8f\udbf0\udc83\udac7\udc97\ud89f\udcb3", "\u5b99\u86d8\ube24\u0486", "\u5810\udbe4\udd52\ud827\uddf4\ud9cd\udc9c\udb99\udd73\uda7e\udd36\ud8de\udcc6\udbf7\udcab\udb86\udc68\udb90\udf9a\udba3\ude40\udaf7\udff3\uda2b\udff6\ud916\udc39\udada\udce3\ud96f\udc93\udb80\udeec\udacc\uddc2\ud930\udd0f\ud9b5\udc0c\ufd00\ud89b\udeeb\udbdd\udcf2\ud8ee\udf53\ud937\uddfb\ud812\udf38\ud9e0\udf37\ud8c4\udd13\u1220\udb1c\udf13\udbf7\udf27",
        26, 89467, 834216887, 723288380884369803L, -19817L, true, true, (char) 8842, (char) 53898,
        Double.longBitsToDouble(0x3fe06667f0dc0da1L), Double.longBitsToDouble(0x3fb3c1374a310e48L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 13, 14, "\uda4a\udd24\ud880\uded1\udb03\udc2d\ud9a1\udde7", "\uce1f\ucf4d\u197d\u0903\ub2cb\uc0ce\u1d0c\u52c2\u34bd\u1ab3\u0991\u045f\u4161\u86d8", "\ud939\ude2b\ud915\udfac\udabd\udcff\udbd6\udf52\ud827\uddf4\ud9cd\udc9c\uda2c\ude78",
        21, -786, 0, 0L, -68665L, false, true, (char) 35447, (char) 37266,
        Double.longBitsToDouble(0x3feaed5fda138cd3L), Double.longBitsToDouble(0x3fea50738c83a230L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\ucde1}\udb99\udcab\udbf3\udd03\udb02\udffe\udaef\udd6e\ud8d0\udd5e\udac3\ude6f\ud885\udee8\udad4\ude2a\uda83\udf71\udb3c\ude03\ud8e2\udf86\ud862\ude0f\udad5\ude48\udbf0\udc83\ud9e7\udcdb\ud89f\udcb3\ud809\udd55\ue45e\ud986\udc06\ud8bd\udcde\ud9e2\ude8b\ud92e\udeeb\ud965\udfc6\uda2f\udeb0\ucd63\udbd6\udf52\ud995\udf8b\ud89f\uddf2\uda2c\ude7f\ud971\uddcf\000\uda86\udf03 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:{\ucde1}\udb99\udcab\udbf3\udd03\udb02\udffe\udaef\udd6e\ud8d0\udd5e\udac3\ude6f\ud885\udee8\udad4\ude2a\uda83\udf71\udb3c\ude03\ud8e2\udf86\ud862\ude0f\udad5\ude48\udbf0\udc83\ud9e7\udcdb\ud89f\udcb3\ud809\udd55\ue45e\ud986\udc06\ud8bd\udcde\ud9e2\ude8b\ud92e\udeeb\ud965\udfc6\uda2f\udeb0\ucd63\udbd6\udf52\ud995\udf8b\ud89f\uddf2\uda2c\ude7f\ud971\uddcf\000\uda86\udf03 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 11, 11, 10, "\udb99\udcab\udbf3\udd03\udb02\udffe\udaef\udd6e\ud8d0\udd5e\udac3\ude6f\ud885\udee8\udad4\ude2a\uda83\udf71\udb3c\ude03\ud8e2\udf86\ud862\ude0f\udad5\ude48\udbf0\udc83\ud9e7\udcdb\ud89f\udcb3\ud809\udd55\ue45e\ud986\udc06\ud8bd\udcde\ud9e2\ude8b\ud92e\udeeb\ud965\udfc6\uda2f\udeb0\ucd63\udbd6\udf52\ud995\udf8b\ud89f\uddf2\uda2c\ude7f\ud971\uddcf\000\uda86\udf03", "\ucde1", "\ud90c\udd94\ud9bb\udfbf\ud96f\udc93\udb80\udeec\udacc\ude70\udacb\udedd\ud98f\udd12",
        20, 20609, -695307236, 9076180044990444953L, 92402L, true, true, (char) 48169, (char) 10638,
        Double.longBitsToDouble(0x3fe20f4dbf1c0d11L), Double.longBitsToDouble(0x3fa870324cc58dc0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 9, 10, "\udbcf\udca6\udbf3\udd03\udb02\udffe\ud9a1\udde7", "\ud189\ucf4d\u197d\u0903\ub2cb\uc0ce\ud30b\u52c2\u34bd\ua426\u0786\u045f\u4161\u86d8", "\u62a5\ud915\udfac\u584d\udbd6\udf52\ud827\uddf4\ud9cd\udc9c\uda2c\ude78",
        -4, -1000, 0, 0L, -68665L, false, true, (char) 35572, (char) 17782,
        Double.longBitsToDouble(0x3feaed5fda138cd3L), Double.longBitsToDouble(0x3fea50738c83a230L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 4, 3, 10, "\udbcf\udca6\uda39\udd0b\udb02\udffe\ud9a1\udde7", "\ud189\ucf4d\u197d\u0903\u7399\u7ee7\ud30b\u52c2\u34bd\ua426\u0786\u045f\u4161\u86d8", "\u6240\ud915\udfac\u584d\udbd6\udf52\ud827\uddf4\ud9cd\udc9c\u90b0",
        -3, 29792, 0, 0L, -85095L, true, true, (char) 55484, (char) 27206,
        Double.longBitsToDouble(0x3fea50738c83a230L), Double.longBitsToDouble(0x3fd6d545dd0bacf0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Integer |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 14, 10, "\udbcf\udca6\udbf3\udd03\udb02\udffe", "\u102b\ucbbd\u8998\u9557\u03d8\u6e10\u50ca\ud360\u52c2\u48a8\ua466\u03e1", "\ud83e\udc84\ud95e\udfd4\ud92e\ude75\uda2c\udee9\ud8ab\udcff\ud91d\udd94\udba6\udcc1\ud859\udfe8\u8a86\ud90e\udc29",
        1, 94397, 327489746, 2475095972726207113L, -72559L, true, true, (char) 16992, (char) 4964,
        Double.longBitsToDouble(0x3fdd23763b7c8e3aL), Double.longBitsToDouble(0x3fe8294f9dfa2489L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 12, 10, "\udbcf\udca6\udbf3\udd03\udb02\udffe\uda5f\udde6\ud97f\udc72\u0a33\ud880\udce5\u5d32", "\u6b48\u191a", "\udaca\udca3\ud89f\udcb3",
        46, 72574, 1433630539, -977191021619627294L, 15354L, true, false, (char) 5958, (char) 13261,
        Double.longBitsToDouble(0x3fdde3fea236f548L), Double.longBitsToDouble(0x3fee229d6690eb4cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 6, "\ud848\udc1d\ud811\udc6f\udb1b\udc9a\ud99e\udd4d\ud97f\udc72\u0a33", "\u0deb\ubd10\u84da\ub9e5\u77da\uabea\u9258\u5497\u4486\uca3d\u053c", "\ud92e\udeeb\u6240\uda1c\uded8\ud9f1\udd6b\udbd6\udf52\ud827\uddf4\udb51\udf02\uda2c\uddf1\ud80e\udebe\ud8fe\udd83\ud909\udeba\udb86\udcdd\uda35\udcc9\udb32\udd1d\u959d",
        6, 73758, 3827161, -8299277194011339794L, 87391L, true, true, (char) 59085, (char) 22989,
        Double.longBitsToDouble(0x3feebf36ef23995fL), Double.longBitsToDouble(0x3fce261dd89778b8L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 3, 3, 2, "\udabf\udc91\uda9f\udca7\uda23\udf25\ud9ad\udc5c\udaef\udeac\ud8f0\ude9d", "\uabd2\ud34b\u39d9\ub9fc\u77da\u137a\u34bd\ua3b7", "\ud986\udc06\udb60\udccc\ud9ee\udea8\ud92e\udeeb",
        10, 63283, 754303583, -8559264262171939978L, -25651L, false, true, (char) 55966, (char) 24003,
        Double.longBitsToDouble(0x3fedaad11382e25cL), Double.longBitsToDouble(0x3fd16dfb6e7a73ecL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Class:int |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:\ud81a\udf12\uda9f\udcb3\udb1b\udc9a\ud99e\udd4d |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 2, 11, 10, "\ud81a\udf12\uda9f\udcb3\udb1b\udc9a\ud99e\udd4d", "\u4351", "\udaf7\udc83\ud81e\udc79\ud96c\udc1e\ud8b4\udd1d\ud844\udc8d\ud919\ude4d\udaec\udf66\ud8f7\udde2\uda65\ude6a\ud986\udc07\ud8bd\udcf9\ucaed\ud92e\ude19\u6240\ud915\udfac\udb4a\udd05\udbd6\udf52\ud904\udc22\ud9cd\udc9c\uda2c\ude78\ud8a1\udfa7\ud813\uddec\udb7c\udeec\udb86\udcdd",
        44, 77594, -697009537, 3416942862561092814L, 99517L, false, true, (char) 32190, (char) 52915,
        Double.longBitsToDouble(0x3fee6a40f9829d4bL), Double.longBitsToDouble(0x3feeb1628f3dfbb5L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Number |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=java.lang.Class:java.lang.Number |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 2, 2, 13, "\udabf\udc91\uda9f\udca7\udb1b\udc9a\ud99e\udd4d", "\u4351\ud291\uabd2\u2643\ub67d\ub9fc\u77da\u137a\u34bd\ua3b7\u4486\uca3d\u4161\u64f4", "\u6240\ud915\udfac\udb4a\udd05\udbd6\udf52\u7950\ud893\udc7d\uda06\udd64",
        7, 68936, 920407546, 7545977652691506050L, -68641L, false, true, (char) 54328, (char) 48911,
        Double.longBitsToDouble(0x3fea1191abee8cd3L), Double.longBitsToDouble(0x3fea5073a483a230L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 1, 1, 15, "\udbac\udf14\ud9dc\udd17\udab1\udd1f\udb1d\udf15", "\u32ab\ud50f\u6de2\u7679\ube93\uc0cf\u5973\u52c2\u9183\ub26a\u4486\u72fc\u0618", "\udbb6\udff5\udbe6\uddbd\ud8f0\ude8a\ud9a6\udedd\udb53\udf52\ud88f\udeaa\uda07\udec3\udafa\ude0e\uda7e\udd36\ud8de\udcc6",
        14, 47148, -537048190, -3657240225924029579L, 52856L, false, true, (char) 24877, (char) 11284,
        Double.longBitsToDouble(0x3fe8956734f368a5L), Double.longBitsToDouble(0x3fdadb8b9d84f2d8L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 4, 4, 10, "\udbcf\udca6\udbf3\udd03\udb02\udffe\ud9a1\udde7", "\ud189\ucf4d\u197d", "\ud8a0\uded9\udad5\ude8f\udbf0\udc83\udac7\udc97\ud89f\udcb3\ud818\ude55\ud9a5\udd74\ud986\udc06\ud8bd\udcde\ud9e2\ude8b\udaf8\udead\u620f",
        23, 1498, -1992859053, -6734100294038127882L, 7980L, true, true, (char) 64240, (char) 54791,
        Double.longBitsToDouble(0x3fec1345c28adffdL), Double.longBitsToDouble(0x3fe339f83b6ed66cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName: |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 11, 10, 10, "", "\ubd20?\u651f\u72c9\ubd6d", "\000",
        -5, -822, -1385886715, -753225660659404174L, -50225L, false, false, (char) 35206, (char) 9587,
        Double.longBitsToDouble(0x3fd057a82fb5ac04L), Double.longBitsToDouble(0x3fae9a07163de430L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\000\000\udb02\udfc7? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 11, 10, 10, "\000\000\udb02\udfc7?", "", "\udb9e\udf46",
        7, 78921, 327174578, -5952338117061246655L, 41185L, true, true, (char) 42365, (char) 35206,
        Double.longBitsToDouble(0x3fde38873a0af504L), Double.longBitsToDouble(0x3feed6b01000000eL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\udbcf\udca6\udbf3\udd03\udb02\udffe\ud9a1\udde7 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:\udbcf\udca6\udbf3\udd03\udb02\udffe\ud9a1\udde7 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 11, 11, 10, "\udbcf\udca6\udbf3\udd03\udb02\udffe\ud9a1\udde7", "\ud189\ucf4d\u197d\u0903\ub2cb\uc0ce\ud30b\u52c2\u34bd\ua426\u4486\uca3d\u4161\u86d8", "\ud88d\ude2d\ud8d9\udc2a\ud998\udfcb\udbd6\udf52\ud827\uddf4\ud9cd\udc9c\uda2c\ude78",
        46, 77859, -371422576, 7545977150180332418L, -68665L, false, true, (char) 35572, (char) 4727,
        Double.longBitsToDouble(0x3fd6012fe42719b0L), Double.longBitsToDouble(0x3fea50738c83a230L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\u2601\u0d02\ucf4d\u6b48\ub9c8\ub2cb\u1924\ud2e6\u9878\u3532\ua426\u364d\u3b1f\u8962\u86d8\u5b40\ucde3}\udbce\udffb\udbf3\udd03\udb02\udffe |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 8, "\udbce\udffb\udbf3\udd03\udb02\udffe", "\u2601\u0d02\ucf4d\u6b48\ub9c8\ub2cb\u1924\ud2e6\u9878\u3532\ua426\u364d\u3b1f\u8962\u86d8\u5b40\ucde3", "\ud9c7\udc74\udafa\ude3b\udbd8\udeca\ud9cd\udc4e\uda2c\ude78\uda7e\udd36\ud9ce\uddde\u1942",
        52, 80186, 1057477258, -2995885070294881426L, -70483L, true, true, (char) 48870, (char) 32187,
        Double.longBitsToDouble(0x3fc074460f92bef4L), Double.longBitsToDouble(0x3fe024eaf8aad504L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\udb99\udcab\udbf3\udd03\udb02\udffe\ud95a\udd43\000\udbbe\udfdf\u6b34\udad4\ude2a\ud887\udc92\000\ud977\ude3b\ud862\ude0f\000\000\ud9e6\udcf3\ud89f\udcb3\ud809\udd55\ue45e\000\000\000\ud92e\udeeb\ud965\udfc6\uda2f\udeb0\ucd63\udbd6\udf52\ud995\udf8b\ud89f\uddf2\000\ud971\uddcf\000\uda86\udf03 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:\udb99\udcab\udbf3\udd03\udb02\udffe\ud95a\udd43\000\udbbe\udfdf\u6b34\udad4\ude2a\ud887\udc92\000\ud977\ude3b\ud862\ude0f\000\000\ud9e6\udcf3\ud89f\udcb3\ud809\udd55\ue45e\000\000\000\ud92e\udeeb\ud965\udfc6\uda2f\udeb0\ucd63\udbd6\udf52\ud995\udf8b\ud89f\uddf2\000\ud971\uddcf\000\uda86\udf03 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 11, 11, 10, "\udb99\udcab\udbf3\udd03\udb02\udffe\ud95a\udd43\000\udbbe\udfdf\u6b34\udad4\ude2a\ud887\udc92\000\ud977\ude3b\ud862\ude0f\000\000\ud9e6\udcf3\ud89f\udcb3\ud809\udd55\ue45e\000\000\000\ud92e\udeeb\ud965\udfc6\uda2f\udeb0\ucd63\udbd6\udf52\ud995\udf8b\ud89f\uddf2\000\ud971\uddcf\000\uda86\udf03", "", "",
        -5, 52968, -1409613645, -8358680508725382637L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e4fe40000000000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 10, 10, "\udbcf\udca6\udbf3\udd03\udb02\udffe\ud9a1\udde7", "\ud189\ucf4d\u197d\u0903\ub2cb\uc0ce\ud30b\u52c2\u34bd\ua426\u4486\uca3d\u4161\u86d8", "\u6240\ud915\udfac\u584d\udbd6\udf52\ud827\uddf4\ud9cd\udc9c\uda2c\ude78",
        48, 60883, -371438086, 7545977150180332418L, -68665L, false, true, (char) 35572, (char) 17782,
        Double.longBitsToDouble(0x3feaed5fda138cd3L), Double.longBitsToDouble(0x3fea50738c83a230L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 2, 2, 6, "\ud848\udc1d\ud811\udc6f\udb1b\udc9a\ud99e\udd4d\ud97f\udc72\u0a33", "\u0deb\ubd10\u84da\u3b2b\ua2fe\uabea\u9258\u5497\u4486\uca3d\u053c", "\ud92e\udeaa\u6240\uda1c\uded8\ud9f1\udd6b\udbd6\udf52\ud827\uddf4\udb51\udf02\uda2c\uddf1\ud80e\udebe\ud8fe\udd83\ud909\udeba\udb86\udcdd\udbdd\udc7e\udb2d\udf4a\u959d",
        6, 73758, 3827161, -8299277194011339794L, -25247L, true, true, (char) 5326, (char) 27853,
        Double.longBitsToDouble(0x3feebf36ef23995fL), Double.longBitsToDouble(0x3fce261dd89778b8L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName: |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName: |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 11, 11, 10, "", "", "\000\udbbe\udfdf\u6b34\udad4\ude2a\ud887\udc92\000\ud977\ude3b\ud862\ude0f\000\000",
        45, 247, -920715264, 242296285036544L, -100000L, false, false, (char) 32843, (char) 46524,
        Double.longBitsToDouble(0x3fd44d0c74a77c5cL), Double.longBitsToDouble(0x3febb449bd00bd8bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|findEnumValue|java.lang.Enum|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_classIfExplicit|java.lang.Class|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_classIfExplicit|java.lang.Class,java.lang.Class|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_constructNoTypeResolverBuilder||new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_constructStdTypeResolverBuilder||new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_constructVirtualProperty|com.fasterxml.jackson.databind.annotation.JsonAppend$Attr,com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedClass,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_constructVirtualProperty|com.fasterxml.jackson.databind.annotation.JsonAppend$Prop,com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedClass|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_findFilterId|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_findSortAlpha|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_findTypeResolver|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_isIgnorable|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_propertyName|java.lang.String,java.lang.String|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|findAndAddVirtualProperties|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.util.List|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|findAutoDetectVisibility|com.fasterxml.jackson.databind.introspect.AnnotatedClass,com.fasterxml.jackson.databind.introspect.VisibilityChecker|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|findContentDeserializer|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|findContentSerializer|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|findEnumValue|java.lang.Enum|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
