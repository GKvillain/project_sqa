package com.fasterxml.jackson.databind.ser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class EnumSerializer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 9, 10, "\u47f3\uda98\udf63\ud9a5\uddbe\ud9c0\udd5c\uda0f\udf31\ud818\udc24", "\u2337", "\ud919\udd15\uda99\udf2a\ud911\uddd2\uda2e\udf6a\udb39\udfde\ud98b\udf42\udabe\udc3b\ud9c8\ude3a\udb8f\ude23\udbaa\udd2c\udb01\ude1e\ud888\udc2c\u495f\u9702\ud8c6\udfcd\ud952\udee0\ud938\udc3f\ud989\udecb\u1339\ud846\udd75\uda9d\udf2e\ud8bd\udd05\ud996\udf50\udac5\udcc1",
        59, 46697, 799089791, 8597294285667940105L, 50789L, false, true, (char) 4954, (char) 1665,
        Double.longBitsToDouble(0x3fe946a70282b652L), Double.longBitsToDouble(0x3fdc329f467ce296L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 9, 10, "\u47f3\uda98\udf63\ua882\000\uda0f\udef8\ud947\udd17", "\u2337", "\000\uda87\udfc3\ud911\uddd2\uda8c\udf79\000\ud9f2\ude39\udabe\udc3b\udaab\udcec\udb8f\ude23\udbaa\udd2c\udb01\ude1e\ud888\udc2c\u495f\u9702\ud8c6\udfcd\ud952\udee0\ud844\udea6\000\udbd5\ude4a\ud846\udd75\u2725\ud8bd\udd05\ud996\udf50\udac5\udcc1",
        59, 17513, 799089791, 8597294284761923584L, 11355L, false, true, (char) 0, (char) 1463,
        Double.longBitsToDouble(0x3fe946a70282b652L), Double.longBitsToDouble(0x3fdc329f467ce296L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 9, 10, "\u47f3\uda98\udf63\ud9a5\uddbe\ud9c0\udd5c\uda0f\udf31\ud818\udc24", "\u2337", "\ud919\udd15\uda99\udf2a\ud911\uddd2\uda2e\udf6a\udb39\udfde\ud98b\udf42\udabe\udc3b\ud9c8\ude3a\udb8f\ude23\udbaa\udd2c\udb01\ude1e\ud888\udc2c\u495f\u89fe\ud8c6\udfcd\ud952\udf21\ud938\udc3f\ud989\udecb\u1339\ud846\udd75\uda9d\udf2e\ud8bd\udd05\ud996\udf50\udac5\udcc1",
        59, 46697, 799089791, 8597294285667940105L, 50789L, false, true, (char) 4954, (char) 1665,
        Double.longBitsToDouble(0x3fd28d4e05056ca4L), Double.longBitsToDouble(0x3fdc329f467ce296L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 9, 10, "\u47f3\uda98\udf63\ud9a5\uddbe\ud9c0\udd5c\uda0f\udf31\ud818\udc24", "\u2337", "\udb60\udeb9\udabd\udc89\ud911\uddd2\uda2e\udf6a\udb39\udfde\ud98b\udf42\udabe\udc3b\ud9c8\ude3a\udb8f\ude23\udbaa\udd2c\udb01\ude1e\ud888\udc2c\u495f\u9702\ud8c6\udfcd\ud952\udee0\ud938\udc3f\ud989\udecb\u1339\ud846\udd75\uda9d\udf2e\ud8bd\udd05\ud996\udf50\udac5\udcc1",
        59, 46697, 799089791, 8597294285667940105L, 50789L, false, true, (char) 4954, (char) 1665,
        Double.longBitsToDouble(0x3fe946a70282b652L), Double.longBitsToDouble(0x3fdc329f467ce296L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 10, "\u47f3\uda98\udf63\ud8a3\uddbd\ud9c0\udd5c\uda0f\udf31\ud818\udc24", "\u2337", "\ud91f\udfbe\udb67\udf62\udb89\udee4\uda2e\uddff\udb39\udfde\ud98b\udf42\udabe\udc3b\ud9c8\ude3a\udb8f\ude23\udbaa\udd2c\u3e20\ud888\udc2c\u495f\u9702\ud8c6\udfcd\ud952\udee0\ud9ad\ude80\ud927\udc3e\ud909\udf4a\ud846\udd75\uda9d\udf2e\uda2e\udcff\udbb9\udef1\udac5\udcc2",
        59, 46697, 799089791, 8597294285667940105L, 50789L, false, true, (char) 4954, (char) 1665,
        Double.longBitsToDouble(0x3fe946a70282b652L), Double.longBitsToDouble(0x3fdc329f467ce296L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 0, 9, 10, "\u47f3\uda98\udf63\ud9a5\uddbe\ud880\udd5c\uda0f\udf31\ud818\udc24", "\ubaae", "\ud919\udd15\uda99\udf2a\ud911\uddd2\uda2e\udf6a\udb39\udfde\ud98b\udf42\udabe\udc3b\uda00\ude8f\udbad\udc13\udbaa\udd2c\udb01\ude1e\ud888\udc2c\u495f\u9702\ud8c6\udfcd\ud952\udee0\ud938\udc3f\ud989\udecb\u1339\ud846\udd75\uda9d\udf2e\ud8bd\udd05\ud996\udf50\udac5\udcc1",
        49, 46697, 799089791, 8597294285667940105L, 50789L, false, true, (char) 4954, (char) 1665,
        Double.longBitsToDouble(0x3fe946a70282b652L), Double.longBitsToDouble(0x3fdc329f467ce296L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 9, 10, "\ud909\udc63\ud920\udee6\ud861\udcdc\udb18\udcfd\uda1f\udc85\ud9cc\udf73", "\u2337", "\ud92f\udc0c\uda99\udf2a\ud911\uddd2\ud91b\udd00\udb39\udf68\udb8d\udf43\udabe\udc3b\ud9c8\ude3a\udb8f\ude23\udbaa\udd2c\udb01\ude1e",
        -4, 39208, -978576782, 3710963735153628216L, -58405L, false, false, (char) 13485, (char) 6070,
        Double.longBitsToDouble(0x3fe1880520d756d8L), Double.longBitsToDouble(0x3fe5139763199751L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 9, 10, "\u47f3\uda98\udf63\ud9a5\uddbe\ud9de\udf5c\uda0f\udf31\ud842\udf23", "\u210a", "\udba6\udc10\ud93a\udee4\udafe\udea3",
        8, 58881, -1639824123, -1692216984264268564L, -67400L, true, false, (char) 57175, (char) 27798,
        Double.longBitsToDouble(0x3fe5fad602dbc5acL), Double.longBitsToDouble(0x3fb704c394e845e0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 4, "\ud99f\ude34\u9394\ud9a5\uddbe\ud961\ude2d\uda09\udebc\udb58\udc24", "\u8128\u0c6a\u304c\u01e2\u4cfe\u567e\ubf7c\u6fbf\u0ef0\uc59c\ucf20\u900a\u3319\u1ad5\ud277\u93cc\u7d28\u36b3", "\ud9c5\udc1d\ud90e\udd01\ud838\udd6e",
        52, 92726, -128371682, -7506283572617747687L, 76033L, false, true, (char) 11864, (char) 47391,
        Double.longBitsToDouble(0x3fe7dd36ca0cfac9L), Double.longBitsToDouble(0x3fe1cb1e49b76044L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 4, 4, "\udbef\uddf2", "\u00e0\000", "\udbbe\udd3a\000\000\000\ud919\udc5d\000",
        -5, -1000, 0, 158L, -100000L, false, false, (char) 42034, (char) 57175,
        Double.longBitsToDouble(0x3eb8d39000780000L), Double.longBitsToDouble(0x3fe0062d625c100eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 0, 0, "\u47f3\uda98\udf63\ud9a5\uddbe", "\uc8d2\u61d5\ud77c\u8710\u6295\u0bde\u09b6\u7b42\u8a37\ucb15\ua0a6\ua6da\u7dc8\ucfa4\u900a\u3319\u1ad5", "\udac7\udcef\ud8c6\udfcd\ud952\udf21",
        50, 68163, 1421589742, -1112289834075674843L, -65225L, true, false, (char) 21023, (char) 26938,
        Double.longBitsToDouble(0x3fc856c82668be84L), Double.longBitsToDouble(0x3fe84bba7a6536bbL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 0, "\u47f3", "\u3d559", "",
        25, 79405, 11164160, 0L, -100000L, false, false, (char) 0, (char) 58444,
        Double.longBitsToDouble(0x3e43b00000000000L), Double.longBitsToDouble(0x3fc7ab4160000000L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 9, 10, "\u47f3\uda98\udf63\ud8a3\uddbd\ud9c0\udd5c\uda0f\udf31\ud818\udc24", "\u2337", "\ud91f\udfbe\udb67\udf62\udb89\udee4\uda2e\uddff\udb39\udfde\ud98b\udf42\udabe\udc3b\ud9c8\ude3a\udb8f\ude23\udbaa\udd2c\u3e20\ud888\udc2c\u495f\u9702\ud8c6\udfcd\ud952\udee0\ud9ad\ude80\ud927\udc3e\ud8c2\udf50\ud846\uddad\uda9d\udf2e\ud8c1\ude68\udbb9\udef1\udac5\udcc2",
        59, 46697, 799089791, 8597294285667940105L, 50789L, false, true, (char) 4954, (char) 1665,
        Double.longBitsToDouble(0x3fe946a70282b652L), Double.longBitsToDouble(0x3fc8653e8cf9c52cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 11, 10, "\u47f3\uda98\udf63\ud8a3\uddbc\ud9c0\udd5c\uda0f\udf31\ud818\udc24\ud9e5\ude6f\uda1c\udc49\ud8f7\udd04\udb86\udcb7\udbfb\udd39\ud916\udcc1\ud853\udd99\ud91e\udff1\uda2e\uddff\udb39\udfde", "\ucfa4\u900a\u3319\u32ee\ud277\u14da\u8550\ub0d8", "\uda5d\udc1c\ud909\udf40\ud846\udd75\uda9d\udf2e\uda2e\udcff\uda91\udcf5\udae1\udf66\ud036\ud85a\udccb\udb8f\uddac\ud857\udfe2\udae2\ude42\u7524\uda6e\udcfa\ud985\udd08\udb91\udfbd\uc084\u9b21\udbaa\udc67\ud8ac\udeaf\ud838\udc48\ud85b\udfcf\u7215\ud925\uddd7",
        1, 67801, -1311038404, -8123530486415864071L, -91610L, true, false, (char) 32114, (char) 61521,
        Double.longBitsToDouble(0x3fa884773081ec10L), Double.longBitsToDouble(0x3fa9291cb61db1e0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 10, 8, "\udbb2\ude24", "\u1f82\ub7f4", "\uda1c\udca3\uda22\udf03\ud9a6\udc54\udbaf\udcf4\udbca\udf74\udaa6\udefc\ud93a\ude18\udb76\udc50\ud958\udeda\u6461\udada\udc99",
        34, 7429, 147816616, 2348807742751489606L, 18784L, true, false, (char) 10412, (char) 39843,
        Double.longBitsToDouble(0x3fe2f7186e08f019L), Double.longBitsToDouble(0x3fb1984c60f5bf20L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 10, "\u47f3\uda98\udf63\ud9a5\uddbe\ud9c0\udd5c\uda0f\udf31\ua70e", "\u2337", "\ud919\udd15\uda99\udf2a\ud911\uddd2\uda2e\udf6a\udb39\udfde\udb4f\udf44\ud8e1\udf6c\udb3f\udcf0\ud936\udd6b\udbaa\udd2c\udb15\ude2b\ud888\udc2c\u495f\u9702\ud8c6\udfcd\ud952\udee0\ud938\udc3f\ud989\udecb\u1339\ud846\udd75\uda9d\udf2e\uda14\udf31\ud996\udf50\udac5\udcc1",
        59, 46697, 799089791, 8597294285667940105L, 50789L, false, true, (char) 32857, (char) 1665,
        Double.longBitsToDouble(0x3fe946a70282b652L), Double.longBitsToDouble(0x3fdc329f467ce296L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ser.std.EnumSerializer|_isShapeWrittenUsingIndex|java.lang.Class,com.fasterxml.jackson.annotation.JsonFormat$Value,boolean,java.lang.Boolean|static",
    "M|com.fasterxml.jackson.databind.ser.std.EnumSerializer|construct|java.lang.Class,com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.annotation.JsonFormat$Value|static",
    "M|com.fasterxml.jackson.databind.ser.std.EnumSerializer|createContextual|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty|new:com.fasterxml.jackson.databind.ser.std.EnumSerializer:com.fasterxml.jackson.databind.util.EnumValues",
    "M|com.fasterxml.jackson.databind.ser.std.EnumSerializer|_serializeAsIndex|com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.std.EnumSerializer:com.fasterxml.jackson.databind.util.EnumValues",
    "M|com.fasterxml.jackson.databind.ser.std.EnumSerializer|acceptJsonFormatVisitor|com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ser.std.EnumSerializer:com.fasterxml.jackson.databind.util.EnumValues",
    "M|com.fasterxml.jackson.databind.ser.std.EnumSerializer|getEnumValues||new:com.fasterxml.jackson.databind.ser.std.EnumSerializer:com.fasterxml.jackson.databind.util.EnumValues",
    "M|com.fasterxml.jackson.databind.ser.std.EnumSerializer|getSchema|com.fasterxml.jackson.databind.SerializerProvider,java.lang.reflect.Type|new:com.fasterxml.jackson.databind.ser.std.EnumSerializer:com.fasterxml.jackson.databind.util.EnumValues",
    "M|com.fasterxml.jackson.databind.ser.std.EnumSerializer|serialize|java.lang.Enum,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.std.EnumSerializer:com.fasterxml.jackson.databind.util.EnumValues",
    "C|com.fasterxml.jackson.databind.ser.std.EnumSerializer|<init>|com.fasterxml.jackson.databind.util.EnumValues",
    "C|com.fasterxml.jackson.databind.ser.std.EnumSerializer|<init>|com.fasterxml.jackson.databind.util.EnumValues,java.lang.Boolean",
    "M|com.fasterxml.jackson.databind.ser.std.EnumSerializer|_isShapeWrittenUsingIndex|java.lang.Class,com.fasterxml.jackson.annotation.JsonFormat$Value,boolean,java.lang.Boolean|static",
    "M|com.fasterxml.jackson.databind.ser.std.EnumSerializer|construct|java.lang.Class,com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.annotation.JsonFormat$Value|static",
    "M|com.fasterxml.jackson.databind.ser.std.EnumSerializer|createContextual|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty|new:com.fasterxml.jackson.databind.ser.std.EnumSerializer:com.fasterxml.jackson.databind.util.EnumValues",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
