package com.fasterxml.jackson.databind.deser;
import org.junit.Test;
import static org.junit.Assert.*;
public class CreatorProperty_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 9, 21, "\uda2f\udd90\ud9de\udcb6\ud83c\udfa4\ud865\udd30\uc296\uda93\udfb0\uda27\ude55\ud9c0\udc4a\ud9bd\udc8e\udbe4\udeff\ud888\udd31\ud808\udf3f\ud970\ude03", "\u0dda\u8d83\ubf48\u4225\u74fb\ua7fa\u3ae3\u50b1\u2e04\ua652\ub026\u5b0e\ua3ab\ud36a\u9773\u639d\u2a43\u567d\u0775\ua722\ua883\u7e20\uc449\ud2d5\u4d8c\u2838", "\u92c9\ud90a\udc82\udaab\udcec\ud957\udf79\udb93\udc5f\uda57\udf44\uda38\udc51\ud87f\ude34\uda43\udda3\ud8ae\udd50\udbcf\udd93\uda70\uddf3",
        26, 39993, 2015601068, 8584971918320967246L, -40999L, false, false, (char) 39921, (char) 33268,
        Double.longBitsToDouble(0x3fe795d020b2f18eL), Double.longBitsToDouble(0x3fc0c69c27cfd10cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 9, 21, "\uda2f\udd90\ud9de\udcb6\ud83c\udfa4\ud865\udd30\uc296\uda93\udfb0\uda27\ude55\ud9c0\udc4a\ud9bd\udc8e\udbe4\udeff\ud888\udd31\ud808\udf3f\ud970\ude03", "\u0dda\u8d83\ubf48\u4225\u74fb\ua7fa\u3ae3\u50b1\u2e04\ua652\ub026\ud391\ua3ab\ud36a\u9773\u639d\u2a43\u567d\u0775\ua722\ua883\u7e20\uc449\ud2d5\u4d8c\u2838", "\u92c9\ud90a\udc82\udaab\udcec\ud957\udf79\udb93\udc5f\uda57\udf44\uda38\udc51\uda07\udf27\ud9ea\udfb9\uda80\udce5\udbcf\udd93\uda70\uddf3",
        8, 38187, 1808084265, 8584971918320967246L, -40999L, false, false, (char) 39921, (char) 33268,
        Double.longBitsToDouble(0x3fe795d020b2f18eL), Double.longBitsToDouble(0x3fc0c69c27cfd10cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 15, 0, "\ud8c4\ude1a\ud9de\udcb6\ud83c\udfa4\ud865\udcc2\uda8a\udf83\uda93\udfb0\u0093\000\ud98f\udce7\udbe4\udeff\ud888\udd31\ud808\udf3f\ud970\ude03", "\000\000", "\udbf9\udcdc\udb29\ude85",
        23, -1000, 0, 66730864L, 56054L, false, false, (char) 26103, (char) 17406,
        Double.longBitsToDouble(0x3fc0cdabc991f95cL), Double.longBitsToDouble(0x3fdbd32b51413f26L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 9, 21, "\uda2f\udd90\ud956\udc16\ud83c\udfa4\ud865\udd30\uc296\uda93\udfb0\uda27\ude55\ud9c0\udc4a\ud9bd\udc8e\udbad\udf45\ud85e\udf56\uda87\udeca\ud970\ude03", "\u0dda\u5683\ubf48\u4225\u74fb\ua7fa\u3ae3\u50b1\u2e04\ua652\ud595\u6ae8\ua3ab\ud36a\u9773\u639d\u26a8\u652a\u071f\ua722\ua883\u7e20\u31a0\ud2d5\u4d8c\u2838", "\u9307\ud90a\udc82\udaab\udcec\ud957\udf79\udb93\udc5f\uda57\udf44\uda38\udc51\ud87f\ude34\uda43\udda3\ud8ae\udd50\udbcf\udd93\uda70\uddf3",
        26, 39993, 2015601068, 8584971918320967246L, -40999L, false, false, (char) 39921, (char) 33268,
        Double.longBitsToDouble(0x3fe795d020b2f18eL), Double.longBitsToDouble(0x3fc0c69c2660b1b0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 21, "\uda0e\udf80\ud9dc\udcd3\ud83c\udfa4\ud865\udd30\uc296\uda93\udfb0\uda27\ude55\ud9c0\udc4a\ud9bd\udc8e\udbe4\udeff\ud888\udd31\ud808\udf3f\ud970\ude03", "\u0dda\u8d83\ubf48\u4225\u74fb\ua7fa\u3ae3\u50b1\u2e04\ua652\ub026\u5b0e\ua3ab\ud36a\u9773\u639d\u2a43\u567d\u0775\ua722\ua883\u7e20\uc449\ud2d5\u4d8c\u2838", "\u92c9\ud90a\udc82\udaab\udcec\ud957\udf79\udb93\udc5f\uda57\udf44\uda38\udc51\ud87f\ude34\uda43\udda3\ud8ae\udd50\udbcf\udd93\uda70\uddf3",
        26, 39993, 2015601068, 8584971918320967246L, -40999L, false, false, (char) 39921, (char) 61940,
        Double.longBitsToDouble(0x3fe7cc41c1b2f18eL), Double.longBitsToDouble(0x3fec03b4f1f3f4e5L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 1, 21, "\ud81f\udd67\ud9de\udca9\ud83c\udfa4\ud865\udd30\uc296\uda93\udfb0\uda27\ude55\ud9c0\udc4a\ud9bd\udc8e\udbe4\udeff\ud888\udd31\ud808\udf3f\ud970\ude03", "\u0dda\u8d83\ubf48\u4225\u74fb\ua7fa\u3ae3\u50b1\u2e04\ua652\u8fd2\u5b0e\ua3ab\ud36a\u9773\u639d\u2a43\u567d\u0775\ua722\ua883\u7e20\uc449\ud2d5\u0f86\u450c", "\u932e\ud90a\udc82\udaab\udcec\ud957\udf79\udb93\udc5f\uda57\udf44\uda38\udc51\ud87f\ude34\uda43\udda3\ud8ae\udd50\udbcf\udd93\uda70\uddf3",
        8, 39993, 2015601068, 8584971918320967246L, -40999L, false, false, (char) 39921, (char) 33268,
        Double.longBitsToDouble(0x3fe795d020b2f18eL), Double.longBitsToDouble(0x3fc0c69c27cfd10cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 9, 21, "\udaa4\udda9\udb5f\udc61\udb32\udff1\uda35\udf99\uda1c\udecb\uda93\udfb0\uda27\ude55\uda92\udfd3\ud808\udc7e\udbe4\udecf\ud888\udd31\ud808\udf3f\ud970\ude03", "\u0dda\u8d83\ubf48\ud14f\u74fb\ua7fa\u7167\ub212\ub520\ua652\ub026\u5b0e\ua3ab\ud36a\u3ffd\u8458\ud7eb\u7490\u0775\ua722\ua883\u7e20\uc449\u6b6c\u4d8c\ua77d", "\uda1c\udfb6\ud90a\udc82\udb5a\udc44\ud957\udf7e\udb93\udc5f\uda57\udf44\uda38\udc51\ud989\udd86\uda43\udcfa\ud8ae\udd50\udbcf\udd93\uda70\uddf3",
        26, 39993, 2015601068, 8584971918320967246L, -930L, true, true, (char) 39921, (char) 33268,
        Double.longBitsToDouble(0x3fe795d0214a47f6L), Double.longBitsToDouble(0x3fb271c5cf9fa218L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 0, 0, "\uda2f\udd90\ud9de\udcb6\ud83c\udfa4\ud865\udd30\uc296\uda93\udfb0\uda27\ude55\ud8ed\udcc1\ud98f\udce7U\000\udb43\udfe1\ud970\ude03", "\u0dda\u8d83\ubf48\u4225\u74fb\ua7fa\u3ae3\u50b1\u2e04\ua652\ub026\u12c2\u4215\ud36a\u9773\u639d\u2a43\u567d\u0775\u00a0\u6897\u7e20\uc449\ud2d5\u4d8c\u2838", "\u92c9\ud90a\udc82\udaab\udcec\000\000\ud8bf\udc3e\uda38\udc51\ud87f\ude34\uda43\udda3\ud8ae\udd50\udbcf\udd93\uda70\uddf3",
        26, 39993, 2015601068, 8584971918320967246L, -40999L, false, false, (char) 39921, (char) 33268,
        Double.longBitsToDouble(0x3fe795d020b2f18eL), Double.longBitsToDouble(0x3fc0c69c27cfd10cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 11, "\udab5\udd77\udb12\udf17\u5c48\ud9b5\udf1a\ud8de\udf3e\uda94\udc0e\ud922\ude00\ud99c\udc16\uda6b\udee2\ud840\udf24\udae7\uddf1\udac8\udd49\uda75\udd11\udbc5\udcdb\udbf5\udca3\u5554\ud9ce\udcac\udb00\udea1\ud882\ude52", "\u3ae3\u50b1", "\ud982\udca0\uda23\udf9d\udb58\udeb5\ud966\udd25\ud92c\udf42\ud8a4\udc1e\ud8ea\ude65\udb33\udcaf\ud8dc\udf69\ud998\uddd5\uda6d\udc96\ud922\uddad\udb6d\uddd2\ud8f4\ude18",
        52, 27951, 1993656108, -2019146006420629002L, 23923L, false, false, (char) 25916, (char) 36976,
        Double.longBitsToDouble(0x3fe4024360c67389L), Double.longBitsToDouble(0x3fe55ea32d63c14aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 17, 17, "\uda2f\udd90\ud9de\udcb6\ud83c\udfa4\ud865\udd30\uc296\uda93\udfb0\uda27\ude55", "\ua26e", "\ud970\ude03\udbc5\udcdb\ud8af\uded1\u9a7c\ud9ce\udcac\ud900\udef4\ud866\uded0\u08ee\udb29\ude85\udaea\udfc9\udae7\udf4e\udac0\udd08\udbf3\ude54\u1bac\uda23\udfcc\udac2\udd4a\uda38\udc31\ud951\udd94\udbe8\udc6f\ua3f8\u1d61\ud911\udc0e\ud9a8\udf9f\uda6d\udc96\ud922\uddad\udb6d\uddd2\ud8f4\ude18\ud8c6\udffb\udae6\udfce\udaf5\udedd\uda38\udeb2\u92c9\ud90a\udc82\udaab\udcec\ud957\udf79\udb93\udc5f\uda57\udf44\uda38\udc51\udb8d\udd5b\uda5b\udd20\udb2d\udc6f\ud9d6\udd72\uda32\udc60\ud83f\udd06\udab4\udd0f\ud9d4\udcc0\ud952\ude7e",
        24, 45410, 881531271, 157290591953525188L, 17006L, false, false, (char) 52582, (char) 9783,
        Double.longBitsToDouble(0x3fcd7ad2115e0a14L), Double.longBitsToDouble(0x3f901fde302f24a0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 9, 21, "\uda2f\udd90\ud9de\udcb6\ud83c\udfa4\ud865\udd30\uc296\uda93\udfb0\uda27\ude55\ud9c0\udc4a\ud9bd\udc8e\udbe4\udeff\ud888\udd31\ud808\udf3f\ud970\ude03", "\u0dda\u8d83\ubf48\u4225\u74fb\ua7fa\u3ae3\u50b1\u2e04\ua652\ub026\u5b0e\ua3ab\ud36a\u9773\u639d\u2a43\u567d\u0775\ua722\ua883\u7e20\uc449\ud2d5\u4d8c\u2838", "\u92c9\ud90a\udc82\udaab\udcec\ud957\udf79\udb93\udc5f\uda57\udf44\uda38\udc51\ud87f\ude34\uda43\udda3\uda72\ude97\uda33\udd8e\uda68\udd9d",
        26, 39993, 2015601068, 8584971918320967246L, -40999L, false, false, (char) 39921, (char) 33268,
        Double.longBitsToDouble(0x3fe795d020b2f18eL), Double.longBitsToDouble(0x3fc0c69c27cfd10cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 11, 19, "\uda2f\udd90\ud834\udcc1\uda49\udc60\uda92\udd44\uc296\uda93\udfb0\udb79\uddb7\ud9c0\udc4a\ud9bd\udc8e\udbb3\udf48\ud942\udebd\uda0c\udf58\udbea\ude3c", "\u0dda\u8536\ubf48\u4225\u74fb\ua7fa\u3ae3\u8a03\ub0ad\ua652\ub026\u4f3d\ua3ab\ud36a\u9773\u639d\u2a43\u567d\u0775\ua722\ua883\u7e20\uc449\ud2d5\u4d8c\u2838", "\u92c9\uc8f4\udaab\uddb6\ud957\udf79\udb93\udc5f\ud9bc\udf77\ud8a5\ude89\ud9b0\ude3a\uda43\udda3\ud8ae\udd50\udbcf\udd93\uda70\uddf3",
        26, 39993, 2015601068, 8584971918320967246L, -86270L, false, false, (char) 39921, (char) 55116,
        Double.longBitsToDouble(0x3fe795d023e82320L), Double.longBitsToDouble(0x3fc0c69c27cfd10cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 20, 15, 0, "\ud8c4\ude1a\ud9de\udcb6\ud83c\udfa4\ud851\udefd\uda8a\udff1\uda93\udfb0\ud863\udcc4\uda4c\udd46\ud98f\udce7\udbe4\udeff\ud8c1\udcee\ud9cd\ude73\ud970\ude03", "\000\u4fd8", "\udbf9\udcdc\udb29\ude85",
        7, -1000, 0, 56453325083261808L, 56054L, false, false, (char) 26103, (char) 17406,
        Double.longBitsToDouble(0x3fc0cdabc993bc30L), Double.longBitsToDouble(0x3fdbd32b51413f26L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 15, 0, "\ud8c4\ude1a\ud9de\udcb6\ud83c\udfa4\ud865\udcc2\uda8a\udf83\uda93\udfb0\u0093\ub700\ud98f\udce7\udbe4\udeff\ud888\udd31\ud808\udf3f\ud970\ude03", "\000\000", "\udbf9\udcdc\udb29\ude85",
        14, -1000, 0, 66730864L, 35021L, false, false, (char) 26103, (char) 17394,
        Double.longBitsToDouble(0x3fc0cdabc991f95cL), Double.longBitsToDouble(0x3fdbd32b51413f26L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 9, 21, "\uda17\udd90\ud9de\udcb6\ud83c\udfa4\ud865\udd30\uf13b\ud86c\udc50\ud889\udd4e\ud9c0\udc4a\ud9bd\udc8e\ud975\udf09\ud861\ude47\ud91a\uddeb\uda08\udea7", "\u0dda\u8d83\ubf48\u4225\u74fb\ua7fa\u3ae3\u50b1\u2e04\u202c\u1aaa\u0886\ua3ab\ud36a\u9773\u639d\ub74b\u567d\u0775\ua722\ua883\u3c81\u4c4a\ub818\u8f7d\ub15d", "\u92c9\ud90a\udc82\udbbb\ude74\ud957\udf79\udb93\udc5f\uda57\udf44\uda2c\udc51\ud87f\ude34\uda43\udda3\ud8ae\udd50\udbcf\udd93\ud837\uddf6\ud83f\udce2\udab4\udd0f\ud9d4\udfc0\ud98a\udd7e\ud90b\uddbe\uda81\ude0d",
        31, 59070, -1008297532, -5042696715651631374L, -78895L, true, false, (char) 11356, (char) 58567,
        Double.longBitsToDouble(0x3fd5e411e6c3901cL), Double.longBitsToDouble(0x3fd330dfe212a70aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.CreatorProperty|withValueDeserializer|com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.CreatorProperty:com.fasterxml.jackson.databind.deser.CreatorProperty,com.fasterxml.jackson.databind.PropertyName",
    "M|com.fasterxml.jackson.databind.deser.impl.FieldProperty|withValueDeserializer|com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.impl.FieldProperty:com.fasterxml.jackson.databind.deser.impl.FieldProperty",
    "M|com.fasterxml.jackson.databind.deser.impl.MethodProperty|withValueDeserializer|com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.impl.MethodProperty:com.fasterxml.jackson.databind.deser.impl.MethodProperty,java.lang.reflect.Method",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdReferenceProperty|withValueDeserializer|com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdReferenceProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReferenceProperty,com.fasterxml.jackson.databind.PropertyName",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|withValueDeserializer|com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.impl.SetterlessProperty|withValueDeserializer|com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.impl.SetterlessProperty:com.fasterxml.jackson.databind.deser.impl.SetterlessProperty,com.fasterxml.jackson.databind.PropertyName",
    "M|com.fasterxml.jackson.databind.deser.std.AtomicReferenceDeserializer|getNullValue|com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.AtomicReferenceDeserializer:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.deser.ValueInstantiator,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.JsonDeserializer",
    "M|com.fasterxml.jackson.databind.deser.CreatorProperty|_reportMissingSetter|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.CreatorProperty:com.fasterxml.jackson.databind.deser.CreatorProperty,com.fasterxml.jackson.databind.PropertyName",
    "M|com.fasterxml.jackson.databind.deser.CreatorProperty|_verifySetter||new:com.fasterxml.jackson.databind.deser.CreatorProperty:com.fasterxml.jackson.databind.deser.CreatorProperty,com.fasterxml.jackson.databind.PropertyName",
    "M|com.fasterxml.jackson.databind.deser.CreatorProperty|deserializeAndSet|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object|new:com.fasterxml.jackson.databind.deser.CreatorProperty:com.fasterxml.jackson.databind.deser.CreatorProperty,com.fasterxml.jackson.databind.PropertyName",
    "M|com.fasterxml.jackson.databind.deser.CreatorProperty|deserializeSetAndReturn|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object|new:com.fasterxml.jackson.databind.deser.CreatorProperty:com.fasterxml.jackson.databind.deser.CreatorProperty,com.fasterxml.jackson.databind.PropertyName",
    "M|com.fasterxml.jackson.databind.deser.CreatorProperty|findInjectableValue|com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object|new:com.fasterxml.jackson.databind.deser.CreatorProperty:com.fasterxml.jackson.databind.deser.CreatorProperty,com.fasterxml.jackson.databind.PropertyName",
    "M|com.fasterxml.jackson.databind.deser.CreatorProperty|fixAccess|com.fasterxml.jackson.databind.DeserializationConfig|new:com.fasterxml.jackson.databind.deser.CreatorProperty:com.fasterxml.jackson.databind.deser.CreatorProperty,com.fasterxml.jackson.databind.PropertyName",
    "M|com.fasterxml.jackson.databind.deser.CreatorProperty|getAnnotation|java.lang.Class|new:com.fasterxml.jackson.databind.deser.CreatorProperty:com.fasterxml.jackson.databind.deser.CreatorProperty,com.fasterxml.jackson.databind.PropertyName",
    "M|com.fasterxml.jackson.databind.deser.CreatorProperty|getCreatorIndex||new:com.fasterxml.jackson.databind.deser.CreatorProperty:com.fasterxml.jackson.databind.deser.CreatorProperty,com.fasterxml.jackson.databind.PropertyName",
    "M|com.fasterxml.jackson.databind.deser.CreatorProperty|getInjectableValueId||new:com.fasterxml.jackson.databind.deser.CreatorProperty:com.fasterxml.jackson.databind.deser.CreatorProperty,com.fasterxml.jackson.databind.PropertyName",
    "M|com.fasterxml.jackson.databind.deser.CreatorProperty|withValueDeserializer|com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.CreatorProperty:com.fasterxml.jackson.databind.deser.CreatorProperty,com.fasterxml.jackson.databind.PropertyName",
    "M|com.fasterxml.jackson.databind.deser.impl.FieldProperty|withValueDeserializer|com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.impl.FieldProperty:com.fasterxml.jackson.databind.deser.impl.FieldProperty",
    "M|com.fasterxml.jackson.databind.deser.impl.MethodProperty|withValueDeserializer|com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.impl.MethodProperty:com.fasterxml.jackson.databind.deser.impl.MethodProperty,java.lang.reflect.Method",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdReferenceProperty|withValueDeserializer|com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdReferenceProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReferenceProperty,com.fasterxml.jackson.databind.PropertyName",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|withValueDeserializer|com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.impl.SetterlessProperty|withValueDeserializer|com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.impl.SetterlessProperty:com.fasterxml.jackson.databind.deser.impl.SetterlessProperty,com.fasterxml.jackson.databind.PropertyName",
    "M|com.fasterxml.jackson.databind.deser.std.AtomicReferenceDeserializer|getNullValue|com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.AtomicReferenceDeserializer:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.deser.ValueInstantiator,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.JsonDeserializer",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
