package com.fasterxml.jackson.databind.type;
import org.junit.Test;
import static org.junit.Assert.*;
public class ResolvedRecursiveType_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 1, 12, 7, 0, "\ud97d\udd60\ud8ee\ude7c\ud8ce\udd80\uda18\udd58\ud9ca\udca6\udade\udde2\u0628\udab8\udcd6\ud920\udd38\udb50\udf97\udbe3\ude18\ud8ea\ude94\udb77\udcde\ud924\udd2e\ud917\uddee", "\ua868\u68a9\u5b94\u523b\ud22a\u922e\u4f1e\u9331\u58ee", "\udabf\udec2\u77f5",
        16, 8679, -349385939, 3004585298979416411L, -25986L, false, false, (char) 62770, (char) 18155,
        Double.longBitsToDouble(0x3fdadb5a89716bc0L), Double.longBitsToDouble(0x3fd69fe279ded848L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 1, 12, 7, 0, "\ud97d\udd60\ud8ee\ude7c\ud8ce\udd80\uda82\udd38\ud9ca\udcbc\udade\udde2\u0628\udab8\udcd6\ud920\udd38\udb50\udf97\udbe3\ude18\ud8ea\ude94\udb77\udcde\ud924\udd2e\ud917\uddee", "\ua868\u68a9\u5b94\u523b\ud22a\u922e\u5d0b\u8a9a\u58ee", "\udabf\udec2\u77f5",
        16, 8679, -349385939, 3004585298979416411L, -25986L, false, false, (char) 62770, (char) 18155,
        Double.longBitsToDouble(0x3fdadb5a88a946c8L), Double.longBitsToDouble(0x3fd69fe279ded848L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 1, 12, 7, 0, "\ud9a1\ude13\ud8ee\ude7c\ud8ce\udd80\uda18\udd58\ud9ca\udca6\udade\udde2\u0628\udab8\udcd6\ud920\uddd7\udb50\udf97\udbe3\ude18\ud8ea\ude94\udb77\udcde\ud924\udd2e\ud917\uddee", "\ua868\u68a9\u5b94\u523b\u843b\u922e\u4f1e\u9331\u58ee", "\udabf\udec2\u77f5",
        1, 25975, -337716114, 3004585298979416411L, -25986L, false, false, (char) 62770, (char) 18155,
        Double.longBitsToDouble(0x3fdadb5a89716bc0L), Double.longBitsToDouble(0x3fd69fe279ded848L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 7, 0, "\ud97d\udd60\ud8ee\ude7c\ud8ce\udd80\uda18\udd58\ud9ca\udca6\udade\udde2\u0628\udab8\udcd6\ud920\udd38\udb50\udf97\udbd6\udd52\ud8ea\ude6e\udb77\udcde\ud924\udd2e\ud917\uddee", "\ua868\u68a9\u5b94\u523b\ud22a\u8b7e\u4f1e\u9331\ud713", "\udabf\udec2\u77f5",
        16, 3199, -345337199, 3004585298979416411L, -25986L, false, false, (char) 62770, (char) 18155,
        Double.longBitsToDouble(0x3fdadb5a8971e686L), Double.longBitsToDouble(0x3fd69fe279ded848L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 7, 0, "\ud97d\udd60\ud8ee\ude7c\ud8ce\udd80\uda18\udd58\ud9ca\udca6\udade\udde2\u0628\udab8\udcd6\ud9a1\ude59\uda03\udf4c\ud834\ude7b\ud9e4\udc04\udb77\udcde\ud924\udd2e\udae7\uddb5", "\ua868\u68a9\u5b94\u523b\ud22a\u922e\u4f1e\u9331\u3e87\ua25c\uaaf9", "\ud989\udca9\ud8a4\udda6\udb3e\uddf2\ud808\udcde\ud81a\ude7a\ud813\udfbd\udbe1\ude69\uda5b\uddb2\ud8d5\udcf0\ud99f\udc35\udac4\udd4e\ud87d\udc9c",
        3, 3015, 438552079, -3370374208533227836L, -2426L, false, true, (char) 32126, (char) 16160,
        Double.longBitsToDouble(0x3fd7143efb9f0f10L), Double.longBitsToDouble(0x3fe4fde393e31a20L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |a3=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 1, 7, 7, 0, "\ud97d\udd60\ud8ee\ude7c\ud8ce\udd80\uda18\udd58\udafd\udeab\udade\udde2\u0628\udb2c\uddc8", "\u49a8\u8e6f\u2292\u2317\u2f71\u0d3e\u5d35", "\udabf\uddd0",
        34, 21937, -629938513, 882838124971372500L, -831L, false, false, (char) 30141, (char) 59904,
        Double.longBitsToDouble(0x3fbcee0553b81cd8L), Double.longBitsToDouble(0x3fd73e029cd3d658L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 1, 0, 7, 0, "\ud97d\udc65\ud8ee\ude7c\u027b\u6c7a\000\000\000\udab8\udcd6\ud504\000\udbe3\udd88\ud8ea\ude94\u85d4\ud924\udc3d\uf2e0", "\ua868", "\ud9a4\udcc8\ud9c8\ude2f\uda0d\udc78\udb50\udd51\udaa7\ude01\000\000\000\udabf\udec22\ud989\udc36\ud8a4\udda6\udb3e\uddf2\ud808\udcde\ud81a\ude7a",
        -1, 96302, -1402742112, -4732077255811364713L, -100000L, false, false, (char) 0, (char) 41707,
        Double.longBitsToDouble(0x3fd764df5470766cL), Double.longBitsToDouble(0x3fc5158ecd2fb4f0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=null |a3=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null]] |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 12, 7, 0, "\udbae\ude47\uda0f\uddb6", "\u9ea8\u4dac\u35f9\u5f1e\u5992\u6ef4\u49a8\uae1e\u2b13\ua28a\u2f71\u0d3e\u5d35\ua868\uaba8", "\ud807\udf07\ud9d5\udf78\ud819\udc35\udaa7\uddd2\udaef\udcc6",
        24, 51054, -1008969138, -5182042067364516749L, -38720L, false, true, (char) 29015, (char) 27136,
        Double.longBitsToDouble(0x3fc9f58c625ef950L), Double.longBitsToDouble(0x3fdadb5a85c817ceL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 1, 0, 0, 0, "\ud97d\udd60\ud8ee\ude7c\ud8ce\udd80\uda18\udd58\ud9ca\udca6\udade\udde2\u0628\udab8\udcd6\ud920\udd38\udb50\udf97\udbe3\ude18\ud8ea\ude94\udb77\udcde\ud924\udd2e\ud917\uddee", "\ua868\u68a9\u5b94\u523b\ud22a\u922e\u4f1e\u9331\u58ee", "\udabf\udec2\u77f5",
        16, 8679, -349385939, 3004585298979416411L, -25986L, false, false, (char) 62770, (char) 18155,
        Double.longBitsToDouble(0x3fdadb5a89716bc0L), Double.longBitsToDouble(0x3fd69fe279ded848L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 1, 1, 7, 0, "\ud97d\udd60\ud9e8\udd91\ud8ce\udd80\udaf1\udee9\ud9ca\udd36\udb31\uddab\ud95c\udd05\udac3\udea4\ud933\udfe4\udb50\udf97\udbe3\ude18\ud8ea\ude94\udb77\udcde\ud924\udd2e\ud917\uddee", "\u615e\u68a9\u5b94\u523b\ud22a\u922e\u4f1e\ub627\u5919", "\udabf\udec2\u77f5",
        10, 8740, -349385939, 3004585299365292379L, -25986L, false, false, (char) 62770, (char) 18155,
        Double.longBitsToDouble(0x3fdadb5a89716bc0L), Double.longBitsToDouble(0x3fd69fe279ded848L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 1, 10, 14, 0, "\ud88d\udd22\ud9c9\ude8a\ud927\ude8e\u2c9f", "\u7cd3\u8a28", "\ud850\udf50\ud8db\udc41\udb77\udcde\ud958\udf9a\ud992\udc30",
        9, 55746, -2087076896, -319264375361905157L, -48917L, false, true, (char) 20923, (char) 57684,
        Double.longBitsToDouble(0x3fe8c92e4a4e228dL), Double.longBitsToDouble(0x3fdf666dcbd2926cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 12, 7, 0, "\ud8c7\ude95\ud865\udc4c\ud8ce\udd80\uda18\udd58\ud9ca\udca6\udade\udde2\u0628\udab8\udcd6\ud920\udd38\udb50\udf97\udbe3\ude18\ud8ea\ude94\udb77\udcde\ud924\udd2e\ud841\uddf3", "\ua868\u68a9\u5b94\u523b\ud22a\u74d9\u9a20\u9358\u58ee", "\u2451\u77f5",
        16, 8679, -349385939, 3004585298979416411L, -25986L, false, false, (char) 62770, (char) 18155,
        Double.longBitsToDouble(0x3fdadb5a89716bc0L), Double.longBitsToDouble(0x3fd69fe279ded848L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |a3=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 1, 7, 11, 2, "\ud8d8\udce6\ud8ee\ude7c\ud8ce\udd80", "\u6567\u926c\u5f1e\u5992\u6ef4\u49a8\u8e6f\u90b8\u515f\u2f71\u0d3e\u5d35\ua868", "\ud902\udd96\ud9c8\ude53\uda0d\udc78\udb50\udd51\ud8eb\udf42\ud9fd\udecb\udbbe\ude6b\ud8ea\udfe9\udabf\udec2\u77f5\ud989\udca9\ud8a4\udda6\udb3e\uddf2\ud808\udcde\ud81a\ude7a",
        -1, 96302, -1402742112, -4732077255811364713L, -79960L, true, true, (char) 47379, (char) 26809,
        Double.longBitsToDouble(0x3fd0443893aae7daL), Double.longBitsToDouble(0x3fe61b1f77f333e2L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 1, 7, 7, 0, "\ud97d\udd60\ud8ee\ude7c\ud8ce\udd80\ud992\udf50\ud9ca\udca6\udade\udde2\uda6e\udc1e\udab8\udcd6\ud8ee\udc45\udb50\udf97\ud9b5\udd01\ud805\udfcd\ud8b6\ude19\ud803\udcfe\ud8df\udd69", "\u9ecd\u3337", "\ud9c8\ude2f\uda0d\udc78\udb50\udd51\udaa7\ude01\udad3\udcb6\udbbe\ude6b\ud8ea\udfe9\udabf\udec2\u77f5",
        16, 8679, -349385939, 3004585298979416411L, 88079L, false, false, (char) 62824, (char) 18155,
        Double.longBitsToDouble(0x3fdadb5a89716bc0L), Double.longBitsToDouble(0x3fd69fe279ded848L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 1, 8, 10, 3, "\udba0\udfca\ud8b9\udea5\ud8ce\udd80", "\ua228\ubd15\u68ed\u49be\u6ef4\u49a8\u8e6f\u2292\u2317\u2f71\u0d3e\u851c\ua868", "\ud9a4\udcc8\ud9c8\ude2f\uda0d\udc78\udb50\udd51\udaa7\ude01\ud9d4\ude05\udbbe\ude6b\ud8ea\udfe9\udabf\udec2\udb78\udf41\udaf0\udf02\ud8a4\udda6\udb3e\uddf2\ud808\udcde\ud81a\ude7a",
        45, 96302, -1402742112, -4732077255811364713L, -86872L, true, true, (char) 30824, (char) 13126,
        Double.longBitsToDouble(0x3fda7c893e2a1a14L), Double.longBitsToDouble(0x3fabac59fb680210L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 7, 0, "\ud97d\udd60\ud8ee\ude7c\ud8ce\udd80\uda18\udd58\ud9ca\udca6\udade\udde2\ud8f4\udd80\udbc2\ude62\ud909\udfb6\udb50\udf97\udb5a\ude2f\ud8ea\udf4c\udb77\udcde\ud924\udd2e\udb0e\udc49", "\u2bc8\u68a9\u4135\u8c2f\u9fe6\u922e\u4f1e\u215a\uab65", "\uda77\udd9b\udb51\udd07\ud989\udca9\ud8a4\udda6\udb3e\uddf2\ud808\udcde\ud81a\ude7a\udb79\udf81\uda14\udfd9\uda5b\uddb7\ud8d5\udcf0\ud99f\udc35\udb50\udc33\ud883\udf00\ud9cd\udfc8\u51b0\ud851\udcef",
        47, 19417, -2077826677, 5041684153571730750L, 98894L, false, false, (char) 17263, (char) 9561,
        Double.longBitsToDouble(0x3fc6c7054bd62d5cL), Double.longBitsToDouble(0x3fef9b27cfabe102L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=null |a3=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 10, 7, 0, "\ud9a1\ude13\ud8ee\ude7c\ud8ce\udd80\ud89f\udf7b\ud9ca\udd55\udade\udde2\u0628\udab8\udcd6\ud920\uddd7\udb50\udf97\udbe3\ude18\ud8ea\ude94\udb77\udcde\ud924\udd2e\ud917\uddee", "\ua868\u68a9\u5b94\u523b\u843b\u922e\u4f1e\u9331\u58ee", "\udabf\udec2\u77f5",
        1, 25975, -337716114, 3004585298979416411L, -25986L, false, false, (char) 62770, (char) 18155,
        Double.longBitsToDouble(0x3fdadb5a89716bc0L), Double.longBitsToDouble(0x3fd69fe279ded848L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=null |a3=[Lcom.fasterxml.jackson.databind.JavaType;:[[null]] |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 5, 7, 0, "\ud9a1\ude13\udab9\udd22\ud8e8\udddc\ud9d9\udc17\u9140\ud80e\udf04\u066d\udab8\udcd6\ud92f\udc4c\udb30\udcb0\udbe3\ude18\ud8ea\ude94\udb77\udcde\ud924\udd2e\ud917\uddee\udbb4\uddc3\udb25\udec2\udb23\udf3a\udadd\ude21\uda3c\ude4d\ud84c\ude9c\u2bd4\uda0d\udc7f\udb50\udd51\ud8c8\udf57\ud8f2\udd8b\ud822\ude59\ud8f4\udcf9\udabf\udec2\u14d1\ud86c\uddeb\ud8b3\uddab\udace\udfd8\ud88e\udc47", "\u7ba4\u0c46\u8a2c\u757a\u75d2\u4a88\u6994\u48dd,\u793f\u4323\ua8e9\u1722\uba98", "\ud9ff\uddd9\ud9b4\udf1c",
        5, 41829, -1394155935, 7442583004954560348L, -30663L, true, true, (char) 55343, (char) 55062,
        Double.longBitsToDouble(0x3fbbb556a4d21260L), Double.longBitsToDouble(0x3fe817d6c17795b8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 0, "\ud97d\udd60\ud8ee\ude7c\ud8ce\udd80\uda18\udd58\ud9ca\udca6\udade\udde2\u0628\udba1\udc0c\udaad\ude98\udada\udfc4\udbe0\udc06\ud8ea\ude6e\ud8d6\udff1\uda4b\ude21\uda2e\udddb", "\ua868\u68a9\ud50e\u4ef0\ud22a\u8b7e\u4f1e\u9331\ud713", "\udacb\udfa7\ud812\udf2a",
        16, 3199, -345337199, 3004585298979416411L, -25986L, false, false, (char) 62770, (char) 18155,
        Double.longBitsToDouble(0x3f9e0e2b8ddba180L), Double.longBitsToDouble(0x3fd69fe27d8c6648L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 10, "\ud97d\udd60\ud8ee\ude7c\ud8ce\udd80\uda18\udd58\ud9ca\udca6\udade\udde2\u0628\udab8\udcd6\ud920\udd38\udb50\udf97\udbd6\udd52\ud847\udc65\udb77\udc54\ud924\udd2e\ud917\uddee", "\ua79a\u68a9\u5b94\u0f45\u9faa\u8c30\u4f1e\u9331\ud713", "\ud83d\udd8e\ud969\uddc4\ud989\udca9\ud999\udc41\ud9b8\udd5a\ud808\udcde\ud81a\ude7a\u3428\ud9c7\uded9\uda5b\uddb2\ud900\udef0\ud99f\udc35\udb41\udcec\ud87d\udc9c\uda3b\udff6\ud9a9\udda3",
        42, 98417, 676948458, -1926157356032214264L, 78880L, true, false, (char) 22993, (char) 60282,
        Double.longBitsToDouble(0x3fb348ab9f7158e8L), Double.longBitsToDouble(0x3fc90e7681c8514cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=void |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 14, 8, 0, "\ud97d\udd60\ud8ee\ude7c\udb7a\udcb6\ud8ee\udd50\udbb8\udfd2\ud8eb\udca8\u90f0\udab8\udcd6\ud9a1\ude59\ud83d\ude2a\ud94c\udc05\ud9e4\udc04\udb77\udcde\ud924\udd2e\udae7\udd90", "\ua868\u68a9\u5b94", "\uda0d\udc78\udb50\udd51\udaa7\ude01\ud823\udf0d\ud975\udf61\ud8ea\udfe9\udba0\udd11\u7803\ud921\uddf5\ud8bf\udc59\ud968\udcf9",
        14, 94075, 518305259, 6476494150465477280L, -86872L, true, true, (char) 47379, (char) 54722,
        Double.longBitsToDouble(0x3fe16273fda15552L), Double.longBitsToDouble(0x3fd61ac895b5d530L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 12, 13, 0, "\ud97d\udd60\ud966\udd45\ud8ce\udd80\uda18\udd58\ud9ca\udca6\udade\udde2\u0628\udab8\udcd6\ud954\udcb7\ud9fa\udf52\ud834\ude7b\ud9e4\udc04\udb77\udcde\ud924\udd2e\udae7\uddb5", "\ua868\u68a9\u5b94\u523b\ud22a\u922e\u4f1e\u9331\u3e87\ua25c\uaace\u3a5d\u8703\u60b9\uc20f\ua5de\u784c\u5b3f\u6288\u7ba4\u8f87\u8af9\ua87a", "\ud9cd\udfc8\ud945\udf68\ud947\udf99\uda7f\udeae\ud8fa\udde8\uf72d\ud82f\udf32",
        19, 92794, 1139746976, -8680567950791238193L, 85315L, false, false, (char) 11729, (char) 23641,
        Double.longBitsToDouble(0x3fd84c3c3638d8c2L), Double.longBitsToDouble(0x3fe009ec4284082eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |a3=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null]] |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=null |a3=[Lcom.fasterxml.jackson.databind.JavaType;:[[null]] |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 7, 7, 0, "\ud97d\udd60\ud8ee\ude7c\ud8ce\udd80\uda18\udd58\udafd\udeab\udade\udde2\u0628\udb2c\uddc8", "\u49a8\u8e6f\u2292\u2317\u2f71\u0d3e\u5d35", "\udb6b\udec5",
        18, 64097, -52871438, -7359429344137629740L, -809L, false, false, (char) 9353, (char) 5650,
        Double.longBitsToDouble(0x3fd73c929cd3d658L), Double.longBitsToDouble(0x3fe3c70374cf0e1bL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |a3=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=null |a3=[Lcom.fasterxml.jackson.databind.JavaType;:[[null]] |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 7, 7, 0, "\ud97d\udd60\ud8ee\ude7c\ud8ce\udd80\uda18\udd58\ud989\udc90\udaf1\uddae\u0628\udb2c\uddc8", "\u49a8\u8e6f\u2292\ub40a\u2f71\u0d3e\u5d35", "\uda13\udd39",
        13, 21861, -629938513, 882838124971372500L, -831L, false, false, (char) 30141, (char) 59904,
        Double.longBitsToDouble(0x3fbcee0553b81cd8L), Double.longBitsToDouble(0x3fd73e029cd3d658L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=java.lang.String:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 13, 9, 15, "\ud97d\udc65\ud8ee\ude7c\ud975\udec2\u6c7a\uda39\uddfb\u00c5\u551c\udab8\udcd6\ud504\000\uda74\udff1\uda6e\udffb\ud965\udc89\ud8b4\udfdc\ud900\udf7d", "\uc849\ua751\u5b94\u7ef8\u2ecf\ua5fc\u8810\u593f\000\000\000\ud3062\uaae3", "\ud808\udcde\ud81a\ude7a\ud813\udfbd\udbe1\ude69\uda5b\uddb2\ud8d5\udcf0\ud99f\udc35\u93ad",
        6, 51534, -116577734, 5617582731831949686L, 39708L, false, false, (char) 10060, (char) 65023,
        Double.longBitsToDouble(0x3feec2f07a2b9b06L), Double.longBitsToDouble(0x3fdd9358b8dda30aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 14, 12, 0, "\udb68\udc38\ud968\udd8f", "\u85ac\u6505\u31de\u5f1e\u5992\u6ef4\ube1a\uae1e\u2b13\ubcea\u2ea2\u940a\uc076\u0952\u24e6", "\ud807\udf07\ud9fd\udfa7\ud830\udfcf\udacb\ude1f",
        30, 53637, 581937111, -4333489450163785678L, 91925L, false, true, (char) 1940, (char) 12306,
        Double.longBitsToDouble(0x3fdc65910d2f95c8L), Double.longBitsToDouble(0x3fe5047b00cfac63L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 0, 0, 0, "\ue30c", "\000\uaa71\u1da8\000", "\udb4a\ude44\udbe3\ude18\udadb\udf1d\ud85b\udd3f\ud885\udfc6\ud917\uddee\u67b8\uda67\uddae\udbed\udf6f\udab8\udd21\000\000\000\ud9d5\udf78\ud819\udc35\udaa7\uddd2",
        4, 31920, 581913054, -4333489450383310848L, -100000L, false, false, (char) 0, (char) 61279,
        Double.longBitsToDouble(0x3fdc65910ce60000L), Double.longBitsToDouble(0x3f41ec033eb00000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 2, "\udb01\uddc8\ud9f4\udcf6", "\u9ea8\u4dac\u35f9\u5f1e\u5992\u6ef4\u49a8\uaa06\u2b13\ua28a\u2f71\u0af9\u5d35\ua868\uaba8", "\ud807\udf07\ud9d5\udf78\ud819\udc35\udaa7\uddd2\udaef\udcc6",
        24, 51054, -1008969138, -5182042067364516749L, -38720L, false, true, (char) 64984, (char) 27136,
        Double.longBitsToDouble(0x3fc9f58c625ef950L), Double.longBitsToDouble(0x3fdadb5a85c817ceL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 12, "\udbae\ude47\udb18\ude5c", "\u9ea8\u4dac\u3774\u3d9d\u5992\u6ef4\u49a8\uae1e\u1fd1\u3627\u5d29\u481e\u22d6\ua7eb\uaba8", "\ud807\udf07\ud9d5\udf78\ud819\udc35\udaa7\uddd2\udae8\uddc6",
        24, 51054, -1012573618, -5182042067364516749L, -55104L, false, true, (char) 61608, (char) 360,
        Double.longBitsToDouble(0x3fdafd9eb0e0b24aL), Double.longBitsToDouble(0x3fd8974755c816f8L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 10, "\ud97d\udd60\ud8ee\ude7c\ud8ce\udd80\uda18\udd58\ud9ca\udca6\udade\udde2\u0628\udab8\udcd6\ud920\udd38\udb50\udf97\udbd6\udd52\ud847\udc65\udb77\udc54\ud924\udd2e\ud917\uddee", "\u9ff0\u6889\u5b94\ud6aa\u9faa\u8c30\u4f1e\u9331\u00d0", "\ud83d\udd8e\ud969\uddc4\ud989\udca9\ud999\udc41\ud9b8\udd5a\ud808\udcde\ud81a\ude7a\u3428\ud9c7\uded9\uda5b\uddb2\ud900\udef0\ud99f\udc35\udb41\udcec\ud87d\udc9c\uda3b\udff6\ud9a9\udda3",
        42, 98417, 676948458, -1926157356032214264L, 78880L, true, false, (char) 22993, (char) 60282,
        Double.longBitsToDouble(0x3fb348ab9f7158e8L), Double.longBitsToDouble(0x3fc90e7681c8514cL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null |a3=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=null |a3=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 7, 7, 0, "\ud97d\udd60\ud8ee\ude7c\ud8ce\udd80\uda18\udd58\udafd\udeab\udade\udde2\u0628\udb2c\uddc8", "\u49a8\u8e6f\u5375\u222f\u2f71\u0d3e\u5d35\u5fa0\u16b5\u8c51\u0e0e", "\ud879\udffc\udaa7\ude01\ud9d4\ude05\udb4a\udc56\udbbe\uddb1\udba0\udfd6",
        39, 96755, -1955945353, -7793164573082047543L, 99887L, true, false, (char) 40969, (char) 50301,
        Double.longBitsToDouble(0x3fe89c9a0b95eaedL), Double.longBitsToDouble(0x3fe1cfe7d99b2b95L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 1, 12, 7, 0, "\ud8a4\udd53\ud8ee\ude7c\ud8ce\udd80", "\u8a29\u230c\u5ef5\u59ab\u6ef4\u49a8\u1165\u8461\u2253\u2f71\u0d3e\u228b\ubac8", "\udad1\udcce\ud880\udd4e\udbe2\ude1f\u2f97\udb38\udd0d\udaa2\udf5d\udbbe\udef8\udace\udcfa\udb77\udf06\u1a2d\ud989\udca9\ud8db\udca6\udb3e\uddf2\udaa9\udd51\ud81a\ude87",
        -1, 96302, -1402742112, -4732077255811364713L, -86872L, true, true, (char) 47379, (char) 13997,
        Double.longBitsToDouble(0x3fc7feb08c39900cL), Double.longBitsToDouble(0x3fc38cb48972c550L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=void |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 8, 8, 0, "\ud97d\udd60\ud8ee\ude7c\ud8ce\udd80\uda18\udd58\ud9ca\udca6\ud998\udd7e\ud847\udc0e\udab8\udcd6\ud920\udd38\ud940\ude4b\udbe3\ude18\ud8ea\ude94\udb77\udcde\ud924\udd2e\ud917\uddee", "\u9f49\u0b1a\u5b4b\u523b\ud22a\u922e\u4f1e\u9331\u58ee", "\udabf\udec2\u77f5",
        16, 8679, -349385939, -635802442494719648L, -25986L, false, false, (char) 62770, (char) 49097,
        Double.longBitsToDouble(0x3fdadb5cd9716bc0L), Double.longBitsToDouble(0x3fd698fb59ded848L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|getSuperClass||new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|_narrow|java.lang.Class|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|equals|java.lang.Object|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|getErasedSignature|java.lang.StringBuilder|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|getGenericSignature|java.lang.StringBuilder|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|getSelfReferencedType||new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|isContainerType||new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|refine|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|setReference|com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|toString||new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|withContentType|com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|withContentTypeHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|withContentValueHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|withStaticTyping||new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|withTypeHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|withValueHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|getSuperClass||new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
