package com.fasterxml.jackson.databind.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class TokenBuffer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 26, 23, 26, "\ud8b9\ude58\udb15\udf3b\udbdc\udf14\udb15\udd8e\ud9aa\ude34\ud901\udc25\ud88a\udde4\udb0a\udcb9\ud936\uddde\udb9b\udeef\udafa\udc36\u789b\ud9c9\ude69\uda68\udf11\udb10\ude86", "\u7a62<\u64b7\u8beb\u964d\u85f1\u3714\ua6db\u2baa\u0f36\u8df6\u9059", "\ud90c\uddda\ud854\udc3d\udbb2\ude6c\udbc9\udda4\ud93d\udf0d\ud830\ude70\ub6c3\ud8b4\udd5a\u7ca7\udae0\ude0b\udb44\udd3e\udb85\udf84\ud843\udedd\udb70\ude15\ud939\udfd7\ud9fb\udf37",
        47, 76690, -104876780, -5921358905949080095L, -48434L, true, true, (char) 53797, (char) 38335,
        Double.longBitsToDouble(0x3fc4c686abd33720L), Double.longBitsToDouble(0x3fd16ae539fc790aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 26, 23, 7, "\udaa6\udc4b\udb15\udf3b\udbdc\udf14\udb15\udd8e\udafc\ude3d\ud901\udc25\ud88a\udde4\uda48\udded\udb78\udf4c\udb4d\udc87\udaeb\udf61\u789b\ud9c9\ude69\udba3\ude4f\udb10\udeb0", "\ucbc6\u20f3\u64b7\u8beb\u964d\u85f1\u3714\u83e5\u0800\u6f90\u8df6\u9059", "\ud90c\uddda\ud854\udc3d\udbb2\ude6c\udbc9\udda4\ud93d\udf0d\ud830\uddd9\ub6c3\udaf8\ude9c\uda95\udde2\udae0\ude0b\udb06\ude7e\udb85\udeb4\ud843\udedd\udb70\ude15\ud939\udfd7\ud82c\udf50",
        47, 76690, 1539290388, -5921103973870258719L, -48434L, true, true, (char) 53950, (char) 2751,
        Double.longBitsToDouble(0x3fc4c69f6bd33720L), Double.longBitsToDouble(0x3fd16ae539fc790aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 33, 23, 27, "\ud8b9\ude58\udb15\udf3b\udbdc\udf14\udb15\udd8e\ud9aa\ude34\ud901\udc25\ud88a\udde4\ud8dd\udd43\udbf9\udcb8\u69cf\ud9f6\udc71\u789b\ud9c9\ude69\uda68\udf11\udb10\ude86\ud830\udf49\uda17\udd94\udb48\ude65\ud92b\udd05\ud84a\udc38\ud9ce\udd18\ud960\udc57\udb3f\uddc1\ud91b\udc64\ud908\udef4\ud84e\udcc0\uda15\uddcc\udb11\udea4\udafc\udd76\ud9d2\udf9c\ud87d\udd49\ud90c\uddda\ud854\udc3d\udb0e\udd2e\udbc0\udeb4\ud93d\udf0d\uda74\uddf3\ud8bc\udf7c\ud83c\udca1\u7ca7\udae0\ude0b\udb44\udd3e\u3789\ud843\udedd\ud9bd\ude3d\udbd5\udee5\ud9fb\udf37\ud8f6\udc39\ud9cf\udf69\udab1\udcb5\ud8d7\ude9b\ud8e8\udc2e\uee53\udb6d\udce7\udb2c\uddc2\ud8f3\uddb8\uda6c\udd60\ud976\uddb0\udb9d\udf8d\udae9\udfa6", "\u5df0\ub96b\u3397\uc52b\u941d\u1464\u995e\u5594", "\udb39\udfbf",
        28, 23453, 1929733181, -1005641715178663932L, -43508L, false, true, (char) 5466, (char) 10597,
        Double.longBitsToDouble(0x3fbecbf7ea13e178L), Double.longBitsToDouble(0x3fd3fe44aff6bb9cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 23, 27, "\ud8b9\ude58\udb15\udf3b\udbdc\udf14\ud821\uddd6\ud999\udea6\ud901\udc25\ud88a\udde4\ud930\udf03", "\u7dce\u8d6d\u4bb3\u3a10\u0f5b\u18d2\u66f0\u8d7e\uc76f\ucc75\u0f9e\u6404", "\ud98d\udf03\ud81e\udc19\ud886\ude8c\ue999\udafc\udd1f\ud9d2\udf9c\ud87d\udd49\ud90c\uddda\ud854\udc3d\udbb2\ude6c\udbc9\udda4\uda48\udc11\ud813\udc07\uda82\ude7d\ud8b4\udd87\u7ca7\udae0\ude0b\udb44\udd3e\udaed\udfba\ud93f\udde0\ud89e\udc04\ud939\udfd7\ud9fb\udf37\udb23\udc4a\u26d7\udab1\udcb5",
        45, 62185, -597559120, 818307759103745987L, 92842L, false, false, (char) 30908, (char) 11114,
        Double.longBitsToDouble(0x3fcfceb0a03aba0cL), Double.longBitsToDouble(0x3fe384c3a89c05ffL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 1, 26, "\ud8b9\ude58\udb15\udf3b\udbdc\udf14\udb15\udd8e\ud9aa\ude34\ud901\udc25\ud88a\udde4\udb0a\udcb9\ud936\uddde\udb9b\udeef\udafa\udc36", "\u3a10\u0f5b\u18d2\u66f0\u42e7<\u64b7\u8beb\u1851\uc54c\uc8f9", "\udae3\ude94\uf8e8",
        58, 7150, -250022358, 7949173687057864479L, 66066L, false, true, (char) 50991, (char) 42679,
        Double.longBitsToDouble(0x3fc77eb97ef31ab4L), Double.longBitsToDouble(0x3fe0829ba76abbd7L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 26, 28, "\udb54\udc45\udb15\udf42\udbdc\udf14\udb15\udd8e\ud9aa\ude34\ud901\udc25\udb3d\udc5d\ud895\ude5f\ud936\uddde\udb9b\udeef\udafa\udc36\u789b\ud9c9\ude69\uda68\udf11\udb10\ude86", "\u73fa\u127c\u64b7\u8beb\u964d\u85f1\u3714\ua6db\u2baa\u0f36\u5be7\u9112", "\ud90c\uddda\ud854\udc3d\udb99\ude85\udbc9\udda4\u2a08\udbf9\udc6f\ud938\udf61\ud950\udd17\u062a\udae0\udedc\udb44\udd3e\udb85\udf84\ud843\udedd\udb70\ude15\ud93b\uddd7\ud9fb\udf37",
        47, 76690, -104876780, -8234641210836306463L, -48434L, true, true, (char) 53797, (char) 38335,
        Double.longBitsToDouble(0x3fc4c686abd33720L), Double.longBitsToDouble(0x3fd16ae539fc790aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 22, 2, 26, "\ud8b9\ude58\udb15\udf3b\udbdc\udf14\udb15\udd8e\ud9aa\ude34\ud901\udc25\ud88a\udde4\udb0a\udcb9\ud936\uddde\udb9b\udeef\ud8ea\udf6f\ud9f6\ude12\uda41\udf5e\uda68\udef0\udb10\ude86", "\u7a6d\u9508\u659e\u8c55\u9689\u85f1\u3714\ua6db\u2baa\u0f36\u8df6\u9059\ua910\u5480\u7e19\u7dc7\ud134\u2c3a\u506b\u76a4\u33b7\u3f14\u73a6\u1548\u735a\ud4eb\u2cdf\uc99e\u47b3\u8b59\u78b1\u6a5e\u45ab\uca0d\ub347\u4650\u8c07\u9540\u00fb\u4cde\u8121\u4227\u66b4\u3c8a\u64c6\u3c95", "\ud918\ude02\ud9b0\ude32\ud907\udd3a\ud875\udf00\ue4bf",
        26, 22009, -420214134, 2282617878306448741L, 48265L, true, false, (char) 4693, (char) 6943,
        Double.longBitsToDouble(0x3feed17f9f6253e4L), Double.longBitsToDouble(0x3fe82eb8f52526b6L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 15, 34, "\ud8b9\ude58\udb15\udf3b\udbdc\udf14\udb0c\udf8e\ud9aa\ude34\ud901\udc25\ud88a\udde4\udb0a\udcb9\ud936\uddde\udb9b\udeef\udafa\udc36\u789b\ud9c9\ude69\uda68\udf11\udb10\ude86", "\u22d5<\u64b7\u8beb\ub675\u85f1\u3714\ua6db\ua70f\ud130\u1c62\u7964", "\ud90c\uddda\ud854\udc3d\udbb2\ude6c\uda9d\udcb3\ud93d\udf0d\ud830\ude70\ub6c3\ud9db\ude4d\udbc0\udf87\udae0\ude0b\udb4c\udfd9\udb85\udf84\udb66\ude2f\udb71\udcc2\ud9e3\udfcc\ud9fb\udf37",
        47, 76690, -104876780, -5921358905949080095L, -48434L, true, true, (char) 53797, (char) 38335,
        Double.longBitsToDouble(0x3fc4c686abd33720L), Double.longBitsToDouble(0x3fd16ae539fc790aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 34, 31, 26, "\ud8b9\udeb9\udb15\udf3b\udbdc\udf14\udb15\udd8e\ud9aa\ude34\ud901\udc25\ud88a\udde4\udb0a\udcb9\ud936\uddde\udb9b\udeef\udafa\udc36\u789b\ud9c9\ude69\uda68\udf11\udbd0\ude86", "\u7a62<\u64b7\u9beb\u964d\u7f81\u2999\u8468\u640d\u0f36\u65aa\u9a20\u9e50\u2372\ub5b9\u7d99\ud134\u2c3a\u506b", "\ud8b4\udd5a\u7ca7\udae0\ude0b\udb44\udd3e\udb85\udf84\ud843\udedd\udb70\ude15\ud939\udfd7\ud978\udc95\udb23\udc42\u26d7\udab1\udcb5\ud8d7\ude9b\ud8e8\udc2e\uee53\ud925\udf3d\udabf\uddc2\ud8f3\uddb8",
        6, 44142, -1370248460, 4361029348973804798L, -98044L, true, false, (char) 5665, (char) 35784,
        Double.longBitsToDouble(0x3fcfee64a789a15cL), Double.longBitsToDouble(0x3fd06889d2eaf81aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 20, 23, 26, "\ud8b9\ude58\udb15\udf3b\udbdc\udf14\udb15\udd8e\ud9aa\ude34\ud901\udc25\ud88a\udde4\udb0a\udcb9\ud936\uddde\udb9b\udeef\udafa\udc36\u789b\ud9c9\ude69\uda68\udf11\udb10\ude86", "\u7a62<\u64b7\u8beb\u964d\u85f1\u3714\ua6db\u042f\u484e\u8df6\u9059", "\ud87a\ude71\u0dc1\udbb2\ude6c\udbc9\udda4\ud93d\udf0d\ud830\ude70\ud8c6\udfd0\ud8b4\udd5a\u7ca7\udae0\ude0b\udb44\udd3e\udb85\udf84\ud843\udedd\udb70\ude15\ud88b\udf76\ud9fb\udf37",
        47, 76690, -104876780, -5921358905949080095L, -32562L, true, true, (char) 53797, (char) 38335,
        Double.longBitsToDouble(0x3fc4c686abd33720L), Double.longBitsToDouble(0x3fd16ae539fc790aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 19, 23, 26, "\ud8b9\ude58\udb15\udf3b\udbf0\udc5e\udb15\udd8e\udb5b\udece\ud901\udc25\ud88a\udde4\udb0a\udcb9\ud936\uddde\udb9b\udeef\udafa\udc36\u789b\ud9c9\ude69\u5f0a\ud90d\uddab", "\u7a98<", "\uda11\udc2d\udb3f\udd89\ud91b\udc64\uda1b\ude23\ud84e\udcc0\ud886\ude25\ue999",
        58, 7150, -250022358, 7949334610892511007L, -96055L, true, true, (char) 51846, (char) 58985,
        Double.longBitsToDouble(0x3fe691acff6abbd7L), Double.longBitsToDouble(0x3fdfb9753eeffb86L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 26, 23, 26, "\ud8b9\ude58\udb15\udf3b\udbdc\udf14\udb15\udd8e\ud9aa\ude34\ud901\udc25\ud88a\udde4\uda48\udcb8\ud936\uddde\udb9b\udeef\udafa\udc36\u789b\ud9c9\ude69\uda68\udf11\udb10\ude86", "\u7a62<\u64b7\u8beb\u964d\u85f1\u3714\ua6db\u2baa\u0f36\u83f6\u9059", "\ud90c\uddda\ud854\udc3d\udbb2\ude6c\udbc9\udda4\ud8ec\udec5\ud813\udd28\ub6c3\ud8b4\udd5a\u7ca7\udae0\ude0b\udb44\udd3e\udb85\udf84\ud843\udedd\udb70\ude15\ud939\udfd7\ud9fb\udf37",
        47, 76690, -104876780, 9200884217834077831L, -13675L, true, true, (char) 53797, (char) 38335,
        Double.longBitsToDouble(0x3fc4c686abd33720L), Double.longBitsToDouble(0x3fd16ae539fc790aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|_appendValue|com.fasterxml.jackson.core.JsonToken|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|_appendValue|com.fasterxml.jackson.core.JsonToken,java.lang.Object|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeBoolean|boolean|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNull||new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNumber|double|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNumber|float|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNumber|int|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNumber|java.lang.String|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNumber|java.math.BigDecimal|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNumber|java.math.BigInteger|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNumber|long|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNumber|short|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeObject|java.lang.Object|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeRawValue|[C,int,int|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeRawValue|java.lang.String|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeRawValue|java.lang.String,int,int|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|_appendValue|com.fasterxml.jackson.core.JsonToken|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|_appendValue|com.fasterxml.jackson.core.JsonToken,java.lang.Object|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeBoolean|boolean|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNull||new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNumber|double|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNumber|float|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNumber|int|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNumber|java.lang.String|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNumber|java.math.BigDecimal|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNumber|java.math.BigInteger|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNumber|long|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeNumber|short|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeObject|java.lang.Object|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeRawValue|[C,int,int|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeRawValue|java.lang.String|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeRawValue|java.lang.String,int,int|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeString|[C,int,int|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeString|com.fasterxml.jackson.core.SerializableString|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeString|java.lang.String|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|writeTree|com.fasterxml.jackson.core.TreeNode|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
