package com.fasterxml.jackson.databind;
import org.junit.Test;
import static org.junit.Assert.*;
public class ObjectMapper_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 4, "\udb8b\udddf\udbeb\ude31\udba9\ude1b\ud8d8\ude0f\ud824\uddb8\ud851\udc2a", "\u692e\u2497\ua477\u6894\ua5d1\u5f60", "\udb2e\udf67\udb0d\ude36\ud87e\udcd3\ud85f\udfcc\ud838\udc49\uda32\udc90",
        28, 54399, -808288561, 6005611541264057228L, -98519L, false, true, (char) 54534, (char) 908,
        Double.longBitsToDouble(0x3feef8393c5be691L), Double.longBitsToDouble(0x3fe42fa4e3f491bbL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 22, 4, "\ud878\ude42", "\ub7cd", "\udbe7\udf54\udabf\udd6e\ud8cc\udd54\udabf\udf7b\ud977\ude3a\udbc9\udf59\ud801\udea7\ud915\udfe5\uda41\udca9\udaa1\udf84\ud8d4\udc79\ud97d\udf17",
        1, 13045, -1326345836, 1592888251950885832L, -94904L, true, false, (char) 5950, (char) 47521,
        Double.longBitsToDouble(0x3fdc965c890a3fa0L), Double.longBitsToDouble(0x3fe78386ed880117L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 15, 20, "\ud89b\ude1b\udad5\udd85\udba9\ude1b\ud8d8\ude0f\ud824\uddb8\ud91b\ude90\ud8ad\ude8c", "\u7301\u0cc2\uc794\u3eb9", "\udbb0\udd34\udb2e\udf67\uda92\uddf6\ud9f3\ude13\udae9\udf24\ud9fc\udcb8\udaa1\udc6d\udb60\udcf6\udba3\udf21\ud872\udff8\ud963\udcca\uda03\uded5",
        34, 50969, -1191237150, -6398274862889750189L, -38931L, true, false, (char) 11695, (char) 44083,
        Double.longBitsToDouble(0x3fdf5d8f55a53256L), Double.longBitsToDouble(0x3fc1272324274540L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 10, 4, "\udb8b\udddf\ud981\udc1a\ud8c6\udec7\ud8c5\udd38\ud81c\uddfe\udb6a\udd11", "\u692e\u2497\ua477\u18e1\u492a\u13d4", "\udb2e\udf67\udb0d\ude36\ud87e\udcd3\ud85f\udfcc\ud838\udc49\uda32\udc90",
        28, 54399, -808288561, 6005611541264057228L, -98519L, false, true, (char) 54534, (char) 908,
        Double.longBitsToDouble(0x3feef8393c5be691L), Double.longBitsToDouble(0x3fe42fa4e3f491bbL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "\udb8b\udddf", "\u2995\000", "\udabf\uddbe",
        31, 910, -1375731712, -3856488643590435439L, 54500L, true, true, (char) 31268, (char) 53993,
        Double.longBitsToDouble(0x3e104b4000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 8, "\udb8b\udddf\udbeb\ude31\udba9\ude1b\ud8d8\ude0f\ud824\uddb8\ud851\udc2a", "\u692e\u2497\ua477\u6894", "\ud91f\udee8\udbb0\udd34\udb2e\udf67\udb0d\ude36\ud87e\udcd3\ud85f\udfcc\ud838\udc49\uda32\udc90\udb22\udd11\ud973\ude18",
        54, 45401, -1341668468, 7334122549175911881L, 14655L, true, true, (char) 35617, (char) 11695,
        Double.longBitsToDouble(0x3fec39d9f64f871cL), Double.longBitsToDouble(0x3fb5730f81fcfcd8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 4, "\uda4b\ude9d\ud8de\ude30\udba9\ude1b\ud8d8\ude0f\ud824\uddb8\ud851\udc2a\ud9c0\ude4e\udabf\uddbe\uda2e\udc95\uda6d\udeeb\ud8cb\udef9\uda31\udcdb\ud800\udf97\ud859\udc66\ud91f\udee8\udb5f\uddae\udb2a\udc44\udb1b\udc56\udb3a\udcab\ud886\udc1f\ud838\udc49\uda32\udc90", "\u492b\ub241\u2bb5\uaa3b\u3414\u59d2", "\ud874\udca0\ud882\udfaf\ud9a6\udc05\udac3\udf21\ud9db\udc89\uda41\ude73\ud84e\udfd5\ud821\uddd1\udb30\udca1\ud861\uddfb",
        40, 88803, 1840397126, 6218464453414849945L, -76062L, true, true, (char) 40561, (char) 65314,
        Double.longBitsToDouble(0x3feeee8fe5b878e4L), Double.longBitsToDouble(0x3fe3f6089304185fL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 14, 20, "\udb8b\udd8b\udbeb\ude31\udba9\ude1b\ud8d8\ude0f\u13aa\ud850\udfbb", "\000", "\uda31\udcdb\u2e97\ud859\udc66\000\000\udb2e\udf57\udb0d\ude36",
        16, 68274, 1967360352, 2400434655113038874L, -67537L, true, true, (char) 5720, (char) 45056,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 17, "\udbc8\ude84\udbeb\ude31?\ud8d0\udd27\ud8dc\udfb5\ud839\udcbb", "\u00d5\u2497\ua477", "\ud859\udc66",
        55, 11541, -756417024, -6989585653797657856L, -69632L, false, false, (char) 60777, (char) 31599,
        Double.longBitsToDouble(0x3fe67f106fe1cfd2L), Double.longBitsToDouble(0x3fec629ac19ab007L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 4, "\ud92f\udc8b\udbeb\ude39\uda8f\uddee\ud8d8\udd83\ud824\uddb8\udaae\udd31\ud9c0\ude4e", "\u2497\ua477\u6894\ua5d1\u5f60\u9c1e\u24f4\u48a0\uc1f2\u2671\u8a38\u875b\u6e15\u571f\ub3f0\u35b5\ub2a8\u24c4\u7b6c\uccdb\ub391\u68af\u0188\u01bb", "\ub356\uda05\udf12",
        29, 68602, 1794748018, -2480158014738072561L, -17198L, false, false, (char) 29524, (char) 49326,
        Double.longBitsToDouble(0x3fe4e752fe07b91cL), Double.longBitsToDouble(0x3fd4bc6feeb160b6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\udb8b\udddf\udbeb\ude31\udba9\ude1b\ud8d8\ude0f\ud824\uddb8\ud851\udc2a\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 4, "\udb8b\udddf\udbeb\ude31\udba9\ude1b\ud8d8\ude0f\ud824\uddb8\ud851\udc2a", "\u692e\u2497\ua477\u6894\ua5d1\u5f60", "\udaf0\udff2\udb0d\ude36\ud87e\udcd3\ud85f\udfcc\ud838\udc49\uda32\udc90",
        28, 54399, -808288561, 6005611541264057228L, -98519L, false, true, (char) 54534, (char) 908,
        Double.longBitsToDouble(0x3feef8393f7fe691L), Double.longBitsToDouble(0x3fee5b7bebf491e9L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 4, "\udb8b\udddf\udaa4\udeec\udac5\udf95\uda4a\udfb9\udb66\ude45\ud851\udc2a", "\u3b41\u2497\ua477", "\ud859\udc66\ud91f\udee8\udbb0\udd34\udb2e\udf67\udb0d\ude36\ud87e\udcd3\udad2\udc65\ud825\udc0a\ud8ae\udc3a\udb22\udd11",
        39, 47535, -1602440812, -5762422190426814054L, 95482L, false, true, (char) 388, (char) 2189,
        Double.longBitsToDouble(0x3fda0367463b9e90L), Double.longBitsToDouble(0x3fe7c9a239997a4aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 4, "\000\udbeb\ude31\000\000\000\000", "\u692e", "\003",
        -5, -1000, 0, 8940834815191154192L, -9120L, false, false, (char) 62546, (char) 0,
        Double.longBitsToDouble(0x3f9a2100edf99180L), Double.longBitsToDouble(0x3fe67f1068e1cfd2L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 12, "\ud89b\ude58\udad5\udd85\ud8c3\uddbc\ud8d8\ude0f\ud824\uddb8\ud91b\ude90\ud8ad\ude8c", "\u7301\u0cc4", "\ud823\uddde\ud91f\udf0f\udbb0\udd34\udb40\udd64\uda92\uddf6\ud9f3\ude13\uda27\udcb7\ud9fc\udcb8\udaa1\udc6d\udb9f\udc56\udba3\udf5d",
        19, 45401, -1341668468, 7334122550238979273L, -72450L, true, false, (char) 32526, (char) 11730,
        Double.longBitsToDouble(0x3fec9c2501f5d8f5L), Double.longBitsToDouble(0x3fe694c95c893919L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 15, "\ud89b\ude7e\udad5\udd85\ud966\uddf1\udbea\udc98\ud824\udda8\ud91b\ude90\ud8ad\ude8c", "\u7301\u2a17\uc794\u3eb9", "\ud8d7\udeea",
        3, 73735, -32786895, -7848521267268817256L, 19628L, false, false, (char) 8412, (char) 34719,
        Double.longBitsToDouble(0x3fdd69bb7335600eL), Double.longBitsToDouble(0x3fc92cb912d051d0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\ud89b\ude1b\udad5\udd85\udba9\ude1b\ud8d8\ude0f\ud824\uddb8\ud91b\ude90\ud8ad\ude8c\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 15, 20, "\ud89b\ude1b\udad5\udd85\udba9\ude1b\ud8d8\ude0f\ud824\uddb8\ud91b\ude90\ud8ad\ude8c", "\u7301\u0cc2\uc794\u3eb9", "\udbb0\udd34\udb2e\udf67\uda92\uddf6\ud9f3\ude13\udae9\udf24\ud9fc\udcb8\udaa1\udc6d\udb60\udcf6\udba3\udf21\ud872\udff8\ud963\udcca\uda03\uded5",
        34, 50969, -1191237150, -6398274862889750189L, -38931L, true, false, (char) 11695, (char) 44083,
        Double.longBitsToDouble(0x3fdf5d8f55a53256L), Double.longBitsToDouble(0x3fc1272324274540L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\0121=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\012",
        Z.run(T, 2, 4, 20, 15, "\ud89b\ude1b\udad5\udd85\udba9\ude1b\ud8d8\ude0f\ud824\uddb8\ud91b\ude90\ud8ad\ude8c", "\u7301\u0cc2\uc794\u3eb9", "\udbb0\udd34\udb2e\udf67\uda92\uddf6\ud9f3\ude13\udae9\udf24\ud9fc\udcb8\udaa1\udc6d\udb60\udcf6\udba3\udf21\ud872\udff8\ud963\udcca\uda03\uded5",
        34, 50969, -1191237150, -6398274862889750189L, -38931L, true, false, (char) 11695, (char) 44083,
        Double.longBitsToDouble(0x3fdf5d8f55a53256L), Double.longBitsToDouble(0x3fc1272324274540L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 8, 15, 20, "\ud89b\ude1b\udad5\udd85\udba9\ude1b\ud8d8\ude0f\ud824\uddb8\ud91b\ude90\ud8ad\ude8c", "\u7301\u0cc2\uc794\u3eb9", "\udb41\ude3e\ud8ac\udd82\uda92\uddf6\ud9f3\ude13\udae9\udf24\ud9fc\udcb8\udaa1\udc6d\udb60\udcf6\udba3\udf21\ud872\udff8\ud963\udcca\uda03\uded5",
        34, 50969, -1191237150, -6398274862889750189L, -38931L, true, false, (char) 11695, (char) 44083,
        Double.longBitsToDouble(0x3fdf5d8f55a53256L), Double.longBitsToDouble(0x3fc127233fedff14L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 21, "\ud9f7\udf34\udad5\udd85\udba9\ude1b\ud9cb\udfa8\udba4\udee2", "\ucc1d\u29e5\u7301\u8fcb\u5994\u5fe9\u2294\uced6\u24f4\u48a0\u147f\u0be0\uac08\uc87a\u1b1b\ub888\u7148\u35b5\ub2a8", "\udb4b\udce9",
        35, 34545, 1713713491, 4997988011128974989L, -98372L, false, true, (char) 51707, (char) 62090,
        Double.longBitsToDouble(0x3fd0ed8fffa61d4aL), Double.longBitsToDouble(0x3fe76f4d0f4a30b5L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\ud89b\ude1b\udad5\udd85\udba9\ude1b\ud8d8\ude0f\u4591l\ud8ad\ude8c\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\012",
        Z.run(T, 2, 17, 4, 20, "\ud89b\ude1b\udad5\udd85\udba9\ude1b\ud8d8\ude0f\u4591l\ud8ad\ude8c", "\uc22b\u0cc2\uc794\u98b2", "\udbb0\udd1c\udb2e\udf67\uda92\uddf6\ud9f3\ude13\udae9\udf24\ud9fc\udcb8\udaa1\udc6d\udb60\udcf6\udba3\udf21\ud872\udff8\ud963\udcca\uda03\uded5\uda03\udf99\udb4b\udce9\udb2b\uddb2\ud979\uddad\u5f58",
        31, 38253, -1849951352, -8889934192810055789L, 63118L, true, false, (char) 62041, (char) 25491,
        Double.longBitsToDouble(0x3febc9d6d8e38f75L), Double.longBitsToDouble(0x3fc4b88b88dc5d8cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 8, 20, "\ud89b\ude1b\udad5\udd85\udba9\ude1b\ud961\uddc7\ud824\uddeb\ud91b\ude90\ud8ad\ude8c\ud83a\udf15\ud968\udcae", "\uc794\u3eb9\u796f\uced6\u24f4\u48a0\u147f\u0be0\uac08\uc87a\u1b1b\ub888\u7148\u35b5\ub2a8\u24c4\uaa3b\u475d\u7d31\ubf32", "\udb3d\uddbb\udbd7\ude4d\ud842\udc18\udbef\udd58\u3b0c",
        26, 11897, -310439591, 1632570048530704681L, -25653L, false, false, (char) 48840, (char) 4758,
        Double.longBitsToDouble(0x3fc58fe7f86aff08L), Double.longBitsToDouble(0x3fef334f3c9cd56aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 0, "\ud89b\ude1b\u948d\000\ud8d8\udd27\ud824\uddb8\ud91b\ude90\ud8ad\ude8c", "\000\000\ua1d2\000", "\udbb0\udd34\udb2e\udf67\uda92\uddf6\ud9f3\ude13\udae9\udf24\ud9fc\udcb8\udaa1\udc6d\udb60\udcf6\udb3f\ude8e\ud853\udd29\ud963\udcca\uda03\uded5",
        34, 50969, -1191237150, -6398274862889750189L, -38931L, true, false, (char) 11695, (char) 44083,
        Double.longBitsToDouble(0x3fdf5d8f50000056L), Double.longBitsToDouble(0x3d04000000000000L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 6, "\ud89b\ude1b\udad5\uddcc\ud8c5\udf58\ud8e9\udd0c\ud824\uddb8\ud91b\ude90\ud8ad\ude8c", "\u6969\u0cc2\uc794\u3eb9", "\udbb0\udd34\udbb0\udfa7\uda9f\udf7f\ud97b\udd17\udafd\udf8e\udbe1\udd94\udaa1\udc6d\udb60\udcf6\udba3\udf21\ud872\udff8\ud963\udcca\uda5b\ude60",
        21, 90409, -1191237150, -6398274862884343638L, -38931L, false, true, (char) 11695, (char) 44083,
        Double.longBitsToDouble(0x3fdf5d8f55a53256L), Double.longBitsToDouble(0x3fc1272324274540L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\udb8b\udddf\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 0, "\udb8b\udddf", "\u2995\000", "\udabf\uddbe",
        31, 910, -1375731712, -3856488643590435439L, 54500L, true, true, (char) 63012, (char) 53993,
        Double.longBitsToDouble(0x3e104b4000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\uda6f\uded1\udbeb\udede\udba9\ude1b\uda5a\udcf0\\u0000\uda6f\udfbb\ud9c0\ude4e\udabf\uddbe\uda15\udc95\u0776\udb96\udf2a\uda31\udcdb\ud800\udf97\udb83\udcbc\ud91f\udf5e\udbb0\udd34\udb2e\udf67\\u0000\udb1d\udd4d\u2882\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 0, 0, "\uda6f\uded1\udbeb\udede\udba9\ude1b\uda5a\udcf0\000\uda6f\udfbb\ud9c0\ude4e\udabf\uddbe\uda15\udc95\u0776\udb96\udf2a\uda31\udcdb\ud800\udf97\udb83\udcbc\ud91f\udf5e\udbb0\udd34\udb2e\udf67\000\udb1d\udd4d\u2882", "\ucce4", "\ud888\udf8f\uda23\udf65\udaca\udd87\uda9c\udf8a\uda63\udde0\ud9da\udef7\u628b\udb99\udd32\ua88e\ud948\udf0a\udbb4\udef0",
        40, 42256, -710222062, -1559435265655908379L, -71663L, false, false, (char) 26912, (char) 28485,
        Double.longBitsToDouble(0x3fc6096f1727c714L), Double.longBitsToDouble(0x3f90845834d07360L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 2, 9, "\udb69\udfc8", "\uc213\u6105", "\udb34\udd38",
        1, 46059, -1375731712, -3856488641577169519L, 54500L, true, true, (char) 31268, (char) 53993,
        Double.longBitsToDouble(0x3dcc500000000000L), Double.longBitsToDouble(0x3fdfb000096c819eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\0121=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\012",
        Z.run(T, 2, 20, 4, 22, "\ud9a4\udd37\udbeb\ude31\udba9\ude1b\uda5a\udcf0\udbc1\udc50\ud8a7\udf52\ud9c0\ude48\udabf\uddbe\uda15\udc95\u0776\ud99b\ude6c\ud9ca\ude28\ud8f8\uddd3\ud887\udf09\ud4b3\udbad\udd7c\ud996\udd1b\ud8a9\uddf0\udbf2\udd8c\u26df", "\uab36", "\udade\udece\ud99b\udcad\udb47\udfa3\udab5\udcb6\ud970\udfbc\ud88b\uddd3\udbb8\ude6e\uda97\udf56\udb70\udf15\udb26\udd1c\ud992\ude84",
        1, 67370, 2068870407, -6478892571933912580L, 68731L, false, false, (char) 40625, (char) 33788,
        Double.longBitsToDouble(0x3fa8eb5bf2e961e0L), Double.longBitsToDouble(0x3fe1bb1243935c59L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\uda8b\udddf\udbeb\ude31\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 0, 8, "\uda8b\udddf\udbeb\ude31", "\000\u2725\u11d4\u23e5\u692e\u0776\u1ed0\u6894\ua5d1\u5f60\uced6\u24f4\u48a0", "\ueafc",
        -5, 5856, 253641932, -2462919147378116953L, 71320L, false, false, (char) 60908, (char) 7366,
        Double.longBitsToDouble(0x3fe647300f57f072L), Double.longBitsToDouble(0x3fb5ec43c7838178L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\udb8b\udddf\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\udb8b\udddf\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 17, 17, 0, "\udb8b\udddf", "\u2995\u2a39", "\udabf\uddbe\ua7c9",
        -1, 89288, -1939054077, -2416518125671008670L, -87727L, false, false, (char) 53993, (char) 0,
        Double.longBitsToDouble(0x3fc04b4000000000L), Double.longBitsToDouble(0x3fedb80004429b9aL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\udb56\ude8b\udbe8\udd31\udba9\ude1b\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 21, 8, "\udb56\ude8b\udbe8\udd31\udba9\ude1b", "\u8694", "\uda15\udc95",
        22, 4763, -897908733, 1712731648L, -70273L, false, false, (char) 0, (char) 35167,
        Double.longBitsToDouble(0x3fe4d3aa181a2150L), Double.longBitsToDouble(0x3e385e3ad0000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\udb8b\udddf\uc073\udba9\ude1b\ud8d8\ude0f\ud824\uddb8\ud851\udc2a\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\udb8b\udddf\uc073\udba9\ude1b\ud8d8\ude0f\ud824\uddb8\ud851\udc2a\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 17, 17, 8, "\udb8b\udddf\uc073\udba9\ude1b\ud8d8\ude0f\ud824\uddb8\ud851\udc2a", "\u2de8\u8b26\ua477\u6894", "\ud91f\udee8\udbb0\udd34\udb9a\udc3c\udb0d\udddb\ud87e\udcd3\ud85f\udfcc\ud838\udc49",
        41, 58058, -950369937, -3479731052407670815L, -8852L, true, true, (char) 7465, (char) 64659,
        Double.longBitsToDouble(0x3fafcfcdf0810ca0L), Double.longBitsToDouble(0x3fdfe0f5ea2ba704L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\ud988\ude28\uda95\udda7\udba9\ude1b\ud8d8\ude0f\ud942\ude07\ud860\ude85\\u0000\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 1, 17, 18, 21, "\ud988\ude28\uda95\udda7\udba9\ude1b\ud8d8\ude0f\ud942\ude07\ud860\ude85\000", "\ud39d", "\ud982\udfd0\uda2a\udf51\ud837\udc0b\uda45\ude6b\udb2e\udf57\ua42e\udae6\udc87\udb5a\udded\ud842\udddf\ud86f\udd8f\udb31\ude68\uda44\udef9",
        32, 45401, -486489344, 0L, -100000L, false, false, (char) 59799, (char) 34354,
        Double.longBitsToDouble(0x3fe7ca3f75e4cf75L), Double.longBitsToDouble(0x3f32bd8d7d7be800L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\udbc8\ude84\udbeb\ude31?\udabd\udcdd\udab4\udf8a\u2aa5\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 1, 12, 19, "\udbc8\ude84\udbeb\ude31?\udabd\udcdd\udab4\udf8a\u2aa5", "\u00d5\u2497\ua477\u9b0a\ub0c1\u5f60\uced6\ud1fc\u4890\ucde9\u25ef\u8a38\u4c5b\u254e\u2277", "\ud963\udcca\uda03\uded5\udbfa\ude15\ud999\udeac\udadc\ude35\ud94d\udd52\ud8f0\udec4\uda30\ude2f\ud875\udcad\uda57\udec2\udb8e\uddcb\udb06\udc99\ud9c9\udfd9\udae6\udf46\udbb4\ude6e\udb1e\udd9f",
        34, 59398, -1549731430, -7991926018536106115L, 96619L, false, true, (char) 62410, (char) 52923,
        Double.longBitsToDouble(0x3feed547dd3f313cL), Double.longBitsToDouble(0x3fd615b6345a3822L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 10, 21, "\udbc8\ude84\udbeb\ude44?\ud8d0\udd27\ud8dc\udfb5\ud839\udcbb", "\u8814\u2497\ua477", "\ud859\udc66",
        25, 50158, -756417024, -6989585653613108480L, -69632L, false, false, (char) 60777, (char) 31599,
        Double.longBitsToDouble(0x3fe67f106ee1cfd2L), Double.longBitsToDouble(0x3fec629b119ab007L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\0121=com.fasterxml.jackson.databind.node.TextNode:\"\ud92f\udc8b\udbeb\ude39\uda8f\uddee\ud8d8\udd83\ud88c\ude0d\udaae\udd31\ud9c0\ude4e\udabf\uddbe\uda15\udc95\uda6d\udeeb\ud8e5\udff9\uda31\udcdb\udba7\udd8a\udb2d\udd88\udb85\udf2b\udad9\udfb4\udb2e\udf67\udb0d\ude36\ud87e\udcd3\ud85f\udfcc\ud846\udf49\uda32\udc90\udb22\udd11\ud8a5\ude12\ud872\udff8\ud963\udcca\uda03\uded5\ud8a5\udceb\udb8a\uddc5\ud9f4\udcf0\ud8bf\uddca\udbc8\udd78\ud931\ude5f\ud882\udfaf\ud9a6\udc05\ub356\uda05\udf12\udbe2\udf00\ud9c8\udd79\udb89\udcbf\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 20, 1, 4, "\ud92f\udc8b\udbeb\ude39\uda8f\uddee\ud8d8\udd83\ud88c\ude0d\udaae\udd31\ud9c0\ude4e\udabf\uddbe\uda15\udc95\uda6d\udeeb\ud8e5\udff9\uda31\udcdb\udba7\udd8a\udb2d\udd88\udb85\udf2b\udad9\udfb4\udb2e\udf67\udb0d\ude36\ud87e\udcd3\ud85f\udfcc\ud846\udf49\uda32\udc90\udb22\udd11\ud8a5\ude12\ud872\udff8\ud963\udcca\uda03\uded5\ud8a5\udceb\udb8a\uddc5\ud9f4\udcf0\ud8bf\uddca\udbc8\udd78\ud931\ude5f\ud882\udfaf\ud9a6\udc05\ub356\uda05\udf12\udbe2\udf00\ud9c8\udd79\udb89\udcbf", "\ub48b\u1d30\u7e2b\u31f3\ub919", "\ud9ca\udc99\udb9f\udcc5\ud96a\udd05\ud894\udff2",
        50, 62563, -1415176318, -3408664290418872272L, -85380L, true, true, (char) 13921, (char) 33932,
        Double.longBitsToDouble(0x3fee70074f77a8e0L), Double.longBitsToDouble(0x3fe01444ec7837fcL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\udb8b\udddf=\\u0000\\u0000\\u0000\udbaf\udcb6\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 4, "\udb8b\udddf=\000\000\000\udbaf\udcb6", "\u692e\u2497\ua477\u6894\ua5d1\u5f60", "\udaf0\udff2\udb0d\ude36\ud87e\udcd3\ud85f\udfcc\ud838\udc49\uda32\udc90",
        28, 54399, -808288561, 24831236116038400L, -98720L, false, true, (char) 54534, (char) 908,
        Double.longBitsToDouble(0x3feef8393f7fe691L), Double.longBitsToDouble(0x3fee5b7be8f491e9L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\udb8b\udddf\\u0000\\u0000\\u0000\ud81f\ude0e\ud851\udc2a\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 4, "\udb8b\udddf\000\000\000\ud81f\ude0e\ud851\udc2a", "\000\000\u97b3\003\000\u5f60", "\udaf0\udff2\uda50\ude48\udb1d\uddcf\ud85f\udfcc\ud838\udc49\uda32\udc90",
        28, 54399, -808288561, 6005611541264057228L, -98519L, false, true, (char) 54534, (char) 895,
        Double.longBitsToDouble(0x3feef8393f000000L), Double.longBitsToDouble(0x3f3bdf4000000000L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 11, "\000\000\000\000\000\000", "\u20d4\u2497\u00c3\000\000\000", "",
        37, 27385, 1513710466, -868587237350864544L, -100000L, false, false, (char) 0, (char) 1762,
        Double.longBitsToDouble(0x3fec629ac19ab000L), Double.longBitsToDouble(0x3fdc965c8ae985a0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\0121=new com.fasterxml.jackson.databind.util.TokenBuffer:[TokenBuffer: ]\012",
        Z.run(T, 2, 4, 20, 19, "\udb8b\udddf\udaa4\udeec\udac5\udf95\uda4a\udfb9\udb66\ude45\ud851\udc2a", "\u3b41\u2497\ua477", "\udb93\udf3a\uda3d\udf46\udbb0\udd34\udb2e\udf67\ud878\ude4a\ud897\udc10\udad2\udc65\ud928\udccc\ud8ae\udc03\ud905\udc22",
        39, 47535, -1602440812, 5264257763912630720L, 65422L, true, true, (char) 989, (char) 19788,
        Double.longBitsToDouble(0x3febf685be1512d5L), Double.longBitsToDouble(0x3fda0367463b9e90L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\udbeb\ude31\\u0000\\u0000\\u0000\\u0000\\u0000\ud9e9\uddc4\udb55\udd59\udb71\udf2d\uc8b6\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 4, "\000\udbeb\ude31\000\000\000\000\000\ud9e9\uddc4\udb55\udd59\udb71\udf2d\uc8b6", "\000\000\u24f4\u48a0\u00e1\u25ef\u0ce3\u6d53\u8647\u571f\ub3f0\u35b5\ua896\ube91\u7149\u2fda\ucde2\ub163\u0a55\ub4c2\ub54b\ub3e3", "\udaa4\udfed\uda24\udfd6\uda03\udf73\uda1b\udc63\udac3\udf9a\ud808\udf53\uda73\ude99\ud902\uddb1\uda57\udeba",
        18, 23952, 727312294, -4135638370536465129L, 859L, false, false, (char) 24083, (char) 33710,
        Double.longBitsToDouble(0x3fec3d719dd235f7L), Double.longBitsToDouble(0x3fe854ddec52d9d0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\udbeb\ude31\\u0000\\u0000\\u0000\\u0000\\u0000\udaab\uddb4\uda15\udc95\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\udbeb\ude31\\u0000\\u0000\\u0000\\u0000\\u0000\udaab\uddb4\uda15\udc95\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 1, 1, 4, "\000\udbeb\ude31\000\000\000\000\000\udaab\uddb4\uda15\udc95", "\ubc47", "\000",
        50, 71992, 717055713, -3500854480559003518L, -84901L, false, false, (char) 31739, (char) 2461,
        Double.longBitsToDouble(0x3fcc39e6b9066e6cL), Double.longBitsToDouble(0x3fe875d636580f7aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\udbeb\ude31\\u0000\ucf5a\u3700\udbfb\udd2en\ud812\udda6\uda15\udc95v\ud8e5\udff9\\u0003\u0092\\u0000\\u0000\udbb0\udd34\udb2e\udf67\u00e1\ud87e\udc51\ud85f\udfcc\udb21\udea2\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 3, 14, "\000\udbeb\ude31\000\ucf5a\u3700\udbfb\udd2en\ud812\udda6\uda15\udc95v\ud8e5\udff9\003\u0092\000\000\udbb0\udd34\udb2e\udf67\u00e1\ud87e\udc51\ud85f\udfcc\udb21\udea2", "\ub3f0\u35b5", "\ud8de\udf54\ud94c\udc27\udb44\udc7a",
        54, 78441, -1448139332, 7825911618181627871L, 20850L, false, false, (char) 62349, (char) 38082,
        Double.longBitsToDouble(0x3fbf330eab3ab3c0L), Double.longBitsToDouble(0x3fd2b37a854ebc2cL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\u7e3e\\u0000\\u0000\\u0000\\u0000\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 22, 10, "\000\u7e3e\000\000\000\000", "\u68ed", "\ud92d\ude58",
        27, 89818, 44, 8940834815191154192L, -76192L, true, false, (char) 62546, (char) 19557,
        Double.longBitsToDouble(0x3fb87033ab7e6460L), Double.longBitsToDouble(0x3fe67f1590e1cfd2L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=null |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 1, 17, 3, "\000\udbeb\ude31\000\000\000\000", "\u692e", "\003",
        -5, -1000, 0, 8940834815191154192L, -9120L, false, false, (char) 62546, (char) 0,
        Double.longBitsToDouble(0x3f9a2100edf99180L), Double.longBitsToDouble(0x3fe67f1068e1cfd2L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\udbeb\ude31\\u0000\\u0000\\u0000\\u0000\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\udbeb\ude31\\u0000\\u0000\\u0000\\u0000\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 1, 17, 4, "\000\udbeb\ude31\000\000\000\000", "\u692ev\ua3de\003\000\000\000\u24f4\u48a0\u00e1\u25ef\u8a38`\u871c\u6cd4\ub3d5\u35b5\u8345\u4142\u8f4f\u92e0\u6bb7\u03a2\u7507\u7c32\u08e4\u2b08\u52f1\u82c8\u5dbf\u7482\u291c\u5bd4", "\ud8d3\udf10\u44c7\uda8a\udd81\ud9cc\ude5f\udbd8\udca3\uda70\udcf0\ud9d2\udf34",
        40, 16212, 1422785683, 7557119363656685394L, -56375L, true, false, (char) 60644, (char) 53819,
        Double.longBitsToDouble(0x3feda6ce943c47bcL), Double.longBitsToDouble(0x3fddce225b38120aL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 10, "", "\000", "",
        -5, -1000, 318813184, 3314649325744685174L, -100000L, false, false, (char) 14821, (char) 31268,
        Double.longBitsToDouble(0x3fcc3a5d2c000000L), Double.longBitsToDouble(0x3fc04b472183cfc8L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\ud89b\ude44\udad5\udd85\udba9\ude1b\ud8d8\ude0f\ud824\uddb8\ud91b\ude90\ud8ad\ude8c\ud83a\udf15\ud968\udcae\udb26\udfa8\ud931\udd14\ud90e\udd0d\udb3e\udf27\ud823\uddb7\ud91f\udee8\udb41\ude3e\ud8ac\udd82\uda92\uddf6\ud9f3\ude13\udae9\udf24\ud9fc\udcb8\udb0c\udd42\ud8d7\ude7d\udba3\udf21\ud872\udff8\ud963\udcca\uda03\uded5\uda03\udf99\udb4b\udce9\udb2b\uddb2\ud979\uddad\u5f58\ud989\udfb4\ud914\udc99\ud9cb\udc07\udadb\udcae\udbef\udd45\uda9e\udfe5\ud99d\ude2f\uda7d\udc10\ud98c\udf38\ud863\udcfe\udbf6\udcc2\ud847\udd26\udb75\udd01\udbc4\uddcb\ud874\udd4c\ud8db\ude85\ud8a0\udd99\udaa4\udf88\ud8df\udc06\ud9ff\udc7b\udace\udf65\udb62\udfb5\udaa0\ude47\ud828\udf2f\udbe0\udf6d\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\ud89b\ude44\udad5\udd85\udba9\ude1b\ud8d8\ude0f\ud824\uddb8\ud91b\ude90\ud8ad\ude8c\ud83a\udf15\ud968\udcae\udb26\udfa8\ud931\udd14\ud90e\udd0d\udb3e\udf27\ud823\uddb7\ud91f\udee8\udb41\ude3e\ud8ac\udd82\uda92\uddf6\ud9f3\ude13\udae9\udf24\ud9fc\udcb8\udb0c\udd42\ud8d7\ude7d\udba3\udf21\ud872\udff8\ud963\udcca\uda03\uded5\uda03\udf99\udb4b\udce9\udb2b\uddb2\ud979\uddad\u5f58\ud989\udfb4\ud914\udc99\ud9cb\udc07\udadb\udcae\udbef\udd45\uda9e\udfe5\ud99d\ude2f\uda7d\udc10\ud98c\udf38\ud863\udcfe\udbf6\udcc2\ud847\udd26\udb75\udd01\udbc4\uddcb\ud874\udd4c\ud8db\ude85\ud8a0\udd99\udaa4\udf88\ud8df\udc06\ud9ff\udc7b\udace\udf65\udb62\udfb5\udaa0\ude47\ud828\udf2f\udbe0\udf6d\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 1, 1, 20, "\ud89b\ude44\udad5\udd85\udba9\ude1b\ud8d8\ude0f\ud824\uddb8\ud91b\ude90\ud8ad\ude8c\ud83a\udf15\ud968\udcae\udb26\udfa8\ud931\udd14\ud90e\udd0d\udb3e\udf27\ud823\uddb7\ud91f\udee8\udb41\ude3e\ud8ac\udd82\uda92\uddf6\ud9f3\ude13\udae9\udf24\ud9fc\udcb8\udb0c\udd42\ud8d7\ude7d\udba3\udf21\ud872\udff8\ud963\udcca\uda03\uded5\uda03\udf99\udb4b\udce9\udb2b\uddb2\ud979\uddad\u5f58\ud989\udfb4\ud914\udc99\ud9cb\udc07\udadb\udcae\udbef\udd45\uda9e\udfe5\ud99d\ude2f\uda7d\udc10\ud98c\udf38\ud863\udcfe\udbf6\udcc2\ud847\udd26\udb75\udd01\udbc4\uddcb\ud874\udd4c\ud8db\ude85\ud8a0\udd99\udaa4\udf88\ud8df\udc06\ud9ff\udc7b\udace\udf65\udb62\udfb5\udaa0\ude47\ud828\udf2f\udbe0\udf6d", "\u07c4\u0e30\ub298\u55cb\ubc97\u2f2d\u35ee", "\udb35\udfd2\udb70\udcc9\u9284",
        45, 71870, -1409429067, -1830910013072541043L, -44803L, false, true, (char) 65308, (char) 48900,
        Double.longBitsToDouble(0x3fba413b5bda1c18L), Double.longBitsToDouble(0x3fe8bc452a98ff9cL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 10, 20, "\ud89b\ude1b\udad5\udd85\udafe\udec9\ud901\uddad\u4591", "\u20db\u3a75\uc22b\u0cc2\uc794\u98b2\u9511\u809a\u24dc\u48a0\u147f\u0be0", "\udaa1\udc6d\udb60\udcf6\udba3\udf21\ud872\udff8\ud963\udcca\uda03\uded5\uda03\udf99\ud92d\udffa",
        35, 34545, 1713713491, 4997988011128974989L, -98453L, false, false, (char) 58785, (char) 63321,
        Double.longBitsToDouble(0x3fa6550f7793adb0L), Double.longBitsToDouble(0x3f767da452e26600L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 17, 17, 0, "", "\ua5b5", "\udbd8\udffd\ud9c4\udc4e",
        19, 15093, 1824, -5908722713049144829L, 17150L, false, true, (char) 19, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc04b4000000000L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\ud988\ude28\uda95\udda7\udba9\ude1b\uda7a\udf00\udaf1\ude3a\uda37\udd25\\f\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 1, 17, 11, 21, "\ud988\ude28\uda95\udda7\udba9\ude1b\uda7a\udf00\udaf1\ude3a\uda37\udd25\014", "\ud39d", "\ud87d\udf6a\uda2a\udf51\ud837\udc0b\uda45\ude6b\udb2e\udf57\ua42e\udae6\udc87\udb5a\udded\ud842\udddf\ud86f\udd8f\udb31\ude68\uda44\udef9",
        32, 45401, -2141338880, 25640954757120L, -100000L, false, false, (char) 59799, (char) 34354,
        Double.longBitsToDouble(0x3fe7ca3f75e4cf75L), Double.longBitsToDouble(0x3f32bd8d7d7be800L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\ua631\\u0000\\u0000\\u0000\ua574\udbb6\udd5d\udabc\udfc9\uda14\udfdf\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\ua631\\u0000\\u0000\\u0000\ua574\udbb6\udd5d\udabc\udfc9\uda14\udfdf\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 1, 1, 4, "\000\ua631\000\000\000\ua574\udbb6\udd5d\udabc\udfc9\uda14\udfdf", "\ubc47", "\000\ud877\udc31\udb4c\udf98\udb24\udd58\u8c89\ud85f\udfcc\ud9a7\udd74\udb73\udcec\udb22\udd36\udaf4\uded2\udbb3\udd38\ud96b\udf95\uda74\ude2c\ud9e0\udff7\ud8fb\udd18\ud973\udc52\ud88f\udffd",
        22, 58623, -1593376340, 940168408379090256L, -47633L, false, true, (char) 29708, (char) 13674,
        Double.longBitsToDouble(0x3fdd1f436853c182L), Double.longBitsToDouble(0x3fe0b315ade3a218L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 15, 15, "\udb5f\udf02\ud9be\ude19\udb4f\uddbe\ud92c\udf7a\udbb6\udcc2\ud851\udc2a\udbbc\udf55\u05c0\uda40\udf85\ud98b\udca6\ud89c\udfb3\udb6a\udd93\udbc4\udc4d\ud96d\udf72\udbaf\udca3\udb9d\uddeb\udb2e\udf67", "\u448b\u3e86\u37b3\u571f\ub3f0\u35b5\u92b0\u24c4\uaa3b\ucd43\u10d6\u8a75\u0241\u3149\u56db\u6bd4\ub0df\uaaf9\u2f72\u6be3\u4821\u0e31\ua882\u08ca\uc410\ua467\ud264\u17b3\u42c4\u6b10\u5511\u83fb\u3f60", "\ud82c\udecd\uda12\udd3f\ud9fb\udd7a\udb22\udf6f",
        56, 84905, 201078741, 206988655741238023L, -66505L, false, false, (char) 42410, (char) 6583,
        Double.longBitsToDouble(0x3fa6c3ba06ddd2b0L), Double.longBitsToDouble(0x3fd764b012bd3aacL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\udb8b\udddf\\t\\u0000\\u0000\\u0000\udbaf\udcb6\ud9c0\ude4e\udabf\uddbe\uda15\udc95\uda6d\udeeb\ud8e5\udff9\uda31\udcdb\udb62\udf66\ud95d\ude16\ud91f\udee8\udbb0\udd34\udaf0\udff2\udb0d\ude36\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\udb8b\udddf\\t\\u0000\\u0000\\u0000\udbaf\udcb6\ud9c0\ude4e\udabf\uddbe\uda15\udc95\uda6d\udeeb\ud8e5\udff9\uda31\udcdb\udb62\udf66\ud95d\ude16\ud91f\udee8\udbb0\udd34\udaf0\udff2\udb0d\ude36\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 1, 1, 4, "\udb8b\udddf\011\000\000\000\udbaf\udcb6\ud9c0\ude4e\udabf\uddbe\uda15\udc95\uda6d\udeeb\ud8e5\udff9\uda31\udcdb\udb62\udf66\ud95d\ude16\ud91f\udee8\udbb0\udd34\udaf0\udff2\udb0d\ude36", "\u4c5b\u6e15\u1133\ub3f0\u35b5\u7849\u2438\u357d", "\ud8bf\uddca\udbc8\udd78\ud931\ude5f\udbef\ude10\ud875\udd4e\ud805\udcb5\udb17\udd68\ud9e2\udcd3\udb38\udfdb\udb30\ude5e",
        48, 29115, -192453719, -9066527057655673576L, 23173L, true, true, (char) 43664, (char) 51724,
        Double.longBitsToDouble(0x3fc2b9ec9b805734L), Double.longBitsToDouble(0x3fd703e84198b51cL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\ud986\udcbbn\udbd2\udd29Z\uda87\udfc3\udbe9\udd22\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\ud986\udcbbn\udbd2\udd29Z\uda87\udfc3\udbe9\udd22\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 1, 17, 3, "\ud986\udcbbn\udbd2\udd29Z\uda87\udfc3\udbe9\udd22", "\u692e\u60bc\ua477\u6894\ua5d1\u5f60", "\udaf0\udf8a\udb0d\ude36\ud87e\udcd3\ud85f\udfcc\ud838\udc49\udae4\udcea",
        -3, 62658, -808288561, 24831236116038400L, -98720L, false, true, (char) 20743, (char) 28776,
        Double.longBitsToDouble(0x3feefb3d377fe691L), Double.longBitsToDouble(0x3f9a6f7d1e923ce0L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\uda5a\udced\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\uda14\udfc0\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\uda5a\udced\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\uda14\udfc0\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 1, 1, 4, "\000\uda5a\udced\000\000\000\000\000\000\uda14\udfc0", "\ubc47", "\000",
        50, 71992, 717055713, -3500854480559003518L, -84901L, false, false, (char) 31739, (char) 2461,
        Double.longBitsToDouble(0x3fcc39e6b9066e6cL), Double.longBitsToDouble(0x3fe875d636580f7aL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\ub496\u4900\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\ub496\u4900\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 1, 1, 4, "\000\000\000\000\000\000\000\ub496\u4900", "\u06f3", "",
        -5, 89325, -756417008, 3079730835929855846L, 70353L, true, false, (char) 60697, (char) 31739,
        Double.longBitsToDouble(0x3f9939841c2006a0L), Double.longBitsToDouble(0x3fe20cdcdb00bac6L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\ue33a\\u0000\\u0000\\u0000\\u0000\ud9f9\ude7b\udb2d\udce9\uda14\udfc0v\uda90\ude4e\ud817\udfb8\udb89\udf5b\\u0000\\u0000\udbb0\udd34\udb2e\udf67\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\ue33a\\u0000\\u0000\\u0000\\u0000\ud9f9\ude7b\udb2d\udce9\uda14\udfc0v\uda90\ude4e\ud817\udfb8\udb89\udf5b\\u0000\\u0000\udbb0\udd34\udb2e\udf67\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 1, 1, 4, "\000\ue33a\000\000\000\000\ud9f9\ude7b\udb2d\udce9\uda14\udfc0v\uda90\ude4e\ud817\udfb8\udb89\udf5b\000\000\udbb0\udd34\udb2e\udf67", "\ua524\u0337\uc217\u571f\u46a9\u7645\u01e4\ub1df\u65d0\u488d\u2ea7", "\udbe5\udf59\ud937\uddf3\ud867\udcfe\udaf5\uddef\ud8ed\ude8a\udbeb\udedb\ud8c5\udd40\ud8be\udc03\ud840\uddd1\ud96c\udeb9\uda5a\udc65\ud8fb\udeac\ud84a\udc70\uda5f\udc83\ud9ae\uded2\ud846\udf62\ud816\udc69\ud9ed\udd12\udba1\udfcd\ud834\uddb7\ud87c\udcc3",
        24, 19218, -2012668565, 569650251330643489L, -30451L, true, true, (char) 59026, (char) 37672,
        Double.longBitsToDouble(0x3fee4b34c0e9e373L), Double.longBitsToDouble(0x3fe7fc9431a0b415L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\udbc2\ude00\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\uda14\udfc0v\udb5b\udd74\uda26\udd05\u1f83\\u0000\\u0000\udbb0\udd34\udb2e\udf67\udb24\udd65\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\\u0000\udbc2\ude00\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\uda14\udfc0v\udb5b\udd74\uda26\udd05\u1f83\\u0000\\u0000\udbb0\udd34\udb2e\udf67\udb24\udd65\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 1, 1, 4, "\000\udbc2\ude00\000\000\000\000\000\000\uda14\udfc0v\udb5b\udd74\uda26\udd05\u1f83\000\000\udbb0\udd34\udb2e\udf67\udb24\udd65", "\ud0f8\u2524\u571f\uab9a\u7645\u01e4\u4435\u0566\u6965\ud61d\u9138\u556c\u7f57\u4fb1\u575d\ua879\u7e54\u7169\u268b", "\ud8bd\ude75",
        31, 55005, 991441078, -6414275857653927658L, -16041L, true, false, (char) 48590, (char) 1579,
        Double.longBitsToDouble(0x3fee9aa989fded0dL), Double.longBitsToDouble(0x3fd340d64c080fc4L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\uda50\udcdc\udbc2\ude00\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\uda14\udfc0v\udb5b\udd74\uda26\udd05\u1f83\\u0000\\u0000\udbb0\udd34\udb2e\udf67\udb24\udd65\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\uda50\udcdc\udbc2\ude00\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\uda14\udfc0v\udb5b\udd74\uda26\udd05\u1f83\\u0000\\u0000\udbb0\udd34\udb2e\udf67\udb24\udd65\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 1, 1, 4, "\uda50\udcdc\udbc2\ude00\000\000\000\000\000\000\uda14\udfc0v\udb5b\udd74\uda26\udd05\u1f83\000\000\udbb0\udd34\udb2e\udf67\udb24\udd65", "\ud0f8\u2524\u571f\uab9a\u7645\u01e4\u4435\u0566\u6965\ud61d\u9138\u556c\u7f57\u4fb1\u575d\ua879\u7e54\u7169\u268b", "\ud8bd\ude75",
        31, 55005, 991441078, -6414275857653927658L, -16041L, true, false, (char) 48590, (char) 1579,
        Double.longBitsToDouble(0x3fee9aa989fded0dL), Double.longBitsToDouble(0x3fd340d64c080fc4L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\u04bd\udbeb\ude31\udba9\ude1b\ud8d8\ude0f\udb1f\udf97\ud850\udfbb\\u0000\ub400\\u0000\ud853\udf69\ud8e5\udff9\uda31\udcdb\u2e97\ud859\udc66\u9e73\udb36\udf1b\udb2e\udf57\udb0d\ude36\ud87e\udcd3\ud85f\udfcc\ud838\udc49\uda32\udc90\udb22\uddf1o\udb18\udfeb\ud963\udcca\ud843\ude49\ud9ce\udc06\\u0000\\u0000\udba5\uddec\ud99b\ude8d\udbdd\uddf4\udaa0\udc2c\udb1e\ude9e\uda0d\udd83\ud9d8\ude11\ud86a\udf19\u8097\ud8a0\uddf9\udaed\ude6d\udb1c\udc97\udaac\udd3f\ud9d7\udf6d\udb95\udd5f\ud849\ude61\udb5a\udd50\ud81a\udd1e\ud859\uddc5\uda99\ude4c\ud842\udee9\ud959\udc97\ud96d\udd5e\ud8e9\udd3b\ud91d\udd86\ud83c\udf45\ud9fd\udc7d\ud8b4\ude35\u3d57\ud91d\udd89\uda5c\udf94\udb09\udc45\ud952\udcd2\udbbc\udcb3\ud96e\udf71\udb41\udc61\uda74\udc82\ud873\ude6a\uda62\udf62\ud9fb\udf50\ud8e0\udc40\ud9e1\ude4e\ud800\udf53\udbbb\udc14\ud9e2\udeba\udb97\udcc3\udb88\udd51\ud9a8\udf72\ud971\udd3d\ud94c\ude8f\udad1\udd0b\ud969\udf71\ud9d5\udc74\uda12\udfde\udb5d\udd31\ud9dc\udfd3\ud9df\udc82\ud84c\udcae\udafe\udf8d\ud8fd\udd4d\udbcf\udd0f\ud83a\udc5e\ud94d\uddfa\ud8eb\udcba\ud802\udccf\udb5d\udd54\udb9a\ude10\uda9b\udf10\ud834\udd90\ud9e3\udd8e\uda1f\uddfc\udad3\udd52\udbe8\udfd8\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 1, 1, 14, 20, "\u04bd\udbeb\ude31\udba9\ude1b\ud8d8\ude0f\udb1f\udf97\ud850\udfbb\000\ub400\000\ud853\udf69\ud8e5\udff9\uda31\udcdb\u2e97\ud859\udc66\u9e73\udb36\udf1b\udb2e\udf57\udb0d\ude36\ud87e\udcd3\ud85f\udfcc\ud838\udc49\uda32\udc90\udb22\uddf1o\udb18\udfeb\ud963\udcca\ud843\ude49\ud9ce\udc06\000\000\udba5\uddec\ud99b\ude8d\udbdd\uddf4\udaa0\udc2c\udb1e\ude9e\uda0d\udd83\ud9d8\ude11\ud86a\udf19\u8097\ud8a0\uddf9\udaed\ude6d\udb1c\udc97\udaac\udd3f\ud9d7\udf6d\udb95\udd5f\ud849\ude61\udb5a\udd50\ud81a\udd1e\ud859\uddc5\uda99\ude4c\ud842\udee9\ud959\udc97\ud96d\udd5e\ud8e9\udd3b\ud91d\udd86\ud83c\udf45\ud9fd\udc7d\ud8b4\ude35\u3d57\ud91d\udd89\uda5c\udf94\udb09\udc45\ud952\udcd2\udbbc\udcb3\ud96e\udf71\udb41\udc61\uda74\udc82\ud873\ude6a\uda62\udf62\ud9fb\udf50\ud8e0\udc40\ud9e1\ude4e\ud800\udf53\udbbb\udc14\ud9e2\udeba\udb97\udcc3\udb88\udd51\ud9a8\udf72\ud971\udd3d\ud94c\ude8f\udad1\udd0b\ud969\udf71\ud9d5\udc74\uda12\udfde\udb5d\udd31\ud9dc\udfd3\ud9df\udc82\ud84c\udcae\udafe\udf8d\ud8fd\udd4d\udbcf\udd0f\ud83a\udc5e\ud94d\uddfa\ud8eb\udcba\ud802\udccf\udb5d\udd54\udb9a\ude10\uda9b\udf10\ud834\udd90\ud9e3\udd8e\uda1f\uddfc\udad3\udd52\udbe8\udfd8", "\u9994\u3c54\u73f5\ua7e0", "\udb23\udf5c\udbdc\udfad\u7cce\ud8eb\uddfd\uda2e\udd98\ud908\uddfc\ud9d4\uddf4\ud95d\ude91",
        1, 2743, -871502676, 9181329962306389507L, 50846L, false, false, (char) 48195, (char) 49833,
        Double.longBitsToDouble(0x3fef60a6853b730dL), Double.longBitsToDouble(0x3fd5af5f8045f62eL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\u04bd\ud876\udf16\udb8f\udc5e\ud8d8\ude0f\udb1f\udf97\udaa6\ude60\uf2cc\ub400\ud90c\udda5\ud853\udf69\ud96e\udcbd\udbfb\udfe3\ud851\udfe7\udb35\udfcf\ud94a\udeb8\udb36\udf1b\udb2e\udf57\udb0d\ude36\ud87e\udcd3\ud85f\udfcc\udabe\udd97\uda32\udc90\udb22\uddf1o\udb18\udfeb\ud963\udcca\ud823\udd86\ud9ce\udc53\uda04\ude84\udbbf\udf39\udba5\uddec\ud99b\ude8d\udbdd\uddf4\udaa0\udc2c\udb1e\ude9e\uda0d\udd83\ud9d8\ude11\ud891\uddad\u6fd6\ud8a0\uddf9\udaed\ude6d\udb1c\udc97\udaac\udd3f\ud9d7\udf6d\udb95\udd5f\ud849\ude61\udb5a\udd50\ud81a\udd1e\ud859\uddc5\uda99\ude4c\ud842\udee9\ud959\udc97\ud96d\udd5e\ud8e9\udd3b\ud91d\udd86\ud83c\udf45\ud9fd\udc7d\ud8b4\ude35\u3d57\ud91d\udd89\uda5c\udf94\udb09\udc45\ud952\udcd2\udbbc\udcb3\ud96e\udf71\udb41\udc61\uda74\udc82\ud873\ude6a\uda62\udf62\ud9fb\udf50\ud8e0\udc40\ud9e1\ude4e\ud8e6\udf47\ud917\udefc\ud9e2\udeba\udb97\udcc3\udb88\udd51\ud9a8\udf72\ud971\udd3d\ud94c\ude8f\udad1\udd0b\ud969\udf71\ud9d5\udc74\uda12\udfde\udb5d\udd31\ud9dc\udfd3\ud9df\udc82\ud8ab\udf3a\udafe\udf90\ud8fd\udd4d\udbcf\udd0f\ud83a\udc5e\ud94d\uddfa\ud8eb\udcba\ud802\udccf\ud8dd\udf76\udb4e\udf02\udabd\udff5\ud834\udd90\ud9e3\udd8e\uda1f\uddfc\udad3\udd52\udaf9\udcb5\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 1, 1, 14, 20, "\u04bd\ud876\udf16\udb8f\udc5e\ud8d8\ude0f\udb1f\udf97\udaa6\ude60\uf2cc\ub400\ud90c\udda5\ud853\udf69\ud96e\udcbd\udbfb\udfe3\ud851\udfe7\udb35\udfcf\ud94a\udeb8\udb36\udf1b\udb2e\udf57\udb0d\ude36\ud87e\udcd3\ud85f\udfcc\udabe\udd97\uda32\udc90\udb22\uddf1o\udb18\udfeb\ud963\udcca\ud823\udd86\ud9ce\udc53\uda04\ude84\udbbf\udf39\udba5\uddec\ud99b\ude8d\udbdd\uddf4\udaa0\udc2c\udb1e\ude9e\uda0d\udd83\ud9d8\ude11\ud891\uddad\u6fd6\ud8a0\uddf9\udaed\ude6d\udb1c\udc97\udaac\udd3f\ud9d7\udf6d\udb95\udd5f\ud849\ude61\udb5a\udd50\ud81a\udd1e\ud859\uddc5\uda99\ude4c\ud842\udee9\ud959\udc97\ud96d\udd5e\ud8e9\udd3b\ud91d\udd86\ud83c\udf45\ud9fd\udc7d\ud8b4\ude35\u3d57\ud91d\udd89\uda5c\udf94\udb09\udc45\ud952\udcd2\udbbc\udcb3\ud96e\udf71\udb41\udc61\uda74\udc82\ud873\ude6a\uda62\udf62\ud9fb\udf50\ud8e0\udc40\ud9e1\ude4e\ud8e6\udf47\ud917\udefc\ud9e2\udeba\udb97\udcc3\udb88\udd51\ud9a8\udf72\ud971\udd3d\ud94c\ude8f\udad1\udd0b\ud969\udf71\ud9d5\udc74\uda12\udfde\udb5d\udd31\ud9dc\udfd3\ud9df\udc82\ud8ab\udf3a\udafe\udf90\ud8fd\udd4d\udbcf\udd0f\ud83a\udc5e\ud94d\uddfa\ud8eb\udcba\ud802\udccf\ud8dd\udf76\udb4e\udf02\udabd\udff5\ud834\udd90\ud9e3\udd8e\uda1f\uddfc\udad3\udd52\udaf9\udcb5", "\u9f6f\u3770\u8fcf\ua7e0", "\udb23\udf5c\udbdc\udfad\u7cce\udba1\udc95\ud943\udd60\ud908\ude10\ud9d4\uddf4\ud95d\ude91",
        1, 2743, -871502676, 9181329962306389507L, 50846L, false, false, (char) 48195, (char) 18160,
        Double.longBitsToDouble(0x3fd9f4b17ba428a6L), Double.longBitsToDouble(0x3fd5af5f8045f62eL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\u04bd\udbeb\ude31\udba9\ude1b\ud8d8\ude0f\udb1f\udf97\ud850\udfbb\\u0000\ub400\\u0000\ud853\udf69\ud8e5\udff9\uda31\udcdb\u2e97\ud859\udc66\u9e73\udb36\udf1b\u7ad0\uda29\udd04\ud897\udfe8\ud85f\udfcc\ud838\udc49\uda32\udc90\udb22\uddf1o\udb18\udfeb\ud963\udcca\ud843\ude49\uda50\udc13\uec14\\u0000\udba5\uddec\ud99b\ude8d\udbdd\uddf4\udaa0\udc2c\udb1e\ude9e\uda0d\udd83\ud9d8\ude11\ud86a\udf19\u8097\ud8a0\uddf9\udaed\ude6d\u096b\udaac\udd3f\ud9d7\udf6d\udb95\udd5f\ud849\ude61\udb5a\udd50\ud81a\udd1e\ud859\uddc5\uda99\ude4c\ud842\udee9\ud959\udc97\ud96d\udd5e\ud8e9\udd3b\ud91d\udd86\ud83c\udf45\ud9fd\udc7d\ud8b4\ude35\u3d57\ud91d\udd89\udbd6\udf91\udb09\udc45\ud952\udcd2\udbbc\udcb3\ud96e\udf71\udb41\udc61\udba8\ude8e\ud873\ude6a\uda62\udf62\ud9fb\udf50\ud8e0\udc40\ud9e1\ude4e\ud800\udf53\udbbb\udc14\ud9e2\udeba\udb97\udcc3\udb88\udd51\ud9a8\udf72\ud971\udd3d\ud94c\ude8f\udad1\udd0b\ud969\udf71\ud9d5\udc74\uda12\udfde\udb5d\udd31\ud9dc\udfd3\ud9df\udc82\ud84c\udcae\udafe\udf8d\ud8fd\udd4d\udb41\udd0e\ud93f\udc44\ud94d\uddfa\ud8eb\udcba\ud802\udccf\udb5d\udd54\ud81b\udd51\uda9b\udf4a\ud834\udd90\ud9e3\udd8e\uda1f\uddfc\udad3\udd52\udbe8\udfd8\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\u04bd\udbeb\ude31\udba9\ude1b\ud8d8\ude0f\udb1f\udf97\ud850\udfbb\\u0000\ub400\\u0000\ud853\udf69\ud8e5\udff9\uda31\udcdb\u2e97\ud859\udc66\u9e73\udb36\udf1b\u7ad0\uda29\udd04\ud897\udfe8\ud85f\udfcc\ud838\udc49\uda32\udc90\udb22\uddf1o\udb18\udfeb\ud963\udcca\ud843\ude49\uda50\udc13\uec14\\u0000\udba5\uddec\ud99b\ude8d\udbdd\uddf4\udaa0\udc2c\udb1e\ude9e\uda0d\udd83\ud9d8\ude11\ud86a\udf19\u8097\ud8a0\uddf9\udaed\ude6d\u096b\udaac\udd3f\ud9d7\udf6d\udb95\udd5f\ud849\ude61\udb5a\udd50\ud81a\udd1e\ud859\uddc5\uda99\ude4c\ud842\udee9\ud959\udc97\ud96d\udd5e\ud8e9\udd3b\ud91d\udd86\ud83c\udf45\ud9fd\udc7d\ud8b4\ude35\u3d57\ud91d\udd89\udbd6\udf91\udb09\udc45\ud952\udcd2\udbbc\udcb3\ud96e\udf71\udb41\udc61\udba8\ude8e\ud873\ude6a\uda62\udf62\ud9fb\udf50\ud8e0\udc40\ud9e1\ude4e\ud800\udf53\udbbb\udc14\ud9e2\udeba\udb97\udcc3\udb88\udd51\ud9a8\udf72\ud971\udd3d\ud94c\ude8f\udad1\udd0b\ud969\udf71\ud9d5\udc74\uda12\udfde\udb5d\udd31\ud9dc\udfd3\ud9df\udc82\ud84c\udcae\udafe\udf8d\ud8fd\udd4d\udb41\udd0e\ud93f\udc44\ud94d\uddfa\ud8eb\udcba\ud802\udccf\udb5d\udd54\ud81b\udd51\uda9b\udf4a\ud834\udd90\ud9e3\udd8e\uda1f\uddfc\udad3\udd52\udbe8\udfd8\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 17, 1, 20, "\u04bd\udbeb\ude31\udba9\ude1b\ud8d8\ude0f\udb1f\udf97\ud850\udfbb\000\ub400\000\ud853\udf69\ud8e5\udff9\uda31\udcdb\u2e97\ud859\udc66\u9e73\udb36\udf1b\u7ad0\uda29\udd04\ud897\udfe8\ud85f\udfcc\ud838\udc49\uda32\udc90\udb22\uddf1o\udb18\udfeb\ud963\udcca\ud843\ude49\uda50\udc13\uec14\000\udba5\uddec\ud99b\ude8d\udbdd\uddf4\udaa0\udc2c\udb1e\ude9e\uda0d\udd83\ud9d8\ude11\ud86a\udf19\u8097\ud8a0\uddf9\udaed\ude6d\u096b\udaac\udd3f\ud9d7\udf6d\udb95\udd5f\ud849\ude61\udb5a\udd50\ud81a\udd1e\ud859\uddc5\uda99\ude4c\ud842\udee9\ud959\udc97\ud96d\udd5e\ud8e9\udd3b\ud91d\udd86\ud83c\udf45\ud9fd\udc7d\ud8b4\ude35\u3d57\ud91d\udd89\udbd6\udf91\udb09\udc45\ud952\udcd2\udbbc\udcb3\ud96e\udf71\udb41\udc61\udba8\ude8e\ud873\ude6a\uda62\udf62\ud9fb\udf50\ud8e0\udc40\ud9e1\ude4e\ud800\udf53\udbbb\udc14\ud9e2\udeba\udb97\udcc3\udb88\udd51\ud9a8\udf72\ud971\udd3d\ud94c\ude8f\udad1\udd0b\ud969\udf71\ud9d5\udc74\uda12\udfde\udb5d\udd31\ud9dc\udfd3\ud9df\udc82\ud84c\udcae\udafe\udf8d\ud8fd\udd4d\udb41\udd0e\ud93f\udc44\ud94d\uddfa\ud8eb\udcba\ud802\udccf\udb5d\udd54\ud81b\udd51\uda9b\udf4a\ud834\udd90\ud9e3\udd8e\uda1f\uddfc\udad3\udd52\udbe8\udfd8", "\u9994\u3c54\u73f5\ua7e0", "\udb23\udf5c\ud898\uddcb\u7cce\ud8eb\uddfd\uda2e\udd98\ud908\uddfc\ud9d4\uddf4\ud95d\ude91",
        1, 2743, -871502676, 9181329962306389507L, 50846L, false, false, (char) 48195, (char) 49833,
        Double.longBitsToDouble(0x3fef60a6853b730dL), Double.longBitsToDouble(0x3fec67afc0227caaL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\u04bd\ud8fe\udfda\ud85f\udddc\udbb1\ude3e\udb1b\udd22\udaa6\ude60\uf2cc\ub400\ud90c\udda5\ud853\udf69\ud96e\udcbd\udbfb\udfe3\ud851\udfe7\udb35\udfcf\ud94a\udeb8\udb36\udf1b\udb2e\udf57\udb0d\ude36\ud87e\udcd3\ud9c3\udd9d\udabe\uddb8\uda32\udc90\ud858\udc4b\udbb9\uddcc\udb18\udfeb\ud986\udd3d\ud849\udf6c\ud9ce\udc53\uda04\ude84\udbbf\udf39\udba5\uddec\ud99b\ude8d\udbdd\uddf4\udaa0\udc2c\udb1e\ude9e\uda0d\udd83\ud9d8\ude11\udb76\ude8e\ud83b\udc5b\ud870\udd06\udaed\ude6d\udb1c\udc97\udaac\udd3f\ud9d7\udf6d\udb95\udd5f\ud849\ude61\udb5a\udd50\ud81a\udd1e\ud859\uddc5\uda99\ude4c\ud842\udef8\ud959\udc97\ud96d\udd5e\ud8e9\udd3b\ud91d\udd86\ud83c\udf45\uda08\udc50\ud8b4\ude35\u3d57\ud91d\udd89\uda5c\udf94\udb09\udc45\ud952\udcd2\udbbc\udcb3\ud96e\udf71\udb41\udc61\uda74\udc82\ud873\ude6a\uda62\udf62\ud9fb\udf50\ud8e0\udc40\ud9e1\ude4e\ud8e6\udf47\ud917\udefc\ud9e2\udeba\udb97\udcc3\udb88\udd51\ud9a8\udf72\ud971\udd3d\ud94c\ude8f\udad1\udd0b\ud969\udf71\ud9d5\udc74\uda12\udfde\udb5d\udd31\ud9dc\udfd3\ud9df\udc82\ud8ab\udf3a\udafe\udf90\ud8fd\udd4d\udbcf\udd0f\ud83a\udc5e\ud94d\uddfa\ud8eb\udcba\udb8f\udcd4\ud8dd\udf76\udb3b\udd30\u8c66\ud8a0\udef0\ud9d4\udc48\uda1f\uddfc\udad3\udd52\udaf9\udcb5\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\u04bd\ud8fe\udfda\ud85f\udddc\udbb1\ude3e\udb1b\udd22\udaa6\ude60\uf2cc\ub400\ud90c\udda5\ud853\udf69\ud96e\udcbd\udbfb\udfe3\ud851\udfe7\udb35\udfcf\ud94a\udeb8\udb36\udf1b\udb2e\udf57\udb0d\ude36\ud87e\udcd3\ud9c3\udd9d\udabe\uddb8\uda32\udc90\ud858\udc4b\udbb9\uddcc\udb18\udfeb\ud986\udd3d\ud849\udf6c\ud9ce\udc53\uda04\ude84\udbbf\udf39\udba5\uddec\ud99b\ude8d\udbdd\uddf4\udaa0\udc2c\udb1e\ude9e\uda0d\udd83\ud9d8\ude11\udb76\ude8e\ud83b\udc5b\ud870\udd06\udaed\ude6d\udb1c\udc97\udaac\udd3f\ud9d7\udf6d\udb95\udd5f\ud849\ude61\udb5a\udd50\ud81a\udd1e\ud859\uddc5\uda99\ude4c\ud842\udef8\ud959\udc97\ud96d\udd5e\ud8e9\udd3b\ud91d\udd86\ud83c\udf45\uda08\udc50\ud8b4\ude35\u3d57\ud91d\udd89\uda5c\udf94\udb09\udc45\ud952\udcd2\udbbc\udcb3\ud96e\udf71\udb41\udc61\uda74\udc82\ud873\ude6a\uda62\udf62\ud9fb\udf50\ud8e0\udc40\ud9e1\ude4e\ud8e6\udf47\ud917\udefc\ud9e2\udeba\udb97\udcc3\udb88\udd51\ud9a8\udf72\ud971\udd3d\ud94c\ude8f\udad1\udd0b\ud969\udf71\ud9d5\udc74\uda12\udfde\udb5d\udd31\ud9dc\udfd3\ud9df\udc82\ud8ab\udf3a\udafe\udf90\ud8fd\udd4d\udbcf\udd0f\ud83a\udc5e\ud94d\uddfa\ud8eb\udcba\udb8f\udcd4\ud8dd\udf76\udb3b\udd30\u8c66\ud8a0\udef0\ud9d4\udc48\uda1f\uddfc\udad3\udd52\udaf9\udcb5\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 1, 1, 20, "\u04bd\ud8fe\udfda\ud85f\udddc\udbb1\ude3e\udb1b\udd22\udaa6\ude60\uf2cc\ub400\ud90c\udda5\ud853\udf69\ud96e\udcbd\udbfb\udfe3\ud851\udfe7\udb35\udfcf\ud94a\udeb8\udb36\udf1b\udb2e\udf57\udb0d\ude36\ud87e\udcd3\ud9c3\udd9d\udabe\uddb8\uda32\udc90\ud858\udc4b\udbb9\uddcc\udb18\udfeb\ud986\udd3d\ud849\udf6c\ud9ce\udc53\uda04\ude84\udbbf\udf39\udba5\uddec\ud99b\ude8d\udbdd\uddf4\udaa0\udc2c\udb1e\ude9e\uda0d\udd83\ud9d8\ude11\udb76\ude8e\ud83b\udc5b\ud870\udd06\udaed\ude6d\udb1c\udc97\udaac\udd3f\ud9d7\udf6d\udb95\udd5f\ud849\ude61\udb5a\udd50\ud81a\udd1e\ud859\uddc5\uda99\ude4c\ud842\udef8\ud959\udc97\ud96d\udd5e\ud8e9\udd3b\ud91d\udd86\ud83c\udf45\uda08\udc50\ud8b4\ude35\u3d57\ud91d\udd89\uda5c\udf94\udb09\udc45\ud952\udcd2\udbbc\udcb3\ud96e\udf71\udb41\udc61\uda74\udc82\ud873\ude6a\uda62\udf62\ud9fb\udf50\ud8e0\udc40\ud9e1\ude4e\ud8e6\udf47\ud917\udefc\ud9e2\udeba\udb97\udcc3\udb88\udd51\ud9a8\udf72\ud971\udd3d\ud94c\ude8f\udad1\udd0b\ud969\udf71\ud9d5\udc74\uda12\udfde\udb5d\udd31\ud9dc\udfd3\ud9df\udc82\ud8ab\udf3a\udafe\udf90\ud8fd\udd4d\udbcf\udd0f\ud83a\udc5e\ud94d\uddfa\ud8eb\udcba\udb8f\udcd4\ud8dd\udf76\udb3b\udd30\u8c66\ud8a0\udef0\ud9d4\udc48\uda1f\uddfc\udad3\udd52\udaf9\udcb5", "\u9f6f\u3770\u8fcf\ua7e0", "\udb23\udf5c\udbdc\udfad\ud800\ude1e\udba1\udc95\ud943\udd60\ud908\ude10\ud9d4\uddf4\ud95d\ude91",
        27, 83986, 2143636112, 9181329077543126531L, 50846L, false, false, (char) 48195, (char) 18160,
        Double.longBitsToDouble(0x3fd9f4b17ba428a6L), Double.longBitsToDouble(0x3fd5af5f8045f62eL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\u04bd\udbeb\ude31\udba9\ude1b\ud8d8\ude0f\udb1f\udf97\ud850\udfbb\\u0000\ub400\\u0000\ud853\udf69\ud8e5\udff9\\u0003\ufdff\ud859\udc66\u9e73\udb36\udf1b\u7ad0\uda29\udd04\ud897\udfe8\ud85f\udfcc\ud838\udc49\uda32\udc90\udb22\uddf1o\\u0000\ud88b\udce4\ud843\ude49\uda50\udc13\uec14\\u0000\udba5\uddec\ud99b\ude8d\udbdd\uddf4\udaa0\udc2c\udb1e\ude9e\uda0d\udd83\u00a6\\u0000\\u0000\\u0000\uda54\udc69\u096b\udaac\udd3f\ud9d7\udf6d\udb95\udc62\ud849\ude61\udb5a\udd50\ud81a\udd1e\ud859\uddc5\uda99\ude4c\ud842\udee9\ud959\udc97\ud96d\udd5e\ud8e9\udd3b\ud91d\udd86\ud83c\udf45\ud9fd\udc7d\ud8b4\ude35\ud95c\udedd\\u0000\udbd6\udf70\udb09\udc45\ud952\udcd2\udb86\udd02\ud96e\udf71\udb41\udc61\udba8\ude8e\ud873\ude6a\uda62\udf62\ud9fb\udf50\ud86b\udcc6\\u0000\\u0000\\u0000\\u0000\udb5b\udfed\ud846\udd50\ud9a8\udf72\ud971\udd3d\ud94c\ude8f\udad1\udd0b\ud969\udf71\ud9d5\udc74\uda12\udfde\udb5d\udd31\ud9dc\udfd3\ud9df\udc82\u14ac\\u0000\ud8fd\udd4d\uda27\udce1\udb8b\udc85\ud94d\udd19\ud8eb\udcba\ud802\udccf\u009d\ud81b\udd51\uda9b\udf4a\ud834\udd90\uda34\udcd7\\u0000\udad3\udd47\udbe8\udfd8\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\u04bd\udbeb\ude31\udba9\ude1b\ud8d8\ude0f\udb1f\udf97\ud850\udfbb\\u0000\ub400\\u0000\ud853\udf69\ud8e5\udff9\\u0003\ufdff\ud859\udc66\u9e73\udb36\udf1b\u7ad0\uda29\udd04\ud897\udfe8\ud85f\udfcc\ud838\udc49\uda32\udc90\udb22\uddf1o\\u0000\ud88b\udce4\ud843\ude49\uda50\udc13\uec14\\u0000\udba5\uddec\ud99b\ude8d\udbdd\uddf4\udaa0\udc2c\udb1e\ude9e\uda0d\udd83\u00a6\\u0000\\u0000\\u0000\uda54\udc69\u096b\udaac\udd3f\ud9d7\udf6d\udb95\udc62\ud849\ude61\udb5a\udd50\ud81a\udd1e\ud859\uddc5\uda99\ude4c\ud842\udee9\ud959\udc97\ud96d\udd5e\ud8e9\udd3b\ud91d\udd86\ud83c\udf45\ud9fd\udc7d\ud8b4\ude35\ud95c\udedd\\u0000\udbd6\udf70\udb09\udc45\ud952\udcd2\udb86\udd02\ud96e\udf71\udb41\udc61\udba8\ude8e\ud873\ude6a\uda62\udf62\ud9fb\udf50\ud86b\udcc6\\u0000\\u0000\\u0000\\u0000\udb5b\udfed\ud846\udd50\ud9a8\udf72\ud971\udd3d\ud94c\ude8f\udad1\udd0b\ud969\udf71\ud9d5\udc74\uda12\udfde\udb5d\udd31\ud9dc\udfd3\ud9df\udc82\u14ac\\u0000\ud8fd\udd4d\uda27\udce1\udb8b\udc85\ud94d\udd19\ud8eb\udcba\ud802\udccf\u009d\ud81b\udd51\uda9b\udf4a\ud834\udd90\uda34\udcd7\\u0000\udad3\udd47\udbe8\udfd8\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 17, 1, 20, "\u04bd\udbeb\ude31\udba9\ude1b\ud8d8\ude0f\udb1f\udf97\ud850\udfbb\000\ub400\000\ud853\udf69\ud8e5\udff9\003\ufdff\ud859\udc66\u9e73\udb36\udf1b\u7ad0\uda29\udd04\ud897\udfe8\ud85f\udfcc\ud838\udc49\uda32\udc90\udb22\uddf1o\000\ud88b\udce4\ud843\ude49\uda50\udc13\uec14\000\udba5\uddec\ud99b\ude8d\udbdd\uddf4\udaa0\udc2c\udb1e\ude9e\uda0d\udd83\u00a6\000\000\000\uda54\udc69\u096b\udaac\udd3f\ud9d7\udf6d\udb95\udc62\ud849\ude61\udb5a\udd50\ud81a\udd1e\ud859\uddc5\uda99\ude4c\ud842\udee9\ud959\udc97\ud96d\udd5e\ud8e9\udd3b\ud91d\udd86\ud83c\udf45\ud9fd\udc7d\ud8b4\ude35\ud95c\udedd\000\udbd6\udf70\udb09\udc45\ud952\udcd2\udb86\udd02\ud96e\udf71\udb41\udc61\udba8\ude8e\ud873\ude6a\uda62\udf62\ud9fb\udf50\ud86b\udcc6\000\000\000\000\udb5b\udfed\ud846\udd50\ud9a8\udf72\ud971\udd3d\ud94c\ude8f\udad1\udd0b\ud969\udf71\ud9d5\udc74\uda12\udfde\udb5d\udd31\ud9dc\udfd3\ud9df\udc82\u14ac\000\ud8fd\udd4d\uda27\udce1\udb8b\udc85\ud94d\udd19\ud8eb\udcba\ud802\udccf\u009d\ud81b\udd51\uda9b\udf4a\ud834\udd90\uda34\udcd7\000\udad3\udd47\udbe8\udfd8", "\u9994\u3c54\u73f5\ua7e0", "\ud863\udf5c",
        53, 58723, 333923537, -6588529875147660442L, -35325L, false, true, (char) 63999, (char) 2316,
        Double.longBitsToDouble(0x3fe7ae606e037f6aL), Double.longBitsToDouble(0x3fcab71d94f85c00L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.TextNode:\"\u04bd\udbeb\ude31\udba9\ude1b\ud8d8\ude0f\udb1f\udf97\ud8a1\udf04\\u0000\ub400\\u0000\ud853\udf69\ud8e5\udff9\\u0003\ufdff\ud859\udc66\u9e73\udb36\udf1b\u7ad0\uda29\udd04\ud897\udfe8\ud85f\udfcc\ud838\udc49\uda32\udc90\udb22\uddf1o\\u0000\ud88b\udce4\ud843\ude49\uda50\udc13\uec14\\u0000\udba5\uddec\ud99b\ude8d\udbdd\uddf4\udaa0\udc2c\udb1e\ude9e\uda0d\udd83\u00a6\\u0000\\u0000\\u0000\uda54\udc69\u096b\udacc\udf4f\\u0000\udb95\udc62\ud849\ude61\udb5a\udd50\ud81a\udd1e\ud859\uddc5\uda99\ude4c\ud842\udee9\ud959\udc97\ud96d\udd5e\ud8e9\udd3b\ud91d\udd86\ud83c\udf45\ud9fd\udc7d\ud8b4\ude35\ud95c\udedd\\u0000\udbd6\udf70\udb09\udc45\ud952\udcd2\udb86\udd02\ud96e\udf71\udb41\udc61\udba8\ude8e\ud873\ude6a\uda62\udf62\ud9fb\udf50\ud86b\udcc6\\u0000\\u0000\\u0000\\u0000\udb5b\udfed\ud846\udd50\uda16\ude6a\ud971\udd3d\ud94c\ude8f\udad1\udd0b\ud969\udf71\ud9d5\udc74\\u001D\udb5d\udd31\ud9dc\udfd3\ud9df\udc82\u14ac\\u0000\ud8fd\udd4d\uda27\udce1\udb8b\udc85\ud94d\udd19\ud8eb\udcba\ud802\udccf\u009d\ud81b\udd51\uda9b\udf4a\ud834\udd90\uda34\udcd7\\u0000\udad3\udd47\udbe8\udfd8\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.node.TextNode:\"\u04bd\udbeb\ude31\udba9\ude1b\ud8d8\ude0f\udb1f\udf97\ud8a1\udf04\\u0000\ub400\\u0000\ud853\udf69\ud8e5\udff9\\u0003\ufdff\ud859\udc66\u9e73\udb36\udf1b\u7ad0\uda29\udd04\ud897\udfe8\ud85f\udfcc\ud838\udc49\uda32\udc90\udb22\uddf1o\\u0000\ud88b\udce4\ud843\ude49\uda50\udc13\uec14\\u0000\udba5\uddec\ud99b\ude8d\udbdd\uddf4\udaa0\udc2c\udb1e\ude9e\uda0d\udd83\u00a6\\u0000\\u0000\\u0000\uda54\udc69\u096b\udacc\udf4f\\u0000\udb95\udc62\ud849\ude61\udb5a\udd50\ud81a\udd1e\ud859\uddc5\uda99\ude4c\ud842\udee9\ud959\udc97\ud96d\udd5e\ud8e9\udd3b\ud91d\udd86\ud83c\udf45\ud9fd\udc7d\ud8b4\ude35\ud95c\udedd\\u0000\udbd6\udf70\udb09\udc45\ud952\udcd2\udb86\udd02\ud96e\udf71\udb41\udc61\udba8\ude8e\ud873\ude6a\uda62\udf62\ud9fb\udf50\ud86b\udcc6\\u0000\\u0000\\u0000\\u0000\udb5b\udfed\ud846\udd50\uda16\ude6a\ud971\udd3d\ud94c\ude8f\udad1\udd0b\ud969\udf71\ud9d5\udc74\\u001D\udb5d\udd31\ud9dc\udfd3\ud9df\udc82\u14ac\\u0000\ud8fd\udd4d\uda27\udce1\udb8b\udc85\ud94d\udd19\ud8eb\udcba\ud802\udccf\u009d\ud81b\udd51\uda9b\udf4a\ud834\udd90\uda34\udcd7\\u0000\udad3\udd47\udbe8\udfd8\" |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 17, 1, 20, "\u04bd\udbeb\ude31\udba9\ude1b\ud8d8\ude0f\udb1f\udf97\ud8a1\udf04\000\ub400\000\ud853\udf69\ud8e5\udff9\003\ufdff\ud859\udc66\u9e73\udb36\udf1b\u7ad0\uda29\udd04\ud897\udfe8\ud85f\udfcc\ud838\udc49\uda32\udc90\udb22\uddf1o\000\ud88b\udce4\ud843\ude49\uda50\udc13\uec14\000\udba5\uddec\ud99b\ude8d\udbdd\uddf4\udaa0\udc2c\udb1e\ude9e\uda0d\udd83\u00a6\000\000\000\uda54\udc69\u096b\udacc\udf4f\000\udb95\udc62\ud849\ude61\udb5a\udd50\ud81a\udd1e\ud859\uddc5\uda99\ude4c\ud842\udee9\ud959\udc97\ud96d\udd5e\ud8e9\udd3b\ud91d\udd86\ud83c\udf45\ud9fd\udc7d\ud8b4\ude35\ud95c\udedd\000\udbd6\udf70\udb09\udc45\ud952\udcd2\udb86\udd02\ud96e\udf71\udb41\udc61\udba8\ude8e\ud873\ude6a\uda62\udf62\ud9fb\udf50\ud86b\udcc6\000\000\000\000\udb5b\udfed\ud846\udd50\uda16\ude6a\ud971\udd3d\ud94c\ude8f\udad1\udd0b\ud969\udf71\ud9d5\udc74\035\udb5d\udd31\ud9dc\udfd3\ud9df\udc82\u14ac\000\ud8fd\udd4d\uda27\udce1\udb8b\udc85\ud94d\udd19\ud8eb\udcba\ud802\udccf\u009d\ud81b\udd51\uda9b\udf4a\ud834\udd90\uda34\udcd7\000\udad3\udd47\udbe8\udfd8", "\u9994\u3c54\u73f5\ua7e0", "\ud863\udf5c",
        53, 58723, 333923537, -6588529875147660442L, -35325L, false, true, (char) 63999, (char) 0,
        Double.longBitsToDouble(0x3e480dfda8000000L), Double.longBitsToDouble(0x3fcab71d94f85c00L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ObjectMapper|_convert|java.lang.Object,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|valueToTree|java.lang.Object|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|copyCurrentEvent|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|forceUseOfBigDecimal|boolean|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "C|com.fasterxml.jackson.databind.util.TokenBuffer|<init>|com.fasterxml.jackson.core.ObjectCodec,boolean",
    "C|com.fasterxml.jackson.databind.util.TokenBuffer|<init>|com.fasterxml.jackson.core.JsonParser",
    "C|com.fasterxml.jackson.databind.util.TokenBuffer|<init>|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext",
    "C|com.fasterxml.jackson.databind.util.TokenBuffer|<init>|com.fasterxml.jackson.core.ObjectCodec",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_checkInvalidCopy|java.lang.Class|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_configAndWriteCloseable|com.fasterxml.jackson.core.JsonGenerator,java.lang.Object,com.fasterxml.jackson.databind.SerializationConfig|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_configAndWriteValue|com.fasterxml.jackson.core.JsonGenerator,java.lang.Object|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_configAndWriteValue|com.fasterxml.jackson.core.JsonGenerator,java.lang.Object,java.lang.Class|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_defaultPrettyPrinter||new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_findRootDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_initForReading|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_newReader|com.fasterxml.jackson.databind.DeserializationConfig|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_convert|java.lang.Object,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|valueToTree|java.lang.Object|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|copyCurrentEvent|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "M|com.fasterxml.jackson.databind.util.TokenBuffer|forceUseOfBigDecimal|boolean|new:com.fasterxml.jackson.databind.util.TokenBuffer:com.fasterxml.jackson.core.JsonParser",
    "C|com.fasterxml.jackson.databind.util.TokenBuffer|<init>|com.fasterxml.jackson.core.ObjectCodec,boolean",
    "C|com.fasterxml.jackson.databind.util.TokenBuffer|<init>|com.fasterxml.jackson.core.JsonParser",
    "C|com.fasterxml.jackson.databind.util.TokenBuffer|<init>|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext",
    "C|com.fasterxml.jackson.databind.util.TokenBuffer|<init>|com.fasterxml.jackson.core.ObjectCodec",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
