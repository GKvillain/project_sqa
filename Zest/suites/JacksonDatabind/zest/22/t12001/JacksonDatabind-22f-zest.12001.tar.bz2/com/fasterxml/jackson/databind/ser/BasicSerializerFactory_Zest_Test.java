package com.fasterxml.jackson.databind.ser;
import org.junit.Test;
import static org.junit.Assert.*;
public class BasicSerializerFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CollectionSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 2, 8, 15, "\ud7ee\ud85c\udf6b\uda10\uded2\ud872\udd42\ud894\udf13\udb6f\ude1f\ud9b5\ude1a\ud97e\udf91\ud903\udfbe\ud855\udcf1\udb43\uded2\ud9ae\udc41", "\u2439\u7691\u73f3\u8829\u82b9\u820a\u64f1", "\udb9b\udf28\udbb1\uddb5\ud84e\udef3\udb59\udcb7\ud957\udfe7\ud9b0\uddaf\udbe2\udf3e\ud821\udfdb\ud84d\uddc0\uda78\udecb\udaec\udc96",
        26, 32845, -365519487, -6087344593034158649L, -4446L, false, false, (char) 1389, (char) 60270,
        Double.longBitsToDouble(0x3fb31738a7299b48L), Double.longBitsToDouble(0x3fec8df8ece4dda5L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CollectionSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 2, 8, 7, "\ud7ee\ud85c\udf6b\udbb2\ude02\ud872\udcfb\ud894\udf13\ud91a\udd0e\udab2\uddda\ud97e\udf0d\ud903\udfbe\ud855\udcf1\udb43\uded2\ud9b0\udea4", "\u2439\u7691\u73f3\u8829\u82b9\u820a\u64f1", "\udb9b\udf28\udbb1\uddb5\ud84e\udef3\udb59\udcb7\uda8f\udd43\udaf9\uddfe\udab8\udf49\ud821\udfdb\ud84d\uddc0\uda78\udecb\udaec\udc96",
        26, 93820, -1938978861, -6087344593841358137L, -4446L, false, false, (char) 1389, (char) 60270,
        Double.longBitsToDouble(0x3fb31738a7299b48L), Double.longBitsToDouble(0x3fd4ebf1de33eeceL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CollectionSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 2, 8, 15, "\ud7ee\ud8ac\ude1d\uda06\udcf1\ud882\udc83\ud894\udf13\udb6f\ude1f\ud9b5\ude1a\ud97e\udf91\ud903\udfbe\ud855\udcf1\udb43\uded2\ud9ae\udc41", "\u2439\ub774\ua1a7\u2132\u234f\ub9cd\u28ec", "\uda2a\udc11\ud814\udd65\ud8f1\udf71\ud922\udfcd\ud8d2\udecc\u0619\udbe2\udf33\ud821\udfdb",
        12, -28, -2132107244, 9089316680927008167L, -37711L, true, true, (char) 64055, (char) 10545,
        Double.longBitsToDouble(0x3fa2b71c0500f650L), Double.longBitsToDouble(0x3fcfb8bd35088504L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 20, 8, 15, "\ud7ee\ud85c\udf6b\uda10\uded2\ud872\udd42\ud894\udf13\udb6f\ude1f\ud9b5\ude1a\ud97e\udf91\ud903\udfbe\ud855\udcf1\udb43\uded2\ud9ae\udc41", "\u2439\u7691\u73f3\u8829\u82b9\u820a\u64f1", "\udb9b\udf28\udbb1\uddb5\ud84e\udef3\udb59\udcb7\ud957\udfe7\ud9b0\uddaf\udbe2\udf3e\ud821\udfdb\ud84d\uddc0\uda78\udecb\udaec\udc96",
        26, 32845, -365519487, -6087344593034158649L, -4446L, false, false, (char) 1389, (char) 3809,
        Double.longBitsToDouble(0x3f9ab5c29b3262a0L), Double.longBitsToDouble(0x3fec8df8ece4dda5L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 8, 15, "\ud7ee\ud85c\udf6b\uda10\uded2\ud872\udd42\ud894\udf13\udb2e\udc5e\udbbe\udc50\uda8a\udcde\ud913\udf4a\ud94e\udce3\ud880\udeda\ud9ae\udc62", "\u2439\u7691\u73f3\u8829\u82b9\u820a\u64f1", "\udb9b\udf28\udbb1\uddb5\ud84e\udef3\udb59\udcb7\ud957\udfe7\ud9b0\uddaf\udbe2\udf3e\ud821\udfdb\ud84d\uddc0\uda78\udecb\udae6\ude7e",
        26, 32845, -365519487, -6087344593034158649L, 26183L, false, true, (char) 32291, (char) 39791,
        Double.longBitsToDouble(0x3fcd93513395f384L), Double.longBitsToDouble(0x3fec8df8ece41ad3L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.EnumSetSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 1, "\ud7ee\ud85c\udf6b\uda10\uded2\ud872\udd42\ud894\udf13\udb6f\ude1f\uda00\udcdf\000\ud903\udf8d\ud855\udcf1\udb43\uded2\ud9ae\udc41", "\u2439\u7691\u73f3\u8829\u82b9\u820a\000", "\udb7e\udfdf",
        40, 30347, -2001884224, 37727259016036352L, -76036L, false, false, (char) 15943, (char) 52818,
        Double.longBitsToDouble(0x3fd8100000b1d46cL), Double.longBitsToDouble(0x3fdc7ab85ed6859aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 8, 12, 15, "\ud7ee\ud85c\udf6b\uda10\uded2", "\u0366\u6207\u4010", "\u9d14\ud97a\udcc7\udb28\uddf0\udbd2\udcb8\ud917\ude03",
        13, 53893, -1961334088, 431188475158836000L, -63977L, false, true, (char) 57690, (char) 15226,
        Double.longBitsToDouble(0x3fbacbdde173cc30L), Double.longBitsToDouble(0x3fe6c2eb62507cd3L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CollectionSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\012",
        Z.run(T, 1, 2, 8, 15, "\uda6c\ude1a\ud974\udd52\ud8f7\udd77\ud87d\udf2a\ud96b\uddde\udb6f\ude1f\uda9d\uddad\ud9e3\udd56\udb96\udcbd\ud9b0\udcce\ud958\udde2\ud9ae\udc41", "\u33f2\u939b\u8915\uaef3\u2694\u4292\u132e", "\udb9b\udf28\u9d5f\ud84e\udef3\ucbc5\ud957\udfe7\ud9b0\uddaf\udbe2\udf3e\ud821\udfdb\ud84d\uddc0\uda78\udecb\udaec\udc96\ud963\udfb7",
        52, 98215, -1417320360, 4813747421635721067L, -357L, true, true, (char) 35717, (char) 1389,
        Double.longBitsToDouble(0x3fea30e3716c8e8bL), Double.longBitsToDouble(0x3f8ce78ae46ff680L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CollectionSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "\ud7ee\ud85c\udf6b\uda10\uded2\ud872\udd42\ud894\udf13\udb6f\ude1f", "\u5966\u10de\ub4ad\ud569\u3ebc\uc802\u2439\u7691\u73f3\u87b6\u82b9\u820a", "\ud91a\uddbd\ud8b3\udc09\udbb4\udcba\ud84e\udef3\udb59\udcb7\ud957\udfe7\ud9b0\uddaf\udbe2\udf3e\ud821\udfdb\ud84d\uddc0\uda78\udecb\udaec\udc96\udac4\ude67\u4a8b\ud917\udc38\ud9e4\udf5d\udb58\uddb6\u66e1\udb4c\udcd4\ud8d6\udd0d\ud83e\udfd4",
        46, 62834, 1190595784, 7218423039113734701L, 7749L, true, true, (char) 60041, (char) 42039,
        Double.longBitsToDouble(0x3f9cef9e53048940L), Double.longBitsToDouble(0x3f72e6b1d3a07300L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CollectionSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 2, 8, 15, "\ud755\ud85c\udf6b\uda10\uded2\udaea\udc1f\ud894\udf13\udb6f\ude1f\ud9b5\ude1a\ud97e\udf91\uda3e\udc9b\ud855\udcf3\udb43\uded2\ud9ae\udc41", "\u2809\u7691\u73f3\u8829\u82b9\u820a\u64f1\u398f\u614b\u6051\ucc56\u45b7\u3e54\ub0c5\ud4ae\u1901\uc9cb\u575b\ua5fc\u3175\u05df", "\ud8c4\udeac\ud9b2\udd7f\u66e1\udb4c\udcd4\ud8d6\udd0d\ud83e\udfd4\udad3\udeb0\udb72\udc0b\ub05e\udbca\udc70\ud929\udc7a\ud999\ude7b\udbea\udefc\udad4\udd8a\ud9e3\udf13\udb07\udf2b\uc688",
        38, 40457, 279994827, 502223041220227398L, 46657L, true, false, (char) 52589, (char) 4308,
        Double.longBitsToDouble(0x3fef779b3c5daa20L), Double.longBitsToDouble(0x3fa6eac066fb25a0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.impl.IndexedListSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 11, 8, 16, "\ud7ee\ud85c\udf6b\uda10\uded2\ud872\udd42\ud894\udf13\udb6f\ude1f\ud9b5\ude1a\ud97e\udf91\ud903\udfbe\ud855\udcf1\udb43\uded2\ud9ae\udc41\udb28\uddf0\udbd2\udcb8\ud917\ude03\udbc1\udc62\udb97\ude9f", "\u820a\u64f1\ua3a1\ubd4a\u6051\u1e72\ud54e\u3e54\ub0c5\u2ae8\u1901\u15cc\u35e0\u01c2\u4f87", "\ud917\udc38\ud9e4\udf5d\udb58\uddb6\uda03\udc54\ud8a8\udfaf\ud8a1\ude15",
        43, 23091, 793867586, 5091702232604131012L, 62927L, false, false, (char) 57129, (char) 51311,
        Double.longBitsToDouble(0x3feab6301177102eL), Double.longBitsToDouble(0x3fda6c0811cddb7eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CollectionSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 0, "\ud7ee\ud85c\udf6b\uda10\uded2\ud1e5\ud886\udfc2\udb6f\ude1f\ud9b5\ude1a\uceec\ud903\udfbe\ud855\udcf1\ud8f9\udc1c\ud9ae\udc41", "\u2439\u7691\u73f3\u8829\u82b9\000\u4f2b", "\udb9b\udf28",
        5, -1000, 0, 8756696139172719662L, -76036L, false, false, (char) 15943, (char) 52685,
        Double.longBitsToDouble(0x3fd8133000b1d46cL), Double.longBitsToDouble(0x3fdc7ab85ed6859aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CollectionSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=com.fasterxml.jackson.databind.ser.std.CollectionSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\012",
        Z.run(T, 2, 2, 18, 2, "\ud7ee\ud85c\udf6b\uda10\uded2\ud872\udd42\ud894\udf13\udb6f\ude1f\ud9b5\ude1a\ud97e\udf91\ud903\udfbe\ud855\udcf1\udb43\uded2\ud9ae\udc41", "\u2439\u7691\u73f3\u8829\u82b9\u820a\u64f1", "\udb9b\udf28\udbb1\uddb5\ud84e\udef3\udb59\udcb7\ud957\udfe7\ud9b0\uddaf\udbe2\udf3e\ud821\udfdb\ud84d\uddc0\uda78\udecb\udaec\udc96",
        26, 32845, -365519487, -6087344593034158649L, -4446L, false, false, (char) 5560, (char) 9744,
        Double.longBitsToDouble(0x3fee9a5b14e52aa9L), Double.longBitsToDouble(0x3fec8df8ece4dda5L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 8, 15, "\ud7ee\ud8a0\uddee\uda81\udc39\ud872\udd42\udb92\ude13\ud980\udded\udb73\udcb7\udbfb\ude9f\ud903\udfff\u90fa\udb75\udf07\ud9ae\udc41", "\u2439\u7691\u73f3\u3015\u86ba\u8283\u64f1", "\udb9b\udf28\udbb1\uddb5\ud84e\udef3\udb59\udcb7\ud957\udfe7\udb5c\udd45\udb5a\udcd2\ud98a\uddc9\udadc\udf1b\uda78\udecb\udaec\udc96",
        26, 32845, -365519487, -6087344593034158649L, -4446L, false, false, (char) 4435, (char) 60270,
        Double.longBitsToDouble(0x3fb31738a7299b48L), Double.longBitsToDouble(0x3fec8df8ece4dda5L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 8, 15, "\ud7ee\ud85c\udf6b\uda10\uded2\ud872\udd42\ud894\udf13\udb6f\ude1f\ud9b5\ude1a\ud97e\udf91\ud903\udfbe\ud855\udcf1\udb43\uded2\ud9ae\udc41", "\u2439\u7691\u73f3\u8829\u82b9\u820a\u64f1", "\udb9b\udf28\udbb1\uddb5\ud95f\udccf\udb59\udc99\ue72a\udb9b\udcc1\udbe2\udf3e\ud821\udfdb\ud84d\uddc0\uda78\udecb\udaec\udc96",
        26, 32845, -365519487, -6087344593034158649L, -4446L, false, false, (char) 1389, (char) 21569,
        Double.longBitsToDouble(0x3fda0d49c9ca5d14L), Double.longBitsToDouble(0x3fec8df9ece4dda5L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CollectionSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 15, 18, "\ud7ee\ud85c\udf6b\udb8a\udecf\ud872\udd42\ud894\udf13\udb6f\ude1f\ud9b5\ude1a\ud97e\udf91\ud903\udfbe\ud855\udcf1\udb43\uded2\ud9ae\udc41", "\u2439\u7691\u73f3\u8829\u84c2\u820a\u64f1", "\udb9b\udf28\udbb1\uddb5\ud84e\udef3\udb59\udcb7\ud957\udfe7\ud9b0\uddaf\udbe2\udf3e\ud821\udfdb\ud84d\uddc0\uda78\udecb\udaec\udc96",
        26, 32845, -365519487, -6087344593034158649L, -4446L, false, false, (char) 1389, (char) 60270,
        Double.longBitsToDouble(0x3fb31738a7299b48L), Double.longBitsToDouble(0x3fec8df8ece4dda5L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CollectionSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=com.fasterxml.jackson.databind.ser.std.CollectionSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\012",
        Z.run(T, 2, 2, 2, 14, "\ud7ee\ud85c\udf6b\u538c\ud9e6\ude94\ud894\udf6f\udb6f\ude1f\ud9b5\ude1a\ud97e\udf91\udad7\udda3\ud855\udcf1\ud90f\ude78\ud9ad\udfbb", "\u2439\u7691\u73f3\u8829\u82b9\u820a\u64f1", "\udb9b\udf28\udbb1\uddb5\ud84e\udef3\udb59\udcb7\ud957\udfe7\ud9b0\uddaf\udbe2\udeef\ud821\udfdb\uda7d\udff9\uda6d\udc8d\ud8da\udc95",
        26, 32845, -365519487, -6087267626343801401L, 89599L, true, true, (char) 33536, (char) 24106,
        Double.longBitsToDouble(0x3fe7690a0c26536bL), Double.longBitsToDouble(0x3fe622354f011c6eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CollectionSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 5, 8, "\ud7ee", "\u4dfe\u1ae8\u1f5f\u6207\u6b78\u5966\u57a2\ub4c3\ud569\u6197\u454e", "\udb97\ude9f\ud912\udf86\ud8ee\udffc\udb6f\ude40\ud9e8\udefb\udace\udc6a\u42ba\udb9b\udf28\ud8d5\udf27\uda9c\udfb5\udb59\udca4\ud957\udfe7\ud9b0\uddaf\udbe2\udf3e\ud821\udfdb\ud84d\uddc0",
        -3, 1756, -842154659, 3696918203750325633L, 39833L, true, true, (char) 10545, (char) 32349,
        Double.longBitsToDouble(0x3fe7587b2cbbcb93L), Double.longBitsToDouble(0x3fd422141a8c5ea2L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.EnumSetSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 8, 18, "\ud7ee\ucfea\udbe1\udec2\ud872\udd42\ud894\udf13\udb6f\ude1f\ud9b5\ude1a\ud921\udce5\ud903\udfb7\ud855\udcf1\udb43\uded2\ud973\udcaf", "\u2439\u7691\u73f3\u7e62\u67c1\u4edf\u64f1", "\udb9b\udf28\udbb1\uddb5\ud9ff\uddee\udb59\udc51\ud957\udfe7\ud82b\udcbd\uda22\udebb\ud821\udfdb\ud84d\uddc0\ud8dc\ude4f\ud9b6\udeaf",
        27, 54997, -367511347, -6087344593034158649L, -4446L, false, false, (char) 1389, (char) 5574,
        Double.longBitsToDouble(0x3fc0c042b394cda4L), Double.longBitsToDouble(0x3feae5f8ece4dda5L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 8, 15, "\ud7ee\ud85c\udf6b\uda10\uded2\ud872\udd42\ud894\udf13\udb6f\ude1f\ud9b5\ude1a\ud97e\udf91\ud903\udfbe\ud855\udcf1\udb43\uded2\ud9ae\udc41", "\u2439\u0563\u73f3\u102a\u82b9\u820a\u64f1", "\udb3f\ude5a\udbb1\uddb5\ud84b\udcd2\udb57\uddff\ud957\udfe7\ud9b0\uddaf\udbe2\udf3e\ud821\udfdb\ud84d\uddc0\udb9d\udc2d\ud80b\udf2b",
        -5, 32829, -1120494207, -4042282128198738681L, -4446L, false, false, (char) 1389, (char) 60270,
        Double.longBitsToDouble(0x3fb31738a7299b48L), Double.longBitsToDouble(0x3fecc738ece4dda5L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.EnumSetSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\012",
        Z.run(T, 1, 10, 0, 1, "\u3c48\ud85c\udf6b\uda10\uded2\ud872\udd42\ud894\udf13\udb6f\ude1f\000\000\000\000\000\000", "\u00c2", "\ud912\udfd4",
        20, 96560, -1483870779, 108954730405093L, -8848L, true, true, (char) 51842, (char) 37227,
        Double.longBitsToDouble(0x3e3aeaeb60000000L), Double.longBitsToDouble(0x3fb43f808fd00000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.impl.IndexedListSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=com.fasterxml.jackson.databind.ser.impl.IndexedListSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\012",
        Z.run(T, 2, 11, 11, 15, "\ud7ee\ud8ac\ude1d\uda06\udcf1\ud882\udc83\u5f08\udb6f\ude1f\ud9b5\ude1a\ud97e\udf91\ud903\udfbe\ud855\udcf1\udb43\uded2\ud9ae\udc41", "\u2439\ub774\ua1a7\u2132\u234f\ub9cd\u28ec", "\uda2a\udc11\ud814\udd65\uda5c\ude65\ud922\udfcd\ud8d2\udecc\u0619\udbe2\udf0e\ud821\udfdb",
        12, 15952, -1945269242, -1036486293293396474L, 9442L, true, true, (char) 57655, (char) 10545,
        Double.longBitsToDouble(0x3fa2b71c0500f650L), Double.longBitsToDouble(0x3fdfdc5e9a844216L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CollectionSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 19, 0, "\uda33\uddb3\ud8ac\ude1d\uda06\udcf1\ud882\udc83\ud894\udf13", "\u6b78", "\udb43\uded2\ud9ae\udc45\udb28\uddf0\udbd2\udcb8\ud917\ude03",
        4, 78498, -1960862792, 1051320160269148828L, 65339L, true, false, (char) 40100, (char) 2954,
        Double.longBitsToDouble(0x3fe219db2c101409L), Double.longBitsToDouble(0x3feae7dca44eb298L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.EnumSetSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=com.fasterxml.jackson.databind.ser.std.EnumSetSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\012",
        Z.run(T, 2, 10, 10, 1, "\ud7ee\ud85c\udf6b\uda10\uded2\ud872\udd42\ud894\udf13\udb6f\ude1f\uda00\udcdf\000\ud903\udf8d\ud855\udcf1\udb43\uded2\ud9ae\udc41", "\u2439\u7691\u73f3\u8829\ud44d\u3156\u1653", "\udb7e\udfdf",
        40, 30347, -2001884224, 37727259016036352L, 48131L, false, false, (char) 23982, (char) 52036,
        Double.longBitsToDouble(0x3fdc7ab85ed6859aL), Double.longBitsToDouble(0x3fea9878b85f7cd3L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.EnumSetSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 5, 15, "\ud7ee\ud85c\udf6b\ud82d\uddc1\ud872\udd42\ud894\udf13\udb6f\ude1b\uda7b\udf6e\ud91a\udd7d\ud903\udf8d\ud855\udcf1\udb0f\udc98\uda37\udceb", "\u2439\u7691\u2e64\u7f07\u9879\u1b01\000", "\udba0\udcdf\udbb1\uddb5\ud84e\udef3\ud91c\udf3b\udb94\udfc8\ud8c5\udcc2\udbe8\udd54\ud99c\ude61\ud813\udcc0\uda78\udecb\udaec\udc96\udac4\ude67\036\uda67\udc0e\ud9e4\udfbc",
        56, 48843, 319561893, -8942691476405905902L, -77448L, false, true, (char) 63192, (char) 37616,
        Double.longBitsToDouble(0x3fec45b2cda501aaL), Double.longBitsToDouble(0x3fea2cfee6e5788dL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CollectionSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 2, 8, 15, "\ud7ee\ud85c\udf6b\uda10\uded2\ud872\udd42\ud894\udf13\udb6f\ude1f\ud9b5\ude1a\ud97e\udf91\ud903\udfbe\ud855\udcf1\udb43\uded2\ud9ae\udc41", "\u2439\u7691\u73f3\u8829\u82b9\u820a\u64f1", "\udb9b\udf28\udbb1\uddb5\ud84e\udef3\udb59\udcb7\ud957\udfe7\ud9b0\uddaf\udbe2\udf3e\ud821\udfdb\ud84d\uddc0\uda78\udecb\udaec\udc96",
        26, 32845, -365519487, -6087344595481252434L, -73570L, true, false, (char) 48719, (char) 26702,
        Double.longBitsToDouble(0x3fd4221418685ea2L), Double.longBitsToDouble(0x3fe622354f011c6eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CollectionSerializer:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 6, "\uda83\udfd3\udbd1\ude86\uda10\uded2\ud1e5\ud9a1\udecf\udb6f\ude43\udaea\udcb4\uceec\ud903\udfbe\ud855\udcf1\udbbc\udcb8\ud80b\ude84", "\u1fb9\u7906\u73f3\u8829\u82b9\uc4af", "\000\udb9b\udf28\u9bf0\000",
        42, 39910, -1140976224, -143358099727572400L, -40964L, false, false, (char) 26972, (char) 48324,
        Double.longBitsToDouble(0x3fd81b155e3bd46cL), Double.longBitsToDouble(0x3fdc72da1ed6859aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildArraySerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.type.ArrayType,com.fasterxml.jackson.databind.BeanDescription,boolean,com.fasterxml.jackson.databind.jsontype.TypeSerializer,com.fasterxml.jackson.databind.JsonSerializer|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildCollectionSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.type.CollectionType,com.fasterxml.jackson.databind.BeanDescription,boolean,com.fasterxml.jackson.databind.jsontype.TypeSerializer,com.fasterxml.jackson.databind.JsonSerializer|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildCollectionSerializer|com.fasterxml.jackson.databind.JavaType,boolean,com.fasterxml.jackson.databind.jsontype.TypeSerializer,com.fasterxml.jackson.databind.JsonSerializer|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildContainerSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription,boolean|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildMapSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.type.MapType,com.fasterxml.jackson.databind.BeanDescription,boolean,com.fasterxml.jackson.databind.JsonSerializer,com.fasterxml.jackson.databind.jsontype.TypeSerializer,com.fasterxml.jackson.databind.JsonSerializer|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|_createSerializer2|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription,boolean|new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|_findContentSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.introspect.Annotated|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|_findKeySerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.introspect.Annotated|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|_verifyAsClass|java.lang.Object,java.lang.String,java.lang.Class|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildEnumSerializer|com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildEnumSetSerializer|com.fasterxml.jackson.databind.JavaType|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildIndexedListSerializer|com.fasterxml.jackson.databind.JavaType,boolean,com.fasterxml.jackson.databind.jsontype.TypeSerializer,com.fasterxml.jackson.databind.JsonSerializer|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildIterableSerializer|com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription,boolean|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildIterableSerializer|com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription,boolean,com.fasterxml.jackson.databind.JavaType|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildIteratorSerializer|com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription,boolean|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildIteratorSerializer|com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription,boolean,com.fasterxml.jackson.databind.JavaType|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildArraySerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.type.ArrayType,com.fasterxml.jackson.databind.BeanDescription,boolean,com.fasterxml.jackson.databind.jsontype.TypeSerializer,com.fasterxml.jackson.databind.JsonSerializer|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildCollectionSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.type.CollectionType,com.fasterxml.jackson.databind.BeanDescription,boolean,com.fasterxml.jackson.databind.jsontype.TypeSerializer,com.fasterxml.jackson.databind.JsonSerializer|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildCollectionSerializer|com.fasterxml.jackson.databind.JavaType,boolean,com.fasterxml.jackson.databind.jsontype.TypeSerializer,com.fasterxml.jackson.databind.JsonSerializer|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildContainerSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription,boolean|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BasicSerializerFactory|buildMapSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.type.MapType,com.fasterxml.jackson.databind.BeanDescription,boolean,com.fasterxml.jackson.databind.JsonSerializer,com.fasterxml.jackson.databind.jsontype.TypeSerializer,com.fasterxml.jackson.databind.JsonSerializer|fld:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:instance",
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|_createSerializer2|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription,boolean|new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
