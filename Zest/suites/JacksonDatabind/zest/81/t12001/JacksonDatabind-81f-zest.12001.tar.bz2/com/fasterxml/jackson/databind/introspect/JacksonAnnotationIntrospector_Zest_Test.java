package com.fasterxml.jackson.databind.introspect;
import org.junit.Test;
import static org.junit.Assert.*;
public class JacksonAnnotationIntrospector_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 10, 18, 3, "\uda79\udcb0\udabc\udf8d\ud8a4\udc95", "\u6159\u75b6\u5a70\u32e2", "\uda4b\udf37\ud947\udc39\u4c1c",
        31, 65856, 2126972163, 2819467887620818555L, -34853L, true, false, (char) 26700, (char) 48165,
        Double.longBitsToDouble(0x3fcedc323f1e7538L), Double.longBitsToDouble(0x3fe3376bbe8da424L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 10, 18, 3, "\uda79\udcb0\udaec\udd8d\ud8a4\udc95", "\u009a\u3a1d\u88b5\u9519", "\udb5a\udc02\ud947\udc39\u4c1c\ud961\udeb2\ud99b\udc35\uda75\udc7b\ud90f\udd69\uda35\udda3\ud886\udda8\ud974\udce1\uda1c\ude92\udaae\udedb\uda28\udf20\udb6c\ude71",
        20, 20062, -310913081, -6619123334866317683L, -26868L, true, false, (char) 42392, (char) 40703,
        Double.longBitsToDouble(0x3fea231ee7b3fa35L), Double.longBitsToDouble(0x3fe0ae577ec003a5L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 17, 13, 3, "\uda79\udcb0\udabc\udf8d\udb30\udeb9", "\u6159\u75b6\u5a70\u32e2\ub753\ubd91", "\u4c1c\ud961\udeb2\ud99b\udc35\uda75\udc7b\ud90f\udd69\udab9\udf06",
        26, 42537, -1782025687, 1636778660527789383L, 45040L, false, true, (char) 29973, (char) 5086,
        Double.longBitsToDouble(0x3fe46d2125871106L), Double.longBitsToDouble(0x3fd16b548ca80c26L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\u9190\u95f0\u3209\ub753}\ud8cf\udedc\ud87f\udea2\ud994\udc1c\ud8c3\udd3e |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 14, 9, 16, "\ud8cf\udedc\ud87f\udea2\ud994\udc1c\ud8c3\udd3e", "\u9190\u95f0\u3209\ub753", "\udb4a\udfe0\ud8e8\udee1\ud989\udf9c\ud99b\udc35\udb25\ude35\uda33\udc35\ud85c\udf67\udb54\udfd2\ud8dc\udc3e\ud993\udc2d\udaae\udedb\ud9c6\ude80\udaf0\uddcf\udb6a\udd8c\ud818\udf25\ud987\udeaf\ud876\udcfc\udacf\ude13\ud87d\udc6c\udb23\udd7b",
        29, 50464, 666055031, 6093780509685958701L, -18576L, false, false, (char) 28822, (char) 37826,
        Double.longBitsToDouble(0x3f9dbe365e886d20L), Double.longBitsToDouble(0x3fcb0f18ed3e5f98L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 10, 18, 7, "\uda4e\udffb\udabc\udf8d\ud8a4\udc95\ud8c3\udd3e\ud991\ude4b\ud8ee\udcd8\ud8eb\udea2\ud8c6\udd6d\udaeb\udca3\uda82\udf4a\ub913\udbf0\udf8c\ud87b\udc1d\u4c1c\ud961\udeb2", "\uc97a\u7974\u1a49\u63a0\u6504\ud470", "\udb6a\udd8c\udbfb\udc25\ud987\udeaf\ud876\udcfc\ud98f\udd6a\ud888\ude98\udacb\udf80\ud9ac\udd47\udb42\udfef",
        57, 37198, -605750208, -4456379816479059293L, -7801L, false, false, (char) 41556, (char) 60189,
        Double.longBitsToDouble(0x3fef246303419920L), Double.longBitsToDouble(0x3fe160b0593d77b9L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 10, 3, "\udbed\udecb\udab2\udc78\ud8a4\udc95", "\000\u7537\u5a70\u32e2", "\uda4b\udf37",
        -5, -1000, 0, 0L, -100000L, false, false, (char) 36174, (char) 14498,
        Double.longBitsToDouble(0x3fd8595c80f62d6eL), Double.longBitsToDouble(0x3fe001126000b8cdL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 7, 1, 9, "\uda79\udcb0\udabc\udf8d\uda6b\ude99\ud81b\udef6\ud894\udd2c\ud8ee\udd9e\ud864\udfb8\uda09\udf63\udaeb\udca3\uda82\udf4a\uda1a\udd26\uda4b\udf37\ud947\udc39\u4c1c\udaa1\udeb2\u2131\ud8ff\udffd\udb5a\udc49\uda87\udd46\u932a", "\ud470\u2922\u799d\u0fcd\u8931", "\ud976\udfc4\ud815\uddcc\uda6d\ude85\uda17\udcb5\udb96\udfe0\udaa1\udfc4\udb98\udd94\ud9a8\udc8e\uce17\ud9d7\udd19\udbb9\uddf9\uda97\ude2e\udabc\udda8\ud868\udfb2\udad0\udebf\ud9a1\ude44\udac5\udf9a\ud95d\uddf3\uda84\udc6e\ud8d0\udcb6\udbc6\udd76",
        49, 74356, -878220959, 4619635572410594224L, -45325L, true, true, (char) 9851, (char) 55265,
        Double.longBitsToDouble(0x3fe0a3a7f5912550L), Double.longBitsToDouble(0x3fefcd075a528214L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 18, 3, "\u7eb8\udabc\udf8d\ud8a4\udc95", "\u6159\u75b6\u5a70\u32e2", "\uda4b\udf37\ud947\udc39\u4c1c",
        31, 65856, 2126972163, 2819467887620818555L, -34853L, true, true, (char) 44060, (char) 48165,
        Double.longBitsToDouble(0x3fcedc323f1e7538L), Double.longBitsToDouble(0x3fe3376bbe8da424L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 18, 3, "\uda79\udcb0\udabc\udf8d\ud8a4\udc95", "\u6159\u75b6\u5a70\u4fbc", "\uda4b\udf37\ud947\udc39\ue425",
        31, 65856, 2126972163, 2819467887620818555L, -34853L, true, false, (char) 26700, (char) 48165,
        Double.longBitsToDouble(0x3fe4370c8fc756c4L), Double.longBitsToDouble(0x3fe3376bbe8da424L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 18, 6, "\uda25\ude2b", "\u0b31\u35e0\u65a5\u75b6\u2b08\u32e2\ub753", "\ud947\udc39\ud995\udd1b\ud871\uddad\ud925\udd7d\uda98\udc29\udbc1\udfe2\udab9\udf06\udb1f\uddf1\ue785\ud9c0\udfdb\udb77\udeff\uda36\udc2a\udb6c\uddcd\ud83b\udca2\udb6a\udc12\ud987\udeaf\uda4f\udf68\uda3e\udd42\ud93a\udd68\uda85\udde2\ud996\udc4c",
        13, 92333, -1568736428, -2247193034552483426L, 8899L, true, true, (char) 10798, (char) 5092,
        Double.longBitsToDouble(0x3fc16993dd3f3788L), Double.longBitsToDouble(0x3fe5452ff4dd8dc4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 18, 18, 3, "\ud8de\udd4f\udad7\udcf6\ud8a4\udc95", "\u6159\u75b6\u5a70\u32e2", "\uda4b\udf37\ud947\udc39\u4c1c",
        31, 65856, 2126972163, 2819467887620818555L, -34853L, true, false, (char) 26700, (char) 48165,
        Double.longBitsToDouble(0x3fcedc323f1e7538L), Double.longBitsToDouble(0x3fb6e0bb5c68be00L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\uda79\udcb0\udae1\udca9\ud8a4\udc95 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 14, 4, 3, "\uda79\udcb0\udae1\udca9\ud8a4\udc95", "\u6159\u75b6\u5a70\u32e2", "\uda4b\udf37\udb00\udc95\uda5b\udf1f",
        31, 65856, 818349315, 1073680599403991317L, -34853L, true, false, (char) 45131, (char) 57593,
        Double.longBitsToDouble(0x3fcedc3226ee7538L), Double.longBitsToDouble(0x3fe3376bbe8da424L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 13, 2, "\uda79\udcb0\u2b15\000", "\u6159", "\udaeb\udca3\uda82\udf4a\000\000\ud947\udc39\u00b7\ud986\udc02",
        -5, -1000, 0, -1973029664L, -70816L, false, true, (char) 65329, (char) 26700,
        Double.longBitsToDouble(0x3f4719a000000000L), Double.longBitsToDouble(0x3fe8000000000077L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 5, 18, 3, "\uda79\udcb0\udabc\udf8d\ud8a4\udc95", "\u6159\u75b6\u5a70\u32e2", "\uda4b\udf37\ud947\udc39\u4c1c",
        31, 65856, 2126972163, 2819467887620818555L, -34853L, true, false, (char) 26700, (char) 48165,
        Double.longBitsToDouble(0x3fcedc323f1e7538L), Double.longBitsToDouble(0x3fe3376bbe8da424L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 18, 3, "\uda79\udcb0\udab3\udd8d\ud8a4\udc95\ud8c3\udd3e\ud804\udce4\ud9d7\udcc9", "\ub151\u5548\u2b62\uc60f\u959d\ubdde\u64cb\u9b9c\u3f35\u2f4c\u7105\u197e\u3eb9\u5445\ud470\u5a4a\ua62e\u81f6\u8b72\u29d0\u8e82\u91a5\ud712\u921b\u29aa\u93b0\u9456\u12cd\u925e\u8f67", "\udbb5\udcae",
        45, 19497, -2071215078, 2284460625624594083L, -35706L, true, true, (char) 42945, (char) 21436,
        Double.longBitsToDouble(0x3fe8416f64929695L), Double.longBitsToDouble(0x3fe03ee275f1d20dL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 18, 3, "\ud95f\udd84\udac8\udec1\uda8d\udd42", "\u0b5a\uc53f\u4a0b\u32e2\ub3e4\ubd91", "\u4c1c\ud961\udeb2\ud99b\udc35\uda75\udc7b\ud90f\udd69\udab9\udf06",
        26, 42537, -1782025687, 1636778660890208379L, 95752L, false, false, (char) 29973, (char) 45789,
        Double.longBitsToDouble(0x3fe46d70ebfb9a58L), Double.longBitsToDouble(0x3fe545d1942b0088L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 4, 4, 3, "\uda79\udcb0\udbcc\udda9\ud8a4\udc95", "\u1c98\u75cc\u33b2\u43c4\ub753\ubd91\ucd7c\u959d\ubdde\u31d9\u9b9c\uc344\u5897\u7974\u197e\u3eb9\u5445", "\udb61\udc89\udb6a\udd8c\ud818\udf25\ud987\udeaf\udbea\udc4a\udaf2\udfd7\ud9dc\udc50\uda70\ude2b\ud877\udd4e\ud8e0\udc16\ud9f3\uddc1",
        14, 54195, 143436510, -3028746149332147762L, -30553L, false, true, (char) 45252, (char) 64543,
        Double.longBitsToDouble(0x3fc6dc20abe2aaa4L), Double.longBitsToDouble(0x3fea4469eb4c1129L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\u6159\u75b6\u5a70\ubaf9}\uda79\udcb0\udabc\udf8d\ud8be\ude95 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 14, 7, 3, "\uda79\udcb0\udabc\udf8d\ud8be\ude95", "\u6159\u75b6\u5a70\ubaf9", "\ud8c2\udd94\ud947\udc39\u4c1c\ud961\udeb2\ud99b\udc35\uda75\udc7b\uda1c\udebc\udab9\udf3d\udb1f\uddf1\ue785\uda16\udfe6\udaae\udedb\ud9c6\ude80\ud898\uddc3\udb90\udc72\ud818\udf25\ud96a\udfea\ud877\uded3\ud9e8\uddb6\ud817\ude43\uda41\udefa\udad6\udca7\uda71\ude05\ud9d2\udec2\uda3d\ude23\udbab\udc06\uda6f\uddd2\ud96f\udccd\uda7a\udc1a\ud8bd\udeec\ue3a3",
        57, 16418, 448743938, -7808996986919858205L, 86179L, false, false, (char) 37747, (char) 4789,
        Double.longBitsToDouble(0x3fedd1048ae69918L), Double.longBitsToDouble(0x3f9cdb04e1b65340L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 6, 5, 14, "\uda79\udcb0\udabc\udf8d\ud8a4\udc95\ud8c3\udd3e\u9776\ud8eb\udd8a", "\u32e2\u9308\ubd91\uc60f\u959d\ubdde\u4066\u35e0\u02fd\u6c39", "\ue785\uda16\udfe6\udaae\udedb\uda69\uddd2",
        37, 97703, -1655772938, -1335361516334733722L, 86883L, false, true, (char) 18038, (char) 36187,
        Double.longBitsToDouble(0x3fd810b5bc3ce324L), Double.longBitsToDouble(0x3fe85ca3ed718e60L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 8, 3, "\udb2c\udc8b\udb50\udc0e\uda97\udc63", "\u7a56\u75b6\ud6ce\u81a1", "\uda4b\udfcb\ud8b3\ude0f\u81d0\ud961\udeb2\ud99b\udc35",
        38, 58523, 155354747, -8474097881883082007L, -34853L, true, false, (char) 14463, (char) 48165,
        Double.longBitsToDouble(0x3fc921522f1e7538L), Double.longBitsToDouble(0x3fe3376ae68da424L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 1, 1, 3, "\uda79\udcb0\ud95a\udc7b\ud9a5\udfa9", "\u375e\u909e\u20f6\u443b", "\uda4b\udf37\ud947\udc39\ud8da\udd7f",
        21, 76848, 2126972240, 2819467887620818555L, -35209L, false, false, (char) 38589, (char) 65329,
        Double.longBitsToDouble(0x3fe001126358b8cdL), Double.longBitsToDouble(0x3fcedc322ce9fd38L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 17, 0, 0, "\uda79\udcb0", "\u0a9f", "\ud8eb\udea2\ud8c6\udd6d\udaea\udfca\uda82\udf4a",
        -1, 88373, -932622464, 0L, -35747L, true, true, (char) 44442, (char) 62463,
        Double.longBitsToDouble(0x3eb9514e30000000L), Double.longBitsToDouble(0x3fd8595c80002d6eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 3, 8, "\uda79\udcb0\udabc\udf8d\ud8a4\udc95", "\u25e8\u0e0a\u5ad8\u32e2", "\uda4b\udf37\ud947\udc39\ue756",
        31, 65856, 1137116419, 4301959597625325285L, -80663L, true, false, (char) 38733, (char) 65329,
        Double.longBitsToDouble(0x3fe001126358b8cdL), Double.longBitsToDouble(0x3fcedc323f1e7538L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 1, 5, 3, "\uda79\udc83\udaa2\udd04\uda26\udfb8", "\uaf9d\u7190\u5ae8\u32e2\u38e9\ubd91\uc60f\u1d91\uba37\ub84c\u9b9c\u8d0b\u1db3\u7974\u197e\u3eb9\u5445\uad54\u5184\uc734\uac5a\u8bfd\u29d0", "\ud961\udfab",
        41, 42281, -36009527, 3797802971946077207L, -91358L, false, true, (char) 41528, (char) 34606,
        Double.longBitsToDouble(0x3fc27c260be10c34L), Double.longBitsToDouble(0x3fe87b51ac357726L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 17, 13, 3, "\uda79\udcb0\udabc\udf8d\udb30\udeb9", "\u6159\u75b6\u5a70\u32e2\ub753\ubd91", "\u4c1c\ud961\udeb2\ud99b\udc35\uda75\udc7b\udae5\uddb4\udab9\udedb",
        26, 14097, -2079144231, 1637889244581254471L, 45040L, true, false, (char) 29973, (char) 5086,
        Double.longBitsToDouble(0x3fe46d2125871106L), Double.longBitsToDouble(0x3fd16b548da20c26L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 5, 18, 5, "\udb83\udf1d\ucb93\udb30\udeb9\ud945\udf16", "\u3190\u5a70\u32e2\ub753", "\ud946\ude78\u4c1c\ud961\udeb2\ud99b\udc35\uda71\uddfa\ud90f\ude0d\udb6a\ude33\udb1f\udde6\ue785\udb10\udceb\ud9b5\udd7f\ud902\udd01\ud915\udc36\ud9ad\udee0\u95cd\ud987\udeaf\udbb7\udf7c\udb60\udc3f\udb22\udd1f\udab7\ude66",
        27, 38541, 560135106, 1067327529170123737L, 85282L, false, false, (char) 49091, (char) 7769,
        Double.longBitsToDouble(0x3fd614312b8e12a8L), Double.longBitsToDouble(0x3fe80ef2c4d2fb4dL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 13, 3, "\uda79\udcb0\udabc\udf8d\udb30\udeb9", "\u6159\u75b6\u5a70\u32e2\ub753\ubd91", "\u4c1c\ud961\udeb2\ud99b\udc35\uda75\udc7b\ud90f\udd69\udab9\udf06",
        31, 62606, 1394271447, 1641697506183271751L, 45040L, false, true, (char) 29973, (char) 5086,
        Double.longBitsToDouble(0x3fe46d2126efde06L), Double.longBitsToDouble(0x3fd162f60ca80c26L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 17, 13, 16, "\u4294\ud953\udd50\ud9f1\uddb1\ud9cd\udee3\ud991\ude4b", "\u5a70\u32e2\ub753\ubd91\u2e96\u7bc9\ubdde\u4066\u9b9c\uc344\uc97a\u7974\u197e\u3eb9\u5445", "\ud863\udc14\ud94b\udddb\u95cd\ud987\udeaf\ud876\udcfc\udb55\udf8d\udb22\udd1f\uda86\udd71\ud8ff\ude8f\udbbc\ude31\ud9b6\uddb5",
        41, 65533, 653473197, -8261893311215743068L, 52852L, false, true, (char) 16386, (char) 61824,
        Double.longBitsToDouble(0x3fd923fbe2bc8660L), Double.longBitsToDouble(0x3fce869bed7f128cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 17, 13, 3, "\uda79\udcb0\udae6\udd41\udb09\udf16", "\u3d5d\ud76c\u5aa9", "\uda1a\udd26\uda69\udf0d\ud946\ude78\u4c1c\ud961\udeb2\ud99b\udc35",
        57, 67804, 155354747, -8474097881883082007L, 84893L, false, true, (char) 28315, (char) 29973,
        Double.longBitsToDouble(0x3feb34f3be8da41cL), Double.longBitsToDouble(0x3fe7dd855cb17e70L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 0, 11, "\udb1c\udeae\ud87b\ude7a\udb30\udf18\ud9cd\udee3\ud991\ude4b\ud8ee\udcd8\ud8eb\udea2\ud8c6\udd6d\ud89a\udd0c\ud852\udc8a", "\u7bc9\ubdde\u3ac2\u5d17\u30d4\uc881\u7974\u197e\u3eb9\u5445\ud470\uc453\u07fc\u3805\u9ea4\u29d0\u39d6\u6aba\u7d1f\u3849", "\uda31\udd21\ud97a\udc48\ud80f\udccd\uda0e\ude81\ud84a\udfe1\udb7a\udca2\ud897\udc7b\ud954\udc35\udba2\ude78\uda7d\udd8d",
        19, 7043, 495001167, 5907518788838063129L, -35119L, true, true, (char) 45733, (char) 52587,
        Double.longBitsToDouble(0x3f7335f60d560b00L), Double.longBitsToDouble(0x3fecdecd1150572fL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Number |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 4, 1, 7, "\uda79\udcb0\udabc\udf8d\udb30\udeb9", "\u22c8\ub64a\u5a70\u32e2\ua7f9", "\ud946\ude78\u4c1c\ud961\udeb2\ud99b\udc35\uda75\udc7b\ud90f\udd69\udab9\udf06\udb1f\uddf1\udae1\ude99\uda16\udfe6\udaae\udedb\uda35\ude06\ud863\udc14\ud94b\udddb\u95cd\ud987\udeaf\ud876\udcfc\udb55\udf8d\udb22\udd1f\uda86\udd71",
        35, 33822, 1235673395, 6005971238357723650L, -44959L, true, false, (char) 28127, (char) 57397,
        Double.longBitsToDouble(0x3fdd63bb34c05262L), Double.longBitsToDouble(0x3f8d31742d917e00L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\uc4eb\u9802\ud177\u32e2\ub753\ubd91}\uda79\udcb0\udabc\udf8d\udb30\udeb9 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 14, 11, 3, "\uda79\udcb0\udabc\udf8d\udb30\udeb9", "\uc4eb\u9802\ud177\u32e2\ub753\ubd91", "\u4c1c\ud961\udeb2\ud99b\udc35\uda75\udc7b\uda8d\ude29\uda58\udd06",
        26, 42537, -1786461039, -5857211119535831904L, 45040L, false, true, (char) 29973, (char) 61661,
        Double.longBitsToDouble(0x3fe38bbcfd87112fL), Double.longBitsToDouble(0x3fd16b548ca80c26L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName: |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 14, 9, 17, "", "\000\u5b90\u137f\u6159\u9190", "\uda82\udf4a\uda1a\udd26\uda4b\udf37",
        13, 45523, 1932120275, -8227439972629215997L, 96997L, true, false, (char) 26700, (char) 48197,
        Double.longBitsToDouble(0x3fcedc3220027538L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Integer |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 5, 17, 16, "\ud8cf\udedc\ud87f\udea2\ud994\udc1c\ud8c3\udd3e", "\u9190\u69c5\u085e\ub753", "\udbff\udc2f\ud88a\udcc3\udaa3\uddbf\ud99b\udc35\udb25\ude35\uda33\udc35\ud85c\udf67\udb54\udfd2\ud8dc\udc3e\ud993\udc2d\udaae\udedb\u035f\uda98\udd08\uda6c\uddfd\udabf\ude77\ud8bf\ude5b\uda0a\ude8d\udacf\ude19\ud87d\udc6c\udb23\udd7b",
        29, 50464, 666055031, 6093780509685958701L, 80522L, false, false, (char) 28822, (char) 37826,
        Double.longBitsToDouble(0x3f9dbe365e886d20L), Double.longBitsToDouble(0x3fcb0f18ed3e5f98L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\ud941\udea1\ud87f\ude80 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 9, 16, "\ud941\udea1\ud87f\ude80", "\ubb44\u615f", "\udaea\udfca",
        36, 18384, -1447240627, -1118444345328310245L, 48208L, true, true, (char) 50041, (char) 3282,
        Double.longBitsToDouble(0x3fda88bd04f10b2cL), Double.longBitsToDouble(0x3fee75cd31850653L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\ud9b0\ude50\udba1\udd17\udb8d\udef5 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 12, 4, "\ud9b0\ude50\udba1\udd17\udb8d\udef5", "\u5900\u7537\u5a70\u32e2", "\ud893\udf09\ud9a6\ude9c\000",
        -5, -1000, 0, 0L, -34853L, true, false, (char) 26700, (char) 47309,
        Double.longBitsToDouble(0x3fb4c7fd2ee7ed38L), Double.longBitsToDouble(0x3fbd996fb98e1318L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 11, 3, "\udbfd\udddc\u1e5c\ud8a4\udc65", "\000\u7537\u9f73\ud1b0", "\uda4b\udf37",
        -5, -1000, 0, 0L, -100000L, false, false, (char) 9917, (char) 14498,
        Double.longBitsToDouble(0x3fd8595c80f62d6eL), Double.longBitsToDouble(0x3fe0011266e1b0d3L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=java.lang.Class:java.lang.Object |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 5, 5, 3, "\udbdd\udd7a\ud8bd\udfef\ud93a\udccf", "\u947a\u1271\u5a70\u32e2", "\uda4b\udf37",
        17, 37669, -156639462, -1453661763763777917L, -4150L, false, false, (char) 42338, (char) 9378,
        Double.longBitsToDouble(0x3fef058646f368fdL), Double.longBitsToDouble(0x3fdd619a5e6ceaf2L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\uda57\udeb0\udab2\udca9\ud8a4\udc95 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 14, 17, 11, "\uda57\udeb0\udab2\udca9\ud8a4\udc95", "", "\ud8c6\udd6d",
        6, 38260, -410910720, 53159518892195968L, -35744L, false, false, (char) 8187, (char) 65171,
        Double.longBitsToDouble(0x3fe74c532a29c678L), Double.longBitsToDouble(0x3fd8595c80f62d6eL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\u2b93\u09fc\u7413\u32e2\ub753\ubd91\uc60f\u3552}\uda79\udcb0\udae1\udca9\ud9f8\udf40 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:{\u2b93\u09fc\u7413\u32e2\ub753\ubd91\uc60f\u3552}\uda79\udcb0\udae1\udca9\ud9f8\udf40 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 14, 14, 11, "\uda79\udcb0\udae1\udca9\ud9f8\udf40", "\u2b93\u09fc\u7413\u32e2\ub753\ubd91\uc60f\u3552", "\ud99b\udc35\udb81\udfe2\udb20\udfb1\ud96a\udda7\udb1f\uddf1\ud934\udf8b\ud828\udc3e\ud924\udc46\ud866\udd7b\udbd8\udffa\udb6a\udd73\ud818\udf25\ud958\udca3\ud86f\udcfc",
        22, 78549, 1099873589, 1530187553930122558L, -4008L, true, true, (char) 34256, (char) 37653,
        Double.longBitsToDouble(0x3fe60b70678d88e7L), Double.longBitsToDouble(0x3fbdcfaa19ddb510L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\ub753\ubd91\uc60f\u3552\uaa7c\u4066\u9b9c\u96d2\ucc79\u1c95\u197e}\uda79\udcb0\udae1\udca9\ud8a4\udc95\ud8c3\udd3e\ud991\udd85\ud8e6\udfd8\ud8eb\udea2 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 14, 4, 3, "\uda79\udcb0\udae1\udca9\ud8a4\udc95\ud8c3\udd3e\ud991\udd85\ud8e6\udfd8\ud8eb\udea2", "\ub753\ubd91\uc60f\u3552\uaa7c\u4066\u9b9c\u96d2\ucc79\u1c95\u197e", "\udaae\udedb\ud9c6\ude80\udbd8\udffa\udb6a\udd73\ud818\udf25\ud958\udca3\ud876\udcfc\udbe2\udd73\ud8d9\uddd4\udb84\uded5",
        36, 83902, -59944204, 5033051541036622724L, -74107L, false, false, (char) 25404, (char) 30080,
        Double.longBitsToDouble(0x3fe6522569480903L), Double.longBitsToDouble(0x3fd0bb25a1ea55a6L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 17, 17, 3, "\uda6d\udf6a\ud982\uddcf\ud9ab\udc78", "\u140a\ucb74\u342f\u30b7", "\ue456\ud9dc\udc99\ud9e3\udff9\ud96c\uddad\ud733\uda75\udc7b\ud90f\udd69\udab9\udf06\udb1f\uddf1\ue785\ud8e6\udece\udbb0\udefc\ud98d\ude01\uda65\udfaa\udade\udc82\ud818\udf25\ud97a\udde9\ud910\ude89",
        12, 13486, -196151906, -2716809368054187066L, 95892L, true, false, (char) 54504, (char) 10739,
        Double.longBitsToDouble(0x3f878be0023a6e40L), Double.longBitsToDouble(0x3fd969f2300ad166L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\u0f9d\u59a5\uc53f\u4a0b\ub7d9\u4510\u2114\uc60f\u959d\ubdde\u4066\u9b9c\uc344\uc97a\u7974}\ud95f\udd84\uda07\udc77 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 15, 11, "\ud95f\udd84\uda07\udc77", "\u0f9d\u59a5\uc53f\u4a0b\ub7d9\u4510\u2114\uc60f\u959d\ubdde\u4066\u9b9c\uc344\uc97a\u7974", "\uda16\udfe6\udaae\udedb\ud9c6\ude80\udb6c\uddcd\udb6a\udd8c\ud818\udf25\udb7c\udf45\uda8a\udc4a\ud958\udc8f",
        23, 60902, 1462801705, 4730208436537066213L, 30815L, false, true, (char) 40597, (char) 40927,
        Double.longBitsToDouble(0x3f9baeca47d19600L), Double.longBitsToDouble(0x3fd89c58ce57c9e2L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 6, 7, 18, "\ud95f\udd84", "\u8687\uafb5", "\ud8c2\udd08\udaeb\udca3\udb65\udf51\uda1a\udd26\uda4b\udf37\ud947\udc39\u4c1c",
        26, 53601, -2051951874, 2819468132433954427L, -34853L, true, false, (char) 26700, (char) 48165,
        Double.longBitsToDouble(0x3fcedc323f1e7538L), Double.longBitsToDouble(0x3fd66ed77d1b5c3aL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 10, 5, 3, "\ud86d\udc86\udac8\ude43\uda8d\udd42", "\u2e9f\u536e\u4a07\u6b71\ub3e4\ubd91\u73e8\u9542\ubdde\u9048\u9b3c\uc344\uc97a", "\ud834\udc0e\udbbd\udf9d\udb52\udd4d\ud9c6\ude80\ud891\udf84",
        15, 15989, -1399358453, 5052412015626702477L, -16712L, true, true, (char) 62354, (char) 3973,
        Double.longBitsToDouble(0x3f3442240637c800L), Double.longBitsToDouble(0x3feb4deaeae8b742L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 10, 10, 3, "\ud95f\udd3d\udac8\udec1\uda8d\udd42", "\u0b5a", "\udaeb\udca3\udb65\udf51\uda1a\udd26\ud804\udd93\ud947\udc01\ud8df\udd20\ud961\udebb\ud99b\udc35\uda88\uddc5\uda89\udc26\udaad\udf83\udb1f\uddf1\udb48\udc0c\uda8b\ude0f\ud80e\udcb7\udb91\ude26\udb90\udf1e",
        20, 20062, -310913081, -5900342896613634419L, -90922L, false, true, (char) 2906, (char) 60982,
        Double.longBitsToDouble(0x3fe982854f22b09cL), Double.longBitsToDouble(0x3fdad35767e8ca24L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 6, 6, 10, "\ud95f\udd84\udac8\udec1\uda8d\udd42", "\u0b5a\uc509\u4a0b\u32e2\ub3e4\ubd91", "\u4c64\ud961\udeb2\ud99b\udc35\uda75\udc7b\ud90f\udd69\udab9\udf06\udb1f\uddf1\ue785\uda16\udfe6\udaae\udedb\ud9c6\ude80",
        -2, 19064, -1655793400, -1335361516167379610L, -10907L, false, false, (char) 16062, (char) 19350,
        Double.longBitsToDouble(0x3fd1b889c16b65aeL), Double.longBitsToDouble(0x3fbee01d4cb11a28L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 4, 4, 3, "\uda79\udcb0\udbcc\udda9\ud8a4\udc95", "\u1c98\ubc75\u65bc\u43c4\ub753\uc390\ua660\ub574\u13c4\ud42e\u0807\ua217\u5897\u7974\u197e\u30a7\ub72e", "\udb61\udc89\udb6a\udd8c\udb77\ude93\ud8b8\udfc6\ud83e\udc26\udaf3\udd83\ud9dc\udc50\uda70\ude2b\uda60\udee3\udaeb\udd09\udaf6\ude83",
        49, 84305, 143436510, 2205255753840876596L, -30553L, false, true, (char) 45252, (char) 64543,
        Double.longBitsToDouble(0x3fc6dc20abe2aaa4L), Double.longBitsToDouble(0x3fea4469eb4c1129L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 1, 1, 3, "\uda79\udcb0\ud95a\udc7b\ud9a5\udfa9", "\u375e", "\uda69\uddd8\ud87e\udc22",
        -1, 88373, -932622464, -6379869252770779299L, 97968L, true, true, (char) 44442, (char) 65057,
        Double.longBitsToDouble(0x3fe74c532c40359fL), Double.longBitsToDouble(0x3fd8595380f62d6eL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 1, 1, 3, "\uda79\udcb0\ud95a\udc7b\ud9a5\udfa9", "\u375e\u909e\u20f6\u443b", "\uda4b\udf37\ud947\udc39\ud8da\udd7f",
        21, 76848, 2126972240, 2819467888891168379L, -35209L, false, false, (char) 38589, (char) 65329,
        Double.longBitsToDouble(0x3fe001126358b8cdL), Double.longBitsToDouble(0x3fcedc322ce9fd38L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\ud941\udea1\ud87f\ude80 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:\ud941\udea1\ud87f\ude80 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 14, 14, 6, "\ud941\udea1\ud87f\ude80", "\ubb44\u615f", "\udaea\udfca",
        36, 18384, -1447240627, -6055233964037173282L, 58475L, true, true, (char) 50116, (char) 3282,
        Double.longBitsToDouble(0x3fda88bd04f10b2cL), Double.longBitsToDouble(0x3fee75cd31850653L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 7, 7, 17, "\uda0a\ude37\udba5\udc0e\ud8ae\udc4e\ud8b4\ude67\uda80\ude5c\ud8ce\ude16\ud8c9\udc23", "\u2b75\u70d6\u1d6e\u0bc7\u1b6d\u62c6", "\uda98\ude0e\ud907\ude38\uda84\udd71\udae4\udd76\ud941\ude83",
        4, 80361, -1950330893, -5660941908501258734L, -32505L, false, true, (char) 54249, (char) 24035,
        Double.longBitsToDouble(0x3fa108ab71380150L), Double.longBitsToDouble(0x3fd6d35d3cb289daL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 17, 17, 13, "\uda6d\udf6a\ud982\uddcf\ud17e", "", "\ud838\udc4f\udad7\udea9\udb5e\udde7\uda6f\udc40\ue456\ud9dc\udc99\ud9e3\udff9\ud96c\uddad\ud733\udb9d\udc6f\ud90f\udd69\udab9\udf06\udb1f\uddf1\ue785",
        27, 52512, 575407100, -7744144066833044758L, -44960L, false, false, (char) 19968, (char) 7041,
        Double.longBitsToDouble(0x3f45d4d11bd13800L), Double.longBitsToDouble(0x3fee36d2580126adL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 17, 17, 13, "\uda6d\udf6a\ud982\uddcf\ud17e", "", "\ud838\udc4f\udad7\udea9\udb5e\udde7\uda6f\udc40\ue456\ud9dc\udc99\ud9e3\udff9\ud96c\uddad\ud733\udb9d\udc6f\ud90f\udd69\udab9\udf06\udb1f\uddf1\ue785",
        27, 75952, 574041369, -7744144066833044758L, -44960L, false, false, (char) 19968, (char) 7041,
        Double.longBitsToDouble(0x3f45d4d11bd13800L), Double.longBitsToDouble(0x3fb13692c00fe4f0L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 10, 18, 3, "\uda79\udcb0\udabc\udf7e\ud8a4\udc95", "\u6159\u75b6\u5a70\u32e2", "\uda4b\udf37\ud947\udc39\u4c1c",
        31, 65856, 2126972163, -1567319624410714700L, -34853L, true, false, (char) 26700, (char) 48165,
        Double.longBitsToDouble(0x3fcedc323f1e7538L), Double.longBitsToDouble(0x3fe3376bbe8da424L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 1, 1, 3, "\ud944\udef7\ud870\udd87\ud995\udfe9", "\u375e", "\uda69\uddd8\ud87e\udc22",
        -1, -883, -932622464, -6379869252770779299L, 97968L, true, true, (char) 44442, (char) 65057,
        Double.longBitsToDouble(0x3fe74c532c40359fL), Double.longBitsToDouble(0x3fd8595380f62d6eL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 1, 17, 16, "\ud8cf\udedc\ud87f\udea2\ud994\udc1c\ud8c3\udd3e", "\u9190\u69c5\u085e\ub753", "\udbff\udc2f\ud88a\udcc3\udaa3\uddbf\ud864\udc19\udb25\ude35\uda33\udc35\ud85c\udf67\udb54\udfd2\ud8dc\udc3e\ud993\udc2d\udaae\udedb\ud9e1\uddad\udad9\udc0c\ud809\udd4d\ud8bf\ude48\ud8c2\udda5\uda0a\ude8d\udacf\ude19\ud87d\udc6c\udb23\udd7b",
        29, 49296, 1052013288, 6093780509685958701L, 80522L, false, false, (char) 28822, (char) 37826,
        Double.longBitsToDouble(0x3f9dbe365e886d20L), Double.longBitsToDouble(0x3fcb0f18ed3e5f98L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 5, 5, 15, "\udbdd\udd7a\uda15\ude1b\ud93a\udc38\ud8a7\uddc2\uda84\udfe4\udbec\udebd\ud840\udff4", "\uc4d0\ub972", "\udb6c\udfae\uda47\udc38\ud8fa\udf4d\udb91\udcd1\ud827\udd01\ud8dd\udff3",
        42, 20118, -1329040855, -6172372541421284510L, 75873L, true, false, (char) 30541, (char) 14470,
        Double.longBitsToDouble(0x3fc7b85d5a2164acL), Double.longBitsToDouble(0x3fe03e33627fdd88L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\udb48\udc98\udba1\udd17\udb8d\udef5\ud8c3\udd3e\uda84\udfe4\u5900\ud8eb\ude23\ud8c6\udd6d\udaeb\udca3\ud89a\uded5\uda39\udf79\ud893\udf09\ud9a6\ude9c\000 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:\udb48\udc98\udba1\udd17\udb8d\udef5\ud8c3\udd3e\uda84\udfe4\u5900\ud8eb\ude23\ud8c6\udd6d\udaeb\udca3\ud89a\uded5\uda39\udf79\ud893\udf09\ud9a6\ude9c\000 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 14, 14, 4, "\udb48\udc98\udba1\udd17\udb8d\udef5\ud8c3\udd3e\uda84\udfe4\u5900\ud8eb\ude23\ud8c6\udd6d\udaeb\udca3\ud89a\uded5\uda39\udf79\ud893\udf09\ud9a6\ude9c\000", "", "",
        -5, 4112, -965213463, -7653742045915840123L, -16544L, false, false, (char) 35911, (char) 31620,
        Double.longBitsToDouble(0x3fbd996fb98e1318L), Double.longBitsToDouble(0x3fc4d1ea20dc7a10L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName: |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName: |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 14, 14, 17, "", "\000\u5b90\u137f\u6159\u9190", "\uda82\udf4a\uda1a\udd26\uda4b\udf37",
        13, 45523, 1932120275, -8227439972629215997L, -1750L, false, true, (char) 2008, (char) 6904,
        Double.longBitsToDouble(0x3fe001126358b8edL), Double.longBitsToDouble(0x3fcedc3220027538L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_primitiveAndWrapper|com.fasterxml.jackson.databind.JavaType,java.lang.Class|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_primitiveAndWrapper|java.lang.Class,java.lang.Class|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|refineDeserializationType|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|refineSerializationType|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_classIfExplicit|java.lang.Class|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_classIfExplicit|java.lang.Class,java.lang.Class|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_constructNoTypeResolverBuilder||new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_constructStdTypeResolverBuilder||new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_constructVirtualProperty|com.fasterxml.jackson.databind.annotation.JsonAppend$Attr,com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedClass,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_constructVirtualProperty|com.fasterxml.jackson.databind.annotation.JsonAppend$Prop,com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedClass|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_findConstructorName|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_findSortAlpha|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_findTypeResolver|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_isIgnorable|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_propertyName|java.lang.String,java.lang.String|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_refinePropertyInclusion|com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.annotation.JsonInclude$Value|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_primitiveAndWrapper|com.fasterxml.jackson.databind.JavaType,java.lang.Class|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_primitiveAndWrapper|java.lang.Class,java.lang.Class|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|refineDeserializationType|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|refineSerializationType|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
