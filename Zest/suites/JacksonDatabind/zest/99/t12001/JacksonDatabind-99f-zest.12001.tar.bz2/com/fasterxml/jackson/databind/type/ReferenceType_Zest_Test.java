package com.fasterxml.jackson.databind.type;
import org.junit.Test;
import static org.junit.Assert.*;
public class ReferenceType_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 2, 13, "\ud956\udfa2\ud9d1\uddda\ud968\udcfe\uda74\udc2d", "\u9dff\u7828\u95b1\u0ad8\u7491\u8eb2\u9069\u1ca9\u9ee6\u3253\u26ee\uade4\u67a3\ua511\ub1a2", "\ud917\uddd7\udb52\udf7e\ud966\udd8f\ud974\udf5f\ud9f0\udf4f\udac0\uddae\ud9fa\udfea\ud9fb\udf25\uda4b\udfe1\ud856\udc0b\ud905\udf6d\udbc6\udc83\ud8f1\udecf\uda67\udce3\udb4e\udce3\ud891\udea7\ud8a7\udcb1\udb31\udefc\udb8f\udd38\ud99b\udc2d\udb59\udcb9\ud8fa\udcf2\udb57\ude54\ud80b\udeb6\ud882\udc64",
        26, 51396, -2108175295, 3347924448028776719L, -4457L, true, true, (char) 2994, (char) 43400,
        Double.longBitsToDouble(0x3fe0aee96ff33c65L), Double.longBitsToDouble(0x3fe9c7d3734bbed9L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 2, 13, "\ud956\udfa2\ud9d1\uddda\ud968\udcfe\uda74\udc2d", "\u9dff\u7828\u95b1\u0ad8\u7491\u8eb2\u9069\u1ca9\u9ee6\u3253\u26ee\uade4\u67a3\ua511\ub1a2", "\ud917\uddd7\udb52\udf7e\ud966\udd8f\ud974\udf5f\ud9f0\udf4f\udac0\uddae\ud9fa\udfea\ud9fb\udf25\uda4b\udfe1\ud856\udc0b\ud905\udf6d\udbc6\udc83\ud8f1\udecf\uda67\udce3\udb4e\udce3\ud891\udea7\ud8a7\udcb1\udb31\udefc\udb8f\udd38\ud99b\udc2d\udb59\udcb9\ud8fa\udcf2\udb57\ude54\ud80b\udeb6\ud882\udc64",
        26, 51396, -2108175295, 3347924448028776719L, 62816L, true, true, (char) 2994, (char) 43400,
        Double.longBitsToDouble(0x3fe0aee96ff33c65L), Double.longBitsToDouble(0x3fe9c7d3734bbed9L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 2, 13, "\ud956\udfa2\ud8e7\udcd1\ud9a3\udff9\uda74\udc2d", "\uc028\uc149\u69a7\ub060\u549f\u8eb2\u9069\u1ca9\u9ee6\u3253\u26ee\uade4\u67a3\ua511\ub1a2", "\ud917\uddd7\udb52\udf7e\ud966\udd8f\ud974\udf5f\ud9fb\udf4f\udac0\uddae\ud9fa\udfea\ud9fb\udf25\udbe6\udd4d\ud856\udc0b\ud905\udf6d\udbc6\udc83\ud8f1\udecf\uda67\udce3\udb4e\udce3\ud891\udea7\ud838\udeba\udb31\udef6\udb8f\udd38\ud99b\udc2d\udb58\udfe2\ud8fa\udcf2\udb57\ude54\ud80b\udeb6\ud882\udc64",
        4, 60932, -1240536969, 3203808924401709638L, -40889L, true, true, (char) 60860, (char) 3718,
        Double.longBitsToDouble(0x3fd2ca2857833b8eL), Double.longBitsToDouble(0x3fe0aee96ff33c65L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 2, 13, "\ud956\udfa2\ud9d1\uddda\ud968\udcfe\uda74\udc2d", "\u9dff\u7828\u95b1\u0ad8\u22e5\u8eb2\u9069\u3e07\u9e95\u3253\u26ee\uade4\u67a3\ua511\ub1a2", "\ud917\uddd7\udb52\udf7e\ud966\udd8f",
        -4, 45024, -253877613, 484906088895046228L, 23133L, true, false, (char) 4589, (char) 39752,
        Double.longBitsToDouble(0x3fef85a4f9fda654L), Double.longBitsToDouble(0x3fe6996f0bc1bee5L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 15, 7, 13, "\ud956\udf05\ue4af\udbe1\udc6b\uda74\udc2d\udbbb\udf1f\ud977\udcbe\ud9fc\udfb3\ud8c3\uddb5\ud8f0\udffc\ud977\udfb1\ud876\udc96\udbbe\ude20\uda25\udf05\ud8bc\ude0a", "\u26ee\u8e27\u58e2", "\uda67\udd33\ud934\ude66\u2934\udb52\udf7e\ud966\udd8f\uda6d\udc16\udbe0\uddd9\udac0\uddae\ud9fa\udfea\ud9fb\udf25\uda4b\udfe1\ud856\udc0b\uda91\udcf3",
        36, 23161, -705466530, -5431405658111177744L, -3151L, false, true, (char) 49831, (char) 33726,
        Double.longBitsToDouble(0x3fe5cf648b59699cL), Double.longBitsToDouble(0x3fb059db549244f0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 5, 13, "\uda26\udc6a\ud857\udf66\ud968\udcfe\uda74\udc2d\udbbb\udf1f", "\u7828\u60a8\u0b78\u4a21", "\udadd\udde3\ud811\ude73\udb7d\udd3e",
        1, 78511, -453779534, -3389516370699550174L, 27950L, false, true, (char) 45489, (char) 50999,
        Double.longBitsToDouble(0x3fe7de861c804a87L), Double.longBitsToDouble(0x3fe49f5e8b85f0deL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 2, 13, "\ud956\udfa2\ud990\uddba", "\u3e26\u824a", "\udac2\ude04\ud80d\udfdf\ubc1a\ud918\ude00\udbdf\udc30\ud8bc\ude0a\uda50\udff3\udb7d\udd3e\udbcc\udd14\ud856\udd96\udbc7\ude19",
        18, 30050, -1615871284, -8879396207592660496L, -90872L, true, true, (char) 40983, (char) 25438,
        Double.longBitsToDouble(0x3fef9feb225406baL), Double.longBitsToDouble(0x3f8194063614ba40L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 13, 0, "\ud838\udf3a\ud889\udc6a\ud91c\udd03\ud981\udc1e\uda16\udfed\udb49\udee8\ud9fc\udfc1\ud8c3\uddb5\ud8d9\udcfc\udbf6\udeb3\udb6c\udc39\uda01\udeec\ud887\uddc9\ud8c5\udc2d\uda37\udd4f\udb7d\udd3e\udae9\ude62\ud840\udd39\ud8da\udfc2\ud936\ude0c\ud93f\ude21", "\u578d\u04a3\ubcdb\u9af6\u4c94\u90a3\uab7e\u930a\u61c4\u3b9c\u13f2\u5f7a\u5233\u7472\ud3fe\u09a9\u505e\u47bd\ub16b\ub4ac\u3630\u47e4\u23cd\uae1d\u56cf", "\ud8e3\udcd9\udbc8\ude48\udb11\udcfb\udb65\udd53\ud9c5\udc95\ud8d8\udc21\ud9ee\uddfe\udae9\udfea",
        39, 61193, -314101048, -411673995099174088L, 7543L, false, true, (char) 10657, (char) 12059,
        Double.longBitsToDouble(0x3fd500c404003e3aL), Double.longBitsToDouble(0x3fe9d62b6654d0e3L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 2, 13, "\ud956\udfa2\ud8e7\udcd1\ud9a3\udff9\uda74\udc2d", "\uc028\uc149\u2877\ub060\u7269\u9982\u7336\u1ca9\u9ee6\u3253\u26ee\u1715\u674b\ua511\ub1a2", "\ud917\uddd7\udb52\udf7e\ud966\udd8f\ud974\udf5f\ud9fb\udf4f\udac0\uddae\ud9fa\udfea\ud9fb\udf25\udbe6\udd4d\ud856\udc0b\ud905\udf6d\udb7a\udc7d\ud8f1\udecf\udadc\udf28\udb4e\udce3\ud891\udea7\ud838\udeba\udb14\uddf6\udb8f\udd38\ud99b\udc2d\udb58\udfe2\ud8fa\udcf2\udb57\ude54\udafe\udc51\ud8b0\udf64",
        4, 60932, -1240536969, 3203808924401709638L, -40889L, true, true, (char) 60860, (char) 3718,
        Double.longBitsToDouble(0x3fd2ca2857833b8eL), Double.longBitsToDouble(0x3fe0aee96ff33c65L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 2, 13, "\ud956\udfa2\ud8e7\udcd1\ud9a3\udff9\uda74\udc2d", "\uc028\u11b8\u8f8a\ub0e3\ud10b\u8eb2\u9069\u0961\u70bc\u323c\u26ee\u83d2\u6718\ua511\ub1a2\u3ca5\u72a8", "\ud966\udd8f\ud974\udf5f\udb36\udd8c\udac0\uddae\ud9fa\udfea\ud9fb\udf25",
        -4, 2229, 1378177686, -578183702039767983L, -86872L, true, false, (char) 59019, (char) 28790,
        Double.longBitsToDouble(0x3fd084e93573d922L), Double.longBitsToDouble(0x3feacb4ce1417681L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 7, 14, "\ud956\udf05\ue4af\udbe1\udc6b\udbf5\udf2a\udbac\udfc1\ud977\udcbe\ud9fc\udfb3\ud8c3\uddb5\ud8f0\udffc\ud977\udfb1\ud876\udc04\udbbe\ude20\uda25\udf05\ud8bc\ude0a\udb0b\udd86\udb7d\udd3e\udae9\ude62\ud8df\ude68\udb3d\udfe4\ud908\ude24\udb21\ude35\uda67\udd33\ud934\ude66\u2934\udb52\udf7e\ud966\udd8f\uda6d\udc16\udbe0\uddd9\udac0\uddae\ud9fa\udfea", "\u6fd4\u6c3d\u9e30\u6591\ua587\ud3fe\u3484", "\ud8d1\udf1a",
        46, 21735, 1762085817, 9090007921938303041L, 6228L, true, true, (char) 29301, (char) 13726,
        Double.longBitsToDouble(0x3fe987b57b619ecdL), Double.longBitsToDouble(0x3fd53fa2aaf54742L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 5, 13, "\uda26\udc6a\ud857\udf66\ud968\udcfe\uda74\udc2d\udbbb\udf1f", "\u7828\u60a8\u0b78\u4a21", "\udadd\udde3\ud811\ude73\udb7d\udd3e",
        1, 67415, -453779534, -3389516370699550174L, 72953L, true, false, (char) 33008, (char) 50999,
        Double.longBitsToDouble(0x3fe7de861c804a87L), Double.longBitsToDouble(0x3fe49f5e8b85f0deL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 15, "\ud83a\ude72\ud857\udf66\ud968\udcfe\uda74\udc2d\udbbb\udf1f\ud977\udcbe", "\u60a8\u0b78\u4a21\u8eb2\u05ae\ube14\uac18\ud384\u272b\uade4", "\ud93f\ude21\udb30\udc6b\udbbb\udcee",
        18, 6620, -792506150, 5370444677291000960L, 64787L, true, true, (char) 12906, (char) 30111,
        Double.longBitsToDouble(0x3fbca77001af0260L), Double.longBitsToDouble(0x3fe8844fde68bd89L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 6, "\udbc2\ude19\uda2e\udcda\ud887\udc62\uda28\udee6", "\u87d1\u7829\u9687\u640c\u4a21\u8eb2\ua2f6\u3f8f\u2a52\u43c3\u9a9d\uade4\u2dba\ubb6b\ub1a2\u38a5\u7225\u578d\u137e\u5882\u0d3d\u4c94\u5810\u9c87\ud131\u8080\u74a1\u93e5\ud26f\u4c6f\u67ab\uc37b\u68a8\uac00\ud2b9\ud04d\u223e\u44ed", "\ud8ec\udcd4\udb3a\udd0a\ud8b0\udd18\ud84a\udddd\ud9f5\ude25\udb82\udf55\udb25\udda5\udaee\udcbf\u356a\udbb4\uddb3\ud83b\ude68\udbf4\udf72\ud810\udcda",
        34, 34703, -430468787, 690356156909470101L, -56442L, false, false, (char) 17250, (char) 2531,
        Double.longBitsToDouble(0x3fe6512636cb1af2L), Double.longBitsToDouble(0x3fe19e9dfdafc393L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 13, "\ud956\udfa2\ud990\uddba", "\u3e26\u824a", "\udac2\ude04\ud80d\udfdf\ubc1a\ud918\ude00\udbdf\udc30\ud8bc\ude0a\uda50\udff3\udb7d\udd3e\udbcc\udd14\ud856\udd96\udbc7\ude19",
        18, 30050, -1615871284, -8879396207592660496L, -90872L, true, true, (char) 40983, (char) 25438,
        Double.longBitsToDouble(0x3fef9feb225406baL), Double.longBitsToDouble(0x3f8194063614ba40L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 15, "\ud956\udfa2\ud990\uddba", "\u3e26\u824a", "\udac2\ude04\ud80d\udfdf\ubc1a\ud918\ude00\udbdf\udc30\ud8bc\ude0a\uda50\udff3\udb7d\udd3e\udbcc\udd14\ud856\udd96\udbc7\ude19",
        18, 30050, -1615871284, -8879396207592660496L, -19070L, false, true, (char) 40983, (char) 25438,
        Double.longBitsToDouble(0x3fef9feb225406baL), Double.longBitsToDouble(0x3fe70e9818d852e9L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 13, "\ud956\udfa2\ud8e7\udcd1\ud9a3\udff9\uda74\udc2d", "\uc028\uc149\u2877\ub060\u7269\u9982\u7336\u1ca9\u9ee6\u3253\u26ee\u1715\u674b\ua511\ub1a2", "\ud917\uddd7\udb52\udf7e\ud966\udd8f\uda1c\udd58\ud9fb\udf4f\udac0\uddae\ud9fa\udfea\ud9fb\udf25\udbe6\udd4d\ud856\udc0b\ud905\udf6d\udb7a\udc7d\ud8f1\udecf\udadc\udf28\udb4e\udce3\ud891\udea7\ud838\udeba\ud904\uddcd\udb8f\udcfa\ud99b\udc2d\udb58\udfe2\ud8fa\udcf2\udb57\ude54\udafe\udc51\udad9\udfb9",
        5, 60793, -1240536969, 3203808924401709638L, -40889L, true, true, (char) 3602, (char) 3718,
        Double.longBitsToDouble(0x3fd2ca2857833b8eL), Double.longBitsToDouble(0x3fe0aee96ff33c65L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 14, "\ud956\udf05\ue4af\udbe1\udc6b\udbf5\udf2a\udbac\udfc1\ud977\udcbe\ud9fc\udfb3\ud8c3\uddb5\ud8f0\udffc\ud977\udfb1\ud876\udc04\udbbe\ude20\uda25\udf05\ud8bc\ude0a\udb0b\udd86\udb7d\udd3e\udae9\ude62\ud8df\ude68\udb3d\udfe4\ud908\ude24\udb21\ude35\uda67\udd33\ud934\ude66\u2934\udb52\udf7e\ud966\udd8f\uda6d\udc16\udbe0\uddd9\udac0\uddae\ud9fa\udfea", "\u6fd4\ub583\ub229\u6591\u2121\ud3f6\u3484", "\ud8d1\udf1a",
        46, 21735, 1762085817, 9090007921938303041L, 6228L, true, true, (char) 9333, (char) 23171,
        Double.longBitsToDouble(0x3fa2fb57b612e310L), Double.longBitsToDouble(0x3fd53fa2aaf54742L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 15, 13, "\uda26\udc6a\ud857\udf66\ud968\udcfe\uda74\udc2d\ud8ff\ude01", "\u7828\u60a8\u0b78\u6d17\ua01f", "\ud811\ude73\udb7d\udd3e",
        -1, 67347, -453779534, -3389516370699550174L, 72953L, true, false, (char) 33008, (char) 50999,
        Double.longBitsToDouble(0x3fe7de861c804a87L), Double.longBitsToDouble(0x3fe49f5e8b85f0deL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 14, "\udbfc\udcb8\ue4af\udbe1\udc6b\udbf5\udf2a\udbac\udfc1\ud977\udcbe\ud9fc\udfb3\ud8c3\uddb5\ud8f0\udffc\ud977\udfb1\ud876\udc04\udbbe\ude20\uda25\udf05\ud8bc\ude0a\udb0b\udd86\udb7d\udd3e\udae9\ude62\ud8df\ude68\udb3d\udfe4\ud908\ude24\udb21\ude35\uda67\udd33\udae7\ude3e\u2934\udb52\udf7e\ud966\udd8f\uda6d\udc16\udbe0\uddd9\udac0\uddae\ud9fa\udfea", "\u6fd4\ub583\ub229\ud794\u37ab\ua945\u6190", "\ud8d1\udf1a",
        46, 21735, 1762085817, 9090007921938303041L, 6228L, true, true, (char) 9333, (char) 23171,
        Double.longBitsToDouble(0x3fa2fb57b612e310L), Double.longBitsToDouble(0x3fd53fa2aaf54742L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 2, 13, "\ud956\udfa2\ud9d1\uddda\ud968\udcfe\uda74\udc2d", "\u9dff\u66a8\u95e8\u0ad8\u7491\u8eb2\u9069\u1ca9\u9ee6\u3253\u26ee\uade4\u67a3\ua511\ub1a2", "\ud917\uddd7\udb52\udf7e\ud966\udd8f\ud974\udf5f\ud9f0\udf4f\udac0\uddae\ud9fa\udfea\ud9fb\udf25\uda4b\udfe1\ud856\udc0b\ud905\udf6d\udbc6\udc83\ud8f1\udecf\uda67\udce3\udb4e\udce3\ud891\udea7\ud8a7\udcb1\udb31\udefc\udb8f\udd38\ud99b\udc2d\udb59\udcb9\ud8fa\udcf2\udb57\ude54\ud80b\udeb6\ud882\udc64",
        26, 51396, -2108175295, 3347924448028776719L, -4457L, true, true, (char) 2994, (char) 43400,
        Double.longBitsToDouble(0x3fe0aee96ff33c65L), Double.longBitsToDouble(0x3fe9c7d3734bbed9L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.type.ReferenceType|buildCanonicalName||new:com.fasterxml.jackson.databind.type.ReferenceType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|_narrow|java.lang.Class|new:com.fasterxml.jackson.databind.type.ReferenceType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|construct|java.lang.Class,com.fasterxml.jackson.databind.JavaType|static",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|construct|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;,com.fasterxml.jackson.databind.JavaType|static",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|equals|java.lang.Object|new:com.fasterxml.jackson.databind.type.ReferenceType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|getAnchorType||new:com.fasterxml.jackson.databind.type.ReferenceType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|getContentType||new:com.fasterxml.jackson.databind.type.ReferenceType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|getErasedSignature|java.lang.StringBuilder|new:com.fasterxml.jackson.databind.type.ReferenceType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|getGenericSignature|java.lang.StringBuilder|new:com.fasterxml.jackson.databind.type.ReferenceType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|getReferencedType||new:com.fasterxml.jackson.databind.type.ReferenceType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|hasContentType||new:com.fasterxml.jackson.databind.type.ReferenceType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|isAnchorType||new:com.fasterxml.jackson.databind.type.ReferenceType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|isReferenceType||new:com.fasterxml.jackson.databind.type.ReferenceType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|refine|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;|new:com.fasterxml.jackson.databind.type.ReferenceType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|toString||new:com.fasterxml.jackson.databind.type.ReferenceType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|upgradeFrom|com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JavaType|static",
    "M|com.fasterxml.jackson.databind.type.ReferenceType|buildCanonicalName||new:com.fasterxml.jackson.databind.type.ReferenceType:com.fasterxml.jackson.databind.type.TypeBase,com.fasterxml.jackson.databind.JavaType",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
