package com.fasterxml.jackson.databind.ser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class DateTimeSerializerBase_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 0, 4, 2, "\ud951\udeef\ud92e\udcb4\uda25\udcc6\udaec\udc9b\ud8a0\udebf", "\u94f6", "\ud972\udc70\udb89\ude83\uda88\udf33\udafe\uddc0",
        58, 37835, 1148016657, 4243460940631036761L, -33836L, false, true, (char) 44224, (char) 60405,
        Double.longBitsToDouble(0x3fb5cd162dbf2bd0L), Double.longBitsToDouble(0x3fef45fe431b5c75L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 0, 4, 2, "\ud951\udeef\ud934\udde0\uda3f\udd1d\ud873\udc4c\ud9de\udd1a", "\u94f6", "\ud972\udc70\udb89\ude83\uda88\udf33\ud896\ude0c",
        45, 49275, 1147995200, 4243460940631036761L, -33836L, false, true, (char) 44224, (char) 60405,
        Double.longBitsToDouble(0x3fb5cd1631a076c8L), Double.longBitsToDouble(0x3fd904393e10f2d4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 1, 7, "\ud921\uddb6\ud829\udcc7\udaa4\udd38\udaec\udd66\ud8a0\udebf", "\u94f6", "\ud969\ude59\udb89\ude83\uda88\udf33\udbcd\udf28\ud8fe\udfb2\uda27\udc7b\ud94a\ude11\ua0b8\ud870\udec1\udaf6\udd17\u94ce\ud831\udf0d\ud95b\ude3c\uda23\udf6e",
        31, 89788, 1551203304, -3446499347649020926L, 99360L, false, true, (char) 43288, (char) 62575,
        Double.longBitsToDouble(0x3fe35a26fa76f5f2L), Double.longBitsToDouble(0x3fe666ac4f663591L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 4, 2, "\ud951\udeef\ud92e\udcb4\ud993\udd5d\udaec\udc9b\ud8a0\udebf", "\u94f6", "\udadc\udf04\ud860\udca9\ud909\ude83\uda42\udeb3",
        58, 37835, 1156410129, 4243460940631036761L, -33836L, false, false, (char) 44065, (char) 60405,
        Double.longBitsToDouble(0x3fc8c347d6dc2578L), Double.longBitsToDouble(0x3fef45fe4337555fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 6, 0, 7, "\u00af\uda9e\udc90\uda25\udcc6\udaec\udc9b", "\ub650\u94f6\u6976\u73b0\u6290\u8187\u8bdf\uca23\u4559", "\ud9a6\udcb6\ud88d\udd44\ud89d\udd3f\udb29\ude67\uda50\udf4b\ud850\udd6c\udb4e\udc41\uda81\udf90\uda4b\udebf\uda80\udd57",
        52, 59669, 556331552, -1050266809476409325L, -10700L, true, true, (char) 18657, (char) 53270,
        Double.longBitsToDouble(0x3fe9482c61f53fa2L), Double.longBitsToDouble(0x3fe14466f0e2a0d6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 4, 2, "\ud951\udeef\ud92e\udcb4\uda25\udcc6\udaec\udc9b\ud8a0\udebf", "\u379a", "\ud972\udca4\udb89\ude83\uda88\udf33\udafe\uddc0\udbf3\udd31\udb9d\udc59\ud929\udc19\ud9a6\udcb6\ud884\udda0\ud943\ude36\ud97e\udd42\ud909\ude73\ud850\udd6c\udac7\udfe6\udb62\udec6\ud898\uddee\udb86\udd5a\ud925\udeba\uda92\ude6a\ud8e5\udc09\uda62\udc47\udbb9\udced",
        43, 48679, -742667664, 333690714023371330L, -93273L, false, false, (char) 24813, (char) 42002,
        Double.longBitsToDouble(0x3fdc10ef470b6faaL), Double.longBitsToDouble(0x3fe6523cc163191bL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 6, 4, 2, "\ud951\udeef\ud92e\udcb4\uda25\udcc6\udaec\udc9b\ud8a0\udebf", "\u94f6", "\ud972\udc70\udb89\ude83\uda88\udf33\udafe\uddc0",
        58, 37835, 1148016657, 4243460940631036761L, -33836L, false, true, (char) 44224, (char) 60405,
        Double.longBitsToDouble(0x3fb5cd162dbf2bd0L), Double.longBitsToDouble(0x3fef45fe431b5c75L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 3, 4, 2, "\ud951\udeef\ud92e\udcb4\uda25\udcc6\udaec\udc9b\ud8a0\udebf", "\u94f6", "\ud972\udc70\udb89\ude49\uda88\udf33\udafe\uddc0",
        58, 37835, 1148016657, 4243460940631036761L, -33836L, false, true, (char) 44224, (char) 60405,
        Double.longBitsToDouble(0x3fb5cd161dbcfb38L), Double.longBitsToDouble(0x3fef45fd531b5c75L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 9, 4, 2, "\ud951\udeef\ud92e\udcb4\uda25\udcc6\udaec\udc9b\ud8a0\udebf", "\u94f6", "\ud972\udc70",
        35, 69204, 1912484617, 6151785331501479683L, 61633L, false, false, (char) 14045, (char) 44224,
        Double.longBitsToDouble(0x3fca2fe4915cd160L), Double.longBitsToDouble(0x3fdb7e57a7d17f90L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 7, 6, 2, "\ud951\udeef\ud92e\udcb4\uda25\udcc6\udaec\udc9b\ud8a0\udebf", "\u94f6", "\ud972\udc70\udb89\ude83\uda88\udf33\udafe\uddc0",
        58, 15627, 1148016739, 4243460940631036761L, -33836L, false, false, (char) 44224, (char) 60405,
        Double.longBitsToDouble(0x3fb5cd162dbf2bd0L), Double.longBitsToDouble(0x3fef45fe431b5c75L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 1, 0, 2, "\ud951\udeef\udb71\udc67\ud855\udc27\ud961\ude22\ud889\udef5", "\u61cb", "\ud972\udc70\udbda\uddcc\udaa7\ude7c\udafe\uddc0\ud974\udffe\ud938\uddc3\udbe7\udc48\ud9d7\ude30\ud88d\udd7c\u7f02\udb03\udf62\uda51\udc0e\udbe2\udc76\uda7a\udd6e\udb62\udec6",
        53, 44304, 851809051, -1764497622637690822L, -90306L, false, false, (char) 44924, (char) 5753,
        Double.longBitsToDouble(0x3fd8ad37d4ddf65eL), Double.longBitsToDouble(0x3fdf92f9ff9e5920L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 1, 6, 6, "\ud951\udeef\ud92e\udcb4\uda25\udcc6\udaec\udc9b\ud8a0\udebf", "\u94f6", "\ud8d6\ude62\udb47\uddba\udaea\uded8\udafe\ude8a\udbf3\udd31\ud9c9\udf46\ud81e\udd9a",
        22, 22129, 1670543201, 4832646573806753024L, -72143L, true, false, (char) 35633, (char) 15281,
        Double.longBitsToDouble(0x3fe8dae3a844102bL), Double.longBitsToDouble(0x3fc7ddc3712c3f24L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 6, 7, 3, "\udbf8\ude03\ud968\udd00\ud9f9\udcb9\ud84f\udda5\ud872\udcca", "\ua7f8\uc8a4\ucb04\u72bf", "\udaa0\uddb1\ud95d\udcd0\u330c\udaee\ude89\ud9a6\udcbc\ud88d\udd44\udb18\ude3d\ud92b\udf5e",
        59, 34643, 2060011804, 8762328079895939489L, 76953L, true, true, (char) 42706, (char) 34803,
        Double.longBitsToDouble(0x3fb851418068b878L), Double.longBitsToDouble(0x3fef99dd263b2e49L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 4, 2, "\ud951\udeef\ud92e\udcb4\uda25\udcc6\udaec\udc9b\ud8a0\udebf", "\u94f6", "\ud972\udc70\udb89\ude83\uda88\udf33\udafe\uddc0",
        58, 37835, 1148016657, 4243460940631036761L, -33836L, false, true, (char) 44224, (char) 60405,
        Double.longBitsToDouble(0x3fb5cd162dbf2bd0L), Double.longBitsToDouble(0x3fef45fe431b5c75L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 1, 4, 6, "\ud951\udeef\ud92e\udcb4", "\u879b\u57f6\u8b4b\u5b77\u8437\u73b0\u6290\u9fbb", "\ud9c8\udebb\udb9d\udcf8\ud83f\udd25\ud8c6\udd53\ud865\udc5b\udabe\udf41\udb2b\udd60\uda50\udf4b\uda2f\udfbc\udac7\udfe6\udb62\udec6",
        53, 85384, -134573285, -322489354527645432L, -64022L, false, false, (char) 53034, (char) 15257,
        Double.longBitsToDouble(0x3fb012f355222878L), Double.longBitsToDouble(0x3fbc29855195ec28L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=void |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 9, 1, 7, "\udbd0\ude0e\ud80d\udf03\udaa4\udd38\udaec\udd66\ud8a0\udebf\uda64\udf88\udadb\udc30\udb63\udf71\u3c37\udaa9\ude5e\ud96f\udf4b\udb89\ude83\uda88\udf33\udbcd\udf28\ud8fe\udfb2\uda27\udc7b\ud94a\ude11", "\ua22f\u1e96\ud6f8\uc966\u4b1f\ub3f2\u40b4\u9d8d\ub26a\u5eb0\u4a3a\u08e9\u2140\u63be", "\ua274\ud91e\uddd3\ud96b\udff5",
        52, 71582, -868965080, 7247474514953602577L, 34665L, true, false, (char) 52323, (char) 39444,
        Double.longBitsToDouble(0x3fe7b7eea0eb6e3bL), Double.longBitsToDouble(0x3feed2a9e7e7c3d1L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 9, 6, 1, "\ud921\uddb6\ud829\udcc7\udaa4\udd38\udaec\udd66\ud86a\udec4", "\u94f6", "\ud969\ude59\udb89\ude83\uda88\udf33\udbcd\udf28\ud8fe\udfb2\uda27\udc7b\ud94a\ude11\ua0b8\udb74\udc83\udb14\udc58\u94ce\ud831\udf0d\ud95b\ude3c\uda23\udf6e",
        31, 89788, 1551203304, -3446499347649020926L, 54854L, false, false, (char) 23147, (char) 42605,
        Double.longBitsToDouble(0x3faeda6de65ce0a0L), Double.longBitsToDouble(0x3fe35a26fa76f5f2L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 3, 8, 7, "\ud921\uddb6\ud829\udcc7\udaa4\udd38\udaec\udd66\ud8a0\udebf", "\u94f6", "\ud92e\udc64\udb89\ude83\uda88\udf33\udbcd\udf28\ud8fe\udfb2\uda27\udcd0\ud93c\udf11\ua0b8\ud870\udec1\udaf6\udd17\u94ce\ud831\udf0d\ud95b\ude3c\uda23\udf6e",
        31, 89788, 1551203304, -3446499347649020926L, -29626L, true, true, (char) 45072, (char) 17406,
        Double.longBitsToDouble(0x3faef415665ce0a0L), Double.longBitsToDouble(0x3fe35a26fa76f5f2L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 6, 8, 2, "\ud951\udeef\ud92e\udcb4\ud993\udd5d\udaec\udc9b\ud8a0\udebf", "\u94f6", "\ud8a4\udf32\ud860\udca9\ud909\ude83\uda42\udeb3",
        58, 37835, 539724203, 4243460940631036761L, -33836L, false, false, (char) 44065, (char) 5677,
        Double.longBitsToDouble(0x3fc6cb00a288e830L), Double.longBitsToDouble(0x3fef41dd9b37555fL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 6, 6, 3, "\ud951\udeef\ud92e\udcb4\ud993\udd5d\udaec\udc9b\ud8a0\udebf", "\u94f6", "\udadc\udf04\ud860\udca9\ud909\ude83\ud8e7\ude88",
        17, 58571, 1156410129, 4243460940631036761L, -33836L, false, false, (char) 44065, (char) 60405,
        Double.longBitsToDouble(0x3fc8c347d6dc2578L), Double.longBitsToDouble(0x3fef45fe4337555fL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 6, 6, 8, "\ud951\udeef\ud92e\udcb4\udb96\uddad\ud809\udec3\ud9cd\udfeb", "\u95b4\u30a9\u23b0", "\udae6\udd7e\uda42\udeb3\udbf3\udd23\udb5a\udd32\udb7e\udc00\ud9c9\ude28\ud83c\udd90\udb87\udc7c",
        11, 93022, 2133082606, 8867806267997550273L, -36396L, false, false, (char) 14302, (char) 19858,
        Double.longBitsToDouble(0x3fefa1cd54e3a34dL), Double.longBitsToDouble(0x3fe207c023efd13eL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 5, 1, "\ud951\udeef\ud92e\udcb4\ud993\udd5d\udaec\udc9b\ud8a0\udebf", "\u94f6", "\udbbf\udc64",
        15, 46628, -774451860, 6151785331501479683L, -41254L, false, true, (char) 60405, (char) 49923,
        Double.longBitsToDouble(0x3fdb7095e7d17f90L), Double.longBitsToDouble(0x3fe9baaaf84fa231L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=void |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 6, 1, 6, "\udbc4\udfa8\ud92e\udd3e\ud993\udd5d\udaec\udc9b\ud8a0\udebf", "\u94f6", "\udadc\udf04\ud860\udca9\ud909\ude83\uda42\udeb3",
        58, 37835, 1156410129, 4243460940631036761L, -33836L, false, false, (char) 44065, (char) 60405,
        Double.longBitsToDouble(0x3fc8c347d6dc2578L), Double.longBitsToDouble(0x3fef45fe4337555fL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 6, 0, 1, "\ud951\udeef\ud92e\udcb4\ud993\udd5d\ud9e4\ude53\ud992\udd8a\uda14\udf88\udadb\udc44\udb63\udf71\uda6e\uddd3\ud9ec\udeeb\udadc\udf04\ud860\udca9\udb16\udd9e\uda42\udf03\udb88\ude7c\udbd8\udd9b\ud8e9\udd52\ud976\udc65\udb2a\udcb2\ud86b\udd24\u3e24", "\uc8ec\uc3e0\ud19a", "\uda0c\udf61\ud904\udd0a\uda20\udc07\ud83f\udf52",
        0, 43354, 1817028388, 3224051188163216524L, -80226L, true, false, (char) 58606, (char) 48280,
        Double.longBitsToDouble(0x3fe386303aa55f5bL), Double.longBitsToDouble(0x3fdcb8e3540dd76eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 9, 9, 3, "\ud951\udeef\ud92e\udcb4\uda25\udcc6\udaec\udc9b\ud8b2\udc49", "\u94f6", "\ud888\uddde\ud892\udf22\ud82f\udfe7\u16bd",
        18, 7522, 846074340, 4243460893378414169L, -33836L, false, true, (char) 33282, (char) 30774,
        Double.longBitsToDouble(0x3fb5ea366dbf2bd0L), Double.longBitsToDouble(0x3fef45fe431b5c75L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=java.lang.Long:0 |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 3, 3, 7, "\ud921\uddb6\ud829\udcc7\udaa4\udd38\udaec\udd66\ud8a0\udebf", "\u94f6", "\ud92e\udc64\udb89\ude83\uda88\udf33\udbcd\udf28\udb7a\udca6\uda1c\udc49\ud93c\udf11\ua0b8\ud870\udec1\udaf6\udd17\u94ce\udb58\udd42\ud900\udda5\uda23\udfbd",
        31, 89788, 1551203304, -3446499347649020926L, -29626L, true, true, (char) 45072, (char) 17406,
        Double.longBitsToDouble(0x3faef4156eed5fd0L), Double.longBitsToDouble(0x3fe35a26fa76f5f2L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 0, 4, 2, "\ud951\udeef\ud92e\udcb4\uda25\udcc6\udaec\udc9b\ud8a0\udebf", "\u94f6", "\udb9c\udea5\udb89\ude1f\uda88\udf33\udafe\uddc0",
        58, 37835, 1148016657, 4243460940631036761L, -33836L, false, true, (char) 44224, (char) 60405,
        Double.longBitsToDouble(0x3fb5cd162dbf2bd0L), Double.longBitsToDouble(0x3fef45fe431b5c75L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|createContextual|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|_acceptJsonFormatVisitor|com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper,com.fasterxml.jackson.databind.JavaType,boolean|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|_asTimestamp|com.fasterxml.jackson.databind.SerializerProvider|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|_timestamp|java.lang.Object|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|acceptJsonFormatVisitor|com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper,com.fasterxml.jackson.databind.JavaType|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|getSchema|com.fasterxml.jackson.databind.SerializerProvider,java.lang.reflect.Type|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|isEmpty|com.fasterxml.jackson.databind.SerializerProvider,java.lang.Object|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|isEmpty|java.lang.Object|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|serialize|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|withFormat|java.lang.Boolean,java.text.DateFormat|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|createContextual|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
