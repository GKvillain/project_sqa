package com.fasterxml.jackson.databind.ser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberSerializer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.NumberSerializer$BigDecimalAsStringSerializer:@?\012",
        Z.run(T, 1, 0, 0, 1, "\ud887\udc65", "\ua8b3\ub1ce\u4da0\u22ec\u29dd\u35d4\uc7b4\u4103\u2668\u12a7\u5e20", "\udb81\udece\ud8e7\ude70",
        7, 6257, 1805830840, 2246986487296228620L, 30137L, false, true, (char) 49890, (char) 6887,
        Double.longBitsToDouble(0x3fecce7dd314ac5aL), Double.longBitsToDouble(0x3faf3f989aaae020L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.NumberSerializer$BigDecimalAsStringSerializer:@?\012",
        Z.run(T, 1, 0, 0, 1, "\ud874\udff2\ud89c\uddbe\udbe6\ude5a\udaf4\udf0f\uda3c\udfc4\ud91f\udcc7\uda92\ude2e\ud9c4\ude0d\ud42a", "\u2668\u12a7\u5e20\u7a2c", "\ud8e7\ude70\ud995\udeb9\uda29\udd27\udb64\udd0f\ud9a8\udc24\uda15\uded6\uda77\udcbd\udb22\udc17\udb4e\ude4f\ud9e1\uded6",
        18, 41833, 2133928724, -5908093524919289461L, -80978L, false, true, (char) 62087, (char) 39865,
        Double.longBitsToDouble(0x3fe0f97ff8feaa89L), Double.longBitsToDouble(0x3fb334f2c0a1de70L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:{\"type\":\"number\"} |this=com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\012",
        Z.run(T, 1, 4, 5, 1, "\ud887\udc65", "\ubc41\ub1ce\u4da0\u884c\ua997\u356c\uc7b4\u4103\u2b66\u12a7\u5e20", "\ud91d\udd3b\ud8e7\ude70",
        12, 6367, 1805830840, 2246986487296228620L, 30137L, false, true, (char) 49890, (char) 9719,
        Double.longBitsToDouble(0x3fee13e94b14ac5aL), Double.longBitsToDouble(0x3faf3f989aaae020L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.NumberSerializer$BigDecimalAsStringSerializer:@?\012",
        Z.run(T, 1, 0, 0, 1, "\uda63\udd34", "\ua8b3\ub1ce\u4da0\u22ec\u29dd\u35d4\uc7b4\u4103\u2668\u12a7\u5e20", "\udb81\udec1\ud8e7\ude70\ud995\udeb9\uda29\udd27\udb64\udd0f",
        50, 85860, -987914186, -4352162074430645388L, -8014L, true, true, (char) 55150, (char) 47983,
        Double.longBitsToDouble(0x3fdaaae02d4b2a5aL), Double.longBitsToDouble(0x3fe2d8b66fc71675L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.NumberSerializers:@?\012",
        Z.run(T, 1, 7, 3, 1, "\ud865\udf71", "\ua8b3\ub1ce\u4da0\u22ec\u29dd\u35d4\u72ab\u9ca1\u2668\u12a7\u761f", "\udb81\udece\ud8e7\ude70\ud995\udeb9",
        42, 50840, -1105160114, 2190153545802424374L, 7660L, false, true, (char) 14330, (char) 23379,
        Double.longBitsToDouble(0x3fe8a4fdcfe57f31L), Double.longBitsToDouble(0x3fdaaae02852ad94L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 6, 0, 1, "\ud90d\udfcc", "\ua8b3\ub1ce\u4da0\u22ec\u29dd\ud74f\uc21b\u2aa7\u075e\u6df6\u5dda", "\udb81\udece\ud8e7\ude70\udb8c\udd14\uda29\udd27\udb64\udd0f\udb36\udceb\ud8cf\udf08\uda62\udcbd\ud9ee\ude1c\ud980\ude7f\ud9e1\uded6\udaff\udc2e\ud807\udeab\ud909\ude9f\u8f69\udb45\udfdd\udb6a\ude63\ud95b\udc85\ud8e5\ude55",
        37, 53721, -32048728, -693528569922050619L, -99125L, true, false, (char) 31892, (char) 50223,
        Double.longBitsToDouble(0x3fe897738553998cL), Double.longBitsToDouble(0x3fe4976d8fe59ad2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 6, 1, 1, "\ud887\udc65", "\ua8b3\ub1ce\u4da0\u22ec\u29dd\u35d4\uc7b4\uba32\u0d70\u7f2d\u5e20", "\udb81\udece\ud8e7\ude70",
        7, 6257, 1805830840, 2246986487296228620L, -41799L, false, false, (char) 18658, (char) 6887,
        Double.longBitsToDouble(0x3fecce794314ac5aL), Double.longBitsToDouble(0x3fc0cfe626aab808L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:{\"type\":\"number\"} |this=com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\012",
        Z.run(T, 1, 4, 6, 9, "\ud887\udc65", "\ua8b3\ub1ce\u4da0\u22ec\u29dd\u35d4\u32b4\u4103\u2668\u12a7\u5e20", "\udb81\udece\ud8e7\ude70",
        -5, 53288, 1805830773, 2246986487296228620L, 36620L, false, false, (char) 51883, (char) 6887,
        Double.longBitsToDouble(0x3fecce7dd314ac5aL), Double.longBitsToDouble(0x3f71fcc4d546b480L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 6, 1, "\ud883\udcf4\uda89\udef4\udbe6\udec8\udaf4\udf0f\ud984\udfc8", "\ubc8f\u35d4\u2796\u5c4a\u662f\u974e\u5f8f\u7a2c\u5949\u59d5\u3bdc\u9b11\ua599\u236a\u5343\uc240\u26ba\u3b01\u5859\u712e\u5b1f\u9d80\u99db\u869f\u0881\u21c5\u2b8b\u3a03\ub37f\u900a\u3020\ua78d\ubf38\u192f", "\uda1a\uddeb\udbf1\udcdc\ud858\udf67\ud85c\ude91\ud938\ude6b\ud8a3\udd66\ud992\ude34\ud8d4\udcad",
        -3, 22451, -2005698383, -2587097364491882443L, 94883L, false, true, (char) 21380, (char) 65225,
        Double.longBitsToDouble(0x3fe87a0c766f912aL), Double.longBitsToDouble(0x3fd3b0dbc0cb2e04L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 0, 0, "\ud887\udc65", "\u73d7\ub1ce\u82a9\000\u29cd\u09f0\000\000\000\000\uab42", "\udb81\udece\uf47b",
        50, -1000, 0, 13200737113013516L, 30137L, false, true, (char) 49890, (char) 6887,
        Double.longBitsToDouble(0x3fecce7dd000ac5aL), Double.longBitsToDouble(0x3faf0000100ae020L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:{\"type\":\"number\"} |this=com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\0121=new com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\012",
        Z.run(T, 2, 4, 5, 1, "\ud887\udc65", "\ubc41\u91ce\u4e3d\u884c\ua997\u356c\uc7b4\u5153\u2b66\u12a7\u5e20", "\udafb\udc73\ud8d0\udd0a",
        12, 6367, 1809500856, 2246986487293210380L, 30137L, false, true, (char) 49890, (char) 9719,
        Double.longBitsToDouble(0x3fee13e94b14ac5aL), Double.longBitsToDouble(0x3faf3f989fe44a40L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 5, 2, "\ud932\udd9c", "\u957b\ub1ce\u4da0\ua424\u9867\u1ce8\uc7b4", "\udaf6\udffc\ud8ec\udf93\udb1a\udf94\udb28\udde5\ud80b\udd10",
        10, 21, -1496206827, 7755984399818221134L, 6550L, true, false, (char) 58610, (char) 37011,
        Double.longBitsToDouble(0x3fe52b6425ff0629L), Double.longBitsToDouble(0x3fdf05aa387cfe0eL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:{\"type\":\"number\"} |this=com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\012",
        Z.run(T, 1, 4, 9, 4, "\ud927\udf68\udae9\ude24", "\u54bc\u4da0\u884c\ua997\u356c\ubc72\u647b\u08d8", "\ud8e5\udf14\udb6d\udf15\ud8d9\ude5a\ud916\udd50\ud981\udc4d\uda29\udd95\udb64\udd0f",
        50, 85860, -987914186, 1275019690938516428L, 68515L, false, true, (char) 11442, (char) 58748,
        Double.longBitsToDouble(0x3fdaaae02fa0380cL), Double.longBitsToDouble(0x3fd18369b03757c2L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 1, 9, "\ud9a0\udc47\ud893\udead\udbe6\ude5a\uda0d\udc9f\uda40\udd31\ud91f\udcc7\ud9f0\ude3a\udab3\udc6d\ud3c2\ud827\udfbe\udb1f\ude7a\udaf2\udf71", "\u71df\u5949\u5b05\u3bdc", "\ud8c8\uded9\ud88b\udcea",
        23, 66814, -1013316810, 184754659479800046L, -4603L, true, false, (char) 47983, (char) 10157,
        Double.longBitsToDouble(0x3fcc839ae702d9d4L), Double.longBitsToDouble(0x3fde859ee668e5d0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 1, 5, "\ud887\udc65", "\ubc41\ub1ce\u4da0\u884c\u2526\ubb3a\ucfda\u4138\u2b66\u12a7\u5e20", "\ud91d\udd3b\ud8e7\ude70",
        12, 6367, -1579276428, -5461199419143291636L, 30137L, false, true, (char) 49890, (char) 9719,
        Double.longBitsToDouble(0x3fee13e94b14ac5aL), Double.longBitsToDouble(0x3faf3f989aaae020L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\0121=new com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\012",
        Z.run(T, 2, 5, 5, 1, "\ud887\udcb9\ud89c\uddbe\udbe6\ude5a\udb3a\ude16\uda3c\udfc4\ud91f\udcc7\ud9f0\ude3a\udaf2\ude6e\ud3c2\udaa6\udedd\udb1f\uddd0\udaf2\udf71\uda2a\ude57\ud8ea\udc03\ud8dc\uded9\udb88\udcfd", "\u65e1\u5ac4\u9f05\u5343\u1112\ua26b\u4c11\uab80\ube72\uce04\uc3b5\u1fd7\uab10\u7635\u1735\u56da\u4ef0", "\ud95d\udda2\ud89f\udca4\ud9ab\udd91\ud945\udeda\uda47\uddfa\ud9aa\udca4\ud8b6\ude74\udbee\udf5a\ud92b\udce2\udb41\udd4b\udbef\ude6c\udaaf\udc52\ud811\ude8b",
        50, 7222, 1971704080, 1912398396411653957L, -71016L, false, false, (char) 48463, (char) 408,
        Double.longBitsToDouble(0x3fc4a25a443594ccL), Double.longBitsToDouble(0x3fdaec07d3ea6b16L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.NumberSerializer$BigDecimalAsStringSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 4, "\uec08\ud89c\uddbe\udbe6\ude5a\uf2a3", "\u884c\ua997\u356c", "\udaf2\udf71\ud91a\udccf\uda81\udfab\uda7a\udead",
        57, 92125, 971719291, 7085339419343896617L, 90054L, true, true, (char) 32831, (char) 51396,
        Double.longBitsToDouble(0x3fd74c39a07f0ff6L), Double.longBitsToDouble(0x3fdead24ddc99cd8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.NumberSerializer$BigDecimalAsStringSerializer:@?\0121=new com.fasterxml.jackson.databind.ser.std.NumberSerializers:@?\012",
        Z.run(T, 2, 0, 7, 5, "\ud887\udc65", "\ubc41\ub1ce\u4da0\u884c\ua997\u356c\uc7b4\u4103\u2b66\u12a7\u5e20", "\ud91d\udd3b\ud8e7\ude70",
        12, 6367, 1805830840, 2246986487296228620L, 30137L, false, true, (char) 49890, (char) 9719,
        Double.longBitsToDouble(0x3fee13e94b14ac5aL), Double.longBitsToDouble(0x3faf3f989aaae020L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:{\"type\":\"number\"} |this=com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 4, "\ud887\udc65\ud89c\uddbe\udbe6\ude5a\udbda\udfde\udabb\ude34\uda96\udd16\ud9c5\udd26\udaf2\ude6e\ud8ac\udd7f\uda9d\udf57", "\u00c5\u1e21\u03c7", "\ud8e7\ude16\ud995\udf40\udb8e\udc87\uda3c\udf87\udab4\udd0c\uda15\uded6\uda77\udcbd\udb22\udc17\udb18\ude54\udb91\udc8d\ud8d4\ude1d",
        45, 91752, -1375563819, 196040356834112786L, 19639L, true, false, (char) 21898, (char) 63445,
        Double.longBitsToDouble(0x3fbfcce8be39aed0L), Double.longBitsToDouble(0x3fddb7b652002378L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 3, 5, "\uda1c\udda9\u2b13\ud949\ude21\ud8be\uded4\udb18\udf0e\u27f6\ud9f0\ude3a\uda50\udc7d\udbfa\udcc5\udaa6\udf6b\udb1f\uddf1\ud9ed\udda5\udad6\udef9\udbb5\udf7b\ud94d\udee6", "\uadeb\u8880\u96c2\uc925\u53a9\u80c8\ua26b\u4c11\u2480", "\ud9b0\udf1d\udb8a\ude92\ud8b0\ude7a\udb1b\udc82",
        56, 27907, -857741938, 89387870462261409L, -26437L, false, false, (char) 13325, (char) 56824,
        Double.longBitsToDouble(0x3fec6e4581a4e098L), Double.longBitsToDouble(0x3fe7fb8d1af88f1aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.NumberSerializer$BigDecimalAsStringSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 7, "\ud809\udd50", "\u6433\u43b4\u4da7\u884c\ua997\u4734\u450e\ub5f9\u2b66\u6498\uabfd", "\udb9a\udcfd\u3005\ud995\udf40",
        44, 50840, 523167310, 2190153548160923947L, 23549L, true, true, (char) 51655, (char) 2224,
        Double.longBitsToDouble(0x3f94ac5ab9b41900L), Double.longBitsToDouble(0x3fc555c05c6bbc54L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:{\"type\":\"number\"} |this=com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\0121=void\012",
        Z.run(T, 2, 4, 6, 1, "\ud887\udc65", "\ubc50\u8b5c\u4da0\u884c\ua997\u356c\uc7b4\u9e58\ucc84\u35d0\u5e20", "\ud91d\udd3b\ud8e7\ude70",
        50, 13855, 1805830840, 2246986485443589071L, 30137L, false, true, (char) 49890, (char) 35574,
        Double.longBitsToDouble(0x3fe613e94b14ac5aL), Double.longBitsToDouble(0x3faf3f989aaae020L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.NumberSerializer$BigDecimalAsStringSerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.NumberSerializer$BigDecimalAsStringSerializer:@?\012",
        Z.run(T, 2, 0, 0, 1, "\udb7c\ude09", "\ua563\ud500\u708a\u3190\u0d46\u72f4\uc7b4\u094f\u3fc2\u66f5\u5e20\uaf35\u50f6\u59c8\u3bdc\u9b11\u50b6", "\u3d47\ud9f6\uddaa\uda40\udf4d\udb4e\ude4f\ud9e1\uded6\udaf5\uddd5\uda9a\udd13\udb64\udead\uda79\udd2d\ud986\udf5e\ubffd\udb60\udfad\ud8a8\udebd\ud9d8\udf67\udb6f\udcb2\ud962\udf08\udbfd\udf7c\udbf0\udcf3\ud91f\ude3f\ud8fb\ude0d\ud92d\ude54\udba2\udf58\ua298",
        49, 73267, -57653970, 4633455558582375088L, 86996L, false, false, (char) 23505, (char) 24173,
        Double.longBitsToDouble(0x3fdc3ae04c15b0e6L), Double.longBitsToDouble(0x3fc3ffc0c9e062b4L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 6, 6, 9, "\udab3\udeab\udab9\ude25\udbb3\udf3f\udb0b\ude7a\udb59\udd83\ud885\ude08\ud8de\udee5\ud9e8\udd31\ud42a\uda81\udddd\udae1\udfd1\udb20\udc8f\udb8b\udf28\ud9d9\udf57\uda80\udea1\udb6f\udf5a\udb8b\udd73\u0aab", "\u09ba\u3d44\u17ae\u9493", "\ud9e1\uded6\udaf5\uddd5",
        38, 44924, -53190598, -7201908680124464111L, -82563L, false, false, (char) 8826, (char) 56972,
        Double.longBitsToDouble(0x3fe789f81a3dac13L), Double.longBitsToDouble(0x3fef84166565d357L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:{\"type\":\"number\"} |this=com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 6, "\ud8f4\udf9d\ud881\ude6e\udbd5\udca9", "\u0654\ud3ca\u29dd\ua291\u32b4\u319b\u3290\uc954\u5e20\u7a2c", "\udba8\ude6f\ud96b\ude04\ud97d\udd3a\udb64\udccc\ud9a8\udc24\uda15\uded6\uda47\udd74\uf4c6\u33eb\ud9e1\uded6",
        45, 24801, 2133928724, -1860755482485753354L, -52880L, false, false, (char) 64393, (char) 43150,
        Double.longBitsToDouble(0x3fd252320c2ea8dcL), Double.longBitsToDouble(0x3fe4c52b4b1068edL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:{\"type\":\"number\"} |this=com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\0121=com.fasterxml.jackson.databind.node.ObjectNode:{\"type\":\"number\"} |this=com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\012",
        Z.run(T, 2, 4, 4, 4, "\ud87f\udccf", "\u311d\ub1e8\u6f82\u884c\ua997\u356c\uc7b4\u0755\u551d\u12a7\u5e20\u383e", "\ud8d0\udd0a\udac3\udcb6\ud93c\ude19\ud86c\udc9d\ud8a0\udcc0\uda21\udfaa\uda77\udcbd\udb22\udc17\udb4e\ude4f",
        -2, 72903, -901206964, 9165154082726624318L, 90434L, true, false, (char) 64489, (char) 17412,
        Double.longBitsToDouble(0x3fef197811f8b351L), Double.longBitsToDouble(0x3fd05b8503777976L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.NumberSerializers:@?\0121=new com.fasterxml.jackson.databind.ser.std.NumberSerializers:@?\012",
        Z.run(T, 2, 7, 7, 1, "\ud887\udc65\ud89c\uddbe\udbe6\ude5a\ud823\udf0a\ud8ce\ude2d\ud91f\udd64\ud9f0\ude3a\udaf2\ude6e\ud3c2", "\u8610\u12a7\u014d\u6461", "\ud8d0\udd0a\ud995\udf40\uda29\udd95\ud86c\udd13",
        50, 97620, -987914186, -4352162074430645441L, 79523L, false, true, (char) 55150, (char) 47983,
        Double.longBitsToDouble(0x3fdfe44a4c5bd572L), Double.longBitsToDouble(0x3fd169a706860d4eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 6, 6, 1, "\ud877\udca7", "\ubc50\u8b5c\u4da0", "\ud3c2\udaa6\udedd\ud93f\udee0\ud938\udeb4\udb94\ude51\ud9d9\udf57\uda7a\udf3f",
        32, 73771, 557444219, 5813477106955751807L, -27886L, true, true, (char) 20525, (char) 51396,
        Double.longBitsToDouble(0x3feba61cd640eca2L), Double.longBitsToDouble(0x3fdbde339d84fb2cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.NumberSerializer$BigDecimalAsStringSerializer:@?\012",
        Z.run(T, 1, 0, 8, 0, "\000", "", "\000\000\ud9bb\udffd",
        4, -1000, 0, 1780329225601877635L, -4303L, true, true, (char) 52819, (char) 53953,
        Double.longBitsToDouble(0x3eaca69000000000L), Double.longBitsToDouble(0x3fe5c536884e6ba2L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 0, 4, "\ud885\udcd7\ud89c\uddbe\udb58\udd12\ud86b\udcb8\ud9f2\udd1e\ud9b4\udd80,\ud9c4\uddfd\ud807\udfb4\ud938\udeff\ud954\udf4b\udb00\ude5f\uda10\udea9", "\u5949\u99d5\u7ffc", "\u15e7\udb95\udc6e\uda11\udf81\udb78\uddd5\ud91b\ude1d\udb21\udd58\ud8ad\udedc",
        18, 41833, 0, -5908093525637957376L, 38038L, true, true, (char) 61672, (char) 60821,
        Double.longBitsToDouble(0x3fe616a7b6f9fc1dL), Double.longBitsToDouble(0x3fe509a0992ac826L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 6, 0, 4, "\ud885\udcd7\ud89c\uddbe\udb58\udd01\000\000\000,\ud9c4\uddfd\ud807\udfb4\ud938\udeff\ud954\udf4b\udb00\ude5f\uda10\udea9", "\u5949\u99d5\000", "\000",
        45, 81935, 975140457, -4793859662793254028L, -8014L, true, true, (char) 44122, (char) 15422,
        Double.longBitsToDouble(0x3fd00ae024055120L), Double.longBitsToDouble(0x3fc95831c316f7c4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ser.std.NumberSerializer|bigDecimalAsStringSerializer||static",
    "M|com.fasterxml.jackson.databind.ser.std.NumberSerializer|createContextual|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty|new:com.fasterxml.jackson.databind.ser.std.NumberSerializer:java.lang.Class",
    "M|com.fasterxml.jackson.databind.ser.std.NumberSerializer|serialize|java.lang.Number,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.std.NumberSerializer:java.lang.Class",
    "M|com.fasterxml.jackson.databind.ser.std.NumberSerializer|acceptJsonFormatVisitor|com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ser.std.NumberSerializer:java.lang.Class",
    "M|com.fasterxml.jackson.databind.ser.std.NumberSerializer|getSchema|com.fasterxml.jackson.databind.SerializerProvider,java.lang.reflect.Type|new:com.fasterxml.jackson.databind.ser.std.NumberSerializer:java.lang.Class",
    "C|com.fasterxml.jackson.databind.ser.std.NumberSerializer|<init>|java.lang.Class",
    "M|com.fasterxml.jackson.databind.ser.std.NumberSerializers|addAll|java.util.Map|static",
    "C|com.fasterxml.jackson.databind.ser.std.NumberSerializers|<init>|",
    "M|com.fasterxml.jackson.databind.ser.std.NumberSerializer|bigDecimalAsStringSerializer||static",
    "M|com.fasterxml.jackson.databind.ser.std.NumberSerializer|createContextual|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty|new:com.fasterxml.jackson.databind.ser.std.NumberSerializer:java.lang.Class",
    "M|com.fasterxml.jackson.databind.ser.std.NumberSerializer|serialize|java.lang.Number,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.std.NumberSerializer:java.lang.Class",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
