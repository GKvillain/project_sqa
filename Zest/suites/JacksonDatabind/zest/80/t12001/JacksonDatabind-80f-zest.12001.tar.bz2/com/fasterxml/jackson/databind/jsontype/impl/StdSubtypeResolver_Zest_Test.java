package com.fasterxml.jackson.databind.jsontype.impl;
import org.junit.Test;
import static org.junit.Assert.*;
public class StdSubtypeResolver_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |a0=[Lcom.fasterxml.jackson.databind.jsontype.NamedType;:[[null, null]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 2, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\ud877\udc9b\udb6f\udca7", "\u2346\u3b0a\u390d\ua13b\u6143\u441e\uc894\ud41d\ub576\u4ed8\ub14a\ucbec", "\u5384\ud88d\udd60\udafe\udd29\ud8da\udd1d\udab6\udcf0\ud890\udcc3\ud85a\udc19\ud899\udfba\uda03\udd19",
        34, 7452, -2111142948, 4059728312494721269L, 66154L, true, false, (char) 23673, (char) 53996,
        Double.longBitsToDouble(0x3fc3f31e31a6a6a4L), Double.longBitsToDouble(0x3fe3166cf490f813L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |a0=[Lcom.fasterxml.jackson.databind.jsontype.NamedType;:[[null, null]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 2, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\ud877\udc9b\udb6f\udca7", "\u2346\u3b0a\u390d\ua13b\u6143\u441e\uc894\ud41d\ub576\u4ed8\ub14a\ucbec", "\u5384\ud88d\udd60\udafe\udd29\ud8da\udd1d\udab6\udcf0\ud890\udcc3\ud85a\udc19\ud899\udfba\uda03\udd19",
        34, 7452, -2111142948, 4059728312494721269L, 66154L, true, false, (char) 23673, (char) 35308,
        Double.longBitsToDouble(0x3fc3e012f1a6a6a4L), Double.longBitsToDouble(0x3fe3166cf490f813L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |a0=[Lcom.fasterxml.jackson.databind.jsontype.NamedType;:[[]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 2, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\ud877\udc9b\udb6f\udca7", "\u2346\u3b0a\u390d\ua13b\ub78c\u39dc\uc894\ud41d\u9e69\ua926\ub14a\ucbec\ub9ea\u4290\u2daa\u36c1\u775c\ua900\u7185", "\ud899\udfba\uda03\udd19\ud9d0\udf17\ud8fe\ude43\uda4b\udc71\udbe8\udcb5\udbc2\uddd4\udb0c\udde6\udb77\udf13\ud8b3\uddf8\uda59\udfc4\udb71\udcc8\ud904\udc42\ud8b2\udeb0\ud9a5\udf88\udbbe\udd70\ud9b6\uddea\udb97\udd77\udb47\udc4e\ud86f\udd72\ud9e5\udf2a\ub0c6\udb21\udef8\ud82e\udd38\udb44\udfb3\udad9\udeba\ud8cb\udf35\ud9d2\ude3a\ud9fd\udf0e",
        16, 12315, -586214662, -1348534531931362657L, 1199L, false, false, (char) 48489, (char) 37485,
        Double.longBitsToDouble(0x3fd15fa99d537db2L), Double.longBitsToDouble(0x3fb530aae7a42ef8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |a0=[Lcom.fasterxml.jackson.databind.jsontype.NamedType;:[[null]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 2, "\ud9b5\udd63\ud9cb\udc09\ud975\uddd9\udb2a\udf63\udb2f\udc97\udb6f\udca7", "\u2346\u686b\u5424\u6585\uc262\ucd26\uc7fd\u2d1e\ub576\u4ed8\ub14a\ucbec", "\u5384\ud88d\udd60\udafe\udd29\ud8da\udd1d\udab6\udcf0\ud890\udcc3\ud85a\udc19\ud899\udfba\uda03\udd19\ud9d0\udf17\ud8fe\ude43",
        49, 6175, 249039093, 6380031321850506262L, 66154L, true, false, (char) 23673, (char) 18263,
        Double.longBitsToDouble(0x3fc3ea8011a6a6a4L), Double.longBitsToDouble(0x3fe3166cf490f813L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 11, 2, "\udb4f\uded0\ud9cb\udc7b\udb58\udeea\u653b\000\000", "\ud5fa\u3b0a\u390d\ua13b\u6143\u441e\uc894", "\udba6\udf43\ud88a\udd34\udb62\udfd8\ud961\ude66\uda7a\uddd3",
        5, 22367, 2118216121, 1076493287424L, -26313L, false, true, (char) 2714, (char) 18458,
        Double.longBitsToDouble(0x3feb662743dcec55L), Double.longBitsToDouble(0x3fd64822a1ea70aeL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Class;:[[interface java.util.List, int]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 2, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\ud877\udc9b\udb6f\udca7", "\u2346\u3b0a\u390d\ua13b\u6143\u441e\uc894\ud41d\ub576\u4ed8\ub14a\ucbec", "\ue1e5\ud87f\udcfe\udafe\udd29\ud8da\udd1d\udab6\udcf0\ud890\udcc3\ud85a\udc19\ud899\udfba\uda03\udd19",
        34, 7452, -2111142948, 4059728312494721269L, 66154L, true, false, (char) 23673, (char) 53996,
        Double.longBitsToDouble(0x3fc3f31e31a6a6a4L), Double.longBitsToDouble(0x3fe3166cf490f813L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Class;:[[class java.lang.Integer, class java.lang.Integer]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 2, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\ud877\udc9b\udb6f\udca7", "\u2346\u3b0a\u390d\ua13b\u4c93\u441e\uc894\ud41d\ub576\ua982\u9817\ucbec", "\u5384",
        22, 43121, -1670031621, -741539840L, 900L, true, false, (char) 18458, (char) 15444,
        Double.longBitsToDouble(0x3feee762ad64822aL), Double.longBitsToDouble(0x3fcea70af2bc3b60L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |a0=[Lcom.fasterxml.jackson.databind.jsontype.NamedType;:[[null, null]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 6, 9, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\ud877\udc9b\udbca\ude34", "\u7496S\u0b17\ua139\u6143\u441e\uc894\uaa73\ub576\u6f0c\ub14a\ucbec", "\u5384\ud88d\udd60\ud97b\udf62\ud8c6\udc26\udab6\udcf0\ud890\udcc3\ud85a\udc19\ud899\udfba\uda03\udd19",
        34, 63475, -2111142948, 4059728312494721269L, -64918L, false, false, (char) 23673, (char) 53996,
        Double.longBitsToDouble(0x3fc3f31e2f3ea6a4L), Double.longBitsToDouble(0x3fe3166b4c90f813L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 2, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\ud877\udc9b\udb6f\udca7", "\u2346\u3b0a\u7e9c\ua159\u6143\u441e\uc894\u1ab6\ub576\u4ed8\ub14a\ucbec", "\u5384\ud88d\udd60\udafe\udd29\ud8da\udd1d\udab6\udcf0\uda80\udc5a\ud85a\udc99\ud899\udfba\uda03\udd19",
        34, 7452, -2111142948, 4059728312494721269L, 66154L, true, false, (char) 23673, (char) 53996,
        Double.longBitsToDouble(0x3fc3f31e31a6a6a4L), Double.longBitsToDouble(0x3fe3166cf490f813L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 2, "\udb4f\uded0\ud9cb\udc7b\ud973\uddb7\udb33\udc94\ud877\udc9b\uda8c\uddf5", "\u2346\u3b0a\u390d\ua13b\u6143\u441e\uc894", "\uda0d\udd40\ud88a\udd34\udb62\udfd8\ud961\ude66\uda7a\uddd3",
        5, 22367, 2118216121, -7172731197021411750L, -26313L, false, true, (char) 2714, (char) 18458,
        Double.longBitsToDouble(0x3feb662743dcec55L), Double.longBitsToDouble(0x3fd64822a3ea70aeL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 6, 0, 2, "\udae4\uddfb\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\ud877\udc9b\udb6f\udca7", "\u2346\u3b0a\u390d\ua13b\u6143\u441e\u2cba\u1223\ub576\u4ed8\ub14a\ucbec", "\u5384\ud88d\udd60\udafe\udd29\ud8da\udd1d\udb58\udf40\ud9fd\udd9d\udb97\udf11\ud899\udfba\uda03\udd19\ud9d0\udf17\ud8fe\ude43\uda4b\udc71\udbe8\udcb5\udbc2\uddd4\udb0c\udde6\udaa1\udd69\udacc\udfa7",
        47, 36593, 1915302280, 6006991299401043127L, -71938L, false, false, (char) 32518, (char) 49940,
        Double.longBitsToDouble(0x3fb844e9ee763ff8L), Double.longBitsToDouble(0x3fd9be6a7523720eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |a0=[Lcom.fasterxml.jackson.databind.jsontype.NamedType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 2, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\ud877\udc9b\udb6f\udca7", "\u2346\u3b0a\u390d\ua13b\u0699\u9ba0\uc894\ud41d\ub576", "\ud98a\udec0\ud9b5\udc3b\uda7a\uddd3\u5384\ud9dd\udc89\ud827\udc22",
        43, 68561, -741534882, -75751778759313956L, -2684L, false, true, (char) 16716, (char) 34439,
        Double.longBitsToDouble(0x3fec1ac22168325eL), Double.longBitsToDouble(0x3fd0a4d6f8b9985cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 2, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\uda33\udc99\udb6f\udca7", "\u2346\ub6f6\u390d\ua13b\u6143\u441e\uc894\u8e1d\ub576\u4ed8\ub14a\ucbec", "\u5384\ud88d\udd60\udafe\udd29\ud8c6\udfd3\udadc\udec3\ud890\udcc3\ud85a\udc19\ud899\udfba\uda03\udd19",
        48, 7452, -2111142948, 4059728312494721269L, 66154L, true, false, (char) 62328, (char) 54194,
        Double.longBitsToDouble(0x3fc3f31e31a6a6a4L), Double.longBitsToDouble(0x3fe3166cf490f813L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 2, "\udb4f\uded0\ud9cb\udc7b\udb58\udeea\udb2a\udf63\ud877\udc9b\udb6f\udca7", "\u2346\u3b0a\u390d\ua13b\u6143\u441e\uc894\ud41d\ub576\u4ed8\ub14a\ucbec", "\u5384",
        22, 43121, 22267, 0L, 900L, true, false, (char) 18458, (char) 85,
        Double.longBitsToDouble(0x3f4d8ab592080000L), Double.longBitsToDouble(0x3fcea70af2bc3b60L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Class;:[[]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 11, "\udb4f\uded0", "\u7836\ua041\u673e\u20e8", "\udb1b\udcc0\ud8f2\udcc2",
        48, 39420, 1998655213, 6794151279040391459L, 77350L, true, true, (char) 18317, (char) 38603,
        Double.longBitsToDouble(0x3fc4f678c73b2198L), Double.longBitsToDouble(0x3feef2bc944e303cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 11, 6, "\ud99b\udfd6\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\ud877\udc9b\udb6f\udca7", "\u4050\u866a\ua1c3\ua13b\uab43\u7975\u7380\u5f0e", "\uda28\udd43\udb62\udfd8\ud961\ude66",
        24, 36088, -932812633, -6851568532227141637L, 91650L, true, false, (char) 45941, (char) 7366,
        Double.longBitsToDouble(0x3fe829197e001999L), Double.longBitsToDouble(0x3fe6e762a86482caL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 8, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\uda8b\uddbd\ud9a9\udd88\uda79\udc43\udb06\udc0e\udbeb\udf3c\ud829\udd87\ud8f2\udcc2", "\u441e\uc894\ud41d\u97c3\u4ed8\ub14a\ucbec\u519f\u29f8\u83f2\ud0da\u9e94\ud68d\u7185\u66fb\u6786\u0289\uc55a\u1212\u3ce2\ua2e8\ub0cd\ubf4e\u554b\ub840", "\udb71\udcc8\ud904\udc42\ud8d3\udd6c\ud9a5\udf88\udbbe\udd70",
        0, 13656, 247610139, 5403082054624722495L, 47303L, true, true, (char) 62646, (char) 2204,
        Double.longBitsToDouble(0x3fcbd229ecd25eccL), Double.longBitsToDouble(0x3fd51ed5be3880c2L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |a0=[Lcom.fasterxml.jackson.databind.jsontype.NamedType;:[[null, null]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=void |a0=[Ljava.lang.Class;:[[interface java.util.List, int]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\012",
        Z.run(T, 2, 7, 8, 2, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\ud877\udc9b\udb6f\udca7", "\u2346\u62ae\u3654\ua13b\u6143\u441e\uc894\ud41d\ub576\u4ed8\ub14a\ua484", "\u5384\ud88d\udd60\udafe\udd29\ud8da\udd1d\udab6\udcf0\ud890\udcc3\ud85a\udc19\ud899\udfba\uda03\udd19",
        34, 7452, -2111142948, 4059728312494721269L, 66154L, true, false, (char) 23673, (char) 53996,
        Double.longBitsToDouble(0x3fc3f31e31a6a6a4L), Double.longBitsToDouble(0x3fecee6cf23e2c29L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |a0=[Lcom.fasterxml.jackson.databind.jsontype.NamedType;:[[null, null]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=void |a0=[Lcom.fasterxml.jackson.databind.jsontype.NamedType;:[[null, null]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\012",
        Z.run(T, 2, 7, 7, 2, "\uda4f\udccf\ud9cb\udc7b\ud989\uded9\udb2a\udf63\ud877\udc9b\udb6f\udca7", "\u7c2a\u3b03\u43e2\ua13b\u6e28\u4387\uc894\ud41d\ub576\u4ed8\ub14a\ucbec", "\ud886\udcbb\ud897\udce6\udafe\udd29\ud8ad\ude05\udab9\ude78\ud890\udcc3\ud85a\udc19\ud813\udfb7\uda03\udd19",
        34, 7452, -2111142948, 4059728312494721269L, 66154L, true, false, (char) 32813, (char) 53996,
        Double.longBitsToDouble(0x3fc3f31e31a6a6a4L), Double.longBitsToDouble(0x3fe3166cf490f813L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |a0=[Lcom.fasterxml.jackson.databind.jsontype.NamedType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=void |a0=[Lcom.fasterxml.jackson.databind.jsontype.NamedType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\012",
        Z.run(T, 2, 7, 7, 7, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\udbb6\ude48\ud877\udc9b\udb6f\udca7", "\u2346\u3b0a\u390d\u6739\u5da9\u441e\uc894\ud41d\ub576\ubfac\u6890\u87c6", "\u5384\ud88d\udd60\udafe\udd29\ud8da\udd1d\udab6\udcf0\ud914\udcc5\ud85a\udc19\ud899\udfba\uda03\udd19",
        47, 45838, -2111142948, 4059728312494721269L, 66154L, true, false, (char) 23673, (char) 60538,
        Double.longBitsToDouble(0x3fc3fbd291a6a6a4L), Double.longBitsToDouble(0x3fe3166cf490f813L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |a0=[Lcom.fasterxml.jackson.databind.jsontype.NamedType;:[[null]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=void |a0=[Ljava.lang.Class;:[[interface java.util.List]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\012",
        Z.run(T, 2, 7, 8, 9, "\udb4f\uded0\ud9cb\udc7b\uda70\udf32\udb2a\udf63", "\u20e8\u675f\u2346\u3b0a\u390d\ua13b\u6143\u441e\uc894\ud41d", "\ud88a\udd34\udb62\udfd8\ud961\ude66",
        45, 9930, -932812633, 7368286707891080887L, 91650L, true, false, (char) 29903, (char) 2714,
        Double.longBitsToDouble(0x3fe4994c3b6c428aL), Double.longBitsToDouble(0x3feee762ad64822aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\012",
        Z.run(T, 1, 9, 0, 2, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\ud877\udc9b\udb6f\udca7", "\u2346\u3b0a\u390d\ua13b\u6143\u441e\uc894\ud41d\ub576\u4ed8\ub14a\ucbec", "\u5384\ud88d\udd60\udafe\udd29\ud8da\udd1d\udab6\udcf0\ud890\udcc3\ud85a\udc19\ud899\udfba\uda03\udd19",
        34, 7452, -2111142948, 4059728312259840245L, -100000L, false, true, (char) 54904, (char) 62574,
        Double.longBitsToDouble(0x3fd882af1186e452L), Double.longBitsToDouble(0x3fc3f31e31a6a6a4L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |a0=[Lcom.fasterxml.jackson.databind.jsontype.NamedType;:[[null, null]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 4, 2, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\ud96e\udc55\udb6f\udc94", "\u2346\u3b0a\u390d\ua13b\u6143\u441e\uc89d\ud150\ub576\u4ed8\ub14a\ucbec", "\u5384\ud88d\udd60\udafe\udd29\ud8da\udc51\ud839\udd30\ud868\udc39\udb45\ude72\ud899\udeff\uda03\udd19",
        34, 7452, -2111142948, 4059728312494721269L, 66154L, true, false, (char) 23673, (char) 53996,
        Double.longBitsToDouble(0x3fc3f31e31a6a6a4L), Double.longBitsToDouble(0x3fe3166cf490f813L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=new com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\012",
        Z.run(T, 2, 9, 9, 1, "\uda50\udd2b\ud9b7\ude7b\udb82\udf9f\udb2a\udf63\uda91\udf27\udbd6\udfa8", "\u2346\u0974\uc516\u9789\u4b64\ub0a7\u64d1\u6c80\u91dc\u58c5\ud12c\u39a6", "\u5384\ud8c8\udc20\udaa2\uddb4\ud8f0\udcbf\udab6\udd18\ud890\udcc3\ud85a\udc19\ud899\udfba\uda03\udd19\ud900\udcd3\ud920\udde5\udac1\udcf5\udafa\udc94\uda4a\udd98\udbaf\ude2b\udbb9\udf89\ud8b3\uddf8\ue491\udb71\udcc8\ud853\ude4a\ud8b2\ude4d",
        28, 32905, -129134494, 8102288609069764586L, -74442L, false, false, (char) 34937, (char) 33165,
        Double.longBitsToDouble(0x3fdbc502c584ac58L), Double.longBitsToDouble(0x3fe25b91f87665caL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 11, 6, "\udb4f\uded0\ud9cb\udc7b\udb58\udeea\u653b\000\000", "\ud5fa\u3b0a\u390d\ua13b\u6143\u441e\u6794", "\udba6\udf43\uda12\udd38\udb62\udfd8\uda0c\uddfa\uda5b\ude15\u5384\ud88d\udd60\udafe\udd29\u00fb\u9a94\ub2ff\u869e\ud963\udd78\uda03\udd19\ud9d0\udf17\udaf5\udc9e\udb81\udfdf\ud851\uddaa\ud883\udd95\uda73\udf8c",
        43, 47135, -705626453, 8596486793259548782L, 24448L, true, true, (char) 17253, (char) 19617,
        Double.longBitsToDouble(0x3fe951403a0eb0b0L), Double.longBitsToDouble(0x3fcab18848c392ecL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Class;:[[class java.lang.Long]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=void |a0=[Ljava.lang.Class;:[[class java.lang.Long]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\012",
        Z.run(T, 2, 8, 8, 2, "\udb55\udf00\ud9cb\udc7b\udb58\udeea\u653b\u1500\000", "\ud5fa\u3c7e\u390d\ua13b\ud65f\u96a5\u7369", "\udba6\udf43\udb14\udd39\udb62\udfd8\udb27\udd83\uda7a\ude50\u5384\ueabe\ud96c\udea7\uda36\udeb2\udbe9\udce8\udb26\udd3e\ud91f\udddc\ud899\udfba\uda03\udd19\udb6c\udf84\ud8fe\uddd7\ud858\udc37\ud885\udc1e\ud899\udc57\udbc7\udc4f\uda18\udd71\udb15\udc5b\uda98\ude99\ud93e\udc12\udb01\udeaa\udbf4\uddd7\ud9f1\udef6\udb99\udc45\uda29\udc9a\ud830\udcca\ud974\udc1f\ud9ef\udd8c\ud91a\udc85\ud827\ude7a",
        25, 99748, -1918318771, -5561211696157069022L, -85404L, true, true, (char) 25067, (char) 5644,
        Double.longBitsToDouble(0x3fc8eec6d89812c0L), Double.longBitsToDouble(0x3fed242ddb6cec6aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Class;:[[char, class java.util.Date]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=void |a0=[Ljava.lang.Class;:[[char, class java.util.Date]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\012",
        Z.run(T, 2, 8, 8, 2, "\udb4f\ude0f\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\ud877\udc9b\ud978\ude4c", "\u3247", "\udaab\udc28\uda30\udce4\ud8d1\uddf2\ud938\udf76\ud9af\ude57\udb56\ude67\udba6\udf43\ud88a\udd34\ud964\udfd9\ud961\ude66\uda7a\uddd3\ue1e5\ud87f\udcfe\udafe\udd29\ud8da\udd1d\udab6\udcf0",
        -2, 36665, -1745717796, 2992486538004668051L, -2684L, false, true, (char) 16716, (char) 31623,
        Double.longBitsToDouble(0x3f96785c2d065860L), Double.longBitsToDouble(0x3fd0a4d6f482e45cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Class;:[[interface java.lang.Comparable, int, class java.util.ArrayList]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=void |a0=[Ljava.lang.Class;:[[interface java.lang.Comparable, int, class java.util.ArrayList]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\012",
        Z.run(T, 2, 8, 8, 0, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\ud810\ude16\udb6c\udeb1\uda8d\udc56", "\u2346\u3b0a\u390d\ua13b\u6143\u441e\uc894\ud41d\ub576\u4ed8\ub14a\uc09a", "\ue1e5\ud87f\udcfe\udafe\udd29\ud8bd\udd2e\udab6\udd8e\ud890\udcc3\udbb3\udfb5\udb1d\udd34\ud9af\udeb7",
        23, 7498, -2111142948, 4059728312494721269L, 66154L, true, true, (char) 6778, (char) 63979,
        Double.longBitsToDouble(0x3fd0e392a6a92dd0L), Double.longBitsToDouble(0x3fc3a34223257ca0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Class;:[[class java.lang.Integer, class java.lang.Integer, class java.lang.Integer]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=void |a0=[Ljava.lang.Class;:[[class java.lang.Integer, class java.lang.Integer, class java.lang.Integer]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\012",
        Z.run(T, 2, 8, 8, 2, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\ud939\ude65\ud877\udc9b\udb6f\udca7", "\u2346\u3b0a\u390d\ua13b\u4c93\u9e26\uc894\ud41d\ub576\u75f4\u5377\ub671", "\u5384",
        15, 43121, -1670031621, -2094006272L, 900L, true, false, (char) 18458, (char) 15444,
        Double.longBitsToDouble(0x3feee762ad64822aL), Double.longBitsToDouble(0x3fcea70af2bc3b60L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\012",
        Z.run(T, 1, 9, 0, 2, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\uda5e\udf5d\ud877\udc9b\udb6f\udca7", "\u2346\ud53f\uab25\ua13b\u6143\u441e\uc894\ud41d\ub576\u4ed8\ub14a\ucc06", "\uda89\uddfd\udb85\uddf9\udaa0\uddbb\udb79\udd0e\ud8d5\udcbf\ud890\udcc3\ud85a\udc19\ud899\udfba\uda03\udd19",
        59, 99446, 1956549700, -2564936391639693067L, -100000L, false, true, (char) 54904, (char) 62574,
        Double.longBitsToDouble(0x3fd882af1186e452L), Double.longBitsToDouble(0x3fc3f31e31a6a6a4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |a0=[Lcom.fasterxml.jackson.databind.jsontype.NamedType;:[[null]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 2, "\ud910\udd8e\uda08\ude19\udae6\uddc4\ud823\ude60\udad7\udea3\udb6f\udca7", "\u6a20\u3b1f\u390d\ua13b\uacd0\ud531\u4048\u9c71\ub576\u4ed8\u5f19\u1682\ub268\u4290\u2daa\u36c1\u775c", "\ud890\udcc3\ud855\udec7",
        41, 43567, 2027853657, -1370141767931824262L, -95060L, false, true, (char) 54904, (char) 62574,
        Double.longBitsToDouble(0x3fd882af1186e452L), Double.longBitsToDouble(0x3fc3f31e31a6a6a4L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |a0=[Lcom.fasterxml.jackson.databind.jsontype.NamedType;:[[null, null]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\0121=void |a0=[Ljava.lang.Class;:[[interface java.util.List, class java.util.Date]] |this=com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:@?\012",
        Z.run(T, 2, 7, 8, 2, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\ud877\udc9b\udb6f\udca7", "\u2346\u62ae\u3654\ua13b\u6143\u441e\uc894\ud41d\ub576\u4ed8\ub14a\ua484", "\u5384\ud88d\udd60\udafe\udd29\ud8da\udd1d\udab6\udcf0\ud890\udcc3\ud85a\udc19\ud899\udfba\uda03\udd19",
        34, 7452, -567639076, 4042217241202657525L, 66154L, true, false, (char) 23673, (char) 53996,
        Double.longBitsToDouble(0x3fc3f31e31a6a6a4L), Double.longBitsToDouble(0x3fecee6cf23e2c29L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 8, 9, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\ud89d\udfdd\ud877\udc9b\udb6f\udca7", "\u71b0\u3b0a\u5a76\u84c5,\u6d42", "\udb56\ude67",
        57, 234, 594198976, -8476058905841054929L, 4281L, true, true, (char) 54588, (char) 49871,
        Double.longBitsToDouble(0x3feaf5216d2a529fL), Double.longBitsToDouble(0x3fe2716aca2f9611L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 6, 0, 2, "\udb4f\uded0\ud9cb\udc7b\ud975\uddd9\udb2a\udf63\ud877\udc9b\udb6f\udca7", "\u2346\u9757\u7525\ua13b\u6143\u441e\uc894,\ub576\u4ed8\ub14a\ucbec", "\ue1e5\ud87f\udcfe\udafe\udd29\ud9f7\udf6b\ud81a\uddea\ue23d\udade\udec4\udb5d\udc2a\uda03\udd19",
        34, 7452, -2111142948, 4059728312494721269L, 66154L, true, false, (char) 23673, (char) 53996,
        Double.longBitsToDouble(0x3fc3f31e31a6a6a4L), Double.longBitsToDouble(0x3fe3166cf490f813L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver|collectAndResolveSubtypesByClass|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedClass|new:com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver|collectAndResolveSubtypesByClass|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedMember,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver|collectAndResolveSubtypesByTypeId|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedClass|new:com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver|collectAndResolveSubtypesByTypeId|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedMember,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver|_collectAndResolve|com.fasterxml.jackson.databind.introspect.AnnotatedClass,com.fasterxml.jackson.databind.jsontype.NamedType,com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.AnnotationIntrospector,java.util.HashMap|new:com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver|_collectAndResolveByTypeId|com.fasterxml.jackson.databind.introspect.AnnotatedClass,com.fasterxml.jackson.databind.jsontype.NamedType,com.fasterxml.jackson.databind.cfg.MapperConfig,java.util.Set,java.util.Map|new:com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver|_combineNamedAndUnnamed|java.lang.Class,java.util.Set,java.util.Map|new:com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver|registerSubtypes|[Lcom.fasterxml.jackson.databind.jsontype.NamedType;|new:com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver|registerSubtypes|[Ljava.lang.Class;|new:com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:",
    "C|com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver|<init>|",
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver|collectAndResolveSubtypesByClass|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedClass|new:com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver|collectAndResolveSubtypesByClass|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedMember,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver|collectAndResolveSubtypesByTypeId|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedClass|new:com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver|collectAndResolveSubtypesByTypeId|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedMember,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
