package com.fasterxml.jackson.databind;
import org.junit.Test;
import static org.junit.Assert.*;
public class ObjectMapper_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 3, 16, 11, "\uda1f\udd15\ud8fa\udc9a\ud991\udd3c\ua0ee\ud9ce\ude6c\ud96c\uddce\uda73\udc60\ud9a2\udfd5\ud9f6\udc7b\u3acb\ud824\udcd4", "\ubc0b\u737a\u7a3c", "\uda72\udfea\udb12\udd3f\udbf9\udc82\ud954\udc48\ud89a\udcab\udaf2\udf49\udbca\ude28\ud9de\uddb5\ud888\udd19\udb75\udc16\udb44\udc89",
        23, 49951, 691385654, 951866693903248095L, 48870L, false, false, (char) 30603, (char) 50461,
        Double.longBitsToDouble(0x3fe244ef5007d75dL), Double.longBitsToDouble(0x3fe9a6c9e3b6c254L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 3, 16, 11, "\ud98b\udf81\ud81f\udc9e\udac5\udd13\uda7e\udc90\udac7\udf93\ud96c\uddce\ud800\udfbf\ud9f3\uddda\ud9f6\udc7b\u3acb\ud824\udcd4", "\ubc0b\u737a\u7a3c", "\uda72\udfea\udb12\udd3f\udbf9\udc82\ud954\udc48\ud89a\udcab\udaf2\udf49\udbca\ude28\ud9de\uddb5\ud888\udd19\uda1a\udd3e\udb44\udc89",
        23, 49951, 691385654, 951866693903248095L, -25032L, false, false, (char) 51098, (char) 7344,
        Double.longBitsToDouble(0x3fc75135b5534910L), Double.longBitsToDouble(0x3fe3d613308e8219L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 11, 12, 11, "\uda1f\udd15\ud8fa\udc9a\ud991\udd3c\u38a6\ud9ce\ude6c\ud96c\uddce\ud9e5\udc59\ud9a2\udfd5\ud9f6\udc7b\u3acb\ud824\udcd4", "\ubc0b\u737a\u7a3c", "\uda72\udfea\udb12\udd3f\udbf9\udc82\ud954\udc48\ud844\udf61\udae3\udd52\udbca\ude28\ud9de\uddb5\uda34\ude10\udbcf\udf78\ud913\udc3d",
        32, 68346, -1858164363, 951866693903248095L, -77316L, false, false, (char) 39773, (char) 7344,
        Double.longBitsToDouble(0x3fc75135b5cd1d10L), Double.longBitsToDouble(0x3fe695625dd7b998L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 9, 11, "\uda1f\udd15\ud8fa\udc9a\ud991\udd3c\ua0ee\ud9ce\ude6c\ud96c\uddce\ud951\udfc2\ud9a3\udc63\ud926\udf13\ud9f6\udf9d\ud928\udf96", "\ubc0b\u737a\u7a3c", "\uda72\udfea\udb12\udd3f\udbf9\udc82\ud93b\udff3\ud89a\udcab\udaf2\udec1",
        43, 49613, 754181747, 5635392344493126502L, 26839L, false, true, (char) 57067, (char) 63507,
        Double.longBitsToDouble(0x3fb440e8067eef08L), Double.longBitsToDouble(0x3fe7f37ae1159e11L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 4, "\uda1f\udd15\ud8fa\udc9a\ud991\udd3c\ua0ee\ud901\udfc7\udad5\udcfc\uda73\udc60\ud9a2\udfd5\ud81b\udeb7\udb77\udeae\ud819\udfbe", "\u4f4e", "\ud946\ude1f\udbdc\udd69\uda72\udfea\udb12\udd3f\udbf9\udc82\ud83b\udd43\udb2a\udc6b\udaf2\udf53\udbca\ude28\ud9de\uddb5\ud888\udd19\udb75\udc16\udb44\udc89\uda2d\ude6a\udbda\udf07\ud86f\ude21\ud88f\udf63\udae8\ude85",
        50, 84252, -1390239178, -5833340797190315392L, 53863L, false, false, (char) 47783, (char) 40075,
        Double.longBitsToDouble(0x3fbdfd825244ef50L), Double.longBitsToDouble(0x3f7f5d759a6c9e00L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 16, 11, "\uda1f\udd15\udb28\udc70\ud917\udc42\ua0ee\ud9ce\ude6c\ud96c\uddce\uda73\udc60\ud9a2\udfd5\ud9f6\udc7b\u3acb\ud803\udfd4", "\ubc0b\u742e\u7a3c", "\uda72\udfea\udb07\udf4b\udbf9\udc82\ud954\udc48\ud89a\udcab\ud976\udeed\ud9c0\ude6a\uda0c\udd7a\ud875\udc4f\udb75\udc16\udb45\udc89",
        23, 49951, -600459978, -1625873076864357793L, 48870L, false, false, (char) 30603, (char) 50461,
        Double.longBitsToDouble(0x3fe244e86007d75dL), Double.longBitsToDouble(0x3fef4ba59bb6c254L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 16, 11, "\uda92\udeee\ud8fa\udc9a\ud991\udd3c\ud8fa\udebd\ud9ce\ude6c\ud96c\uddce\uda73\udc60\udb50\udded\ud9f6\udc56\u3acb\ud824\udcd4", "\ubc0b\u737a\u7a3c", "\uda72\udfb2\udb12\udd3f\uda2c\ude7b\udbcb\udf80\ud89c\udc84\udaf2\udf49\udbca\ude28\ud9de\uddb5\ud888\udd19\udb75\udc16\udb44\udc89",
        23, 49951, 691385654, -8598002022284727585L, 48870L, false, false, (char) 30603, (char) 50461,
        Double.longBitsToDouble(0x3fe244ef5007ba5dL), Double.longBitsToDouble(0x3fe9a6c9e3b6c254L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 14, "\udb18\udf32\udaf6\udcc6\ud991\udd3c\ua0ee\ud9ce\ude6c\ud96c\uddce\uda73\udc60\ud884\ude40\ud9f6\udca8\udbf3\udf03\ud824\udcd4", "\ubc0b\uceaa\u7a1f", "\uda72\udfea\udb12\udd3f\udbf9\udc82\udb7e\uddfd\ud937\udc35\udb1a\udcad\udbca\uddad\ud9de\uddb5\ud88d\uddf8\udb75\udc16",
        38, 2945, 798959164, 3025293749987423671L, 32177L, true, false, (char) 25354, (char) 28801,
        Double.longBitsToDouble(0x3fe8178d895e89adL), Double.longBitsToDouble(0x3fe83b3a627a28fdL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 16, 11, "\u4950\ud843\ude99\udb97\udf5d\ua0ee\ud9ce\ude6c\ud96c\uddce\uda73\udc60\ud9a2\udfd5\ud9f6\udc7b\ud85f\udcbe\ud824\udd4b", "\ubc0b\u737a\u7a3c", "\uda72\udfea\udb12\udd3f\udbf9\udc82\ud954\udc48\ud89a\udcab\udaf2\udf49\udbca\ude28\ud90a\udeab\ud889\ude11\udb75\udc16\udb44\udc89",
        23, 49951, 691385654, 951866693903248095L, 81710L, false, true, (char) 2663, (char) 49227,
        Double.longBitsToDouble(0x3fe3d613308e8219L), Double.longBitsToDouble(0x3fb149d1afa67948L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 16, 4, "\uda1f\udd15\ud8fa\udc9a\ud87f\udd3d\ua0ee\ud9ce\ude6c\ud96c\uddce\uda73\udc60\ud9a2\udfd5\ud9f6\udc7b\u3acb\ud824\udcd4", "\ub40a\u737a\u0e0c", "\uda72\udfea\udb12\udd3f\udbf9\udc82\uda5c\ude4b\ud89a\udcab\udaf2\udf49\udbca\ude28\ud9de\uddb5\ud888\udd19\udb75\udc16\ud93a\udce4",
        6, 45929, -1690979018, 951866693903248095L, 48870L, false, false, (char) 30603, (char) 50461,
        Double.longBitsToDouble(0x3fe244ef5007174dL), Double.longBitsToDouble(0x3fe9a6c9e3b6c254L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 16, 11, "\uda1f\udd15\ud8fa\udc9a\ud991\udd3c\ua0ee\ud9ce\ude6c\ud96c\uddce\ud822\udc17\ud9a2\udfd5\ud9f6\udc7b\ud9fb\udc80\udbc2\udcca", "\ubc0b\u737a\u7a3c\u64d4", "\udb12\udc7f\udbf9\udc82\ud954\udcaa\ud89a\udcab\udaf2\udf49\udbca\ude28\uda66\udeb7",
        2, 2019, -814222486, 2975407026862944119L, 12055L, true, true, (char) 22932, (char) 59056,
        Double.longBitsToDouble(0x3fe7f37ae0159e11L), Double.longBitsToDouble(0x3fe887b520ba89adL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 16, 11, "\uda1f\udd15", "\uace9\u8ac9\uc249\u7814\u4336\u4d98\u1815", "\udb44\udf7f\uda60\udeb0\ud8a3\udfe3\ud90b\udfae",
        7, -1000, 0, 7879806209746676043L, -59405L, false, false, (char) 32134, (char) 58075,
        Double.longBitsToDouble(0x3fe39ed3177b2cf3L), Double.longBitsToDouble(0x3feb327004edcf77L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 11, 12, 11, "\udbf9\udf7b\ud8fa\udc9a\ud991\udd3c\u38a6\ud9ce\ude6c\u94cc\ud9e5\udc59\ud9a2\udfd5\ud9f6\udc7b\ud804\ude0c\000", "\uc6da", "\ud870\uddb8\udbdc\udd69\uda72\udfea\000\000\000\ud844\udf61\udae3\udd52\udbb1\udc28\ud9de\uddb5\ud9e9\udc07\udbcf\udf78\000\uda47\udc94",
        36, 42381, 0, 1636237312L, -100000L, false, false, (char) 41727, (char) 35245,
        Double.longBitsToDouble(0x3fd734744da55896L), Double.longBitsToDouble(0x3fdd7b9981709c88L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 11, "\uda1f\udd15\ud8fa\udc9a\ud991\udd3c\u38a6\uda22\udf25\udbb9\udc4d\ud9e5\udc59\ud9a2\udfd5\ud9f6\udc7b\u3acb\ud824\udcd4", "\ubc0b\u737a\u7a3c", "\uda72\udfea\udb12\udd3f\udbf9\udc82\ud954\udc48\ud844\udf61\udae3\udd52\udbca\ude28\ud9de\uddb5\ud9a3\udf0a\udbcf\udf78\ud913\udc3d\udbc4\udff2\ud868\udd5b\ud81c\udeee\ud8fd\ude7e\udae8\udf15\ud96c\ude10\ue72c\ud84d\uddba\udba2\udc3f\udbb5\udc16\ud889\udced\ud88e\udc84\udb3a\udeab\ud8d0\uded3\uccc3\uda1e\udcf2\uda4d\udd26\udb85\ude34\udbbd\udefd\udb65\udd8d",
        26, 12627, 1098422101, -926405562178557807L, -2038L, false, false, (char) 46521, (char) 43755,
        Double.longBitsToDouble(0x3fd365304d901d00L), Double.longBitsToDouble(0x3fedfc4bc6c3a6beL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 11, 2, 2, "\uda1f\udd15\ud86f\udc54\ud959\udd9e\ud8f9\uddbb\ud9ce\ude6c\ud96c\uddce\ud9e5\udc59\ud9a2\udfd5\ud9f6\udc7b", "\u547f\u5fa9\ubc0b\u737a\u7a3c\u6478\u141b\u2c28\u6c69\u6122\uaece\uc5e0\u4721\u1709\u2ea8\u455c\ub290\u88d3\u6f01\u6a46\u3844\u68ac\ucf2b\ub7e8\u3c98\u9e70\ua93b\u8ed3\u6d31", "\ud9d6\udf56",
        17, 43113, -292952117, 1378362897864760669L, -93718L, false, false, (char) 38736, (char) 21344,
        Double.longBitsToDouble(0x3fdde9407778af96L), Double.longBitsToDouble(0x3fd3fa86d8e1d130L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 14, "\uda1f\udd15\ud8fa\udc9a\ud991\udd3c\u38a6\ud9ce\ude6c\ud96c\uddce\uda92\udf77\ud8e6\udd27\ud9f6\udc7b\u3acb\ud824\udcd4\ud87a\uddc1\udb44\udf7f\uda60\udeb0\ud8a3\udfe3\ud90b\udfae\ud946\uddc3\udbdc\udd69\uda72\udfea\udb12\udd3f\udbf9\udc82\ud954\udc48", "\u96da\u9757\u5e45\u0184\u88cc\u6f01\u6a46\u5e30\u055f\ucafd\u4271", "\udba2\udc3f\udbb5\udc16\ud889\udced\ud88e\udc84\udb3a\udeab\ud9b4\udec5\udab1\udc24\ud880\udce9\uda8b\udd93\udbe6\udc61\ud820\ude97\udb73\udef5\udbab\udd51",
        7, 44961, -1339320361, -7422502180252505507L, -81420L, true, true, (char) 20975, (char) 6142,
        Double.longBitsToDouble(0x3fe8a8424ba0622aL), Double.longBitsToDouble(0x3fe5fda5dae7b36cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 10, 12, 11, "\uda1f\udd15\ud8fa\udc9a\ud991\udd3c\u38a6\ud9ce\ude6c\ud96c\uddce\ud9e5\udc59\ud9a2\udfd5\ud5ba\ud87a\udd01\ud93e\udf5f", "\ubc0b\u737a\ua63c", "\uda72\udfea",
        -2, 3851, 812217710, 2207214149403081729L, 44365L, true, false, (char) 23358, (char) 53215,
        Double.longBitsToDouble(0x3fefedaf51ba824cL), Double.longBitsToDouble(0x3fd75f9b6b6f227cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 10, 3, "\uda1f\udd15\ud8fa\udc9a\ud8ff\uddd3\udae8\udc90\udac8\udc08\ud932\udec7\ud9e5\udc59\ud9a2\udfd5\ud9f6\udc7b\u3acb\ud824\udcd4", "\ubc0b\u737a\u7a3c", "\uda72\udfea\udb12\udd3f\udbf9\udc82\ud919\udf0c\ud844\udf2c\udae3\udd52\udbca\ude28\ud9de\uddb5\uda34\ude10\udbcf\udf78\uda7b\udc31",
        32, 68346, -1858164363, 951866693903248095L, -77316L, false, false, (char) 39773, (char) 7344,
        Double.longBitsToDouble(0x3fc75135b5cd1d10L), Double.longBitsToDouble(0x3fe695625dd7b998L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 12, 12, 11, "\uda1f\udd15\ud8fa\udc9a\ud991\udd3c\u38a6\udadc\ude73\ud96c\uddce\ud9e5\udc59\ud9a2\udfd5", "\u5e34\u547f\u5fa9\ubc0b\u737a\u87af\u811a", "\udb12\udd3f\udbf9\udc82\udba0\udc4e\ud844\udf61\udae3\udd52\udbca\ude28\ud9f1\udeff",
        15, 32529, -1242941190, -9057754812376510022L, 50089L, true, false, (char) 45040, (char) 47651,
        Double.longBitsToDouble(0x3fdec205cb357e5aL), Double.longBitsToDouble(0x3fe883c970ba89adL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 11, "\uda1f\udd15\ud961\udc46\ud97d\ude16\u38a6\ud9ce\ude6c\udb4c\udcbe\ud9e5\udc59\ud9a2\udfd5\ud9f6\udc7b\u3acb\ud824\udcd4", "\ubc0b\u737a\u7a3c", "\uda72\udfea\udb12\udd3f\udbf9\udc82\ud954\udc48\ud844\udf61\udae3\udd52\udbca\ude28\ud9de\uddb5\uda34\ude10\udbcf\udf78\ud913\udc3d",
        32, 68346, -1858164363, 951866693903248095L, -77316L, false, false, (char) 39773, (char) 7344,
        Double.longBitsToDouble(0x3fc75135b5cd1d10L), Double.longBitsToDouble(0x3fe695625dd7b998L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 12, "\uda1f\udd15\udace\udf56\udb2c\ude84\udb36\udd7d\ud929\udf65\ud996\udddc\ud9e5\udc59\ud9a2\udfd5\ud9f6\udc7b\u3acb\ud824\udcd4", "\ubc0b\u737a", "\ud9e8\uddcf\udaa1\udf95\udb12\udd3f",
        -4, 75710, 513909362, -108044606680184274L, 37613L, true, true, (char) 53215, (char) 6632,
        Double.longBitsToDouble(0x3fdba254c2ebf36cL), Double.longBitsToDouble(0x3fdb7913e5be1a6aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 10, 10, 6, "\uda1f\udd15\ud8fa\udc9a\ud991\udd3c\u38d6\uda8e\udd09\ud96c\uddce\ud9e5\udc59\ud9a2\udfd5\ud9f6\udc7b\u3acb\ud824\udcd4", "\ubc0b\u737a\u7a3c", "\uda72\udfea\udb12\udd3f\udbf9\udc82\ud954\udc48\ud844\udf61\udae3\udd52\udbca\ude28\ud9de\uddb5\uda34\ude10\udbdd\udf78\ud913\udc3d",
        32, 68346, -1858164363, 951866693903248095L, -77316L, false, false, (char) 39773, (char) 4051,
        Double.longBitsToDouble(0x3fee4056dfcaa579L), Double.longBitsToDouble(0x3fe695625dd7b998L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 13, 8, "\uda1d\udf67\ud8fa\udc9a\ud991\udd3c\uda36\ude5f\udb7c\udd5f\ud95c\ude40\ud9e5\udc59\ud9a2\udfd5\ud9f6\udc7b\u3acb\ud824\udcd4", "\ubc0b\u737a\u2e22", "\udb83\uddea\udb12\udd3f\udbf9\udc82\ud954\udc48\ud844\udf61\ud85a\udf8e\uda3c\udd30\ud9d9\udde4\uda34\ude10\udbcf\udf78\ud913\udc3d",
        32, 58099, -1858164363, 951866693903248095L, -77316L, false, false, (char) 39773, (char) 7344,
        Double.longBitsToDouble(0x3fc75135b5cd1d10L), Double.longBitsToDouble(0x3fe735625dd7b998L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 9, 8, "\ud948\udde8\ud8fa\udc9a\ud991\udd3c\u38a6\ud9ce\ude6c\ud96c\uddce\ud9e5\udc59\ud9a2\udfd5\ud9f6\udc7b\u3acb\ud824\udcd4\ud87a\uddc1\udb44\udf7f\uda60\udeb0\ud8a3\udfe3\ud90b\udfae\ud946\uddc3\udbdc\udd69\udbb7\udfed\udb12\udd3f\udbf9\udc82\ud954\udc48\ud844\udf61\udae3\udd52\udbca\ude28\ud9e1\udfb5\udb11\udc3e\ud965\udfc5\ud913\udc9e\ud9c0\udf90\uda33\uddb2\ue9f9\ud8fd\ude7e\udae8\udf15\ud96c\ude10", "\ua93b\u8ed3\ube5f\u023e\ud35f\u48b2\u18f3\ub2a0\u366c\u225b\u057e\u6aed\uc989\u3d91\ub040\u69de\u1ef3\u82ab", "\ud8ff\udc22\ud9aa\udc09\ud9b3\udde1\u9b1f\udbd7\udf17\uda4a\udd24\u09d2\ud91d\udd7a\ud91c\udd6b",
        33, 99111, 1806509303, -935426599980915382L, -23332L, false, false, (char) 57176, (char) 18701,
        Double.longBitsToDouble(0x3feade5feae8a27eL), Double.longBitsToDouble(0x3fe665f0d6fee3c8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 4, 12, "\uda1f\udd15\ud8d7\udc27\ud8cc\ude7a\u0bec\ud9ce\ude6c\ud96c\uddce\ud9e5\udc59\ud9a2\udfd5\ud9f6\udc7b\u3acb\ud8a8\udf5a", "\u4457\u484e\ua4ad\u6478\ubf6a\u2b99\u6c69\u6122", "\udae3\udd52\udbca\ude28",
        -2, 52803, -1757108827, -5338392171498216451L, -12309L, true, true, (char) 63507, (char) 45040,
        Double.longBitsToDouble(0x3fc38c30fbf9bd70L), Double.longBitsToDouble(0x3fd157248620f340L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 8, 11, "\uda1f\udd15\ud8fa\udc9a\ud991\udd3c\u38a6\ud9ce\ude6c\ud96c\uddce\ud9e5\udc59\ud9a2\udfd5\ud9f6\udc7b\u3acb\ud824\udcd4", "\ubc0b\u737a\u7a3c", "\uda72\udfea\udb12\udd3f\udbf9\udc82\ud954\udc48\ud844\udf61\udae3\udd52\udbca\ude28\ud9de\uddb5\uda34\ude10\udbcf\udf78\udba4\udd30",
        32, 68346, -1858164363, 951866693903248095L, -77316L, false, false, (char) 39773, (char) 7344,
        Double.longBitsToDouble(0x3fc75135b5cd1d10L), Double.longBitsToDouble(0x3fd36ac4bb4c6e1eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 11, 11, 9, "\uda1f\udd15\ud8fa\udc9a\ud991\udd3c\udbc8\udd6f\ud9ce\ude6c\ud96c\uddce\ud9e5\udc59\uda7f\uded4\ud907\udc6e\u3acb\ud824\udcd4\udb81\ude77", "\u7639\u8edf\u5cf9\u141b\u2c28\u6c69\u6122\uaece\uc5e0\u5689\u96da", "\udbcf\udf78\ud913\udc3d\uda47\udc94\u1356\ud81c\udeee\ud8fd\ude7e\udae8\udf15\ud958\udf10\ue72c",
        30, 47408, -1647239787, 5427838126633233818L, -56439L, false, true, (char) 58165, (char) 1107,
        Double.longBitsToDouble(0x3f9db294b9b86580L), Double.longBitsToDouble(0x3fe57a1093634282L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 14, 16, "\ud9c1\udd06\ud8fa\udc9a", "\u34cd\uc249\u568e", "\u3acb\ud824\udcd4",
        31, 14894, 1092732634, -8983177967902897006L, -68676L, false, true, (char) 7568, (char) 38565,
        Double.longBitsToDouble(0x3fd6eaeded266146L), Double.longBitsToDouble(0x3fe31248ffde104dL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 7, "\uda23\ude13\ud8fa\udc9a\ud991\udd3c\ua0ee\ud972\udcff\ud874\udd2e\ud951\udfce\ud4cd\udb5b\ude4b\ud9f6\udf9d\uda61\udff4\uda1c\udc3d\ud908\udff8", "\ua36a\ub1dc\u3951\u26eb", "\uda51\udf9e\ud8f6\ude04\ud9a3\udf35\udbd0\udf08",
        -2, 10867, 996470741, 6888383002311910261L, 4321L, true, true, (char) 63507, (char) 42480,
        Double.longBitsToDouble(0x3fc9fc1c5bf9bd70L), Double.longBitsToDouble(0x3fd159e11ed4779aL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 16, 0, "\u4950", "\uace9\u46a3\uc249\u7814\u4336\u4d98\000", "\udb22\udf31\uda60\udeb0\ud8a3\udfe3\ud90b\udfae",
        58, 35007, 0, 0L, 71667L, true, true, (char) 32134, (char) 58075,
        Double.longBitsToDouble(0x3fbafaab7bd96798L), Double.longBitsToDouble(0x3eaa400000000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 9, 12, "\uda60\uddd3\udb70\udee9", "\u8b61\u9258\u7443\u4336\uaa2c\u4fcc\ua94c\u7cd8\u276e\ubc0b\u737a\u7a3c\u7bcc", "\udb12\udd3f\udbf9\udc82\ud954\udc48",
        52, 92905, -1360115154, -2700976783842453133L, 16581L, true, true, (char) 46853, (char) 41771,
        Double.longBitsToDouble(0x3fdb7913ed5f79e2L), Double.longBitsToDouble(0x3fe4272627301c63L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 3, 16, 11, "\uda6c\ude3d\ud906\udfac\ud991\udcd7\ua0ee\ud9ce\ude6c\ud96c\uddce\uda73\udc60\ud9a2\udfd5\ud9f6\udc7b\u3acb\udb36\udd93", "\ubb7d\u743d", "\udbdc\udd69\uda96\udc5d\udb12\udcd9",
        23, 75710, 596287123, 1627525650131609328L, -93459L, true, false, (char) 18976, (char) 37988,
        Double.longBitsToDouble(0x3febb94a5536325dL), Double.longBitsToDouble(0x3fdb729355be1a6aL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ObjectWriter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 5, "\uda23\ude13\ud8fa\udc9a\ud991\udd3c\ua0ee\uda01\udfa2\ud95d\udc6c\ud975\ude86\udbf9\udd9b\udbed\uddb4\ud8d9\ude51\uda62\udc68\uda1c\udc3d\ud908\udff8", "\u4fdc\ua225\u83b1\u26eb", "\uda51\udf9e\ud8f6\ude04\ud9a3\udf35\udbd0\udf08",
        -2, 10867, 996470741, 6888383002311910261L, 4321L, true, true, (char) 63507, (char) 42480,
        Double.longBitsToDouble(0x3fe8770716a727efL), Double.longBitsToDouble(0x3fefb9d0a2fe3b10L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder|buildTypeDeserializer|com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.JavaType,java.util.Collection|new:com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder|buildTypeSerializer|com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.JavaType,java.util.Collection|new:com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_checkInvalidCopy|java.lang.Class|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_configAndWriteCloseable|com.fasterxml.jackson.core.JsonGenerator,java.lang.Object,com.fasterxml.jackson.databind.SerializationConfig|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_configAndWriteValue|com.fasterxml.jackson.core.JsonGenerator,java.lang.Object|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_convert|java.lang.Object,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_findRootDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_initForReading|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_newReader|com.fasterxml.jackson.databind.DeserializationConfig|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_newReader|com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.JavaType,java.lang.Object,com.fasterxml.jackson.core.FormatSchema,com.fasterxml.jackson.databind.InjectableValues|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_newWriter|com.fasterxml.jackson.databind.SerializationConfig|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_newWriter|com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.core.FormatSchema|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_newWriter|com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.PrettyPrinter|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_readMapAndClose|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_readValue|com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_serializerProvider|com.fasterxml.jackson.databind.SerializationConfig|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder|buildTypeDeserializer|com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.JavaType,java.util.Collection|new:com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:",
    "M|com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder|buildTypeSerializer|com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.JavaType,java.util.Collection|new:com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
