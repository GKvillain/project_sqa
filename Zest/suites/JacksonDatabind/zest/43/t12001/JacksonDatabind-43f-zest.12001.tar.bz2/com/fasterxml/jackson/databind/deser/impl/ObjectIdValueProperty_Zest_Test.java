package com.fasterxml.jackson.databind.deser.impl;
import org.junit.Test;
import static org.junit.Assert.*;
public class ObjectIdValueProperty_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 1, 3, "\udad9\ude78\udb5e\udd3c\uda63\ude5c\udbf8\udfc0\udb2d\udc4d\udb93\udd68\u5f93", "\uaa64\ucf8c\u3510\u8f7c\ubba1\u4d0f\u07ac\ud760\u6bff\u8df1", "\uda3f\ude8d",
        47, 1005, 856914418, 1453739395678180564L, -48246L, true, true, (char) 4858, (char) 28271,
        Double.longBitsToDouble(0x3facd27104ceb660L), Double.longBitsToDouble(0x3fe7bb4c7bf2fe55L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 2, 3, "\udad9\ude78\udb5e\udd3c\udb3c\ude69\ud83c\udc4d\udb2d\udc5f\udb93\udd68\u5f93", "\u42c6\u613f\ua63d\u3be2\ubba1\u4d0f\u07ac\ud760\u6bff\u8df1", "\uda3f\ude8d",
        30, 60766, 856914418, 1453739395678180564L, -48246L, true, true, (char) 4858, (char) 28271,
        Double.longBitsToDouble(0x3facd27124ceb660L), Double.longBitsToDouble(0x3fe8535a55cd72e6L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 2, "\udaa4\udf51", "\000\u631f\000\u3284\u7461\ua5db\ub2fb\000\000\u2f1c\ubba1", "\ud8f9\udcaf\uda65\udedb",
        -5, -1000, 1900544000, 3145592794723728937L, -65682L, true, false, (char) 43263, (char) 9737,
        Double.longBitsToDouble(0x3fe150ec7397a504L), Double.longBitsToDouble(0x3feb7f5c51eaf484L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 1, 3, "\udb5a\udf4c\udb5e\udd3c\uda3f\udc5c", "\u9ca8\u42ce\u44a3", "\udbbe\udfdf",
        4, -1000, 0, 102254050055424L, -6300L, false, true, (char) 26146, (char) 38530,
        Double.longBitsToDouble(0x3fefdb8a460000a7L), Double.longBitsToDouble(0x3fe6e88c4900005fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 10, 3, "\udad9\ude78\udb5e\udd3c\u0d0e\ud9df\udcd1\udb42\udd6d\udb93\udd68\u5f93", "\u6bca\u73ec\ucd56\u8f60\ubba1\u874a\u07ac\u8eca\u8ce9\u8df1", "\uda3f\ude8d",
        34, 4607, 856914384, 1453739395678180564L, -48246L, true, true, (char) 4858, (char) 28271,
        Double.longBitsToDouble(0x3fd39a4e2099619cL), Double.longBitsToDouble(0x3fe7bb4c7bf2fe55L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 1, 7, "\udad9\ude78\udb5e\udd3c\uda63\udde0\udbf8\udfc0\udb64\uddc8\udbd5\udee6\u5f93\udac8\udc62\ud98f\ude6a\ud932\uddc0\uda1f\ude0b", "\ubbe6\u4d0f\u07ac\ud760\u7525\u0cf7\u884a\uca3c\u951c\u38e6\u865a\uc529\u3830\u11bc\u55ae\u1655\u7b57", "\ud8a9\udef0\uda07\ude84\ud823\ude3c\udb85\uddfd\ud9bd\uddde",
        17, 77003, -708090943, 4251774248818429157L, 12387L, false, true, (char) 39326, (char) 43329,
        Double.longBitsToDouble(0x3fdecf270a3730faL), Double.longBitsToDouble(0x3fd73118a79b16d0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 1, 3, "\udad9\ude78\udb5e\udd3c\ud893\ude95\udb71\udda9\uda80\udf38\udb80\udfb4\u5f93", "\uaa1c\ucf8c\u3510\u8f7c\u5261\u4d0f\ub88f\ud760\ud641\ud0b2\u09d9\uc2fe\u71fe\u93af\ub644\u0878\u3830\u11bc\u55ae\u1655", "\ud961\udc8b\ud8a9\udf02\uda07\ude84\udb66\udedd\ud996\udd47\udb7e\udc6c\udadc\ude97\ucdd8\ud927\udffc\ud958\udd6e\uda57\uddd9\udb50\ude70\uda6c\udeb4\udb99\uddcb\ud95f\udf62\ud913\udd2d\ud960\udd6e\ud81c\uddb9\udafb\udf01\ud9ce\udd44\ud9cf\ude84",
        28, 78215, 1970028090, 5712062249264275000L, -43786L, false, false, (char) 45164, (char) 15116,
        Double.longBitsToDouble(0x3fea6a3251f82f20L), Double.longBitsToDouble(0x3fd46e9e021666deL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 1, 3, "\udad9\ude78\udb5e\udd3c\udb3c\udcda\ud9c4\uddef\ud827\udd26\udb93\udd68\ud807\ude89", "\ubcb9\ucf8c\u6e0f\u8f7c\ubba1\u7c2c\u0829\ud760\u6bff\u8df1", "\uda3f\ude8d",
        47, 96597, 51608030, 1453739739275564244L, 22311L, false, true, (char) 1666, (char) 43591,
        Double.longBitsToDouble(0x3fecf35a218342f3L), Double.longBitsToDouble(0x3fec846af13ef1f5L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 0, 7, "\udad9\ude78\udb5e\udd3c\uda63\ude5c\ud856\udd24\u6e05\ud89e\udc4b\u5f93", "\uaa64\u7fe9\u0098\u8f7c\ubba1\u4d0f\u07ac\u341f\ucd66\u45eb", "\ud98b\udcf6",
        -2, 1005, 856914418, 1453739395678180564L, -48246L, true, true, (char) 4858, (char) 27847,
        Double.longBitsToDouble(0x3facd27104ceb660L), Double.longBitsToDouble(0x3fdb0399b7e5fcaaL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|deserializeSetAndReturn|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|deserializeAndSet|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|getAnnotation|java.lang.Class|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|getMember||new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|set|java.lang.Object,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|setAndReturn|java.lang.Object,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|withName|com.fasterxml.jackson.databind.PropertyName|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|withValueDeserializer|com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "C|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|<init>|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty,com.fasterxml.jackson.databind.PropertyName",
    "C|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|<init>|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty,com.fasterxml.jackson.databind.JsonDeserializer",
    "C|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|<init>|com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
    "M|com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty|deserializeSetAndReturn|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty:com.fasterxml.jackson.databind.deser.impl.ObjectIdReader,com.fasterxml.jackson.databind.PropertyMetadata",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
