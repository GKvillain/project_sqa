package com.fasterxml.jackson.databind.type;
import org.junit.Test;
import static org.junit.Assert.*;
public class SimpleType_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 13, "\udbf3\udf1b", "\u4880\u5887\u5f99\u4482\u514ff\ua2fd\u3e4b", "\udaa5\udca9\ud99b\udd57\ud867\udc3b\u2414",
        15, 3581, 1941984432, 2897715101428534375L, -5340L, false, false, (char) 9996, (char) 51677,
        Double.longBitsToDouble(0x3f9db3429f7f7f60L), Double.longBitsToDouble(0x3fd182e973fe04d2L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 15, 13, "\udbf3\udf1b", "\u4880\u5887\u5f99\u4482\u514ff\ua2fd\u3e4b", "\udaa5\udca9\ud99b\udd57\ud867\udc3b\u2414",
        -5, 3480, 1941984432, 2897715101428534375L, -5340L, false, false, (char) 9996, (char) 51677,
        Double.longBitsToDouble(0x3f9db3429f7f7f60L), Double.longBitsToDouble(0x3fd182e973fe04d2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 15, 13, "\udbf3\udf1b\ud921\udf90\ud8fe\udc14", "\u5f99\u4482\u514ff\ua2fd\ua271\u1cba\ub511\ucc97\ub96c\u86d4\u0d74\u3bfb\u90bb\u5de0\u5831\ub665\u0cbe\u3155\u3af1\u953c\u9a2d\uc504\u78fd\u275a\uac33\u5ff4\uc9bf\uaa87\u05e3\u5131\uc649\u109a\ud53a\u353c\u34c7\u309c\u7307\u0152\u51cc\u5b1c", "\ud84b\ude04\ud980\udda9\ud9d7\udfa8\ud9d1\udfdb\uda68\ude8e\ud93c\udfbe\ud933\udc66\ud8cd\ude31\udbc0\udde8\ud8bc\udfa1\ud9bd\udfdb\udb49\udc97",
        29, 95754, 1028998827, 1969932461545523229L, -96948L, false, false, (char) 1527, (char) 62791,
        Double.longBitsToDouble(0x3fe27633b01bc1cbL), Double.longBitsToDouble(0x3febd24d6841e243L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 13, "\uda68\udd95", "\u4880", "\ud8ea\udf1e\ud8ac\udf5a\ud8dc\udfc6\ud80a\udcba\udad9\udea3\udafb\udf44\udb75\udd2c\udaa5\udca9\ud99b\udd57\ud867\udc0f\u2414\udae7\udeff\ud1c8\ud8fc\udf82\udaae\udee6\ud8b9\udf49\u6f85\udb0a\udef2\uda23\udf43\ud883\udeb6\ud8e3\ude78\udab6\udd76\ud8bb\udf6c\ud970\udfe0",
        38, 99504, 1804472831, -4382754830018404720L, -41508L, false, false, (char) 49420, (char) 8257,
        Double.longBitsToDouble(0x3fbcb304604f8d48L), Double.longBitsToDouble(0x3fc4a297602b6e74L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.List]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 3, "\udbf3\udf1b", "\u8997\u9df5\ua2ed\u4482\ube91\u25e2\ucc31\ua480\ud649\ub4e5", "\uda08\udd06\uda6a\udf43\ud8a6\ude26\ud976\udf65\udbad\udcc0\ud80f\udcf7\udb88\ude5a\ud930\udd54\ud9d2\uddbb\ud89d\udf43\ud961\udc06\ud92e\udf3b\udbb0\udd7a",
        46, 72469, 781694203, 173948339852284415L, 6267L, false, true, (char) 6366, (char) 38992,
        Double.longBitsToDouble(0x3fbe9eedeace0f80L), Double.longBitsToDouble(0x3fe9ad00c9bc81ceL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 15, 13, "\udbf3\udf1b", "\u4880\u5887\u5f99\u4482\u514ff\ua2fd\u3e4b\u1cba\ub511\ucc97\ub96c\ub9ce\u0d74\u3bfb\u9e4f", "\ud8b9\udf49\ud86c\udfcd\udb0a\udef2\uda23\udf43\ud883\udeb6\ud8e3\ude78\udab6\udd76\ud8bb\udf6c\ud9d2\udc90\udbab\udfb9\ud989\udd3c\ud9b7\udd58\ud888\ude04\udb7f\udd60\ud8d9\udcb0\ud87a\ude16\ud8d6\ude92\ud825\udcb4\ud910\ude5a\udad0\udc83\udb6d\ude6c\udb03\udff0\ucf00\udb67\udf6f\ud8ad\udd6b\ud865\udd3b\uda5c\ude70",
        23, 70218, 1907795808, -379063242858389146L, 30864L, true, true, (char) 28092, (char) 27878,
        Double.longBitsToDouble(0x3fda33bf05eba73aL), Double.longBitsToDouble(0x3fe479a53b127945L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 13, "\udbf3\udf1b", "\u2e8c\u5887\u5f99\u4482\u514ff\ua2fd", "\udb75\udd2c\uda48\udd9c\ud99b\udd57\ud867\udc3b\u2414\udae7\udeff\ud1c8\ud8fc\udf82\udaae\udee6\ud8b9\udf49\ud86c\udfcd\udb0a\udef2\uda23\udf43\ud883\udeb6\ud8e3\ude78\udab6\udd76\ud8bb\udf6c",
        -1, 54203, 40500504, -8610862701399688400L, 62183L, true, false, (char) 42934, (char) 8170,
        Double.longBitsToDouble(0x3f90bc3b7339ab00L), Double.longBitsToDouble(0x3fe5c4a8b9ef3de8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.String]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 14, "\udaf0\ude59\ud87d\udf87\uda1e\ude6d\ud9d3\udeb4\uda0d\udf86\uda2a\udd2d\uda25\udfea\ud8ac\udf5a\u4181\udbb5\udd2a\uda7b\udd07\udaf2\ude41\ud848\udd16\udaa5\udcd0\udbb8\ude06\udaf1\udd7c\ud880\udce5\udad8\udd38", "\uc3d5\ubc38\u0ca7\u3155\u667e\u9536\u9a2d\u166f\ud6d4\u8c15\uce74\u2cfa\u1888\u726e\u4423\u2dd5", "\uda0a\ude00\ud83b\udd5e\ud873\udc2e\ud9ac\udcc5",
        0, 42120, -1258710059, -631291125713346763L, 40131L, true, true, (char) 17939, (char) 1202,
        Double.longBitsToDouble(0x3fe03c0ed095a66cL), Double.longBitsToDouble(0x3fe0dfa640405103L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Thread$State]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 15, 13, "\udbe6\ude53", "\u4880\u5887\u5f99\u4482\u514ff\ua2fd\u3e4b", "\udaa5\udca9",
        53, 60476, -1767058871, -7345270123660940732L, 80360L, true, false, (char) 41075, (char) 21929,
        Double.longBitsToDouble(0x3fedcb48e4c26484L), Double.longBitsToDouble(0x3fc1ca7db93662fcL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Long]\012",
        Z.run(T, 1, 3, 15, 13, "\udbf3\udf1b", "\u4880\u5887\u5f99\u4482\u514ff\ua2fd\u3e4b\u1cba", "\ud99b\udd57\ud867\udc3b",
        54, -1000, 1533588480, 8340759625455812744L, -71451L, true, false, (char) 40003, (char) 44507,
        Double.longBitsToDouble(0x3fc1ca7db93662fcL), Double.longBitsToDouble(0x3fef956f5c1db342L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Object]\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Object]\012",
        Z.run(T, 2, 2, 3, 4, "\udbf3\udf1b\ud921\udf90\ud8fe\udc14", "\u5f99\u4482\u514ff\ub675\u1e58\u0883\ub511\ucc97\ub96c\u86d4\u0d74\u3bfb\u90bb\u5de0\u5831\ub665\u0cbe\u3155\u3af1\u953c\u9a2d\uc504\u98b2\u3976\uac33\u5ff4\uc9bf\u2639\u05e3\u5131\u00a8\u7ce1\ud53a\ua472\u34c7\u309c\u7307\u0152\u51cc\u5b1c\ucaee", "\ud980\udda9\ud9d7\udfa8\ud9d1\udfdb\udbbb\ude5f\ud93c\udfd4",
        31, 56342, -1144377874, -1756565411234425689L, 49915L, false, true, (char) 19007, (char) 55624,
        Double.longBitsToDouble(0x3f9d1b56a39f3dc0L), Double.longBitsToDouble(0x3fc79b401ce30860L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.List]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 8, 3, "\udbeb\udc9e", "\u8997\u9df5\ua2ed\u4482\ube91\u25e2\ucc31\ua480\u74ce\u2ab0", "\uda08\udd06\uda33\uddc8\ud8e3\udd43\ud976\udf65",
        46, 16576, -1591484430, 9033545690036918879L, 79145L, false, true, (char) 58569, (char) 3825,
        Double.longBitsToDouble(0x3f9d57439f7f7f60L), Double.longBitsToDouble(0x3fd182e973fe04d2L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.Date]\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.Date]\012",
        Z.run(T, 2, 2, 2, 3, "\udbf3\udf1b\ud99d\udde9\udab7\uddd1\ud8e6\udd34", "\u4482\ube91\u25e2\ucc31", "\udb75\udd00\udaa5\udca9\ud8c1\udc0c\uda08\udd06\uda6a\udf43\ud8a6\ude26\ud976\udf65\udbad\udcc0\ud9e1\udf5f\udb88\ude5a\ud930\udd54\ud9d2\uddbb\ud89d\udf43\udb6c\ude7b\ud9e5\udda0\udbb0\udd7a\ud9f9\udc32\ud970\udfe0\udbab\udfb9\uda5f\udf9c\udbaa\udc10\udb6b\udcd7",
        38, 13298, 796942844, 8914649249706182778L, -469L, false, true, (char) 31697, (char) 15871,
        Double.longBitsToDouble(0x3fe12901b72ccc89L), Double.longBitsToDouble(0x3fe1d9113bdfd71dL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.List]\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.List]\012",
        Z.run(T, 2, 3, 3, 3, "\udbf3\udf1b", "\u9e55\u2c9a\u48f5\u4482\ube91\u25e2\ucc31\ua480\u85e7\ub4e5", "\uda08\udd06\uda6a\udf43\ud8a6\ude26\ud976\udf65\udbad\udcc0\ud80f\udcf7\udb88\ude5a\ud930\udd54\ud9d2\uddbb\ud95d\udd82\ud9e0\ude13\uea52\udbb0\udd7a",
        46, 72469, 779282939, 173948341796339382L, 6267L, false, false, (char) 6383, (char) 38992,
        Double.longBitsToDouble(0x3fbe9eedeace0f80L), Double.longBitsToDouble(0x3fe9ad00cac581ceL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Long]\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Long]\012",
        Z.run(T, 2, 2, 2, 3, "\ud8c0\ude23\u1f46\udab7\uddd1\ud8e6\udd34\ud90f\udd00\udb55\udcb8\ud8ea\udf1e\ud8d3\udc51\ud91c\udd41\uda61\uddf5\ud866\udffb\ud8d7\udc8c\udb25\udc79\udaa5\udca9", "\u65f9\u3a55\u6f05\ucf04", "\ud849\udea2\ud8d9\udf50\ud9a6\ude6e\udb6c\ude7b\ud9e5\udda0\ud862\udcf3\ud9f9\udcdc\ud970\udfe0\udbab\udfb9\uda5f\udf9c\udbaa\udc10\udbad\ude45\udaac\udc32\udb84\udefa\uda73\udcc8\ud9a4\udd8d",
        12, 73417, -2117174475, 158173252826134944L, 16261L, false, true, (char) 51297, (char) 29436,
        Double.longBitsToDouble(0x3fdf87649abd126eL), Double.longBitsToDouble(0x3fecec3359c8e95aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 13, "\udbf3\udf1b", "\u4880\u5887\u5f99\u4482\u514ff\ua2fd\u3e4b", "\udaa5\udca9\ud99b\udd57\ud867\udc3b\u2414",
        15, 87563, 1941984432, 2897715101428534375L, -5340L, false, false, (char) 9996, (char) 51677,
        Double.longBitsToDouble(0x3f9db3429f7f7f60L), Double.longBitsToDouble(0x3fde82e973fe04d2L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.type.SimpleType|_narrow|java.lang.Class|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|buildCanonicalName||new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|construct|java.lang.Class|static",
    "M|com.fasterxml.jackson.databind.type.SimpleType|constructUnsafe|java.lang.Class|static",
    "M|com.fasterxml.jackson.databind.type.SimpleType|equals|java.lang.Object|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|getErasedSignature|java.lang.StringBuilder|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|getGenericSignature|java.lang.StringBuilder|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|isContainerType||new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|refine|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|toString||new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|withContentType|com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|withContentTypeHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|withContentValueHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|withStaticTyping||new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|withTypeHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|withValueHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|_narrow|java.lang.Class|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
