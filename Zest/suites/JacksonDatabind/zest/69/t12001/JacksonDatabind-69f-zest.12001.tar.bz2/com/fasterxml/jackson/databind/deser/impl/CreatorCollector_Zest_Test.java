package com.fasterxml.jackson.databind.deser.impl;
import org.junit.Test;
import static org.junit.Assert.*;
public class CreatorCollector_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 1, "\uda2e\udc8b\udbfc\udcdd\u22c5\ud9db\ude6e", "\u501e\u1475\ub072\u1514\u8dab\u96db\u625f\ud7ed\u65c9\u6c52", "\uda41\udec6\ud981\udea5\udb8a\ude2c\ud8f0\udef8\udbed\udeac\ud9e4\udc81\uda90\udce7\udab1\udfe0\ud854\udeb8\ud8c0\udf52\ud872\udfe0\udbe7\udd1b\ud839\udc9d\ud9a2\uddfa",
        5, 41387, -1226645640, 3816567377884038366L, 91645L, false, false, (char) 60678, (char) 7540,
        Double.longBitsToDouble(0x3feacbf36e708940L), Double.longBitsToDouble(0x3fd4ae2ef468afe0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 1, "\ud941\udf34\udbfc\udcdd\u22c5\udafa\udee0", "\uba11\u8e0a\ub072\ubdf2", "\ucb67\uda39\udcb4\ud858\ude6c\ud85a\udea0\uda7d\udcd9\udb4c\udd80\ud993\udd7e",
        -3, 27680, -2068127172, -2940057741348748519L, 50124L, false, false, (char) 43484, (char) 11361,
        Double.longBitsToDouble(0x3fe326868ff32e21L), Double.longBitsToDouble(0x3fc809e4d7fc535cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 6, 1, "\uda2e\udc8b\udbfc\udcdd\u22c5\ud9db\ude6e", "\u501e\u1475\ubc9f\u1521\u8dab\u96db\u625f\ud7ed\u65c9\u6c52", "\uda41\udec6\ud981\udea5\udb8a\ude2c\ud8f0\udef8\udbed\udeac\ud9e4\udc81\uda90\udce7\udab1\udfe0\ud854\udeb8\ud8c0\udf52\ud872\udfe0\udbe7\udd1b\ud839\udc9d\ud9a2\uddfa",
        5, 41387, -1226645640, 3816567377884038366L, 91645L, false, false, (char) 60678, (char) 7540,
        Double.longBitsToDouble(0x3feacbf36e708940L), Double.longBitsToDouble(0x3fd4ae2ef468afe0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 4, 1, "\uda2e\udecb\udbfc\udcdd\u22c5\ud9db\ude6e", "\u501e\u8c74\u2d6a\ub2ba\u74f5\u09b9\u68fa\ud7ed\u65c9\u6c52", "\ud87a\udc84\ud98a\udd26\udb8a\ude2c\ud8f0\udef8\uda6f\uddec\ud9e4\udc86\uda90\udce7\udab1\udfe0\ud854\udeb8\ud8c0\udf52\ud885\ude29\udbba\udeed\ud839\udc9d\ud9a2\uddfa",
        5, 41387, -1226645640, 3816567377202952036L, 91645L, false, false, (char) 60678, (char) 55060,
        Double.longBitsToDouble(0x3feacbf2af768940L), Double.longBitsToDouble(0x3fd4ae217c3eb5e0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "", "", "\ud897\udeb0\udb16\udead\uda99\ude03\ua689\000\ud957\udd5f\udbce\udf9f\ud8dc\udf2e",
        -2, 56497, -1379915963, 7785998360695998400L, 62568L, false, false, (char) 21962, (char) 6809,
        Double.longBitsToDouble(0x3fecf2de2c898e19L), Double.longBitsToDouble(0x3e4621f05c000000L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 16, 1, "\udbfd\udc6b\uda74\udf53\uda0e\udc53\udaff\udcca", "\u98b8\u1475\ub072", "\udac1\ude2a\ucb67\uda39\udcb4\ud858\ude6c\udb13\udd9d\ud824\udd97\udbde\udd45\uda41\udec6\ud89a\uddaa",
        46, 48841, -679489264, -2033953469410707545L, -32760L, false, false, (char) 46611, (char) 42666,
        Double.longBitsToDouble(0x3fdff14d70d6bd5eL), Double.longBitsToDouble(0x3febc7b50bcfb6e2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 6, 1, "\uda38\udf54\udbfc\udcdd\u22c5\ud9db\ude6e", "\u501e\u1475\u3ece\u01d2\u8dab\u96db\u625f\ud7ed\u65c9\u6c52", "\uda41\udec6\ud981\udea5\udb8a\ude2c\ud8f0\udef8\udbed\udeac\udaf0\udfe8\uda90\udce7\udab1\udfe0\ud854\udeb8\ud8c0\udf52\ud872\udfe0\udbe7\udd1b\ud839\udc9d\ud9a2\uddfa",
        5, 7515, -532135548, 3816567377884038366L, 91645L, false, false, (char) 60678, (char) 7540,
        Double.longBitsToDouble(0x3fe6c2eccf6536edL), Double.longBitsToDouble(0x3fd4ae231468afe0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 1, "\ud958\ude09\u368c\u22c5\ud9db\ude6e\ud897\udeb0\udb16\udead\udaf1\udc6a\udbb4\udc4d\ud883\uddf0\ud957\uddf5\udbce\udf9f\ud8dc\udf2e\ucb67\uda39\udcb4\ud858\ude6c\ud85a\udea0\uda7d\udcdd\udbde\udd12\ud8a8\udee6\ud9fd\ude97\udb8a\udd3c\udba4\udef2\udbed\udeac\ud9be\udcc0\ud8fb\udcfa\ud87b\udc2a\ud848\ude51\ud8c0\udf52\ud872\udfe0\udbdf\ude28\ud856\udd0c\udb48\udda8\ud9b0\udf74\uda6b\udfdd\udbd8\udf28", "\u65f6\ud77f\ua7a4", "\ud87e\udef3\ud9f0\udc6e\udab4\ude78\ud84d\udced\udba7\udeb0\udb65\udc09\uda90\udd11\udad2\ude80\ud88e\udf69\udad2\udcee\ud8ed\udcc9\udb4c\udefc\uda27\udc33\ud830\udf29\ud91f\udc6a\ud80c\udf35\uda3d\udcd1\udb73\udfc9\udb4f\udc57\udb2a\udf94",
        6, 32095, -1141345455, 3937745010138789795L, 28245L, true, false, (char) 56254, (char) 36087,
        Double.longBitsToDouble(0x3fe333e06615aeffL), Double.longBitsToDouble(0x3fdeddf57fe1548eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addDelegatingCreator|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,boolean,[Lcom.fasterxml.jackson.databind.deser.SettableBeanProperty;|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addDelegatingCreator|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,[Lcom.fasterxml.jackson.databind.deser.CreatorProperty;|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addPropertyCreator|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,boolean,[Lcom.fasterxml.jackson.databind.deser.SettableBeanProperty;|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addPropertyCreator|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,[Lcom.fasterxml.jackson.databind.deser.CreatorProperty;|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|verifyNonDup|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,int,boolean|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|_computeDelegateType|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,[Lcom.fasterxml.jackson.databind.deser.SettableBeanProperty;|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|_fixAccess|com.fasterxml.jackson.databind.introspect.AnnotatedMember|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addBooleanCreator|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addBooleanCreator|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,boolean|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addDoubleCreator|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addDoubleCreator|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,boolean|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addIncompeteParameter|com.fasterxml.jackson.databind.introspect.AnnotatedParameter|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addIntCreator|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addIntCreator|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,boolean|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addLongCreator|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addLongCreator|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,boolean|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addDelegatingCreator|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,boolean,[Lcom.fasterxml.jackson.databind.deser.SettableBeanProperty;|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addDelegatingCreator|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,[Lcom.fasterxml.jackson.databind.deser.CreatorProperty;|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addPropertyCreator|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,boolean,[Lcom.fasterxml.jackson.databind.deser.SettableBeanProperty;|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|addPropertyCreator|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,[Lcom.fasterxml.jackson.databind.deser.CreatorProperty;|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
    "M|com.fasterxml.jackson.databind.deser.impl.CreatorCollector|verifyNonDup|com.fasterxml.jackson.databind.introspect.AnnotatedWithParams,int,boolean|new:com.fasterxml.jackson.databind.deser.impl.CreatorCollector:com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.cfg.MapperConfig",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
