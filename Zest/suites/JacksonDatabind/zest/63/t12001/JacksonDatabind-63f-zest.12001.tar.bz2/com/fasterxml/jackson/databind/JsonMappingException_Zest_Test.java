package com.fasterxml.jackson.databind;
import org.junit.Test;
import static org.junit.Assert.*;
public class JsonMappingException_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 2, 4, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\u62f0\uc747\u7168\u9a98\u2352\uaf44\u1f23\u75ad\uc7a6\u6405\uc45b\u3fc6\u0baa\u59ff", "\udbe4\udcbc\ud85b\udf15\ud8f6\udc4f\ud9f6\uddd0\ud9aa\uddbf\udaa3\udec3\uda07\uddc4\uda43\udd4d\uda66\udc83",
        15, 55780, -755868628, 3583784145071815068L, 55237L, false, false, (char) 29947, (char) 54519,
        Double.longBitsToDouble(0x3fd10df92d17102eL), Double.longBitsToDouble(0x3fe192aa517d6e2dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 2, 4, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\ucb85\ucd99\u7168\u9a98\u2352\u0157\u1f23\u75ad\uc7a6\u6405\uc45b\u3fc6\u0baa\u59ff", "\udbe4\udcbc\ud85b\udf15\ud8f6\udc4f\ud9f6\uddd0\ud9aa\uddbf\udaa3\udec3\uda07\uddc4\uda43\udd4d\uda66\udc83",
        15, 55780, -755868628, 3583784145071815068L, 55237L, false, false, (char) 29947, (char) 54519,
        Double.longBitsToDouble(0x3fd10df9232f622eL), Double.longBitsToDouble(0x3fdccff9a2fadd9aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 14, 12, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\u62f0\uc747\u7168\u9a98\u2352\ua508\uac77\u75ad\uc7a6\u6405\uc45b\u944f\ub1cd\u59ff", "\udbe4\udcbc\ud85b\udf15\ud8f6\udc4f\ud9f6\uddd0\ud9aa\uddbf\udaa3\udec3\uda07\uddc4\uda43\udd4d\uda66\udc83",
        15, 55780, -755868628, 3583784145071815068L, 55237L, false, false, (char) 29947, (char) 54519,
        Double.longBitsToDouble(0x3fd10df92d17102eL), Double.longBitsToDouble(0x3fe192aa517d6e2dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 2, 4, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\uda3e\uddba", "\u62f0\uc747\u7168\u9a98\u2356\uaf44\u1f23\u75ad\ud569\u6485", "\udaf8\udef5\ud874\udd0e\udad3\udcaa\udbbe\ude0c\uda75\udf05\ud85b\udf15\ud8f6\udc4f\ud9f6\uddd0\ud9aa\uddbf\udaa3\udec3\uda07\uddc4\uda43\udd4d\uda66\udc83\udae4\ude07\udb30\udef5\ud908\udd84\ud928\udf9f\udbe1\udcd4\udb3f\udc75\ud9e3\udc29\ud93e\udfc6\ud945\udc44\ud9a0\udcc9\udac9\ude79",
        -1, 93833, -1854101123, -8568700519374388134L, -87101L, true, false, (char) 29806, (char) 209,
        Double.longBitsToDouble(0x3fe3e00233b3c170L), Double.longBitsToDouble(0x3fedf2aefdb8be01L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \uda43\udf52\uda31\ude40\ud9b6\udf0e\udaed\ude0d\012",
        Z.run(T, 1, 3, 2, 2, "\uda43\udf52\uda31\ude40\ud9b6\udf0e\udaed\ude0d", "\u62f0\uc747\u7168\u9a98\u2352\uaf44\u1f23\u75ad\uc7a6\u5705\uc45b\u498d\u152d\u59ff", "\udbe4\udcbc\ud85b\udf15\ud8f6\udc4f\ud9f6\uddd0\ud9aa\uddbf\udaa3\udec3\uda07\uddc4\uda43\udd4d\uda66\udc9a",
        15, 55780, -755868628, 3583784146262997404L, -97756L, false, false, (char) 34571, (char) 10723,
        Double.longBitsToDouble(0x3fd10df92c727e2eL), Double.longBitsToDouble(0x3fe192ad427d6e2dL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 12, 4, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\ud475\u609f\u7168\u9a98\u2352\uaf44\u1f23\u18bb\uc7a6\u4305\uc45b\u3fc6\u0baa\u59ff\uce4c\ua08f\ua0d9\u3992\u2822\u0cf8\u33ff\u830f\u6129\u935b\ub618\ub883\u5a5f\u36c6\u33a3\u526b\u058e\u8263\u58a8\uc452\u609e\ua6f1\u1ba1\u38c7\ub484\ub732\u34cc\u7441\u668d\u649c\u6f8b\ub2eb\ub2e2\ub586\ud405\u2496\u7733\ubcc5\u0d96\u89f6", "\uda19\ude7f\ud935\ude66\udafc\udccd\udb23\udf4b\ud99b\udf6a\uda9a\udfc5\ud854\udf7a\ud8e1\udfbf\udb06\uddaa\udae9\udfa5\ud9a8\udfd3\ud97e\udc8d\ud87b\ude6f\uda00\udd4c\udb79\udf02\udac9\udcde\ud9f1\udc2d\uda42\udf9c\ud922\udd5e\u60e3\ud9b1\udedd\ud82b\udc74\ud8df\udd64\ud8ba\udc6b\ud9da\udd4e\ud809\udd20",
        3, 88030, 119937267, -8647498133819094822L, 88480L, true, false, (char) 9643, (char) 23102,
        Double.longBitsToDouble(0x3fe9bd1b6785934bL), Double.longBitsToDouble(0x3fcfdbaddc56a618L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\udb4b\udf56\udb11\ude8f\udb3a\ude59\ud940\udd77 |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\udb11\ude8f\udb3a\ude59\ud940\udd77\012",
        Z.run(T, 1, 12, 3, 4, "\udb4b\udf56\udb11\ude8f\udb3a\ude59\ud940\udd77", "\u62f0\uc747\uc296\u9a98\u2352\uaf44\u1f23\ubfad\uc7a6\u6405\uc45b\u3fc6\u0baa\u59ff", "\udbe4\udcbc\ud85b\udf15\ud8f6\udc4f",
        3, 51531, 898190236, -5924799095373859909L, 76993L, false, true, (char) 19826, (char) 64419,
        Double.longBitsToDouble(0x3fd9c31bc7f86d5cL), Double.longBitsToDouble(0x3fe328409f3c61deL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\uda4b\udf40\udab1\udf98\udb23\ude95\0121=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\uda4b\udf40\udab1\udf98\udb23\ude95\012",
        Z.run(T, 2, 13, 4, 4, "\udb4b\udf56\uda4b\udf40\udab1\udf98\udb23\ude95", "\u3e6f\uc747\u51c6\u7ea7\ube98\ub969\u3480\u4f4d\ubbb0\u54bc\u8674\u3fc6\u0baa\u59ff", "\udbe4\udcbc\ud89d\udfe4\uda54\udeef\ud80d\udf81\ud9aa\udd03\udbc8\udd8b\uda7b\udf05\udaaa\udd4f\uda66\udc83",
        12, 42500, -767424206, 3583784145071815161L, 55237L, false, false, (char) 29947, (char) 11114,
        Double.longBitsToDouble(0x3fd10df92d17102eL), Double.longBitsToDouble(0x3fdf45dea322b39aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 8, 3, "\ud856\uddaa\ud9b7\udfff\ud9ac\udebb\udbea\ude99\uda9e\udf64\ud98a\uddcd\u0733\udbf6\ude73\uc1ab\uda17\udd1e\ud894\udd2f\udb7f\udfda\ud8e2\ude5c\ud8e8\udc0b\udbdf\udd98\u948d\ud892\udcb8\udb28\udda5\udaf8\ude1f\udab2\udccf\udac9\ude1d\ud9d6\udf4a\udbe4\udc23", "\u0c95\u8f5e\u6209\u6129\u903b\ub32d\ub883\ua38a\u36c6", "\udbbc\udc05",
        54, 59156, -840323152, -2336797501952684784L, -6254L, true, false, (char) 54583, (char) 47628,
        Double.longBitsToDouble(0x3fedd70fa61da8f9L), Double.longBitsToDouble(0x3fecbda75266e5ffL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77\012",
        Z.run(T, 1, 2, 2, 4, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\u62f0\uc747\u7168\u9a98\u2352\uaf44\u1f23\u75ad\uc7a6\u6405\uc45b\u3fc6\u0baa\u59ff", "\udbe4\udcbc\ud85b\udf15\ud914\udd27\ud9f6\uddd0\ud9aa\uddbf\udaa3\udec3\uda07\uddc4\uda43\udd4d\uda66\udc83",
        42, 56326, -755868628, 3583784145071815068L, 55237L, false, false, (char) 29973, (char) 54519,
        Double.longBitsToDouble(0x3fd10df925b7102eL), Double.longBitsToDouble(0x3fe19648b17d6e2dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\000 |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \ucc2b\000\000\000\012",
        Z.run(T, 1, 0, 0, 1, "\ucc2b\000\000\000", "\000", "\uda05\udc01\ud98d\udf70\udb7f\udff7\ud8e2\uddff\ud99d\udfa5\u743b\ud801\udc28\uda12\udcdd\ud816\udd6a\udac6\udf02",
        40, 4592, -826563852, -6070766861573055268L, -69084L, false, false, (char) 23452, (char) 13705,
        Double.longBitsToDouble(0x3fedd80000a41aafL), Double.longBitsToDouble(0x3fc3ffbb4f535024L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:\ud92b\udd29\udb04\udfa6\ud9b6\udf0e\ud940\udd77 |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \ud92b\udd29\udb04\udfa6\ud9b6\udf0e\ud940\udd77\012",
        Z.run(T, 1, 11, 14, 2, "\ud92b\udd29\udb04\udfa6\ud9b6\udf0e\ud940\udd77", "\u62f0\uc747\u0984\ud58d\u34fa\u249e\u36d2\u75ad\uc7a6\u6405\u224a\u2401\ubde9\ub61a", "\udbe4\udcbc",
        53, 86421, -1978894140, -3637500253247118658L, -15687L, true, false, (char) 28282, (char) 54720,
        Double.longBitsToDouble(0x3fa678a28b1d2f20L), Double.longBitsToDouble(0x3fe591bde0473f9dL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 2, 4, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\u62f0\uc747\u6ca2\u9a98\u2352\uaf44\u1f23\u75ad\u2e2c\u6405\uc45b\u3fc6\u0baa\u59ff", "\udbe4\udcbc\ud85b\udf15\ud8f6\udc4f\ud9f6\uddd0\ud9aa\uddbf\udaa3\udec3\uda07\uddc4\uda43\udd4d\uda9e\udc31",
        37, 55582, -755868628, 3583784145071815068L, 55237L, false, false, (char) 29947, (char) 54519,
        Double.longBitsToDouble(0x3fd10df92d17102eL), Double.longBitsToDouble(0x3fe192aa517d6ec7L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 14, 12, "\udb33\udc34", "\uccd3\uabc2\u6f7a\ua8dc\ud5c8\u713a\uc5da\uc003\uc4a5\u2666\u75ad\u55e1\u687a\uc45b\u3fc6\u01a9\u7dfe\uce4c\ua08f\ub1d9\u3992\u2822", "\ud8f1\udd4b\udb12\udfe9\uda69\udd26\udb33\udeae\udae4\ude5d\udb30\udef5\ud908\udd84",
        14, 90713, 135474172, 7052177852754279996L, 32878L, true, false, (char) 18172, (char) 50168,
        Double.longBitsToDouble(0x3fd7d6e2d94cc008L), Double.longBitsToDouble(0x3fce502c5a47a520L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77\012",
        Z.run(T, 1, 5, 2, 4, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\u62f0\ua5ea\u9c52\u9a98\u2352\uaf44\u1f23\u75ad\uc7a6\u6405\uc45b\u3fc6\u0baa\u59ff", "\udbe4\udcbc\ud85b\udf15\ud8f6\udc4f\ud9f6\uddd0\ud9aa\uddbf\udaa3\udec3\uda07\uddc4\uda43\udd4d\uda66\udc83",
        15, 55780, -755868628, 3583784145071815068L, 55237L, false, false, (char) 29947, (char) 54519,
        Double.longBitsToDouble(0x3fd10df92d17102eL), Double.longBitsToDouble(0x3fe192aa517d6e2dL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77\012",
        Z.run(T, 1, 14, 1, 8, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\u62f0\ub6c7\u7168\u9a98\u1e48\ucb85\u1f23\u75ad\uc7a6\u6405\uc45b\u3fc6\u0baa\u59ff", "\udbe4\udcbc\ud8b2\udc81\udaa6\udd16\ud9f6\uddd0\ud9aa\uddbf\udaa3\udec3\uda07\uddc4\uda43\udd4d\uda66\udc83",
        15, 55780, -755868628, 3583784145071815068L, 55237L, false, false, (char) 29947, (char) 54519,
        Double.longBitsToDouble(0x3fd10df92d17102eL), Double.longBitsToDouble(0x3fe192aa517d6e2dL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 12, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\u694b\uc747\u7168\u9a98\u2352\uaf44\u1f23\u75ad\uc7a6\u0c05\uc45b\u3fc6\u0baa\u59ff", "\udbe4\udc9d",
        53, 60309, -1978894140, 1167559076172352412L, -64091L, false, false, (char) 19066, (char) 34781,
        Double.longBitsToDouble(0x3fa678a28b1d2f20L), Double.longBitsToDouble(0x3fd9c31bcc68a4a8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb77\udd0f\ud8e9\uddca\udbd9\udc2d\ud801\udfce\uda40\udd6e\udbb4\udd3f\u33ae\ud91b\udde6\ud833\udf5e\udba7\udef7\ud98d\udf70\udb7f\udff7\ud8e2\uddff\ud99d\udfa5\u743b\udb0a\ude4a\0121=java.util.Collections$EmptyList:[] |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb77\udd0f\ud8e9\uddca\udbd9\udc2d\ud801\udfce\uda40\udd6e\udbb4\udd3f\u33ae\ud91b\udde6\ud833\udf5e\udba7\udef7\ud98d\udf70\udb7f\udff7\ud8e2\uddff\ud99d\udfa5\u743b\udb0a\ude4a\012",
        Z.run(T, 2, 13, 13, 13, "\udb77\udd0f\ud8e9\uddca\udbd9\udc2d\ud801\udfce\uda40\udd6e\udbb4\udd3f\u33ae\ud91b\udde6\ud833\udf5e\udba7\udef7\ud98d\udf70\udb7f\udff7\ud8e2\uddff\ud99d\udfa5\u743b\udb0a\ude4a", "\u6005\ua069\uce4c", "\ud8c6\udcc7\ud8f1\udd24",
        45, 51531, 898190236, 9135238058553078715L, 76993L, false, true, (char) 19826, (char) 42659,
        Double.longBitsToDouble(0x3fd9c317f7f86d5cL), Double.longBitsToDouble(0x3fe328409ef4d3deL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 14, 4, "\ud9e4\udda6\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\u62f0\ud46f\uc527\u3e59\u2352\u68d4\u1716\u75cc\uc7a6\u6405\uc45b\u3fc6\u0baa\u59ff", "\udbe4\udcbc\ud85b\udf15\ud8f6\udc4f\ud913\udf1e\ud994\udd7c\udaa3\udec3\uda07\uddc4\uda43\udd4d\ud8eb\udd2f",
        20, 84536, -768174274, 3584006246423472819L, 55237L, false, false, (char) 50853, (char) 54519,
        Double.longBitsToDouble(0x3fd55df92fda77d4L), Double.longBitsToDouble(0x3fe192a9f17d6e2dL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:N/A |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: N/A\012",
        Z.run(T, 1, 1, 2, 4, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\u134e\uc747\u7168\u9a98\u2352\uaf44\u1f23\u75ad\uc7a6\u1e6c\uc45b\u3fc6\u0baa\u59ff", "\udbe4\udcbc\ud85b\udf15\ud8f6\udc4f\ud9f6\uddd0\ud9aa\uddbf\udaa3\udec3\uda07\uddc4\uda43\udd4d\ud81b\udd3d",
        15, 55780, 1869951489, 3583783642560641436L, 55237L, false, false, (char) 29947, (char) 54519,
        Double.longBitsToDouble(0x3fd10dfe2d17102eL), Double.longBitsToDouble(0x3fdf9c77e2fb4458L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: N/A\0121=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: N/A\012",
        Z.run(T, 2, 2, 2, 14, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\udadc\udde4\uda40\udd6e\udbb4\udd3f\ud9a1\uddd8\uda02\udcb6\ud8f5\udce0\uda04\udf5a\ud85e\udeb8\uda7e\udee1\ud91b\udce2\uda4e\ude5d\ud882\udd08", "\u3fc6\u0baa\u0abd\uce4c\ua08f\ub1d9\uc690\uc96c\ub65c\u3407\u830f\u6129\ub1d4", "\udb30\udef5\u788f\ud9ac\udde5\udb34\udfdf\udbd1\udc10\ud9e2\udfc5",
        46, 96848, -544078066, -8640422996285438325L, 1774L, true, false, (char) 53990, (char) 38007,
        Double.longBitsToDouble(0x3fdad3d8135276e0L), Double.longBitsToDouble(0x3fddc1ab06438c50L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 7, 13, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\u62f0\uc747\u9083\u210e\u29e6\ua528\uac77\u75ad\uc7a6\u6405\uc45b\u944f\ub1cd\u59ff", "\udbe4\udcbc\ud85b\udf15\ud8f6\udc4f\udb5e\udee3\ud9c4\udc19\ud9b9\udfcf\uda07\ude13\uda43\udd4d\uda66\udc83",
        15, 55780, -755868628, 819148547732319448L, 55275L, false, false, (char) 2300, (char) 54519,
        Double.longBitsToDouble(0x3fd10df92d17102eL), Double.longBitsToDouble(0x3fe192aa517d6e2dL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf8a\uda31\ude40\ud9b6\udf0e\0121=void |a0=java.lang.StringBuilder:\udb4b\udf8a\uda31\ude40\ud9b6\udf0e |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf8a\uda31\ude40\ud9b6\udf0e\012",
        Z.run(T, 2, 14, 0, 12, "\udb4b\udf8a\uda31\ude40\ud9b6\udf0e", "\u4c01\u62f0\uc747\u7168\u80df\u417a", "\ud9b8\udc82\ud90a\udf50\ud911\uddb0\uda12\udcdd\ua820\ud89b\udca3\ud874\uddb1\udad3\udcaa\udada\udc0c\udbe4\udcbc\ud85b\udf15\ud8f6\udc4f\ud9f6\uddd0\ud9aa\uddbf\udaa3\udec3\uda07\uddc4\uda43\udd4d",
        46, 41327, -247090220, -3246431036497975119L, -72158L, true, false, (char) 8218, (char) 32763,
        Double.longBitsToDouble(0x3fe8766f4d10df92L), Double.longBitsToDouble(0x3fe45c40be32554aL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: N/A\012",
        Z.run(T, 1, 0, 11, 2, "\ud98b\ude1a\udaf5\udc87\ud9eb\udf17\ud940\udd77", "\u4415\uae00\u71e7\u7cc9\u049e\u4ad2\u1329\u10cc", "\uda12\udcdd\ud97d\ude2a\udafd\udf8c\uda78\udc33\ud974\udd26\uda48\udfd5\udbcb\uddce\ud86c\ude09\uda35\udff4\ud803\udd18",
        6, 97236, 600892061, 1892759436969810084L, -83192L, false, true, (char) 54519, (char) 60578,
        Double.longBitsToDouble(0x3fec5c40b9bf7142L), Double.longBitsToDouble(0x3fe3947d604c0b79L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 6, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\uda3e\uddba", "\u62f0\uc747\u7168\u9a98\u2356\uaf44\u1f23\u75ad\ud569\u6485", "\ud859\ude22\ud874\udd0e\udad3\udcaa\udbbe\ude0c\uda75\udf05\ud85b\udf15\ud8f6\udc4f\ud9f6\uddd0\ud9aa\uddbf\udaa3\udec3\uda07\uddc4\uda43\udd4d\uda66\udc83\udae4\ude07\udb30\udef5\ud908\udd84\ud928\udf9f\udbe1\udcd4\udb3f\udc75\ud9e3\udc29\ud93e\udfc6\ud945\udc44\ud9a0\udcc9\udac9\ude79",
        -1, 93833, -1854101123, -8568700519374388134L, -87101L, true, false, (char) 29806, (char) 209,
        Double.longBitsToDouble(0x3fe3e00233b3c170L), Double.longBitsToDouble(0x3fedf2aefdb8be01L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 12, 4, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\u35c6\u4048\u3993\u9a98\u2352\u3561\u0ab8\u2adc\u498f\u4305\u501f\u059b\u0baa\u59ff\uce4c\u1973\ua06f\u3992\u2822\u0cf8\u33ff\u830f\u6129\u935b\ub618\ub883\u5a5f\u36c6\u33a3\u526b\u058e\u8263\u58a8\uc452\u609e\ua6f1\u406e\u22ff\ub484\ub732\u34cc\u7441\u668d\u649c\u6f8b\ub2eb\ub2e2\ub586\ud405\u83f2\u7733\ubcc5\u0d96\uab26", "\uda19\ude7f\ud8f7\udc06\udafc\udd52\udb23\udf4b\ud99b\udf6a",
        53, 94298, -74213374, -579026859933760241L, -70528L, true, false, (char) 42816, (char) 11303,
        Double.longBitsToDouble(0x3fd76023e93a51c0L), Double.longBitsToDouble(0x3fc43f1399eeab74L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77 |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77\0121=java.lang.String:\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77 |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77\012",
        Z.run(T, 2, 12, 12, 4, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\ud475\u609f\u7168\u9a98\u2352\uaf44\u2705\ucf0b\uc7a6\u4305\uc45b\u3fc6\u0baa\u59ff\uce4c\ua08f\ua0d9\u3992\u2822\u0cf8\u33ff\u830f\u4b13\u8403\u398d\u00a1\u5a5f\u36c6\u33a3\u526b\u65d9\u8263\u58a8\uc452\u609e\ua6f1\u1ba1\uc937\uaca1\ub732\u34cc\u743b\u668d\u649c\u6f8b\ub2eb\ub2e2\u8e06\u95be\u2496\u7733\ubcc5\u0d96\u89f6", "\uda19\ude7f\ud935\ude66\udafc\udccd\udb23\udf4b\ud99b\udf6a\uda9a\udfc5\ud854\udf7a\ud8e1\udfbf\udb06\uddaa\udae9\udfa5\ud9a8\udfd3\ud97e\udc8d\ud87b\ude6f\uda00\udd4c\udb79\udf02\udac9\udcde\ud9f1\udc2d\uda42\udf9c\ud922\udd5e\u60e3\udbac\udd95\ud9c5\ude1d\uda7d\udfb2\uda12\udfe0\ud9da\udd4e\uda63\ude2b",
        3, 88030, 119937267, -8647498133819094822L, 88480L, true, false, (char) 9643, (char) 23102,
        Double.longBitsToDouble(0x3fd80a36cf0b2696L), Double.longBitsToDouble(0x3fcfdbaddc56a618L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\udba5\udcf6\udbee\udcfe\ud996\udefb\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 10, 4, "\udb4b\udf56\udba5\udcf6\udbee\udcfe\ud996\udefb", "\u62f0\uc747\u34de\u1629\u9e9b\u2d28\u231f\u4c14\u2e0a\u1705\uc45b\u3fc6\u8cba\u0471\u5fcb\u0a68\u8cd9\u3992\ua2cc\u1785\u337b\u830f\u3657\u15b3\ud0f1\uc7eb\ua6bd\u36c6\u33a3", "\ud9e3\udc29\ud9b6\uddb8\ud93d\ude0c\ud9f9\udc28\ud969\udfe7\ud939\udd2c\u1778\ud8ae\uded4\udb31\ude10\ud9e7\udcd7\udb63\udc50",
        32, 49333, -946113887, 9104881370867054053L, -21771L, false, false, (char) 56013, (char) 27916,
        Double.longBitsToDouble(0x3fa0dca3e8051ac0L), Double.longBitsToDouble(0x3fbae78555d3c3e0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\udbec\ude23\udaca\udde7\udb7a\udd52\0121=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\udbec\ude23\udaca\udde7\udb7a\udd52\012",
        Z.run(T, 2, 3, 3, 12, "\udb4b\udf56\udbec\ude23\udaca\udde7\udb7a\udd52", "\u3e6f\uc747\u8a81\u7ee5\ube98\ub969\u3480\u4f4d\ubbb0\u54bc\u8674\u3fc6\u0baa\u59ff", "\udbe4\udcbc\ud89d\udfe4\ud835\uddfc\uda1b\udded\uda0f\ude2e\ud840\udd8f\uda32\udd21\udaaa\udd4f\uda66\udc83",
        12, 42500, 2097377, 3583784145071815161L, 55237L, false, false, (char) 29947, (char) 11114,
        Double.longBitsToDouble(0x3fd10df92d17102eL), Double.longBitsToDouble(0x3fd1be9ea322b39aL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\uda4b\udf40\udab1\udf98\uda9b\uddfa\uda5e\udd75\udbb4\udd3f\uda41\udfa7\udbf6\ude73\ue03f\uda06\udd36\udbde\udf9a\ud8e1\udedd\udb65\ude63\ud895\udc30\ud992\udd34\udb2c\udead\u2866\0121=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\uda4b\udf40\udab1\udf98\uda9b\uddfa\uda5e\udd75\udbb4\udd3f\uda41\udfa7\udbf6\ude73\ue03f\uda06\udd36\udbde\udf9a\ud8e1\udedd\udb65\ude63\ud895\udc30\ud992\udd34\udb2c\udead\u2866\012",
        Z.run(T, 2, 4, 4, 3, "\udb4b\udf56\uda4b\udf40\udab1\udf98\uda9b\uddfa\uda5e\udd75\udbb4\udd3f\uda41\udfa7\udbf6\ude73\ue03f\uda06\udd36\udbde\udf9a\ud8e1\udedd\udb65\ude63\ud895\udc30\ud992\udd34\udb2c\udead\u2866", "\u59ff\uce4c\ua08f", "\uda54\udeef\ud80d\udf81\ud9b7\udc1a\udbc8\udd8b\uda7b\udf05\udaaa\udd4f\uda66\udc83\ud90a\udc1a\ud9ad\udcd9\udb9d\ude7f\uda15\udcf6\ud8a2\udfef\udb3f\udc75\ud9e3\udc29\ud930\udec6\ud945\udcbc\udb04\udf96\udbdf\uddfe\udb65\udc13\udb2f\udf3e\uda5c\uddc9\ud8ec\udc96\uc440\udb7d\udcff\ud8f7\udd4b\ud834\udc28\uda61\ude19",
        13, 81559, 1232228842, -764331493340450570L, 15405L, false, false, (char) 5907, (char) 26194,
        Double.longBitsToDouble(0x3fe65cd6b7fba438L), Double.longBitsToDouble(0x3febf3d4379ee760L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\u4c83\uabc2\ua39f\u3e6f\uc747\u51c6\u7ea7\ube98\ub969\u3480\u4f4d\ubbb0\u54bc\u8674\u3fc6\u0baa\u06b4\000\000\000\000\ud144 |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\0121=void |a0=java.lang.StringBuilder:\udb4b\udf56 |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\012",
        Z.run(T, 2, 0, 0, 0, "\udb4b\udf56", "\u4c83\uabc2\ua39f\u3e6f\uc747\u51c6\u7ea7\ube98\ub969\u3480\u4f4d\ubbb0\u54bc\u8674\u3fc6\u0baa\u06b4\000\000\000\000\ud144", "\udbbf\udc8b\uafde\udaaa\udd4f\uda66\udc83\ud8b5\uddd0\ud9ad\udcd9",
        44, 52769, 917420537, 581857139834642021L, 51632L, false, true, (char) 60578, (char) 52898,
        Double.longBitsToDouble(0x3fdf45dea322b39aL), Double.longBitsToDouble(0x3fe881877ad8643fL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: N/A\0121=java.lang.String:N/A |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: N/A\012",
        Z.run(T, 2, 13, 11, 7, "\udb4b\udf56\uda4b\udf40\udab1\udf98\udb1a\udd23\uda40\udd6e\udbb4\udd3f\uda41\udfa7\udbf6\ude73\ue03f\uda06\udd36\udbae\udc5f\ud89f\udef6\ud9cf\udf7b\ud8c3\udd39\ud992\uddd2\udb2c\udead\u2866\ud91a\udfae\udaf8\ude1f\ud874\uddb1\udad3\udcaa\udada\udc0c\udbe4\udcbc\ud89d\udfe4\uda54\udeef\ud80d\udf81\ud9aa\udd03\udbc8\udd8b\uda7b\udf05\udaaa\udd4f", "\u1b62\u3afb\u5699\u51ef\u058e\u8263", "\udb04\udf96\ud95f\ude3d\udb6b\udf35\udb2f\udf3e",
        25, 15016, -254194766, -2762426699142263317L, 38328L, true, false, (char) 57241, (char) 22448,
        Double.longBitsToDouble(0x3fe04c79340c1af8L), Double.longBitsToDouble(0x3fc0b20bfb469c94L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77 |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77\0121=java.lang.String:\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77 |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77\012",
        Z.run(T, 2, 11, 11, 4, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\u62f0\u6747\u7168\u9a98\u2352\uaf44\u1f23\u75ad\uc7a6\u4257\u18a9\u3fc6\u01c1\u7f55", "\udbe4\udcbc\ud85b\udf15\ud914\udd27\ud9f6\uddd0\ud9aa\uddbf\udbe2\udf43\uda07\uddc4\uda43\udd4d\uda66\udc83\udabd\udf73\udb31\udd17\ud908\udd84\ud8ac\udde1",
        58, 32172, -1998692763, -4222729122372596816L, -15652L, false, true, (char) 55206, (char) 6058,
        Double.longBitsToDouble(0x3fb746e46b0375a8L), Double.longBitsToDouble(0x3fd94583c8de54f8L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \ud945\udd78\udb04\udfa6\ud9b6\udf0e\ud940\udd77\0121=java.lang.String: |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \ud945\udd78\udb04\udfa6\ud9b6\udf0e\ud940\udd77\012",
        Z.run(T, 2, 14, 14, 2, "\ud945\udd78\udb04\udfa6\ud9b6\udf0e\ud940\udd77", "\ud50d\uc747\u08ef\ud58d\u34fa\u249e\u47d2\u75ad\uc7a6\u0405\u8539\u2401\ubde9\ube9f", "\udac8\udfcd",
        36, 79558, -1978894178, -3637500253247118658L, -15687L, true, false, (char) 28282, (char) 27187,
        Double.longBitsToDouble(0x3fa678e6011d2f20L), Double.longBitsToDouble(0x3fe591bde0473f9dL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.String:N/A |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: N/A\0121=java.lang.String:N/A |this=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: N/A\012",
        Z.run(T, 2, 12, 1, 1, "\ud93e\udd38\udaa4\udc70\ud9b6\udf81\ud940\udd77\uda40\udd6e\udbb4\udd3f\u33ae\ub074\uda74\udf7f\udb7f\udea0\uda17\ude4e\udacb\udf62", "\uc7a6\u6405\uc2cf\u19bb\u2378\u0a60\u4bd6\u2a7c\uce4b\u38cd\u4667\u7dc6\u1d52\ua5d0\u6129", "\udb52\udef9\udb30\udef5\ud908\udd84\udb5c\udff9\udace\ude71\ud91e\udfcd\ud8ea\udf42\ud8a1\udf14\ud8de\uddd7\ud930\udfe6\ud8aa\udde2\uda3c\udc8d\ud89e\udcac\ud94e\ude11\udb8c\udead\udbec\udc80\udbbf\udc0b\ud8c2\udd3d\ud91d\udf7b\ud811\udcef\udb8d\ude24",
        32, 80509, 1045921303, 1544239145994401730L, -88741L, true, false, (char) 20015, (char) 19907,
        Double.longBitsToDouble(0x3fe32be535b81643L), Double.longBitsToDouble(0x3fbfe28782e65860L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 9, 11, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\u62f0\uc747\u6ca2\u9a98\u2352\uaf44\u1f23\u75ad\u2e2c\u6405\uc45b\ube96\ucaaf\u59ff", "\udbe4\udcbc\ud85b\udf15\ud8f6\udc4f\ud9f6\uddd0\ud9aa\uddbf\udaa3\udec3\uda07\uddc4\uda43\udd4d\uda9e\udc31",
        37, 55582, -755868628, 3583784145071815068L, 55237L, false, false, (char) 29947, (char) 54519,
        Double.longBitsToDouble(0x3fd4cf992d8254daL), Double.longBitsToDouble(0x3fe192aa517d6ec7L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77\0121=com.fasterxml.jackson.databind.JsonMappingException:com.fasterxml.jackson.databind.JsonMappingException: \udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77\012",
        Z.run(T, 2, 5, 5, 4, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\u3845\u02f4\u9c3a\u9a98\u2352\uaf44\u1f23\u75ad\u17a7\u6405\uc45b\u7b10\uca77\u59ff", "\uda5a\udf3f\ud85b\ude93\ud8f6\udc4f\ud9f6\uddd0\ud9aa\uddbf\udaa3\udec3\uda07\uddc4\udb0f\udc94\ud93c\udc8b",
        45, 21852, -681433704, 8116791208341062122L, 55237L, false, false, (char) 53164, (char) 54519,
        Double.longBitsToDouble(0x3fd10df92d17102eL), Double.longBitsToDouble(0x3fe31385b97d6e2dL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 6, 12, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77\uda66\ude60", "\u923e\u0745\u4560\u2352\uaf74", "\u743b",
        7, 69827, 418488886, 3681348671364456115L, -83205L, true, true, (char) 18588, (char) 42078,
        Double.longBitsToDouble(0x3fc88388232e2830L), Double.longBitsToDouble(0x3fece081a28f2e89L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 7, 10, "\udb77\udd0f\ud8e9\uddca\udbd9\udc26\udbe1\udec1\ud888\udd72\udbb4\udd3f\u33ae\ud91b\udde6\ud833\udf5e", "\uaf44\u1f23\u75ad\uc7a6", "\udbe5\udee4\ud8c9\udd80\uda93\ude24\udaa5\udfac\udab5\uddb2",
        4, 77340, 474049402, 5775717830616959227L, 89085L, true, true, (char) 56914, (char) 26414,
        Double.longBitsToDouble(0x3fb6e9c0e9663ea0L), Double.longBitsToDouble(0x3fed9740db90bd03L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 8, 2, "\udb4b\udf56\uda31\ude40\uda08\udf17\ud940\udd77", "\u3627\u4048\u3993\u9a98\u2352\u3561\u0ab8\u2adc\u498f\u4305\u501f\u059b\u0baa\u59ff\uce4c\u1973\ua06f\u3992\u2822\u0cf8\u33ff\u9a3a\u7139\u935b\ub618\ub883\u5a5f\u36c6\u33a3\u526b\u058e\u8263\u58a8\uc452\u609e\ua6f1\u406e\u22ff\ub484\ub732\u34cc\u7441\u668d\u649c\u6f8b\ub2eb\ub2e2\ub586\u7abf\u83f2\u7733\ubcc5\u0d96\uab26", "\uda19\ude7f\ud8f7\udc06\udafc\udd52\udb23\udf4b\ud99b\udf6a",
        53, 94298, -74213374, -579026859933760241L, -19174L, true, false, (char) 26548, (char) 25981,
        Double.longBitsToDouble(0x3fc43f1399eeab74L), Double.longBitsToDouble(0x3fe2b67ba48b9447L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 2, 4, "\udb4b\udf56\uda31\ude40\ud9b6\udf0e\ud940\udd77", "\u62f0\uc747\ud15c\u9a81\u2352\uaf44\u1f23\u75ad\uc81d\u6405\uc45b\ucfd0\u0baa\u59ff", "\udbe4\udcbc\ud85b\udf15\ud8f6\udc4f\ud9f6\uddd0\ud9aa\uddbf\udaa3\ude28\uda07\uddc4\uda43\udd4d\ud88d\uddb6",
        1, 55780, -755868628, 3583784145071815068L, 55237L, false, false, (char) 29947, (char) 54519,
        Double.longBitsToDouble(0x3fd10df92d17102eL), Double.longBitsToDouble(0x3fe192aa517d6e2dL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.JsonMappingException|_appendPathDesc|java.lang.StringBuilder|new:com.fasterxml.jackson.databind.JsonMappingException:java.lang.String",
    "M|com.fasterxml.jackson.databind.JsonMappingException|_buildMessage||new:com.fasterxml.jackson.databind.JsonMappingException:java.lang.String",
    "M|com.fasterxml.jackson.databind.JsonMappingException|from|com.fasterxml.jackson.core.JsonGenerator,java.lang.String|static",
    "M|com.fasterxml.jackson.databind.JsonMappingException|from|com.fasterxml.jackson.core.JsonGenerator,java.lang.String,java.lang.Throwable|static",
    "M|com.fasterxml.jackson.databind.JsonMappingException|from|com.fasterxml.jackson.core.JsonParser,java.lang.String|static",
    "M|com.fasterxml.jackson.databind.JsonMappingException|from|com.fasterxml.jackson.core.JsonParser,java.lang.String,java.lang.Throwable|static",
    "M|com.fasterxml.jackson.databind.JsonMappingException|from|com.fasterxml.jackson.databind.DeserializationContext,java.lang.String|static",
    "M|com.fasterxml.jackson.databind.JsonMappingException|from|com.fasterxml.jackson.databind.DeserializationContext,java.lang.String,java.lang.Throwable|static",
    "M|com.fasterxml.jackson.databind.JsonMappingException|from|com.fasterxml.jackson.databind.SerializerProvider,java.lang.String|static",
    "M|com.fasterxml.jackson.databind.JsonMappingException|from|com.fasterxml.jackson.databind.SerializerProvider,java.lang.String,java.lang.Throwable|static",
    "M|com.fasterxml.jackson.databind.JsonMappingException|fromUnexpectedIOE|java.io.IOException|static",
    "M|com.fasterxml.jackson.databind.JsonMappingException|getLocalizedMessage||new:com.fasterxml.jackson.databind.JsonMappingException:java.lang.String",
    "M|com.fasterxml.jackson.databind.JsonMappingException|getMessage||new:com.fasterxml.jackson.databind.JsonMappingException:java.lang.String",
    "M|com.fasterxml.jackson.databind.JsonMappingException|getPath||new:com.fasterxml.jackson.databind.JsonMappingException:java.lang.String",
    "M|com.fasterxml.jackson.databind.JsonMappingException|getPathReference||new:com.fasterxml.jackson.databind.JsonMappingException:java.lang.String",
    "M|com.fasterxml.jackson.databind.JsonMappingException|getPathReference|java.lang.StringBuilder|new:com.fasterxml.jackson.databind.JsonMappingException:java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
