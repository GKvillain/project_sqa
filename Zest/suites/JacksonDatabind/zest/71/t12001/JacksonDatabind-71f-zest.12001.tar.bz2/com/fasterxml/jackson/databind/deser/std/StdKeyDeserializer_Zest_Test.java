package com.fasterxml.jackson.databind.deser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class StdKeyDeserializer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 8, 1, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud879\udd31\ud97c\udff6\udaa5\udedf\ud9c6\udc9f\u8c82\uda49\udfac\udaaf\ude09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\u7ccb\u378b\u7952\u54d2\uc42f\u6726\u3392\ua8ab\u0aaf\u5e99\u6bd5\ub705\ub234", "\ud85b\udd02",
        24, 29116, -1151380291, 4404533536897019804L, 56591L, true, false, (char) 45940, (char) 36296,
        Double.longBitsToDouble(0x3fdcf55903c81930L), Double.longBitsToDouble(0x3fd8aabb1d8fd43eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 8, 1, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud879\udd31\ud97c\udff6\udaa5\udedf\ud9c6\udc9f\u8c82\uda49\udfac\udaaf\ude09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\udadf\udc67\ud9ce\ude30\ud9f1\ude30\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\u7ccb\u378b\u7952\u54d2\uc42f\u6726\u3392\ua8ab\u0aaf\u5e99\u6bd5\ub705\ub234", "\uda41\udec4",
        56, 29116, -1151380291, 4404533536897019804L, 56591L, true, false, (char) 45940, (char) 36296,
        Double.longBitsToDouble(0x3fdcf55903c81930L), Double.longBitsToDouble(0x3fd8aabb1d8fd43eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 3, 7, 5, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2", "\u2e2e\u304c\u8a71\u8451\u216f\u1a7e\u154e\ud158\u167b\u8fc1\u418f\ub17d\u4a1a\u7821\ua489\u861d\u7dc2\u33e7", "\udaf6\udfa6\uda9c\ude4a\ud986\ude71\ud968\udc8d\uda35\udc79\ud9cc\udc03\udb94\udf98\ud9fa\uddc1\udbee\udd68\udb15\ude98\ud830\udf1f\u1422\u2549\ud9a1\udd26\u7714\udbf1\udcad\udaa5\udc89\ud85b\udd02\ud816\udf89\uda21\udcf8\uda7e\udcb1\ud879\udf84\ud8f9\udd81\ud99f\ude61",
        37, 44563, 112616367, -1667589500496285494L, -35025L, false, true, (char) 42299, (char) 378,
        Double.longBitsToDouble(0x3fd5bdfe68a91fa6L), Double.longBitsToDouble(0x3fd26095b69b12beL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 8, 5, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud879\udd31\ud97c\udff6\udaa5\udedf\ud9c6\udc9f\u8c82\uda49\udfac\udaab\udf09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\ud9b4\udd53\ud80b\udedf\ud9b3\udc59\udac9\udddb\ud9ba\uddd3", "\ua647\u3575", "\udb4d\udd54\uda35\udc79\uda4a\ude22\udb94\udf98\ud9fa\uddc1\udbee\udd68\udb15\ude98\ud830\udf1f\u1422\u2549\ud9b8\udf26\u7714",
        17, 44831, -2106090392, 435014276388334700L, 28022L, false, true, (char) 20633, (char) 4021,
        Double.longBitsToDouble(0x3fca67ae8ebc2030L), Double.longBitsToDouble(0x3fe17835b5999556L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 3, 8, 7, "\ud8e8\udc77\udba3\udfe2\udb10\udeb0\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud879\udd31\ud97c\udff6\udaa5\udedf\ud9c6\udc9f\u8c82\uda49\udfac\udaaf\ude09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9fb\udf54", "\u2faf\u98e2\u4cd6\u7ccb\u378b\u3b10\uc5e1\uc42f\u6726\u3392\ua8ab\u0aaf\u5e99\u6bd5\ub705\ub234", "\ud85b\udd02\ud816\udf89",
        51, 18709, 1025510378, 7208778128572476559L, -73575L, true, true, (char) 36729, (char) 45970,
        Double.longBitsToDouble(0x3fd9ecc2ab9eab20L), Double.longBitsToDouble(0x3fde40c98b155762L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 4, 6, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud879\udd31\ud84c\udc5e\udad3\udf3c\ud984\udcd3\u8c82\uda49\udfac\udaaf\ude09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\ud880\uddb8\udad5\udd94\ud9c3\udc64\udac9\udddb\udbb7\udf7f", "\u2faf\u67f2\u837a\u7ccb\u2921\u7952\u54d2\uc42f\u0266\u3b0b\u9353\u9c95\u5e99\u6bd5\u2900\ud55d", "\ud85b\udd02",
        19, 29116, -1151380291, 4404533536897019804L, 71374L, true, false, (char) 45940, (char) 51708,
        Double.longBitsToDouble(0x3fdcf55903c81930L), Double.longBitsToDouble(0x3fd8aabb1d8fd43eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.Date |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 6, 1, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\ud851\ude25\udbb4\udf79\ud879\udd31\ud97c\udff6\ud930\udda4\uda44\udc89\u916a\u465c\udb6c\udee6\ud827\udfca\udbe7\udca7\uda62\ude3b\ud819\udd84\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\u9a64\u0370\u9810\u457f\ua7b2\u8154\u248c\u806c\u07b2\u5e99\u4335\u5dd6\ub1ab", "\ud85b\udd02",
        24, 29116, -1151380291, 4404533536897019804L, -82969L, false, false, (char) 11886, (char) 36580,
        Double.longBitsToDouble(0x3fd9995db33d9854L), Double.longBitsToDouble(0x3fe8e568e8604698L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer$StringKD:@?\012",
        Z.run(T, 1, 0, 3, 7, "\000\000", "\u0d25", "",
        28, 73995, 15461, 5511974936608478011L, -70561L, false, false, (char) 13056, (char) 39381,
        Double.longBitsToDouble(0x3e4949bc00000000L), Double.longBitsToDouble(0x3fea88753cf65567L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 4, 2, 4, "\ud81a\udf56\udba3\udfe2\uda95\udeb2", "\uba30\u911d\u695a\u43b3\u323b\u3195\u54ff\u2b9e\u68db\u8fc1\u418f\u3615\u4a1a\ud7af\u0f6a\u861d\u7dc2\u1ddb", "\udaf6\udf4a\ud86e\ude74\ud986\ude71\ud890\udc81\uda35\udc79\uda4a\ude22",
        -2, 99783, 942336928, 138706523583608272L, -80540L, false, false, (char) 5465, (char) 20046,
        Double.longBitsToDouble(0x3fe97413bc6c0609L), Double.longBitsToDouble(0x3fc7bf0b3454a97cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 0, 0, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud879\udd31\ud97c\udff6\ud817\udd38\ud9c6\udce7\ud8eb\udf65\ud822\udec3\udaa1\udea9\uda81\ude50\ud83e\udfc4\udba9\udd80\ud819\udd96\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\u7ccb\u378b\u7952\u54d2\uc42f\u6726\u3392\u6a9f\u0a2b\u5e99\u6bd5\ub705\ua492", "\ud85b\udd02",
        24, 29116, -1151380291, 4404533536897019804L, -54826L, true, false, (char) 27579, (char) 13862,
        Double.longBitsToDouble(0x3feb81e4819ecc52L), Double.longBitsToDouble(0x3fdcf55903c81930L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 5, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\uda7a\udfae\ud879\udd31\ud97c\udff6\udae4\ude1d\ud9c6\udc9f\u8c82\uda49\udfac\udaaf\ude09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\u7ccb\u378b\u7952\u0470\u4416\ua7d1\u3392\ua8ab\u0aaf\u4988\u896d\ud0d3\u4304", "\ud85b\udd02\ud816\udf89\uda44\udff8\uda7e\udcb1\ud879\udf84\ud8f9\udd81\udbf4\udccb\ud854\udf29\ud98e\udd4c\ud8e5\udc14\uda9e\udded\udbea\ude8a\udb87\udea8",
        9, 51236, -367028870, -6341755716763899902L, 65895L, false, false, (char) 50157, (char) 58215,
        Double.longBitsToDouble(0x3feb97ebb5f47415L), Double.longBitsToDouble(0x3fe14366791a44faL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 7, 8, "\ud8e8\udca5\udba3\udfe2\udae5\udd5f\udba3\udcec\udaef\udd3e\udbcd\ude2f\ud879\udd31\ud97c\udff6\udaa5\udedf\ud9c6\udc9f\u8c82\uda49\udfac\udaaf\ude09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\u7ccb\u378b\u7952\u54d2\uc42f\u6726\u3392\ua8ab\u0aaf\u0f6c\uacc1\ub705\ub234", "\ud85b\udd02",
        24, 29116, -1151380291, 4404533533424136092L, 74843L, true, false, (char) 27579, (char) 36580,
        Double.longBitsToDouble(0x3fd9995db33d9854L), Double.longBitsToDouble(0x3fdcf55903c81930L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 8, 1, 4, "\ud8e8\udc77\uda79\udc4f\uda95\udec7\udbcc\uddb2\udafa\udd43\udbcd\ude2f\udbf1\ude6d\ud8f4\udd6d\udaa5\udedf\ud9c6\udc9f\udb5f\udcbf\uda49\udfac\udaaf\ude09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u0be3\u837a\u7ccb\u378b\u7952\u54d2\uc42f\u6726\u3392\ua8ab\u0aaf\u5e99\u6bd5\ub705\ub234", "\ud85b\udd02",
        24, 29116, -1151380291, 4404533536897019804L, -24842L, true, false, (char) 45940, (char) 36296,
        Double.longBitsToDouble(0x3fdcf55903c81930L), Double.longBitsToDouble(0x3fd8aabb1d8fd43eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 2, 1, 4, "\ud8e8\udc77\udba3\udfe2\uda47\uddcc\udbf2\udfb2\udb02\udcc2\udbcd\ude2f\ud879\udd31\ud8b8\udff4\ud82a\uddeb\udb46\uddd9\udb55\udeda\uda49\udfac\udaaf\ude09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\udadf\udc67\ud8d7\udcf5\ud9b3\udc59\udac9\udddb\ud9ce\udd7d\udaf5\udc47\ua4b2\udba0\udf0a\ud951\udc28\udb5e\ude57\ud986\ude71\ud968\udc8d", "\uc42f\u6726", "\ud9be\udd00\u1417\u2549\ud9a1\udd26\u7714\uda9d\udfe3\udaba\udc7c\ud85b\udd02\ud816\udf89\uda44\udff8\uda93\udfb1\ud879\udf84\ud8f9\udd81\udbf4\udccb\ud854\udf29\ud98e\udd4c\ud8e5\udc14",
        35, 98769, 1435550061, 907754389000759780L, 44368L, true, true, (char) 30975, (char) 21915,
        Double.longBitsToDouble(0x3fec2e8614c3ead8L), Double.longBitsToDouble(0x3fde3a55e6dc7fe4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 1, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\ud9fd\udd05\uda1e\udc01\ud879\udd31\ud97c\udff6\udaa5\udedf\ud9c6\udc9f\u8c82\uda49\udfac\udaaf\ude09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\u7ccb\u378b\u7952\u54d2\uc42f\u6726\u3392\ua8ab\u0aaf\u5e99\u5186\ub705\u6447", "\udb99\udf04\ud9cd\udfa5\ud916\udc4d\uda6e\ude03\ud879\udf84\ud8f9\udd81\udbf4\udccb\ud854\udf29\ud98e\udd4c\u58ce\uda9e\udded",
        2, 36110, 211353039, -6075028363483834998L, -69101L, false, false, (char) 14070, (char) 8060,
        Double.longBitsToDouble(0x3fb601e388b40d58L), Double.longBitsToDouble(0x3fea4f163c6db4daL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 6, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\u8234\ud879\udd31\ud97c\udff6\udaa5\udedf\ud9c6\udcd6\ua9e0\uda49\udfac\udaaf\ude09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\udba0\udd69\ud843\udccb\ud84c\udfca\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\ua77f\u79da\u7952\u54d2\uc42f\u6749\ub691\u46fc\uc625\uac91\u291f\ub705\ub234", "\ud9a6\ude26\ud817\udc10\uda44\udff8\uda7e\udcb1\ud879\udf84\ud8f9\udd81\ud875\udf0b\ud87d\udc4c\ud98e\udd4c\ud8e5\udc14\uda9e\udded\udbea\ude8a\udb87\udea8\uf68d\ud81b\udcec\udbd1\udc3f\udb3f\udd93\udacf\udc47\ud972\uddad\udb12\udd9d\uda5d\udfb6\ud981\udc79\uda94\udc63\ud8ca\udd21\ud9ff\udfca\udad9\udeb8\udaa2\udcb4\udb28\udd92\udbda\udf01\udb6d\udcd8\uda0f\udefb\udbd9\udc07\udab9\udd82\ud865\udd84\ud89c\ude02\uda79\udde2\uda5e\ude6b\udb63\udc47\ud928\uddc5\udbce\udfc4\udbb1\udea9\uda6b\udd7a\ud844\udd8b\ud971\ude55",
        11, 85730, -12713409, -2621041437869252252L, 36400L, false, true, (char) 10891, (char) 44331,
        Double.longBitsToDouble(0x3f89930cfd0dce80L), Double.longBitsToDouble(0x3fe855e3a988dc6aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 0, 0, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud879\udd31\ud907\ude76\uda65\udea9\ud9c6\udcc7\u8c82\uda49\udfac\udaaf\ude09\ud843\udf51\udb2c\udd98", "\u4a1a\ud7af\ua489", "\udaf5\udc47\ua4b2\u830b\udaf6\udfa6\uda9c\ude4a\ud986\ude71\ud968\udc8d\uda35\udc79\uda4a\ude22\udb94\udf98\ud9de\udc32\udbee\udd33\udb15\ude98\ud830\udf1f\u1422\u2549\ud9a1\udd26\u7714\udbf1\udcad\udb6f\udc72",
        29, 70728, -50830140, -2259828697132813939L, -29487L, false, true, (char) 42567, (char) 27579,
        Double.longBitsToDouble(0x3fa7835b59995db0L), Double.longBitsToDouble(0x3fd9ecc2ab9eab20L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer$StringKD:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ud8e8\udc77", "\u540c\u2baa\u5079", "\udaa5\udedf\ud9c6\udc9f\u8c82\uda49\udfac\udaaf\ude09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\udadf\udc67",
        31, 19994, -2022048522, 4367820846852356661L, -74319L, false, true, (char) 13999, (char) 63218,
        Double.longBitsToDouble(0x3fd12a5bf518fdeaL), Double.longBitsToDouble(0x3fdcf20b772292d4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 3, 7, 5, "\ud8ac\udc79\udba3\udfe2\uda95\udeb2", "\u2e2e\u665e\u8a07\u8451\u216f\u1a7e\u154e\ud158\u167b\u8fc1\u418f\ub17d\u4a1a\u7821\ua489\u3b1d\u7dc2\u33e7", "\udaf6\udfa6\uda9c\ude4a\ud986\ude71\ud968\udc8d\uda35\udc79\ud9cc\udc03\udb94\udf98\ud9fa\uddc1\udbee\udd68\udb15\ude98\ud830\udf1f\u1422\u2549\ud9a1\udd26\u7714\udbf1\udcad\udaa5\udc89\ud85b\udd02\ud816\udf89\uda21\udcf8\uda7e\udcb1\ud879\udf84\ud8f9\udd81\ud99f\ude61",
        37, 69427, 112612766, -1667589500496285494L, -35025L, false, true, (char) 42299, (char) 378,
        Double.longBitsToDouble(0x3fd5bdfe68a91fa6L), Double.longBitsToDouble(0x3fd26095b69b12beL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 3, 7, 5, "\000", "\000", "\ud957\uddbe",
        36, 90158, 1203780709, -821212039215597509L, -70561L, false, false, (char) 0, (char) 31189,
        Double.longBitsToDouble(0x3fdd451990000134L), Double.longBitsToDouble(0x3fea880004f65567L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 6, 6, 7, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud8f3\udf5a\ud93d\uded4\udaa5\udedf\ud9c6\udc9f\u8c82\uda49\udfac\udaab\udf09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\ud9b4\udd53\ud80b\udedf\ud9b3\udc59\udac9\udddb\ud9ba\uddd3", "\ua647\u3575", "\udb4d\udd54\uda35\udc79\uda4a\ude22\udb94\udf98\ud9fa\uddc1\udbee\udd68\udb15\ude98\ud830\udf1f\u1422\u2549\ud9b8\udf26\u7714",
        17, 44831, -2106090392, 435014276388334700L, 28022L, false, true, (char) 20633, (char) 4021,
        Double.longBitsToDouble(0x3fca67ae8ebc2030L), Double.longBitsToDouble(0x3fe17835b5999556L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud879\udd31\ud97c\udff6\udaa5\udedf\ud9c6\udc9f\u8c82\uda49\udfac\udaab\udf09\uda81\ude50\udaf9\udf4f\udb9e\udf31\ud819\udd96\ud9b4\udd53\ud80b\udedf\ud9b3\udc59\udac9\udddb\ud9ba\uddd3", "\ua647\u3575", "\udb4d\udd54\uda35\udc79\uda4a\ude22\udb94\udf98\ud9fa\uddc1\udbee\udd68\udb15\ude98\ud830\udf1f\u1422\u2549\ud9b8\udf26\u7714",
        17, 44831, -2106090392, 435014276388334700L, 28022L, false, false, (char) 20697, (char) 4021,
        Double.longBitsToDouble(0x3fca67ae8ebc2030L), Double.longBitsToDouble(0x3fe17835b5999556L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 3, 6, "\uda57\udf1c\udba3\udfe2\uda95\udeb2\udbcc\uddb2\uda32\ude7d\udbd5\udd65\uda59\udcd6\u3853\ud946\ude0f\udb45\udc39\u1dc1\udab7\udee4\udbe1\udd5b\udb0a\udfd0", "\ub17d\u9b48\u2631\u9eee\u10de\u24be\u69e6\u4c88\ua6ab\u1f5d\uab95", "\uda35\udc79\uda4a\ude22\udb94\udf98\ud9fa\uddc1\udbee\udd68\udb15\ude98\ud830\udf1f\u1422\u2549\ud9b8\udf26\u7714\udbf1\udcad\udaa5\udc89\ud8d2\udc6a\ud816\udf89\udada\udd82\uda7e\udcac\udac3\udf89\ud8f9\udd81\udbf4\udd11\ud854\udf29\ud98e\udd4c\ud901\ude14\uda49\uddbd\udaab\udcdb\uda33\udd65\ud9e4\udd84\uda69\udcb4\udb25\udea8\ud891\udda0\udac4\uded6\ud921\udd6c\udb22\ude3b\uda21\uddd4\uda4a\udef2\udb3e\udff9\ud83d\udd91\udb36\udfcbc\uda81\udce6\udb85\udccd",
        21, 180, 478313321, 4532507002429885119L, -21466L, true, false, (char) 3048, (char) 46082,
        Double.longBitsToDouble(0x3fd7725e1ef0b204L), Double.longBitsToDouble(0x3fe48c576f6c2850L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud879\udd31\ud97c\udff6\udaa5\udedf\ud9c6\udc9f\u8c82\uda49\udfac\udaab\udf09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\ud9b4\udd53\ud80b\udedf\udbb8\ude07\udac9\uddcf\ud9ba\uddd3\uda20\udc4f\udae7\udffb\uda5e\uddec\ud8cd\udfe2\uda58\udfa9\ud987\udd63\udb4d\udd54\uda35\udc79\uda4a\ude22\udb94\udf98\uda99\udcd3\ud9d3\ude5b\udb15\ude48", "\u6bd5\u3d06\ub234\u475b\u0100\u9f9f\u9a55\ud35a", "\ud8f9\udd81\udbf4\udccb\ud854\udf29\ud98e\udd4c\ud8e5\udc14\udb48\udfe5\udae6\uddc8\ud9f0\udf56\uda9c\udc28\ud9b3\udf44\udb1f\uded1\udbbe\uddef\ud8cf\udc7f\udaf8\ude79\ud89a\udd51\udaab\udf13\ud9c2\udc16\ud8ed\udf9a",
        4, 82346, -1550940633, 5858846814405581797L, 28406L, true, false, (char) 25878, (char) 35554,
        Double.longBitsToDouble(0x3fef3249960f373fL), Double.longBitsToDouble(0x3fb3c1047be9fee0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 0, "\udbdb\udd86\udba3\udf7b\uda95\udeb2\udbcc\uddb2\udb1b\udd81\udbcd\ude2f\ud879\udd31\ud97c\udff6\udaa5\udedf\ud9c6\udc9f\ubb82\udaf5\udfb0\udaab\udf09\uda81\ude50\udbe7\udca7\udba9\udd80\udb3f\udfba\ud9b4\udc87\ud80b\udedf\ud9b3\udc59\udac3\udd57\ud9ba\uddd3", "\u82b8\u93f0", "\uda55\udef9\ud87e\udfca",
        9, 99833, -1945528169, -2932709983003380099L, 92894L, false, true, (char) 47965, (char) 39228,
        Double.longBitsToDouble(0x3fd9c347f37e6832L), Double.longBitsToDouble(0x3fba29e7d97413b8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 0, 8, 4, "\udaf7\udd46\ud880\udd26\udb10\udf34\ud8c8\udff0\udbb8\ude7c\udbcd\ude18", "\u452e\u216f\u196b\u9c99\ud158\u52e1\ua114\u056a\u012a\u4a1a", "\udac9\udddb\ud9fb\udf54\udb21\udc22\ua4b2\udba0\udf0a\udaf6\udfa6\ud8c0\udf4f\ud986\ude71\ud968\udc8d\ud979\udd5b\uda30\udf32",
        -2, 33831, -682824753, 132704993982206114L, -80540L, false, false, (char) 39104, (char) 38766,
        Double.longBitsToDouble(0x3fe974103c6c0609L), Double.longBitsToDouble(0x3fc7bf0b2faaed7cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 8, 7, "\ud8e8\udc77\udba3\udfe2\udb10\udeb0\udbcc\uddb2\uda72\ude3f\udbcd\ude2f\ud879\udd31\ud97c\udff6\udaa5\udedf\ud9c6\udc9f\u8c82\uda49\udfac\udaaf\ude09\uda81\ude50\udbe7\udca7\udba9\udd80\ud81e\udd96\uda17\udc63\ud80b\udf2f\ud80c\udf8b\ud8c0\udd34\ud9d7\ude43\udb21\udc22\ua4b2\udba0\udf0a\udaf6\udfa6\ud8c0\udf4f\ud986\ude71\udba6\udd2f\ud979\udd28\uda30\udf32\udb94\udf98\ud9fa\uddc1\udbee\udd68", "\u5e99\u6bd5\ub705\ub234\uaad9\u8ea5", "\uda44\udff8\uda7e\udcb1\ud879\udf84\ud8fb\udf69\u2c37\ud8d3\udc7e\ud98d\udfb2\ud8e5\udc14\ud9a2\ude84\udbea\ude8a",
        15, 60039, -1414452764, 8248788613336274787L, 39220L, false, false, (char) 21661, (char) 24682,
        Double.longBitsToDouble(0x3fd512823de8b33aL), Double.longBitsToDouble(0x3feef75a0d7d8f42L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 7, "\ud8e8\udc77\udba3\udfe2\udb10\udeb0\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud879\udd31\ud97c\udff6\udaa5\udedf\ud9c6\udc9f\u8c82\uda49\udfac\udaaf\ude09\uda81\ude50\udbe7\udca7\udaa9\udedf\udb03\udda3\udbff\uddf3\ud80b\udf2f\ud9b3\udc59\uda0e\udf3d\ud9f9\uddc4", "\u2faf\u986f\u4cd6\ua1cb\uc789\u2649\uc5e1\uc42f\u6726\u3392\ua8ab\ub472\ua109\u6bd5\ub705\ub234", "\udb39\uded7\udad6\udf89\uda44\udff8\uda7e\udcb1\ud879\udf84\ud8fb\udf69\ud96b\udf07",
        12, 68905, 112616367, -7639924918332023399L, -35025L, false, true, (char) 16699, (char) 14071,
        Double.longBitsToDouble(0x3fde0f225340205aL), Double.longBitsToDouble(0x3fea9bb9cfa89404L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 7, 8, 7, "\ud8e8\udc77\udba3\udfe2\udb10\udeb0\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud879\udd31\ud97c\udff6\udaa5\udedf\ud9c6\udc9f\u8c82\uda49\udfac\udaaf\ude09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9fb\udf54", "\u2f8b\u98e2\u4cd6\u7ccb\u378b\u3b10\uc5e1\uc42f\ua22b\u618d\ua8ab\u0aaf\u5e99\u6bd5\ub705\ub234", "\ud85b\udd02\ud816\udf89",
        51, 18709, 1025510378, 7208778128572476559L, -73575L, true, true, (char) 36729, (char) 45970,
        Double.longBitsToDouble(0x3fd9ecc2ab9eab20L), Double.longBitsToDouble(0x3fde40c98b155762L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 4, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud879\udd31\ud85a\udf5e\udad3\udf3c\ud984\udcd3\udbd8\udf3d\uda48\udfe9\udaaf\ude09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\ud880\uddb8\udad5\udd94\ud9c3\udc64\ud8b9\uddb2\udbb7\udf7f", "\u3af1\u67f2\u8804\u7ccb\u2921\u5c8d\uc839\uc42f\u0266\u3b0b\u9353\u9c95\u5e99\u6bd5\u2900\ud55d", "\ud85b\udd02",
        19, 29116, 1633637565, 4449090489698398108L, 71374L, true, false, (char) 56247, (char) 51708,
        Double.longBitsToDouble(0x3fdcf55903c81930L), Double.longBitsToDouble(0x3fd8aabb1d8fd43eL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 7, 1, 8, "\ud8e8\udc77\udba3\udfe2\udab6\udcc2\ud98e\udd46\udafa\udd43\udbcd\ude2f\ud879\udd31\ud94c\udebd\uda64\udc1d\udafa\udfbc\uda40\udfe1\u07a9\ud801\ude72\uda35\udf9a\udbe7\udc7e\u231c\udaaf\udc49\ud880\uddb8\udad5\udd94\ud9c3\udc64\ud933\ude60\ud9f7\udf2d", "\u4a4b\u42ac\u1786\u1adb", "\uda0d\udd69\ud982\udf8b\udb07\udc0b\ud9d5\udc47\ud8d8\uddd1\udb2c\udd1d\u1422\u2549\ud9a6\udc08\udb36\udc80\udb7b\udc61\ud8f7\udf6f\udb9f\udee4\u500b\uda44\udff8\uda7e\udcb1\ud879\udf84\ud8f9\udd81\udbf4\udccb\ud854\udf29\udbea\udcee\udada\udef2\uda9e\udded\udb5a\uddec\uda21\udcf0\uda29\udc77\ud83b\udd99\ud92b\ude8c\uda71\udecb\ud87c\udc6e\ud8fa\udd09\ud889\udcd7\ud962\udcf7\udb76\udefa\ud87f\ude3e\udabf\udf80\ubf2b",
        -2, 81137, -483311491, 5184613997993247818L, 53471L, false, true, (char) 54085, (char) 11868,
        Double.longBitsToDouble(0x3f850c3003f6df80L), Double.longBitsToDouble(0x3fef822bc2fad55aL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 3, 7, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\ud9f9\udf7d\ud9c0\udc85\udb20\udfad\ud861\ude14\udad3\udf3c\ud984\udcd3\u8c82\uda49\udfac", "\u8fc8", "\ud880\uddb8\udad5\udd94\ud9c3\udc64",
        8, 91915, 590232117, -23700284574295121L, -21214L, false, false, (char) 23101, (char) 30078,
        Double.longBitsToDouble(0x3fdb9f98772292d4L), Double.longBitsToDouble(0x3fc1a010db6fddbcL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 3, 2, "\ud8e8\udcea\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\ud9ea\udd1e\udade\udcfc\udb33\udfb2\udb44\udd94\udb7c\udcd3", "\u2679\u3554\u0707\u418f\u771e\u156a", "\ud8e5\udf55\udb7a\udd80\uda2c\ude81\udaa9\udcd0\udad8\udcb1\udb1a\ude39\udaaf\udde4\ud986\ude71\udb30\udf50\ud9f7\ude7a\ud8bd\udf66",
        0, 10909, -733417765, -7635148479329039735L, -71688L, false, false, (char) 40463, (char) 57935,
        Double.longBitsToDouble(0x3fdbf34f0bd34f3eL), Double.longBitsToDouble(0x3fd52d0ae6cea6daL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.Date |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 2, 1, "\ud8e8\udc77\u1411\udafd\udf8b\udbcc\uddb2\ud851\ude25\udbb4\udf79\ud879\udd31\ud97c\udff6\ud930\udda4\uda44\udc89\u916a\u465c\udb6c\udee6\ud827\udfca\udbe7\udca7\uda62\ude3b\ud825\udd1b\udadf\udc5b\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\u9a64\u0370\u9810\u457f\ua7b2\u8154\uc3c0\u59e7j\u5e99\u4335\u5dd6\ub1ab", "\ud85b\udd02",
        24, 29116, -1151380291, 4404533536897019804L, -82969L, false, false, (char) 11886, (char) 36580,
        Double.longBitsToDouble(0x3fd9995db9b5f768L), Double.longBitsToDouble(0x3fe30fe008b3d180L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Class:[I |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 5, "\ud8e8\udce8\udba3\udfe2\uda95\udeb2\udbcc\uddb2\ud851\ude25\udbb4\udf79\ud879\udd31\ud97c\udff6\ud930\udda4\uda44\udc89\u916a\u465c\udb6c\udee6\ud827\udfca\udbe7\udca7\uda62\ude3b\ud819\udd84\udadf\udc67\ud80b\udf2f", "\u7dc2\u33e7\u2c53\u2faf\u98e2", "\udbe2\ude80\ud880\ude8c\ud8d6\ude06\ud8fd\udde3\ud86f\udc6e\ud8ed\udf48\ud924\ude75\ud89b\udf74\u1422\udb09\udc4d\ud943\udd17\u768b\udbf1\udcad\udaa5\udc89\ud85b\udd02\ud8ff\ude9d",
        9, 18709, 1025510378, 7208767236266948834L, -18072L, true, true, (char) 36580, (char) 45940,
        Double.longBitsToDouble(0x3fd9ecc2a6395a3aL), Double.longBitsToDouble(0x3fb811a638b82480L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.String |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Class:java.lang.String |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 6, 6, 4, "\ud8e8\udc77\udba3\udfe2\ud851\udf49\udbcc\uddb2\ud851\ude25\udbb4\udf79\ud879\udd31\ud97c\udff6\ud930\udda4\uda44\udc89\u916a\u465c\udb5e\udde6\ud827\udfca\udbe7\udca7\uda62\ude3b\ud819\udd84\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\udb0d\udfed", "\u2faf\u98e2\ua0f6\u9a64\u0370\u97c5\u457f\uabd8\u88c8\u6533\u6faf\u07b2\u5e99\u4335\u5dd6\ub1ab\u475b\u0100\uafb9\u9a55\ud35a\u6b66\u245c\uce2d\u59ac", "\ud8e5\udc14\uda9e\udded\udbea\ude8a\uda2b\udcbb\u6f45\ud9f9\udf37\uda66\udebb\ud8df\udea1\uda51\uddd9",
        57, 37324, 240374187, -4445568749750353031L, 14286L, false, true, (char) 32132, (char) 12094,
        Double.longBitsToDouble(0x3fb09d930eb26c70L), Double.longBitsToDouble(0x3fee344474b4ad76L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\ud851\ude25\udbb4\udf79\ud879\udd31\ud97c\udff6\ud930\udda4\uda44\udc89\u916a\u465c\udb6c\udee6\ud827\udfca", "\000\u4946", "\udac9\udddb\ud9ce\udd7d\udaf5\udc47\ua4b2\udba0\udf0a\udaf6\udfa6\uda9c\ude4a\uda87\udfd1\udbe2\uddcd\ud880\ude8c\ud8d6\ude06",
        15, 39413, 0, 8059133259781846254L, -71176L, false, false, (char) 38835, (char) 26139,
        Double.longBitsToDouble(0x3fdbf34198d14f3eL), Double.longBitsToDouble(0x3fe97413bc6c0609L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Integer |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 6, 1, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\ud851\ude25\udbb4\udf79\ud879\udd31\ud97c\udff6\ud930\udda4\uda44\udc89\u916a\u465c\udb6c\udee6\ud827\udfca\udbe7\udca7\uda62\ude3b\ud819\udd84\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\u9a64\u0370\u9810\u457f\ua7b2\u8154\u248c\u806c\u07b2\u5e99\u4335\u5dd6\ub1ab", "\ud85b\udd02\ud816\udf89\uda44\udff8\uda7e\udcb1\ud879\udf84\ud8f9\udd81\ud969\udce6\udb7f\udf9d\uda37\udfb4\ud8e5\udc14\uda9e\udded\udbea\ude8a\uda2b\udcbb\u6f45\ud908\udee0",
        0, 96349, 284797094, -2226147319721155610L, 77705L, true, false, (char) 38387, (char) 45213,
        Double.longBitsToDouble(0x3fe1db07167473f3L), Double.longBitsToDouble(0x3fc2046bb2b6e728L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Class:char |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 1, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udec3\udbcc\uddb2\ud851\ude25\udbb4\udf79\ud879\udd31\ud97c\udff6\ud930\udda4\uda44\udc89\u916a\u465c\udb6c\udee6\ud827\udfca\udbe7\udca7\uda62\ude3b\ud819\udd84\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u0b83\u837a\u7348\u028a\u9810\u457f\ua7b2\u8154\u248c\u806c\u07b2\u0b55\u4335\u5dd6\ub1ab", "\ud85b\udd02\ud816\udf89\uda44\udff8\uda7e\udcb1\ud879\udf84\ud8f9\udd81\ud969\udce6\udb7f\udf9d\uda37\udfb4\ud8e5\udc14\uda9e\udded\udbea\ude8a\uda2b\udcbb\u6f45\ud859\ude67",
        12, 96613, -1100988795, -166810186503181718L, -90753L, false, false, (char) 33091, (char) 84,
        Double.longBitsToDouble(0x3fe3f2a317bb2d1bL), Double.longBitsToDouble(0x3feb4ad61894c7c8L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 7, 1, 6, "\ud8e8\udc15\udba3\udfe2\uda95\udeb2\udbcc\uddb2\ud851\ude25\udbb4\udf79\ud879\udd31\ud97c\udff6\ud930\udda4\uda44\udc89\u916a\u465c\udb6c\udee6\ud827\udfca\udbe7\udca7\uda62\ude3b\ud819\udcf7\udadf\udc67", "\u85f2\u7dc2\u33e7\u2c53\u2faf\u98e2\u837a\u9a64\u0370\u9810\u15b1", "\ud8ed\udf48\ud924\ude75\ud89b\udf74\u1422\udb09\udc4d\ud943\udd17\u768b\udbf1\udcad\udaa5\udc89\ud85b\udd02\ud816\udf89\uda44\udff8\uda7e\udcb1\ud911\udf71",
        6, 37316, 1448875608, -3837354026740587601L, 23495L, false, true, (char) 53305, (char) 26360,
        Double.longBitsToDouble(0x3fe2bb29e40f411eL), Double.longBitsToDouble(0x3fe40fc927b6dc67L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Class:[Ljava.lang.String; |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 1, 4, "\ud906\udf0b\udb2b\udf84\ud972\udfa3\udbcc\ude55\ud851\ude25\udbb4\udf79\ud879\udd31\udac2\udc30\ud930\uddb2\uda44\udc89\u916a\ud8fe\udd70", "\u9ce5\u79d7\u8a25\uc119\ud7af\ua489\u861d\u7dc2\u33e7\u749f\u2ba3\u98ea\uaf7a\u9a64\u0370\u9810\u457f\ua7b2\u0c17\u243c\u806c\ud2ef\u5e99\u4335\u1f06\ub198\uc14e\u551d\ua2b8", "\uda7e\udcb1\ud879\udf84\ud8f9\udd81\ud969\udce6\udb7f\udf9d\uda37\udfb4\ud8e5\udc14\uda9e\udded",
        2, 8182, -66103902, 2301880382394973196L, 8782L, true, false, (char) 9347, (char) 42330,
        Double.longBitsToDouble(0x3fbe5dcaf2c18a88L), Double.longBitsToDouble(0x3feb8e42a8ccd0b2L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Thread$State |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 4, 0, "\ud8e8\udc77", "\u540c\u707a\uc5c2", "\ud930\udda4\u40f0\000\u465c\udb6c\udee6\ud827\udfca\udbe7\udca7\u3392\ud819\udd84\000",
        28, 59161, -2022048522, 4367820846852356661L, -74319L, false, true, (char) 13999, (char) 63218,
        Double.longBitsToDouble(0x3fe76697c160408fL), Double.longBitsToDouble(0x3fe5d4612ef47bd5L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.Date |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 1, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\ud851\ude25\udbb4\udf79\ud879\udd31\udae2\udd83\ud907\udece\uda44\udc89\u916a\u465c\udb6c\udee6\udbd3\udd5d\ud9e8\udd1e\uda62\ude3b\udbbe\uddd8\ud8e6\ude4d\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\u9a64\u0370\u9810\u457f\ua7b2\u8154\u248c\u806c\u07b2\u6f75\u53ae\u5dd6\ub1ab", "\ud85b\udcce",
        8, 29116, -1151380291, 4404533536897019804L, -82969L, false, false, (char) 11886, (char) 36580,
        Double.longBitsToDouble(0x3fd9995db33d9854L), Double.longBitsToDouble(0x3fe05568e8ed229aL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.ArrayList |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 1, 4, "\ud8e8\udc77\udba3\udfe2\ud96e\uddbf\udbac\uddc5\ud98b\ude7b\udbb4\udfe7\ud981\udc6e\uda5d\udf22\ud966\udc7b\udb26\ude0b\u8852\u465c\udb6c\udee6\ud827\udfca\udbe7\udca7\uda62\ude3b\ud819\udd84\udadf\udc67\ud80b\udf2f\ud9b3\udc59\ud818\udcc3\ud9d9\udce3\udaf5\udc47\ua4b2\udba0\udf0a\udaf6\udf2f\uda9c\ude4a\uda9b\udd1b", "\u457f\ua7b2", "\ud924\ude75\ud89b\udf74\u1422\udb25\udf4d\ud943\udd17\u768b\udbf1\udcad\udaa5\udc89\ud85b\udd02\ud816\udf89\uda44\udff8\uda7e\udcb1\ud879\udf84\ud8f9\udd81\ud969\udce6\udb7f\udf9d\uda37\udfb4\ud8e5\udc14\uda9e\uddf0\udbea\ude8a\uda2b\udcbb\u6f45\ud936\udf57\udb88\udde9\udb68\udc44\udb8d\udc8d\udbc9\udf39\uda4b\udf34\ud94b\udecf\uda0b\udf07\udae8\uddfc\udb85\udf29\udbae\udca0\udb8d\udf63\ud8af\udec5\ud832\udf33\ud997\udfd6\uda6d\udd2a\ud80a\ude69\ud9e1\udf14\udb9e\ude2e\ud969\udfd1\ud98c\udf82\u8bb4\ud8c0\udd35\ud99a\udd9c\ud89f\udeec\u327e\uda68\udc17\udacd\udcf3\ud989\udda7\ud656\udbe9\udd1d\udb48\udcb3\ud835\udf81\ud8cc\udcdd\ud957\ude4d\ud8bb\udd74\uda5c\udd3f\udb9d\udf7e",
        3, 80467, -773246056, -182857393826268987L, -25981L, false, true, (char) 55674, (char) 54589,
        Double.longBitsToDouble(0x3fe17d44afce6307L), Double.longBitsToDouble(0x3fe3689bd3c30d3aL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.Date |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 1, 4, "\ud8e8\udc77\udaa4\udc83\uda95\udeb2\udbcc\uddb2\ud851\udd9f\ud8eb\udd95\ud879\udd31\ud97c\udff6\ud812\udf56\uda32\udd9f\u7f37\u465c\ud821\udde3\ud827\udfca\udbe7\udca7\udad7\udd81\ud81d\udd3a\udadf\udc67\ud80b\udf2f\uda57\udf60\udac9\udddb\ud9ce\udd7d", "\u2faf\u1fb2\u837a\u9a64\u0370\u9810\u457f\u4f83\u8154\u018c\u806c\uc3ec\u9ebb\u4335\u5dd6\ud1ab", "\ud85b\udd02",
        7, 29116, -1151380291, 4404533536897019804L, -82969L, false, false, (char) 11886, (char) 36580,
        Double.longBitsToDouble(0x3fd9995db33d9854L), Double.longBitsToDouble(0x3fe8e568e8604698L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.String |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\ud851\ude25\ud84d\uddde\udabb\udf82\ud99e\udde9\ud934\udc5e\uda44\udc89\u916a\u465c\udb6c\udee6\ud827\udfca\udbe7\udca7\uda62\ude3b\ud977\udc34\ud8c1\ude30\uda70\udcc2\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\u9a64\u0370\u702f\ua6cc\ua7b2\u8154\ua0b1\ua070\u07b2\u5e99\u4335\u5dd6\ub1ab", "\ud85b\udd02\ud816\udf89\uda44\udff8",
        1, 56378, 1678421916, 4911871257107776135L, 5553L, true, false, (char) 45940, (char) 36296,
        Double.longBitsToDouble(0x3fe8e568ea31ee98L), Double.longBitsToDouble(0x3fee30940dd92a5cL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 7, 7, 6, "\ud8e8\udc77\udb36\udecd\uda95\udeb2\udbcc\uddb2\ud851\ude25\udbb4\udf79\ud879\udd31\ud97c\udff6\ud930\udda4\uda44\udc89\u916a\u465c\udb6c\udee6\ud81b\udfca\udbe7\udca7\uda62\ude3b\ud819\udd84\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\u9a64", "\ud974\uddc7\udbfe\udd05",
        38, 98926, 1876413406, 3086431317190963582L, -92134L, true, false, (char) 26139, (char) 30168,
        Double.longBitsToDouble(0x3fba29e7d97413b8L), Double.longBitsToDouble(0x3fbb018265efc2c8L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Number |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udbf7\uddf7\udb67\ude91\ud879\udd31\ud97c\udff6\ud93a\udda3\uda44\udc89\ud888\udc5b\uda08\ude47\u7eaa\ud89e\udc6e\ud9e5\udfcd\udbcd\udf71\ud48a\uda67\udd16\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u942b\u6208\u12b1\u9b5e\u4dfc\u07c5\ub5b2\u8154\ub54b\ua609\u0955\u5e99\u4335\u5dd6\ub1ab", "\ud868\udc02",
        10, 98973, 683021943, 4404544480473690012L, -82969L, true, true, (char) 61039, (char) 36651,
        Double.longBitsToDouble(0x3fd9995db33d9854L), Double.longBitsToDouble(0x3fea0100e860c4beL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 6, "\ud8e8\udc77\udba3\udfe2\udb2f\udf9f\udbc6\ude24\ud971\udd15\ud91b\udd64\ud879\udd31\ud97c\udff6\ud85e\udf90\uda43\udff1\u916a\uda66\udd64\ud87d\udd4e\ud828\udc39\udbfe\udea7\ud899\udfa3\ud816\udd35\udadf\udc67\ud9e8\udd7f\ud9b3\udc59\udb93\ude0c\uda3c\udccd", "\u2faf\u98e2\u837a\u9a64\u01f5\ud434\u457f\ua7b2\ubfc4\u70fe\u9057\u8d50\u5e99\u4335\u5dd6\ub1ab", "\ud80d\udfda",
        16, 29557, -1151342719, 4404533536906063772L, -82969L, false, false, (char) 11886, (char) 36580,
        Double.longBitsToDouble(0x3fef7cfed8560edaL), Double.longBitsToDouble(0x3fe8e568ed604698L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\ud851\ude25\udbb4\udf79\ud879\udd31\ud97c\udff6\ud930\udda4\uda44\udc89\u916a\u465c\udb6c\udee6\ud827\udfca\udbe7\udca7\uda62\ude3b\ud819\udd84\udadf\udc67\ud80b\udf2f\ud985\udc62\udac9\udddb\ud9ce\udd7d", "\u2faf\uc59f\u837a\u9a64\u0370\u9810\u457f\ua7b2\u8154\u248c\u806c\u07b2\u5e99\u4335\u5dd6\ub1ab", "\udaaf\udf6c",
        11, 93742, 496192445, 4404533536897019804L, -82969L, false, false, (char) 11886, (char) 36580,
        Double.longBitsToDouble(0x3fd9995db33d9854L), Double.longBitsToDouble(0x3fe8e568e8604698L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=null\0121=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 0, 6, 4, "\u0084\000\000\000\ud823\udd31\udbb4\udf79\000\ud97c\udff6\ud930\udda4\ud898\udcf3\u1482\u465c\udb52\udf09\udada\ude43\000\000\ud819\udd84\udadf\udc67\ud8b7\udf25\ud9b3\udc59\ud801\udcf6\000", "\u2faf", "\uda9b\udd1b\udbe2\udeb9\000",
        -5, -1000, 0, -6828754458814395426L, 92894L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e2bf34000000000L), Double.longBitsToDouble(0x3f44f3e000000000L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 0, 3, 7, "\000\000\ud9d9\ude19\udbc2\udd60\ud99f\udcf6\000", "\u331b", "\uda49\udfac",
        57, 9545, 186, -7417935461139611449L, 30294L, false, false, (char) 46893, (char) 5913,
        Double.longBitsToDouble(0x3f928b5b4705d140L), Double.longBitsToDouble(0x3fe0303df77ae8e0L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=!java.net.MalformedURLException\012",
        Z.run(T, 1, 1, 5, 0, "\ud969\udeca", "\u2bba", "\000",
        14, 55199, 15461, 5511974936608478011L, -29692L, false, false, (char) 18565, (char) 39381,
        Double.longBitsToDouble(0x3e4949bc00000000L), Double.longBitsToDouble(0x3fea88753cf65567L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 0, 0, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud879\udd31\ud97c\udff6\ud817\udd38\ud9c6\udce7\ud82c\udd35\ud822\udec3\udaa1\udea9\uda81\ude50\ud83e\udfc4\udba9\udd80\ud819\udd96\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\u87dd\u378b\u7952\u54d2\uc42f\u6726\u3392\u6a9f\u0a2b\u5e99\u6bd5\ub705\ua492", "\ud85b\udd02",
        24, 29116, -1151380291, 4404533536897019804L, -54826L, true, false, (char) 27579, (char) 13862,
        Double.longBitsToDouble(0x3feb81e4819ecc52L), Double.longBitsToDouble(0x3fdcf55903c81930L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer$StringKD:@?\0121=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer$StringKD:@?\012",
        Z.run(T, 2, 0, 0, 7, "\ud8e8\udc77\uda02\udf7c", "\u2baa\ub678\u4410\u065a", "\ud8eb\udf65\ud822\udec3\udaa1\udea9\udb5e\udebe\ud84a\udee8\udba9\udd80\u834e",
        45, 6519, 1432846161, -8684632271898173973L, 36081L, true, false, (char) 30680, (char) 7292,
        Double.longBitsToDouble(0x3fe273c4493787f7L), Double.longBitsToDouble(0x3fea1875bd42790bL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.net.URI:\ud80e\ude21\udbcd\udce3\uda95\udeb2 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 5, 2, 4, "\ud80e\ude21\udbcd\udce3\uda95\udeb2", "\u8e17\u1397\u695a\u389c\u216f", "\udaaf\ude09\ud991\uded8",
        13, 77458, 1369039047, 8041975191379066450L, 30294L, true, false, (char) 53440, (char) 13830,
        Double.longBitsToDouble(0x3fed7ffd59b47cdfL), Double.longBitsToDouble(0x3fda0210ff869e60L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 7, 8, "\ud8e8\udca5\udbd5\udfd9\udae5\udd5f\udba3\udcec\udaef\udd3e\udbcd\ude2f\udbf0\udecd\ud9ce\udd30\udaa5\udedf\ud9c6\udc9f\udbed\ude3e\udaa8\udc2d\udaaf\ude09\uda98\udd62\udad6\ude96\udba9\udddc\ud819\udd96\udb9b\udc85\udb93\uddfc\ud9b3\udc59\udac9\udddb\ud9b2\udd7d", "\u2faf\u98e2\u837a\u7ccb\u378b\u1bfd\u54d2\uc42f\u6726\u876e\u65ba\u0a48\u0f6c\uacc1\ub705!", "\ud85b\udd02",
        12, 29116, -1151380291, 4404533533424136092L, 74843L, true, false, (char) 27655, (char) 87,
        Double.longBitsToDouble(0x3fd9995db33d9854L), Double.longBitsToDouble(0x3fdcf5590eaa1930L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 1, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\ud9fd\udd05", "\u695a\u452e", "\uda49\udfac\ud8b8\udfae\uda81\ude5e\udbe7\udca7\udba9\udd80\ud819\udd96\udadf\udc67\ud80b\udf2f\ud9b3\udc59\ud9f0\uddce\ud9ce\udd7d\udaf5\udc47\ua4b2\udba0\udf0a\udaf6\udfa6\uda9c\ude4a\ud986\ude71\ud968\udc8d\uda35\udc79\uda4a\ude22\udb94\udf98\ud9fa\uddc1\udbee\udd68\udb15\ude98\ud830\udf1f\u1422\udb4f\udca9",
        5, 7636, 111561777, 498921813370054637L, -53062L, true, false, (char) 51017, (char) 60603,
        Double.longBitsToDouble(0x3fd8f640a371a8c0L), Double.longBitsToDouble(0x3fca67b8eebc2030L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 0, 0, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud879\udd31\ud907\ude76\uda65\udea9\ud9c6\udcc7\u8c82\uda49\udfac\udaaf\ude09\ud843\udf51\udb2c\udd98", "\u4a1a\ud7af\ua489", "\udaf5\udc47\ua4b2\u830b\udaf6\udfa6\uda9c\ude4a\ud986\ude71\ud968\udc8d\uda35\udc79\uda4a\ude22\udb94\udf98\ud9de\udc32\udbee\udd33\udb15\ude98\ud830\udf1f\u1422\uda3d\udfe6\uda2f\udf99\u7691\udbf1\udcad\udb6f\udc72",
        29, 70728, -50830140, -2259828697132813939L, -29487L, false, true, (char) 42567, (char) 27579,
        Double.longBitsToDouble(0x3fa7835b59995db0L), Double.longBitsToDouble(0x3fd9ecc2ab9eab20L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 0, "\ud966\udf09", "\u540c\u2baa\u5079\177\ud459\u452e\ud46e\u3aa9\u9c99\u0144\u5887\u299f", "\ud97a\udd60\ud80c\udd93\uda6d\udc8e",
        25, 93539, 590232117, -23700285530611537L, -94464L, true, true, (char) 18897, (char) 11925,
        Double.longBitsToDouble(0x3fdcf20b73071ad4L), Double.longBitsToDouble(0x3fedbabef1bb40b6L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 6, 6, 7, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud8f3\udf5a\ud93d\uded4\udaa5\udedf\ud9c6\udc9f\u8c82\uda49\udfac\udaab\udf09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\ud9b4\udd53\ud80b\udedf\ud9b3\udc59\udac9\udddb\ud9ba\uddd3", "\ua647\u3575", "\udb4d\udd54\uda35\udc79\ud9da\uddea\udb94\udfce\ud9fa\uddc1\udbee\udd68\udb15\ude98\ud830\udf1f\u1422\u2549\ud9b8\udf26\u7714",
        17, 44831, -2106090392, 435014276388334700L, 28022L, false, true, (char) 20633, (char) 60481,
        Double.longBitsToDouble(0x3fca67ae8ebc2030L), Double.longBitsToDouble(0x3fe17835b5999556L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 7, 1, 8, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\ud96c\uddfc\udbdf\udd27\udad0\uddfe", "\u216f\u3aa9\u9c99\uc258", "\udb9e\udf31\udb3b\ude87\udbee\udd0d\udb8f\ude9b\ud9b3\udc59\udac9\udddb\ud9ba\uddd3\uda20\udc4f\udae7\udffb\uda5e\uddec",
        5, 47272, 1908386417, -2374644609470471557L, 84442L, true, false, (char) 30680, (char) 19914,
        Double.longBitsToDouble(0x3fc0481ae5f8a8e8L), Double.longBitsToDouble(0x3fef616674ba3e51L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 4, "\ud8e8\udc77\ud9eb\udf82\udb6a\ude06\uda0a\udc95\udbbc\udca2\ud85b\udece\udb78\udf8e\ud97c\udff6\udaa5\udedf\ud9c6\udc9f\u8c82\uda49\udfac\udaab\udf09\uda81\ude50\udaf9\udf4f\udb9e\udf31\ud819\udd96\ud9b4\udd53\ud912\udf2d\ud9ab\udea2", "\u69e6\u4c88\ua647\u3575\u03b8\u7f79\u5412\u7918\ua856\uc42f\u6726\u3392\ua8ab\u0aaf\u5e99\u6bd5\u3d06\ub234\u475b\u0100", "\uda30\udca3\uda7e\udcb1\udac3\udf89\u6829\udbf4\udccb\ud854\udf29\ud98e\udd4c\ud8e5\udc14\udb48\udfe5\ud87e\ude14",
        14, 33437, 756721274, -8923991696646378631L, 96136L, false, false, (char) 56302, (char) 51828,
        Double.longBitsToDouble(0x3fde44263b441ed6L), Double.longBitsToDouble(0x3fdd03449120d1d6L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 8, 7, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udad2\udf8a\000\000\ud861\udd98\udad3\udf3c\ud8e5\udca4\u8c82\uda49\udfac", "\000", "\u00d4\udac5\udec1\ud9c3\udc64",
        13, 91680, 590232117, -23700284574295121L, -34464L, false, false, (char) 23101, (char) 30078,
        Double.longBitsToDouble(0x3fdb9f98772200d4L), Double.longBitsToDouble(0x3fc1a010db6fddbcL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer$StringKD:@?\0121=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer$StringKD:@?\012",
        Z.run(T, 2, 0, 0, 6, "\ud8e8\udc77\u0ed6\uda95\udeb2\udbcc\uddb2\ud851\ude25\udbb4\udf79\ud879\udd31\ud97c\udff6\ud930\udda4\uda44\udc89\u916a\u465c\udb6c\udee6\ud827\udfca\udbe7\udca7\uda62\ude3b\ud819\udd84\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\u9a64\u0370\u9810\u457f\ua7b2\u8154\u248c\u806c\u07b2\u5e99\u4335\u5dd6\ub1ab", "\ud85b\udd02\ud816\udf89\uda44\udff8\uda7e\udcb1\ud879\udf84\ud8f9\udd81\ud969\udce6\udb7f\udf9d\uda37\udfb4\ud8e5\udc14\uda9e\udded\udbea\ude8a\uda2b\udcbb\u6f45\ud908\udee0",
        0, 96349, 284797094, -2226147319721155610L, 77705L, true, false, (char) 38387, (char) 142,
        Double.longBitsToDouble(0x3fe1d800067473f3L), Double.longBitsToDouble(0x3fc2046bb2b6e728L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 0, 0, 6, "\ud8e8\udc77\udba3\udfe2\uda95\udec3\udbcc\uddb2\000\000\ud97b\udc5c\ud97c\udff6\ud930\udda4\uda44\udc89\u916a\u465c\u00dd\000\udbe7\udca7\uda62\ude3b\ud819\udd84\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u0b83\u6dda\u7348\u028a\u9810\u457f\ua7b2\u8154\u248c\u806c\u07b2\u0b55\u4335\u5dd6\ub1ab", "\ud85b\udd02\ud816\udf89\uda44\udff8\uda7e\udcb1\ud879\udf84\ud8f9\udd81\ud969\udce6\udb7f\udf9d\uda37\udfb4\ud8e5\udc14\uda9e\udded\udbea\ude8a\uda2b\udcbb\u6f45\ud859\ude67",
        12, 96613, 6307461, -166914661582656918L, -90753L, false, false, (char) 33091, (char) 84,
        Double.longBitsToDouble(0x3fe3f2a317bb2d1bL), Double.longBitsToDouble(0x3feb4ad61894c7c8L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.net.URI:\ud8e8\udc15\uda09\udeab\uda6e\udfb5\ud8d0\uddb0\ud851\ude25\udbb4\udf79\udb03\udc2c\ud97c\udff6\ud874\udc8c\uda44\udc74\u916a\u465c\udb6c\udee6\ud9b6\udf71\ud98e\ude8b\uda62\ude3b\ud819\udcf7\udb39\ude55 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.net.URI:\ud8e8\udc15\uda09\udeab\uda6e\udfb5\ud8d0\uddb0\ud851\ude25\udbb4\udf79\udb03\udc2c\ud97c\udff6\ud874\udc8c\uda44\udc74\u916a\u465c\udb6c\udee6\ud9b6\udf71\ud98e\ude8b\uda62\ude3b\ud819\udcf7\udb39\ude55 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 5, 1, 4, "\ud8e8\udc15\uda09\udeab\uda6e\udfb5\ud8d0\uddb0\ud851\ude25\udbb4\udf79\udb03\udc2c\ud97c\udff6\ud874\udc8c\uda44\udc74\u916a\u465c\udb6c\udee6\ud9b6\udf71\ud98e\ude8b\uda62\ude3b\ud819\udcf7\udb39\ude55", "\u85f2\u7dc2\uc755\u2c53\u2faf\u98e2\u837a\u8155\u0370\u9810\u15b1", "\udb73\udeb1\ud924\ude22\ud89b\udf74\u1422\udb09\udc4d\ud943\udd17\u768b\ud841\uddf6\udb0b\udf4b\udb49\udc39\uf89a\uda44\udff8\uda7e\udcb1\ud911\udf71",
        13, 37283, 1448875608, -3837354026740587601L, 23495L, false, true, (char) 26093, (char) 26259,
        Double.longBitsToDouble(0x3fe2bb29e465e01eL), Double.longBitsToDouble(0x3fe6c2c1efb6dc67L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Character:\000 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 6, 1, 4, "\000", "R", "",
        4, 60390, -1508986717, 7707934276348597L, -100000L, false, false, (char) 65256, (char) 20262,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 0, 3, 7, "8\000\ud9d9\ude19\udbc2\uddf6\ud99f\udcf6\000", "\u331b", "\uda49\udfac",
        2, 9545, 1744830650, -3672627303604737684L, 14975L, true, true, (char) 21229, (char) 54228,
        Double.longBitsToDouble(0x3fe5d0e3a10c0e0dL), Double.longBitsToDouble(0x3f928b5b4705d140L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Character:\000 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Character:\000 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 1, 1, 4, "\000", "R", "",
        4, 60390, -1508986717, 7707934276348597L, -100000L, false, false, (char) 65256, (char) 20262,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Integer:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 0, 3, 7, "8", "", "\000\000\ud961\ude30\ud8f0\udca4\000\u8c82\uda25\udc71\udaa6\udf09\ud9f3\udd08\000\ud80c\uddec\uda52\udd6f\udbb1\udfe7\ua996\udbc3\udc61\udab9\ude32\u00d8\u3b8e",
        10, 24338, 1134324280, 4793270919386422183L, -18601L, false, false, (char) 34068, (char) 17316,
        Double.longBitsToDouble(0x3fdd8d5a43fb9bd0L), Double.longBitsToDouble(0x3fb929eee224ea18L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Long:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Integer:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 4, 3, 5, "8", "\u9efc", "\000",
        28, 29243, 15461, 5511974936608478011L, -70561L, false, false, (char) 40173, (char) 63092,
        Double.longBitsToDouble(0x3fec9a69eee1bc1eL), Double.longBitsToDouble(0x3fea8867f4f655f7L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 0, 1, 7, "8\udacf\udc67\u8ade\ud8a9\ude40\ud99f\udcf6\000", "\u331b", "\uda49\udfac",
        2, 67273, -16325439, 5169609807849408982L, 14975L, true, true, (char) 21229, (char) 54228,
        Double.longBitsToDouble(0x3fe5d0e3a10c0e0dL), Double.longBitsToDouble(0x3f928b5b4705d140L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Double:8.0 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Double:8.0 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 2, 2, 0, "8\000", "\u0d25\000\000\ud393\u331b\u3c65\u3aa9\u9c99\uae54\u7a7a\ucbfc\u99b5\u03ee\u5b74\u3e47\u5d34\u3dd7\uc891\uc361\u7ecc\u8b3b\u1444\u6c82", "\ud996\ude03\ud9e2\udfc4\udb32\ude07\ud81c\udf4e\ud87a\udf68\ud98c\udeaf\udad1\udd00",
        2, 2410, 1909468598, 6843405678211920500L, -80020L, true, true, (char) 29682, (char) 37034,
        Double.longBitsToDouble(0x3fda6d5683409ed8L), Double.longBitsToDouble(0x3fe49346b0aa881eL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Integer:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Integer:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 3, 3, 7, "8", "\u2c4b", "\000",
        28, 66203, 58649, 5511974936608440320L, -70561L, false, false, (char) 13549, (char) 63092,
        Double.longBitsToDouble(0x3fef4001e8e1bc1eL), Double.longBitsToDouble(0x3fea886004f655f7L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Byte:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 5, 3, 8, "8", "\ub0af\u46c6\u7d67\u47f1\u9525\u9aef", "\uda25\udc71",
        2, 89509, 0, -7091640765524399764L, 65151L, true, true, (char) 21235, (char) 5589,
        Double.longBitsToDouble(0x3fe5d000030a0e0dL), Double.longBitsToDouble(0x3fc120bc50e0ba28L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Long:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Long:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 4, 4, 3, "8", "\uc0ec", "\000\ud961\ude30\udb0d\udd93\u3c65\u8c82\uda49\udfac\uda2e\udf0d\ud9e5\udcf3\u0edb\ud80c\uddec\ud8e7\uddf9\udbb1\udf92\u5fa5\udbc3\udc61\ud977\uddd2\ud8b6\udfbe\udad5\ude2c\ud949\udef9\udaab\udfb8\udafa\udd70\ud98a\udd48\ud9c8\udfdc",
        6, 54001, 355372040, 309779684328792684L, -91346L, false, true, (char) 10070, (char) 50958,
        Double.longBitsToDouble(0x3fe6fcd8b6241b65L), Double.longBitsToDouble(0x3fddb1697a6df37cL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Byte:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Byte:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 5, 5, 8, "8", "\ub0af\u46c6\u7d67\u47f1\u9525\u9aef", "\uda25\udc71",
        2, 89509, 0, -7091640765524399764L, 65151L, false, false, (char) 64757, (char) 5589,
        Double.longBitsToDouble(0x3fe5d000030a0e0dL), Double.longBitsToDouble(0x3fc120bc50e0ba28L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Short:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Short:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 5, 1, 8, "8", "\ub0af\u64f4\u7d41\u47f1\u2312\u9aef", "\uda25\udc71",
        3, -1000, 0, 0L, -100000L, false, false, (char) 21235, (char) 5589,
        Double.longBitsToDouble(0x3fe5d000030a0e0dL), Double.longBitsToDouble(0x3fc120bc40e0ba28L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Integer:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Integer:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 5, 1, 8, "8", "\ub0af\u64f4\u7d41\u47f1\u2312\u9aef", "\udbe9\udfe4",
        5, -1000, 0, 286075392L, -99834L, true, false, (char) 21235, (char) 5589,
        Double.longBitsToDouble(0x3fe5d000030a0e0dL), Double.longBitsToDouble(0x3fc120bc40e0ba28L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Short:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 5, 6, 8, "8", "\ub0af\u64f4\u7d41\u47f1\u2312\u9aef", "\uda25\udc71",
        3, -1000, 0, 0L, -100000L, false, false, (char) 21235, (char) 5589,
        Double.longBitsToDouble(0x3fe5d000030a0e0dL), Double.longBitsToDouble(0x3fc120bc40e0ba28L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 8, 1, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud879\udd31\ud97c\udff6\udaa5\udedf\ud9c6\udc9f\u8c82\uda49\udfac\udaaf\ude09\uda81\ude50\udbcc\udf1b\udbae\uded7\ud819\udd96\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\u7ccb\u3780\u7952\u54d2\uc42f\u6726\u3392\uc730\u6b5e\u5e99\ua2cf\ubb50\ub234", "\ud85b\udd02",
        24, 29116, -1151380291, 4404533536897019804L, 56591L, true, false, (char) 45940, (char) 36296,
        Double.longBitsToDouble(0x3fe67aac86b66be4L), Double.longBitsToDouble(0x3fd8aabb1d8fd43eL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 1, 4, "\000", "R", "",
        13, 43152, -1508986717, 2817954101755546176L, 20646L, false, false, (char) 54272, (char) 0,
        Double.longBitsToDouble(0x3fb10000305ad0f8L), Double.longBitsToDouble(0x3feac80bbd31543aL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Float:8.0 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Float:8.0 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 5, 1, 8, "8", "\ub0af\u64f4\u7d41\u47f1\u2312\u233b", "\uda25\udc71\u008a\000\uda06\udeef\ud845\udf6c\ud95e\udf47\ud9d1\udc01\017\ud8e5\udd11\udab9\ude32\u00d8\u3b8e\udb16\udf62\ud851\udf47\udad2\udf41",
        7, 19245, 434293188, -454628530977650496L, -29008L, false, true, (char) 5321, (char) 57479,
        Double.longBitsToDouble(0x3fa234c86505f180L), Double.longBitsToDouble(0x3fe4ccf5ca0ee344L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Long:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Long:8 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 5, 1, 8, "8", "\ub0af\u64f4\u7d41\u47f1\u4780\u9aef", "\ud835\udd5a",
        6, 49760, 126, 0L, -100000L, false, false, (char) 21235, (char) 5589,
        Double.longBitsToDouble(0x3fe5d000030a0e0dL), Double.longBitsToDouble(0x3fc120bc40e0ba28L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 8, 1, 4, "\ud8e8\udc77\udba3\udfe2\uda95\udeb2\udb65\udfb1\udafa\udd43\udbcd\ude2f\ud879\udd31\ud97c\udff6\udaa5\udedf\udb0a\udd9c\u8c82\uda49\udfac\udaaf\ude09\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd40", "\u2faf\u98e2\u837a\u7ccb\u378b\u7952\u54d2\uc42f\u6726\u3392\ua8ab\u0aaf\u5e99\u6bd5\ub705\u1ea6", "\ud85b\udd02",
        24, 29116, -1151380291, 4404533536897019804L, 56591L, true, false, (char) 45940, (char) 36296,
        Double.longBitsToDouble(0x3fdcf55903c81930L), Double.longBitsToDouble(0x3fd8aabb1d8fd43eL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 3, 7, "-\000\udb65\uddce\ua40a\ud99f\udcf6\000", "\u32ba", "\uda49\udfac",
        2, 30777, 689535680, -3672584603039880852L, -99969L, false, false, (char) 21018, (char) 54228,
        Double.longBitsToDouble(0x3fe5d0e3a10c0e0dL), Double.longBitsToDouble(0x3f928b5b4705d140L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 3, 0, 5, "-\ud907\uddf1\ud870\ude37\ud83f\udf55\ud9c0\ude35\000\ud95f\udcde\ud819\udc42\ud8f0\udc78\ud893\udeff\udaf3\udec9", "\u0352\u49ed\ua2d1\u60f8\u787d\ub85c\u5d34\u3dd7\u627e", "\ud8bb\udcc2",
        32, 91679, -1386136891, -1266193530614005239L, 98366L, false, true, (char) 7359, (char) 31225,
        Double.longBitsToDouble(0x3fe160eaf80b9f03L), Double.longBitsToDouble(0x3feb455229398522L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.Long:9 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Short:9 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 4, 1, 8, "\u0e59", "\ub0af\u64f4\u7d41\u47f1\u2312\u41c0", "\uda25\udc71",
        3, -1000, -989855744, 459561500672L, -100000L, false, false, (char) 21235, (char) 5589,
        Double.longBitsToDouble(0x3fe5d000030a0e0dL), Double.longBitsToDouble(0x3fc120bc40e0ba28L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 1, 4, "-", "\u3ba6", "\udadb\ude90\ud96c\udca0\ud812\udf56\ud9d3\udec1\udb37\ude1f\ud8e7\udd8b\udb1f\udf0b\u1097\ud84c\udd4d\udad9\ude6b\000\000\uda8c\udd93",
        3, 50361, 1954565425, 5481239545666571595L, 87627L, false, true, (char) 23642, (char) 31381,
        Double.longBitsToDouble(0x3fdc611791027124L), Double.longBitsToDouble(0x3fe561f511c80f71L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 3, 2, "-\000\udb65\uddce\ua40a\uda4c\udeb9\000", "\u32ba", "\uda49\udfac",
        2, 30777, 689535680, -3672584603039880852L, -99969L, false, false, (char) 21018, (char) 54228,
        Double.longBitsToDouble(0x3fe5d0e3a10c0e0dL), Double.longBitsToDouble(0x3f928b5bc7033140L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 3, 2, "-\000\ud969\uddce\ua40a\uda4c\udeb9\udad2\ude88\u3dec\ud9ae\udd37\udb0d\udd32\u3c65\u8c82\ud9d3\udfb1\udaa6\udf09\uda90\ude36\ue52c\ud840\udd77\udb79\ude63\udbb1\udfe7\uda39\udc1d\ud9e9\uddc0\udab9\ude32\ud90c\udc85\u3b8e\ud8c2\ude2c\ud93f\udd93", "\u2a58\u69bb\u8cb2\u00b6\u7df3\u4517\u63f5\u605f\uc5cc\ua4c0\u7a36\u84be\u2aa9\u5477\uc529\u194d\u2cc5\u0bf7\u40b3\ubb4b\u8d46\u9d69\ub040\uae49\uab3d\u6ca6\ud193\u31f3\u1d70\ud4b4\u1fbe\ub7dc\u8a29\u1693\u4ec1\u3116\u8b87", "\ud986\ude1e\udbdd\udd38\u54f8\udb68\udc3f\ud9b0\udfa7\ua877\ud820\udc2a\uda4a\udf15\ud9c0\udece\ud879\uddc8\ud8f3\udf00\udb14\udf06\udb7b\udd78\udb76\udeda\ud9d8\ude98\uda4f\udf62\udbcf\udfce\ua3f0\ud814\ude75\udb83\udf92\ud95f\udd2b\ud8ab\uddac\udb0f\udddf\ud844\udfe6\ud865\udd93\uda1c\ude7c\ud87f\udf66",
        45, 61836, 1015772956, 901356353100788333L, 27800L, false, false, (char) 28100, (char) 55120,
        Double.longBitsToDouble(0x3fc6859cf88dd640L), Double.longBitsToDouble(0x3f80f2c583cb5080L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 8, 1, 4, "\ud86d\udca3\udba3\udfe2\uda95\udeb2\udbcc\uddb2\udafa\udd43\udbcd\ude2f\ud879\udd31\ud97c\udff6\udaa5\udedf\udbbc\udea1\u8c82\ud803\ude51\ud91c\udf73\uda81\ude50\udbe7\udca7\udba9\udd80\ud819\udd96\udadf\udc67\ud80b\udf2f\ud9b3\udc59\udac9\udddb\ud9ce\udd7d", "\u2faf\u98e2\u837a\u7ccb\u5906\ua877\u54d2\ucb5c\u6726\u3392\ua8ab\u0aaf\u5e99\u6bd5\ub705\ub234", "\ud85b\udd02",
        24, 29116, -1151380291, 4404533536897019804L, 56591L, true, false, (char) 45940, (char) 36296,
        Double.longBitsToDouble(0x3fdcf55903c81930L), Double.longBitsToDouble(0x3fd8aabb1d8fd43eL)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.Double:8.0 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Double:8.0 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 5, 1, 8, "8", "\ub0af\u64f4\u7d41\u47f1\u2312\u9aef", "\uda25\udc71",
        8, 48134, 0, 0L, -100000L, false, false, (char) 21235, (char) 5589,
        Double.longBitsToDouble(0x3fe5d000030a0e0dL), Double.longBitsToDouble(0x3fc120bc40e0ba28L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|forType|java.lang.Class|static",
    "M|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|_parse|java.lang.String,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:int,java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|_parseDouble|java.lang.String|new:com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:int,java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|_parseInt|java.lang.String|new:com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:int,java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|_parseLong|java.lang.String|new:com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:int,java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|deserializeKey|java.lang.String,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:int,java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|getKeyClass||new:com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:int,java.lang.Class",
    "C|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|<init>|int,java.lang.Class",
    "C|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|<init>|int,java.lang.Class,com.fasterxml.jackson.databind.deser.std.FromStringDeserializer",
    "M|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|forType|java.lang.Class|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
