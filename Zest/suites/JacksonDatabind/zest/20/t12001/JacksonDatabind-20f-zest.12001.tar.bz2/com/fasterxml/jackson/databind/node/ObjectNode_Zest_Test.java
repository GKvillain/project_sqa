package com.fasterxml.jackson.databind.node;
import org.junit.Test;
import static org.junit.Assert.*;
public class ObjectNode_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\u640c\u20a7\u40cc\u7731\ub05f\uad97\ub824\u0516] |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 12, 14, 2, "\ud99b\ude02\udbf2\udc61", "\u640c\u20a7\u40cc\u7731\ub05f\uad97\ub824\u0516", "\ud9ac\ude90\udab4\udff7\uda3b\udf70\uda1b\udffb\ud913\udf2d\udbc7\udf67\ud8b4\udc08\uc60a\ud9d8\udf00\udb48\ude28\udba6\udd6d\u3567\udb5f\ude3e\udb06\udc90",
        11, 89003, 465098229, -3471955653628632474L, 71398L, false, true, (char) 27008, (char) 53521,
        Double.longBitsToDouble(0x3fd68739d79168bcL), Double.longBitsToDouble(0x3fe8b8669454f571L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:{} |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 2, "\ud99b\ude02\udbf2\udc61", "\u63e1\u7318\u40d5\u7731", "\ud8f9\udc31\udb48\udd80\uda8e\udfb6\ud959\udecb\ud9ac\udebf\uda97\udca8\udb7b\udd11\uda1b\udffb\ud913\udf2d\udb4d\udf6a\ud8b4\udc08\uc60a\ud9d8\udf00\udb48\ude28",
        35, 18779, -202559755, -8837577179662638744L, 5882L, true, false, (char) 52245, (char) 61071,
        Double.longBitsToDouble(0x3fe30e18fc6c14a6L), Double.longBitsToDouble(0x3fd68739d79168bcL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 2, "\ud83a\udd31", "\u30ff", "\uda64\udebd\ud9b0\udd86",
        -5, 77568, -417817175, 274585849167872L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fca4006200280f4L), Double.longBitsToDouble(0x3e40000000000000L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\ubb4d\u678b\uac56\u1f87\u3dce\ud083\u2b53\u4f86\u0e76\u7a92\u3b70\u711f\u6d97\ubc93\ua0a5] |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 12, 14, 5, "\ud9d2\udf7d\ud9be\ude14\udb40\udcb2\udaa6\udd1c\udb01\udd1a\ud891\udc8d\uda64\udebd\ud9ac\udf65\ud89e\udd06\udb5d\udeed", "\ubb4d\u678b\uac56\u1f87\u3dce\ud083\u2b53\u4f86\u0e76\u7a92\u3b70\u711f\u6d97\ubc93\ua0a5", "\ud867\ude53",
        19, 25330, 1838047846, 3355377879106100614L, -11521L, false, false, (char) 38149, (char) 24614,
        Double.longBitsToDouble(0x3fd170cd28a8b28aL), Double.longBitsToDouble(0x3fe49f47471f7bf8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\u640c\u20a7\uac94\u7731\ub05f\uad97\ub824\u0516] |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 13, 14, 2, "\ud99b\ude02\udbf2\udc61", "\u640c\u20a7\uac94\u7731\ub05f\uad97\ub824\u0516", "\ud9ac\ude90\udab4\udff7\uda3b\udf70\uda1b\udffb\ud913\udf2d\udbc7\udf67\ud8b4\udc08\uc60a\ud9d8\udf00\udb48\ude28\udba6\udd6d\u3567\udbda\ude3c\udba1\udf63",
        11, 89003, 465098229, -3471955653628632474L, 71398L, false, true, (char) 27008, (char) 53521,
        Double.longBitsToDouble(0x3fd68739d79168bcL), Double.longBitsToDouble(0x3fe8b866965cf571L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 12, 12, 2, "\ud99b\uddf5\udbf2\udc61", "\u640c\u20a7\u7e21\ucdd3\ub0c8\uad97\ub824\ud0a3\ua921\u7446\u243e\u5239", "\ud913\udf2d\udbc7\udf67\ud8b4\udc08",
        53, 98926, -477930096, 778138034586422963L, -9473L, true, true, (char) 43623, (char) 51135,
        Double.longBitsToDouble(0x3fee98ddc266cfd1L), Double.longBitsToDouble(0x3fe33b6c75862e90L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\ud30c\u20a7\u40cc\u44d3\ua8d2\uad97\u5acc\u1457] |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=java.util.ArrayList:[\ud30c\u20a7\u40cc\u44d3\ua8d2\uad97\u5acc\u1457] |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 12, 10, 2, "\ud99b\ude02\ud83c\udc66", "\ud30c\u20a7\u40cc\u44d3\ua8d2\uad97\u5acc\u1457", "\ud9b2\udf14\udaae\udd55\uda3b\udf70\uda22\udf9e\ud88b\ude69\udbc7\udf67\ud8b4\udc08\uc60a\ud9d8\udf00\ud833\udd2e\udba6\udd6d\u3567\udb5f\ude3e\udb06\udc90",
        11, 36795, -1321715765, -3511174408757681562L, 71398L, false, true, (char) 22337, (char) 32724,
        Double.longBitsToDouble(0x3fd68739d79168bcL), Double.longBitsToDouble(0x3fe8b8669454f571L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 0, 0, "\ud99b\ude02\000", "", "\ud800\udd2b",
        17, 47216, -1688277796, 63932L, -100000L, false, false, (char) 11776, (char) 59390,
        Double.longBitsToDouble(0x3fd7fbd069a45462L), Double.longBitsToDouble(0x3fd13a03de77c762L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 11, 14, 7, "\ud99b\ude02", "\u5900", "\uda64\udebd",
        43, 47216, -1688277796, -1794511102397908548L, -44196L, false, true, (char) 34627, (char) 59489,
        Double.longBitsToDouble(0x3f47a0c000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\u20a7\u4eed\u35e8\ub908\uad97\ub837\ub215\u5d21\u9dad\u1715\u9db7\u0c02\u3011\uae45] |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=com.fasterxml.jackson.core.JsonToken:START_OBJECT |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 10, 3, 2, "\udb37\uddcf\ud8db\udd8b\ud813\uddee", "\u20a7\u4eed\u35e8\ub908\uad97\ub837\ub215\u5d21\u9dad\u1715\u9db7\u0c02\u3011\uae45", "\uc52e\ud9d8\udf7a\ud921\udd95\ud91d\udf1c\u359a\udb5f\ude3e\ud90c\udc93\udb84\udce9\uda83\ude74\ud8bb\udf97\udba5\udd08\udb55\udf99\ud9e6\udf25\u5589\uda3b\udf8e\uda19\udf98\ud8d2\udf3c\udbdd\udcf2\ud9af\udc89\udb7b\udef8\ud828\udc4d\ud839\udfa5\ud8d1\ude44\udaaf\udc18\ud9c8\udcf3",
        37, 73653, -861737473, -6012788203896683987L, 63404L, false, true, (char) 33124, (char) 9545,
        Double.longBitsToDouble(0x3fc1757d7480744cL), Double.longBitsToDouble(0x3feca28a995b1869L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedEntryIterator:@? |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 2, "\ud97e\udec3\udbf2\udc61", "\u640c\ua736\u72f7\u7b9f\ub05f\uad97\u62c0\u047c", "\ud9ac\ude90\udab4\udff7\uda3b\udf70\uda1b\udffb\udb3e\udfd5\udbb9\udc8c\ud8b4\udc08\uc60a\ud9d8\udf00\udb48\ude28\udb8b\udc6d\ud803\udcc1\udb54\udc5d\udb06\udc90",
        11, 89003, 465098229, 7974505749286904422L, 71398L, false, true, (char) 27008, (char) 53521,
        Double.longBitsToDouble(0x3fd68739d79168bcL), Double.longBitsToDouble(0x3fe8b8669454f571L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonToken:START_OBJECT |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 1, 3, 14, 2, "\ud99b\ude02\udbf2\udc61", "\u640c\u20a7\u40cc\u7731\u93ac\u02c4\ub78f\u3d6c", "\ud8c1\uddad\udab4\udff7\uda3b\udf70\uda1b\udffb\ud913\udf2d\udbc7\udf67\ud8b4\udc08",
        53, 98926, -968794736, 778138446903283379L, -9473L, true, true, (char) 43799, (char) 683,
        Double.longBitsToDouble(0x3fe594278a5b5dd1L), Double.longBitsToDouble(0x3fe33b6c75862e90L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 12, 14, 2, "\ud99b\ude02\udbf2\udc61", "\u640c\u20a7\u40cc\u7731\ub05f\uad97\ub824\u0516", "\ud9ac\ude90\udab4\udff7\uda3b\udf70\uda1b\udffb\ud913\udf2d\udbc7\udf67\ud8b4\udc08",
        53, 98926, -968794736, 1209639586188914200L, -9473L, true, true, (char) 43623, (char) 51135,
        Double.longBitsToDouble(0x3fe5d0ddc266cfd1L), Double.longBitsToDouble(0x3fe33b6c75862e90L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 6, 14, 2, "\udb54\udf9e\udade\ude5d", "\u7a02\u81a3\u0d40\u3176\ub05f", "\ud815\uddc6\udab0\udd40\ud989\udd27\ud9ac\ude90\ud963\ude4f\uda3b\udfc0\uda8d\udd54\ud85e\udf5f\udb98\udeac\uda5c\udfaf\udb54\udc34\ud9d8\udf0c\udb48\ude28\ud82f\udda0\u35a8\udb5f\ude3e\udb06\udc90\udb75\udfe9",
        53, 54069, -808377670, 7889288992872510055L, -66458L, true, false, (char) 57617, (char) 22442,
        Double.longBitsToDouble(0x3fea97ad4b170cd2L), Double.longBitsToDouble(0x3fb53d5c640f9ac8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=java.util.LinkedHashMap$LinkedValueIterator:@? |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 6, 5, 13, "\ud99b\ude02\udb94\udc52", "\u640c\u20a7\u4b91\u73ca\ub1f9\uad97\u7a72\u58ec\u5f42", "\udab4\udff7\uda3b\udf70\ud889\ude33\ud913\udf2d",
        38, 4707, 305868023, 2075254864186793360L, 67603L, true, false, (char) 40782, (char) 20234,
        Double.longBitsToDouble(0x3fea5f58e5f5f1caL), Double.longBitsToDouble(0x3fe5d0ddc34ecfd3L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 1, 11, 14, 0, "\ud99b\ude02\ud909\udc2b", "\u640c\u20a7\u40cc\u0b32\ub05f\uad97\ub824\u0516", "\ud9ac\ude9a\udab5\udc32\uda3b\udf70\uda1b\udffb\ud913\udf2d\udbc7\udf67\ud8ae\udc05\uc60a\ud9d8\udf00\udb48\ude28\udba6\udd6d\u3567\udb5f\ude3e\udb06\udc90",
        11, 45065, -1783823792, -3471955507599744410L, -27162L, false, true, (char) 27008, (char) 53521,
        Double.longBitsToDouble(0x3fd68739d79168bcL), Double.longBitsToDouble(0x3fe8b8669454f571L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 9, 14, 6, "", "\000", "\ud891\udc8d\uda64\udebd\ud9ac\udf65\000\udb22\ude11\ud8f9\udc31\udb48\udd80\uda8e\udfb6\ud959\udecb\ud9ac\ude90\udab4\udff7\uda3b\udf70\uda95\udff8\udacb\udf29",
        58, 4648, 3878135, 2075254529179344272L, 67603L, true, false, (char) 0, (char) 20005,
        Double.longBitsToDouble(0x3fea5f58e0000000L), Double.longBitsToDouble(0x3fe5d0ddc26600d1L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 2, "\ud99b\ude02\udbf2\udc61", "\u640c\u20a7\u40cc\u7731\ub05f\uad97\ub824\u0516", "\ud987\udd42\udab4\udff7\uda3b\udf70\uda1b\udffb\ud913\udf2d\udbc7\udf67\ud8b3\udfcd\uc60a\ud9d8\udf00\udb48\ude28\udba6\udd6d\u3567\udb5f\ude3e\udb06\udc90",
        11, 89003, 465098229, -3471955653628632474L, 71398L, false, true, (char) 27008, (char) 53521,
        Double.longBitsToDouble(0x3fd68739d79168bcL), Double.longBitsToDouble(0x3fe8b8669454f571L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 1, 11, 14, 10, "\ud818\udee6\udbf2\udc61", "\u640c\u20a7\u4812\u444e\u27fa\u5e06\u9dee\u31e9", "\ud9ac\ude90\udab4\udff7",
        54, 79511, -1606585134, -2039716035760068805L, -13699L, true, false, (char) 3551, (char) 39294,
        Double.longBitsToDouble(0x3fe7ab8df1b4f3edL), Double.longBitsToDouble(0x3fe060d2a7ad7a91L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.JsonToken:START_OBJECT |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 2, "\uda44\udcd8\udbc0\udd2c", "\u640c\u7a21\u4125\u6228\u6c43\u8a61\u0ba7\u693c\uac53\u9e6b", "\udb38\udcc6\ud978\ude02\udb0a\udd88\udbc8\udc43\ud8b4\udc08\udba4\udfbe\udb47\udc97\ud98c\udd5f\udbf7\ude27\ud943\udf82",
        44, 98142, -531430303, 2196402922239607615L, 5766L, true, false, (char) 51621, (char) 41721,
        Double.longBitsToDouble(0x3fe086c7a893ba5eL), Double.longBitsToDouble(0x3fcc690249907580L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 11, 11, 0, "\ud99b\ude02\udbf2\udc61", "\u640c\u20a7\u40cc\u7731\ub05f\uad97\ub824\u0516", "\ud9ac\ude90\udab4\udff7\uda3b\udf70\uda1b\udffb\udb63\udc34",
        58, 70844, 305868017, 2075254864186793360L, 67603L, true, false, (char) 37454, (char) 20095,
        Double.longBitsToDouble(0x3fea5f58e5f5f1caL), Double.longBitsToDouble(0x3fe5d0ddc766cfd1L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedEntryIterator:@? |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=com.fasterxml.jackson.databind.node.ObjectNode:{} |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 8, 4, 2, "\ud99b\ude02\udbf2\udc61", "\u640c\u20a7\u40cc\u7731\ub05f\uad97\ub824\u0516", "\ud8a6\udcaa\udab4\udff7\uda3b\udf70",
        26, 20866, -474908397, -8801609018335613705L, -10512L, true, false, (char) 39294, (char) 41139,
        Double.longBitsToDouble(0x3fe30f9f69259d5aL), Double.longBitsToDouble(0x3fea5f58e5f5f1caL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 14, 14, 2, "\ud99b\ude02\ud85d\udd21", "\u640c\u20a7\u40cc\u7731\ub05f\uad97\ub824\u0516", "\udb0e\ude41\udac2\udf98\udbe8\udd9a\uda1b\udffb\ud913\udf2d\udbc7\udf67\ud8b4\udc08\uc60a\ud9d8\udf00\udb48\ude28\udba6\udd6d\u3567\udb5f\ude3e\udb06\udc90",
        11, 89003, 465098229, -3471955653628632474L, 71398L, false, true, (char) 27008, (char) 53521,
        Double.longBitsToDouble(0x3fd89739d7916870L), Double.longBitsToDouble(0x3fe8b8669454f571L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedKeyIterator:@? |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 7, 14, 2, "\udbf3\ude90\udbf2\udc61\ud813\udd1e\udaa6\udd1c\udb35\udc74\ud891\udd02\uda6c\udfc1\uda00\udc15\ud9df\udc3b", "\u0516\u5d21\u9dad\u1715\u9db7\uc10b\u88c2\u0abf\ubf86\u0e76\u7a92\u3b70\ub002\u6d01\uaf16", "\udb75\udfe9\uda32\udf2b\udb51\udc50\ud81b\udff3\udb44\udcda\ud9eb\udd25\ud94a\uddf6\uda3b\udfa7\ud9fe\udec2\ud8d2\udf3c\udbdd\udcf2\ud87e\udddc\udb70\udcf7\udb1b\udde2\ud946\ude88\udbb6\udfc3\uda2e\udc2c\udb6e\udfe9\ud980\udd97\udb1e\ude33\ud981\udc30\ud8b4\udf25\uda4f\udda2\ud998\udd3a\udbc4\udcd9\ud9a3\udc3f\udb34\uddfe\udabd\udc90\ud93e\udd93\ud98f\uddfc\ud8ed\udc47\ud988\uddc4\udbf2\udd37\ud81d\ude86\ud82c\udfbb\udaf3\udc07\udba9\udfc6\ud82c\udf79",
        42, 10164, 2140611634, -5630955120524462493L, -75925L, true, true, (char) 44440, (char) 765,
        Double.longBitsToDouble(0x3fd23147895a9a8cL), Double.longBitsToDouble(0x3fef9dba45c6beb8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 9, 2, "\ud99b\ude02\udbf2\udc61", "\u640c\u20a7\u40cc\u7731\ub05f\uad97\ub824\u0516", "\ud9ac\ude90\udab4\udff7\uda3b\udf70\ud890\udd95\ud9a1\udc6b\udbbc\uded3\ud8b4\udc08\udb17\udddc\ud9c4\ude68\udb48\ude28\udba6\udd6d\u3567\udb5f\ude3e\udb06\udc90",
        11, 89003, 465098229, -3471955653628632474L, 71398L, false, true, (char) 59619, (char) 53521,
        Double.longBitsToDouble(0x3fd68739d79168bcL), Double.longBitsToDouble(0x3fe8b8669454f571L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 9, 9, 2, "\udbba\udc77\ud9b7\udef3", "\u84c2", "\ud9ac\udf65\ud89e\udd06\ud867\uddfb\ud8f8\udf90\udb48\udd80\ud806\uddf2\ud988\udc14\udb13\udfe5\udb27\udef1\ud89d\udc08\udb04\udffb\ud913\udf4b\udbc7\udf67\ud8b4\udc08\ud81a\udc9e",
        -4, 97264, 181174475, -285540202113585419L, 79808L, false, true, (char) 58480, (char) 27690,
        Double.longBitsToDouble(0x3fd66cf11b428420L), Double.longBitsToDouble(0x3feac338e559dcb8L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap$LinkedEntryIterator:@? |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=java.util.LinkedHashMap$LinkedEntryIterator:@? |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 8, 8, 7, "\ud99b\ude02\udbf2\udc61", "\u6456\u20a7\u40cc\u7731\ub05f\uad97\ub824\u0516", "\ud9ac\ude90\udab4\udff7\ud9f1\udcab\uda17\udf1e\ud913\udf2d\udbc7\udf67\ud8b4\udc08\uc60a\ud9d8\udf00\udb48\ude28\udba6\udd6d\u3567\udb5f\ude3e\udb06\udc90",
        11, 89003, 465098229, -3471955653628632474L, 71398L, false, true, (char) 26945, (char) 53521,
        Double.longBitsToDouble(0x3fd68739d79168bcL), Double.longBitsToDouble(0x3fe8b8669454f571L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 2, "\ud87f\udcb9\udaa8\uddb5\ud842\udc92\udb71\udd3d\udaea\udd3c\ud9a8\ude9a\ud8c3\udd26\ud9ac\udf65\ud89e\udd06", "\ubd2d\u5d21\u9dad\u8f18\u9db7\u0c7d\ucba5\u12b4\u26e0\u76fb\u9bd7\u6bc6\u13bd\ua4ad\u6d82\ua0a5\u9776\u851b", "\udb6d\udc5c\ud962\uddbc",
        22, 93251, 917021132, 3339837227314894L, -12904L, true, true, (char) 2059, (char) 5209,
        Double.longBitsToDouble(0x3fb030e678170d20L), Double.longBitsToDouble(0x3fe52421fb1ba084L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 10, "\ud98f\uded9\ud852\udc2b\ud99d\udda5\udaa6\udd1c", "\u78cb\u89c9\u4e6e\u5633\ud3ff\u0516\u5d21\u9dad\u5f25\u9db7\u0c02", "\udbc7\udf67\udaef\udca4\uc60a\ud903\udf15\ud8ba\udfcb\ud96a\udc05\u3567\udb5f\ude3e",
        -3, 27821, -238370997, 1997581682174141114L, 13772L, false, true, (char) 24614, (char) 15052,
        Double.longBitsToDouble(0x3fb53d6644e69b98L), Double.longBitsToDouble(0x3feb1e4be4e0d32dL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 0, "\ud99b\ude02\udbf2\udc61", "\u640c\u20a7\u40cc\u7731\ub05f\uad97\ub824\u0516", "\ud9ac\ude90\udab4\udff7\ud8e2\udc22\uda14\udfd5\ud913\udf2d\udbc7\udf67\ud8b4\udc08\uc60a\ud9d8\udf00\udb48\ude28\udba6\udd6d\ud815\udd6a\udb5f\ude3e\udb06\udc90",
        11, 89003, 465098229, -3471955653628632474L, 71398L, false, true, (char) 27008, (char) 53521,
        Double.longBitsToDouble(0x3fd68739d79168bcL), Double.longBitsToDouble(0x3fe8b8669454f571L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 2, "\ud996\udf06\udbf2\udc6a", "\u640c\u616d\u40cc\u7731\ub05f\uad97\ua83a", "\udbff\udc7e\udadd\udcd9",
        7, 71654, 312794160, 3902060805363956197L, -98058L, false, true, (char) 31324, (char) 10509,
        Double.longBitsToDouble(0x3fe59af6679b292eL), Double.longBitsToDouble(0x3fe30ec821259d5aL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 2, 1, "\udbd3\udc40\udbf2\udc61\ud813\udd1e\udab4\udc1c\udb33\ude2e\udaf0\uddc7\ud806\ude34\ud8d7\udca3\udb8d\ude94\ud87e\udc42\udac4\udf7f\udb18\ude0a\uda8e\udfb6\ud959\udecb\ud9ac\ude90\udab4\udff7\uda29\udd2a\udbf1\udd19\ud913\udf1d\udbc7\udf67\ud8b4\udc08\uc60a\ud8cd\ude02\ud952\udd77\udba6\udd6d\u3612\udb5c\udd9c\udaec\udec2\ud872\udd89", "\u7986", "\ueafd\uda3c\udc23\uda19\udf98\ud8d2\udf3c\udbdd\udcf2",
        23, 65279, -1472859052, -5193247328532091221L, -25144L, false, false, (char) 27399, (char) 36189,
        Double.longBitsToDouble(0x3fe3f10b91a87d7aL), Double.longBitsToDouble(0x3f95d1d43db24a80L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\u63e1\ua3fb\u34e6\u7731] |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=java.util.ArrayList:[\u63e1\ua3fb\u34e6\u7731] |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 10, 10, 2, "\ud971\udd4d\ud861\udcf9", "\u63e1\ua3fb\u34e6\u7731", "\ud8f9\udc31\udb48\udd80\uda8e\udfb6\ud959\udecb\ud9ac\udebf\uda97\udca8\udb7b\udd11\uda1b\udffb\ud913\udf2d\udb4d\udf6a\ud8b4\udc08\uc60a\ud9d8\udf00\udb48\ude28",
        52, 28447, -202559961, -8837678377682067096L, -2784L, false, true, (char) 52245, (char) 61071,
        Double.longBitsToDouble(0x3fe30e18fe8914a6L), Double.longBitsToDouble(0x3fd68739d79168bcL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 12, 2, "", "\u6e60", "",
        -5, 43416, 22906, 0L, -36256L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e1a400620000000L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 11, "\udacb\ude27", "\ub1c0\u3337\u7b37\ud064\u6a74\u9244\ucfb9\u9013\u00ea\u0a24\u5d55\u4d56\000\000\u103a\u2b53\u6fb3\u37ca\u2cd4\u8e95\u5ee9", "\ud854\ude75\udb8c\ude76\ud87a\udd82\udb7a\udf3b\ud881\ude50\udad2\udc61\udbb3\udd23\ud871\udfb8\udbcf\ude36",
        56, 59876, -337856132, 8447862068999343654L, -33792L, false, true, (char) 30422, (char) 22885,
        Double.longBitsToDouble(0x3fcb86dc086f2c18L), Double.longBitsToDouble(0x3fedc0bf0651d857L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 2, "+", "\u30ff", "\uda64\udebd\ud9b0\udd86",
        -5, 77568, -417817175, 274585849167872L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fca4006200280f4L), Double.longBitsToDouble(0x3e40000000000000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 14, "\ud83a\udd31\u1287\ud80c\udf5c\uda66\udd1c\udb96\ude0a\ud869\ude13\uda64\udebd\ud970\udd26\udbd3\udd73\udba1\udece\ud85a\udd06\u7cf8\000\000", "", "\ud913\udf2d\u0080",
        -5, 71527, 419505659, -3829679352651767097L, 19536L, true, false, (char) 5492, (char) 40471,
        Double.longBitsToDouble(0x3fd02ce9bf88d546L), Double.longBitsToDouble(0x3fd48326ceee84eaL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 2, "\udaa0\udf42\ud937\udc61\ud947\udcbd\uda66\udd1c\udb96\ude59", "\u6a74\000\u98ba\u3d24\u21bd\u605b1", "",
        38, 16395, -1982673175, 51428565467529216L, 66176L, false, true, (char) 9553, (char) 50630,
        Double.longBitsToDouble(0x3fd38b12f94c3f7cL), Double.longBitsToDouble(0x3fd650b65a0d2df4L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 14, 14, 2, "\ud83a\udd31", "\000", "\uda64\udebd",
        52, -1000, 0, 6928022766680320L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e434800c4000000L), Double.longBitsToDouble(0x3f4407a000000000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 8, "\udbd6\ude00\u818d\ud1fa\uda66\udd1c\udb96\ude0a\ud869\ude13\uda64\udebd\ud9b0\udd86\ud806\udfb4\uda1c\udc0c\ud8de\ude1c\ud800\uddbc\000\000\000\000\000\udb86\udc02\udb04\udd04", "\u648e", "\ud842\udf91\ufcad\uda41\uddab\udab0\udc9d\ud90c\ude62\udbf4\udea0\ud835\udc78",
        43, 66549, 409457278, -1348011598056061198L, -48921L, false, false, (char) 19567, (char) 2265,
        Double.longBitsToDouble(0x3fefda37ebdfdde6L), Double.longBitsToDouble(0x3fb80656a416cbf8L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 7, "\ud82a\udcb0\uda80\udefb\uda04\udf10\ud93f\udefb\udbb6\ude6c\ud869\ude13\uda64\udebd\ud9b0\udd86\000\udb22\ude11\udb4a\udc7a\ud85a\udcd3", "\000\000\000\ucea5\u2b53\000\000\u0cd5\u7f08\uc2c8\u3680\u744b\u4c9c\u47da", "\ud908\udd4d\uda9f\udda3\ud84a\udf6f\udb49\udc0d\udb58\udc40\udbbe\udd61\ud960\udd00\ud934\udc62\ud80a\udef1\ud8ee\udddc\udaa9\udf30\udb1a\udc6d\udbae\udcce\ud927\udffd\ud8bd\udc92\udba2\udd77\udad7\udd1c\ud984\ude37\uda1e\udeb0\udad2\uddb5\uda15\udf88\uda5f\ude7c\uda16\udca5\ud910\udcc9\ud997\udeab\udaf3\uddaa\ud8fe\udebe\udaa2\udc53\udb25\uded5\uda7a\udf72\udb75\udd34\u6a7a\ud918\ude32\uda5e\udd46\udb7b\udd2e\udbd5\udd2c\ud998\udced\ud97a\udd12\ud806\udf1b",
        47, 29514, -1170717044, -942251721889992302L, 20348L, true, false, (char) 7434, (char) 62496,
        Double.longBitsToDouble(0x3fe31201d7d34bbbL), Double.longBitsToDouble(0x3fda30bb79483540L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 2, "\000", "\000", "\000",
        25, -1000, 6160384, -1794511828181517892L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 2, "\ud8eb\udd0c\u1f87\ud813\udd1e\uda66\udd1c\udb96\ude0a\ud869\ude13\uda64\udebd\ud9b0\udd86\000\udb22\ude11\ud8f9\udc31\ud800\uddbc\000\000", "", "\ud913\udf2d",
        -5, -1000, 1249913856, -8557309959214476189L, -89166L, false, false, (char) 26600, (char) 43307,
        Double.longBitsToDouble(0x3fb7abebe4fb21a8L), Double.longBitsToDouble(0x3fdd448f22265f48L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:[null] |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 12, 8, "\ud9af\udd38", "\u30ff", "\uda64\udebd\udaea\udfc3",
        36, 77568, -1212179031, 1100654325546929115L, 18016L, true, false, (char) 17433, (char) 0,
        Double.longBitsToDouble(0x3fe5e8018e49a03dL), Double.longBitsToDouble(0x3febcf5404d8070dL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:[\u3adb\u5a2c\u40cc\u6a74\000\u98ba\ud4b9\u336b, null] |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 12, 1, "\ud83a\udd31\udbf1\udf86", "\u3adb\u5a2c\u40cc\u6a74\000\u98ba\ud4b9\u336b", "\000\000\000\udb86\udc02\ud913\udf2d\000\000\ud8dd\uddc6\ud859\udc88\ud9c8\udde3\ud9fa\udc1f\ud8c5\udcf2\udab2\ude63\ud893\ude11\udaa7\udf74\uda6f\uded5\udaa1\ude14\uda97\udd06\udb32\uded4\udbec\udf42",
        56, 1409, -310165453, -1478330400291324516L, 19464L, true, true, (char) 62104, (char) 36297,
        Double.longBitsToDouble(0x3fe7a62a296d3a8eL), Double.longBitsToDouble(0x3fe919b2c056e532L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 2, "\ub12b", "\u30ff", "\uda64\udebd\ud9b0\udd86",
        -5, 77568, 169, 273778395316224L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fca4000000280f4L), Double.longBitsToDouble(0x3e40000000000000L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 11, 2, "\ud9b0\ude25\ud827\udd8a\ud813\udd1e", "\ud062\u4150\u6a74\000\u98ba\ub824\u21bd\000\000\000\000\000\u510e\u2b53", "",
        42, 60430, 1976723050, -8901092955134852208L, 36862L, true, true, (char) 58105, (char) 55938,
        Double.longBitsToDouble(0x3fccc963aa729458L), Double.longBitsToDouble(0x3fbb88cba51081b0L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 6, "\ud83a\udd31\udbdb\uddbe\ud813\udd1e\ud857\udd94\udb96\udef0\ud869\ude13\uda64\udebd\ud9b0\udd86\000\udb22\ude11\ud8f9\udc31\ud800\uddbc\000\000\000\000", "\u2b53", "",
        35, 93293, -2116898360, -4409301855299858969L, -61834L, true, false, (char) 11257, (char) 54117,
        Double.longBitsToDouble(0x3fc4a89ca863e2f4L), Double.longBitsToDouble(0x3fe89f7f0c2c6e78L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 6, 6, 8, "\ud83a\udd31", "\u30ff", "\uda64\udec2\ud9b0\udd86",
        -5, 21208, 1133224507, 3492283606829629571L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fca4006200280f4L), Double.longBitsToDouble(0x3feeb75000026cfcL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\u79e6\u41cc\uac94\u0711\ub05f\ub14c\u5dde\u04b8\u5d21\u9dad\u1715\u9db7\u2717\u418d\u1c1f\u4f86\u0e76\u3e34] |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=java.util.ArrayList:[\u79e6\u41cc\uac94\u0711\ub05f\ub14c\u5dde\u04b8\u5d21\u9dad\u1715\u9db7\u2717\u418d\u1c1f\u4f86\u0e76\u3e34] |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 13, 13, 10, "\ud99b\ude02\ud94c\udeae", "\u79e6\u41cc\uac94\u0711\ub05f\ub14c\u5dde\u04b8\u5d21\u9dad\u1715\u9db7\u2717\u418d\u1c1f\u4f86\u0e76\u3e34", "\ud968\udd5f\u35ac\udbda\ude3c",
        20, 27821, -238370997, 1997581682174141114L, -54329L, false, true, (char) 61071, (char) 27008,
        Double.longBitsToDouble(0x3fbb05298b439ce8L), Double.longBitsToDouble(0x3fee45a2f3170cd2L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\u693e\u509d\u7c41] |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 2, 2, "\ud99d\udf35\udbe6\ude0c\ud8e7\udd28\udaa6\udd1c\ud9eb\udcfe\ud8a8\udcad\ub643\ud9a8\udd76\ud89e\udd6f\udb5d\udeed\ud8f9\udc31\ud985\ude7f\udaa1\udfb6\uda71\udc33\udad9\udfe8\udbce\udcd3\uda3b\udf70\udafb\udccf\uda0f\udd51\udbbe\udd84\ud8b4\udc08\uc60a\udbc4\udeff\ud8bc\udfe2\udba6\udd0d\uda50\uddfd\ud856\udcbf\ud954\udc76\ud668\uda79\udfaa\ud8bb\udf97\ud979\udf28\udb21\udecb\ud9eb\udd25\ud905\udeb5\udad4\uddd4\ud8ee\udf83\ud9ca\udf1b\ud885\uddb6\uda21\udecd\ud938\uddf5\u8e73\uda28\udf3b\ud874\uddc5\uda5b\ude0c\udabb\udcd1\uda2f\ude75", "\u693e\u509d\u7c41", "\ud8ba\udd1c\uc70b\ud89e\ude96\ud968\ude68\uda78\udce0",
        37, 58430, 534619992, -4501084803819751212L, 98278L, false, false, (char) 5319, (char) 54839,
        Double.longBitsToDouble(0x3fe01b48d5306b21L), Double.longBitsToDouble(0x3fc90d6084363d8cL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 6, "\ud99b\ude02\000\000\000\000\ud851\udd68\ub1aa", "\uad97\000\u21bd", "\000\udab4\udff3\uda3b\udf0d\uda1b\udffb\ud913\udf2d\udbc7\udf67\uda28\udc02\udb56\udc6c\uda7f\udc65\udbd0\udf61\udb7d\udebd\uda4f\udc24\ud9cd\ude7e\ud804\udc75",
        31, 28595, 478140165, 2539036053722933591L, -41727L, false, true, (char) 41934, (char) 53119,
        Double.longBitsToDouble(0x3fd7a3445dd8dfb4L), Double.longBitsToDouble(0x3fe1a1f35ba5f318L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 14, "\ud97e\udec3\udbf2\udc61\ud813\udd1e\udbd2\udeb2\udb01\udcf4\ud8ba\ude23\ud8ef\uded2\uda7e\udd04\udaaf\udced\udb5d\ude67\udb7f\uddb0\udb48\udce6\uda8e\udfb6\ud959\udecb\uda9e\udda1\udab5\udcd9\ud919\udf17\ud859\udec2\udb3e\udfd5\udbb9\udc8c\ud8b4\udc08\ud964\udf99\uda34\udd50\udb48\ude79\udb8b\udc6d\ud803\udcc1\udb54\udc5d\udb06\udc90\udbb7\udcc9\uda83\ude76\ud8bb\udf97\uda56\udd3f\udb44\udcda\udbba\udd2b\uda0f\ude42\uda51\udd6e\uda19\udf98\udb16\udebf\udbdd\udcf2\ud9af\udc89\udaf8\ude77\uda05\udd97\udaa8\udddb\ud8a1\ude60\ud84a\udc5e\ud8eb\udff0\udb8d\udd13\uda83\udc15\ud923\uddf8\uda50\uddc2\udb8e\uddfc\uda43\udea6\ud80b\udfa8\ud803\udda2\udaba\uddaa\uda90\udd48\uda31\uddcc\ud990\ude4f", "\u154a\u4262\u7e7d\u4350\u3d85\u17d1", "\ud94c\udc8a\uda72\udc3a\uda09\udfb4\ud8de\udfb8\udadf\udd75",
        38, 30521, 1643067577, -9018014698765030886L, -93355L, false, false, (char) 4356, (char) 23224,
        Double.longBitsToDouble(0x3fc0aadcbcd254d0L), Double.longBitsToDouble(0x3fe903a4fcb59eedL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 2, "\ud87f\udcb9\udaa8\uddb5\ud842\udc92\udb71\udd3d\udaea\udd3c\ud9a8\ude9a\ud8c3\udd26\ud9ac\udf65\ud89e\udd06\udb5d\udeed\ud875\ude95\udaf7\udecd\uda8e\udfb6\ud959\udecb\uda6c\ude90\ud812\udca7\uda07\udd59\udba5\udc8b\ud95e\udcb1\udbf3\uddbd\ud901\udfb3\uda9a\ude67\ud961\udddb\uda47\udd94\ud9d4\udc9f\u3567\udb5f\ude3e\udb0f\ude90\ud99f\ude1d\ud8b8\udc1e\uda1c\uddd6\udb6d\udc5c\ud962\uddbc\udb49\udd7c\ud849\udf63\uda5b\udd04", "\u27c4", "\u529f\udae7\udc7e\udbf0\ude75",
        41, 40676, -1776862437, 4551662743018682658L, -78338L, false, true, (char) 42766, (char) 56667,
        Double.longBitsToDouble(0x3fdad4e8afbea50cL), Double.longBitsToDouble(0x3fdf71aaee002d12L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 0, "\ud99b\ude77\udbf2\udc61\ud813\udd1e\ud88b\ude23\udb01\udd1a\ud891\udc8d\uda64\udebd\udaea\udf64\udbcb\udf7d\ud8d9\udf15\ud8f8\udf8e\udb48\udd0b\uda8e\udfb6\ud959\udecb\ud9ac\ude90\udab4\udff7\ud8e2\udc22\uda14\udfd5", "\u0e76", "\udb48\ude28\udba6\udd6d\ud815\udd6a\udb5f\ude3e\udb06\udc90\udb75\udfe9\uda83\ude74\ud8bb\udf97",
        25, 48846, -2010092441, 5415345153778885438L, 13772L, false, true, (char) 24614, (char) 59368,
        Double.longBitsToDouble(0x3fb53d5c5f40c1a8L), Double.longBitsToDouble(0x3fd2af439dc3b770L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 0, "+", "\u48b3", "\uda64\udebd\ud9ac\udf65\000\000\ud8f9\udc31\udb48\udd80\uda8e\udfb6\ud959\udecb\ud9ac\ude90\udab4\udff7\000",
        35, 28906, 30995, -8801722521436345097L, -10512L, true, false, (char) 39294, (char) 11776,
        Double.longBitsToDouble(0x3fe30f9f69259d5aL), Double.longBitsToDouble(0x3e4403c728000000L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 0, "\000\000", "\u640c\u20a7\u40cc\u7731\ub05f\uad97\ub824\u0516", "\000\udab4\udff3\udbaf\udcb6\uda14\udfd5\ud913\udf2d\udba9\ude67\ud959\udffb\uc60a\ud9d8\udf00\udb48\ude28\udba6\udd6d\u8eb3\000\000",
        -5, -1000, 0, 0L, 71398L, false, true, (char) 27008, (char) 5394,
        Double.longBitsToDouble(0x3fd68739d19168bcL), Double.longBitsToDouble(0x3e4153d400000000L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 6, 6, 3, "\ud996\udf06\udbf2\udc6a", "\u640c\u5cc3\u5465\u28cd\ubb0d\uad59\ua4bd", "\udbff\udc7e\udadd\udcd9",
        7, 71654, 312794160, 3902060805363956197L, -98058L, false, true, (char) 31324, (char) 10509,
        Double.longBitsToDouble(0x3fe59b85cf9b292eL), Double.longBitsToDouble(0x3fe30ec821259d5aL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 12, 6, "\ub12b\udbf1\udf86\udbc6\udf83\012\u8900\000\uda26\ude00\udaa2\udc3e\ud9a4\ude9d\ud98e\udda6\u00e0\uda40\udfa5\udac5\udf5e\ud8c8\udee3\u4f8d\000\000\udb86\udc02\ud930\udcbd\ud98b\ude2f\udbd4\udf2e\uda62\udf94\udacd\ude97", "\u1948\u0b0c\u0193\u96e4\u3baf\u136a\uc40a\u38c6\u3eec\u5364\u3dfc\u4cca\u55f2\u875e\uc3c2\uad89\uc57a\u5c7a\ud476\u914c", "\ud83f\udfdb\uda7d\udd0e\ua50b\u5d48\udbf6\udf28\udba5\udfde\udb79\udf22\ud96f\udfeb\ud9ea\udec9\ud84d\udd3f\udad1\udeb1\udb63\udf86\uff1f\udb19\udf49\ud940\udcec\ud883\udfd6\ud92a\udfa6\udac8\ude40\ud835\udfb8",
        54, 80193, -1238190748, 7917732434215856372L, 75449L, false, true, (char) 52206, (char) 52098,
        Double.longBitsToDouble(0x3fd127cc3668fe4cL), Double.longBitsToDouble(0x3feee001ffcca2f7L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 2, "\000", "\u30ff", "\uda64\udebd\ud9b0\udd86",
        -5, 77568, -417817175, 274585849167872L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e40000000000000L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 14, "\ud8a7\ude55\uda44\udcbd\udab8\udeb9\udbb4\ude70\udbed\udc90\ud869\ude13\uda64\udebd\ud9b0\udd86\ud806\udfb4\ud868\ude23\ud881\udd53\ud800\uddde\udbdf\uddef\udb9a\udfde\ud884\ude0f\udb74\udcee\ud8bc\ude01\udb6d\ude1b\udaa6\uddb8\uda46\udfbf\ud9ec\udd2e\udba5\udc6c\udad1\udd34\uda95\udcfd\ud842\udf91\ufcad\uda41\uddab\udab0\udc9d\ud90c\ude62\udbf4\udea0\ud835\udc78\ud7a8\uda18\ude6d\ud896\udfee\udb05\udd7d\udb27\ude84\ud8a9\udd04\ud84e\udeb8\ud93c\ude26\ud922\ude1b\ud89c\udfa7\uda09\udd30\ud9dd\udd5d\ud848\ude1b\uda69\udf96\ud922\udcb3\uda78\udf33\udb94\udf7e\uda77\udd52\ud8ba\udd57\udba4\udcd4\ud8c7\udd85\ud9ef\udd0c\ud80b\ude04\udaf4\udf1c\ud9f9\udc1e\udb1f\udc8f\udba7\udc56\ud991\udc35\udbc6\ude7a\ud80d\udc2b\ud885\udc13\ud86b\ude12\udb4f\udd6c\udb73\udcbc\udb54\udc97\u7145\ud9b4\udcc7\ub158\ud9d8\udef6\udbe0\ude5f\uda4e\udc10\ud947\ude51\udb49\uddc8\udabb\udde7\ud88b\udeb7\uda2f\udc03\ud968\udf7f\udb4b\ude14\ud9b3\ude7a\ud9e4\ude52\uda2b\udc1e\udbc4\udeaa\uda2b\udf12\ud8e4\ude40\udb97\udcde\ud9e4\ude5d\uda43\udd07\udaf8\udff7\ud8d4\udfd3\ud9eb\udc97\u00f0\udb43\udc94", "\u1d86\u6314\ua7a7\u9043", "\ud84c\udfc4\ud947\udd0f\udaa0\ude4e\udbf9\udc37\u421c\udb2c\ude52\uda2c\udda1\udb76\ude86\udbd2\udfc1\uda04\udc3e\ud96d\udd51\ud889\ude1b\udbfe\udf8c\ud9e5\udc7c\ud8bb\udc5b\ud939\udd3c\udb85\udd81\udb61\udff1\ud8a7\udd9f\ud82a\ude19\uda62\udffa\ud85d\udf55\udbe7\uded4\ud8f0\udc1f\uda14\udd3f\udb08\ude45\uda2c\udc2a\udae1\udcce\ud87a\udd58\ud9a3\udd77\ud8c5\uddbc\udbbd\ude0e\uda8a\udc0d\udac9\udff1\ud980\udf17\udbcd\udef7\udaa3\udec0\udb33\udd96\udac6\udf5b\udbd5\ude5f\ud959\udcc0\ud898\udd9c\uda46\ude64",
        42, 21401, 832442569, -4721878424918455140L, 3778L, true, false, (char) 24124, (char) 40296,
        Double.longBitsToDouble(0x3fe017a3556f4020L), Double.longBitsToDouble(0x3fd9e015102eb5faL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 6, "\000\u818d\ud8b0\uddf7\uda54\udc69\udb96\ude0a\ud869\ude13\ud916\udc0a\000\000\u4ec8\000\ud800\uddbc\000\000\000\000\000\udb86\udc02\u00d2", "", "\uda95\udcfd\ud842\udf91\ufcad\uda41\uddab\ufca4\000\000\ud82f\udef6\ud7a8\uda18\ude6d\ud896\udfee\udb05\udce5\udb27\ude84\ud8a9\udd04\ud84e\udeb8\000",
        55, 48205, -572114949, 1826908796560080992L, -68217L, false, true, (char) 42174, (char) 16161,
        Double.longBitsToDouble(0x3fe4d1c2c77dd1c7L), Double.longBitsToDouble(0x3fc2ef320ec21434L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 0, "\012\udbf1\udf86\udb67\ude29\000\u0200\000", "%", "\ud800\uddbc",
        -5, -1000, 0, 0L, -82054L, true, false, (char) 41549, (char) 14065,
        Double.longBitsToDouble(0x3f97e3edda723a00L), Double.longBitsToDouble(0x3f93554f535d5140L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 4, "\ud9b0\ude25\ud827\udd8a\ud813\udd1e\udbc1\udd69\udaba\udd81\ud8fc\udd92\uda64\udf41\ud9b0\udd86\000\udb22\ude11\ud8f9\udc31\uda02\udcd7\000\000\000\000\000\udaca\udd00\ud913\udf2d\000\000\udb8b\udddf\udabc\udf91\ud9ff\udd5b\ud96d\udfd6\uda21\udc0f\ud99a\udfe3\udac6\udc36\udbe3\ude39\ud88e\uded4\ud8db\udf78\ud9a6\udf8a\udb11\udcae\uda4f\udd62\ud84c\udc33\ud800\udcac\ud949\uddc2\ud8b9\udfca\ud833\udf98\udb8a\udd2e\ud95e\udcf7\udb24\udf05\udb7a\udec9\udb23\udf34\udb73\udca0\uad0a\udbbf\udeb3\udbf0\udeaa\ud922\udd76\udbdd\ude32\ud892\udc43\udad5\ude64\udacb\udc2f\ud9b6\ude82\udbb8\udcba\ud978\udc02\udbca\udd5b\udb25\udcc0\udb4f\udc65\ud83b\udc88\udbd4\udfd5\udbe4\ude42\ud8e0\ude52\uda8d\udc06\ud8e5\udded\u7133\uda14\udd49\udb91\udeb1\ud80f\ude61\udbfa\udf6b\ud928\udc60\ud922\ude39\ud830\ude7e\udb73\udd60\ud911\udcdb\uda46\udf6c\ud8e1\udd7d\udb34\udecc\ud91e\uded9\uda02\ude15\udb55\udfd3\udaa9\udcac\ud9a1\udef8\ud9ba\udf95\udbf1\ude6a\ud881\udda0\ud833\udd4a\ud91e\udcad\udb27\udef7\ud8e1\udc2d\ud95f\udd88\ubd2f\udb90\udd75\ud98d\udf9c\udadc\udd7b\ud856\udeed\udaee\udf67\ud98c\udf81", "\u267e\ua14e\u8256\u770b\u67a1\ube73\uae1c\u80ba\uc8b5\u5fc1\u7a52\u0b4c\u97f6\u7342", "\udbe9\udfe0",
        22, 26165, -824118335, -5928570824875432495L, 52595L, false, false, (char) 3337, (char) 10982,
        Double.longBitsToDouble(0x3fe962398664e779L), Double.longBitsToDouble(0x3feb0319909f4c3aL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 6, "\ufe35\000\000\000\u0088\ud818\udf04\ub1aa", "\ua4b5\000\uc60d\u0934\000\000", "\uda1b\udffb\ud913\udf2d\ud832\ude3c",
        54, 56164, 972660987, -3568084225914528333L, -6427L, true, false, (char) 56308, (char) 2056,
        Double.longBitsToDouble(0x3fe82c459fd71c7fL), Double.longBitsToDouble(0x3fd57233cd1d4c20L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 0, "\ud99b\uddd7\udbf2\udc61\ud813\udd1e\ud88b\ude23\udb01\udd1a\ud891\udc8d\uda64\udebdz\udab8\udcfc\ua41e\udb4d\ude86\uda87\udfc3\uda8e\udfb6\ud8d1\ude07N\ua60f\ud8c1\udcbf\uda14\udfd5", "\u0e76", "\udb48\ude28\udba6\udd6d\ud815\udd6a\udb5f\ude3e\udb06\udc90\ub125\000\ud930\udd97",
        25, 48846, -2010092441, 5415345154800222208L, 13772L, false, true, (char) 24614, (char) 56273,
        Double.longBitsToDouble(0x3fb53d5c5f40c1a8L), Double.longBitsToDouble(0x3fd2a0000dc3b770L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 0, "\000\000\000\ud862\udc70\udb00\udf1a\ud891\udc8d\ud800\udd2b\000\udbcb\udefd\udbb3\udc22\000\udb48\udd0bz\ud8d1\ude03\udabf\udd3e\udab4\udff7\ud8e2\udc22\uda14\udfd5", "\u0e3b", "\000\udba6\udca2\ud815\udd6a\udb5f\ude3e\000\000\000\000",
        -5, 48744, -2010092441, 48076842574654L, 13772L, false, true, (char) 24614, (char) 59368,
        Double.longBitsToDouble(0x3fb53d5c5f40c1a8L), Double.longBitsToDouble(0x3f4e873b876ee000L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 14, "\ud8a7\ude55\uda44\udcbd\udab8\udeb9\udbb4\ude70\000\ud869\ude13\uda64\udebd\ud9b0\udd86\ud806\udfb4\ud868\ude23\ud881\udd53\ud800\uddde\udbdf\uddef\udb9a\udfde\ud884\ude0f\udb74\udcee\ud8bc\ude01\udb6d\ude1b\udaa6\uddb8\uda46\udfbf\ud9ec\udd2e\udba5\udc6c\uda76\udf46\ud96a\udd75\000\ufcad\uda41\uddab\udab0\udc9d\ud90c\ude62\udbf4\udea0\ud835\udc78\ud7a8\uda18\ude6d\ud816\udde8\udb05\udd7d\udb27\ude84\ud8a9\udd04\ud84e\udeb8\ud93c\ude26\ud922\ude1b\ud89c\udfa7\uda09\udd30\ud9dd\udd5d\ud848\ude1b\uda69\udf96\ud922\udcb3\ud803\udeb9\000\000\ud8ba\udd16\udba4\udcd4\ud8c7\udd85\ud9b3\udd39\ud80b\ude04\udaa8\udf16\ud9f9\udc1e\udb1f\udc8f\udba7\udc56\ud991\udc35\ud3d3\ud80d\udc2b\ud885\udc13\ud86b\ude12\udb4f\udd6c\udb73\udcbc\ud933\udd87\u7051\ud9b4\udcc7\ub158\udb2a\udc9e\udbe0\udd98\uda4e\udc10\ud947\ude51\udb49\uddc8\udbbe\udea9\000\uda2e\udf05\ud968\udf7f\ud95a\ude4c\ud9b3\ude7a\ud9e4\ude52\uda2b\udc1e\udbc4\udeaa\uda2b\udf12\ud8e4\ude40\udb97\udcde\ud9e4\ude5d\uda43\udd07\udaf8\udff7\ud8d4\udfd3\ud9eb\udc97\u8640\000", "\u1d86\u6314\u8ca7", "\udbe5\udd1f\u8d10\ud947\udc81\udaa0\ude4e\udbf9\udc37\u421c\udb2c\ude52\uda2c\udda1",
        59, 76346, -113950555, 7897060692343815815L, -100000L, true, false, (char) 59914, (char) 65215,
        Double.longBitsToDouble(0x3fd914df6e99028aL), Double.longBitsToDouble(0x3fc978f66410ac60L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 4, "\ud9b0\ude25\ud827\udd8a\ud813\udd1e\udbc1\udd69\ud8bd\udea2\000\000\ud9b0\udd86\000\udb22\ude11\ud8f9\udc31\uda02\udcd7\000\000\000\000\000\udaca\udd00\ud913\udf2d\000\000\udb8b\udddf\udabc\udf91\ud9ff\udd5b\ud96d\udfd6\uda21\udc0f\ud99a\udfe3\udaa3\ude36\udbe3\ude39\ud88e\uded4\ud8db\udf78\ud9a6\udf8a\udb11\udcae\uda4f\udd62\ud84c\udc33\ud800\udcac\ud949\uddc2\ud8b9\udfca\ud833\udf98\udb8a\udd2e\ud95e\udcf7\udb38\udc4f\udb7a\udec9\udb23\udf34\udb73\udca0\uad0a\udbbf\udeb3\udbf0\udeaa\ud922\udd76\udbdd\ude32\ud892\udc43\udad5\ude64\udacb\udc2f\ud9b6\ude82\udbb8\udcba\ud978\udc02\udbca\udd5b\udb25\udcc0\udb4f\udc65\ud83b\udc88\udbd4\udfd5\udbe4\ude42\ud8e0\ude52\uda8d\udc06\ud8e5\udded\u7133[\000\000\000\ud927\udfb6\ud922\ude39\ud830\ude7e\000\ud90c\udd06\uda46\udf6c\ud8e1\udd7d\udb34\udecc\ud91e\uded9\uda02\ude15\udb55\udfd3\udaa9\udcac\ud9a1\udef8\ud9ba\udf95\udbf1\ude6a\udb33\udd994\ud91e\udcad\udb27\udef7\ud8e1\udc2d\ud95f\udd88\ubd2f\udb90\udd75\ud98d\udf9c\udadc\udd7b\ud856\udeed\udaee\udf67\ud98c\udf81", "\u2607\ua14e\u8256\u770b\u67a1\ube73\uae1c\u1084\uc8b5\u5fc1\u7a52\u0b4c\u97f6\u7342", "\ud8bf\udc3e",
        22, 26165, -824118335, -5928570824875432495L, -100000L, false, false, (char) 54576, (char) 19172,
        Double.longBitsToDouble(0x3fe9623980000000L), Double.longBitsToDouble(0x3fe80000009f4c3aL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:[\u267e\ua14e\u8256\uc203\u6798\u4e2d\uae1c\u80ba\uc8b5\ub608\u478d\u0b4c\u97f6\u7fcd, null] |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 12, 12, "\ud9b0\ude25\ud827\udd8a\ud813\udd1e\udbc1\udd69\udaba\udd81\ud90b\udf92\uda64\udf41\ud914\udcd8\ud9a3\udd78\ud8c8\udf8f\udaec\udc6b\uda02\udcd7\000\000\000\000\udb86\ude8b\udaca\udd00\ud913\udf2d\uac04\000\udb8b\udddf\udabc\udf91\ud9ff\udd5b\ud96d\udfd6\uda21\udc0f\ud99a\udfe3\udac6\udc36\udbe3\ude39\ud88e\uded4\ud8db\udf78\uda5e\udee5\udb0c\udc17\udab7\udc16\ud84c\udc33\ud800\udcac\ud949\uddc2\ud8b9\udfca\ud8cb\udf85\udb8a\udd2e\udb92\udcf1\udb24\udf05\udb7a\udec9\udb23\udf34\udb73\udca0\uad0a\udbbf\udeb3\udbf0\udeaa\ud922\udd76\udbdd\ude32\ud892\udc43\u265f\udacb\udc2f\udaa9\udc5d\udb4f\udc59\ud977\udfd9\udbca\udd5b\udb25\udcc0\udb4f\udc65\ud83b\udc88\udbd4\udfd5\udbe6\udf39\ud8e7\udd25\uda8d\udc06\ud8e5\udded\u7133\uda14\udd49\udb91\udeb1\ud80f\ude61\udbfa\udf6b\uda1f\udeba\ud929\udc7f\ud830\ude7e\udb73\udd60\ud911\udcdb\uda46\udf6c\ud8e1\udd7d\udb34\udecc\ud91e\uded9\uda02\ude15\udb6c\uddfe\udaa9\udcac\ud9a0\udff8\ud846\udd7b\u6ced\ud857\udcac\ud833\udd85\ud934\udd6f\uda57\udfbe\u2c84\ud961\udf53\ubd2f\udb90\udd75\ud98d\udf9c\udadc\udd7b\ud856\udeed\udaee\udf67\ud98c\udf81", "\u267e\ua14e\u8256\uc203\u6798\u4e2d\uae1c\u80ba\uc8b5\ub608\u478d\u0b4c\u97f6\u7fcd", "\udbe9\udfe0",
        22, 26165, -824118335, -5928570824875432495L, -50674L, false, true, (char) 39304, (char) 11363,
        Double.longBitsToDouble(0x3f69765c3ae53200L), Double.longBitsToDouble(0x3fb8d9f7172706f8L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 4, "\ud9b0\ude25\u4a00\000\udbc1\udd69\udaba\udd81\ud9f6\udc91\u00af\000\000\000\ud8f9\udc31\uda02\udcd7\000\000\000\000\000\udaca\udd00\ud913\udf2d\000\000\udb80\udddf\udabc\udf91\ud9ff\udd5b\ud96d\udfd6\uda21\udc0f\ud99a\udfe3\udac6\udc36\uda00\udd28\ud85d\ude0e\ud8db\udf78\ud9a6\udf8a\udb11\udcae\uda4f\udd62\ud84c\udc33\ud800\udcac\ud949\uddc2\ud8b9\udfca\ud833\udf98\udb8a\udd2e\udb06\ude6c\udb24\udf05\udb7a\udec9\udb23\udf34\udb73\udca0\uad0a\udbbf\udeb3\udbf0\udeaa\ud922\udd76\udbdd\ude32\ud892\udc43\udad5\ude64\udacb\udc2f\ud800\udfa8\000\000\udbca\udd28\udb25\udcc0\udb4f\udc65\u00ba\ud96d\udc05\udbe4\ude3a\ud8e0\ude52\udaef\ude77\ud8e5\udded\u7133\uda14\udd49\udb91\udeb1\ud80f\ude61\udbfa\udf6b\ud928\udc60\ud922\ude39\ud830\ude7e\udb73\udd60\ud911\udcdb\uda46\udf6c\ud8e1\udd7d\udb34\udecc\ud91e\uded9\uda02\ude15\udb55\udfd3\udaa9\udcac\ud989\udef8\ud9ba\udf95\udbf1\ude6a\ud881\udda0\ud833\udd4a\000\000\000\ud95f\udd88\ubd2f\udb90\udd75\ud98d\udf9c\udadc\udd7b\ud856\udeed\udaee\udf67\ud98c\udf81", "\u267e\ua14e\u8256\u770b\u67a1\ube73\uae1c\u80ba\u65bf\000\000\000\u2d1e\u7342", "\udbe9\udfe0",
        22, 26165, -824118335, -5928570824875432495L, 96608L, false, false, (char) 15326, (char) 4073,
        Double.longBitsToDouble(0x3feec6a980e4e001L), Double.longBitsToDouble(0x3e48000000000000L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 11, 14, "\ud8a7\ude55\uda44\udcbd\udab8\udeb9\udbb4\ude70\000\ud869\ude13\uda64\udebd\ud9b0\udd86\ud806\udfb4\ud868\ude23\ud881\udd53\ud800\uddde\udbdf\uddef\udb9a\udfde\ud884\ude0f\udb74\udcee\ud8bc\ude01\udb6d\ude1b\udaa6\uddb8\uda46\udfbf\ud9ec\udd2e\udba5\udc6c\uda76\udf46\ud96a\udd75\000\ufcad\uda41\uddab\udab0\udc9d\ud90c\ude62\udbf4\udea0\ud835\udc78\ud7a8\uda18\ude6d\ud816\udde8\udb05\udd7d\udb27\ude84\ud8a9\udd04\ud84e\udeb8\ud93c\ude26\ud922\ude1b\ud89c\udfa7\uda09\udd30\ud9dd\udd5d\ud848\ude1b\uda69\udf96\ud922\udcb3\ud803\udeb9\000\000\ud8ba\udd16\udba4\udcd4\ud8c7\udd85\ud9b3\udd39\ud80b\ude04\udaa8\udf16\ud9f9\udc1e\udb1f\udc8f\udba7\udc56\ud991\udc35\ud3d3\ud80d\udc2b\ud885\udc13\ud86b\ude12\udb4f\udd6c\udb73\udcbc\ud933\udd87\u7051\ud9b4\udcc7\ub158\udb2a\udc9e\udbe0\udd98\uda4e\udc10\ud947\ude51\udb49\uddc8\udbbe\udea9\000\uda2e\udf05\ud968\udf7f\ud95a\ude4c\ud9b3\ude7a\ud9e4\ude52\uda2b\udc1e\udbc4\udeaa\uda2b\udf12\ud8e4\ude40\udb97\udcde\ud9e4\ude5d\uda43\udd07\udaf8\udff7\ud8d4\udfd3\ud9eb\udc97\u8640\000", "\u1d86\ua2ac\u8d2e", "\udbe5\udd1f\u8d10\ud947\udc81\udaa0\ude4e\udbf9\udc37\uda85\udc55\u576d\uda2c\ude3c",
        59, 76346, -113950555, 7897060692343815815L, -100000L, true, false, (char) 60043, (char) 65215,
        Double.longBitsToDouble(0x3fd914df6e99028aL), Double.longBitsToDouble(0x3fc978f66410ac60L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\u640c\u20a7\u40cc\u7731\ub05f\uad97\ub824\u0516] |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\0121=null |this=com.fasterxml.jackson.databind.node.ObjectNode:{}\012",
        Z.run(T, 2, 12, 14, 3, "\ud99b\ude02\udbf2\udc61", "\u640c\u20a7\u40cc\u7731\ub05f\uad97\ub824\u0516", "\ud9ac\ude90\udab4\udff7\uda3b\udf70\uda1b\udffb\ud913\udf2d\udbc7\udf67\000\uc60a\ud9d8\udf00\udb48\ude28\udba6\udd6d\u3567\udb5f\ude3e\udb06\udc90",
        11, 89003, 465098229, 38184097309286L, 71398L, false, true, (char) 27008, (char) 53521,
        Double.longBitsToDouble(0x3fd68739d79168bcL), Double.longBitsToDouble(0x3fe8b8669454f571L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 0, "\012\udbf1\udf86\udb67\ude29\000\udba2\uddf0\ud996\udd23\ud8c3\udca1\ud98b\udee5%\ud831\ude77\udbef\udd65\ud800\uddaf\000\000\000\ud803\udc20`\\\udb02\ude34\ud8d0\udf4a\ud94e\udcf4\uda91\udc16\ud970\udc38\ud9f0\uddbd\uda82\udd98\u53da\ud8f0\udecf\ud8cf\udc2a\uda9f\udc47\ud94a\udf4e\ud83e\udd2e\ud805\ude82", "\u991b\ud5a6\u211b\u077f\u6923\u9737\u9cde\u2851\u04d9\u9280\u886a\u6cae\u5f7f\u9915\u7115", "\ud9ed\udfa2\ud968\udd77\ud9a8\udd64\ud8a8\udd2f\uda3c\uddcd\ud8df\udf27\ue737\ud9e4\udda8\uda2e\udc1a\ud965\udf71\udb1f\udcd3\ud86a\udf53\ud8ac\udcc6\ud973\udc91\ud96e\ude75\ud827\udd9d\ud95a\udc24\udbfb\udc9b\udac4\udc45\ud8f8\ude1b\ud821\ude2e\ud90b\udc7b\udae1\uddd7\udbc5\udfd5\uc5f3",
        55, 56823, 646293498, 3022231025011228192L, -5868L, true, false, (char) 64617, (char) 40872,
        Double.longBitsToDouble(0x3faecf6f34d216a0L), Double.longBitsToDouble(0x3fb1f995c2e791f0L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 0, "\ud99b\ude77\udb67\udf9b\udaf1\ude69\uda1f\udfb3\udb2b\ude21\uda5a\udc12\ud889\udc85\ud9dc\udc24\udbcb\udf1f\ud8d9\udf15\udb84\uddba\ud8e8\udd6e\uda8e\udfb6\ud959\udecb\udbea\ude8f\udab4\udff7\ud8e2\udc22\uda14\udfd5\ud913\udf2d\udb11\uddec\ud8b4\udc08\udbb3\udc09\udbc6\udebd\uda43\udd54\ud94b\udda0\udaf8\ude45\udaaf\udd6a\udb5b\udea6\u4e0b\uda83\ude74\udb2a\ude6e\ud81b\udfd4\udb44\udcda\ud9bb\udd57\udb28\udc27\uda3b\udfa7\ud82d\udc09\udbab\udf6e\ud8a6\udede\ud8ba\udcf9\udaf8\ude77\ud8d9\uddc1\ud926\udf36\udaab\udf06\ud82a\udcc5\ud886\udfed\udbbb\udf07\ud915\udeb2\ucd9c\uda51\udf74\udb77\udc5e\uda46\ude60\ud996\udeb8\ud847\udfeb\ud95b\udcfb\udba4\udfc4\uda8c\udc06\udbae\udda2\udac3\ude45\ud99e\udf94\udae1\udce9\ud805\udd34\ud8bd\ude86\udb95\ude65\ud814\ude0c\ud9a7\udd6d\ud8da\udfc4\ud8c5\uddfa\ud895\udeb9\ud8aa\udfbe\uda09\udd64\ud82d\udecc\uda36\udeda\ud95d\ude4b\udb31\uddd2\ud8b7\udd91\ud9f9\uddb1\uda31\udd35\ud870\udc2b\ud9ca\udec2\udb3c\ude08\udbda\ude68\u09c9\uda8c\ude10\udaf7\udc3a\uda02\udc21\udb98\udc16\udbdc\udf3a\ud81f\udf19\ud864\ude52\udab1\udf1d\uda71\udc4e\ud912\udc37\ud897\udebf\ud9c5\udf8a\udbee\udc05\ud8fc\udfa8\udba8\udeb2\ud9d5\udf14\ud883\udea2\uda26\udcc7\ud867\udc20\ud820\udf6d\udb02\udefa\ud83f\udddc\ud922\ude08\ud9c0\ude6e\ud8fe\ude40\ud9ef\uded9\ud842\udd7e\udb0f\udd48\uda42\ude3e\ud876\udc09\uda04\udfca\ud8ab\udc34\ud963\udf99\udb2a\udd9c\udb8e\ude69\ud976\udfb3\ud945\uddbd", "\u4765\ua273\u1bc8\u49b4\uce23\u8005\u4fa0\u2bd1\u4d18", "\ud91c\udc98\ud8d2\udf09\ud875\uddf8\ud8a4\udfd4",
        33, 32907, -301812103, -3210337597395823878L, -22769L, false, false, (char) 40314, (char) 10678,
        Double.longBitsToDouble(0x3fb3a2e54c1527e8L), Double.longBitsToDouble(0x3fe248ca8583e42dL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 0, "\ud99b\ude77\udb67\udf9b\udaf1\ude69\ud9de\udca6\udb2b\ude65\uda5a\udc12\ud889\udc85\ud9dc\udc24\udbcb\udf1f\ud8d9\udf15\udb84\uddba\ud8e8\udd6e\uda8e\udfb6\ud959\udecb\udbea\ude8f\udb0b\udfc4\ud8e2\udc22\uda14\udfd5\ud913\udf2d\udb11\uddec\ud8b4\udc08\udbb3\udc09\udbc6\udebd\uda43\udd54\ud94b\udda0\udaf8\ude45\udaaf\udd6a\udb5b\udea6\u4e0b\uda83\ude74\udb2a\ude6e\ud81b\udfd4\udb44\udcda\ud9bb\udd57\udb28\udc27\uda3b\udfa7\ud82d\udc09\udbab\udf6e\ud8a6\udede\ud8ba\udcf9\udaf8\ude77\ud8d9\uddc1\ud926\udf36\udaab\udf06\ud82a\udcc5\ud886\udfed\udbbb\udf07\ud915\udeb2\ucd9c\uda51\udf74\udb77\udc5e\uda46\ude60\ud996\udeb8\ud847\udfeb\ud95b\udcfb\udba4\udfc4\uda8c\udc06\udbae\udda2\udac3\ude45\ud99e\udf94\udae1\udce9\ud805\udd34\ud8bd\ude86\udb95\ude65\ud814\ude0c\ud9a7\udd6d\ud8da\udfc4\ud8c5\uddfa\ud895\udeb9\ud8aa\udfbe\uda09\udd64\ud82d\udecc\uda36\udeda\ud95d\ude4b\udb31\uddd2\ud8b7\udd91\ud9f9\uddb1\uda31\udd35\ud870\udc2b\ud9ca\udec2\udb3c\ude08\udbda\ude68\u09c9\uda8c\ude10\udaf7\udc3a\uda02\udc21\udb98\udc16\udbdc\udf3a\ud81f\udf19\ud864\ude52\ud98e\udc4b\ud94b\udc14\udb41\ude16\ud897\udebf\ud9c5\udf8a\udbee\udc05\ud8fc\udfa8\udba8\udeb2\ud9d5\udf14\ud883\udea2\uda26\udcc7\ud867\udc20\ud820\udf6d\udb02\udefa\ud83f\udddc\ud922\ude08\ud9c0\ude6e\ud8fe\ude40\ud9ef\uded9\ud842\udd7e\udb0f\udd48\uda42\ude3e\ud876\udc09\uda04\udfca\ud8ab\udc34\ud963\udf99\udb2a\udd9c\udb8e\ude69\ud976\udfb3\ud945\uddbd", "\u4765\ua273\u1bc8\u49b4\uce23\u8005\u4fa0\u2bd1\u0379", "\ud91c\udc98",
        29, 11747, 1066700821, -7992155853817100525L, -7575L, false, false, (char) 35637, (char) 14024,
        Double.longBitsToDouble(0x3fe737e68b679213L), Double.longBitsToDouble(0x3fece5b0c84e8b95L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 10, 0, "\ud99b\ude77\udb67\udf9b\udaf1\ude69\uda1f\udfb3\udb2b\ude21\uda5a\udc12\ud889\udc85\ud9dc\udc24\udbcb\udf1f\ud8d9\udf15\udb84\uddba\ud8e8\udd6e\uda8e\udfb6\ud959\udecb\udbea\ude8f\udab4\udff7\ud8e2\udc22\uda14\udfd5\ud913\udf2d\udb11\uddec\ud8b4\udc08\udbb3\udc09\udbc6\udebd\uda43\udd54\ud94b\udda0\udaf8\ude45\udaaf\udd6a\udb5b\udea6\u4e0b\uda83\ude74\udb2a\ude6e\ud81f\udfd4\udb44\udcda\ud9bb\udd57\udb28\udc27\uda3b\udfa7\ud82d\udc09\udbab\udf6e\ud8a6\udede\ud8ba\udcf9\udaf8\ude77\ud8d9\uddc1\ud926\udf36\udaab\udf06\ud82a\udcc5\ud886\udfed\udbbb\udf07\ud915\udeb2\ucd9c\uda51\udf74\udb77\udc5e\uda46\ude60\ud996\udeb8\ud847\udfeb\ud95b\udcfb\udba4\udfc4\uda8c\udc06\udbae\udda2\udac3\ude45\ud99e\udf94\udae1\udce9\ud805\udd34\ud8bd\ude86\udb95\ude65\ud814\ude0c\ud9a7\udd6d\ud8da\udfc4\ud8c5\uddfa\ud895\udeb9\ud8aa\udfbe\uda09\udd64\ud82d\udecc\uda36\udeda\ud95d\ude4b\udb31\uddd2\ud8b7\udd91\ud9f9\uddb1\uda31\udd35\ud870\udc2b\ud9ca\udec2\udb3c\ude08\udbda\ude68\u09c9\uda8c\ude10\udaf7\udc3a\uda02\udc21\udb98\udc16\udbdc\udf3a\ud81f\udf19\ud864\ude52\udab1\udf1d\uda71\udc4e\ud912\udc37\ud897\udebf\ud9c5\udf8a\udbee\udc05\ud8fc\udfa8\udba8\udeb2\ud9d5\udf14\ud883\udea2\uda26\udcc7\ud867\udc20\ud820\udf6d\udb02\udefa\ud83f\udddc\ud922\ude08\ud9c0\ude6e\ud8fe\ude40\ud9ef\uded9\ud842\udd7e\udb0f\udd48\uda42\ude3e\uda1c\udefc\uda04\udfca\ud8ab\udc34\ud963\udf99\udb2a\udd9c\udb8e\ude69\ud976\udfb3\ud945\uddbd", "\u4765\ua273\u1bc8\u49b4\uce23\u8005\u4fa0\u2bd1\u4d18", "\ud91c\udc98\ud8d2\udf09\ud875\uddf8\ud8a4\udfd4",
        33, 32907, -301812103, -3210337597395823878L, -22769L, false, false, (char) 40314, (char) 10678,
        Double.longBitsToDouble(0x3fb3a2e54c1527e8L), Double.longBitsToDouble(0x3fe248ca8583e42dL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 14, "\ud99b\ude77\ud98e\udd2f\udaf1\ude69\ud9de\udca6\uda82\uddc0\u0521\ud889\udc85\ud9dc\udc24\udbcb\udf1f\udb83\udc4a\udb84\uddfb\ud8e8\udd6e\uda8e\udfb6\ud959\udecb\udbea\ude8f\udb0b\udfc4\ud8e2\udc22\uda14\udfd5\ud913\udf2d\udb11\uddec\ud8b4\udc08\udbb3\udc09\udbc6\udebd\uda43\udd54\ud841\udcdc\udaf8\ude45\udab9\udc0f\ud912\udfa2\u4e0b\uda83\ude74\udb2a\ude6e\ud81b\udfd4\udb44\udcda\ud9bb\udd57\udb28\udc27\uda3b\udfa7\ud82d\udc09\ud9b2\uddb2\ud8bd\ude2d\ud8ba\udcf9\ud8be\udd99\ud8a9\ude20\ud926\udf36\uda8d\udf06\ud82a\udcc5\ud886\udfed\ud9df\ude38\ud915\ude71\ucd9c\uda51\udf74\udb77\udc5e\uda46\ude60\ud996\udeb8\ud847\udfeb\ud95b\udcfb\udba4\udfc4\uda8c\udc06\udbae\udda2\udac3\ude45\ud99e\udf94\udae1\udce9\ud805\udd34\ud8bd\ude86\udb95\udee8\ud814\ude0c\ud9a7\udd6d\ud8da\udfc4\ud8c5\uddfa\ud895\udeb9\ud8aa\udfbe\udab8\udcbc\ud82d\udecc\uda36\udeda\ud95d\ude4b\udb31\uddd2\udbad\ude8d\ud9f9\uddb1\uda31\udd35\udb9d\udea2\ud9e7\udc21\udb3c\ude08\udbda\ude68\u09c9\uda8c\ude10\udaf7\udc3a\uda02\udc21\udb98\udc16\udbdc\udf3a\ud81f\udf19\ud864\ude52\ud98e\udc4b\ud94b\udc14\udb41\ude16\ud897\udebf\ud9c5\udf8a\udbee\udc05\ud8fc\udfa8\udba8\udeb2\uda79\udddc\ud8c7\udcd5\uda26\udcc7\ud867\udc20\ud820\udf6d\udb02\udefa\ud83f\udddc\ud922\ude08\ud9c0\ude6e\ud8fe\ude40\ud9ef\uded9\ud9c4\udc5f\udb0f\udd48\uda42\ude3e\ud876\udc09\uda04\udfca\ud8ab\udc34\ud963\udf99\udb2a\udd9c\udb8e\ude69\ud976\udfb3\ud945\uddbd\uda52\ude79\udb8e\uddd3\ud9c7\udc19\udb5b\ude05\udbd8\udfce\udaa0\uddf8\ud97f\udfd5\udbe3\udf80\ufb1c\ud962\udec1\udb18\ude52\ud9ae\udde0\udb21\udf13", "\u7d1e\u70e5\u5d23\u5877\uaaa1\uc88b\u0e1b", "\uda6f\udc6b\uda98\udc71\udb89\udd59\udaf3\ude4f",
        32, 75083, 1985286053, 634266674736292566L, 15571L, false, false, (char) 2517, (char) 14465,
        Double.longBitsToDouble(0x3fe3e4a15fc01835L), Double.longBitsToDouble(0x3fe1ec1d0cf7b0f0L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\0121=java.util.ArrayList:!toString:java.lang.NullPointerException |this=com.fasterxml.jackson.databind.node.ObjectNode:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 0, "\ud99b\ude77\udb67\udf9b\udaf1\ude69\ud9de\udc4f\udb2b\ude65\uda5a\udc12\000\ud9dc\udc24\udbcb\udf1f\ud8d9\udf15\udb84\uddba\ud8e8\udd6e\uda8e\udfb6\ud959\udecb\udbea\ude8f\udb0b\udfc4\ud8e2\udc22\uda14\udfd5\ud913\udf2d\udb11\uddec\ud8b4\udc08\udbb3\udc09\udbc6\udebd\uda43\udd54\ud94b\udd22\udaf8\ude45\udaaf\udd6a\udb5b\udea6\u4e0b\uda83\ude74\udb2a\ude6e\ud81b\udfd4\udb44\udcda\ud9bb\udd57\udb28\udc27\uda3b\udfa7\u6861\ud950\udfa7\ud8a6\udede\ud8ba\udcf9\udaf8\ude77T\ud926\ude4e\udaab\udf06\ud82a\udcc5\ud886\udfed\udbbb\udf07\ud915\udeb2k\000\000\uda46\ude60\ud996\udeb8\udb34\ude42\ud95b\udcac\udba4\udfc4\uda8c\udc06\udbae\udda2\udac3\ude45\ud99e\udf94\udae1\udce9\ud805\udd34\ud8bd\ude86\udb95\ude65\ud814\ude0c\ud9a7\udd6d\ud8da\udf25\ud8c5\uddfa\ud895\udeb9\ud8aa\udfbe\uda09\udd64\ud82d\udecc\uda36\udeda\ud95d\ude4b\udb31\uddd2\ud8b7\udd91\ue190\uda07\udd42\ud870\udc2b\ud9ca\udec2\udb3c\ude08\udbda\ude68\u09c9\uda8c\ude10\udaf7\udc3a\uda02\udc21\udb98\udc16+\u9152\ud864\ude52\ud98e\udc4b\ud94b\udc14\udb41\ude16\ud897\udebf\ud9c5\udf8a\udbee\udc05\ud8fc\udfa8\udba8\udeb2\ud9d5\udf14\ud883\udea2\uda26\udcc7\ud867\udc20\ud820\udf6d\udb02\udefa\ud83f\udddc\ud922\ude08\ud9c0\ude6e\ud8fe\ude40\ud9ef\uded9\ud842\udd7e\udb0f\udd48\uda42\ude3e\ud876\udc09\uda04\udfcaF\000\000\udb5e\udd4f\uee15\000", "\u4765\ua273\u1bc8\u49b4\uce23\u8005\u4fa0\uc255\000", "",
        22, 17929, 11761835, -1860818792L, 77785L, true, false, (char) 58988, (char) 35637,
        Double.longBitsToDouble(0x3fdaf09195cdf9a2L), Double.longBitsToDouble(0x3feb3c909b9cb619L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.node.ObjectNode|_at|com.fasterxml.jackson.core.JsonPointer|new:com.fasterxml.jackson.databind.node.ObjectNode:com.fasterxml.jackson.databind.node.JsonNodeFactory",
    "M|com.fasterxml.jackson.databind.node.ObjectNode|_childrenEqual|com.fasterxml.jackson.databind.node.ObjectNode|new:com.fasterxml.jackson.databind.node.ObjectNode:com.fasterxml.jackson.databind.node.JsonNodeFactory",
    "M|com.fasterxml.jackson.databind.node.ObjectNode|_put|java.lang.String,com.fasterxml.jackson.databind.JsonNode|new:com.fasterxml.jackson.databind.node.ObjectNode:com.fasterxml.jackson.databind.node.JsonNodeFactory",
    "M|com.fasterxml.jackson.databind.node.ObjectNode|asToken||new:com.fasterxml.jackson.databind.node.ObjectNode:com.fasterxml.jackson.databind.node.JsonNodeFactory",
    "M|com.fasterxml.jackson.databind.node.ObjectNode|deepCopy||new:com.fasterxml.jackson.databind.node.ObjectNode:com.fasterxml.jackson.databind.node.JsonNodeFactory",
    "M|com.fasterxml.jackson.databind.node.ObjectNode|elements||new:com.fasterxml.jackson.databind.node.ObjectNode:com.fasterxml.jackson.databind.node.JsonNodeFactory",
    "M|com.fasterxml.jackson.databind.node.ObjectNode|equals|java.lang.Object|new:com.fasterxml.jackson.databind.node.ObjectNode:com.fasterxml.jackson.databind.node.JsonNodeFactory",
    "M|com.fasterxml.jackson.databind.node.ObjectNode|fieldNames||new:com.fasterxml.jackson.databind.node.ObjectNode:com.fasterxml.jackson.databind.node.JsonNodeFactory",
    "M|com.fasterxml.jackson.databind.node.ObjectNode|fields||new:com.fasterxml.jackson.databind.node.ObjectNode:com.fasterxml.jackson.databind.node.JsonNodeFactory",
    "M|com.fasterxml.jackson.databind.node.ObjectNode|findParent|java.lang.String|new:com.fasterxml.jackson.databind.node.ObjectNode:com.fasterxml.jackson.databind.node.JsonNodeFactory",
    "M|com.fasterxml.jackson.databind.node.ObjectNode|findParents|java.lang.String,java.util.List|new:com.fasterxml.jackson.databind.node.ObjectNode:com.fasterxml.jackson.databind.node.JsonNodeFactory",
    "M|com.fasterxml.jackson.databind.node.ObjectNode|findValue|java.lang.String|new:com.fasterxml.jackson.databind.node.ObjectNode:com.fasterxml.jackson.databind.node.JsonNodeFactory",
    "M|com.fasterxml.jackson.databind.node.ObjectNode|findValues|java.lang.String,java.util.List|new:com.fasterxml.jackson.databind.node.ObjectNode:com.fasterxml.jackson.databind.node.JsonNodeFactory",
    "M|com.fasterxml.jackson.databind.node.ObjectNode|findValuesAsText|java.lang.String,java.util.List|new:com.fasterxml.jackson.databind.node.ObjectNode:com.fasterxml.jackson.databind.node.JsonNodeFactory",
    "M|com.fasterxml.jackson.databind.node.ObjectNode|get|int|new:com.fasterxml.jackson.databind.node.ObjectNode:com.fasterxml.jackson.databind.node.JsonNodeFactory",
    "M|com.fasterxml.jackson.databind.node.ObjectNode|get|java.lang.String|new:com.fasterxml.jackson.databind.node.ObjectNode:com.fasterxml.jackson.databind.node.JsonNodeFactory",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
