package com.fasterxml.jackson.databind;
import org.junit.Test;
import static org.junit.Assert.*;
public class MappingIterator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.util.NoSuchElementException\012",
        Z.run(T, 1, 3, 18, 17, "\uda92\udc3f\ud920\udffb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\ud3ff\ud3fd\u8185\u4edd\uc35b\ubd3c\uc921\u2011\u85fd\ucc31\u3f64\u1d98\u5946\u01b9\ud36e\u0f58\u08a9\u8925\u2f81\u8753\u988e\u73a2\u0e8c\u4027\ub923\u9a4b\u1ba9\u0f37\ucbae\ucdfe\u9192", "\ud8f9\udd55",
        36, 71281, 784051173, 1869895180702028208L, -51756L, true, true, (char) 689, (char) 8353,
        Double.longBitsToDouble(0x3fe9c36777cf7aceL), Double.longBitsToDouble(0x3fed65e36c077d30L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.util.NoSuchElementException\012",
        Z.run(T, 1, 3, 18, 17, "\uda92\udc3f\ud920\udffb\ud85f\uddde\udb50\udc30\udb8c\udef6\ud96c\udf9a\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\u2192\ud3b1\u8103\u4edd\ud4cc\u02c3", "\udb41\ude6e\udb1b\udde9\ud804\udc29\uda66\udfc4\uda45\udebf\u1d0d\udb19\udf9b\uda88\udefe\udbef\udd97\ud80f\udf27",
        1, 15468, -968973539, -3661830683913867672L, -38711L, true, false, (char) 45185, (char) 8482,
        Double.longBitsToDouble(0x3fe8972d7bf2f2aaL), Double.longBitsToDouble(0x3fef8ba3d307777fL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.util.NoSuchElementException\012",
        Z.run(T, 1, 13, 18, 5, "\uda92\udc3f\ud920\udffb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\ud3ff\ud3fd\u3ce6\u4edd\u5278\uc6c5\uc921\u2011\u1e96\u73d9\u35c2\u1e3f\u7d6c\u01b9\u6240\uafff\u08a9\u8925\u2f81\u8753\u988e\u73a2\u0e8c\u3fc7\u0500\u375f\u1ba9\u0f37\ucbae\ucdfe\u6991", "\ud8f9\udd55",
        56, 71281, -886133787, 1869895180702028208L, -51756L, true, true, (char) 689, (char) 8353,
        Double.longBitsToDouble(0x3fe9c36772ff99ceL), Double.longBitsToDouble(0x3fd6a9e786b738c2L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 1, 4, 8, 12, "\uda92\udc3f\ud920\udffb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\ud3ff\ud3fd\u05ab\u832b\uc35b\ubd3c\uc921\u2011\u85fd\ucc31\u3f64\u7aed\u7a35\u3335\ud36e\u0f58\u08a9\u8925\u4ed2\u8753\u988e\u45c4\u8e4f\u2747\ub923\u9a4b\u1ba9\u0f29\ucbae\u09c0\u6b75", "\ud8f9\udd53",
        36, 71281, 784051173, 1869895180702028208L, -51756L, true, true, (char) 689, (char) 8353,
        Double.longBitsToDouble(0x3fe9c36777cf7aceL), Double.longBitsToDouble(0x3fed65e36c077d30L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\uc841\u721b\u2f3b\ua19b] |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 1, 14, 3, 17, "\uda92\udc3f\ud920\udffb\uda83\udf0f\udb50\udc3a", "\uc841\u721b\u2f3b\ua19b", "\ud9f3\ude0f\udbd3\uddfc\uda70\udfd9\ud92a\udd2d\uda08\udcb5\uda41\ude9d\udac5\udd74\udb41\ude6e\udb1b\udde9\udba2\udff9\uda9e\udd81\uda31\udcc8\uda34\udee2",
        30, 82766, 1120939730, -1995716988116870663L, -89219L, true, true, (char) 19781, (char) 19729,
        Double.longBitsToDouble(0x3fd2bf8824178674L), Double.longBitsToDouble(0x3fea5a89b6b30a6fL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 1, 15, 18, 9, "\uda92\udc3f\ud920\udffb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\ud3ff\ud3fd\u8185\u4edd\uc35b\ubd3c\u557a\u203d\u85fd\ucc31\u3f64\u1d98\u5946\u01b9\ud36e\u0f58\u08a9\u8925\u2f81\u3f07\u6bf9\u73a2\u0e8c\u4027\ub923\u9a4b\u1ba9\u0f37\ucbae\ucdfe\u9192", "\ud8f9\udd55",
        36, 71281, 784051173, 1869895180702030512L, -51756L, true, true, (char) 689, (char) 15617,
        Double.longBitsToDouble(0x3fe9c3674fcf7aceL), Double.longBitsToDouble(0x3fed65e36c077d30L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 1, 12, 3, 17, "\uda92\udc3f\ud920\udffb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\ud3ff\ud3fd\u8185\u4edd\uc35b\ubd3c\uc921\u8b03\u6b3a\ube18\u3f64\u1d98\u5946\u01b9\ua3a2\u0f80\u08a9\u8bde\u2f81\u8753\u988e\u73a2\u0e8c\u4027\ub923\u9a4b\u1ba9\u0f37\ucbae\ucdfe\u395a", "\ud8f9\udd55",
        36, 71281, 784051173, 1869895180702028208L, -51756L, true, true, (char) 15612, (char) 8353,
        Double.longBitsToDouble(0x3fe9c3658c28db82L), Double.longBitsToDouble(0x3fed65e62c077d30L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 1, 10, 18, 17, "\uda92\udc3f\ud920\udffb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\ud3ff\ud3fd\u8185\u4edd\ucdef\u8656\ud606\u2011\u85fd\ucc31\u3f64\u1d98\u5946\u01b9\u62f8\u0f58\u08a9\u8925\u2f81\u8753\u988e\u73a2\u0e8c\u4027\u0aa0\u9abf\u1ba9\u0f37\ucbae\ucdfe\u9192", "\ud8f9\udd55",
        4, 71281, 784051173, 257918590722085585L, -51756L, true, true, (char) 689, (char) 8353,
        Double.longBitsToDouble(0x3fe9c36777cf7aceL), Double.longBitsToDouble(0x3fed65e36c077d30L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 18, 9, "\uda92\udc3f\ud920\udffb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\ud3e3\u06e4\u8150\u3d0a\u3b88\u0af3\uc947\u2011\u85fd\u8b69\u3f64\u1d98\u5946\u01b9\ud36e\u0f58\u08a9\u8925\u2f81\u85d8\u3620\u73a2\u0e8c\u4027\ub923\u9afa\u1ba9\u0f37\ucbae\ucdfe\u3488", "\ud8f9\udd55\uda9b\ude05\ud872\udd2f\ub6a6\ud9dd\udd49\ud8a2\udd0d\ud81e\udeea\udb18\udfa5\uda1b\udc18\ud8ba\udc58\uda0b\udd4b\udbf8\ude54\ud98b\udfd2",
        -5, 57647, 2100352940, 4895355649823696934L, 4799L, true, true, (char) 53541, (char) 21485,
        Double.longBitsToDouble(0x3fe4fb2353a4b0a1L), Double.longBitsToDouble(0x3fddb998ff062126L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 1, 1, 18, 17, "\uda92\udc3f\ud920\udffb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\ud3ff\ud3fd\u8185\u4edd\uc35b\ubd3c\uc921\u2011\u85fd\ucc31\u3f64\u1d98\u5946\u01b9\ud36e\u0f58\u08a9\u8925\u2f43\u8753\u988e\u73a2\u0e8c\u4027\ub923\u9a4b\u1ba9\u0f37\ucbae\ucdfe\u9192", "\ud8f9\udd55",
        36, 71281, 784050994, 1869895180702028208L, -51756L, true, true, (char) 689, (char) 8353,
        Double.longBitsToDouble(0x3fe9c36777cf7aceL), Double.longBitsToDouble(0x3fed65e36c077d30L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.MappingIterator:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 2, 8, 18, 1, "\uda92\udc3f\ud920\udfdb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\uc950\ua303\u8185\u4edd", "\udb0b\udc60\ud85e\udc20\udb41\ude6e",
        13, 4912, 146373573, -7003963313574919295L, -74863L, true, true, (char) 3273, (char) 13239,
        Double.longBitsToDouble(0x3fc783628874313cL), Double.longBitsToDouble(0x3fe5cef5f51efb92L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 1, 17, 18, 1, "\uda92\udc3f\ud912\uddd3\uda83\udf5b\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\ud3ff\ud3fd\u3ce6\u348b\u5278\uc6c5\uc921\u2011\u1e96\u73d9\u35c2\u1e3f\u7d6c\u01b9\ua33b\u4f1c\u08a9\u0d25\u7a6a\u48a1\u123e\ua0c8\u408a\u3fc7\u0500\u375f\u1ba9\u0f37\ucbae\u7aff\u6991", "\ud8f9\udd55",
        56, 71281, -886133787, 1869895180702028176L, 79316L, true, false, (char) 689, (char) 8353,
        Double.longBitsToDouble(0x3fe9c36772ffc7f0L), Double.longBitsToDouble(0x3fd6a9e786b738c2L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.MappingIterator:@?\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 14, 19, 5, "\uda92\udc30\ud920\udffb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\u73ac\ua813\ucce1\u4eb6\u5831\u146c\u7664\u2011\u1e96\u73d9\u0966\u5bd5\u7d6c\u01b9\u6240\uafff\u08a9\uba8f\u9bd3\u8753\uc08f\u73a2\u0e8c\u3fc7\u0500\u375f\u5323\u0bbc\ub586\u91a3\u6991", "\ud8f9\udd55\udaba\udf05\ud872\udd2f\ud872\udcc8\ud9dd\udd49\ud8a2\udd0d\ud8de\udcc5\uda78\ude43\ud801\udd4a\ud8ba\udc58\uda0b\udd4b\udbff\udc54\ud98b\udfd2\ud8f3\udd32\uda75\udd3f\ud846\udef6\ud8c3\udc2c\ud96c\udd05\ud8eb\udebf\ud9ad\udd87\u0e85\uda7a\udfc0\ud959\ude93",
        39, 64192, 1855164290, 677548174917985415L, 71659L, true, false, (char) 48935, (char) 41033,
        Double.longBitsToDouble(0x3fd0cedf18a0fd24L), Double.longBitsToDouble(0x3fdec22a8b49793eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 1, 8, 18, 5, "\uda92\udc3f\ud920\udffb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\ud3ff\ud3fd\u3ce6\u4edd\u4a78\uc6c5\uc921\u2011\u1e96\u73d9\u35c2\u1e3f\u7d6c\u0081\u6240\uafff\u08a9\u8925\u2f81\u8753\u988e\u73a2\u0e8c\u3fc7\u0500\u375f\u1ba9\u0f37\ucbae\u00f2\000", "\ud8f9\udd55",
        56, 71281, -886133787, 1869895180702028208L, -51756L, true, true, (char) 0, (char) 8295,
        Double.longBitsToDouble(0x3fe9c36772ff99ceL), Double.longBitsToDouble(0x3fd6a9e786b738c2L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.MappingIterator:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 2, 17, 12, 0, "\udb9c\udc44\ud920\udffb\udb7c\udf06\udb50\udc3a\uda32\udc68\ud936\udd20\ub90e\uda96\udcda\uda0e\udde6", "\u055f", "\uda88\udfe8\udb0d\udf30\uda08\udcb5\u7eea\udac5\udda0\ud974\udd06",
        53, 50509, -408963399, -7003963313574919295L, 60415L, true, true, (char) 54109, (char) 45554,
        Double.longBitsToDouble(0x3fe847f4c12dec99L), Double.longBitsToDouble(0x3fd914c52ce60ed2L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=com.fasterxml.jackson.databind.MappingIterator:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 2, 15, 18, 9, "\uda92\udc3f\ud920\udffb\ue3dd\udb4f\udfb4\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\ud3ff\ud3fd\u8185\u4edd\uc35b\ubd3c\u557a\u9213\u85fd\u5302\u97e5\u934a\u5946\u01b9\ud36e\u0f58\u08a9\u8925\u2f81\u3f07\u6bf9\u73a2\u0e8c\ubde8\ub923\u9a4b\u1ba9\u0f37\ucbae\ucdfe\u9192", "\u88c3",
        37, 57937, 1119595493, 699905832543175202L, -4140L, false, true, (char) 22228, (char) 15737,
        Double.longBitsToDouble(0x3fe9c3674fcf7aceL), Double.longBitsToDouble(0x3fed65e36c077d30L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=com.fasterxml.jackson.databind.MappingIterator:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 2, 15, 18, 9, "\uda92\udc3f\ud920\udffb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\u0ea1", "\ud3ff\ud3fd\u8185\u4edd\uc35b\ubd3c\u557a\u203d\u85fd\ucc31\u3f64\u1d98\u5946\u01b9\ud36e\u0f58", "\uda06\udd01\ud84d\udc46\udb55\udd8d\uda84\ude0e\ud95b\udf0e\udbfa\udc96\udb98\udefd\ud8af\udc75\ud993\udfe8\udad4\udf19\udb86\udeee\ud8d6\udecf",
        16, 73943, 1234541147, -7708418326806171472L, -78469L, false, true, (char) 46242, (char) 54587,
        Double.longBitsToDouble(0x3fe76d28825eb964L), Double.longBitsToDouble(0x3fbd0c65499a1040L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.MappingIterator:@?\0121=null |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 2, 10, 10, 18, "\uda92\udc60\ud920\udffb", "\ucde4\u485f\uc841\u2ec9\u3ac2\ua19b", "\udb86\ude64\ud9ed\uddf4\uda70\udfd9\ud85b\ude14\udb52\udddd\udaf9\ude1e\uda5b\udcf1\ud8eb\ude54\ubaf4\udbac\ude44\uda66\udfc4\uda45\udebf\udb6f\udd1f",
        -4, 7342, -1281652614, 3165117020426751849L, -74962L, false, true, (char) 1847, (char) 42937,
        Double.longBitsToDouble(0x3fea5a89b683ac29L), Double.longBitsToDouble(0x3fee49f19bf2f990L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.MappingIterator:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 2, 4, 18, 17, "\uda92\udc3f\ud801\udc2b\uda97\ude68\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\ub35b\ud3b8\u8185\u4edd\ua832\ubd3c\uc921\u26a8\u85fa\ucc31\u3f64\u1d98\u5946\u01b9\ud36e\u0f58\u08a9\u8925\u2f43\u8753\u988e\u73a2\u0e8c\u4027\ub923\u9a4b\u1ba9\ubf75\ucbae\ucdfe\u9192", "\ud8f9\udd55",
        36, 88945, 784050994, 8859481801081019055L, -51756L, true, true, (char) 689, (char) 8353,
        Double.longBitsToDouble(0x3fe9c36777cf7ac8L), Double.longBitsToDouble(0x3fed65e36c077d30L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.MappingIterator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 7, "\uda92\udc3f\ud920\udfdb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\uc950\ua303\u0f2f\u6837\u61b5\ubd07", "\udb3f\udf6e\uda3b\udd9a\uda97\udc18\ud80b\uddfb\ud950\udc84\uda13\udceb\ud8d8\udc30\udb4b\uddb7\udbef\udd6a\ud870\udc57\uda06\udd01\udaec\udd75\ud8e0\udc27\ud8b2\ude76\ud950\udef8\ud888\udc5a\ud80c\udccf\udaf4\udc76\udbff\udfa2\uda93\udf2f\ud813\udc32\ud870\udde6\ud8a0\udd85\ud840\udfd2\udb5d\udd19\ud87f\udf8e\udbbf\udd65\ua4fe\udbd0\udca7\ud967\udd53\ud89f\udcf5\ud864\udc86\ud904\ude38\uda9a\uddda\udae2\udef5\ud83d\uddcb\ud905\udf50\ud94f\ude4e\uda3b\udc2e\ud85c\udc39\ud9ce\udebb\udb83\udf92\udb0c\udff4\ud827\udd13\ud9d9\udea8\ud902\udc39",
        23, 61432, -2086175379, 1041647771195841805L, -25396L, true, true, (char) 2148, (char) 41809,
        Double.longBitsToDouble(0x3fd53d028389dafaL), Double.longBitsToDouble(0x3fde2c8b7669952eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.MappingIterator:@?\0121=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 2, 8, 8, 1, "\uda92\udc2d", "\u2e39", "\u0acc\ud947\udc02\uda0c\uddcf\ud806\ude3e",
        53, 56891, 10682576, 1713280256L, -56224L, false, true, (char) 29902, (char) 31649,
        Double.longBitsToDouble(0x3fef4ce151e021fdL), Double.longBitsToDouble(0x3fee2cfdd87a00b9L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.MappingIterator:@?\0121=new com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 2, 4, 4, 11, "\uda92\udc3f\ud920\udfdb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud877\udd70\ud874\udccc\ud97b\udd7b\uda0c\uddcf", "\uc950\ua303\u9b3a\u0fc8", "\udb0b\udc60\ud85d\udff1\udb41\ude6e",
        13, 4912, 146373573, -7003963313574919295L, -74863L, true, true, (char) 18064, (char) 59116,
        Double.longBitsToDouble(0x3fc783628874313cL), Double.longBitsToDouble(0x3fe7e89df51e7224L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.MappingIterator:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 2, 4, 18, 1, "\udac0\uded4\ud920\udfdb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf\ud821\udc3e\udb86\udc3f\ud884\udea6\uc8db\ud9ed\uddf4\uda70\udfd9\ud924\udca9\uda08\udcb5\udb0b\udc60", "\ub1ec\u67c7\u1e1c\u5946\u01b9\ud36e\u0f58\u08a9\ubbee\u2f81\u8753\u4ab2\ud579\u6ea8\u11fe\uc173\ubf62\ucfa9\u643c\uad50\ub345!\u9660", "\udb1d\udfca\udbbd\ude93\ud9b7\udc5a\uda98\udd66\udba1\udda5\ud8f0\udd3b",
        50, 39001, 511229334, -2465060408151234255L, -78438L, true, false, (char) 15725, (char) 34789,
        Double.longBitsToDouble(0x3fc0d8e6977cc0b4L), Double.longBitsToDouble(0x3fa15ebfcec16a70L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=com.fasterxml.jackson.databind.MappingIterator:@?\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 15, 13, 1, "\uda92\udc3f\ud920\udfdb\uda83\udf0f\udb50\udc3a\uda32\udc68\uda7f\uddd5\ud9f9\udf1c\uc1c5\uda0c\uddcf", "\uc950\ua303\u8185\u4edd", "\udb0b\udc60\ud85e\udc20\udb41\ude6e",
        -2, 43160, 683244485, -7003963311887924607L, -74863L, true, true, (char) 59521, (char) 9990,
        Double.longBitsToDouble(0x3fc783628874313cL), Double.longBitsToDouble(0x3fe5cef5f51efb92L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.MappingIterator:@?\0121=void |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 2, 1, 1, 2, "\udbb6\udd32\uda87\udcba\udbda\ude1a\udb4c\udfce\udb44\ude47\ud9c6\udc97\ud874\udca3\udb94\udf08\uda0c\uddcf\ud9c5\udfb0\ud8fd\udedf\ud9fd\udf8a\ud8f8\udec0\ud83a\udc00\ud8f6\udd02\ud9c0\udfe7\udb76\udf20\uda58\udec7\udac5\udd74", "\u35c2\u8c8b\u7d6c\u01b9", "\udbef\udd68\ud851\udc57\ud962\uddbf\ud89b\udd6f\ud966\udcef\ud977\udf5b\ud974\udc86\ud8b2\udc92\ud870\udd72\udb4e\uded7\ud993\udfe8\udad4\udf19\udb86\udeee\ud8f7\udfcf\udb7f\udc34\udbd9\ude53\ud85f\uddab\ud8f9\udd55\udaba\udeb2\ud872\udd2f",
        28, 57898, -942370416, -6518054142099542065L, 79316L, true, false, (char) 222, (char) 52547,
        Double.longBitsToDouble(0x3fe9c36772ffc7f0L), Double.longBitsToDouble(0x3fd6a9e786b738c2L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\u2011\u1e96\u73d9\u0966\u5bd5\u7d6c\u01b9\u6240\uafff\u08a9\u874c\u9b5e\u8753\uc08f\u73a2] |this=com.fasterxml.jackson.databind.MappingIterator:@?\0121=java.util.ArrayList:[\uda92\udc30\ud920\udffb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf\udab5\udf28\udab6\udcd5\ud9b7\ude81\ud95f\udeac\uda9f\udec9\uda70\udfb2\ud94a\ude9c] |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 2, 14, 14, 4, "\uda92\udc30\ud920\udffb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf\udab5\udf28\udab6\udcd5\ud9b7\ude81\ud95f\udeac\uda9f\udec9\uda70\udfb2\ud94a\ude9c", "\u2011\u1e96\u73d9\u0966\u5bd5\u7d6c\u01b9\u6240\uafff\u08a9\u874c\u9b5e\u8753\uc08f\u73a2", "\ud870\udd72\ud96b\udc24\uda9a\ude3d\ud853\udd3c\udba3\udc42\ud8fd\ude73\ud869\udf89\uda98\udefe\ud839\udfe9\ud8f9\udd55\ud9ca\ude5a\ud872\udd5b\ud871\udfee\ud9dd\udd49\ud8a2\udd0d\ud8de\udcc5\uda78\ude43\ud801\udd4a\ud8ba\udc58\uda0b\udd4b\udbff\udc54\ud98b\udfd2\ud9d9\ude05\uda75\udd3f\ud846\udef6\ud957\uddf8",
        9, 77337, 693318424, -8726237029701377988L, 11786L, false, true, (char) 43534, (char) 37133,
        Double.longBitsToDouble(0x3fc0e12ceb42b0ccL), Double.longBitsToDouble(0x3febac6b5a550e2dL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.MappingIterator:@?\0121=null |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 2, 14, 14, 5, "\uda92\udc30\ud920\udffb\uda83\udf0f\udb50\udc3a\uda32\udc68\ud9c6\udc97\ud874\udca3\ud97b\udd7b\uda0c\uddcf", "\u73ac\ua813\ucce1\u4eb6\u5831\u146c\u7664\u2011\u1e96\ua7d9\u0966\u5bd5\u7d6c\u4958\u6240\u4bd9\u1ba4\uba8f\u9bd3\u8753\uc08f\u73a2\u0e8c\u3fc7\u0500\u375f\u5323\u0bbc\ub586\u91a3\u6991", "\ud8f9\udd55\ud9d1\udd1e\ud929\ude39\uda64\udf4c\ud9dd\udd1a\ud8a2\udd0d\ud8de\udcc5\uda78\ude43\ud801\udd4a\ud8ba\udc58\uda0b\udd4b\udbff\udc54\ud98b\udfd2\ud8f3\udd32\uda75\udd3f\ud846\udef6\ud8c3\udc2c\ud96c\udd05\ud8ae\udcc0\u0911\u0e85\uda7a\udfc0\ud959\ude93",
        39, 64192, 1855164290, 677548720378832007L, 71659L, true, false, (char) 48935, (char) 41033,
        Double.longBitsToDouble(0x3fd0cedf18a0fd24L), Double.longBitsToDouble(0x3fdec22a8b49793eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=com.fasterxml.jackson.databind.MappingIterator:@?\0121=java.util.ArrayList:[] |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 2, 15, 15, 16, "\uda92\udc3f\ud8df\udfdb\uda83\udf0f\udb50\udc3a\uda32\udc68\uda7f\uddd5\ud9f9\udf1c\uc1c5\uda0c\uddcf", "\uc950\ua29d\u8185\u4edd", "\udb0b\udc60\ud85e\udc20\udb41\ude6e",
        -2, 43160, 683244485, -7003963309871656319L, -74863L, true, true, (char) 59521, (char) 9990,
        Double.longBitsToDouble(0x3fc783628203593cL), Double.longBitsToDouble(0x3fe5cef6f51efb92L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 5, 17, "\u287c\ud920\udf33\u012c\udb6d\udd00\uda32\udc68\ud9ee\udf9f\ud953\udd34\udbaf\udd6c\udb81\udc3b", "\u8a38\u90a5\u40b2", "\ud9e2\uddb5\uda41\ude99\uda9d\udf22\udb41\ude6e\uda5f\uddcb\ud803\udf72\ud9d3\udc4b\ud860\udc0e\u1d0d\ud950\udfd6\ud96b\ude0b\udbef\udd68\ud870\udc57\uda06\udd01\ud8ab\udf30\uda60\udfc4\ud9f4\ude62\ud898\udc84\udbfa\udc96\ud867\udd96\ud8a3\uded4\ud993\udfe8\udad4\udf19\udb86\udeee\ud8d6\udecf",
        16, 36831, 848059227, 947071553616107460L, -78469L, false, true, (char) 43938, (char) 54587,
        Double.longBitsToDouble(0x3fee7d28825eb964L), Double.longBitsToDouble(0x3fe3a18ca94d55c7L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.MappingIterator:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.MappingIterator:@?\012",
        Z.run(T, 2, 12, 12, 16, "\uda92\udc3f\ud920\udfdb\uda83\udf0f\udb41\ude32\ud874\udfd7\ud938\uddcd\udb3d\udd3a\ud97b\udd7b\uda0c\uddcf", "\uc950\u04c4\u7592\u5d3b\ua879\u23a7\ud494\ua35d\u85fd\ucbbc\u67c7\u1e1c\u5946", "\uda6c\udfc6\uda53\udcfb\ud856\udc5b\uda06\udd01\udaec\udd75\ud8e0\udc27\udb51\udc65\udac6\udf74\udbee\udc36\ud864\udf0a\udb81\ude2d\ud95d\udd4e",
        16, 55773, -457861608, -8458040279146140208L, -35307L, true, true, (char) 20040, (char) 4831,
        Double.longBitsToDouble(0x3fbef24b8e2cbfb8L), Double.longBitsToDouble(0x3fcc6341afcc9cccL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.MappingIterator|_resync||new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|close||new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|hasNextValue||new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|nextValue||new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "C|com.fasterxml.jackson.databind.MappingIterator|<init>|com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|_handleIOException|java.io.IOException|new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|_handleMappingException|com.fasterxml.jackson.databind.JsonMappingException|new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|_throwNoSuchElement||new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|emptyIterator||static",
    "M|com.fasterxml.jackson.databind.MappingIterator|getCurrentLocation||new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|getParser||new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|getParserSchema||new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|hasNext||new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|next||new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|readAll|java.util.Collection|new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|readAll||new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|_resync||new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|close||new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|hasNextValue||new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "M|com.fasterxml.jackson.databind.MappingIterator|nextValue||new:com.fasterxml.jackson.databind.MappingIterator:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
    "C|com.fasterxml.jackson.databind.MappingIterator|<init>|com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JsonDeserializer,boolean,java.lang.Object",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
