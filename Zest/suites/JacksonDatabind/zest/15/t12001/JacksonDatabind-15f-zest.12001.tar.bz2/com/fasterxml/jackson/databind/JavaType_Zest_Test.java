package com.fasterxml.jackson.databind;
import org.junit.Test;
import static org.junit.Assert.*;
public class JavaType_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class com.fasterxml.jackson.databind.JsonNode]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 4, 21, "\uda34\ude44\udbc1\udd62\ud8eb\udead\ud8ce\udfff\ud9cd\udf02\udb3d\udf85\udb33\udf57\uda42\udc41\uda91\udfa6\ud855\udf0a\udaed\udc9b\ud842\udfeb\uda75\udeae\udb62\udcab\uda2e\udf63\ud8e3\udc9c\ud872\udf33\ud910\uddc0\ud972\ude06\udb36\ude20\udad6\udd11\udbdb\udc6f\udbc4\ude4c\ud8cd\udc93", "\u4096", "\uda82\ude0c\ud89f\ude4a\ud809\ude4b\ud865\udcd3\ud9a6\udf48\ud891\uddc5\ud938\udc06\ud95a\ude5d\uda8e\udd68\ud823\udf26",
        14, 2201, -721159422, -3136836307264721618L, -83908L, true, false, (char) 41255, (char) 36778,
        Double.longBitsToDouble(0x3fe93db4e6d155b4L), Double.longBitsToDouble(0x3fc857cf0cc3c8a8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class com.fasterxml.jackson.databind.JsonNode]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 4, 19, "\uda34\ude44\udbc1\udd62\udb08\ude4c\udbea\uddd7\ud9cd\udf0d\udb3d\udf85\udb33\udf57\uda42\udc41\uda91\udfa6\ud855\udf0a\udaed\udc9b\ud842\udfeb\uda75\udeae\udb62\udcab\uda2e\udf63\ud8e3\udc9c\ud872\udf33\u926a\udbbd\udd99\udb36\ude20\udad6\udd11\udbdb\udc6f\udbc4\ude4c\ud8cd\udc93", "\u4096", "\uda82\ude0c\ud80c\udd6c\u2a64\ud87d\udf0d\ud9a6\udf48\ud891\uddc5\ud938\udc06\ud95a\ude5d\uda8e\udd68\ud823\udf26",
        14, 2201, -721159422, -3136836307264721618L, -83908L, true, false, (char) 41255, (char) 36778,
        Double.longBitsToDouble(0x3fe93db4e6d155b4L), Double.longBitsToDouble(0x3fc857cf0cc3c8a8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 23, 21, "\uda34\ude44\udbc1\udd62\ud8eb\udead\ud8ce\udfff\ud9cd\udf02\udb3d\udf85\udb33\udf57\uda42\udc41\uda19\ude0b\ud852\udcba\udaed\udc9b\ud842\udfeb\uda75\udeae\udb62\udcab\uda2e\udf63\ud8e3\udc9c\ud872\udf33\ud910\uddc0\ud972\ude06\udbb7\udea2\udad6\udc77\ud8e6\ude76\udbc4\ude4c\ud8cd\udc93", "\u4096", "\uda82\ude0c\ud89f\ude4a\ud809\ude4b\ud865\udcd3\ud9a6\ude9a\ud891\uddc5\ud938\udc06\ud95a\ude5d\ud8ba\udf80\ud823\udf26",
        14, 2201, -721159422, -3136836304999797458L, -42138L, true, false, (char) 32495, (char) 58901,
        Double.longBitsToDouble(0x3fd9cbf8bb7ffd98L), Double.longBitsToDouble(0x3fe93db685d155b4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 20, 1, 11, "\uda34\ude44\udbc1\udd62\uda8b\udc0f\ud8ce\udfff\ud9cd\udf02\udb3d\udf85\udbfe\uddc3\ufd61\uda91\udfa6\ud855\udf0a\udaed\udc9b", "\u56de", "\ud872\udf33\ud910\uddc0\ud972\ude06\udb36\ude10\udad6\udd11\udbdb\udc6f\udbc4\ude4c",
        30, 13566, 628658805, 3284560707849153837L, 59619L, true, false, (char) 12207, (char) 8305,
        Double.longBitsToDouble(0x3fe66b09fcccc44eL), Double.longBitsToDouble(0x3fd7a88c4f4a567aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 10, 11, "\ud245\ud874\udf41\ud8eb\ude22\ud8ce\udfff\ud9cd\udf02\udb3d\udf85\udb33\udf57\uda42\udc41\uda91\udfa6\ud855\udf0a\udaed\udc9b\ud842\udfeb\uda75\udeae\udb62\udcab\uda2e\udf63\ud8e3\udc9c\ud872\udf33\ud910\uddc0\ud972\ude06\udb36\ude20\udad6\udd11\udbdb\udc6f\udbc4\ude4c\ud8cd\udc93", "\u404e", "\uda82\ude0c\ud998\udce1\ud978\ude09\uda28\udcba\udb09\udcce\ud824\udd59\ud921\udcc2\ud95a\ude5d\uda8e\udd68\udbd5\udee0",
        44, 81161, -721188104, -3136836307264721618L, -83908L, true, true, (char) 41261, (char) 24149,
        Double.longBitsToDouble(0x3fe93db4e6d155b4L), Double.longBitsToDouble(0x3fe70acbc330f2bfL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class com.fasterxml.jackson.databind.JsonNode]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 0, 21, "\uda34\ude44\udbc1\udd62\ud8eb\udead\ud8ce\udfff\u5687\udb81\udde0\udb33\udf57\u9d35\000\ud855\ude1d\udaed\udc66\000\000\000", "\ub258", "\000",
        29, 6918, -1504682090, 246L, -27664L, true, true, (char) 0, (char) 36863,
        Double.longBitsToDouble(0x3f4257a2746ae400L), Double.longBitsToDouble(0x3fe8c38acecd613fL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 21, "\uda34\ude44\ud952\udd6c\udab7\udde7\ud8cf\udc68\ud9cd\udf02\udb3d\udf85\ud91c\udeec\udaf6\udc67\uda91\udfa6\ud85c\udd0a\udaed\udc9b\ud842\udfeb\udbac\udeca\udb62\udcab\uda2e\udf63\ud8e3\udc9c\uda7a\udfc2\udace\udc33\ud972\ude06\udb36\ude20\udad6\udd11\udbdb\udc6f\uda18\udd58\ud8cd\udd03", "\u041e\u115c\u2dc1", "\ud809\ude4b\ud865\udcd3\ud9a6\udf48\ud9b5\udee6\ud938\udc06\ud95a\ude5d\uda8e\udd68\ud823\udf26\ud9d5\udd10\ud83e\ude63\ud9ee\udc79\ud8cd\udd6f",
        8, 92622, -1085786371, -4770443466379902684L, 38852L, true, true, (char) 46531, (char) 9349,
        Double.longBitsToDouble(0x3fc857cf0cc3c8a8L), Double.longBitsToDouble(0x3fedd996f45c1dfdL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 12, 21, "\ud86e\udd22\udbc1\udd34\ud8eb\udead\udb75\udcf5\ud9e6\udf8b\ud83e\udc91\ud8cf\uddab\uda3d\udf70\ud829\udd93\udacf\uded7\udaed\udcd4\ud842\udfeb\uda75\udeae\udb62\udcab\ud800\udc04\ud8e3\udc9c\ud872\udf33\udbc1\ude58\ud905\uddc8\udbf7\ude96\udad6\udd11\udbdb\udc15\ud842\ude4b\ud8cd\udc93", "\u4096", "\uda82\ude0c\ud89f\ude4a\ud809\ude4b\ud865\udcd3\ud9a6\udf48\ud891\uddc5\ud938\udc06\ud95a\ude5d\uda8e\udd68\uda71\udede",
        40, 2201, -797543166, -8897670556736148190L, -83908L, true, true, (char) 6191, (char) 36778,
        Double.longBitsToDouble(0x3fe93db4e6d155b4L), Double.longBitsToDouble(0x3febedf3c204c954L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class com.fasterxml.jackson.databind.JsonNode]\012",
        Z.run(T, 1, 13, 0, 21, "\uda34\ude44\udbc1\udd62\ud8eb\udead\000\ud9cd\ude7b\udb3d\udf85\udb33\udf57\uda42\udc41\uda91\udfa6\ud855\udf0a\udaed\udc9b\ud842\udfeb\uda75\udeae\udb62\udcab\uda2e\udf63\ud8e3\udc9c\ud872\udf33\ud910\uddc0\ud972\ude06\udb36\ude20\udad6\udd11\000\udbc4\uddb6\ud8cd\udc93", "\u4096", "\uda5e\udd8f\ud89f\ude4a\ud809\ude4b\ud865\udcd3\ud9a6\udf48\ud891\uddc5\ud938\udc06\ud95a\ude5d\uda8e\udd68\ud823\udf26",
        14, 2201, -721223678, -3136836305285010130L, -100000L, false, false, (char) 0, (char) 36709,
        Double.longBitsToDouble(0x3fe93db4e6d155b4L), Double.longBitsToDouble(0x3fc857cf0cc3c8a8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 24, 20, 21, "\uda34\ude44\udbc1\udd62\ud8eb\udead\ud8ce\udfff\ud9cd\udf02\udb3d\udf85\udb33\udf57\uda42\udc41\udbaa\udc50\ud854\udd4f\udaed\udc9b\ud842\udfeb\uda75\udeae\udb62\udcab\uda2e\udf63\ud8e3\udc9c\ud872\udf33\ud910\uddc0\ud972\ude06\udb36\ude20\udad6\udd11\udbdb\udc6f\udbc4\ude4c\ud8cd\udc93", "\u4096\ucbbb\uc60c\u9583\ud196\u9738\u725a\u780d\u477b\u8091\u1e5a\u8a4f\u4a4a\u9399\u1201\ub10f\u9ce5\uca6f\u97f9\ua248", "\uda53\udcf2\ud869\udc34\udb53\udf11\u6c34\ud97a\udef4\ud901\udff1",
        0, 59168, -412236768, -2490398024175951247L, -80805L, false, true, (char) 59333, (char) 2552,
        Double.longBitsToDouble(0x3fe5861d04938edcL), Double.longBitsToDouble(0x3fe42eebc5de450aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 21, "\uda34\ude44\udbc1\udd62\ud8eb\udead\ud8ce\udfff\ud9cd\udf02\udb3d\udf85\udb33\udf57\uda42\udc41\uda91\udfa6\ud855\udf0a\udaed\udc9b\ud842\udfeb\uda75\udeae\udb62\udcab\uda2e\udf63\ud8e3\udc9c\ud872\udf33\ud910\uddc0\ud972\udd2d\udb36\ude20\udad6\udd11\udbdb\udc6f\udbc4\ude4c\ud8cd\udc93", "\u4096", "\uda82\ude0c\ud8d2\udd88\ud809\ude4b\ud865\udcd3\ud9a6\udf48\ud872\uddc5\ud938\udc06\ud95a\ude5d\uda8e\udd68\ud823\udf26",
        14, -1000, 0, -1963971328L, -86176L, true, false, (char) 32495, (char) 58901,
        Double.longBitsToDouble(0x3fd9cbf8b6cb488aL), Double.longBitsToDouble(0x3fe93db4e6d155b4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 4, 21, "\udbcc\ude50\udbc1\udd62\ud8eb\udead\ud8c5\udea3\udadc\udcf3\udb2a\udf92\udb33\udf57\uda42\udc41\uda91\udfa6\ud855\udf0a\udaed\udc9b\ud842\udfeb\uda75\udeae\udb62\udcab\uda2e\udf63\ud8e3\udc9c\ud872\udf33\ud910\uddc0\ud972\ude06\udb36\ude20\ud8c3\udd75\ud84b\udf17\udbc4\ude4c\ud8cd\udc93", "\u4096\u433a\u8529\u36fe", "\udbcf\udf6d\udaa8\ude96\ud891\uddc5\ud938\udc06\ud95a\ude5d\ud9d4\udfad\ud81f\udebb\ud863\udf6d\ud83e\ude63\ud9ee\udc79\ud8cd\udd6f",
        8, 92622, -1085786371, -4770443466195353308L, 38852L, true, true, (char) 46531, (char) 9349,
        Double.longBitsToDouble(0x3fc857cf0cc3c8a8L), Double.longBitsToDouble(0x3fe582379d21c876L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 17, 0, "\ud97b\udc89\udbc1\udd62\uda56\ude23\ud8cf\udc69\ud9cd\udf02\udb3d\udf85\udb33\udf57\uda42\udc41\uda19\ude0b\ud852\udcba\udaed\udc9b\ud842\udfeb\uda75\udeae\udb62\udcab\uda2e\udf63\ud8e3\udc9c\udac1\udd19\u71ba\udbe8\udde5\ud944\udd84\udae8\udddd\ud961\udd72\udbc4\ude4c\ud8cd\udc93", "\ucb56", "\uda82\ude0c\uda17\ude86\u23a3\udb85\udf8e\ud87a\ude5a\ud891\uddc5\ud938\udc64\ud95a\ude8c\ud8ba\udf80\ud823\udf26\ud996\udef3\ud83f\udd79\ud87a\udcdf\udace\ude15\uda66\udfc3\udb0b\udca2",
        4, 97791, 827834654, -8202457677386444894L, 96825L, true, true, (char) 15520, (char) 7792,
        Double.longBitsToDouble(0x3fc4042a487e11bcL), Double.longBitsToDouble(0x3f7d604abe478d00L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 8, 21, "\uda34\ude44\udbc1\udd62\ud8eb\udead\ud8ce\udfff\ud9cd\udf02\udb3d\udf85\udb33\udf57\uda42\udc41\uda19\ude0b\ud852\udcba\udaed\udc9b\ud842\udfeb\uda75\udeae\udb62\udcab\uda2e\udf63\ud8e3\udc9c\ud872\udf33\ud910\uddc0\ud972\ude06\udbb7\udea2\udad6\udc77\ud8e6\ude76\udbc4\ude4c\ud8cd\udc93", "\u4096", "\uda82\ude0c\ud89f\ude4a\ud809\ude4b\ud865\udcd3\ud9a6\ude9a\ud891\uddc5\ud938\udc06\ud95a\ude5d\ud8ba\udf80\ud823\udf26",
        14, 2201, -721159422, -3136836304999797458L, -42138L, true, false, (char) 32495, (char) 58901,
        Double.longBitsToDouble(0x3fd9c29d3b7ffd98L), Double.longBitsToDouble(0x3fe93db685d155b4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 23, 21, "\uda34\ude44\udbc1\udd62\ud8eb\udead\ud8ce\udfff\ud9cd\udf02\udb3d\udf85\udb33\udf57\uda42\udc41\u273f\ud9e7\udce5\udafc\udccc\ud842\udfeb\uda75\udeae\udb62\udcab\uda2e\udf63\ud8f9\udd8e\ud872\udf33\ud910\uddc0\ud972\ude06\ud812\udf24\ud8fa\udd4b\ud8e6\ude76\udbc4\ude4c\ud8cd\udc93", "\u4096", "\uda82\ude0c\ud89f\ude4a\ud809\ude4b\ud865\udcd3\udb9b\udc20\ud891\uddc5\ud938\udc06\ud95a\ude5d\ud8da\udc80\ud823\udf26",
        14, 2201, -721159422, -3136836304999797458L, -42138L, true, false, (char) 32495, (char) 58901,
        Double.longBitsToDouble(0x3fd9cbf8bb7ffd98L), Double.longBitsToDouble(0x3fd08b6d0ba2ab68L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 23, 21, "\uda34\ude44\ud9d4\udc2c\u4635\ud8ce\udfff\ud9cd\udf02\udb3d\udf85\udb33\udf57\uda42\udc41\uda19\ude0b\ud852\udcba\udaed\udc9b\ud842\udfeb\uda75\udeae\udb62\udcab\uda2e\udf63\ud8e3\udc9c\ud872\udf33\ud910\uddc0\ud972\ude06\udbb7\udea2\udad6\udc77\ud8e6\ude76\udb0c\udc4f\udbce\udd6e", "\u4096", "\uda82\ude0c\ud89f\ude4a\ud809\ude4b\ud865\udcd3\ud9a6\ude9a\ud891\uddc5\ud938\udc06\ud95a\ude5d\ud8ba\udf80\ud823\udf26",
        14, 2201, -721159422, -3136836304999797458L, -42138L, true, false, (char) 8944, (char) 8618,
        Double.longBitsToDouble(0x3fd9cbf8bb7ffd98L), Double.longBitsToDouble(0x3fe93db685d155b4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 21, "\uda34\ude44\udbc1\udd62\ud8eb\udead\ud8ce\udfff\udbe9\udc36\udb3d\udf85\udb33\udf57\uda42\udc41\uda19\ude0b\ud852\udcba\udaed\udc9b\ud842\udfeb\uda75\udeae\udb62\udcab\uda2e\udf63\ud8e3\udc9c\ud872\udf33", "\u1bca\u9fdb\u653b\u154a\ub650\u51ec\u08f6\u4096\u433a\u5ea0\u8485\u0464\uc5f4\u1935\u8873\u3da0\u78a4\u3eae\u2a9a\u39b2\u0248\ub8c0\ud00f\u7a67", "\uda97\ude35\ud9b2\udd69\ud924\udd38\uda46\ude00\udb6d\udd89\udb7e\udd6e\udb55\udd60",
        36, 73273, -900025534, 4082385284532007161L, 40797L, false, false, (char) 14491, (char) 31669,
        Double.longBitsToDouble(0x3fd9654442f9b5f6L), Double.longBitsToDouble(0x3fdc68c7a829e756L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:@?\012",
        Z.run(T, 1, 3, 20, 21, "\ud8b7\udf4d\ud9ad\udef2\uc018\ud92e\udf1c\ud9cd\udf02\udb3d\udf85\uda19\udf0b\uda42\udc6a\uda19\ude0b\ud992\udf7b\udb93\udd9a\ud842\udfcb\uda75\udeae\ud9fb\udf8b\udb11\udf37\uda27\ude9c\ud7ae\ud8f4\udc16\ud972\ude06\udbb7\udea2\udad6\udc77\ud8e6\ude76\udbc4\ude4c\ud9a1\udd7d", "\u4096", "\uda82\ude0c\ud89f\ude4a\udbcf\udf4d\ud865\udcd3\ud9a6\ude9a\ud891\uddc5\ud938\udc06\ud95a\ude5d\ud8ba\udf80",
        20, 38899, -661872007, -4185044218743900160L, -98705L, false, true, (char) 58901, (char) 1320,
        Double.longBitsToDouble(0x3fdbffecce476da0L), Double.longBitsToDouble(0x3fdd155b41b9ed46L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:@?\0121=void |this=com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:@?\012",
        Z.run(T, 2, 3, 19, 11, "\uda34\ude44\udbc1\udd62\uda8b\udc0f\ud8ce\udfff\ud9cd\udf02\udb3d\udf85\udbfe\uddc3\ufd61\uda91\udfa6\ud855\udf0a\udaed\udc9b", "\u56de", "\ud872\udf33\ud910\uddc0\ud972\ude06\udb36\ude10\udad6\udd11\udbdb\udc6f\udbc4\ude4c",
        30, 13566, 628658805, 3284560707849153837L, 59619L, true, false, (char) 12207, (char) 8305,
        Double.longBitsToDouble(0x3fe66b09fcccc44eL), Double.longBitsToDouble(0x3fd7a88c4f4a567aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 16, 21, "\uda33\udfa4\udbc1\udd34\ud8eb\udead\udb75\udcf5\ud9e6\udf8b\ud83e\udc91\ud8cf\uddab\uda3d\udf70\udbbc\udc5b\ud82c\ude85\udaed\udcd4\ud842\udfeb\uda75\udeae\udb62\udcab\ud800\udc04\ud8e3\udc9c\ud872\udf33\ud900\udc03\uda58\udcfc\udbf7\ude96\udad6\udd11\udbdb\udc15\ud842\ude4b\ud8cd\udc93", "\u4096", "\uda82\ude0c\ud89f\ude4a\ud809\ude4b\ud865\udcd3\ud9a6\udf48\ud891\uddc5\ud938\udc06\ud95a\ude5d\uda8e\udd68\uda71\udede",
        40, 2201, -797543166, -8897670556736148190L, -83908L, true, true, (char) 6191, (char) 42870,
        Double.longBitsToDouble(0x3fe893f7a6d155b4L), Double.longBitsToDouble(0x3febedf3c204c954L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 21, "\ud86e\udd22\udbc1\udd34\ud8eb\udead\udb75\udcf5\ud9e6\udf8b\ud83e\udc91\ud8cf\uddab\uda3d\udf70\ud829\udd93\udacf\uded7\udaed\udcd4\ud842\udfeb\uda75\udeae\udb62\udcab\ud895\udc6f\udb0f\udc53\ud872\udf33\udbc1\ude58\uda78\udcc1\ud899\udd40\udad6\udd11\udbdb\udc15\ud842\ude4b\ud8cd\udc93", "\u4096", "\uda82\ude0c\ud89f\ude4a\ud809\ude4b\ud865\udcd3\ud9a6\udf48\ud891\uddc5\ud938\udc06\ud95a\ude5d\uda8e\udd68\uda71\udede",
        40, 2201, -797543166, -8897670556736148190L, 97545L, true, false, (char) 32495, (char) 31358,
        Double.longBitsToDouble(0x3fd9c36936cb488aL), Double.longBitsToDouble(0x3fe93db4e6d155b4L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 9, 6, "\uda34\ude44\udbc1\udcf6\ud9c7\udeb1\ud829\udd23\ud8e7\udd46\ud863\udee7\ud998\uddab\uda42\udc8c\uda91\udfa6\ud855\udf0a\ud91f\udc53\ud853\udef0\ud9f7\udc8f\udb62\udc2c\ud924\udf5e\ud8e3\udc9c\udbe2\udf2b\ud910\uddc0\ud972\ude06\uda60\udc76\udaf2\udfee\udbe5\udc6f\udbb8\udf4c\ud852\ude75", "\ua846", "\udae7\ude0b\ud89f\ude4a\ud809\ude4b\ud947\udf85\ud9a6\udf78\ud88b\udd41\ud938\udc06\ud95a\ude5d\uda8e\udd68",
        18, 28411, -24337763, -3097356133422614528L, 10514L, true, false, (char) 47673, (char) 32495,
        Double.longBitsToDouble(0x3fc7e6aae671d62cL), Double.longBitsToDouble(0x3feb2d222f27b69cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 4, 10, "\udbcc\ude50\udbc1\udd62\ud8eb\udead\ud90e\udf1f\udadc\udcf3\udb2a\udf92\udb33\udf57\uda42\udc41\uda91\udfa6\ud955\udc80\ue6d6\ud842\udfeb\uda75\udeae\udb62\udcab\uda2e\udf63\ud8e3\udc9c\ud872\udf33\ud910\uddc0\ud972\ude06\udb36\ude20\ud8c3\udd75\ud84b\udf17", "\u1f77\u0965\u4096\u433a\u8529\u36fe\u0464\u2dd3\u55e9", "\ud938\udc06\ud95a\ude5d",
        29, 63804, 1271253750, -104666390924625150L, -83908L, true, false, (char) 41255, (char) 36778,
        Double.longBitsToDouble(0x3fe93db4e6d155b4L), Double.longBitsToDouble(0x3fb05c5799879150L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|createSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.ser.std.BeanSerializerBase|findConvertingSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.ser.BeanPropertyWriter|new:com.fasterxml.jackson.databind.ser.BeanSerializer:com.fasterxml.jackson.databind.ser.std.BeanSerializerBase",
    "M|com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer|_findSerializer|java.lang.Object,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:com.fasterxml.jackson.databind.util.Converter",
    "M|com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer|acceptJsonFormatVisitor|com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:com.fasterxml.jackson.databind.util.Converter",
    "M|com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer|createContextual|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty|new:com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:com.fasterxml.jackson.databind.util.Converter",
    "M|com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer|isEmpty|com.fasterxml.jackson.databind.SerializerProvider,java.lang.Object|new:com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:com.fasterxml.jackson.databind.util.Converter",
    "M|com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer|isEmpty|java.lang.Object|new:com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:com.fasterxml.jackson.databind.util.Converter",
    "M|com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer|serialize|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:com.fasterxml.jackson.databind.util.Converter",
    "M|com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer|serializeWithType|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.jsontype.TypeSerializer|new:com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:com.fasterxml.jackson.databind.util.Converter",
    "M|com.fasterxml.jackson.databind.ser.std.StdSerializer|findConvertingContentSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty,com.fasterxml.jackson.databind.JsonSerializer|fld:com.fasterxml.jackson.databind.ext.CoreXMLSerializers$XMLGregorianCalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.JavaType|_assertSubclass|java.lang.Class,java.lang.Class|fld:com.fasterxml.jackson.databind.ObjectMapper:JSON_NODE_TYPE",
    "M|com.fasterxml.jackson.databind.JavaType|_narrow|java.lang.Class|fld:com.fasterxml.jackson.databind.ObjectMapper:JSON_NODE_TYPE",
    "M|com.fasterxml.jackson.databind.JavaType|_widen|java.lang.Class|fld:com.fasterxml.jackson.databind.ObjectMapper:JSON_NODE_TYPE",
    "M|com.fasterxml.jackson.databind.JavaType|containedType|int|fld:com.fasterxml.jackson.databind.ObjectMapper:JSON_NODE_TYPE",
    "M|com.fasterxml.jackson.databind.JavaType|containedTypeCount||fld:com.fasterxml.jackson.databind.ObjectMapper:JSON_NODE_TYPE",
    "M|com.fasterxml.jackson.databind.JavaType|containedTypeName|int|fld:com.fasterxml.jackson.databind.ObjectMapper:JSON_NODE_TYPE",
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|createSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.ser.std.BeanSerializerBase|findConvertingSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.ser.BeanPropertyWriter|new:com.fasterxml.jackson.databind.ser.BeanSerializer:com.fasterxml.jackson.databind.ser.std.BeanSerializerBase",
    "M|com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer|_findSerializer|java.lang.Object,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:com.fasterxml.jackson.databind.util.Converter",
    "M|com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer|acceptJsonFormatVisitor|com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:com.fasterxml.jackson.databind.util.Converter",
    "M|com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer|createContextual|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty|new:com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:com.fasterxml.jackson.databind.util.Converter",
    "M|com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer|isEmpty|com.fasterxml.jackson.databind.SerializerProvider,java.lang.Object|new:com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:com.fasterxml.jackson.databind.util.Converter",
    "M|com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer|isEmpty|java.lang.Object|new:com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:com.fasterxml.jackson.databind.util.Converter",
    "M|com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer|serialize|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:com.fasterxml.jackson.databind.util.Converter",
    "M|com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer|serializeWithType|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.jsontype.TypeSerializer|new:com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer:com.fasterxml.jackson.databind.util.Converter",
    "M|com.fasterxml.jackson.databind.ser.std.StdSerializer|findConvertingContentSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty,com.fasterxml.jackson.databind.JsonSerializer|fld:com.fasterxml.jackson.databind.ext.CoreXMLSerializers$XMLGregorianCalendarSerializer:instance",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
