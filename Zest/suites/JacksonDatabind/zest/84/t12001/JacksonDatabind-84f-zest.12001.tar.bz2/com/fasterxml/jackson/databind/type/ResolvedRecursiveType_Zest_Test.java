package com.fasterxml.jackson.databind.type;
import org.junit.Test;
import static org.junit.Assert.*;
public class ResolvedRecursiveType_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 11, 10, 13, "\ud9b1\udfc3", "\u71de\u2565\u72d5\ud64f", "\udab4\udc5b",
        -2, 15733, -340127422, 1477927500982671506L, 89690L, true, false, (char) 28048, (char) 15750,
        Double.longBitsToDouble(0x3faf127ef8609410L), Double.longBitsToDouble(0x3fe926ec589431d7L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 11, 10, 13, "\udb19\udecc", "\u6f7d\u2565\ud1cb\u6ee8", "\uda48\udc06",
        9, 15733, -340127422, 1477927500982671506L, 89690L, true, false, (char) 28048, (char) 15750,
        Double.longBitsToDouble(0x3faf127ef8609410L), Double.longBitsToDouble(0x3fe976ec5982421fL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 11, 13, 15, "\ud966\udfef", "\ud36d\u4828\u2e0e\u5aaf", "\udb84\uded8",
        48, 27619, 245240130, 2158362153923264370L, 89690L, true, false, (char) 29675, (char) 15750,
        Double.longBitsToDouble(0x3faf127ef8609410L), Double.longBitsToDouble(0x3fe926ec5ee33a41L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 0, 10, 13, "\ud9b1\udfc3", "\u71de\u252b\u72d5", "\udb19\ude3b\udab4\udc5b\udb69\ude8c\ud8d7\udf67",
        23, 99811, 1406818450, 3714986667356644602L, -8011L, true, false, (char) 253, (char) 55429,
        Double.longBitsToDouble(0x3f4bb16250c40000L), Double.longBitsToDouble(0x3fe2a26ea28216e3L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 2, 5, 13, "\ud9b1\udfc3", "\u71de\u2951\u794c\u0524\uaa82\u6010\u9e6f\u9e90\u3d6c\u3136\u2281\u7dca\u95cb\u0695\ua9d5", "\ud81f\udf5a\uda6a\udcc3\udba4\ude13\udbb6\ude29\udb88\udd42\udac7\udccd\ud953\udd97\ud90f\udf7c\ud8ae\ude57\u177f\ud858\ude5e\ud896\udd73\udaa9\ude99\ud91c\udff5\udb50\udc63\udad5\udea5\udb64\udf74",
        28, 55723, 2034555147, 3335704047173419987L, -86056L, true, true, (char) 47456, (char) 36989,
        Double.longBitsToDouble(0x3fe3de5433dd1014L), Double.longBitsToDouble(0x3fe32769f7229cc8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 11, 10, 13, "\ud9b1\udeef", "\u71de\u2565\u7251", "\000\u1400\000\ud819\udf68",
        23, 41811, 0, 0L, -100000L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe926e8009431d7L), Double.longBitsToDouble(0x3f9ffe4ae84ac300L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=void |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 11, 8, 13, "\ud9b1\udfc3", "\u71de", "\udb8b\udc2c\ud861\udde7\udb26\udc3b\udb5f\udf36\udb69\ude8c",
        33, 74444, 344106811, 4706388682965355741L, -4513L, true, true, (char) 23147, (char) 209,
        Double.longBitsToDouble(0x3fdf2a2458f153aeL), Double.longBitsToDouble(0x3fdb7dcaff4204faL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 10, 0, "\uda31\udd77\udb8b\ude58\udaef\udc83\udb32\udd09\ud917\udcd6\ud8ad\udc85", "\ua988\u18e3\u06e8\u3186", "\u5eb5\udb26\udfba\udbbe\udfdc\u6cf5\udb3d\udf86\ud9c3\udc8f",
        37, 83070, 1996213540, -8231972562303811750L, -1160L, true, true, (char) 43606, (char) 46349,
        Double.longBitsToDouble(0x3fee3a4fe9c8df52L), Double.longBitsToDouble(0x3f9730b23a7b1980L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 7, 10, 13, "\uda97\udc76", "\u3dcf\u4c18\u72b9\u2a70\u6fc0\u93b8\u6607\u2d11\u427a\ub93a\u178a", "\ud8ec\udc33\udadb\udd04\ud8f7\udf83\udac7\udc40\uda6e\udcc1\ud8a5\udd7e\ua940\udad8\udf80\ud8ef\udfb2\udacf\uddfd\uda02\udebc\ud863\udd3a\ud9d6\uddea\udad6\udd6d\ud989\udc01\udac5\ude52\udb38\udcc0\uda20\udcc6\uda05\udf20\uda55\udd39\uda2f\udf0c\uda59\udd46\ud943\ude54\ud250\udba7\uddc4\ud89e\udce9\udaaf\udd9a\udb77\udf73\ud8d8\udf7b\udb48\udcb3\ud8d4\udf7e\uda77\udcd7",
        11, 23256, 2075054534, 803262588142610000L, 56899L, false, true, (char) 27235, (char) 63290,
        Double.longBitsToDouble(0x3fb25dfdf562a2f8L), Double.longBitsToDouble(0x3fec9f0fb9d048baL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=null |a3=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 10, 7, 13, "\uda40\udd58\udb78\udc8a\ud893\udfd6", "\u9ddd\ud64f\u9595\u4ad9", "\ud819\udf68\ud862\udc10\ud9c8\udcd4\udb12\udc3e\udbbf\udc62\uda52\udf05\uda80\udf0b\udb3d\udfab\uda74\udff5\ud9b1\udd2c",
        14, 96671, 900426010, -4510161544535076439L, -28074L, false, true, (char) 51589, (char) 28572,
        Double.longBitsToDouble(0x3fe28ac796a38f39L), Double.longBitsToDouble(0x3feb5fea28ac9383L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 10, 10, 13, "\ud9b1\udfc3", "\u71de\u2565\u72d5\ud64f", "\udab4\udc5b",
        -2, 22966, -952179858, -4737498725950510260L, 89690L, true, false, (char) 28048, (char) 20870,
        Double.longBitsToDouble(0x3feec1255fe13e1cL), Double.longBitsToDouble(0x3fe926ec5894316fL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 9, 1, 13, "\ud9b1\udfc3", "\u7f31\u2fac\u5405\ud64f", "\udb0f\udda7",
        -2, 15733, -1531185430, 1478022110522267794L, 69987L, true, false, (char) 32059, (char) 55494,
        Double.longBitsToDouble(0x3fe926ec5dda52feL), Double.longBitsToDouble(0x3fd4629fac1aef72L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 11, 15, 11, "\ud9b1\udfc3", "\u71de\u3f36\u72d5\ud64f", "\udaee\udc39",
        55, 92003, -340127422, 1477927500982671506L, 89690L, true, false, (char) 28048, (char) 15750,
        Double.longBitsToDouble(0x3faf127ef8609410L), Double.longBitsToDouble(0x3fe926ec589431d7L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 3, 13, "\ud9b1\udfc3\ud89a\udf33\ud893\udfd6\udb29\udc28\ud917\udcd6\ud8ad\udc85\udb8b\udc2c\ud861\udde7\udb87\udd73\udadd\udd6f\udb69\ude8c\ud819\udf68\ud862\udc10\ud948\udc49\uccc6\ud9c1\udd22\udbbe\udfa9\u6cf5\udb3d\udf86\uac67\uda6e\udcc9\ud8a5\udd7e\udba4\ude13\ucee8", "\u4ffd\ud3b1\u88ec\u90f9\u01e0\ua45d\u47e4\u631a\u7c46\u7437\u3a51\u379b\u810a\u184a", "\ud85f\udf99\udb4d\ude1f\uda51\udfd3\udb2a\udfd0\ud92d\udf5e\udb26\ude0b\ud8b1\udf1c\u9f8f\udaff\udf1a\ud833\udce5\ud86f\udffd\ud93e\udffb\uf045\ufe32\ud87b\udd0b\ud830\udd5b\ud8b4\udfc0\uda0b\udeee",
        -1, 66895, 132470318, -5671165262954891554L, -83106L, true, false, (char) 18020, (char) 56487,
        Double.longBitsToDouble(0x3fec939ef295d090L), Double.longBitsToDouble(0x3fe7296fd5782ff2L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 6, "\ud9ad\ude81", "\u9c7e\u7c79\u86ea\ud578", "\uda67\udf1d",
        42, -599, 1118406766, 7310172564500168546L, -73607L, true, true, (char) 8417, (char) 15876,
        Double.longBitsToDouble(0x3faf127eef983070L), Double.longBitsToDouble(0x3fe453aadc3090eaL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 6, "\ud9b1\udfc3", "\u74cb\u2565\u72d5\ud64f", "\ud986\udd5e",
        -2, 76669, -1525608126, 8876529832974242523L, 26237L, false, false, (char) 48676, (char) 22215,
        Double.longBitsToDouble(0x3fb1f736403029b0L), Double.longBitsToDouble(0x3f9000e1db0a6de0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 0, 0, 13, "\ud9b1\udfc3", "\u9519\u4879\uc050\ud64f", "\udab4\udc5b",
        -2, 76112, 1383366712, -1007946449786611651L, -8011L, true, false, (char) 49609, (char) 55494,
        Double.longBitsToDouble(0x3feee661409431d7L), Double.longBitsToDouble(0x3fd955de9c2cd9fcL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 13, "\udb19\udecc", "\u6f7d\u71d9\ud1cb\u6ee8", "\uda48\udc06",
        9, 15733, -340127422, 7539772598979259135L, -8011L, true, false, (char) 32059, (char) 55494,
        Double.longBitsToDouble(0x3fe976ec5982421fL), Double.longBitsToDouble(0x3fd0f3405d2f497eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 13, 15, "\ud966\udfef", "\u8a10\u4828\u86ee\u4680\ubddb\u0d9d\u916e\027\u2363\u1a95\u1543\u9230\u953d\u0695\ua19b\u4992\ud494", "\ud9ab\udf6e\ud839\udfb8\udb14\udeff\u14af\ud8f8\udd7a\ud8cd\udc8b\ud82a\udd31\ud8f6\udd26\udbd1\udf68",
        10, 41289, 757126041, -6177363641240281620L, -33871L, true, true, (char) 19520, (char) 46307,
        Double.longBitsToDouble(0x3fe016ef12fc33cbL), Double.longBitsToDouble(0x3fe566c04e8b80acL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 13, "\ud923\ude7b", "\u71de\u252b\u72d5\uad50\uc52d\ua988\u18e3", "\ud862\udc10\ud996\udc70",
        45, 98737, -317004550, 432482552264877909L, -100000L, false, true, (char) 56715, (char) 29936,
        Double.longBitsToDouble(0x3fe2a26ea28216e3L), Double.longBitsToDouble(0x3fcb770e5263155cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 7, 7, 13, "\ud9b1\udeef", "\u64f8\u15ec\u7251", "\000\u1400\ud89d\udd8a\ud819\udf68",
        25, 93685, -2084175863, 97804995264512L, 31072L, false, false, (char) 51748, (char) 53145,
        Double.longBitsToDouble(0x3fda7cad00924af0L), Double.longBitsToDouble(0x3fee33951b3d984aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=void |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 8, 8, 13, "\ud9cb\udec6\udbec\uddda\ud89c\ude30", "\uab70\u6952\u2cf6\u0389", "\ud819\udf68\ud884\udc42\ud996\udc70\ud951\udf6b\ud88a\udc38\udaff\udf22\ud8c6\uddcc",
        6, 62138, -449682327, 4449965940630032129L, 67983L, false, true, (char) 56872, (char) 2663,
        Double.longBitsToDouble(0x3fed0813ed73e647L), Double.longBitsToDouble(0x3fececc1d1956d9aL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |a3=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null]] |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=null |a3=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 7, 7, 13, "\uda97\udc76", "\u3dcf\u74af\u9149\u49b4\u6fc0\u93b8\u6607\u2d11\u427a\ub93a\u178a", "\udb0d\ude7a\ud989\udecc",
        1, 63719, 155277366, -2482662593606726876L, 33959L, false, true, (char) 63978, (char) 31918,
        Double.longBitsToDouble(0x3fea58f401752c82L), Double.longBitsToDouble(0x3fb2bfe13977d980L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 13, "\udb0b\udcf0", "\u7112\u4c66\ua8c3\uba83\u61fa\u3f63\u04d7\u2d11\u427a\ub93a\u02dc", "\ud813\udf91\ud994\udc89\udaf4\udf76\ud80c\udea6\ud87e\udfec\ud9dc\udc56\udb0d\udef1",
        1, 26812, 1113596390, 6454654764327117678L, -95694L, true, true, (char) 54970, (char) 40516,
        Double.longBitsToDouble(0x3fe2cb83a2195020L), Double.longBitsToDouble(0x3fd830f41a55199aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 2, 10, 13, "\ud8ad\ude72", "\u71de\u0a65\u72d5\ud64f\uc52d\ua988\u18e3", "\ud862\udc10\ud996\udc70",
        4, 60083, 300194255, 449182033651787605L, -11874L, false, true, (char) 60591, (char) 23147,
        Double.longBitsToDouble(0x3fe8382a6f04fac5L), Double.longBitsToDouble(0x3fd72d03b519f75eL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\0121=null |this=com.fasterxml.jackson.databind.type.ResolvedRecursiveType:[recursive type; UNRESOLVED\012",
        Z.run(T, 2, 7, 7, 13, "\uda97\udc76\ud99e\udfc9", "\ucdde", "\ud954\udc62\udb98\udcb5\uda87\udefe\udaaf\udf97\u507b\ud862\udc10\ud996\udc70\uda1c\udcd4\udb5d\ude9e\u1c98\ud8f6\udc99\ud8f8\udd59\udac7\udc40\uda6e\udcc1\ud8a5\udd7e\ud878\udc25\ud8b2\udd7a\ud9e6\uded1\udacf\uddfd\uda02\udebc\ud863\udd3a\ud9d6\uddea\udad6\udd6d\ud989\udc01\uda40\udc10\ud9bf\udc69\ud9d6\ude05",
        9, 29199, 767413591, 6520797029381835371L, -28724L, true, false, (char) 56100, (char) 44852,
        Double.longBitsToDouble(0x3fd5d2c3d6030ff2L), Double.longBitsToDouble(0x3fd96449162ba626L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|getSuperClass||new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|_narrow|java.lang.Class|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|equals|java.lang.Object|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|getErasedSignature|java.lang.StringBuilder|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|getGenericSignature|java.lang.StringBuilder|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|getSelfReferencedType||new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|isContainerType||new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|refine|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|setReference|com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|toString||new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|withContentType|com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|withContentTypeHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|withContentValueHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|withStaticTyping||new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|withTypeHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|withValueHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
    "M|com.fasterxml.jackson.databind.type.ResolvedRecursiveType|getSuperClass||new:com.fasterxml.jackson.databind.type.ResolvedRecursiveType:java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
