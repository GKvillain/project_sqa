package com.fasterxml.jackson.databind;
import org.junit.Test;
import static org.junit.Assert.*;
public class ObjectReader_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 11, 3, "\ud9a1\udf3c\uda35\udf3e", "\u34a9\u89e5\u3f3d\u3ba7\u2629\u3b98\uc2eb", "\udbb6\udf51\ud8f3\udda5\udac9\udc74\ud9ab\udfbc\ud90f\udc35\udb8f\ude38\ud901\ude02",
        51, 43724, 1390362005, -1191108757443775922L, -30969L, true, false, (char) 37535, (char) 27197,
        Double.longBitsToDouble(0x3fe792afcf66fd60L), Double.longBitsToDouble(0x3fa074bdea12c310L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 11, 3, "\ud9a1\udf05\uda35\udf3e", "\u34a9\u89e5\u3f3d\u3ba7\u2629\u3b98\uc2eb", "\udbb6\udf51\ud8f3\udda5\udac9\udc74\ud9ab\udfbc\ud90f\udc35\udb8f\ude38\uc3bc",
        22, 33466, 1390362005, -1191108757443775922L, -31134L, true, false, (char) 9140, (char) 27197,
        Double.longBitsToDouble(0x3fe792afcf66fd60L), Double.longBitsToDouble(0x3fa074bdea12c310L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 0, 14, "\udbb2\udf22\udbba\udce3", "\u2fdd\u6204\u43cd\u3a77\u2629\u3b98\u74d8", "\udbb6\udf51\u3f25\udac9\udc74\udb0e\uddee\udaa0\udd94\udb8f\uddd0\ud901\ude02",
        51, 43724, -1074941158, -2278282521306499230L, -82862L, false, true, (char) 62107, (char) 31054,
        Double.longBitsToDouble(0x3fe6397eadc1298eL), Double.longBitsToDouble(0x3fe743ed08667541L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 11, 3, "\ud9a1\udf3c\uda35\udf3e", "\u5ede\u89e5\u3f3d\u3ba7\ua71b\u3b98\u8344\u86fb\u87f4\uaeb2\u76b7\u049e\u56c3\u8485\ua39b\u50e9\u6acd\u2a3e\u5fcd\u814d\u5241\u0870\u396a\u4316\u0d13\u62fa", "\udad2\udeba\udb16\uddba\ud8c4\udf6c\udab6\ude14\u8439",
        26, 34451, -1310448958, 5974160861573122914L, 9459L, false, false, (char) 60544, (char) 50248,
        Double.longBitsToDouble(0x3feea39d39b68aedL), Double.longBitsToDouble(0x3fda2b39bcf3ad06L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 11, 3, "\ud9a1\ude8a\udb20\udc52", "\u9e4e\u2840\u157d\u6ba2\u63f8\u842b\u1f9b", "\udbb4\udef9\ud8f3\udda5\udac9\udc74\ud833\udd84\udb06\ude54\udb63\udd71\ud901\ude02\uda59\ude14\udbb7\udd58\ud8d6\ude77\uda62\udfeb\ud895\udf79\ud8ba\udf89\uda47\udf90\ud993\udf13\udbee\uddf7\ud9f3\udfe7\ud982\udeca\udbcc\uddc4\ud848\udf87\ud8d6\ude56\udaf6\ude4a\ud981\udca3\udafc\udc36\ud89f\udf88\ud8df\udd4b\ud8c6\udc77\ud854\ude3a\u0d5a",
        31, 43198, -771004911, 1723005519760397221L, -11802L, false, true, (char) 51980, (char) 63598,
        Double.longBitsToDouble(0x3fe46e3f608bc90eL), Double.longBitsToDouble(0x3fd40a4436382c7aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 11, 3, "\ud9a1\udf3c\uda35\udf3e", "\u34a9\u89e5\u3f3d\u2882\u22e0\u4cc6\u71ab", "\udbb6\udf51\ud8f3\udda5\udac9\udc74\ud9ab\udfbc\ud90f\udc35\udb8f\ude38\ud901\ude02",
        51, 43724, 1390362005, -1191108758551072178L, -30969L, true, false, (char) 37535, (char) 27197,
        Double.longBitsToDouble(0x3fe792afcf66fd60L), Double.longBitsToDouble(0x3fa074bdea12c310L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 11, 3, "\ud9a1\udf3c\uda35\udf3e", "\u768c\u7ebc\u3f3d\u2c8a\u26d0\u3b98\uc2eb", "\udbb6\udf51\ud8f3\udda5\udac9\udc74\ud9ab\udfbc\ud90f\udc35\udb8f\ude38\ud901\ude02",
        51, 43724, 1390362005, -1191108757443775922L, -30969L, true, false, (char) 37535, (char) 27197,
        Double.longBitsToDouble(0x3fe94c14e0b42303L), Double.longBitsToDouble(0x3fa074bdea12c380L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 11, 5, "\ud9a1\udf3c\udad8\udd8e", "\u65bc\u89e5\u3f3d", "\udb99\udd26\ud8c8\udfa0\ud98b\udd5d\udad9\udc5f\ud86f\udc93\ud921\udfb7\udac9\udc74\uda26\udcbf\ud843\udcee\uda99\ude3c\ud871\ude0e\udb23\ude7c\udbdd\udfc3\ud8e9\ude74\uda62\udfeb\ud895\udf79\ud8a3\udc5a\ud83a\udeca\ud8cd\ude15\udb49\udcad\ud882\udf13\ud8c6\udeac\ud832\udcc4\udad2\udeba\uda09\udc53\u68dc\uda70\uddb5\ud9ee\udf51\udae3\ude5d\udaa1\ude04\uda4a\udfdc\udb2c\udc23\ud9ec\udcdd\uadd4\udb15\udfb5\ua70e\ud82f\udffd\uda70\udeac\udbbe\udd96\ud945\udebb\ud956\ude5e\ud939\udc70\udb2a\udfa3\udab7\udcdc\ud884\udd9b\ud8a1\udd64",
        36, 62922, 1814015304, 2258815832408412644L, -9426L, false, false, (char) 55251, (char) 9196,
        Double.longBitsToDouble(0x3fc303ce81d85fe0L), Double.longBitsToDouble(0x3fe3c8f8f7757084L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 11, 3, "\ud9a1\udf3c\uda35\udf3e", "\u34a9\u89e5\u3f3d\u3ba7\u2629\u3b98\uc2eb", "\udbb6\udf51\ud8f3\udda5\udac9\udc74\ud9ab\udfbc\ud90f\udc35\udb8f\ude38\udab8\udc1b",
        51, 43724, 1390362005, -1191108757443775922L, -30969L, true, false, (char) 37535, (char) 27197,
        Double.longBitsToDouble(0x3fe792afcf66fd60L), Double.longBitsToDouble(0x3fa074bdea12c310L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ObjectReader|_bindAsTree|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_findTreeDeserializer|com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_bind|com.fasterxml.jackson.core.JsonParser,java.lang.Object|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_bindAndClose|com.fasterxml.jackson.core.JsonParser,java.lang.Object|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_bindAndCloseAsTree|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_bindAndReadValues|com.fasterxml.jackson.core.JsonParser,java.lang.Object|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_detectBindAndClose|[B,int,int|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_detectBindAndClose|com.fasterxml.jackson.databind.deser.DataFormatReaders$Match,boolean|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_detectBindAndCloseAsTree|java.io.InputStream|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_detectBindAndReadValues|com.fasterxml.jackson.databind.deser.DataFormatReaders$Match,boolean|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_findRootDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_initForMultiRead|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_initForReading|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_inputStream|java.io.File|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_inputStream|java.net.URL|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_new|com.fasterxml.jackson.databind.ObjectReader,com.fasterxml.jackson.core.JsonFactory|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_bindAsTree|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_findTreeDeserializer|com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
