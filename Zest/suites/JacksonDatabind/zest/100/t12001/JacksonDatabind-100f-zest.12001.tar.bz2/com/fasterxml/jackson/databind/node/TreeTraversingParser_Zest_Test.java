package com.fasterxml.jackson.databind.node;
import org.junit.Test;
import static org.junit.Assert.*;
public class TreeTraversingParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 9, 4, "\ud902\ude04\uda58\udcf6\uda23\udd81\ud988\ude8f", "\ua424\u452f\u60ec\u7265\ubdd3\u5dff\u21cc\u5bb5\u8736\u9233\ubea7\u6c73\u46e0\uc9cc\ub2ec", "\ud985\udfac",
        7, 53563, -1857275080, 3545911485160769514L, -40777L, false, true, (char) 63067, (char) 58225,
        Double.longBitsToDouble(0x3fc13cbf68fd0904L), Double.longBitsToDouble(0x3fe24f8d1a36da90L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 9, 4, "\ud902\ude04\uda58\udcf6\ub3dd\ud988\udea2", "\ua424\u452f\u60ec\u7265\ud696\u5dff\u2295\ub65f\u055d\u91c3\ubea7\u6c73\u46e0\u95e2\u2b0f", "\ud985\udfac",
        7, 8811, -384421104, 4324046421167458237L, -40777L, false, true, (char) 31182, (char) 58225,
        Double.longBitsToDouble(0x3fc13cbf68fd0904L), Double.longBitsToDouble(0x3fe24f8d1a36da90L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 11, 8, "\ud902\ude04\uda58\udcf6\uda23\udd81\ud988\ude8f", "\u13ff", "\ud99b\udd33",
        5, 59033, 1132726727, -1977955180352706969L, 49314L, false, true, (char) 51830, (char) 30737,
        Double.longBitsToDouble(0x3fef924deb0436d3L), Double.longBitsToDouble(0x3fd92741f522d190L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 9, 4, "\ud84c\udf09\uda37\udd52\uda23\udd81\udb2d\udde3", "\ua424\u452f\u60ec\u7248\ubdd3\u2fd7\u21cc\u5bb5\u8736\u9233\u6823\u1de8\u46e0\uc5a6\ucee8\u34a5\u15c2\ua862\uc2d0\u551b\u7003\ua607\u0245\uc2a9\u6ed3\uac98\u193a\ucc61", "\uda81\udc16\ud93d\ude27\ud9bf\udc7a\ud816\ude77\ud8a4\udd35\ud8c6\ude66\uda06\ude63\ud80d\ude49",
        7, 97780, -2022172012, 2952358043398898994L, 92240L, false, true, (char) 10376, (char) 61848,
        Double.longBitsToDouble(0x3fe5ed6e86468ea4L), Double.longBitsToDouble(0x3fef5a936a392d15L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 14, 4, "\ud975\ude2e\ud85a\udd76\udae3\udec9\ud988\ude8f", "\ua424\u452f\u1c7b\u0616\ubdd3\u5dff\u21cc\u5bb5\u8736\u9233\ubea7\u6c73\u46e0\u3d3f\u9831", "\ud985\udfac",
        7, 86469, -875947287, 3545911712794036202L, -59149L, false, true, (char) 63067, (char) 18802,
        Double.longBitsToDouble(0x3fc13cbe08fd0904L), Double.longBitsToDouble(0x3fe24f8d1a36da90L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 4, "\ud902\ude04\uda58\udcf6\uda23\udd81\u6c1a", "", "",
        4, 39265, -356770048, -4520285433581535232L, -41017L, true, true, (char) 44422, (char) 63561,
        Double.longBitsToDouble(0x3fe440380267cd00L), Double.longBitsToDouble(0x3fdf249bd6086da6L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 9, 7, "\uda72\ude23\ud873\udca6\uda23\ude55\ud988\ude8f\ud97d\udf69", "\u3b0f", "\ud887\ude40\u18ef\udb95\uded6\udb7c\udf02\ud996\udcb5\udba1\udd78\ud951\udd8d\udac2\udf83\uda81\udf90\ud9c5\udfbf\ud851\udd2d\udab6\udd51\udb21\udfbe",
        11, 1226, -1365629135, -7976917068474573899L, 81058L, true, true, (char) 20954, (char) 63067,
        Double.longBitsToDouble(0x3fc80fe1c22795a0L), Double.longBitsToDouble(0x3fe1fa120dbc4c22L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 4, "\u17c7\uda58\udc73\uda23\udd81\ud988\ude8f", "\ua424\ua513\u60f9\u48cf\ubdd3\u5dff\u21cc\u5ab4\u93a8\u9243\ubea7\ua36e\u46e0\uc9cc\ub2ec", "\ud985\udfac\ud9a4\udd46\ud909\udd2e\udb81\udcb1\ud975\ude9b\ud90b\ude65\ud946\udfda\udb50\udcc1\udb5b\udc54\udba7\udff0\ud9d0\ude28\uda4f\udc70\udb8b\udf0a\ud8bd\udc14\uda12\udc72\uda8f\udf2d\ud8a1\udcf0\udbdf\udcb1\ud8f2\udcff\ud910\udf6f\uda85\udc97\ud968\uddc0",
        43, 94889, -419703057, 1431371262293896869L, -22984L, false, true, (char) 6373, (char) 11682,
        Double.longBitsToDouble(0x3fe7a30d9251c4d6L), Double.longBitsToDouble(0x3fcb89633e2cb198L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 2, 4, "\ud902\ude04\uda58\udcf6\uda23\udd81\ud988\ude8f", "\ua424\u452f\u60ec\u7265\ubdd3\u5dff\u21cc\u5bb5\u8736\u9233\ubea7\u3787\ub942\uc9cc\ub2ec\u49f9\u9b7c\ua7fe\uc2d0\ubc37\u7003\ua607\u0245\uc2a9", "\udb01\udd51",
        6, 12721, -240922049, 5480536893536982000L, -69991L, false, true, (char) 21091, (char) 17589,
        Double.longBitsToDouble(0x3fe0c0b37faba4a2L), Double.longBitsToDouble(0x3fc3247d2e8170dcL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 4, "\ud902\ude04\uda58\udcf6+\ud988\ude8f", "\ua424\u452f\u60ec\u7265\ubdd3\u5dff\u21cc\u5bb5\u8736\u886c\u05e9\u6c73\uc288\uc9cc\ub2ec", "\u0091",
        7, 53563, 0, 3530822109703718890L, -40777L, false, true, (char) 22364, (char) 0,
        Double.longBitsToDouble(0x3fc1200008fd0904L), Double.longBitsToDouble(0x3fe24f8d1a36da90L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 9, 4, "\ud902\ude04\uda58\udcf6\uda23\udd81\ud988\ude8f", "\ua424\u452f\u22ec\u1a32\u809b\u5e12\u21cc\u5bb5", "\ud9ac\udfdd\udac2\udf83\uda81\udf90\ud9dd\udebf\ud851\udd2d",
        22, 38210, -823575919, -8103340112518080164L, 56747L, false, true, (char) 56051, (char) 29002,
        Double.longBitsToDouble(0x3fdce1810f4cad6cL), Double.longBitsToDouble(0x3fe9c301d089e5fbL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 14, 12, "\ud902\ude04\uda58\udcf6\uda23\udd81\ud988\ude8f", "\ua424\u452f\u60ec\u7265\ubdd3\u5dff\u21cc\u5bb5\u8736\u9233\ubea7\u6c73\u46e0\ua851\ub2ec", "\ud985\udfac",
        7, 53563, -1857275080, 3545911485160769514L, -40777L, false, true, (char) 63067, (char) 58225,
        Double.longBitsToDouble(0x3fc13cbf68fd0904L), Double.longBitsToDouble(0x3fe24f8d1a36da90L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 9, 4, "\ud902\ude04\uda58\udcf6\udbb7\ude20\ud988\ude8f", "\ud1d5\u452f\u60ec\u7265\ubdd3\u12ee\u3d9a\u5bb5\u8736\u9233\u9a81\uc550\u03f5\uc9cc\ub2ec", "\ud985\udfac",
        7, 53563, -1857275080, 3545911485160769514L, -40777L, false, true, (char) 63067, (char) 58225,
        Double.longBitsToDouble(0x3fc13cbf68fd0904L), Double.longBitsToDouble(0x3fe24f8d1a36da90L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 9, 12, "\ud942\udfbf\udac3\udfeb\ud83a\udd81\ud988\ude8f\udbe8\uddb3\ud9b1\uded8\ud8d5\uddba\ud90d\udd4d\uda44\udfc2", "\u5dff\ud559\u9fc9\u4418\u8f40\uc144\u13a5\u465b\u9049\u3f3f\ud1fc\u190e\ua81c\uc2d0\ubbce\u70b1", "\uda23\udc3c\ud94d\udc97\ud86c\udc68",
        58, 52560, 1111619721, -1034893059456698295L, 59559L, false, true, (char) 14619, (char) 12913,
        Double.longBitsToDouble(0x3fec351697ee8143L), Double.longBitsToDouble(0x3fa01d4a04a9b330L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 9, 5, "\ud902\ude04\uda58\udcf6\uda23\udd81\ud91f\udd61", "\ua424\u452f\u60ec\u7265\uaaca\u90a3\ub6d5\u5be4\u8736\u9233\ubea7\u6c73\u56da\uc9cc\ub2ec", "\ud985\udfac",
        7, 53563, -1857275080, 3545911485160769514L, -40777L, false, true, (char) 63067, (char) 58225,
        Double.longBitsToDouble(0x3fc13cbf68fd0904L), Double.longBitsToDouble(0x3fe24f8d1a36da90L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 9, 4, "\ud902\ude04", "\u8dfe\u0fbf\u77f6\ua424\u452f\u60ec\u7265\ubdd3\u5dff\u21cc\uc707\u87ba\u12f9\ubed4\ub1de\u3483\uc9cc\u9467\u428c\u15c2\ua969\ua2bf\ud29a\uafa0", "\udb00\udda4\udb46\udd7f\ud889\udeea\udb01\udd51\ud9d0\uddaf\uda4f\udc70\ud944\udd66\ud8bd\udc14\ud922\udcb9\ud82c\udc5c\ud8eb\ude25\udbdd\udf55",
        37, 94175, 688838818, 4114076022462329734L, -8147L, true, false, (char) 34917, (char) 35957,
        Double.longBitsToDouble(0x3fea8b2319a1fcbaL), Double.longBitsToDouble(0x3fb214958e9049f0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 9, 4, "\ud902\ude04\uda58\udcf6\uda23\udd81\ud988\ude8f", "\ua424\u452f\u545e\u7265\ubdd3\u5dff\u21cc\u5bb5\u8736\u9233\ubea7\u6c73\u46e0\uc9cc\ub2ec", "\ud985\udfac",
        7, 53563, -1857275080, 3545911485145151315L, -40777L, false, true, (char) 63067, (char) 58225,
        Double.longBitsToDouble(0x3fc13cbf68fd0904L), Double.longBitsToDouble(0x3fe24f8d1a36da90L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 12, 4, "\udbb9\udce8\uda58\udcf6\uda23\udd81\ud988\ude8f", "\ua424\ubbb3\u6157\u7265\ubdd3\u5dff\u21cc\u5bb5\u8736\u9233\ubea7\u5069\u46e0\uc42b\u8a7e", "\ud985\udfac",
        7, 11309, -702969204, 3545910733126417627L, 55878L, true, false, (char) 62976, (char) 58225,
        Double.longBitsToDouble(0x3fc13cbf68fd0904L), Double.longBitsToDouble(0x3fe24f8d1a36da90L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 11, 8, "\ud8c5\udc05\uda34\ude8a\ud91f\udcd9\uda1d\udc6f", "\ucaa5\u0572\u70f8\u5075\u69b4\u6f46\u7287", "\uda09\udc73\udb0e\udf2a\ud8d7\udd8e\uda81\udf90\ud9dd\udebf\ud878\udf2d\ud83d\udef4\ud9df\udfdb\udba6\udfa6",
        52, 72868, 1492208691, -1046373782314644117L, 24745L, true, false, (char) 12365, (char) 7895,
        Double.longBitsToDouble(0x3fcd4879294f6b18L), Double.longBitsToDouble(0x3feb00f37ad8222dL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 4, "\udad9\udd1c\ud89e\udcd9\uda65\udfa5\u6c1a\000\000\000\000\ud90b\udc45\ud99b\udd3b\ud807\udfcf\ud8b5\udf48\uda27\udd72\u00bc\ud92c\uddff\udb0d\uded5\ud9ac\udfdd", "\u7d04", "\udae8\uded4\ud9b3\udd57\udb12\udc23\u063b\ud947\udc01\udbde\udc1b\udb08\udc10\udafd\udd1a",
        23, 75091, 1099946974, -3387605479917643534L, 84109L, false, false, (char) 22949, (char) 21882,
        Double.longBitsToDouble(0x3fd2f05998960744L), Double.longBitsToDouble(0x3fd8b0829065bf86L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 4, "\u17c7", "\u9206\u5504\u8a66\ua424\ua513\u60f9\u48cf\ubdd3\u5dff\u73a9\u5ab4\u93a8\u9243\ubea7\ua37a\u3bc3\uc9cc\u02fe\u04f3\ud6df\ua862\u19ff\ua127\u7003", "\ud946\udfda\uda10\ude6e\ud966\ude00\ud975\udf7b",
        38, 12721, -912010689, -2697490937020194250L, 74663L, false, true, (char) 51317, (char) 38747,
        Double.longBitsToDouble(0x3f8f4bbf45205380L), Double.longBitsToDouble(0x3fed027a6d51ceb1L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 9, 4, "\uda92\udf9f\uda58\udcf6\uda23\udd81\ud988\ude8f", "\ua424\u452f\u22ec\u1a32\u809b\u5e12\u21cc\u5bb5", "\ud9ac\udf8c\udac2\udf83\uda81\udf90\ud9dd\udebf\ud851\udd2d",
        43, 53678, -831001199, -8103340112518080164L, -1274L, false, false, (char) 56036, (char) 29092,
        Double.longBitsToDouble(0x3fdce1810f4cad6cL), Double.longBitsToDouble(0x3fe9c301d089e5fbL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 11, 14, "\ud902\ude04\uda58\udcf6\udbb7\ude20\ud988\ude8f", "\ud1d5\u452f\u60ec\u7265\u67e2\ua9c2\u9c57\u1e86\ud56f\u123c\u32f0\u2dd6\u03f5\uc9cc\ub2ec", "\udb54\udd9f",
        15, 53390, -1857275080, 3545911485160769514L, -40777L, true, true, (char) 63067, (char) 58225,
        Double.longBitsToDouble(0x3fc13cbf68fd0904L), Double.longBitsToDouble(0x3fe24f88a26de00aL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 5, "\udb65\udc3a\ud9e2\udf39\ud970\uddfe\ud91f\udd61\ud84f\ude18\ud906\ude39\ud8e7\uddcf\ud90d\udd4d\u3678\ud96a\ude4a\udaba\ude00\ud88d\udf06\ud869\udff9\udb7c\udece\udb38\ude05\udb0d\uded5\ud9ac\udfdd\udac2\udf83\ua28f\ud9dd\udebf\ud851\udd2d\udb92\udddb\udb21\udfbe\uda45\uddeb\udb8f\uded1\ud909\udd2e", "\u0245\uc2a9\u2bd8\u6893", "\uda4f\udc7e",
        56, 59449, 114909750, 1353912407867576477L, -10405L, false, true, (char) 8927, (char) 18258,
        Double.longBitsToDouble(0x3fede3699aaeec36L), Double.longBitsToDouble(0x3fe238db617b314cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 11, 12, "\u17c7\ud9d6\udda0\ud9dc\udcdd\udbb9\udf84\ud853\udcba\udb77\udd50\ud8e7\uddcf\ud931\udf76\uda44\udfcf\ud9a8\udfe9\udb08\udf7d\ud870\udf62\udabe\uddc9\udb78\ude49\ud8bd\udd07", "\u520a\ubfc2\u68cc", "\udbca\uddc8\ud97a\udebb\ud8c9\udf17\uda87\udce0\ud81b\udcfa\udbbf\udce5\udbd9\udeb4\ud946\udfda\uda10\ude6e\ud966\ude00\uda56\udf20\uda06\udc46\uad40",
        34, 87064, 528907386, -716068712321325109L, 6596L, true, true, (char) 38892, (char) 63153,
        Double.longBitsToDouble(0x3fe0e03e3c51ac5bL), Double.longBitsToDouble(0x3fe10a886b9a2b26L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 4, "\u17c7", "\u9206\u5504\u8a66\ua424\ua513\u60f9\u48cf\ubdd3\u5dff\u73a9\u5ab4\u93a8\u9243\ubea7\ua37a\u3bc3\u55cc\u02fe\u04f3\u576f\uab0d\u19ff\ua127\u7003", "\ud946\udfda\uda10\ude6e\ud899\udd96\ud981\uddbe",
        38, 12721, -912010689, -2697490937020194250L, 74663L, false, true, (char) 51317, (char) 40008,
        Double.longBitsToDouble(0x3f8f4b2545205380L), Double.longBitsToDouble(0x3fed027a6ee6ceb1L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 8, 4, "\u17c7", "\u9206\u5504\u8a66\ua424\ua513\u60f9\u48cf\ubdd3\ub353\u75a5\u5ab4\u93a8\u9243\ubea7\ua37a\u3bc3\uca37\u57f4\u04f3\u576f\uab0d\u19ff\ub044\u8c9c", "\udb49\udda9\uda10\uddca\ud899\udd96\ud981\uddbe\uda06\udcad\uda4f\udc70\udb8b\udf0a\ud8bd\udc14\uda12\udc72\uda8f\udf2d\uda61\udd1f\ud8fb\ude8a\udbae\uddb8\udae6\udcd5\uda85\udc97\ud968\uddc0\ud85c\udcb8\udb30\udcc3\uda42\udedb\udb7d\udc76",
        33, 51955, -1083316515, -6964906266121787704L, 41766L, true, true, (char) 41646, (char) 65517,
        Double.longBitsToDouble(0x3fd26dd99db0d50eL), Double.longBitsToDouble(0x3fe377904ddbee44L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 9, 4, "\ud9d0\ude0b\uda58\udcf6\uda23\udd81\ud988\ude8f", "\ua424\u5535\u7c94\u7265\u2c82\u5dff\u21cc\u5bb5\u8aec\u9233\ubea7\u12f1\u13ff\uc975", "\udb21\udfbe\ud985\udfac\ud844\udd2b\ud9e0\ude11\udb81\udcb1\ud975\ude9b\ud90b\ude65\ud9ec\udfcd\ud83d\udd8a\udb51\udd1a\ud9ff\udc49\u8502",
        30, 62951, 1933974345, -7103920637701734509L, 62898L, false, false, (char) 21724, (char) 15016,
        Double.longBitsToDouble(0x3fc38fef1a9d7e08L), Double.longBitsToDouble(0x3fab70d6ec2a4080L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 7, 4, "\udac8\udd67", "\u8ce0\u229c\u8a66\ua424\u7e6a\u60f9\uaec4\u1404\u3724\ub62f", "\udb0d\udee5\ud9ac\udfdd",
        23, 34586, 1237140918, -3827389041509760127L, -19471L, false, false, (char) 60897, (char) 62134,
        Double.longBitsToDouble(0x3fe979829f2e2d78L), Double.longBitsToDouble(0x3fea136fe5e14df9L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getBinaryValue|com.fasterxml.jackson.core.Base64Variant|new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|_handleEOF||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|close||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|currentNode||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|currentNumericNode||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getBigIntegerValue||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getCodec||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getCurrentLocation||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getCurrentName||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getDecimalValue||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getDoubleValue||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getEmbeddedObject||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getFloatValue||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getIntValue||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getLongValue||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getNumberType||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getBinaryValue|com.fasterxml.jackson.core.Base64Variant|new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
