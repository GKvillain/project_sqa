package com.fasterxml.jackson.databind.deser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringArrayDeserializer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 6, "\uda5d\udff0\ud99a\udc35\ud84d\udea2\ue143\ud935\udf07", "\u34b8\u071f\u366a\u8e34\u45f7\ud1dd\ua2e9\u4828\u465b\u19c5\u5439\ua2ee\u8714\u0712", "\uda67\udefd\udbfd\ude23\udb5b\udf1e\ud8f4\ude84\udba3\udd99\udb29\udc7c\ud81e\udd77\ud953\udc57\ud9b8\udd8f\udb99\udf36\udbe6\ude68\uda7a\udf0e\uda3b\udc57\udb41\udeba\ud87a\uddb3\ud87c\udfb6\udb1d\udc6b\udb71\udf6d\ud832\udce8\udacb\ude79\udb53\udf94\ud880\udd73\udba8\ude4a\ud9fb\udc9b\ud9de\udc58",
        44, 74940, -1377908412, -9137096632119151315L, 45456L, false, true, (char) 37951, (char) 36097,
        Double.longBitsToDouble(0x3fb43cdd4d2800f0L), Double.longBitsToDouble(0x3fe1a7de87161426L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 6, "\uda5d\udff0\ud99a\udc35\ud84d\udea2\ue143\ud916\udd07", "\u34b8\u071f\u366a\u8e34\u45f7\ud1dd\ua2e9\u4828\u465b\u19c5\u5439\ua2ee\u8714\u0712", "\uda67\udefd\udbfd\ude23\udbba\udd11\ud8fa\uddca\ud8c1\uddce\udb29\udc7c\ud81e\udd77\ud953\udc57\ud9b8\udd8f\udb99\udf36\udbe6\ude68\uda7a\udf0e\uda3b\udc57\udb41\udeba\ud87a\uddb3\ud81e\udfa7\udb1d\udcde\uda38\udcd0\ud832\udc0f\udacb\ude79\udb53\udf94\ud880\udd73\udba8\ude4a\ud9fb\udc9b\ud9de\udc58",
        52, 74987, -1377908412, -9137096632146489936L, -74608L, false, true, (char) 37951, (char) 36097,
        Double.longBitsToDouble(0x3fe9979ba97c33ddL), Double.longBitsToDouble(0x3fcea5537005b7a0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 6, "\uda7c\udf20\ud99a\udc35\ud84d\udea2\ue143\ud935\udf07", "\u34b8\u071f\u366a\u8e34\u45f7\ub733\ua2e9\u4828\u465b\u19c5\u5439\ua2ee\u8714\u0712", "\uda67\udefd\udbfd\ude23\udb5b\udf1e\ud8f4\ude84\udba3\udd99\udb29\udc7c\ud81e\udd77\ud953\udc57\ud935\udf6f\udbe9\ude91\udbb9\udf07\uda7a\udf0e\uda3b\udc57\udb41\udeba\ud87a\uddb3\ud87c\udfb6\udb1d\udc6b\udb71\udf6d\ud832\udce8\udacb\ude79\udb53\udf94\ud880\udd73\udba8\ude4a\ud9fb\udc9b\ud9b1\udea2",
        4, 74940, -1377908412, -9137096632119151315L, 45456L, false, true, (char) 37951, (char) 36097,
        Double.longBitsToDouble(0x3fd50f37534a003eL), Double.longBitsToDouble(0x3fe1a7de87161426L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 6, "\uda5d\udff0\ud99a\udc35\ud84d\udea2\ue143\ud935\udf07", "\u34b8\u071f\u366a\u8e34\u3d60\u5c1a\ua2e9\u4828\u465b\u412c\u54df\ua2ee\u8714\u0712", "\uda67\udefd\udbfd\ude23\udb5b\udf1e\ud8f4\ude84\ud804\uddc9\ud88e\udc2e\ud81f\ude0d\ud953\udc57\ud9b8\udd8f\udb99\udf36\udbe6\ude68\uda7a\udf0e\uda3b\udc57\udb41\udeba\ud87a\uddb3\ud87c\udfb6\udb1d\udc6b\udb71\udf6d\ud832\udce8\udab4\ude79\udb53\udf94\ud880\udd73\udba8\ude4a\uda58\udece\ud9c3\udc2b",
        44, 74940, 2098753154, 4986191799314724141L, 45456L, false, true, (char) 37951, (char) 36097,
        Double.longBitsToDouble(0x3fb43cdd4d2800f0L), Double.longBitsToDouble(0x3fe1a7de87161426L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 6, "\uda5d\udff0\ud99a\udc35\ud84d\udea2\ue143\ud935\udf07", "\u34b8\u071f\u2b6b\u77fb\ua60f\u550b\u51cc\u7599\u465b\u19c5\u5439\ua2ee\u8714\u0712", "\uda67\udefd\udbfd\ude23\udb5b\udf1e\ud8f4\ude84\udba3\udd99\udb29\udc7c\ud81e\udd77\ud953\udc57\ud9b8\udd8f\udb99\udf36\udbe6\ude68\uda7a\udf0e\uda3b\udc57\udb41\udeba\ud87a\uddb3\ud87c\udfb6\udb1d\udc6b\udb71\udf6d\ud832\udce8\udacb\ude79\udb53\udf94\ud880\udd73\udba8\ude4a\ud9fb\udc9b\ud9de\udc58",
        47, 74940, -1377908412, -9137096632119151315L, 45456L, false, true, (char) 37951, (char) 36097,
        Double.longBitsToDouble(0x3fb43cdd652800f0L), Double.longBitsToDouble(0x3fe1a05527161426L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:@?\012",
        Z.run(T, 1, 5, 0, 7, "\uda5d\udff0\ud99a\udc35\ud84d\udea2\ue143\ud935\udf07", "\u34b8\u071f\u366a\u8e34", "\ud8ae\udc5e\u4727",
        51, 85647, 1712728891, -7914380545491426654L, -79233L, true, false, (char) 60628, (char) 30558,
        Double.longBitsToDouble(0x3fe78837bf4527ecL), Double.longBitsToDouble(0x3f94e6d6abfaf400L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:@?\0121=new com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:@?\012",
        Z.run(T, 2, 5, 6, 6, "\u412a\ud99a\udc35\ud8fd\udf6c\udb19\udfa6\ud91a\udf60\uda52\udfbc", "\u3711\uce69\u9f18\ud64e", "\u4727\ud83e\uddc2\ud90e\udfee\ud856\udd3f\ud87e\udc22\udb06\ude06\udadd\uded8\ud9bb\uddd1\uda15\udc92\uda67\udefd\ud8eb\ude67\udb5b\udf25\udb96\ude16\ud898\udefd\ud8b1\udca5",
        40, 98357, 1967753894, -4232228417902929370L, -67047L, false, true, (char) 5163, (char) 65023,
        Double.longBitsToDouble(0x3fe76090cff499edL), Double.longBitsToDouble(0x3fb4aefb08503350L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 3, "\uda5d\udff0\ud9b7\udcc7\ud84d\ude4a\ue143\udba8\udebc", "\u34b8\u071f\u366a\ubf07\u459e\ud1dd\u2a86\u4828\ud1e8\ud23c\u5431\u1324\u6533\u5560", "\udbcc\uddf5\ud847\ude23\udb5b\udf9e\ud8f4\ude84\udba3\udd99\uda63\udf79\uda98\uddb2",
        13, 70894, 240139074, 6815630904979649408L, -85311L, true, true, (char) 23321, (char) 6299,
        Double.longBitsToDouble(0x3fe2e8a886ec1216L), Double.longBitsToDouble(0x3feade3afb70e6ecL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 6, "\uda5d\udff0\ud99a\udc35\ud828\udf2e\ue14c\ud935\udf07", "\u34b8\u071f\u366a\u8e34\u45f7\ud1dd\ua2e9\u9030\ub73e\u19fa\u5439\ua2ee\u8714\u408c", "\uda67\udefd\udbfd\ude23\udb5b\udf1e\ud872\udfc4\udb97\udece\udb29\udc7c\ud81e\udd77\ud953\udc57\ud9b8\udd8f\udb99\udf36\udbda\ude62\uda7a\udf0e\uda3b\udc57\udb41\udeba\ud87a\uddb3\ud87c\udfb6\udb1d\udc6b\udb71\udf6d\ud832\udce8\udacb\ude79\ud957\udef7\ud8e8\udc27\ud9bc\udf72",
        18, 11438, -468163787, -673352346840938172L, -26652L, true, true, (char) 16129, (char) 10227,
        Double.longBitsToDouble(0x3fee6f4b92cadd7bL), Double.longBitsToDouble(0x3fb43cdd4d2800f0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 6, "\uda5e\udc57\ud825\ude1a\ud98e\udd63\u7c43\ud935\udf07", "\u34b8\u071f\u366a\u7b54\u259e\ud1dd\ua2e9\u0e29\ud7d6\u19c8\u5439\ua2ee\u0c6a\u288d", "\udabf\ude59\udbfd\ude23\udb5b\udf1e\ud8f4\ude84\udba3\udd99\udb76\udf47\ud81e\udd8e\ud953\udc57\ud9b8\udd8f\udb99\udf36\uda88\udf3d\uda7a\udf0e\uda3b\udc57\udb41\udeba\ud87a\uddb3\ud87c\udfb6\udb1d\udc6b\udb71\udf6d\ud832\udce8\ud99e\udd02\udbc5\ude57\udb13\udd93\udb33\udf92",
        56, 8182, 443468350, -673352089142900412L, -15309L, true, true, (char) 15889, (char) 11398,
        Double.longBitsToDouble(0x3fe66f4be2bcda45L), Double.longBitsToDouble(0x3fb43cdd4d2800f0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 0, "\udb7e\udf9f\ud81c\uddf5\ud84d\udea2\ue143\ud935\udf07\uda52\udfbc\udbec\ude2d\udbba\udc7e\udaf2\udf06\ud859\ude53\ud83e\udf2c\ud9c1\ude68\ud822\udf3b\ud8ae\udc5e\u4727\ud8dd\udec5\ud90e\udfee\ud856\udd3f\ud87e\udc22\udb06\ude06\udadd\uded8", "\uacaa\uad6f\u192f\u41eb\u5821\uc513\u450e\u8cd9\u65a8\u4d10\u7cf0\u2a98\u0e2e\uc419\u6fff\u33ae\u5d97\u266f\u9df9\u223c\u99d7\u23dd\u0efe\u914f\ub691", "\udbc3\udc6c",
        20, 36325, 114378173, -3826309054973453044L, 50852L, false, false, (char) 27075, (char) 57860,
        Double.longBitsToDouble(0x3fe8b0a134206124L), Double.longBitsToDouble(0x3feaacc0e6ef2bc5L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:@?\0121=new com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:@?\012",
        Z.run(T, 2, 5, 5, 6, "\uda5d\udff0\uda9d\udcf7\ud84d\udea2\ue143\ud935\udf07", "\u34b8\u071f\u366a\u8e34\u45f7\ud1dd\ua2e9\u4828\u465b\u19c5\u5439\ua2ee\u8714\u0712", "\uda67\udefd\udbfd\ude23\udb5b\udf1e\ud8f4\ude84\udba3\udd99\udb29\udc7c\ud81e\udd77\ud953\udc57\ud9b8\udd8f\udb99\udf36\udbe6\ude68\uda7a\udf0e\uda3b\udc57\udb41\udeba\ud87a\uddb3\ud87c\udfb6\udb1d\udc6b\udb71\udf6d\ud832\udce8\udacb\ude79\udb53\udf94\ud880\udd73\udba8\ude4a\ud9fb\udc9b\ud9de\udc58",
        44, 74940, -1377908412, -9137096632119151315L, 45456L, false, true, (char) 37951, (char) 36097,
        Double.longBitsToDouble(0x3fbf7cdd4d2800f0L), Double.longBitsToDouble(0x3fe1a7de87161426L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 6, "\uda5d\udff0\ud99a\udc35\ud84d\udea2\ue143\ud935\udf07", "\u34b8\u7517\u366a\u8e34\u45f7\ud1dd\ua2e9\u4828\u465b\u19c5\u5405\ua2ee\u8714\u0712", "\ud854\udcb3\udbfd\ude23\udb5b\udf1e\ud8f4\ude84\udba3\udd99\udb29\udc7c\ud81e\udd77\ud953\udc57\ud9b8\udd8f\udb99\udf36\udbe6\ude68\uda7a\udf0e\uda3b\udc57\udb41\udeba\ud87a\uddb3\ud87c\udfb6\udb1d\udc6b\udb71\udf6d\ud832\udce8\udacb\ude79\udb53\udf94\ud880\udd73\udba8\ude4a\ud9fb\udc9b\ud9de\udc58",
        44, 74940, -1377908412, -9137096632119151315L, 45456L, false, true, (char) 37951, (char) 36097,
        Double.longBitsToDouble(0x3fb43cdd4d2800f0L), Double.longBitsToDouble(0x3fe1a7de87161426L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 6, "\uda7c\udf20\ud99a\udc35", "\u15de\ub28b\u3097\u89f3", "",
        -5, -1000, 0, 3674937294876771038L, 44943L, true, true, (char) 57065, (char) 8977,
        Double.longBitsToDouble(0x3fedc57a011f78f3L), Double.longBitsToDouble(0x3fcf69f693e5bf6cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer|_deserializeCustom|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:",
    "M|com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer|deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:",
    "M|com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer|createContextual|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanProperty|new:com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:",
    "M|com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer|deserializeWithType|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.jsontype.TypeDeserializer|new:com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:",
    "M|com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer|handleNonArray|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:",
    "C|com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer|<init>|",
    "C|com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer|<init>|com.fasterxml.jackson.databind.JsonDeserializer",
    "M|com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer|_deserializeCustom|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:",
    "M|com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer|deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
