package com.fasterxml.jackson.databind;
import org.junit.Test;
import static org.junit.Assert.*;
public class ObjectReader_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 11, "\ud801\udc04\uda9b\udfe6\udbf0\ude29\uda04\ude27\udb07\ude8c\udb5e\udd48\uda49\udc58\u5144\udb12\udc5a", "\ubdc5\u872c\u02a5\ua552\u81e2\u1017\u7325\uab5f\uae3b\u293b\ub464\u7f09\u6c60\u768f\u90e5\u715a\u0c50\u6844\u3e6a\u7628\u34ba\u27c0\u3a39\u155f\ub150\u7f82\uc388", "\uda94\ude51\udb7b\ude80\ud86d\udf98\ud85c\udfe0\uda7f\ude63\ud9b3\udd57\ud99f\udcf8\udad6\udfd1\ud873\uddca\ud9ec\udd0f\uda0d\udd79\u8170\uda58\udc72\udaee\udcd7\ud954\uded3\ud94a\ude36\ud881\udd82\uda5f\udc08\ud8d5\udf3c\uda04\udf2e\ud30c\u7b61\udb8c\uddf4\ud9e1\ude5b\ud882\uddae\uda4d\udfa3\uda76\ude56\uda02\ude28\ud942\udec1\ud86e\ude8d\ud943\udf2b\udabb\udde3\uda33\uddac\udbe8\udd81\u75fc\ubca1\uda12\udc1a\ud96e\udf9d\ud823\udf4b\udaa5\udc62\uda4a\udc22\ud88d\udcca\uda3a\udeac\udba6\ude77\ubece\udbed\udecd\uda51\udc29\ud8cc\udf6d\udb60\udeb8\udb03\ude1f",
        2, -259, -556942341, 7142978988646851590L, -77146L, true, true, (char) 19675, (char) 17867,
        Double.longBitsToDouble(0x3fe15ae6c51e2f00L), Double.longBitsToDouble(0x3fdd7522c5703048L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 11, "\ud801\udc04\uda9b\udfe6\udbf0\ude29\uda04\ude27\udb07\ude8c\udb5e\udd48\uda49\udc58\u5144\udb12\udc5a", "\ubdc5\u872c\u02a5\ua552\u81e2\u1017\u7325\uab5f\uae3b\u293b\ub464\u7f09\u6c60\u768f\u90e5\u715a\u0c50\u6844\u3e6a\u7628\u34ba\u27c0\u3a39\u155f\ub150\u7f82\uc388", "\uda94\ude51\udb7b\ude80\ud86d\udf98\ud85c\udfe0\uda7f\ude63\ud9b3\udd57\ud99f\udcf8\udad6\udfd1\ud873\uddca\ud9ec\udd0f\uda0d\udd79\ud84e\udd55\uda58\udc72\udad0\uddc7\ud954\uded3\ud94a\ude36\ud881\udd82\uda5f\udc08\ud8d5\udf3c\uda04\udf2e\ud30c\u7b61\udb8c\uddf4\ud9e1\ude5b\ud882\uddae\uda4d\udfa3\uda76\ude56\uda02\ude28\ud942\udec1\ud86e\ude8d\ud943\udf2b\udabb\udde3\uda33\uddac\udbe8\udd81\u75fc\ubca1\uda12\udc1a\ud96e\udf9d\ud823\udf4b\udaa5\udc62\uda4a\udc22\ud88d\udcca\uda3a\udeac\udba6\ude77\ubece\udbed\udecd\uda51\udc29\ud8cc\udf6d\udb60\udeb8\udb03\ude1f",
        2, -259, -556942341, 7142978988646851590L, -77146L, true, true, (char) 19675, (char) 17867,
        Double.longBitsToDouble(0x3fe15ae6c51e2f00L), Double.longBitsToDouble(0x3fdd7522c5703048L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 11, "\ud801\udc04\uda9b\udfe6\udbf0\ude29\uda04\ude27\udb07\ude8c\ud8ab\udecf\udbc8\udd59\ud9ac\udeba\udbed\udcec", "\ubdc5\u872c\u02a5\ua552\u81e2\u1017\u7325\uab5f\uae3b\u293b\ub464\u7f09\u6c60\u768f\u90e5\u715a\u0c50\u6844\u3e6a", "\udbac\udf53\uda40\udee2\ud94e\udec3\ud9b7\udd9a\uda6c\ude36\ud870\uddd6\udae2\udf62",
        28, 60757, -565063555, -8400710328430327132L, -59558L, true, true, (char) 43784, (char) 3457,
        Double.longBitsToDouble(0x3f817e0589d6ef40L), Double.longBitsToDouble(0x3fdf19f337586276L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 10, 11, "\ud801\udc04\uda9b\udfe6\udbf0\ude29\uda04\ude27\udb07\ude8c\udb5e\udd48\uda49\udc58\u5144\udb12\udc5a", "\ubdc5\u872c\u02a5\ua552\u81e2\u1017\u7325\uab5f\uae3b\u293b\ub464\u7f09\u6c60\u768f\u90e5\u715a\u0c50\u6844\u3e6a\u7628\u34ba\u27c0\u3a39\u155f\ub150\u7f82\uc388", "\uda94\ude51\udb7b\ude80\ud86d\udf98\ud85c\udfe0\uda7f\ude63\ud9b3\udd57\ud99f\udcf8\udad6\udfd1\ud873\uddca\ud9ec\udd0f\uda0d\udd79\u8170\uda58\udc72\udaee\udcd7\ud954\uded3\ud94a\ude36\ud881\udd82\uda5f\udc08\ud8d5\udf3c\uda04\udf2e\ud30c\u7b61\udb8c\uddf4\ud9e1\ude5b\ud882\uddae\uda4d\udfa3\uda76\ude56\uda02\ude28\ud942\udec1\ud86e\ude8d\ud943\udf2b\udabb\udde3\ud939\udf8f\udbe8\uddc4\u75fc\ubca1\uda12\udc1a\ud96e\udf9d\ud823\udf4b\udaa5\udc62\uda4a\udc22\ud88d\udcca\uda3a\udeac\udba6\ude77\ubece\udbed\udecd\uda51\udc29\ud8cc\udf6d\udb60\udeb8\udb03\ude1f",
        51, 220, -556942341, 7142978988646851590L, -77146L, true, true, (char) 19675, (char) 17867,
        Double.longBitsToDouble(0x3fe15ae6c51e2f00L), Double.longBitsToDouble(0x3fdd7522c5703048L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 10, 11, "\uaa04\uda42\udcf9\uda11\udf4e\u8271\ud9d6\udf92\udb3a\udd35\uda49\udc58\u5144\udb12\udc5a", "\ubdc5\u872c\u02a5\ua552\u81e2\u1017\u72fa\uab5f\uae3b\u293b\ub464\u7f09\u6c60\u768f\u90e5\u715a\u0c50\u6844\u316b\u7628\u34ba\u27c0\u3a39\u155f\ub150\u7f82\uc388", "\uda94\ude51\udb7b\ude80\ud86d\udf98\ud85c\udfe0\uda7d\udd63\ud97a\udcbb\uda85\udf8a\udad6\udf51\ud873\uddca\ud9ec\udd0f\uda0d\udd79\u8170\udaad\udcfc\udada\ude3c\ud954\uded3\ud94a\ude36\ud881\udd82\uda5f\udc08\ud8d5\udf3c\udb96\udf6e\ud82b\ude67\u7b61\udb8c\uddf4\ud9e1\ude5b\ud882\uddae\uda4d\udfa3\uda76\ude56\uda02\ude28\ud942\udec1\ud86e\ude8d\ud943\udf2b\udabb\udde3\uda33\uddac\udbe8\udd81\u75fc\ubca1\udb46\udc14\ud96e\udf9d\ud823\udf4b\udaa5\udc62\uda4a\udc22\ud88d\udcca\uda3a\udeac\udba6\ude77\udb1d\udc40\uda02\udd80\uda51\udc29\ud8cc\udf6d\udb60\udeb8\udb03\ude1f",
        2, -259, -556942341, -6980309439279636734L, -72689L, true, false, (char) 22275, (char) 52253,
        Double.longBitsToDouble(0x3fdd7522c9703048L), Double.longBitsToDouble(0x3fe3ca8bc711f3a7L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 11, "\ud801\udc04\uda9b\udfe6\udbf0\ude29\uda04\ude27\udb07\ude8c\udb5e\udd48\uda49\udc58\u5144\udb12\udc5a", "\ubdc5\u872c\u02a5\ua552\u81e2\u1017\u7325\uab5f\uae3b\u293b\ub464\u7f09\u6c60\u768f\u90e5\u715a\u0c50\u6844\u3e6a\u7628\u34ba\u27c0\u3a39\u155f\ub150\u7f82\uc388", "\uda94\ude51\udb7b\ude80\ud86d\udf98\ud85c\udfe0\uda7f\ude63\ud9b3\udd57\ud99f\udcf8\udad6\udfd1\ud873\uddca\ud9ec\udd0f\uda0d\udd79\u8170\uda58\udc72\udaee\udcd7\ud954\uded3\ud94a\ude36\ud881\udd82\uda5f\udc08\ud8d5\udf3c\uda04\udf2e\ud30c\u7b61\udb8c\uddf4\ud9e1\ude5b\ud882\uddae\uda9d\udf9f\uda76\ude56\uda02\ude28\ud942\udec1\ud86e\ude8d\ud943\udf2b\udabb\udde3\uda33\uddac\udbe8\udd81\u75fc\ubca1\uda12\udc1a\ud96e\udf9d\ud823\udf4b\udaa5\udc62\uda4a\udc22\ud88d\udcca\uda3a\udeac\udba6\ude77\ubece\udbed\udecd\uda51\udc29\ud8cc\udf6d\udb60\udeb8\udb03\ude1f",
        2, -259, -556942341, 7142978988646851590L, -77146L, true, true, (char) 19675, (char) 17867,
        Double.longBitsToDouble(0x3fe15ae6c51e2f00L), Double.longBitsToDouble(0x3fdd7522c5703048L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ObjectReader|_bindAsTreeOrNull|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|readTree|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|readTree|[B|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|readTree|[B,int,int|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|readTree|java.io.DataInput|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|readTree|java.io.InputStream|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|readTree|java.io.Reader|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|readTree|java.lang.String|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_bind|com.fasterxml.jackson.core.JsonParser,java.lang.Object|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_bindAndClose|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_bindAndCloseAsTree|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_bindAndReadValues|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_bindAsTree|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_considerFilter|com.fasterxml.jackson.core.JsonParser,boolean|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_detectBindAndClose|[B,int,int|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_detectBindAndClose|com.fasterxml.jackson.databind.deser.DataFormatReaders$Match,boolean|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|_bindAsTreeOrNull|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|readTree|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|readTree|[B|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|readTree|[B,int,int|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|readTree|java.io.DataInput|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|readTree|java.io.InputStream|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|readTree|java.io.Reader|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
    "M|com.fasterxml.jackson.databind.ObjectReader|readTree|java.lang.String|new:com.fasterxml.jackson.databind.ObjectReader:com.fasterxml.jackson.databind.ObjectMapper,com.fasterxml.jackson.databind.DeserializationConfig",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
