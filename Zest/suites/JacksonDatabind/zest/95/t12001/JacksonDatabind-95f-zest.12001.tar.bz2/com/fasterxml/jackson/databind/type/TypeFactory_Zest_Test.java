package com.fasterxml.jackson.databind.type;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 14, 12, "\ud8ff\udfe4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud889\ude3c\ud82c\udee9\ud940\udcbe\ud9ae\udf7e\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u0a76\u4023\uab9f\ua967", "\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\ud88a\udc10\udbea\udec1\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb0d\udf77\uda22\udf97\udb82\udf52\u89c6\uda06\udd67",
        38, 62135, 1503322285, -4657610318911798648L, 69681L, false, false, (char) 45319, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fc9526d00ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 14, 12, "\ud8ff\udfe4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud958\ude68\udb8f\udea6\ud940\udc85\ud9ae\udf7e\udbc6\ude58\udb83\udc3e\uda9c\udf25\uda31\ude50\udbc2\udc2a", "\u0a76\u4023\uab9f\ua967", "\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\udb32\udda3\udbea\ude62\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb0d\udf77\uda22\udf97\udb82\udf52\u89c6\uda06\udd67",
        38, 62135, 1503322285, -4657610318911798648L, 69681L, false, false, (char) 24801, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fc9526d00ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 5, 14, "\ud8ff\udfe4\udad4\udf90\u9488", "\u7553", "\ud9ae\udf7e",
        7, 66285, 1029748495, -130996864058925242L, -94170L, true, true, (char) 55186, (char) 48927,
        Double.longBitsToDouble(0x3fd7914e2ae993e2L), Double.longBitsToDouble(0x3fc4c8bd5b2a3640L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 16, 12, "\ud834\udda4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud9d7\udc9c\ud907\ude29\ud940\udcbe\ud9ae\udf7e\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u0a76\u4023\uab9f\ub4cc", "\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\ud88a\udc10\udbea\udec1\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb0d\udf77\uda22\udf97\ud9ca\udd0d\u89c6\uda06\udd67",
        38, 62135, -950763603, -4657610318911798648L, 69681L, false, false, (char) 45319, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fc9526d00ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 6, 7, "\ud8ff\udfe4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud889\ude3c\ud82c\udee9\ud940\udcbe\ud9ae\udf7e\udbc6\ude58\udbce\udc12\ud8da\udc51\uda30\udef0\udbc2\udc2a", "\u0a76\u4023\uab9f\ua967", "\ud845\udd9e\uda46\udd3f\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\ud88a\udc10\udbea\uded1\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb0d\udf77\uda22\udf97\udb82\udf52\u89c6\uda06\udd67",
        38, 62135, 1503322285, -4657610318911798648L, 69681L, false, false, (char) 45319, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fc9526d00ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class int] |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 16, 14, 12, "\ud882\udd5f", "\ub502\u02e3\u7553\u7c04\uc0c9\u43d7", "\udbea\udeac\uda30\udef0\udbc2\udc2a\ud8e6\udd0e\uda06\udfe6\ud93f\udf95\ud8e9\udc9e\uda8c\udddc\ud9cf\ude96\ud8c8\ude32\udbf4\udcd7\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\u2358",
        44, 93624, -2048215230, 1662049701292941303L, -49973L, false, false, (char) 17858, (char) 32006,
        Double.longBitsToDouble(0x3febce11dca09ad6L), Double.longBitsToDouble(0x3fd54a87d2ced494L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 14, 12, "\ud8ff\udfe4", "\ub502\u02e3\u7553", "\000",
        -5, 79856, 1029748495, -130996863050710970L, -100000L, true, true, (char) 9746, (char) 35399,
        Double.longBitsToDouble(0x3ecc540000000000L), Double.longBitsToDouble(0x3fef8fdbe6ca8d90L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 14, 12, "\ud8ff\udfe4\udad4\udf90\u0abc\udbdd\udec7\ud8ef\udd96\ud889\ude3c\uda4d\uddf9\ud940\udd17\ud9ae\udf7e\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u0a76\u4023\uab54\u38ff", "\ud93a\uddf7\uda46\udd2e",
        36, 40731, 1482246269, -5437172515654158526L, -91817L, true, false, (char) 8343, (char) 43753,
        Double.longBitsToDouble(0x3fd37688b981708cL), Double.longBitsToDouble(0x3febce11dca08cd6L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 14, 12, "\uda0f\ude8d\udad5\udc7d\u9488\udbdd\udec7\ud8ef\udd96\ud889\ude3c\ud82c\udee9\ud93f\udf1b\ud9b0\udcfb\udae5\ude19\udb83\udc09\ud873\udf1b\ud913\udf20\udbc2\udc2a", "\ua5fe\u401c\uab9f\ua967\u8250\ud729\u7eaf\u66e9", "\ud822\udd8c\ud983\udd13\ud88a\udc10\udbea\udec1\ud92d\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\ud90d\udfab\ud86a\udc6b\ud9a3\udd46\udb0d\udf77\ud82e\ude7f\udb5a\uddff\u89c6\uda06\udd67",
        38, 62135, 1503322285, -4657610318911798648L, 241L, true, false, (char) 45319, (char) 291,
        Double.longBitsToDouble(0x3fe4340d0bbb3ffeL), Double.longBitsToDouble(0x3fc9526340afd674L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 14, 12, "\ud8ff\udfe4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud889\ude3c\ud82c\udee9\ud940\udcbe\udbc4\udca9\udbd2\udfe0\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\ucf14\u3fdb\uab9f\ua967", "\ud93a\uddf7\ud887\udc4e\uda8f\udc97\udaa7\udfa4\ud876\udfdc\uda65\udc31\ud864\udd10\udbea\udec1\ud916\udf95\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb0d\udf77\uda23\udc2b\udb82\udf52\u89c6\uda06\udd67",
        38, 62135, 1503322285, -4657610318911798648L, 69681L, false, false, (char) 45319, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fc9526d00ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 14, 12, "\000", "", "\udb12\udc00",
        5, 7858, 601018722, -9007198477171885155L, -60308L, false, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd5700000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 6, 12, "\ud8ff\udfe4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud8cf\udf2a\ud830\udfaf\ud940\udcb3\ud9ae\udf7e\udbc6\ude58\ud8f5\udc57\udbea\udeac\uda30\udef0\udbb4\udf64", "\u0a76\u4023\uab9f\ua967", "\ud93a\uddf7\uda46\udd2e\ud8d6\udeb5\u2358\ud9d1\uddbb\uda6c\udff5\ud88a\udc10\udbea\udec1\ud916\udffe\uda7f\udf28\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb0d\udf77\uda22\udf97\udb82\udfdb\u89c6\uda06\udd67",
        38, 12583, 1503280554, 7592180668758547203L, 69652L, false, false, (char) 45319, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d0f4d3912L), Double.longBitsToDouble(0x3fc9526e40ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 12, 0, "\ud8ff\udfbd\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud889\ude3c\ud82c\udee9\ud940\udcbe\udb3a\udd04\udbd1\udd4e\udb83\udc3e\udb4d\udd95", "\u769d\u6fe8\u4797\u4038\uab9f\u64e3\u0190\u704f", "\ud8c8\udf75\ud8c9\udd47\ud893\ude9f\ud99a\udc66\ud960\ude62\uda7c\udd0d\ud916\udffe",
        20, 77053, 1753987802, -5168200295104396096L, 37738L, false, false, (char) 33566, (char) 64003,
        Double.longBitsToDouble(0x3fcb27a3a9f31648L), Double.longBitsToDouble(0x3fe30e0cae2dbe69L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Long] |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 16, 3, 8, "\ud8ff\udfe4\udad4\udf90\u9488\udbdd\udec7", "\u7c04\uc0c9\u43d7\ucdb1\ua054", "\udbc2\udc2a\ud8e6\udcb8\uda06\udfe6\ud93f\udf95\ud8e9\udc9e",
        40, 38668, -72311711, -8246011816398194998L, 5122L, true, false, (char) 8178, (char) 43250,
        Double.longBitsToDouble(0x3fea15a4596685eaL), Double.longBitsToDouble(0x3fefb8b880e5bc9cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 14, 12, "\ud8ff\udfe4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\udb90\udf3e\ud82c\udee9\ud940\udcbe\ud9ae\udf7e\udbc6\ude58\udb83\udc3e\udbf5\udccb\ud8ef\udeae\udbc6\ude32", "\u0a76\u4023\uab9f\ua967", "\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\ud88a\udc10\udbea\udec1\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\uda6e\udcf1\ud851\udf13\udb5f\udfc3\udb0d\udeec\uda22\udf97\udb82\udf52\u89c6\uda06\udd67",
        23, 53409, 1503322285, 520121881254265585L, 69681L, true, true, (char) 1052, (char) 41661,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fc9526d00ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |a4=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 14, 14, 12, "\ud8ff\udfe4\ud901\udd26\u9488\udbdd\udec7\ud8ef\udd96\ud889\ude3c\ud82c\udee9\ud940\udcbe\ud9ae\udf7e\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u0a76\u4023\uab9f\ua967", "\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\ud88a\udc10\udbea\udec1\ud916\udffe\uda5b\udf4c\ud95e\udc1b\udbe8\ude14\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb0d\udf77\uda22\udf97\udb82\udf52\u89c6\uda06\udd67",
        38, 62135, 1503322285, -4657610318911798648L, 69681L, false, false, (char) 45319, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fc9526d00ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Thread$State] |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 16, 14, 12, "\ud8ff\udfe4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud889\ude3c\ud82c\udee9\ud940\udcbe\ud9b4\ude20\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u0a76\u4023\uab9f\ua967\ub31a\u704f\u7eaf\u66e9", "\udb26\udde6\uda8c\udc5a\ud88a\udc10\udbea\udec1\ud916\udffe\uda7f\udf3e\ud85d\udcfb\ud8c4\udd08\uda10\uddb5\ud869\udc64\uda35\udcaf\udb0d\udf77\uda22\udf97\udb82\udf52\u89c6\uda06\udd67\uda7c\udc87\uda34\ude8d\ud83f\uddef\udb57\udc48\ud8d0\udfe0\udabf\udf13",
        11, 79436, 175961984, -9105725772817831067L, 78124L, true, true, (char) 1943, (char) 8124,
        Double.longBitsToDouble(0x3fed96efe378497aL), Double.longBitsToDouble(0x3fb4e9501c2089d0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.Date] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 9, 15, 12, "\ud8ff\udfe4\udad4\udf90\u9488\udbcf\udc26\ud8ef\udd96\ud889\ude3c\udbdc\udc89\ud8c5\ude97\ud9ae\udf7e\udbc6\ude58\ud82c\ude15\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u0a76\u4023\uab9f\ua967", "\ud93a\uddf7\uda46\udd2e\udb43\udfbc\udbfe\udf52\udb7d\uddb1\uda6c\udff5\ud88a\udc10\udbea\udec1\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb0d\udf77\uda22\udf97\ud980\udf98\ud894\ude5d\ud978\udf70",
        38, 62135, 1503322285, -4657610318911798648L, 69681L, false, false, (char) 45319, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fc9526d00ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.Date] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 16, 14, 12, "\ufa84\u330c\000\000\ud8f2\udf98\ud889\ude3c\ud9d2\uddfb\000\ud9ae\udf1c\udbc6\ude58\ud800\udf9d\ud8f2\udf98\udaec\udf0e\ue700", "\u0a76", "\ud9cf\ude49\udb81\udd2f\uda14\udd32",
        -4, -923, 0, 8315532272561899645L, -15842L, false, true, (char) 14087, (char) 60801,
        Double.longBitsToDouble(0x3fc2bc802b680000L), Double.longBitsToDouble(0x3fd37688b981708cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ArrayType:[array type, component type: [simple type, class int]] |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 16, 14, 12, "\ud8ff\udfe4\udad4\udf90\u9484\udbd0\udfc7\ud8ef\udd96\ud889\ude3c\ud82c\udee9\ud940\udcbe\ud9ae\udf7e\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u0a76\u4023\u2846\u12a6", "\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\u2358\udb7d\uddb1\udb1c\udfed\ud88a\udc10\udbea\udec1\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03",
        19, 89600, -1932123271, -6305746874828954284L, 12172L, true, true, (char) 20494, (char) 48276,
        Double.longBitsToDouble(0x3fd92f8530cc4864L), Double.longBitsToDouble(0x3fe445fae08f8f11L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 14, 12, "\ud8ff\udfe4\udad4\udf90\u9488\udbdd\udec7\ud8dc\udd96\ud911\udf00\ud82c\udee9\ud940\udcbe\ud9ae\udf7e\udbc6\ude58\udbe4\ude6e\ud988\udd65\uda30\udfac\udbc2\udc5b", "\u3565\u59fa\uab9f\ua967\u4008\u704f", "\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\ud877\udecb\udbea\udec1\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud8db\ude75\uc92e\ud970\udcc6\ud87b\udea6\udb82\udfc3",
        0, 59713, 1721076348, 5571891719195779245L, -18216L, true, false, (char) 1388, (char) 65430,
        Double.longBitsToDouble(0x3fec05cc3ea70a7cL), Double.longBitsToDouble(0x3feb2c0d09076112L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 8, 14, 10, "\ud8ff\udfe4\udad4\udf90\udbc7\udc78\udbdd\udec7\ud8ef\udd96\ud889\ude3c\ud82c\udee9\ud940\udcbe\ud9ae\udf7e\ud8de\udea3\udb61\ude1b\uda80\udf7a\uda30\udef6\udbc2\udc2a", "\ud6fa\ubc92\uab9f\ua967", "\ud979\udd6f\uda73\udf18\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\ud88a\udc10\udbea\udec1\ud916\udffe\ud94b\udf31\udaa8\udf09\ud8c4\udd03\udbc2\udcfc\uda37\uddcc\ud9fb\udf45\udaf7\udd75\uda39\udfb6\udb05\udf73\udaef\uddee\uda1c\udd09",
        38, 62135, 1503322285, -4657610318911798648L, 69681L, true, true, (char) 35469, (char) 36045,
        Double.longBitsToDouble(0x3feb2c0881076112L), Double.longBitsToDouble(0x3fc942cd00ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 7, 0, 8, "\ud8ff\udfe4\udad4\udf90\012\udbdd\ude11\ud8ef\udd96\ud889\ude3c\ud82c\udee9\ud940\udcbe\ud9ae\udf7e\udbc6\ude58\udb83\udc3e\udab9\udf14\uda09\udfe4\udbc2\udc2a", "\u0a76\u66a1\uab9f\ua967", "\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\u2358\000\uda5a\udf8d\ud96e\udc02\udbea\udec1\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\udbd2\udda2\udb0d\udf77\uda22\udf97\udb06\udde2\udaf1\ude2d\udb8b\udc85",
        38, 62135, 1503322285, -4657610317017120768L, 69681L, false, false, (char) 45319, (char) 2851,
        Double.longBitsToDouble(0x3e20700000000000L), Double.longBitsToDouble(0x3fc9526d00ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char] |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 16, 14, 13, "\ud8ff\udfe4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud889\ude3c\ud82c\udee9\ud940\udcbe\ud9ae\udf7e\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a\ud8e6\udcb8\uda06\udfe6\ud93f\udf95\ud8e9\udc9e\uda55\udc61\ud9cf\ude49\udb81\udd2f\uda14\udd32\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\ud88a\udc10\udbea\udec1\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03", "\u9347", "\udb82\udf52\u89c6",
        13, 35348, 1297307135, 6456562431628728344L, -87855L, true, false, (char) 65430, (char) 45319,
        Double.longBitsToDouble(0x3fe53853e36581a1L), Double.longBitsToDouble(0x3fd07611299526d0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ArrayType:[array type, component type: [simple type, class java.lang.String]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 16, 14, 9, "\udba2\udff9\udad4\udf90\u9488\udaa1\udeca\ud8ef\udd96\ud889\ude3c\ud82c\udee9\ud940\udcbe\udb72\udf01\ud8b5\udd23\udb54\ude06\ud950\udedd\udad9\udd64\udbc2\udc2a", "\u6a3f\u4023\uab9f\ua967", "\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\udb04\uddd6\ud9e9\udf67\uda49\udf0e\ud9a6\udeb3\uda91\udd06\udbbe\ude64\uda7f\ude61\uda03\udfdb\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c",
        34, 64896, 1783260500, 2349376416499217970L, 61156L, true, true, (char) 54957, (char) 58198,
        Double.longBitsToDouble(0x3fe0d0a9188f8f11L), Double.longBitsToDouble(0x3fe68b74d8dcdebaL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 5, 15, "\ud816\udde0\udad4\udf95\u9488", "\u7553", "\ud9c5\udee9",
        8, 66285, 1029748495, -130996864058925242L, -94170L, true, true, (char) 55186, (char) 48927,
        Double.longBitsToDouble(0x3fd7914e2ae993e2L), Double.longBitsToDouble(0x3fc4c8bd5b2a3640L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 17, 5, 14, "\ud8ff\udfe4\udad4\udf90\u9488", "\u7553", "\uda1a\udc8b\udbc6\uddc7\ud9af\udeb4\udb0e\udf3f",
        56, 98121, -1983464019, -3587584004161665548L, 66472L, true, true, (char) 2662, (char) 33166,
        Double.longBitsToDouble(0x3fe6546c876c3266L), Double.longBitsToDouble(0x3fe76816017bd3dcL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 14, 5, 14, "\ud8ff\udfe4\udad4\udf90\u9488\uda8c\udd5c\udbf9\udd9b\ud889\ude3c\ud82c\udee9", "\u3ced\ud002", "\ud8c9\ude68\ud872\udcbe\uda06\udfe6\ud93f\udf95\udb57\udcd6\uda52\udee0\udabd\udee3\udb08\udd92\uda08\udde7\ud974\ude75\ud884\ude9a\ud8f9\udf0a",
        9, 92829, 1101518901, -5701502174164725610L, -703L, false, true, (char) 34661, (char) 32639,
        Double.longBitsToDouble(0x3fef259417a5fcfbL), Double.longBitsToDouble(0x3fe0e1d319a8669bL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Number] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 16, 5, 14, "\ud8ff\udfe4\udad4\udf90\u9488", "\u7553", "\ud9ae\udf7e",
        7, 55125, 0, -130996864058925242L, -94170L, true, true, (char) 55186, (char) 48927,
        Double.longBitsToDouble(0x3fd7914e2ae993e2L), Double.longBitsToDouble(0x3fc4c8bd5b2a3640L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ArrayType:[array type, component type: [simple type, class int]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 11, 5, 14, "\ud8ff\udfe4\udad4\udf90\ua2a9", "\u8095", "\ud99a\udc92\ub04a\uda03\udcce\ud9ea\uddd4\ud91b\udd6a",
        19, 44988, -2144367542, 2743260995045077377L, 13017L, false, true, (char) 24637, (char) 8185,
        Double.longBitsToDouble(0x3fd70d49c16ba2ecL), Double.longBitsToDouble(0x3fe77dbbf3192a00L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 6, 14, "\ud8cd\ude16", "\ub502\u7d13\u4fcd", "\ud9ae\udf7e\udbc6\ude58\udb3b\udc3a\uda46\udc7b\udb2f\udd1d\ud9d2\udfea\uda09\udd6f\uda7a\udda4",
        46, 17737, 350390856, -3895128272183614092L, 662L, true, false, (char) 25386, (char) 50701,
        Double.longBitsToDouble(0x3fe30d5a32b7bf8fL), Double.longBitsToDouble(0x3fe2cab558a72793L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Integer] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 14, "\ud8e5\ude58\uda03\udc29\u9488\udb09\ude21\udae0\udd62\ud889\uddef\ud82c\udee9\ud940\udcbe\ud9ae\udf7e\ub65e\udb3b\udc3a", "\ud207\u574a\u9cfe\u2c77\u9208", "\udb08\udd92\uda08\udde7\ud9f0\udcd2\udb57\udcd3\ud925\udc2f\uf5f6\ud8cc\ude58\udb8f\ude96\uda50\ude7e\ud99c\udc8e\ud88b\udedd\ud883\ude52\udb75\udeb1\ud8cb\udc87\ud837\udd2b\ud8af\udcf1\ud921\udebc\uda97\udccc\ud948\udfbc",
        57, 88163, 1553681862, 4273750653144079066L, -38511L, true, false, (char) 50482, (char) 14972,
        Double.longBitsToDouble(0x3fbfe4ffc30ad628L), Double.longBitsToDouble(0x3fefe263292a62e2L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.String] |a1=[Ljava.lang.Class;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 17, 5, 13, "\ud8ff\udfc2", "\u3a37\u7a71\u4504", "\ud90c\udf30\u89e7\udb3b\udc73\udb3d\udfd6\ud9e5\udc41\ud8ed\udca0\udb07\udd61\udafd\udd8c\uda17\uddd6\ud848\udfb6\ud81a\udf83\ud9cf\ude49\udb08\udd92\u14a5\ud885\udf5d\ud899\udcd6\ud881\udcaa\uc2bc\udaac\uddea",
        14, 38640, 305366515, -629169346299568997L, -56890L, false, false, (char) 3141, (char) 43709,
        Double.longBitsToDouble(0x3fe5bf7aca303f84L), Double.longBitsToDouble(0x3fc1d2a26d407d90L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 17, 3, 14, "\ud900\udc48\udad4\udf90\u9488", "\u2591\ud150\u79ac", "\ud94a\udcda\udb52\uddb5\ud988\udc9e\ud8fe\udf24\ud8e6\udcb8\uda06\udfe6\ud90d\udd5c\udaf9\udca9\uda88\udf72\ud9dd\udf86\udbdd\udf7e\uda08\udddc\udbcd\udda1\ud8bc\udcaf\ud9a8\udca6\u43b6\u8371\ud898\udeb0\ud816\udd94\ud89d\uddc9\udb76\uddd0\udb18\udde9\u69ac\udbf2\udda9\ud93e\udd82\ud852\udcbe\ud826\ude89\udab5\ude26\udb76\ude0f\ud9cf\udd5c",
        29, 88381, 1485943540, -6680504075703248411L, -66615L, true, false, (char) 64926, (char) 7710,
        Double.longBitsToDouble(0x3fbd8c603ed6c778L), Double.longBitsToDouble(0x3fc58bf7c64f932cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 16, 12, "\ud834\udda4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud9d7\udc9c\ud907\ude29\ud940\udcbe\ud9b2\ude01\udbc6\ude68\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u0a76\u4023\uab9f\ub4cc", "\ud93a\udd47\uda46\udd2e\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\ud88a\udc10\udbea\udec1\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb0d\udf77\uda22\udf97\ud9ca\udd0d\u89c6\uda06\udd67\uda7c\udc87\uda34\ude8d\uc456\udb57\udc48\ud8d0\udfe0\udabf\udf13\uecdb\udb39\udcb4\ud8bc\udc1e\uda17\udf34\ud9ee\udd1d\udad8\udea0\uea21\ue81c\ud9d4\udf3f\uda5b\udc81\uda59\ude3a\udaa3\udd85\udbd5\ude17\udac5\udd7a\udbc4\udd52\ud9f3\ude9e\ud9ad\udf8d\ud9cd\uddc9\ud8e9\udd92\ud94e\udfea\udb3b\uddfb\ud89b\udfad\udbe8\udd39\u3fa2\u12a2\ud9f7\udc74\ud851\udee2",
        47, 5791, -735089632, -6510308060562505949L, 71847L, true, true, (char) 18901, (char) 36467,
        Double.longBitsToDouble(0x3fd4f5c52244d124L), Double.longBitsToDouble(0x3fecb51823d24164L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 16, 12, "\ud834\udda4\udad4\udf90", "\u02e3", "\ud981\udc73\ud92c\udd20\ud958\udd4c",
        15, 52495, -30500084, 1093494303051147908L, 29705L, true, true, (char) 48927, (char) 24768,
        Double.longBitsToDouble(0x3fd74c9f1fe3f6f8L), Double.longBitsToDouble(0x3fe6546c814d35e9L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 16, 6, "\uda4a\udf10\udaf5\ude5a\ud927\udf49\udbdd\udec7\ud8ef\udd96\ud807\udc92\ud874\udc9e\ud809\udf8f\udb37\ude67\ud980\udcae\ud998\udc09\udbfb\udedb\uda30\udef0\ud979\udf94\ud8e6\udca8\uda06\udfe6\ud982\udda1\ud8e9\udc9e\uda55\udc61\ud9d2\uddae", "\u7eaf\u66e9\u03b6\u6cae\u4efa\u96f9\u5709\u54bc\ud017\ub7b6\u2d00\u76c2\u7094\u62e4\uc2fa\ud59c\uce48\ubf63\u9729\u5f99", "\uc456\udb57\udc48\udbe1\ude68\udabf\udf13\ufbdb\udb39\udcb4\ud830\udd39\uda86\udeca\uda56\udd8d\udad8\udea0",
        55, 35651, 548299345, 8981894157168499127L, -61284L, false, true, (char) 31946, (char) 15269,
        Double.longBitsToDouble(0x3feccd4045d2a568L), Double.longBitsToDouble(0x3fda399942f0eac8L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 16, 12, "\ud834\udda4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud9d7\udc9c\ud907\ude29\ud940\udcbe\000\ud884\udca2\udb83\udc3e\ub70f\000\ud906\udce2", "\u0a76\u4023\uab9f\ub4cc", "\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\ud88a\udc10\udbea\udec1\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\u00da\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb0d\udf77\uda22\udf97\ud9ca\udd0d\u89c6\uda06\udd67",
        38, 21015, -956301312, -4657610318911798648L, -61391L, false, false, (char) 63231, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fc9526d00ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class int]] |a1=[Ljava.lang.Class;:[[int]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 1, 16, 12, "\udb3d\ude2a\udad5\udc43\u9488\udbdd\udec7\ud8ef\udd96\ud9d7\udc9c\ud907\ude29\udbb4\udd2a\udad0\udee4\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u0a76\u4023\ud002\u4282\u1fc3\u704f\u015a\u10a0", "\udb7d\uddb1\uda6c\udff5\ud88a\udc10\uda82\udecd\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb08\udcd0\ud9c0\uddec\ud9ca\udd0d\u89c6\uda06\udd67\uda7c\udc87\uda34\ude8d\uc456\udb57\udc48\ud8d0\udfe0\udabf\udf13",
        23, 1381, 175961984, -9105725772817831067L, 2857L, true, true, (char) 51457, (char) 33670,
        Double.longBitsToDouble(0x3fc8c767e643d3bcL), Double.longBitsToDouble(0x3fe884d2c19f5efcL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 16, 12, "\ud834\udda4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud9d7\udc9c\ud907\ude29\ud940\udcbe\ud9ae\udf7e\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u0a76\u4023\uab9f\ub4cc", "\udaef\udc5f\uda46\udd2e\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\ud88a\udc10\udbea\udec1\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb0d\udf77\uda22\udf97\ud9ca\udd0d\u89c6\uda06\udd67",
        38, 97447, -950763603, -4657610318911798648L, 69681L, false, false, (char) 45319, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fc9526d00ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 16, 4, "\ud834\udda4\udad4\udf90\uda81\udea6\udbc4\udea6\ud872\udc1b", "\ua842\u2c6e\ubac1", "\uda7f\udd2e\udbc2\udc2a\ud8e6\udcb8\ud8bf\udd1c",
        -5, 37449, 400722504, -3895115697768094348L, 66198L, true, true, (char) 25435, (char) 64831,
        Double.longBitsToDouble(0x3fd7d73666f75702L), Double.longBitsToDouble(0x3fea15a4596685eaL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 16, 12, "\ud834\udda4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud9d7\udc9c\ud907\ude29\ud940\udcbe\ud9ae\udf7e\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u0a76\u4023\uabca\ub4cc", "\ud93a\uddf7\uda46\udd2e\uda44\uddd2\u2358\udb7d\uddb1\uda9c\udd18\ud88a\udc10\udbea\udec1\ud916\udffe\uda7f\udf3e\udb7d\udf4b\ud8c4\udd06\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb0d\udf77\uda22\udf97\ud9ca\udd0d\u89c6\uda06\udd67",
        18, 62135, -950763603, 8975348703092114056L, 69681L, false, false, (char) 45319, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fc9526d00ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.List, contains [simple type, class java.lang.Integer]] |a1=[Ljava.lang.Class;:[[class java.lang.Integer]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 1, 6, 7, "\ud834\udda4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud9d7\udc9c\ud907\ude29\ud940\udcbe\ud8a9\ude1c\ud948\udde3\udb83\udc3e\ud9c7\uddfa\uda30\udefa\udbc2\udc2a", "\u2a76\u4023\uab9f\ub4cc", "\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\uda6f\udd62\ud8a8\udfe0\ud995\udfa4\uda7f\udf29\ud9ee\udfa4\ud8c4\udd03\udbb1\udeda\ud86a\udd1c\ud8cd\udf5a\udb0d\udf77\uda22\udf97\ud9d1\udc18\u89c6\uda06\udd67",
        46, 65889, -926277715, -4657610318911798648L, 82737L, false, false, (char) 45319, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fc958d500ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.List, contains [collection type; class java.util.ArrayList, contains [simple type, class java.lang.Object]]] |a1=[Ljava.lang.Class;:[[class java.util.ArrayList]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 1, 16, 12, "\ud834\udda4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud9d7\udc9c\ud907\ude29\ud940\udcbe\ud991\ude30\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u0a76\u4023\uab9f\ub4cc", "\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\ud88a\udc10\udbea\udec1\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb0d\udf77\uda22\udf97\ud9ca\udd0d\u89c6\uda06\udd67",
        32, 49685, -950738255, -4657610318911798648L, 69681L, false, false, (char) 32549, (char) 49493,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fc9526d00ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class java.lang.Integer]] |a1=[Ljava.lang.Class;:[[class java.lang.Integer]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 1, 16, 12, "\ud834\udda4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud9d7\udc9c\ud907\ude29\ud940\udcbe\ud9ae\udf7e\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u0a76\u4023\uab9f\ub4cc", "\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\ud88a\udc10\udbea\udec1\udbb9\udf4e\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb0d\udf77\uda22\udf97\ud964\uddba\ud9f8\udc32\uda06\udd67",
        51, 3713, -950763603, -4657610318911798648L, 69681L, false, false, (char) 45319, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fe6549b469cbffaL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 6, 7, "\ud8ff\udfe4\udad4\udf90\u9488\udbdd\udec7\ud8ef\udd96\ud889\ude3c\ud82c\udee9\ud940\udcbe\udb36\udee3\udbc6\ude86\ud80b\udf32\udbb6\ude38\uda30\udef0\udbc2\udc2a", "\u0a76\ud3fc\u41a2\u54df", "\ud825\udd35",
        52, 51366, 1936110731, 6366199248707078248L, 84091L, true, false, (char) 43753, (char) 17858,
        Double.longBitsToDouble(0x3fc81708cde708ecL), Double.longBitsToDouble(0x3fc4118eb552a1f4L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [array type, component type: [simple type, class int]]] |a1=[Ljava.lang.Class;:[[class [I]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 1, 14, 10, "\ud882\udd5f", "\ub502\u4c31\ua73a\u426a\ud75f\u6839", "\udbea\udeac\uda30\udef0\udbc2\udc2a\ud823\udcae\uda06\udf7e\ud93f\udf95\ud8e9\udc9e\udbde\udc14\ud90e\udf05\u5cb3\udbf4\udcd7\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\udac2\udd8a\udb7d\uddb1\uda6c\udff5\ud88a\udc10\udbea\udec1\ud916\udffe\uda7f\udf3e\uda17\udea4\ud8c4\udd03\udbc2\udcfc\ud80f\ude24\ud8e9\udf3a",
        9, 3425, -143677081, -1011337580308921368L, 30995L, false, false, (char) 37280, (char) 30591,
        Double.longBitsToDouble(0x3fd5b91ce844396cL), Double.longBitsToDouble(0x3fe974255e416491L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class int] |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=null |a4=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 16, 14, 12, "\ud882\udd5f", "\ub502\u02e3\u7553\u7c04\uc0c9\ub2ed", "\udbea\udeac\uda30\udef0\udbc2\udc2a\ud849\udeec\udb8f\udcc9\ud8c1\udfcc\ud98e\udd51\uda8c\udddc\uda2b\uddc9\ud8c8\udea4\udbf4\udcd7\ud93a\uddf7\uda46\udd2e\ud9d3\udfd6\u2358",
        44, 93624, -2048215230, 1662049701292941303L, -49973L, false, false, (char) 17858, (char) 32006,
        Double.longBitsToDouble(0x3febce11dca09ad6L), Double.longBitsToDouble(0x3fd54a87d2ced494L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.String] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=null |a4=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 11, 14, 14, "\ud882\udd5f", "\u7c11\u4788\u754d\u7c04\uc032\u43d7", "\udbf5\uddc7\uda30\udef0\udbc2\udc2a\udb27\udfb5\ud8e3\udd14\ud988\udd79\ud8e9\udc9e\ud841\ude17\uda01\udeab\ud841\udc50\udbb9\udcc7\udb09\udf8e\uda60\udce2\ud8c8\udf75\udb21\udc44",
        14, 90779, -193441604, -8672094177881989750L, -49973L, false, false, (char) 17858, (char) 32006,
        Double.longBitsToDouble(0x3febce11dca09ad6L), Double.longBitsToDouble(0x3fd54a8cc3648894L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class int] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class int] |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 11, 16, 12, "\ud882\udd5f", "\ub502\u020a\u7553\u7c04\uc0c9\u43d7", "\udbea\udeac\uda30\udf0f\udbc2\udc2a\ud8e6\udd0e\udac3\udc04\ud903\uddd5\ud8e9\udc9e\udaac\udd2c\ud9cf\ude5d\ud8c8\ude32\udbf4\udcd7\udaf3\ude53\uda1d\udfcd\ud8c8\udf75\u2358",
        44, 76584, -2048215230, 1662049701175500791L, -49971L, false, false, (char) 22351, (char) 62220,
        Double.longBitsToDouble(0x3febcd28dca09ad6L), Double.longBitsToDouble(0x3fe9b01a04f6a2efL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 1, 13, "\udbed\ude3b", "\ub4d3", "\ud8d4\udf08\udba3\udcf7\000\000\ud894\ude29\udaaf\udede\uda1b\uddd8",
        -1, 69879, -1071390805, 5769679974298080958L, 92769L, true, true, (char) 53077, (char) 6456,
        Double.longBitsToDouble(0x3fc25381a3278830L), Double.longBitsToDouble(0x3fe5a543fee2ef41L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=null |a4=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 8, 14, 12, "\ud8ff\udfe4", "\ub502\u02e3\u7553", "\000",
        -5, 79856, 1029748495, -130996863050710970L, -100000L, true, true, (char) 9746, (char) 35399,
        Double.longBitsToDouble(0x3ecc540000000000L), Double.longBitsToDouble(0x3fef8fdbe6ca8d90L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 17, 0, 15, "\ud8ff\udfe4", "\ub502\uba94\uce1d", "\ud9ae\udf7e",
        48, 28971, -1065508116, -5882874864205349266L, -94170L, true, true, (char) 4376, (char) 45916,
        Double.longBitsToDouble(0x3feca9b715f1a972L), Double.longBitsToDouble(0x3fe883961eca8d90L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=null |a4=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=null |a4=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 14, 14, 12, "\ud8cf\udf4b\udad4\udf90\u0abc\udbdd\udec7\ud8ef\udd96\ud889\ude3c\udaaf\udc29\ud92b\udff4", "\ua054\uafcd\ua84c\u0aa2\u574a\u9cfe\u0a76\u4023\uab54\u38ff\u6e52\u79e2\u7ec4\u66e9\u4ef8\u2d51\u814f\u96f9\u5690\u54bc\ud218\ub7b6\u0381\u16ee\u3835\u338b\uc2fa\u89ea\u6ca2\u6628", "\ud974\ude67\ud895\udd54",
        18, 15558, 777369385, 2338212362776532158L, -51401L, true, false, (char) 47033, (char) 57104,
        Double.longBitsToDouble(0x3fe0bf6438d9f0a3L), Double.longBitsToDouble(0x3fe2cbf5e17923f5L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 17, 7, "\uda45\udff8\udad4\udf90\u0abc", "\u7553", "\ud8cd\uddab",
        46, 43269, 1029748495, -130996863050653882L, -94170L, false, true, (char) 55186, (char) 9929,
        Double.longBitsToDouble(0x3fa1cd42841f8500L), Double.longBitsToDouble(0x3feca808b6ca8d90L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Thread$State] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 8, 2, "\ub6e3\u00b6\udab2\udc78\udbb4\udcf2\ud9f5\udf98\ud9cb\udc6f\udb3a\udec7\udb63\udf8c\ud9d5\ude12\ud884\udd33\ud917\ude69\uda11\udcff\udb7c\udf2d\ue746\udb7b\udc8d\ud88a\udc6e", "\u1827\ub912\u57e4\u70ee\u9906\u1875\u8f6d\u7343\u0da5\u172a\u4002\u8ddc", "\uda6d\udecb\uda4c\udcbf",
        39, 28118, 1769201826, 7058182561580611662L, -68587L, true, true, (char) 18681, (char) 12697,
        Double.longBitsToDouble(0x3fef968ce4ad89e6L), Double.longBitsToDouble(0x3fc8de3817c5ec40L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 7, 7, 13, "\udb9b\udef2\ud999\udf19\udb7f\udfd4\udb19\udc03", "\u578b\u9f0a\u1453\u21f9", "\uda30\udef0\ud8b6\ude95\ud9bf\udcc5\ud86d\udd56\udb19\uddc3\ud8f7\udd24\ud94d\ude0a\ud9b8\udf5a\uda43\ude40\udb6c\ude4a\ud88a\ude6a",
        23, 39239, -496585589, 6506306039057015354L, -7002L, true, false, (char) 4141, (char) 28907,
        Double.longBitsToDouble(0x3fcd747c98e760acL), Double.longBitsToDouble(0x3fed20a50da650d5L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Number] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Number] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 11, 11, 16, "\ud900\udc14\ud901\udd26\u9488", "\u7553", "\ud9ae\udf7e",
        7, 43269, 1029748495, -130996863151317178L, -54559L, false, false, (char) 21851, (char) 61285,
        Double.longBitsToDouble(0x3fef8fdbe6ca8d90L), Double.longBitsToDouble(0x3fd4d35e94006b54L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=null |a4=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=null |a4=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 14, 14, 12, "\ud8ff\udfe4\ud901\udd26\u9488\udbdd\udec7\ud8ef\udd96\ud889\ude3c\ud83a\udee9\ud940\udcbe\ud9ae\udf7e\udbc6\ude58\udb83\udc3e\udbea\udeac\udb3e\udef7\udbc2\udc2a", "\u0a76\u4023\uab9f\ua967", "\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\ud88a\udc10\udbea\udec1\ud916\udffe\uda5b\udf4c\ud95e\udc1b\udbe8\ude14\udbc2\udcfc\ue7e7\ud824\udf99\udb0d\udf06\uda22\udf97\udb82\udf52\u89c6\uda06\udd67",
        38, 62135, 1503322285, -4657610318899959436L, 69681L, false, false, (char) 45319, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fc9526d00ad6a74L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.String] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.String] |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 11, 0, 12, "\ud8ff\udfe4\udb73\udfbf\ue4fa\ud959\udfac\ucd59\udbb6\udd15\ud884\udd74\ud80b\uddd7\uda93\udc4e\ud8b6\udce5\ufe9b\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u1eac\u56a1\ucbf6\u4394\u1078\u8a94", "\udb5b\udf9d\udbfc\udfd3\udb7d\uddb1\uda6c\udff5\ud9a5\udd06\udb96\udd57\ud916\udffe",
        42, 91092, -1655967858, -5125084089082460992L, 64704L, false, true, (char) 1987, (char) 32712,
        Double.longBitsToDouble(0x3fe74fcecd948330L), Double.longBitsToDouble(0x3fe5e18b88312381L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 14, 14, 7, "\ufa84\ud95e\ude94\uda26\udea6\000\ud8f2\udf98\ud889\ude3c\ud9d2\uddfb\000\udb9b\udf32\ud8fe\udc32\ud99a\udd43\ud88e\udf74\udaec\udfd8\ue700", "\u30d4", "\ud9cf\ude49\u73cc",
        32, 59906, 867932800, 1936110731L, 83400L, false, true, (char) 25670, (char) 47659,
        Double.longBitsToDouble(0x3fccb79392579004L), Double.longBitsToDouble(0x3fe6d0000537688bL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Integer] |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Integer] |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 16, 16, 12, "\ud94a\udcbd\udaf3\udf21\u9484\ud914\udfc9\ud8ef\udd96\ud889\ude3c\ud82c\udea9\ud940\udcbe\udb1d\udd15", "\uca50\ua463\u6dac\u1d16\u9cfe\u19de\u4023\u2846\u12a6\u22f5\u2c6b\u7eaf\u66e9\u4ef8\u2d51\u2133\u0e5c\uaaf9\u7545\ucd67\ub7b6\u61b0\u76c2\u3835\u338b\uc2fa\u54e8\ucb4d\u700b\u36e6\ub016\u4c11\u64e6\u3079\u2bca\u14af\u3aae", "\ud8ac\udfe8\ud83a\udcbe\ud84e\udfb5\udbbf\ude6e\udbac\udd93\udbb2\udf76\udb28\udeb6",
        57, 76112, -479524594, -6297819665642087318L, -59481L, false, false, (char) 7080, (char) 2148,
        Double.longBitsToDouble(0x3fed5b23a7ba2e14L), Double.longBitsToDouble(0x3fe4806241b483efL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Comparable<char>] |a1=[Ljava.lang.Class;:[[char]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 1, 5, 15, "\ud816\udde0\udad4\udf95\u9488", "\u7553", "\ud9c5\udee9",
        8, 66285, 1029748495, -130996864058925242L, -94170L, true, true, (char) 55186, (char) 7387,
        Double.longBitsToDouble(0x3fd7914efae993e2L), Double.longBitsToDouble(0x3fc4c8bd5b2a3640L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 17, 12, 9, "\ud8ff\udfe4\udb9f\uddb0\udbd6\udcbf\ud968\ude21\ud8bf\uddb0", "\u7429\u4f74\ubaaa\u3182\u4079\uc801\u3ab2\u15eb\ua458\u0b13\ubd8a\ud7ec", "\uda08\udd53\ud950\uddc2\ud9f5\udf95\ud845\udc53\ud89a\udf63\udbaa\udc0a\ud9a5\udc76",
        -2, 56723, -1958318638, -4034030839312545713L, 72567L, false, false, (char) 40630, (char) 35753,
        Double.longBitsToDouble(0x3fe5bcb221354b7cL), Double.longBitsToDouble(0x3fec9a36bf7f0473L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [collection type; class java.util.List, contains [simple type, class java.lang.Object]]] |a1=[Ljava.lang.Class;:[[interface java.util.List]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 17, 5, 14, "\ud8ff\udfe4\udad4\udf90\u9488", "\u7553\u7663\u7429\u4f74\ucd20\u41ca\u28a9\u58e4", "\udb77\udc6b\ud940\udc32\ud969\udcb9",
        51, 73777, 1769750644, -8246064451281324342L, -228L, true, false, (char) 47203, (char) 50727,
        Double.longBitsToDouble(0x3fdf0caf431000e8L), Double.longBitsToDouble(0x3fdbde3744d9ee8cL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Comparable<java.util.ArrayList<java.lang.Object>>] |a1=[Ljava.lang.Class;:[[class java.util.ArrayList]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 17, 5, 14, "\ud8ff\udfe4\udad4\udf90\u9488", "\u7553", "\uda1a\udc8b\udbc6\uddc7\udb82\uddea\ub4f9",
        50, 98121, -1983464019, -3587584004161665548L, 66472L, true, true, (char) 2662, (char) 33166,
        Double.longBitsToDouble(0x3fe6546c876c3266L), Double.longBitsToDouble(0x3fe76816017bd3dcL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [collection type; class java.util.ArrayList, contains [simple type, class java.lang.Object]]] |a1=[Ljava.lang.Class;:[[class java.util.ArrayList]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 17, 5, 18, "\ud8ff\udfe4\udad4\udf90\u9488", "\u0d32", "\uda1a\udc8b\udbc6\uddc7\ud9af\udeb4\ud973\udd4e",
        -5, 1849, -2018479699, -3587584004161665548L, 66472L, true, false, (char) 2662, (char) 33166,
        Double.longBitsToDouble(0x3fe6546c876c3266L), Double.longBitsToDouble(0x3fe76816017bd3dcL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class java.lang.Object]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 16, 14, "\ud956\udfb1\uda05\ude06\u9488\udb09\ude21\udae0\udd62\ud889\uddef\ud82c\udee9\ud940\udcbe\ud9ae\udf7e\ub65e\udb3b\udc3a", "\ud207\u574a\u9cfe\u6cdb\u9208", "\ud8f7\udc9f\uda08\udde7\ud9f0\udcd2\udb57\udcd3\ud925\udc2f\uf5f6\ud8cc\ude58\udb8f\ude96\ud87f\ude96",
        37, 75976, 93611518, 123844146057396459L, 88439L, false, true, (char) 17847, (char) 16467,
        Double.longBitsToDouble(0x3fe3f12dee7147ccL), Double.longBitsToDouble(0x3fdc6c60b326b936L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class int] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 16, 7, "\ud8e5\ude58\uda03\udc29\u9488\ud88d\udce2", "\u7c04\uc0c9", "\udaee\udc84\ud92b\udf0d\uda12\udf09\ud87f\udd07\udb20\udde4\uda06\udff5\ud97e\udd95\udba7\udebe\ud9ca\udf6c\ud96a\udd65\ud913\ude91",
        44, 12165, 143281234, 7538522220937616507L, -36386L, false, true, (char) 12759, (char) 3116,
        Double.longBitsToDouble(0x3fbb6dedc5b19f88L), Double.longBitsToDouble(0x3f974ba3324a4ac0L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Integer] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Integer] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 9, 9, 14, "\ud8e5\ude58\uda03\udc29\u9488\uda29\ude1f\udae0\udd62\ud889\uddef\ud82c\udee9\ud940\udcbe\ud9ae\udf7e\ub65e\ud9ae\udcf3", "\ud24f\u574a\u9cfe\u2c77\u9208", "\udb08\udd92\uda08\udde7\ud9f0\udcd2\udb57\udcd3\ud925\udc2f\uf5f6\ud8cc\ude58\udb8f\ude96\uda50\ude7e\ud99c\udc8e\ud88b\udedd\ud883\ude52\udb75\udeb1\ud8cb\udc87\ud837\udd2b\ud8af\udcf1\ud921\udebc\uda97\udccc\ud948\udfbc",
        57, 88163, 1553681862, 4273750653144079066L, 96481L, true, false, (char) 32865, (char) 19468,
        Double.longBitsToDouble(0x3fe5cb73c2fed7eaL), Double.longBitsToDouble(0x3fcfbcf8989bce14L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Long] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 17, 14, "\ud9e6\udcb7\uda02\udfda\u9488\ud887\ude40\udae0\udcd5\ud889\uddef", "\u9130", "\udbea\udeac\uda30\udef0\ud8ed\udca0",
        26, 13550, 639696727, -3372438003280945095L, 21484L, false, false, (char) 1115, (char) 57651,
        Double.longBitsToDouble(0x3fd85f03f8f6750aL), Double.longBitsToDouble(0x3fe1fb73056cbdccL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Integer] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 1, 0, "\ud8e5\ude58\uda03\udc29\u9488\udb09\ude21\udae0\udd62\ud889\uddef\ud82c\udee9\ud940\udcbe\ud9ae\udf7e\ub65e\udb3b\udc3a", "\ud207\u574a\u9cfe\u2c77\u9208", "\udb08\udd92\uda08\udde7\ud9f0\udcd2\udb57\udcd3\ud925\udc2f\uf5f6\ud8cc\ude58\udb8f\ude96\uda50\ude7e\ud99c\udc8e\ud88b\udedd\ud883\ude52\udb75\udeb1\ud8cb\udc87\ud837\udd2b\ud8af\udcf1\ud921\udebc\uda97\udccc\ud948\udfbc",
        57, 88163, 1543720390, 4273750653144079066L, -38511L, true, false, (char) 50482, (char) 14972,
        Double.longBitsToDouble(0x3fbfe4ffc30ad628L), Double.longBitsToDouble(0x3fefe263292a62e2L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 16, 12, "\ud914\udc55\udbb6\udf8b\ud8ac\uddeb\uda6e\udd00\ud885\uded4\ud9c4\udd8f\ud907\ude29\ud940\udcbe\000\ud884\udca2\udb83\udc3e\ub70f\000\udab1\udd2f", "\u0a76\u41bf\u964b\ub4cc", "\udbb6\udfbc\ud9e4\ude16\udb3a\udf6e\u7dda\udb7d\uddb1\uda6c\udff5\ud88a\udc10\ud80b\udcdb\ud916\udffe\udabb\ude8f\ud9f0\ude7e\u00da\udbc2\udcfc\udba8\udcda\uda35\udc9a\ud82a\udfc5\ud8b0\ude31\ud954\udf0f\u8a85\uda06\udd67",
        38, 21015, Integer.MIN_VALUE, -5521133083110160838L, -61391L, false, false, (char) 63231, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d091f6112L), Double.longBitsToDouble(0x3fc9526d1fd16a74L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 16, 4, "\ud8d5\udd72\udb96\udce4\udacb\ude5f\udb2b\udece\ud8da\udd9a\ud9d7\udc9c\ud907\ude29\uda16\udcd5\udaa9\udfba\udb4b\udf57\ud8c6\udf9c\udaac\udf41\uda30\udef0\udb67\ude63", "\u0a76\u4023\ud002\u4282\u3a6d\ubc28\u8119\u6354", "\udb7d\uddb1",
        9, 63770, 430164326, -4880740950222163739L, -82298L, true, true, (char) 32006, (char) 58804,
        Double.longBitsToDouble(0x3fda08cd6650f406L), Double.longBitsToDouble(0x3fe93b96ae2c203eL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class int]] |a1=[Ljava.lang.Class;:[[int]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 16, 12, "\udb3d\ude2a\udad5\udc43\u9488\ud89a\udc92\udbb8\udfeb\ud9d7\udc9c\ud907\ude29\udbb4\udd2a\udad0\udee4\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u0a76\u4023\ud002\u4282\u1fc3\u704f\u015a\u10a0", "\udb7d\uddb1\uda6c\udff5\ud88a\udc10\uda82\udecd\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb08\udcd0\ud9c0\uddec\ud9ca\udd0d\u89c6\uda06\udd67\uda7c\udc87\uda34\ude8d\uc456\udb57\udc48\ud8d0\udfe0\udabf\udf13",
        23, 1381, 175961984, -9105725772817831067L, 57903L, true, true, (char) 51457, (char) 33670,
        Double.longBitsToDouble(0x3fc8c767e643d3bcL), Double.longBitsToDouble(0x3fe884d2c19f5efcL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class int]] |a1=[Ljava.lang.Class;:[[int]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class int]] |a1=[Ljava.lang.Class;:[[int]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud9c9\udc55\udbc8\udcfe\u9488\ud831\uded1\ud8ef\udd96\ud841\udcaa\ud907\ude29\udbb4\udd2a\udad0\udee4\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\ua3f0\ua95f\ud002\u7e1b\u70dc\u704f\u015a\u84e6", "\udb7d\uddb1\uda6c\udff5\ud88a\udc10\ud982\udf7a\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb08\udcd0\ud9c0\uddec\ud9ca\udd0d\u89c6\uda06\udd67\uda7c\udc87\uda34\ude8d\uc456\udb57\udc48\ud8d0\udfe0\udabf\udf13",
        23, 1381, 175961984, -9105725772817831067L, 2857L, true, true, (char) 51457, (char) 33670,
        Double.longBitsToDouble(0x3fc8c767e643d3bcL), Double.longBitsToDouble(0x3fe884d2c19f5efcL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ArrayType:[array type, component type: [simple type, class java.lang.String]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.ArrayType:[array type, component type: [simple type, class java.lang.String]] |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 11, 16, 4, "\ud925\udde4", "\u1d5a\ud595\ub531\ua15c\u2e8b\u5854\u55d1", "\udaa8\udea1\udbc2\udc4e\ud8e6\udcb8\ud8a8\uddb1\uda70\udcc4\udb2f\udc96",
        6, 73676, 1181020553, 1035557308370037207L, 96514L, true, false, (char) 4323, (char) 59132,
        Double.longBitsToDouble(0x3febc5a4596685eaL), Double.longBitsToDouble(0x3fc06baeed62135cL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class java.lang.Integer]] |a1=[Ljava.lang.Class;:[[class java.lang.Integer]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 16, 12, "\ud834\udda4\udad4\udf90\u9488\udaf0\udfd2\uda27\udd5f\ud805\ude40\udab8\ude62\ud940\udcbe\ud9ae\udf7e\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u0a76\u4023\uab9f\ub4cc", "\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\ud88a\udc10\udbea\udec1\udbb9\udf4e\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb0d\udf77\uda22\udf97\ud964\uddba\ud9f8\udc32\uda06\udd67",
        51, 3713, -950763603, -4657610318911798648L, 69681L, false, false, (char) 45319, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fe6549b469cbffaL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 1, 13, "\udbed\ude3b", "\ub4d3", "\ud8d4\udf08\udba3\udcf7\000\000\ud894\ude29\udaaf\udede\uda1b\uddd8",
        -1, 69879, -702292053, 7435650449863352307L, 89362L, false, true, (char) 38486, (char) 6468,
        Double.longBitsToDouble(0x3fc25381a3278830L), Double.longBitsToDouble(0x3fe5a543fee2ef41L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ArrayType:[array type, component type: [simple type, class java.lang.String]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.ArrayType:[array type, component type: [simple type, class java.lang.String]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "R", "",
        6, 25980, 0, 0L, 96608L, true, false, (char) 51434, (char) 35,
        Double.longBitsToDouble(0x3fe00000024817b8L), Double.longBitsToDouble(0x3fd0000e2e000000L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 17, 13, "\ud848\udc25\ud8f3\ude22\uf90a", "\u7553", "\ud8cd\uddab",
        46, 38197, 1029748528, -130996863050653882L, -94170L, false, true, (char) 42239, (char) 9929,
        Double.longBitsToDouble(0x3fa1cd42841f8500L), Double.longBitsToDouble(0x3feca808b6ca8d90L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 11, 12, "\udb9b\udcc8\ud9ee\udd58\udbda\udd89\000\ud8f2\udf98\ud889\ude3c\ud82c\udee9\udbec\udf2b\udb89\udde1\ud8fe\udc32\ud99a\udd43\ud88e\udf74\udaec\udfd8\ue700", "\u30d4", "\ud9cf\ude49\u73cc",
        32, 59906, 867932800, 1936110731L, 83400L, false, true, (char) 25670, (char) 47659,
        Double.longBitsToDouble(0x3fccb79392579004L), Double.longBitsToDouble(0x3fc3046015bf18c8L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 16, 17, "\u5af1\udb4d\udd2b\udb29\udff1", "\u8f1b", "\uda1a\udc8b\uda43\uded2\udb82\uddea\ub4f9",
        50, 98121, -1983464019, -3587584006627916300L, 66529L, true, true, (char) 2662, (char) 33166,
        Double.longBitsToDouble(0x3fee546c87177605L), Double.longBitsToDouble(0x3fe76816017bd3dcL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class java.lang.Object]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 16, 14, "\ud956\udfb1\uda05\ude06\u9488\udb09\ude21\udae0\udd62\ud889\uddef\ud82c\udee9\ud940\udcbe\uda97\udd12\ud999\udff5\udb3b\udc4d", "\ud207\u574a\u9cfe\u6cdb", "\udbb2\udfc9\ud8f7\udc9f\uda08\udde7\ud9f0\udcd2",
        51, 19981, -1855972229, -4770325486074469012L, 88439L, false, true, (char) 17847, (char) 16467,
        Double.longBitsToDouble(0x3fe3f12dee7147ccL), Double.longBitsToDouble(0x3fdc6c60b326b936L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class int] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 1, 0, "\ud8e5\ude58\uda03\udc29\u9488\udb09\ude21\udae0\udd62\ud889\uddef\ud82c\udee9\ud940\udcbe\uda26\udffb\ub65e\udb3b\udc3a", "\ud207\u574a\u9cfe\u2c77\u9208", "\udb08\udd92\uda08\udde7\ud9f0\udcd2\udb57\udcd3\ud925\udc2f\uf5f6\ud8cc\ude58\udb8f\ude96\uda50\ude7e\ud99c\udc8e\ud88b\udedd\ud883\ude52\udb75\udeb1\ud8cb\udc87\ud837\udd2b\ud8af\udcf1\ud921\udebc\uda97\udccc\ud948\udfbc",
        58, 62263, 1543720390, 4273750653144079066L, -38511L, true, false, (char) 50482, (char) 14972,
        Double.longBitsToDouble(0x3fbfe4ffc30ad628L), Double.longBitsToDouble(0x3fefe263292a62e2L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Number] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 1, 0, "\ud8e5\ude58\uda03\udc29\u9488\udb09\ude21\udae0\udd62\ud883\uddef\ud82c\udee9\ud940\udcbe\ud9ae\udf7e\ub65e\udb3b\udc3a", "\ud207\u574a\u9cfe\u2c77\u9208", "\udb08\udd92\uda08\udde7\ud9f0\udcd2\udb57\udcd3\ud925\udc2f\uf5f6\ud8cc\ude58\udb8f\ude96\uda50\ude7e\ud99c\udc8e\ud88b\udedd\ud883\ude52\udb75\udeb1\ud8cb\udc87\ud837\udd2b\ud8af\udcf1\ud921\udebc\ud99a\udde0\ud94c\udf45",
        21, 86451, 1543720390, 4273750653144079066L, -38511L, true, false, (char) 50482, (char) 14972,
        Double.longBitsToDouble(0x3fbfe4ffc30ad628L), Double.longBitsToDouble(0x3fefe263292a62e2L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class java.lang.Object]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class java.lang.Integer]] |a1=[Ljava.lang.Class;:[[class java.lang.Integer]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 9, 1, 0, "\ud8e5\ude58\uda03\udc29\u9488\udb09\ude21\udae0\udd62\ud889\uddef\ud82c\udee9\ud940\udcbe\uda33\udd6b\udbcf\udf2b\udb3b\udc3a", "\ud207\u574a\u9cfe\u2c77", "\ud96a\udd65\ud996\uddda\ud90f\udc6f\ud9f0\udcd2",
        51, 19981, -1855972229, -4770325483973450388L, 33110L, false, true, (char) 14968, (char) 55966,
        Double.longBitsToDouble(0x3fcd75d1e2d8f50cL), Double.longBitsToDouble(0x3f974ba3324a4ac0L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Comparable<int>] |a1=[Ljava.lang.Class;:[[int]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Comparable<int>] |a1=[Ljava.lang.Class;:[[int]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud9c9\udc55\udbc8\udcfe\u9488\ud831\uded1\ud8ef\udd96\ud841\udcaa\ud907\ude29\udbb4\udd2a\uda9c\uddad\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\ua3f0\ua95f\ud002\u7e1b\u70dc\u704f\u015a\u84e6", "\udb7d\uddb1\uda6c\udff5\ud88a\udc10\ud982\udf7a\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb08\udcd0\ud9c0\uddec\ud9ca\udd0d\u89c6\uda06\udd67\uda7c\udc87\uda34\ude8d\u00ad\udb57\udc30\ud8d0\udfe0\udabf\udf13",
        36, 1381, 175961984, 718886928384L, 2857L, true, true, (char) 51457, (char) 33670,
        Double.longBitsToDouble(0x3fc8c767e643d3bcL), Double.longBitsToDouble(0x3fe884d2c19f5efcL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [array type, component type: [simple type, class java.lang.String]]] |a1=[Ljava.lang.Class;:[[class [Ljava.lang.String;]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 16, 12, "\ud834\udda4\udad4\udf90\u9488\udaf0\udfd2\uda27\udd5f\ud805\ude40\udab8\ude62\ud940\udcbe\ud9ae\udf7e\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u4d6c\000\uab9f\ub4cc", "\ud93a\uddf7\uda46\udd2e\ud8c8\udf75\u2358\udb7d\uddb1\uda6c\udff5\ud88a\udc10\000\udadf\udf4e\uda7f\udf3e\ud9ee\udfa4\u00da\000\ud86a\udd1c\uda35\udcaf\udb0d\udf77\uda22\udf97\ud964\uddba\ud9f8\udc32\uda06\udd67",
        51, -919, -950796288, -4657610318911798648L, 69681L, false, false, (char) 45319, (char) 291,
        Double.longBitsToDouble(0x3feb2c0d09076112L), Double.longBitsToDouble(0x3fe6549b469cbffaL)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 1, 13, "\ud81c\udd03", "\ub4d3", "\ud912\udd07\udba3\udc2c\000\000\ud894\ude29\udaaf\udede\uda1b\uddd8",
        -1, 69879, -702292053, 7435650449863352307L, 89362L, false, true, (char) 38486, (char) 6468,
        Double.longBitsToDouble(0x3fc25381a3278830L), Double.longBitsToDouble(0x3fe5a543fee2ef41L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 1, 11, "\ud8dd\uddd3", "\u77d3", "\ud8d4\udf08\u5251\ud18c\000\ud894\ude29\udaaf\udede\uda1b\uddd8",
        -1, 65015, -702292053, 7435650449863352307L, 89362L, false, true, (char) 38486, (char) 6468,
        Double.longBitsToDouble(0x3fd929c0d193c5b8L), Double.longBitsToDouble(0x3fe5a543fde2ef41L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [collection type; class java.util.List, contains [simple type, class java.lang.Object]]] |a1=[Ljava.lang.Class;:[[interface java.util.List]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 16, 12, "\ud834\udda4\udad4\udf90\u9488\udaf0\udfd2\uda27\udd5f\ud805\ude40\udab8\ude62\ud940\udcbe\uda7e\udce6\ud9bc\udc8e\udbe0\udec4\ud988\udf7c\ud987\udc26\ud9ea\udd7f", "\u4d6c\000\uab9f\ub4cc\u101a\u65b6\u19d8\ubeca\u4f73\u2d51\u2133\u96f9\u5690\000\u2af7\u1fdf\u61b0\u00da\000", "\udb0d\udf77\ud907\ude83\ud964\uddce\ud9f8\udc32\uda06\udd67\udb04\udd4bQ\udab3\uddd6",
        9, 13161, 1855705310, -2397438028411363108L, 28679L, true, true, (char) 64024, (char) 10802,
        Double.longBitsToDouble(0x3fe4e5ffd4647b0eL), Double.longBitsToDouble(0x3fec65729768beeaL)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Thread$State] |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 16, 17, 12, "\ue2bd\udba0\udf93\u9488\ud858\udcf3\udb62\ude53\ud889\ude3c\ud82c\udee9\ud940\udcbe\ud9ae\udf7e\ud8f3\udce3\udb0e\udc27\udbea\udea0\udae9\udd6b\udbc0\udd93", "\u7280\u4023\uab9f\ua967\u101a\u704f\u8746\u7722", "\udb7d\uddb1\uda6c\udfc2\ud88a\udc10\udbea\udec1\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbf6\udd54\ud87e\udf51\uda35\udcaf\udb0d\udf77\uda22\udf97\udb82\udf52\u89c6\uda06\udd67\uda7c\udc87\uda34\ude8d\udb49\uddf4\udb57\udc48\ud8d0\udfe0\udabf\udf13",
        11, 79436, 176289664, -9105725772817831067L, 87190L, true, false, (char) 8192, (char) 2591,
        Double.longBitsToDouble(0x3fe93af19bcb0c8eL), Double.longBitsToDouble(0x3fd373436166a250L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [collection type; class java.util.ArrayList, contains [simple type, class java.lang.Object]]] |a1=[Ljava.lang.Class;:[[class java.util.ArrayList]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 16, 12, "\udb3d\ude2a\udb04\ude43\uda79\udf35\udb99\udc85\ud8c5\udca8\ud976\udf18\udb1a\udedd\udbb4\udd7c\uda05\udd7f\udbe6\udec2\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u8e76\u4023\ud002\u4282\u1fc3\u071b\u3134\u10a0", "\udb7d\uddb1\uda6c\udff5\ud88a\udc10\uda82\udecd\ud916\udffe\uda7f\udf3e\ud9ee\udfa4\ud8c4\udd03\udbc2\udcfc\ud86a\udd1c\uda35\udcaf\udb08\udcd0\ud9c0\uddec\ud9ca\udd0d\u89c6\uda06\udd67\uda7c\udc87\uda34\ude8d\uc456\udb57\udc48\ud8d0\udfe0\udabf\udf13",
        23, 1381, 1585760409, -9105725772817831067L, 2857L, true, true, (char) 51457, (char) 64235,
        Double.longBitsToDouble(0x3fc8c7784643d3bcL), Double.longBitsToDouble(0x3fe884d2c19f5efcL)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.List, contains [collection type; class java.util.List, contains [simple type, class java.lang.Object]]] |a1=[Ljava.lang.Class;:[[interface java.util.List]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.List, contains [collection type; class java.util.List, contains [simple type, class java.lang.Object]]] |a1=[Ljava.lang.Class;:[[interface java.util.List]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 17, 17, 13, "\ud848\udc25\ud8f3\ude22\uf952", "\u7553", "\ud8e0\udf62",
        46, 38197, 1029748528, -130996861360873658L, -94170L, false, true, (char) 42239, (char) 9929,
        Double.longBitsToDouble(0x3fa1cd42841f8500L), Double.longBitsToDouble(0x3feca808b6ca8d90L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Comparable<java.util.ArrayList<java.lang.Object>>] |a1=[Ljava.lang.Class;:[[class java.util.ArrayList]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 16, 17, "\uda1d\ude5a\udb2e\udf0a\uda13\udc74", "\ub138\u1ba4", "\ud850\ude98\udaed\ude27\ud801\udc41",
        8, 98121, -1983464019, -3587584006627916300L, 66529L, true, true, (char) 2662, (char) 33166,
        Double.longBitsToDouble(0x3fef934487177605L), Double.longBitsToDouble(0x3fb4125fcbde9db0L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Comparable<java.util.List<java.lang.Object>>] |a1=[Ljava.lang.Class;:[[interface java.util.List]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Comparable<java.util.List<java.lang.Object>>] |a1=[Ljava.lang.Class;:[[interface java.util.List]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud9c9\udc55\udbc8\udcfe\u9488\ud831\uded1\ud913\uddb6\ud81b\uddc9\ud907\ude29\udbb4\udd2a\uda9c\uddad\udbc6\ude58\udb83\udc3e\udbea\udeac\uda30\udef0\udbc2\udc2a", "\u8d6d\u4872\ud002\u7e1b\ud2db\u704f\u015a\u84e6", "\udb7d\uddb1\uda6c\udff5\ud88a\udc10\ud982\udf7a\ud916\udffe\uda7f\udf3e\udaf1\uddd0\ud827\udebf\udaab\udcf9\ud86a\udc64\uda35\udcaf\udb08\udcd0\ud9c0\uddec\ud979\uddc4\uda92\udfa8\uda06\udd67\uda41\udceb\ud82e\udc6c\u00ad\udb57\udc30\ud8d0\udfe0\udabf\udf13",
        36, 91053, 2053783596, 907871937280L, -76532L, true, true, (char) 36408, (char) 15815,
        Double.longBitsToDouble(0x3fc13f0f1caf916cL), Double.longBitsToDouble(0x3fc8c767e643d3bcL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructParametricType|java.lang.Class,[Lcom.fasterxml.jackson.databind.JavaType;|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructParametricType|java.lang.Class,[Ljava.lang.Class;|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructSpecializedType|com.fasterxml.jackson.databind.JavaType,java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeParser|parseType|com.fasterxml.jackson.databind.type.TypeParser$MyTokenizer|new:com.fasterxml.jackson.databind.type.TypeParser:com.fasterxml.jackson.databind.type.TypeFactory",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_bindingsForSubtype|com.fasterxml.jackson.databind.JavaType,int,java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_collectionType|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_constructSimple|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_findPrimitive|java.lang.String|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_findWellKnownSimple|java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromAny|com.fasterxml.jackson.databind.type.ClassStack,java.lang.reflect.Type,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromArrayType|com.fasterxml.jackson.databind.type.ClassStack,java.lang.reflect.GenericArrayType,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromClass|com.fasterxml.jackson.databind.type.ClassStack,java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromParamType|com.fasterxml.jackson.databind.type.ClassStack,java.lang.reflect.ParameterizedType,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromVariable|com.fasterxml.jackson.databind.type.ClassStack,java.lang.reflect.TypeVariable,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromWellKnownClass|com.fasterxml.jackson.databind.type.ClassStack,java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromWellKnownInterface|com.fasterxml.jackson.databind.type.ClassStack,java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructParametricType|java.lang.Class,[Lcom.fasterxml.jackson.databind.JavaType;|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructParametricType|java.lang.Class,[Ljava.lang.Class;|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructSpecializedType|com.fasterxml.jackson.databind.JavaType,java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeParser|parseType|com.fasterxml.jackson.databind.type.TypeParser$MyTokenizer|new:com.fasterxml.jackson.databind.type.TypeParser:com.fasterxml.jackson.databind.type.TypeFactory",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
