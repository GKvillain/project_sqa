package com.fasterxml.jackson.databind.deser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class NullifyingDeserializer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 2, "\ud8ed\udc00\udb98\udcfd\ud814\ude42", "\ub18a", "\ud801\udc45\uda02\udf3a\ud8ad\udfa8\uda5c\ude43\u4457\ud8d5\udf81\ud9b8\udf3b\udb79\udc7e\udbb5\udd15\udb7d\udee1\uda31\udf83\udbc9\ude57\ud8bc\udd8c\ud945\udf64\ud8fc\udec6\uda1f\udcfe\udae8\ude96\ud899\udf8c\ud9df\udfd1\ud91d\ude1a\udb11\udca7\ud8c0\udc1f\ud837\ude71\uda20\udc56\udbcf\udfaf",
        1, 91019, -460214090, 7976641775929914659L, 42280L, false, false, (char) 21194, (char) 49478,
        Double.longBitsToDouble(0x3fec4935c41db236L), Double.longBitsToDouble(0x3fd26e16cdc4680eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 2, "\ud8ed\udc00\udb98\udcfd\ud814\ude42", "\ub18a", "\ud801\udc45\uda02\udf3a\ud8ad\udfa8\uda5c\ude43\u4457\ud8d5\udf81\ud9b8\udf3b\udb79\udc7e\udbb5\udd15\udb7d\udee1\uda31\udf83\udbc9\ude57\ud8bc\udd8c\ud945\udf64\ud8fc\udec6\uda1f\udcfe\udae8\ude96\ud899\udf8c\ud9df\udfd1\ud91d\ude1a\udb11\udca7\ud8c0\udc1f\uda07\ude38\uda20\udc53\udbcf\udfaf",
        1, 80419, -460214090, 7976641776489657635L, 42280L, false, false, (char) 21194, (char) 49478,
        Double.longBitsToDouble(0x3fec4935c41db236L), Double.longBitsToDouble(0x3fd26e16cdc4680eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 2, "\ud8ed\udc00\ud8d3\uddfc\ud814\ude42", "\ua5e1", "\ud949\udc49\uda02\udf3a",
        7, 30995, 1553771832, -1268883964374831794L, 74362L, true, true, (char) 45354, (char) 22709,
        Double.longBitsToDouble(0x3fe52734b35cf2b7L), Double.longBitsToDouble(0x3fe9a9ccfbe13c28L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer:@?\0121=new com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer:@?\012",
        Z.run(T, 2, 2, 2, 2, "\ud8ed\udc00\udb98\udcfd\ud814\ude42", "\ub18a", "\ud801\udc45\uda02\udf3a\ud8ad\udfa8\uda5c\ude43\u4457\ud8d5\udf81\ud9b8\udf3b\udb79\udc7e\udbb5\udd15\udb7d\udee1\udbe7\uddbe\udbc9\uddea\ud8bc\udd8c\ud945\udf64\ud8fc\udec6\uda1f\udcfe\udae8\ude96\ud899\udf8c\ud9df\udfd1\ud91d\ude1a\udb11\udca7\ud8c0\udc1f\ud837\ude71\uda20\udc56\udbcf\udfaf",
        1, 91019, -460214090, 7976641775929914659L, 42280L, false, false, (char) 34250, (char) 8159,
        Double.longBitsToDouble(0x3fec4935c41db236L), Double.longBitsToDouble(0x3fd26e16cdc4680eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer:@?\0121=new com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer:@?\012",
        Z.run(T, 2, 2, 2, 2, "\ud8c6\udd6c", "\000\000\ub149\ud084\u9fca\u6872\ub92f\u89ac\u18ec\u4c4c\u2160\ua8b6\u080b\uc270[\u12bd\u9a85\u8754", "\uda1f\udcfe\udae8\ude96\ud899\udf8c\ud9df\udfd1\ud91d\ude1a",
        53, 79464, -1272079639, 1144195123198820358L, -57371L, false, false, (char) 40448, (char) 28373,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd77000005deb9aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\ud8ed\udc00\udb98\udcfd\udbe7\udd6c\ud9cf\udf75\udb68\udfff\uda4f\udd66\udb0f\udd45\u551b\ud801\udc45\uda02\udf3a\ud8ad\udfa8\uda79\udf1f\u4457\ud8d5\udf81\ud9b8\udf3b\udb79\udc7e\ud9dd\udf67\udb7d\udee1\uda31\udf83\udbc9\ude57\ud8bc\udd8c\u1f9a\udad2\udc3b\ud9f4\udd34\ud822\uddeb\udb3c\udde9\ud9df\udfd1\ud878\udd67\ud866\udee8\ud928\udf54", "\u4c60\uae28\u6508\u1833\u34a2\u7a94\uc202\u23a0\u0561\uc107\u5e30\uaf1e\u8beb\u5b12\u283b", "\ud9b1\udef3\udade\ude4f",
        12, 69996, -1560550707, 8041726838750396568L, -81287L, false, true, (char) 8405, (char) 56529,
        Double.longBitsToDouble(0x3fd98122bbb443d8L), Double.longBitsToDouble(0x3fe638c97455ec83L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer:@?\012",
        Z.run(T, 1, 2, 0, 2, "\ud839\udde9\ud995\uddc1\ud814\ude42", "\u5b7f", "\ud8c6\ude9d\udae4\uddef\uda60\udea9\uda5c\ude43\ud9dc\udffc\ud8d2\ude10\ud8c7\udca7\udb70\ude1e\udaef\ude52\uda29\udf48\u7421\ud9b3\udfdc\ud960\udfd4\ud90d\ude60\ud8fc\udec6\uda1f\udcfe\udae8\ude96\udbec\uddd6\ud9df\udf54\ud91d\ude1a\udb11\udca7\udbe2\udfa1\udb03\udcb5\u7397\uda70\udd30",
        -3, 51532, 1322607811, 7976641758350013731L, -95811L, false, true, (char) 51521, (char) 56227,
        Double.longBitsToDouble(0x3fac467ef5b127d0L), Double.longBitsToDouble(0x3feb274313e5d238L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "\ud9b8\uddc1\uda24\udc38\ud814\ude85", "\ub18a", "\ud801\udc45\uda02\udf3a\ud8ad\udfa8\uda5c\ude43\u5940\ud8d5\udf81\ud9b8\udf3b\udb79\udc7e\udbb5\udd15\udbc5\uddc4\ud951\ude6e\ud961\ude92\ud8bc\udd8c\ud945\udf64\ud8fc\udec6\uda1f\udcfe\udae8\ude96\ud899\udf8c\ud9df\udfd1\ud91d\ude1a\ud889\udca3\ud8c0\udc1f\ud837\ude71\uda20\udc56\udbcf\udfaf",
        1, 91019, -460214090, 7976641775929914659L, 42249L, false, false, (char) 21194, (char) 49478,
        Double.longBitsToDouble(0x3feeb135c6ef9e2fL), Double.longBitsToDouble(0x3fad843561e1a960L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer:@?\012",
        Z.run(T, 1, 2, 2, 2, "\ud8ed\udc00\udb98\udd24\udbbd\udcb7", "\ub289", "\ud92e\udd2a\udb91\ude46\ud8ad\udf6a\ud929\udf5b\ud9c8\udfa0\ud8d5\udf81\ud9b8\udf3b\udb4e\ude7e\udbb5\udd15\udb7d\udee1\udba2\ude4b",
        8, 75524, 966779903, 7767688136688015457L, -25114L, false, false, (char) 49939, (char) 347,
        Double.longBitsToDouble(0x3feb3cc6c2e98476L), Double.longBitsToDouble(0x3feb3da16c060fe0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 2, "\udb54\udef1\uda9d\udd71\uda83\udd0e", "\ub18a", "\ud9cf\udd2b\udb93\udf10\ud8c6\udc00\uda5c\ude43\u4457\ud9c3\udf39\uda74\uddc8\uda22\ude3e\udbb5\udd15\u99b6\uda31\udf83\ud821\udc42\ud8bc\udd4b\ud8e4\uddc8\udbf0\udfd9\uda1f\udc34\udae8\ude96\ud899\udf8c\ud9df\udfd1\udb7a\udda0\udbc8\udf4b\udb83\udda9\udba5\uddd4\uda20\udc83\udb95\uddaf",
        48, 45228, -1855171628, -386542732097157484L, 34500L, false, false, (char) 34144, (char) 34223,
        Double.longBitsToDouble(0x3fb556900506a198L), Double.longBitsToDouble(0x3fb6e3973711a038L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer:@?\0121=new com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer:@?\012",
        Z.run(T, 2, 2, 2, 2, "\ud8ed\udc00\udb98\udcfd\ua4af", "\ub1ba", "\ud813\udd22\udbf5\uddda\ud892\ude72\uda5c\ude43\u4457\ud8d5\udf81\ud9b8\udf3b\udb79\udc7e\udbb5\udd15\udb84\udfc4\uda31\udf83\udbc9\ude57\ud8bc\udd8c\ud945\udf64\udb7e\udc07\uda0c\udf1b\uda18\ude47\u3b36\uda7b\udddf\uda64\udceb\uda5e\udc2e\ud8c0\udc1f\ud837\ude71\uda20\udc56\uda6d\udca9",
        1, 91019, -467090105, 7976641776828675363L, -90968L, true, true, (char) 1532, (char) 42238,
        Double.longBitsToDouble(0x3fd73fb7f0f84650L), Double.longBitsToDouble(0x3fac467ee68e07d0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer|deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer:",
    "M|com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer|deserializeWithType|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.jsontype.TypeDeserializer|new:com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer:",
    "C|com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer|<init>|",
    "M|com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer|deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
