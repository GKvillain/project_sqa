package com.fasterxml.jackson.databind.node;
import org.junit.Test;
import static org.junit.Assert.*;
public class POJONode_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\udac2\ude7a\uda03\udca1\udb24\udd5a |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 4, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\uc8e5\u7673\u07ca\u7fce\u2948\ub106\u7cac\ub4cb\u73c9\ub8e3\u62b0\uc77d\u7395\u4300\u36d0\ua923\u1fa8\u5cc9\u0584\u737f\u2302\u4e8c\uc443\uc121\uc0f9\ud3ff\u08c5\ud5cc\u6ad5\u10a9", "\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e",
        48, 66192, 705608062, -8661022373218782098L, -79802L, false, true, (char) 21509, (char) 16804,
        Double.longBitsToDouble(0x3fe9719aae86b016L), Double.longBitsToDouble(0x3fdfe21ae46ef992L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:\udac2\ude7a\uda03\udca1\udb24\udd5a |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 4, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\uc8e5\u7673\u07ca\u7fce\u2948\ub106\u7cac\ub4cb\u73c9\ub8e3\u62b0\uaa42\u7395\u4300\u36d0\ua923\u1fa8\u5cc9\u0584\u737f\u2302\u4e8c\uc443\uc121\uc0f9\ud3ff\u08c5\ud5cc\u6ad5\u10a9", "\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e",
        48, 66192, 705608062, -8661022373218782098L, -79802L, false, true, (char) 21509, (char) 16804,
        Double.longBitsToDouble(0x3fe9719aae86b016L), Double.longBitsToDouble(0x3fdfe21ae46ef992L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:\udac2\ude7a\uda03\udca1\udb24\udd5a |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 4, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\ud652\u7704\u07ca\u7fce\u2948\ub106\uc3ac\ub4cb\u73c9\ub8e3\u62b0\uc77d\u7395\u4300\u36d0\ua923\u8e6c\u5cc9\u0584\u737f\u2302\u08eb\uc443\uc121\uc0f9\u70f6\uc8f0\ud5cc\u6ad5\u10a9", "\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e",
        48, 66192, 705608062, -8661022373218782098L, -79802L, false, true, (char) 21509, (char) 16804,
        Double.longBitsToDouble(0x3fe9719aa94db016L), Double.longBitsToDouble(0x3fec35359a378101L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:null |this=com.fasterxml.jackson.databind.node.POJONode:null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 4, "\udabd\ude7a\uda03\udca1\ud9d5\udc7d\uda19\ude77", "\u7673\u07ca\u7fce\u2948\ub106\u7cac", "\ud85f\udefb\uda54\udd05\uda41\udcbd\ud826\udfea\ud8e9\udfed\uda90\udec0\ud916\ude36\ud80a\udc4c\ud8ec\ude0a\ud814\udd6d\udb84\udf5f\ud9c6\udc85\ud972\udc07\ud848\udc54\udbd7\udf84\ud98b\udd76\uda2a\udd76\ud860\udc52\ud83e\ude53\u899e\ud9bc\udd77\udbe6\udd0e\u96b8\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e\udb05\udfc7\ud8c0\udf4f\ud9ae\udcfa\uda8b\udef4\uda12\udfe9\ud94f\udc49\udb96\udd5e\ud8e9\udf8d\ud856\udde0\ud9cd\ude87\udba3\ude14\ud86e\udcc6\ud828\udc10\uda3c\uddc2\u2335\ud98d\udf12\uda63\udce2\uda81\udc83",
        26, 47964, -1309376474, 5112086818406678592L, -62391L, false, true, (char) 50923, (char) 15496,
        Double.longBitsToDouble(0x3fa72f0a7e226fb0L), Double.longBitsToDouble(0x3fd0318549cd03aaL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:\udac2\ude7a\uda03\udca1\udb24\udd5a\uda2f\udc3e |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\uda2f\udc3e\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\uda2f\udc3e\012",
        Z.run(T, 2, 6, 10, 8, "\udac2\ude7a\uda03\udca1\udb24\udd5a\uda2f\udc3e", "\u71b5\u07ca\u43bf\u29a4\ub106\u7cac\ub4cb\u9ec0\ub8e3\u62b0\uc77d\u7395\u4300\u36d0\ua923\u1fa8\ucf5a\ua2e6\u737f\u2302\u4e8c\uc443\ud464\ub2ba\ud3ff\u08c5\ud5cc\u6ad5\u10a9\u7cb2\u3b03\ua8d5", "\udab3\ude68\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\uda8b\udef4\udbad\ude95\ud94f\udc49",
        25, 64090, 1176714571, 3699139199083399982L, -13474L, true, false, (char) 42782, (char) 56984,
        Double.longBitsToDouble(0x3fd34a0848732722L), Double.longBitsToDouble(0x3fe5f73aae2cd736L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\uda1d\udd17\012",
        Z.run(T, 1, 9, 1, 4, "\udac2\ude7a\uda03\udca1\uda1d\udd17", "\uc8e5", "\ud9ea\ude63\ud82a\udc0f",
        18, 94466, 1508991538, 7964485125967037L, 93709L, false, true, (char) 1526, (char) 23936,
        Double.longBitsToDouble(0x3fc4837aee585efcL), Double.longBitsToDouble(0x3fefca9507f9b1f9L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 4, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\uc8e5\u7673\u07ca\u7fce\u2d6e\ub106\u7cac\ub4cb\u73c9\ub8e3\u62b0\uc77d\u7395\u4300\u36d0\ua923\u1fa8\u5cc9\u0584\u737f\u2302\u4e8c\uc443\uc121\uc0f9\ud3ff\u08c5\ud5cc\u6ad5\u10a9", "\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e",
        48, 66192, 705608062, -8661021660254210962L, 83086L, false, false, (char) 29612, (char) 8960,
        Double.longBitsToDouble(0x3fb1260f171e06d0L), Double.longBitsToDouble(0x3fe3b9e85246d84aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:\ud9bb\udf97\uda09\ude6f\ud87b\udef7\ud916\udeea |this=com.fasterxml.jackson.databind.node.POJONode:\ud9bb\udf97\uda09\ude6f\ud87b\udef7\ud916\udeea\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 4, "\ud9bb\udf97\uda09\ude6f\ud87b\udef7\ud916\udeea", "\u7673\u07ca\u7fce\u2948\ub106\u7cac", "\uda9f\udfba\ud94a\ude59\uda41\udc8a\ud826\udfea\ud8e9\udfed\uda90\udec0\ud916\ude36",
        14, 79228, 1388749462, -5622216492735156231L, -97007L, true, true, (char) 64505, (char) 48721,
        Double.longBitsToDouble(0x3fed4cbda5e9ff92L), Double.longBitsToDouble(0x3fe3861940a079d5L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 4, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\uc8e5\u7673\u07ca\u7fce\u2948\ub106\u7cac\ub4cb\000\ub8e3\u0e0b\uc702\u7395\u4300\u36d0\ua923\u1fa8\u5cc9\u0584\u737f\u2302\u4e8c\uc443\uc121\uc0f9\ud3ff\u08c5\ud5cc\u6ad5\u10a9", "\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e",
        48, 66192, 705608062, -8661022373218782098L, -79802L, false, false, (char) 21509, (char) 16804,
        Double.longBitsToDouble(0x3fe9719aae86b016L), Double.longBitsToDouble(0x3fdfe21ae46ef992L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Long:-8661022373218782098 |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 4, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\u0d1c\u76bc\u07ca\u7fce\u2948\ub106\u7cac\ub4cb\u73c9\ub8e3\u62b0\uc77d\u7395\u4300\u36d0\ua923\u1fa8\u5cc9\u0584\u737f\u2302\u4e8c\uc443\uc121\uc0f9\ud3ff\u08c5\ud5cc\u6ad5\u10a9", "\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e",
        48, 66192, 705608062, -8661022373218782098L, -79802L, false, true, (char) 21509, (char) 16804,
        Double.longBitsToDouble(0x3fe9719aae86b016L), Double.longBitsToDouble(0x3fdfe21ae46ef992L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:\udac2\ude7a\uda03\udca1\udb24\udd5a |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\0121=java.lang.Double:0.7951177033151022 |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\012",
        Z.run(T, 2, 6, 3, 4, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\uc8e5\u7673\u07ca\u7fce\u2948\ub106\u7cac\ub4cb\u73c9\ub8e3\u62b0\uc77d\u7395\u4300\u36d0\ua923\u1fa8\u5cc9\u0584\u737f\u2302\u4e8c\u62c8\ub691\uc152\uafd6\u08c5\ud5cc\u7e96\u10a9", "\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e",
        48, 66192, 705608062, -6366648150751087480L, -79802L, false, true, (char) 21509, (char) 16804,
        Double.longBitsToDouble(0x3fe9719aae86b016L), Double.longBitsToDouble(0x3fdfe21ae46ef992L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:\udac2\ude7a\uda03\udca1\udb24\udd5a\uda2f\udc3e\ud859\udff5\uda48\uddbf\udaaa\udd04\udbcf\uddf8\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud825\udcc6 |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\uda2f\udc3e\ud859\udff5\uda48\uddbf\udaaa\udd04\udbcf\uddf8\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud825\udcc6\0121=java.lang.String:\udac2\ude7a\uda03\udca1\udb24\udd5a\uda2f\udc3e\ud859\udff5\uda48\uddbf\udaaa\udd04\udbcf\uddf8\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud825\udcc6 |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\uda2f\udc3e\ud859\udff5\uda48\uddbf\udaaa\udd04\udbcf\uddf8\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud825\udcc6\012",
        Z.run(T, 2, 6, 14, 0, "\udac2\ude7a\uda03\udca1\udb24\udd5a\uda2f\udc3e\ud859\udff5\uda48\uddbf\udaaa\udd04\udbcf\uddf8\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud825\udcc6", "\u776d\u62b0\u6257\u7395\uabe9\u36d0", "\ud8ec\ude0a\uda1c\udc74\ud9bd\udc58",
        37, 75838, -1133054897, -1944120056515062028L, 53125L, true, true, (char) 54680, (char) 45685,
        Double.longBitsToDouble(0x3fdc68688f816a30L), Double.longBitsToDouble(0x3fdf7ee805d9e84aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 4, "\udac2\ude7a", "\u52a6", "\udaaa\udd04\ud98f\udf82\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud825\udcc6",
        23, 35376, 8948081, 3936642454349005619L, 44813L, false, true, (char) 1526, (char) 61311,
        Double.longBitsToDouble(0x3fc4837aee585efcL), Double.longBitsToDouble(0x3fefca9507f9b1f9L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\ud8c8\uddfe\uda03\udce4 |this=com.fasterxml.jackson.databind.node.POJONode:\ud8c8\uddfe\uda03\udce4\0121=java.lang.String:\ud8c8\uddfe\uda03\udce4 |this=com.fasterxml.jackson.databind.node.POJONode:\ud8c8\uddfe\uda03\udce4\012",
        Z.run(T, 2, 6, 6, 4, "\ud8c8\uddfe\uda03\udce4", "\u3047\uc8e5\uadf7", "\ud82a\udc0f\udaf1\udf72\ud825\udcc6\udbb3\udf7e\uda2a\udfb3\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud826\udfea",
        27, 67552, -264372965, 2006352156923230372L, 22873L, true, true, (char) 17925, (char) 42204,
        Double.longBitsToDouble(0x3fd1cbc76de9ca0aL), Double.longBitsToDouble(0x3fece735a9db97b4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\udac2\ude7a\uda03\udca1\udb24\udd5a\uda2f\udc3e\uda5e\udc96\ud9e9\udf6a\udb80\uddf6\ud98f\udf77\udb14\uddb9\ud82a\udc9b\udaf1\udf72\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud826\udfea\ud8e9\udfed\uda90\udec0\udba8\ude9f\uda68\udf5d\ud8ec\udddd\uda1c\udc74\ud88b\ude1b\ud8fe\udc75\ud972\udc07\udb7a\udc8c\uda22\udd49\ud99b\ude45\uda2a\udd76\ud889\udf6a\udb0a\ude2c\u899e\udada\udd69\udb39\udd96\udab2\udda1\udabd\uddd2\udbcd\udd57\ud81f\udf3f\ud87f\udf9e\udb05\udfc7\ud9e2\udcce\ud95d\uded9\ud89e\udc0d |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\uda2f\udc3e\uda5e\udc96\ud9e9\udf6a\udb80\uddf6\ud98f\udf77\udb14\uddb9\ud82a\udc9b\udaf1\udf72\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud826\udfea\ud8e9\udfed\uda90\udec0\udba8\ude9f\uda68\udf5d\ud8ec\udddd\uda1c\udc74\ud88b\ude1b\ud8fe\udc75\ud972\udc07\udb7a\udc8c\uda22\udd49\ud99b\ude45\uda2a\udd76\ud889\udf6a\udb0a\ude2c\u899e\udada\udd69\udb39\udd96\udab2\udda1\udabd\uddd2\udbcd\udd57\ud81f\udf3f\ud87f\udf9e\udb05\udfc7\ud9e2\udcce\ud95d\uded9\ud89e\udc0d\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 3, "\udac2\ude7a\uda03\udca1\udb24\udd5a\uda2f\udc3e\uda5e\udc96\ud9e9\udf6a\udb80\uddf6\ud98f\udf77\udb14\uddb9\ud82a\udc9b\udaf1\udf72\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud826\udfea\ud8e9\udfed\uda90\udec0\udba8\ude9f\uda68\udf5d\ud8ec\udddd\uda1c\udc74\ud88b\ude1b\ud8fe\udc75\ud972\udc07\udb7a\udc8c\uda22\udd49\ud99b\ude45\uda2a\udd76\ud889\udf6a\udb0a\ude2c\u899e\udada\udd69\udb39\udd96\udab2\udda1\udabd\uddd2\udbcd\udd57\ud81f\udf3f\ud87f\udf9e\udb05\udfc7\ud9e2\udcce\ud95d\uded9\ud89e\udc0d", "\uc922\u64aa", "\udad5\udcb5\ud86e\udc1b\uda4c\udd58\uda18\udfc2\uda0c\udfeb\udbfa\uded4\udb28\udc24\ud92e\udddf",
        40, 16530, 2037438932, -8845334478227274097L, 15590L, true, true, (char) 42929, (char) 55574,
        Double.longBitsToDouble(0x3fe3a84ba9dc611aL), Double.longBitsToDouble(0x3fd51aa53d4ae32eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:null |this=com.fasterxml.jackson.databind.node.POJONode:null\0121=null |this=com.fasterxml.jackson.databind.node.POJONode:null\012",
        Z.run(T, 2, 6, 7, 3, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\uc8e5\u7673\uc815\u7fce\u2948\ub106\u7cac\ub4cb\u73c9\ub8e3\u62b0\uc77d\u7395\u4300\u49f0\ua923\u1fa8\u5cc9\u0584\u737f\u2302\u4e8c\uc443\uc121\uc0f9\ud3ff\u08c5\ucc05\u6a69\u10a9", "\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e",
        16, 82722, 1849531488, 5352231882309596270L, -79802L, true, true, (char) 58401, (char) 16804,
        Double.longBitsToDouble(0x3fe9719aae86b016L), Double.longBitsToDouble(0x3fdfe21ae46ef992L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:\u5a86\uda03\udd61\udb24\udd5a\uda88\udc95\ud952\udc90\uda82\uddd2\uda89\udef4\ud924\udcd1\ud9ea\ude63\ud82a\udc0f\udbbd\ude31 |this=com.fasterxml.jackson.databind.node.POJONode:\u5a86\uda03\udd61\udb24\udd5a\uda88\udc95\ud952\udc90\uda82\uddd2\uda89\udef4\ud924\udcd1\ud9ea\ude63\ud82a\udc0f\udbbd\ude31\0121=java.lang.String:\u5a86\uda03\udd61\udb24\udd5a\uda88\udc95\ud952\udc90\uda82\uddd2\uda89\udef4\ud924\udcd1\ud9ea\ude63\ud82a\udc0f\udbbd\ude31 |this=com.fasterxml.jackson.databind.node.POJONode:\u5a86\uda03\udd61\udb24\udd5a\uda88\udc95\ud952\udc90\uda82\uddd2\uda89\udef4\ud924\udcd1\ud9ea\ude63\ud82a\udc0f\udbbd\ude31\012",
        Z.run(T, 2, 6, 12, 4, "\u5a86\uda03\udd61\udb24\udd5a\uda88\udc95\ud952\udc90\uda82\uddd2\uda89\udef4\ud924\udcd1\ud9ea\ude63\ud82a\udc0f\udbbd\ude31", "\u59df\ub8e3\u62b0\uc77d\u7395\u4300\u36d0\ua923\u1fa8\u5cc9\ud22d\u735a\u2302\u725d\uc42d\uc121\uc0f9\u2872\uae7c\u1e78\uaf9b\uc4aa\u7cb2\u5fad\ua831\ud333\u5acb\u123d\u703d\u847d\uc308\u0660\ud7c9\uc9b6", "\ud856\udd6d\udb26\udcdf\ud895\udcbf\udb47\udd8f\uda4c\udd58\udaba\udc81\ud9a2\udd80",
        43, 35447, -528232108, -5519963992675858360L, 30552L, false, true, (char) 52144, (char) 34373,
        Double.longBitsToDouble(0x3fe97e892d411302L), Double.longBitsToDouble(0x3fb67ecdfe4c50f0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Double:0.27806268438067205 |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 3, "\udac2\ude7a\uda03\udca1", "\u3047\uc8e5\u7673", "\udb85\udfdc\udaf1\udfa9\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d",
        44, 58864, 1595001427, -8441291993252398309L, 22868L, true, true, (char) 17925, (char) 42204,
        Double.longBitsToDouble(0x3fd1cbc76de9ca0aL), Double.longBitsToDouble(0x3fece735a9db97b4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.node.POJONode:\ud849\uddf6\uda03\udcd2\udb24\udd5a\uda2f\udc0f\udaa1\uddb2\ud87d\ude05\ud85d\udf1f\ud969\udf39\udb8d\udf06\ud82a\udc0f\udaf1\udf72\ud883\udcd5\udb47\ude66\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 1, 4, "\ud849\uddf6\uda03\udcd2\udb24\udd5a\uda2f\udc0f\udaa1\uddb2\ud87d\ude05\ud85d\udf1f\ud969\udf39\udb8d\udf06\ud82a\udc0f\udaf1\udf72\ud883\udcd5\udb47\ude66", "\u5bee\u9b56\u741a\u4300\u36d0\ua923\u1fa8\u5cc9", "\ud9c6\udc85\ud8fa\ude2a\udbe3\udf8f\udb90\udefb\ud838\udd0e\uda73\udecb\ud889\udecd\ud8ce\udff4\udbd0\uddcd\udaac\ude5a\ud91d\udf40",
        30, 19701, 570200759, 2080872479124296796L, -84392L, false, true, (char) 2072, (char) 11400,
        Double.longBitsToDouble(0x3fd131ee02357662L), Double.longBitsToDouble(0x3fdbade47a976d74L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\0121=java.lang.String:\udac2\ude7a\uda03\udca1\udb24\udd5a |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\012",
        Z.run(T, 2, 9, 7, 4, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\uc8e5\u7673\u9487\u7fc5\u2991\ub106\u7cac\u57be\u9329\ub8e3\u62b0\uc77d\u7395\u4300\ud40a\ua923\u1fa8\u5cc9\u3e48\u737f\u2302\u4e8c\uc443\uc121\uc0f9\ud3ff\u08c5\ud5cc\u6c9b\u10a9", "\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e",
        48, 66192, 705608191, -8661022373218782098L, -79802L, false, true, (char) 21509, (char) 16804,
        Double.longBitsToDouble(0x3fe9719aae86b016L), Double.longBitsToDouble(0x3fdfe21ae46ef992L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:null |this=com.fasterxml.jackson.databind.node.POJONode:null\0121=java.lang.Integer:23 |this=com.fasterxml.jackson.databind.node.POJONode:null\012",
        Z.run(T, 2, 6, 4, 4, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\u1747\u7673\u07ca\u7fce", "\ud825\udcc6",
        23, 35376, 851479741, -7012977587031775877L, 44813L, false, true, (char) 1526, (char) 61311,
        Double.longBitsToDouble(0x3fc4837aee585efcL), Double.longBitsToDouble(0x3fefca9507f9b1f9L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:null |this=com.fasterxml.jackson.databind.node.POJONode:null\0121=com.fasterxml.jackson.databind.node.JsonNodeType:POJO |this=com.fasterxml.jackson.databind.node.POJONode:null\012",
        Z.run(T, 2, 6, 11, 4, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\uc8e5\u7673\u07ca\u7fce\u2948\ub106\u7cac\ub4cb\u73c9\ub8e3\u62b0\uc77d\u7395\u4300\u36d0\ua923\u1fa8\u5cc9\u0584\u9a0a\u2302\u4e8c\uc443\uc121\uc0f9", "\ud83e\ude53\u899e\ud9bc\udd77\uda15\udde5\u9634\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e\udb05\udfc7\ud8c0\udf4f\udab7\udf81\udadf\udcef\ud9c8\ude36\ud88e\uddc7\ud8bf\udc1a\udba0\udf10\ud856\udd6d\ud9cd\ude87\ud9f6\udd6e\ud83c\udfd1\uda4c\udd58\ud931\uddce\uc197\udba3\udeb0",
        0, 60396, 643947500, 6062888426943586876L, -55511L, true, false, (char) 15170, (char) 6397,
        Double.longBitsToDouble(0x3fc168fd965833e8L), Double.longBitsToDouble(0x3fdcc7c79cdf9ef0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:\000\uda03\udca1\udb24\udd5a |this=com.fasterxml.jackson.databind.node.POJONode:\000\uda03\udca1\udb24\udd5a\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 4, "\000\uda03\udca1\udb24\udd5a", "\u150c\u6045\u07ca\u5d23\ubda0\ub106\u7cac\ub4cb\u73c9\ub8e3\u62b0\uc77d\u7395\u4300\u36d0\ua923\u26a9\000\u0584\u6c7e\u2302\u4e8c\000\000\u392f\ud3ff\u08c5\ud5cc\u6ad5\u10a9", "\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e",
        48, 66192, 705608062, -8661022373218782098L, -79802L, false, true, (char) 21509, (char) 16804,
        Double.longBitsToDouble(0x3fe9719aae86b016L), Double.longBitsToDouble(0x3fdfe21ae46ef992L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:\000\000\000 |this=com.fasterxml.jackson.databind.node.POJONode:\000\000\000\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 4, "\000\000\000", "\uc8e5\u7673\u07ca\u7fce\u2948\ub106\u7cac\ub4cb\u73c9\ub8e3\u62b0\uc77d\u7395\u4300\ubdcd\ua923\u1fa8\u5cc9\u0584\u737f\u2302\u4e8c\uc443\uc121\uc0f9\ud3ff\u08c5\ud5ccp\000", "\u00f7\000\ud885\udca2\ud87f\udf9e",
        48, 66192, 705608062, -8661022373218782098L, -100000L, false, false, (char) 21323, (char) 16804,
        Double.longBitsToDouble(0x3fe9719aa8000016L), Double.longBitsToDouble(0x3e31b80000000000L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\udac2\ude7a\u1342\udb24\udd6e |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\u1342\udb24\udd6e\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 1, 4, "\udac2\ude7a\u1342\udb24\udd6e", "\ube3d\ud23e\u07ca\u7fce\u00b1\ub155\u7cac\ub4cb\u8b7d\u08d4\ua984\ub56a\u7395\ud613\u36d0\u34b4\u9b19\u0f59\u6aa8\u442e\uae93\u4e8c\uc443\u45dd\u34a6\ud3ff\u08c5\ud321\u2bcd\u563b", "\uda3e\udfbf\udae7\udcec\ud933\udd40\ud87f\udfd0",
        48, 5176, 705607988, 4919322862314401045L, 73361L, false, true, (char) 21509, (char) 16804,
        Double.longBitsToDouble(0x3fd2d33556d1de4aL), Double.longBitsToDouble(0x3fde3a81d0608876L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\ud985\udf89\uda08\ude08\udb24\udd5a |this=com.fasterxml.jackson.databind.node.POJONode:\ud985\udf89\uda08\ude08\udb24\udd5a\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:\ud985\udf89\uda08\ude08\udb24\udd5a\012",
        Z.run(T, 2, 7, 10, 4, "\ud985\udf89\uda08\ude08\udb24\udd5a", "\ud2ed\u8d3e\u987d\u80b2\u2948\ub106\u7cac\ub4cb\u73c9\ub8e3\u62b0\uc77d\u7395\u4300\u36d0\ua923\u1fa8\u5cc9\u0584\u737f\u2302\u4e8c\uc443\uc121\uc0f9\ud3ff\u08c5\ud5cc\u6ad5\u10a9", "\uda47\udebf\udac2\udf20\ud8b4\udf21\ud87f\udf9e",
        48, 69264, -1723840924, -2821761658724336242L, -79802L, false, true, (char) 21509, (char) 16804,
        Double.longBitsToDouble(0x3fe9719aae86b016L), Double.longBitsToDouble(0x3fdfe21ae46ef992L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.node.POJONode:\ud8a4\udc0c\ud8c7\udc67\uda1f\udf13\uda2f\udc3e\uda5e\udc96\uda82\uddd2\ud917\uddc3\udbf7\ude85\ud91c\ude9c\udb62\udc72\ud9ef\ude55\ud86c\udfb8\uda7d\udcdb\ud9e5\uddf2\udaa9\udcdf\u45ab\u628f\ud95a\udf4d\ud9d3\udf31\uda95\udf1d\ud916\ude36\ud80a\udc4c\012",
        Z.run(T, 1, 15, 1, 4, "\ud8a4\udc0c\ud8c7\udc67\uda1f\udf13\uda2f\udc3e\uda5e\udc96\uda82\uddd2\ud917\uddc3\udbf7\ude85\ud91c\ude9c\udb62\udc72\ud9ef\ude55\ud86c\udfb8\uda7d\udcdb\ud9e5\uddf2\udaa9\udcdf\u45ab\u628f\ud95a\udf4d\ud9d3\udf31\uda95\udf1d\ud916\ude36\ud80a\udc4c", "\u737f\u70ef\u4e8c\u6528\u93b1\u8d9e\ud3ff\uaf19\ud5cc\u6ad5\u6dc9\u08ad\u59d7\u16c2\u8df5\u7565\u516a\u703d\ua57a\uab56\ub6fd\ud7c9\u776b\uc922\u64aa\u906b\ud058", "\udbca\udcd8",
        24, 37602, 1301076066, 5494667730034053694L, -28574L, false, true, (char) 35385, (char) 41005,
        Double.longBitsToDouble(0x3fd09973f6946d66L), Double.longBitsToDouble(0x3fbb8294455d99a8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String:\000\000\udb24\udd5a |this=com.fasterxml.jackson.databind.node.POJONode:\000\000\udb24\udd5a\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 4, "\000\000\udb24\udd5a", "", "\ud98f\udf82\ud9ea\ude63",
        13, 76238, -1908198534, 6481069305652595624L, -41110L, true, true, (char) 16481, (char) 46264,
        Double.longBitsToDouble(0x3fda85f1103715b4L), Double.longBitsToDouble(0x3e14800000000000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:null |this=com.fasterxml.jackson.databind.node.POJONode:null\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:null\012",
        Z.run(T, 2, 6, 10, 15, "\udac2\ude7a\uda03\udca1\udb2e\udca6", "\u77d3\u6a6d\u545b\u88d6\u93c8\ub106\u7cac\ub4cb\u10bc\u95fe\u7f76\ucd37\ua0dd\u9e6e\u90ed\u82ee\u519c\ub293\u5cf6\u737f\u22a8\u4e8c\uc443\u33a6\u3df9\u99b5\u779d\ud5cc\u90ba\u21ba", "\ud954\udd59\udae3\uddae\udb16\uddb2\ud954\udcb4\ud970\udeb0\udb17\udf44",
        40, 36502, 613774539, 557114084437723001L, -74866L, false, true, (char) 26992, (char) 28785,
        Double.longBitsToDouble(0x3fe748fc7652633aL), Double.longBitsToDouble(0x3fea3d05d14d30eaL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:null |this=com.fasterxml.jackson.databind.node.POJONode:null\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:null\012",
        Z.run(T, 2, 6, 2, 4, "\udac2\ude7a", "\u5325", "\udaaa\udd04\ud98f\udf82\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud825\udcc6",
        23, 35376, 851479741, -7012977587031775877L, 44813L, false, true, (char) 1526, (char) 61311,
        Double.longBitsToDouble(0x3fda41bd772c2f7eL), Double.longBitsToDouble(0x3fefca9507f9b1f9L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Long:6657931387174151058 |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\0121=java.lang.Long:6657931387174151058 |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\012",
        Z.run(T, 2, 5, 5, 4, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\u2f74\u8ca3\u2d2f\u58c1\u0148\u65c4\u3d3f\ub4cb\u73c9\ub8e3\u0ed7\u7214\u7395\u4300\u6818\u286c\u1f17\u5cc9\u0584\u1cb9\u69b6\ub810\uc443\ub217\u45b7\u2da1\u0873", "\ud9bc\udd77\udbe6\udd0e\ud81a\udc9b",
        11, 54812, -908018049, 6657931387174151058L, -16462L, false, false, (char) 64571, (char) 36138,
        Double.longBitsToDouble(0x3fe156ec5612de47L), Double.longBitsToDouble(0x3fe0c2ec639e0288L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String:\udac2\ude7a\uda03\udca1u |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1u\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 4, "\udac2\ude7a\uda03\udca1u", "", "\ud98f\udf82\ud9ea\ude63\ud82a\udc0f\udaf1\udf72",
        -5, 88224, 1854376, 3657077640801609226L, 16016L, true, false, (char) 33191, (char) 1526,
        Double.longBitsToDouble(0x3fda80000148374aL), Double.longBitsToDouble(0x3fecb00007f952a0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:\udac2\ude7a\ud9dc\ude0d\000 |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\ud9dc\ude0d\000\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 4, "\udac2\ude7a\ud9dc\ude0d\000", "\ud652\000\u07ca\u7fce\u2948\ub106\uc3ac\ub4cb\u73c9\ub8e3\u62b0\u1db6\u7395\u4300\u36d0\ua923\u8e6c\u78a4\000\u737f\u2302\u08eb\uc443\uc121\uc0f9\u70f6\uc8f0\ud5cc\u6ad5\u38a0", "\uda47\udebf",
        7, 38303, -1390996351, 5147615002954825728L, -34464L, false, false, (char) 9365, (char) 27674,
        Double.longBitsToDouble(0x3fdbade47a962d74L), Double.longBitsToDouble(0x3fec0a3118000000L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.fasterxml.jackson.databind.node.POJONode:\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:\012",
        Z.run(T, 2, 6, 10, 0, "", "\ua52d\u2f4e\u1092", "\ud98f\udf82\ud872\udfb2\ud82a\udc6b\udaf1\udf72\ud825\udcc6\udbb3\udf7e\udaa0\udd40\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud826\udfea\ud254\uda70\udd18\ud916\ude36\ud80a\udc4c\ud85b\udf62\uda0d\uddd7\udb84\udf5f\ud9c6\udc85\ud972\udc07\ud848\udc54\ud90b\udf3d\ud987\udf37\uda2a\udd76\ud889\udf6a\ud96f\uddeb\u899e\ud9bc\udd77\udbe6\udd0e\u96b8",
        41, 54812, -1023623553, -5938370748896746606L, 78558L, false, false, (char) 64571, (char) 36068,
        Double.longBitsToDouble(0x3fd1abbc0375bc8eL), Double.longBitsToDouble(0x3fd4b16ba7028c46L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude75\uda03\udca1\udb24\udd5a\uda3b\udc3e\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude75\uda03\udca1\udb24\udd5a\uda3b\udc3e\012",
        Z.run(T, 2, 10, 10, 8, "\udac2\ude75\uda03\udca1\udb24\udd5a\uda3b\udc3e", "\u71b5\u07ca\u43bf\u29a4\ub106\u7cac\ub4cb\u9ec0\ub8e3\u62b0\uc77d\u7395\u4300\u36d0\ua923\u1fa8\ucf5a\ua2e6\u737f\u2183\u4e15\uc443\u0ec3\ub2ba\ud3ff\u17e2\ub1ad\ud41e\u10a9\u7cb2\u3b03\ua8d5", "\udab3\ude68\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\uda8b\udef4\udbad\ude95\ud94f\udc49",
        25, 64090, 1176714571, 3699139199083399982L, -13474L, true, false, (char) 58846, (char) 56984,
        Double.longBitsToDouble(0x3fd34a0848732722L), Double.longBitsToDouble(0x3fe5f73aae2cd736L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:\udbd8\udc34\uda83\udd68\udb4b\ude62\uda2f\udc3e\udb67\udddc\ud981\ude32\ud9a6\udfc5\ud98f\udf82\ud872\udfc7\ud82a\udc6b\udaf1\udf72\ud825\udcc6\udbb3\udf7e\udaa0\udd40\uda9f\udfba\ud94a\uddfb\uda41\udc7a\ud826\udfea\ud8e9\udfed\uda90\udec0\ud916\ude36\ud80a\udc4c\uda69\udd28\ud9bb\udca5\udb64\ude58\ud9c6\udc85\ud972\udc07\ud848\udc54\ud90b\udf3d\ud987\udf37\uda2a\udd76\ud889\udf6a\ud83e\ude53\u899e\ud9bc\udd77\udbe6\udd0e\u96b8\uda07\ude60\udae7\udc2f\ud9fe\udee6\udab3\ude68\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\uda8b\udef4\udbad\ude95\udada\udfa4\udb20\udf83\udba0\udf10\ud856\udd6d |this=com.fasterxml.jackson.databind.node.POJONode:\udbd8\udc34\uda83\udd68\udb4b\ude62\uda2f\udc3e\udb67\udddc\ud981\ude32\ud9a6\udfc5\ud98f\udf82\ud872\udfc7\ud82a\udc6b\udaf1\udf72\ud825\udcc6\udbb3\udf7e\udaa0\udd40\uda9f\udfba\ud94a\uddfb\uda41\udc7a\ud826\udfea\ud8e9\udfed\uda90\udec0\ud916\ude36\ud80a\udc4c\uda69\udd28\ud9bb\udca5\udb64\ude58\ud9c6\udc85\ud972\udc07\ud848\udc54\ud90b\udf3d\ud987\udf37\uda2a\udd76\ud889\udf6a\ud83e\ude53\u899e\ud9bc\udd77\udbe6\udd0e\u96b8\uda07\ude60\udae7\udc2f\ud9fe\udee6\udab3\ude68\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\uda8b\udef4\udbad\ude95\udada\udfa4\udb20\udf83\udba0\udf10\ud856\udd6d\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:\udbd8\udc34\uda83\udd68\udb4b\ude62\uda2f\udc3e\udb67\udddc\ud981\ude32\ud9a6\udfc5\ud98f\udf82\ud872\udfc7\ud82a\udc6b\udaf1\udf72\ud825\udcc6\udbb3\udf7e\udaa0\udd40\uda9f\udfba\ud94a\uddfb\uda41\udc7a\ud826\udfea\ud8e9\udfed\uda90\udec0\ud916\ude36\ud80a\udc4c\uda69\udd28\ud9bb\udca5\udb64\ude58\ud9c6\udc85\ud972\udc07\ud848\udc54\ud90b\udf3d\ud987\udf37\uda2a\udd76\ud889\udf6a\ud83e\ude53\u899e\ud9bc\udd77\udbe6\udd0e\u96b8\uda07\ude60\udae7\udc2f\ud9fe\udee6\udab3\ude68\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\uda8b\udef4\udbad\ude95\udada\udfa4\udb20\udf83\udba0\udf10\ud856\udd6d\012",
        Z.run(T, 2, 6, 10, 8, "\udbd8\udc34\uda83\udd68\udb4b\ude62\uda2f\udc3e\udb67\udddc\ud981\ude32\ud9a6\udfc5\ud98f\udf82\ud872\udfc7\ud82a\udc6b\udaf1\udf72\ud825\udcc6\udbb3\udf7e\udaa0\udd40\uda9f\udfba\ud94a\uddfb\uda41\udc7a\ud826\udfea\ud8e9\udfed\uda90\udec0\ud916\ude36\ud80a\udc4c\uda69\udd28\ud9bb\udca5\udb64\ude58\ud9c6\udc85\ud972\udc07\ud848\udc54\ud90b\udf3d\ud987\udf37\uda2a\udd76\ud889\udf6a\ud83e\ude53\u899e\ud9bc\udd77\udbe6\udd0e\u96b8\uda07\ude60\udae7\udc2f\ud9fe\udee6\udab3\ude68\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\uda8b\udef4\udbad\ude95\udada\udfa4\udb20\udf83\udba0\udf10\ud856\udd6d", "\u62ad\u44dc\u0780\u231d\u2748\ud4b0\u36fd\u8e66\u950c\u2e95\u460e\u87a0\u865b\u8884\u7223\u184c\ud715\u837f", "\uda96\ude81\ud835\udd18\udb79\ude4f\ud9b1\udcbf\udbc7\udd1a",
        33, 35435, 2102299928, 1295342196630314917L, -11554L, true, true, (char) 63800, (char) 29404,
        Double.longBitsToDouble(0x3fd0f7ca55794854L), Double.longBitsToDouble(0x3fe345391e4439d9L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:\000 |this=com.fasterxml.jackson.databind.node.POJONode:\000\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:\000\012",
        Z.run(T, 2, 6, 10, 8, "\000", "", "\ud981\ude32",
        24, 45669, 1906257173, -4016647917653812434L, 71470L, true, false, (char) 37278, (char) 6346,
        Double.longBitsToDouble(0x3fd7b9eaca60f662L), Double.longBitsToDouble(0x3fe29f5329a85f11L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:\udac2\ude7a\000\udb24\udd5a\uda2f\udc3e |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\000\udb24\udd5a\uda2f\udc3e\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\000\udb24\udd5a\uda2f\udc3e\012",
        Z.run(T, 2, 6, 10, 8, "\udac2\ude7a\000\udb24\udd5a\uda2f\udc3e", "\u71b5\ub061\u8ded\u29a4\ub106\u7cac\ub4cb\ubdb4\ub8e3\u62b0\uc77d\u7395\u4300\u36d0\ua923\u1fa8\ucf5a\ua2e6\u737f\u2302\u4dd6\uc443\ud464\ub2ba\ud3ff\u6014\ud5cc\u6ad5\u10a9\u7cb2\u3b03\u5547", "\udab3\ude68\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\uda8b\udef4\udbad\ude95\ud94f\udc49",
        25, 64090, 75, 3698862667614047022L, -100000L, false, false, (char) 42782, (char) 56984,
        Double.longBitsToDouble(0x3fd34a0848732722L), Double.longBitsToDouble(0x3fe00002ae2cd736L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:\udac2\ude7a\000u\uda2f\udc3e |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\000u\uda2f\udc3e\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\000u\uda2f\udc3e\012",
        Z.run(T, 2, 6, 10, 8, "\udac2\ude7a\000u\uda2f\udc3e", "\u71b5\u07ca\u43bf\u29a4\u15d8\u7cac\ub4cb\u9ec0\ub8e3\u62b0\uc77d\u7395\u4300\u36d0\ua923\u1fa8\ucf5a\ua2e6\u737f\u2302\u4e8cO\ud464\ub2ba\ud3ff\u08c5\ud5cc\u6ad5\u10a9\u7cb2\u3b03\ua8d5", "\udab3\ude68\udb05\udfc7\u00f8\ud9e4\udf7a\uda8b\udef4\udbad\ude95\ud94f\udc49",
        25, 64090, 1176714571, 3699139199083399982L, -13474L, true, false, (char) 42782, (char) 56984,
        Double.longBitsToDouble(0x3fd00a0848732722L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.node.POJONode:\udab2\udc7a\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.node.POJONode:\udab2\udc7a\012",
        Z.run(T, 2, 2, 2, 8, "\udab2\udc7a", "\u56cc", "\uda77\udf04\ud98f\udf82\ud9ea\ude63\u125d\udaf4\udfcc",
        26, 53418, 1854376, 3657077639168714250L, 16016L, true, false, (char) 57528, (char) 1537,
        Double.longBitsToDouble(0x3fd4f3cd71483710L), Double.longBitsToDouble(0x3fecb0bdfff952a0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 4, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\uc8e5\u7673\ud30c\ud727\u2d6e\ub106\u7cac\ub4cb\uce61\ub8e3\u62b0\uc77d\u7395\u4300\u36d0\u4cf3\u1fa8\u5cc9\u0584\u737f\u6b47\u9d9d\uc443\uc121\uc0f9\ud3ff\u08c5\ud5cc\u6ad5\u10a9", "\uda47\udebf\uda19\udda6\ud8b4\udf3a\ud87f\udf9e",
        48, 66192, 705608062, -8661021660254210962L, 83086L, false, false, (char) 29612, (char) 8960,
        Double.longBitsToDouble(0x3fb1260f171e06d0L), Double.longBitsToDouble(0x3fe3b9e85246d84aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:null\0121=java.lang.Double:0.4053945654263499 |this=com.fasterxml.jackson.databind.node.POJONode:null\012",
        Z.run(T, 2, 2, 3, 4, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\uc8e5\u7673\u07ca\u7fce\u2d6e\ub106\u7cac\u15cc\u7b0c\ub8e3\u62b0\uc77d\u5251\u42ee\u36d0\ub5e2\u1fa8\u5cc9\u0584\u737f\u65ad\u439f\u587b\uc121\uc0f9\ud3ff\u08c5\u3007\u6a6d\u10a9", "\uda47\udebf\udae7\udcec\uda7a\udf07\uda16\udc91",
        37, 66192, 1966324094, -8661021930837150610L, -97142L, false, true, (char) 25173, (char) 30425,
        Double.longBitsToDouble(0x3fd9f1fc0c1ede16L), Double.longBitsToDouble(0x3fdfe21ae81a42c4L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.String:\000\000\000 |this=com.fasterxml.jackson.databind.node.POJONode:\000\000\000\0121=java.lang.Double:0.47835763253360586 |this=com.fasterxml.jackson.databind.node.POJONode:\000\000\000\012",
        Z.run(T, 2, 6, 3, 4, "\000\000\000", "\uc8e5\u7673\u07ca\u7fce\u2948\ub106\u7cac\ub4cb\u73c9\ub8e3\u62b0\uc77d\u7395\000", "\ud80a\udc4c",
        28, 21062, -1309024263, 670948352150289590L, 92884L, false, false, (char) 24677, (char) 14690,
        Double.longBitsToDouble(0x3fde9d6954e18650L), Double.longBitsToDouble(0x3fc40d1815e61a20L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.POJONode:\u1231\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 11, "\u1231", "\u24a6\u3115\uc8e5\u7673\u07ca\u7fce\u2948\ub106\u7cac\ub4cb\u73c9\ub212\u0434\ua535\u5d19\u4300\u36d0\ua923\u1fa8\u5cc9\u0584\u737f\u1f54\u5820\ucfe4\u8630\ucb43\ua510\u36c4", "\ud989\udd68\ud899\ude31\u3ec7\u78f7\ud873\udd4d\ud835\udf78\ud91d\ude48\udb9c\udc8d\udbd0\udd03\ud99c\ude1b\udaae\udca5\udbea\uddeb\udaa8\udee4\ud8e6\udf71\udbda\udcc6\ud9b2\udda6\ud9a7\uddf7\ud868\udf1e\udb0e\udc62\ud91f\ude8e\udbd4\udc79\uda30\udc0e\uda23\udfd7\udad7\udec6\ud96a\udcc3\ud92c\ude08\udbc7\udfe7\ud999\udd8c\ud961\udcc8\udbcb\udcea\ud95c\ude58\ud927\udfa0",
        38, 97379, 714683884, 1711359654061237745L, -71512L, true, false, (char) 52262, (char) 44249,
        Double.longBitsToDouble(0x3fcdd24b0e5ead30L), Double.longBitsToDouble(0x3fedb1279328b9a6L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String:null |this=com.fasterxml.jackson.databind.node.POJONode:null\0121=java.lang.String:null |this=com.fasterxml.jackson.databind.node.POJONode:null\012",
        Z.run(T, 2, 6, 6, 4, "\udaaa\udd29\uda03\udce4", "\u3047\uc8e5\uadf7", "\ud82a\udc0f\udaf1\udf72\ud825\udcc6\udbb3\udf7e\uda2a\udfb3\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud826\udfea",
        27, 67552, -2086192101, 8394706519714542290L, 22873L, true, true, (char) 11956, (char) 19010,
        Double.longBitsToDouble(0x3fd1cbcbade9ca0aL), Double.longBitsToDouble(0x3f94e6b53b72f300L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String:\uda91\udc87\uda03\udca1\udb24\udd5a\uda2f\udc3e\uda5e\udc96\ud9e9\udf6a\udb80\uddf6\ud98f\udf77\udb14\uddb9\ud82a\udc9b\udaf1\udf72\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud826\udfea\ud8e9\udfed\uda90\udec0\udba8\ude9f\uda68\udf5d\ud8ec\udddd\uda1c\udc74\ud88b\ude1b\ud8fe\udc75\ud972\udc07\udb7a\udc8c\000\000\uda2a\udd76\ud889\udf6a\udb0a\ude2c\u899e\udada\udd69\udb39\udd96\udab2\udda1\udabd\uddd2\udbcd\udd57\ud81f\udf3f\ud87f\udf9e\udb05\udfc7\udbb4\udef8\000\000 |this=com.fasterxml.jackson.databind.node.POJONode:\uda91\udc87\uda03\udca1\udb24\udd5a\uda2f\udc3e\uda5e\udc96\ud9e9\udf6a\udb80\uddf6\ud98f\udf77\udb14\uddb9\ud82a\udc9b\udaf1\udf72\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud826\udfea\ud8e9\udfed\uda90\udec0\udba8\ude9f\uda68\udf5d\ud8ec\udddd\uda1c\udc74\ud88b\ude1b\ud8fe\udc75\ud972\udc07\udb7a\udc8c\000\000\uda2a\udd76\ud889\udf6a\udb0a\ude2c\u899e\udada\udd69\udb39\udd96\udab2\udda1\udabd\uddd2\udbcd\udd57\ud81f\udf3f\ud87f\udf9e\udb05\udfc7\udbb4\udef8\000\000\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 3, "\uda91\udc87\uda03\udca1\udb24\udd5a\uda2f\udc3e\uda5e\udc96\ud9e9\udf6a\udb80\uddf6\ud98f\udf77\udb14\uddb9\ud82a\udc9b\udaf1\udf72\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud826\udfea\ud8e9\udfed\uda90\udec0\udba8\ude9f\uda68\udf5d\ud8ec\udddd\uda1c\udc74\ud88b\ude1b\ud8fe\udc75\ud972\udc07\udb7a\udc8c\000\000\uda2a\udd76\ud889\udf6a\udb0a\ude2c\u899e\udada\udd69\udb39\udd96\udab2\udda1\udabd\uddd2\udbcd\udd57\ud81f\udf3f\ud87f\udf9e\udb05\udfc7\udbb4\udef8\000\000", "\uc922\u5297", "",
        -5, 56423, 2093568510, 1889262480312387343L, -74862L, false, false, (char) 38804, (char) 34968,
        Double.longBitsToDouble(0x3fe47c29fd7719bfL), Double.longBitsToDouble(0x3fbeb368dc994f70L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\uda2f\udc3e\uda5e\udc96\ud9e9\udf6a\udb80\uddf6\uda6f\udfc6\udb2f\udcec\ud819\udd68\ud861\udf37\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud826\udfea\ud8e9\udfed\uda5a\udd03\udaf2\ude3b\uda19\udd43\ud8fa\udc4e\uda1c\udc74\ud88b\ude1b\ud8fe\udc75\ud9fa\udccb\udb7a\udd15\uda22\udd49\u81e9\uda11\udd7d\ud889\udf6a\udb0a\ude2c\u899e\udada\udd69\udb39\udd96\udab2\udda1\udabd\uddd2\udbcd\udd57\udb3b\udfbd\ud8ad\udf7f\uda61\udc53\udb83\udda6\ud814\udfbf\ud93d\udf3f\0121=null |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\uda2f\udc3e\uda5e\udc96\ud9e9\udf6a\udb80\uddf6\uda6f\udfc6\udb2f\udcec\ud819\udd68\ud861\udf37\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud826\udfea\ud8e9\udfed\uda5a\udd03\udaf2\ude3b\uda19\udd43\ud8fa\udc4e\uda1c\udc74\ud88b\ude1b\ud8fe\udc75\ud9fa\udccb\udb7a\udd15\uda22\udd49\u81e9\uda11\udd7d\ud889\udf6a\udb0a\ude2c\u899e\udada\udd69\udb39\udd96\udab2\udda1\udabd\uddd2\udbcd\udd57\udb3b\udfbd\ud8ad\udf7f\uda61\udc53\udb83\udda6\ud814\udfbf\ud93d\udf3f\012",
        Z.run(T, 2, 9, 9, 3, "\udac2\ude7a\uda03\udca1\udb24\udd5a\uda2f\udc3e\uda5e\udc96\ud9e9\udf6a\udb80\uddf6\uda6f\udfc6\udb2f\udcec\ud819\udd68\ud861\udf37\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud826\udfea\ud8e9\udfed\uda5a\udd03\udaf2\ude3b\uda19\udd43\ud8fa\udc4e\uda1c\udc74\ud88b\ude1b\ud8fe\udc75\ud9fa\udccb\udb7a\udd15\uda22\udd49\u81e9\uda11\udd7d\ud889\udf6a\udb0a\ude2c\u899e\udada\udd69\udb39\udd96\udab2\udda1\udabd\uddd2\udbcd\udd57\udb3b\udfbd\ud8ad\udf7f\uda61\udc53\udb83\udda6\ud814\udfbf\ud93d\udf3f", "\uc922\u64aa\u1e0d\ub8d7\u425e\u2c24\ud5bc\u194a\u70d4\u93b1\u1a53\u5fb6\uce7c\ucd8c\uc203\ucdaa\u4513\u29c7\ua44a\u1c4b", "\udbe6\udfea\uda61\udea9\udbbc\udc26\udb89\udcd1\udb97\ude19\ud9e7\udc5b\udb26\udf9b\udaee\udd75\uda86\ude3f\udb49\udf1e\u2ae5\ud9a5\udc67\udb18\udc0a\u1eed\ud8fc\udf86\ud9b7\udc77\uda47\udfaf",
        32, 79034, -2002269648, 8926323860454792800L, 70384L, false, true, (char) 26772, (char) 12413,
        Double.longBitsToDouble(0x3fe52d448372319dL), Double.longBitsToDouble(0x3fe4abe24bb7f9caL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Double:0.37149088969973965 |this=com.fasterxml.jackson.databind.node.POJONode:null\0121=java.lang.Double:0.37149088969973965 |this=com.fasterxml.jackson.databind.node.POJONode:null\012",
        Z.run(T, 2, 3, 3, 3, "\ud92f\udc69\ud82a\udc20\udb24\udd4f\uda2f\udc3e\uda5e\udc96\uda82\uddd2\udaaa\udd04\ud879\udd76\ud9ea\udf15\udb85\udfdc\udaf1\udfa9\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda41\udcbd", "\u36d0\ua923\u1fa8\u5cc9\ua1da\u737a\uaa1e\u36a4\u7111", "\uda2a\udd76\ud9da\udd51\u3ff4",
        31, 55727, 99183574, -6969082727696242659L, -93087L, true, false, (char) 34222, (char) 29800,
        Double.longBitsToDouble(0x3fd7c681b9816dc6L), Double.longBitsToDouble(0x3fc357c9f60fe3d0L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.node.POJONode:\000\uda03\udc96\udb24\udd5a\uda2f\udc0f\udaa1\uddb2\ud99b\udc53\000\000\udb8d\udf06\ud82a\udc0f\udaf1\udf72\ud876\uddd5\udb47\ude66\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 0, 0, "\000\uda03\udc96\udb24\udd5a\uda2f\udc0f\udaa1\uddb2\ud99b\udc53\000\000\udb8d\udf06\ud82a\udc0f\udaf1\udf72\ud876\uddd5\udb47\ude66", "\u5b5a\u9b56\u741a\u4300\u36d0\ua923\u1f00\u5cc9", "\ud9c6\udc85\ud8fa\ude2a\udbe3\udf8f\uda4a\uddfb\ud838\udd0e\uda73\udecb\ud889\udecd\ud8ce\udff4\udbd0\uddcd\udaac\ude5a\ud91d\udf40",
        15, 19701, 553685687, 2017822084341109852L, -84392L, false, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd131ee02357662L), Double.longBitsToDouble(0x3fdbade47a976c00L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.node.POJONode:\ud849\uddf6\uda03\udcd2\uda34\udde2\uda2f\udc9b\udaa1\uddb2\ud87d\ude05\ud85d\udf1f\ud969\udf39\udb8d\udf06\ue016\udaf1\udf72\ud883\udcd5\udb47\ude66\uda62\udd1a\ud988\udd7b\udbae\uddd3\ud987\udf02\ud827\udc6f\ud8e9\udfed\uda9d\udfc0\0121=new com.fasterxml.jackson.databind.node.POJONode:\ud849\uddf6\uda03\udcd2\uda34\udde2\uda2f\udc9b\udaa1\uddb2\ud87d\ude05\ud85d\udf1f\ud969\udf39\udb8d\udf06\ue016\udaf1\udf72\ud883\udcd5\udb47\ude66\uda62\udd1a\ud988\udd7b\udbae\uddd3\ud987\udf02\ud827\udc6f\ud8e9\udfed\uda9d\udfc0\012",
        Z.run(T, 2, 15, 15, 10, "\ud849\uddf6\uda03\udcd2\uda34\udde2\uda2f\udc9b\udaa1\uddb2\ud87d\ude05\ud85d\udf1f\ud969\udf39\udb8d\udf06\ue016\udaf1\udf72\ud883\udcd5\udb47\ude66\uda62\udd1a\ud988\udd7b\udbae\uddd3\ud987\udf02\ud827\udc6f\ud8e9\udfed\uda9d\udfc0", "\u5c43\u0584\u737f", "\udbe7\udc30\udb50\udf2c\ud861\udc45\udb82\udcac",
        0, 68109, 1771003936, 7893688002320150905L, 98933L, true, false, (char) 57466, (char) 12604,
        Double.longBitsToDouble(0x3fec9568bcf8fe8aL), Double.longBitsToDouble(0x3fd7e6b98c14541cL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.node.POJONode:null\0121=java.lang.String:null |this=com.fasterxml.jackson.databind.node.POJONode:null\012",
        Z.run(T, 2, 15, 14, 4, "\ud9cb\udf9a\uda03\udcd2\udb24\udd5a\uda2f\udc0f\udaa1\uddb2\ud87d\ude05\ud85d\udf1f\ud969\udf39\u1b1b\ud913\ude95\udb72\udc2f\ud802\ude7f\ud9dd\ude9c", "\u7d6d\u9b56\u741a\u4300\u36d0\ua923\u1fa8\u5cc9\u0584\u737f\u2302", "\udb90\udefb\ud838\udd0e",
        17, 44118, -1511018173, 5697886019677586406L, -44768L, true, true, (char) 55249, (char) 38182,
        Double.longBitsToDouble(0x3fefdcdbbb92adaeL), Double.longBitsToDouble(0x3fcf08ee05f9ae60L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.String:\udac2\ude7a\uda03\udca1\udb24\udd5a |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\0121=java.lang.String:\udac2\ude7a\uda03\udca1\udb24\udd5a |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\012",
        Z.run(T, 2, 7, 7, 4, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\uc8e5\u7673\u9487\u7fc5\u2991\ub106\u7cac\u57be\u9329\ub8e3\u62b0\uc77d\u7395\u4300\ud40a\ua923\u1fa8\u5cc9\u3e48\u559a\u12bd\ud187\uc443\uc121\uc0f9\ud3ff\u08c5\ud5cc\u6c9b\u10a9", "\uda47\udebf\udae7\udcec\udbc2\udf8d\uda30\ude40",
        48, 66192, 705608191, -8661022373218782098L, -79802L, false, true, (char) 21509, (char) 16804,
        Double.longBitsToDouble(0x3fe9719aae86b016L), Double.longBitsToDouble(0x3fdfe21ae46ef992L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.node.POJONode:null\0121=null |this=com.fasterxml.jackson.databind.node.POJONode:null\012",
        Z.run(T, 2, 15, 7, 8, "\udac2\ude7a\uda03\udca1\ud9e2\udd9a", "\uc8e5\u7673\uc7e1\u2ce9\u0c86\ua72b\ua4c8\uaa79\u9329\ub8e3\u62b0\ud2b9\uc7de\u4300\u07e5", "\ud8ec\ude0a\uda2a\udd38\udb84\udf5f",
        17, 22093, -1195221937, -4322171808255764748L, 53125L, true, true, (char) 54680, (char) 59765,
        Double.longBitsToDouble(0x3fd2a8688f816a30L), Double.longBitsToDouble(0x3fcefdd00bb0790cL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Integer:18 |this=com.fasterxml.jackson.databind.node.POJONode:\udb7b\udc77\uda03\udcc7\udb24\udd5a\0121=java.lang.Integer:18 |this=com.fasterxml.jackson.databind.node.POJONode:\udb7b\udc77\uda03\udcc7\udb24\udd5a\012",
        Z.run(T, 2, 4, 4, 4, "\udb7b\udc77\uda03\udcc7\udb24\udd5a", "\u2f37", "\ud9ea\ude63\ud82a\udc0f",
        18, 94466, 1508991538, 7964485125967037L, 37861L, false, true, (char) 46264, (char) 57528,
        Double.longBitsToDouble(0x3fe8dc56d6a8f0d7L), Double.longBitsToDouble(0x3fc4837aee585fecL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.String:\udb23\udf31\000\000\uda2f\udc3e\uda5e\udc96\uda82\uddd2\udaaa\udd04\ud98f\udf82\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud998\udd8d\uda42\udc8e\udb36\udeb3\ud916\ude36\ud80a\udc4c\ud8ec\ude0a\uda1c\udc74\udb84\udf5f\ud9c6\udc85\ud972\udc07\ud848\udc54\udbd7\udf84\ud98b\udd76\uda2a\udd76\ud9a3\udf97\ud83e\ude53p\000\udbaa\udf95\u96b8\u00f7\000\ud885\udca2\ud87f\udf9e\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\uda8b\udef4\udbad\ude95\u684f\000\udb98\udd4b\ud856\udd6d\ud9cd\ude87\uda40\udf34\000\000\ud933\udc2f |this=com.fasterxml.jackson.databind.node.POJONode:\udb23\udf31\000\000\uda2f\udc3e\uda5e\udc96\uda82\uddd2\udaaa\udd04\ud98f\udf82\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud998\udd8d\uda42\udc8e\udb36\udeb3\ud916\ude36\ud80a\udc4c\ud8ec\ude0a\uda1c\udc74\udb84\udf5f\ud9c6\udc85\ud972\udc07\ud848\udc54\udbd7\udf84\ud98b\udd76\uda2a\udd76\ud9a3\udf97\ud83e\ude53p\000\udbaa\udf95\u96b8\u00f7\000\ud885\udca2\ud87f\udf9e\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\uda8b\udef4\udbad\ude95\u684f\000\udb98\udd4b\ud856\udd6d\ud9cd\ude87\uda40\udf34\000\000\ud933\udc2f\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 4, "\udb23\udf31\000\000\uda2f\udc3e\uda5e\udc96\uda82\uddd2\udaaa\udd04\ud98f\udf82\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud998\udd8d\uda42\udc8e\udb36\udeb3\ud916\ude36\ud80a\udc4c\ud8ec\ude0a\uda1c\udc74\udb84\udf5f\ud9c6\udc85\ud972\udc07\ud848\udc54\udbd7\udf84\ud98b\udd76\uda2a\udd76\ud9a3\udf97\ud83e\ude53p\000\udbaa\udf95\u96b8\u00f7\000\ud885\udca2\ud87f\udf9e\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\uda8b\udef4\udbad\ude95\u684f\000\udb98\udd4b\ud856\udd6d\ud9cd\ude87\uda40\udf34\000\000\ud933\udc2f", "\u9502\u368c\u965a\u127f\u8cdc\u5a82\ucd5c\u597d\u59ba", "\ud82b\udf0e\ud941\udead\uda82\ude1c\udbc6\ude6f",
        53, 38489, -904806810, 4344636091929018493L, -30630L, false, true, (char) 48379, (char) 38152,
        Double.longBitsToDouble(0x3fd761044c9f49acL), Double.longBitsToDouble(0x3fc6fb315b25f83cL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:null\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:null\012",
        Z.run(T, 2, 2, 2, 2, "\udac2\ude7a", "\u5325", "\udaaa\udd04\ud98f\udf82\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud825\udcc6",
        23, 35376, 851479741, -7012977587031775877L, 44813L, false, true, (char) 1526, (char) 61311,
        Double.longBitsToDouble(0x3fda41bd772c2f7eL), Double.longBitsToDouble(0x3fefca9507f9b1f9L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.String:\udac2\ude83\ud96f\udef7\\\uda57\ude8a\udb67\udfe5\udae9\udd5e\udaaa\udd95\ud98f\udf82\ud9ea\ude63\uda6d\udf16\ud8af\udf3e\000\udabf\udd3e |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude83\ud96f\udef7\\\uda57\ude8a\udb67\udfe5\udae9\udd5e\udaaa\udd95\ud98f\udf82\ud9ea\ude63\uda6d\udf16\ud8af\udf3e\000\udabf\udd3e\012",
        Z.run(T, 1, 6, 1, 1, "\udac2\ude83\ud96f\udef7\\\uda57\ude8a\udb67\udfe5\udae9\udd5e\udaaa\udd95\ud98f\udf82\ud9ea\ude63\uda6d\udf16\ud8af\udf3e\000\udabf\udd3e", "\u0ac7", "\uca53\uda90\udec0\u7b1b\ud8ba\udf0a",
        3, 21062, -1594040327, -1810318535908738775L, 58575L, true, true, (char) 62202, (char) 22740,
        Double.longBitsToDouble(0x3fee2a6bf38aa051L), Double.longBitsToDouble(0x3fe14a9189bf7b56L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\ud8b0\udd56\015\0121=null |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\ud8b0\udd56\015\012",
        Z.run(T, 2, 4, 9, 15, "\udac2\ude7a\ud8b0\udd56\015", "", "\ud96b\udcde\ud9ea\ude63\ud82a\udc0f\udbc0\ude4d\udaec\udecb\uda8b\udde4\uda96\udfa7\uda9f\udfba\uee0a\uda07\udfbd\ud8b4\udff1\uca53\ud6b3\u07b9\ud837\udf49",
        4, 5926, -717103111, -6454100863376357274L, 72048L, false, true, (char) 58008, (char) 48552,
        Double.longBitsToDouble(0x3fd734dd29f0d9a2L), Double.longBitsToDouble(0x3fe7f4fcf14ecb95L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Integer:-1452401853 |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\ud9dc\ude0d\000\uda2f\udc3e\uda5e\udc96\udacc\ude17\000\ud98f\udf82\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud836\udfc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\udbbf\udd7d\ud826\udfea\ud990\udcc5\udb8c\udec9\ud916\ude36\ud837\udf49\u78a4\000\udb84\udf5f\ud9c6\udc85\ud8bf\ude8e\ud848\udc54\udbd7\udf84\ud98b\udd76\udbb3\uddf3\uda99\udf79\ud83e\udd7b\u899e\u38a0\000\u95f8\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e\udaed\udcc7\ud8b1\ude57\ud9e4\udff8\uda54\udcea\ud9f7\udfe5\udb68\udf54\ud8f3\udf1d\udba0\udf10\ud856\udd6d\0121=java.lang.String:\udac2\ude7a\ud9dc\ude0d\000\uda2f\udc3e\uda5e\udc96\udacc\ude17\000\ud98f\udf82\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud836\udfc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\udbbf\udd7d\ud826\udfea\ud990\udcc5\udb8c\udec9\ud916\ude36\ud837\udf49\u78a4\000\udb84\udf5f\ud9c6\udc85\ud8bf\ude8e\ud848\udc54\udbd7\udf84\ud98b\udd76\udbb3\uddf3\uda99\udf79\ud83e\udd7b\u899e\u38a0\000\u95f8\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e\udaed\udcc7\ud8b1\ude57\ud9e4\udff8\uda54\udcea\ud9f7\udfe5\udb68\udf54\ud8f3\udf1d\udba0\udf10\ud856\udd6d |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\ud9dc\ude0d\000\uda2f\udc3e\uda5e\udc96\udacc\ude17\000\ud98f\udf82\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud836\udfc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\udbbf\udd7d\ud826\udfea\ud990\udcc5\udb8c\udec9\ud916\ude36\ud837\udf49\u78a4\000\udb84\udf5f\ud9c6\udc85\ud8bf\ude8e\ud848\udc54\udbd7\udf84\ud98b\udd76\udbb3\uddf3\uda99\udf79\ud83e\udd7b\u899e\u38a0\000\u95f8\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e\udaed\udcc7\ud8b1\ude57\ud9e4\udff8\uda54\udcea\ud9f7\udfe5\udb68\udf54\ud8f3\udf1d\udba0\udf10\ud856\udd6d\012",
        Z.run(T, 2, 13, 7, 4, "\udac2\ude7a\ud9dc\ude0d\000\uda2f\udc3e\uda5e\udc96\udacc\ude17\000\ud98f\udf82\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud836\udfc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\udbbf\udd7d\ud826\udfea\ud990\udcc5\udb8c\udec9\ud916\ude36\ud837\udf49\u78a4\000\udb84\udf5f\ud9c6\udc85\ud8bf\ude8e\ud848\udc54\udbd7\udf84\ud98b\udd76\udbb3\uddf3\uda99\udf79\ud83e\udd7b\u899e\u38a0\000\u95f8\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e\udaed\udcc7\ud8b1\ude57\ud9e4\udff8\uda54\udcea\ud9f7\udfe5\udb68\udf54\ud8f3\udf1d\udba0\udf10\ud856\udd6d", "\uc6a4", "\uda0e\udf9d\udbf5\udccb",
        22, 65574, 1521778856, 8225546955435112630L, -71128L, false, false, (char) 38326, (char) 15649,
        Double.longBitsToDouble(0x3fc4db0b6d065134L), Double.longBitsToDouble(0x3fef7e1a748e494fL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:null\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:null\012",
        Z.run(T, 2, 10, 10, 10, "\udac2\ude75\ud855\ude13\udb24\udd80\uda3b\udc3e", "\u71b5\u07ca\u81d8\u2948\u0452\uaefc\u99e7\u9ec0\ub8e3\u62b0\uc77d\u7395\u40eb\u36d0\ua923\u1fa8\ucf5a\ua2e6\u737f\u4d1e\u309c\uafe0\u0ec3\ub2ba\ud3ff\u17e2\ub1ad\ud41e\u04de\uc7aa\u086e\ua8d5", "\udab3\ude68\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\uda8b\udef4\udbad\ude95\ud94f\udc49",
        25, 64090, 874724683, 2382908450526344939L, 51264L, true, true, (char) 64507, (char) 56984,
        Double.longBitsToDouble(0x3fd34a0848732722L), Double.longBitsToDouble(0x3fe5f73aae2cd736L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.String:\000\000\000\000\udb67\udddc\ud96b\udf32\ud9a6\udfc5\ud924\udfdc\uda92\udea7\ub582\ud9f4\udf34\ud825\udcc6\udbb3\udf7e\ud87e\udd35\uda9f\udfba\ud878\udc49\udb48\ude21\udae9\udd2a\ud840\udeeb\ud815\udedd\ud8f8\udc6b\ud865\uddf6\udace\udf29\uba56\ud961\udcd2\udb94\udcad\ud979\udf46\udb0a\udc87\udb97\udd32\udab3\udd80\udb25\udc9a\udb2d\udf38\udb29\uded3\ud997\ude3c\udbf1\udf80\uca89\ud942\udc53\udbf4\udfa7\uda4f\udc9c\udbd5\uddfb\udb1d\uddfc\udae1\udda6\ud81c\uddde\udb1a\udfa2\ud982\udeca\udab6\udceb |this=com.fasterxml.jackson.databind.node.POJONode:\000\000\000\000\udb67\udddc\ud96b\udf32\ud9a6\udfc5\ud924\udfdc\uda92\udea7\ub582\ud9f4\udf34\ud825\udcc6\udbb3\udf7e\ud87e\udd35\uda9f\udfba\ud878\udc49\udb48\ude21\udae9\udd2a\ud840\udeeb\ud815\udedd\ud8f8\udc6b\ud865\uddf6\udace\udf29\uba56\ud961\udcd2\udb94\udcad\ud979\udf46\udb0a\udc87\udb97\udd32\udab3\udd80\udb25\udc9a\udb2d\udf38\udb29\uded3\ud997\ude3c\udbf1\udf80\uca89\ud942\udc53\udbf4\udfa7\uda4f\udc9c\udbd5\uddfb\udb1d\uddfc\udae1\udda6\ud81c\uddde\udb1a\udfa2\ud982\udeca\udab6\udceb\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:\000\000\000\000\udb67\udddc\ud96b\udf32\ud9a6\udfc5\ud924\udfdc\uda92\udea7\ub582\ud9f4\udf34\ud825\udcc6\udbb3\udf7e\ud87e\udd35\uda9f\udfba\ud878\udc49\udb48\ude21\udae9\udd2a\ud840\udeeb\ud815\udedd\ud8f8\udc6b\ud865\uddf6\udace\udf29\uba56\ud961\udcd2\udb94\udcad\ud979\udf46\udb0a\udc87\udb97\udd32\udab3\udd80\udb25\udc9a\udb2d\udf38\udb29\uded3\ud997\ude3c\udbf1\udf80\uca89\ud942\udc53\udbf4\udfa7\uda4f\udc9c\udbd5\uddfb\udb1d\uddfc\udae1\udda6\ud81c\uddde\udb1a\udfa2\ud982\udeca\udab6\udceb\012",
        Z.run(T, 2, 6, 10, 8, "\000\000\000\000\udb67\udddc\ud96b\udf32\ud9a6\udfc5\ud924\udfdc\uda92\udea7\ub582\ud9f4\udf34\ud825\udcc6\udbb3\udf7e\ud87e\udd35\uda9f\udfba\ud878\udc49\udb48\ude21\udae9\udd2a\ud840\udeeb\ud815\udedd\ud8f8\udc6b\ud865\uddf6\udace\udf29\uba56\ud961\udcd2\udb94\udcad\ud979\udf46\udb0a\udc87\udb97\udd32\udab3\udd80\udb25\udc9a\udb2d\udf38\udb29\uded3\ud997\ude3c\udbf1\udf80\uca89\ud942\udc53\udbf4\udfa7\uda4f\udc9c\udbd5\uddfb\udb1d\uddfc\udae1\udda6\ud81c\uddde\udb1a\udfa2\ud982\udeca\udab6\udceb", "\u109a\u7d34\ud3fe\u4120\u0799\u5dc6\u5d51\u03df\u6d19\ud432\u101e\u0d78\u046e\u9b17\u03dc", "\u35bc",
        10, 74361, -375879512, 4842464691814636533L, -51212L, false, false, (char) 60011, (char) 60020,
        Double.longBitsToDouble(0x3fd848eb4a4ebe70L), Double.longBitsToDouble(0x3fe25074a1c0c45aL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.node.POJONode:\ud849\uddf6\uda03\udcd2\uda34\udde2\u00ab\000\ud87d\uddba\ud85d\udf1f\000\udb8d\udeabX\000\000\udb47\uddc59\ud959\udd8c\ubf94\ud987\ude87\ud827\udc6f\000\uda9d\udf18\0121=new com.fasterxml.jackson.databind.node.POJONode:\ud849\uddf6\uda03\udcd2\uda34\udde2\u00ab\000\ud87d\uddba\ud85d\udf1f\000\udb8d\udeabX\000\000\udb47\uddc59\ud959\udd8c\ubf94\ud987\ude87\ud827\udc6f\000\uda9d\udf18\012",
        Z.run(T, 2, 15, 15, 10, "\ud849\uddf6\uda03\udcd2\uda34\udde2\u00ab\000\ud87d\uddba\ud85d\udf1f\000\udb8d\udeabX\000\000\udb47\uddc59\ud959\udd8c\ubf94\ud987\ude87\ud827\udc6f\000\uda9d\udf18", "\ubc42", "\ud9c6\udc85\udb92\udec4\udbcd\udcc6\udb50\udf2c\ud861\udc45\udb82\udcac\u6306\ud934\uddfa\uda0b\ude58\udaac\uddde\ud91d\udf40",
        30, 19701, 570200759, 2080872479124296796L, 22378L, false, false, (char) 6951, (char) 34401,
        Double.longBitsToDouble(0x3feecbbfacbfe35bL), Double.longBitsToDouble(0x3fc38fb764874930L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.node.POJONode:\000\000\uda34\udde2\uda2f\udc9b\udaa1\uddb2\ud87d\ude05\ud85d\udf1f\ud969\udf39\ud25b\000\000\ud8ae\udd57\udabf\udda2\000\000\ud9f2\ude39\ud987\udf02\ud827\udc6f\ud8e9\udfed\uda9d\udfc0\0121=new com.fasterxml.jackson.databind.node.POJONode:\000\000\uda34\udde2\uda2f\udc9b\udaa1\uddb2\ud87d\ude05\ud85d\udf1f\ud969\udf39\ud25b\000\000\ud8ae\udd57\udabf\udda2\000\000\ud9f2\ude39\ud987\udf02\ud827\udc6f\ud8e9\udfed\uda9d\udfc0\012",
        Z.run(T, 2, 15, 15, 10, "\000\000\uda34\udde2\uda2f\udc9b\udaa1\uddb2\ud87d\ude05\ud85d\udf1f\ud969\udf39\ud25b\000\000\ud8ae\udd57\udabf\udda2\000\000\ud9f2\ude39\ud987\udf02\ud827\udc6f\ud8e9\udfed\uda9d\udfc0", "\ubc24\u0584\000", "\udbe7\udc30\udb50\udf2c\ud861\udc45\udb82\udcac",
        55, 55752, 1771003936, 7893688000675983737L, 98933L, true, false, (char) 57466, (char) 12380,
        Double.longBitsToDouble(0x3fec9568bcf8fe00L), Double.longBitsToDouble(0x3ec30028a8380000L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.POJONode:\udb23\udf31\000\000\uda2f\udc3e\uda5e\udc96\uda82\uddd2\udaaa\udd04\ud924\udead\ud9ea\udf08\ud82a\udc0f\udaf1\udf72\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud998\udd8d\uda42\udc8e\udb36\udee9\ud916\ude36\ud80a\udc4c\ud8ec\ude0a\uda1c\udc74\udb84\udf5f\ud9c6\udc85\ud972\udc07\ud848\udc54\udbd7\udf84\ud98b\udd76\uda2a\udd76\ud9a3\udf97\ud83e\ude53p\000\udbaa\udf95\u96b8\u00f7\000\ud885\udca2\ud880\udc0d\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\uda8b\udef4\udbad\ude95\u684f\000\udb98\udd4b\ud856\udd6d\ud9cd\ude87\uda40\udf34\000\000\ud933\udc2f\0121=com.fasterxml.jackson.databind.node.JsonNodeType:POJO |this=com.fasterxml.jackson.databind.node.POJONode:\udb23\udf31\000\000\uda2f\udc3e\uda5e\udc96\uda82\uddd2\udaaa\udd04\ud924\udead\ud9ea\udf08\ud82a\udc0f\udaf1\udf72\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud998\udd8d\uda42\udc8e\udb36\udee9\ud916\ude36\ud80a\udc4c\ud8ec\ude0a\uda1c\udc74\udb84\udf5f\ud9c6\udc85\ud972\udc07\ud848\udc54\udbd7\udf84\ud98b\udd76\uda2a\udd76\ud9a3\udf97\ud83e\ude53p\000\udbaa\udf95\u96b8\u00f7\000\ud885\udca2\ud880\udc0d\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\uda8b\udef4\udbad\ude95\u684f\000\udb98\udd4b\ud856\udd6d\ud9cd\ude87\uda40\udf34\000\000\ud933\udc2f\012",
        Z.run(T, 2, 9, 11, 4, "\udb23\udf31\000\000\uda2f\udc3e\uda5e\udc96\uda82\uddd2\udaaa\udd04\ud924\udead\ud9ea\udf08\ud82a\udc0f\udaf1\udf72\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda41\udcbd\ud998\udd8d\uda42\udc8e\udb36\udee9\ud916\ude36\ud80a\udc4c\ud8ec\ude0a\uda1c\udc74\udb84\udf5f\ud9c6\udc85\ud972\udc07\ud848\udc54\udbd7\udf84\ud98b\udd76\uda2a\udd76\ud9a3\udf97\ud83e\ude53p\000\udbaa\udf95\u96b8\u00f7\000\ud885\udca2\ud880\udc0d\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\uda8b\udef4\udbad\ude95\u684f\000\udb98\udd4b\ud856\udd6d\ud9cd\ude87\uda40\udf34\000\000\ud933\udc2f", "\u9502\u368c\u965a\u127f\u8cdc\u499f\ucd5c\u597d\u59ba", "\ud82b\udf0e\ud941\udead\uda82\ude1c\udaa6\udc47",
        27, 38489, -904806810, 4344636091929018493L, -30630L, false, true, (char) 48379, (char) 38152,
        Double.longBitsToDouble(0x3fd761044c9f49acL), Double.longBitsToDouble(0x3fc6fb315b25f83cL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Integer:-429700726 |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\ud9dc\ude0d\000\uda2f\udc3e\uda5e\udc96\udacc\ude17\000\udb19\udf2c\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud836\udfc62\000\000\000\udbbf\udd7d\ud826\udfea\ud990\udcc5\udb8c\udec9\ud916\ude36\ud837\udf49\u78a4\000\udb84\udf5f\ud9c6\udc85\ud8bf\ude8e\ud87a\udc4d\000\udaef\ude77\udbb3\uddf3\uda99\udf79\ud83e\udd7b\u899e\u38a0\000\u95f8\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e\udaed\udcc7\ud8b1\ude57\ud9e4\udff8\uda54\udcea\ud9f7\udfe5\udb68\udf54\ud8f3\udf1d\udb6e\ude10\ud856\udd6d\0121=java.lang.String:\udac2\ude7a\ud9dc\ude0d\000\uda2f\udc3e\uda5e\udc96\udacc\ude17\000\udb19\udf2c\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud836\udfc62\000\000\000\udbbf\udd7d\ud826\udfea\ud990\udcc5\udb8c\udec9\ud916\ude36\ud837\udf49\u78a4\000\udb84\udf5f\ud9c6\udc85\ud8bf\ude8e\ud87a\udc4d\000\udaef\ude77\udbb3\uddf3\uda99\udf79\ud83e\udd7b\u899e\u38a0\000\u95f8\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e\udaed\udcc7\ud8b1\ude57\ud9e4\udff8\uda54\udcea\ud9f7\udfe5\udb68\udf54\ud8f3\udf1d\udb6e\ude10\ud856\udd6d |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\ud9dc\ude0d\000\uda2f\udc3e\uda5e\udc96\udacc\ude17\000\udb19\udf2c\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud836\udfc62\000\000\000\udbbf\udd7d\ud826\udfea\ud990\udcc5\udb8c\udec9\ud916\ude36\ud837\udf49\u78a4\000\udb84\udf5f\ud9c6\udc85\ud8bf\ude8e\ud87a\udc4d\000\udaef\ude77\udbb3\uddf3\uda99\udf79\ud83e\udd7b\u899e\u38a0\000\u95f8\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e\udaed\udcc7\ud8b1\ude57\ud9e4\udff8\uda54\udcea\ud9f7\udfe5\udb68\udf54\ud8f3\udf1d\udb6e\ude10\ud856\udd6d\012",
        Z.run(T, 2, 13, 7, 4, "\udac2\ude7a\ud9dc\ude0d\000\uda2f\udc3e\uda5e\udc96\udacc\ude17\000\udb19\udf2c\ud9ea\ude63\ud82a\udc0f\udaf1\udf72\ud836\udfc62\000\000\000\udbbf\udd7d\ud826\udfea\ud990\udcc5\udb8c\udec9\ud916\ude36\ud837\udf49\u78a4\000\udb84\udf5f\ud9c6\udc85\ud8bf\ude8e\ud87a\udc4d\000\udaef\ude77\udbb3\uddf3\uda99\udf79\ud83e\udd7b\u899e\u38a0\000\u95f8\uda47\udebf\udae7\udcec\ud8b4\udf21\ud87f\udf9e\udaed\udcc7\ud8b1\ude57\ud9e4\udff8\uda54\udcea\ud9f7\udfe5\udb68\udf54\ud8f3\udf1d\udb6e\ude10\ud856\udd6d", "\uc62e", "\uda0e\udf9d\uba49",
        -5, -1000, 1521745920, 8225546955435112630L, -71128L, false, false, (char) 38326, (char) 15649,
        Double.longBitsToDouble(0x3fc4db0b6c000000L), Double.longBitsToDouble(0x3fef7e1a748e494fL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.String:\udac2\ude7a\uda03\udca1\udb24\udd5a |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\0121=java.lang.Integer:7 |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb24\udd5a\012",
        Z.run(T, 2, 6, 4, 4, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\uc8e5\u7673\u07ca\u7fce\u2948\ub106\u7cac\ub4cb\u73c9\ub8e3\u62b0\uc77d\u7395\u4300\u36d0\ua923\u1fa8\u5cc9\u0584\u737f\u2302\u4e8c\uc443\uc121\uc0f9\ud3ff\u08c5\ud5cc\u6ad5\u8437", "\uda47\udebf",
        7, 38303, -1390996351, 5147723854605991160L, 22378L, false, false, (char) 36068, (char) 27866,
        Double.longBitsToDouble(0x3fdbade47a962d74L), Double.longBitsToDouble(0x3fec0a311b2e3355L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.POJONode:null\0121=null |this=com.fasterxml.jackson.databind.node.POJONode:null\012",
        Z.run(T, 2, 7, 7, 4, "\udac2\ude7a\uda03\udca1\udb24\udd5a", "\uc8e5\u7673\u9487\u7fc5\u2991\ub106\u7cac\u57be\u9329\ub8e3\u62b0\uc77d\u7395\u4300\ud40a\ua923\u1fa8\u5cc9\u3e48\u6e99\u12bd\ucf75\u75a9\uc121\uc0f9\u0d93\u4bcb\ud5cc\u295a\u10e1", "\uda47\udebf\udae7\udcec\udbc2\udf8d\uda30\ude40",
        48, 66192, 207600127, 9044684836561056878L, -79802L, false, true, (char) 21509, (char) 16804,
        Double.longBitsToDouble(0x3fe9719aae86b016L), Double.longBitsToDouble(0x3fdfe21ae46ef992L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.POJONode:\udb23\udf31\000\000\uda2e\udff0\uda5e\udc96\uda82\uddd2\udaaa\udd04\ud924\udead\ud9ea\udf08\ud82a\udc0f\udaf1\udf72\udbd4\udf7d\udabf\udd3e\uda96\udfa9\uda9f\udfba\000\000\ud998\udd5d\uda42\udc8e\udb36\udee9\ud916\ude36\ud80a\udc4c\ud8ec\ude0a\uda1c\udc74\u00f9\000\ud972\udc07\ud848\udc54\000\000\ud9f4\uddda\000\000\000\000\udbaa\udf95\u96b8\u00f7\000\udbe9\udc94\u14f0\udb05\udf35\000\000\uda8b\udeea\udb2f\udc76\000\000\000\000\ud80a\udf05\uda0e\udc06\000\000\ud933\udc2f\0121=com.fasterxml.jackson.databind.node.JsonNodeType:POJO |this=com.fasterxml.jackson.databind.node.POJONode:\udb23\udf31\000\000\uda2e\udff0\uda5e\udc96\uda82\uddd2\udaaa\udd04\ud924\udead\ud9ea\udf08\ud82a\udc0f\udaf1\udf72\udbd4\udf7d\udabf\udd3e\uda96\udfa9\uda9f\udfba\000\000\ud998\udd5d\uda42\udc8e\udb36\udee9\ud916\ude36\ud80a\udc4c\ud8ec\ude0a\uda1c\udc74\u00f9\000\ud972\udc07\ud848\udc54\000\000\ud9f4\uddda\000\000\000\000\udbaa\udf95\u96b8\u00f7\000\udbe9\udc94\u14f0\udb05\udf35\000\000\uda8b\udeea\udb2f\udc76\000\000\000\000\ud80a\udf05\uda0e\udc06\000\000\ud933\udc2f\012",
        Z.run(T, 2, 9, 11, 4, "\udb23\udf31\000\000\uda2e\udff0\uda5e\udc96\uda82\uddd2\udaaa\udd04\ud924\udead\ud9ea\udf08\ud82a\udc0f\udaf1\udf72\udbd4\udf7d\udabf\udd3e\uda96\udfa9\uda9f\udfba\000\000\ud998\udd5d\uda42\udc8e\udb36\udee9\ud916\ude36\ud80a\udc4c\ud8ec\ude0a\uda1c\udc74\u00f9\000\ud972\udc07\ud848\udc54\000\000\ud9f4\uddda\000\000\000\000\udbaa\udf95\u96b8\u00f7\000\udbe9\udc94\u14f0\udb05\udf35\000\000\uda8b\udeea\udb2f\udc76\000\000\000\000\ud80a\udf05\uda0e\udc06\000\000\ud933\udc2f", "\u9502\u368c\u963c\u127f\u8cdc\u499f\ucd5c\u597d\u59ba", "\ud82b\udf0e",
        40, 61241, -466308629, -5528662134398018559L, -50722L, true, false, (char) 26030, (char) 173,
        Double.longBitsToDouble(0x3fe39c0ee1068964L), Double.longBitsToDouble(0x3fea845850004cc4L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.POJONode:\udb23\udf31\000\000\uda2e\udff0\uda5e\udc96\uda82\uddd2\udaaa\udcd7\ud924\udead\ud9ea\udf08\ud82a\udc0f\udaf1\udf72\000\000\000\ud926\udef2\000\000\ud998\udd5d\uda42\udc8e\udb36\udee9\ud916\ude36\ud80a\udc4c\ud8ec\ude0a\uda1c\udc74\u00f9\000\ud972\udc07\ud848\udc54\000\000\ud9f4\uddda\000\000\000\000\udbaa\udf95\u96b8\u00f7\000\udbe9\udc94\u14f0\udb05\udf35\000\000\uda8b\udeea\udb2f\udc76\000\000\000\000\ud80a\udf05\000\000\000\ud933\udc2f\0121=com.fasterxml.jackson.databind.node.JsonNodeType:POJO |this=com.fasterxml.jackson.databind.node.POJONode:\udb23\udf31\000\000\uda2e\udff0\uda5e\udc96\uda82\uddd2\udaaa\udcd7\ud924\udead\ud9ea\udf08\ud82a\udc0f\udaf1\udf72\000\000\000\ud926\udef2\000\000\ud998\udd5d\uda42\udc8e\udb36\udee9\ud916\ude36\ud80a\udc4c\ud8ec\ude0a\uda1c\udc74\u00f9\000\ud972\udc07\ud848\udc54\000\000\ud9f4\uddda\000\000\000\000\udbaa\udf95\u96b8\u00f7\000\udbe9\udc94\u14f0\udb05\udf35\000\000\uda8b\udeea\udb2f\udc76\000\000\000\000\ud80a\udf05\000\000\000\ud933\udc2f\012",
        Z.run(T, 2, 9, 11, 4, "\udb23\udf31\000\000\uda2e\udff0\uda5e\udc96\uda82\uddd2\udaaa\udcd7\ud924\udead\ud9ea\udf08\ud82a\udc0f\udaf1\udf72\000\000\000\ud926\udef2\000\000\ud998\udd5d\uda42\udc8e\udb36\udee9\ud916\ude36\ud80a\udc4c\ud8ec\ude0a\uda1c\udc74\u00f9\000\ud972\udc07\ud848\udc54\000\000\ud9f4\uddda\000\000\000\000\udbaa\udf95\u96b8\u00f7\000\udbe9\udc94\u14f0\udb05\udf35\000\000\uda8b\udeea\udb2f\udc76\000\000\000\000\ud80a\udf05\000\000\000\ud933\udc2f", "\u9502\u368c\u963c\u127f\u8cdc\u499f\ucd5c\ubd6a\000", "",
        24, 10350, 262056241, -2002780312684839147L, 47866L, false, true, (char) 31944, (char) 26030,
        Double.longBitsToDouble(0x3ec5b80003700000L), Double.longBitsToDouble(0x3fd068964ea11614L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.POJONode:\udb23\udf31\000\000\ud965\udf0c\uda5e\udc96\uda82\uddd2\000\000\000\ud867\udcb3\udaf1\udf72\000\000\000\ud926\udef2\000\000\ud998\udd5d\uda42\udc8e\udb36\udee9\ud916\ude36\ud80a\udc4c\ud8ec\ude0a\uda1c\udc74\u00f9\000\ud972\udc07\ud848\udc54\000\000\ud9f4\uddda\000\000\000\000\udbaa\udf95\u00c0\000\000\000\000\udb05\udf35\000\000\uda54\udcea\udb2f\udc76\000\000\000\000\ud800\udf00\000\000\000\ud933\udc2f\0121=com.fasterxml.jackson.databind.node.JsonNodeType:POJO |this=com.fasterxml.jackson.databind.node.POJONode:\udb23\udf31\000\000\ud965\udf0c\uda5e\udc96\uda82\uddd2\000\000\000\ud867\udcb3\udaf1\udf72\000\000\000\ud926\udef2\000\000\ud998\udd5d\uda42\udc8e\udb36\udee9\ud916\ude36\ud80a\udc4c\ud8ec\ude0a\uda1c\udc74\u00f9\000\ud972\udc07\ud848\udc54\000\000\ud9f4\uddda\000\000\000\000\udbaa\udf95\u00c0\000\000\000\000\udb05\udf35\000\000\uda54\udcea\udb2f\udc76\000\000\000\000\ud800\udf00\000\000\000\ud933\udc2f\012",
        Z.run(T, 2, 9, 11, 4, "\udb23\udf31\000\000\ud965\udf0c\uda5e\udc96\uda82\uddd2\000\000\000\ud867\udcb3\udaf1\udf72\000\000\000\ud926\udef2\000\000\ud998\udd5d\uda42\udc8e\udb36\udee9\ud916\ude36\ud80a\udc4c\ud8ec\ude0a\uda1c\udc74\u00f9\000\ud972\udc07\ud848\udc54\000\000\ud9f4\uddda\000\000\000\000\udbaa\udf95\u00c0\000\000\000\000\udb05\udf35\000\000\uda54\udcea\udb2f\udc76\000\000\000\000\ud800\udf00\000\000\000\ud933\udc2f", "\u9502\u364c\u963c\u60ec\u00fd\u499f\ucd5c\ubd6a\000", "",
        24, 10350, 262056241, 1008025468928L, 47866L, false, true, (char) 31944, (char) 26030,
        Double.longBitsToDouble(0x3e48000000000000L), Double.longBitsToDouble(0x3fd060000ea11614L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb17\udc5a\uda2f\udc3e\udb37\udca3\ud9f4\udf55\udaaa\udd4d\ud98f\udf82\ud860\udd63\ud815\ude05\udbed\udc2f\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda5b\udc7a\udb6a\udc4a\ud8e9\udfed\uda90\udec0\ud916\ude36\ud80a\udc4c\ud9a5\udc07\ud8e2\ude90\ud85f\udedb\udb2d\udf75\ud962\udcde\ud848\udc54\udbd7\udf84\ud81d\udd5f\uda34\udee4\ud83d\udc16\ud832\udc0b\ud807\udc9e\ud9bc\udd77\udbe6\udd0e\u96b8\uda47\udebf\udae3\udecb\ud9d3\uddc9\ud9f8\udc08\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\ud90d\udfd4\udbad\ude8f\ud94f\udc49\ud8dc\ude98\ub535\ud856\udddd\ud9cd\ude87\ud987\ude78\ud86e\udc82\uda2f\ude91\ud869\ude85\udb77\udf22\uda16\uddb1\u24ac\ud956\udc0b\uda21\udd18\ud9f3\ude3f\udbd1\udf7b\ud98c\udc17\ud91f\udf0f\uda67\udff0\udb86\ude20\udbe4\udc42\ud934\uddf9\ud8c8\ude7d\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.node.POJONode:\udac2\ude7a\uda03\udca1\udb17\udc5a\uda2f\udc3e\udb37\udca3\ud9f4\udf55\udaaa\udd4d\ud98f\udf82\ud860\udd63\ud815\ude05\udbed\udc2f\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda5b\udc7a\udb6a\udc4a\ud8e9\udfed\uda90\udec0\ud916\ude36\ud80a\udc4c\ud9a5\udc07\ud8e2\ude90\ud85f\udedb\udb2d\udf75\ud962\udcde\ud848\udc54\udbd7\udf84\ud81d\udd5f\uda34\udee4\ud83d\udc16\ud832\udc0b\ud807\udc9e\ud9bc\udd77\udbe6\udd0e\u96b8\uda47\udebf\udae3\udecb\ud9d3\uddc9\ud9f8\udc08\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\ud90d\udfd4\udbad\ude8f\ud94f\udc49\ud8dc\ude98\ub535\ud856\udddd\ud9cd\ude87\ud987\ude78\ud86e\udc82\uda2f\ude91\ud869\ude85\udb77\udf22\uda16\uddb1\u24ac\ud956\udc0b\uda21\udd18\ud9f3\ude3f\udbd1\udf7b\ud98c\udc17\ud91f\udf0f\uda67\udff0\udb86\ude20\udbe4\udc42\ud934\uddf9\ud8c8\ude7d\012",
        Z.run(T, 2, 10, 10, 13, "\udac2\ude7a\uda03\udca1\udb17\udc5a\uda2f\udc3e\udb37\udca3\ud9f4\udf55\udaaa\udd4d\ud98f\udf82\ud860\udd63\ud815\ude05\udbed\udc2f\ud825\udcc6\udbb3\udf7e\uda96\udfa9\uda9f\udfba\udac0\udc4d\uda5b\udc7a\udb6a\udc4a\ud8e9\udfed\uda90\udec0\ud916\ude36\ud80a\udc4c\ud9a5\udc07\ud8e2\ude90\ud85f\udedb\udb2d\udf75\ud962\udcde\ud848\udc54\udbd7\udf84\ud81d\udd5f\uda34\udee4\ud83d\udc16\ud832\udc0b\ud807\udc9e\ud9bc\udd77\udbe6\udd0e\u96b8\uda47\udebf\udae3\udecb\ud9d3\uddc9\ud9f8\udc08\udb05\udfc7\ud8c0\udf4f\ud9e4\udff8\ud90d\udfd4\udbad\ude8f\ud94f\udc49\ud8dc\ude98\ub535\ud856\udddd\ud9cd\ude87\ud987\ude78\ud86e\udc82\uda2f\ude91\ud869\ude85\udb77\udf22\uda16\uddb1\u24ac\ud956\udc0b\uda21\udd18\ud9f3\ude3f\udbd1\udf7b\ud98c\udc17\ud91f\udf0f\uda67\udff0\udb86\ude20\udbe4\udc42\ud934\uddf9\ud8c8\ude7d", "\u92f1\u7c00\u20f4\u6ec8\ua4e0\u07ba\u5df2\ube37\uc72c\u1661\u1d56\uc87c", "\ud903\udc3f\udb77\udf64\ud884\ude0f\uda5f\udf92\u158e\ud515\uda3f\udfd2\uda3a\udd57\uda1c\udd12\ud915\ude72\udbca\udc24\udab6\udfa2\ud8b8\uded5\udbc7\uddfe",
        23, 76029, 12552718, 8562763325948456331L, 43571L, true, true, (char) 56495, (char) 64137,
        Double.longBitsToDouble(0x3fe3b883d4f30cebL), Double.longBitsToDouble(0x3fe9cd64e18d38a4L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.POJONode:\000\000\000\000\000\uda61\udd70\udaaa\udcd7\ud924\udead\ud9ea\udf08\ud829\udfb7\udaf1\udf72\000\000\000\ud926\udef2\000\000\000\uda42\udc8e\udb36\udee9\udab8\udf27\000\000\000\000\000\000\ud848\udc05\000\000\ud9f4\uddda\000\000\000\000\udbaa\udf95\u96b8\u00f7\000\udbe9\udc94\000\udb05\udf35\000\000\000\000\000\000\000\000\ud80a\udf05\000\000\000\ud933\udc2f\0121=com.fasterxml.jackson.databind.node.JsonNodeType:POJO |this=com.fasterxml.jackson.databind.node.POJONode:\000\000\000\000\000\uda61\udd70\udaaa\udcd7\ud924\udead\ud9ea\udf08\ud829\udfb7\udaf1\udf72\000\000\000\ud926\udef2\000\000\000\uda42\udc8e\udb36\udee9\udab8\udf27\000\000\000\000\000\000\ud848\udc05\000\000\ud9f4\uddda\000\000\000\000\udbaa\udf95\u96b8\u00f7\000\udbe9\udc94\000\udb05\udf35\000\000\000\000\000\000\000\000\ud80a\udf05\000\000\000\ud933\udc2f\012",
        Z.run(T, 2, 9, 11, 4, "\000\000\000\000\000\uda61\udd70\udaaa\udcd7\ud924\udead\ud9ea\udf08\ud829\udfb7\udaf1\udf72\000\000\000\ud926\udef2\000\000\000\uda42\udc8e\udb36\udee9\udab8\udf27\000\000\000\000\000\000\ud848\udc05\000\000\ud9f4\uddda\000\000\000\000\udbaa\udf95\u96b8\u00f7\000\udbe9\udc94\000\udb05\udf35\000\000\000\000\000\000\000\000\ud80a\udf05\000\000\000\ud933\udc2f", "\u9502\u368c\u3560\u127f\u8cdc\u499f\ucd5c\ubd6a\000", "",
        47, 7712, 262056241, -2002780312684839147L, 14278L, false, true, (char) 31944, (char) 26030,
        Double.longBitsToDouble(0x3ec5b80003700000L), Double.longBitsToDouble(0x3fd068964ea11614L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.node.POJONode:\ud8ef\udf37\000\000\ud817\udc45\ud9bd\udebb\ud889\ude5b\udaaa\udcd7\ud924\udead\ud8d6\udf99\udacc\udd1e\ud9d2\udfd5\000\udb02\udf7b;\ud926\udef2\ud8cb\uddb4\u0091\ud998\udd5d\uda42\udc8e\udb36\udee9\ud916\ude36\ud80a\udc4c\ud902\udf95\udb2f\udc7b\177\000\ud972\udc07\ud8fc\udec3\u4bd7\000\ud9f4\uddda\000i\000\000\udbaa\udf95\u96b8\udbb5\ude31\udb7b\ude7e\udab3\udff3\u14d4\udb05\udf35x\000\udbae\ude7e\ud9c4\udef0\uf06e\ud9e1\udfd8\udaa8\udc4d\udb39\udf98\ud96e\udecb\ud87b\udcd3\000\udb01\ude5a\udacc\udeea\0121=com.fasterxml.jackson.databind.node.JsonNodeType:POJO |this=com.fasterxml.jackson.databind.node.POJONode:\ud8ef\udf37\000\000\ud817\udc45\ud9bd\udebb\ud889\ude5b\udaaa\udcd7\ud924\udead\ud8d6\udf99\udacc\udd1e\ud9d2\udfd5\000\udb02\udf7b;\ud926\udef2\ud8cb\uddb4\u0091\ud998\udd5d\uda42\udc8e\udb36\udee9\ud916\ude36\ud80a\udc4c\ud902\udf95\udb2f\udc7b\177\000\ud972\udc07\ud8fc\udec3\u4bd7\000\ud9f4\uddda\000i\000\000\udbaa\udf95\u96b8\udbb5\ude31\udb7b\ude7e\udab3\udff3\u14d4\udb05\udf35x\000\udbae\ude7e\ud9c4\udef0\uf06e\ud9e1\udfd8\udaa8\udc4d\udb39\udf98\ud96e\udecb\ud87b\udcd3\000\udb01\ude5a\udacc\udeea\012",
        Z.run(T, 2, 9, 11, 4, "\ud8ef\udf37\000\000\ud817\udc45\ud9bd\udebb\ud889\ude5b\udaaa\udcd7\ud924\udead\ud8d6\udf99\udacc\udd1e\ud9d2\udfd5\000\udb02\udf7b;\ud926\udef2\ud8cb\uddb4\u0091\ud998\udd5d\uda42\udc8e\udb36\udee9\ud916\ude36\ud80a\udc4c\ud902\udf95\udb2f\udc7b\177\000\ud972\udc07\ud8fc\udec3\u4bd7\000\ud9f4\uddda\000i\000\000\udbaa\udf95\u96b8\udbb5\ude31\udb7b\ude7e\udab3\udff3\u14d4\udb05\udf35x\000\udbae\ude7e\ud9c4\udef0\uf06e\ud9e1\udfd8\udaa8\udc4d\udb39\udf98\ud96e\udecb\ud87b\udcd3\000\udb01\ude5a\udacc\udeea", "\uc3e6\u2d10\u1251\u127f\u8cdc", "\uda78\udf4e\ud8c4\uddbd\ud136\000\ud82b\udf0e\ud941\udead\uda82\ude1c\udaa6\udc47",
        27, 38489, -904806810, 4344636091929018493L, -100000L, false, false, (char) 710, (char) 40137,
        Double.longBitsToDouble(0x3feb738fcdc6c5d1L), Double.longBitsToDouble(0x3fea687f21df902cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.node.POJONode|serialize|com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.node.POJONode:java.lang.Object",
    "M|com.fasterxml.jackson.databind.node.POJONode|_pojoEquals|com.fasterxml.jackson.databind.node.POJONode|new:com.fasterxml.jackson.databind.node.POJONode:java.lang.Object",
    "M|com.fasterxml.jackson.databind.node.POJONode|asBoolean|boolean|new:com.fasterxml.jackson.databind.node.POJONode:java.lang.Object",
    "M|com.fasterxml.jackson.databind.node.POJONode|asDouble|double|new:com.fasterxml.jackson.databind.node.POJONode:java.lang.Object",
    "M|com.fasterxml.jackson.databind.node.POJONode|asInt|int|new:com.fasterxml.jackson.databind.node.POJONode:java.lang.Object",
    "M|com.fasterxml.jackson.databind.node.POJONode|asLong|long|new:com.fasterxml.jackson.databind.node.POJONode:java.lang.Object",
    "M|com.fasterxml.jackson.databind.node.POJONode|asText||new:com.fasterxml.jackson.databind.node.POJONode:java.lang.Object",
    "M|com.fasterxml.jackson.databind.node.POJONode|asText|java.lang.String|new:com.fasterxml.jackson.databind.node.POJONode:java.lang.Object",
    "M|com.fasterxml.jackson.databind.node.POJONode|asToken||new:com.fasterxml.jackson.databind.node.POJONode:java.lang.Object",
    "M|com.fasterxml.jackson.databind.node.POJONode|binaryValue||new:com.fasterxml.jackson.databind.node.POJONode:java.lang.Object",
    "M|com.fasterxml.jackson.databind.node.POJONode|equals|java.lang.Object|new:com.fasterxml.jackson.databind.node.POJONode:java.lang.Object",
    "M|com.fasterxml.jackson.databind.node.POJONode|getNodeType||new:com.fasterxml.jackson.databind.node.POJONode:java.lang.Object",
    "M|com.fasterxml.jackson.databind.node.POJONode|getPojo||new:com.fasterxml.jackson.databind.node.POJONode:java.lang.Object",
    "M|com.fasterxml.jackson.databind.node.POJONode|hashCode||new:com.fasterxml.jackson.databind.node.POJONode:java.lang.Object",
    "M|com.fasterxml.jackson.databind.node.POJONode|toString||new:com.fasterxml.jackson.databind.node.POJONode:java.lang.Object",
    "C|com.fasterxml.jackson.databind.node.POJONode|<init>|java.lang.Object",
    "M|com.fasterxml.jackson.databind.node.POJONode|serialize|com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.node.POJONode:java.lang.Object",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
