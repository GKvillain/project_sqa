package com.fasterxml.jackson.databind.introspect;
import org.junit.Test;
import static org.junit.Assert.*;
public class POJOPropertiesCollector_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 6, 0, "\ud957\udd59\udb37\udcd9\uda17\ude1d\ud979\udc45\udb01\ude2e\ud958\udd63\ud8ca\udd30\udaf1\udeb9\ud969\udda8\ud9c7\udd65\ud9ca\udd3e\ud9b6\udfe0\u2048\ud95d\udd17\ud842\udfa5\ud9af\uddc8\uda4f\udeda\udbe4\udf6a\udb52\udf35\udbf0\ude7d\uda9c\ude48\udbb0\udd32\udb89\udcd7\udb41\udff3\ud8c2\udfab\ud885\udd11\udb10\uddce\ud951\udda2\uda27\udced\ud9da\udf22", "\u99d4\ubbb3\u01ac\u5e8b\u4a49\u8c24\u76b5\u036e\u5751\ud59d\ub942\u62f1\uce50\u907a\u5b1e\ub543\u353c\u3090\u851d\u7a86\u1df4\u4244\ud3e4\ub4d0", "\ud9f6\ude11\ud88d\udd15\udb47\udd25\ud857\udf13\ud8d9\uddd3\u7a77\udb52\udc31\ud87d\ude32\ud808\uddcc\ud87a\udde9\uda8b\uddc1\ud9f0\udc4a\ud8b2\udd1f\ud8fc\udc89\ud9e6\udc3c\uda55\udc2a\ud82f\udcf9\udb29\ude8f\uda8a\ude90\uda81\ude85\ud90a\udd5d\udb5a\ude1d\udaf5\udc8d",
        -2, 90038, 85652446, -7833864681357617334L, 36258L, false, true, (char) 16671, (char) 14052,
        Double.longBitsToDouble(0x3fd6a6789e32457eL), Double.longBitsToDouble(0x3fc732d3cbe8f258L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 6, 0, "\ud957\udd59\udb37\udcd9\uda17\ude1d\ud979\udc45\udb01\ude2e\ud958\udd63\ud8ca\udd30\udaf1\udeb9\ud969\udda8\ud9c7\udd65\ud9ca\udd3e\ud9b6\udfe0\u2048\ud95d\udd17\ud842\udfa5\ud9af\uddc8\uda4f\udeda\udbe4\udf6a\udb52\udf35\udbf0\ude7d\uda9c\ude48\udbb0\udd32\udb89\udcd7\udb41\udff3\ud8c2\udfab\ud885\udd11\udb10\uddce\ud951\udda2\uda27\udced\ud9da\udf22", "\u99d4\ubbb3\u01ac\u5e8b\u4a49\u8c24\u760a\u036e\u5751\ud59d\u1529\u7be6\u178a\u9073\u5b1e\ub543\u353c\u3090\u851d\u7a86\u1df4\u4244\ud3e4\ub4d0", "\ud9f6\ude11\ud88d\udd15\udb47\udd25\ud857\udf13\ud8d9\uddd3\u7a77\udb52\udc31\ud87d\ude32\ud808\uddcc\ud87a\udde9\uda8b\uddc1\ud9f0\udc4a\ud8b2\udd1f\ud8fc\udc89\ud9e6\udc3c\uda55\udc2a\ud82f\udcf9\udb29\ude8f\uda8a\ude90\uda81\ude85\ud90a\udd5d\udb5a\ude1d\udaf5\udc8d",
        -2, 90038, 85652446, -7833864681357617334L, -92220L, false, true, (char) 13555, (char) 20952,
        Double.longBitsToDouble(0x3fc732d3ca511258L), Double.longBitsToDouble(0x3fe0b148b2f74df4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 9, 6, "\ud957\udd59\udb37\udcd9\uda17\ude1d\ud979\udc45\udb01\ude2e\ud958\udd63\ud8ca\udd30\udaf1\udeb9\ud969\udda8\ud9c7\udd65\ud9ca\udd3e\ud9b6\udfe0\u2048\ud95d\udd17\ud842\udfa5\ud9af\uddc8\uda4f\udeda\udbe4\udf6a\udb52\udf35\udbf0\ude7d\uda9c\ude48\udbb0\udd32\udb89\udcd7\udb41\udff3\ud8c2\udfab\ud885\udd11\udb10\uddce\ud951\udda2\uda27\udced\ud9da\udf22", "\u99d4\ubbb3\u01ac\u5e8b\u4a49\u8c24\u76b5\u036e\u5751\ud59d\ub942\u62f1\uce50\u907a\u5b1e\ub543\u353c\u3090\u851d\u7a86\u1df4\u4244\ud3e4\ub4d0", "\ud9f6\ude11\ud88d\udd15\udb47\udd25\ud857\udf13\ud8d9\uddd3\u7a77\udb52\udc31\ud87d\ude32\ud808\uddcc\ud87a\udde9\uda8b\uddc1\ud9f0\udc4a\ud8b2\udd1f\ud8fc\udc89\ud9e6\udc3c\uda55\udc2a\ud82f\udcf9\udb29\ude8f\uda8a\ude90\uda81\ude85\ud90a\udd5d\udb5a\ude1d\udb56\udebd",
        0, 77737, 85652446, -7833864681357617334L, 36258L, false, true, (char) 16671, (char) 14052,
        Double.longBitsToDouble(0x3fd6a67894f2457eL), Double.longBitsToDouble(0x3fc1ee30ebe8f258L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 0, "\ud957\udd59\udb37\udcd9\uda17\ude1d\ud979\udc45\udb01\ude2e\ud958\udd63\ud8ca\udd30\udaf1\udeb9\ud969\udda8\ud9c7\udd65\ud9ca\udd3e\ud9b6\udfe0\u2048\ud95d\udd17\ud842\udfa5\ud9af\uddc8\uda4f\udf3a\udbe4\udf6a\udb52\udf35\udbf0\ude7d\uda9c\ude48\udbb0\udd32\udb89\udcd7\udb41\udff3\ud8c2\udfab\ud878\udca9\udb10\uddce\ud951\udda2\uda27\udced\ud9da\udf22", "\u5817\u7965\ucfe0\ubbc3\u091c\u974c\u9bf2\u036e\u5751\ud59d\ub942\u62f1\uce50\u907a\u5b1e\ub543\u353c\u3090\u851d\u7a86\ubcae\u4244\ubc22\ub4d0", "\ud9f6\ude11\ud88d\udd15\udb47\udd25\ud857\udf13\ud978\udc83\u8994\udb52\udc31\ud87d\ude32\ud808\uddcc\ud87a\udde9\ud9a8\udc51\ud9d5\udd14\ud8b2\udd1f\ud8fc\udc89\ud9e6\udc3c\uda55\udc2a\ud82f\udcf9\udb29\ude8f\uda8a\ude90\uda81\ude85\ud8ca\udd98\ud8a0\udda8\udaf5\udc8d",
        -2, 90038, 85652446, -7833864681357617334L, 36258L, false, true, (char) 16671, (char) 14052,
        Double.longBitsToDouble(0x3fd6a6789e32457eL), Double.longBitsToDouble(0x3fc732d3cbe8f258L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 6, 0, "\ud957\udd59\udb37\udcd9\uda17\ude1d\ud979\udc45\udb01\ude2e\ud958\udd63\ud8ca\udd30\udaf1\udeb9\ud969\udda8\ud9c7\udd65\ud9ca\udd3e\ud9b6\udfe0\u2048\ud95d\udd17\ud842\udfa5\ud9af\uddc8\uda4f\udeda\udbe4\udf6a\udb52\udf35\udbf0\ude7d\uda9c\ude48\udbb0\udd32\udb89\udcd7\udb41\udff3\ud8c2\udfab\ud885\udd11\udb10\uddce\udb64\udfec\udb86\uddcf\ud8d1\udffc", "\u99d4\ubbb3\u01ac\u5e8b\u4a49\u5ffd\u2cec\u3548\u5751\ud59d\ub942\u62f1\uce50\u907a\u5b1e\ub543\u353c\u3090\u851d\u7a86\u1df4\u4244\ud3e4\ub4d0", "\ud9f6\ude11\ud88d\udd15\udb47\udd25\ud857\udf13\ud8d9\uddd3\u7a77\udb52\udc31\ud87d\ude32\ud808\uddcc\ud87a\udde9\uda8b\uddc1\ud9f0\udc4a\ud8b2\udd1f\ud8fc\udc89\ud9e6\udc3c\uda55\udc2a\ud82f\udcf9\udb29\ude8f\uda8a\ude90\uda81\ude85\ud90a\udd5d\udb5a\ude1d\udaf5\udc8d",
        -2, 90038, 85652446, -7833864681357617334L, 36258L, false, true, (char) 16671, (char) 14052,
        Double.longBitsToDouble(0x3fd6a6789e32457eL), Double.longBitsToDouble(0x3fc732d3cbe8f258L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 6, 0, "\ud957\udd59\udb37\udcd9\uda17\ude1d\udb0f\udc10\ud8db\udda9\ud958\udd63\ud8ca\udd30\udaf1\udeb9\ud969\udda8\uda7d\udcff\ud9ca\udd16\ud9b6\udfe0\u2048\ud95d\udd17\ud842\udfa5\ud9af\uddc8\uda4f\udeda\udbe4\udf6a\udb52\udf35\udbf0\ude7d\uda9c\ude48\udbb0\udd32\udb89\udcd7\udb41\udff3\ud8c2\udfab\ud885\udd11\udb10\uddce\ud951\udda2\uda27\udced\ud9da\udf22", "\u99d4\ubbb3\u01ac\u5e8b\u2340\u8c24\u76b5\u036e\u5751\ud59d\ub942\u62f1\uce50\u907a\u5b1e\ub543\u353c\u836e\u7d9b\u7a86\u1df4\u4244\ud3e4\ub4d0", "\ud9f6\ude11\ud88d\udd15\udb47\udd25\ud857\udf13\ud8d9\uddd3\u7a77\udb52\udc31\ud87d\ude32\ud808\uddcc\ud87a\udde9\uda8b\uddc1\ud9f0\udc4a\ud8b2\udd1f\ud8fc\udc89\ud8af\udc20\uda55\udcbf\ud82f\udcf9\udb29\ude8f\uda8a\ude90\uda81\ude85\ud90a\udd5d\udb5a\ude1d\udaf5\udc8d",
        -2, 90038, 85652446, -7833864681357617334L, 36258L, false, true, (char) 16671, (char) 14052,
        Double.longBitsToDouble(0x3fd6a6789e32457eL), Double.longBitsToDouble(0x3fc732d3cbe8f258L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 8, 0, "\ud957\udd59\udb37\udcd9\uda17\ude1d\u00cc\000\ud958\udd63\ud8ca\udd30\udaf1\udeb9\ud969\udda8\ud9c7\udd65\ud9ca\udd3e\u00e1\u2048\ud95d\udd17\ud842\udfa5\ud9af\uddc8\uda4f\udeda\udbe4\udf6a\u00c0\udbf0\ude39\uda9c\ude48\000\000\000\000\u3135\000\000\000\000", "\u99d4", "\udac3\udd83\ud86c\ude2e\ud9d7\udd97",
        4, 90033, -1947854612, -8913722920790917120L, -8141L, true, false, (char) 31932, (char) 219,
        Double.longBitsToDouble(0x3e395eaba0000000L), Double.longBitsToDouble(0x3fd39c7cd0000000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 1, "\ud957\udd59\udb37\udcd9\ud91b\udd00\ud979\udc44\u675a\ud8a7\ude64\u31ff\udaf1\udeb9\ud969\udda8\ud9c7\udd65\ud819\udcda\udba8\udd7b\ua7e4\ud95d\udd17\ud842\udfa5\ud9af\uddc8\uda4f\udeda\udbe4\udf6a\udb52\udf35\ud93c\ude63\ud864\udea0\udb2f\udfc2\udba6\udc2c\udb41\udff3\udbd3\udd60\ud885\uddc0\udb10\uddce\ud951\udda2\uda27\udced\ud9ee\ude42", "\u99d4\ubbb3\u01ac\u5e8b\u4a49\u6623\u76b5\u036e\u5751\ud59d\ub942\u62f1\u0819\ua4c3\u5b1e\ub543\u353c\ub7cd\u1a4f\u5d3e\u6226\uce13\u1db5\ud3bb", "\ud9f6\ude11\ud88d\udd15\udb47\udd25\ud857\udf13\ud8d9\uddd3\uca77\ud8ad\udd9f\ud85b\udd28\ud8c1\udfc8\ud87a\udd7b\uda8b\uddc1\udabc\ude05\uda89\udcbf\udb3d\udd6b\ud89b\uded6\uda6b\udca7\ud82f\udcf9\udb29\ude8f\uda26\uddb6\ud86a\udedf\ud90d\udd52\udb5a\ude1d\ud9e3\ude7c",
        -2, 20113, 85650008, -7833864681357617334L, 36258L, false, true, (char) 16671, (char) 14052,
        Double.longBitsToDouble(0x3fd6a6789e32452aL), Double.longBitsToDouble(0x3fc732d3d178f258L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 1, "\ud957\udd59\udb37\udcd9\ud91b\udd00\ud979\udc44\u675a\ud8a7\ude64\u31ff\udaf1\udeb9\ud969\udda8\ud9c7\udd65\ud819\udcda\udba8\udd7b\ua7e4\ud95d\udd17\ud842\udfa5\ud9af\uddc8\uda4f\udeda\udbe4\udf6a\udb52\udf35\ud93c\ude63\ud864\udea0\udb2f\udfc2\udba6\udc2c\udb41\udff3\udbd3\udd60\ud885\uddc0\udb10\uddce\ud951\udda2\uda27\udced\ud9ee\ude42", "\u99d4\ubbb3\u01ac\u5e8b\u8224\u6623\u76b5\u036e\u7f9d\ud59d\ub942\u62f1\u0819\ua4c3\u5b1e\ub543\u353c\ub7cd\u1a4f\u8a3e\u6226\uce13\u9db4\ud3bb", "\ud9e5\udd38\ud88d\udd15\udb47\udd25\ud857\udf13\udb05\udd29\uca56\ud8ad\udd9f\ud85b\udd28\ud8c1\udfc8\ud87a\udd7b\uda8b\uddc1\udabc\ude05\uda89\udcbf\ud96f\udd64\ud89b\uded6",
        7, 70864, -1824002824, -2232602846666225652L, 14535L, false, true, (char) 57478, (char) 37780,
        Double.longBitsToDouble(0x3fe2c0a7f594051aL), Double.longBitsToDouble(0x3fea549a46e9f133L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 6, 0, "\ud957\udd59\udb37\udcd9\uda17\ude1d\udaef\ude77\udb01\ude2e\ud958\udd63\udaca\udc04\udaf1\ude0c\ud969\udda8\ud9c7\udd65\ud9ca\udd3e\ud9b6\udfe0\u2048\ud95d\udd17\ud842\udfa5\ud9af\uddc8\uda4f\udeda\udbe4\udf6a\udb52\udf35\udbf0\ude7d\uda9c\ude48\udbb0\udd32\udb89\udcd7\udb41\udff3\ud8c2\udfab\ud885\udd11\udb10\uddce\ud951\udda2\uda27\udced\ud9da\udf22", "\u99d4\ubbb3\u01ac\u5e8b\u4a49\u8c24\u76b5\u036e\u5751\ud59d\ub942\u62f1\uce50\u907a\u5b1e\ub543\u353c\u3090\u851d\u7a86\u1df4\u4244\ud3e4\ub4d0", "\ud9f6\ude11\ud88d\udd15\000\ud848\udd64\ud8d9\uddd3\u7a77\udb52\udc31\ud87d\ude32\ud808\uddcc\ud87a\udde9\uda8b\uddc1\ud9f0\udc4a\ud8b2\udd1f\ud8fc\udc89\ud9e6\udc3c\uda55\udc2a\ud82f\udcf9\udb29\ude8f\uda8a\ude90\uda81\ude85\ud90a\udd5d\udb5a\ude1d\udaf5\udc8d",
        -2, 90038, 85652446, -7833864681357617334L, 36258L, false, true, (char) 16671, (char) 14052,
        Double.longBitsToDouble(0x3fd6a6789e32457eL), Double.longBitsToDouble(0x3fc732d3cbe8f258L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector|_removeUnwantedAccessor|java.util.Map|new:com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector:com.fasterxml.jackson.databind.cfg.MapperConfig,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.lang.String",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertyBuilder|removeNonVisible|boolean|new:com.fasterxml.jackson.databind.introspect.POJOPropertyBuilder:com.fasterxml.jackson.databind.introspect.POJOPropertyBuilder,com.fasterxml.jackson.databind.PropertyName",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector|_addCreatorParam|java.util.Map,com.fasterxml.jackson.databind.introspect.AnnotatedParameter|new:com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector:com.fasterxml.jackson.databind.cfg.MapperConfig,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.lang.String",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector|_addCreators|java.util.Map|new:com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector:com.fasterxml.jackson.databind.cfg.MapperConfig,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.lang.String",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector|_addFields|java.util.Map|new:com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector:com.fasterxml.jackson.databind.cfg.MapperConfig,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.lang.String",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector|_addGetterMethod|java.util.Map,com.fasterxml.jackson.databind.introspect.AnnotatedMethod,com.fasterxml.jackson.databind.AnnotationIntrospector|new:com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector:com.fasterxml.jackson.databind.cfg.MapperConfig,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.lang.String",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector|_addInjectables|java.util.Map|new:com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector:com.fasterxml.jackson.databind.cfg.MapperConfig,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.lang.String",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector|_addMethods|java.util.Map|new:com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector:com.fasterxml.jackson.databind.cfg.MapperConfig,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.lang.String",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector|_addSetterMethod|java.util.Map,com.fasterxml.jackson.databind.introspect.AnnotatedMethod,com.fasterxml.jackson.databind.AnnotationIntrospector|new:com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector:com.fasterxml.jackson.databind.cfg.MapperConfig,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.lang.String",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector|_collectIgnorals|java.lang.String|new:com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector:com.fasterxml.jackson.databind.cfg.MapperConfig,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.lang.String",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector|_doAddInjectable|java.lang.Object,com.fasterxml.jackson.databind.introspect.AnnotatedMember|new:com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector:com.fasterxml.jackson.databind.cfg.MapperConfig,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.lang.String",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector|_findNamingStrategy||new:com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector:com.fasterxml.jackson.databind.cfg.MapperConfig,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.lang.String",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector|_propNameFromSimple|java.lang.String|new:com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector:com.fasterxml.jackson.databind.cfg.MapperConfig,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.lang.String",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector|_property|java.util.Map,com.fasterxml.jackson.databind.PropertyName|new:com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector:com.fasterxml.jackson.databind.cfg.MapperConfig,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.lang.String",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector|_property|java.util.Map,java.lang.String|new:com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector:com.fasterxml.jackson.databind.cfg.MapperConfig,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.lang.String",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector|_removeUnwantedProperties|java.util.Map|new:com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector:com.fasterxml.jackson.databind.cfg.MapperConfig,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.lang.String",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector|_removeUnwantedAccessor|java.util.Map|new:com.fasterxml.jackson.databind.introspect.POJOPropertiesCollector:com.fasterxml.jackson.databind.cfg.MapperConfig,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.lang.String",
    "M|com.fasterxml.jackson.databind.introspect.POJOPropertyBuilder|removeNonVisible|boolean|new:com.fasterxml.jackson.databind.introspect.POJOPropertyBuilder:com.fasterxml.jackson.databind.introspect.POJOPropertyBuilder,com.fasterxml.jackson.databind.PropertyName",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
