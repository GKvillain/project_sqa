package com.fasterxml.jackson.databind.ser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberSerializer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 0, "\ud837\udf36\uda08\udcf2\uda74\udc0e\udac2\udd2e\udb59\udc39\udb81\udd66", "\u57c3\u3653\ucd84\u3370\u78ff\ud13a\u28cc\u13f1\ua4d5\u1e1e\u6ba1\u7ea6\u8edc\ua90e\u5c67\u9991\u81ec\u6d8c\ua948\ua9f1\u2bed\u2451\u310b\u59eb\u835c\u8aa5", "\uda26\udf18\ud99d\udee3\udb01\udf07\udb4f\udee3\ud919\ude88\ud9e3\udd65\uda1e\udcd0",
        -4, 79550, -1460925757, -5914797414318947301L, 30218L, true, false, (char) 63851, (char) 52423,
        Double.longBitsToDouble(0x3fe7ffc2216138e3L), Double.longBitsToDouble(0x3fe365a5b3ec3fafL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 0, "\ud837\udeeb\uda08\udcf2\udaee\udf0e", "\ubf6f", "\u39cc\udabd\udd88\uda36\udf2f\u00b9\uda71\udc58\ud91f\udcb3\u6969\017\ud878\ude4d\000\000\uda41\udc5b\ud8a5\udcdf\ud94f\udc15\ud817\udc32\ud97e\uddf6\ud9d2\udf34\udbbb\udcec\ud930\udd08\udb73\udffb\ud935\udcdd\000\udb15\udf6a\u4d67\ud9cd\ude81\udaeb\udd2b",
        21, 59388, -178454528, 116722827159177048L, -100000L, false, false, (char) 15434, (char) 0,
        Double.longBitsToDouble(0x3fe8000002c34845L), Double.longBitsToDouble(0x3f451d906eb7a800L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 0, "\ud837\udf36\uda08\udcf2\uda74\udc0e\udac2\udd2e\udb59\udc39\udb81\udd66", "\u57c3\u3653\ucd84\u3370\u78ff\ud13a\u28cc\u13f1\ua4d5\u1e1e\u6ba1\u7ea6\u8edc\ua90e\u5c67\u9991\u81ec\u6d8c\ua948\ua9f1\u2bed\u2451\u310b\u59eb\u835c\u8aa5", "\uda26\udf18\ud99d\udee3\udb01\udf07\udb4f\udee3\ud919\ude88\ud9e3\udd65\uda1e\udcd0",
        -4, 79550, -1460925757, -5914797414318947301L, 30218L, true, false, (char) 63851, (char) 52423,
        Double.longBitsToDouble(0x3fcfff088585f218L), Double.longBitsToDouble(0x3fe365a5b3ec3fafL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:{\"type\":\"number\"} |this=com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 0, "\ud837\udf36\uda08\udcf2\uda29\udd49\ud945\ude6f\udb59\udc39\udb81\udd66", "\u57c3\u3653\ucd84\u3370\u78ff\ud13a\u28cc\u13f1\ua4d5\u1e1e\u6ba1\u7ea6\u8edc\ua90e\u5c67\u9991\u81ec\u6d8c\ua948\u4a35\u2bed\u2451\u310b\u59eb\u835c\u8aa5", "\uda26\udf18\ud99d\udee3\udb01\udf07\udb4f\udee3\ud919\ude88\ud9e3\udd65\uda1e\udcd0",
        -4, 79550, -1460925757, -5914797414318947301L, 30218L, true, false, (char) 13025, (char) 54498,
        Double.longBitsToDouble(0x3fe7ffc2216138e3L), Double.longBitsToDouble(0x3fe365a5b3ec3fafL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 1, "\ud837\udf36\uda08\udcf2\uda74\udc0e\udac2\udd2e\udb59\udc39\udb81\udd66", "\u57c3\u3653\ucd84\u3370\u78ff\ud13a\u28cc\u13f1\ua4d5\u1e1e\u6ba1\u7ea6\u8edc\ua90e\u5c67", "\udbbb\udcec\ud930\udd08\udb73\udffb\udb99\ude70\uda0e\udefb",
        58, 79966, 421479655, -4767938639563425816L, 5401L, true, false, (char) 35061, (char) 53925,
        Double.longBitsToDouble(0x3fc1ddb842f6673cL), Double.longBitsToDouble(0x3fd3f4f0bbff699aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 0, "\ud837\udf36\uda08\udcf2\uda74\udc0e\udac2\udd2e\udb59\udc39\udb81\udd66", "\u57c3\u3653\ucd84\u3370\ua7ae\u5700\u28cc\u13f1\ua4d5\u1e1e\ud4b5\ud3b8\u8edc\ua90e\u5c67\u9991\u81ec\u6d8c\ua948\ua9f1\u2bed\u2451\u310b\u231c\u835c\ua1e9", "\ud9e0\udee2\ud972\udec2\udb01\udf2a\udb4f\udee3\ud919\ude88\ud9e3\udd65\uda1e\udcd0",
        -4, 79550, -1460925757, -5914797414318947301L, -1526L, false, false, (char) 60361, (char) 52456,
        Double.longBitsToDouble(0x3fe7ffc2216138e3L), Double.longBitsToDouble(0x3fe365a5b3ec3fafL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:{\"type\":\"number\"} |this=com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 0, "\ud837\udf36\uda08\udcf2\uda92\ude0e\udac2\uddd8\udb59\udc39\udb81\udd66", "\u57c3\u3653\ucd84\u3370\u78ff\ud13a\u28cc\u13f1\ua4d5\u1e1e\u6ba1\u7ea6\u8edc\u020f\u5c67\u9991\u81ec\u6d8c\ua948\ua9f1\u2bed\u2451\u310b\u59eb\u835c\u8aa5", "\uda26\udf18\ud99d\udee3\udb01\udf07\udb4f\udee3\ud919\ude88\ud9e3\udd65\uda1e\udcd0",
        -4, 79550, -70685745, 2653679926585898659L, 30218L, true, false, (char) 63851, (char) 52423,
        Double.longBitsToDouble(0x3fe7ffc2216138e3L), Double.longBitsToDouble(0x3fe365a5b3ec3fafL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 0, "\ud837\udf36\uda08\udcf2\uda74\udc0e\ud828\udd74\udbeb\udde3\ud985\uddc2", "\u57c3\u3653\ucd84\u3370\u9fd0\ud13a", "\ud878\ude4d\udabd\udf21\ud971\ude94\uda41\udc5b",
        -3, 89493, 1765044438, -1048825694210594407L, 90095L, false, false, (char) 24864, (char) 48482,
        Double.longBitsToDouble(0x3fcd17ba8c750de4L), Double.longBitsToDouble(0x3fe2ee1eaecbf577L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:{\"type\":\"number\"} |this=com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\0121=new com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\012",
        Z.run(T, 2, 1, 3, 0, "\ud837\udf36\uda08\udcf2\uda74\udc0e\udac2\udd2e\uda46\udcef\ud8b7\udf82", "\u57c3\u3653\ucd84\u3370\u3ead\ud6b1\u28cc\uc060\u635a\u1f40\uc0ec\u7ea6\u8edc\ua90e\u9567\u9991\u317d\u3306\u9ba6\ua9f1\u2bed\u2451\u310b\u59eb\u835c\u8aa5", "\ud8ad\udc11\ud9ba\udec0\udb01\udf07\udb4f\udee3\ud919\ude88\ud88e\udd9c\uda1e\udcd0",
        56, 54541, -1460925757, -5914797414318947301L, 30218L, true, false, (char) 63851, (char) 52423,
        Double.longBitsToDouble(0x3fe7ffc2216138e3L), Double.longBitsToDouble(0x3fe365a5b3ec3fafL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\0121=new com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\012",
        Z.run(T, 2, 3, 3, 2, "\ud837\udeeb\uda08\udcf2\udaee\udf0e", "\ubf6f", "\udbd8\udec9\udabd\udd88\ud936\udd94\u00b9\uda71\udc58\ud91f\udcb3\u6969\017\udb51\udff9\uda37\udf5a\ud9f5\udefe\ud8ac\udf3b\udbd6\udf76\udbcf\udf03\ud817\udc32\ud97e\uddf6\ud944\udd29\ud87e\udf2d\ud930\udd08\ud8f3\udca2\ud853\udcfa\u52c4\udb15\udf6a\u4d67\ud9cd\ude81\udbd1\udf82",
        49, 26188, -178426915, 116722827394058072L, -11500L, false, false, (char) 8944, (char) 40536,
        Double.longBitsToDouble(0x3fe80000dac34845L), Double.longBitsToDouble(0x3fe00547631d4919L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.node.ObjectNode:{\"type\":\"number\"} |this=com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\0121=com.fasterxml.jackson.databind.node.ObjectNode:{\"type\":\"number\"} |this=com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud837\udeeb\uda08\udcf2\udaee\udf0e", "\ubfa1", "\u39cc\udabd\udd88\uda36\udf2f\u00b9\uda71\udc58\ud91f\udcb3\u6969\017\ud878\ude4d\000\000\uda41\udc5b\ud97b\udd68\ud94e\udfd5\ud817\udc32\ud97e\uddf6\ud9d2\udf34\udbbb\udcd0\ud930\udd08\udb73\udffb\ud935\udcdd\000\udb15\udf6a\u4d67\ud9cd\ude81\ud976\udf10",
        38, 59388, -178454528, 116722827162126168L, -100000L, false, false, (char) 17745, (char) 46064,
        Double.longBitsToDouble(0x3fe8000002c34845L), Double.longBitsToDouble(0x3f451d906eb7a800L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\0121=com.fasterxml.jackson.databind.node.ObjectNode:{\"type\":\"number\"} |this=com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\012",
        Z.run(T, 2, 3, 1, 0, "\ud837\udf36\uda08\udcf2\uda74\udc0e\udac2\udd2e\udb59\udc39\udb81\udd66", "\u57c3\u3653\ucd84\u3370\u78ff\ud13a\u28cc\u13f1\ua4d5\u1e1e\u6ba1\u7ea6\u8edc\ua90e\u5c67\u9991\u81ec\u6d8c\ua948\ua9f1\u2bed\u2451\u310b\u59eb\u835c\u8aa5", "\ud822\udc3a\ud99d\udeb7\udb01\udf07\udb4f\udee3\ud919\ude88\ud9e3\udd65\uda1e\udcd0",
        -4, 69566, -1473608612, -5914797414318947301L, 30218L, true, false, (char) 63851, (char) 52423,
        Double.longBitsToDouble(0x3fa6de221617c860L), Double.longBitsToDouble(0x3fe365a5b3ec3fafL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\012",
        Z.run(T, 1, 3, 0, 3, "\ud830\udf69\uda08\udcf2\uda29\udd49\ud945\ude6f\ud924\uddde\uda2d\uddf2", "\u57c3\u3653\ucd84\u7bbc\u7973\ud13a\u28cc\uc30b\u5d32\uc641\u12f1\u1b17\u8edc\u47a5\u2e34\ucd84\uae05\u6d8c\ua948\u4a35\u2bed\u2451\u310b\u59eb\u835c\u8aa5", "\uda26\udf18\ud99d\udee3\udb01\udf07\udb4f\udee3\ud919\ude88\ud9e3\udd65\uda1e\udcd0",
        -4, 79550, -1460925757, -5914797415877732935L, -13302L, true, false, (char) 13025, (char) 54498,
        Double.longBitsToDouble(0x3fe4f7c221618521L), Double.longBitsToDouble(0x3fe365a5b3ecbfafL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.NumberSerializer:@?\012",
        Z.run(T, 1, 3, 2, 0, "\uda3a\udc92\uda08\udcf2\uda92\ude0e\udac2\uddd8\udb59\udc39\udb81\udd66", "\u57c3\u3653\ucd84\u3370\u78ff\ud13a\u28cc\u13f1\ua4d5\u83bf\u6ba1\u1fd6\ub20f\u020f\u5c67\u9991\u81ec\u6d8c\ua948\ua9f1\u2bed\u2451\u310b\u59eb\u05a4\ubd7d", "\uda26\udf18\ud99d\udee3\udb01\udf07\udb4f\udee3\ud919\ude88\ud9e3\udd65\uda1e\udcd0\udb16\udf81\ud90a\udc08\ud99c\udf8f\udb60\udc0c\udb26\udd6a\uda53\uddb2\ud947\udd98\ud9bc\udc66\ud8ae\udf9e\ud930\udcfe\ud8e4\ude59\ud87b\udcf1\udb34\ude2c\ud979\ude64\udb01\udecf\udb3c\udeee\ud89f\udde0\ud89e\udfd2\uda39\udfbc\uda66\ude0b\ud98d\udf51\ud940\udf25",
        7, 1538, 2118265177, -7632560327650808120L, -89194L, true, true, (char) 56982, (char) 566,
        Double.longBitsToDouble(0x3fcb580e48702570L), Double.longBitsToDouble(0x3fe0370fb2e956a2L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 0, "\ud837\udf36\uda08\udcf2\uda74\udc0e\udac2\udd2e\udb59\udc39\udb81\udd66", "\u57c3\u3653\ucd84\u3370\u78ff\ud13a\u28cc\u13f1\ua4d5\u1e1e\u6ba1\u7ea6\ua5db\ua90e\u5c67\u9991\u81ec\u6d8c\ua948\ua9f1\u2bed\u2451\u4fdb\u59eb\u835c\u8aa5", "\uda26\udf18\ud99d\udee3\udb01\udf07\udb4f\udee3\ud919\ude88\ud9e3\udd65\uda1e\udcd0",
        -4, 79550, -1460925757, -5914797414318947301L, 30218L, false, false, (char) 63851, (char) 52423,
        Double.longBitsToDouble(0x3fe7ffc2216138e3L), Double.longBitsToDouble(0x3fe365a5b3ec3fafL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ser.std.NumberSerializer|acceptJsonFormatVisitor|com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ser.std.NumberSerializer:java.lang.Class",
    "M|com.fasterxml.jackson.databind.ser.std.NumberSerializer|getSchema|com.fasterxml.jackson.databind.SerializerProvider,java.lang.reflect.Type|new:com.fasterxml.jackson.databind.ser.std.NumberSerializer:java.lang.Class",
    "M|com.fasterxml.jackson.databind.ser.std.NumberSerializer|serialize|java.lang.Number,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.std.NumberSerializer:java.lang.Class",
    "C|com.fasterxml.jackson.databind.ser.std.NumberSerializer|<init>|java.lang.Class",
    "M|com.fasterxml.jackson.databind.ser.std.NumberSerializer|acceptJsonFormatVisitor|com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ser.std.NumberSerializer:java.lang.Class",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
