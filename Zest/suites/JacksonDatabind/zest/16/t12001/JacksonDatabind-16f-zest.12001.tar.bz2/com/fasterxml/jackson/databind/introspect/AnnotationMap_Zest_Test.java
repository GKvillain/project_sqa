package com.fasterxml.jackson.databind.introspect;
import org.junit.Test;
import static org.junit.Assert.*;
public class AnnotationMap_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\0121=null\012",
        Z.run(T, 2, 3, 5, 5, "\udbfd\udd4c\ud9af\udc45\udb57\udfbe\ud912\udfaa\udbd0\udcd4\ud88c\ude35\udabe\udc4b\udb79\udeca\udbc5\uddba\uda84\uddab", "\u1c31\u2f63", "\ud9d5\udc47\udae4\udfd4\ud81a\udd46\u0d42\udb21\ude9d\ud991\udec3\udb07\udd15\ud885\udd30\udb6d\uddd6\u18bc\udba1\udd86\ud98a\uddcc\u3fa9\ud8d8\udff7\ud80b\udc1e\u7ff8",
        43, 31276, -1001902653, 425997292426383500L, 21167L, true, false, (char) 56173, (char) 40897,
        Double.longBitsToDouble(0x3f87bd82d9d34a00L), Double.longBitsToDouble(0x3f997db993257e80L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\0121=null\012",
        Z.run(T, 2, 3, 5, 5, "\udbfd\udd4c\ud9af\udc45\udb57\udfbe\ud912\udfaa\udbd0\udcd4\ud88c\ude35\udabe\udc4b\udb79\udeca\udbc5\uddba\uda84\uddab", "\u1c31\u2f63", "\ud9d5\udc47\udae4\udfd4\ud81a\udd46\u0d42\udb21\ude9d\ud991\udec3\udb07\udd15\ud885\udd30\udb6d\uddd6\u18bc\udba1\udd86\ud98a\uddcc\u3fa9\ud8d8\udff7\ud80b\udc1e\u7ff8",
        43, 31276, -1001902653, -3465112785363518497L, 21167L, true, false, (char) 56173, (char) 40897,
        Double.longBitsToDouble(0x3f87bd82d9d34a00L), Double.longBitsToDouble(0x3f997db993257e80L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\0121=null\012",
        Z.run(T, 2, 6, 5, 5, "\udbfd\udd7b\ud9af\udc45\udb57\udfbe\ud912\udfaa\udbfa\udd89\ud88c\ude20\udabe\udc4b\udb79\udeca\udbc5\uddba\uda84\uddab", "\ubdaf\u2f63", "\udadf\udc4c\udae4\udfd4\ud81a\udd46\u0d42\udb21\ude9d\udae3\udd1a\udb07\udd15\ud96f\udc24\udaca\udddf\uda50\udd20\u9d98\ud98a\uddcc\u3fa9\u3cb3\udbf7\ude4b\udb8f\uddbd",
        40, 31276, -968348221, 2274523334238108655L, -26764L, true, false, (char) 56012, (char) 45199,
        Double.longBitsToDouble(0x3f997db993257e80L), Double.longBitsToDouble(0x3fdfc09362fab034L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\0121=java.util.Collections$EmptyList:[] |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\012",
        Z.run(T, 2, 3, 3, 5, "\udbfd\udd4c\ud9af\udc45\udb57\udfbe\ud912\udfaa\udbd0\udcd4\ud88c\ude35\udabe\udc4b\ud947\uded1\udbc5\uddba\uda84\uddab", "\u9230\u2f63", "\ud9d5\udc47\udae4\udfd4\ud81a\udd46\u0d42\ud9ca\udc71\ud991\ude87\udb04\udfb9\ud8a7\udc91\udb6d\uddd6\u18bc\udba1\udd86\ud98a\uddcc\u3fa9\ud8d8\udff7\udac6\udec8\u7ff8",
        43, 31276, -1001902653, 425997294355763340L, 84417L, false, true, (char) 58261, (char) 61565,
        Double.longBitsToDouble(0x3fdecf98105faf24L), Double.longBitsToDouble(0x3f87bd82d9d34a00L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 5, "\udbfd\udd4c\ud9af\udc45\udb57\udfbe\ud912\udfaa\udbd0\udcd4\ud88c\ude35\ud8f3\udd39\ud8b5\ude24\udbc5\uddba\uda84\uddab", "\u977c\ud0cd", "\ud9d5\udc47\udae4\udfd4\ud81a\udd46\u0d42\udb21\ude9d\ud991\udec3\uda3e\udd11\ud996\udf39\udb6d\uddd6\u18bc\udba1\udd86\udade\ude15\u3fa9\ud8d8\udff7\ud80b\udc1e\u7ff8",
        43, 31276, -1001902653, 425997292426383500L, 21167L, true, false, (char) 44955, (char) 21941,
        Double.longBitsToDouble(0x3f875918d1e5c040L), Double.longBitsToDouble(0x3f997db993257e80L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\0121=null |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\012",
        Z.run(T, 2, 6, 4, 6, "\ud9ef\udf03\000\uda27\udc26\ud894\udd8b\000\udb23\uddd1\udabe\udc4b\ud9f1\udec6\udbc5\uddba\uda84\uddab", "\u1c31\u4cb8", "\ud9d5\udc47",
        -5, 41618, 862964282, -5866242625212683608L, -99751L, false, false, (char) 1882, (char) 0,
        Double.longBitsToDouble(0x3ec6bf155fe40000L), Double.longBitsToDouble(0x3fe3aa4e38a2d5c7L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 1, "\udbfd\udd4c\ud9af\udc45\udb57\udfbe\ud912\udfaa\udbd0\udcd4\ud88c\ude35\udabe\udc4b\udb79\udeca\udbc5\uddba\uda84\uddab", "\u1c31\u2f63", "\ud963\udeee\udae4\udfd4\ud81a\udd46\udad3\udd01\udb21\ude9d\ud991\udec3\udb07\udd15\ud885\udd30\udb6d\uddd6\u18bc\ud8b8\udd9f\ud98a\uddcc\u3fa9\ud8d8\udff7\ud80b\udc1e\udafb\udc3d",
        21, 31276, -456910397, -966359977507117681L, 21167L, true, false, (char) 3950, (char) 40920,
        Double.longBitsToDouble(0x3f87bd82d9d34a00L), Double.longBitsToDouble(0x3f997db993257e80L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\0121=new com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\012",
        Z.run(T, 2, 3, 9, 5, "\000\ud9af\udc45\udb57\udfbe\ud912\udfaa\udbd0\udcd4\ud88c\ude35\udabe\udc4b\udb79\udeca\udbc5\uddba\000", "\u1c31\u2f63", "\ud9d5\udc47\u00ba\ud81a\udd46\u0d42\udb94\udf2a\ud991\udec3\udb07\udd15\ud885\udd30\udb6d\uddd6\u18bc\udba1\udd86\ud98a\uddcc\u3fa9\ud8d8\udff7\ud80b\udc1e\u7ff8",
        43, 98460, 0, 0L, 31072L, true, false, (char) 63744, (char) 0,
        Double.longBitsToDouble(0x3f87bd82d9d34a00L), Double.longBitsToDouble(0x3f997db993257e80L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 5, "\udbfd\udd4c\ud9af\udc45\udb57\udfbe\ud912\udfaa\udbd0\udcd4\ud88c\ude59\udabe\udc4b\udb79\udeca\udbc5\uddba\uda84\uddab", "\ub00a\u7f6a", "\ud9d5\udc47\udae4\udfd4\ud81a\udd46\u0d42\udb21\ude9d\ud991\udec3\udb07\udd15\ud885\udd30\udb6d\uddd6\udaf1\udfad\udba1\udd86\ud98a\uddcc\u3fa9\ud8d8\udff7\ud80b\udc1e\u7ff8",
        43, 92852, -1001902653, 425997292426383500L, 21167L, true, false, (char) 56173, (char) 40897,
        Double.longBitsToDouble(0x3fd545ec1d01c4f6L), Double.longBitsToDouble(0x3fe4f42ca973c919L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\0121=null\012",
        Z.run(T, 2, 8, 5, 5, "\udbfd\udd4c\ud9af\udc0f\udb57\udfbe\ud912\udfaa\udb8c\udcd2\ud88c\uded3\udabe\udc4b\udb79\udeca\udbc5\uddba", "\u3e81\u1c31\u2f63\uc6db\u2c9b\u9dec\u671b\u9bbd", "\ud991\udec3\udb07\udd15\ud885\udd30\udbe2\udd16\u18bc\udbc8\udf86\ud87f\udff0\u3fe7\ud8d8\udff7\uda61\udd75\udb0d\udcac\udb65\udfa9\ud959\udd3a\ud802\ude3e\ud890\udea1\uda81\udd62\ud875\uddc0\ud8f2\ude32\uda33\udf71",
        57, 40035, -678239764, -2395413030458819573L, 11723L, true, false, (char) 41337, (char) 26771,
        Double.longBitsToDouble(0x3fe1dfe3d4979488L), Double.longBitsToDouble(0x3fe68212b68a5fe8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 5, 5, 1, "\udbfd\udd4c\udb3c\udf8c\udadd\ude60\ud90c\udcde\udbd0\udcd4\ud88c\ude35\u486b\udb79\udeca\udbc5\uddba\uda84\uddab", "\u1c31\u2f63\ubd14", "\udad6\ude3f\ud81a\udd46\u0d42\udb21\ude9d\ud991\udec3",
        53, 24622, 1570082899, -291325530348621963L, 84825L, false, false, (char) 58911, (char) 37928,
        Double.longBitsToDouble(0x3fc45ab8fa91c514L), Double.longBitsToDouble(0x3fce3d00ebcc1c48L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 5, "\ud849\udd52\ud9f8\udc98\udb57\udfd4\ud912\udfaa\udbd0\udcd4\ud88c\ude35\udabe\udc4b\udb79\udeca\udbc5\uddba\uda84\uddab", "\u1c31\u2f63", "\ud9d5\udc47\udae4\udfd4\ud81a\udd46\u9553\uda54\udda3\ud991\udec3\udb07\udd15\ud885\udd30\udb6d\uddd6\u1bbe\udba1\udd86\ud98a\uddcc\u3fa9\ud8d8\udff7\ud80a\udf63\ud924\udc0e",
        6, 43456, -993908837, 425997292426383500L, -19347L, true, false, (char) 58261, (char) 21127,
        Double.longBitsToDouble(0x3fdecf98105faf24L), Double.longBitsToDouble(0x3f87bd82d9d34a00L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.introspect.AnnotationMap:{}\0121=null\012",
        Z.run(T, 2, 9, 5, 5, "\udbfd\udd4c\ud9af\udc45\udb57\udfbe\ud912\udfaa\udbd0\udcd4\ud88c\ude35\udabe\udc4b\udb79\udeca\udbc5\uddba\uda84\uddab", "\u1c31\u4cb8", "\ud9d5\udc47\udae4\udfd4\ud81a\udd46\u0d42\udb21\ude9d\ud991\udec3\udb07\udd15\ud885\udd30\udb6d\uddd6\u18bc\u00ba\000\u3fa2\uda03\udde8\ud933\udc12\u7ff8",
        43, 31276, 11715, 360287969289588876L, -100000L, false, true, (char) 48533, (char) 0,
        Double.longBitsToDouble(0x3fdecf98105faf24L), Double.longBitsToDouble(0x3f87bd82d9d34a00L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\012",
        Z.run(T, 1, 8, 7, 0, "\udbfd\udd4c", "\u024e\000\000\000\000\u8f6e\uccd5", "\ud98d\udfb1\ud8cb\ude4f",
        9, 40779, 1097037933, -155598382L, 31178L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fb4c06f07caeca8L), Double.longBitsToDouble(0x3fe5d7dfac5a7365L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\0121=null\012",
        Z.run(T, 2, 8, 5, 1, "\udbfd\udd4c\udb91\udd76\uda10\udd42\uda54\udf18\udbd0\udcd4\ud88c\ude35\udabe\udc4b\udb79\udeca\ud8d4\udf02\udaee\ude36", "\u1c31\u824c\ubd14\u179a\u1845\ub5d9\u0196\u88df\u66f1\uc808\u0c5c\u6f24\u8f3d\u6f2e\u3f7e\u7901\ubedd", "\u7ff8\udbbf\udf5d\uda1e\udeec\udbe5\uddcc\ud890\udea1\uda81\udd62\ud875\uddc0\ud812\udde3\uda33\udf71\ud870\udd83\u1247\ud835\udf8a\ud9c7\ude39\ud81a\udc97\udaec\udecf\ud854\udeb0\udb5d\udd7d\udb7c\udfa8\udb23\udc94\ud8c9\udf75\udbdc\udda7\udaa5\udc59\udb4f\udcde\uda4d\uddcf\uda1c\ude15\udbbf\udf8a\ud983\udff2\ud8f1\udf6c\ubad3\ud903\ude28\udb20\udda4\udafd\udcb9\ud86a\ude2a\uda39\udc0b\ud9ef\udfd0\udb1a\udec3\ud9b6\udd42\ud8c1\uddc0\udb9d\ude29\uda21\udfc0\ud8b1\udf4b\ud9f9\udec9\ud962\udcce\ud891\ude5d\ud8bd\ude7e\ud8cd\udcfc\ud812\udebd\udab1\uddc5\uda41\udca4",
        3, 94252, -1850223662, 6363019285303437499L, -1324L, false, true, (char) 60000, (char) 2784,
        Double.longBitsToDouble(0x3fd88f7899867126L), Double.longBitsToDouble(0x3fd39708c02c6492L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.introspect.AnnotationMap:{}\0121=new com.fasterxml.jackson.databind.introspect.AnnotationMap:{}\012",
        Z.run(T, 2, 9, 9, 9, "\ud84e\udec3\uda63\udd40\uda89\udfd4\ud912\udfaa\ud861\ude9e\udace\udc7c\udb3e\uded0\ud8b9\udcee\udb10\uddde\ud941\ude03\udba3\udd70\ud903\udde7\ud859\udce9", "\u2c9b", "\ud975\udccc\ud900\udc9f\udaf1\udc9d\ud991\udec3\udb07\udd15",
        52, 36899, -67829511, -965196155637099373L, 22568L, false, true, (char) 10765, (char) 38624,
        Double.longBitsToDouble(0x3fe52496b51de807L), Double.longBitsToDouble(0x3feba305f6e86efeL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.introspect.AnnotationMap:{}\0121=new com.fasterxml.jackson.databind.introspect.AnnotationMap:{}\012",
        Z.run(T, 2, 9, 9, 5, "\uccc1\ud9e2\udec9\udb57\udfbe\ud912\udfaa\udbd0\udcd4\ud88c\ude35", "\ud3c7\ub658\u177d\ua729\u41ef\u2f63\ubd14\u2c9b\u1656", "\u0d42\udb21\ude9d",
        18, 33573, 29113622, 6743454703146041593L, 3514L, true, false, (char) 64124, (char) 44990,
        Double.longBitsToDouble(0x3fe3aa4e38a2d5c7L), Double.longBitsToDouble(0x3fcb6e28b70fcb1cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\0121=java.lang.Integer:0 |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\012",
        Z.run(T, 2, 6, 6, 9, "\udbfd\udd7b\ud9af\udc45\ud913\udcdd\ud8fb\udef6\udbc6\ude2f\ud88c\uddfb\udabe\udc4b\udb79\udeca", "\u9256", "\ud8cb\ude4f\udba0\udfea\uda95\udeae\udadf\udc4c\udae4\udfd4\ud81a\udd46\u0d42\udb21\ude9d\udae3\udd1a\udb07\udd15\ud838\udc7c\ud8ab\udc53\uda66\udfae\u4b06\ud98a\uddcc\u3fa9\u3cb3\udbf7\ude4b\ud826\uddc7\udb61\udfc4\ud959\udd3a\ud8be\ude5c\ud8a9\udcc8\ud85a\udeac\ud875\uddc0\ud8f2\ude32\uda33\udf71",
        26, 13583, -678239764, -2395631871927452661L, 2425L, true, false, (char) 56247, (char) 12695,
        Double.longBitsToDouble(0x3febfc8aaadc8b58L), Double.longBitsToDouble(0x3fc53cbe1cdc4888L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\0121=null |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\012",
        Z.run(T, 2, 4, 4, 1, "\udbfd\udd7b\ud9eb\udc43\udb57\udfbe\ud863\udd84\udb81\udfcd\ud88c\ude20\udabe\udc4b\udb79\udeca\udbc5\uddba\uda84\uddab", "\u0661\ucb3f", "\ud9cb\udefa\udae4\udfd4\ud81a\udd46\u0d42\udb21\ude9d\udae3\udd1a\udb07\udd15\uda55\udcb3\uda80\udc4b\ud976\ude88\u9d98\ud98a\uddcc\u3fa9\u3cb3\udb8b\udfe3",
        1, 53005, -402149724, -4159023939798565359L, -50313L, true, false, (char) 33860, (char) 13462,
        Double.longBitsToDouble(0x3fdbf09e83d9f302L), Double.longBitsToDouble(0x3fa7ebc940bdec10L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:[null] |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\0121=java.lang.String:[null] |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\012",
        Z.run(T, 2, 7, 7, 5, "\udbfd\udd4c\ud9af\udc45\udb57\udfbe\ud912\udfaa\udbd0\udcd4\ud928\udc43\udb16\udd3e\ud800\udf57\udbc5\uddd5\uda84\uddab", "\u9230\u2f63\ubd14\u2c9b\u9dec\u6b9b\u06d4", "\ud991\ude87\udb04\udfb9\ud8a7\udc91\udb6d\uddd6\u18bc\udba1\udd86\ud98a\uddcc\u3fa9\ud8d8\udff7\udac6\udec8\u7ff8\udb61\udf4e\ud959\udd3a\ud802\ude3e\ud890\udea1\uda51\udc29\ud8b2\udfc0\ud90f\udc40\uda33\udf71",
        44, 40944, -678239764, -2395413421300843509L, 73918L, true, false, (char) 19137, (char) 6556,
        Double.longBitsToDouble(0x3fe084f6846bf659L), Double.longBitsToDouble(0x3f650dd17c680c00L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 5, 8, 9, "\udbfd\udd4c\ud9af\udc45\udb57\udfbe", "\u0189\u594a", "\uda84\uddab\udae5\udd71\udad7\udd9b",
        55, 43833, 258052263, 6011177280152500333L, 78898L, false, false, (char) 7897, (char) 6463,
        Double.longBitsToDouble(0x3feaedef8f129530L), Double.longBitsToDouble(0x3fcae6e323e57654L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\0121=null\012",
        Z.run(T, 2, 3, 5, 5, "\uda06\udef1\ud9af\udc45\udb57\udfbe\ud8b4\udf9b\udbd0\udcd4\ud88c\ude35\udabe\udc4b\udb79\udeca\udbc5\uddba\uda84\uddab", "\u1c31\u2f63", "\ud8c1\udcf1\udbb9\ude34\ud81a\udd46\u0d42\udb21\ude9d\ud991\udec3\udb07\udd15\ud885\udd30\udb6d\uddd6\u18bc\udba1\udd86\ud98a\uddcc\u3fa9\ud8d8\udff7\ud80b\udc1e\u7ff8",
        43, 31276, -1001902653, 425997292426383500L, 21167L, true, false, (char) 56173, (char) 143,
        Double.longBitsToDouble(0x3f87bd82d9d34a00L), Double.longBitsToDouble(0x3f997db9932e3e80L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\0121=new com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\012",
        Z.run(T, 2, 3, 9, 5, "\ud8fe\udd15\ud9b7\udffe\udb57\udfbe\ud912\udfaa\ud8e9\udf01\udac9\udec1\udbb1\udef6\uda4e\udc47\udb2e\udcc8,", "\u1c31\u2f63", "\ud8fb\udc5b\udbaf\udc25\ud81a\udd46\u0d42\udadf\udf4e\ud998\udf54\udb07\udd15\ud885\udd30\ud90d\uddd0\u18bc\udba1\udd86\ud98a\uddcc\u3fa9\ud8d8\udff7\ud80b\udc1e\u7ff8\udb61\udf4e\ud9ad\udea4\uda54\udc69\uda02\udc06\ud813\udc6e\ud875\uddc0\ud8f2\ude32\u7366",
        19, 30361, 0, -2395633525489861621L, -63111L, true, false, (char) 60482, (char) 52080,
        Double.longBitsToDouble(0x3fc469365f18e808L), Double.longBitsToDouble(0x3fe925f0bad18bc3L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\0121=new com.fasterxml.jackson.databind.introspect.AnnotationMap:[null]\012",
        Z.run(T, 2, 9, 9, 5, "\ud8fe\udd15\ud9b7\udffe\udb57\udfbe\ud912\udfaa\ud8e9\udf01\udac9\udec1\udbb1\udef6\uda4e\udc47\udb2e\udcc8,", "\u1c31\u2f63", "\ud8fb\udc5b\udbaf\udc25\ud866\ude2c\u0d4a\udadf\udf4e\ud998\udf54\udb07\udd15\ud885\udd30\ud90d\uddd0\u18bc\udba1\udd86\ud98a\uddcc\u3fa9\ud8d8\udff7\ud80b\udc1e\u7ff8\udb61\udf4e\ud9ad\udea4\uda54\udc69\uda02\udc06\ud813\udc6e\ud875\uddc0\ud8f2\ude32\u7366",
        19, 30361, 0, -2332583130706674677L, -63111L, true, false, (char) 60482, (char) 52080,
        Double.longBitsToDouble(0x3fc469365f18e808L), Double.longBitsToDouble(0x3fe925f0bad18bc3L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.introspect.AnnotationMap|_add|java.lang.annotation.Annotation|new:com.fasterxml.jackson.databind.introspect.AnnotationMap:",
    "M|com.fasterxml.jackson.databind.introspect.AnnotationMap|add|java.lang.annotation.Annotation|new:com.fasterxml.jackson.databind.introspect.AnnotationMap:",
    "M|com.fasterxml.jackson.databind.introspect.AnnotationMap|addIfNotPresent|java.lang.annotation.Annotation|new:com.fasterxml.jackson.databind.introspect.AnnotationMap:",
    "M|com.fasterxml.jackson.databind.introspect.AnnotationMap|annotations||new:com.fasterxml.jackson.databind.introspect.AnnotationMap:",
    "M|com.fasterxml.jackson.databind.introspect.AnnotationMap|get|java.lang.Class|new:com.fasterxml.jackson.databind.introspect.AnnotationMap:",
    "M|com.fasterxml.jackson.databind.introspect.AnnotationMap|merge|com.fasterxml.jackson.databind.introspect.AnnotationMap,com.fasterxml.jackson.databind.introspect.AnnotationMap|static",
    "M|com.fasterxml.jackson.databind.introspect.AnnotationMap|size||new:com.fasterxml.jackson.databind.introspect.AnnotationMap:",
    "M|com.fasterxml.jackson.databind.introspect.AnnotationMap|toString||new:com.fasterxml.jackson.databind.introspect.AnnotationMap:",
    "C|com.fasterxml.jackson.databind.introspect.AnnotationMap|<init>|",
    "C|com.fasterxml.jackson.databind.introspect.AnnotationMap|<init>|java.util.HashMap",
    "M|com.fasterxml.jackson.databind.introspect.AnnotationMap|_add|java.lang.annotation.Annotation|new:com.fasterxml.jackson.databind.introspect.AnnotationMap:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
