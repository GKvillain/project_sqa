package com.fasterxml.jackson.databind.deser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringCollectionDeserializer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@? |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\012",
        Z.run(T, 1, 9, 1, 9, "\udbd3\udce8\udbcf\udd0c\ud93f\udc78\udb11\udd01\u117b\ud8ab\udf50\ud940\udcc8\ud9db\udd1d\uda05\uddd8\udb03\udfef\udad1\udcea\ud9f6\udeb4\uda55\udf9c\ud905\ude4d\ud8b4\udf2c\udacd\ude99\udbce\udcbd\uda57\udfe8\ud83d\uddfc\ud9ef\udf50\udb45\udd11\ud917\ude55\udb12\udc43\udab3\udc87\u4157", "\uaaf7\u14d7\u04ba\ub319\u9d69\u475e\u8d4b", "\ud9fb\udc47\udb3a\udf6b\ud8eb\udc4b\udb67\udfbc\udafd\udcb5\ud837\uddc5\uda18\ude14\uda9f\udf23\ud805\udc26",
        4, 45020, 2029402325, 2141610493962357365L, 2465L, true, false, (char) 3167, (char) 55808,
        Double.longBitsToDouble(0x3fd85394e2c76388L), Double.longBitsToDouble(0x3fe73177c9753a61L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 9, "\udbd3\udce8\udbcf\udd0c\udb4b\udc7e\udb1d\udc01\u117b\udb73\udf94\udb08\udfa6\ud9db\udd1d\uda05\uddd8\udbc0\udc0d\udad1\udc77\ud9f6\udeb4\ud933\udd80\uda98\udc2d\ud8b4\udf6d\udacd\ude99\udbce\udcbd\uda57\udfe8\ud83d\uddfc\ud9ef\udf50\udb45\udd11\ud917\ude55\udb12\udc43\udab9\ude27\u410f", "\uaaf7\u14d7\u04ba\ub319\u9d69\u475e\u8d4b", "\ud9fb\udc47\udb3a\udf6b\ud895\udc40\udb67\udfbc\udafd\udcb5\ud837\uddc5\uda18\ude14\udb03\udfb6\udb24\udc31",
        40, 2068, 1163660813, 2141610687235885685L, 2465L, true, false, (char) 3167, (char) 55808,
        Double.longBitsToDouble(0x3fd85394e2c76388L), Double.longBitsToDouble(0x3fe73177c9753a61L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\012",
        Z.run(T, 1, 5, 8, 9, "\udbd3\udce8\udb8f\udf0c\ud93f\udc78\udb11\udd01\u117b\ud8ab\udf50\ud940\udcc8\ueece\udb74\udd1a\udb03\udfef\udad1\udcea\ud9f6\udeb4\uda55\udf9c\ud905\ude4d\ud8b4\udf2c\udacd\ude99\udbce\udcbd\uda57\udfe8\ud83d\uddfc\ud9ef\udf50\udb45\udd11\ud917\ude55\udb12\udc43\udab3\udc87\u4157", "\uaaf7\u14d7\u04ba\u00ac\000\000\u8c7e", "\ud9fb\udc47\udb3a\udf6b\ud8eb\udc4b\udb67\udfbc\udafd\udcb5\ud837\uddc5\uda18\ude14\uda9f\udf23\ud805\udc26",
        4, 45020, 2013280469, 2141610494971084800L, -44147L, false, false, (char) 28607, (char) 23745,
        Double.longBitsToDouble(0x3fe468e804152decL), Double.longBitsToDouble(0x3fd85394e2c76388L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@? |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\012",
        Z.run(T, 1, 9, 1, 9, "\udbd3\udce8\udbcf\udd0c\ud93f\udc78\udb11\udd01\u117b\ud8ab\udf50", "\u1a32\u9ccd\ub6de\u1b88\u399f", "\udacd\ude99",
        52, 14225, 1240076705, 4004971148820569884L, -14161L, true, true, (char) 15551, (char) 1010,
        Double.longBitsToDouble(0x3fdf7b1edbcc38e6L), Double.longBitsToDouble(0x3fc39230e603e5c4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\012",
        Z.run(T, 1, 10, 1, 9, "\udbd3\udce8\ud8a1\udeb5\ud948\ude8c\ud85b\udc67\uda9b\uddab\ud8ab\udf50\ud940\udcc8\ud9db\udd1d\uda05\uddd8\udb03\udfef\udad1\udcea\ud9f6\udeb4\uda55\udf9c\ud905\ude4d\ud8b4\udf2c\udacd\ude99\udbce\udcbd\uda57\udfe8\ud83d\uddfc\ud9ef\udf50\udb45\udd11\ud917\ude55\udb12\udc43\udab3\udc87\u4157", "\uaaf7\u9b52\u04ba\ub319\u9d69\u475e\u8d4b", "\ud9fb\udc47\udb3a\udf6b\ud8eb\udc4b\udb67\udfbc\udafd\udcb5\ud837\uddc5\uda18\ude14\uda9f\udf23\ud805\udc26",
        4, 45020, 2029402325, 2141610493962357365L, 2465L, true, false, (char) 3167, (char) 55808,
        Double.longBitsToDouble(0x3fd85394e2c76388L), Double.longBitsToDouble(0x3fe73177c9753a61L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 1, 9, "\udbd3\udce8\udbcf\udd0c\ud93f\udc78\udb11\udd01\u117b\ud8ab\udf50\ud940\udcc8\ud9db\udd1d\uda05\uddd8\udb03\udfef\udad1\udcea\ud9f6\udeb4\uda55\udf9c\ud905\ude4d\ud8b4\udf2c\udacd\ude99\udbce\udcbd\uda57\udfe8\ud83d\uddfc\ud9ef\udf50\udb45\udd11\ud917\ude55\udb12\udc43\ud8a7\udf8d\u4157", "\uaaf7\u14d7\u04ba\ub319\u9d69\u475e\u8d4b", "\ud9fb\udc47\udb3a\udf6b\ud8eb\udc4b\udb67\udfbc\udafd\udcb5\ud837\uddc5\uda18\ude14\uda9f\udf23\ud805\udc26",
        4, 45020, 2029402325, 2141610493962357365L, 2465L, true, false, (char) 3167, (char) 55808,
        Double.longBitsToDouble(0x3fd85394e2c76388L), Double.longBitsToDouble(0x3fe73177c9753a61L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 1, 9, "\udbd3\udce8\udbcf\udd0c\ud93f\udc78\udb11\udd01\u117b\ud8ab\udf50\ud940\udcc8\ud9db\udd1d\udab7\udf51\udb03\udfe5\udad1\udcea\ud9f6\udeb4\uda55\udf9c\ud905\ude4d\ud8b4\udf2c\udacd\ude99\udbce\udcbd\uda57\udfe8\ud83d\uddfc\ud9ef\udf50\udb45\udd11\ud917\ude55\udb12\udc43\udab3\udc87\u4157", "\uaaf7\u14d7\u04ba\ub319\u9d69\u475e\u45c6", "\ud9fb\udc47\udb3a\udf6b\ud8eb\udc4b\udb67\udfbc\ud885\uddd8\ud837\uddc6\uda18\ude14\uda9f\udf23",
        0, 49464, 822858532, 8716216706994308966L, 55858L, false, false, (char) 2653, (char) 62026,
        Double.longBitsToDouble(0x3fdad9d4bf7f4282L), Double.longBitsToDouble(0x3fabae4568d1dd20L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 3, 9, "\udbd3\udce8\udbcf\udd0c\ud93f\udc78\udb11\udd01\u117b\ud8ab\udf50\ud940\udcc8\udb10\udeb8\uda05\uddd8\udb03\udfef\udad1\udcea\udb0a\udeb5\uda79\udfcd\ud905\ude19\ud8b4\udf2c\ud8d9\uded7\u509c\uda32\uddea\ud83d\uddfc\ud890\udc9b\ud90c\udd4a\ud916\udcb1\udb12\udc43\udab3\udc87\u4157", "\u28f7\u14d7\u2e81\u2543\u9d69\u475e", "\ud9ae\udc5e\ud8f6\udd2e\udb1b\uddc6\ud904\udd46\ud897\udc13\udafd\udd30\ud837\uddc5\uda18\ude14",
        22, 23379, -52974536, -5977451926802515755L, 33749L, false, true, (char) 35142, (char) 2672,
        Double.longBitsToDouble(0x3fe528c0f2ad9d4bL), Double.longBitsToDouble(0x3fef7667d232b4dcL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\012",
        Z.run(T, 1, 8, 1, 9, "\udbd3\udce8\udbcf\udd0c\ud93f\udc78\udb11\udd01\u117b\ud8ab\udf50\ud940\udcc8\ud9db\udd1d\ud884\uddbc\uda2b\udd78\ufdc2\ud9f6\ude31\uda55\udf9c\ud905\ude4d\ud8b4\udf2c\udacd\ude99\udbce\udcbd\uda57\udfe8\ud83d\uddfc\ud9ef\udf50\udb45\udd11\ud917\ude55\udb12\udc43\udab3\udc87\u4157", "\uaaf7\u14d7\u04ba\ub319\u9d69\u47b8\u8d4b", "\ud9fb\udc47\udb3a\udf6b\ud8eb\udc4b\udb67\udfbc\uda4e\udd5d\ud837\uddb2\uda18\ude14\ud9b2\udd6d\ud805\udc26",
        4, 97556, 2029402325, 2141610493962357365L, 59572L, true, false, (char) 3167, (char) 55808,
        Double.longBitsToDouble(0x3fd85394e2c76388L), Double.longBitsToDouble(0x3fe73177c9753a61L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@? |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 9, "\udbd3\udce8\udbad\ude0c\ud93f\udc78\udb11\udd01\u117b\ud8ab\udf50\ud940\udcc8\ud9db\udd1d\uda05\uddd8\udb03\udfef\udad1\udcea\ud9f6\udeb4\uda55\udf9c\ud905\ude4d\ud8b4\udf2c\udacd\ude99\udbce\udcbd\uda57\udfe8\ud83d\uddfc\ud9ef\udf50\udb45\udd11\ud917\ude55\udb12\udc43\ud80e\udfd4\udbe1\udeae", "\ub5aa\u14d7\u04ba\ub319\u9d69", "\ud887\udcb9\ud9ae\udc5e\ud9fb\udc47\udb3a\udf6b\ud8eb\udc4b\udb67\udf65\udafd\udcb5",
        16, 13580, 1550967217, 945997127058172984L, 16523L, false, true, (char) 62738, (char) 25358,
        Double.longBitsToDouble(0x3fe66dcbc9e0e08fL), Double.longBitsToDouble(0x3fe168c0f1ad9d4bL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 11, "\udbd3\udce8\udbcf\udd0c\ud93f\udc78\ud831\udd71\u1205\ud8ab\udf50\ud940\udcc8\udbea\udefc\uda09\uddc2\udb03\udfef\udad1\udcea\udb9e\udc68\udb99\udeba\ud8f7\udd40\ud8b4\udf2c\udacd\ude99\udb9d\udf09\uda57\udfe8\uda02\udf60\ud9d6\udec8\udb45\udd11\ud917\ude55\udb12\udc43\uda8a\ude52\udbe5\ude01\ud887\udcb3\ud8b1\udfa4\ud95b\udf63\ud818\udd7e\ucb59", "\u875e\u8d4b\u5aea\ud08c\u6f21\u501a\u759d\u40b1\u5c0a\u4f61\uba00\u588b\u0e31\u3a91\ua0d2\u5032\u5b60\u1326\u825d\ua589\u8e75\u0531\u457e\u9317\u69db", "\udae3\udce8\ud8ed\udd9a\udb08\ude56\ud954\ude63\ud9bb\uddf3\udb2a\udfec\ud976\udf71\ud900\udc80\udbe3\udd8f\uda17\ude08\ud8fd\uddc8\ud958\udc72\udbad\udd66\udb18\udd80\uda0d\udd57\udaa6\udf9a\ud9c8\udc76\ud8dd\udf3b\ud9e6\ude2b\udb12\ude36\ud902\udfb5\ud8ea\udda8\udb2f\udcae\ud83b\udea7\ud92b\udf16\udb7d\udcbc\udba6\udfc0\ud802\ude58\udb5f\udd41",
        5, 28874, 224114330, -6974722961546990381L, -1170L, false, false, (char) 14941, (char) 32854,
        Double.longBitsToDouble(0x3fb9ea34c812f2d8L), Double.longBitsToDouble(0x3f9926849f0a55a0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\012",
        Z.run(T, 1, 5, 1, 9, "\ud957\udfea\udbcf\udca7f\udb11\udc83\u117b\ud8ab\udf50\ud940\udcc8\uee00\uda05\udd1c\udb03\udfef\udad1\udcea\ud9f6\udeb4\uda55\udf9c\ud905\ude4d\ud8b4\udf2c]\000\uda57\udfe8\u00a1\ud9ef\udf50\udb45\udd11\ud917\ude55\udb12\udc43\udbd2\udd29\u4157", "\uaaf7\u14d7\u04ba\ub319\u9d69\u475e\u8d4b", "\ud950\udc07\ud8e2\udd67\ud8eb\udc4b\udb67\udfbc\udafd\udcb5\ud837\uddc5\uda18\ude14\u471d\ud805\udc26",
        13, -1000, 0, 2089670227114592885L, 59488L, true, false, (char) 61137, (char) 55808,
        Double.longBitsToDouble(0x3fd85394e2c76388L), Double.longBitsToDouble(0x3fe73177c9753a61L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\012",
        Z.run(T, 1, 10, 8, 9, "\udbcd\udd26\udbcf\udd0c\udb4b\udc7e\udb1d\udc01\u117b\udb73\udf94\udb08\udfa6\ud9db\udd1d\uda05\uddd8\udbc0\udc0d\udad1\udc77\ud9f6\udeb4\ud8fa\udfa4\uda98\udc2d\ud8b4\udf6d\udacd\ude99\udbce\udcbd\uda57\udfe8\ud83d\uddfc\ud9ef\udf50\udb45\udd11\udba2\udfd2\udb12\udc3b\udab9\ude27\u410f", "\u24b2\u14d7\u7a0e\u27bb\u9d69\u475e\uce58", "\ud9fc\udf0e\udb3a\udf6b\ud961\udc47\udb67\udfbc\udafd\udcb5\ud837\uddc5\uda18\ude14\udb03\udfb6\udb24\udc31",
        40, 2068, 1163660813, 2141610687235885685L, 2465L, true, false, (char) 3167, (char) 55808,
        Double.longBitsToDouble(0x3fd85394e2c76388L), Double.longBitsToDouble(0x3fe73177c9753a61L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\012",
        Z.run(T, 2, 5, 8, 5, "\udbd3\udce8\udb8f\udf0c\ud93f\udc78\udb11\udd01\u117b\ud8ab\udf50\ud940\udcc8\ueece\udb74\udd1a\udb03\udfef\udad1\udcea\ud9f6\udeb4\uda55\udf9c\ud905\ude4d\ud8b4\udf2c\udacd\ude99\udbce\udcbd\uda57\udfe8\ud83d\uddfc\ud9ef\udf50\udb45\udd11\ud917\ude55\uda16\udc38\udb73\ude03\udbf2\udc34", "\uaaf7\u14d7\u04ba\u00ac\u0097\000\u77be", "\ud9fa\udfc4\udb3a\udf6b\ud8eb\udc4b\udb67\udfbc\udafd\udcb5\ud837\uddc5\uda18\ude14\uda9f\udf23\ud805\udc26\ud86a\udd56\ud9ed\udf01\ud975\udfe7\ud964\udd26\000\udb00\udcf9\u60ab\udb62\udebe\ue22d\000\ud847\udd33\ud9ec\uddec\udb66\udd41\uda2d\udf75\ud822\udcd1\uda4b\udfad\udbdf\ude29\uda10\udc51\ud86c\udd6f\uda9a\udf4b\uda4f\udddf\ud88b\udde3\ud845\udd49\ud827\ude53\ud952\ude7f\u8eae\udb29\ude37\udada\udf6f\ud814\uddbe\udbd0\udcb9\udbb2\udd2d",
        53, 51682, -1857056549, 5188462506261685418L, 28730L, true, false, (char) 2143, (char) 21982,
        Double.longBitsToDouble(0x3fe4cd9075876a9bL), Double.longBitsToDouble(0x3fe675f49d068ed2L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 1, 9, "\udbd3\udce8\ud8a1\udeb5\ud948\ude8c\ud85b\udc67\uda9b\uddab\ud8ab\udf50\ud940\udcc8\ud9db\udd1d\uda05\uddd8\udb03\udfef\udad1\udcea\ud9f6\udeb4\uda55\udf9c\ud905\ude4d\ud8b4\udf2c\udacd\ude99\udbce\udcbd\uda57\udfe8\ud83d\uddfc\ud9ef\udf50\udb45\udd11\ud917\ude55\udb12\udc43\udab3\udc87\udbea\ude7d", "\uaaf7\u9b52\u04ba\ub319\u9d69\u475e\u8d4b", "\ud9fb\udc47\ud90d\udf53\ud8cf\udf44\udb67\udfbc\udafd\udcb5\ud837\uddc5\uda18\ude14\uda9f\udf23\ud805\udc26",
        4, 45020, 2029402325, 2141610493962357365L, 2465L, true, false, (char) 3167, (char) 55808,
        Double.longBitsToDouble(0x3fd85394e2c76388L), Double.longBitsToDouble(0x3fe73177c9753a61L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 9, "\udb43\udd4a\ud8a1\udeb5\uda47\udfeb\ud85b\udc67\uda9b\uddab\ud8ab\udf50\ud940\udcc8\ud9db\udd1d\uda05\uddd8\udb03\udfef\udad1\udcea", "\ucacb\uc47b", "\udac9\udd41\udbd0\udc66\ud9e4\udea5\uda45\udcd5\ud917\ude76\udb12\udc43\udab3\udc87\u4157",
        11, 14175, 1855456252, 1474323515480531228L, -21989L, true, false, (char) 57362, (char) 59257,
        Double.longBitsToDouble(0x3fe2cc8d40c65b5eL), Double.longBitsToDouble(0x3fe5b1dbed87844dL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 3, 9, "\udbd3\udce8\udbcf\udd0c\ud93f\udc78\udb11\udd01\u117b\ud8ab\udf50\ud940\udcc8\udb10\udeb8\uda05\uddd8\udac4\udf10\ud853\udd68\ud978\udf18\ud8ee\ude40\udb4e\ude94\ud9e3\udca4\ud8d9\uded7\u509c\uda32\uddea\ud83d\uddfc\ud890\udc9b\ud90c\udd4a\u9fda\udb12\udc43\udab3\udc87\u4157", "\ub681\u14d7\u2ee0\u2543\u9d69\u475e", "\ud9ae\udc5e\ud8f6\udd2e\udb1b\uddc6\ud904\udd46\udb9d\udff6\udafd\udd30\ud837\uddc5\uda18\ude14",
        22, 23379, -121204168, -7424112639989106514L, 33749L, false, true, (char) 35142, (char) 2672,
        Double.longBitsToDouble(0x3fe528c0f2ad9d4bL), Double.longBitsToDouble(0x3fe07aa01a320f5bL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\0121=null |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\012",
        Z.run(T, 2, 6, 5, 5, "\udbd3\udce8\ue221\ud93f\udc78\udb11\udd01\udb21\udf7b\uda9f\udd8c\ud940\udcc8\ud946\ude93\ud8ac\udfc9\u34c9\ud85f\udf87\udbc3\udff8", "\u269e\u75d0\uc16d\ub5bd\u95d7\ubb56\u81c7\u1100\u604c\u62fb\u7bcb\u4c71\u6c10\u77e9\u71dd\u258f\ub923\u9d69\u840d\u40e7\u5633\u5151", "\udaa1\udf23",
        3, 80655, -1809981088, 1503534680919915927L, -20171L, false, false, (char) 6194, (char) 9387,
        Double.longBitsToDouble(0x3fedc003c8320f4cL), Double.longBitsToDouble(0x3fed380cf068fa3dL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@? |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\0121=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@? |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\012",
        Z.run(T, 2, 9, 9, 0, "\udbd3\udce8\ue43c\udac1\udd09\udb2a\udc03\u122e\ud843\udea8\udb9c\udd1d\ud9db\udd40\uda05\uddd8\udb03\udfef\udad1\udcea\ud9f6\udeb4\udaba\udec1\ud905\ude1f\ud8b4\udf2c\udacd\ude84\udbce\udcbd\uda57\udfe8\ud83d\uddfc\ud9ef\udf50\ud854\udfa0\ud917\ude55\udb12\udc43\ud80e\udfd4\udbe1\udeae", "\ub5aa\u14d7\u7530\ub319\u9d69", "\ud887\udcb9\ud9ae\udc5e\ud9fb\udc47\udb3a\udf6b\ud8eb\udc4b\udb67\udf65\udafd\udcb5",
        16, 13580, 1550967217, 945997125898343603L, 16523L, false, true, (char) 62738, (char) 25358,
        Double.longBitsToDouble(0x3fe66dcbc9e0e08fL), Double.longBitsToDouble(0x3fe168c0f1ad9d4bL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\0121=new com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\012",
        Z.run(T, 2, 10, 11, 5, "\udbd3\udce8\udbad\ude0c\ud960\ude78\ud96f\udc10\u1195\ud8ab\udf50\ud940\udcc8\ud9db\udd1d\uda05\uddd8\ud8b9\udc2a\ud805\ude26\uda35\udd85\uda55\udfe8\ud905\ude4d\ud8b4\udf2c\ud91b\udebf\udbce\udcbd\uda57\udfe8\ud8e2\udeaf\ud9db\ude31\udb45\udd11\ud917\ude55\ud998\ude1f\ud820\udeff\udbe1\udeae", "\ua5f7\ua589\ubb50\ub319\u9d69", "\ud9a1\udce6\uda89\ude72\ud9fb\udc47\udb3a\udf6b\ud8eb\udc4b\udb67\udf65\udafd\udcb5",
        16, 13580, 1550967217, 945997127058172984L, 16523L, false, true, (char) 62738, (char) 25358,
        Double.longBitsToDouble(0x3fe66dcbc9e0e08fL), Double.longBitsToDouble(0x3fe168c0f1604c4bL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\0121=null |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\012",
        Z.run(T, 2, 5, 5, 6, "\udbd3\udce8\udbad\ude0c\ud93f\udc78", "\u05f0\u7273\ucdb7\u1a32\u9ccd\ub6de\u1b88\u399f\ucacb\ud455\u0ce9\uc16d\u19d7\u793b\u9de9\u136c\u475c\u4dd5\u3d4d\u96f6\ua0a3\ua0d5\ub5aa", "\ud9e0\udff2\ud94c\udd90\u9009\ud874\udeb4\ud9e2\udf66",
        7, 20238, -2075311434, 8273813482791267423L, 9200L, true, false, (char) 30593, (char) 14289,
        Double.longBitsToDouble(0x3fac0690324fcd70L), Double.longBitsToDouble(0x3fe6ad685ae001cbL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 7, 9, "\udbd3\udce8\udbad\ude0c", "\ub752\u05f0\u7273\ucdb7\u1a32\u9ccd\u1edf\ua2ca", "\ud8b4\udf2c\udb82\udc82\udb49\ude1a\uda5e\ude05\udb00\udcad\ud9ef\udf5a\udb45\udd11\ud917\ude55\udb12\udc43\ud80e\udfd4\udbe1\udeae\ud9dd\udcfc\udb1e\udf18\ub997\ud835\udc39\udae2\ude74\ud9fc\udcf2\udb17\udf96\uc8b1\ud874\udeb4\ud887\udcb9\ud9ae\udc5e",
        23, 23902, -264733300, -6080752104185970305L, 198L, true, false, (char) 25358, (char) 9287,
        Double.longBitsToDouble(0x3fde0e08f0b62d0cL), Double.longBitsToDouble(0x3fe77dc92feeea57L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@? |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\0121=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@? |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\012",
        Z.run(T, 2, 9, 9, 9, "\udbd3\udce8\udbad\ude0c\ud93f\udc78\udb11\udd01\u117b\ud8ab\udf50\ud940\udcc8\ud9db\udd1d\uda05\uddd8\udb03\udfef\udad1\udcea\ud9f6\udeb4\udb77\udf3b\ud905\ude4d\ud8b4\udf2c\udacd\ude99\ud9fb\ude93\uda57\udfe8\ud83d\uddfc\ud9ef\udf50\udb45\udd11\ud917\ude55\ud9c4\udcbc\udab2\udc78\udbe1\udeae", "\ub5aa\u14d7\u04ba\ub319\u9d69", "\ud8c8\udcd9",
        -5, 65744, -2075311434, 8273813482791267423L, -40750L, false, false, (char) 30500, (char) 14289,
        Double.longBitsToDouble(0x3fac069000000d70L), Double.longBitsToDouble(0x3fcaa0001d99e3d8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\012",
        Z.run(T, 2, 8, 8, 9, "\udb43\udd4a\ud8a1\udeb5\uda47\udfeb\ud85b\udc67\uda9b\uddab\ud8ab\udf50\ud940\udcc8\ud9db\udd1d\uda05\uddd8\ud9a8\udfa2\udab2\udc21", "\u069a\uc47b", "\udac9\udd41\udbd0\udc66\ud986\udda1\ud8d9\udf2d\udac6\udc6c\udb12\udc43\udab3\udc87\u4157",
        55, 14025, 1855456252, -2468038099260829403L, 84133L, true, false, (char) 51986, (char) 59051,
        Double.longBitsToDouble(0x3fe2cc8d40c65b5eL), Double.longBitsToDouble(0x3fe5b1dbed87844dL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@? |this=com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:@?\012",
        Z.run(T, 1, 9, 1, 9, "\udbd3\udce8\udbcf\udd0c\ud93f\udc78\udb11\udd01\u117b\ud8ab\udf50\ud940\udcc8\ud9db\udd1d\uda05\uddd8\udb03\udfef\udad1\udcea\ud9f6\udeb4\uda55\udf9c\ud905\ude4d\ud8b4\udf2c\udacd\ude99\udbce\udcbd\uda57\udfe8\ud83d\uddfc\ud9ef\udf50\udb45\udd11\u6c18\udb12\udc43\udab3\udc87\u4157", "\uaaf7\u14d7\u04ba\ub319\u9d69\u475e\u8d4b", "\ud9fb\udc47\udb3a\udf6b\ud8eb\udc4b\udb67\udfbc\udafd\udcb5\ud837\uddc5\uda18\ude14\uda9f\udf23\ud805\udc26",
        4, 45020, 2029402325, 2141610493962357365L, 2465L, true, false, (char) 3167, (char) 55808,
        Double.longBitsToDouble(0x3fd85394e2c76388L), Double.longBitsToDouble(0x3fe73177c9753a61L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer|createContextual|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanProperty|new:com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.deser.ValueInstantiator",
    "M|com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer|deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.deser.ValueInstantiator",
    "M|com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer|deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.util.Collection|new:com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.deser.ValueInstantiator",
    "M|com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer|deserializeUsingCustom|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.util.Collection,com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.deser.ValueInstantiator",
    "M|com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer|deserializeWithType|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.jsontype.TypeDeserializer|new:com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.deser.ValueInstantiator",
    "M|com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer|getContentDeserializer||new:com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.deser.ValueInstantiator",
    "M|com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer|getValueInstantiator||new:com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.deser.ValueInstantiator",
    "M|com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer|handleNonArray|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.util.Collection|new:com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.deser.ValueInstantiator",
    "M|com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer|isCachable||new:com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.deser.ValueInstantiator",
    "M|com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer|withResolved|com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.deser.NullValueProvider,java.lang.Boolean|new:com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.deser.ValueInstantiator",
    "C|com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer|<init>|com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.deser.ValueInstantiator",
    "C|com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer|<init>|com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.deser.ValueInstantiator,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.deser.NullValueProvider,java.lang.Boolean",
    "M|com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer|createContextual|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanProperty|new:com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.deser.ValueInstantiator",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
