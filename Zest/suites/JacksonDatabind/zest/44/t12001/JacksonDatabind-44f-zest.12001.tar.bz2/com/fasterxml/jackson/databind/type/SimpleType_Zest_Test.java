package com.fasterxml.jackson.databind.type;
import org.junit.Test;
import static org.junit.Assert.*;
public class SimpleType_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 2, "\ud80b\udda8\ud8a0\udd63\uda8b\ude0d\ud951\udd4b\udb00\udc41\uda37\ude1f\ud980\udf0f\ud8a8\ude14\u493e", "\ucb95\u0f39\ub2a6\u1184\u497b\u73fb\u669d\u8ae3\u2837\uceae\u94dc\u77e0", "\ud99b\udcc0\udb34\udfbd\uda4c\udfc7\udb98\udf28\ud818\udff5\udafe\udd5b\ud9d6\udf46\ud82a\udef6\uda35\udeab\udaa0\ude11\udb37\udec2\ud8ac\udced\udaa1\ude76\ud935\uddef\uda97\udc3f\ud94d\udc39\udbe4\udedd\udb96\udce7",
        59, 57117, -1006943721, -7842672662708702728L, -71040L, true, true, (char) 33004, (char) 10454,
        Double.longBitsToDouble(0x3fefe8e21e03d5efL), Double.longBitsToDouble(0x3f7b753661033700L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 2, "\ud80b\udda8\ud8a0\udd63\uda8b\ude0d\ud951\udd4b\udb00\udc41\uda37\ude1f\ud980\udf0f\ud8a8\ude14\u493e", "\ucb95\ud6a0\u5523\u1184\u497b\u73fb\u669d\u8ae3\u05ea\u11e9\u6ad6\u77e0", "\ud99b\udcc0\udb34\udfbd\uda4c\udfc7\udb98\udf28\ud818\udff5\udafe\udd5b\ud9d6\udf46\ud82a\udef6\uda35\udeab\udaa0\ude11\udb37\udec2\ud8ac\udced\udaa1\ude76\ud935\uddef\uda97\udc3f\ud94d\udc39\udbe4\udedd\udb96\udce7",
        50, 57116, -1006943721, -7842672662708702728L, 30336L, false, true, (char) 33004, (char) 10454,
        Double.longBitsToDouble(0x3fefe8e21e03d5efL), Double.longBitsToDouble(0x3f7b753661033700L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 2, "\ud80b\udda8\ud8a0\udd63\uda8b\ude0d\ud951\udd4b\udb00\udc41\uda37\ude1f\ud980\udf0f\ud8a8\ude14\u493e\ud91b\udc5b", "\u0f39\ub2a6", "\ud8e8\udeb6",
        34, 47405, -1246922412, 795107003036605608L, 85448L, true, true, (char) 10249, (char) 61960,
        Double.longBitsToDouble(0x3fceed5e8950cb1cL), Double.longBitsToDouble(0x3fe7b77c5c9d4935L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Object]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 2, "\ud80b\udda8\ud8a0\udd63\uda8b\ude0d\ud951\udd4b\udb00\udc41\uda37\ude1f\ud980\udf0f\ud8a8\ude14\u493e", "\ucb95\u0f39\ub2a6\u1184\u497b\u73fb\u669d\u8ae3\u2837\uceae\u94dc\u77e0", "\ud99b\udcc0\udb34\udfbd\uda4c\udfc7\udb98\udf28\ud818\udff5\udafe\udd5b\ud9d6\udf46\ud82a\udef6\uda35\udeab\udaa0\ude11\udb37\udec2\ud8ac\udced\udaa1\ude76\ud935\uddef\uda97\udc3f\ud94d\udc39\udbe4\udedd\udb96\udce7",
        59, 57117, -1006943721, -7842672662708702728L, -71040L, true, true, (char) 33004, (char) 10454,
        Double.longBitsToDouble(0x3fefe8e21e03d5efL), Double.longBitsToDouble(0x3f7b753661033700L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 2, "\000\000\uda8b\udd76\ud951\udd4b\udb00\udc41\uda37\ude1f\u65bd\000\000", "\ucb95", "\u4e6c\uda10\udca3\ud8e8\udeb6\ud8fd\udd34\uda4e\udf3fM\ud98e\udca6\udb0e\udd0a\u00aa",
        -5, -496, 0, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e110e0f00000000L), Double.longBitsToDouble(0x3fc2e0d6b1d18eacL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 11, 2, "\ud80b\udda8\ud8a0\udd63\uda8b\ude0d\ud951\udd4b\udb00\udc41\uda37\ude1f\ud980\udf0f\ud8a8\ude14\u493e", "\ucb95\u0f39\ub2a6\u1184\u497b\u73fb\u669d\u8ae3\u2837\uceae\u94dc\u77e0", "\ud99b\udcc0\udb34\udfbd\uda4c\udfc7\udb98\udf28\ud818\udff5\udafe\udd5b\ud9d6\udf46\ud82a\udef6\uda35\udeab\udaa0\ude11\udb37\udec2\ud8ac\udced\udaa1\ude76\ud935\uddef\uda97\udc3f\ud94d\udc39\udbe4\udedd\udb96\udce7",
        59, 57117, -1006943721, -7842672662708702728L, -71040L, true, true, (char) 33004, (char) 10454,
        Double.longBitsToDouble(0x3fefe8e21e03d5efL), Double.longBitsToDouble(0x3f7b753661033700L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Object]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 2, "\ud80b\udda8\udabb\udc43\udac6\udf61\ud951\udd4b\udb00\udc41\udbe8\udc28\ud980\udf0f\ud8a8\ude14\u493e", "\ucb95\u0f39\ub2a6\u7e41\u697a\u73fb\u5088\u8ae3\u2837\uceae\u94dc\u4b3e", "\ud99b\udcc0\udb34\udfbd\uda4c\udfc7\ud936\udeb2\ud818\udff5\ud9ad\udfb5\ud8c7\udcd2\ud82a\udeee\uda35\udeab",
        59, 26950, 112558216, 7181975414945152116L, -60673L, false, true, (char) 942, (char) 19618,
        Double.longBitsToDouble(0x3fd8d15fe42f5054L), Double.longBitsToDouble(0x3fe6261fdb57f529L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class [I]\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class [I]\012",
        Z.run(T, 2, 1, 1, 2, "\ud946\ude82\ud914\udf83\ud922\udeeb\ud8e6\udc76\udb00\udc3e\uda37\ude1f\ud980\udf0f\ud9bd\udd7e\ud89e\udf81", "\ucb95\u9e8b\ub2a6\u49d0\u992e\u8beb\u2af0\u427f\u6774\ua1f1\u4096\u04be\u5bf7\u254f", "\uda4c\udfc7\ud981\udcfb\ud81a\udc13\udafe\udd5b\ud9d6\udf46\ud82a\udef6\udb1b\udf7e\udaa0\ude11\udb37\udec2\ud8ac\udced\udaa1\ude76\ud909\udecc\udbc4\uddec\ud94d\udc39\udbe4\udedd\udb96\udce7\udb2a\uddb1\ud891\udd69\ud9fd\ude8d\udb0c\udc64\ud9a3\udcd9\udb5f\udc88\uda93\udd37\udbb0\udd19\uda55\udf24\ud957\udf33\ud956\udd82\uda18\udff7\u6067\ud975\udcca\udbe2\udd59\udb81\udfc2\ud934\udcc3\udbb5\udfc1\udad5\udde2",
        47, 37795, -65885251, 2849693439996354717L, 40917L, false, true, (char) 35126, (char) 27637,
        Double.longBitsToDouble(0x3fdbc732f101974cL), Double.longBitsToDouble(0x3fc449835f9976acL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class [Ljava.lang.String;]\012",
        Z.run(T, 1, 1, 0, 2, "\ud80b\udda8\ud8a0\udd63\uda8b\ude0d\ud951\udd4b\udb00\udc41\uda37\ude1f\ud980\udf0f\ud8a8\ude14\u493e", "\u1dc6\u0f69\ub2a6", "\ud8e8\udeb6",
        34, 47405, -1246891955, 795107003036605608L, 19912L, false, true, (char) 97, (char) 20519,
        Double.longBitsToDouble(0x3fcef5d30950cb1cL), Double.longBitsToDouble(0x3fe7b77c5c9d4935L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 2, "\ud89b\udc78\ud886\udfe3\uda8b\ude0d\ud951\udd4b\udb00\udc41\uda37\ude1f\ud980\udf0f\udb98\ude8c\u486f", "\u6648\u0f39\ub2a6\u1184\u497b\u73fb\u669d\u8ae3\ubc89\uce84\u94dc\u77e0", "\ud99b\udcc0\udb34\udfbd\uda5d\udcc7\udb98\udf28\ud818\udff5\udafe\udd5b\ud9d6\udf46\ud82a\udef6\uda35\udeab\udaa0\ude11\udb37\udec2\ud8ac\udced\udaa1\ude76\ud935\uddef\ubd78\ud94d\udc39\udbe4\udedd\udb96\udce7",
        59, 57117, -1006943721, -7842672662708702728L, -71040L, false, false, (char) 33027, (char) 10454,
        Double.longBitsToDouble(0x3fefe8e21e03d5efL), Double.longBitsToDouble(0x3f7b753661033700L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Object]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 2, "\ud80b\udda8\ud8a0\udd63\uda8b\ude0d\ud951\udd4b\udb00\udc41\uda37\ude1f\ud95c\udefe\ud8b7\uddc5\ud972\udc8e", "\ucb95\u0f39\u91f2\u1184\u2910\u3de8\u669d\u8ae3\u2837\uceae\u94dc\u825b", "\ud99b\udcc0\udb34\udfbd\uda4c\udfc7\udb98\udf28\ud97a\udcc6\udb5f\ude0e\ud9d6\udf46\ud97e\ude80",
        45, 85100, 1886965935, 483433858288287895L, 71104L, true, false, (char) 2831, (char) 942,
        Double.longBitsToDouble(0x3fb9810f2c6e03e8L), Double.longBitsToDouble(0x3fe0bd4155d847dbL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.String]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 2, "\ud80b\udda8\ud8a0\udd63\uda8b\ude0d\ud927\udc96\ud8df\ude05\uda37\ude1f\ud9c9\udc74\ud9a4\udc4b", "\u2ee7\ucb95\u54c7", "\uda10\udca3\ud8e8\udeb6\ud8fd\udd34",
        0, 40956, 185125189, 5362529678780435853L, 6061L, false, true, (char) 64445, (char) 54251,
        Double.longBitsToDouble(0x3fe2a1963ef6ef8bL), Double.longBitsToDouble(0x3fc3a486bc3dbbc0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Long]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 8, "\ud8f7\udcfa\ud86b\udf63\uda8b\ude0d\udadd\uddf4\udaff\udfc4\udb5e\udf12\ud980\udf35\udb8e\udfe7\u488c", "\u9937\u53dc\u6e1d", "\ud806\udc76\ud8b1\udc5b\ud9c6\udf75\udad0\udf73\udaeb\udf8d\ud9a0\ude5e\udbdc\udd7d\ud8ff\udfb7\uda20\udefe\ud8ec\udd68\udb34\udfbd\uda4c\udfc7\udb98\udf28\ud818\udff5\ud96f\udc60\ud9d6\udf46\ud82a\udef6\uda35\udeab\udaa0\ude11\udb37\udec2\ud8ac\udced\udaa1\ude76\udb64\udcc1\uda9f\ude54\ud94d\udc39\ud8f8\udcd0\ud827\udc7a\uda73\ude25\udb6e\udc47\ud9fd\ude8d\udbf9\udc59\ud86c\udd97\udb5f\udc88\uda93\udd37\udbcc\udea6\uda67\ude24\ud957\udf33\ud956\udd82\uda18\udff7\uda82\udc75\uda7b\udc18\udaf1\udf96",
        -2, 57779, -864171670, 1509335121586140221L, -29154L, true, false, (char) 8380, (char) 1729,
        Double.longBitsToDouble(0x3fd26e74c6845732L), Double.longBitsToDouble(0x3fe97a8dcc5abe66L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Object]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 8, 15, "\ud80b\udda8\ud8a0\udd63\uda8b\ude0d\ud951\udd4b\udb00\udc41\uda37\ude1f\udac7\ude54\udb33\udf6b\u493e", "\ucbf9\u0f39\u6d05\u7c10\u1673\u7372\u669d\u8ae3\u2837\uac03\u20ef\u0b34", "\ud99b\udcc0\udb34\udfbd\uda4c\udfc7\udb98\udf28\ud818\udff5\udafe\udd5b\ud9d6\udf46\ud82a\udef6\uda35\udeab\uda37\udf5d\ud8ac\ude9c\ud8ac\udced\udaa1\ude76\ud935\uddef\uda97\udc3f\ud94d\udc39\udbe4\uded7\udb96\udce7",
        59, 57117, -1006943721, -7842672662708702728L, -71040L, true, true, (char) 33004, (char) 10454,
        Double.longBitsToDouble(0x3fefe8e21e03d5efL), Double.longBitsToDouble(0x3f7b753661033700L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Thread$State]\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Thread$State]\012",
        Z.run(T, 2, 1, 1, 13, "\ud80b\udda8\ud8a0\udd63\uda8b\ude0d\ud951\udd4b\udb00\udc41\uda2f\udc1f\ud980\udf0f\ud8a8\ude14\u493e", "\ucb95\u0f39\u608e\ub5c2\u2233\u741a\u669d\u8ae3\u2837\uceae\u94dc\u29a8", "\ud9ba\udf44\uda22\udfc3\udbeb\uded8",
        39, 94335, -276055468, 2897449490769763485L, 59180L, false, false, (char) 61792, (char) 34635,
        Double.longBitsToDouble(0x3fbd18eadd048b20L), Double.longBitsToDouble(0x3fe30c16afe0632fL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Integer]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 2, "\ud80b\udda8\ud8a0\udd63\uda8b\ude0d\ud951\udd4b\ud8b5\udc5d\uda37\udd4d\ud980\udf0f\uda79\udd17\udb22\ude3e\ud91b\udc5b\uda20\uddd4\ud919\udfd6\udb3e\ude5d\ud9b7\udc40\u7973\udb3a\ude9d\ud9df\udc66\ud8fd\udd34", "\ucf01\u94dc\u77e0\u5bf7\u254f\u0f08\u8b84\u74d9", "\u611e\ud865\udc0e\ud82a\udf37\uda35\udeab\udaa0\ude11\udb37\udec2\udad7\udef5\udaa1\ude76\ud935\uddef\uda97\udc3f",
        15, 22296, -941467480, 1537414608707892814L, 96615L, false, false, (char) 62402, (char) 33004,
        Double.longBitsToDouble(0x3fd89234d7fa3886L), Double.longBitsToDouble(0x3fe01eaf7f3edd4dL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.ArrayList]\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.ArrayList]\012",
        Z.run(T, 2, 1, 1, 2, "\ud946\ude82\ud914\udf83\ud922\udeeb\ud8e6\udc76\udb00\udc3e\uda37\ude1f\ud980\udf0f\ud852\ude08\udbd1\udfea", "\u0784\ud50f\ub2a6\u49d0\u992e\u8beb\u2af0\u427f\u6774\ua1f1\u4096\u04be\u5bf7\u4ae9", "\uda4c\udfc7\ud981\udcfb\ud81a\udc13\udafe\udd5b\ud9d6\udf46\ud9fe\udffb\udaeb\udc7e\udaa0\ude11",
        37, 27968, 1672183959, 3932314914139496790L, 50794L, false, false, (char) 59974, (char) 64638,
        Double.longBitsToDouble(0x3fdad5425ff29a4aL), Double.longBitsToDouble(0x3fe7062d47e3e3dfL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 0, 2, "\ud80b\udda8\ud8a0\udd63\uda45\uddea\udaed\udc57\udb00\udc41\uda37\ude1f\ud980\udf0f\ud8a8\ude14\ud85a\ude68", "\u776b\u1dce\ub2a6\u1184\u497b\u73fb\u669d\u8ae3\u2837\uceae\u94fe\u77e0\u7526", "\udb34\udfbd\uda4c\udfc7\udb98\udf28\ud818\udff5\udafe\udd5b\ud9d6\udf46\ud82a\udef6\uda35\udeab\udaa0\ude11\udb37\udec2\ud8ac\udced\udaa1\ude76\ud935\uddef\uda97\udc3f\ud94d\udc39\udbe4\udedd\udb96\udce7",
        0, 57097, -721731049, -7842501838974438920L, -5504L, true, true, (char) 33004, (char) 10454,
        Double.longBitsToDouble(0x3fefe8e21e82d5efL), Double.longBitsToDouble(0x3f7b753661033700L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Integer]\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Integer]\012",
        Z.run(T, 2, 3, 3, 2, "\ud80b\udda8\ud8a0\uddcf\uda8b\ude0d\ud951\udd4b\udb00\udc41\uda37\ude1f\ud95c\udefe\udbdc\udd92\uda75\udf36", "\ucb95\ub570", "\ud96c\udf72\uda35\udc57\ud897\ude84\uda9e\uddf9\udaf8\udfeb\ud9c0\ude41\udb0e\udd0a\udbc8\udefa\udbf0\ude72\ud9e3\udcc1\ud99b\udcc0\udb34\udfbd\uda4c\udfc7\udb98\udf28\udbcb\udd0f\ud85c\ude56\uda34\uddac\ud97e\ude80\ud871\udebf\udbd1\udd99\ud9ec\ude2b\uda64\udc36\udbc8\udf6b\uda93\udf24\uda54\udcd2\uda57\udd1d",
        1, 59720, -1065531290, -6329205037589642729L, -91121L, true, false, (char) 4876, (char) 20212,
        Double.longBitsToDouble(0x3fe3a0412399f57cL), Double.longBitsToDouble(0x3febdd729f41bb97L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.type.SimpleType|_narrow|java.lang.Class|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|_buildSuperClass|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings|static",
    "M|com.fasterxml.jackson.databind.type.SimpleType|buildCanonicalName||new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|construct|java.lang.Class|static",
    "M|com.fasterxml.jackson.databind.type.SimpleType|constructUnsafe|java.lang.Class|static",
    "M|com.fasterxml.jackson.databind.type.SimpleType|equals|java.lang.Object|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|getErasedSignature|java.lang.StringBuilder|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|getGenericSignature|java.lang.StringBuilder|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|isContainerType||new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|refine|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|toString||new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|withContentType|com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|withContentTypeHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|withContentValueHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|withStaticTyping||new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|withTypeHandler|java.lang.Object|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
    "M|com.fasterxml.jackson.databind.type.SimpleType|_narrow|java.lang.Class|new:com.fasterxml.jackson.databind.type.SimpleType:com.fasterxml.jackson.databind.type.TypeBase",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
