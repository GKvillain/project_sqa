package com.fasterxml.jackson.databind.type;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 13, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud822\ude45", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u658e\u8b63\u483c\u86c9\u32a6\uaa7c", "\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29\uda91\udd65",
        -1, 62143, 1795423071, -5769521168377775263L, -68001L, true, false, (char) 20080, (char) 62963,
        Double.longBitsToDouble(0x3fc5f187aae1d128L), Double.longBitsToDouble(0x3fe31bfe94509356L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 13, "\ud8c9\udf8b\udb16\udc15\udb86\udcf8\ud826\udca4", "\u57f4\ub684\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u658e\u8b63\u483c\uadc4\uaee3\u9846", "\udbe7\udf97\udbb6\udd34\ud898\udd9b\udbed\ude29\uda91\udd65",
        -1, 62143, 1795423071, -5769521169274438815L, -68182L, true, false, (char) 20080, (char) 62963,
        Double.longBitsToDouble(0x3fc5f187aae1d128L), Double.longBitsToDouble(0x3fe567fe94509356L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Number] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 13, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud822\ude45\ud8f7\udc05\ud970\udcf3\ud946\uddbb\ud8d5\udc6f\udbb4\udd21\ud839\udef0\uda94\ude77\udbcb\udd28\ud88d\udfb7\uda1c\udf2b\ud801\ude67\ud879\udda2\ud85d\udf07\udaff\udf13\udb16\uddd6\ud89d\udee1\udb2a\udd30\udbf5\udca3\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29", "\u8d8e", "\uda38\udc3d\udaf7\udfae\ud99a\udd7d\udb0a\udd05\ud862\udc27\uda2a\udc3b\ud978\udf89\ud972\ude40\udaa5\udffb\udb68\udee2\ud8a9\udfa9\ud8cb\udf01\ud964\udfea\ud87a\udc5f",
        7, 65226, -1278367453, 7021456639034827249L, -40319L, false, true, (char) 45398, (char) 54344,
        Double.longBitsToDouble(0x3fd61a40620ab690L), Double.longBitsToDouble(0x3febaaa7f41fcc01L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class int] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 13, 13, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud81d\udd45", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u3de2\u87e1\u8b3d\u483c\u86c9\u32a6\uaa7c", "\ud9b3\udf3d\ud83c\udf70\u0cb2\udbed\ude29\uda91\udd65",
        44, 62143, 1795423071, -5769521168377775263L, -68001L, true, false, (char) 20080, (char) 40670,
        Double.longBitsToDouble(0x3fc5f18fcae1d128L), Double.longBitsToDouble(0x3fe3430e94509356L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Long] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 3, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud822\ude45", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u658e\u8b63\u483c\u86c9\u32a6\uaa7c", "\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29\udb83\uded5",
        40, 62143, 1795423071, -5769521168377775263L, -68001L, true, false, (char) 20080, (char) 62963,
        Double.longBitsToDouble(0x3fc5f187aae1d128L), Double.longBitsToDouble(0x3fe31bfe94509356L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |a4=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 12, 9, "\ud9d7\udd84\ud859\ude4f\uda9f\ude07\ud822\ude45", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u658e\u8b63\u483c\u86c9\u32a6\uaa7c", "\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29\uda91\udd65",
        -1, 62143, -155210772, -5769521168377775263L, -68001L, true, false, (char) 20080, (char) 62963,
        Double.longBitsToDouble(0x3fc5f187aae1d128L), Double.longBitsToDouble(0x3fe31bfe94509356L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ArrayType:[array type, component type: [simple type, class java.lang.String]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 9, "\ud9d0\udf22\u1b31\ud8b2\udccf\ud867\udc86", "\uc782\u413e\u5427\u91d1\ub4cd\u1ac9\ub396\u67bc\u5695\u87b6\u8c1e\ubb75\u32a6\uaa7c", "\ud9b3\udf3d\ud83c\udf70\ud94e\udfea\ud9e6\udd64\ud839\udd53",
        34, 62143, 1795423071, -5769521166498727071L, 33123L, false, true, (char) 53536, (char) 36493,
        Double.longBitsToDouble(0x3fc5f187aae1d128L), Double.longBitsToDouble(0x3fe113fe94509356L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 13, "\udad3\udf30\udb9f\udd5d\ud93d\udfb4\ud822\ude64", "\u55fd\u413e\u4dc2\u0118\ub40d\u636c\ucd10\ua2c0\ud0b9\u8b63\ua6e6\ua129\u3290\uaa7c", "\ud94c\udc89\ud83c\udf70\ud90e\udf1d\udbed\ude29\uda91\udd65",
        -1, 51471, 335778076, -4916034789259150495L, 30166L, false, true, (char) 37100, (char) 61186,
        Double.longBitsToDouble(0x3fe31bfe94509356L), Double.longBitsToDouble(0x3faa39d88831bbd0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Number] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 4, 5, "\ud8ed\udfba\udb9f\udd5d\ud8b2\udccf\ud82b\udf45", "\u55fd\u413e\u3c28\ua7c2\u6b3f\u346a\ub326\u9147\u52bc\u80f1\u483c\u86c9\u32a6\u094d", "\udbb4\udc3d\ud805\udf29\ud882\udd51\uda0d\ude73\udab6\udda2\udbb3\ude8e\udbe4\udc9c",
        21, 78673, -893507231, -2991109091875650815L, 30166L, false, true, (char) 37100, (char) 61186,
        Double.longBitsToDouble(0x3fe31bfe94509356L), Double.longBitsToDouble(0x3fc75af05d07bcc8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Long] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 15, 2, "\udb47\udc02", "\uca67\u4e71\u5e8c\u04b4\u6f1b\u3c28\u3b4d", "\ud85b\uded2\uda51\ude16\udaa6\ude26\ud93e\udee8\uda0e\udcc6\udaff\udf13\udb16\uddd6\ud983\udc74\udb27\ude1f\udb45\udea0\udaa5\udfc7\udbdb\udd88\ud890\udcfe\ud942\udf73\udbab\udcf0\udbb3\ude46\ud9b8\udfa6\udb12\udd2d\udab1\udc8e\uda15\udd66\ud8bf\udc31\ud999\ude69\udb0a\udd05\ud92a\udf15\uda2a\udc77\udbc3\udf91\ud972\ude40\udaa5\udffb\uda58\udc21\udb7d\ude48\udb45\udc37\udae1\udc81\uda75\udc20\uda43\udcaf",
        54, 88578, -1402202832, 220812166154725311L, -37966L, false, false, (char) 32683, (char) 63886,
        Double.longBitsToDouble(0x3fd63ee5773a9fc4L), Double.longBitsToDouble(0x3febd4247fa3da62L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 11, 19, "\ud867\udcc9", "\uca67\u0a00\u33f9\u98de\u69af\u2a8a\u91d1\ub4c5\u591d", "\ud8ca\ude51\ud871\ude6a\ud85d\udf07\udaeb\ude29\ud9f5\udd67\uda77\udd44\ud948\udf21\udb12\udc19",
        13, 82152, -983882848, -5844263099854203047L, 38735L, true, true, (char) 56920, (char) 47134,
        Double.longBitsToDouble(0x3fe10e55f4acd67dL), Double.longBitsToDouble(0x3fc6425d51d9879cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 1, 16, 13, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud822\ude45", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u658e\u8b63\u483c\u86c9\u32a6\uaa7c", "\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29\uda91\udd65",
        -1, 62143, 1795423071, -5769521168377775263L, -68001L, true, false, (char) 20080, (char) 62963,
        Double.longBitsToDouble(0x3fc5f187aae1d128L), Double.longBitsToDouble(0x3fe31bfe94509356L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 16, 13, "\udacb\ude16\udb9f\udd5d\ud8b2\udccf\udaef\ude4a", "\u260c\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u658e\u8b63\u483c\u86c9\u32a6\uaa7c\ua654\u5451", "\ud890\udcfe\ud9a0\udc01\ud90b\ude5a\udbb3\ude8e\udbe4\udc9c\udacd\ude36",
        58, 92529, -696421855, -1851116880132408271L, -18195L, false, true, (char) 61186, (char) 22069,
        Double.longBitsToDouble(0x3fb424d5a6ec21d0L), Double.longBitsToDouble(0x3fed024e8d0b41b1L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.Date] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 13, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud822\ude45", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u658e\u8b63\u483c\u86c9\u32a6\uaa7c", "\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29\uda91\udd65\udbb3\ude8e\udbe4\udc9c\ud9de\uddad\uc659\uda38\udc3d\udaf7\udfae\ud99a\udd7d\udb0a\udd05\ud862\udc27\uda2a\udc3b",
        24, 67408, -1823025565, 3301565478994868368L, -22782L, true, false, (char) 20335, (char) 5500,
        Double.longBitsToDouble(0x3fedf9ceade06af4L), Double.longBitsToDouble(0x3fd9432c620e8884L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class java.lang.Object]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 13, "\ud82c\udc80\udb6c\udc7b\ud8b2\udccf\ud854\udddc", "\uba34\u418a\u2cf3\u5fe2\u2de0\u346a\ub326", "\ud879\udda2\ud85d\udf07\udaff\udf13",
        51, 89599, 963446719, -2795167040867833103L, -83297L, false, false, (char) 51475, (char) 23720,
        Double.longBitsToDouble(0x3fe1bb38035fa0f2L), Double.longBitsToDouble(0x3fe88b581b61af1bL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 10, 13, "\udab2\ude56\udb37\udf44\ud8b2\udcf8\ud840\udf45", "\u55fd\u413e\u5e36\u91d1\ub40d\u346a\ub326\u67bc\ua168\u0606\u6d7f\u86c9\u32a6\uaa7c", "\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\ud985\udd2b\uda91\udd65",
        -1, 72463, -885995880, -5769521168377775263L, -68001L, true, false, (char) 20080, (char) 62963,
        Double.longBitsToDouble(0x3fc5f187aae1d128L), Double.longBitsToDouble(0x3fd0f952e8a126acL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 7, 12, 0, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\udaa8\ude48", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u658e\u8b63\u483c\u86c9\u32a6\uaa7c", "\ud983\udf45\ud963\udf37\ud890\udcfe\udbed\ude29\ud911\udf6c",
        -1, 62143, 1795423071, -5769521168377775263L, 83295L, false, true, (char) 10334, (char) 50118,
        Double.longBitsToDouble(0x3fce477b2ae1d128L), Double.longBitsToDouble(0x3fe31bfe94509356L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 16, 13, "\u6013\ud885\udf79\ud8b2\udccf\ud865\udef0", "\u55fd\u413e\u39a8\u80ee\u9e3a\ucfcd\u2ec6", "\ud866\udec3\ud85d\udf07",
        30, 27566, -865378401, 4137972148892701283L, -98815L, true, true, (char) 43855, (char) 15584,
        Double.longBitsToDouble(0x3fe80eb3eff6584eL), Double.longBitsToDouble(0x3fbd9474b875b728L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Object] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 8, 0, 19, "\ud9d1\udeea\uda07\udc2c\ud8ae\uddba\uda0b\udd94\udaaf\udee5\ud829\ude16\ud913\udc74\ud963\udc71\ud894\udc7e\ud839\udef0\uda94\ude77\udbcb\udd28\uda45\uddfa\udb87\udced\ud96a\ude7d\udaad\uddfc\ud868\udc5a\ud94b\udf61\uda8c\udcb9\ue465\ud952\uddc6\ud974\udef7\udbbe\udcf9\ud925\udc72\ud890\udcfe\udbed\ude29\uda91\udd65\udbb3\ude8e", "\u84cb\u503b\u48ee", "\uda31\udeee\uda20\ude0e\ud8e9\udcc2\uda5e\udf57\ud801\udd13\ud88c\udde3\ud887\udcad\ud800\udcc4\ud87b\udff3",
        17, 50713, -1098471389, 4330601290257883850L, -55108L, false, false, (char) 8976, (char) 34606,
        Double.longBitsToDouble(0x3fb02f290277a6b0L), Double.longBitsToDouble(0x3fe653006911e996L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Integer] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 13, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud822\ude45", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u658e\u8b63\u95c3\u878a\u3212\u550a\u3e38\u5469\u0bcc\u2aa8\u7c27\u1691\u0e22\uaa90\u8d8e\uc234", "\udaf7\udfae\ud99a\udd7d\udb0a\udd05\ud9b4\udfa0\ud909\uddba\ud978\udf1b\ud972\ude40\udaa5\udffb\ud81d\udf8d\ud9d2\udf6b\uda46\udf59\uab8c\udba0\udd9f\ue4ec\ud9d4\ude7c\udb8d\udec8\ud930\ude7f\uda41\ude2f\ud878\udcbd\ud8da\udfbc\uda46\udf8f\udab7\udf95\ue757\ud80a\uddfa\udbde\udd61\ud9ca\ude4f\uda1e\udd58\udb1f\ude7a\ud8fe\udc18\ud9dd\ude58\ud9c1\udf67\ud877\udd3a\uda90\udedb\udadd\udea7\ud9ed\udeac\uda9c\udda2\udb3f\udc1c\ud937\udd9f\ue58e",
        15, 62690, -1381119081, -6709167278141492033L, 88944L, false, true, (char) 64563, (char) 35242,
        Double.longBitsToDouble(0x3fe408e272956b29L), Double.longBitsToDouble(0x3fd1726e52dbc2d6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class java.lang.Object]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 4, 14, "\udad3\udf30\uda51\uddd6\udb1d\udcee\udaf9\udfe2\ud8c7\udd4d\ud86d\udcaa\ud940\udc50", "\uabb0\u9097\u454d\u688c\u1240", "\udbbf\udd0f\ud9c6\udf77\udb16\uddd6\udb43\udc94\ud948\udf21\udb12\udc19\uda1f\udc12\ud83c\udf22\uda24\ude12",
        -5, 1948, 1728067709, 8586760312315930333L, -33281L, true, false, (char) 22910, (char) 12397,
        Double.longBitsToDouble(0x3fae5bc3943b6e50L), Double.longBitsToDouble(0x3fc5f19576e1d128L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.List, contains [simple type, class java.lang.Object]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 13, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud822\ude45", "\u55fd\u413e\u2516\ub444\ub40d\u346a\ub326\u67bc\u658e\u8b63\u483c\u86c9\u32a6\uaa7c\ua3ce\u5469\u7880\u2aa8\u7c27\u1691\u0e22\uaa90\u8d8e\uc234\u3c2b\u0c43\u48ee\u6c8e", "\uda2a\udc3b\ud978\udf89\ud972\ude40\udaa5\udffb\udb86\ude21\uda64\udc8e\ud832\uddb7",
        46, 38315, 1748248469, -8598271631922715571L, -83966L, false, false, (char) 53938, (char) 54227,
        Double.longBitsToDouble(0x3fe974bfc5923616L), Double.longBitsToDouble(0x3fedb021e891e0e5L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Long] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 13, "\udad3\udf30\udb3b\udf46\uda94\ude93\ud822\udee2", "\u17eb\ua260\u3c28\u91d1\ub40d\u346a\u3c8a\u67bc\u658e\u8b63\u483c\u86c9\u32a6\uaa7c", "\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29\uda91\udd65\ud93e\ude2e\ud9aa\udf22\ud9de\ude44",
        -2, 66649, 1481560271, 1968944057896188767L, 80360L, true, false, (char) 40075, (char) 12341,
        Double.longBitsToDouble(0x3fb4150ab672a880L), Double.longBitsToDouble(0x3fdec2baa045dc6aL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Number] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Number] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 4, 3, 19, "\u43b1\ud9de\udde0\udaf7\udfa3\ud954\udf73", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u45d7\u8b63\u483c\u8248\uc61e\uaac1", "\udb4a\udcf0\ud8d9\udf33\udb00\udda3\ud963\udd2d\udbb1\udf8c\ud8ac\udd4c\udbe4\udc9c",
        49, 78673, -893453471, -2991109091875650815L, 30166L, false, true, (char) 4692, (char) 17241,
        Double.longBitsToDouble(0x3fdf662d48a126f2L), Double.longBitsToDouble(0x3fe3b0380785631dL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class int] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 16, 13, "\udb6b\udd45\udb9f\udd5d\ud8b2\udccf\ud822\ude45", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u658e\u8b63\u483c\u150a\u6132\uaa7c", "\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udafd\udd29\uda91\udd65",
        16, 76442, 1795423071, -5769521168377775263L, -68001L, true, false, (char) 58233, (char) 25102,
        Double.longBitsToDouble(0x3fb9c45995c3a250L), Double.longBitsToDouble(0x3fe31bfe94509356L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Comparable] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 9, "\udad3\udf30", "\uca67\u0472\u5e8c\u55fd\u413e\u3c28\u91d1", "\ud88d\udfb7\uda1c\udf2b\ud801\ude67\ud879\udda2\ud85d\udf07\uda70\udfac\udb16\udd43\udb43\udc94\ud948\udf21\udb12\udc19\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29\uda91\udd65\udbb3\ude8e\udbe4\udc9c\ud9de\uddad\uc659\uda38\udc3d\udaf7\udfae\ud99a\udd7d\udbaf\udd98\udacd\udc20\ud84a\udcb7\ud978\udf89\ud972\ude40\ud944\udf2a\udb97\udf65\udb0f\udf7e\ud82e\ude2a\ud877\udc51\ud968\udc0d\udbb7\udeba\udab0\udec9\ud87d\udc1d\udae4\udfda\ud9d7\udd78\ud97f\udfcf\ud9a3\ude0f\udaf0\udd06\uda33\udc00\uda8c\udece",
        36, 10450, -388278905, 7054361542079210491L, 92579L, true, false, (char) 3513, (char) 49150,
        Double.longBitsToDouble(0x3fe2ad51f6f4bf65L), Double.longBitsToDouble(0x3fd11a02e18d9368L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 13, "\udad3\udf30\udb9f\udd5d\ud8dc\udfcf\ud822\ude45", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u658e\u8b63\u483c\u86c9\u32a6\uaa7c", "\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29\uda91\udd65",
        -1, 95899, 1794321010, -8460366678092490399L, -68001L, true, false, (char) 20080, (char) 62963,
        Double.longBitsToDouble(0x3feba461eab874b4L), Double.longBitsToDouble(0x3fe31bfe94509356L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 16, 3, "\ud92c\udc71\udba6\udeb2\ud8b2\udccf\ud822\ude45\ud8f7\udc05", "\u0c00\u3c28\ud056\ub46d\u346a\ub326\u4dbf\u650c\u8b63\u483c\u86c9\u529b\uaa4a\uade0\u6d78\uacc5\u2aa8\u7c27\u1691\u0e22\uaa90", "\uda65\udd3c\uda38\udc3d\udaf7\udfae",
        -5, 52289, -1226441610, -8341441603507190609L, -45164L, false, false, (char) 31243, (char) 8500,
        Double.longBitsToDouble(0x3f9c5667ccf06520L), Double.longBitsToDouble(0x3fedc3077bd60606L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Integer] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 13, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud822\ude45", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u658e\u7e51\u483c\u86c9\u32a6\uaa7c", "\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29\uda91\udd65\udbb3\ude8e\udbe4\udc9c\ud9de\uddad\uc659\uda38\udc3d\udaf7\udfae\ud99a\udd7d\udb0a\udd05\ud862\udc27\uda2a\udc3b\ud978\udf89\ud972\ude40\ud83b\udde4\ud9fe\udd0a",
        29, 76489, -1719930663, 334056932260546355L, -13127L, true, true, (char) 28255, (char) 36775,
        Double.longBitsToDouble(0x3fead52d4d1c69dbL), Double.longBitsToDouble(0x3fe4cea2893697daL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Long] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 3, 16, 13, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud822\ude45", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u658e\u8b63\u483c\u86c9\u32a6\uaa7c", "\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29",
        -2, 57709, -1594726857, 7711283371085564689L, 67391L, true, true, (char) 25217, (char) 31753,
        Double.longBitsToDouble(0x3fe875b72caf8c3dL), Double.longBitsToDouble(0x3fe5c3a256637fd2L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.String] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 0, 12, "\uda01\udc46\udb9f\udd5d\ud8b2\udccf\ud822\ude45\ud8f7\udc05\ud970\udcf3", "\u3c28\u91d1\ub40d\u346a\ub326\ub0b1\u658e", "\udaff\udf13\udb16\uddd6\udb43\udc94\ud948\udf21\udb12\udc19\ud9b3\udf3d\ud83c\udf70\udbf1\udecf\udbed\ude29\uda91\udd65\udbfa\udf32\udbe4\udd46\ud9de\uddad\uc659\uda38\udc3d\udaf7\udfae\ud99a\udd7d\udb0a\udd05\ud862\udc27\uda2a\udc3b\ud978\udf89\ud972\ude40\udaa5\udffb\ud805\ude01\udbe2\ude50\ud843\uddec\ud9b1\udd04\udb05\udc17\udaaa\uddc8\ud9cd\udf2b\ud98d\udd19\uda3e\ude28\ud853\uddae",
        14, 20810, 1080178416, -4774912957810573203L, -2633L, false, true, (char) 43102, (char) 38600,
        Double.longBitsToDouble(0x3fe0001ea1d7c3f4L), Double.longBitsToDouble(0x3fe6dd3d977fcd79L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 16, 13, "\udad3\udf30\ud8e6\ude60\udb1d\udf6c\ud822\ude45", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u658e\u8b63\u483c\u86c9\u32a6\u4966", "\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29\ud88e\udda3\udbb3\udea1\udbe4\udc9c\ud9de\uddad\udaec\ude82\ud8a4\udfb4\udaf7\udfae\ud99a\udd7d\udb0a\udd05\ud862\udc27\uda2a\udc3b\ud978\udf89\ud972\ude40\udaa5\udffb\udac1\udc3f\ud98c\udc74\udbd1\udcb3\ud8b9\udc4f\udab6\udce3\udaaf\udc48\u62bc\udaef\udfc4\ud858\udcb4\ud956\uddc6\udb7c\udedc\uda35\ude60\udbbf\ude0d\ud914\udd1a\ud943\udd06\udae0\ude07\ud842\udfb2\uda66\ude37\ud8af\udc50\ud914\ude93\udb39\udef8\udb80\ude02\udb25\udd26\udb0a\udfb7\ud969\udf88\ud9ec\udd74\udb6d\ude6c\ud928\udd55\ud9b6\udf37\ud8ad\udd9f",
        57, 42597, 1229334428, -5619478711502510682L, 54170L, true, false, (char) 2897, (char) 31503,
        Double.longBitsToDouble(0x3fd6ef21b824ba9cL), Double.longBitsToDouble(0x3fecd671d6fbe362L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class java.lang.Object]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 13, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud822\ude45", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u658e\u8b63\u483c\u86c9\u32a6\u009f", "",
        -5, 17160, -72072897, -7651672477043838140L, -73833L, true, true, (char) 62995, (char) 43855,
        Double.longBitsToDouble(0x3fe10e55f300007dL), Double.longBitsToDouble(0x3fa8f327c7651fa0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.Date] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 13, "\udad3\udf30\udb9f\uddf5", "\u4e71", "\ud8d5\udc6f\ud972\udd2d\ud839\udef0\uda94\ude77\udbcb\udd28\ud88d\udfb7\uda1c\udf2b\ud801\ude67\ud879\udda2\ud85d\udf07\udb65\ude67\udb16\uddd6\udb43\udc94\ud948\udf21\udb12\udc19\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29\uda91\udd65\ud907\ude0a\udbe4\udc9c\ud9de\uddad\uc659\udadd\udcdb\udaf8\udc1f\ud99a\udd7d\udb0a\udd05\ud862\udc27\ud988\udf90\ud978\udf89\udad3\udf52\udbb6\udffd\ud95a\udd2c\ud8fe\ude9c\udb8b\udead\udbe3\udf6b",
        10, 2384, 2010617613, -3625507977228504988L, -92652L, true, false, (char) 40184, (char) 42477,
        Double.longBitsToDouble(0x3f9b95a91ca5c360L), Double.longBitsToDouble(0x3fd12ef33295d6f2L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class java.lang.Object]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 13, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud822\ude45", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326", "\ud879\udda2\ud85d\udf07\udaff\udf95\udb16\uddd6\ud822\udee3\ud948\udf21\udb12\udc19\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29\uda91\udd65\udbb3\ude8e\udbe4\udc9c",
        37, 60789, -893453471, -2991109091875650815L, 30166L, false, true, (char) 1526, (char) 56806,
        Double.longBitsToDouble(0x3fc5f369baec0420L), Double.longBitsToDouble(0x3fc47deff3082c54L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.String] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 3, 16, 13, "\ud8c9\udf8b\udb16\udc15\udb86\udcf8\ud826\udca4", "\u57f4\ub684\u3c28", "\udbcb\udd28\ud88d\udfb7\uda1c\udf2b\ud801\ude67",
        56, 36491, 2065843482, -8849244291704432768L, 3011L, true, false, (char) 44199, (char) 6572,
        Double.longBitsToDouble(0x3fbb3eed1a24ae78L), Double.longBitsToDouble(0x3fbf490af71b3800L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Long] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 13, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud822\ude45\ud8f7\udc05\ud970\udcf3\ud946\uddbb\ud8d5\udc6f\udbb4\udd21\ud839\udef0\uda94\ude77\udbcb\udd28\ud88d\udfb7\uda1c\udf2b\ud801\ude67\ud879\udda2\ud85d\udf07\udaff\udf13\udb16\uddd6\ud89d\udee1\udb2a\udd30\udbf5\udca3\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\ud9d0\udcba", "\u8d8e\uc234\u3c2b\u0c43", "\udb0a\udd05\ud862\udc27\uda2a\udc3b\ud978\udf89\ud972\ude40\udaa5\udffb\udb68\udee2\ud8a9\udfa9\ud8cb\udf01\ud964\udfea",
        54, 76332, -746222774, -5490546402536844336L, -38454L, true, false, (char) 54344, (char) 60775,
        Double.longBitsToDouble(0x3fd055b48eeaa9fcL), Double.longBitsToDouble(0x3f9fcc01e5a738e0L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.Date] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 8, 13, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud822\ude45\ud8f7\udc05\ud970\udcf3\ud946\uddbb\ud8d5\udc6f\udbb4\udd21\ud839\udef0\uda94\ude77\udbcb\udd28\ud88e\udc8b\uda1c\udf2b\ud801\ude67\ud879\udda2\ud85d\udf07\udaff\udf13\udb16\uddd6\ud89d\udee1\udb2a\udd30\udbf5\udca3\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29", "\u4107\uc218\u3c2b\u0c43\u48ee\u6c8e\u455a\u05d2\u95da\u8682\uc236\uc599\uafa1\u06c2\u097a", "\ud98c\udd88\udbe4\udcaa\ud9af\udca5\ud80d\udf5b\ud9f9\udcb9\uda8c\udff9\uda26\ude2f\udb5d\ude61",
        38, 29185, 1531464033, 6124588750082250613L, 44401L, false, false, (char) 24339, (char) 6853,
        Double.longBitsToDouble(0x3fa93fd779328450L), Double.longBitsToDouble(0x3fc94741c09f6a34L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 16, 13, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud822\ude45\ud8f7\udc05\ud970\udcf3\ud946\uddbb\ud8d5\udc6f\udbb4\udd21\ud839\udef0\uda94\ude77\udbcb\udd28\ud88d\udfb7\uda1c\udf2b\ud801\ude67\ud879\udda2\ud85d\udf07\udb72\udc6d\udb16\udd6a\ud942\udf94\ud9d2\udc2f\udbf5\udca3\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udb87\uddcd", "\u8d8e", "\uda38\udc3d\udaf7\udfae\ud99a\udd7d\udb0a\udd05\ud862\udc27\uda2a\udc3b\ud978\udf89\ud972\ude40\udaa5\udffb\udb68\udee2\ud8a9\udfa9\ud8cb\udf01\ud964\udfea\ud87a\udc5f",
        7, 65226, -979523293, 7021456639034827249L, -40319L, false, true, (char) 45398, (char) 54344,
        Double.longBitsToDouble(0x3fd61a40620ab690L), Double.longBitsToDouble(0x3febaaa7f41fcc01L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class java.lang.Object]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 5, 15, "\udbff\udde5\udbc0\udf56\ud8a8\uddcf\ud81d\udd45", "\uc3ea\uc838\ucac9\u91d1\ub40d", "\ud9ca\udde2\ud961\ude2e",
        -5, 4204, 472364395, 6193800537451487135L, 3011L, true, false, (char) 26105, (char) 54769,
        Double.longBitsToDouble(0x3fd1e0b8b4cd8566L), Double.longBitsToDouble(0x3fd31bf44bc9e6e2L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ArrayType:[array type, component type: [simple type, class java.lang.String]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 13, 13, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud81d\udd45", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u3de2\u87e1\u8b3d\u483c\u86c9\u32a6\uaa7c", "\ud94f\udeaa\ud83c\udeb2\u0cb2\udbed\ude29\uda91\udd65",
        34, 62151, 1795423071, -5769521168377775263L, -68001L, true, false, (char) 20080, (char) 40670,
        Double.longBitsToDouble(0x3fc5f18fcae1d128L), Double.longBitsToDouble(0x3fe3430e97069356L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 8, 8, 3, "\uda9f\udfd6\udbab\udde2\ud8b2\udccf\ud822\ude45", "\u55fd\u413e\u3c28\u91d1\ub40d\u4722\ub363\u67bc\u658e\u8b63\u483c\u86c9\u32a6\uaa7c", "\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29\udb83\uded5",
        40, 62143, 1795423071, -5769521168377775263L, -68001L, true, false, (char) 20080, (char) 62963,
        Double.longBitsToDouble(0x3fc5f187aae1d128L), Double.longBitsToDouble(0x3fe31bfe94b70c56L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class java.lang.Object]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 16, 15, "\udad3\udee0\ud8e3\udf56\udaa6\udd37\ud822\ude94", "\u2373\u7b07\u261a\u91d1\u8c0c\u28e5\ub7ef", "\ud879\udda2\ud85d\udf07\uda91\udf1c",
        51, 99287, 1528906680, 5082319202500758895L, -83297L, false, false, (char) 5396, (char) 21356,
        Double.longBitsToDouble(0x3fd33aeca6bf403cL), Double.longBitsToDouble(0x3fe88c701b61afeeL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=null |a4=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=null |a4=[Lcom.fasterxml.jackson.databind.JavaType;:[[]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 14, 14, 9, "\uda9b\udf19\udaf1\udf89\uda9f\ude07\ud822\ude45", "\u55fd\u413e\u3c28\u91d1\u7b07\u4b55\u98bb\u67bd\u658e\u8b63\u483c\u82ab\u32a6\u7f1e", "\ud9b3\udf3d\ud83c\udf70\udaa3\ude48\udbed\ude29\uda91\udd65\udbb3\ude8e",
        30, 25228, -1343321327, -3837353439139106271L, -66257L, true, false, (char) 62963, (char) 15845,
        Double.longBitsToDouble(0x3fe4dc58be630cd2L), Double.longBitsToDouble(0x3fefc49ab0459580L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ArrayType:[array type, component type: [simple type, class java.lang.String]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.ArrayType:[array type, component type: [simple type, class java.lang.String]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 1, 4, 9, "\ud9d7\udd84\ud912\udfab\udba9\udf0a\ud864\udf2e", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u658e\u8b63\u483c\u86c9\u32a6\uaa7c\ua3ce\u5469", "\udb6b\ude8d\udbed\ude29\udaef\udd74\ud89f\udc73",
        34, 25228, -1343321327, -3848495013801659871L, -721L, false, false, (char) 62963, (char) 37100,
        Double.longBitsToDouble(0x3fc3ae89598dfc34L), Double.longBitsToDouble(0x3fb424d587d88680L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=null |a4=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 9, "\ud9d7\udd84\ud859\ude4f\uda9f\ude07\ud822\ude45", "\u55fd\u413e\u27f7\u2a23\ub4c8\u7252\u259f\u67a8\u658e\u8b63\u483c\u86c9\u32a6\uaa7c", "\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29\uda91\udd65",
        -1, 62143, -155210772, -5769521168377775263L, -68001L, true, false, (char) 20080, (char) 62963,
        Double.longBitsToDouble(0x3fc5f187aae1d128L), Double.longBitsToDouble(0x3fe31bfe94509356L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.Date] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.Date] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 4, 4, 5, "\ud8ed\udfba\udb9f\udd5d\ud8b2\udccf\ud8cb\udd53", "\u55fd\u413e\u3c28\ua7c2\u6b3f\u346a\ub326\u9147\u61bb\u808f\u483c\u86c9\u32a6\u094d\u56e4\ua454", "\udafe\udcf1\uda0d\ude73",
        52, 57709, -1594726857, 7711283371085564689L, 67391L, true, true, (char) 25217, (char) 20080,
        Double.longBitsToDouble(0x3fe8774893f27c3dL), Double.longBitsToDouble(0x3fe6a4cda6637fd2L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Number] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Number] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 4, 4, 6, "\ud9b7\udc22\udbb2\udd6e\ud8b2\udccf\ud82b\udf45", "\u55fd\u7e04\u3c28\u2e47\u6bbe\u346a\ub326\u9184\u52bc\u80f1\u483c\u86c9\u32a6\u094d", "\udbb4\udc3d\ud9dc\udc95\uda89\udf83\ud82a\ude48\udbf4\udda1\udbb3\ude8e\udbe4\udc9c",
        21, 78673, -289527455, -2991109091875650815L, 30166L, false, true, (char) 37100, (char) 61186,
        Double.longBitsToDouble(0x3fe31bfe945cfd7eL), Double.longBitsToDouble(0x3fc74b3c7d07bcc8L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.List, contains [simple type, class java.lang.Object]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.List, contains [simple type, class java.lang.Object]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 18, 9, 4, "\ud8b6\udc5b\udb98\udde9\ud8b2\udc7d", "\u5e8c\u04b4\u6f1b\u1d27\u3b4d\u9541\u9373\ud27d\u7256\u7d51\u8636\u19dd\u86c9\u32a6\uc7f0\u3181\ua165\u9883", "\ud942\udf73\u1b40\uda22\udf7f\ud9b9\udc63",
        32, 22913, -893489014, 2522985701886099437L, -30543L, false, false, (char) 22069, (char) 6717,
        Double.longBitsToDouble(0x3fe858a6d798f322L), Double.longBitsToDouble(0x3fb3fc32059dfbe0L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=null |a4=[Lcom.fasterxml.jackson.databind.JavaType;:[[null, null, null]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 15, 2, "\ud93c\udce3\udb98\udde9\ud8b2\udc7d\ud822\ude45\ud8f7\udc05\ud970\udcf3\ud92a\udf85\udb45\udc29\udbb4\udd21\ud9c8\ude97\uda92\udfbe\ud900\ude74\udb6f\udcdc\udaee\udfaa\ud8fc\udee4\ud93e\ude33", "\u32a6\uc7f0\u3181\ua165\u0d34\u0498\u7c27\u97ff\u3145\uaa48\u24b6\u0a48\u1a40\u596b\u73a0\u697a\u455a\u48c1\u0825\u532e\uc236\uc599", "\udb45\udc37\udada\udffd\uda3e\udc1d",
        1, 34791, 1034430578, 8894069611451088550L, -15590L, true, true, (char) 63886, (char) 8819,
        Double.longBitsToDouble(0x3fecea7f137a848fL), Double.longBitsToDouble(0x3fed1ed314c913b4L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Object] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Object] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 19, 19, 15, "\udb47\udc48", "\uca67\u5fdc\u96e7\u04b4\u6f1b\u3c28\u3b4d", "\ud85b\uded2\uda51\ude16\udaa6\ude26\ud93e\udee8\uda0e\udcc6\udaff\udf13\udb16\uddd6\ud983\udc74\udb27\ude1f\udb45\udea0\udaf0\ude8c\udbdb\udcd5\ud890\udcfe\ud947\udcf6\udbab\udcf0\udbb3\ude46\ud9b8\udfa6\udb12\udd2d\uda9b\udf8e\uda15\udd66\ud8bf\udc31\ud999\ude69\ud847\ude4d\ud92a\udf15\ud8ee\udcb8\ud986\udea0\ud972\ude40\udaa5\udffb\uda58\udc21\udb7d\ude48\udb45\udc37\udae1\udc81\uda75\udc20\uda22\ude9f",
        59, 88578, -1402202832, 220812166154725311L, 73786L, false, false, (char) 32704, (char) 39137,
        Double.longBitsToDouble(0x3fef6952a39d4fe2L), Double.longBitsToDouble(0x3febd4247fa3da62L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.List, contains [simple type, class java.lang.Object]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 8, 3, 19, "\u43b1\ud9de\udde0\udaf7\udfa3\ud954\udf73", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u45d7\ud0b9\u6636\u8248\u4458\u6192", "\udb4a\udcf0\ud8d9\udf33\udb00\udd54\ud963\udd2d\udbb1\udf8c\ud996\udc40\udbe4\udcaf\udb41\udda9\uc659\uda38\udc3d\ud970\udeeb",
        46, 21823, -1226441610, -7679713726630429465L, -170L, false, false, (char) 21878, (char) 64748,
        Double.longBitsToDouble(0x3fd7911f18d50b38L), Double.longBitsToDouble(0x3feab301cc931904L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 7, 7, 19, "\ud8c7\uddb0\udafd\udeb9", "\u46a5\u5e8c\u2416\u413e\u3c28\u91d1\ud55d", "\udacc\ude2d\uda6d\udc8e\ud879\udda2\ud85d\udf07\u00b5\uda25\udd97\ud8dc\uddf8\ud9e8\udede\udb4f\udf1f\udadc\udf7e\ud810\ude4f\udb25\udddc\ud963\udd2d\udadc\ude93\ud8ac\udd4c\udbe4\udc9c\ud9b9\udda5\udadc\uddda\udb88\udca5\udaf7\udfae\uda91\udd4b\udb0a\udcef",
        -2, 69726, 104504379, 1149086488507565976L, -95478L, true, false, (char) 17488, (char) 42844,
        Double.longBitsToDouble(0x3fe5e3ea2cd6becaL), Double.longBitsToDouble(0x3fe0bb4236a120c1L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Number] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Number] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 3, 3, 19, "\uda84\udc4a\ud916\udce9\ud9e6\udf5c\ud954\udf73", "\u55fd\u69df\u3c28\u91d1\ub40d\u175b\ub326\u67bc\uacab\u8b63\u483c\u8248\u991e\uaac1", "\udb4a\udcf0\ud8d9\udf33\udb00\udda3\ud963\udd2d\udbb1\udf8c\ud8ac\udd4c\udbe4\udc9c",
        49, 78673, -893453471, -2991109091875650815L, 30166L, false, true, (char) 4547, (char) 17241,
        Double.longBitsToDouble(0x3fdf662d48a126f2L), Double.longBitsToDouble(0x3fe3b0380785631dL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ArrayType:[array type, component type: [simple type, class int]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 17, 15, "\udaf2\udd70\ud8e3\udfb5\udaa6\udd37\ud822\ude94", "\u2373\u7b07\u261a\u91d1\u68aa\u5c73\ub8d2", "\ud879\udda2\ud9ca\udcdd\ud88e\udc00",
        33, 99287, 1528906680, 5082319202500758895L, -83297L, false, false, (char) 5396, (char) 15493,
        Double.longBitsToDouble(0x3fd33aeca6bf403cL), Double.longBitsToDouble(0x3fe88c701b1220f2L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=null |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 14, 14, 9, "\uda9b\udf19\udaf1\udf89\u00d8\ud9fc\udcde", "\u55fd\u74cc\000\u217b\u7b07\u4b55\u98bb\u67bd\u658e\u8b63\u483c\u82ab\u32a6\u7f1e", "\ud9b3\udf3d\ud83c\udf70\ud828\udd4a\udbed\uddbd\uda91\udd65\udbb3\ude8e",
        30, 25228, 0, -3837353439139106271L, 80466L, true, true, (char) 40370, (char) 58164,
        Double.longBitsToDouble(0x3f426ac116540000L), Double.longBitsToDouble(0x3fd65653f998c560L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Long] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Long] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 4, 4, 12, "\ud8ed\udfba\udb9f\udd5d\ud8b2\udc5c\ud8cb\udd53\ud960\udf55\ud977\udebe\ud946\uddbb", "\ua7c2\u6b3f\u346a\ub326", "\udbaa\udc88\ud9b2\udd58\udaff\udf13\udb16\uddd6\ud8bc\udcf1\ud8f5\ude77\udbb6\udeec\udbd6\udeed\ud975\uddcb\udb7a\uddd0\udad7\udd97\udab6\udfdf\udbb3\ude8e\udb5f\uddf9\ud8b3\udcfd\uc4ff",
        54, 73145, -430996735, 5907170410760436854L, -70318L, true, true, (char) 48739, (char) 16550,
        Double.longBitsToDouble(0x3fd5abdf475b81faL), Double.longBitsToDouble(0x3fee4a2b6e80c5aaL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 4, 16, 1, "\udad3\udf30\udb9f\udd5d\ud8b2\udccf\ud822\ude45", "\u55fd\u413e\u3c28\u91d1\ub40d\u346a\ub326\u67bc\u2da2\u8b63\u03cb\u2a5f\u32a6\uaa7c", "\ud9b3\udf3d\ud83c\udf70\ud890\udcfe\udbed\ude29\uda91\udd65",
        -1, 62143, 1795423071, -5769521168377775263L, -68001L, true, false, (char) 20080, (char) 62963,
        Double.longBitsToDouble(0x3fc5f187aae1d128L), Double.longBitsToDouble(0x3fe31bfe94509356L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class java.lang.Object]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.CollectionType:[collection type; class java.util.ArrayList, contains [simple type, class java.lang.Object]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 4, 4, 8, "\u43b1", "\u283d\u46a5\u5e8c\u55fd\u413e\u3c28", "\udbcb\udd28\ud88d\udfb7\uda1c\udf2b\uda8f\udff6",
        51, 51012, 974828907, -6056020183054852109L, -4902L, true, true, (char) 25736, (char) 32857,
        Double.longBitsToDouble(0x3fa8e024d66473d0L), Double.longBitsToDouble(0x3fbf492131bc2fe0L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 4, 4, 12, "\ud9af\ude54\udb2b\udee2", "\u6e68", "\ud931\udc23\udbb4\udd3b\ud9c3\udef2\udac2\udc4d\udbcb\udd28\ud88d\udfb7\ud9e2\udfd3\ud903\udff5\udbaa\udc88\ud9b2\udd58\udaff\udf13\udb16\uddd6\ud8bc\udcf1\ud8f5\ude77\udbb6\udeec\udbd6\udeed\ud975\uddcb\udb7a\uddd0\udad7\udd97\udab6\udfdf\ud87c\udf8c",
        -1, 90554, -1343321673, -3837584336580939231L, -721L, false, false, (char) 10273, (char) 61487,
        Double.longBitsToDouble(0x3fd130fb4154ab72L), Double.longBitsToDouble(0x3fed66a7c95abdf4L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 4, 4, 5, "\ud8ed\udfba\udb9f\udd5d\ud8b2\udccf\ud8cb\udd53", "\u55fd\u413e\u3c28\ua7c2\u86d2\u850a\ub326\u9147\u621c\u808f\u483c\u86c9\u32a6\u094d\u56e4\ua454", "\u4653\uad1d",
        13, 43917, -1594726857, 7711283371085564689L, 67391L, true, true, (char) 25217, (char) 20080,
        Double.longBitsToDouble(0x3fe8774893f27c3dL), Double.longBitsToDouble(0x3fe6a4cda6637fd2L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class int] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class int] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 4, 4, 4, "\ud8ed\udfba\udb9f\udd5d\ud8b2\udc5c\ud8cb\udd53\ud960\udf55\ud977\udebe\uda3a\udfb5", "\ua7c2\u6b3f\u346a\ub326", "\udbaa\udc88\ud9b2\udd58\ud8d1\udf3d\udb6b\udd84\ud8bc\udcf1\uda2e\udf75\udb83\udd20\uda01\udfe7\u393a\udb7a\uddd0\udad7\udd97\udab6\udfdf\udbb3\ude8e\udb5f\uddf9\ud8b3\udcfd\uc4ff\uda03\ude3d\udaf7\udfae\ud99a\udd7d\udb0a\udd05\ud84c\udf1c\ud937\ude60\udbe6\udd96\ud90e\ude20\udb87\ude20\uda51\udfc7\ud967\udda3\ud98b\udfc4\udbaa\udc58\udaa9\udec4\u1993\uda82\udcfc\uda6a\udea5\uda75\ude5a\ud967\ude53\uda90\udcc8\udad2\udd6c\ud994\udfaf",
        16, 82854, -987858093, -1379210121887263474L, 86037L, false, false, (char) 5133, (char) 61298,
        Double.longBitsToDouble(0x3fef6527cb3031eaL), Double.longBitsToDouble(0x3fe0eea5b750b206L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.String] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.String] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 4, 4, 5, "\ud8ed\udfba\udb9f\udd5d\ud8b2\udccf\ud8cb\udd53\ud949\udc55\ud977\udebe\ud946\uddbb\ud8d5\udc6f\udbb4\udd21\ud9c3\udef2\udaa3\ude63\uda23\uddaa\ud88d\udfb7\u7bdc\ud901\udc65", "\u86c9\u32a6\u094d\u56e4\ua454\u6551\ubb42\u8392\u4a3c\u4cbb\u74b0\u24a5\uc234\u3c2b\u1242\u48ee\u6c8e\ua359\u014a\uaa4d\u4ab4\uc252\u16e8\u21a7\u04e7\u00f2\u1b97\u07db\u728b\u8d7f\u6465\u4af3\u6506", "\udba1\ude3b\udbcf\uddc4\uda4a\udd3f\uda6c\udd7c\udb86\udc77\ud89d\uddf2\ud857\uddee\udb77\ude4c\udbf7\ude34\uda93\ude00\udae5\udf87\ud986\udc57\uda5e\udea1\ud831\ude76\udb67\udd6e\uda97\ude6f\ud867\udc17\uda25\ude65\udb19\udddf\uc78f\uda8a\udfda\udaab\ude64\ud896\udfda\ud8c7\udd9f\ud952\udfe5\ud966\udd72\udb15\udfc6\ud94c\udf72\ud9d8\udd2c\ud8f6\udef8\udb0d\udfc8\udb83\udfc4\udb02\udc2e\ud9a0\udfa4\udbff\uddd5\udaab\udf99\udb7b\ude6b\ud9c7\udd51\udbcc\udeb0\uda9f\uddb1\ud998\udc05\ud972\ude50\udb87\udde7\uda42\udd7e\ud9a3\udd46",
        42, 34510, -1361408508, -6032822886835962353L, -42549L, false, false, (char) 44605, (char) 4755,
        Double.longBitsToDouble(0x3fe39cd900037849L), Double.longBitsToDouble(0x3fcb1b8290f51e14L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructType|com.fasterxml.jackson.core.type.TypeReference|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructType|java.lang.reflect.Type|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructType|java.lang.reflect.Type,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructType|java.lang.reflect.Type,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructType|java.lang.reflect.Type,java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_collectionType|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_constructSimple|java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_findPrimitive|java.lang.String|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_findWellKnownSimple|java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromAny|com.fasterxml.jackson.databind.type.ClassStack,java.lang.reflect.Type,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromArrayType|com.fasterxml.jackson.databind.type.ClassStack,java.lang.reflect.GenericArrayType,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromClass|com.fasterxml.jackson.databind.type.ClassStack,java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromParamType|com.fasterxml.jackson.databind.type.ClassStack,java.lang.reflect.ParameterizedType,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromVariable|com.fasterxml.jackson.databind.type.ClassStack,java.lang.reflect.TypeVariable,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromWellKnownClass|com.fasterxml.jackson.databind.type.ClassStack,java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromWellKnownInterface|com.fasterxml.jackson.databind.type.ClassStack,java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.JavaType;|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructType|com.fasterxml.jackson.core.type.TypeReference|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructType|java.lang.reflect.Type|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructType|java.lang.reflect.Type,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructType|java.lang.reflect.Type,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructType|java.lang.reflect.Type,java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
