package com.fasterxml.jackson.databind.ser;
import org.junit.Test;
import static org.junit.Assert.*;
public class BeanPropertyWriter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 8, 4, "\ud8d4\udd0a\ud89e\ude8f\ud8f4\udf0d", "\uc226\u827b\ud160\u030f\u70a6\u625f\u4599", "\ud848\udd42\ud853\udc46\ud885\udfaf\u2f21",
        29, 42163, -728590846, 2165094764641566995L, -529L, false, false, (char) 10528, (char) 14414,
        Double.longBitsToDouble(0x3fe5bc1adef0ac0cL), Double.longBitsToDouble(0x3fd290a8a32d2398L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 13, 7, "\ud8d4\udd0a\ud89e\ude8f\ud8f4\udf0d", "\uc226\u8282\ud160\u030f\u70a6\u625f\u4599", "\ud848\udd42\ud853\udc46\ud88f\udf28\u2f21",
        29, 42163, -728590846, 2165094764641566995L, -529L, false, false, (char) 10528, (char) 14414,
        Double.longBitsToDouble(0x3fe5bc1adff0ac0cL), Double.longBitsToDouble(0x3fd290a8afb12398L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 14, 4, "\udb1e\udc54\uda23\udfc4\ud8f4\udf0d", "\u1399\u09d7\ud160\u030f\u70a6\uce05\uc66b\u6fae\u6d58\u1f7b\u81cd\u2a31\uc2ea\u3cdb\u31e5\u7a89\u8646\u3f05\u4423\u55a8\u720c\u98d0\u2678\u3b37\u4e65\u3a8c\u6d66\u4a13\ube6e", "\udbee\uddc3\ud915\udf48\ud8bb\udffb\ud8af\udd7b\udac7\ude77\ud8fe\udd6f\ud8d7\udd0e\ud856\udc1b\ud977\ude7d\ud843\udcde\uda3e\ude80\ud8b3\ude88\ud898\udea2\ud8d4\udca4\udb8c\udc8e\ud90c\udc1f\udbc7\udc73",
        7, 32353, -365335389, -5768928033316332033L, -64006L, false, true, (char) 30193, (char) 11564,
        Double.longBitsToDouble(0x3fe46a5f6b2bb2c9L), Double.longBitsToDouble(0x3fa13052e27df530L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 0, 5, "\udaa3\udfe1\ud83d\uddbe\udb9c\uddbd", "\u5250\u827b\ud160\ubd6d\u628c\u2181\ub997", "\ud8ec\udd5e\udb97\udea7\udb02\udebf\u2fff\ud812\udf84\ud99c\udeef\udb3d\uded4\ud90b\udcfd\ud823\udcac\udae8\udc80\ud9da\udf6b\ud95f\udfcd\ud958\ude77\udbcc\udcc9\udb50\udef8\ud9bc\udf21\ud993\udeaa\ud863\udf5b\uda93\ude35\udb25\ude09\uda79\udda9\ud895\ude34\udbc9\udda6\ud9e0\udc99\udbaa\uddaf\udb35\udd50\uda5a\udc78",
        57, 99441, 617899619, -8188461879866523927L, -76909L, true, false, (char) 23555, (char) 34957,
        Double.longBitsToDouble(0x3fd9b59f2292d9a0L), Double.longBitsToDouble(0x3fe6976b64e33f88L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 8, 4, "\ud8d4\udd0a\ud89e\ude8f\udaa8\udf0a", "\uc226\u827b\ud160\ud34e", "\udaf5\udef6\ud800\udca3\udaaa\udf36\ud848\udd42\ud853\udc46\ud885\udfaf\u2f21\udb19\udf67\uda07\udfc4\udb46\udf72",
        53, 36227, 1149434608, -1392310959085601706L, -3472L, true, true, (char) 60258, (char) 14822,
        Double.longBitsToDouble(0x3fe2971d12c0fd8cL), Double.longBitsToDouble(0x3fdff169831c2094L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 13, 12, "\ud8d4\udd0a\ud89e\ude8f\ud8f4\udf0d", "\uc226\u827b\ud160", "\udbde\udf06\udaf5\udf86\ud800\udca3\udaaa\udf36\ud848\udd42\ud853\udc46\ud871\ude44\udbe1\udf3a\udb19\udf67\uda07\udfc4\udb46\udf72\ud909\udffd\ud990\udf63\uda53\udef9\ud9da\udf6b\udacb\udf44\uda47\ude5b",
        27, 89027, 176850592, -7940896002471077482L, -78383L, true, false, (char) 39123, (char) 34765,
        Double.longBitsToDouble(0x3fc4d57d8f795238L), Double.longBitsToDouble(0x3feb3df4d350c695L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 4, "\udb9d\udf83\ud9a4\ude96\ud8c0\uddb9\uda7b\udcd5\udab1\ude55\ud935\udf2c\udb04\udd4b", "\u2134\u43d3\u16fd\u12c2\u9d1a\u0279\u3ce0", "\udb2f\ude14\uda15\udca4\ud938\udf72\ud9c8\udc4d\ud845\udc02\udabd\udf38\ucb91\ud935\udda7\udbc9\udf48",
        38, 19292, 710182265, 7097873303258493159L, 21340L, true, true, (char) 2401, (char) 25036,
        Double.longBitsToDouble(0x3feda4311678fcc3L), Double.longBitsToDouble(0x3fd2623d5b87d502L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 14, 5, "\ud8d4\udd0a\ud89e\ude8f\udb9c\ude6b", "\u9a98\u6535\ud160\u030f\u427c\u625f\u4599", "\ud848\udd42\ud853\udc46\ud822\udf3b\u2f21\udb19\udf8b\ud904\udc5b\udb46\udfed\ud909\udffd",
        56, 53608, -84376433, -3009888812161504818L, -82295L, false, true, (char) 50270, (char) 26547,
        Double.longBitsToDouble(0x3fd5b601a21fa618L), Double.longBitsToDouble(0x3fb3f3069804f430L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 14, 4, "\ud8d4\udd0a\ud89e\ude8f\ud8e4\ude0d", "\uc226\u827b\ud160\u030f\u70a6\u315f\u4599", "\ud9fd\udf7d\ud91b\ude83\ud885\udfaf\u2f21",
        29, 42163, -728590846, 2165094764641566995L, -529L, false, false, (char) 17303, (char) 9996,
        Double.longBitsToDouble(0x3feee41adef04324L), Double.longBitsToDouble(0x3fd290a8a32d2398L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 6, 0, "\ud8d4\udd0a\ud89e\ude8f\ud8f4\udf0d", "\u2888\u33ed\u05e8\u9147\u70a6\u625f\u4599", "\ud848\udd42\ud853\udc46\ud885\udfaf\u2f21",
        29, 42163, -728590846, 2165094764641566995L, -529L, false, false, (char) 10528, (char) 14414,
        Double.longBitsToDouble(0x3fe5bc1adef0ac0cL), Double.longBitsToDouble(0x3fd290a8a32d2398L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\0121=void |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 11, "\udbc9\udd6c\ud985\udda5\ud8fc\udeea\ud853\udfb9\ud8fe\udd58\udb7d\udf4d\udb3b\udfe0", "\u70a6\u625f", "\udaaa\udf36\ud834\udc42\ud85a\ude46\ud885\udfaf\u2f21\udb19\udfdf\uda07\udfc4\udb25\udd6b\ud909\udffd\ud990\udf63\uda53\udef9\ud9da\udf6b\ud95f\udfcd\ud8b9\udccc\udb0d\udc6e\uda6c\udf26\ud945\udd13\udb71\ude52\udb43\udf49\ud80d\udd17\udb49\udd0b\ud906\udf43\uda44\udd8d\uda9d\udc4a\ud851\udf58\udb05\ude79\udb50\udd6a\uda82\udff0\udae1\udee9\ud9c6\ude40\uda1f\uded4\ud9c7\udd46\uda02\udffd\udb2b\ude79\uda22\udc67\ud85f\ude77\u4ccf\uda49\udecc\ud827\udedb\uda6f\udde7",
        37, 50239, -2067385037, -6487593050120042478L, -17246L, true, false, (char) 60535, (char) 16966,
        Double.longBitsToDouble(0x3fd22d27fdeb178aL), Double.longBitsToDouble(0x3fbc1685e3a7a388L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 8, 4, "\uda97\udff4\ud8ce\udff9\udba2\udda3", "\uc226\uc5c8\u823e\u6e80\ua80e\u02eb\u4926\u00b6\u5429\u6f1d\u81cd", "\ud8d0\udfe4\udaea\udf6b\udb46\udf72\uda86\uddc5\ud8a5\udc59\udab3\udf1f\ud9da\udf61\ud95f\udfcd\uda8f\udd17\udb64\ude6e\udae9\udddb\udbc3\ude33\ud993\udf70\uda1f\udcf9\uda5f\udc7c\ud828\udc0c\udbc9\udd71\udac3\ude50\ud86a\udffe\ud81a\uddb2\ud85e\ude2b\uda94\udc7b\u7236\ud9f7\ude24",
        0, 33741, -1930311856, -2203196001112108369L, -51219L, false, true, (char) 4243, (char) 11448,
        Double.longBitsToDouble(0x3fd714d7de7afb2aL), Double.longBitsToDouble(0x3fe680b1d74a9762L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 8, 4, "\ud8d4\udd0a\ud89e\ude8f\ud975\udf4f", "\u0e98\ucfdc\u99b6", "\udbde\udf06\udb48\udf30\uffdd\udaaa\udf36\ud848\udd42\ud805\udf1e\ud89f\udf0a\udbcd\udf5f",
        54, 42163, -728590846, -4230684927790983738L, -36965L, true, false, (char) 10528, (char) 14414,
        Double.longBitsToDouble(0x3fe5bc1adef0ac0cL), Double.longBitsToDouble(0x3fd290a8a32ce398L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 8, 13, "\ud8d4\udd0a\ud89e\ude8f\ud8f4\udf0d\udaed\udf05", "\u3718\u9cc9\u030f\u70a6\u625f\u2599\u1e65\u517e\u201e\u81cd\u38bb\u9ef2\u3cdb\u31e5\u7a89\u79d4\ud2ac\u133a\ub456\u24a9\u511b", "\udabc\udc9d",
        26, 36777, -568310093, -3551260153297271437L, -13175L, false, false, (char) 55394, (char) 40612,
        Double.longBitsToDouble(0x3fed96a75bbb05abL), Double.longBitsToDouble(0x3fe212f04dcf704dL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 8, 4, "\ud8f4\udc43\ud89e\ude8f", "\u953e\uc226\u827b\ud160\u030f\u70a6\u625f\u4599\u1355\u6d88\u1fd0\ub723\u2a31\u7ac5\ua131\u0777\u7a89", "\uda53\udef9\ud9da\udf6b\ud961\udfce\ud8b9\udccc\uda40\uded9\ud9c2\uddc4\u7f8f",
        53, 84326, -1782369841, -8576971274054057194L, 16703L, true, false, (char) 62360, (char) 56990,
        Double.longBitsToDouble(0x3febdd778fec8ab9L), Double.longBitsToDouble(0x3fec6da000321ff5L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 11, 11, "\ud8d4\udd0a\ud9a9\ude75\ud98a\udcd7", "\uc226\u827b\u4923\uaba6\ub1da\u625f\ud7f7", "\ud9b6\uded9\udbf4\udf78\ud885\udfaf\u2f21\udb19\udf67\uda08\udc96\udaf8\udf6b\ud909\udffd\ud83c\udf58\uda29\udd8b\ud9a9\udef2\uda77\udca0\ueffc\ud90f\udcc8\udb09\udc33\udbfc\ude2f\ud84b\udd07\udbbc\udda8\uda8e\udefe\ud8bd\udc35\ud8d4\udc11",
        5, 52366, 1018876572, 8386493155320785317L, -25345L, false, true, (char) 51896, (char) 50746,
        Double.longBitsToDouble(0x3fb5b5eee4b096e8L), Double.longBitsToDouble(0x3fe7092030a110a3L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 3, 3, "\ud8d4\udd0a\ud9c0\udca4\udb86\udd26", "\uc226\u827b\u3500\ub47c\u70a6\u625f\u4599\u4190\u5571\u1f7b\u81cd\ua684\u13b9\u7f33\uc0ee\u7a89", "\uda4e\udd06\ud930\ude56\ud95f\udfcd\ud895\udccc\uda40\uded9\ud9c2\uddc4\u7f8f",
        43, 42253, -416930408, 292628351321410098L, 73421L, true, true, (char) 58007, (char) 64474,
        Double.longBitsToDouble(0x3fe46a6a840f9a60L), Double.longBitsToDouble(0x3fea1d5057f8e83bL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 6, "\udad8\udc2b\u9af5\udacf\udee9\udaed\udf49\ud910\uddef\udb97\udcfb\udb3b\udfe0\ud9e2\udcbe\uda6f\udef6\udb66\udfa2\uda8a\udd5f", "\u8e58\u7a1e\u40a6\ubdc4\u1a05\u3cdb\u31e5\u7a89\u79d4", "\ud9da\udf6b\ud95f\udfcd\udab9\ude36\ud9ee\udedd\ud9c2\uddc4\ud822\udfaf\udbc9\udf70\udaef\udd81\ud84e\udf32\ud98e\udecd\ud8c2\udeff\ud918\udfc6\udbc5\ude84\udba1\ude43\ud897\udccc\udb9d\udcda\uda13\udcd8\u37b8\ud9ba\uddc6\ud92d\udcfe\ud827\udeea",
        33, 48462, -1483488743, 3126128748682073554L, 83246L, true, false, (char) 36630, (char) 42791,
        Double.longBitsToDouble(0x3fd572bc0541f6a4L), Double.longBitsToDouble(0x3febfc829d7b6f71L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 10, 4, "\ud8d4\udd0a\ud89e\ude8f\udaa8\udf0a", "\u7e3f\u827b\ud160\u2516", "\udbe2\udec4\ud9b3\udeb8\uda8c\uddd3\udb08\udf9f\uda18\udc76\udb77\udf4d\udb11\udd78",
        58, 42163, -728590846, -4968607042437609515L, -529L, false, false, (char) 10528, (char) 12981,
        Double.longBitsToDouble(0x3fe49ec14520ca2dL), Double.longBitsToDouble(0x3fd290aea32d2398L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 12, 14, "\ud8d4\udd0a\udad6\udec7\ud8f4\udf22", "\uc226\u827b\ud160", "\udbde\udf06\udaf5\udf86\ud800\udca3\ud833\udcbb\udb09\udc29\uda9f\udc84\ud871\ude44\udbe1\udf3a\udb19\udf67\uda07\udfc4\udb46\udf72\ud909\udffd\udb94\ude84\udb71\udf96\ud9dc\udd2b\udacb\udf44\uda47\ude5b",
        -5, 89027, 176850592, -1116084392353834736L, -78383L, true, false, (char) 39123, (char) 27341,
        Double.longBitsToDouble(0x3fc4d5668f795238L), Double.longBitsToDouble(0x3feb3df4d1db9195L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 2, 0, "\ud8d8\udc0a\ud89e\ude8f\ud945\ude56\udb63\udd66\ud904\ude4b\udbb7\udcb2", "\u6bbf\u70a6\u625f\u8fac\uc366\u46bb\u2c3a\u86d3\u2fb6\u7f61\u3cdb\u31e5\u77b1\u7a72\u40bf\u4423\u55a8\u9e6b\u17ce\u42a9\u088f", "\uc2e4\udbbe\udf42\udb8e\udd4d\ud827\udd64\ud88b\ude16\uda1f\uddf3\ud809\udd4f\ud970\udc03\udb31\udc22\udab9\udc68\udb16\udcf3\ud914\udfcb\ud9d8\udce4\uda07\udfd7\udbb3\ude77\udbbe\udf2f\udbc6\udcd4\uda85\ude47\ud86d\udfec\ud935\uddf4\udbec\udf40\ud963\udff0\ud81e\udd86\ud92f\ude14\ud998\ude74\ud86f\uddbb",
        13, 21811, 1463879537, 4593946148939133082L, 48519L, true, true, (char) 13465, (char) 31510,
        Double.longBitsToDouble(0x3fcb94195cb26180L), Double.longBitsToDouble(0x3f77d19d1e334500L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 1, 4, "\ud9ed\udcdb\ud9bc\ude61\ud8c0\uddb9\uda61\udcc8\udabc\udc1a\ud935\udea9\udb04\udd4b\uda66\udd79\ud9d3\udce2\ud8a5\udd11\udaf6\udfe6\uda22\ude57\udaf3\udc70\udb46\ude4c\udb0f\udd7e\udbaf\udf7f\ud8da\udd29\ud8e8\udeb0\udb59\udf6e\uda15\udca4\ud938\udf72\ud9c8\udc4d\ud843\ude41\udabd\uded6\udaf5\ude71\uda76\udfd7\ud997\udc14\ud8d4\udf4d\uda80\ude03\ud85a\udd71\ud8f7\ude5a\ud9e6\udfc5\ud9de\udd10\udae5\ude53\udbed\udcf7\ud92b\udf01\ud9c0\udc3a\udb7e\udd32\uda42\udc94\ud876\ude0c\udbf7\ude79\udba4\uddab\uda27\udc8a\udbae\ude81\ud894\udd2d", "\u8b8a\u75c9\uca22\ud008\ubb90\ubf40\uba65\u9048\u7435\ub878\u6888\u871e", "\ud8e4\ude0f\ud9c9\udc9c\ud80c\udf1e\u3d99\uda5b\udd9f\ud82a\udd09\ud832\ude7a\ud890\udff4\ud862\udfe5\ud8ef\udc35\ud894\udda9\udaee\udd67",
        42, 57251, 2022380986, -7327310503339132544L, -42300L, true, false, (char) 59346, (char) 51548,
        Double.longBitsToDouble(0x3fe27c06488c5966L), Double.longBitsToDouble(0x3fe8837716aad4f8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 11, "\udbc9\udd6c\ud985\udda5\ud928\ude69\ud853\udfb9\ud8fe\udd58\udb7d\udf4d\udb3b\udfe0", "\u70a6\u625f\u4599\u4190\u6d58\ua67a\u9fcd\u2a31\u3548", "\udb25\udd6b\ud909\udffd\ud990\udf63\uda53\udef9\ud9da\udf6b\ud95f\udfcd\ud8b9\udccc\udb0d\udc6e\uda6c\udf26\ud945\udd13\udb71\ude52\udb43\udf49\ud80d\udd17",
        59, 57477, -641002546, -6951039968995594234L, 56431L, true, true, (char) 11190, (char) 59186,
        Double.longBitsToDouble(0x3fe5beb9c38abe15L), Double.longBitsToDouble(0x3fd6d1d766bfcf48L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\0121=void |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 5, 11, "\udbc9\udd6c\ud985\udda5\ud88d\udff4\ud833\udddd\ud8fe\udd58\udb7d\udf4d\udb3b\udfe0", "\u70a6", "\ud800\udca3",
        7, 43308, -1347664126, -7516993948600312554L, -13429L, false, false, (char) 51795, (char) 57117,
        Double.longBitsToDouble(0x3fe784fc248f4482L), Double.longBitsToDouble(0x3fb5bb2b7279d688L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\0121=void |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 4, "\uda0b\uddae", "\uaf05\u134e\u5c78\u827b", "\udbbd\udd49\ud8b5\udc74",
        57, 80298, 865947898, 7541369194926096316L, -25526L, false, false, (char) 42276, (char) 8008,
        Double.longBitsToDouble(0x3fe1c6a0dab01e0bL), Double.longBitsToDouble(0x3fe784fc248f4482L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 3, "\udbc9\udd6c\ud985\udda5\ud8fc\udeea\ud853\udfb9\ud8fe\udd58\udb7d\udf4d\udb3b\udfe0", "\u70a6\u625f\u4599\u4190\u6d58\ua67a\u9fcd\u2a31\u3548", "\udb25\udd6b\ud909\udffd\ud990\udf63\uda53\udef9\ud9da\udf6b\ud95f\udfcd\ud8b9\udccc\udb0d\udc6e\uda6c\udf26\ud945\udd13\udb71\ude52\udb43\udf49\ud80d\udd17",
        59, 57477, -641002546, -6951039968995594234L, 56431L, true, true, (char) 11190, (char) 59186,
        Double.longBitsToDouble(0x3fe5bdabb38abe15L), Double.longBitsToDouble(0x3fd6d1d766bfcf48L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\0121=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 14, 7, "\ud8d4\udd0a\udaff\udcc7\ud8f4\udf22", "\uc226\ua867\uba08", "\udbde\udf06\udaf5\udf86\uf1e5\ud857\uddbb\udb09\udc29\uda9f\udc84\ud871\ude44\udbe1\udf3a\udb19\udf67\uda07\udfc4\udbb8\udccb\ud869\udcbb\ud850\udc7d\udb71\udf96\ud8bc\udc7a\udacb\udfc1\udad3\udd40",
        6, 89027, 176850592, -1116084392353834736L, -78383L, true, false, (char) 39123, (char) 27341,
        Double.longBitsToDouble(0x3fc4d5668f795238L), Double.longBitsToDouble(0x3feb3df4d1db9195L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.ser.BeanPropertyWriter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 13, 4, "\ud8d4\udd0a\ud89e\ude8f\ud8f4\udf0d", "\uc226\u827b\ud160\u030f\u70a6\u625f\u4599", "\ud8b3\ude36\udab6\udec6\ud885\udf75\ud988\udd0d",
        13, 32845, -728590846, 2165094764641566995L, 20404L, false, true, (char) 10539, (char) 14414,
        Double.longBitsToDouble(0x3feb7b52def0ac0cL), Double.longBitsToDouble(0x3fef4854519691e5L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ser.BeanPropertyWriter|_depositSchemaProperty|com.fasterxml.jackson.databind.node.ObjectNode,com.fasterxml.jackson.databind.JsonNode|new:com.fasterxml.jackson.databind.ser.BeanPropertyWriter:",
    "M|com.fasterxml.jackson.databind.ser.BeanPropertyWriter|_findAndAddDynamic|com.fasterxml.jackson.databind.ser.impl.PropertySerializerMap,java.lang.Class,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.BeanPropertyWriter:",
    "M|com.fasterxml.jackson.databind.ser.BeanPropertyWriter|_handleSelfReference|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.JsonSerializer|new:com.fasterxml.jackson.databind.ser.BeanPropertyWriter:",
    "M|com.fasterxml.jackson.databind.ser.BeanPropertyWriter|_new|com.fasterxml.jackson.databind.PropertyName|new:com.fasterxml.jackson.databind.ser.BeanPropertyWriter:",
    "M|com.fasterxml.jackson.databind.ser.BeanPropertyWriter|assignNullSerializer|com.fasterxml.jackson.databind.JsonSerializer|new:com.fasterxml.jackson.databind.ser.BeanPropertyWriter:",
    "M|com.fasterxml.jackson.databind.ser.BeanPropertyWriter|assignSerializer|com.fasterxml.jackson.databind.JsonSerializer|new:com.fasterxml.jackson.databind.ser.BeanPropertyWriter:",
    "M|com.fasterxml.jackson.databind.ser.BeanPropertyWriter|assignTypeSerializer|com.fasterxml.jackson.databind.jsontype.TypeSerializer|new:com.fasterxml.jackson.databind.ser.BeanPropertyWriter:",
    "M|com.fasterxml.jackson.databind.ser.BeanPropertyWriter|depositSchemaProperty|com.fasterxml.jackson.databind.jsonFormatVisitors.JsonObjectFormatVisitor|new:com.fasterxml.jackson.databind.ser.BeanPropertyWriter:",
    "M|com.fasterxml.jackson.databind.ser.BeanPropertyWriter|depositSchemaProperty|com.fasterxml.jackson.databind.node.ObjectNode,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.BeanPropertyWriter:",
    "M|com.fasterxml.jackson.databind.ser.BeanPropertyWriter|findFormatOverrides|com.fasterxml.jackson.databind.AnnotationIntrospector|new:com.fasterxml.jackson.databind.ser.BeanPropertyWriter:",
    "M|com.fasterxml.jackson.databind.ser.BeanPropertyWriter|get|java.lang.Object|new:com.fasterxml.jackson.databind.ser.BeanPropertyWriter:",
    "M|com.fasterxml.jackson.databind.ser.BeanPropertyWriter|getAnnotation|java.lang.Class|new:com.fasterxml.jackson.databind.ser.BeanPropertyWriter:",
    "M|com.fasterxml.jackson.databind.ser.BeanPropertyWriter|getContextAnnotation|java.lang.Class|new:com.fasterxml.jackson.databind.ser.BeanPropertyWriter:",
    "M|com.fasterxml.jackson.databind.ser.BeanPropertyWriter|getFullName||new:com.fasterxml.jackson.databind.ser.BeanPropertyWriter:",
    "M|com.fasterxml.jackson.databind.ser.BeanPropertyWriter|getGenericPropertyType||new:com.fasterxml.jackson.databind.ser.BeanPropertyWriter:",
    "M|com.fasterxml.jackson.databind.ser.BeanPropertyWriter|getInternalSetting|java.lang.Object|new:com.fasterxml.jackson.databind.ser.BeanPropertyWriter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
