package com.fasterxml.jackson.databind.deser;
import org.junit.Test;
import static org.junit.Assert.*;
public class BeanDeserializerFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 14, 2, 10, "\uda3c\uddc3\uda6a\udf1d\ud8c9\uddd5\udafe\udc8e\udabe\ude1f\ua764\udb76\ude86\udb4e\udf48\udac9\udeb7\ud873\udf17\ud96b\udef7\ud940\udd2b\udb15\udc75\udba6\udd5e\udb32\udec5", "\u9297\ub91c\u4ff0\u818b", "\uda7e\udfa7\udab6\ude14\ud84a\udd45\udbcc\udcd6\ud84f\udf7e\ud85e\udefb\ud9c6\udce3\udaa9\ude5f\udb82\ude11\ud8bc\uddbe",
        43, 93728, 1498707940, -4382736520131785743L, 42734L, false, false, (char) 282, (char) 8338,
        Double.longBitsToDouble(0x3fd7702a8eb67206L), Double.longBitsToDouble(0x3feb5d8959ff5978L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 14, 2, 10, "\uda3c\uddc3\uda6a\udf1d\ud8c9\uddd5\udafe\udc8e\udabe\ude1f\ua764\udb76\ude86\udb4e\udf48\udac9\udeb7\ud873\udf17\ud96b\udef7\ud940\udd2b", "\u1205\u405c\u5718\u9297\ub91c\u4ff0\u818b\ua901\u3de3\u856e\u6909\ua943\u6977\uc148\ud1ff\u0949\u1146\uc75d\u2f10\ua878\u5099\ub9c3\u8444\ua3d6\u8963\u46e5", "\ud817\udf48\ud86b\udcd3\udadc\udeb5\udb1a\udec5\udae1\udfb8\udb58\udeac\udbb5\udd49\ud989\udde2\ud8ae\udeea\ud8a9\ude65\ud8cc\udc97\ud9ae\udc23\ud9df\udfec\ud801\udc0b\udbb1\udf80\udaf4\uded3\udba9\ude77\ud9a2\udc83\udb44\udce3\ud852\udfcc\u1f50\udadc\udf92\uda2e\ude47",
        58, 42700, -554323347, -5501858000376247818L, 76276L, true, true, (char) 1897, (char) 54851,
        Double.longBitsToDouble(0x3fce2dce25c6ce28L), Double.longBitsToDouble(0x3fc6ff2c08782e68L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 14, 2, 10, "\uda3c\uddc3\uda6a\udf1d\ud8c9\uddd5\udafe\udc8e\udabe\ude1f\ua764\udb76\ude86\udb4e\udf48\udac9\udeb7\ud873\udf17\ud96b\udef7\ud940\udd2b\udb16\udf75\udba6\udd5e\udb32\udec5", "\u9297", "\udb3b\udff5\udab2\udca3\uda7a\uddf7\uda7e\udfa7\udab6\ude14\ud84a\udd45\udbcc\udcd6\ud84f\udf7e\ud85e\udefb\ud9c6\udce3\udaa9\ude5f",
        52, 4708, -236674767, -2745060794494060572L, 44399L, false, false, (char) 50166, (char) 9527,
        Double.longBitsToDouble(0x3fd7ec39be4012e4L), Double.longBitsToDouble(0x3fd7702a8eb67206L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 16, 2, "\udac4\uddc7\ud973\udf63\ud8c3\udfd9\udafe\udc8c\ud993\udf89\udade\udf7d\udb76\ude75\ud9d8\udd4d\udac9\udeb7\ud906\udef6\ud96b\udef7\ud82c\udc85\udb1a\udea6", "\u405c\u5718\u9297\ub91c\u2ad8\u50f1\u8318", "\ud9c3\udec7\ud994\udc13\udbf7\udc55\ud84f\udf7e",
        39, 40682, -75970908, 6480852234502903540L, 39007L, false, true, (char) 27968, (char) 37479,
        Double.longBitsToDouble(0x3fec706b4a72f184L), Double.longBitsToDouble(0x3fea9a400dfa46fdL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 2, 10, "\uda3c\uddc3\uda6a\udf1d\ud8c9\uddd5\udafe\udc8e\udabe\ude1f\ua764\udb76\ude86\udb4e\udf48\udac9\udeb7\ud873\udf17\ud96b\udef7\ud940\udd2b\udb15\udc75\ud84c\udd51\udb32\udec5", "\u9297\ub91c\u4ff0\u0b2b", "\uda7e\udfa7\udab6\ude14\ud84a\udd45\udbcc\udcd6\ud84f\udf7e\ud85e\udefb\ud86b\udc96\udaa9\ude5f\udb82\ude11\ud8bc\uddbe",
        43, 93728, 1498707940, -4382736520131785743L, 42734L, false, false, (char) 282, (char) 16836,
        Double.longBitsToDouble(0x3fd7702a89147206L), Double.longBitsToDouble(0x3feb5d8959ff5978L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 2, 10, "\uda3c\uddc3\uda6a\udf1d\ud8c9\uddd5\udafe\udc8e\udabe\ude1f\ua764\udb76\ude86\udb4e\udf48\udac9\udeb7\ud873\udf17\ud96b\udef7\ud940\udd2b\ud8cd\uded1\udba6\udd70\udb32\udec5", "\uaa00\u5bfe\u4ff0\u818b", "\uda7e\udfa7\udab6\ude14\ud84a\udd45\udbcc\udcd6\ud84f\udf7e\ud9e4\udfee\uda4c\udce6\udaa9\ude5f\udb82\ude11\ud8bc\uddbe",
        43, 93728, -1521190940, -5063247344277271567L, 95310L, false, true, (char) 40606, (char) 54901,
        Double.longBitsToDouble(0x3fd7702a8eb67206L), Double.longBitsToDouble(0x3fbaec4acffc4438L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 10, "\uda3c\uddc3\uda6a\udf1d\ud8c9\uddd5\udafe\udc8e\udabe\ude1f\ua764\udb76\ude86\udb4e\udf48\udac9\udeb7\ud873\udf17\ud96b\udef7\ud940\udd2b\udb15\udc75\udba6\udd5e\udb32\udec5", "\u9297\ub91c\u4ff0\u818b", "\uda7e\udfa7\udab6\ude14\ud84a\udd45\udbcc\udcd6\ud84f\udf7e\ud85e\udefb\ud9c6\udce3\udaa9\ude5f\udb82\ude11\udbb8\uddbc",
        43, 93728, 1498707940, -4382736520131785743L, 42734L, false, false, (char) 282, (char) 8338,
        Double.longBitsToDouble(0x3fd7702a8eb67206L), Double.longBitsToDouble(0x3feb5d8959ff5978L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 2, 10, "\uda3c\uddc3\uda6a\udf1d\ud8c9\uddd5\udafe\udc8e\uda6e\udef6\ua764\udb3b\udc48\ud8a2\uddd5\udac9\udeb7\ud873\udf17\ud86f\udcf1\ud940\udd2b\udb15\udc75\udba6\udd5e\udb32\udec5", "\u9297\ub91c\u4203\u4829", "\uda7e\udfa7\udab6\ude14\ud84a\udd45\u330b\ud84f\udf7e\ud85e\udefb\ud9c6\udce3\udaa9\ude5f\udbb8\ude0c\ud8bc\uddbe",
        43, 93728, -1513716226, -9204051052208801532L, 33231L, false, false, (char) 282, (char) 62729,
        Double.longBitsToDouble(0x3fc9530747257934L), Double.longBitsToDouble(0x3fe887efe9ff5978L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 2, 10, "\uda3c\uddc3\ud82f\udd1e\ud8c9\uddd5\udafe\udc8e\udabe\ude1f\ua764\udb76\ude86\ud800\udf61\udbe6\udddf\ud87f\uddb1\uda4d\udcc2\udb76\ude55\udb08\udfa4\udba6\udd5e\udb32\udec5", "\u9297\ub91c\u4ff0\u818b", "\uda7e\udfa7\udab6\ude14\ud84a\udd45\udbcc\udcd6\ud84f\udf7e\ud85e\udefb\ud9c6\udce3",
        47, -3, 794269428, -1016510384692554304L, -8773L, true, true, (char) 24567, (char) 50166,
        Double.longBitsToDouble(0x3fab4880d7ec39b0L), Double.longBitsToDouble(0x3fe9004b9177961dL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 14, 10, "\uda3c\uddc3\uda6a\udf1d\ud8c9\uddd5\udafe\udc8e\udabe\ude1f\ud8e5\udd81\ud9bb\udc0a\uda20\ude3e\uda3d\uddb3\ud873\udf17\ud96b\udef7\ud940\udd2b\udb15\udc75\udba6\udd5e\udb32\udec5", "\u9297\ub91c\u4ff0\u898c", "\uda7e\udfa7\udab6\ude14\ud84a\udd45\udbe3\udf32\ud84f\udf7e",
        39, 40667, -75970908, -7641873246099932339L, -8773L, true, true, (char) 24567, (char) 23609,
        Double.longBitsToDouble(0x3fe919574361aab6L), Double.longBitsToDouble(0x3fe9004b917702a8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 2, 10, "\uda3c\uddc3\uda6a\udf1d\ud8a5\udca4\ud9e9\udfe5\ud9c6\udce2\ua764\udb76\ude86\udb4e\udf48\udac9\udeb7\ud873\udf17\ud96b\udef7\ud940\udd2b\udb15\udc75\udba6\udd5e\udb32\udec5", "\u9297\ub91c\u4ff0\u818b", "\uda7e\udfa7\udab6\ude14\ud829\udcf2\udbcc\udcd6\ud84f\udf7e\ud85e\udefb\ud9c6\udce3\uda8b\udc5f\udb82\ude11\ud8bc\uddbe",
        43, 93728, 1498707940, -4382736520131785743L, 42734L, false, false, (char) 282, (char) 8338,
        Double.longBitsToDouble(0x3fd7702a8eb67206L), Double.longBitsToDouble(0x3feb5d8959ff5978L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 14, 2, 10, "\uda3c\uddc3\u5855\uda8d\udda0\ud982\udead\ud896\udf12\ua764\udb76\ude86\udb4e\udf48\udac9\udeb7\uda2d\udc13\ud96b\udef7\ud940\udd2b\udb15\udc75\udba6\udd5e\udb32\udec5", "\u9a6d\u46a0\u6603\u20f5", "\uda7e\udfa7\udab6\ude14\ud84a\udd45\udbcc\udcd6\ud84f\udf7e\ud85e\udefb\ud9c6\udce3\udaa9\ude5f\udb82\ude11\ud803\uddc2",
        25, 93728, 1498707940, -4382736520131785743L, 42734L, false, false, (char) 282, (char) 8338,
        Double.longBitsToDouble(0x3fd7702a8eb67206L), Double.longBitsToDouble(0x3feb5d8959ff5978L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|checkIllegalTypes|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|createBeanDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addBeanProps|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addInjectables|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addObjectIdReader|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addReferenceProperties|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|buildBeanDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|buildBuilderBasedDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|buildThrowableDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|constructAnySetter|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.AnnotatedMethod|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|constructBeanDeserializerBuilder|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|constructSettableProperty|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|constructSetterlessProperty|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|createBuilderBasedDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription,java.lang.Class|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|filterBeanProps|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder,java.util.List,java.util.Set|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|findStdDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|checkIllegalTypes|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|createBeanDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
