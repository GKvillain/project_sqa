package com.fasterxml.jackson.databind.deser.impl;
import org.junit.Test;
import static org.junit.Assert.*;
public class ExternalTypeHandler_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 11, 4, "\ud812\udc46\udafc\udc23\ud95e\udc57\udb39\udfb6\ud9ad\udd52\ud88b\udf98", "\ub316\u987a\u9a49\u62ba\ubbaf", "\ud82b\udf2d\udae9\uddf1",
        39, 48892, 1987007870, 3306962601770641618L, -86064L, true, true, (char) 7881, (char) 65241,
        Double.longBitsToDouble(0x3fdf3cec70712baeL), Double.longBitsToDouble(0x3fc9d68fa8ebe2bcL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 11, 2, "\uc443\udafc\udc23\ud95e\udc57\udb39\udfb6\ud9ad\udd52\ud88b\udf98", "\ub316\u987a\u9a49\u58a8\ubbef", "\ud82b\udf2d\ud99d\uddeb",
        40, 48892, 1987007870, -79744320295090107L, -86064L, true, true, (char) 7881, (char) 65241,
        Double.longBitsToDouble(0x3fd04cec70712baeL), Double.longBitsToDouble(0x3fc9c46fa8ebe2bcL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 4, "\ud812\udc46\udafc\udc23\ud95e\udc57\udb39\udfb6\uda66\udf0d\ud88b\udf98", "\u8f31\u987a\u9a49\u62ba\ubbaf", "\ud918\udc84\ud9d5\udf00",
        9, 49014, 1987007870, 3306962601770641618L, -86064L, true, true, (char) 7881, (char) 65241,
        Double.longBitsToDouble(0x3fdf3cec78fbabaeL), Double.longBitsToDouble(0x3fc9cb9288ebe2bcL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 11, 0, "\uda73\udf76", "\u4e69\ua927\uae61\u1ebe", "\uda30\udce8\udb05\uddb5\ud973\udd5c\udb55\udc07\000\ud99b\ude6cZ",
        4, 3854, -572721108, 8534133819314581751L, -43223L, false, false, (char) 42651, (char) 10204,
        Double.longBitsToDouble(0x3fd0b09cf3e79d8eL), Double.longBitsToDouble(0x3ecae33ad1f40000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 0, "\u8f6f\000\000\000\000\ud88b\udf98", "\ub316\u987a\u9a49\u62ba\ubbaf", "\ud82b\uded3\u009b",
        1, 48892, 1987007870, 194574903410688L, -86064L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3dfc4a8000000000L), Double.longBitsToDouble(0x3fc9d68fa8ebe2bcL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 0, "\ud812\udc46\udafc\udc23\ud95e\udc57\udb39\udfb6\ud8eb\udcb0\ud85b\ude5f", "", "\udbde\uddc2",
        49, 34549, 0, 7910572745711029850L, -31306L, false, false, (char) 13147, (char) 45413,
        Double.longBitsToDouble(0x3fca45bc97247028L), Double.longBitsToDouble(0x3fe3803465df30bcL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 7, 4, "\udb92\udcc5\udaf2\udd15\uda09\uddd0\udb39\udfb6\udaf0\udd13\udbde\udece\ud8b1\udec8\uda89\udfcd\ud9f7\udf57\uda30\udce8", "\u1815\ud169\u7480\u1f8d\u0f7d\uceee\u20e6\uc2e9\u5025\u37ac\u7859\uc032\u551d\ub827\u4ab5\u3421\u2d9f\u2fbf\uc007\u0c93\u1f24\u2573\u7377\u63ba\ua1a9\u42d1\ub01d\u2864\ub91d\ub34c\u23ff\u72b9\u8583\u1aba\u6fa2\u978d\u3595\u65c2\u35f8\u0118\uc994\u1dc8\u4c3a\u0499\uaf53\u15ca\u7719\u5f09\u1072\u93a3\ub52e\u8f27\u5be4\uace8\u0616\u2f40\u6971\ua93b\ua523\ua4c0", "\ud906\udf55\ud8f6\udc8e\ud9ad\udc19\ud9a4\udf45\ud989\udf20\ud9de\udcc1\ud8db\udfa8\udbb1\udee1\u81fb\ud919\udeca\udb13\udf05\udbe3\udea4\udbbf\udc33\ud8b1\udf5a\uda21\udc7f\ud96e\udca9\udbfd\udd53\uda20\udeb3",
        51, 7871, -1448603708, -3051151093374537433L, -27504L, true, true, (char) 33434, (char) 5183,
        Double.longBitsToDouble(0x3fe5a213c2db6c26L), Double.longBitsToDouble(0x3fd97823bb849982L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:@? |a1=[Lcom.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$ExtTypedProperty;:[[null, null, null]] |a3=[Ljava.lang.String;:[[\u3421\ua6b9\u7da6\u38bf\u812f\u48db]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 5, "\ud97a\ude85\udb07\udd8f\ud95e\udc57\udb39\udfb6\ud9ad\udd52\ud88b\udf98\udaa7\udcbd\uda89\udfcd\ud967\udc59\uda56\udcec\udb05\uddb5\ud941\ude1e\ud872\udce2\ud9f2\udcd0\ufce3\ud82b\udf2d\udae9\uddf1\ud807\udc77\udbf7\ude2d\ud901\udcda\ud6ea\ud82d\udc47\ud910\udfca\uda82\udf98\ud952\udc38", "\u3421\ua6b9\u7da6\u38bf\u812f\u48db", "\u79ec\uda42\udeb5\ud867\udc8b\u7467\uda9e\udf6c\ud81d\udcd4\ud832\udd35\ud8e8\udf6e",
        -1, 25875, -1392322505, -5532740863074948319L, 47892L, false, true, (char) 55890, (char) 32187,
        Double.longBitsToDouble(0x3fe33fea1246564bL), Double.longBitsToDouble(0x3fa8aec52d61b880L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$Builder:@?\0121=new com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:@? |a1=[Lcom.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$ExtTypedProperty;:[[]] |a3=[Ljava.lang.String;:[[\udb7c\udf2d\udba8\udeb7\udbc1\udc80]] |a4=[Lcom.fasterxml.jackson.databind.util.TokenBuffer;:[[null, null, null]]\012",
        Z.run(T, 2, 5, 9, 10, "\uda9e\udc85\ud882\udc95\ud95e\udc57\ud8fd\udcb6\udbfc\udda0\ud80b\udd6d\udbe6\udf39\udbbf\udfd3\u7199\uda8d\udc08\u1d62", "\u22f0", "\udb7c\udf2d\udba8\udeb7\udbc1\udc80",
        12, 49111, 470468622, 435625481245308528L, -67731L, true, false, (char) 30027, (char) 42672,
        Double.longBitsToDouble(0x3feaa26b1e32c4b2L), Double.longBitsToDouble(0x3fd86aca4269e446L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$Builder:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 8, "\udb60\udc6e\udafc\udc23\ud95e\udc57\udb39\udfb6\ud9ad\udd52", "\u68d5\ub341\u987a\u33d5", "\u7de8",
        31, 28626, 2089281179, 157921024868677676L, -54697L, false, false, (char) 7206, (char) 15495,
        Double.longBitsToDouble(0x3fddf30bc4558be2L), Double.longBitsToDouble(0x3fd957cabc63836cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$Builder:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 10, 11, "\ud812\udc46\udafc\udc23\ud95e\udc57\udb39\udfb6\ud9ad\udd52\udbb6\udfac\ud98d\udd85\uda89\udfcd\udb84\udc63\uda30\udd78\udb05\uddb5\ud94c\udec8\ud872\udce2\ud9f2\udcd0\ud8f3\udd7a\uda4c\udeb7\udae9\uddf1\ud807\udc77\udbf7\ude28\udb0d\udc78\ud9f3\ude5b\ua1ae\udb3d\ude2b\ud8f8\udc54\uda4f\udfdd\ud993\udd80", "\ua6b9\u3023\ucfc5", "\udbe2\udc7d\uda76\udfc9\udb7e\udc76\udbbd\udee2\uda5e\udf4e\ud945\udced\ud821\udea7",
        31, 85303, -1104954157, -3736119362939659495L, -63841L, false, true, (char) 39906, (char) 57721,
        Double.longBitsToDouble(0x3f9b090f1373ab00L), Double.longBitsToDouble(0x3fd0a0c0ba5e1874L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:@? |a1=[Lcom.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$ExtTypedProperty;:[[null]] |a3=[Ljava.lang.String;:[[\ud896\udcf3\u009b]] |a4=[Lcom.fasterxml.jackson.databind.util.TokenBuffer;:[[]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 10, 0, "\u8f6f\000\000\000\000\ud88b\udf98", "\ub316\ud225\u89b0\u0eb4\u631c", "\ud896\udcf3\u009b",
        1, 48892, 1987007870, 194574903410688L, -86064L, true, true, (char) 0, (char) 13,
        Double.longBitsToDouble(0x3dfc4a8000000000L), Double.longBitsToDouble(0x3fc9d68fa8ebe2bcL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$Builder:@?\0121=com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$Builder:@?\012",
        Z.run(T, 2, 5, 5, 4, "\ud812\udc46\ud84c\udfcb\ud95e\udc1a\udb39\udfb6\ud8eb\udcb0\udbad\udd07", "\u63ba", "\ud94c\udec8\udb55\udc94\000",
        54, 71794, 1264095068, 176332380680550444L, -54706L, false, false, (char) 52525, (char) 44816,
        Double.longBitsToDouble(0x3fddf30b12632646L), Double.longBitsToDouble(0x3fe992d345130123L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:@? |a1=[Lcom.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$ExtTypedProperty;:[[null, null, null]] |a3=[Ljava.lang.String;:[[\ud94c\udec8\ud95f\udc99\000\ud8b3\ude78\ud82b\udf2d\uda90\udd26]] |a4=[Lcom.fasterxml.jackson.databind.util.TokenBuffer;:[[]]\0121=new com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:@? |a1=[Lcom.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$ExtTypedProperty;:[[null, null, null]] |a3=[Ljava.lang.String;:[[\ud94c\udec8\ud95f\udc99\000\ud8b3\ude78\ud82b\udf2d\uda90\udd26]] |a4=[Lcom.fasterxml.jackson.databind.util.TokenBuffer;:[[]]\012",
        Z.run(T, 2, 9, 9, 0, "\ud812\udc46\udafc\udc23\ud95e\udc57\udb39\udfb6\ud8e6\udfb6\uda80\ude76", "\000", "\ud94c\udec8\ud95f\udc99\000\ud8b3\ude78\ud82b\udf2d\uda90\udd26",
        55, 92860, -698302324, 6244155877826914386L, -86064L, true, true, (char) 17482, (char) 25021,
        Double.longBitsToDouble(0x3fa6c238da8acd10L), Double.longBitsToDouble(0x3fecf020475e2cbaL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:@? |a1=[Lcom.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$ExtTypedProperty;:[[null, null, null]] |a3=[Ljava.lang.String;:[[\u3421\ua6b9\u7da6\u38bf\uba6a\u48db]]\0121=new com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:@? |a1=[Lcom.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$ExtTypedProperty;:[[null, null, null]] |a3=[Ljava.lang.String;:[[\u3421\ua6b9\u7da6\u38bf\uba6a\u48db]]\012",
        Z.run(T, 2, 9, 9, 5, "\ud97a\ude85\udb07\udd8f\ud95e\udc57\udb39\udfb6\ud9ad\udd52\ud88b\udf98\udaa7\udcbd\udb82\udc66\udb0f\udf4c\uda56\udd7d\udb05\uddb5\ud941\ude1e\ud872\udce2\ud9f2\udcd0\ufce3\ud82b\udf2d\udae9\uddf1\ud807\udc77\udbf7\ude2d\ud901\udcda\ud6ea\ud82d\udc47\ud910\udfca\uda82\udf98\ud952\udc38", "\u3421\ua6b9\u7da6\u38bf\uba6a\u48db", "\u7a27\uda42\udeb5\ud867\udc8b\u7467\uda9e\udf6c\ud81d\udcd4\ud832\udd35\ud8e8\udf6e",
        -1, 25875, -1392322505, -5532740863074948319L, 47892L, false, true, (char) 55890, (char) 32187,
        Double.longBitsToDouble(0x3fb9ff509232b258L), Double.longBitsToDouble(0x3fe98aec5315b43aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:@? |a1=[Lcom.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$ExtTypedProperty;:[[null, null, null]] |a3=[Ljava.lang.String;:[[\u3421\ua6b9\u7da6\u38bf\u812f\u48db]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 8, 5, "\ud97a\ude85\udb07\udd8f\ud95e\udc57\udb39\udfb6\ud9ad\udd52\ud88b\udf98\udaa7\udcbd\uda89\udfcd\ud967\udc59\uda56\udcec\udb05\uddb5\ud941\ude1e\ud872\udce2\ud9f2\udcd0\ufce3\ud82b\udf2d\udae9\uddf1\ud807\udc77\udbf7\ude2d\ud901\udcda\ud6ea\ud82d\udc47\ud910\udfca\ud98f\uddff\uda09\udcc4", "\u3421\ua6b9\u7da6\u38bf\u812f\u48db", "\u79ec\uda42\udeb5\ud867\udc8b\u7467\uda9e\udf6c\ud81d\udcd4\ud832\udd35\ud8e8\udf6e",
        -1, 25875, -1392322505, -5532740863074948319L, 47892L, false, true, (char) 55890, (char) 32187,
        Double.longBitsToDouble(0x3fe33fea1246564bL), Double.longBitsToDouble(0x3fa8aec52d61b880L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 4, "\ud99e\udccf", "\u4e69\u6400\u6fb3\u1efa", "\000\000\ud923\udd70\ud872\udce2\ud9f2\udcd0\ud9db\udd6e\udbe1\ude68",
        -5, -1000, 44, 8534133278148702455L, -43223L, false, false, (char) 0, (char) 63212,
        Double.longBitsToDouble(0x3fd0b0900000018eL), Double.longBitsToDouble(0x3fac4aeb80000000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:@? |a1=[Lcom.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$ExtTypedProperty;:[[null, null]] |a3=[Ljava.lang.String;:[[\uda7a\udc56\ud8d5\ude76\ud925\ude24\udb4f\ude4f\ud992\ude5c\ud8ca\ude7a]] |a4=[Lcom.fasterxml.jackson.databind.util.TokenBuffer;:[[]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 9, "\ud97a\ude85\udb07\udd8f\ud95e\udc57\udb39\udfb6", "\ua5fa\u7c63\ub316\u3776\u9a49\u3610\ubbaf\u22f0\u230d\u93ad\u6dbb\u4fe7\ub373\u9849\u22e8\u0505\u080e\u5342,\u3985\u4ab5", "\uda7a\udc56\ud8d5\ude76\ud925\ude24\udb4f\ude4f\ud992\ude5c\ud8ca\ude7a",
        22, 12896, -157743847, -7321900387962100502L, -54775L, true, false, (char) 397, (char) 28290,
        Double.longBitsToDouble(0x3fe90d99bbcdae21L), Double.longBitsToDouble(0x3fed6d947e41084cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:@? |a1=[Lcom.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$ExtTypedProperty;:[[null, null, null]] |a3=[Ljava.lang.String;:[[\ua5fa\u7c63\ub316\u3776\u4c5c\u46c2\u811d\ub3e4\u230d\u93ad\u6dbb\u4fe7\ub373\u9849\u22e8\u0505\u080e\u5342, \u3985\u4ab5]] |a4=[Lcom.fasterxml.jackson.databind.util.TokenBuffer;:[[null, null]]\0121=new com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:@? |a1=[Lcom.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$ExtTypedProperty;:[[null, null, null]] |a3=[Ljava.lang.String;:[[\ua5fa\u7c63\ub316\u3776\u4c5c\u46c2\u811d\ub3e4\u230d\u93ad\u6dbb\u4fe7\ub373\u9849\u22e8\u0505\u080e\u5342, \u3985\u4ab5]] |a4=[Lcom.fasterxml.jackson.databind.util.TokenBuffer;:[[null, null]]\012",
        Z.run(T, 2, 9, 9, 9, "\ud97a\ude85\udb07\udd8f\ud95e\udc57\udb39\udfb6", "\ua5fa\u7c63\ub316\u3776\u4c5c\u46c2\u811d\ub3e4\u230d\u93ad\u6dbb\u4fe7\ub373\u9849\u22e8\u0505\u080e\u5342,\u3985\u4ab5", "\uda7a\udc56\uda76\ude39\ud925\uddbc\udb76\udd52\ud992\ude5c\udb93\ude9c\u79ec\uda42\udeb5\ud867\udc8b\u7467\uda9e\udf6c\ud81d\udcd4\ud832\udd35\ud8e8\udf6e\ud9db\uddda\uda70\udd85\udbcb\udc8d\uda63\udcf9\udb63\ude4d\udaaf\udf3c\ud8a3\udc2a\udafc\udf58\ud9fc\udca8",
        15, 59910, -410097126, -5728765898502226595L, 83086L, false, false, (char) 65521, (char) 41220,
        Double.longBitsToDouble(0x3f9bc53067874a20L), Double.longBitsToDouble(0x3fed2f70b50e8fbaL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:@? |a1=[Lcom.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$ExtTypedProperty;:[[null, null]] |a3=[Ljava.lang.String;:[[\uda7a\udc56\ud8d5\ude76\ud925\ude24\udbbb\ude45\ud992\ude5c\ud8ca\ude7a]] |a4=[Lcom.fasterxml.jackson.databind.util.TokenBuffer;:[[]]\0121=new com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:@? |a1=[Lcom.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$ExtTypedProperty;:[[null, null]] |a3=[Ljava.lang.String;:[[\uda7a\udc56\ud8d5\ude76\ud925\ude24\udbbb\ude45\ud992\ude5c\ud8ca\ude7a]] |a4=[Lcom.fasterxml.jackson.databind.util.TokenBuffer;:[[]]\012",
        Z.run(T, 2, 9, 9, 9, "\ud97a\ude85\udb07\udd8f\ud95e\udc57\udb39\udfb6", "\ua5fa\u7c63\ub316\u3776\u9a49\u3610\ubbaf\u22f0\u230d\u93ad\u6dbc\u4fe7\ub373\u3728\u22e8\u0505\u080e\u5342,\u3985\u1a47", "\uda7a\udc56\ud8d5\ude76\ud925\ude24\udbbb\ude45\ud992\ude5c\ud8ca\ude7a",
        22, 12896, -157743847, -7321900387962100502L, -54775L, true, false, (char) 397, (char) 28290,
        Double.longBitsToDouble(0x3fe90d99bbcdae21L), Double.longBitsToDouble(0x3fed6d947e41084cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 11, 4, "\ud812\udc46\udafc\udc23\ud95e\udc57\udb39\udfb6\ud9ad\udd52\ud88b\udf98", "\ub316\u987a\u9a49\u62ba\ubbaf", "\ud82b\udf2d\udb22\ude0f",
        20, 48892, 1987007870, 3306962601770641618L, -86064L, true, true, (char) 7881, (char) 65241,
        Double.longBitsToDouble(0x3fdf3cec70712baeL), Double.longBitsToDouble(0x3fc9d68fa8ebe2bcL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|complete|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.deser.impl.PropertyValueBuffer,com.fasterxml.jackson.databind.deser.impl.PropertyBasedCreator|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|complete|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|_deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,int,java.lang.String|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|_deserializeAndSet|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object,int,java.lang.String|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|_handleTypePropertyValue|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.String,java.lang.Object,java.lang.String,int|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|builder|com.fasterxml.jackson.databind.JavaType|static",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|handlePropertyValue|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.String,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|handleTypePropertyValue|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.String,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|start||new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "C|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|<init>|com.fasterxml.jackson.databind.JavaType,[Lcom.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$ExtTypedProperty;,java.util.Map,[Ljava.lang.String;,[Lcom.fasterxml.jackson.databind.util.TokenBuffer;",
    "C|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|<init>|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|complete|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.deser.impl.PropertyValueBuffer,com.fasterxml.jackson.databind.deser.impl.PropertyBasedCreator|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|complete|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
