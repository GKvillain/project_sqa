package com.fasterxml.jackson.databind.deser;
import org.junit.Test;
import static org.junit.Assert.*;
public class BeanDeserializerBase_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 2, 12, "\udb45\ude0f\ud879\udf8d\uda0b\udd8a\ud830\ude7f\uda3b\ude5b\ud996\udcd6", "\u1fb4\u70b4]\u12d3\ubd57\u9fd0", "\udb47\udf34\ud9f0\udefc\ud936\udd7f\ud956\ude47\ud845\udda6\udb2e\udd44\ud84d\udfa9\ud83b\udcb0\udbaf\udd28\ud8ca\udc3d\ub5e2\ud8f6\udd62\ud824\ude01\ud83a\udc73\uda8f\udc40\ud80d\ude7a\ud943\ude31\uda21\udc87\uda45\udf18\ud89a\udd3d\udbdd\udf3f",
        12, 44775, 1396848793, -7465486507379657981L, -15642L, false, true, (char) 59101, (char) 56454,
        Double.longBitsToDouble(0x3fe472aae4cae366L), Double.longBitsToDouble(0x3fe9aa213a1da3dcL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 2, 6, "\ub305\ud879\udfa1\uda0b\udd8a\ud830\ude7f\ud9ed\ude4f\ud996\udcd6", "\u1fb4\u70b4\u53d2\u0a34\ubd57\u9fd0", "\udb47\udf34\ud9f0\udefc\ud938\udd81\ud956\ude47\ud845\udda6\udb1c\udc44\ud84d\udfa9\ud83b\udcb0\udbaf\udd28\ud8ca\udc3d\ub5e2\ud8f6\udd62\ud824\ude01\ud83a\udc73\uda8f\udc40\ud80d\ude7a\ud943\ude31\uda21\udc87\ud91a\udf42\udb80\uddc1\udafc\udc6d",
        -4, 67343, 1399450521, -7465486507379657981L, 47086L, false, false, (char) 22364, (char) 13817,
        Double.longBitsToDouble(0x3fc1a9e924be0790L), Double.longBitsToDouble(0x3fe39eb0e53b1de0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 12, 12, "\udb45\ude0f\udbc4\uddf3\uda0b\udcd5G\uda3b\ude5b\ud996\udcd6", "\u1fb4\u70b4\u4812\u12d3\ubd57\u9fd0", "\udb47\udf34\ud9d0\uddfc\ud936\udd7f\uda13\udd3b\ud845\udda6\udb2e\udd44\035\ud83b\udcb0\udbaf\udd28\ud8ca\udc3d\ud8be\udf4a\ud8f6\udd61\ud824\ude01\ud83a\udc73\uda8f\udc40\ud80d\ude7a\u1793\000\uda0c\udd45\ud89a\udd3d\udbdd\udf3f",
        12, 44775, 1396848793, -7465486507379657981L, -15642L, false, true, (char) 59101, (char) 56454,
        Double.longBitsToDouble(0x3fe472aae4cae366L), Double.longBitsToDouble(0x3fe9aa213a1da3dcL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 2, 8, "\udb45\ude0f\ud879\udf8d\uda0b\udd8a\ud830\ude7f", "\u326b\ub21d\u1fb4\u70b4]\u12d3\ubd57\u9fd0\ub7d8\u36c4\u1562\uc836\u0bab\ub434\ud06d\u8bce\u0dad\u1e88\u70fa\u2129\ub774\u9b50\u6b3c\u6046\u20f9\u682d\u54f4\ubec9\ud705\uad77\u51b5\uc77b\u63bf\ua346\u10c8\u0e47\u7996\u0d19\ud0c9\u0e12\uad90\u74a8\u5591\u5e00\u21fd\u6594\uc61a", "\ud965\udd55\ud9bf\ude4e\ud8b5\udcf1\udb49\udea5\ud8d1\udda7\udaf3\udcb3\uda85\udf31",
        59, 64748, -1295574384, 1060795128355066848L, -4642L, false, false, (char) 50023, (char) 27077,
        Double.longBitsToDouble(0x3fec9e975e2c0e26L), Double.longBitsToDouble(0x3fc3d946c4220854L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 2, 12, "\udb45\udee7\ud879\udf8d\uda0b\udd8a\ud830\ude7f\uda3b\ude5b\ud996\udcd6", "\u1fb4\u70b4]\u662b\u8d3c\u9fd0", "\udb47\udf34\ud9f0\udefc\ud936\udd7f\ud956\ude47\ud845\udda6\udb2e\udd44\ud84d\udfa9\ud83b\udcb0\udbaf\udc4c\ud8ca\udc3d\ub5e2\ud8f6\udd62\ud824\ude01\ud83a\udc73\uda8f\udc40\ud80d\ude7a\ud943\ude31\uda21\udc87\uda45\udf18\ud89a\udd3d\udbdd\udf3f",
        12, 44775, 1396848793, -7465486507379657981L, -15642L, false, true, (char) 59101, (char) 56454,
        Double.longBitsToDouble(0x3fe472aae4cae366L), Double.longBitsToDouble(0x3fe9aa213a1da3dcL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|_delegateDeserializer||new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|deserializeFromArray|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|deserializeFromBoolean|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|deserializeFromDouble|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|deserializeFromNumber|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|deserializeFromObjectUsingNonDefault|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|deserializeFromString|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|_convertObjectId|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object,com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|_deserializeUsingPropertyBased|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|_findDelegateDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.introspect.AnnotatedWithParams|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|_findSubclassDeserializer|com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object,com.fasterxml.jackson.databind.util.TokenBuffer|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|_handleTypedObjectId|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object,java.lang.Object|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|_resolveInnerClassValuedProperty|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.deser.SettableBeanProperty|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|_resolveManagedReferenceProperty|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.deser.SettableBeanProperty|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|_resolveUnwrappedProperty|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.deser.SettableBeanProperty|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|_resolvedObjectIdProperty|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.deser.SettableBeanProperty|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|_delegateDeserializer||new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|deserializeFromArray|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|deserializeFromBoolean|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|deserializeFromDouble|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|deserializeFromNumber|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|deserializeFromObjectUsingNonDefault|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerBase|deserializeFromString|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.BeanDeserializer:com.fasterxml.jackson.databind.deser.BeanDeserializerBase",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
