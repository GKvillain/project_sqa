package com.fasterxml.jackson.databind.deser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class CollectionDeserializer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 8, 2, "\ud8bb\udd1b\uda97\ude4b\ud848\udf42", "\u0235", "\udba0\udf05\ud837\udf6e\ud70f\udba7\uddac\ud875\udc17\udbae\uddc0\ud91d\udf34\udbc1\udc6f\udb27\udeb8",
        10, 4863, -489788286, 1017337360826731522L, 47377L, true, false, (char) 57756, (char) 6303,
        Double.longBitsToDouble(0x3fe38941bd8b3ad1L), Double.longBitsToDouble(0x3fd905c2b18231b8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 8, 2, "\ud8bb\udd1b\uda97\ude4b\ud848\udf42", "\u0235", "\udba0\udf05\ud837\udf6e\ud70f\udba7\uddac\ud875\udc17\udbae\uddc0\ud91d\udf34\udbc1\udc6f\udb27\udeb8",
        10, 4863, -489788286, 1017337360826731522L, 47377L, true, false, (char) 57756, (char) 6303,
        Double.longBitsToDouble(0x3fe38941bd8b3ad1L), Double.longBitsToDouble(0x3fd905c2b18231b8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 8, 12, "\ud8a3\udd1b\uda97\ude4b\ud848\udf42", "\u0235", "\u00f0\000\ud70f\udba7\uddac\ud875\udc17\u1ced\ud840\ude1f\udbc1\udc6f\udb27\udeb8",
        10, 4863, -489788286, 1017337360826731522L, 47377L, true, false, (char) 57756, (char) 6303,
        Double.longBitsToDouble(0x3fe38941bd8b3ad1L), Double.longBitsToDouble(0x3fd905c2b18231b8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 8, 2, "\ud92c\ude74\uda97\ude4b\ud869\udd52", "\u0235", "\u09dd\ud813\udf68\ud70f",
        25, 38544, -903078675, 2599822815595131469L, 87286L, true, false, (char) 42559, (char) 30655,
        Double.longBitsToDouble(0x3f6330c9cdab4300L), Double.longBitsToDouble(0x3fe28c5953eaf4f1L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 8, 2, "\ud8bb\udd1b\uda97\ude4b\ud819\udd42", "\u0235", "\udba0\udf05\ud9eb\udd28\ud9fe\udf9d\ud8bc\udc4d\uda99\ude92\udbcd\udf4a\udb1f\udd29\ud882\udfe0\udb2b\ude59",
        10, 72271, 870809734, -8182017446542078728L, 47377L, true, false, (char) 57756, (char) 6303,
        Double.longBitsToDouble(0x3fe38941bad8fe7eL), Double.longBitsToDouble(0x3fd06756489c31b8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:@?\012",
        Z.run(T, 1, 12, 8, 2, "\udbd5\udeea\uda97\ude4b\ud848\udf42\ud868\udf30\udb3e\udeca\uda44\udfc5\udbaf\uddf4\udb6d\udc61\ud99d\udcd9\ud810\udeeb\ud70f\udbaf\udf76\udb1a\ude22", "\u7460", "\ud9cb\udfa0",
        4, 82308, 2068635736, -567599965733273521L, 33301L, false, true, (char) 9896, (char) 55387,
        Double.longBitsToDouble(0x3fec8cf670c118dcL), Double.longBitsToDouble(0x3fdd7599674a2574L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 8, 10, "\ud8bb\udd1b\uda20\udecf\ud848\udf42", "\ub607\u7642\u6150\ua4cd\ua1bb", "\u2f25\udb6e\udff0\ud91d\udf34",
        12, 45215, 1024578807, 4160521345967221890L, 13900L, true, false, (char) 9094, (char) 6303,
        Double.longBitsToDouble(0x3fe38941bde23ad1L), Double.longBitsToDouble(0x3fd905c2b1823134L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 3, 6, "\ud8bb\udd1b", "\u9dd2", "\ud9e3\udc6a\udb7c\udd69\uda55\uddbe\ud841\udccd\ud70f\udba7\uddac\ud875\udc17\udbae\uddc0\ud91d\udf34\udbc1\udc6f\ud820\udfd5\ud929\udfe4\ud819\udf86\uda2a\udec9\udbfd\udfc5\udb55\udcfb\ud872\ude60\ud896\udee2\udbb1\uddaf\ud92e\udca2\udabf\udc3c\ucb8b\udb92\udf65\udbf4\udfc9\udabe\udebc\udba9\uddaf\ud9b9\ude7c",
        10, 99581, 288336032, -1175727075115686791L, -57416L, true, false, (char) 51919, (char) 35559,
        Double.longBitsToDouble(0x3feda78b86554689L), Double.longBitsToDouble(0x3fe5e698f81b2f02L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 8, 2, "\uda05\ude81\ud8a3\udd1b\ud949\udda1", "\u0235\u1a48", "\ud837\udf6e\uda08\udef6\udba7\uddac\ud91a\udd0b\ud81d\udf40\uda22\udf8c\udb6a\udca2\udb2e\udf13\ud929\udfe4\uda0a\udc61\ub1cb\udaee\udec4",
        29, 60866, 1894849827, -1562237200408381621L, -31791L, true, true, (char) 7611, (char) 63900,
        Double.longBitsToDouble(0x3fd6a2b4459b396aL), Double.longBitsToDouble(0x3fe0eb59be73ae20L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 8, 2, "\udb29\udfa2\ud8ad\ude50\ud869\udd52\udace\uddf3", "\uaaeb\u5956\ubd3d\u3a57\u47f3\u104f\ub9ae\ud520\u0fd7\u170b\u73ad\u5d30\u988d\ucef1\u56f3\u41a6\u1dcb\ub535\u896b\uc450\u1a30\ud7b0\u3696", "\uda62\ude8b\udad3\udf2f\udb69\udf60\udb70\udc61\udb3c\udf76\u2f6b\ud82e\udd67\ud9d0\ude5f\udbe5\udc5d\uda0f\udf20\udb3f\ude73\udbd0\udcbd\ud8c9\udcc4\udb78\udd50\udaf4\ude1b\udbd0\ude45\udbfe\udc37\udbde\udec4",
        21, 86791, 1023165893, 3115984076352650046L, 38795L, true, true, (char) 4472, (char) 43331,
        Double.longBitsToDouble(0x3fce728683bcd66cL), Double.longBitsToDouble(0x3fc8d2f9d304f31cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 6, 2, "\udbd5\udeea\ud982\ude40\ud848\udf42\ud868\udf30\udb3e\udeca\uda44\udfc5\udbaf\uddf4\udb6d\udc61\ud99d\udca9\ud810\udeeb\ud70f\udbaf\udf76\udb1a\ude22", "\u7460", "\udaa8\udf8c",
        3, 55787, 2068635736, -2001594941424387008L, 4777L, false, true, (char) 9855, (char) 20614,
        Double.longBitsToDouble(0x3fd48307d0ea0e26L), Double.longBitsToDouble(0x3fc87132cdad93bcL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:@?\0121=new com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:@?\012",
        Z.run(T, 2, 12, 11, 10, "\uda66\uddd9\udbef\udf3c\udacf\udda4\udb79\udc17\ud96a\udd84\uda94\udcdd\ud9e3\udc6a\udb7c\udd69\udb80\udf05\ud837\udf6e\uda08\udef6\udbb8\udebf\ud91a\udd0b", "\ub956\u14cc\u44ac\u7938\u4de9", "\uda05\udc06\uda17\udcfe\udba5\udff6\ud92e\udca2\udabf\udc3c\ucde9\uda4a\udd7c",
        51, 45001, -1664422747, 7725796297476715037L, 88628L, false, false, (char) 43151, (char) 9686,
        Double.longBitsToDouble(0x3fe1c5c5d1a1b696L), Double.longBitsToDouble(0x3fdcb175c8bd0996L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 6, 2, "\udbd5\udeea\ud982\ude40\ud848\udf42\ud868\udf30\udb3e\udeca\uda44\udfc5\udbaf\uddf4\udb6d\udc61\ud99d\udca9\ud810\udeeb\ud70f\udbaf\udf76\udb1a\ude22", "\u7460", "",
        -5, 10878, -363069189, 8884722832990857217L, 16110L, true, true, (char) 5919, (char) 9855,
        Double.longBitsToDouble(0x3fdb53ad129060faL), Double.longBitsToDouble(0x3e93987132c00000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:@?\0121=new com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:@?\012",
        Z.run(T, 2, 12, 12, 11, "\udbd5\udeea\ud982\ude40\ud848\udf42\ud868\udf30\udbb0\udec3\uda44\udfc5\udbaf\uddf4\udb6d\udc61\ud8e3\udfed\ud9b6\udda5\u9b24\udbe0\udc76\udb1a\ude22", "\u74dc", "\uda81\uded4\ud939\udf67\uda12\udcb4\ud883\udf9c",
        46, 74079, 2033304974, 707515155957550414L, -28907L, true, false, (char) 34895, (char) 19321,
        Double.longBitsToDouble(0x3fceac9dfb724c24L), Double.longBitsToDouble(0x3fe2cabbf83643d5L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 8, 2, "\ud8bb\udd1b\uda97\ude4b\ud848\udf42", "\u0235", "\udba0\udf05\ud837\udf6e\ud70f\udba7\uddac\ud875\udc17\udbae\uddc0\ud91d\udf34\udbc1\udc6f\udb27\udeb8",
        10, 61671, -167457703, 8794769964113950787L, 47377L, true, false, (char) 57756, (char) 6303,
        Double.longBitsToDouble(0x3fe38941bd8b3ad1L), Double.longBitsToDouble(0x3fd905c2b18231b8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 8, 3, "\ud8bb\udd1b\uda97\ude4b\ud848\udf42", "\u0235", "\ud948\ude7a\ud837\udf6e\ud70f\uda37\udc54\ud875\udc17\udbae\uddc0\ud91d\udf34\udbc1\udc6f\udb27\udeb8",
        10, -185, -489806951, 1017337360826731522L, 47377L, true, false, (char) 57756, (char) 6303,
        Double.longBitsToDouble(0x3fe38941bf8b3ad1L), Double.longBitsToDouble(0x3fc20b8563046370L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.std.CollectionDeserializer|createContextual|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanProperty|new:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer",
    "M|com.fasterxml.jackson.databind.deser.std.CollectionDeserializer|deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer",
    "M|com.fasterxml.jackson.databind.deser.std.CollectionDeserializer|deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.util.Collection|new:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer",
    "M|com.fasterxml.jackson.databind.deser.std.CollectionDeserializer|deserializeWithType|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.jsontype.TypeDeserializer|new:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer",
    "M|com.fasterxml.jackson.databind.deser.std.CollectionDeserializer|getContentDeserializer||new:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer",
    "M|com.fasterxml.jackson.databind.deser.std.CollectionDeserializer|getContentType||new:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer",
    "M|com.fasterxml.jackson.databind.deser.std.CollectionDeserializer|handleNonArray|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.util.Collection|new:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer",
    "M|com.fasterxml.jackson.databind.deser.std.CollectionDeserializer|isCachable||new:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer",
    "M|com.fasterxml.jackson.databind.deser.std.CollectionDeserializer|withResolved|com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.jsontype.TypeDeserializer|new:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer",
    "M|com.fasterxml.jackson.databind.deser.std.CollectionDeserializer|withResolved|com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,java.lang.Boolean|new:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer",
    "C|com.fasterxml.jackson.databind.deser.std.CollectionDeserializer|<init>|com.fasterxml.jackson.databind.deser.std.CollectionDeserializer",
    "C|com.fasterxml.jackson.databind.deser.std.CollectionDeserializer|<init>|com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.deser.ValueInstantiator,com.fasterxml.jackson.databind.JsonDeserializer,java.lang.Boolean",
    "C|com.fasterxml.jackson.databind.deser.std.CollectionDeserializer|<init>|com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.jsontype.TypeDeserializer,com.fasterxml.jackson.databind.deser.ValueInstantiator",
    "M|com.fasterxml.jackson.databind.deser.std.CollectionDeserializer|createContextual|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanProperty|new:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer:com.fasterxml.jackson.databind.deser.std.CollectionDeserializer",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
