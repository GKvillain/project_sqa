package com.fasterxml.jackson.databind.deser;
import org.junit.Test;
import static org.junit.Assert.*;
public class BeanDeserializerFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 3, 6, "\ud8b3\udf05\ud977\udfd5", "\u4746\u4eb9\u893c\u1769\u4c51\u09c1\uc50a\uc332\u41f7\u2f74\u6db5\u4583\ub745\u8e7a", "\ud8f8\udcb7\udb3d\udc79",
        -4, 33528, 41411568, -3669628940676775970L, -94248L, true, false, (char) 4901, (char) 53417,
        Double.longBitsToDouble(0x3fceabf099202474L), Double.longBitsToDouble(0x3feb1b2be3450fc2L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 3, 8, "\ud8b3\udf05\ud977\udfd5", "\u6efe\u4b94\u288c\ud582\u4c51\uaf18\u5567\u0c9f\uc2eb\u4238\u153c\u5bbc\u6ee8\u3e0d", "\ud8f8\udcb7\udb3d\udc79",
        -4, 33528, 41411568, 6847346014050088538L, -94248L, true, false, (char) 4901, (char) 18346,
        Double.longBitsToDouble(0x3fcc3c97b9202474L), Double.longBitsToDouble(0x3fb8d95f1a2879d8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 3, 6, "\ud8b3\udf05\ud977\udfd5", "\u4746\u4eb9\u893c\u1769\u4c51\u09c1\uc50a\uc332\u41f7\u229d\u29cb\u4583\ub745\u8e7a", "\ud930\udc3d\udb3d\udd26\ua6dd\uda89\ude4c\ud8c5\udc15\udab6\udceb\udbc9\udc6a\ud800\udf47\ud813\udc93\udb0c\udf81",
        12, 70670, 152900853, 7312823558537910115L, -29134L, false, false, (char) 27086, (char) 50783,
        Double.longBitsToDouble(0x3fe4a8ace4389c66L), Double.longBitsToDouble(0x3fee96d728d60b9fL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 2, 6, "\ud87c\uddd4\ud977\udfd5", "\u4746\u4eb9\u893c\u1769\u4c51\u09c1\uc50a\u50d4\u416c\u2f74\u6db5\u4583\ub745\u8e7a\uc9ba\uace5\u3980\u670c\u760d\uae81\uc6dc", "\ud800\udf47\ud813\udc93\udb98\udf87",
        12, 70670, 1545409781, 7315692764195362659L, -88788L, false, false, (char) 3661, (char) 32213,
        Double.longBitsToDouble(0x3f9a99cae23a62c0L), Double.longBitsToDouble(0x3fe9a817207d9256L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 5, 0, "\ud8b3\udf05\ud977\udfd5", "\u6015\u655a\uc90e\u2da5\u4c51\u8fc0\u7f25\u44ae\ub48c\ua8c8\u6db5\u40a8\ub757\u1a95", "\ud99a\ude49",
        38, 51153, -776831451, -1335382701819028286L, -41276L, false, true, (char) 13849, (char) 34048,
        Double.longBitsToDouble(0x3fe0efdebcf51235L), Double.longBitsToDouble(0x3fd48091d8cb6268L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 3, 6, "\uda39\udc37\u1cfe\udbfe\ude72\ud905\udd48\udb09\udcf4\ud9bb\uddb3", "\u302c\u09c1\uc50a\u7e84\u48f0\u3fe5", "\ud9fd\udd92",
        14, 62442, 1998294971, 5680354222892074500L, -53062L, false, true, (char) 56930, (char) 11149,
        Double.longBitsToDouble(0x3fd64c577f11b848L), Double.longBitsToDouble(0x3fe3599d1e821b86L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 6, 0, "\ud8b3\udf05\ud977\udfd5", "\u4746\u4eb9\u893c\u4a70\u4c51\u09c1\ub510\uc332\u41f7\u2f20\u4e4c\u288d\u5244\u9d98", "\ud8f8\udcb7\udbdd\udf0a",
        57, 33528, 41411568, -7416623831663767228L, -94248L, true, false, (char) 4901, (char) 53417,
        Double.longBitsToDouble(0x3fceabf099202474L), Double.longBitsToDouble(0x3feb1b2be3450fc2L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 16, 6, "\ud80e\udd75\ud9e9\udcf2", "\u1d4f\u2b81\u0aed\ubd3d\u4c51\u7e06\u9b3a\u116f\u844e\u8412\u6d81\u4583\ub745\u8e7a", "\ud8f8\udcb7",
        51, 60551, -706313928, 7214035311868959534L, -68661L, true, false, (char) 3371, (char) 47350,
        Double.longBitsToDouble(0x3fd48091dec6cb82L), Double.longBitsToDouble(0x3fea8bf614d80eacL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 12, "\ud8be\ude71\ud977\udfd5\udb57\udc9e\ud8fc\uddc2\ud814\udd99\ud9bb\ude06\ud951\ude99\ud8f4\udf30\ud9d2\ude95\uda66\udf84\ud8f8\udefb\udb33\udebb\u3494", "\u4583\ub745\u8e7a\uc9ba\uace5\u3980\u670c\u760d\uae81\uc6dc\u3f90\u7a7e\ubae4\u46bc\ub8cc\u199d", "\ud811\udc43\udb02\udc50\uda99\udcf5\ud950\udc7e\u1a48\ue6f5\udb5a\udfc2\udab5\uddda\ud826\udd51\u703e\udbf5\uddef\ud86a\udf01\uda20\udc4c\ud8d9\uddc0\ud91f\udf3a\ud94a\udc64\uda5e\ude79\ud833\udc3f\ud98a\ude85\ud82d\udd11\udb2a\udc9d",
        7, 38855, -141571335, 6418123280768904114L, 85013L, true, false, (char) 9931, (char) 15535,
        Double.longBitsToDouble(0x3fee340eb7015a9aL), Double.longBitsToDouble(0x3fdf94418984a068L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 14, 6, 6, "\ud8b3\udf05\ud977\udfd5", "\u4746\u4eb9\u893c\u1769\u4c35\u094e\uc50a\uc332\u41f7\u3032\u81b5\u00dc\u58a6\u3909", "\ud8f8\udcb7\ud8aa\udff9\udaf3\udf09\udb42\udf04\udb0c\uddb9",
        34, 28128, -601561756, -6386099574760078858L, 86566L, true, false, (char) 26469, (char) 64734,
        Double.longBitsToDouble(0x3fea287e15d4ab1bL), Double.longBitsToDouble(0x3fcaf72f540931d0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 3, 6, "\udbf0\udc8e\ud977\udfd5", "\u4746\u4eb9\u17c0\u467f\u6635\ubc43\uc50a\uc332\u41f7\u2f74\u6d39\u4583\ub745\uc52b", "\uda5f\ude0c\udab3\udf02",
        37, 33528, 41411568, -3669628940822447650L, 68114L, false, false, (char) 45420, (char) 24071,
        Double.longBitsToDouble(0x3fd267978b5f5c2cL), Double.longBitsToDouble(0x3fd237e5ecd95b42L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 3, 8, "\ud8b3\udf05\ud977\udfd5", "\u1cf7\u4116\u20be\u130b\u4ad4\u0974\uc50a\u91fa\u1530\u2c01\u6db5\u4583\ub745\uc026", "\ud8f8\udcb7\udb3d\udc79",
        -4, 33528, 41411568, 974708174113062891L, -94367L, true, false, (char) 4901, (char) 53417,
        Double.longBitsToDouble(0x3fceabf099202474L), Double.longBitsToDouble(0x3fe31b2be3450f0bL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 3, 9, "\ud8b3\udf05\ud977\udfd5", "\u4746\u4eb9\u893c\u1769\u4c51\u09c1\uc50a\uc332\u474d\u0da1\ud6fd\u73bb\ub434\u8e7a", "\ud8f8\udcb7\udb3d\udc79",
        -4, 29367, 41411568, -3669628940676775970L, -94248L, false, false, (char) 4901, (char) 53417,
        Double.longBitsToDouble(0x3fceabf099202474L), Double.longBitsToDouble(0x3fd63657c5653a06L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|checkIllegalTypes|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|createBeanDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addBeanProps|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addInjectables|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addObjectIdReader|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addReferenceProperties|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|buildBeanDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|buildBuilderBasedDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|buildThrowableDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|constructAnySetter|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.AnnotatedMember|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|constructBeanDeserializerBuilder|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|constructSettableProperty|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|constructSetterlessProperty|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|createBuilderBasedDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription,java.lang.Class|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|filterBeanProps|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder,java.util.List,java.util.Set|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|findStdDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|checkIllegalTypes|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|createBeanDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
