package com.fasterxml.jackson.databind.jsontype.impl;
import org.junit.Test;
import static org.junit.Assert.*;
public class AsPropertyTypeDeserializer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:[com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer; base-type:null; id-resolver: null]\012",
        Z.run(T, 1, 7, 1, 6, "\u471a\ud82e\udea6\udb37\udc75", "\u60a0\u977c\u5c10\u4eb1\u4e6d\ub629\u167f\ucde8\u6546\u7641\ud5e0\ub994", "\udae1\udfe8\ud9cf\uded3\udaff\udf9c\uda2b\udd63",
        22, 57421, 641673846, -8040288306396965374L, -87860L, true, false, (char) 50879, (char) 19444,
        Double.longBitsToDouble(0x3fca83e57f4f7d64L), Double.longBitsToDouble(0x3fbc68cd4d78b978L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:[com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer; base-type:null; id-resolver: null]\012",
        Z.run(T, 1, 8, 1, 6, "\u471a\udb25\udc9e\uda3e\udce7\ud9b9\udd5e\ud97b\udcaf\ud8a7\udf68\ud877\udee9\udb9e\udf91\uda3c\udd84\u4402\ud82f\udc1d\ud91e\udcb6", "\u7641\ud5e0\ub994\u25f7\u62c9\u613d\u642e\u9cd7\ud2ab\ub8b7\u1e10", "\ud971\udcee\udb4a\udf09\udade\udd28\ud80e\udcef\ud998\udff6\ud9b9\udd4c\ud864\udcdd\ud822\udd95",
        -3, 36903, -249053302, -1441883208306377852L, -92713L, false, false, (char) 24584, (char) 37751,
        Double.longBitsToDouble(0x3fdb6a02effea762L), Double.longBitsToDouble(0x3fd74915bcd41a1aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 1, 6, "\u471a\ud82e\udea6\udb37\udc75", "\u60a0\u977c\u5c10\u57c8\u4e6d\ub629\ubf30\ucde8\u6546\u7641\ud5e0\ub994", "\udae1\udfe8\ud9cf\uded3\udaff\udf9c\uda2b\udd63",
        22, 57421, 641673846, -8040288306396965374L, -87860L, true, false, (char) 50879, (char) 19444,
        Double.longBitsToDouble(0x3fca83e57f4f7d64L), Double.longBitsToDouble(0x3fbc68cd4d78b978L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 1, 6, "\u471a\ud82e\udea6\udb37\udc75", "\u1e87\u7709\ub8a6\u04ac\u4e15\ub629\u167f\ucde8\u6546\u7641\ud5e0\u8c94", "\udae1\udffb\ud9cf\udf01\udaff\udf9c\uda2b\udd63",
        22, 57421, 641673846, -8040288306396965374L, -87860L, true, false, (char) 50879, (char) 19444,
        Double.longBitsToDouble(0x3fca83e57f4f7d64L), Double.longBitsToDouble(0x3fbc68cd4d78b978L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 1, 6, "\u471a\ud82e\udea6\ud826\udded", "\u60a0\u5bda\u35bf\u4eb1\u4e6d\ub629\u167f\ucde8\u6546\u7641\uad94\000", "",
        -5, 10272, 1379807940, 2897137293063945328L, -56482L, false, true, (char) 24614, (char) 43439,
        Double.longBitsToDouble(0x3fcd783a8003bf28L), Double.longBitsToDouble(0x3fca83e57f4f7d64L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 1, 6, "\ud82e\ude24\ud82e\udea6\udb37\udc75", "\u60a0\u977c\u5c10\u4eb1\u4e6d\ub629\u167f\ucde8\u6546\u7641\ud5e0\ub994", "\ud89a\ude44\ud9b8\udf34\udaff\udf9c\uda2b\udd63\ud9df\udfe0\ud873\ude0d\u93b2\uda62\uddce",
        59, 81307, 622317716, -4479809936933911317L, -5580L, true, true, (char) 9126, (char) 49373,
        Double.longBitsToDouble(0x3fe7af57b5c4f724L), Double.longBitsToDouble(0x3fd446d144c66e46L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:[com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer; base-type:null; id-resolver: null]\012",
        Z.run(T, 1, 7, 1, 6, "\u471a\ud82e\udea6\udb37\udc75", "\u60a0\u977c\u5c10\ub06e\u4e41\ub629\u167f\ucfe8\u6546\u7641\ud5e0\ub994\ub647", "\ud9cf\uded3",
        25, 63341, 950958960, 8254006066342210166L, -56482L, false, true, (char) 24614, (char) 19413,
        Double.longBitsToDouble(0x3fcd783a90a7bf28L), Double.longBitsToDouble(0x3fca83e57f4f7d64L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:[com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer; base-type:null; id-resolver: null]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 6, "\u471a\ud862\ude00\udb48\udf75", "\u60a0\u977c\u5c10\u4eb1\u4e6d\ub629\u167f\ucde8\u6546\u7641\ud5e0\ub994", "\udae1\udfe8\ud9cf\uded3\udb1d\udff5\ud805\udfbb",
        21, 94740, 641673846, -8040288306396965374L, -87860L, true, true, (char) 50879, (char) 19444,
        Double.longBitsToDouble(0x3fca83e57f4f7d64L), Double.longBitsToDouble(0x3fbc68cd4d78b978L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 8, "\u471a\ud82e\udea6\udb37\udc75", "\u60a0\u1997\u5c10", "\ud8ff\udc01\ud91e\udcb6\udb87\udd60\ud83f\udd06\udace\uddee\udbac\udc87\ud976\udd7b\ud8cb\udf0f\uda82\udfd2\udae1\udfe8\udb0f\ude95\udaff\udf9c\uda2d\ude63\ud9df\udfe0\ud84b\udd0d\u34b7\uda62\uddce\ud9c6\udfa7\udb78\udd7b\uda5f\uddc3\ud80e\udcef\ud998\udff6\ud8c5\uddff\ud983\udee7\ud822\ude5b\udb7b\udca6\ud8b2\udea8\udada\udff0\uda18\udee0\ud993\ude85\ud993\udcd8",
        51, 22194, -1964601172, 6110216766404924808L, 6903L, true, false, (char) 45695, (char) 21905,
        Double.longBitsToDouble(0x3fd6a18c8fb1c24cL), Double.longBitsToDouble(0x3fe7027761c280ddL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:[com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer; base-type:null; id-resolver: null]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 6, "\ud96b\uddf3", "\ub34f\u882a\u07b0\ub2a3\u3df5\u02b1\u4e6d\ub629\ucff9\u2b37\u6546\u7641\ud5f8\u4324\u1022\u3fa5\u613d\u8750\u7c63\u804d\u4aee\u1857\u424d", "\udb4a\udf09\uda54\udec3\udaf4\udec2\ud998\udff6\ud8c5\uddff\ud983\udee7\ud822\ude5b\udb1c\uddce\ud880\udc73\ud9ca\udf5f\uda51\udc86\uda8e\uddba\udbcc\udf33\ud9a8\udf9c\udb3e\ude94\ud9a9\udec9",
        1, 25160, 874732183, -7390648682810045685L, 32219L, false, true, (char) 30363, (char) 57423,
        Double.longBitsToDouble(0x3fe838c3b2715e1cL), Double.longBitsToDouble(0x3fbf77dbadd3ae50L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:[com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer; base-type:null; id-resolver: null]\0121=new com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:[com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer; base-type:null; id-resolver: null]\012",
        Z.run(T, 2, 7, 8, 7, "\u471a\ud862\ude00\udb48\udf75", "\u60a0\u977c\u5c10\u4eb1\u4e6d\ub629\u167f\ucde8\u6546\u7641\ud5e0\ub994", "\udae1\udfe8\ud9cf\uded3\udb1d\udff5\ud805\udfbb",
        21, 94740, 641673846, -8040288306396965374L, -52664L, true, true, (char) 50879, (char) 19444,
        Double.longBitsToDouble(0x3fca83e57f4f7d64L), Double.longBitsToDouble(0x3fbc618d4d78b978L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:[com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer; base-type:null; id-resolver: null]\0121=new com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:[com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer; base-type:null; id-resolver: null]\012",
        Z.run(T, 2, 7, 7, 6, "\u471a\ud862\ude00\udb48\udf75", "\u3482\uab18\u0d0c\u4ea1\ud5d2\u8b32\ub1bb\u7f57\u478f\u7641\ud5e0\u0623", "\udbc0\udfb6\ud9b8\udfc9\ud894\udf56\u3329",
        18, 42150, -912266964, 5031647236560548082L, 2718L, true, false, (char) 17931, (char) 29674,
        Double.longBitsToDouble(0x3fca83e5654b7db4L), Double.longBitsToDouble(0x3feb9a4271af172fL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:[com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer; base-type:null; id-resolver: null]\0121=new com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:[com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer; base-type:null; id-resolver: null]\012",
        Z.run(T, 2, 8, 8, 6, "\ud96d\uded8\udb7a\uded6\uda44\udeac", "\u60a0\u977c\u5c10\u4eb1\u4e6d\ub629\u167f\ucde8\u6546\u7641\ud5e0\ub994", "\udae1\udfe8\ud9cf\uded3\udb1d\udff5\ud805\udfbb",
        21, 94740, 641673846, -8040288306396965374L, -87860L, true, true, (char) 50879, (char) 19444,
        Double.longBitsToDouble(0x3fca83e57f4f7d64L), Double.longBitsToDouble(0x3fbc68cd4d78b978L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:[com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer; base-type:null; id-resolver: null]\012",
        Z.run(T, 1, 7, 1, 6, "\u471a\ud82e\udea6\udb37\udc75", "\u60a0\u977c\u5c10\u4eb1\u4e6d\ub629\u167f\ucde8\u6546\u9be2\ud580\ub994", "\udae1\udfe8\ud9cf\uded3\udaff\udf9c\uda2b\udd63",
        22, 57421, 641673846, -8040288306396965374L, -87860L, true, false, (char) 50879, (char) 19444,
        Double.longBitsToDouble(0x3fd351f2b82dfe74L), Double.longBitsToDouble(0x3fbc68cd4d78b978L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer|_deserializeTypedUsingDefaultImpl|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.util.TokenBuffer|new:com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer,com.fasterxml.jackson.databind.BeanProperty",
    "M|com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer|_deserializeTypedForId|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.util.TokenBuffer|new:com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer,com.fasterxml.jackson.databind.BeanProperty",
    "M|com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer|deserializeTypedFromAny|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer,com.fasterxml.jackson.databind.BeanProperty",
    "M|com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer|deserializeTypedFromObject|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer,com.fasterxml.jackson.databind.BeanProperty",
    "M|com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer|forProperty|com.fasterxml.jackson.databind.BeanProperty|new:com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer,com.fasterxml.jackson.databind.BeanProperty",
    "M|com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer|getTypeInclusion||new:com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer,com.fasterxml.jackson.databind.BeanProperty",
    "C|com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer|<init>|com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer,com.fasterxml.jackson.databind.BeanProperty",
    "C|com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer|<init>|com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.jsontype.TypeIdResolver,java.lang.String,boolean,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.annotation.JsonTypeInfo$As",
    "C|com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer|<init>|com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.jsontype.TypeIdResolver,java.lang.String,boolean,com.fasterxml.jackson.databind.JavaType",
    "M|com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer|_deserializeTypedUsingDefaultImpl|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.util.TokenBuffer|new:com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer:com.fasterxml.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer,com.fasterxml.jackson.databind.BeanProperty",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
