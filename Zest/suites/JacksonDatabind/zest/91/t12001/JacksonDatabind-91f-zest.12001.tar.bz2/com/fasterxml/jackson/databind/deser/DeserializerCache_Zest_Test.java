package com.fasterxml.jackson.databind.deser;
import org.junit.Test;
import static org.junit.Assert.*;
public class DeserializerCache_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 8, 4, 15, "\ud868\uddcf\uda9e\ude11\uda97\ude62\ud966\udd09\ud970\udccd\ud912\udcc8\ud89f\udd28\udb8f\udf63\udbff\udf28\udbc9\uddab\ud995\udfdc\udbd9\udebc\ud89a\uddcb\ud9d3\udda5\ud90d\udccd\ud900\udd7b\udbdd\udd39\uda23\udcce\udb42\udd73\uda46\udc0e\udbe7\udf0a\ud950\udc21\ud9ba\uddf8\uda6c\udc11\uda97\udea2\ud873\ude21\ud8d3\ude54\ud8bf\udcf2\udab5\ude2a\ud8c2\udea4\ud9eb\udf13\ud9be\udc14\ud987\udca9\ud9ff\udc82\ud806\udc20", "\u9c7f\u6553", "\ud975\ude8e\ud9f9\udfcd\udb11\udfc2\udb89\udc8e\ud97a\ude04\ud86e\udc1c\ud81b\udd24\ud9c0\ude14\ud96d\udf06\ud839\ude22\udbc7\udf3f\ud899\udcf9\uda0b\udfa0\udb4e\udf8f\ud9aa\udc64",
        45, 24893, 1039772126, 9181907454766104746L, -73118L, true, true, (char) 4066, (char) 3343,
        Double.longBitsToDouble(0x3fedd6c6e6b7dc82L), Double.longBitsToDouble(0x3fe14de1f7cbbe49L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 8, 4, 15, "\ud868\uddcf\uda9e\ude11\uda97\ude62\ud966\udd09\ud970\udccd\ud912\udcc8\ud89f\udd28\udb8f\udf63\udbff\udf28\udbc9\uddab\ud995\udfdc\udbd9\udebc\ud89a\uddcb\ud9d3\udda5\ud90d\udccd\ud900\udd7b\udbdd\udd39\udaf5\udf16\udb42\udd73\uda46\udc0e\udbe7\udf0a\udbd2\udce1\ud82b\udf63\uda6c\udc11\uda97\udea2\uda0d\udf8e\ud9e2\ude68\ud8bf\udcf2\udab5\ude2a\ud8c2\udea4\ud9eb\udf13\ud9be\udc14\ud8b6\udf79\udaf5\uddee\uda84\ude50", "\u9c7f\u9b1f", "\udb11\udefb\ud9f9\udfeb\udb11\udfc2\udb89\udc8e\ud97a\ude04\ud86e\udc1c\ud81b\udd24\ud9c0\ude14\ud981\udf06\ud839\ude22\udbc7\udf83\ud899\udcf9\uda0b\udfa0\udb4e\udf8f\ud9aa\udc64",
        45, 24893, 1039772126, 9181907454766104746L, -73118L, true, true, (char) 4066, (char) 3343,
        Double.longBitsToDouble(0x3fedd6c6e6b7dc82L), Double.longBitsToDouble(0x3fe14de1f7cbbe49L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 8, 4, 15, "\ud868\uddcf\uda9e\ude11\uda97\ude62\ud966\udd09\ud970\udccd\ud912\udcc8\uda27\udc8d\udb8f\udf7d\udbff\udf28\udbc9\uddab\ud995\udfdc\uda70\udf12\ud8ea\udd8c\udbad\uddea\ud8ab\udc87\udb98\udd2f\ud82e\udc7c\uda0f\ude53\udb42\udd73\uda46\udc0e\udbe7\udf0a\ud950\udc21\ud9ba\uddf8\uda6c\udc11\uda97\udea2\ud873\ude21\ud8d3\ude54\ud8bf\udcf2\udab5\ude2a\ud8c2\udea4\ud9eb\udf13\ud9be\udc14\ud987\udca9\ud9ff\udc82\ud806\udc20", "\u9c7f\u6553", "\ud975\ude8e\ud9f9\udfcd\udb11\udfc2\udb89\udc8e\ud97a\ude04\ud86e\udc1c\ud81b\udd24\ud9c0\ude14\ud950\udf1e\ud839\ude22\udbc7\udf3f\ud899\udcf9\uda0b\udfa0\udb4e\udf8f\ud9aa\udc64\ud9f4\udc99\udb7a\udde4\udbf9\udd84\ud81e\udfe8\udb21\udddc\uda5a\udfe9\ud945\udcb6\udb40\udce2",
        55, 52405, -595402822, -4882272846123274711L, -31155L, true, false, (char) 36890, (char) 27348,
        Double.longBitsToDouble(0x3fc022dfb951732cL), Double.longBitsToDouble(0x3fc5922f8d1ab194L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 0, "\ud84e\udd11\ud81f\udef2\ud923\udc9a\ud966\udd09\ud970\udccd\ud8a7\udd32\ud89f\udd28\udb8f\udf63\udbff\udf28\ud8d1\uddaf\ud995\udfdc\ud888\udd02\ud89a\uddcb\udba5\udf1d\ud90d\uddb1\ud800\udd7b\udbdd\udd39\uda23\udcce\udb42\udd73\uda46\udc0e\udbe7\udf0a\ud950\udc21\ud9ba\uddf8\uda6c\udc11\uda97\udea2\ud873\ude21\ud8d3\ude54\ud8bf\udcf2\udab1\udf2a\ud8c2\udea4\ud9eb\udf13\ud9be\udc14\ud987\udca9\uda0b\udc88\udb31\udc34", "\u9c7f\uc01d", "\ud975\ude8e\ud9f9\udfcd\udb11\udfc2\udb89\udc8e\ud97a\ude04\ud86e\udc1c\udae1\udf9f\ud9c0\ude14\ud96d\udf06\ud839\ude22\udbc0\ude3f\uda22\udf04\uda0b\udfa0\udb4e\udf8f\ud9aa\udc64",
        45, 24893, 1039772126, 9181907454766104746L, -73118L, true, true, (char) 4066, (char) 3343,
        Double.longBitsToDouble(0x3fedd6c6e2b7dc82L), Double.longBitsToDouble(0x3fa4de6b08db7580L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 15, "\ud868\uddcf\uda9e\ude11\u00eb\ud966\udcdc\ud970\udccd\ud912\udcc8\ud89f\udd28\udb8f\udf63\udbff\udf28\udbc9\uddab\ud995\udfdc\udbd9\udebc\ud89a\uddcb\ud9d3\udda5\ud90d\udccd\ud900\udd7b\udbe9\udc94\uda23\udcce\udb42\udd73\ud800\udc0b\ud271\ud950\udc21\ud9ba\uddf8\uda6c\udc11\u5de2\ud873\uddb3\ud8d3\ude54\ud8bf\udcf2\000\ud8c2\udea4\ud9eb\udf13\ud9be\udc14\ud987\udca9\ud9ff\udc82\ud806\udc20", "\u9c7f\u6553", "\ud975\ude8e\ud9f9\udfcd\udb11\udfc2\udb89\udc8e\ud97a\ude04\ud86e\udc1c\ud81b\udd24\000\000\ud839\ude22\udbc7\udf3f\ud899\udcf9\uda0b\udfa0\udb4e\udf8f\ud9aa\udc64",
        45, 24893, 1039772126, 9181907454766104746L, -73118L, true, true, (char) 4066, (char) 3343,
        Double.longBitsToDouble(0x3fedd6c6e6b7dc82L), Double.longBitsToDouble(0x3fe14de1f7cbbe49L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 4, 15, "\ud868\uddcf\uda9e\ude11\uda97\ude62\ud966\udd09\ud970\udccd\uda9a\udccc\ud89f\udd28\udb8f\udf63\ud8fc\udd66\udba4\udd1a\ud995\udfdc\udbd9\udebc\ud89a\uddcb\ud9d3\udda5\ud90d\udccd\ud900\udd7b\udbdd\udd39\uda23\udcce\udb42\udd73\uda46\udc0e\udbe7\udf0a\udb93\udfa4\uda23\udfbf\ud811\ude36\uda97\udea2\ud873\ude21\ud8d3\ude54\ud8bf\udcf2\udab5\ude2a\ud90f\udeca\ud8a2\udf05\ud9be\udc14\ud987\udca9\ud9ff\udc82\ud806\udc20", "\u9c7f\u6553", "\ud975\ude8e\ud9f9\udfcd\udb11\udfc2\ud8b6\uddd4\udb83\udc6d\ud88b\udf50\ud81b\udd24\ud9c0\ude14\ud96d\udf06\ud839\ude22\udbc7\udf3f\ud899\udcf9\uda0b\udfa0\udb4e\udf8f\ud9aa\udc64",
        45, 24893, 1039772126, 9181907454766104746L, 57954L, true, true, (char) 501, (char) 6415,
        Double.longBitsToDouble(0x3fdac40e5e04c818L), Double.longBitsToDouble(0x3fe14de1f7cbbe49L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 15, "\ud868\uddcf\uda9e\uddec\udba6\udf2a\uda4e\udded\ud909\udecf\ud92c\uddfe\ud89f\udd28\udb8f\udf63\udbff\udf28\udbc9\uddab\udb81\ude86\uda47\ude08\ud89a\udddc\ud9d3\udda5\ud90d\udccd\ud900\udd7b\ud821\udd7a\ud8e2\udfbf\udb42\udd73\u3265\ud870\uddfa\ud89c\udd38\ue384\udbba\udeda\uda97\udea2\ud878\udd16\ud8d3\ude54\ud8bf\udcf2\udab5\ude2a\ud8c2\udea4\ud9eb\udf13\ud9be\udc14\ud987\udca9\ud9ff\udc82\udbf1\udf07", "\u34d5\u5a09", "\udb12\udd37\uda1d\udc67\u7fb0\udb89\udc8e\ud97a\ude04\ud9b2\udc1e\ud81b\udd24\ud9c0\ude14\u4cba\ud82c\udcbe\udbc7\udf3f\ud899\udcf9\udb1f\udf49\ud98f\udeaf\udad4\udc14",
        54, 9420, 391676701, 9180201888893124778L, -73314L, true, false, (char) 4066, (char) 3343,
        Double.longBitsToDouble(0x3fedd6c6e2b7dc82L), Double.longBitsToDouble(0x3fe120370c65416dL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 15, "\ud868\uddcf\uda9e\ude11\uda97\ude62\ud966\udd09\ud970\udccd\ud912\udcc8\ud89f\udd28\udb8f\udf63\udbff\udf28\udbc9\uddab\ud995\udfdc\udbd9\udebc\ud89a\uddcb\ud9d3\udda5\ud90d\udccd\ud900\udd7b\udbdd\udd39\uda23\udcce\ud9bf\udf51\uda46\udc0e\udbe7\udf0a\ud950\udc21\ud9ba\uddf8\uda6c\udc11\uda97\udea2\ud873\ude21\ud8d3\ude54\ud8bf\udcf2\udab5\ude2a\ud8c2\udea4\ud9eb\udf13\ud9be\udc14\ud987\udca9\ud9ff\udc82\ud806\udc20", "\u9c7f\u6553", "\ud975\ude8e\ud9f9\udfcd\udb11\udfc2\udb89\udc8e\ud97a\ude04\ud86e\udc1c\ud81b\udd24\ud9c0\ude14\ud96d\udf06\ud839\ude22\udbc7\udf3f\ud899\udcf9\uda0b\udfa0\udb4e\udf8f\ud9aa\udc64",
        45, 24893, 1039772126, 9181907455566807978L, -73118L, true, true, (char) 4066, (char) 3343,
        Double.longBitsToDouble(0x3fedd6c6e6b7dc82L), Double.longBitsToDouble(0x3fe14de1f7cbbe49L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.deser.DeserializerCache:@?\012",
        Z.run(T, 1, 15, 5, 15, "\ud87d\udf7b\uda9e\ude11\uda97\ude62\ud966\udd09\ud970\udccd\ud915\udfaf\udb17\udd05\udb88\udf96\ud9b7\udf24\udbc9\uddab\ud995\udfdc\udbd9\udebc\ud8b1\udd36\ud904\udd17\ud90d\udcd0\ud900\udd7b\udbcc\uddb0\ud976\udce3\udacc\udd73\ud8f1\udf38\u841c\ud950\udc21\udbd4\udcc6\ud8f3\udc40\ud82c\udfea\ud873\ude21\ud8d3\ude54\ud9ff\udcf2\udab5\ude2a\ud8c2\udea4\ud9eb\udf13\ud9be\udc14\ud987\udca9\ud8ea\uddb0\ud806\udc20", "\u9c7f\u6553", "\ud975\ude8e\ud9f9\udfcd\udb11\udfc2\udb89\udc8e\uda4b\udcac\ud86e\udc1c",
        44, 91092, 915413971, 1853640439550371234L, -93135L, false, false, (char) 31547, (char) 60706,
        Double.longBitsToDouble(0x3fcda7f1077841b8L), Double.longBitsToDouble(0x3fa79efc8aa7f6c0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.databind.deser.DeserializerCache:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 5, 15, "\ud8e6\udfee\ud967\uddf5\uda97\ude62\uda29\udd69\ud9e1\ude26\uda1a\udff9\ud858\udc1d\udb8f\udf63\udbff\udf28\udbc9\uddab\udbe6\udc80\ud980\udecf\ud89a\uddcb\ud833\udf17\ud90d\udccd\ud900\udd7b\udbdd\udd39\uda23\udcce\udb42\udd73\uda46\udc0e\udbe7\udf0a\uda96\ude44\ud9d4\ude82\ud8fa\udcee\udaa7\ude91\ud82c\uddc9\ud8d3\ude54\ud8bf\udcf2\udab5\ude2a\ud8c2\udea4\ud9bf\udf8a\ud9be\udc14\ud98f\udeb8\udb56\ude60\ud805\udf6f", "\u9c7f\u6553", "\ud975\ude8e\ud802\udf31\udb26\udf21\udb89\udc8e\ud97a\ude04\u99bb\ud81b\udd24\ud9c0\ude14\ud96d\udf06\ud839\ude22\uda59\udf1d\u9610\uda0b\udfa0\udb4e\udf8f\udad8\udd45",
        18, 69869, -1477766021, 5306960506880016920L, -73118L, true, true, (char) 4066, (char) 17100,
        Double.longBitsToDouble(0x3fedd6c6e51fdc82L), Double.longBitsToDouble(0x3fe14ff8a7cbbe49L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 4, 15, "\ud868\uddcf\ud89a\udc5f\ud9ca\ude9f\ud966\udd09\ud970\udccd\ud912\udcc8\ud89f\udd28\udbab\udf71\udbff\udf28\udbc9\uddab\ud995\udfdc\ud8eb\uddd2\ud85b\uddce\ud9e0\udc33\ud90d\udccd\ud900\udd7b\udbdd\udd39\uda23\udcce\udb42\udd73\uda46\udc0e\udbe7\udf0a\udae9\udc5e\udaf7\uded2\udb01\udde9\u41c9\ud8ec\udd27\ud8ee\udce6\ud8bf\udcf2\udab5\ude2a\ud8c2\udea4\ud90a\udf80\ud9be\udc3b\ud987\udca9\ud9ff\udc82\ud806\udc20", "\u9c7f\u6553", "\ud975\ude8e\ud9f9\udfcd\udb11\udfc2\udb89\udc8e\udacd\udc5d\udad6\udce5\ud81b\udd24\ud9c0\ude14\ud96d\udf06\ud839\ude22\udbc7\udf3f\ud899\udcf9\uda0b\udfa0\udb4e\udf8f\ud9aa\udc64",
        45, 24893, 1039772126, 9181907454766104746L, -73118L, true, true, (char) 4066, (char) 3343,
        Double.longBitsToDouble(0x3fedd6c6e6b7dc82L), Double.longBitsToDouble(0x3fe13860f7cbbed0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.deser.DeserializerCache:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 15, 8, 15, "\ud868\uddcf\uda9e\ude11\uda97\ude62\ud966\udd09\ud970\udccd\ud912\udcc8\uda27\udc8d\udb8f\udf7d\udbff\udf28\udad0\udc0d\ud996\udc4c\uda70\udf12\ud8ea\udd8c\udbad\uddea\ud8ab\udc87\udb98\udd2f\ud82e\udd2d\ud9d0\udc12\udb42\udd18\uda46\udc0e\udbe7\udf0a\ud950\udc21\ud9bf\ude1e\ud8c3\udd23\uda97\udeac\ud873\ude21\ud8d3\ude54\ud8bf\udcf2\udab5\ude2a\ud8c2\udea4\ud9eb\udf13\ud9be\udc14\ud987\udca9\ud9ff\udc82\ud806\udc20", "\u6201\ub7a6", "\ud975\ude8e\ud9f9\udfcd\udb11\udfc2\ud821\udd9c\udaaa\udff5\ud86e\udc1c\ud81b\udd24\ud9c0\ude14\ud950\udf1e\ud839\ude22\ud988\udf91\ud899\udcf9\uda0b\udfa0\udb44\udc67\ud9aa\udc64\ud9f4\udc99\udb7a\udde4\udbf9\udd84\ud81e\udfe8\udb21\udddc\uda5a\udfe9\udbab\udf51\uda04\ude3a",
        36, 52405, -595402822, -4882272846123274711L, 93299L, true, false, (char) 36890, (char) 27348,
        Double.longBitsToDouble(0x3fc022dfb951732cL), Double.longBitsToDouble(0x3fc5922f8d1ab194L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.deser.DeserializerCache:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 1, 0, "\ud84e\udd11\ud81f\udef2\ud923\udc9a\ud966\udd09\udaa7\udce9\ud8a7\udd99\ud89f\udd28\udb8f\udf63\udbff\udf28\ud855\uddb1\ud995\udfdc\ud888\udd02\ud89a\uddcb\udba5\udf1d\ud90d\uddb1\ud800\udd7b\ud9a3\ude98\uda23\udcb3\udbd2\udda0\uda46\udc0e\udbe7\udf0a\ud950\udc21\ud9ba\uddf8\uda6c\udc11\uda97\udea2\ud873\ude21\ud8d3\ude54\ud8bf\udcf2\udae1\udfba\ud8c2\udea4\ud8a4\udc10\ud925\udc1f\ud80c\udeb9\ud9ee\udcd4\udb31\udc34", "\u9c7f\uc01d", "\ud975\ude8e\ud9f9\udfcd\udb11\udfc2\udb75\udf44\udadf\udd4e\ud89f\udd49\udae1\udf9f\ud9c0\ude14\ud96d\udf06\ud839\ude22\udbc0\ude3f\uda22\udf04\uda0b\udfa0\udb4e\udf8f\ud9aa\udc64",
        45, 24893, 1039785182, 9181907454766104746L, -73118L, true, true, (char) 4066, (char) 3343,
        Double.longBitsToDouble(0x3fedd6c6e2b7dc82L), Double.longBitsToDouble(0x3fa4de6b08db7580L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.databind.deser.DeserializerCache:@?\0121=void |this=com.fasterxml.jackson.databind.deser.DeserializerCache:@?\012",
        Z.run(T, 2, 9, 15, 13, "\ud8e6\udfee\ud967\uddf5\uda97\ude62\uda29\udd69\ud9e1\ude26\uda1a\udff9\ud858\udc1d\uda5a\ude29\udbff\udfa0\udbc9\uddab\udbe6\udc80\ud980\udecf\udbee\uded6\ud833\udf17\ud90d\udccd\ud900\udd7b\udbdd\udd39\uda23\udcce\udb42\udd73\uda35\udc0e\udbe7\udf0a\uda96\ude44\ud9d4\ude82\ud8fa\udcee\udaa7\ude91\ud82c\uddc9\ud8d3\ude54\ud8bf\udcf2\ud930\udd28\ud992\udcb2\ud91a\uded7\udb5f\udef5\ud8da\udd49\udb56\ude60\ud9d6\udef6", "\u2b4c\u5ecd\u7f45", "\ud802\udf31",
        23, 39956, -1935650607, -8921911208414416555L, -92877L, false, false, (char) 52055, (char) 36232,
        Double.longBitsToDouble(0x3fd6e20590a93b12L), Double.longBitsToDouble(0x3fe751b6f98be424L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.databind.deser.DeserializerCache:@?\0121=java.lang.Integer:0 |this=com.fasterxml.jackson.databind.deser.DeserializerCache:@?\012",
        Z.run(T, 2, 9, 9, 15, "\udb55\udfe4\ud96c\ude42\uda97\ude62\uda29\udd69\ud9ba\udf92\uda1a\udfa1\ud99c\udec0\ud990\udfda\udbe6\ude69\udbc9\uddab\udbe6\udc80\ud980\udecf\ud89a\uddcb\ud833\udf17\udbc9\uddeb\udb5d\udd7a\ud975\udf79\uda23\udcce\udb42\udd73\ud9a3\udc1d\udbe7\udf2b\uda96\ude44\ud9d4\udeec\ud8fa\udcee\udaa7\ude91\ud82c\uddc9\ud8e5\udd53\ud8bf\udcf2\udab5\ude2a\ud8c2\udea4\ud9bf\udf8a\ud9be\udc14\ud98f\udeb8\ud9d4\udf7f\ud810\udf40", "\u9c7f\u6553\u7ed0\uaea5\u2e42\uc988\u7baa\u91c9\u1813\u6e47\u0d0b\ua9e4\ucb4d\u631b\u81e5\u127f\u30bb\u015d", "\uda94\udd11",
        4, 89031, -1449377256, 5742533112903723266L, 39334L, true, false, (char) 57746, (char) 1557,
        Double.longBitsToDouble(0x3fb10ffd9611a1b0L), Double.longBitsToDouble(0x3fe0ba783d02eeb4L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.fasterxml.jackson.databind.deser.DeserializerCache:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 2, 15, "\ud8e6\udfee\ud967\uddf5\uda97\ude62\uda29\udd69\ud9e1\ude26\uda1a\udff9\ud95e\udf00\ud958\udeff\u2748\udbc9\uddab\udbe6\udc80\ud980\udecf\ud89a\uddcb\ud833\udf17\ud90d\udccd\ud900\udd7b\udbdd\udd39\uda23\udcce\udb42\udd73\uda46\udc0e\udbe7\udf0a\uda96\ude44\ud9d4\ude82\ud8fa\udcee\udaa7\ude91\ud82c\uddc9\ud8d3\ude54\ud8bf\udcf2\udab5\ude2a\ud8c2\udea4\ud9bf\udf8a\ud9be\udc14\ud98f\udeb8\udb56\ude60\ud805\udf6f", "\u9c7f\u6553", "\ud975\ude8e\ud802\udf31\udb26\udf21\udb89\udc8e\ud97a\ude04\ud94d\udcad\ud81b\udd24\ud9c0\ude14\ud96d\udf06\ud839\ude22\uda59\udf1d\u9610\uda0b\udfa0\udb4e\udf8f\udad8\udd45",
        18, 69869, -1477766021, 5306960506880016920L, -38558L, true, true, (char) 4066, (char) 17100,
        Double.longBitsToDouble(0x3fedd6c6e51fdc82L), Double.longBitsToDouble(0x3fe14ff8a7cbbe49L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.deser.DeserializerCache:@?\0121=void |this=com.fasterxml.jackson.databind.deser.DeserializerCache:@?\012",
        Z.run(T, 2, 15, 15, 1, "\ud868\uddcf\uda9e\ude11\uda97\ude62\ud966\udd09\ud8c6\uddf2\ud912\udcc8\uda27\udc8d\udb8f\udf7d\udbff\udf28\udad0\udc0d\ud996\udc4c\uda70\udf12\ud970\udd8f\udbad\uddea\ud8ab\udc87\udb98\udd2f\ud82e\udd2d\ud9d0\udc12\udb42\udd18\uda46\udc0e\ud9de\udd44\ud950\udc21\ud9d7\udf1e\ud8c3\udd23\ua6b6\ud873\ude21\ud8d3\ude54\ud8bf\udcf2\udab5\ude2a\ud88b\ude69\ud9c4\udd13\ud9c2\udd45\ud987\udca9\ud970\ude10\ud842\udde4", "\u325d\u832e", "\ud975\ude8e\ud8e6\udcfc\udad9\ude2d\ud962\udc1b\uda4c\udd1e\ud887\udd1c\ud81b\udd24\ud9c0\ude14\udadc\udca4\ud839\ude02",
        50, 25838, -1651925650, 4079704136840761066L, 41549L, false, true, (char) 60820, (char) 60337,
        Double.longBitsToDouble(0x3feb358fcc024fa5L), Double.longBitsToDouble(0x3fdde3834f84f0d0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 8, 4, 15, "\ud868\uddcf\uda9e\ude11\uda97\ude62\ud966\udd09\ud970\udccd\ud912\udcc8\ud89f\udd28\udb8f\udf63\udbff\udf28\udbc9\uddab\ud995\udfdc\udbd9\udebc\ud89a\uddcb\ud9d3\udda5\ud90d\udccd\ud98b\udc7d\udbf3\udf39\uda23\udcce\udb42\udd73\uda46\udc0e\udbe7\udf0a\ud950\udc21\ud9ba\uddf8\uda6c\udc11\uca2b\ud92f\uddbb\ud8d3\udf0d\ud8bf\udcf2\udab5\ude2a\ud8c2\udea4\ud9eb\udf13\ud9be\udc14\ud987\udca9\ud9ff\udc82\ud806\udc20", "\u9c7f\u6553", "\ud975\ude8e\ud9f9\udfcd\ud848\udede\udb89\udc8e\ud97a\ude04\ud86e\udc1c\ud81b\udd24\ud9c0\ude14\ud96d\udf06\ud839\ude22\udbc7\udf3f\udaa2\ude6b\uda0b\udfa0\udb4e\udf8f\ud9aa\udc64",
        45, 24893, 1039772126, 9181907454766104746L, -73118L, true, true, (char) 4066, (char) 3343,
        Double.longBitsToDouble(0x3fedd6c046b7dc82L), Double.longBitsToDouble(0x3fe14de1f7cbbe49L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|_hasCustomHandlers|com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|_createAndCache2|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.deser.DeserializerFactory,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|_createAndCacheValueDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.deser.DeserializerFactory,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|_createDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.deser.DeserializerFactory,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|_createDeserializer2|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.deser.DeserializerFactory,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|_findCachedDeserializer|com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|_handleUnknownKeyDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|_handleUnknownValueDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|_verifyAsClass|java.lang.Object,java.lang.String,java.lang.Class|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|cachedDeserializersCount||new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|findConverter|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|findConvertingDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|findDeserializerFromAnnotation|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|findKeyDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.deser.DeserializerFactory,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|findValueDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.deser.DeserializerFactory,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|flushCachedDeserializers||new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
    "M|com.fasterxml.jackson.databind.deser.DeserializerCache|_hasCustomHandlers|com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.DeserializerCache:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
