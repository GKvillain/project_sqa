package com.fasterxml.jackson.databind.jsontype.impl;
import org.junit.Test;
import static org.junit.Assert.*;
public class ClassNameIdResolver_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:int |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 1, 5, 0, 0, "\udac7\udc38\udbc1\ude6a\udb88\uddab\ud8c3\udd21\ud834\udf08", "\u7490\ua03e", "\u8904",
        44, 18509, 376746841, -3802699508270178008L, -36589L, true, true, (char) 16389, (char) 42882,
        Double.longBitsToDouble(0x3fc11986414aca80L), Double.longBitsToDouble(0x3fcd82669ddaa63cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 0, 0, "\udac7\udc38\udbc1\ude6a\udb88\uddab\ud8c3\udd21\udb1c\udf5f", "\u7490\u9ee1\u480b", "\ud964\udd54\ud97b\ude45\udaf5\udca5\udb4d\uddd5\ud837\udf27\uda2d\udf14\ud9c7\ude17",
        49, 71697, -869113038, -4494547863202605526L, -38346L, false, true, (char) 1723, (char) 29267,
        Double.longBitsToDouble(0x3fe2a883e33a8129L), Double.longBitsToDouble(0x3fe9eafa2732ead2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:java.util.ArrayList |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 1, 5, 0, 0, "\000\000\udb88\udd32", "\u4a13\000\000\ua03e\ud785\u5e5b\uccfb\u00e2\u8784\u55f6\ud265\000\u5753\u8f5e\u8717\000\000\000\u66c2\000", "\ud8f5\ude5b\udbed\udc37\ud93e\udc77\ud814\udd10\ud808\udc2a\udae6\udc23\udad9\udc14\ud98a\udc4e\udbaf\ude48\ud89d\ude5e\uda1e\udd46\ud876\udc04\uda9c\udd2e\ud8a6\ude7e\ud825\udcf4\ud8ee\udfc9\udb49\ude53\udadb\uddce\ud9ee\udf5c\ud974\udd3b\uda69\udfeb\uda2d\ude5f",
        23, 92796, -1956735086, -6168177274889035702L, 7130L, false, true, (char) 24074, (char) 26965,
        Double.longBitsToDouble(0x3fd70ea52d64b0a4L), Double.longBitsToDouble(0x3fd8021d665d9e9eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 0, "\udac7\udc38\udad2\uded2\ud82a\udd4a\ud8c3\udd21\ud834\udf08", "\u7d07\ua03e", "\ud817\ude11",
        32, 66778, -1519231049, -3802699508270178008L, -36589L, true, true, (char) 16389, (char) 42882,
        Double.longBitsToDouble(0x3fd6ccc323137714L), Double.longBitsToDouble(0x3fe2ccd31f87298fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 1, 6, 0, 0, "\udac7\udc38\udbc1\ude6a\udb88\uddab\ud8c3\udd21\ud834\udf08", "\u7490\ua03e", "\u8904",
        38, 51877, 1526464243, -6712887524617821912L, -36589L, true, true, (char) 16389, (char) 42882,
        Double.longBitsToDouble(0x3fc1198640aaca80L), Double.longBitsToDouble(0x3fcd82669ddaa63cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:java.lang.String |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 1, 4, 7, 3, "\ud8b1\ude0e\udbc1\ude6b\ud85d\udd83\ud8c3\udd21\ud834\udf08\udacd\udfe4\ud800\udd05\udbdd\udc63\ud8c1\udd0f\udaf9\udddf\u2fe4\ud81a\uddb4\ud977\udd88\ud935\udceb\udb00\ude14", "\u57ad\u50e8\u5e98\ud25e\u251b\u844f\u1bd3\uc76d\u165e\ua76e\u7bad\u71e7\ub3f1\u831a\u50cc\u5a01", "\ud96b\udff0",
        36, 84354, 935352660, -324430354491140337L, 24945L, false, false, (char) 13867, (char) 34830,
        Double.longBitsToDouble(0x3fbfe9d54bcf08f0L), Double.longBitsToDouble(0x3fead159198931afL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:class name used as type id |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 1, 2, 0, 0, "\udac7\udc38\udbc1\ude6a\udb88\uddab\ud8c3\udd21\ud834\udf08\udbfc\udcf2\ud937\udf06\udb60\udfa5\ud895\udddb\ud908\udf60\udba2\udc10\u8904", "\u55f6\ud265\u00dd\u57ad\u5925\u5816\u4f08\u35cc\u84d3\u2715\u8a79\u8236\uba53\u9a84\uabde\u1509\ua3c3\uaa5a\u7a95\u6ae3\u6427", "\uda1c\udd35\uda9d\ude23\ud9ff\udcd5\ud9e5\udfae\udb24\udf93\udbf7\udd5c\ud8cd\udc5a\udb1b\ude62\udb5c\uddee",
        18, 8875, 1507863509, -882792813013375674L, -52407L, false, false, (char) 42076, (char) 31386,
        Double.longBitsToDouble(0x3fcb15d302ec8918L), Double.longBitsToDouble(0x3fc8a24135ecc118L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:[I |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 1, 1, 1, 1, "\ud8cb\udc3a\uda13\udc34\udb88\uddab\ud8c3\udd21\ud834\udf08", "\u9fd2\u1f1c", "\u8904",
        5, 18625, 376746841, -3802699508270178008L, -50157L, true, true, (char) 16389, (char) 42882,
        Double.longBitsToDouble(0x3fc11986414aca80L), Double.longBitsToDouble(0x3fcd82669d26a63cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:java.lang.Thread$State |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 1, 5, 0, 0, "\udbf2\udcb6\udad9\udf95\udb47\uddf6\uda9c\udfc0\ud834\udf08", "\u7490\ua03e", "\u8904\ud964\udd54\ud97b\ude45\udb13\udd21\udb4d\uddd5",
        11, 40130, -457640013, -2741700451088964079L, -8189L, false, true, (char) 17467, (char) 40842,
        Double.longBitsToDouble(0x3fe8554672f3906eL), Double.longBitsToDouble(0x3fc307288dbf17a0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 1, 8, 0, 8, "\udac7\udc38\udbc1\ude6a\ud988\udcab\ud947\udfd1\ud834\udf08\udbfc\udcf2\ud937\udf06\udb60\udfa5\ud895\udddb\ud908\udf60\udba2\udc10\u8904\ud964\udd54\ud9c9\udf29\udb13\udd23\udb4d\uddd5\ud837\udf27\ud933\udcbf\ud9c7\ude17\udbe4\udfb8\uda68\ude17\ud9be\udc24\udaaa\udff8\udaea\udd73\udbc8\udfd3\uda0a\udff8\ud97e\ude92\udae7\udf77\uda3f\udf86\ud8f5\udd3b\ud81f\udf95\udb09\ude6d\uda05\uddba\ud816\udcb4\udb3c\udd15\ud984\udf57\ud8b3\udd15\udbe2\uddb7\udb3d\udc89\udbda\ude44\udaa5\udc40", "\ube16\u39de\u6d7a\ucf5a\u97c8\u1b5c\ucc51\u9364\ua79d\ubc75\u29bd\u57b6\u36a2\ud757\uacce\ub108\ubc49\u7e71\uad82\u4176\u1282\ub0d1\u6ae2", "\ud862\udd0d\udb32\udd3b\ud967\ude22\udb8d\udce0",
        56, 36872, -100594351, -8989525932341123771L, 91030L, true, true, (char) 45182, (char) 9479,
        Double.longBitsToDouble(0x3fe4f5e41f723210L), Double.longBitsToDouble(0x3fd088d87c071faeL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 0, "\uda48\uddda\udadd\ude2e\uda78\udf8b\ud9c3\ude08\ud89a\udd49", "\u7490\ua03e", "\u8904",
        44, 18509, 376746841, -3802699508270178008L, -36589L, true, true, (char) 16389, (char) 65238,
        Double.longBitsToDouble(0x3fd2ecbad0e17cdaL), Double.longBitsToDouble(0x3fca80ecaa6f9324L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:java.lang.Comparable |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 0, "\udac7\udc38\udbc1\ude6a\udb7d\udd40\ud911\udc3d\udb8b\udd3d\u7a2d\ud937\udf06\ud949\udf3a\ud957\udc90", "\uccfb", "\ud9f6\udc28\uda88\ude3f\ud845\uded7\uda2d\udf14\udb1a\udf21\udbe4\udfb8\uda68\ude17\uda17\udd70\udaab\udc0e\udaea\udd73\udbc8\udfd3\uda46\udcb6\ud880\udd31\uda11\udd85\ud92c\ude43\udae3\udf36\udaf1\udfc8\ud84b\udc10\ud932\ude23\ud9c3\udead\ud823\udde4\uca5a",
        36, 27232, -1228859159, 6106177685550693091L, -70344L, false, true, (char) 35972, (char) 38372,
        Double.longBitsToDouble(0x3fc19fcd45a408d4L), Double.longBitsToDouble(0x3fdd40c6c2a56d40L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.annotation.JsonTypeInfo$Id:CLASS |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\0121=java.lang.String:java.util.List |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 2, 3, 5, 5, "\udab9\udd8e\udbc1\ude6a\ucec3", "\u7b04\ub48d\u7490\ua03eG\u47fd\u389c\ucfc8", "\udb58\udc45\ud837\udf27\uda95\uddc8\ud9c7\ude17\ud88e\udead\uda38\udf7a",
        32, 43413, 322230442, -7780275205777127377L, 86781L, true, true, (char) 6778, (char) 64294,
        Double.longBitsToDouble(0x3feb3a66a8a29bf5L), Double.longBitsToDouble(0x3fdb3c184aa65a68L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:class name used as type id |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 0, "\udac7\udc38\uda41\ude11\udb8c\udc19\u2d90\udaa3\udf05", "\u7490\ua03e", "\uda4b\udd3d",
        44, 28293, 376746841, -3802699508265571800L, -36589L, true, true, (char) 16389, (char) 42882,
        Double.longBitsToDouble(0x3fe056619226802cL), Double.longBitsToDouble(0x3fcd845c7ddaa63cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:int |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 1, 1, 0, 5, "\udac7\udc38\udbc1\ude6a\udb76\uddab\ud85a\udc9d\ud844\udf22", "\ub65a\u2e52", "\ud811\udfcd",
        44, 73901, 376641776, -3802699508270178008L, 98520L, false, false, (char) 64543, (char) 47365,
        Double.longBitsToDouble(0x3fb429dec1bf99f8L), Double.longBitsToDouble(0x3fad40f16cad5f70L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 1, 8, 4, 1, "\udbeb\udebf\uda8f\udee5\ud9e7\ude9c\ud8f5\udcac\uda49\udc09", "\u7165\u081d*\u5e5b\uccfb\ub817\u5702\u8a2e\u3201\uc67e\u1385\u61a8\u211f\ub301", "\ud958\udc06\udbc8\udfd3\udbd0\uddee\ud860\uddb2\ud947\udfb0\ud9d9\udc3f\udb4e\udf6b\ud9b8\udc02\ud80f\udcd2\uda35\udcc9\ud933\udef2\ud973\udd39\ud93f\udc92",
        2, 19610, 1504932961, 2242632016943257195L, -43607L, false, false, (char) 27805, (char) 41463,
        Double.longBitsToDouble(0x3fdbb34892853fdeL), Double.longBitsToDouble(0x3faeb55be7c04010L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.annotation.JsonTypeInfo$Id:CLASS |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 6, "\udbc7\ude0a\ud920\udf7e\ud8b2\udd08\udbfc\udf70\ud834\udf08\udbfc\udcf2\ud937\udf06\udb60\udfa5\ud895\udddb\ud908\udf60\udba2\udc10\ud9c7\ude15\ud964\udcb0\ud97b\ude45\udb13\udcab\udb4d\uddd5\ud95e\ude5a\uda19\ude6f\ud9c7\ude17\udbe4\udfb8\uda68\ude17\ud9be\udc24\udaaa\udff8\udac7\udc73\udbc8\udfd3\uda7a\ude91\ud8aa\udea8\u305a\ucf4c\udb8b\ude4e", "\u33aa\u136a\ub53d\uaa41\ub14f\u315b\u2e82\u1286\u7b86\u7e9d\u524a\u6c14\ub66d\u2e0b\u614d", "\ud97a\udfd0\udb07\udf55\ud81f\ude3e\udbce\udf4b\ud996\udf66\ud8c8\udcc5\uda58\udd98",
        28, 74669, -1396535553, 165692524929264200L, 18407L, true, false, (char) 24606, (char) 48401,
        Double.longBitsToDouble(0x3fa0343b614e76d0L), Double.longBitsToDouble(0x3fdd31d81ddc2a4aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\ud9b3\uddd4\ud874\udfa7\u41cf\ud8eb\udc5e\ud819\ude6a", "\ucd5f\u639d", "\u8904",
        19, 8604, -2068137008, -3802518771751395032L, 71763L, true, true, (char) 33206, (char) 42997,
        Double.longBitsToDouble(0x3fe755e616161617L), Double.longBitsToDouble(0x3fcaa2668316a63cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String:java.lang.Number |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\0121=java.lang.String:java.lang.Number |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 2, 5, 5, 5, "\ud945\udd71\udacd\udc00\udb4e\udc74\ud916\udc91\udba4\udfa7\udbf3\udcb5\udbb0\udd6d\ud91e\uddda", "\u960f", "\u100a\udb92\udf6c\udab5\udd48\ud828\udd2d\uda2d\udf14\ud907\udf17",
        7, 44167, -1450237231, -5575411881155979182L, -58724L, true, false, (char) 22856, (char) 964,
        Double.longBitsToDouble(0x3fb6678b1dcbf5c8L), Double.longBitsToDouble(0x3fed1ddd7183e77aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:class name used as type id |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\0121=com.fasterxml.jackson.annotation.JsonTypeInfo$Id:CLASS |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 2, 2, 3, 6, "\udac7\udc38\udb61\udc1a\ud82e\udf29\ud96f\udc08\ud834\udf19", "\u3555\u10ff\u4737\ub4df\u9d18\u6b25\u01a6\u6a6d\u7045\u5aa3\u92c5\u8f5e\u70de\u4f08\ub2e0\u283a\ub4b8\ud4d8\u2476\uaeca\u3d09", "\udaf9\udf56\udab4\uddff\udb46\udd10\udb1e\udef5\ud9d8\udefd\ud8e9\ude37\udb78\udc29\udb87\udcd0\udab3\udcda\uda5c\uddae\udadb\udc69",
        48, 52972, 1970247306, 8184101506882815296L, -76911L, false, true, (char) 10665, (char) 64907,
        Double.longBitsToDouble(0x3f8910789b4a0300L), Double.longBitsToDouble(0x3fd8e3cb6a00f94aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:java.lang.Integer |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\0121=java.lang.String:java.lang.Integer |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud8cb\udc3a\uda13\udc34\udb88\uddab\ud8c3\udd21\ud834\udf08", "\u7e4a\uaad3", "\udb38\udd48\udb93\udd61\ud97b\udeb9\udb13\udcab\udb4d\uddd5\ud837\udf27\uda2d\udf14\udadd\udea0\udbe4\udfb8\uda68\ude17\ud9be\udc24\udaaa\udff8\udaea\udd73\udbc8\udfd3",
        57, 89166, -1310484086, 4421171885957986455L, -97412L, false, false, (char) 11474, (char) 61350,
        Double.longBitsToDouble(0x3fe5c5a41938e9c0L), Double.longBitsToDouble(0x3fcc454ed4083ad4L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:java.util.ArrayList |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\0121=java.lang.String:java.util.ArrayList |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud8ca\udf77\uda13\udc34\udb88\uddab\ud8c3\udd21\ud834\udf08\udbfc\udcf2\ud937\udf06\ud87a\uddd2\ud8ab\udcb8\ud92a\udd60\udba2\udc10\u8904\ud960\udf33\ud968\udd6f\udb13\udc53\udb38\udfcb", "\u0202\u7075\u4f08\u3661\u850d\u2715\u8a79", "\uda07\udd51",
        37, 28803, 1116440405, -7023723650291714321L, 46660L, false, false, (char) 62332, (char) 15843,
        Double.longBitsToDouble(0x3fd54336b20e9e80L), Double.longBitsToDouble(0x3fd02b815dbfcbe0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:java.lang.String |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\0121=java.lang.String:java.lang.String |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 2, 4, 4, 5, "\ud8cb\udc3a", "\u35d2\u78ce\u4a13\ub4ae\u72d2\u1a59\ub146\u5f43\ubffb\u6e9b\u5776\ua38c\u74f0\u00dd\u57ad\uc9ed\u2064", "\udaaa\udff8",
        -5, 37724, 1884763936, -5270905819280901957L, -64200L, false, true, (char) 25195, (char) 48739,
        Double.longBitsToDouble(0x3fdae51c87bcbeb6L), Double.longBitsToDouble(0x3febcb70678a1037L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:java.lang.Thread$State |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\0121=java.lang.String:java.lang.Thread$State |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud8cb\udc3a\uda13\udc34\udb88\uddab\ud8c3\udd21\ud834\udf08", "\u9fd2\u1f1c", "\u8904",
        25, 18625, 376746841, -3802699508270178008L, -50157L, true, true, (char) 16389, (char) 42882,
        Double.longBitsToDouble(0x3fc11986414aca80L), Double.longBitsToDouble(0x3fcd82669d26a63cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\0121=void |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 2, 6, 6, 1, "\ud8cb\udc3a\uda13\udc34\udb88\uddab\ud920\udedc\ud894\udfd1", "\u9fd2\u1f1c", "\u8904",
        5, 18625, 376746841, -3802699508270178008L, -50157L, true, true, (char) 51586, (char) 42889,
        Double.longBitsToDouble(0x3fc11986414aca80L), Double.longBitsToDouble(0x3fcd82669d26a63cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\0121=new com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 2, 8, 8, 6, "\udb39\udf8e\udaf0\ude2e\ud9b2\ude03\ud9e7\udd3d\udba5\udecd", "\u7284\ud759", "\u8904",
        44, 18509, 376746841, -3802699508270178008L, -36589L, true, true, (char) 48027, (char) 65160,
        Double.longBitsToDouble(0x3fd2ecbadad8ee4cL), Double.longBitsToDouble(0x3fca80fa0a6f9324L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:class name used as type id |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\0121=java.lang.String:class name used as type id |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\012",
        Z.run(T, 2, 2, 2, 0, "\udac7\udc38\uda3f\udeac\uda0c\uddca\u2d90\udaa3\udf05", "\u7421\ua03e", "\uda4b\udd3d",
        -3, 28182, -546008743, -3802699508265571800L, 42888L, true, true, (char) 16120, (char) 42882,
        Double.longBitsToDouble(0x3fe056619226802cL), Double.longBitsToDouble(0x3fcd845c7ddaa63cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String:int |this=com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 0, "\udb4e\ude0a\udbc1\udea4\udb88\uddab\ud8c3\udd21\ud834\udf08", "\u9417\u196f", "\u8904",
        44, 18509, 376746841, -3802699508270178008L, -36589L, true, true, (char) 16389, (char) 42882,
        Double.longBitsToDouble(0x3fc11986414aca80L), Double.longBitsToDouble(0x3fef6099a776b8aaL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver|_typeFromId|java.lang.String,com.fasterxml.jackson.databind.DatabindContext|new:com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.type.TypeFactory",
    "M|com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver|_idFrom|java.lang.Object,java.lang.Class,com.fasterxml.jackson.databind.type.TypeFactory|new:com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.type.TypeFactory",
    "M|com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver|getDescForKnownTypeIds||new:com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.type.TypeFactory",
    "M|com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver|getMechanism||new:com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.type.TypeFactory",
    "M|com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver|idFromValue|java.lang.Object|new:com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.type.TypeFactory",
    "M|com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver|idFromValueAndType|java.lang.Object,java.lang.Class|new:com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.type.TypeFactory",
    "M|com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver|registerSubtype|java.lang.Class,java.lang.String|new:com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.type.TypeFactory",
    "M|com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver|typeFromId|com.fasterxml.jackson.databind.DatabindContext,java.lang.String|new:com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.type.TypeFactory",
    "C|com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver|<init>|com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.type.TypeFactory",
    "M|com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver|_typeFromId|java.lang.String,com.fasterxml.jackson.databind.DatabindContext|new:com.fasterxml.jackson.databind.jsontype.impl.ClassNameIdResolver:com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.type.TypeFactory",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
