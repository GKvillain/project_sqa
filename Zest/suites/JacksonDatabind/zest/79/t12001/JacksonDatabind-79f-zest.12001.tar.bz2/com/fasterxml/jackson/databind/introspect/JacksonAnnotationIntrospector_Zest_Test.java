package com.fasterxml.jackson.databind.introspect;
import org.junit.Test;
import static org.junit.Assert.*;
public class JacksonAnnotationIntrospector_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 17, 9, "\uda22\udd68", "\u442c\u6a82\u75cb", "\ud8a7\udc44\uac6b\uda0b\udf63\udbd6\udf03",
        28, 46129, 1088869564, 784303229811204302L, -41810L, false, true, (char) 2856, (char) 43826,
        Double.longBitsToDouble(0x3faec158dcbfbe00L), Double.longBitsToDouble(0x3fd100a7354e779eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 17, 9, "\ud8b0\udd6f\ud985\udf32\udb06\udd62\udac5\ude2d\udb4b\udc8f", "\uc5da\u738b\uc652\ubad7\u9433\u6692\u59fa\u01a8\u6488\u5934\u8529", "\uda76\udc17\udb19\udcac\ud84a\udfbb\udaa4\udde3\ud920\udc96\ud80b\udd1c\uda1b\ude48\ue3ac\ud9f0\udeea\udb31\udfd6\ud8a0\udfd9\ud8a7\udcee",
        -4, 11223, -846470978, 6471656522074172972L, -89482L, false, true, (char) 26305, (char) 58990,
        Double.longBitsToDouble(0x3feaab2114453c9dL), Double.longBitsToDouble(0x3fef3d06d8495d63L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.introspect.ObjectIdInfo:ObjectIdInfo: propName=, scope=java.lang.Object, generatorType=null, alwaysAsId=false\012",
        Z.run(T, 2, 5, 17, 10, "\uda22\udd68\ud985\udf32", "\u6af3\ucdc3\u2dd4\uc5da\u690f\u1019\u2e25\u3c15\u6bf2", "\ud8a4\udc46\ud94d\ude03\ud95e\uddbc\udb26\udca4",
        26, 60292, -2102320683, -7285117492870777360L, -66553L, false, true, (char) 55521, (char) 23455,
        Double.longBitsToDouble(0x3fee533f7ce85c48L), Double.longBitsToDouble(0x3fbf078ded8ed688L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 17, 9, "\uda22\udd68\ud985\udf32\udb06\udd62", "\u75cb\u2dd4\uc5da", "\ud931\ude58\udbd6\udf03\udad8\ude92\udb21\ude1c\ud85e\udc8f\u717f",
        0, 83664, -757537970, 5698253781014002708L, 59215L, true, true, (char) 14121, (char) 4134,
        Double.longBitsToDouble(0x3fef934b796f1c55L), Double.longBitsToDouble(0x3fe542508f8b853cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.introspect.ObjectIdInfo:ObjectIdInfo: propName=, scope=java.lang.Object, generatorType=null, alwaysAsId=false\012",
        Z.run(T, 2, 9, 17, 9, "\uda22\udd68", "\u442c\u6a82\u75cb", "\ud8a7\udc44\uac6b\uda0b\udf63\udbd6\udf03",
        28, 46129, 1088869564, 784303229811204302L, 13684L, true, true, (char) 37614, (char) 61867,
        Double.longBitsToDouble(0x3fd100a7354e779eL), Double.longBitsToDouble(0x3fd700a401a3b810L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\u442c\u6a82}\uda22\udd68 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 13, 17, 9, "\uda22\udd68", "\u442c\u6a82", "\udb52\udfc6\ud8a7\udc44\uac6b\uda0b\udf63\udbd6\udf03\udad8\ude92\ud927\udd53\ud85e\udc8f\ud86b\udf6a\ud953\udf1c\ud89e\udde0",
        40, 92096, -1990345708, -9029398579258585027L, 93232L, true, true, (char) 56747, (char) 22505,
        Double.longBitsToDouble(0x3fd2c5e470b87680L), Double.longBitsToDouble(0x3fe90af9f9d0bc7aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 11, 16, "\udb2c\udd6d\ud985\udf32\uda6e\udc00\udac5\ude2d\udb4b\udc8f\udbd3\udfbe\ud97b\ude85", "\u1019\u2e25\u9433\u0df9\u3924\u685c\u45fb\u7c8b\u8529\u0dca\u4f6f\ud049\uc550\u34d5", "\uda59\udeae\ud8d1\udd71\udb33\udc5c\ud88e\udfd5\udb96\udffb\ud826\udecc\ud92c\ude9e\udbf0\udde1\ud933\udee9\udb45\ude0c\udb63\uddd5\udb43\uddaa\ud86c\udc66",
        21, 654, -1490947185, 1155562779867199556L, -64176L, false, true, (char) 52563, (char) 36897,
        Double.longBitsToDouble(0x3fc6a4963d7b6a84L), Double.longBitsToDouble(0x3fe9140fb2a97dccL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 12, 1, "\udbb4\udc4a", "\u442c\uc65c\uc328", "\ud8b7\udc2c\ud953\udd9a\uda0b\udf63\udbd6\udf03",
        17, 46129, 1088869564, 784303229240778958L, -26917L, false, true, (char) 34068, (char) 37857,
        Double.longBitsToDouble(0x3fae9f55dcbfbe00L), Double.longBitsToDouble(0x3fc655592a9d0b58L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 17, 9, "\uda22\udd68", "\u442c\u6a82\u75cb", "\ud8a7\udc44\uac6b\uda0b\udf63\udbd6\udf03",
        28, 46129, 1088869564, -953523275260627118L, -41810L, false, true, (char) 45608, (char) 43826,
        Double.longBitsToDouble(0x3faec158dcbfbe00L), Double.longBitsToDouble(0x3fd100a7354e779eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 17, 9, "\uda22\udd68", "\u442c", "\ud97b\ude85",
        10, 31684, -1613559274, -2638703061965402118L, 17087L, false, false, (char) 43144, (char) 43951,
        Double.longBitsToDouble(0x3fc3ba22cd389658L), Double.longBitsToDouble(0x3fed0696c4144f14L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.introspect.ObjectIdInfo:ObjectIdInfo: propName=, scope=java.lang.Object, generatorType=null, alwaysAsId=false\0121=com.fasterxml.jackson.databind.introspect.ObjectIdInfo:ObjectIdInfo: propName=, scope=java.lang.Object, generatorType=null, alwaysAsId=false\012",
        Z.run(T, 2, 17, 17, 9, "\uda22\udd68", "\u87b0\u6a82\u75cb", "\ud8a7\udc44\uac6b\udb39\udcda\udb9a\udecb\ud9b6\ude65\ud9c2\udd5f\ud85e\udc8f",
        0, 89549, -1437902668, -5819239382499782146L, -13573L, false, true, (char) 61816, (char) 63106,
        Double.longBitsToDouble(0x3fe55dbe8ec3d03aL), Double.longBitsToDouble(0x3f96c46a13df8e00L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.List |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 1, 3, 3, 14, "\udac0\udec8", "\u442c\u3629", "\udb41\udf21\ud890\udea9\ud8e1\ude31\udbfe\udff2\ud927\ude81\udad8\ude92\ud927\udda0\ud85e\udc8f\ud8a4\udc46\udb80\udf1d\ud867\udd2b\udaf4\udea4\ue949\ud948\udea0\ud9dc\udc2c\udb07\udffe\udab9\ude7c\uc838\udb89\udf3b\udbc8\ude72\uda38\udd85\ud84a\udf27\ud933\udf24\ud8e3\udce8\ud955\ude6c\udb23\udc46\ud811\udf8b\ud92d\udeeb\ua94d\ud9cd\udd6a\ud807\udc17\uda5d\uddf5\ud90d\udca3",
        18, 36272, 816551534, 4896302270998671577L, 87306L, false, true, (char) 49705, (char) 17275,
        Double.longBitsToDouble(0x3fd6996495b1ef2aL), Double.longBitsToDouble(0x3fe6868de7f017daL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Class:[I |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:\uda22\udd68\uda2b\udc3b\udab7\udc92\ud8ae\udf2e\ud878\udcaa\ud9a0\udf0b\ud81c\udeee\udb02\udeec\ud94f\uddfe\ud9a6\udcc7\udb5e\udd9f\ud9c4\uddf7\uda9f\udf15\udb90\ude64 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 4, 13, 17, "\uda22\udd68\uda2b\udc3b\udab7\udc92\ud8ae\udf2e\ud878\udcaa\ud9a0\udf0b\ud81c\udeee\udb02\udeec\ud94f\uddfe\ud9a6\udcc7\udb5e\udd9f\ud9c4\uddf7\uda9f\udf15\udb90\ude64", "\ua3a8\u1430\u0dca", "\ud86f\udec6\ud91c\ude77\ud92f\udc49\udb8b\udc0d\udbc7\udd9f\ud94c\udd42\ud9e0\udec3\ud821\udc37\ud85a\udd83\udb6c\udc6e\ud915\udfba\udb12\udf84\ud9a9\udf72\ud882\ude78",
        5, 41673, -1253775600, 191901894843276773L, -20591L, true, false, (char) 25673, (char) 12053,
        Double.longBitsToDouble(0x3fc6a4a7ec94a6c4L), Double.longBitsToDouble(0x3fea987095596c2dL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 3, 5, "\uda22\udd68", "\u442c\u6a82\u6dca", "\ud8a7\udc66\uac6b\uda0b\udf63\udbd6\udf03\udad8\ude92\ud927\udda0\ud8a9\udc44\uf1d8\ud8c9\udc14",
        -2, 62173, 1326728096, -8548469111519330603L, -97387L, false, true, (char) 48757, (char) 52248,
        Double.longBitsToDouble(0x3fe42dedf0f7704bL), Double.longBitsToDouble(0x3fd584c38c1cd186L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 17, 9, "\uda22\udd68", "\u442c\u6a82\u75cb", "\ud8a7\udc44\uac6b\uda0b\udf63\udbd6\udf03",
        28, 46129, 1088869564, 784303229811204302L, -41810L, false, true, (char) 2856, (char) 43826,
        Double.longBitsToDouble(0x3faec158dcbfbe00L), Double.longBitsToDouble(0x3fd100a735194d9eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 9, 9, 9, "\uda22\udd68", "\u442c\u6a82\u75cb", "\ud8a7\udc44\uac6b\uda0b\udf63\udbd6\udf03",
        28, 46129, 1088869480, 784303228922011854L, -68831L, false, true, (char) 2856, (char) 43826,
        Double.longBitsToDouble(0x3faec158dcbfbe00L), Double.longBitsToDouble(0x3fd100a7354e779eL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 5, "\uda22\udd68", "\u442c\u6a82\u75cb", "\udafd\udc5c\uac6b\uda0b\udf63\uda0d\udf7e",
        28, 46129, 1088869564, 7845947446448882031L, -41868L, false, true, (char) 2856, (char) 43826,
        Double.longBitsToDouble(0x3faec15881a1ce00L), Double.longBitsToDouble(0x3f900a8754e771c0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 15, 15, "\udb7e\udef7\ud985\udf32\udb06\udd62\ud908\udf77\udb4b\udc36\ud931\udc6e\ud933\uddb2\udb65\udf08", "\u2c2e\u9433", "\udb53\udde3\ud98c\udd83\ud8b4\ude54\ud80e\uded4\udb26\udca4\ud940\udc5c\ud974\udc15\udbf9\udda6\uda4c\udf28\udab9\ude68\ud920\udc96",
        33, 63849, 399036596, 3605764567122797564L, -90362L, true, true, (char) 1932, (char) 3960,
        Double.longBitsToDouble(0x3fe495423db6a27aL), Double.longBitsToDouble(0x3fdf450dd167acaeL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.introspect.ObjectIdInfo:ObjectIdInfo: propName=, scope=java.lang.Object, generatorType=null, alwaysAsId=false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 7, 6, "\uda22\udd68\ud8cb\udd95\ud8b7\udce2\udac3\udefc\udaf2\udc26\u7ab1\ud94e\uddb2\udb52\udfc6\ud8a7\udc44\uac6b\uda0b\udf63\udbd6\ude18", "\u2e1c\u31cf\u5934\ud56a\u7d36\u8959\ucf78\u378a\ube40\u3ec0\uabc4", "\ud933\udd83\udb44\uddf3\ud815\udd76\udabd\udf1e\ud8aa\udd89\ud9c5\udcfe\ue72c\ud972\udcad\uda56\udd84\uda39\udfd1\udb87\udd40\ud889\udee1\ud949\udc18\ud95e\udf92\ud8e0\ude0e\udb39\udf74\udb3d\udefb\udbcb\udd83\uda82\ude39\udbbc\udfe2\udbc9\ude8e\uda6d\udf26\ud854\uddf1\udb4e\uddca\ud9e8\ude17\uda68\udd33\udbfa\udc95\uda67\ude91\udbb1\udfda\u3328\udad1\udf2d",
        32, 48448, -877570730, 3750413658744074884L, 33095L, true, false, (char) 3587, (char) 14385,
        Double.longBitsToDouble(0x3fd540e23c54cbc0L), Double.longBitsToDouble(0x3fe163dd32c8e58aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 17, 9, "\uda22\udd68", "\u442c", "\uef65",
        34, -1000, 13828096, 0L, 88393L, false, false, (char) 43144, (char) 43951,
        Double.longBitsToDouble(0x3f4a22cd38940000L), Double.longBitsToDouble(0x3fc41a5b00000000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 17, 9, "\uda22\udd68", "\u442c", "\uda2d\udf2a\ud8fe\udd5c\ud8a9\udf99",
        6, 11068, 2136313338, 767680460972023785L, 57602L, true, true, (char) 18868, (char) 2276,
        Double.longBitsToDouble(0x3fed0696c4144f14L), Double.longBitsToDouble(0x3fdd5895d07b0562L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 6, 6, 8, "\uda22\udd68", "\ua6a7\u6a82\u7f95", "\ud8a7\udc44\uac6b\uda0b\udf63\udbd6\udf03",
        28, 50073, 1088869564, 3585654111998484686L, -41810L, true, true, (char) 18571, (char) 18015,
        Double.longBitsToDouble(0x3faec158dcbfbe00L), Double.longBitsToDouble(0x3fdb8367354e779eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.introspect.ObjectIdInfo:ObjectIdInfo: propName=, scope=java.lang.Object, generatorType=null, alwaysAsId=false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 0, 4, "\uda22\udd68", "\u442c\u1782\u75cb", "\ud8a7\udc44",
        6, 11068, -1412366086, 767681156756725737L, 57602L, false, false, (char) 18868, (char) 2276,
        Double.longBitsToDouble(0x3fed0696c4144f14L), Double.longBitsToDouble(0x3fdd5895d07b0562L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\u442c\u2b90\u75cb}\uda22\udd68 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.introspect.ObjectIdInfo:ObjectIdInfo: propName=, scope=java.lang.Object, generatorType=null, alwaysAsId=false\012",
        Z.run(T, 2, 13, 17, 9, "\uda22\udd68", "\u442c\u2b90\u75cb", "\ud8a7\udc44\uac6b\uda0b\udf63\udbd6\udf03",
        31, 46129, 1088869564, 784303229811204302L, -41810L, false, true, (char) 2856, (char) 43826,
        Double.longBitsToDouble(0x3faec158dcbfbe00L), Double.longBitsToDouble(0x3fd100a7354e779eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.introspect.ObjectIdInfo:ObjectIdInfo: propName=, scope=java.lang.Object, generatorType=null, alwaysAsId=false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 10, 8, "\udb46\udc3a", "\u442c\u7b5e", "\uda65\udcdb\udb62\udc4a\uac89\uda0b\udf63\uda0d\udf17\udaef\udea0",
        56, 90986, 171209355, -3380337663043012451L, 47937L, false, false, (char) 29435, (char) 20386,
        Double.longBitsToDouble(0x3fe539de7cead75bL), Double.longBitsToDouble(0x3fe6d21a91c67b03L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.String |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=java.lang.Class:java.lang.String |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 4, 4, 15, "\uda22\udd68", "\u4463\u6a82\u75cb", "\ud8a7\udc44\uac6b\uda0b\udf63\udbd6\udf03",
        28, 79329, 1088869379, 784303230690339103L, -41810L, false, true, (char) 2856, (char) 43826,
        Double.longBitsToDouble(0x3faec158dcbfbe00L), Double.longBitsToDouble(0x3fd100a7354e779eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\u442c\u6a82\u75cb}\uda22\udd68 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 2, 1, "\uda22\udd68", "\u442c\u6a82\u75cb", "\ud8a7\udc44\uac6b\uda0b\udf63\udbd6\udf03",
        28, 46129, 1088869564, 784303229811204302L, -41810L, false, false, (char) 59838, (char) 4884,
        Double.longBitsToDouble(0x3faed77edcbfbe00L), Double.longBitsToDouble(0x3fd100a7354e779eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\000 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 11, 0, "\000", "", "",
        31, 11117, 30932992, -3674937039849846250L, 92518L, false, true, (char) 60047, (char) 250,
        Double.longBitsToDouble(0x3e19c00000000000L), Double.longBitsToDouble(0x3fc3ba22cd389658L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.introspect.ObjectIdInfo:ObjectIdInfo: propName=, scope=java.lang.Object, generatorType=null, alwaysAsId=false\0121=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 1, 3, 16, "\uda22\udd68", "\u203a\u652c\u75cb", "\udba2\udeb0\uac6b\uda0b\udf63\udb65\uddaa",
        4, 61296, 1088847424, 784303229811204302L, 13684L, true, false, (char) 37588, (char) 61665,
        Double.longBitsToDouble(0x3fd100a7354e779eL), Double.longBitsToDouble(0x3fe357bf39a10522L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.introspect.ObjectIdInfo:ObjectIdInfo: propName=, scope=java.lang.Object, generatorType=null, alwaysAsId=false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 14, 8, "\uda22\udd68", "\u442c\u6a82\u75cb", "\ud8a7\udc44\uac6b\uda0b\udf63\udbd6\udf03",
        15, 46074, 1088869564, 5540104438891185112L, -66839L, true, false, (char) 474, (char) 43826,
        Double.longBitsToDouble(0x3fe4e99f95ea9683L), Double.longBitsToDouble(0x3fd100a7340db1aaL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName: |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.introspect.ObjectIdInfo:ObjectIdInfo: propName=, scope=java.lang.Object, generatorType=null, alwaysAsId=false\012",
        Z.run(T, 2, 13, 17, 9, "", "", "\udb4b\udc8f",
        5, 58237, 30960555, -3628960961134392810L, -30624L, false, true, (char) 60047, (char) 54459,
        Double.longBitsToDouble(0x3fed1207300000e2L), Double.longBitsToDouble(0x3fc3a0000d389658L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 5, 5, 14, "\uda22\udd68\ud985\udf32", "\u8b3e\ucdc3\u2dd4\uc5da\u690f\uacc9\uc9ac\u3c15\u6bf2", "\ud8a4\udc46\ud94d\ude03\ud95e\uddbc\udb26\udca4",
        32, 38296, 2084242026, 479727233340675978L, -66553L, false, true, (char) 55521, (char) 23455,
        Double.longBitsToDouble(0x3fee533f7ce85c48L), Double.longBitsToDouble(0x3fe4d9b1b8b13076L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:{\ua8ae\uc59d\u8658\uad21\u0f95\u690f\u8e22\u427e\ud6b2\u137e\u2917\u01a8}\uda22\udd68 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 4, 13, 5, "\uda22\udd68", "\ua8ae\uc59d\u8658\uad21\u0f95\u690f\u8e22\u427e\ud6b2\u137e\u2917\u01a8", "\uda6c\udd33\udb26\udce6\ud97d\ude81\udb44\udee8\uda02\ude72\uda73\uddda\udbef\udc0b\ud920\udcd3\ud9e1\udf86\ud923\udcda\udb14\udfb8\u4c2c\ud8bc\udd3a\ud955\udeb8\ud812\ude4b\ud8ce\ude2f\udacf\uddf2\udaba\uddf7",
        6, 24982, 594988990, 7906962944204806383L, 78736L, true, true, (char) 24270, (char) 20738,
        Double.longBitsToDouble(0x3fdaa223faf17b4cL), Double.longBitsToDouble(0x3fd03c5a26c2f204L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.introspect.ObjectIdInfo:ObjectIdInfo: propName=, scope=java.lang.Object, generatorType=null, alwaysAsId=false\012",
        Z.run(T, 1, 17, 17, 10, "\uda22\udd68\ud985\udf32", "\u0247\uce63\u2dd4\uc5da\u690f\u1019\u2e25\u3c15\u6bf2", "\ud820\udc44\ud94d\ude03\ud95e\uddbc\udb26\udca4",
        26, 60292, -2102320683, -7285117492870777360L, -66553L, false, true, (char) 55521, (char) 38735,
        Double.longBitsToDouble(0x3fee533f7ce85c48L), Double.longBitsToDouble(0x3fbf078ded8ed688L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder:@? |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 12, 10, "\uda22\udd68\ud985\udf32", "\u8ab6\uab0e\u9c06\uc5da\u690f\u1019\u2e25\u3c15\u6bf2", "\ud8a4\udc46\ud8bf\udf66\ud95e\udd91",
        40, 92096, -1990345708, -9029398580885581763L, 80540L, true, false, (char) 49672, (char) 55521,
        Double.longBitsToDouble(0x3fe280aa7bcab5efL), Double.longBitsToDouble(0x3fcd0b8909e078dcL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 15, 11, "\uda22\uddf9\ud87f\ude75\ud926\udd37\udb21\ude32\ud918\udc3f\ud85f\udfdf\udbdc\udd2e\udb52\udf97\udbb3\uddaa\uac6b\u8d3e", "\uabd6\u72d6\u6488\u206c\u9ac4\u0dca\u8959\u2184", "\udab9\ude18\ud920\udc96\ud955\udfc5\ud8f3\ude02\udbbc\ude35\u4c84\ud8bc\udd3a\udb83\udeaf\ud806\udd4b\ud9a0\udd78\udafa\udd3c",
        3, 41733, -294122941, 2841186052553138980L, -87957L, true, true, (char) 44658, (char) 61416,
        Double.longBitsToDouble(0x3fc680585a42fdf8L), Double.longBitsToDouble(0x3fe4cc97dfe2488dL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Class:[I |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:\udaf6\udd72\uda2b\udc3b\udab7\udc92\ud8ae\udf2e\ud878\udcaa\ud9a0\udf0b\ud81c\udeee\udb02\udeec\ud94f\uddfe\ud9a6\udcc7\udb5e\udd9f\ud9c4\uddf7\uda9f\udf15\udb90\ude64 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 4, 13, 13, "\udaf6\udd72\uda2b\udc3b\udab7\udc92\ud8ae\udf2e\ud878\udcaa\ud9a0\udf0b\ud81c\udeee\udb02\udeec\ud94f\uddfe\ud9a6\udcc7\udb5e\udd9f\ud9c4\uddf7\uda9f\udf15\udb90\ude64", "\ua3a8\u1430\u0dca", "\ud86f\udec6\ud91c\ude77\ud92f\udc49\udb8b\udc0d\udbc7\udd9f\ud94c\udd42\ud9e0\udec3\ud821\udc37\ud85a\udd83\udb6c\udc6e\ud915\udfba\udb12\udf84\ud9a9\udf72\ud882\ude78",
        5, 41673, -1253775600, 191901894843276773L, -20591L, true, false, (char) 25673, (char) 12053,
        Double.longBitsToDouble(0x3fc6a4a7ec94a6c4L), Double.longBitsToDouble(0x3fea987095596c2dL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\u57a8\u1430\u0dca}\uda22\udd68\udbb0\udcfb\udab7\udc92\ud8ae\udecd\ud878\udcaa\ud9a0\udf0b\ud81c\udeee\udb02\udeec\ud8a4\ude92\udb58\udc7e\ud998\udf47\ud9c4\uddaf\uda9f\udf15\udb90\ude64 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:{\u57a8\u1430\u0dca}\uda22\udd68\udbb0\udcfb\udab7\udc92\ud8ae\udecd\ud878\udcaa\ud9a0\udf0b\ud81c\udeee\udb02\udeec\ud8a4\ude92\udb58\udc7e\ud998\udf47\ud9c4\uddaf\uda9f\udf15\udb90\ude64 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 13, 13, 13, "\uda22\udd68\udbb0\udcfb\udab7\udc92\ud8ae\udecd\ud878\udcaa\ud9a0\udf0b\ud81c\udeee\udb02\udeec\ud8a4\ude92\udb58\udc7e\ud998\udf47\ud9c4\uddaf\uda9f\udf15\udb90\ude64", "\u57a8\u1430\u0dca", "\udb80\udd52\ud9d2\udd02\ud929\udc91\udbbe\udf67\ud9d4\udd65\ud981\ude42\u87e4",
        53, 88802, 490260472, 1095261832483489045L, 16305L, false, true, (char) 61893, (char) 2584,
        Double.longBitsToDouble(0x3fd5f6544bca055cL), Double.longBitsToDouble(0x3fe02d8ede3138b6L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 3, 3, 5, "\uda22\udd68", "\u442c\u6a82\u6dca", "\ud8a7\udc66\uac6b\uda0b\udf30\udbd6\udf03\udad8\ude92\ud9e8\ude0f\udb2e\ude84\uf1d8\ud8c9\udc14",
        -2, 62173, 1326728018, -8548469111519330603L, -97387L, false, true, (char) 48757, (char) 40126,
        Double.longBitsToDouble(0x3fe42dedf0f7704bL), Double.longBitsToDouble(0x3fd584c38c1cd186L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:{\u0dc2\u2b5b\uab8c}\uda22\udd68 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:{\u0dc2\u2b5b\uab8c}\uda22\udd68 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 13, 13, 5, "\uda22\udd68", "\u0dc2\u2b5b\uab8c", "\udacd\udfd8\udb38\udeb1\uda0b\udf63\udbd6\udf03",
        31, 46129, 1088869564, -2458288499492777117L, 13684L, true, true, (char) 37614, (char) 61867,
        Double.longBitsToDouble(0x3fd100a7354e779eL), Double.longBitsToDouble(0x3fd68539f48a92c2L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\uda22\udd68 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:\uda22\udd68 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 13, 13, 9, "\uda22\udd68", "\u442c\ub32d\u75cb", "\ud8a7\udc44\ud8ab\udc64\uda0b\udf63\udbd6\udf03\udb99\udf93\ud927\udda0\ud85e\udc8f\ud8af\udeed",
        -4, 74269, -757537970, 5698253781014002708L, -40242L, true, false, (char) 17783, (char) 10363,
        Double.longBitsToDouble(0x3fe7a11e46b2cd93L), Double.longBitsToDouble(0x3fed0ebb686698ccL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=null |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 4, 4, 13, "\udb46\udc3a", "\u442c\u7b5e", "\udad9\udcd5\udb62\udc4a\uac89\uda0b\udf63\uda0d\udf17\udaef\udea0",
        56, 90986, 171209355, -2227416158671046613L, -90052L, false, false, (char) 37160, (char) 52515,
        Double.longBitsToDouble(0x3fd0a6bf1a21b4f4L), Double.longBitsToDouble(0x3fe539de7cead75bL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName:\000 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:\000 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 13, 13, 3, "\000", "", "",
        31, 11117, 30932992, -3674937039849846250L, 35162L, true, true, (char) 60047, (char) 250,
        Double.longBitsToDouble(0x3e19c00000000000L), Double.longBitsToDouble(0x3fc3ba22cd389658L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.PropertyName: |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName: |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 13, 13, 8, "", "\u0dd7\u282f\u6a82\u75cb\u0f66\u7dff\u738b\u1019\u718c\u9339", "\ud82e\ude20\ud935\udfaf\000\ubad4\udad9\udc7e\ud8ca\udf46\udbaf\udd76\ud99e\udd15\ud9fd\udd7f\ud9ee\udde4\udb81\udf5d",
        52, 9048, 1592575771, 1040636427861842231L, 31983L, false, false, (char) 16176, (char) 22616,
        Double.longBitsToDouble(0x3fee58b29ce77e4eL), Double.longBitsToDouble(0x3f7df4d347331800L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 9, "\uda22\udd68", "\ua87d\uaf5d\u75cb", "\ud86f\udfe2\uac6b\uda0b\udf63\udbd6\udf03\udad8\ude92\ud927\udda0\u4fcb\ud8a4\udc46",
        39, 74269, -757537970, 5698253781014002854L, -27262L, true, false, (char) 49601, (char) 10219,
        Double.longBitsToDouble(0x3fd55eeb89533f30L), Double.longBitsToDouble(0x3feaea51c5097b23L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.Date |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\0121=com.fasterxml.jackson.databind.PropertyName:{\ua3a8\u1430\u7d20}\uda22\udd68\udb8a\ude0b\ud933\udd64\udb71\udc09\ud878\udcaa\ud9a0\udf0b\ud896\udfb3\udb02\udeec\ud94f\uddfe\ud828\udf75\udb28\udda8\ud9c4\uddf7\ud988\udc74\udb92\udfa0 |this=com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:@?\012",
        Z.run(T, 2, 4, 13, 17, "\uda22\udd68\udb8a\ude0b\ud933\udd64\udb71\udc09\ud878\udcaa\ud9a0\udf0b\ud896\udfb3\udb02\udeec\ud94f\uddfe\ud828\udf75\udb28\udda8\ud9c4\uddf7\ud988\udc74\udb92\udfa0", "\ua3a8\u1430\u7d20", "\ud86f\udec6\ud91c\ude77\ud92f\udc49\udb8b\udc0d\udbc7\udd9f\ud9b5\udfe3\ud90a\ude3b\udb41\udf38\ud85a\udd83\ud885\udc03\ud8fd\udfac\udb12\udf84\ud9a2\udf30\udbc5\udde7",
        24, 4199, -1253775361, 191901894843276773L, -20591L, true, false, (char) 6133, (char) 39791,
        Double.longBitsToDouble(0x3feb3005d7bd92c5L), Double.longBitsToDouble(0x3fc235821567acccL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|findObjectReferenceInfo|com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.introspect.ObjectIdInfo|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.ObjectIdInfo|empty||static",
    "M|com.fasterxml.jackson.databind.ser.std.BeanSerializerBase|createContextual|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty|new:com.fasterxml.jackson.databind.ser.BeanSerializer:com.fasterxml.jackson.databind.ser.std.BeanSerializerBase",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_classIfExplicit|java.lang.Class|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_classIfExplicit|java.lang.Class,java.lang.Class|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_constructNoTypeResolverBuilder||new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_constructStdTypeResolverBuilder||new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_constructVirtualProperty|com.fasterxml.jackson.databind.annotation.JsonAppend$Attr,com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedClass,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_constructVirtualProperty|com.fasterxml.jackson.databind.annotation.JsonAppend$Prop,com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedClass|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_findConstructorName|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_findSortAlpha|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_findTypeResolver|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_isIgnorable|com.fasterxml.jackson.databind.introspect.Annotated|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|_propertyName|java.lang.String,java.lang.String|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|findAndAddVirtualProperties|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.util.List|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|findAutoDetectVisibility|com.fasterxml.jackson.databind.introspect.AnnotatedClass,com.fasterxml.jackson.databind.introspect.VisibilityChecker|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector|findObjectReferenceInfo|com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.introspect.ObjectIdInfo|new:com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector:",
    "M|com.fasterxml.jackson.databind.introspect.ObjectIdInfo|empty||static",
    "M|com.fasterxml.jackson.databind.ser.std.BeanSerializerBase|createContextual|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty|new:com.fasterxml.jackson.databind.ser.BeanSerializer:com.fasterxml.jackson.databind.ser.std.BeanSerializerBase",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
