package com.fasterxml.jackson.databind.deser;
import org.junit.Test;
import static org.junit.Assert.*;
public class BeanDeserializerFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 9, 3, "\u4af0\ud8cf\udd24\udae4\udf3e\uda93\udd53", "\u4484\u3087\u8dcf\u543c\u4824\u2f2e", "\ud9bd\udd33\uda9c\udf8f\ud85a\uddcb\udbe2\udea7\u5b72\udbd6\ude68\udbeb\udd16\udb73\udc06\uda1e\udc72\ud907\udf60\ud88a\udce8\ud949\ude8c\udb83\ude7c\udb51\ude04\ud901\udd58\udab4\udd35\udb13\ude7c\ud952\udfec\ud9b0\udf54",
        58, 11735, -1046739976, 505449896004562711L, 19538L, false, false, (char) 39936, (char) 11806,
        Double.longBitsToDouble(0x3fe21031af03f94eL), Double.longBitsToDouble(0x3fe9dc12729f1a56L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 9, 3, "\u4af0\ud8cf\udd24\udae4\udf3e\uda93\udd53", "\u4484\u3087\u8dcf\u543c\u4824\u2f2e", "\ud98d\ude32\uda9c\udf8f\ud85a\uddcb\udbe2\udea7\u5b72\udbd6\ude68\udbeb\udd16\udb73\udc06\uda1e\udc72\ud86f\udf73\udafd\udf43\udb34\udc48\ud8af\udfc9\udb51\ude04\ud901\udd58\udab4\udd35\udb13\ude7c\ud952\udfec\ud9b0\udf54",
        58, 11735, -1046739976, 505449896004562711L, 19538L, false, false, (char) 39936, (char) 11806,
        Double.longBitsToDouble(0x3fe21031af03f94eL), Double.longBitsToDouble(0x3fe9dc12729f1a56L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 9, 13, "\u4af0\ud8cf\udd24\udae4\udf3e\uda93\udd53", "\u4484\u3087\u8dcf\u543c\u1724\u2f2e", "\uda07\udd38\uda9c\udf8f\ud85a\uddcb\udbe2\udea7\u5b72\udbd6\ude68\udbeb\udd16\udb73\udc06\uda1e\udc72\ud907\udf60\ud88a\udce8\u6976\ud9a2\uddcb\udb51\ude04\ud901\udd58\udab4\udd35\udb13\ude7c\ud952\udfec\ud9b0\udf54",
        58, 67535, -1046740185, 2595120122893986457L, 19538L, false, false, (char) 39883, (char) 11806,
        Double.longBitsToDouble(0x3fe21031af03f94eL), Double.longBitsToDouble(0x3fe9dc12729f7a56L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 9, 3, "\u4af0\ud8cf\udd24\udae4\udf3e\uda93\udd53", "\u4484\u3087\u8dcf\u543c\u57e3\u2f2e", "\ud9bd\udd33\uda9c\udf8f\uda55\udd3b\udbe2\ude14\u5b72\udbd6\ude68\udbeb\udd16\udb72\udfa9\uda1e\udc72\ud907\udf60\ud88a\udce8\udac2\udde1\udb83\ude7c\udb51\ude04\ud901\udd58\udab4\udd35\udb13\ude7c\ud952\udfec\ud9b0\udf54",
        58, 11735, -1046739976, 505449896004562711L, 19538L, false, false, (char) 39936, (char) 11806,
        Double.longBitsToDouble(0x3fe21031af03f94eL), Double.longBitsToDouble(0x3fe9dc12729f1a56L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 12, 2, "\uaffd\u688b\ud810\udc02\ud9b7\udcbb", "\u4484\ud49e\u8dcf\u543c\u4824\u2f2e\u5f5e\u7d2e\u8560\uacd3\u48aa", "\udbb8\udea3\udbeb\udd16\udb73\udc06\uda1e\udc72\ud9ff\udf9a",
        59, 17281, 215612859, 7254393097649752490L, -78338L, true, false, (char) 38893, (char) 15454,
        Double.longBitsToDouble(0x3fe3ef854bf8adf0L), Double.longBitsToDouble(0x3f5c19ce2e0e0600L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 14, 11, 0, "\uce69\ud8cf\udd24\udae4\udf3e\ud9db\udcd1", "\u4484\u3087\u252c\uc733\u6369\u20e0", "\uda98\udfac\udbb6\udda8",
        43, 73804, 638347572, -1809122597952466613L, -22828L, false, true, (char) 10516, (char) 37173,
        Double.longBitsToDouble(0x3fdbb07a502c19f0L), Double.longBitsToDouble(0x3fe738c5527d3e75L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 0, 3, "\udba5\udece\ud8c4\udece\udae4\udf3e\uda93\udd53\udafb\udd0e\ud8c3\ude49\u0af6\uda3e\udcc0\ud89d\udd79\ud9dd\udfe2\ud820\udcbc\ud98f\uddec\ud999\udfd3\ud9e1\udfac\ud9bd\udd33\uda9c\udf8f\ud85a\uddcb\udbe2\udea7\u5b72", "\u3ff9\u58d5\u5c6a\uad6d\u6b3c\u5545\u79d8\uc3b0\u9862\u38bf\u77d4\u23b2\ub77d", "\udb42\udc6a\ud8e0\udd61\ud8dc\udcef\u247c\uda02\udf11\udbc0\ude31\uda99\udf32\ud98d\uddce\ud988\udfcd\ud997\udc02\uda80\udff2\udb50\udd96\ud8fb\ude6e\udab9\udf6a\ud806\udd6a\uda9f\uddc2\udae8\ude4d\ud822\udc49\udb7b\udc5c\udae9\ude1c\udaf1\udf41\udbd3\ude6a\udb4f\ude14\ud815\uddf1\ud867\udcc0\ud80a\udc7f\udb4d\udea6\ud8fe\udfb3\ud98b\ude24\ud940\uddc4\uda77\udc83\uda29\udf06\ud837\udf36\ud8cc\udc1a\ud898\udf5a\ud9d2\uddfb\udbe0\udd96\ud9cf\udf16\ud90b\udd1b\ud8e6\udef2\u571c",
        24, 36771, -337731238, -5828595826799475501L, 40553L, true, false, (char) 34675, (char) 4876,
        Double.longBitsToDouble(0x3fe877d3df88d823L), Double.longBitsToDouble(0x3febf1846bc307d3L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 9, 3, "\u4af0\ud8cf\udd24\udae4\udf3e\uda93\udd53", "\u4484\u3e29\u8dcf\u543c\u4824\u2f2e", "\ud9c0\udf27\uda9c\udf8f\ud85a\uddcb\udbe2\udea7\u5b72\udbd6\ude68\udbeb\udd16\udb73\udc06\uda1e\udc72\ud907\udf60\ud88a\udce8\ud949\ude8c\udb83\ude7c\udb51\ude04\ud901\udd58\udab4\udd35\udb13\ude7c\ud952\udfec\ud9b0\udf54",
        58, 11735, -1046739976, 505449896004562711L, 19538L, false, false, (char) 39936, (char) 11806,
        Double.longBitsToDouble(0x3fe21031af03f94eL), Double.longBitsToDouble(0x3fe9dc12729f1a56L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 5, 3, "\u4af0\ud8cf\udd24\udae4\udf3e\uda93\udd53", "\u4484\u3087\u8dcf\u00af\uae30\u2f2e\u5d3c\u7d3a\u8560\uba7c", "\u5b72\udbd6\ude68\udbeb\udd16\udb73\udc06\uda1e\udc72\ud907\udf60\ud88a\udce8\ud949\ude8c\udb83\ude7c",
        54, 14346, 2013606435, 2286795747722116667L, 87988L, true, false, (char) 45544, (char) 31133,
        Double.longBitsToDouble(0x3fe8b8381bf79f1cL), Double.longBitsToDouble(0x3fe792a2a6801a1dL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 14, 3, "\u4af0\ud8cf\udd51\udae4\udf3e\uda93\udd53", "\u4484\u3087\u8dcf\u543c\u4824\u2f2e", "\ud9bd\udd33\uda9c\udf8f\ud85a\uddcb\udbe2\udea7\u5b72\ud809\udfc2\udbe2\uddbc\udb73\udc06\uda1e\udc72\ud907\udf60\ud88a\udce8\ud949\uded6\udb83\ude7c\udb51\ude04\ud901\udd58\udab4\udd35\udb13\ude7c\ud991\udc82\u51b5",
        16, 93969, -1046740125, 6270057419038797569L, 19538L, false, false, (char) 39936, (char) 11806,
        Double.longBitsToDouble(0x3f86964019802240L), Double.longBitsToDouble(0x3fef43e3529f1a56L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addBeanProps|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addInjectables|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addObjectIdReader|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|addReferenceProperties|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|buildBeanDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|buildBuilderBasedDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|buildThrowableDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|checkIllegalTypes|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|constructAnySetter|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.AnnotatedMethod|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|constructBeanDeserializerBuilder|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|constructSettableProperty|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|constructSetterlessProperty|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|createBeanDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|createBuilderBasedDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription,java.lang.Class|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|filterBeanProps|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.deser.BeanDeserializerBuilder,java.util.List,java.util.Set|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.deser.BeanDeserializerFactory|findStdDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.deser.BeanDeserializerFactory:com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
