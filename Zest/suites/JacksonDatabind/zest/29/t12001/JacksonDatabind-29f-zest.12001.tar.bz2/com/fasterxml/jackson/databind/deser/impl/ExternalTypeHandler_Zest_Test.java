package com.fasterxml.jackson.databind.deser.impl;
import org.junit.Test;
import static org.junit.Assert.*;
public class ExternalTypeHandler_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 1, 5, "\uea1c\udae7\udf58\uda25\udca5\udb46\udfeb\udae9\udcc7\ud9ac\udfc7\udb15\udfbb\ud95c\udfd0\ud9a2\uddb5\u27b9", "\ub857\u5e3c\uccc7\u2176\u7df2\u5208\u6b86\u066c", "\ud895\udf1b\udada\udd0f\udb77\udc1b\uda54\udff9\udb3e\udf72\uda20\udfcb\ud904\ude5b\uda07\udd50",
        44, 34849, 1544156062, 4378621190310186020L, -17817L, true, false, (char) 57687, (char) 37084,
        Double.longBitsToDouble(0x3fde3f6a9833555aL), Double.longBitsToDouble(0x3fead6b57ce97ae3L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 1, 5, "\uea1c\udae7\udf58\uda25\udca5\udb46\udfeb\udae9\udcc7\ud9ac\udfc7\udb15\udfbb\ud95c\udfd0\ud9a2\uddb5\u27b9", "\ub857\u5e3c\uccc7\u2176\u7df2\u5208\u6b86\u066c", "\ud895\udf1b\udbb6\udd0d\udb7b\udc12\uda54\udff9\udb3e\udf72\uda20\udfcb\ud8f7\udd3c\uda00\uddeb",
        44, 34849, 1544156062, 4378621190313790500L, -17817L, true, false, (char) 57687, (char) 37084,
        Double.longBitsToDouble(0x3fde3f6a9833555aL), Double.longBitsToDouble(0x3fead6b57ce97ae3L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 7, 6, "\uea1c\udae7\udf58\uda25\udca5\udb46\udfeb\udae9\udcc7\ud9ac\udfc7\udaa1\udc41\uda8a\udde5\uda47\udee0\u27b9", "\ub857\u5e3c\uccc7\u2176\u7df2\u5208\u6b86\u066c", "\ud895\udf1b\udada\udd0f\udb77\udc1b\uda54\udff9\udb3e\udf72\uda20\udfcb\ud904\ude5b\uda07\udd50",
        44, 34849, 597029790, 4378621190310186020L, -17817L, true, false, (char) 57687, (char) 37084,
        Double.longBitsToDouble(0x3fde3f6a9833555aL), Double.longBitsToDouble(0x3fead6b57ce97ae3L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 1, "\uea1c\udae7\udf58\ud836\udfcb\ud966\udf41\uda69\udd26\ud9ac\udfc7\udb15\udfbb\udbef\udf24\ud8f5\udf31\ud97f\udd83", "\u43fa\u5e3c\u87e9\u2b4e\u7df2\u5d8f\u6b86\u066c\uae51\uc788\u3193\u4ab0\u8d13\ub38a\u5292\ub7e6", "\uda79\udd0e\udb49\udf6e\uda18\udd0a\udb2e\udf5c\udb27\udcfd",
        14, 61160, -788903028, -6903227018630307601L, -88761L, false, true, (char) 50042, (char) 24856,
        Double.longBitsToDouble(0x3fd9c2ad222ddfa4L), Double.longBitsToDouble(0x3fdd4fae259da94aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 1, 5, "\uea1c\udae7\udf58\uda25\udca5\udb46\udfeb\udae9\udcc7\ud9ac\udfc7\udb15\udfbb\ud95c\udfd0\ud9a2\uddb5\u27b9", "\ub857\u5e3c\u66d3\u832f\u7df2\u5208\u6b86\u066c", "\ud895\udf1b\udada\udd0f\udb77\udc1b\uda54\udff9\udb3e\udf72\uda20\udfcb\ud904\ude5b\uda07\udd50",
        44, 34849, 1544156062, 4378621190310186020L, -17817L, true, false, (char) 57687, (char) 37084,
        Double.longBitsToDouble(0x3fde3f6a9833555aL), Double.longBitsToDouble(0x3fead6b57ce97ae3L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:@? |a0=[Lcom.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$ExtTypedProperty;:[[null, null, null]] |a2=[Ljava.lang.String;:[[\ud935\udea0\u25c4\ue25b]] |a3=[Lcom.fasterxml.jackson.databind.util.TokenBuffer;:[[null]]\012",
        Z.run(T, 1, 7, 5, 8, "\uea1c\ud80e\ude4b\uda3b\udf12\udb46\udfeb\udae9\udcc7\uda55\udd13\ud838\udc01\ud941\udd96\ud9a2\ude39\u27b9", "\ub857\u5e3c\uccc7\u2176\u7df2\u5208\ub641\u066c", "\ud935\udea0\u25c4\ue25b",
        3, 34309, 1150536714, -4182286030525023106L, 59375L, true, true, (char) 22919, (char) 2279,
        Double.longBitsToDouble(0x3fedb8737ef9eeebL), Double.longBitsToDouble(0x3fe1d4ce5719b23eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 7, 7, "\uea1c\udae7\udf58\uda4c\ude08\ud823\udc19\udaf3\uddfc\ud9e1\udec7\udb15\udfbb\ud81b\uddae\ud9a2\uddce\udadb\udff8", "\u636b\u293c\uccc7\u2967\u56b9\ub403\u6b86\u066c\u02df\u9bd9\u124c\u9882\u1c3a\u1b98\u7c95\u4e14\uc759\u7a98\u305a\u2478\ubdbc\u0ccb\u3d40\u0779\ua4df\u620e\ub58c\u367d\uc422\ud729\u2be3\u8d64\ubc0d\u18b4\u4a92\u7952\u84df\u9cfb", "\uda40\udee2\ud992\udd3f\u7c1d",
        3, 85908, -2050724920, -2966218302371759363L, 89494L, false, false, (char) 38577, (char) 60203,
        Double.longBitsToDouble(0x3fd8ecd5efd1d6e6L), Double.longBitsToDouble(0x3fe0b61ce98c5039L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 1, 5, "\uea1c\udae7\udf58\uda25\udca5\udb46\udfeb\udae9\udcc7\ud9ac\udfc7\udb15\udfbb\ud94b\uded0\ud9a2\uddb5\u27b9", "\ub857\u1a06\u7f68\u1509\u8c6d\u5120\u2ba2\u8300", "\ud895\udf1b\udada\udd0f\udb67\udcf2\uda54\udff9\udb3e\udf72\uda20\udfcb\ud904\ude5b\uda07\udd50",
        44, 34849, 1544156062, 4381717415054003236L, 79752L, true, false, (char) 57687, (char) 37084,
        Double.longBitsToDouble(0x3fde3f6a9833555aL), Double.longBitsToDouble(0x3fead6b57ce97ae3L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|_deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,int,java.lang.String|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|_deserializeAndSet|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object,int,java.lang.String|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|complete|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.deser.impl.PropertyValueBuffer,com.fasterxml.jackson.databind.deser.impl.PropertyBasedCreator|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|complete|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|handlePropertyValue|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.String,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|handleTypePropertyValue|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.String,java.lang.Object|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|start||new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "C|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|<init>|[Lcom.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler$ExtTypedProperty;,java.util.HashMap,[Ljava.lang.String;,[Lcom.fasterxml.jackson.databind.util.TokenBuffer;",
    "C|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|<init>|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|_deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,int,java.lang.String|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
    "M|com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler|_deserializeAndSet|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,java.lang.Object,int,java.lang.String|new:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler:com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
