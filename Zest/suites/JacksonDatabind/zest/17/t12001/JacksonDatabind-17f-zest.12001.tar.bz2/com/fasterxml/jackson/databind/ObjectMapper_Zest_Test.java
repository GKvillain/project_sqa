package com.fasterxml.jackson.databind;
import org.junit.Test;
import static org.junit.Assert.*;
public class ObjectMapper_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 9, "\ud854\udc75\ud80e\udd9f\ud9ff\ude69\ud9c3\udeeb\ud9bc\udd89\ud9a5\udd94\udbd8\udefd\udaf1\udd79\ud850\udd81\ud8b7\ude2b\uda6b\udf0f\ud95b\udc58\udb7a\udfd0\udba8\udf25\uf8bd\ud974\ude4e\uda0b\udf88\ud98c\uded6\uda86\ude58\ud80f\udee9\ud86e\udec0\udaae\ude22\ud8c3\uddfc\ud83d\udf17\udb18\udf29\uda78\udda1\ud873\udfec", "\ud711\u6eca", "\udbc9\udf1e\ud899\udf28\ud92c\udebf\uda94\udd34\ud885\udf71\ud9a9\udc61\ud96b\udca6",
        47, 81786, -1754166920, -6958160604649059949L, -94177L, false, true, (char) 61648, (char) 10545,
        Double.longBitsToDouble(0x3feac21aaffd0f00L), Double.longBitsToDouble(0x3fe768f44d589289L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 9, "\ud854\udc75\ud80e\udd9f\ud9ff\ude69\ud9c3\udeeb\ud9bc\udd89\ud9a5\udd94\udbd8\udefd\udaf1\udd79\ud850\udd81\ud8b7\ude2b\uda6b\udf0f\ud95b\udc58\udb7a\udfd0\udba8\udf25\uf8bd\ud974\ude4e\uda0b\udf88\ud98c\uded6\uda86\ude58\ud80f\udee9\ud86e\udec0\udaae\ude22\ud8c3\uddfc\ud83d\udf17\udb18\udf29\uda78\udda1\ud873\udfec", "\ud711\u6eca", "\udbc9\udf1e\ud899\udf28\ud92c\udebf\uda94\udd34\ud885\udf71\ud9a9\udc61\ud96b\udca6",
        47, 81786, -1754166920, -6958160603672180333L, -94177L, false, true, (char) 61648, (char) 10545,
        Double.longBitsToDouble(0x3feac21aaffd0f00L), Double.longBitsToDouble(0x3fe768f44d589289L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 13, 10, 4, "\ud854\udc75\ud80e\udd9f\ud9ff\ude69\u58b8\ud845\udee8\udbd5\udf4b\ud845\udf11\ud930\udf1c\uda37\udd17\ud8b7\ude2b\uda6b\udf0f\ud95b\udc58\udb7a\udfd0\udba8\udf25\uf8bd\ud97a\udd4e\uda0b\udf88\ud94e\udd37\uda86\ude58\ud8d2\udf49\ud866\udfb0\udaae\ude22\ud8c3\uddfc\ud83d\udf17\u0fdb\udabf\ude01\ud873\udfec", "\ud711\u1c6c", "\udb1f\udc56\ud899\udf28\udbe9\udc7d\uda0c\udde4\ud885\udf71\ud9a9\udc61\ud96b\udca6\ud88f\udf09\udba5\udd21\uda4e\udf4e\ud9a9\udc8a\udbbe\udf6b\ud97f\udeed",
        8, 62995, 396891373, 9203788836543665855L, 6709L, true, true, (char) 42669, (char) 14077,
        Double.longBitsToDouble(0x3fc5e3d13c2a4a24L), Double.longBitsToDouble(0x3fcd56fa0dfd009cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 9, "\ud854\udc75\ud80e\udd9f\udac9\ude68\uda9e\udc97\udbe7\uddc7\udbfc\udf60\ud906\ude41\udaf1\ude31\udaa4\udfeb\udbc7\uddb3\ud868\udfa7\ud95b\udc58\udb7a\udfd0\udba8\udf25\ud9a6\ude32\ud9f5\udea8\uda0b\udf88\ud98c\udf30\uda86\ude58\ud80f\udee9\ud86e\udec0\udaae\ude22\udaa5\udcf8\ud83d\udf17\udbeb\udeb2\uda8c\ude71\ud873\udfec", "\u3055\u6eca", "\ud8f3\udff2\udb44\udc9a\ud92c\udec3\uda81\udc6d\ud96a\ude52\ud9a9\udc61\ud96b\udca6",
        47, 81786, -1754166920, -6958160604604373613L, -94177L, false, true, (char) 61648, (char) 20273,
        Double.longBitsToDouble(0x3fd37fd58f93c47eL), Double.longBitsToDouble(0x3fe768f44e0b3389L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 1, 11, 9, "\ud854\udc75\ud80e\udd9f\ud9ff\ude69\ud9c3\udeeb\ud9bc\udd89\ud9a5\udd94\udbd8\udefd\udaf1\udd79\ud850\udd81\ud8b7\ude2b\uda6b\udf0f\ud929\udd54\udb7a\udfd0\udba8\udf25\uf8bd\ud974\ude4e\uda0b\udf88\ud98c\uded6\uda21\uddb6\udb3d\ude77\ud885\udcfc\udbc4\ude81\ud8a3\udea3\udbe8\udf93\ud806\udc3f\uda9c\udff5\ud8a2\udfec", "\ub8c7\u6eca", "\ud90a\udf9d\uda66\ude05\udace\udc8f\uda94\udd34\ud885\udf71\ud9a9\udc61\ud96b\udca6",
        52, 81786, -1754166920, -6958160604649059949L, -94177L, false, true, (char) 61648, (char) 11057,
        Double.longBitsToDouble(0x3feac4833ffd0f00L), Double.longBitsToDouble(0x3fe768f44d589289L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 6, "\ud854\udc75\ud80e\udd9f\ud9ff\ude69\ud9c3\udeeb\ud9bc\udd89\ud9a5\udd94\udbd8\udefd\udaf1\udd79\ud848\udd5c\ud8b7\ude2b\uda6b\udf0f\ud95b\udc58\udb7a\udfd0\udba8\udf25\uf8bd\ud974\ude4e\uda0b\udf88\ud98c\uded6\uda86\ude58\ud80f\udee9\ud86e\udec0\udaae\ude22\ud8c3\uddfc\ud83d\udf17\udb18\udf29\uda78\udda1\ud873\udfec", "\u9e11\u6eca", "\udbc9\udf1e\ud9ea\udff3\ud933\udc97\uda94\udd34\ud885\udf71\ud9a9\udc61\ud96b\udca6",
        47, 81786, -1754166920, -6958160604649059949L, -94177L, false, true, (char) 61648, (char) 10545,
        Double.longBitsToDouble(0x3feac21aaffd0f00L), Double.longBitsToDouble(0x3fe768f44d589289L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 9, "\ud854\udc75\ud80e\udd9f\ud9ff\ude69\ud9c3\udeeb\ud9bc\udd89\ud9a5\udd94\udbd8\udefd\udaf1\udd79\ud850\udd81\ud8b7\ude2b\uda6b\udf0f\ud95b\udc58\udb84\ude75\udbda\udd04\uf8bd\ud974\ude4e\uda0b\udf88\ud98c\uded6\uda86\ude58\ud80f\udee9\ud86e\udec0\udaae\ude22\ud8c3\uddfc\udb51\udf5f\uda12\udde9\ud8c3\udcf7\ud874\udc2a", "\ud711\u828c", "\udbc9\udf1e\ud899\udf28\ud92c\udebf\uda94\udd34",
        33, 52373, -607863095, -5563454247673406582L, -76908L, true, true, (char) 38799, (char) 36305,
        Double.longBitsToDouble(0x3fee723c5cede22cL), Double.longBitsToDouble(0x3fd2f17a8d7eff74L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 5, 9, "\ud854\udc75\ud80e\udd9f\ud9ff\ude69\ud9c3\udeeb\ud9bc\udd89\ud9a5\udd94\udbd8\udefd\udaf1\udd79\ud850\udd81\ud8b7\ude2b\uda6b\udf0f\ud95b\udc58\udb7a\udfd0\udba8\udf25\uf8bd\ud974\ude4e\uda0b\udf88\ud98c\uded6\uda86\ude58\ud80f\udee9\ud86e\udec0\udaae\ude22\ud8c3\uddfc\ud83d\udf17\udb18\udf29\uda78\udda1\ud873\udfec", "\ud711\u6eca", "\udbc9\udf1e\ud899\udf28\ud92c\udebf\uda94\udd34\ud885\udf71\ud9a9\udc61\ud96b\udca6",
        47, 81786, -1754166920, -6983924833557509741L, -94177L, false, true, (char) 61648, (char) 10545,
        Double.longBitsToDouble(0x3feac21aaffd0f00L), Double.longBitsToDouble(0x3fe768f44d585d89L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 0, 5, 9, "\udb2d\udeb0\ud893\udd15\ud9ff\ude06\ud9c3\udeeb\ud9bc\udd89\ud9a5\udd94\ud83f\udfb1\ud8da\udd0e\ud850\udd81\ud8b7\ude2b\uda6b\udf0f\ud95b\udc58\udb7a\udfd0\udba8\udf25\uf8bd\ud974\ude4e\ud9c1\udcc3\ud98c\ude86\uda86\ude58\ud80f\udee9\ud86e\udec0", "\u89ab\u744a\u2872\u541e\uae64", "\udaf3\udf9e\ud885\ude39",
        33, 85098, -512440075, -6494137822864552857L, 14085L, true, false, (char) 32667, (char) 36436,
        Double.longBitsToDouble(0x3fd7e9349b992ee2L), Double.longBitsToDouble(0x3fe49cfb79c9298aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 9, "\ud854\udc75\ud80e\udd9f\ud9ff\ude69\ud9c3\udeeb\ud9bc\udd89\ud9a5\udd94\udbd8\udefd\udaf1\udd79\udbb7\udfa0\ud9f9\udfda\ud967\udc39\ud95b\udc58\udb7a\udfd0\udba8\udf25\uf8bd\ud974\ude4e\uda0b\udf88\ud98c\uded6\uda86\ude58\ud80f\udee9\ud86e\udec0\udaae\ude22\ud8c3\uddfc\ud83d\udf17\udb18\udf29\uda78\udda1\ud873\udfec", "\ud711\u6eca", "\udbc9\udf1e\ud899\udf28\ud92c\udebf\uda94\udd34\ud885\udf71\ud9a9\udc61\ud96b\udca6",
        47, 81786, -1754166920, -6958160604649059949L, -94177L, false, true, (char) 61648, (char) 10545,
        Double.longBitsToDouble(0x3feac21aaffd0f00L), Double.longBitsToDouble(0x3fe768f44d589289L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 5, 9, "\ud854\udc75\ud80e\udd9f\udbe8\udd66\ud9c3\udeeb\ud9bc\udd89\ud9a5\udd94", "\ua52a\ua922\ud60f\ud667\ubb5b\u26c4\u881a\ua04b", "\uda86\ude58\ud80f\udee9\ud86e\udec0\udaae\ude22",
        59, 46153, -221537295, -1611326650407058893L, -30852L, true, true, (char) 6975, (char) 44813,
        Double.longBitsToDouble(0x3fe4d02079e3358fL), Double.longBitsToDouble(0x3fed452c346bd66aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 4, 9, "\ud854\udc75\ud8cb\udc3e\udb58\udd20\udba8\udfb5\ud936\udf33\ud9a5\udd94\udbd8\udefd\udaf1\udd79\ud850\udd81\ud9d0\udd77\udbde\ude0f\ud95b\udc58\udb7a\udfd0\udba8\udf25\uf8bd\ud974\ude4e\uda0b\udf88\ud98c\uded6\uda86\ude58\ud80f\udee9\ud86e\udec0\udb7c\udffc\ud8c3\uddfc\uda0f\uddc3\ud879\udd0d\udbb8\udd39\ud9e2\udd83", "\ubaa8\u6eca\ua75a\u83bb", "\ud92c\udebf",
        30, 12323, -359809627, -2610752112498007081L, 68371L, false, true, (char) 61297, (char) 31206,
        Double.longBitsToDouble(0x3fe2127ad4a34719L), Double.longBitsToDouble(0x3fc7c83854bce800L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 9, "\ud854\udc75\ud80e\udd9f\ud9ff\ude69\ud9c3\udeeb\ud9bc\udd89\ud9a5\udd94\udbd8\udefd\udaf1\udd79\ud850\udd81\ud8b7\ude2b\uda6b\udf0f\ud95b\udc58\udb7a\udfd0\udba8\udf25\uf8bd\ud974\ude4e\uda0b\udf88\ud98c\uded6\uda86\ude58\ud80f\udee9\ud86e\udec0\udaae\ude22\ud8c3\uddfc\ud83d\udf17\udb18\udf29\uda78\udda1\ud873\udfec", "\ud711\u6eca", "\udbc9\udf1e\ud899\udf28\ud92c\udebf\uda94\udd34\ud885\udf71\ud9a9\udc61\ud96b\udca6",
        47, 81786, -1754166920, -6958160604649059949L, -94177L, false, true, (char) 61648, (char) 10545,
        Double.longBitsToDouble(0x3feac21aaffd0f00L), Double.longBitsToDouble(0x3fcda3d135601ea8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=com.fasterxml.jackson.core.util.DefaultPrettyPrinter:@? |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 12, 5, 9, "\ud854\udc75\ud80e\udd9f\ud9ff\ude69\ud9c3\udeeb\ud9bc\udd89\ud9a5\udd94\udbd8\udefd\udaf1\udd79\ud850\udd81\ud8b7\ude2b\uda6b\udf0f\ud95b\udc58\udb7a\udfd0\udba8\udf25\uf8bd\ud974\ude4e\uda0b\udf88\ud98c\uded6\uda86\ude58\ud80f\udee9\ud86e\udec0\udaae\ude22\ud8c3\uddfc\ud83d\udf17\udb18\udf29\uda78\udda1\ud873\udfec", "\ud711\u6eca", "\udbc9\udf1e\ud899\udf28\ud92c\udebf\uda94\udd34\udaf5\ude09\ud9a9\udc2f\ud96b\udca6",
        47, 81786, -1754166920, -6958160604649059949L, -94177L, false, true, (char) 61648, (char) 10545,
        Double.longBitsToDouble(0x3feac21aaffd0f00L), Double.longBitsToDouble(0x3fe768f44d589289L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 12, 0, 0, "\ud854\udc75\ud80e\udd9f\ud9ff\ude69\ud9c3\udeeb\ud9bc\udd89\udb19\udfaf\udbd8\udefd\udaf1\udd79\ud850\udd81\ud8b7\ude2b\uda6b\udf0f\ud95b\udc58\udaf7\ude2e\ua0b0\udaf0\uddb5\uda2e\udecd\uda0c\udc3a\ud98c\uded6\uda86\ude58\ud876\udecf\uda82\udd0a\udaa5\udcaf\ud8c3\uddfc\ud83d\udf17\udb18\udf29\uda78\udda1\ud873\udfec", "\ud711\u6eca", "\udbc9\udf1e\ud899\udf28\ud92c\udebf\uda94\udd34\ud885\udf71\ud9a9\udc61\ud80b\udef5",
        47, 81786, -1754167029, -6958160604649059949L, -94177L, false, true, (char) 39759, (char) 57949,
        Double.longBitsToDouble(0x3feac21aaffd0f00L), Double.longBitsToDouble(0x3fe768f44aa69289L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 8, 4, "\udaef\udf44\ud820\udfbc\uda06\udddf\uda1f\udc3c\ud9c3\ude3f\udbd5\udf4b\u623c\ud930\udf1c\uda37\udd17\ud8b7\ude2b\uda6b\udf0f\ud95b\udc58\udb7a\udfd0\ud8a4\udd2a\ud8c0\udcbe\ud97a\udd4e", "\u175e\u0a37\u21da\uc3cf", "\udbfa\uddda\udabf\ude01\uda16\udcdd\uda3d\udf87\uda75\udc64\ud91a\udf42",
        -4, 59312, 1884380407, -6577833643736766816L, 14085L, true, false, (char) 32602, (char) 36436,
        Double.longBitsToDouble(0x3fd789349b992ee2L), Double.longBitsToDouble(0x3fe8239379c9c303L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 10, 4, "\ud854\udc75\ud80e\udd9f\ud9ff\ude69\u58b8\ud845\udee8\udbd5\udf4b\ud845\udf11\ud930\udf1c\uda37\udd17\ud8b7\ude2b\uda6b\udf0f\ud95b\udc58\udb7a\udfd0\udba8\udf25\uf8bd\ud97a\udd4e\uda0b\udf88\ud94e\udd37\uda86\ude58\ud8d2\udf49\ud866\udfb0\udaae\ude22\ud8c3\uddfc\ud83d\udf17\u0fdb\udaba\udd01\ud873\udfec", "\ud711\u1c6c", "\udb1f\udc56\ud9d4\udc5f\udbe9\udc7d\uda0c\udde4\ud885\udf71\ud9a9\udc61\ud96b\udca6\ud88f\udf09\udba5\udd21\uda4e\udf4e\ud9a9\udc8a\udbbe\udf6b\ud97f\udeed",
        8, 62995, 396891373, -4167075198929012084L, 6709L, true, true, (char) 42669, (char) 14077,
        Double.longBitsToDouble(0x3fe578f44f0a9289L), Double.longBitsToDouble(0x3fcd56fa0dfd689cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 12, 13, 4, "\ud854\udc75\ud80e\udd9f\uda39\udf61\u58b8\ud845\udee8\udbd5\udf4b\ud845\udf11\ud930\udf1c\uda37\udd17\ud8b7\ude2b\uda6b\udf0f\ud95b\udc58\udb7a\udfd0\udba8\udf25\uf8bd\ud97a\udd4e\uda0b\udf88\ud94e\udd37\uda86\ude58\ud8d2\udf49\ud866\udfb0\udaae\ude22\uedf8\ud83d\udf17\u0fdb\udabf\ude01\ud873\udfec", "\ud711\u1c6c", "\ud8bb\udf84\ud85e\udce3\udbe9\udc7d\uda0c\udde4\ud885\udf71\ud9a9\udc61\ud96b\udca6\udb2f\udfe2\ud82b\udf2d\uda4e\udf6b\ud9a9\udc8a\udbbe\udf6b\ud97f\udeed",
        8, 62995, 1543704813, -5259800191738571158L, 6709L, true, true, (char) 42669, (char) 36465,
        Double.longBitsToDouble(0x3fdbdfeb5e152512L), Double.longBitsToDouble(0x3fcd56fa0dfd009cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 9, 9, "\ud87d\udf32\ud8b1\udeeb\udac9\udd7a\uda9e\udc97\udbe7\uddc7\udbfc\udf60\ud906\ude41\udaf1\ude31\udbd5\udcc1\udbc7\ude21\ud968\udfa7\ud95b\udc7e\udb7a\udfd0\udba7\udce3\ud9a6\ude32\uda6a\udd06\uda0b\udf88\udb4d\udded\udb72\udfa7\ud869\udd47\ud86e\udec0\udaae\ude22\udaa5\udcf8\ud83d\udeb1\ud8cf\udf1e\uda8c\ude96\ud873\udfec", "\u3055\u6eca\ua75a\u83e1\ub910\u55ef\u1d42\ua883\u5240\uc3e6\uc3d7", "\uda4e\udf4e\ud888\udc1b\udb0c\ude4c\ud8b1\udcb3\ud92f\ude8f\ud8b5\udf49\u03ab\udbeb\udcb5\ud981\udcbc\ud84d\udcd1\u8090\udbdf\udf1e",
        53, 32097, 864647917, -7690918863473421132L, -16368L, false, true, (char) 13863, (char) 9972,
        Double.longBitsToDouble(0x3fcb43dd36d4fb20L), Double.longBitsToDouble(0x3fe025ea26d07c0eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 14, 9, "\ud854\udc75\ud80e\udd9f\udac9\ude68\uda9e\udc97\udb93\udc5d\udbfc\udf28\ud890\ude46\udaf1\ude31\udaa4\udfeb\udbc7\uddb3\ud868\udfa7\ud95b\udc58\udb7a\udfd0\udba8\udf25\ud9a6\ude32\ud9f5\udea8\uda0b\udf88\ud98c\udf30\uda86\ude58\ud80f\udee9\ud86e\udec0\udaae\ude22\udaa5\udcf8\ud83d\udf17\udbeb\udeb2\uda8c\ude71\ud873\udfec", "\u3055\u21ca", "\ud924\udd2b\udb78\udc09\uda25\udd0f\uda81\udc6d\ud96a\ude52\ud9a9\udc61\ud96b\udca6",
        47, 81786, -1747563400, -6958160604818610797L, -69996L, true, true, (char) 41623, (char) 50249,
        Double.longBitsToDouble(0x3fe95c8d2f478feaL), Double.longBitsToDouble(0x3fd37fd58f93c47eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 2, 9, "\ud854\udc75\ud80e\udd9f\udbbb\udd62\u4cfc\ud8fc\udc51\udbc6\ude3c\ud906\ude41\udaf1\ude31\udaef\udeee\ud9ba\udf63\ud868\udfb9\ud95b\udc58\udb7a\udfd0\udba8\udf25\ud9a6\ude32\ud9f5\udea8\uda0b\udf88\ud98c\udf30\uda86\ude58\ud80f\udee9\ud86e\udec0\udb6e\udf36\udaa5\udcf8\ud83d\udf17\udbeb\udeb2\uda8c\ude71\ud946\udcb0", "\u211c\u8467", "\ud90e\udef2\udb44\udc9a\ud92c\udec3\uda81\udc6d\ud96a\ude52\ud9a9\udc61\ud96b\udca6",
        47, 81786, -1754166920, -6958160604604373613L, -78802L, true, true, (char) 38521, (char) 6455,
        Double.longBitsToDouble(0x3fe95c8d2f478feaL), Double.longBitsToDouble(0x3fd37fd58f93c47eL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 11, 11, "\ud854\udc75\uda5f\udde8\ud898\udd70\uda9e\udc97\udbe7\uddc7\ud87e\udf61\ud906\ude41\ud84e\udee1\ud8e2\udcef\udbc7\uddb3\ud868\udfa7\ud95b\udc58\udb7a\udfd0\ud843\udcba\udb7f\udf65\ud9f5\udea8\ud932\udc5b\ud93d\udfe9\uda7a\udd2d\udba0\udca7\uda1a\udf37", "\u89ab\u172f\u43d1\u4469\ud241", "\udb89\udc2a\ud9a7\ude7b",
        51, 27266, -1827311866, 4704181414567986689L, -54458L, true, false, (char) 32667, (char) 36392,
        Double.longBitsToDouble(0x3fd789349b992ee2L), Double.longBitsToDouble(0x3fd93dd6f10790e0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 1, 12, 2, 9, "\ud854\udc75\ud80e\udd9f\udac9\ude68\uda9e\udc97\udbe7\uddc7\udbfc\udf60\ud906\ude41\udaf1\ude31\udaa4\udfeb\udbc7\uddb3\ud868\udfa7\ud95b\udc58\udb7a\udfd0\udba8\udf25\ud9a6\ude32\ud9f5\udea8\uda0b\udf88\udbca\ude2f\ud906\uddc2\ud80f\udee9\ud86e\udec0\udaae\ude22\udaa5\udcf8\ud83d\udf17\udbeb\udeb2\uda8c\ude71\ud873\udfec", "\u3055\u6eca", "\ud8f3\udff2\udb44\udc9a\ud92c\udec3\uda81\udc6d\ud96a\ude52\ud9a9\udc61\ud96b\udca6",
        47, 81786, -1754166920, -6958160604604373613L, -94177L, false, true, (char) 61648, (char) 20273,
        Double.longBitsToDouble(0x3fd37fd58f93c47eL), Double.longBitsToDouble(0x3fe768f44e0b3389L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 9, 12, "\ud854\udc75\ud8fe\udd17\ud9b5\ude38\ud9c3\udeeb\ud9bc\udd89\ud9a5\udd94\uda98\udc3c\udaf1\udda5\ud892\udf41\ud8b7\ude2b\udae5\udf0c\u5206\ub5ef\udac9\uddb2\uda29\udcb2\ud837\udfb0\uda1e\udf32\ud98c\uded6\uda86\ude58\uda69\udcb7\udafa\udd66\uda78\ude70\uda79\udc77\uda7c\udd5c\ud820\ude49\ud884\udf23\ud874\udc2a", "\ud711\u828c", "\uda89\udc5d\ud899\ude7e\ud92c\udebf\udae1\udc34",
        33, 52373, 361811145, -1797999886025384985L, -76908L, true, true, (char) 10931, (char) 36305,
        Double.longBitsToDouble(0x3fee723c5db1fec9L), Double.longBitsToDouble(0x3fd2f1712d7eff74L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=void |this=com.fasterxml.jackson.databind.ObjectMapper:@?\012",
        Z.run(T, 2, 12, 12, 8, "\ud854\udc75\udb83\udcba\ud9ff\ude7f\ud9c3\udeeb\ud9bc\udd89\ud9a5\udd94\udbd8\udefd\uda45\udc84\ud9fc\udd44\ud9f9\udfda\ud98a\udc54\ud991\udfca\udb50\udc6b\udba8\udf25\uf8bd\ud974\ude4e\uda0b\udf88\ud98c\uded6\udba5\udc47\ud80f\udee9\ud86e\udec0\ud872\udd21\ud9f6\udffa\ud83d\udf17\udb18\udf29\uda78\udda1\ud873\udfec", "\ud77d\uc5d8", "\ud9de\udc0e\ud874\udf28\ud858\udd80\uda9a\udeee",
        33, 7917, 224070849, 2537645129648410286L, 92967L, true, false, (char) 36194, (char) 36213,
        Double.longBitsToDouble(0x3fed1a3c5cede22cL), Double.longBitsToDouble(0x3fd2f17a8d7eff74L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 2, 9, "\ud854\udc75\ud849\udd9f\ud9ff\ude69\ud9be\udf69\ud891\udc0f\ud9a5\udd94\udbd8\udefd\udaf1\udd79\udbb7\udfa0\uda3b\udfdb\ud967\udc39\ud95b\udc58\udb7a\udfd0\ud98b\ude16\ud801\udc16\udb37\udd4f\ud921\udf6c\ud98c\udeb8\uda86\ude58\ud80f\udee9\ud86e\udec0\udaae\ude22\ud8c3\uddfc\ud83d\udf17\udb18\udf29\uda78\udda1\ud873\udfec", "\ud711\u6eca", "\udbc9\udf1e\ud8f1\uddf3\ud92c\udebf\uda94\udd34\ud885\udf71\uda2d\udf04\udbad\uddd1",
        55, 71235, 1954680952, -6958160604649059949L, -94752L, false, true, (char) 29958, (char) 26952,
        Double.longBitsToDouble(0x3fc74ff746303918L), Double.longBitsToDouble(0x3fe6c16d1a7e5fa6L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ObjectMapper:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 9, "\ud854\udc75\ud80e\udd9f\ud9ff\ude69\ud9c3\udeeb\ud9bc\udd89\ud900\udce1\udbdf\udffd\udaf1\udd79\ud9ff\uddb8\ud8d0\udd2b\uda6b\udf0f\ud95b\udc58\udb7a\udfd0\uda92\udec8\ud90f\udc86\ud974\ude4e\uda0b\udf88\ud98c\uded6\ud83c\udd41\ud9b2\udebd\udad6\ude74\udaae\ude22\ud8c3\uddfc\ud83d\udf17\ud8b9\udde0\ud804\ude6e\ud950\udcaf", "\u9902\u6eca", "\ud95d\udcc9\ud8fe\udc8b\ud932\udf1e\uda94\udd34\uda96\udc0b\ud9a9\udc2f\ud96b\udca6",
        47, 81786, -1754166920, -6958160604649059949L, -94177L, false, true, (char) 61648, (char) 10545,
        Double.longBitsToDouble(0x3feac21aaffd0f00L), Double.longBitsToDouble(0x3fe768f44d589289L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ObjectMapper|_checkInvalidCopy|java.lang.Class|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_configAndWriteCloseable|com.fasterxml.jackson.core.JsonGenerator,java.lang.Object,com.fasterxml.jackson.databind.SerializationConfig|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_configAndWriteValue|com.fasterxml.jackson.core.JsonGenerator,java.lang.Object|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_configAndWriteValue|com.fasterxml.jackson.core.JsonGenerator,java.lang.Object,java.lang.Class|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_convert|java.lang.Object,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_defaultPrettyPrinter||new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_findRootDeserializer|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_initForReading|com.fasterxml.jackson.core.JsonParser|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_readMapAndClose|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_readValue|com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_serializerProvider|com.fasterxml.jackson.databind.SerializationConfig|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_unwrapAndDeserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.DeserializationConfig,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_verifySchemaType|com.fasterxml.jackson.core.FormatSchema|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|_writeCloseableValue|com.fasterxml.jackson.core.JsonGenerator,java.lang.Object,com.fasterxml.jackson.databind.SerializationConfig|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|acceptJsonFormatVisitor|com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper|new:com.fasterxml.jackson.databind.ObjectMapper:",
    "M|com.fasterxml.jackson.databind.ObjectMapper|acceptJsonFormatVisitor|java.lang.Class,com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper|new:com.fasterxml.jackson.databind.ObjectMapper:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
