package com.fasterxml.jackson.databind.deser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class FromStringDeserializer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 4, 5, 2, "\uda7b\udee1\ud8b9\udfc0\u2aaf\u714d\u6438", "\ua84f\u57c8\u02a9\u9dcc\ub6f7\ub212\u9ac8\ucfb8\u7453\u1cd9\u7273\u4fce\uc6e5\uaee8\u4027\u4290\u0d01", "\udb92\udffc\ud9eb\udd8e\uda20\udd80\ud9d7\ude5f\ud8e2\udfd3\ud911\ude39\udad5\udcfb",
        59, 49875, 478768803, 916269442113868083L, -32416L, false, false, (char) 18756, (char) 1657,
        Double.longBitsToDouble(0x3f92fd8eb85fb640L), Double.longBitsToDouble(0x3fe560c1892be4a6L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 4, 5, 2, "\uda7b\udee1\ud8b9\udfc0\u2aaf\u714d\u6438", "\ua84f\u57c8\u02a9\u9dcc\uaf7f\ub212\u9ac8\ucfb8\u7453\u1cd9\u7273\u4fce\uc6e5\uc1e8", "\udb6b\uddc7\u967c\ud8cc\udfdb\udb92\udffc\ud9eb\udd8e\uda20\udd80\ud9d7\ude5f\ud8e2\udfd3\ud911\ude39\udad5\udcfb\ud94e\udf95\udae8\udd8e\ud9fa\udc51\udbd5\udeed\ud98c\udcb6\ud921\udd8b\ud80e\ude46\udb02\udd00\ud9b1\ude68\ud86f\ude88\ud8d3\udfef\udb3a\ude7b\ud96c\udd0f\uda55\udc0b\ub6a9\udb7d\udf0d\ud976\udd78\udb34\udd88\udbcd\udeae\ud9ae\udde0\ud981\udc1d\udaef\udc38",
        50, 62802, -1408885292, -3039446211084232298L, 59510L, false, false, (char) 64181, (char) 35647,
        Double.longBitsToDouble(0x3fc6b9d23807f6fcL), Double.longBitsToDouble(0x3fb6193af1608dc0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 4, 5, 2, "\uda7b\udee1\ud8b9\udfc0\u2aaf\u714d\u6438", "\ua84f\u57c8\u02a9\u9dcc\ub6f7\ub212\uce0b\u03d7\u7453\u1cd9\u7273\u4fce\uc6e5\uaee8\u4027\u4290\u0d01", "\udb04\udffd\ud9eb\udd8e\uda20\udd80\ud9d7\ude5f\ud8e2\udfd3\uda1c\udf04\u55fd\uda20\udd5c\ud82b\ude72",
        2, 65323, -138538701, 417081266007246848L, -35472L, true, false, (char) 23969, (char) 4981,
        Double.longBitsToDouble(0x3fe56679892be4a6L), Double.longBitsToDouble(0x3fda13020bdee7a6L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=[Ljava.lang.Class;:[[class java.io.File, class java.net.URL, class java.net.URI, class java.lang.Class, class com.fasterxml.jackson.databind.JavaType, class java.util.Currency, class java.util.regex.Pattern, class java.util.Locale, class java.nio.charset.Charset, class java.util.TimeZone, class java.net.InetAddress, c...\012",
        Z.run(T, 1, 5, 5, 2, "\uda7b\udee1\ud8b9\udfc0\u2aaf\u714d\u6438", "\ua84f\u57c8\u02a9\u7665\u3590\ub291\u9ac8\ucfb8\u7453\u1cd9\u7273\u4cb1\uc6e5\uaee8", "\udaa3\ude23\udbf1\udcfc\udad6\ude9c\udae1\udfca\ud9eb\udda0\ud9f3\udf54\ud9d7\ude5f\ud8e2\udfd3\ud911\ude39\udad5\udcfb\ud978\udcf0\uda69\udffe\ud974\udd99\ud8c6\udda0\ud98c\udcb6\ud8a5\udd8d\ud80e\ude46\udb02\udd00\udae7\udc81\ud9f6\udc6a\ud8d4\udc80\udb71\udc36\ud96e\udf6e\ud8c9\udda5\ud92d\uddf6\udabe\ude81\udb8f\udf37\uda0d\udd9a\udbad\uded5\ud91f\ude94\udb55\ude1b\uda66\udfdf",
        15, 98526, -1926004542, -476350018413585161L, -41545L, false, false, (char) 44291, (char) 57273,
        Double.longBitsToDouble(0x3fcf643afa7c7128L), Double.longBitsToDouble(0x3feb42afb37f0d82L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!H:norecv\012",
        Z.run(T, 1, 2, 3, 0, "\uda7b\udef8\ud8b9\udfc0\u2aaf\u714d\u6438", "\ua84f\u57c8\u02a9\u9dcc\ub6f7\ub212\u23e8\ud007\u6f64\u1cd9\u7273\u4fce\uc6e5\uaee8\u4027\u4290\u0d01", "\udb92\udffc\ud9eb\udd8e\uda20\udd80\ud9d7\ude5f\ud8e2\udfd3\ud911\ude39\udad5\udcfb",
        59, 49875, 478768803, 916269442113868083L, -32416L, false, false, (char) 18756, (char) 1657,
        Double.longBitsToDouble(0x3f92fd8eb85fb640L), Double.longBitsToDouble(0x3fe560c189f821a6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null\0121=!H:norecv\012",
        Z.run(T, 2, 4, 1, 4, "\udbbc\udd32\ud8f9\udd80\ud9fd\ude91\ud952\udfe9", "\ub20d\ub689\u576c\u02a9\u66cd\u478f\u5e8f\ube90", "\udb66\udc1e\ud9d4\ude11\ufc08\ud81d\udd01\uda35\udf4c",
        38, 46303, -2095148559, -5280015305294984097L, -5465L, false, true, (char) 43243, (char) 31466,
        Double.longBitsToDouble(0x3fca74254329d6dcL), Double.longBitsToDouble(0x3fec471143b36d9bL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null\0121=[Ljava.lang.Class;:[[class java.io.File, class java.net.URL, class java.net.URI, class java.lang.Class, class com.fasterxml.jackson.databind.JavaType, class java.util.Currency, class java.util.regex.Pattern, class java.util.Locale, class java.nio.charset.Charset, class java.util.TimeZone, class java.net.InetAddress, c...\012",
        Z.run(T, 2, 4, 5, 2, "\uda7b\udee1\ud8b9\udfc0\u2aaf\u714d\u6438", "\u0512\u7c0a\010\uca92\u3646\ub212\u9ac8\ucfb8\u762e\u1cd9\u7b0a\u6cde\uabac\u72bf\u9669\u4290\u0d01", "\udb3a\ude50\ud904\udf61\ud8d2\udf80\ud9e3\udd77\udb4e\udda8\ud911\ude39\udad5\udcfb",
        59, 49875, 478768803, 916269442933155379L, 48194L, true, false, (char) 33926, (char) 28978,
        Double.longBitsToDouble(0x3fe539257763bd4eL), Double.longBitsToDouble(0x3fe560c2992be4a6L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 4, 4, 2, "\uda7b\udee1\ud8b9\udfc0\u2aaf\u714d\u6438", "\u1346\u5742\u02a9\u9dcc\ub6f7\ub212\u9ac8\ucfb8\u7453\u1cd9\u7273\u4fce\uc6e5\uaee8\u4027\u4290\u2fac", "\udb92\udffc\ud9eb\udd8e\uda20\udd80\ud9d7\ude5f",
        28, 30267, 2100381083, 7919852472797920179L, 46124L, false, false, (char) 15177, (char) 18756,
        Double.longBitsToDouble(0x3fe5693e6012fd8eL), Double.longBitsToDouble(0x3fdc2fdb25583062L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[Ljava.lang.Class;:[[class java.io.File, class java.net.URL, class java.net.URI, class java.lang.Class, class com.fasterxml.jackson.databind.JavaType, class java.util.Currency, class java.util.regex.Pattern, class java.util.Locale, class java.nio.charset.Charset, class java.util.TimeZone, class java.net.InetAddress, c...\0121=[Ljava.lang.Class;:[[class java.io.File, class java.net.URL, class java.net.URI, class java.lang.Class, class com.fasterxml.jackson.databind.JavaType, class java.util.Currency, class java.util.regex.Pattern, class java.util.Locale, class java.nio.charset.Charset, class java.util.TimeZone, class java.net.InetAddress, c...\012",
        Z.run(T, 2, 5, 5, 4, "\uda7b\udee1\ud8b9\udfc0\u2aaf\u714d\u6438", "\ua84f\ubdc8\u02a9\u7665\u3590\u6ae1\u9ac8\ucfb8\u9749\u8481\u0b96\u4cb1\uc6e5\uaee8", "\uda6e\uddf3\udbf1\udcfc\ud817\udd9c\ud82c\udd37\udadd\udd64\ud9f5\udd62\ud9d7\ude5f\ud8e2\udfd3\ud911\ude39\udad5\udcfb\udad3\uddff\ud8e1\ude70\ud9d7\udd3d\udb08\uddd5\ud98c\udcb6\udb51\udf3e\ud80e\ude46\udb02\udd00\udae7\udc81\ud87a\ude0d\ud8d4\udc71\udb71\udc36\ud96e\udf6e\ud8c9\udda5\ud92d\uddf6\udabe\udef6\uda94\udc78\udb7e\uddf0\ud887\udff4\uda07\udec8\ud855\udc1f\uda60\udd82",
        42, 98526, -1926004542, -476350016308038953L, 26167L, false, true, (char) 58065, (char) 45800,
        Double.longBitsToDouble(0x3feb42afb37f0d82L), Double.longBitsToDouble(0x3fa4226121665de0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 4, 5, 2, "\uda7b\udee1\ud8b9\udfc0\u2aaf\u714d\u6438", "\ua84f\u5d69\u6a31\u9dcc\ub6f7\ub212\u9ac8\ucfb8\u7453\u1cd9\u7273\u4fce\uc6e5\ucb5a\ub590\u3bb7\u8157", "\udb92\udffc\ud9eb\udd8e\uda20\udd80\udaa3\ude65\ud8e2\udfd3\ud911\ude39\udad5\udcfb",
        59, 49875, 478768803, 916269442113868083L, 98656L, false, false, (char) 18756, (char) 1657,
        Double.longBitsToDouble(0x3f92fd8eb85fb640L), Double.longBitsToDouble(0x3fe560c1892be4a6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 4, 4, 2, "\uda7b\udee1\ud8b9\udfc0\u2aaf\udad8\udc6a\udac5\udfac", "\ud6d0\u5742\u02a9\u9dcc\ub6f7\ud3a4\u9ac8\ucfb8\u7453\u1cd9\u7273\u4fce\uc6e5\uaee8\u4027\u4290\u803a", "\udb92\udffc\ud9eb\udd8e\uda20\udd80\ud9d7\ude5f\ud8e2\udfd3\ud911\ude39\udad5\udcfb\ud875\ude57\udae8\uddf7",
        53, 22604, -138538701, 417081266007246848L, -35472L, true, false, (char) 23969, (char) 4981,
        Double.longBitsToDouble(0x3fe560c18d990359L), Double.longBitsToDouble(0x3fd6129a283b9642L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.std.FromStringDeserializer|deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|fac:com.fasterxml.jackson.databind.deser.std.FromStringDeserializer:findDeserializer:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.FromStringDeserializer|_deserialize|java.lang.String,com.fasterxml.jackson.databind.DeserializationContext|fac:com.fasterxml.jackson.databind.deser.std.FromStringDeserializer:findDeserializer:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.FromStringDeserializer|_deserializeEmbedded|java.lang.Object,com.fasterxml.jackson.databind.DeserializationContext|fac:com.fasterxml.jackson.databind.deser.std.FromStringDeserializer:findDeserializer:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.FromStringDeserializer|_deserializeFromEmptyString||fac:com.fasterxml.jackson.databind.deser.std.FromStringDeserializer:findDeserializer:java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.FromStringDeserializer|findDeserializer|java.lang.Class|static",
    "M|com.fasterxml.jackson.databind.deser.std.FromStringDeserializer|types||static",
    "M|com.fasterxml.jackson.databind.deser.std.FromStringDeserializer|deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|fac:com.fasterxml.jackson.databind.deser.std.FromStringDeserializer:findDeserializer:java.lang.Class",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
