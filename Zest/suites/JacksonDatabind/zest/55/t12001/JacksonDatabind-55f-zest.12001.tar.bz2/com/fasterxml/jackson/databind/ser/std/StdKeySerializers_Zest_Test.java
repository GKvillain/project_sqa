package com.fasterxml.jackson.databind.ser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class StdKeySerializers_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.StdKeySerializers:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 3, 1, 2, "\ud8e1\udf84\ud887\uddfe\ud961\udda2\udafd\udd62\ud875\ude7e\udb3d\udda4\ud861\udd6c\udbd0\uddf3\ud907\udf79\ud9fb\udeaf\udb12\udd96\udb35\ude71", "\u6e40\u1a83\u4c55\u9f71\u1bed\u3cdc\u1ea5", "\udb7e\udf8f\udac7\udcf2\uda52\udc04\ud924\udeca",
        45, 58395, 1778449930, 7676103925409732363L, 80562L, true, true, (char) 44809, (char) 41781,
        Double.longBitsToDouble(0x3fdf6245b6b69deeL), Double.longBitsToDouble(0x3fc5300dfd0a7688L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.StdKeySerializers:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 3, 1, 2, "\ud8e1\udf84\ud887\uddfe\ud820\udecb\ud98b\udd18\ud858\udee6\udb3d\udda4\ud861\udd6c\udbd0\uddf3\udad9\udddc\uda35\ude33\udb12\udd96\udb35\ude71", "\u9f23\u1a83\u4c55\u9f71\u1bed\u3cdc\u1ea5", "\udb7e\udf8f\udac7\udcf2\uda30\udf66\ud8fe\udd0d",
        45, 58395, 1778449930, 7676103925409732363L, 80562L, true, true, (char) 44809, (char) 41781,
        Double.longBitsToDouble(0x3fdf6245b6b69deeL), Double.longBitsToDouble(0x3fc5300dfd0a7688L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.StdKeySerializers:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 3, 1, 3, "\ud8e1\udf84\udbfa\udfc8\ud961\udd80\udafd\udd62\ud875\ude7e\udb2d\udd9c\ud861\udd6c\ud921\udd9b\ud9b1\udf6d\ud8fb\ude90\udb12\uddf1\ud8b0\udece", "\u6e40\uc7ca\u0b89\u9f71\u1bed\u3cdc\u1ea5", "\uda5b\ude00\udad8\udd5f\uda4b\udde5\ud93a\udd70\uda93\udce5",
        15, 35466, 1274281946, -4916076954228472252L, -23293L, true, true, (char) 39135, (char) 45758,
        Double.longBitsToDouble(0x3feada77b9a980f8L), Double.longBitsToDouble(0x3feba4953db43541L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 0, 1, 2, "\ud8e1\udf84\ud887\uddfe\ud9b5\ude4d\udad8\ude74\ud82d\udcf2\udb17\udf43\ud861\udd6c\udb34\udfe5\ud907\udf79\ud9fb\udeaf\udb12\udd96\udb35\ude71", "\u6e40\u1a83\u4c55\u9f71\u1bed\u8ce0\u1ea5", "\udb7e\udf8f\udadc\udff2\uda52\udc04\ud924\udeca",
        45, 58395, 1778449930, 7676103925409732363L, 80562L, true, true, (char) 44809, (char) 41781,
        Double.longBitsToDouble(0x3fdf6245b6b69deeL), Double.longBitsToDouble(0x3fe42bd37ee7fc7fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 1, 1, 1, 2, "\ud8e1\udf84\ud887\uddfe\ud961\udda2\ud82e\udcdb\ud878\udf28\udb3d\udda4\ud861\udd6c\udbd0\uddf3\ud907\udf79\udb9b\udda6\udb4e\ude89\udb35\ude71", "\u5d31\u1a6b\u4c55\u9f71\u1bed\u3cdc\u89ef", "\udb7e\udf8f\udac7\udcf2\uda52\udc04",
        26, 43820, 1612544886, 7638384288710721498L, -6855L, false, true, (char) 29905, (char) 44809,
        Double.longBitsToDouble(0x3fee9fdb159e525bL), Double.longBitsToDouble(0x3feada73935a6d3cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializers$Dynamic:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 2, 1, 2, "\ud8e1\udf84\ud887\uddfe\ud961\udda2\udafd\udd62\ud875\ude7e\udb3d\udda4\ud861\udd6c\udbd0\uddf3\ud9ae\udf8a\uda1c\udda7\udb12\udd96\udb35\ude71", "\u6e40\u1a83\u4c55\u13ec\u1c3a\u6117\u1ea5", "\u9d04\udac7\udcf2\uda52\udc04\ud924\udeca",
        45, 58395, 1778449930, 7676103925409732363L, 59906L, true, true, (char) 44809, (char) 41781,
        Double.longBitsToDouble(0x3fdf6245b6b69deeL), Double.longBitsToDouble(0x3fc5300dfd0a7688L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 1, 1, 2, "\ud8e1\udf84\ud887\uddfe\ud961\udda2\udafd\udd62\ud875\ude7e\udb3d\udd15\ud958\udd26\udba3\udc07\uda9b\udc08\ud9fb\udeaf\ud9a3\udfff\ud92f\udd78", "\u6e40\u4f96\u4c55\u9f71\u37af\u3d04\u16a5", "\udb7e\udf8f\udac7\udcf2\uda52\udc04\ud924\udeca\uda61\udf6f\uda02\udef4\uad75\ud851\ude21\udbbe\ude9f\ud802\udf94\ud813\udda2\udaa2\udd2e",
        24, 46515, 1324846582, -9192107034527260503L, -70224L, true, true, (char) 26950, (char) 49455,
        Double.longBitsToDouble(0x3fdc13a5378ffa24L), Double.longBitsToDouble(0x3fc9745fb0b19918L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 2, 1, 0, "\ud8e1\udf84\udbd9\udcc7\udb09\udcd2\uda17\ude30\ud875\udecc", "\ubb69\u52cc\u3c9c\u6051\u468c\u794a\u7197\u6e40\u1a83\u4c55\u9f71\u1bed\u3cdc", "\ud9d1\udfe3",
        35, 41439, 99645355, 1639822032494061244L, -34966L, false, true, (char) 49553, (char) 18734,
        Double.longBitsToDouble(0x3fd527eba746925cL), Double.longBitsToDouble(0x3fc5facb574fed88L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializers$Dynamic:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializers$Dynamic:@?\012",
        Z.run(T, 2, 2, 2, 0, "\ud8e1\udf84\ud887\uddfe\ud961\udda2\udafd\udd62\ud875\ude7e\udb3d\udda4\ud861\udd6c\udbd0\uddf3\ud907\udf79\ud9fb\udeaf\udb12\udd96\udb35\ude71", "\u889b\ud1a7\u4c55\ud2b4\u1bb1\u3cdc\u1ea5", "\udb84\udcb4\udac7\udcf2\udb6f\ude52\ud92a\ude83",
        45, 58395, 1778449930, 7676103926493959947L, -24399L, true, false, (char) 12737, (char) 36786,
        Double.longBitsToDouble(0x3fedd66ee7846628L), Double.longBitsToDouble(0x3f964ebb98c452a0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 2, 1, 2, "\ud8e1\udf84\ud887\uddfe\ud961\udda2\udafd\udd62\ud875\ude7e\udb3d\udda4\ud861\udd6c\udbd0\uddf3\ud907\udf79\ud9fb\udeaf\udb4e\udf55\uda37\udc91", "\u6e40\u1a83\u4c55\u9f71\u1bed\u3cdc\u1ea5\u4963\u8334\u8e30\u3d0b", "\udad9\udd4f\u8115\ue72a\udbed\udc85\udbbe\ude9f\udb96\udf9e\ud813\udda2",
        19, 57919, 609986515, 5690080827467043675L, -56802L, false, true, (char) 24838, (char) 35885,
        Double.longBitsToDouble(0x3fc21f8e63c4f5c8L), Double.longBitsToDouble(0x3fedcbeb735e626eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 2, 1, 2, "\ud8fe\ude21\udb53\udc0d\ud961\udda2\udafd\udd62\ud875\ude7e\udb3d\udda4\ud861\udd6c\ud937\ude58\ud8b5\udd60\ud9fb\udeaf\udb12\udd96\udb35\ude71", "\u6e40\u1a83\u4c55\u9f71\u2c87\u3cdc\u44e9", "\udbf0\udce8\uda59\ude63\uda50\udc79\ud924\udeca",
        2, 58395, 1778449930, 7676103925409732363L, 80562L, true, true, (char) 44809, (char) 19371,
        Double.longBitsToDouble(0x3fdb4b1044b69deeL), Double.longBitsToDouble(0x3fdeaa077e84a14eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializers$Dynamic:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 2, 1, 3, "\ud8e1\udf84\udbfa\udfc8\ud961\udd80\udafd\udd62\ud9d6\udf4f\udb2d\udd9c\udae2\udcab\ud921\ude55\udb62\uddc6\ud8d7\udd28\ud95c\ude07\ud8b8\udc54", "\uba22\ud134\u0e08\u4f03\u569c\u3cdc\u1ea5", "\uda5b\ude00\udad8\udd5f\uda4b\udde5\ud899\udd3f\udbd3\udd2b",
        37, 35352, 1274281946, -4916076957649201340L, 66108L, true, true, (char) 58335, (char) 45758,
        Double.longBitsToDouble(0x3feada77b9a980f8L), Double.longBitsToDouble(0x3feba4953db43541L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 1, 1, 3, "\ud8e1\udf84\udbfa\udfc8\ud968\ude80\udafd\udd62\ud875\ude7e\udb2d\udd9c\ud861\udd6c\ud921\udd9b\ud9b1\udf6d\ud8fb\ude90\udb12\uddf1\ud8b0\udece", "\u6e40\uc7ca\u27b1\u2b93\u7530\u3cdc\u1ea5", "\uda5b\ude00\udad8\udd5f\uda4b\udde5\ud93a\udd70\uda93\udce5",
        15, 35466, 1274281946, -4916076954228472252L, -23377L, true, true, (char) 39135, (char) 45758,
        Double.longBitsToDouble(0x3feada77b9a980f8L), Double.longBitsToDouble(0x3feba4953db43541L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 2, 1, 2, "\ud8e1\udf84", "\u7355\u8909\ub579\uc642\ua7c9\u4d37\ubb49\u6051\u468c\u794a\u7197", "\udac9\udf88\ud856\ude7e\uda97\udc35\ud816\uded6\uda43\udf8e\ud802\udf6b\udb2f\ude1f\udb7e\udf8f\udadc\udff2\uda52\udc04\ud924\udeca\udae2\udf4f\ud853\ude6e\ud8c1\udc49",
        13, 42835, 2126120999, 5273364770930174883L, -77427L, false, true, (char) 25170, (char) 30964,
        Double.longBitsToDouble(0x3fd76fc7fae31f2cL), Double.longBitsToDouble(0x3fc87a6a153b2b94L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 2, 1, 1, "\ud8e1\udf84\ud887\uddfe\ud9b5\ude4d\udad8\ude74\ud82d\udcf2\udae3\udfe9\udb87\uddaf\udb60\udf19\ud907\udf79\ud9fb\udeaf\udb12\udd96\udb35\ude71", "\u6e40\u1a83\u4c55\u9f71\u1bed\u8ce0\ucdb0", "\udaad\udd74\udae4\udeb2\uda52\udc04\ud924\udeca\udae2\udf4f\u8115\ud8c1\udc49\ud833\udd21\udbbe\ude9f\udb73\udf9e\ud813\udda2\udaa2\udd2e\ud96c\udc69\ud9f4\uddf7\ud934\ude9d\ud836\ude92\ud897\ude50\uda50\uddbb\ud90d\udc7c\udb0f\udd06\ud854\uddde\ud899\uddec\ud8a9\uddbb\ud95a\udc84\ud8d8\udeec\ud856\ude37\udb96\ude5d\udbfc\udf96\ud060\ud9a4\uddb7\ud9cb\udd6a\u96d1\uda98\udfd5\udbe7\uddaa\ud849\udd25\ud99e\udce8\ud94f\udccc\ud96b\ude28\udb5b\udcdb\ud88e\udf01",
        -2, 50165, 1606457700, 7470390265071060288L, -70688L, false, false, (char) 17504, (char) 13546,
        Double.longBitsToDouble(0x3fea855dcca9a935L), Double.longBitsToDouble(0x3fa57c5915f55680L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializers$Default:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 2, 1, 0, "\ud8e1\udf84\ud950\ude30\ud9b5\ude4d\udad8\ude74\ud82d\udcf2\udba0\ude85\ud917\udd66\udb35\udc60\ud9b8\udecb\ud9fb\udeaf\udb12\udd96\udb35\ude71", "\u6e40\ud591\u4c55\ud72c\u1a57\u53db\uc660", "\ud804\ude32",
        38, 58355, 381800819, 3278874222262181739L, 69394L, false, true, (char) 29905, (char) 44809,
        Double.longBitsToDouble(0x3fc4520c4b419734L), Double.longBitsToDouble(0x3fdf55678d73d7aaL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 1, 2, 1, 2, "\u403d\ud887\udd64\ud835\udf68\ud9b0\udc21\ud888\ude8b", "\u18fe\ub932\u4639\u2132\uc9eb\u544c\u2fd6\u5cf2\u8187\u2600\u0bbe\ud6e1\u67f8", "\udb9f\udef0\udb7e\udf8f\udac7\udcf2",
        8, 5755, 1303045834, 6948627022278139398L, -10361L, true, true, (char) 21670, (char) 44753,
        Double.longBitsToDouble(0x3fc969e7cef1ecc0L), Double.longBitsToDouble(0x3fdeafb30613f490L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializers$StringKeySerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 2, 1, 2, "\ud944\udfbe\ud887\ude28\ud961\udda2\udafd\udd62\ud875\ude7e\udb3d\udda4\udaf8\udfa3\ud94c\udf1c\ud9b4\ude8a\uda1c\udda7\udb12\udd96", "\u7197\u6e40\u1a83\u4c55\u13ec\u1c3a\u6117\u9a7f\u4963", "\udac7\udcf2\uda52\udc04\ud924\udeca\udae2\udf4f\u8115\ud8c1\udc49\ud851\ude21\udbbe\ude9f",
        0, 23258, -698733661, -332465175731132461L, 80926L, false, false, (char) 9378, (char) 17003,
        Double.longBitsToDouble(0x3fe81878ff5eb011L), Double.longBitsToDouble(0x3feeba0314a34328L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 2, 2, 0, "\ud8e1\udf84\ud887\uddfe\ud961\udda2\ud9b3\udfdd\udb2b\udf04\udb3d\udda4\ud861\udd6c\udbd0\uddf3\ud9ae\udf8a\uda1c\udda7\udb12\udd96\udb35\ude71\ud853\udcef\udb33\udc49\ud9d6\udfd0\udb0e\udd16\udac9\udf88\uda4b\ude1b\udb80\udffa\ud9d3\ude18\uda2d\udc23\udbe9\udf5b\udb45\udca7\u9d04\udac7\udcf2\uda52\udc04", "\u2d55\ucbac\ua61b\u9e2f\u898a\u275e\ubadd\u1297\u6aea\u838d\uac29\u647f", "\uc5a7\udb7c\ude11",
        51, 75702, 1350586091, -3151513447594454081L, 51374L, true, true, (char) 50332, (char) 35671,
        Double.longBitsToDouble(0x3fedd2fe7af14eb9L), Double.longBitsToDouble(0x3fe92e0a73dabeaeL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializers$Dynamic:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializers$Dynamic:@?\012",
        Z.run(T, 2, 2, 2, 0, "\ud8e1\udf84\ud887\uddfe\ud961\udda2\udafd\udd62\ud875\ude7e\udb30\udcc5\ud861\udd6c\udbd0\uddf3\ud9ae\udf8a\udaed\udc70\uda56\udc2f\ud8c7\ude39\ud84c\udfef\udb33\udc49\ud9d6\udfd0\udb0e\udd16\udac9\udf88\ud691\udba1\udd7a\ud924\udec0\udba7\ude6f\udbe9\udf4b\udb45\udca7\u9d04\udac7\udcf2\uda52\udc04\ud924\udeca\ud90c\udf04\ud849\udf69\udbd0\uddcb", "\u6dfb\u32b6\u9613\u66ca\u10a0\ud1e0\uac29", "\ud884\udf01\u0ee8\udb6c\udfa9\ud966\udcdc\udac1\ude4b",
        42, 46187, -1393285915, 7257189498721859249L, 47723L, true, true, (char) 312, (char) 4782,
        Double.longBitsToDouble(0x3fee982ee21331c8L), Double.longBitsToDouble(0x3fe43b58096fb312L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializers$StringKeySerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializers$StringKeySerializer:@?\012",
        Z.run(T, 2, 2, 2, 2, "\udb69\udf48\ud887\uddfe\ud961\udda2\udafd\udd62\ud875\ude7e\udbc9\udc89\ud9c1\udedb\ud924\udfbc\ud912\udd40\ud877\udf13\udb32\udfa6\ud9da\udf78", "\u418e\u7440\u76d3\u7149\u370a\u6117\u4f33\u4963", "\udac7\udcf2\uda52\udc04\ud924\udeca\udae2\udf4f\ud92d\udcf0\ud8c1\udcdf\udb44\ude5c\uda1f\udfcf",
        0, 23258, 991186786, -332465176119040045L, 77962L, true, false, (char) 62692, (char) 39654,
        Double.longBitsToDouble(0x3fce7707b2ade460L), Double.longBitsToDouble(0x3fe7d640b55922b1L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 2, 2, 2, "\ud8e1\udf84\ud887\uddfe\ud961\udda2\udafd\udd62\ud875\ude7e\ud935\udd96\ud861\udd6c\udbd0\uddf3\ud9ae\udf8a\uda1c\udda7\udb12\udd96\udb35\ude71\ud853\udcef\udb33\udc49\ud9d6\udfd0\udb0e\udd16\uda06\udfce\uda4b\ude1b\udb80\udffa\ud9d3\ude18\uda2d\udc23\udbe9\udf5b\udb45\udca7\u9d04\udac7\udcf2\uda52\udc04\ud924\udeca", "\ucbac\ua61b\u9e2f\u898a\u275e\u7246", "\ud934\ude9d\ud9ba\udfd6\udbee\udedc\ud191\ud9f4\uddf1\uda88\udcdf\ud995\udf05\ud9f6\udf04\udb03\ude90\ud836\udfc7\udbf1\uddad\uda41\udd16\udaa9\udc6a\udb67\ude83\udba8\udf99\ud8b1\udf42\udbc6\udce8\ud9f5\udded",
        58, 7526, 906332349, 5726757259580314095L, -9568L, false, false, (char) 45636, (char) 19093,
        Double.longBitsToDouble(0x3fe1ce5760527459L), Double.longBitsToDouble(0x3fe6a1d2527d4d06L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 2, 2, 3, "\udb96\udc29\ud887\uddfe\ud961\udda2\udafd\udd62\ud875\ude7e\udb3d\udda4\ud861\udd6c\udbd0\uddf3\ud9ae\udf8a\uda1c\udda7\udb12\udd96\udb35\ude71\ud853\udcef\udb33\udc49\ud9d6\udfd0\udb0e\udd16", "\u6474\u6117\u1ea5\ua221\u3c0a\u336d\u5400\u0eb5\uac6b\u4ac9\u4625", "\udbbe\ude9f\ud820\ude63\ufcf2\udaa2\udd2e\ud96c\udc69\ud9f4\uddf7\ud934\ude9d",
        33, 19809, -639084734, 2000199864194800402L, 48012L, false, true, (char) 3283, (char) 20047,
        Double.longBitsToDouble(0x3fd633e9d11729c2L), Double.longBitsToDouble(0x3fb442ba08fee750L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 2, 2, 2, "\ud8e1\udf84\udbd9\udcc7\udb09\udcd2\uda17\ude30\ud875\udecc", "\ubb69\u52cc\u3c9c\u6051\u0382\u8d57\u7b9d\u139c\u1a83\u4c55\u9f71\u1bed\uac44", "\ud9d1\udfe3",
        35, 55959, 1620913818, 1639632776244562876L, -34966L, false, true, (char) 15293, (char) 12591,
        Double.longBitsToDouble(0x3fd507eba746ff2aL), Double.longBitsToDouble(0x3fc5facb574fed88L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 2, 2, 0, "\ud8e1\udf84\ud887\uddfe\ud961\udda2\udafd\udd62\ud875\ude7e\udb3d\udda4\ud861\udd6c\udbd0\uddf3\ud8b3\udfee\uda2b\udc4a\uda1f\udeef\ud978\udcf0", "\u9a8f\ud180\u4c55\ud2b4", "\uda2d\udc23",
        13, 23540, -199186072, -5178856793229461589L, 90140L, true, true, (char) 24103, (char) 27098,
        Double.longBitsToDouble(0x3fc70d50d09fb898L), Double.longBitsToDouble(0x3fea13e33efdd923L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializers$Default:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializers$Default:@?\012",
        Z.run(T, 2, 2, 2, 0, "\ud8e1\udf84\ud887\uddfe\ud961\udda2\udafd\udd62\ud875\ude7e\udb3d\udda4\ud861\udd6c\udbd0\uddf3\ud907\udf79\ud9fb\udeaf\udb7d\ude6b\udabd\udc12", "\u889b\ud1a7\u4c55\ud2b4\u1bb1\u216e\u1ea5", "\udb84\udcb4\udac7\udcf2\udb6f\ude52\ud92a\ude83\udad0\udd67\ud81c\udd5b\ud8c1\udc49\ud851\ude21\udb9d\ude6e\udb50\udf7b\udace\udcf7\ud87e\udd78\ud936\udd86",
        52, 21560, 981672100, -6013441567317486379L, 33984L, false, true, (char) 21431, (char) 43353,
        Double.longBitsToDouble(0x3fe9149fa74dda75L), Double.longBitsToDouble(0x3fea44fb3545b8f1L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 2, 2, 2, "\ud9fe\udc3a\ud863\ude67\udb89\udd87\ud8e2\ude5f\ud8c8\ude2f\udb3d\udda4\ud8ad\udea6\ud97a\udef3\ud938\udf4e\ud9fb\udeb6\ud9f7\udc89\uda37\udcd9", "\u8fbb\u1298\u4b68\u6397\u80b7\u9cda\u1f15\u4963\u8334\u8e30\u3d0b", "\udad9\udd4f\u8115\ue72a\udbed\udcf7\udbbe\ude9f\udb96\udf9e\ud813\udda2\udaa2\udd2e\u575f\ud9f4\udd7d\ud91f\udf05\ud9ba\udfd6\ud978\udcc0",
        12, 1048, -1037485585, -255664034712662825L, 34073L, false, true, (char) 21337, (char) 27019,
        Double.longBitsToDouble(0x3fbdf1e2f60e5558L), Double.longBitsToDouble(0x3fc61368f56c9abcL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.std.StdKeySerializers:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 3, 1, 2, "\uda07\udef9\ud887\uddfe\ud961\udda2\udae3\udeb5\udadd\ude2a\udb3d\uddcb\ud861\udd6c\udbd0\uddf3\ud907\udf79\u2bed\udb12\udd96\udb35\ude71", "\u0921\u1a83\u64bd\uac0d\u1bed\ud31b\u1f4a\u4963\u8334\u8e30\u5400\u0eb5\uac6b\ud5c8", "\uda0d\udce0",
        -5, 39916, 1239527748, -3001038222686758737L, 88247L, false, false, (char) 43790, (char) 5324,
        Double.longBitsToDouble(0x3feaab13c2b17ad5L), Double.longBitsToDouble(0x3fea4129c7b1ea67L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.StdKeySerializer:@?\012",
        Z.run(T, 2, 2, 1, 2, "\uda43\udc55\ud80a\udf06\ud961\uddbd\udafd\udd62\ud875\ude7e\udb3d\udda4\ud861\udd6c\udbd0\uddf3\ud9ae\udf8a\uda1c\udda7\udb12\udd96\udb35\ude71", "\u6e40\u0183\u3355\u13ec\u1c3a\u6117\ub77c", "\u9d04\udac7\udcf2\uda52\udc04",
        44, 43820, 1612524395, 7638384288710714632L, -72391L, false, false, (char) 29905, (char) 44809,
        Double.longBitsToDouble(0x3fee9fdb164a825bL), Double.longBitsToDouble(0x3feada77b8a9806fL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ser.std.StdKeySerializers|getFallbackKeySerializer|com.fasterxml.jackson.databind.SerializationConfig,java.lang.Class|static",
    "M|com.fasterxml.jackson.databind.ser.std.StdKeySerializers|getDefault||static",
    "M|com.fasterxml.jackson.databind.ser.std.StdKeySerializers|getStdKeySerializer|com.fasterxml.jackson.databind.SerializationConfig,java.lang.Class,boolean|static",
    "C|com.fasterxml.jackson.databind.ser.std.StdKeySerializers|<init>|",
    "M|com.fasterxml.jackson.databind.ser.std.StdKeySerializers|getFallbackKeySerializer|com.fasterxml.jackson.databind.SerializationConfig,java.lang.Class|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
