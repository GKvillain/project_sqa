package com.fasterxml.jackson.databind.ser;
import org.junit.Test;
import static org.junit.Assert.*;
public class AnyGetterWriter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\012",
        Z.run(T, 1, 19, 14, 16, "\ud85a\udde8\udbfc\udcfc\uda8e\udfe3\ud9f2\udd5d\ud839\ude75\ud8db\ude02\uda17\udf57\udbc6\uddaf\ud910\udff0\udbdb\udd9c", "\u1a92\u6269\uc6bf\u8149\u01be", "\udbf0\udc99\ud92f\udd43\uda65\udfbe\ud862\udf65\ud83a\udcef\ud8f7\udf19\udbe8\udc6c\ud95c\udd83\ud864\udedb\ud806\udfdd\udbdc\ude14",
        11, 3895, -1464859810, -6277645538535843914L, 59594L, true, true, (char) 31729, (char) 64931,
        Double.longBitsToDouble(0x3fc424da6b13690cL), Double.longBitsToDouble(0x3fd1c3a4c86dd44aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\012",
        Z.run(T, 1, 19, 14, 16, "\ud85a\udde8\udbfc\udcfc\uda8e\udfe3\ud9f2\udd5d\ud839\ude75\ud8db\ude02\uda17\udf57\udbc6\uddaf\ud910\udff0\udbdb\udd9c", "\u1a92\u6269\uc6bf\u8149\u01be", "\udbf0\udc99\ud92f\udd43\uda65\udfbe\ud862\udf65\ud83a\udcef\ud8f7\udf19\udbe8\udc6c\ud95c\udd83\ud864\udedb\ud806\udfdd\udbdc\ude14",
        57, 1881, -1464847706, -6277645538535843914L, 59594L, true, true, (char) 31729, (char) 64931,
        Double.longBitsToDouble(0x3fc424da6b13690cL), Double.longBitsToDouble(0x3fd1c3a4c86dd44aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.BeanSerializerBuilder:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\012",
        Z.run(T, 1, 7, 14, 16, "\ud85a\udde8\udbfc\udcfc\uda8e\udfe3\ud9f2\udd5d\ud839\ude75\ud8db\ude02\uda8b\udf51\udbc6\uddaf\udb99\uddb4\ud971\udce8", "\u1a92\u09d0\u09b2\u8609\u01be", "\udbf0\udc99\ud92f\udd43\uda65\udfbe\ud862\udf65\ud83a\udcef\ud8f7\udf19\udbe8\udc6c\ud95c\udd83\ud8b5\udd43\ud806\udfdd\udbdc\ude14",
        11, 58773, -1464859810, -6277645538535843914L, 26913L, false, false, (char) 33667, (char) 5737,
        Double.longBitsToDouble(0x3fd5aea97fecdb5cL), Double.longBitsToDouble(0x3fc424da6b13690cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 15, 16, "\ud85a\udde8\udbfc\udd22\uda8e\udfe3\ud9f2\udd5d\ud839\ude75\ud8db\ude02\uda17\udfa4\udbc6\uddaf\udb12\udf10\ud843\ude70", "\u2fed\u6269\uc6bf\u8149\u01be", "\udbf0\udc99\ud92f\udd43\uda65\udfbe\ud862\udf65\ud83a\udcef\ud8f7\udf19\udbe8\udc6c\ud95c\udd83\ud864\udedb\ud806\udfdd\udbdc\ude14",
        11, 62427, -1464859810, -6277645538535843914L, 59594L, true, true, (char) 31729, (char) 64931,
        Double.longBitsToDouble(0x3fc424da6b13690cL), Double.longBitsToDouble(0x3fd1c3a4c86dd44aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.util.ArrayIterator:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\012",
        Z.run(T, 1, 12, 14, 16, "\uda4e\udd50\udba0\ude83\uda8e\udfe3\ud9f2\udd5d\ud839\ude75\ud8b1\udd4d\ua33a\udbc6\uddaf\ud910\udff0\udbdb\udd9c", "\u1a92\u6269\u07a4\u092b\uabb4", "\udbf0\udc99\ud98a\udd09\ud830\udcfa\ud862\udfa7\ud83a\udcef\ud8f7\udf19\udbe8\udc6c\uda67\udc86\ud864\udedb\udbdb\udfe7\u08e8",
        41, 21290, -716269383, -6542540261500513302L, 75731L, false, true, (char) 11124, (char) 15624,
        Double.longBitsToDouble(0x3fdf93a4c590d0eaL), Double.longBitsToDouble(0x3fe9032625a8f562L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 6, 17, "\ud85a\udde8\ud9c7\udda4\udac6\udc58\ud9f2\udd5d\ud825\udf75\ud8db\ude02\uda17\udf57\udbc6\uddaf\ud910\udff0\udbdb\udd9c", "\u1a92\u6269\uc6bf\u8149\u01e5", "\udbf0\udc99\ud92f\udd43\uda65\udfbe\ud862\udf65\ud821\udf0a\ud8f7\udf19\udbe8\udc6c\ud95c\udd83\ud864\udedb\ud806\udfdd\udbdc\ude14",
        38, 25796, -881747227, -6277645736104339530L, 59594L, true, false, (char) 31729, (char) 64931,
        Double.longBitsToDouble(0x3fc424da6b13690cL), Double.longBitsToDouble(0x3fd1c3a4c95fd44aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 14, 16, "\ud85a\udde8\udbfc\udcfc\uda8e\udfe3\ud9f2\udd5d\ud839\ude75\ud8db\ude02\uda17\udf57\udbc6\uddaf\ud911\udcb7\udbdb\udd9c", "\u1a92\u6269\uc6bf\u8149\u01be", "\udbf0\udc99\ud93e\udf43\uda65\udfbe\ud862\udf65\ud83a\udcef\ud8f7\udf19\udbe8\udc6c\ud95c\udd83\ud864\ude9c\ud82e\udfc6\udbdc\ude14",
        11, 3895, -1464859810, -6277645538535843914L, 59594L, true, true, (char) 27133, (char) 64931,
        Double.longBitsToDouble(0x3fc424da6b13690cL), Double.longBitsToDouble(0x3fd1c3a4c86dd44aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 14, 0, "", "", "\ud913\udda8\000\u2011\udbc6\uddaf",
        30, -1000, 0, 0L, 78635L, true, false, (char) 584, (char) 46143,
        Double.longBitsToDouble(0x3e452f4c00000000L), Double.longBitsToDouble(0x3fcf670489d522acL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 10, 6, "\ud85a\udde8\udbfc\udcfc\uda8e\udfe3\uda00\udc5d\ud839\ude75\ud8db\ude02\uda17\udf57\udbc6\uddaf\ud910\udff0\udbdb\udd9c", "\u1a92\u6269\uc6bf\u8149\u01be", "\udbf0\udc99\ud92f\udd43\uda65\udfbe\ud862\udf65\ud83a\udcef\ud8f7\udf19\udbe8\udc6c\ud95c\udd83\ud864\udedb\ud806\udfdd\udbdc\ude14",
        11, 3895, -1464859810, -6277645538535843914L, 59594L, true, true, (char) 31729, (char) 64931,
        Double.longBitsToDouble(0x3fc424da6b13690cL), Double.longBitsToDouble(0x3fd1c3a4c86dd44aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 14, 16, "\ud85a\udde8\udbfc\udcfc\uda8e\udfe3\ud9f2\udd5d\ud839\ude75\ud8db\ude02\uda17\udf57\udb94\udd75\udb88\udf48\udbdb\udd9c", "\u1a92\u6269\uc6bf\u8149\u01be", "\udbf0\udc99\ud92f\udd43\uda65\udfbe\ud862\udf65\ud83a\udd7b\ud8f7\udf19\udbe8\udc6c\udb0e\udebb\ud864\ude42\ud992\udd63\uda1c\udf1f",
        11, 3895, -1464859810, -6277645538535843914L, 59594L, true, true, (char) 31729, (char) 64931,
        Double.longBitsToDouble(0x3fc424da68ef090cL), Double.longBitsToDouble(0x3fd1c3a4c86dd44aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\012",
        Z.run(T, 1, 18, 10, 16, "\ud85a\udde8\udbfc\udcfc\ud90c\ude58\udb70\udd5b\uda71\udd0e\ud902\ude4f\udaae\udddd\ud93d\ude57", "\u2eca\u9d60\u16d6\u9f80\u306d\u91e6\u614b", "\udba3\udf94",
        6, 25813, -2051591526, -3906463518028618798L, -45472L, true, false, (char) 15706, (char) 5360,
        Double.longBitsToDouble(0x3feaf46812a5a8b0L), Double.longBitsToDouble(0x3fe5fba5bb74114bL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 9, "\ud85a\udde8\udbfc\udcfc\uda8e\udfe3\ud9f2\udd5d\ud839\ude75\ud8db\ude02\uda17\udf57\udbc6\uddaf\ud910\udff0\udbdb\udd9c", "\u1a92\u6269\uc6bf\u8149\u01be", "\udbf0\udc99\ud92f\udd43\uda65\udfbe\ud862\udf65\ud83a\udcef\ud8f7\udf19\udbe8\udc6c\ud95c\udd83\ud864\udedb\ud806\udfdd\udbdc\ude14",
        11, 3895, -1464859810, -6277645538535843914L, 59594L, true, true, (char) 31729, (char) 64931,
        Double.longBitsToDouble(0x3fc424da6b13690cL), Double.longBitsToDouble(0x3fd1c3a4c86dd44aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\012",
        Z.run(T, 1, 19, 14, 12, "\ud85a\udde8\udbfc\udcfc\ud910\udf73\ud9f2\udd8f\ud839\ude75\ud8db\ude02\uda17\udf57\udb86\udc87\ud9e7\udfc5\udbcc\udf49\udb5a\udd0b\ud87c\udcc1\ud8cf\udf58\udab8\udf77", "\u01be\u6af8\ucb00\u17d5\u2163\u33dd\u49ab\u0be0\ud4dc\u296a\ub3f9\u69c1\u56cb", "\ud896\udcf0",
        10, 42749, -1581164618, -8745877376416037026L, 47853L, true, true, (char) 31729, (char) 64931,
        Double.longBitsToDouble(0x3fc424da6af976e8L), Double.longBitsToDouble(0x3fdcc9d79c4209e4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 8, 8, "\ud85a\udde8\udbfc\udcfc\uda8e\udfe3\ud9f2\udd5d\ud839\ude75\ud8db\ude02\uda17\udf57\udbc6\uddaf\ud910\udff0\udbdb\udd9c\udb5a\udd94\ud855\udc59\ud8cf\udf58\udab8\udf77\ud8c9\udd70", "\uab97\uca77\u17d5\uc71b\u44cc\u49ab\u0be0\ud4dc\ub926\u9db1\u0e10\uc45d\ubaf4\u7fd9\ub56d\u3be2\u9b63\uc802\u9f02\u972f\u27bb\u4942\u1e37\uc358\ua6fa\u9fe6\ua29f", "\udac4\ude17\ud8dd\udf48\ud95a\udeef\ud97a\udc71\uda68\udcab\udaed\udc42\ud889\udd36",
        26, 53138, -786397720, -8129364624430278535L, -92279L, false, false, (char) 51051, (char) 33051,
        Double.longBitsToDouble(0x3fd0e225855c31daL), Double.longBitsToDouble(0x3fd365bee7e485a2L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.BeanSerializerBuilder:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 18, "\ud85a\udde8\udbfc\udcfc\ud97f\ude2f\ud9f2\udd5d\udbb5\udc53\ud8db\udde3\uda17\udf57\udbc6\uddaf\ud9b6\udca3\ud9a6\ude98", "\u1a92\u6269\uc6bf\u7202\u01be\uab97", "\ud92f\udd43\uda65\udfbe\ud862\udf65\ud83a\udcef\ud8f7\udf19\ud952\udcfe\ud95c\udda7\udb70\udedb\udb8c\udddf\udbdc\ude14\udb15\ude9f\udbfd\udd51\udb01\udd80\uda8f\udd82\ud8cc\ude1c\ud804\udd74\udaf4\ude4e\ud979\udf30\ua2d3\ud822\udc32\udad3\udfd0",
        28, 25889, 978084548, -1574684148143416266L, 27728L, true, false, (char) 63106, (char) 63576,
        Double.longBitsToDouble(0x3fc0441e97e0dbc4L), Double.longBitsToDouble(0x3feeb848cedee3a5L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\0121=void |this=com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\012",
        Z.run(T, 2, 19, 2, 16, "\ud85a\udde8\udb1a\udf0d\uda8e\udfe3\ud9f2\udd5d\ud839\ude75\ud8db\ude02\uda17\udf57\udbc6\uddaf\ud910\udff0\udbdb\udd9c", "\u1a92\u6269\uc6bf\u8149\u01be", "\udbf0\udc99\udaad\ude03\uda65\udfbe\ud862\udf65\ud83a\udcef\ud9e0\udfcb\ud8ec\udee2\ud95f\udfe7\ud9fd\ude62\ud806\udfdd\udbdc\ude14",
        57, 1881, -1464847706, -6277645538535843914L, 59594L, true, true, (char) 31729, (char) 64931,
        Double.longBitsToDouble(0x3fc424da6b13690cL), Double.longBitsToDouble(0x3fd1c3a4c86dd44aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 14, 16, "\ud85a\udde8\udbfc\udcfc\uda8e\udfe3\ud9f2\udd5d\ud839\ude75\ud8db\ude02\uda17\udf57\udbc6\uddaf\ud910\udff0\udbdb\udd9c", "\u1a92\u6269\uc6bf\u8149\u01be", "\udbf0\udc99\ud92f\udd43\uda65\udfbe\ud862\udf65\ud830\ude4a\ud8f7\udf19\udbe8\udc6c\ud9aa\udcd4\udbcf\udf92\ud814\uddee\udbdc\ude14",
        57, 1881, -1464847706, -6277645538535843914L, 59594L, true, true, (char) 31729, (char) 64931,
        Double.longBitsToDouble(0x3fc424da6b13690cL), Double.longBitsToDouble(0x3fd1c3a4c86dd44aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 18, 14, "\ud85a\udde8\udbfc\udcfc\uda8e\udfe3\ud9f2\udd5d\ud839\ude75\ud8db\ude02\uda17\udf57\udbc6\uddaf\uda61\udd39\udbe9\udd4d", "\u1a92\u6269\uc6bf\u8149\u01be", "\udb78\udc93\udbe8\ude6e\uda7b\udefe\ud9cb\udc78\udbe8\udde9\udb91\uddc3\udbe6\uddaa\uda46\uddbc\ud864\ude71\uda4d\udddf\udbdc\ude14",
        57, 1881, 1823486630, -6277645538534309706L, 59594L, false, false, (char) 27532, (char) 64931,
        Double.longBitsToDouble(0x3fc424da6b13690cL), Double.longBitsToDouble(0x3fd1c3a4c86dd44aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.util.ArrayIterator:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\012",
        Z.run(T, 1, 12, 14, 16, "\ud85a\udde8\udbfc\udcfc\uda8e\udfe3\ud9f2\udd5d\ud839\ude75\uda5d\udce3\uda17\udf57\udbc6\uddaf\ud910\udff0\udbdb\udd9c", "\u500c\u2906\u6b08\u819e\u3ca7", "\udbf0\udc99\ud92f\udd43\uda65\udfbe\ud862\udf65\ud83a\udcef\ud8f7\udf19\udbe8\udc6c\ud95c\udd83\ud864\udedb\ud806\udfdd\udbdc\ude14",
        57, 1881, -1464847706, 856056273433728741L, 59594L, true, true, (char) 31729, (char) 64931,
        Double.longBitsToDouble(0x3fc424da6b136be0L), Double.longBitsToDouble(0x3fb71a4021b75128L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.BeanSerializerBuilder:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=void |this=com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\012",
        Z.run(T, 2, 7, 18, 15, "\ud854\ude44\udabd\udf42\uda8e\udfdc\ud9f2\udd5d\udbf9\udc55\ud8db\ude38\uda2f\ude95\udbfb\udef4\udb99\ude15", "\u1607\u1aa1", "\uda59\udd84\uda14\udd7e\udbe5\udc42\udbcd\udd43\udbf0\udd0e\ud92f\udd43\uda65\udfbe\ud862\udf65\uda0b\ude4d\ud8f7\udf19\udbe8\udc6c\ud95c\udd83\ud8b5\udd43\ud806\udfdd\ud9cb\udcdc\ud915\uded9\udb53\udffa\ud9d4\ude4d\ud83a\udc82\ud87f\udf5d\udaf8\udc3f\udb38\udf58\ud98f\ude5d\udad9\udc4a\u1e54\ud861\udc77\udbfa\udcc0\ud809\ude65\uda95\udc4b\ud9a4\udd1b\ud844\ude32\ud8f6\ude2e\u77ce\udb90\udc52\ud92a\udd74\udada\udc81\ud94e\ude2c\udb91\udc66\ud8ac\udef9\udb77\udce7\udab0\uddd5\ud855\udfc2\ud856\udd52",
        7, 32267, 1852098288, 4426204351585889655L, -5052L, false, false, (char) 37124, (char) 23776,
        Double.longBitsToDouble(0x3fc89caf6579e17cL), Double.longBitsToDouble(0x3fd5ef36c49a48c2L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 16, 17, "\uda4e\udd50\udba0\ude83\uda8e\udfe3\udaae\udd7b\ud94b\udc6c\ud8b0\ude0b\ua33a\udbc6\uddaf\ud910\udff0\udbdb\udd9c", "\u1a92\u6269\u07a4\u092b\u0bb0", "\udbf0\udc99\ud98a\udd09\ud830\udcfa\ud862\udfa7\ud83a\udcef\ud8f7\udf19\ud997\udf74\uda67\udc86\ud864\udedb\udbdb\udfe7\u08e8",
        41, 21290, -716269383, -6542540262421646358L, 19750L, true, false, (char) 46602, (char) 64840,
        Double.longBitsToDouble(0x3fe39a82af3c68feL), Double.longBitsToDouble(0x3fc424da6b13690cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 14, 4, "\uda4e\udd50\udba0\ude83\uda8e\udfe3\ud9f2\udd5d\ud996\udcb0\udae5\udf2a\ua33a\udbc6\uddaf\ud813\udfb2\ud813\uded9", "\uca19\u6269\u07a4\u71c2\u2a5b\uac57\uca77\u17d5\u1056\u3d9e\u4922", "\ud81e\udfb3\udaa0\udff7\uda96\udeff\ud946\udd81\u52f9\udba0\udcfa\udb9e\udcba\udb9d\ude34\ud89b\udcf2\ud802\udd88\udabd\udc37\udb95\ude0f\uda71\udc69\udace\ude9a\udbc7\udc52\u34a3\udaf8\udd85\uda8e\ude67\udb52\udfc0\uda3d\udd3f\ud8c2\udcb8\ud8ad\udfeb\udba8\udf93\uda14\udcaa\ud8cd\udd4f\uda6f\udd9e\ud95f\ude26\ud8ac\udf36",
        29, 67192, -514098470, 1457827530946023618L, 32788L, false, true, (char) 12072, (char) 64952,
        Double.longBitsToDouble(0x3f9468d140f40700L), Double.longBitsToDouble(0x3feff376f9a0f8b1L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 6, 6, "\ud80f\udf23\ud9a0\ude96\udac6\udc58\ud9f2\udd5d\ud887\udded\udb8c\udc8e\uda17\udfc6\ud9d1\udfb4\udade\uddf0\udbc8\udd66", "\u71a7\u9f34\u1121\ua00b\u01cf\u085b", "\ud902\udf54\ud97c\udcca\ud8c4\udf93\ud82c\udf67\ud8f7\udf19\udbe8\udc6c\ud95c\udd83\ud81f\udc38\ud807\udc46\udba5\udc99\uda5f\udcad\uda5e\udef9\ud835\udfcc\uda8f\udd54\ud87a\ude28\udace\ude96\udb68\udd8c\ud878\uded4\ud97b\udea1\uc554\udad3\udfd0",
        28, 25889, 978084548, -1576091522334778193L, 28709L, false, true, (char) 63776, (char) 21895,
        Double.longBitsToDouble(0x3fe0a98e6850e2ffL), Double.longBitsToDouble(0x3fdd7b016f078550L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 10, 17, "\ud85a\udde8\ud9c7\udda4\ud825\uddc1\uda61\udd5d\ud825\udf75\ud8db\ude02\uda17\udf57\udbc6\uddaf\ud910\udff0\udbdb\udd9c", "\u1a92\u6269\uc6bf\u8149\u01e5", "\udbf0\udc99\ud92f\udd43\uda65\udfbe\uda78\udc42\ud83b\uddbf\ud8f7\udf19\udbe8\udc6c\ud95c\udd83\udbf3\udf82\ud808\udcfe\udbdc\ude14",
        38, 25796, -881747227, -6277645736104339530L, -71798L, false, true, (char) 11124, (char) 15624,
        Double.longBitsToDouble(0x3fd1c3a4c95fd44aL), Double.longBitsToDouble(0x3fe5122912781fccL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.BeanSerializerBuilder:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 17, "\ud85a\udde8\ud9c7\udda4\udac6\udc58\ud9f2\udd5d\ud825\udf75\ud8db\ude02\uda17\udf57\udbc6\uddaf\ud910\udff0\udbdb\udd9c", "\u1a92\u6269\uc6bf\u8149\u01e5", "\ud898\udfe5\ud92f\udd43\uda65\udfbe\ud862\udf65\ud821\udf0a\ud8f7\udf19\udbe8\udc6c\ud95c\udd83\ud864\udedb\uda76\udff0\udb6e\udccf",
        26, 3576, -1561851602, -6340554401261725770L, 59594L, true, false, (char) 31729, (char) 64931,
        Double.longBitsToDouble(0x3fc424da6b13690cL), Double.longBitsToDouble(0x3fd1c3a4c95fd44aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 6, 10, "\udb3b\ude98\udb54\udfa0\ud8c5\udf58\ud946\uded9\u630d\ud9aa\udd20\ud8a7\udcf8\ud8d7\udd66\ud9bb\udc32", "\u570d", "\ud8c9\udd70",
        57, 86235, -558159098, -3203520408978176693L, -17451L, false, false, (char) 57340, (char) 27906,
        Double.longBitsToDouble(0x3fe43d7f0f926416L), Double.longBitsToDouble(0x3fc91326ec037d50L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\0121=new com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\012",
        Z.run(T, 2, 19, 3, 17, "\ud85a\udde8\ud9c7\udda4\udac6\udc58\ud9f2\udd5d\ud825\udf75\ud8db\ude02\uda17\udf57\udbc6\uddaf\ud910\udff0\udbdb\udd9c", "\u1a92\u6269\uc6bf\u8149\u01e5", "\udbf0\udc99\ud92f\udd43\uda65\udfbe\ud862\udf65\ud821\udf0a\ud8f7\udf19\udbe8\udc6c\ud95c\udd83\ud864\udedb\ud806\udfdd\udb50\udf2f",
        36, 25796, -881747227, -6277645736104339530L, -48384L, true, false, (char) 29003, (char) 64931,
        Double.longBitsToDouble(0x3fc424da6b13690cL), Double.longBitsToDouble(0x3fd1c3a4c95fd44aL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 8, 10, "\udb03\udffb\ud9c7\udda4\udac6\udc58\uda03\udf5d\udae3\udf74\ud8db\ude02\uda17\udf57\ud98c\udcd1\ud909\udd92\ud818\uddad\ud997\udc76\u8be7\udae3\udda2\udb2e\uddd8\ud8b7\udfcd\udb3d\udda8\uda19\udecd\ud820\udd10\ud8f7\udc8a\udbf0\udc99", "\u49ab\u814e", "\ud88e\udcaf\udb47\uddc2\ud806\udfdd\udbdc\ude14\ud882\udf86\ud836\udd00\ud835\udfcc\uda8f\udd54\ud87a\ude28\ud820\udc1f\ud897\udf91\udabf\ude42\ud97b\udf7d",
        27, 37018, 651399158, -2719324659487317308L, 83675L, false, false, (char) 33719, (char) 64073,
        Double.longBitsToDouble(0x3fe05e15d1edaadcL), Double.longBitsToDouble(0x3fecb9117ebcbdbfL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.BeanSerializerBuilder:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=com.fasterxml.jackson.databind.util.ArrayIterator:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\012",
        Z.run(T, 2, 7, 12, 18, "\ud85a\udde8\ud910\udd06\u93e3\ud81d\udf11\ud90d\ude24\ud8db\udde3\uda17\udf57\udbc6\uddaf\ud9b6\udca3\ud96c\udeba\uda16\udd8c\ud855\udc59\udbda\udc48\ud94c\ude60\ud8c9\udd70\ud882\udc42\ud962\udd81\ud897\udf91\u8629\udb9d\udffb\udbed\udc8d\uda65\udfbe", "\ud4ad\u9d04\uc999\ube11\u5b6d\ubae1", "\udb01\udd80\ud9bc\udfb3\ud903\udcf9\udad4\ude32",
        37, 75386, -1795509130, -1547090418483490470L, 97793L, false, true, (char) 8942, (char) 27054,
        Double.longBitsToDouble(0x3fe05a8a57ac3ef6L), Double.longBitsToDouble(0x3fe24aa01af042b4L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.BeanSerializerBuilder:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=com.fasterxml.jackson.databind.ser.BeanSerializerBuilder:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\012",
        Z.run(T, 2, 7, 7, 18, "\ud85a\udde8\udbfc\udcfc\ud97f\ude2f\ud9f2\udd5d\udbb5\udc53\ud8db\udde3\uda17\udf57\udbc6\uddaf\ud9b6\udca3\ud9a6\ude98", "\u1a92\u6269\uc6bf\u7202\u01be\uab97", "\ud92f\udd43\uda65\udfbe\ud862\udf65\ud83a\udcef\ud8f7\udf19\ud952\udcfe\ud95c\udda7\udb70\udedb\udbb0\udf38\udbdc\ude14\udb15\ude9f\udbfd\udd51\udb01\udd80\uda8f\udd82\ud8cc\ude1c\ud804\udd74\udaf4\ude4e\ud979\udf30\ua2d3\ud822\udc32\udad3\udfd0",
        28, 25889, -1624321084, 2824376998917410024L, 27644L, true, false, (char) 62613, (char) 63576,
        Double.longBitsToDouble(0x3fc0441e97e0dbc4L), Double.longBitsToDouble(0x3feeb848cedee3a5L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\0121=void |this=com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\012",
        Z.run(T, 2, 18, 18, 14, "\ud85a\udde8\udbfc\udcfc\uda98\ude88\ud9b9\udd17\ud839\udde7\ud8db\ude02\ud920\ude1c\ue782\ud9e1\uddb1\udbe9\udd4d", "\u1a92\u6269\uc6bf\u6363\u4c5b", "\udb78\udc93\udbe8\ude6e\uda7b\udefe\ud9cb\udc78\udbe8\udde9\udb91\uddc3\udbe6\uddaa\udb0c\udc7f\udaa5\udeaf\ud823\udc49\ud88a\uddb1",
        43, 89129, 1504916019, -5539315792730536227L, 59594L, false, false, (char) 27532, (char) 41891,
        Double.longBitsToDouble(0x3fc424da6b13690cL), Double.longBitsToDouble(0x3fd1c3a4c52ad21aL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 8, 10, "\udb03\udffb\ud9c7\udda4\udac6\udc58\uda03\udf5d\udba8\ude17\ud8db\ude50\udb31\udf84\udb13\udf0b\ud8bc\udfab\udbc3\udf61\ud982\udd7d\u8c1b\udaa8\udecc\udb2e\uddd8\uefaf\udb3d\udd8f\uda19\udecd\ud820\udd10\ud8f7\udc8a\ud92a\udfee", "\u0752\u814e\u827e\u312b\ud6d6\u7803\uc45d\ubaf4\u528f\ucb51\ua49a\u9b35\uc802\ubf7f\u5203\ubff2\u4a1e", "\udaf8\ude3f\uda8e\ude67\ud9f9\udda7\ud913\udfd2\udb61\udfdc\udb71\udede\ud8fc\ude5c\ud8db\ude37\ud943\udd13\uda52\udd8e",
        1, 31125, -859882601, 6853632528113886459L, -58716L, false, false, (char) 23895, (char) 37029,
        Double.longBitsToDouble(0x3fc2c1b311676ec8L), Double.longBitsToDouble(0x3fe33f1b86686655L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.util.ArrayIterator:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\0121=com.fasterxml.jackson.databind.util.ArrayIterator:@? |this=com.fasterxml.jackson.databind.ser.BeanSerializerFactory:@?\012",
        Z.run(T, 2, 12, 12, 18, "\u05b9\ud910\udd23\u93e3\ud81d\udf11\ud90d\ude24\ud8db\udde3\uda2b\udd20", "\u53af\uabf3", "\ud94c\ude60\ud8c9\udd70\ud882\udc42\ud962\udd81\ud897\udf91\u8629",
        0, 25230, 1505313397, -8850308177968016607L, 62937L, false, true, (char) 37641, (char) 29877,
        Double.longBitsToDouble(0x3f9a82c3cc2c8700L), Double.longBitsToDouble(0x3fdb4891b54d04c8L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\012",
        Z.run(T, 1, 19, 6, 0, "\021", "\u410d", "\uda17\udf57\udbc6\uddaf",
        30, 31713, -310443860, -8806802760054802000L, 78635L, true, false, (char) 584, (char) 46143,
        Double.longBitsToDouble(0x3fe94ef5dd4bd38aL), Double.longBitsToDouble(0x3fcf670488000000L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.ser.AnyGetterWriter:@?\012",
        Z.run(T, 1, 19, 14, 16, "\ud85a\udde8\udbfc\udcfc\uda8e\udfe3\ud9f2\udd5d\ud839\ude75\ud8db\ude02\uda17\udf57\udbc6\uddaf\ud910\udff0\udbdb\udd9c", "\u1a92\u6269\uc6bf\u8149\u01be", "\udbf0\udc99\ud92f\udd43\uda65\udfbe\ud862\udf65\ud83a\udcef\ud8f7\udf19\udbe8\udc6c\ud95c\udd83\ud864\udedb\ud806\udfdd\udbdc\ude14",
        57, 1881, -1464847706, -2458593054525663306L, 59594L, true, true, (char) 31729, (char) 64931,
        Double.longBitsToDouble(0x3fc424da6b13690cL), Double.longBitsToDouble(0x3fd1c3a4c86dd44aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ser.AnyGetterWriter|getAndFilter|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.ser.PropertyFilter|new:com.fasterxml.jackson.databind.ser.AnyGetterWriter:com.fasterxml.jackson.databind.BeanProperty,com.fasterxml.jackson.databind.introspect.AnnotatedMember,com.fasterxml.jackson.databind.JsonSerializer",
    "M|com.fasterxml.jackson.databind.ser.AnyGetterWriter|getAndSerialize|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.AnyGetterWriter:com.fasterxml.jackson.databind.BeanProperty,com.fasterxml.jackson.databind.introspect.AnnotatedMember,com.fasterxml.jackson.databind.JsonSerializer",
    "M|com.fasterxml.jackson.databind.ser.AnyGetterWriter|resolve|com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.AnyGetterWriter:com.fasterxml.jackson.databind.BeanProperty,com.fasterxml.jackson.databind.introspect.AnnotatedMember,com.fasterxml.jackson.databind.JsonSerializer",
    "C|com.fasterxml.jackson.databind.ser.AnyGetterWriter|<init>|com.fasterxml.jackson.databind.BeanProperty,com.fasterxml.jackson.databind.introspect.AnnotatedMember,com.fasterxml.jackson.databind.JsonSerializer",
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|constructBeanSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|_constructWriter|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition,com.fasterxml.jackson.databind.type.TypeBindings,com.fasterxml.jackson.databind.ser.PropertyBuilder,boolean,com.fasterxml.jackson.databind.introspect.AnnotatedMember|new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|_createSerializer2|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription,boolean|new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|constructBeanSerializerBuilder|com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|constructFilteredBeanWriter|com.fasterxml.jackson.databind.ser.BeanPropertyWriter,[Ljava.lang.Class;|new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|constructObjectIdHandler|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanDescription,java.util.List|new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|constructPropertyBuilder|com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|createSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|customSerializers||new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|filterBeanProperties|com.fasterxml.jackson.databind.SerializationConfig,com.fasterxml.jackson.databind.BeanDescription,java.util.List|new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|findBeanProperties|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanDescription,com.fasterxml.jackson.databind.ser.BeanSerializerBuilder|new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|findBeanSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
    "M|com.fasterxml.jackson.databind.ser.AnyGetterWriter|getAndFilter|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.ser.PropertyFilter|new:com.fasterxml.jackson.databind.ser.AnyGetterWriter:com.fasterxml.jackson.databind.BeanProperty,com.fasterxml.jackson.databind.introspect.AnnotatedMember,com.fasterxml.jackson.databind.JsonSerializer",
    "M|com.fasterxml.jackson.databind.ser.AnyGetterWriter|getAndSerialize|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.AnyGetterWriter:com.fasterxml.jackson.databind.BeanProperty,com.fasterxml.jackson.databind.introspect.AnnotatedMember,com.fasterxml.jackson.databind.JsonSerializer",
    "M|com.fasterxml.jackson.databind.ser.AnyGetterWriter|resolve|com.fasterxml.jackson.databind.SerializerProvider|new:com.fasterxml.jackson.databind.ser.AnyGetterWriter:com.fasterxml.jackson.databind.BeanProperty,com.fasterxml.jackson.databind.introspect.AnnotatedMember,com.fasterxml.jackson.databind.JsonSerializer",
    "C|com.fasterxml.jackson.databind.ser.AnyGetterWriter|<init>|com.fasterxml.jackson.databind.BeanProperty,com.fasterxml.jackson.databind.introspect.AnnotatedMember,com.fasterxml.jackson.databind.JsonSerializer",
    "M|com.fasterxml.jackson.databind.ser.BeanSerializerFactory|constructBeanSerializer|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanDescription|new:com.fasterxml.jackson.databind.ser.BeanSerializerFactory:com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
