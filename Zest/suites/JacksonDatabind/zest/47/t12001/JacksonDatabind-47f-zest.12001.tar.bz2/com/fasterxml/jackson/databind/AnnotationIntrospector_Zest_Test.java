package com.fasterxml.jackson.databind;
import org.junit.Test;
import static org.junit.Assert.*;
public class AnnotationIntrospector_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\0121=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\012",
        Z.run(T, 2, 12, 14, 15, "\ud9ba\udcde\udb07\udd07\udb85\ude29\ud873\ude56\ud9c0\ude3c\udbed\udd68\udbc8\udcee\udbd2\ude0a\ud8f9\udf6d\ud9e9\udc7b\udbf0\udddf", "\uac8f\u83e1\u561e\u5378\u971b\u6697\ud15c\u8381\ua479\u4087\u0b60\ub4c9\u740f\u7759\ucde6\ucb18\u6aa5\u026d\ub794\u6302\u9e88\u1032\u804e", "\ud88b\udeb3\udb9e\udc0d\uda59\udfcc\udb5e\udc81\ud8e4\udf28\udb92\udf88\ud9e9\udc5c\uda2c\udd9b\udac4\udf83\udb5a\udc3e\ud9c6\udeda\ud94f\udf2c\udbc5\udea7\ud815\udccc\udba3\udd7a\ud88f\udd93\udada\udfce\udba0\udf34\udbee\udcb8\uda73\udd08\udb39\ude3e",
        27, 16237, -312317388, 1472010484874007392L, -24016L, false, false, (char) 10137, (char) 4090,
        Double.longBitsToDouble(0x3fdff21fa6060ea4L), Double.longBitsToDouble(0x3fd08466dda0bad4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\0121=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\012",
        Z.run(T, 2, 12, 14, 15, "\ud9ba\udcde\udb07\udd07\udb85\ude29\ud873\ude56\ud9c0\ude3c\udbed\udd68\udbc8\udcee\udbd2\ude0a\ud929\ude24\ud9dc\udced\udbf0\udddf", "\uac8f\u83e1\u561e\u5378\u971b\u6697\ud15c\u8381\ua479\u4087\u0b60\ub4c9\u740f\u7759\ucde6\ucb18\u6aa5\u026d\ub794\u6302\u9e88\u1032\u804e", "\ud88b\udeb3\udb9e\udc0d\uda59\udfcc\udb5e\udc81\ud8e4\udf28\udb92\udf88\ud9e9\udc5c\uda2c\udd9b\udac4\udf83\udb5a\udc3e\ud9c6\udeda\ud94f\udf2c\udbc5\udea7\ud815\udccc\udba3\udd7a\ud88f\udd93\udada\udfce\ud8db\udeb0\udbea\ude79\uda73\udd08\udb39\ude3e",
        27, 16237, -312317388, 1472010484874007392L, -24016L, false, false, (char) 10137, (char) 4090,
        Double.longBitsToDouble(0x3fdff21fa6060ea4L), Double.longBitsToDouble(0x3fd08466dda0bad4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 14, 15, "\udb82\udf68\udb07\udd07\udb85\ude29\ud873\ude56\ud9c0\ude3c\udbed\udd68\udbc8\udcee\udbd2\ude0a\ud8f9\udf6d\ud9e9\udc7b\udbf0\udddf\ud91d\udec8\ud999\udcb8\udaf6\udc5e\udb13\udd20\ud996\udf3a\udb62\udfa6\uda33\udca4\uda1a\udd67\u106d\udad3\udc73\u2932\udbec\udd17\uda39\udc80", "\u5a8e\ucde6", "\ud872\udd9f\ud8d3\udd7a\ud993\udf42\ud8aa\uddaf\ud862\udfea\u88ed\ud846\udca5\uda75\udd15\ud88b\udeb3\udb48\udc02",
        37, 53373, -2073699727, 2354223288331189119L, 10168L, true, false, (char) 20875, (char) 58516,
        Double.longBitsToDouble(0x3fe9fe0dbba5b21cL), Double.longBitsToDouble(0x3fdc5138f0876e6cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\0121=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\012",
        Z.run(T, 2, 12, 14, 15, "\ud9ba\udcde\udb07\udd07\udb85\ude29\ud92c\udc53\ud9c0\ude3c\udbed\udd68\udbc8\udcee\udbd2\ude0a\ud8f9\udf6d\ud9e9\udc7b\udbf0\udddf", "\uac8f\u83e1\u561e\u5378\u971b\u6697\ud15c\u8381\ua479\u4087\u0b60\ub4c9\u740f\u7759\ucde6\ucb18\u6aa5\u026d\ub794\u6302\u9e88\u1032\u804e", "\ud88b\udeb3\udb9e\udc0d\uda59\udfcc\udb5e\udc81\ud8e4\udf28\udb92\udf88\ud9e9\udc5c\uda2c\udd9b\udac4\udf83\udb5a\udc3e\ud9c6\udeda\ud94f\udf2c\udbc5\udea7\ud815\udccc\udba3\udd7a\ud88f\udd93\udada\udfce\udba0\udf34\udbee\udcb8\uda73\udd08\udb39\ude3e",
        27, 64253, -315715617, 1472010484874007392L, -24016L, false, false, (char) 10137, (char) 4090,
        Double.longBitsToDouble(0x3fdff21fa6060ea4L), Double.longBitsToDouble(0x3fd08466dda0bad4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 3, 15, "\ud9ba\udcde\udb07\udd07\udb85\ude29\ud873\ude56\ud9c0\ude3c\udbed\udd68\udbc8\udcee\udbd2\ude0a\ud8f9\udf6d\ud981\udc87", "\u5e80\u2b14\u03f5\u814f\u16e1\ub50e\u6697\ud15c\u8381\ua479\u4087\u0b60\ub4c9", "\udad4\udee1\ud5d8\ud8eb\udea6\ud872\udd9f\ud8d3\udd7a\ud993\udf42\ud8aa\uddaf\ud862\udfea\u88ed\ud846\udca5\uda75\udd15\ud88b\udeb3",
        29, 15612, -403844627, -8906472508640992868L, 61385L, false, false, (char) 20265, (char) 20875,
        Double.longBitsToDouble(0x3fe93f38633fc124L), Double.longBitsToDouble(0x3fed2d90e1c5138fL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\0121=java.util.ArrayList:@? |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\012",
        Z.run(T, 2, 12, 5, 15, "\ud9ba\udcde\udb07\udd07\udb85\ude29\ud873\ude56\ud9c0\ude3c\udbed\udd68\udbc8\udcee\udbd2\ude0a\ud8f9\udf6d\ud9e9\udc7b\udbf0\udddf", "\uac8f\u83e1\u561e\u5378\u971b\u6697\ud15c\u8381\ua479\u4087\u0b60\ub4c9\u740f\u7759\ucde6\ucb18\u6aa5\u026d\ub794\u6302\u9e88\u1032\u804e", "\ud88b\udeb3\udb9e\udc0d\uda59\udfcc\udb5e\udc81\ud8e4\udf28\udb92\udf88\ud9e9\udc5c\udb49\udfe9\udac4\udf83\udb5a\udc3e\ud9c6\udeda\ud94f\udf2c\udbc5\udea7\ud815\udccc\udba3\udd7a\ud88f\udd93\udada\udfce\udba0\udf34\udbee\udcb8\uda73\udd08\udb39\ude3e",
        27, 16237, -312317388, 1472010484874007392L, -24016L, false, false, (char) 10137, (char) 4090,
        Double.longBitsToDouble(0x3fdff21fa6060ea4L), Double.longBitsToDouble(0x3fd08466dda0bad4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 12, 15, "\ud9ba\udcde\udb07\udd07\udb85\ude29\ud873\ude56\ud9c0\ude3c\udbed\udd68\ud92c\udde0\ud951\udc32\ud903\ude4f\ud9e9\udc7b\udbf0\udddf", "\uac8f\u349f\u561e\u5378\u971b\u6697\ud15c\u8381\ua479\u4087\u0b60\ub4c9\u740f\u7759\ubb32\u81e0\u6aa5\u026d\ub794\u6302\u9e88\u1032\u804e", "\ud88b\udeb3\ud981\udc0a\uda59\udfcc\udb5e\udc81\ud8e4\udf28\udb92\udf88\ud9e9\udc5c\uda2c\udd9b\udac4\udf83\udb5a\udc3e\ud9c6\udeda\ud95d\udd12\ud9f4\udcaa\ud815\udccc\udba3\udd7a\ud88f\udd93\udada\udfce\udba0\udf34\udbee\udcb8\uda73\udd08\udb39\ude3e",
        27, 16237, -312317388, 1472010484874007392L, -24016L, false, false, (char) 10137, (char) 4090,
        Double.longBitsToDouble(0x3fdff21fa6060ea4L), Double.longBitsToDouble(0x3fd244501da0bad4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\0121=java.util.Collections$SingletonList:@? |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\012",
        Z.run(T, 2, 12, 4, 11, "\ud9ba\udcde\udb07\udd07\udb85\ude29\ud9b9\ude59\ud9c0\ude3c\udbed\udd68\udbc8\udcee\udbd2\ude0a\udb5c\ude9e\uda59\udf1c\u701b\ud91d\udec8", "\u83e1\u561e\u5378\u971b\u6697\ud15c\u8381\ua479\ud79d\u0bf4\ub4c9\u740f\u7759\ucde6\u7fd6\u7b15", "\ud993\udf42\udb3b\udc1f\ud8b7\udd54\u89c5\ud846\udca5\uda75\udd15",
        8, 41059, -481955458, -1734499467704018319L, 79071L, true, true, (char) 44708, (char) 20430,
        Double.longBitsToDouble(0x3fe4101848d849bdL), Double.longBitsToDouble(0x3fe7c6f72ba5b2eeL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 3, 15, "\ud9ba\udcde\udb07\udd07\udb85\ude29\ud873\ude56\ud9c0\ude3c\udbed\udd68\udbc8\udcee\udbd2\ude0a\ud8f9\udf6d\ud9e9\udc7b\udbf0\udddf", "\uac8f\u83e1\u561e\u5378\u971b\u6697\ud15c\u8381\ua479\u4087\u0b60\ub4c9\u740f\u7759\ucde6\ucb18\u6aa5\u026d\ub794\u6302\u9e88\u1032\u804e", "\ud88b\udeb3\udb9e\udc0d\uda59\udfcc\udb5e\udc81\ud8e4\udf28\udb92\udf88\ud9e9\udc5c\uda2c\udd9b\udac4\udf83\udb5a\udc3e\ud9c6\udeda\ud94f\udf2c\udbc5\udea7\ud815\udccc\udba3\udd7a\ud88f\udd93\udada\udfce\udba0\udf34\udbee\udcb8\uda73\udd08\udb39\ude3e",
        27, 16237, -312317388, 1472010484874007392L, -24016L, false, false, (char) 10137, (char) 4090,
        Double.longBitsToDouble(0x3fdff21fa6060ea4L), Double.longBitsToDouble(0x3fd08466d36d8cd4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 0, 15, "\ud9ba\udcde\udb07\udd07\udb85\ude29\ud873\ude56\ud9c0\ude3c\udbed\udd68\udbc8\udcee\udbd2\ude0a\ud8f9\udf6d\ud9e9\udc7b\udbf0\udddf", "\uac8f\u83e1\u561e\u5378\u861b\u6697\ud15c\u8381\ua479\u4087\u0b60\ub4c9\u3164\u5bcd\ucde6\ucb18\u6aa5\u026d\ub794\u6302\u9e88\u1032\u804e", "\ud88b\udeb3\udb9e\udc0d\uda59\udfcc\udb5e\udc81\ud8e4\udf28\udb92\udf88\ud9e9\udc5c\uda2c\udd9b\ud90c\ude17\udb5a\udc3e\ud9c6\udeda\ud94f\udf2c\udbc5\udea7\ud815\udccc\udba3\udd7a\ud88f\udd93\udada\udfce\udba0\udf34\udbee\udcb8\uda73\udd08\udb39\ude3e",
        27, 16237, -312317388, 1472010485377323872L, -89552L, false, false, (char) 10137, (char) 4090,
        Double.longBitsToDouble(0x3fdff21fa9900ea4L), Double.longBitsToDouble(0x3fd0a6998da0bad4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\0121=void |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\012",
        Z.run(T, 2, 11, 6, 15, "\ud9ba\udcde\udb07\udd07\udb85\ude29\ud873\ude56\ud9c0\ude3c\udbed\udd68\udbc8\udcee\udbd2\ude0a\ud8f9\udf6d\ud9e9\udc7b\udbf0\udddf", "\uac8f\u83e1\u561e\u5378\u971b\u6697\ud15c\u8381\ua479\u4087\u0b60\ub4c9\u740f\u7759\ucde6\u3005\u6ad1\u026d\ub794\u6302\u9e88\u1032\u804e", "\ud88b\udeb3\udb9e\udc0d\uda59\udfcc\udb5e\udc81\ud8e4\udf28\udb92\udf88\ud9e9\udc5c\udbba\ude9c\udac4\udf8d\udb5a\udc3e\ud9c6\udeda\ud94f\udf2c\udbc5\udea7\ud815\udccc\udba3\udd7a\ud88f\udd93\udada\udfce\udba0\udf34\udbee\udcb8\uda73\udd08\udb39\ude3e",
        27, 16237, -312317388, 1472010484874007392L, -24016L, false, false, (char) 10137, (char) 4090,
        Double.longBitsToDouble(0x3fdff21fa6060ea4L), Double.longBitsToDouble(0x3fd08466dda0bad4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "\ud9ba\udcde\udb07\udd07\udb85\ude29\ud873\ude56\ud9c0\ude3c\udbed\udd68\udbc8\udcee\udbd2\ude0a\ud8e2\udd6d\ud963\udc78\udbf0\udddf", "\uab98", "\udb62\udfa6",
        3, 27088, 1086489756, -5178804565408154100L, -37894L, true, true, (char) 38346, (char) 38143,
        Double.longBitsToDouble(0x3fdd7b71bcd113dcL), Double.longBitsToDouble(0x3fea9fb3adc47c4dL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\012",
        Z.run(T, 1, 12, 14, 15, "\ud9ba\udcde\udb07\udd07\udb85\ude29\ud873\ude56\ud9c0\ude3c\udbed\udd68\udbc8\udcee\udbd2\ude0a\ud8f9\udf6d\ud9e9\udc7b\ud9a3\ude63", "\uac0e\u83e1\u561e\u5378\u971b\u6733\ud15c\u5c65\ud6b8\u4087\u0b60\ub4c9\u740f\u7759\ucde6\ucb18\u6aa5\u026d\ub794\u6302\u9e88\u1032\u804e", "\ud88b\udeb3\udb9e\udc0d\uda59\udfcc\udb5e\udc81\ud8e4\udf28\uda07\ude02\udb8e\udeb1\uda2c\udd9b\udac4\udf83\udb5a\udc3e\ud9c6\udeda\ud94f\udf2c\udbc5\udea7\ud962\udc33\udba3\udd7a\uda47\udf66\udada\udfce\udba0\udf34\ud9c2\ude63\uda73\udd24\udb39\ude3e",
        27, 16307, -312317388, 1472010484874007392L, -24016L, false, false, (char) 10137, (char) 4090,
        Double.longBitsToDouble(0x3fdff21fa6060ea4L), Double.longBitsToDouble(0x3fd08466dda0bad4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\0121=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\012",
        Z.run(T, 2, 13, 13, 15, "\ud9ba\udcde\udb07\udd07\udb85\ude29\ud873\ude56\ud9c0\ude3c\ud9fa\udfb8\udbc8\udc23\udbd2\ude0a\ud8f9\udf6d\ud9e9\udc7b\udbf0\udddf", "\uac8f\u83e1\u0e4b\ub2b2\u971b\u6697\ud15c\u8381\ua479\u4087\u0b60\ub4c9\u740f\u7759\ucde6\ucb18\u6aa5\u026d\ub794\u6302\u9e88\u1032\u804e", "\ud88b\udeb3\udb9e\udc0d\uda59\udfcc\udb5e\udc81\ud8e4\udf28\udb92\udf88\ud9e9\udc5c\uda2c\udd9b\udac4\udf83\udb5a\udc3e\ud9c6\udeda\ud94f\udf2c\udbc5\udea7\ud815\udccc\udba3\udd7a\ud88f\udd93\udada\udfce\udba0\udf34\udbee\udcb8\uda73\udd08\udb39\ude3e",
        27, 16237, -314893516, 1472010484874007392L, -24016L, false, false, (char) 10137, (char) 4090,
        Double.longBitsToDouble(0x3fdff21fa6060ea4L), Double.longBitsToDouble(0x3fd08466dda0bad4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 14, 15, "\ud9ba\udcde\udb07\udd07\udb85\ude29\ud873\ude56\ud9c0\ude3c\udbed\udd68\udbc8\udcee\udbd2\ude0a\ud8f9\udf6d", "\u4209\u5e80\uac8f\u83e1\u561e\u5378\u971b\u6697", "\u2932\udbec\udd17",
        27, 80711, 1457052961, -5252439899102117417L, 94733L, false, true, (char) 21522, (char) 9674,
        Double.longBitsToDouble(0x3fe496fe85723e86L), Double.longBitsToDouble(0x3fe554d201ab1971L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\0121=java.util.Collections$SingletonList:@? |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\012",
        Z.run(T, 2, 12, 4, 15, "\ud9ba\udcde\udad2\ude5c\udb95\udf3d\uda3f\ude5c\ud9c0\ude3c\udbed\udd68\uda18\udfdd\ud8a2\udd7b\u6b5d\udba3\udfb3\ud8f4\udf3c", "\uac8f\u83e1\u568e\u5378\u971b\u6697\ud15c\u8381\ua479\u4087\u8363\ub4c9\u977d\u9214\ucde6\u7364\u8210", "\ud993\udf42\ud8aa\uddaf\ud862\udfea\u88ed",
        6, -880, 606801328, 2000792447904313726L, -67951L, false, false, (char) 9023, (char) 63332,
        Double.longBitsToDouble(0x3fe2c00232fa57bdL), Double.longBitsToDouble(0x3fe410184ad849bdL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\0121=void |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\012",
        Z.run(T, 2, 6, 6, 15, "\uda83\uddc2\udb07\udca2\udb85\ude29\ud873\ude56\ud9c0\ude3c\udbed\udd68\udbc8\udcee\udbd2\ude0a\ud929\ude24\u021f\udbf0\udde4", "\uac8f\u83e1\u561e\u5378\u971b\u6697\ud15c\u8381\ua479\u4087\u0b60\ub4c9\u740f\u7759\ucde6\ucb18\u6aa5\u026d\ub794\u6302\u9e88\u92c7\ud1e6", "\uae26\udb9e\udc0d\uda59\udfcc\udb5e\udc81\ud8e4\udf28\udb92\udf88\udb2a\udcb7\uda42\udfb2\udac4\udf83\uae4c\ud9c6\udeda\ud9c4\udddf\udbc5\udea7\ud815\udccc",
        18, 83979, -1895255433, -8395451265230350288L, 55203L, false, true, (char) 7087, (char) 3206,
        Double.longBitsToDouble(0x3fe2544cb730fc2bL), Double.longBitsToDouble(0x3fe1d67756ff009aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.util.Collections$SingletonList:@? |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\0121=java.util.ArrayList:@? |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\012",
        Z.run(T, 2, 4, 5, 0, "\u38e9\ud895\udfb6\ud8f9\ude45\udbd9\udffe\ud8d9\udff7\ud694\udbc8\udcf7\udbd2\ude0a\ud8f9\udf6d\ud9e9\udc7b\udb60\udcd2\ud850\ude83\ud999\udcb8\udae8\ude6a\udb13\udd21\ud996\udf3a\udb62\udfa6\uda33\udca4\ud84d\uddf5\u106d\ud861\ude1a\udb92\udf93\udbec\udcc5\uda39\udc80", "\u52c1\ucde6\ucb18\u6aa5\u026d\ub794\u6302\u9e88\u2468\u7f26\u91b3", "\udb48\udc3d\uda59\udfcc\udb5e\udc81\ud8e4\udf28\udb92\udf88",
        5, 53727, 1472048728, 257540881848819842L, -72920L, true, true, (char) 22995, (char) 45427,
        Double.longBitsToDouble(0x3fea6c529cc81b8bL), Double.longBitsToDouble(0x3fd13a500801d4f6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 12, "\ud9f4\ude77\udb07\udd07\udb85\ude29\udb98\udc68\ud9c0\uded0\udbed\udd68\udbc8\udcee\ud985\udd5b\ud8f9\udf6f\udad8\udff3\ud828\uddd7\ud936\udfa6\ud999\udcb8\ud88a\ude89\udaf8\udf5d\uda0b\udeb4\udb62\udfaf\uda33\udca4\uda1a\udd67\u106d\udad3\udc73\u2932\udbec\udd17\uda91\udc0b", "\u5ae2\u694a\u20bb", "\ud8d3\udd7a\ud993\udf42\ud8aa\uddaf\uda42\udeda\udb4d\udca9",
        39, 58631, -585343959, 1947910763679445374L, -90385L, false, true, (char) 56361, (char) 4229,
        Double.longBitsToDouble(0x3fe2c002681157bdL), Double.longBitsToDouble(0x3fe410184ad849bdL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.util.ArrayList:@? |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\0121=java.util.ArrayList:@? |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\012",
        Z.run(T, 2, 5, 5, 15, "\ud9ba\udcde\udb07\udd07\udb85\ude29\ud873\ude56\ud9c0\ude3c\ud863\udd63\udbc8\udcee\udbd2\ude0a\ud8f9\udf6d\ud9e9\udc7b\udbf0\udddf", "\uac8f\u83e1\u561e\u5378\u971b\u6697\ud15c\u8381\ua479\u4087\u0b60\ub4c9\u740f\u7759\ucde6\ucb18\u6aa5\u026d\ub794\u6302\u9e88\u1032\u804e", "\ud88b\udeb3\udb9e\udc0d\uda59\udfcc\udb5e\udc81\ud8e4\udf28\udb92\udf88\ud9e9\udc5c\udb49\udfe9\uda0e\udfe9\udbf2\uddd0\udb06\udd99\ud94f\udf2c\udbc5\udea7\ud815\udccc\udba3\udd7a\ud88f\udd93\udada\udfce\udba0\udf34\udbee\udcb8\uda73\udd08\udb39\ude3e",
        27, 16237, -312317388, 1472010484874007392L, -24016L, false, false, (char) 37267, (char) 4149,
        Double.longBitsToDouble(0x3fdff21fa6060ea4L), Double.longBitsToDouble(0x3fd08466dda0bad4L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\0121=null |this=com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector$1:@?\012",
        Z.run(T, 2, 12, 14, 15, "\ud9ba\udcde\udb07\udd07\udb85\ude29\ud873\ude56\ud9c0\ude3c\udbed\udd68\udbc8\udcee\udbd2\ude0a\ud8f9\udf6d\ud9e9\udc7b\udbf0\udddf", "\uac8f\u83e1\u561e\u5378\u971b\u6697\ud15c\u1c1a\uc56a\u4087\u0b60\ub4c9\u740f\u7759\ucde6\ucb18\u6aa5\u026d\u59d8\u4dff\u3970\u1032\uc54e", "\ud88b\udeb3\udb9e\udc0d\uda59\udfcc\udb5e\udc81\ud8e4\udf28\udb92\udf88\udbcf\udf8e\uda2c\udd9b\udac4\udf83\udb5a\udc3e\ud9c6\udeda\ud94f\udf2c\udbc5\udea7\ud815\udccc\uda8b\udcd2\ud9ef\udcd8\udab1\udef3\udba0\udf34\udbee\udcb8\uda73\udd08\udb39\ude3e",
        27, 16237, -312317388, 1472010484874007392L, -24016L, false, false, (char) 10137, (char) 4090,
        Double.longBitsToDouble(0x3fdff21fa6060ea4L), Double.longBitsToDouble(0x3fd08466dda0bad4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|refineSerializationType|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JavaType|fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|_findAnnotation|com.fasterxml.jackson.databind.introspect.Annotated,java.lang.Class|fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|_hasAnnotation|com.fasterxml.jackson.databind.introspect.Annotated,java.lang.Class|fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|_hasOneOf|com.fasterxml.jackson.databind.introspect.Annotated,[Ljava.lang.Class;|fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|allIntrospectors||fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|allIntrospectors|java.util.Collection|fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|findAndAddVirtualProperties|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.AnnotatedClass,java.util.List|fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|findAutoDetectVisibility|com.fasterxml.jackson.databind.introspect.AnnotatedClass,com.fasterxml.jackson.databind.introspect.VisibilityChecker|fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|findClassDescription|com.fasterxml.jackson.databind.introspect.AnnotatedClass|fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|findContentDeserializer|com.fasterxml.jackson.databind.introspect.Annotated|fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|findContentSerializer|com.fasterxml.jackson.databind.introspect.Annotated|fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|findCreatorBinding|com.fasterxml.jackson.databind.introspect.Annotated|fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|findDeserializationContentConverter|com.fasterxml.jackson.databind.introspect.AnnotatedMember|fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|findDeserializationContentType|com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JavaType|fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|findDeserializationConverter|com.fasterxml.jackson.databind.introspect.Annotated|fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|findDeserializationKeyType|com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JavaType|fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
    "M|com.fasterxml.jackson.databind.AnnotationIntrospector|refineSerializationType|com.fasterxml.jackson.databind.cfg.MapperConfig,com.fasterxml.jackson.databind.introspect.Annotated,com.fasterxml.jackson.databind.JavaType|fac:com.fasterxml.jackson.databind.AnnotationIntrospector:nopInstance:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
