package com.fasterxml.jackson.databind.deser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class UntypedObjectDeserializer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 3, 2, "\ud8cf\udc50\uda58\udc12", "\u2c4b", "\ud809\udee0\ud91f\uddac\udba2\udee3\uda3b\ude6d",
        8, 72543, -440786019, -3022841272666755376L, 6657L, false, false, (char) 32193, (char) 12137,
        Double.longBitsToDouble(0x3fe694f84ce42be7L), Double.longBitsToDouble(0x3fc9d965c1310088L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 3, 2, "\ud8cf\udc50\uda58\udc12", "\u2c4b", "\ud809\udee0\ud91f\uddac\udba2\udee3\uda3b\ude6d",
        8, 72543, -440786019, -3022841272666755376L, 6657L, false, false, (char) 42177, (char) 12137,
        Double.longBitsToDouble(0x3fe694f84ce42be7L), Double.longBitsToDouble(0x3fc9d965c1310088L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 3, 2, "\uda92\udc4a\uda58\udc12", "\u2c4b", "\ue842\ud91f\uddac\udba2\udee3\uda3b\ude6d",
        8, 72543, -444065391, -3022841272666755376L, 6657L, false, false, (char) 32193, (char) 12137,
        Double.longBitsToDouble(0x3fe694f84ce42be7L), Double.longBitsToDouble(0x3fc9d965c1310088L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 0, "\ud8cf\udc50\uda58\udc12\ud887\udda2", "\u07b4\u0e31\u9ca7\uca7a\u5060\u72e9\ua55d\u37a3\u6479\u9c28\u78a8\u88bd\u5795\ua47e\u2fca\u5b7f\ubada\u564a", "\udaca\uddec",
        39, 81993, -1773349507, 3550437507170730565L, -92466L, false, true, (char) 9870, (char) 17687,
        Double.longBitsToDouble(0x3fec10852ead1440L), Double.longBitsToDouble(0x3fec8f2bbb0ef575L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 11, 2, "\ud8cf\udc50\uaa3d", "\u2c4b\u5069\u19d0", "\udba2\udee3\uda3b\ude6d\ud96b\ude81\uda72\udd12\udb56\udd45\uda6e\udfdf",
        33, 78190, 786574919, -623150483800012825L, 23354L, false, false, (char) 43004, (char) 57453,
        Double.longBitsToDouble(0x3fe87d6ca9989751L), Double.longBitsToDouble(0x3fdea8dff8c04ec0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 2, "\ud846\udf91\ud970\udd45", "\u789d", "\ud809\udee0\uda13\udda6\udba2\udee3\uda3b\ude6d\ud999\udc61\udb9a\udd30\ud990\ude1f",
        6, 9929, -1440786810, -2106912359442959720L, 65781L, false, false, (char) 53024, (char) 36990,
        Double.longBitsToDouble(0x3fd6228ab701156eL), Double.longBitsToDouble(0x3f9b8cbfc7421020L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 8, 2, "\udb03\udf29\ud927\udee8", "\ua9a0", "\ud809\udee0\ud9d2\ude28\udab9\ude4f\uda37\udc26",
        8, 72543, -440786019, -3022801093247701296L, -10993L, true, false, (char) 58843, (char) 53450,
        Double.longBitsToDouble(0x3fc9d965d8da9488L), Double.longBitsToDouble(0x3fc631dc3c26b288L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer$Vanilla:@? |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\012",
        Z.run(T, 2, 4, 12, 2, "\ud8cf\udc50\ud92a\ude9b", "\u2c4b", "\ud809\udec7\ud91f\uddac\udba2\udee3\uda3b\ude6d",
        14, 72543, -440786019, -3022841272666755376L, 87985L, true, false, (char) 58843, (char) 53450,
        Double.longBitsToDouble(0x3fc9d965c1310088L), Double.longBitsToDouble(0x3fdb12cf43a3878cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 3, 2, "\ud8cf\udc50\uda58\udc12", "\u2c4b", "\uda1a\udff0\udb6f\udc1a\ud94e\udd52\udbfa\udd78",
        40, 17519, -2144889705, -3022841272666755376L, 6657L, false, false, (char) 32193, (char) 12137,
        Double.longBitsToDouble(0x3fe1363e0089feddL), Double.longBitsToDouble(0x3fc9c32941310088L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@? |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 11, 2, "\udbd6\udc33\uda57\udfa1", "\u2c4b", "\ud921\ude2d\ud91f\udd7a\udba2\udee3\ud871\udea8",
        47, 72543, -440786019, -1132834660031082463L, -18675L, false, false, (char) 32193, (char) 12137,
        Double.longBitsToDouble(0x3fe694f84dbe3ac2L), Double.longBitsToDouble(0x3fc30a24a1310088L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@? |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\012",
        Z.run(T, 2, 12, 3, 10, "\ud982\udfbc\uda66\udf87", "\u8903\u07b4\u4fac\ucbb9\u0dfa\u5060\u72e9\ua55d\u37a3\u6479\u325c\uc69b\u9c0d\u0fcd\u439a\uab6a\u5b7f\u8bbd\ua793\u8362\u6ee3\u5113\u9391\u2c56\ucce4\u8f79\uaac5\u8122\u30aa\u3265\u7df6\ua7e8\u8de9", "\udb48\udcd2\ud90c\udd94",
        2, 92288, 1986557727, 5919815776887739167L, 13988L, true, true, (char) 45817, (char) 34492,
        Double.longBitsToDouble(0x3fe0d3a8b2d6bf8aL), Double.longBitsToDouble(0x3fee6f6bfc5896e3L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\012",
        Z.run(T, 2, 12, 6, 11, "\udab4\udea0\uda58\udc12\uda35\udd89", "\u07b4\u7f82\u9ca7\uc0fe", "\udab7\udf95",
        30, 77981, -2140614943, 5943090713240376601L, 4521L, false, false, (char) 23150, (char) 48147,
        Double.longBitsToDouble(0x3fef147e54cecbb8L), Double.longBitsToDouble(0x3fb31008b5ed9140L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 4, "\udb32\udf1b\ud9c2\udd5b", "\u2c4b", "\uda64\udca6\ud917\udf09\udba2\udee3\uda3b\ude6d\ud999\udc61\ud960\udc52\uda70\udf30\ud83c\udf68\uda99\udc1e\ud976\udd76\ud8ae\udd6a\ud8d8\udd3f\udbbd\uded4\ud87e\udcb4\ud940\udd68\udbce\udd47\ua102\udb55\udee0",
        26, 5727, 1525716785, 2821862165876005167L, -22278L, false, true, (char) 12292, (char) 19654,
        Double.longBitsToDouble(0x3fe85189c4166568L), Double.longBitsToDouble(0x3fcfe4d15268b2c4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=null |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\012",
        Z.run(T, 2, 6, 1, 11, "\ud8e3\udcfd\udaa6\udd50\ud94c\udebe\ud89c\udf5f\ud865\ude52\udbe1\udd4e\ud95c\uded8\ud809\udee0\ud91f\uddac\ud996\udf9c\ud912\udf66\uda5e\udf30\ud8dd\udcf3\uda70\udd82\udab8\udc66\udbc2\udde7\ud8ad\udeb8\ud86f\ude77\udaf0\udd02\udb52\udfbd\udb5e\udf4b\ud99e\udd77\ud870\uddd0", "\ub7aa", "\ud8ed\udced\ubb7d\uda76\ude2d\udae7\udc0e\ud83b\udcd0\ud9dc\udc01\udb09\udf5c\ud8f8\udf38\udb8a\udcf9\ud9b8\uddc7\udb42\udf93\ud85f\udca8\udb0b\udd8b\ud976\udf74\udbd8\udc16",
        44, 89642, -107341960, 7484066610263478299L, 12990L, false, true, (char) 29712, (char) 24333,
        Double.longBitsToDouble(0x3fd7ee80eb2202daL), Double.longBitsToDouble(0x3fa2b6a22b4ea040L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 2, 0, "\ud8cf\udc50\uda58\udc12\ud887\udda2\udab6\ude2d\ud847\udd0e\ud826\udcd9\ud95c\uded8", "\u5060\u72e9\u514a\u37a3\u6479", "\ud976\udd76\udbd2\udd5c\ud8d8\udc91\udbbd\uded4\ud87e\udcb4",
        31, 42506, -1092320179, -4447118363159219401L, -3622L, true, false, (char) 43128, (char) 10844,
        Double.longBitsToDouble(0x3fe5057309382ff6L), Double.longBitsToDouble(0x3fec1a2b2bc87810L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 3, 2, "\ud8cf\udc50\uda58\udc12", "\u1071", "\ud8bf\udfdb\ud91f\ude3a\udba2\udee3\uda3b\ude6d",
        8, 72543, -440786019, -3022841272666755373L, -52594L, false, false, (char) 43004, (char) 57453,
        Double.longBitsToDouble(0x3fe99f98e408f1beL), Double.longBitsToDouble(0x3fed472dd0f5e37eL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer$Vanilla:@? |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\012",
        Z.run(T, 2, 1, 4, 7, "\ud8ea\udcf8\uda58\udc12\ud887\udda2\udab6\ude2d\ud847\udd0e\udb1b\udde7\ud95c\udf24\ud809\udee0\ud91f\uddac\udba2\udee3\uda3b\ude6d\ud999\udc61\udb9a\udd30\uda70\ude10\ud83c\udf68\uda99\udc1e\udb81\udd7b\udb4b\udff6\ud8ac\udf8d", "\ubada\u2e97\ua0d1", "\ud95f\udd1b\ud813\udf4d\uda23\udf33\uda27\udff5\uda8d\uddcd",
        52, 64014, 1382325929, -1110423072677236819L, 83459L, true, false, (char) 14744, (char) 22557,
        Double.longBitsToDouble(0x3fe32bdea9f49f66L), Double.longBitsToDouble(0x3fd4b800c10613fcL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\012",
        Z.run(T, 2, 12, 13, 11, "\ud8bd\udff6\udaaa\udd13", "\u2c4b", "\ud809\udee0\ud90f\udf02\udba2\udee3\udb87\udf2e",
        19, 72543, 1840915357, -3022841272666755376L, 6657L, true, true, (char) 3184, (char) 12137,
        Double.longBitsToDouble(0x3fe694f84ce42be7L), Double.longBitsToDouble(0x3fc9d965c1310088L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\012",
        Z.run(T, 1, 13, 3, 2, "\ud8cf\udc50\uda58\udc12", "\u2c4b", "\udb09\udee0",
        44, 15653, -290677274, -5567063841466753889L, -6377L, true, true, (char) 33246, (char) 32193,
        Double.longBitsToDouble(0x3fe35c07f6d29f09L), Double.longBitsToDouble(0x3fcc857ce294f604L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\012",
        Z.run(T, 2, 12, 12, 0, "\000\000", "", "\u2e70",
        -5, 15486, 0, 0L, 22112L, true, true, (char) 50396, (char) 10375,
        Double.longBitsToDouble(0x3feafd50f8f09aeeL), Double.longBitsToDouble(0x3d90000000000000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer$Vanilla:@? |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\012",
        Z.run(T, 2, 12, 4, 2, "\uda11\udedc\udae7\udc64", "\u2c4b\u07b4\ucfac\u9ca7\uca7a\u5060", "\udb9a\udd30\uda70\ude10\ud83c\udf68\uda99\udc1e\ud976\udd76\ud8ae\udd6a\ud8d8\udd3f\udbbd\uded4\ud87e\udcb4\ud940\udd68\uda63\ude01",
        6, 88940, 1650919487, 4612792576457074389L, -17953L, true, false, (char) 16760, (char) 4207,
        Double.longBitsToDouble(0x3fe0c9ee9154117fL), Double.longBitsToDouble(0x3fc3d29ad1a26c5cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=null |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\012",
        Z.run(T, 2, 13, 1, 3, "\udbd5\udd62\uda66\ude1a", "\u2c4b\u07b4\uacab", "\udba2\udf25\ud802\udff0\ud975\uddbd\u55a5\udaa2\udef8",
        8, 10008, 924800646, -3070190832245003241L, 51957L, false, false, (char) 17219, (char) 36240,
        Double.longBitsToDouble(0x3fdeb549fe1d6d7aL), Double.longBitsToDouble(0x3fe63b4336a3b6eeL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=java.lang.Boolean:true |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\012",
        Z.run(T, 2, 6, 6, 8, "\uda92\udc4a\uda58\udc12\ud887\udda2\udab6\ude2d\ud9df\udf0a\ud826\udcd9\u21ee\ue842", "\u72e9\ua55d\u0755\u2232\u684f", "\ud9f2\ude64\ud93d\udd58\udbbd\udf77\ud87e\udcb4\ua405\ud870\uddc7\uda48\udc95\udbfc\ude96\ud8f9\udd7a",
        46, 39531, 865701138, 7649312560734599499L, 73158L, true, true, (char) 62518, (char) 57377,
        Double.longBitsToDouble(0x3feda0c90c10058cL), Double.longBitsToDouble(0x3fe91b1e48082bd8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\0121=null |this=com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud8cf\udc50\uda58\udc12\ud887\udda2", "\uc564\u0e31\u9ca7\uca7a\u07a2\u72e9\ua55d\u37a3\u6479\u9c28\u6e31\u88bd\u5795\ua47e\u2fca\u5b7f\ubada\u564a", "\udaca\uddec",
        41, 81993, -1773349507, -6910017052327378363L, 8398L, false, true, (char) 13606, (char) 25049,
        Double.longBitsToDouble(0x3fb4527f8ac5e878L), Double.longBitsToDouble(0x3fd91e5773cadc2cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 3, 2, "\ud8dc\udc50\uda58\udc12", "\u3d67", "\ud809\udee0\ud91f\uddac\ud8a7\udf45\uda3b\ude6d",
        8, 72543, -440786019, -3022841272666755376L, 6657L, false, false, (char) 32193, (char) 12137,
        Double.longBitsToDouble(0x3fec9cf84be4abf7L), Double.longBitsToDouble(0x3fc9d28681310088L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer|deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:",
    "M|com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer|_clearIfStdImpl|com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:",
    "M|com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer|_findCustomDeser|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.JavaType|new:com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:",
    "M|com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer|_withResolved|com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.JsonDeserializer|new:com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:",
    "M|com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer|createContextual|com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.BeanProperty|new:com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:",
    "M|com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer|deserializeWithType|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext,com.fasterxml.jackson.databind.jsontype.TypeDeserializer|new:com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:",
    "M|com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer|isCachable||new:com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:",
    "M|com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer|mapArray|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:",
    "M|com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer|mapArrayToArray|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:",
    "M|com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer|mapObject|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:",
    "M|com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer|resolve|com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:",
    "C|com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer|<init>|com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.JsonDeserializer,com.fasterxml.jackson.databind.JsonDeserializer",
    "C|com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer|<init>|com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JavaType",
    "C|com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer|<init>|",
    "M|com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer|deserialize|com.fasterxml.jackson.core.JsonParser,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
