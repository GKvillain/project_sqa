package com.fasterxml.jackson.databind.deser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class StdKeyDeserializer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\ud5e4\u1b85\u388e\ua5d1\u8c2f\u37db\ud47a\u49f5\ud33c\u008c\u0d62\u435c\u5707\u3730\uc9c2\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u1aa7\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\uda43\udde0\udbf0\udf2b",
        -2, 2419, 414353598, -8125358546517188035L, -4208L, true, false, (char) 565, (char) 11883,
        Double.longBitsToDouble(0x3fe382654b652f85L), Double.longBitsToDouble(0x3fe728db75f771ecL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8b7\udecb\uda34\udd32\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\ud5e4\u1b85\u388e\ua5d1\u8c2f\u37db\ud47a\u49f5\ud33c\u008c\u0d62\u435c\u5707\u3730\uc9c2\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u1aa7\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\uda43\udde0\udbf0\udf2b",
        -2, 2419, 414353598, -8125358546517188035L, -4208L, true, false, (char) 565, (char) 11933,
        Double.longBitsToDouble(0x3fe382654b652f85L), Double.longBitsToDouble(0x3fe728db75f771ecL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 8, 5, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\ud5e4\u1b85\u388e\ua5d1\u8c2f\u37db\ud47a\u49f5\u481d\ua2f6\u0d62\u435c\u5707\u3730\uc9c2\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u1aa7\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\uda43\udde0\udbf0\udf2b",
        -2, 2419, 414353598, -8125358546517188035L, -4208L, true, false, (char) 565, (char) 11883,
        Double.longBitsToDouble(0x3fe382654b652f85L), Double.longBitsToDouble(0x3fe728db75f771ecL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 1, "\udb33\udf14\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\ud5e4\u1b85\u388e\ua5d1\u8c2f\u37db\ud47a\u49f5\ud33c\u008c\u0d62\u435c\u5707\u3730\uc9c2\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u1aa7\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\uda43\ude81\udbf0\udf2b\ud8bd\udd58\udb93\udcb9\uda4c\ude32\udb2f\udece\uda7b\udda6\uda39\udcc9\udad7\udd29\ud942\udee3\udb29\udef6\ud934\udd15\udbab\ude1a\uda3c\udd7c\udbae\udd3c\udb47\udd02\udad9\udd9b\ud884\udc3a\ud960\udf5b\ud9b6\udff5\uda11\udc26\u388d\ud98f\udf49\ud98e\udc91\ud9c8\ude13\ud9a9\udff8\udb65\udfa8\udadb\udf0d\ue9ee",
        10, 96210, 464074610, -1255847235653125866L, 89932L, false, true, (char) 39521, (char) 17710,
        Double.longBitsToDouble(0x3feff0ebe0a222f7L), Double.longBitsToDouble(0x3feee61580ce4001L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 1, "", "\u2012\ub01d\u45fe\u87ae\uc063\u47fc\ua302\u0eda\ucd26\u2f97\u9c35\000\u5cab\u4009", "\udb4f\uddde",
        -4, -1000, 0, -3983261247624025414L, -100000L, false, false, (char) 10998, (char) 349,
        Double.longBitsToDouble(0x3fe684a48af2b85aL), Double.longBitsToDouble(0x3fe2c46de7ad48bdL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 7, 7, 3, "\udac7\udd05\ud928\udd06\ud81f\udca6\uda47\udc95\udaa7\ude84\ud86f\udc50\uda3e\udfae", "\u9123\u6109\u7270\u6ada\u27b6\u61b0\u6138\u2e92\u611f", "\ud978\udd3c\ud947\udf73\ud99d\udddc\ud822\udd65\udbee\udc0e\udb0d\ude4c\udb45\udc95\udbe3\udc31\ud8d2\udf42\udab4\udde7\udac3\udd2e\udb62\udeb0",
        45, 17352, -1220678121, 196163049399491057L, -1453L, true, true, (char) 36940, (char) 25767,
        Double.longBitsToDouble(0x3fd2aa942515b3eaL), Double.longBitsToDouble(0x3feda1506874635bL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89", "\u2e92\u60c9\u4de9\u59d9\u1ca5\u4b12\u93d4\u3c8d\u2fdd\ua9a2\u0ee8\ud5db\u5243\ud5e4\u1b85\u388e\ua5d1\u8c2f\u37db", "\ud9ad\udc4a\ud809\udfde\ud906\udf4a\uda78\udf6e\udb57\ude0c\ud887\udfa3\ud968\udf74\ud829\udeec\ud900\ude6b\ud86d\udc21\ud9e2\ude98",
        12, 98389, 953569098, -3366468490033964937L, 63596L, false, true, (char) 23621, (char) 39020,
        Double.longBitsToDouble(0x3fc285162ce52e50L), Double.longBitsToDouble(0x3feb78905970fb8eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 5, 7, 1, "\udad2\ude88", "\ub01d\u45fe", "\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b",
        30, 70281, 1194711103, 3336582594148998489L, 75017L, false, false, (char) 61695, (char) 40801,
        Double.longBitsToDouble(0x3fe79002d2588dbcL), Double.longBitsToDouble(0x3e44000000000000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 5, 8, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\ud5e4\u1b85\u388e\ua5d1\u8c2f\u37db\ud47a\u49f5\ud33c\u008c\u0d62\u435c\u5707\u3730\uc9c2\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u1aa7\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\uda43\udde0\udbf0\udf2b",
        -2, 2419, 414353598, -8125358546517188035L, -4208L, true, false, (char) 565, (char) 11883,
        Double.longBitsToDouble(0x3fe382654b652f85L), Double.longBitsToDouble(0x3fe728db75f771ecL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 1, "\udb16\ude7d\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\u6795\ud8dd\udf3b\ud85b\udca4\ud91d\udd2b\uda32\udceb\ud993\uddef\uda5e\udd19\udbee\udc68\udb0d\ude4c\udb45\udc95", "\ud5e4", "\udb65\udd8c\udb74\udd04\ud928\uddcd\udb2e\ude5a\u12c7\ud9bd\uddc5",
        0, 39588, 1533181709, 8763722170923092417L, 59446L, false, true, (char) 50914, (char) 13184,
        Double.longBitsToDouble(0x3fc073b559558e64L), Double.longBitsToDouble(0x3fea5685d6bf38d6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 2, 5, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\udb6f\udf8d\udbd6\udedb\ud9d9\ude1d\ub856\ud80e\udeb5\udbab\udcef\udb39\ude32\ud91d\udc71\uda31\udf2f\u8a17\ud810\udcd4\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\ud5e4\u0c48\u3f43\ua5d1\u8c2f\u37db\ud47a\u49f5\ud33c\u207a\u9823\u435c\u5707\u3730\uc9c2\ud320\u9a58\u60b9\u93d8\u6e8e\ua64e\uc3a7\uaf5f\u36a9\u476e\u3694\ub807\u4338", "\uda43\udde0\udbf0\udf2b",
        -2, 2419, 414353598, -8125358546517188035L, -4208L, true, false, (char) 44789, (char) 11905,
        Double.longBitsToDouble(0x3fe382654b652f85L), Double.longBitsToDouble(0x3fe728db75f771ecL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\udba3\udff7\ud937\udfe4\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\ud5e4\u1b85\u388e\ua5d1\u8c2f\u37db\ud47a\u49f5\ud33c\u360f\u0d62\u1b0a\u5707\u3730\uc9c2\ucc13\u9a58\ub753\u12a9\u6e8e\ua64e\u1aa7\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\uda6d\uded0\u511c",
        7, 2419, 414353598, -8125358546517188035L, -4208L, true, false, (char) 565, (char) 11883,
        Double.longBitsToDouble(0x3fe382654b696e85L), Double.longBitsToDouble(0x3fe728db75f771ecL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 3, 8, 5, "\udb3e\udd1a\ud978\udd16\udbe3\udf43\udbab\udf44\ud81d\udefd\uda01\uddb0\uda29\udd5b\ud9bb\udf64\ud94f\udeba\ud81a\udeeb\ud960\udf95\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\ud92c\udd1a\ud810\udc7a\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\ud5e4\uc367\u39c7\ua5d1\u8c2f\u37db\u78de\u2363\ua24c\u008c\u0d62\u435c\u5707\u3730\uc9c2\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u1aa7\uaf5f\u7d82\u59d5\u6c5a\uc6ac\u4357", "\uda43\udde0\udbf0\udf2b",
        -2, 2419, 414353598, -7013474111751278728L, 21489L, true, false, (char) 42751, (char) 44398,
        Double.longBitsToDouble(0x3fe83786bcf86973L), Double.longBitsToDouble(0x3fe382654b652f85L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Thread$State |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 6, 6, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\ud94a\udc2a\udbb5\udd02\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\ud5e4\u1b85\u388e\ua5d1\u8c2f\u37db\ud47a\u49f5\ud33c\u008c\u0d62\u435c\u5707\u3730\uc9c2\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u4eca\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\uda43\udde0\udbf0\udf2b",
        -2, 2419, 414353598, -8125358546517188035L, -4208L, true, false, (char) 565, (char) 11883,
        Double.longBitsToDouble(0x3fe382654b652f85L), Double.longBitsToDouble(0x3fe728db75f771ecL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 1, "\ud82d\ude92", "\ub01d", "\udb66\udf67",
        8, 5340, -1133101338, 8356556325385207808L, 58146L, false, true, (char) 5524, (char) 13256,
        Double.longBitsToDouble(0x3fdbadf2f50ad668L), Double.longBitsToDouble(0x3fe289c6e03f9dbbL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 1, "\udb3e\udd1a\uda06\ude5e\ud4fb\ud9b7\udeb6\ud8c3\ude12\udba4\udd39\udb42\udd4d\udb10\udcd2\ud94a\udedc\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\udea5\udbde\udf86\uda75\udd03\udab1\udd52\ud9ce\udc86\uda5f\ude13\udaf9\udc06\ua790\ud810\udcd4\ud890\udc5f\ud974\ude26\udb45\udc38", "\ud5e4\u1b85\u388e\ua5d1\u8c2f\u37db\u11b1\u4507\uab21\u52b4\u6b9a", "\ud887\udfa3\ud968\udf74\ud829\udeec\ud900\ude6b\ud86d\udc21\ud9e2\ude98\uda4f\ude61\udb6a\udf8b\ud9c8\udea3\ud878\udffe\ud964\udece\ud9cb\udd09\uda89\udcff\ud820\udd54\uda00\udc12\ud8b2\udc89\ud804\udd1d\uda15\udf23",
        2, 6368, -196946581, 1779635150498098548L, -84038L, true, true, (char) 15626, (char) 42751,
        Double.longBitsToDouble(0x3f5856de6c24a200L), Double.longBitsToDouble(0x3fcf0d2e79c132a4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 5, 8, 1, "\ud8bb\udc23\ud978\udcc4\uba09\udbab\udf44\ud843\udf70\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\udba4\udf10\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\ud5e4\u1b85\u388e\u1539\u8c2f\u37db\ud47a\u49f5\ud33c\u008c\u0d62\u435c\u5707\u3730\uc9c2\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u1aa7\uaf5f\u36a9\u476e\uc6be\uc2e3\u4357", "\ud95d\udd50\udbb3\udcf2",
        1, 2387, 414353598, -8125358546517188035L, -14384L, true, true, (char) 49746, (char) 26595,
        Double.longBitsToDouble(0x3fe89b4856342d9fL), Double.longBitsToDouble(0x3fb5a753e0077660L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 1, "\udb23\udf28\ud96f\udc16", "\u9442\u87ae\uc063\u47fc\ua302\u0745", "\ub95d",
        11, 55864, 1045589548, -2364401390392669766L, -19279L, true, true, (char) 52613, (char) 57441,
        Double.longBitsToDouble(0x3fe5d4900873dfcaL), Double.longBitsToDouble(0x3fc5f2bacea57d34L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 4, 1, 1, "\udbdd\udc13\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\udb81\uddb0\u4062\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\ud5e4\u1b85\u388e\ua5d1\u451a\u1012\ud47a\u4997\ud33c\u008c\u0d62\u435c\u5707\u3730\uc9c2\ucc13\u9a58\u60b9\u93d8\ud38e\ua64e\u1aa7\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\uda43\udde0\ud810\udc85",
        45, 2408, 414353598, -8125358546517188035L, -4208L, true, false, (char) 565, (char) 11883,
        Double.longBitsToDouble(0x3fe382654b652f85L), Double.longBitsToDouble(0x3fe728db75f771ecL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud95b\udf4d\udbc6\uded4\ud8fd\udc42\ud9ef\udcc4\ud872\udfd7\udafd\udd68\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\u8890\u1b85\u388e\ua5d1\u8c2f\u37db\ud47a\u49f5\ud33c\u008c\u0d62\u435c\u5707\u3730", "\ud900\ude6b\ud86d\udc21\ud9e2\ude98\uda4f\ude61",
        9, 27098, 1200875199, -3045708285846231390L, -83818L, true, false, (char) 38253, (char) 52548,
        Double.longBitsToDouble(0x3fe9ca5ca36f2d0bL), Double.longBitsToDouble(0x3fd70fb8ead68498L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 1, "\ud9d4\udd0d\ud9aa\ude53\uba09\udbab\udf44\ud80d\udf2d\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud822\udd73\uda1d\udc82\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\uda9c\udf85\ud948\udc0b\udb4f\uddde\ud9ce\udc86\uda1f\uded2\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udb09\udf4c\udb45\udc95", "\uab39\ub043\u38f9", "\ud928\uddcd\ud80e\udd6a\udb7e\udebc\ud9ad\udc4a\ud809\udfde\ud906\udf4a\udaa7\udc6f\udb57\ude0c\ud887\udfa3\ud9ad\udc7d\udb44\udc19\ud943\udf24\ud86d\udc21\ud9e2\ude98\uda4f\ude61\udb6a\udf8b\ud9c8\udea3\ud878\udffe\ud8c3\udfdc\u93f1\ud9c7\udc6b\udbc5\udfcb\u1432\udba2\udfa6\udbb7\udcba",
        16, 13185, 1112320368, -845879126356466754L, -4208L, true, false, (char) 565, (char) 11883,
        Double.longBitsToDouble(0x3fe382654bb13b85L), Double.longBitsToDouble(0x3fe728db752571ecL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udbae\udf67\ud9bc\udc46\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\ud5e4\u1b85\u388e\ua5d1\u8c2f\u37db\ud47a\u49f5\uac20\u464a\u0d36\ubd5b\u5707\u707c\uc9c2\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u8bd5\u99da\u07dc\u48dd\uc6be\uc6ac\u4357", "\uda43\udde0\udab2\uddeb",
        6, 2867, 414353598, -8125358546517188035L, -4208L, true, false, (char) 565, (char) 11883,
        Double.longBitsToDouble(0x3fe382666b652f85L), Double.longBitsToDouble(0x3fea04bc7527745cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 5, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\u209f", "\u47fc\ua302\u0eda\ucd26\u2f97\u9c35", "\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb",
        4, 67466, -1790439847, 6867216127436696489L, 27383L, false, false, (char) 25420, (char) 21,
        Double.longBitsToDouble(0x3fed6a45ed1663aeL), Double.longBitsToDouble(0x3fe0ba15e941b73dL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 7, "\udb3e\udd1a\udaf9\udcdd\udb71\udd45\udbab\udf9a\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb", "\u2fdd\ua9a2", "\ud8d2\udf42\ud811\ude97\ud873\udc36\ud971\udea1\udb65\udd8c\udb74\udd04\ud928\uddcd\ud80e\udd6a\udb7e\udebc\ud9ad\udc4a\ud809\udfde\ud906\udf4a\udaa7\udc6f\udb57\ude0c\ud887\udfa3\ud968\udf74\ud829\udeec\ud900\ude6b\ud86d\udc21\ud8f9\udf63\uda4f\ude61\udb6a\udf8b\uda06\udca2\ud878\udffe\ud964\udece",
        1, 23268, 332152630, 4551811533598972225L, -3934L, false, true, (char) 12665, (char) 29646,
        Double.longBitsToDouble(0x3fd9135430067a0eL), Double.longBitsToDouble(0x3fd3030cf0028e96L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.net.URI:\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\uda78\udce7\ud959\udd42\udb0d\ude15\udb45\udc95 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 0, 6, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\uda78\udce7\ud959\udd42\udb0d\ude15\udb45\udc95", "\ud5e4\u4b57\uab89\ua5d1\u8c2f\u37db\ud47a\u49f5\ud33c\u008c\u0d62\u435c\u5707\u3730\uc9c2\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u1aa7\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\uda43\udde0\udbf0\udf2b",
        13, 2419, 414353598, -8125358546517188035L, -4208L, true, false, (char) 565, (char) 11883,
        Double.longBitsToDouble(0x3fb5532a4e57ec28L), Double.longBitsToDouble(0x3fe728dab5f771ecL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 8, 8, 3, "\udbaa\udd87\ud978\udd00\uba09", "\u87ae\uc063\u47fc\u0908\u0e92\u6d44\u1f80\u9c35\u7fd2", "\uda9e\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\ud96f\udf9d\ud805\udc23\udbee\udc0e\udb92\udcef\udb45\udcc2\ud914\udf66\ud8d2\udf42\ud811\ude97\ud873\udc36\ud971\udea1\udb65\udd8c\udb74\udd04\ud928\uddcd",
        59, 83433, -1088206819, 3114447300216957516L, -42969L, false, true, (char) 25775, (char) 14956,
        Double.longBitsToDouble(0x3fd8ad9f53690e5cL), Double.longBitsToDouble(0x3fb912c7041ced50L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\u74ec\u65e2\u388e\ua5d1\u8c2f\u37db\ud47a\u49f5\ud33c\u008c\u0d62\u435c\u5707\ubdc8\u11b7\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u1aa7\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\uda43\udde0\udbf0\udf2b",
        5, 51104, 414353598, -8125358546517188035L, -4208L, true, false, (char) 565, (char) 11883,
        Double.longBitsToDouble(0x3fe382654b652f85L), Double.longBitsToDouble(0x3fe728db75f771ecL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Thread$State |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 6, 8, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\ud949\udc56\uda1c\udc85\ud976\udf48\ud8b7\udecb\uda34\udd32\ud8b6\uddd8\udbde\ude05\ud948\udc0b\udb9a\udca3\ud9ce\udcc2\ud91d\udc71\uda31\udeeb\uda25\udf37\ud80b\udee8\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\ud5e4\u1b85\u388e\ua5d1\u8c2f\u37db\ud47a\u49f5\u5c5c\u008c\u1daf\u2c15\u5707\u3730\uc9c2\ucc13\u9a58\uc902\u93d8\u6e8e\ua64e\u1aa7\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\uda43\udde0\udbf0\udf2b",
        -2, 2419, -121397744, -8431088921535252117L, 66352L, true, false, (char) 21112, (char) 11886,
        Double.longBitsToDouble(0x3fe382654b652f85L), Double.longBitsToDouble(0x3fe728db75f771ecL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8b7\udecb\uda34\udd32\ud8b6\uddd8\udbde\udf86\uda4a\udc0c\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\ud5e4\u1b85\u388e\ua5d1\u8c2f\u37db\ud47a\u49f5\ud33c\u008c\u0d62\u435c\u5707\u3730\uc9c2\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u1aa7\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\uda43\udde0\udbf0\udf2b",
        15, 2419, 414353598, -8125358546517188035L, -4208L, true, false, (char) 64820, (char) 46412,
        Double.longBitsToDouble(0x3fe382654b652f85L), Double.longBitsToDouble(0x3fe728db75f771ecL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 1, "\uda4c\udeb4\ud978\udd16\ub97c\udbab\udf44\ud80d\udf75\uda01\uddb0", "\u7262\u0eda\ucd26", "\udb8c\udcd6",
        3, 36548, -550505098, 7724950693758134917L, 41249L, true, false, (char) 52133, (char) 13171,
        Double.longBitsToDouble(0x3fe2cefe50af9548L), Double.longBitsToDouble(0x3fed4afa6b440fb2L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 8, 5, 1, "\udb3e\udd1a\ud978\udd16\uba09\udaad\udc46\ud8e3\udcbf", "\u47fc\ua302\u0eda\ucd26\u2f97\u9c35\u7fd2\u5cab\u90a1\u453e\u60c9", "\ud8fd\udceb\uda4b\udcb9\udb45\uddd4",
        12, 87153, -1488109393, 1131211875414317892L, 28304L, false, false, (char) 21, (char) 40221,
        Double.longBitsToDouble(0x3fef6ff6f5577e08L), Double.longBitsToDouble(0x3fd41c7353e20570L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 5, 5, 1, "\udb3e\udd1a\ud978\udd16\uba09\ud985\udf80\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\ud9fc\udc50\udb45\udc95", "\ud5e4\u1b85\u388e\ua5d1\u8c2f\u37db\ud47a\u49f5\u481d\ucd08\u0d2c\u435c\u5707\u3730\uc9c2\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u1aa7\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\uda43\udde0\udbf0\udf2b",
        -2, 2419, 414353598, -8125358546517188035L, -4208L, true, false, (char) 565, (char) 11883,
        Double.longBitsToDouble(0x3fe382654b652f85L), Double.longBitsToDouble(0x3fe728db75f771ecL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer$StringKD:@?\012",
        Z.run(T, 1, 5, 6, 2, "\udadb\udf2f\ud983\udc15\udbff\udd89\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\udbf2\udfb4\udac5\ude87\ud952\ude76\udb7b\udda1\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda2d\udd3e\u8a17\ud810\udcd4\udbee\udc0e\udb0d\ude4c\udb45\udc95\udbb0\udd8c\ud994\udf01\ud960\udc43\ud873\udc36\ud971\udea1\udb65\udd8c\udb74\udd04\udaae\udc2f\ud80e\udd6a\udb7e\udebc\u481d\udad2\ude88\ud906\udf4a\udaa7\udc6f\udb57\ude0c\udb4a\udf24\ud8cc\udc1f\uda33\udfc5\ud932\ude05\ud815\udfe9\ud9e2\ude96", "\uc7af\u01f3\u4d82\u476e\uc6be\uc6ac\u4357\u997b\u1e28\u789c\u3ec2\u1804\u3781\u6e03\u77ce\ucdfa\u28c7\u1662\u52a2\ucce9\u85b6\u9a66", "\udb4b\ude02\udad9\udd9b\udaf4\udcb1",
        0, -365, -2013263467, -4570620370270935623L, 49906L, false, true, (char) 36336, (char) 2109,
        Double.longBitsToDouble(0x3fe4b829b2423b71L), Double.longBitsToDouble(0x3f9d89bfb8d37da0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 8, 1, 4, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud852\ude18\uda3e\udef3\u4329\ud9bb\udf86\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud9be\udc20\ud8b6\uddd8\udbde\udf86\ud948\udc0b\ud81a\udca4\ud8b3\udccf\ud91d\udc37\ud939\udeef\udb84\udf27\udbbf\udf65\ud827\udccf\udb90\udcb9\udb45\udc95", "\ud5e4\u1b85\u388e\u76ae\u7e56\u293f\ud47a\u49f5\ucce5\u656b\u0d62\u435c\u5707\u3730\uc9c2\ucc13\uaf57\u60b9\u93d8\u6e8e\ua64e\u5512\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\udb5d\udef3\udbdd\udd0e",
        36, 56059, 414353598, -8125358546517188035L, -4208L, true, true, (char) 29289, (char) 43383,
        Double.longBitsToDouble(0x3fd25064990c5f0aL), Double.longBitsToDouble(0x3fcca36b97ddc6ecL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 5, 8, 1, "\udb33\udf14\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\uda23\udc08\udad7\udd93\ud8f0\udee5\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udaa6\ude1f\ud874\ude1e", "\ud5e4\u1b85\u388e\ua5d1\u7300\u1bde\u896a\ubba1\u284f\u0138\ube45\u435c\u5707\u3730\u7fb0\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u1aa7\uaf5f\u36a9\u4a64\u915a\u96d7\uc03f", "\uda43\ude81\udbf0\udf2b\ud8bd\udd58\udb93\udcb9\uda4c\ude32\udb2f\udece\uda7b\udda6\uda39\udcc9\udad7\udd29\ud942\udee3\udaa9\udef6\ud934\udd15\udbab\ude1a\uda3c\udd7c\udbae\udd3c\udb47\udd02\udad9\udd9b\ud884\udc3a\ud960\udf5b\ud9b6\udff5\uda11\udc26\u388d\ud98f\udf49\ud98e\udc91\ud9c8\ude13\ud9a9\udff8\udb65\udfa8\udadb\udf0d\ue9ee",
        10, 96210, 464074610, -1255847235653125866L, 10060L, true, false, (char) 39521, (char) 17710,
        Double.longBitsToDouble(0x3feff0ebe0a222f7L), Double.longBitsToDouble(0x3feee61580ce4001L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 3, 8, 1, "\udb33\udf14\ud978\udd16", "\u45fe\u87ae\uc063\u47fc\ua302\u0eda", "\udb89\uddae\ud826\udc4a\u9782\ud9b4\ude6e\ud9ae\udcc4\ud945\udd53\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udb36\udc12\udb0d\ude4c\udb45\udc95\udbe3\udc31\ud8c7\ude83\ud811\ude97\ud873\udc36\ud971\udea1\udb65\udd8c\udb74\udd04\ud928\uddcd\ud80e\udd6a\udb7e\udebc\ud9ad\udc4a\ud809\udfde\ud906\udf4a\udaa7\udc6f\ud99c\udd10\ud887\udfa3\ud968\udf74\ud829\udeec\ud900\ude6b\ud86d\udc21\ud9e2\ude98\udb89\ude5e\ud83b\udd22\ud8bf\udf15\ud878\udffe\ud964\udece\ud9cb\udd09\uda89\udcff\udaa6\udc60\u1432\udae9\udc4a\ud9ab\udfb6",
        12, 13207, 1112320368, -845879124039661378L, -4208L, true, false, (char) 565, (char) 11883,
        Double.longBitsToDouble(0x3fe382654b652f85L), Double.longBitsToDouble(0x3fe728db75f771ecL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 4, 3, 5, "\udb3e\udc88\ud978\udd16", "\ud4e6\u889b\uc063\u47fc\u0aa5\u6611\ua6df\u852c", "\udb7b\udd45\ud8b6\ude2a\000\udaea\udc42\udb41\udf48\ud9ce\udc86\ubc00",
        -5, 6512, 140663233, -239026722865176030L, 38052L, true, false, (char) 50144, (char) 25420,
        Double.longBitsToDouble(0x3fe2c46de7ad48bdL), Double.longBitsToDouble(0x3fe9e8771850e346L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.List |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 1, "", "\u2012\ub01d\ua21e\u87ae\uc063\u47fc\ua302", "\ud8ea\udc74\ud961\udc75",
        -5, 54828, 1045589548, -5155495671633749335L, -100000L, false, true, (char) 13171, (char) 60963,
        Double.longBitsToDouble(0x3f42a9105df00000L), Double.longBitsToDouble(0x3fea2078c9970fc6L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 1, 6, 8, 1, "\udb3e\udc88", "\ub01d\u45fe", "\ud9bb\udfe8\ud93d\udfcc\ud81a\ude0f\udb11\udd97\ud8ea\udc74\ud961\udc75\000\ud98a\udc73\ud8b6\uddd8\000\ud947\udf51",
        30, 70281, 0, 226501422805462L, 85643L, false, true, (char) 349, (char) 40801,
        Double.longBitsToDouble(0x3fe795c2d2588dbcL), Double.longBitsToDouble(0x3fed6a45e988be55L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 1, "\udbc4\ude50", "\ub01d", "\udb43\ude50\ud9a2\ude1a",
        14, 16662, 1945662388, -2712064268316678336L, -95308L, false, true, (char) 15954, (char) 35071,
        Double.longBitsToDouble(0x3fe42b59a6512c4bL), Double.longBitsToDouble(0x3f43b76000000000L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer$StringKD:@?\012",
        Z.run(T, 1, 5, 3, 8, "\udac7\udd05\ud928\udd06\ud81f\udca6\uda47\udc95\udaa7\ude84\ud86f\udc50\uda77\ude6e", "\u9123\u6109\u7270\u120b\u27b6\u61b0\u6138\u2e92\u611f", "\udb76\udcb5\ud947\udf73\ud99d\udddc\ud822\udd65\u7bc5\udb0d\ude4c\udb45\udc95\udbe3\udc31\ud8d2\udf42\udab4\udde7\udac3\udd2e\udb62\udeb0",
        17, 52532, -1220722921, 196163049399491057L, -1453L, true, true, (char) 36940, (char) 25767,
        Double.longBitsToDouble(0x3fd2aa942515b3eaL), Double.longBitsToDouble(0x3feda1506874635bL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 5, 2, 4, "\udac7\udd05\ud928\udd06\ud81f\udca6\udb3a\udcee\ud8d6\udd81\ud95e\udefe\uda65\udd24", "\u90d1\u6109\u2a24\ubc94\u5f3f\u61b0", "\udbc5\udc1a\udb88\udf66\ud99f\udfe1\ud978\udd3c\ud947\udf73\ud99d\udddc\ud822\udd65\udbee\udc0e",
        36, 59593, 264641348, -7741140651611649328L, 79256L, false, true, (char) 64054, (char) 12500,
        Double.longBitsToDouble(0x3fcc58a7b6300ae0L), Double.longBitsToDouble(0x3f9d0df2aa57e460L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 7, 7, 3, "\udac7\udd05\ud928\udd06\ud81f\udca6\uda47\udc95\udaa7\ude84\ud86f\udc50\uda3e\udfae", "\u9123\u6109\u7270\u6ada\u27b6\u6253\uc78d\ud1c6\u611f", "\ud978\udd3c\ud947\udf73\ud99d\udddc\ud822\udd65\udbee\udc0e\udb0d\ude4c\udb45\udc95\udbe3\udc31\ud8d2\udf42\udab4\udde7\udac3\udd2e\udb62\udeb0",
        45, 17352, -1220678121, 196163049399491057L, -1453L, true, true, (char) 36940, (char) 25767,
        Double.longBitsToDouble(0x3fd2aa942515b3eaL), Double.longBitsToDouble(0x3feda1506874635bL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=null\0121=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 5, 8, 1, "\udad2\ude88", "\ub01d\u45fe", "\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda91\udf2d\ud8f1\ude16\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud84e\udc06",
        48, 12465, -582265733, -2320926109857899943L, 75017L, false, false, (char) 61695, (char) 40801,
        Double.longBitsToDouble(0x3fd10005a4b0cb6aL), Double.longBitsToDouble(0x3e44000000000000L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Thread$State |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Class:java.lang.Thread$State |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 6, 6, 1, "\udaa7\ude66\ud8cc\udc21\ud855\udc5e", "\u87ae\uc063\u47fc\ua0e0\u358d\ucd26\u8f7b\u85fc\u996c", "\udbcc\udcfc\udb2a\udc2d",
        30, 73721, 1194711103, 3192467406073142617L, -71327L, true, true, (char) 2806, (char) 178,
        Double.longBitsToDouble(0x3e39327ce0000000L), Double.longBitsToDouble(0x3fe37ce2d67b0403L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 5, 4, 0, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\ud5e4\u1b85\ud1d4\u5316\u5be7\u37db\ud47a\u49f5\u17b2\u008c\u0d62\u435c\u5707\u3730\uc9c2\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u1aa7\uaf5f\u89ec\u1924\uc6be\u69a1\uc005", "\uda43\udde0\udb6a\udcc8",
        -2, 2419, 414353598, -8125358546517188035L, -4208L, true, true, (char) 52643, (char) 24277,
        Double.longBitsToDouble(0x3fe382654b652f85L), Double.longBitsToDouble(0x3fe1d8db75f771ecL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbc7\ude41\uda68\udf21\ud8ce\ude05\ud8cd\udee4\ud9e8\udcad\uda31\udf36\udba3\udff7\udb9f\uddd7\udbf0\udc43\udb0d\ude1c\udb45\udc95", "\ud5e4\u1b85\u3a09\u9424\u8c2f\u37db\ud47a\u49f5\ud33c\u360f\u0d62\u1b0a\ud691\u3730\u2d9d\ucbfe\ua463\ucd83\u12a9\u6e8e\ua64e\u1aa7\uaeac\ucda0\u476e\u87c5\u0a43\ubc3f", "\uda6d\uded0\u511c\ud94f\udd0b\uda35\udf0e\ud929\udf29\ud8ec\ude9d\udb6c\udefe\uda39\udcc9\udad7\udd29\ud942\udee3\udb29\udef6\ud934\udd15\udbab\ude1a\uda3c\udd7c\ud8f3\udfef\udb47\udd06\udad9\udd9b\udbe6\udf2b\ud9e1\udc40\ud881\udd40\ud976\udff7\udbf8\udf5d\ud920\udf29\ud9d6\ude43\ud853\ude7f\ud895\uddbd",
        14, 38083, 311563056, -1035605182051590954L, -38019L, false, false, (char) 61, (char) 22406,
        Double.longBitsToDouble(0x3fd34debf4c53d14L), Double.longBitsToDouble(0x3fe0ba331b332781L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 3, 8, 2, "\000\ud953\udc48", "\000\u01ad\uc1ad\u4778\ub702\u0eda\u314c\u2f97\u9c35\u7fd2\u5cab\u4009", "\udbf4\ude91\000\000\000\ud904\udfc1\udbb2\ude6b\000\000\ud9d6\udc0a\udbdc\udced\ud8d2\udf42\u0ad0\000\000\udb41\udddf\udb74\udd04",
        34, 32897, 8706379, 9851624184872960L, 28575L, true, false, (char) 14956, (char) 54143,
        Double.longBitsToDouble(0x3feda43970644b1cL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 3, 5, "\udb4b\udde3\u4590\udbe3\uded6\uda06\udc32\udbcb\udc9e\ud9c9\udd36\uda29\udc89\ud80b\udfab\udb25\udf45\udbee\udfb3\ud960\udf95\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud95e\udc2b\ud9ee\udf50", "\u4de9\u59d9\u1ca5\u4b12\ub0de\u856c\u7bd8\ua9a2\uce43\ud5f5\u5243\ud5e4\ucc62\u39c7\ua5d1\u8c2f", "\ud884\udc29\udb8c\udcd4\ud809\udfde\ud906\udf4a\udaa7\udc6f\udb57\ude0c\ud887\udfa3\ud968\udf74\ud829\udeec\ud9a2\udd7b\ud86d\udc21\uda26\ude9a\uda4f\ude61\udb6a\udf8b\ud9c8\udea3\ud878\udffe",
        30, 27527, -1712237268, 1426584684190189689L, -14974L, true, true, (char) 2170, (char) 42238,
        Double.longBitsToDouble(0x3fd6b424c17de884L), Double.longBitsToDouble(0x3fe3a0c597789eabL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 3, 1, "\ud81a\udca6", "\ub023\u5568", "\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8d3\udf89\ud961\udc75\ud8e9\ude3f\ud989\udfc7\udb45\udc00\ud9fd\udde9\udafd\udf76",
        18, 59009, -1849829313, -1714053542035663742L, 4566L, true, true, (char) 20674, (char) 53679,
        Double.longBitsToDouble(0x3feb46d0ac2de2ecL), Double.longBitsToDouble(0x3fd61ee1876ac36eL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.List |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 1, "\udb23\udf28\ud96f\udc16", "\u9442\u87ae\u1852\u47fc\ua302\u0745", "\ub95d",
        11, 55864, 1045589548, -2364401390388156942L, -19279L, true, true, (char) 52613, (char) 57441,
        Double.longBitsToDouble(0x3fe5d4900873dfcaL), Double.longBitsToDouble(0x3fc5f2bacea57d34L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 1, "\udbdd\udc13\ud8bf\udd0c\udad6\udfdc\udb71\udeb7\ud80d\udf75\001\000\ud9bb\udf4e\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\u00ba\udbed\udfb5\udb0d\ude4c\udb45\udc95", "\ud5e4\u1b85\u3836\ua5d1\u7503\u1012\ud47a\000\ud31f\u008c\u0d62\000\u5625\u00c1\uc9c2\ucc13\u91c1\u60b9\u93d8\ud38e\ua64e\u1aa7\uaf5f\u36a8\u476e\uc6be\uc6ac\u4357", "\uda43\udde0\ud9ef\udf75",
        13, 2408, 414353598, -8125358546517188035L, -100000L, true, false, (char) 42751, (char) 109,
        Double.longBitsToDouble(0x3e43e1a5cc000000L), Double.longBitsToDouble(0x3fe382654b652f85L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Thread$State |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 1, "\ud9d4\udd0d\ud911\udc48\ud8cb\udd10\udbab\udf8f\ud80f\udf2d\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud822\udd73\uda1d\udc82\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\uda9c\udf85\ud948\udc0b\udb4f\uddde\ud9ce\udc86\uda1f\uded2\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udb09\udf4c\udb45\udc95", "\uab39\ub043\u38f9", "\ud928\uddcd\ud80e\udd6a\udb7e\udebc\ud9ad\udc4a\ud809\udfde\ud906\udf4a\udaa7\udc6f\udb57\ude0c\ud887\udfa3\ud9ad\udc7d\udb44\udc19\ud943\udf24\ud86d\udc21\ud9e2\ude98\uda4f\ude61\udb6a\udf8b\ud9c8\udea3\ud878\udffe\ud8c3\udfdc\u93f1\ud9c7\udc6b\udbc5\udfcb\u1432\udba2\udfa6\udbb7\udcba",
        16, 13185, 1112320368, -845879126356466754L, -4208L, true, false, (char) 565, (char) 11883,
        Double.longBitsToDouble(0x3fe382654bb13b85L), Double.longBitsToDouble(0x3fe728db752571ecL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.net.URI:\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\udb2e\udddf\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\uda3f\udc56\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\uda78\udce7\ud959\udd42\udb0d\ude15\udb45\udc95 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 1, 3, 2, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\udb2e\udddf\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\uda3f\udc56\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\uda78\udce7\ud959\udd42\udb0d\ude15\udb45\udc95", "\ud5e4\u4b57\uab89\ua5d1\u8c2f\u37db\ud47a\u49f5\ud33c\u008c\u5d00\u435c\u64b0\u3688\uc9c2\ucc13\u9a58\u60b9\u1b95\u6e8e\u4726\u7ae3\u3933\ub3fd\u476e\uc6be\uc6ac\u4357", "\ud869\udff0\udbf0\uded8",
        13, 69211, 404964035, 5905043143780967059L, -12836L, false, true, (char) 3312, (char) 11806,
        Double.longBitsToDouble(0x3fb5532a4307ec28L), Double.longBitsToDouble(0x3fcdca7e37ddafe4L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Thread$State |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 3, 1, "\udada\udc98\ud829\uded4\udab0\ude9a\ud9d6\uddc4\udb24\udfe2\uda67\udc10\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\ud949\udc56\uda3f\ude85\ud976\udf48\ud8b7\udecb\uda34\udd32\ud8b6\uddd8\udbde\ude05\ud948\udc0b\udb9a\udca3\ud94f\udebc\ud91d\udca5\udbfe\udc91\ud91f\udf54\ud80b\ude98\udbee\udc0e\ud8c2\ude87\udb42\udfb5", "\ud5e4\u1b85\u388e\u9d85\u175f\u835c\ud47a\u49f5\u5c5c\u008c\u80a5\u2c15\u5707\u3730\uc9c2\ucc13\u9a58\uc902\u93d8\uc18e\ua64e\uc297\uaf5f\u36a9\u2e1e\u2169\uc76b\u4357", "\uda54\udd03\udbf0\udf82",
        -2, 2419, -121397744, -8431088921535252117L, 66352L, true, false, (char) 21112, (char) 11886,
        Double.longBitsToDouble(0x3fd474ca964bcd34L), Double.longBitsToDouble(0x3fe728db75f771ecL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 5, 5, 1, "\udb16\udcc3\ud978\udd16\uba09\ud9b6\ude9f\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud9e2\udea7\u6cec\udb61\udf18\ud891\udd50\uda20\udd31\ud8fc\udf89\ud98a\udc73\ud8b6\ude47\udbde\udf86\ud948\udc0b\uda45\udcda\ud9d3\udf7a\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\ud97b\udec4\ud88e\udd57\ud814\uddbc", "\u8a57\u674b\u283b\u63fd\u8c2f\u37db\ud47a\u49f5\u481d\u7359\u46fd\u4417\u5707\u3730\uc9c2\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u1aa7\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\uda43\udde0\udbf0\udf2b",
        21, 26979, 2030667966, -8125358546517188035L, 56449L, false, false, (char) 36946, (char) 11883,
        Double.longBitsToDouble(0x3fe382654b652f85L), Double.longBitsToDouble(0x3fc5d59617ddc618L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 5, 5, 1, "\udb3e\udd1a\ud906\udf3a\ud8a7\udc37\uda15\udce0\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\uda04\udd5f\udbde\udfda\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\ud9fc\udc50\udb45\udc95", "\ud5e4\u1b85\u388e\u85fd\u8c2f\u37db\ud47a\u49f5\u481d\ucd08\u0d2c\u435c\u5707\u3730\uc9c2\ucc13\u9a58\u60b9\u93d8\u6e8e\ua64e\u433e\u3d18\u36a9\u476e\uc6be\uc6ac\u4357", "\uda43\udde0\udbf0\udf2b\ud8bd\udd58\udb93\udcb9\uda4c\ude32\udb2f\udece\uda7b\udda6\uda39\udcc9\udad7\udd29",
        43, 36112, 307308545, 7598680760630625528L, 42181L, true, false, (char) 26595, (char) 56023,
        Double.longBitsToDouble(0x3fef23417cd3763fL), Double.longBitsToDouble(0x3fe45701e9927eb3L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud852\ude18\uda3e\udef3\ud9bc\udcbe\uda5f\udd84\ud96e\udc9d\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud9be\udc20\ud8b6\uddd8\udbde\udf86\ud948\udc0b\ud81a\udca4\ud8b3\udccf\ud91d\udc37\ud939\udeef\udb84\udf27\uda04\ude08\ud827\udccf\udb90\udcb9\udb45\udc95", "\ud5e4\u82fa\u218d\u6ee3\u7e56\u293f\ud47a\u49f5\ucce5\u656b\u0d62\u435c\u7cf3\u371f", "\ud8cf\udf6b\ud86d\udc21\uda18\ude93\uda4f\ude61",
        9, 42053, -783817025, -6918979870065432926L, -75882L, true, false, (char) 39020, (char) 52548,
        Double.longBitsToDouble(0x3fd7638714a4329eL), Double.longBitsToDouble(0x3fd70fb018d68570L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 4, "\udb3e\udd1a\ud978\udd16\uba09\udb13\ude79\ud852\ude18\uda3e\udef3\u4329\ud9bb\udf86\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud9be\udc20\ud8b6\uddd8\udbde\udf86\ud948\udc0b\ud81a\udca4\ud8b3\udccf\ud91d\udc37\ud939\udf6b\udb84\udf27\udbbf\udf65\ud827\udccf\udb90\udcb9\udb45\udc95", "\u0bb0\u1b85\u388e\u76ae\u8669\u293f\ud47a\u49f5\ucce5\uade0\u0d62\u435c\u5707\u36b6\uc9c2\ucc13\uaf57\u60b9\u93d8\u6e8e\ua64e\u5512\u5f3d\u36a9\u476e\uc6be\uc6ac\u4357", "\uda38\ude9e\udb34\udde8",
        15, 32095, 414353598, -8125358546517188035L, -4208L, true, true, (char) 29289, (char) 43383,
        Double.longBitsToDouble(0x3fd25064990c5f0aL), Double.longBitsToDouble(0x3fcca36b97ddc6ecL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 4, 3, "\udb3e\udd1a", "\ub01d\u7a22", "\ud9bb\udf86\ud94a\udeba\ud81a\udeeb\uda54\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud9be\udc20\ud8b6\uddd8\udbde\udf86\ud95a\udf0b\u4188\udb90\udd0e\uda2a\udde3\ud939\udf70\udb84\udf27",
        42, 91168, -1734015060, 1131155199025879876L, 28304L, false, false, (char) 21, (char) 55401,
        Double.longBitsToDouble(0x3feaae494d516b99L), Double.longBitsToDouble(0x3fd01c8143e22654L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 1, 4, "\udb3e\udcff\ud978\udd16\uba09\uda39\udf8c\uda4c\udd9a\uda41\udfa5\u4329\ud9bb\udf86\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\uda02\ude61\ud8b6\uddd8\udbde\udf86\ud948\udc0b\ud81a\udca4\ud8b3\udccf\ud91d\udc37\ud939\udeef\udb84\udf27\udbbf\udf65\ud827\udccf\udb90\udcb9\udb45\udc95", "\u9603\u2122\ub7cc\u4082\u7e56\u293f\ua9ad\u4928\u510b\ub86e\u0d62\u435c\ubbc3\u7055\uc9c2\ucc13\uaf57\u60b9\u93d8\u9ba9\u1e97\u3106\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\udb5d\udef3\udb1f\udc0e",
        2, 56059, 716343486, -8125358546517188035L, -4208L, true, true, (char) 29289, (char) 43383,
        Double.longBitsToDouble(0x3fd25064990c5f0aL), Double.longBitsToDouble(0x3fcca36b97ddc6ecL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud852\ude18\uda3e\udef3\u4329\ud9bb\udf86\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud9be\udc20\ud8b6\uddd8\udbde\udf86", "\u3677\u1c6b\u2b5e\u2944\u4b84\ua380\u9cb4\uce43\ud5f5\u5243\ud5e4\ubba9\u388e\u76ae\u7e56\u293f", "\ucce5\udaf9\udcfc\ud906\udf4a\udb2c\udd12\ud886\ude8d\ud8a6\udd04\ud968\udf74\ud829\udeec\ud8cf\udf6b\ud86d\udc21\ud9e2\ude98",
        12, 98389, 953584053, -3366468490033964937L, 63596L, false, true, (char) 23621, (char) 39020,
        Double.longBitsToDouble(0x3fc2851635d8e1c4L), Double.longBitsToDouble(0x3fd52194f2e1f71cL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 4, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud852\ude18\uda3e\udef3\u4329\ud9bb\udf86\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud9be\udc20\ud8b6\uddd8\udbde\udf86\ud948\udc0b\ud81a\udca4\ud8b3\udccf\ud91d\udc37\ud939\udeef\udb84\udf27\udbbf\udf65\ud827\udccf\udb90\udcb9\udb45\udc95", "\ud5e4\u1b85\u388e\u76ae\u7e56\u293f\ud47a\u49f5\ucce5\u656b\u0d62\u435c\u5707\u3730\uc9c2\ucc13\uaf57\u60b9\u93d8\u6e8e\ua64e\u5512\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\udb5d\udef3\udbdd\udd0e",
        1, 56059, 414353598, -8125358546517188035L, -4208L, true, true, (char) 29289, (char) 43383,
        Double.longBitsToDouble(0x3fd61c52390c5f0aL), Double.longBitsToDouble(0x3fcca36b97ddc6ecL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 1, 4, "\udb3e\udd1a\uda9f\udc0a\uba09\udbab\udf44\ud852\ude18\uda3e\udef3\u4329\ud2e0\ud94a\udef3\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud9be\udc20\ud8b6\uddd8\udbde\udf86\ud948\udc0b\ud81a\udca4\ud8b3\udccf\ud91d\udc37\ud939\udeef\udb84\udf27\udbbf\udf65\ud827\udccf\udb90\udcb9\udb45\udc95", "\ud5e4\u1b85\u65a2\u76ae\u7e56\u293f\u03c8\u49f5\ucce5\u656b\u0d62\u435c\u5707\u3730\uc9c2\ucc13\uaf57\u60b9\u93d8\u6e8e\ua64e\u5512\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\udb5d\udef3\udb5e\udccf",
        3, 55998, 414353598, -8125358546517188035L, -4208L, true, true, (char) 29289, (char) 43383,
        Double.longBitsToDouble(0x3fd25064990c5f0aL), Double.longBitsToDouble(0x3fcca36b97dc10bcL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 1, 4, "\udb3e\udd1a\ud978\udd16\udbed\udc01\udbab\udf44\ud852\ude18\uda3e\udef3\u4329\ud9bb\udf86\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud9be\udc20\ud8b6\uddd8\udbde\udf86\ud948\udc0b\ud81a\udca4\ud8b3\udccf\ud91d\udc37\ud939\udeef\udb84\udf27\udbbf\udf65\ud827\udccf\udb90\udcb9\uda4f\udc28", "\ucc21\u715a\u0e6f\u76ae\u7e56\u293f\ub873\u7646\ucce5\u656b", "\udb57\ude0c\ud887\udfa3\ud968\udf74\ud829\udeec",
        5, 65516, -1649754780, 2801586288551671288L, -93506L, false, false, (char) 22513, (char) 23621,
        Double.longBitsToDouble(0x3fd413f2b9285162L), Double.longBitsToDouble(0x3fd763871aa4329eL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 1, 4, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud852\ude18\uda3e\udef3\ud924\udf32\ud9bb\udf86\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud9be\udc20\ud8b6\uddd8\udbde\udf86\ud948\udc0b\ud81a\udca4\ud8b3\udccf\ud91d\udc37\ud939\udeef\udb84\udf27\udbbf\udf65\ud827\udccf\udb90\udcb9\udb45\udc95", "\ud5e4\u1b85\u388e\u76ae\u7e56\u293f\ud47a\u49f5\ucce5\u656b\u0d62\u435c\u5707\u3730\uc9c2\ucc13\uaf57\u60b9\u93d8\u6e8e\ua64e\u5512\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\udb5d\udef3\udbdd\udd0e",
        8, 80884, 414353525, -8125358546517188035L, -4208L, true, false, (char) 42078, (char) 32293,
        Double.longBitsToDouble(0x3fd25064990c5f0aL), Double.longBitsToDouble(0x3fcca36b97ddc6ecL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer$StringKD:@?\0121=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer$StringKD:@?\012",
        Z.run(T, 2, 5, 5, 8, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud852\ude18\udbd0\udcfd\ud805\udf0e\ud9bb\udf86", "\ucd26\u4590\u9c35\u7fd2\u6c6c\u4009\u2e92", "\ud8b6\udd81\ud91d\udc37\ud939\udeef\ufbab\udbae\udc13\ud827\udccf\ud90e\udf37\u3740\udbe3\udc92\ud8d2\udf42\ud811\ude97\ud873\udc36\uda03\ude0a\ud981\ude48\ud923\udc1f\ud8ee\udf32",
        59, 83433, 52453, 3098646364643076684L, -29118L, true, true, (char) 25767, (char) 14956,
        Double.longBitsToDouble(0x3fe4513aefb4872eL), Double.longBitsToDouble(0x3fb912c7041ced50L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.Date |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 1, "", "\u2012\ub01d\ua21e\u87ae\uc063\u47fc\ua302", "\ud8ea\udc74\ud989\udc88",
        0, 94216, 1045589548, -5155495671633749335L, 31072L, false, true, (char) 22374, (char) 48931,
        Double.longBitsToDouble(0x3fbaac9ea0bbe000L), Double.longBitsToDouble(0x3fea2078c9970fc6L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Class:[Ljava.lang.String; |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 1, "", "\u2012\ub01d\ua21e\u87ae\uc063\u47fc\ua302\u0e5a\ucd26\u2f97\u9c35\000\u5cab\u4009\ua333\ub1b8\u4de9\u59d9\000\000", "\udbee\udc0e\udadf\udf4e",
        10, 20348, 1561653655, 7582496913482280195L, 40147L, false, true, (char) 14959, (char) 41344,
        Double.longBitsToDouble(0x3fe35bc7a4a4179dL), Double.longBitsToDouble(0x3fd1f629817acdfcL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 2, "\ud8d8\udef4", "\ub01d\ua21e", "\uda07\udff8\ud94a\udeba\ud837\ude6b\uda4a\ude89\ud98e\udf07\ud955\uddcb\000\ud98a\udc73\ud8b6\uddd8\ud87c\udc9d\ud95c\udc70",
        7, 47243, 0, -927425280L, 30071L, false, true, (char) 349, (char) 17643,
        Double.longBitsToDouble(0x3fe30939d95665b8L), Double.longBitsToDouble(0x3fb96038c263cf00L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Comparable |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 1, "", "\u2012\ub01d\ua21e\u87ae\uc063\u47fc\u1515\uc886\ucd26\u300f\u953d\000\u5cab\u4009\ua333\ub1b8\u4de9\u59d9\000\000\u937b\u3c8d\u2fdd\u2af7", "\udaf1\udf51\ud8f4\ude3c\uda32\udc4d\ud84f\udfdd\udb57\udee7\udae6\uddaf\ud982\udf4d\udb16\udfe8\udb71\udc4a\ud940\udc2c\ud833\udc52\ud9a7\udf85\ud991\udd66\ud855\udda0\ud9a6\udd5d",
        6, 32250, 1754450287, 681616448141364260L, 25095L, false, false, (char) 21567, (char) 12273,
        Double.longBitsToDouble(0x3fe64767d1c6c8bfL), Double.longBitsToDouble(0x3fe66c9328ed5adfL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=null |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 6, 6, 1, "", "\u2012", "\uda01\uddb0\udb66\udf67\u7e9a\ud94a\udeb6\ud80b\udc05\uda4a\ude89\ud8ea\udc74\ud961\udc75\000",
        -2, 48156, 0, 7725038955336067717L, -100000L, false, false, (char) 40191, (char) 13171,
        Double.longBitsToDouble(0x3fe2cefe50009548L), Double.longBitsToDouble(0x3f977c006881e320L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 5, 5, 2, "\udad6\udfce\ud928\udd06\uda29\udc4b\ud989\udca7\ud920\udf64\ud86e\udfde\uda77\ude6e\ud9ca\udf2f\ud986\udf91\udab7\udc39\ud85d\udea3\ud8ae\ude81\udbfc\udd60\ud8b9\udfa6\ud9b4\udebe\udb83\ude2f\ud9c7\udf8b", "\u5032\u0d48\u0a31\ud411", "\udaa2\udd10\udbca\uddaa\udbe3\udc31\ud8d2\udf42\udab4\udde7\udac3\udd2e\udb62\udeb0\u38a8\uda70\udf30\ud8fc\udecd\ud80e\udd6a\udb7e\udebc\ud9ad\udc4a\ud809\udfde\ud906\udf4a\udaa7\udc6f\ud8a1\udde9\ud887\udfde\ud968\udf74\ud829\udeec\ud9ab\udd04\udbe5\udd8e\uda66\udd47\ud981\udfea\ud99b\ude9f\ud8d7\udd08\u99ab\udb32\udcfb\udb24\udffe",
        24, 72895, -568245465, -2155608280923951267L, 40619L, true, true, (char) 64852, (char) 15620,
        Double.longBitsToDouble(0x3fee1ae47f76c3beL), Double.longBitsToDouble(0x3fe4a29e8d5bf9faL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbc7\ude41\uda68\udf21\ud8ce\ude05\ud8cd\udee4\ud9e8\udcad\uda31\udf36\udba3\udff7\udb9f\uddd7\udbf0\udc43\udb0d\ude1c\udb45\udc95", "\ud5e4\u1b85\u3a09\u9424\u8c2f\u37db\ud47a\u49f5\ud33c\u360f\u0d62\u1b0a\ud691\u3730\u2d9d\ucbfe\ua463\ucd83\u12a9\u9ae7\ua64e\u1aa7\uaeac\ucda0\u476e\u87c5\u0a43\ubc3f", "\uda6d\uded0\u511c\ud94f\udd0b\uda35\udf0e\ud929\udf29\ud8ec\ude9d\udb6c\udefe\uda39\udcc9\udad7\udd29\ud942\udee3\udb29\udef6\ud934\udd15\udbab\ude1a\uda3c\udd7c\ud8f3\udfef\udb47\udd06",
        4, 21143, 174037924, -6681166226300202657L, 57798L, false, true, (char) 9201, (char) 35752,
        Double.longBitsToDouble(0x3fc1f6a7cc4d8e8cL), Double.longBitsToDouble(0x3fe982e6b2931292L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 3, 8, 2, "0\ud953\udc48", "\000\u01ad\uc1ad\u4778\ub702\u0eda\u314c\u2f97\u9c35\u7fd2\u5cab\u4009", "\udbf4\ude91\000\000\000\ud904\udfc1\udbb2\udead\000\000\ud9d6\udc0a\udbdc\udced\ud8d2\udf42\u0ad0\000\000\udb41\udddf\udb74\udd04",
        34, 32897, 8706379, 9851624184872960L, 20895L, false, false, (char) 15113, (char) 54143,
        Double.longBitsToDouble(0x3feda43970644b1cL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 3, 1, "\000", "", "",
        40, -1000, -1912602624, 8207366134231875302L, -34464L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.net.URI:\u8477\ud81d\udd57\ub968\udb61\udc7f\ud821\uddb9\udb87\udc20\udbe4\udf66\ud9bb\udfe8\ud8b8\udf51\ud84a\udc18\ud9c3\udc99\ud910\udd0c\ub95d\ud8e8\udc0b\ud861\ude79\udb51\ude89\udb73\udf55\ud987\udc47 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.net.URI:\u8477\ud81d\udd57\ub968\udb61\udc7f\ud821\uddb9\udb87\udc20\udbe4\udf66\ud9bb\udfe8\ud8b8\udf51\ud84a\udc18\ud9c3\udc99\ud910\udd0c\ub95d\ud8e8\udc0b\ud861\ude79\udb51\ude89\udb73\udf55\ud987\udc47 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 0, 0, 7, "\u8477\ud81d\udd57\ub968\udb61\udc7f\ud821\uddb9\udb87\udc20\udbe4\udf66\ud9bb\udfe8\ud8b8\udf51\ud84a\udc18\ud9c3\udc99\ud910\udd0c\ub95d\ud8e8\udc0b\ud861\ude79\udb51\ude89\udb73\udf55\ud987\udc47", "\u83c9\ud1a6\u41ac\u3c8d\u9a9f\ua9a2\u76ec\u2eb8\ua29d\ud1b3\u6dc4\ub010\u8f4c\ub066\u993c\u583a\ua8b1", "\u3649\udbb8\ude16\ud874\udc42",
        13, 59108, -814048961, 2040459306346224034L, -75554L, true, true, (char) 23554, (char) 48407,
        Double.longBitsToDouble(0x3fddd9b0ad8f32c8L), Double.longBitsToDouble(0x3fa411966366a080L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 1, "\udbdd\udc13\udacf\udc14\udab3\uddf8\udb71\udeb7\ud80d\udf75\001\udb77\udf3b\ud928\udc40\ud94a\udeba\ud81a\udeeb\ud887\udcba\uda27\ude52\ud984\udde2\ud8fc\udf89\udb5c\udef9\ud8b6\uddd8\udbde\udf86\udb90\udf11\uda78\udca8\ud9ce\udc86\ud8a7\udc57\uda8f\ude46\ud935\udfbf\udb8b\udd6f\udbed\udfb5\udb0d\ude4c\udb45\udc95", "\ud5e4\u1b85\u3836\ua5d1\u7503\u1012\ubcd6\000\ud31f\u008c\u0d62\000\u5625\u00c1\uc9c2\ucc13\u91c1\u60b9\u93d8\u9690\ua64e\u1aa7\uaf5f\u36a8\u473c\uc385\uc6da\u4357", "\uda43\udde0\ud9ef\udf75",
        13, 2408, 414353598, -8125358546517188035L, -4208L, false, false, (char) 0, (char) 11883,
        Double.longBitsToDouble(0x3fe382654b652f85L), Double.longBitsToDouble(0x3fd08d6cb0922302L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Character:\u0092 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 1, 3, 0, "\u0092", "\ub01d\u45fe", "\ud9bb\udfe8\ud94a\udeba\udb2e\udddf\uda7a\udfc2\000\000\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b",
        4, 70281, 1194711103, 3336582593221533017L, -96327L, false, false, (char) 24566, (char) 0,
        Double.longBitsToDouble(0x3e1a000000000000L), Double.longBitsToDouble(0x3fd000000bfcf5c4L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer$StringKD:@?\0121=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer$StringKD:@?\012",
        Z.run(T, 2, 5, 5, 2, "\udad6\udfce\ud928\udd06\uda29\udc4b\ud989\udca7\ud920\udf64\ud86e\udfde\uda77\ude6e\ud9ca\udf2f\ud986\udf91\udab7\udc39\ud85d\udea3\ud8ae\ude81\udbfc\udd60\ud8b9\udfa6\ud9b4\udebe\udb83\ude2f\ud9c7\udf8b", "\u3c32\u4248\u0a31\ud411\u851e\u1b94\u0415\uabdc\ud5f5\u5243\u3974\u25ca\ua661\u42ba\u8630\u60da\ud47a\u49f5\ud33c\u008c\u0d62\u435c\u6cdc\u376b", "\ud9ab\udd04\udbe5\udd8e\uda66\udd47\ud981\udfea",
        0, 87020, -1605779633, -4395077195012667555L, 48015L, true, true, (char) 39889, (char) 4467,
        Double.longBitsToDouble(0x3fece1151d46f6d0L), Double.longBitsToDouble(0x3fe2e423a509b98dL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 3, 8, 2, "0\000", "\000\u01ad\uc1ad\u4778\ub702\u0eda\u314c", "\ud8fc\udf89",
        -2, 36548, -550505098, 7724950692818610821L, -100000L, false, false, (char) 0, (char) 43610,
        Double.longBitsToDouble(0x3ec9400000000000L), Double.longBitsToDouble(0x3d16400000000000L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=null\0121=java.lang.Integer:3 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 5, 3, 0, "3", "\ub01d\u45fe", "\ud9bb\udfe8\ud94a\udeba\udb2e\udddf\uda7a\udfc2\000\000\ud8fc\udf89\udaa8\udc6c\ud8b6\uddd8\udbde\udf86\ud948\udc0b",
        4, 70281, 1194711103, 3336582593221533017L, -96245L, false, false, (char) 24566, (char) 0,
        Double.longBitsToDouble(0x3e4c86aa64000000L), Double.longBitsToDouble(0x3fefe56fd769c63cL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Character:\u0092 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Character:\u0092 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 1, 0, 0, "\u0092", "\ua100\u9d9e", "\000\ud94a\udeb6\udb2e\udddf\uda7a\udfc2\000\000\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b",
        4, 70281, 1194711103, 3336582594148998489L, -96327L, false, false, (char) 24566, (char) 0,
        Double.longBitsToDouble(0x3e1a000000000000L), Double.longBitsToDouble(0x3fd000000bfcf5c4L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 5, 3, 0, "3\ud978\udd16\uba09", "\ubb9d\ub9c0\u9d0c\ua302\u2e3c\u64da\000\000\u7fd2", "\udbde\udf86\ud948\udc0b\uda3f\udc56\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17",
        15, 74619, 1598898296, 725849473024L, -24001L, false, true, (char) 62885, (char) 62118,
        Double.longBitsToDouble(0x3fe01fb2f17aec46L), Double.longBitsToDouble(0x3feef7174bdc8883L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Integer:3 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 3, 3, 0, "3", "\ub01d\u45fe", "\ud9bb\udfe8\ud94a\udeba\udb2e\udddf\udaa6\udfb8\000\000\ud8fc\udf89\udaa8\udc6c\ud8b6\uddd8\udbb1\udf86\ud948\udc0b",
        4, 70281, 1194711103, 3336582593221533017L, -96245L, false, false, (char) 24566, (char) 0,
        Double.longBitsToDouble(0x3e4c86aa64000000L), Double.longBitsToDouble(0x3fefe56fd769c63cL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Double:3.0 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Double:3.0 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 2, 2, 0, "3", "\ub01d\u45fe", "\ud9bb\udfe8\ud94a\udeba\udb2e\udddf\uda7a\udfc2\000\000\ud8fc\udf89\ud9a5\udfcb\udae0\udedd\udbde\udf86\ud948\udc0b",
        4, 65621, 1194711103, 3336582593221533017L, 39119L, false, false, (char) 24566, (char) 0,
        Double.longBitsToDouble(0x3e4c86aa64000000L), Double.longBitsToDouble(0x3fefe56fd769c63cL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 5, 3, 0, "3\000\000", "\ubb9d\ub9c0\u9d0c\ua302\u2e3c\u64da\000\000\u7fd2", "\udba1\ude10\ud948\udc0b\uda3f\udc56",
        -4, 82103, 776858673, -3983260864498734406L, -17960L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe90d54cffcadfaL), Double.longBitsToDouble(0x3feb4e31e467c63fL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 1, "\udb3e\udd1a\ud978\udd16\uba09\udbab\udf44\ud80d\udf75\uda01\uddb0\udb66\udf67\ud9bb\udfe8\ud94a\udeba\ud81a\udeeb\uda4a\ude89\ud8ea\udc74\ud961\udc75\ud8fc\udf89\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udb4f\uddde\ud9ce\udc86\ud91d\udc71\uda31\udeeb\u8a17\ud810\udcd4\udbee\udc0e\udb0d\ude4c\udb45\udc95", "\ud5e4\u1b85\u388e\ua5d1\u8c2f\u84b7\ud47a\u49f5\ube3c\u008c\u0d62\u435c\u5f58\u4eaf\uc9c2\ucc13\uc845\u1e8e\u938b\u6e8e\ua64e\u1aa7\uaf5f\u36a9\u476e\uc6be\uc6ac\u4357", "\uda43\udde0\udbf0\udf2b",
        -2, 2419, 414353598, -8125358546517188035L, -4208L, true, false, (char) 565, (char) 11883,
        Double.longBitsToDouble(0x3fe382654b652f85L), Double.longBitsToDouble(0x3fe728db75f771ecL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 3, 1, "-", "", "\ud8e3\ude9c\000\ud850\udd48\ud94a\udeba\ud833\udd29\ud952\uddec\udbc4\udcf4\ud9a4\udc91\uda14\udf8d\000\000\000\000\uf727\udb09\ude79\ud9ee\ude30\uda35\ude52\ud840\ude91\ud997\ude3d\udb38\udfc6\ud9e7\udeb4\ud89f\udef7\udab9\ude46\ud9d4\ude56\ud8aa\udf36\udb29\udc4b\ud9d3\udd43\udad4\udf29\ud978\ude57\udb20\uddbc\u537e\ud9a2\udc59\ud991\udca8\udb68\udf1c\ud8ac\udf52\udaca\udf11\ud8d7\udf2c\udb10\udff3\uda04\udda9\uda34\udd70\ud82e\udc74\uda70\udcaa\ud8ca\ude9e\ud913\udf72\ud903\udd29\uda8a\ude57\ud845\udf19\ud9a0\udc1d\udafa\udf74\uda2d\udf84\ud958\udfae\ud970\ude12\udad2\udf7b\ue580\ud8d4\uddd4",
        41, 69726, 1184196263, -7283185374689452955L, -10463L, true, false, (char) 35982, (char) 32887,
        Double.longBitsToDouble(0x3fe13f0359c68861L), Double.longBitsToDouble(0x3fd269fc446fb114L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 4, 6, 0, "-\000\ud8ce\udf67\u0087\000", "\u88f6\u3b28\u642c\u30ca\u2f97", "\ud98a\udc73\ud8b6\uddd8\udbde\udf86\ud948\udc0b\udbf4\ude91\000\000\000\ud904\udfc1\udbc4\udea1\000\000\ud809\udea1",
        11, 87956, -1961035049, 7991394565240862078L, -6984L, true, true, (char) 42859, (char) 39684,
        Double.longBitsToDouble(0x3fd33c4b051e881cL), Double.longBitsToDouble(0x3fe05ea6e88929edL)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Long:3 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Long:3 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 4, 4, 8, "3", "\u4b7c\u4601", "\ud908\uddac\ud942\udc87\ud9ba\udc63\ud89a\udf53\ud948\ude18\udbf7\udc60\ud8fc\udf89\ud9a5\udfcb\udae0\udedd\udbde\udf86",
        28, 86541, 383765664, 5131245113712700465L, -17960L, false, false, (char) 36364, (char) 12895,
        Double.longBitsToDouble(0x3fa3c0de7fcad590L), Double.longBitsToDouble(0x3feb4e31e06d1bd6L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 3, 0, "-\ud8fc\ude3d\u00bb", "\uac05\000\uc8e2\ua302\uc29c\uc6e6\u191a\u136d\u0444\000\000\000\000\ub894\u2251\u5e03\ub7b9\u7119\ub86c\u1f9c\u5fd2\u7162\u3ac7\u127b\ubbb4\u692b\ubfa8\u8f42\u3577\u891e\u904d\ud77b\u6fb7\u68b1\u47c6\u0d07\u6b8f\u54dd\ua2b1\u0156\uaa03\u2f93\u0b4f\u6884\u2067\u904a\u6203\u0434\u1508\ucf15\u6582\u7058\u0bf6\u7c16\u7c56", "\udb82\udc0a\ud851\udf88\udaca\uddd5\ud840\udca6\udad4\udd94\ud875\udda0\ud8cc\udfe9\uda39\udfd5\uda8e\ude0c\ud88a\udfd1\udaae\uded2\ud8be\udcfd\u709f\udb93\udf97\udbcd\uddf1\ud966\ude35\ub90b\uda9c\udd0b\ud8a0\ude6c",
        50, 4285, -1672349730, 7720801733208073258L, 60380L, true, true, (char) 5405, (char) 36499,
        Double.longBitsToDouble(0x3fe3a60d0d737a36L), Double.longBitsToDouble(0x3fe25d438719dc48L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 3, 4, "-\000\000\ud913\udf10\ud890\udf0e\ud8e3\ude9c\000\ud9f6\udc5a", "\uc6e6\u191a", "\000\000\000\000\uf727\udb09\ude79",
        10, 97251, 1289010698, 651638439944150455L, -54818L, false, false, (char) 24729, (char) 9021,
        Double.longBitsToDouble(0x3fd4c95e42a7de08L), Double.longBitsToDouble(0x3feaf5d8c5f2fc88L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=null\0121=java.lang.Byte:3 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 5, 0, 0, "3", "\ub01d\u45fe", "\uda2f\uddeb\ud94a\udeba\udb2e\udddf\uda7a\udfc2\000\000\ud8fc\udf89\udaa8\udc6c\ud8b6\uddd8\udbde\udf27\udaa9\udcdc",
        2, 70281, 1194711103, 3336582593221533017L, -93387L, false, true, (char) 12636, (char) 0,
        Double.longBitsToDouble(0x3e4c86aa64000000L), Double.longBitsToDouble(0x3fefe56fd769c63cL)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.Byte:3 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Byte:3 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 0, 0, 0, "3", "\u8656\u461d", "\uda2f\uddeb\ud94a\udeba\udb2e\udddf\uda7a\udfc2\000\000\ud8fc\udf89\udaa8\udc6c\ud8b6\uddd8\udbdc\udee6\ud86c\udf09",
        2, 70281, 1194711103, 3336582593221533017L, -93387L, false, true, (char) 12636, (char) 0,
        Double.longBitsToDouble(0x3e4c86aa64000000L), Double.longBitsToDouble(0x3fefe56fd769c63cL)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=new com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Short:3 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 8, 0, 0, "3", "\000\u45fe", "\uda2f\uddeb\uda37\udc11\ud83c\udffe\u00b4\000\000\ud8fc\udf89\u9eac\000\udbde\udf27\ud82a\uddbd",
        3, 70281, 1194711103, 21933268404273152L, -100000L, false, true, (char) 12636, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.Float:3.0 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Float:3.0 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 0, 1, 4, "3", "\u8656\u6e25", "\uda2b\udc1b\ud94a\udeba\ud926\ude3a\udb77\ude4d\ud83f\udc3e\000",
        7, 68116, 1045589548, -2674868698625187872L, 1969L, false, false, (char) 13140, (char) 52133,
        Double.longBitsToDouble(0x3fdbac8b8c57a97aL), Double.longBitsToDouble(0x3fd52e5e3e1e349aL)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Short:3 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Short:3 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 0, 0, 0, "3", "\000\u45fe", "\uda2f\uddeb\uda37\udc11\ud83c\udffe\u00b4\000\000\ud8fc\udf89\u9eac\000\udbde\udf27\ud82a\uddbd",
        3, 70281, 1194711103, 21933268404273152L, -100000L, false, true, (char) 12636, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Integer:3 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 0, 1, 4, "3", "\uad88\u6e2f", "\uda2b\udc1b\ud94a\udeba\ud926\ude3a\udb77\ude4d\ud83f\udc3e\000",
        5, 68042, 1045589548, -2674868698625187872L, 1969L, false, false, (char) 13140, (char) 52133,
        Double.longBitsToDouble(0x3fdbac8b8c57a97aL), Double.longBitsToDouble(0x3fd82e5e3e1e349aL)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Double:3.0 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\0121=java.lang.Double:3.0 |this=com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:@?\012",
        Z.run(T, 2, 0, 1, 4, "3", "\u8656\u6e25\u7be2\ucb36\u9c6a\ua302\ud63c\u3981", "\ud8fc\udf89\udaa8\udc6c\ud8b6\uddd8\udbdc\udee6\ud86c\udf09\ud908\udd23",
        8, 81860, 776858673, -3983260865557311046L, 81934L, true, true, (char) 43954, (char) 63268,
        Double.longBitsToDouble(0x3fe7371edd8022f0L), Double.longBitsToDouble(0x3feee3c314acedb3L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|deserializeKey|java.lang.String,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:int,java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|_parse|java.lang.String,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:int,java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|_parseDouble|java.lang.String|new:com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:int,java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|_parseInt|java.lang.String|new:com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:int,java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|_parseLong|java.lang.String|new:com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:int,java.lang.Class",
    "M|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|forType|java.lang.Class|static",
    "M|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|getKeyClass||new:com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:int,java.lang.Class",
    "C|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|<init>|int,java.lang.Class",
    "C|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|<init>|int,java.lang.Class,com.fasterxml.jackson.databind.deser.std.FromStringDeserializer",
    "M|com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer|deserializeKey|java.lang.String,com.fasterxml.jackson.databind.DeserializationContext|new:com.fasterxml.jackson.databind.deser.std.StdKeyDeserializer:int,java.lang.Class",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
