package com.fasterxml.jackson.databind.type;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeBindings_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 18, 2, 1, "\udaf2\udf92", "\u3dba\u2da6\u8025", "\ud9f0\ude59\uda70\udf7e\uda5f\udedf\uda81\ude6e\ud9de\uddce\ud88b\udf9f\uda7b\udd3d\ud846\uddce\udbb6\udc67",
        -5, 47890, -310689602, -7154607321655255015L, -40244L, true, false, (char) 61667, (char) 34644,
        Double.longBitsToDouble(0x3fdbac9f39496c0eL), Double.longBitsToDouble(0x3fea988adda73438L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 20, 2, 21, "\udb9b\udc4f\ud92f\udcaf\udba3\udfbe\ud887\udcbe\udb57\udf73", "\u8455\ud23d\u872e\u5a2b\uc124\u0873\u59c2\u73d3\u7fcb\u7e18\u150e\ucd43\ua780\u8bf9\ubf4d\u0947\uc487\u6aa9", "\uda1e\udde3\ud92c\udd6a\uea3b\ud8e8\udf3c\udb2a\ude3a",
        30, 28148, -386080829, 3874135740837786187L, 17451L, true, true, (char) 25207, (char) 4975,
        Double.longBitsToDouble(0x3fad44a375272960L), Double.longBitsToDouble(0x3fc723ef48addaa4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 19, 2, 12, "\udaf2\udf92", "\u3dba\u57d7\u8857\u2a9d\u03aa\u6202\u8fc7\u1b91\u50ce\u66f8", "\ud846\uddce\uda75\udf15\uda18\udd8e\u0081\uda61\udfa6\uecb2\uda22\udf3d",
        45, 48146, -1012755915, -3819872085234093071L, -92337L, false, true, (char) 39595, (char) 6318,
        Double.longBitsToDouble(0x3fda73438ac9a38aL), Double.longBitsToDouble(0x3fee64b06a49dd4aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 18, 2, 1, "\udafd\udfab", "\u3dba\u2da6\uba25", "\ud845\udf02\uda70\udf7e\uda5f\udedf\uda81\ude6e\ud9de\uddce\ud88b\udf9f\uda7b\udd3d\ud846\uddce\uda55\uddd6",
        40, 53569, 1791828624, -7154607321655255015L, -40244L, true, false, (char) 61667, (char) 49976,
        Double.longBitsToDouble(0x3fdbac9f39496c0eL), Double.longBitsToDouble(0x3fea988adda73438L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 18, 2, 1, "\udaf2\udf92", "\u3dba\u2da6\u8025", "\000\000\uda5f\ude62\uda81\ude6e\ud9de\uddce\ud88b\udf9f\u00f2\000\000",
        1, -1000, 0, 894722048L, -100000L, true, true, (char) 27161, (char) 63835,
        Double.longBitsToDouble(0x3fc68cbed35b9340L), Double.longBitsToDouble(0x3feada83872cea01L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 15, 16, 1, "\udaf2\udf92", "\u3dba\u2da6\u8025\u7a7f\uce7b\u1bc1\u8fa7\u4803", "\udba9\udced\udab7\udd73\ud846\uddce\udbb6\udc67\uda18\udcf7",
        0, 86398, -1665811828, 2527290254113670918L, -6357L, true, true, (char) 52468, (char) 61667,
        Double.longBitsToDouble(0x3fe08d2a19bac9f3L), Double.longBitsToDouble(0x3fc5aba05d4f545cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<> |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[]]\012",
        Z.run(T, 1, 12, 18, 1, "\udaf2\udf92", "\u3dba\ua722\ub3e8\u7a7f\u12f0\ud1a7\u8fc7\u1b91\uc031\u2735\u27c6\ucbac\u7b03\u7e18", "\uda61\udfa6\uecb2\udb1e\udf3b\uda41\udc8e\ud9a5\udf24\ud907\udea6\u01d0\ud978\uddaa\ud834\udee5\uda59\udee1\u555e\udb85\udda9\udb2a\ude66\uda8a\uddd6\udb65\ude0b",
        3, 87272, -748024638, -6951023607142727387L, -99819L, true, false, (char) 39519, (char) 44741,
        Double.longBitsToDouble(0x3fe16bc4b44e92cbL), Double.longBitsToDouble(0x3feddbd74445fe5cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 19, 9, "\udaf2\udf92\ud9c1\udcc1\ud9b8\ude34", "\u0bd8\u94ab\u12f0\ud5cd\u0e53\u3d3c\u049b\u0873\u59c2\u0585\u793e\u7e18\u330e\u5299\u32cb\u2acb\ubf4d\ua05e\u903f\uc9ab", "\uda04\udd3e\uda59\udfa0\u555e\ud910\udd2f\udaed\uded4\ud9ab\udcad\ud8b8\udd6a\udbbd\udf75\ud979\uddfb",
        6, 86797, -1972785071, -4885112935482800157L, -65383L, true, false, (char) 15629, (char) 7826,
        Double.longBitsToDouble(0x3fe954fca306d476L), Double.longBitsToDouble(0x3fd4a0f98c6dac4eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 18, 2, 1, "\udaf2\udf92", "\u3dba\u2da6\u6d5a", "\ud9f0\ude59\uda70\udf7e\uda47\ude52\ud884\udfb3\udbb7\udef3\ud9a7\udc83\ud931\udc2e\ud846\uddce\udbb6\udc67\ud894\udcf5\ud891\udde9",
        56, 81172, 894722073, -1745305403429206534L, -40244L, true, false, (char) 61667, (char) 34644,
        Double.longBitsToDouble(0x3fdbac9f39496c0eL), Double.longBitsToDouble(0x3fea988adda73438L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Integer] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 21, 2, 1, "\udaf2\udf92", "\u3dba\u2da6\u828f", "\udbd3\udc4f\uda70\udf7e\uda5f\udedf\uda81\ude6e\ud9de\uddce\ud88b\udf9f\uda7b\udd3d\ud846\uddce\udbb6\udc67\uda18\udcf7\ud891\udde9\uda61\udfa6\uecb2\uda22\udf3d\uda41\udc8e\ud9a5\udf24\ud907\udea6\ud88a\uded6\ud978\uddaa\ud834\udee5\uda59\udee1\u555e\udb85\udda9\udb2a\ude66\ud81d\udedf\udbae\udff8",
        57, 21188, 633509774, -2281316115151790059L, 50363L, true, false, (char) 53408, (char) 14767,
        Double.longBitsToDouble(0x3fed8133b37b28a1L), Double.longBitsToDouble(0x3fe742b38cdaefeaL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.ArrayStoreException\012",
        Z.run(T, 1, 10, 2, 1, "\udaf2\udf92\ud905\udca3\udb50\uddf3\ud970\udf6b\udb87\udd5b\udb7c\udd52\u0bc5\udbed\ude95\ud9f0\ude94\uda70\udf7e\uda5f\udedf\uda81\ude6e\ud9de\uddce\ud969\udda3\uda7b\udd3d\ud846\uddce\udbb6\udc67\uda18\udd8c", "\u14de\u7360\u0947\uc487", "\ud978\uddaa\ud834\udee5",
        4, 46546, -363076444, -6056104826262839894L, -75817L, false, false, (char) 59265, (char) 54877,
        Double.longBitsToDouble(0x3fe1dee36ae0c473L), Double.longBitsToDouble(0x3fd796ec10d0072cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 3, 18, "\udaf2\udf92", "\u6411O\ub6f6", "\ud9f0\ude59\ud936\udd41\uda5f\udeab\uda12\udf92\ud929\udf74\ud881\udf1f\ud8ff\udd5e\udaa8\udcfe\udbad\udcfd",
        -5, 35778, 1389258546, -7154607321655255015L, -40244L, true, false, (char) 61667, (char) 34644,
        Double.longBitsToDouble(0x3fdbac9f39496c0eL), Double.longBitsToDouble(0x3fe16cb696bf2e18L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 9, 10, "\udaf2\udf92", "\u3dba\u2da6\u8025", "\ud9f0\ude59\uda70\udf7e\uda5f\udedf\uda81\ude6e\ud9de\uddce\ud9f2\udcfa\uda7b\udd3d\ud846\uddce\udbb6\udc67",
        -5, 47890, -310689602, -7154607321655255015L, -40244L, true, false, (char) 61667, (char) 34644,
        Double.longBitsToDouble(0x3fdbac9f39496c0eL), Double.longBitsToDouble(0x3fea988adda73438L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 4, 1, "\udaf2\udf92", "\u3dba\u2da6\u34e3", "\ud9f0\ude59\uda70\udf7e\uda5f\udedf\uda81\ude6e\udb0d\udf90\u8741\uda7b\udd3d\ud846\uddce\udbb6\udc67\uda18\udcf7\ud891\udde9\uda6f\udfa6\uecb2\uda22\udf3d\udae7\udd01\ud9bb\udf5d\ud90d\udea9\ud88a\uded6",
        9, 75230, -1459756527, -8168309058016624216L, -82667L, true, false, (char) 34711, (char) 10654,
        Double.longBitsToDouble(0x3fe9d10213402df0L), Double.longBitsToDouble(0x3fd239f5892e042eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 1, "\udaf2\udf92", "\u3dba\u2da6\u8025", "\ud9f0\ude59\ud901\udd45\ud8da\udd41\udaa6\ude51\ud9de\uddce",
        33, 99874, -456042144, -3730400740720451031L, 80034L, false, false, (char) 61328, (char) 39677,
        Double.longBitsToDouble(0x3fdfa8dd346b1810L), Double.longBitsToDouble(0x3fe4a61d1471c083L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 2, 1, "\udaf2\udf92", "\u3dba\u2da6\ua025\u9100\u12f0\ud1a7\u8fc7\ubaf5\uc124\u0873\u59c2\u751b\ud43e\u7e18", "\uda61\udfa6\uecb2\uda22\udf3d\uda41\udc8e\ud9a5\udf24\ud907\udea6\udb23\udfa3\ud997\udd9c\ud834\udee5\uda59\udee1\u555e\udb85\udda9\udb2a\ude66\uda49\ude76\udb3d\ude64\ud9a8\udc88\ud914\uddb1\u55a1\udaf8\udf61\ud9e1\udfac",
        21, 92690, -942281070, -3871149832423908074L, 84677L, false, true, (char) 54314, (char) 42821,
        Double.longBitsToDouble(0x3fd0afbafa5e3946L), Double.longBitsToDouble(0x3fd15bf97c2be0feL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<>\012",
        Z.run(T, 1, 10, 18, 9, "\udaf2\udf92\ud9c1\udcc1\uf375", "\u8025\uce11\ub784\ud1e6\u8fc7\u1b91\uc124\u0873\u59c2\u751b\ud43e\u1406\u330e\u5299\u32cb\u14de\ubf4d\u0947\uc487\u1cbc", "\ud834\udee5\uda59\udfb2\u555e\udb85\udda9\udb2a\ude66\udbd8\udf9c\uda47\udd47\ud806\uddc2\ud9c2\ude6f",
        13, 38853, -1040913650, -5884522845872927147L, -59087L, false, false, (char) 49577, (char) 39863,
        Double.longBitsToDouble(0x3fdc076ce7f8953cL), Double.longBitsToDouble(0x3fc8669dc8166384L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<>\012",
        Z.run(T, 1, 11, 12, 1, "\udaf2\udfc8", "\u3dba\ucc76\ub568", "\udb5d\udc50\uda1c\udf97",
        17, 68451, -258557236, -4469704679387092949L, 13803L, true, false, (char) 15706, (char) 64991,
        Double.longBitsToDouble(0x3fe4676bd8199cb5L), Double.longBitsToDouble(0x3fdfc3554bf5cf8eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 2, 1, "\ud972\udcc9", "\u0e34\ud470\u802f\ua280\ua9a9\u499e\u99de\u3b91\u1215\u0873\u59c2\u751b\u664d\u7e18", "\udb53\udc90\udae0\udc06\udb3a\udcc7\ud942\ude37\ud871\udf30\ud907\udea6\ud88a\udeba\ud978\uddeb\ud834\udee5\uda59\udee1\ud95c\ude60\ud9f2\udf69\udb4f\ude28\ud8d6\udcbc\ua286\ue750\udbc4\udea7\udbc4\udf0f\udb34\udcbc\ud991\ude3a",
        1, 10405, -1842514709, 6167197238897505932L, -95205L, true, false, (char) 60624, (char) 60924,
        Double.longBitsToDouble(0x3fc36713f3ae4f1cL), Double.longBitsToDouble(0x3fe0c9f0fd502047L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<>\012",
        Z.run(T, 1, 9, 2, 17, "\uda0b\udc7f", "\u7b07\u2da6\u8025\u7a7f\u12f0\u6e91\u0ed8\ub6af\uc124\u0873\ucb67\u751b\ud43e\u7e18\u330e\u5299\u6f08\ud2de\u2c6d\ub603\uc487\ud5a8\ucb54\u1d82\u74b3\u4a02\u020e\ubad4\ubd36\u46a0", "\ud894\ude0c\ud901\udf04\udbd7\ude4e\ud871\udfa8\udb24\udd3b",
        21, 65565, 1153007779, 8428842146518132891L, 79697L, true, true, (char) 61424, (char) 36856,
        Double.longBitsToDouble(0x3f8d14e19f1dea00L), Double.longBitsToDouble(0x3fcac012be6f4790L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<>\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Number] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 11, 21, 21, "\udaf2\udf92", "\ua4f3\u769b\u54b7", "\ud951\udcc0",
        49, 37086, 278736244, -1110494963999151289L, -51038L, false, false, (char) 64718, (char) 41808,
        Double.longBitsToDouble(0x3fdfae7c746b1810L), Double.longBitsToDouble(0x3fe4a61d1626c083L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 2, 1, "\ub497", "\u691c\u2da6\u8025", "\ud9f0\ude59\uda70\udf7e\uda5f\udedf\uda81\ude6e\ud9de\uddce\ud88b\udf9f\uda7b\udd3d\ud846\uddce\udbb6\udc67",
        -5, 47890, -310689602, -3839957996332987701L, -82086L, true, false, (char) 55862, (char) 52468,
        Double.longBitsToDouble(0x3faf2c53211a5430L), Double.longBitsToDouble(0x3fdbac9f39496c0eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Thread$State] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 5, 16, 1, "\ua3c4", "\u3dba\u2da6\u2155", "\ud828\udf57\ud8c1\udc11\uda5f\uded1\uda81\ude6e\ud9de\uddce\uda7e\udfd9\uda4b\udc82\ud9f2\ude75\ud83d\udd51",
        53, 28238, -310689602, -7154607012417609703L, -66789L, true, false, (char) 48243, (char) 44020,
        Double.longBitsToDouble(0x3faf2c53211a5430L), Double.longBitsToDouble(0x3fdbac9f39496c0eL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<>\012",
        Z.run(T, 1, 13, 2, 15, "\udb9b\udc4f\ud92f\udcaf\udba3\udfbe\ud887\udcbe\udb24\uddfa", "\u8455\uc49b\u1a73\u5a77\uc124\u0873\u59c2\u0bc6\u800c\u0794\u0cfa\ucd68\ua780\u8bf9\u6b1c\u4d45\uc487\u2032", "\uda1e\udde3\ud92c\udd6a\uea3b\ud8e8\udf3c",
        44, 16015, -1957956852, 7315485713049536181L, -62501L, false, false, (char) 4975, (char) 24960,
        Double.longBitsToDouble(0x3fea9394b06f3841L), Double.longBitsToDouble(0x3fe7dbb8f124f032L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.String] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 5, 2, 7, "\udaf2\udf92", "\u3dba\u3015\u6c80\u2a9d\u03aa\u6202\u8fc7\u1b91\u50ce\u66f8\ub6e2\u751b\ud43e\u522f\u33a5\u4e28\u1194\u14de\ubf4d\u0947\uc487", "\uda85\udfb9\udbcd\uddfc\uda59\udee1\u555e\udb85\udda9\udb2a\ude66\uda38\udeed\ud844\uddcb\ud9be\ude61\ud809\uded1\ud81c\uddfa\ud916\udd73\udae9\udd0d\ud863\udf49\ud99b\udf2d\uda14\udfef\ue250\ud9c8\udf34\uda7d\udf00\ud953\udf0d\uda87\udc32\udbc8\udc21\ud876\udf81",
        0, 17017, -578316346, 768342235472326460L, -94389L, true, false, (char) 23140, (char) 1998,
        Double.longBitsToDouble(0x3fc10ea6c8841fa0L), Double.longBitsToDouble(0x3fe96c2050da8a67L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 2, 12, "\udaf2\udf92", "\u3dba\u57d7\u8857\u2a9d\u614a\u6217\u8fc7\u1b91\u50ce\u66f8", "\ud846\uddce\uda75\udf15\uda18\udd93\u0081\ud87e\ude95\ud9e0\udf7f\uda22\udf3d",
        5, 48146, -1012755915, -3819872085234093071L, -92337L, false, true, (char) 56397, (char) 30324,
        Double.longBitsToDouble(0x3fda79438ac9a38aL), Double.longBitsToDouble(0x3fe948e06d93eb20L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.Date] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 5, 9, 12, "\udaf2\udf92", "\u211a\uaee0\u4352\u329e\u4c0c\u6fc9\u0f76\u1b20\u2bfd\u667e", "\ud846\uddce\uda75\udf15\u0724\udbff\udfda\udb2b\udc8a\uecb3\uda22\udf3d",
        10, 48146, -1012755915, 7095164560961963912L, -92337L, false, true, (char) 51642, (char) 50958,
        Double.longBitsToDouble(0x3fdd486aeac9a38aL), Double.longBitsToDouble(0x3fee64b069b3184aL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class int] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 21, 12, 12, "\ud8da\udc23", "\u3dba\u57d7\u8857\ucf0b\u03aa\u59f3\u4293\u1b91\u50ce\u66f8", "\ud846\uddce\uda75\udf15\uda18\udd8e\u0081\uda69\udd53\u8439\udb46\udd1d",
        44, 59564, -1012730540, -3819872085234093071L, -92337L, false, true, (char) 41, (char) 6318,
        Double.longBitsToDouble(0x3fda734f4ac9be74L), Double.longBitsToDouble(0x3fee64b06f414f3bL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 6, 12, "\ud9f7\ude93", "\u3dba\u57d7\u8857\u2a9d\u9193\u1124", "\ud939\ude6a\ud9d8\udd4a\ud8a3\udcbf\uda7b\udd3d\ud9af\ude81\ud913\udf6f\uda18\udd88\u0081\uda61\udfa6\uecb2\uda22\udf3d\udabf\udd90\ud9a5\udf24\ud907\udea6",
        19, 76625, -1333415252, -3894520691344066118L, -98125L, true, true, (char) 42793, (char) 32217,
        Double.longBitsToDouble(0x3fe24eea50886e78L), Double.longBitsToDouble(0x3fe26526b91ea4e1L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 13, "\udaf2\udf92", "\u3dba\u57d7\u8857\u2a9d\u03aa\u6202\u8fc7\u1b91\u50ce\u66f8", "\udb4c\uddd1\uda75\udf15\uda18\udd8e\u0081\uda61\udfa6\uecb2\uda22\udf3d",
        45, 48146, -1012755915, -3876273732807182673L, -49105L, true, false, (char) 39811, (char) 6318,
        Double.longBitsToDouble(0x3fe6e06635e0ecedL), Double.longBitsToDouble(0x3fa5fe86fef2a870L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 2, 12, "\uda71\udcad\uda30\udcfb\uf360\ud974\udf6d\ud83c\udfd5\uda74\udca8\udb07\ude87\ud84f\udca5\uda0a\udebb\uda70\udf7e\uda5f\udedf\ud939\ude6a\ud959\udf2b\udb81\udeca\udb03\udf6b\udbfa\ude03\ud91a\udd16\uda18\udd8e\u0081\ud95b\udcc3", "\u0947\uc487", "\uda85\udfb5\udaa0\udc85\ud8e7\udc99\u555e\udac5\udfe2\ud85f\udea4\ud9da\udc86\ud904\udfdc\ud963\uddc0\ud95f\uded4\ud931\udd9a\udacd\udfa4\udb71\udcec\udaa3\udce3\udb18\udc8e\u8767\udb75\udf94\uda70\udf2f\udaec\udd84\ue653\udbed\udc31\ud89a\uddcc\udad8\udc0d",
        38, 43258, 2078808818, 6992824326235289598L, 3514L, false, false, (char) 65069, (char) 23661,
        Double.longBitsToDouble(0x3fc7c92ddcaecc9cL), Double.longBitsToDouble(0x3fe9edb4077ea0aeL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 10, 12, "\udb67\uddb0", "\u3dba\u57d7\u8857\u9b53\u03aa\u6202\u8fc7\u1b91\uc013\u66f8", "\udb60\udefb\uda75\udf02\uda18\udd8e\u0081\uda61\udfa6\uecb2\uda22\udf3d",
        45, 49090, -1012755915, -3819872085234093071L, -36150L, false, true, (char) 44715, (char) 6255,
        Double.longBitsToDouble(0x3fda73438ac9a38aL), Double.longBitsToDouble(0x3fee64b06e49dd4aL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 2, 1, "\udaf2\udf92", "\u8d6c\u5d89\u7b7b", "\000\000\uda5f\ude62\uda81\ude6e\ud9de\uddce\ud88b\udf9f\u00f2\000\000",
        1, -1000, 0, 1129603072L, -100000L, true, true, (char) 27161, (char) 63835,
        Double.longBitsToDouble(0x3fc68cbed35b9340L), Double.longBitsToDouble(0x3feada83872cea01L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 2, 1, "\ud891\udd96", "\u3dba\u55f2\u4675\u8a96", "\udb02\udcd9\uda5f\ude62\uda81\ude6e\ud9f6\udc39\ud975\ude93\udb59\udd16",
        21, -1000, 57856, 0L, -83360L, false, true, (char) 11655, (char) 25205,
        Double.longBitsToDouble(0x3fe4a79220000000L), Double.longBitsToDouble(0x3faf08a7a11a5430L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 2, 1, "\udaf2\udf92", "\u3dba\u2da6\u8025", "\000\000\uda5f\ude62\uda81\ude6e\ud9de\uddce\ud88b\udf9f\u00f2\000\000",
        1, -1000, 0, 894722048L, -73438L, true, false, (char) 942, (char) 58531,
        Double.longBitsToDouble(0x3e469cd000000000L), Double.longBitsToDouble(0x3fa914f3f9ef9bd0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 2, 1, "\udaf2\udf92", "\u3dba\u2da6\u8025", "\u00f1\000\uda5f\ude62\u6875\ud8f8\ude8c\udb02\udf14\u00f2\000\ud856\uddf9",
        46, -1000, 0, 894722048L, 36878L, true, false, (char) 49682, (char) 57766,
        Double.longBitsToDouble(0x3fa914f3f9ef9bd0L), Double.longBitsToDouble(0x3fc68cbed35b9340L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 16, 7, "\udaf2\udf92\uda1c\ude28\ud9f1\udcce\ud974\udf6d\udb87\udd5b", "\ucda0\uc464\u8fa7\u4803\u64ff\u089e\u7480\uc02a\ud43e\u7e18\u330e\u5299\u32cb\u14de\u8eaa\ucb2b\u8f94\u6af6", "\ud82b\udd74\uda59\udee1",
        13, 10237, -283900589, 472761686557916884L, 28993L, true, true, (char) 46891, (char) 53801,
        Double.longBitsToDouble(0x3fee65b68f93b252L), Double.longBitsToDouble(0x3fedda3c03357e08L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 18, 1, "\udaf2\udf92", "\u3dba\ua722\u65ce\u7a7f\u12f0\ud1a7\u8fc7\u1b91\uc031\u2735\u27c6\ucbac\u7b03\u890f", "\uda61\udfa6\uecb2\udb1e\udf3b\uda41\udc8e\ud9a5\udf24\ud907\udea6\u01d0\ud978\uddaa\ud834\udee5\uda59\udee1\u555e\udb85\udda9\udb2a\ude66",
        37, 24793, 2029005233, 748669801750727874L, -51141L, false, false, (char) 56782, (char) 26356,
        Double.longBitsToDouble(0x3feffcb3054e8977L), Double.longBitsToDouble(0x3fe16bc4b44e92cbL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<>\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 18, 1, "\udaf2\udf92\u7dd1\ud804\udcff\ud974\udf6d", "\u7a7f\u12f0\u86b0\u8fc7\u1b91\uc031", "\ud87f\udd36\ud823\udd4b",
        7, 45845, -1179247118, -1334401681463068020L, 85155L, false, true, (char) 52363, (char) 61667,
        Double.longBitsToDouble(0x3fefcafa1c5a4eb4L), Double.longBitsToDouble(0x3fe639e255d71da4L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 0, 1, "\udaf2\udf92", "\u6d2c\ube8b\ub3e8\u7a7f\u12f0\ud1a7\u8fc7\u1b91\uc031\u971f\u73b0\ucbac\u7b03\u457c", "\uda61\udfa6\uecb2",
        33, 62420, -632142342, -4349765676700129900L, -70952L, false, false, (char) 60066, (char) 57822,
        Double.longBitsToDouble(0x3feccdfa437466a9L), Double.longBitsToDouble(0x3fe9c3c2a5c20a63L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 12, 20, "\udaf2\udf92", "\ubab6\u4687\u92ff\uc939\u7ff1\u4159\u8fc7\u1b91\u0e1e\u2726\u27c6\ucbac\u7b03\u7e18", "\udb1a\udcf6\ud933\udffc\ud96e\ude6a\uda41\udc55\ud9a5\udf24\ud907\udea6\u01d0\ud978\uddaa\ud9d6\udfd6\uda34\ude8d\u555e\u11aa\udbfc\udcb2\uda90\udc07\udb65\ude0b",
        36, 56649, -747995710, -6951023486883643099L, -69631L, true, false, (char) 29625, (char) 38395,
        Double.longBitsToDouble(0x3fe663f9544e92cbL), Double.longBitsToDouble(0x3feddbd74445fe5cL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ArrayType:[array type, component type: [simple type, class java.lang.String]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 5, 1, 9, "\udaf2\udf92\ud9c1\udcc1\ud9b8\ude34\udab1\uddcb", "\u94ab\u12f0\ud5cd\u0e53\u3d3c", "\ud88b\udf9f\udb85\udd42",
        20, 2125, -511647191, -3798864411452817157L, 62329L, true, true, (char) 13042, (char) 61240,
        Double.longBitsToDouble(0x3fdc717df5e694aaL), Double.longBitsToDouble(0x3fec22c532d0de94L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.String] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 2, 1, "\udaf2\udf92", "\u3dba\u2da6\u6d5a", "\ud9f0\ude59\uda70\udf7e\uda47\ude52\ud884\udfb3\udbb7\udef3\ud9a7\udc83\ud931\udc2e\ud846\uddce\udbb6\udc67\ud894\udcf5\ud891\udde9",
        56, 81172, 894722073, -1745305403429206534L, -40244L, true, false, (char) 61667, (char) 34644,
        Double.longBitsToDouble(0x3fdbac9f39496c0eL), Double.longBitsToDouble(0x3fea988adda73438L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 21, 3, "\udaf2\udf92", "\u3dba\u73c5\u828f", "\udbd3\udc4f\uda70\udf7e\uda5f\udedf\uda81\ude6e\ud9de\uddce\ud88b\udf9f\uda7b\udd3d\ud846\uddce\udbb6\udc67\uda18\udcf7\ud891\udde9\uda61\udfa6\uecb2\udbdb\udf99\udab5\udc0e\ud8b2\udc31\ud907\udea6\ud88a\uded6\ud978\uddaa\uda4b\udf50\ud95d\udd06\u555e\udb85\udda9\udb2a\ude66\ud99f\udda9\u29e8",
        32, 43239, 633509774, -2281316115151790059L, 50363L, true, false, (char) 53408, (char) 11637,
        Double.longBitsToDouble(0x3febb945efd2fdcbL), Double.longBitsToDouble(0x3fe4642804daefeaL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 1, 21, 2, 1, "", "", "\udb87\udd5b",
        13, 7931, -2058683392, 2469136199976734688L, -34464L, true, false, (char) 23518, (char) 21994,
        Double.longBitsToDouble(0x3fb8238edbac8420L), Double.longBitsToDouble(0x3fe14e61d1da7380L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 21, 2, 1, "\udaf2\udf92", "\u3dba\u2da6\u828f", "\udbd3\udc4f\uda70\udf7e\uda5f\udedf\uda81\ude6e\ud9de\uddce\ud88b\udf9f\uda7b\udd3d\ud846\uddce\udbb6\udc67\uda18\udcf7\ud891\udde9\uda61\udfa6\uecb2\uda22\udf3d\uda41\udc8e\ud9a5\udf24\udbd9\udf17\udb84\udd7f\ud978\uddaa\ud834\udee5\uda59\udee1\ud8c9\udd76\ud937\udc28\uda08\udfa3\ud81d\udea5\udaef\uddb9",
        32, 21188, 633509774, -2281316115151790059L, 50363L, true, false, (char) 53408, (char) 24980,
        Double.longBitsToDouble(0x3fed8133b37b28a1L), Double.longBitsToDouble(0x3fe742b38e345fe5L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Integer] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 21, 2, 1, "\udaf2\udf92", "\u3dba\u2da6\u828f", "\udbd3\udc4f\uda70\udf7e\uda5f\udedf\ud9fe\udd8d\udab3\udc9f\ud864\ude12\uda7b\udd3d\ud8e7\udde5\udadd\udd66\uda18\udcf7\ud891\udde9\uda9f\udda5\ud9ab\udcd2\uda22\udf3d\uda41\udc8e\ud9a5\udf24\ud907\udea6\ud88a\uded6\ud978\uddaa\ud931\udea1\uda59\udf20\u555e\udb85\udda9\udb2a\ude66\ud81d\udedf\udbae\udffd",
        57, 21188, 633509774, -2281316115151790059L, 97440L, true, false, (char) 25693, (char) 43366,
        Double.longBitsToDouble(0x3fead90dacb923beL), Double.longBitsToDouble(0x3fd3eb362cdc8682L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 0, 4, "\udaf2\udf92\udafb\udefe\udaa5\udc55\ud884\udff5\udb87\udd5b\ud8c5\ude8e\ud8ef\uded6\udb07\udd14\udbd3\udc4f\uda70\udf7e\udaad\udfc5\ud896\ude82\ud951\udd1f\udb7e\ude94\uda7b\udd3d\ud846\uddce\udbb6\udc67\uda18\udcf7\udb29\udca5\uda61\udfa6\ud8d5\uddde\udae5\udc0d\uda3f\ude8e\ud9a5\udf24\ud921\udf21", "\u24a2\u4a9b\ub59c", "\ud81d\udedf\udbae\udff8\ud95e\uded2\udac5\udde5",
        9, 53765, 984866977, -6447036052325218027L, -40441L, false, false, (char) 20139, (char) 34848,
        Double.longBitsToDouble(0x3fd3eb362cdc8682L), Double.longBitsToDouble(0x3fefa133b37bfb2cL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 1, "\udab9\ude36\uda7a\udc19\udbad\udd95\ud970\udee8\udb5a\udfb2\ud941\udf71\udb5f\udf90\udb80\udc4f\udb91\udd74\uda4a\ude05\ud944\udc6f\uda81\ude6e\ud994\udf12\udbdd\udeef\uda5a\udd1d\udb97\udf52\ud937\udf7d\ud85b\udc78", "\u51dc\ud536\ub84b\ua28f\ua410\u524e\u6309\u74b3\u7944\u020e\ub2fd\u7922\u9e58\u7964\u958c\ucceb\u1257\u2d60\u5a8c\u4904\ubfa6\ud5d7\u9204\ua533\u3371\u7315\u1dae\u9e40\u8b65\u9901\u69cc\u808e\u69de\u38c2\u57f0\u54fe\u8ef3", "\udb53\udf9f\udba0\udd7d\ud912\udfd8\ud806\ude2e\uda8c\uddb3\udab0\udef5\ud888\udc4e\udb79\udda7\ud97a\udf0d\udb58\udd2f\udbfb\uddfc\udb6e\ude80\ud911\udc9e\ud971\udff9\ud8bf\udfef\udb62\udc45\ud85b\udfff\udbf0\udfb8\udb79\udd98\udb2e\udc97\ud980\udc69\ud846\udc83\ud965\udc2b",
        46, 8094, 2018235176, -3057030256519421868L, 80632L, true, false, (char) 31713, (char) 38473,
        Double.longBitsToDouble(0x3fecc4ba8a6b33e3L), Double.longBitsToDouble(0x3fe1af0379b0a882L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 9, 10, "\udaf2\udf92", "\u3dba\u2da6\u8025", "\ud9f0\udea1\uda70\udf7e\uda5f\udedf\uda81\ude6e\ud9de\uddce",
        50, 99874, -1870354336, -3730595169594973655L, -51038L, false, false, (char) 64718, (char) 41808,
        Double.longBitsToDouble(0x3fdfae7c746b1810L), Double.longBitsToDouble(0x3fe4a61d1671c083L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 9, 10, "\udaf2\udf92", "\u3dba\u2da6\u8025", "\ud9fd\udcf9\uda70\udf7e\uda5f\udedf\ud9ab\udf6f\ud9de\uddce\ud9f2\udcfa\uda7b\udd3d\ud846\uddce\udbdf\udd67",
        -5, 47890, -310689602, -7154607321655255015L, -49242L, false, false, (char) 6318, (char) 57822,
        Double.longBitsToDouble(0x3fba0d79f12cbe50L), Double.longBitsToDouble(0x3f90c6750ea04360L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<>\0121=com.fasterxml.jackson.databind.type.TypeBindings:<>\012",
        Z.run(T, 2, 10, 12, 13, "\udb07\udd4b\ud8a4\udda5\udb6a\ude8d", "\u34e3\u1b45\u51a3\u5704\ub142\u5b0c\u7100\u08c0\u4161\u751b\ub3f3\u95e8\u330e\u5299\ud7cb\u274f\u7507\u2d7d", "\ud820\udc3a\ud978\uddaa\ud9a1\udca2\ud904\ude3d\udb37\udf81",
        57, 12123, 1863560615, 3014185735481496247L, -54948L, false, false, (char) 16684, (char) 58285,
        Double.longBitsToDouble(0x3fc7b6fec6616628L), Double.longBitsToDouble(0x3fed58bd254fe60dL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<> |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 2, 1, "\udaee\ude20\ud9c1\udcc1\ud844\udc19\ud874\udda6\ud9b7\uded7\udbc5\udd02\udb19\ude58", "\ub411\u561f\u7d08\u1a58\u5a0f\u5587\u7928\u56ee\u330e\u5e99\u96fc\u0884\u2949\u2329\ucad7\u59e6\ucbd4\u283b\u6a38\u31fd\u783a\ubd7d\u6fc1", "\ud95e\ude9a\udbf4\ude4a",
        49, 8376, -987475035, 2647106359457300087L, 74193L, false, false, (char) 18120, (char) 31609,
        Double.longBitsToDouble(0x3fe4797bdb181ccdL), Double.longBitsToDouble(0x3fec8305b1d40331L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 2, 1, "\udaf2\udf92", "\u3dba\u2da6\ua025\u9100\u12f0\ud1a7\u8fc7\ubaf5\uc124\u0873\u59c2\u751b\ud43e\u7e18", "\uda61\udfa6\uecb2\uda22\udf3d\uda41\udc8e\ud9a5\udf24\ud907\udea6\udb23\udfa3\ud997\udd9c\ud834\udee5\uda59\udee1\u555e\udb85\udda9\udb2a\ude66\uda49\ude76\udb3d\ude64\ud9a8\udc88\ud914\uddb1\u55a1\udaf8\udf61\ud9e1\udfac",
        21, 92690, -304746862, -3871149875373581034L, 84677L, false, true, (char) 54314, (char) 42821,
        Double.longBitsToDouble(0x3fd0afbafa5e3946L), Double.longBitsToDouble(0x3fd15bf97c2be0feL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 7, 1, "\udaf2\udf92", "\u3d6d\u2da6\ua025\u9100\u12f0\ud1a7\u8fc7\ubaf5\uc124\u0873\u59c2\u751b\ud43e\u7e18", "\uda61\udfa6\uecb2\uda22\udf3d\uda41\udc8e\ud9a5\udf24\ud8ba\udd7e\udb59\udd6d\ud997\udd9c\ud834\udee5\uda51\udedd\u555e\udb85\udda9\udb2a\ude66\uda49\ude76\udb3d\ude64\ud9a8\udc88\ud8e4\udf4c\uda73\udd87\udaf8\udf61\ud9e1\udfac",
        21, 92690, -942281070, 6649258899914047049L, 84677L, false, true, (char) 9776, (char) 42823,
        Double.longBitsToDouble(0x3fd0afbafa5e3946L), Double.longBitsToDouble(0x3fd15bf97c2be0feL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 1, 9, "\uab95", "\u3dba\ucf53\u9152\ub9a6\u12f0\ud1a7\u8fc7\ubaf5\uc124\u0873\u20c2\u751b\ucd3d\u7e18", "\ud8f2\ude2b\ud99a\udc78\uda22\udf3d\udb7f\udcec\ud9a9\udd4b\ud907\udea6\udb23\udfa3\ud997\udd9c\ud834\udee5\uda59\udee1\u555e\udb46\udc09\udb2a\ude66\uda49\ude76\udb3d\ude64\ud9a8\udc88\ud914\uddb1\u55a1\udaf8\udf61\ud9e1\udfac",
        21, 39746, 1710972608, -3871150269577292522L, 84677L, false, true, (char) 54314, (char) 42821,
        Double.longBitsToDouble(0x3fd0afbafa5e3946L), Double.longBitsToDouble(0x3fe9c5fcbb4f22b3L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 0, 14, "\udaf2\udf92", "\u0096\u2da6\ua025\u9100\u12f0\ud1a7\u8fc7\ubaf5\uc124\u0873\u59c2\u751b\ud43e\u7e18", "\uda61\udfa6\uecb2\uda58\udf38\uda41\udc8e\ud9a5\udf24\ud907\udea6\udb23\udfa3\ud997\udd9c\ud834\udee5\uda59\udee1\u555e\udb85\udda9\udb2a\ude66\uda49\ude76\udb3d\ude64\ud9a8\udc88\ud914\uddb1\u55a1\udaf8\udf61\ud9e1\udfac",
        21, 92690, -942281070, -3871149832423908074L, -22688L, false, true, (char) 54314, (char) 42821,
        Double.longBitsToDouble(0x3fd0afbafa5e3946L), Double.longBitsToDouble(0x3fd15bf97c2be0feL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Number] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 17, "\uda0b\udc7f", "\u7b07\u2da6\u8025\u7a7f\u12f0\u6e91\u0ed8\u0c37\uc124\u0873\ucb67\u751b\ud43e\u7e18\u330e\u6b94\u7304\u4838\u2c67\ub603\uc487\ud5a8\uce95\u273a\u7cc0\u4a02\u020e\ubad4\ubd36\u46a0", "\ud894\ude0c\ud901\udf04\udbd7\ude4e\ud871\udfa8\udb24\udd3b",
        21, 91421, 1153007779, 5186250413861470174L, 79697L, true, true, (char) 61424, (char) 36856,
        Double.longBitsToDouble(0x3f8d14e19f1dea00L), Double.longBitsToDouble(0x3fcac012be6f4790L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 21, 21, "\ud880\udf99", "\ua4f3\u769b\u54b7", "\ud951\udcc0",
        32, 45015, 278736244, -1110494963999151289L, 93445L, false, true, (char) 64991, (char) 43015,
        Double.longBitsToDouble(0x3f999cb5bf86aa80L), Double.longBitsToDouble(0x3fdfae7c766b1810L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<>\0121=com.fasterxml.jackson.databind.type.TypeBindings:<>\012",
        Z.run(T, 2, 11, 11, 21, "\udaf2\udfa2", "\u627c\u4b1e\u2ac2", "\ud8dd\udfe7",
        59, 78798, 2141281324, 9145368243788725875L, -42103L, false, true, (char) 10208, (char) 17786,
        Double.longBitsToDouble(0x3f999cb5bf86aa80L), Double.longBitsToDouble(0x3fefd73e3ac8df92L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 20, 12, "\udaf2\udf92", "\u3dba\u4e25\uc754\ucafa\u66c6\u885b\u9f49\u1b91\u7e8e\ub1ea", "\ud846\uddce\udb1a\udc28\udb54\udcb5\ud901\udf84\ud87e\ude95\ud9e0\udf7f\uda22\udf3d",
        5, 48146, 1147193018, -3819872016514616335L, -92337L, false, true, (char) 13133, (char) 46385,
        Double.longBitsToDouble(0x3fda79438cc9a38aL), Double.longBitsToDouble(0x3fc7f50ab64d1960L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<>\0121=com.fasterxml.jackson.databind.type.TypeBindings:<>\012",
        Z.run(T, 2, 12, 12, 7, "\udaf2\udf92\u7dd1\ud804\udcff\ud974\udf6d", "\u7a7f\u12f0\u86b0\u8fc7\u1b91\uc031", "\ud87f\udd36\ud823\udd4b",
        7, 45845, -1179247118, -1334401681463068020L, 85155L, false, true, (char) 52363, (char) 61667,
        Double.longBitsToDouble(0x3fefcafa1c5a4eb4L), Double.longBitsToDouble(0x3fe639e255d71da4L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<> |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[null]]\0121=com.fasterxml.jackson.databind.type.TypeBindings:<> |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[null]]\012",
        Z.run(T, 2, 12, 12, 6, "\udaf2\udf92\u7dd1\ud8c4\udcff\udb0d\uddb9", "\u7a7f\u12f0\u86b0\u8fc7\u1b91\uc031\ubf1a\u82fb\u8bad\u7a94\ud376\uc5ca\u72a3\u32cb\u14de\u472a\uadb8\ud145\uabb7\u79d8\u1d82\u4926\ud58f\ucf6c\ubada\u6319\u0cde\u43e5\u7ed0\u5ed7\u9259\u45a5\ua592\u5095\u13f5\u4764\u52f3", "\uda3a\udeca\udac4\udfbb\udb37\udcac\udb4b\udeee\ud864\udd58\ud85d\udd89",
        27, 14449, -1176916032, 5855768724009461337L, -23419L, true, false, (char) 4435, (char) 31083,
        Double.longBitsToDouble(0x3fe445eb5c99aaddL), Double.longBitsToDouble(0x3fc74c1cffad54ecL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 20, "\udaf2\udf92", "\ubab6\u4687\u8e36\uc939\u7ff1\u4159\u8fc7\u1b91\u0e1e\u2726\u27c6\ucbac\u7b03\u7e18", "\udb1a\udcf6\ud933\udffc\ud8e6\udda6\ud9b0\udef5\ud9a5\ude90\ud907\udea6\u01d0\ud978\uddaa\ud901\uddea\uda34\ude8d\u555e\u11aa\udbfc\udcb2\uda90\udc07\udb65\ude0b",
        36, 56649, 1963818434, -393783089014542435L, -69631L, true, false, (char) 29625, (char) 38395,
        Double.longBitsToDouble(0x3fe663f9544e92cbL), Double.longBitsToDouble(0x3fdbb7ae865d0fa0L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 7, 10, "\udaf2\udf92", "\u3dba\u2da6\u9a26", "\ud9f0\udea1\uda70\udf7e\uda5f\udedf\ud8c4\ude6f\ud9de\uddce",
        50, 99874, -1870354336, -3730595171345031008L, -51038L, false, false, (char) 64718, (char) 57506,
        Double.longBitsToDouble(0x3fdfa3f8e46b1810L), Double.longBitsToDouble(0x3fe4a61d1660c083L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 9, 10, "\ud868\udf8d", "\000\u2da6\u8025", "\ud9fd\udcf9",
        37, 65197, 279629428, 42426540598034432L, -51038L, false, false, (char) 64718, (char) 41808,
        Double.longBitsToDouble(0x3fdfae7c7a6b1810L), Double.longBitsToDouble(0x3fe670e72471c083L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 9, 10, "\udaf2\udf92", "\u3dba\u2da6\u8025", "\ud9fd\udcf9\uda70\udf7e\uda5f\udedf\ud9ab\udf6f\ud9de\uddce\ud9f2\udcfa\uda7b\udd3d\ud846\uddce\udbdf\udcf2",
        -5, 97216, -310689602, -7154607321655255015L, -99938L, false, false, (char) 942, (char) 39588,
        Double.longBitsToDouble(0x3fea988ad8a73438L), Double.longBitsToDouble(0x3fba0d79f12cbe50L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 9, 10, "\udaf2\udf92", "\u3dba\u2da6\u8025\u7a7f\u66d1", "\uda5f\udedf\ud9ab\udf6f\ud9de\uddce\ud9f2\udcfa\uda7b\udd3d\ud846\uddce\udbdf\udd67\uda18\udcf7\ud8aa\udd34\uda61\udf1a\uecb2\uda22\udf3d\uda41\udc8e",
        46, 67029, -1067850673, 6387806799420168254L, -49242L, false, false, (char) 6318, (char) 57822,
        Double.longBitsToDouble(0x3fba0d79f12cbe50L), Double.longBitsToDouble(0x3f90c6750ea04360L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 12, 18, "\udaf2\udf92", "\u3dba\u2da6\u8025", "\ud9fd\udcf9\uda70\udf7e\udbcd\uddb5\ud9ab\udfa1\ud88d\udde5\udbd1\udc0b\uda7b\udd3d\ud846\uddce\udbdf\udd67",
        -5, 47890, -310689602, -7154607321655255015L, 21158L, false, false, (char) 6318, (char) 57822,
        Double.longBitsToDouble(0x3fba0d79f12cbe50L), Double.longBitsToDouble(0x3f90c6750ea04360L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.Date] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.util.Date] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 21, 21, 21, "\udaba\udc60\uda68\udd8b\udb96\uddf0\udb43\udf44", "\u537c", "\udbb1\uddc3\uda9f\ude4f\ud87b\ude77\ud831\uddc3\ud88b\udf9f",
        24, 42341, -868596875, -8374148448259028518L, -49921L, false, false, (char) 15664, (char) 11714,
        Double.longBitsToDouble(0x3fdf1a0081f3c766L), Double.longBitsToDouble(0x3fc77b036bff4bc4L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 11, 21, "\ud880\udf99", "\u119d\u769b\u54b7", "\ud951\udcc0",
        32, 52695, 278736244, -1110494963999151289L, 93445L, false, false, (char) 64991, (char) 43015,
        Double.longBitsToDouble(0x3f999cb5bf86aa80L), Double.longBitsToDouble(0x3fdfae7c7c531810L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.ArrayType:[array type, component type: [simple type, class java.lang.String]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.ArrayType:[array type, component type: [simple type, class java.lang.String]] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 21, 21, 6, "\ud880\udf99", "\ua4f3\u769b\u547d\uba65\ub14e\u1877\u5931\u1702\uc124\ubdfe\u59c2\u751b\ud43e", "\ud891\udde9\uda61\udfa6\uecb2\uda22\udf3d",
        48, 8917, -939610878, -2542978377618585988L, 34212L, false, false, (char) 54506, (char) 13410,
        Double.longBitsToDouble(0x3fdbc8ce504985beL), Double.longBitsToDouble(0x3fedee8746e3ca6cL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<>\0121=com.fasterxml.jackson.databind.type.TypeBindings:<>\012",
        Z.run(T, 2, 10, 9, 20, "\udaf2\udf92\ud858\udfe6", "\u41ff\u7fb6\u7a7f\u66d1\u6cee\uc902\u29e6\u7cd8\u5ddb\u7a3d", "\udbdf\udcf2\uda18\udcf7\u534b\u155d\udb26\udf26\ud902\udcad\uda41\udc8e\ud9a5\udf24",
        14, 32118, 1487277169, 630453370880L, -92996L, true, true, (char) 13535, (char) 58190,
        Double.longBitsToDouble(0x3fe2a0e71de66ef6L), Double.longBitsToDouble(0x3fbe3b54f88c5808L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<>\0121=com.fasterxml.jackson.databind.type.TypeBindings:<>\012",
        Z.run(T, 2, 9, 9, 10, "\udaf2\udf92\ud9c1\udcc1\uf375\ud974\udf6d\ud9ab\udc8c\ud9ae\udd27\udaf2\udd17\ud925\udfe6\ud9fd\udcf9\uda70\udf7e", "\u0873\u0a78", "\udaee\ude01\udac2\udf8e\ud949\ude57\uda99\udd24\ue9d9\uda22\udf3d\uda41\udc8e\ud9a5\udf24",
        14, 32118, 1487277169, 265381150720L, 48757L, true, true, (char) 13535, (char) 21071,
        Double.longBitsToDouble(0x3fe129e170e46dbeL), Double.longBitsToDouble(0x3feb2ef04b3018b3L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<>\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 12, 11, "\ud844\udd79", "\u737c\u2da6\ub3bb", "\ud9fd\udcf9\uda70\udf7e",
        18, 1326, 763867041, -4509044621313338382L, -28437L, true, true, (char) 19473, (char) 64991,
        Double.longBitsToDouble(0x3fe4676bdd0d9cb5L), Double.longBitsToDouble(0x3fdfc3554b2dde24L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.String] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.String] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 21, 21, 21, "\udaba\udcba\uda68\udd8b\udb96\uddf0\udb43\udf44", "\u5408", "\ud925\udfda\uda9f\ude4f\ud87b\ude77\ud831\uddc3\ud88b\udf9f",
        0, 42341, -868596875, -8374148448259023398L, -49921L, false, false, (char) 53295, (char) 61297,
        Double.longBitsToDouble(0x3fe0d0bf88f9c52fL), Double.longBitsToDouble(0x3fc77b036bff4bc4L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class char] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 21, 21, 21, "\udaba\udc5f\uda68\udd8b\udb96\uddf0\udb43\udf44\ud844\udc2a\udaf4\udf42\ud8bd\udf08\ud8a8\udc8c\udbdb\udd2b\u9a69\ud991\udc60\ud8b1\udc6e\ud83c\udd21\ud81c\udc27\ud9a9\udf93\udb8c\udcb6\udbb6\udc67\udb9e\udc87\ud9b5\udf70\u5d5c\ue6f7", "\u517f\ubeeb\ub1b0\u7f54\u3c7d\ua80d\u54e9\u66ff\u82e0\ub83b\u75fc\ud77a\u4aef\ud05e\u2970\u3674", "\udb20\udd0b\u54b0\uda91\udfaa",
        41, 96034, 1636283588, 4131109701480359838L, 1828L, true, false, (char) 43106, (char) 62408,
        Double.longBitsToDouble(0x3fdd265179c00b4cL), Double.longBitsToDouble(0x3fe2ba646bd621bdL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class int] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class int] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 21, 21, 1, "\udaba\udc60\uda6e\udd8b\udb96\uddf0\udb43\udf44", "\u13f1", "\u5a05\udaa1\ude50\udbb6\uddb4\ud831\uddc3\ud853\ude4b",
        30, 42341, -868596875, -8374148448259028518L, -83311L, false, false, (char) 15664, (char) 11404,
        Double.longBitsToDouble(0x3febc5de48f9bca3L), Double.longBitsToDouble(0x3fc77b037f1afbc4L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Object] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\0121=com.fasterxml.jackson.databind.type.SimpleType:[simple type, class java.lang.Object] |this=com.fasterxml.jackson.databind.type.TypeFactory:@?\012",
        Z.run(T, 2, 21, 21, 21, "\udaba\udc60\uda68\udd8b\udb96\uddf0\udae9\udc77", "\u537c\ua345\u7744\u8e0d\u3760\ub45b\u94ea\u59c2\u751b\u80f3\u7e18\ud29d\u5299\u61e8\u73c5\ucbb2\ud1f0\u243c\u9866\ub1b0\u7f54\u0592\u956d\u535b\ub27c\u9c81", "\ud93e\udf92\ud88c\udc49\udbcc\ude78\ud8db\udff5\ud84c\ude0c\ud917\ude6b\udac0\udfff\uda21\udd6c\ud92d\udc07\uda8e\udea2\udaf2\ude3d\ud8da\ude52\uf970\ud826\udeb1\ud972\udd72\uc3a2\ud958\udc74\uda36\udc7b\ud809\ude53\ud94b\udda3\ud816\udf76\udb86\udf62\ud984\udc31\ud8c2\ude8d\ud96a\udf09\ud96e\udfad\udaec\udc17\udb28\udd97\ud9fd\ude40\udb0c\udec7\ud822\udf14\udb59\udc43\ud926\udf0b\udbca\udf15",
        59, 7632, -88829233, -1452248810400792410L, -29223L, false, false, (char) 9753, (char) 40341,
        Double.longBitsToDouble(0x3fcfb1050f908bb8L), Double.longBitsToDouble(0x3fe9e9903cd1c323L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 18, 2, 1, "\udaf2\udf92", "\u3dba\u2da6\u8025", "\ud9f0\ude59\uda70\udf7e\uda5f\udedf\uda81\ude6e\ud9de\uddce\ud88b\udf9f\uda7b\udd3d\ud91c\udf78\udbb6\udc67",
        -5, 47890, -310689602, -7154607321655255015L, -40244L, true, false, (char) 61667, (char) 37460,
        Double.longBitsToDouble(0x3fdba7ffec856c0eL), Double.longBitsToDouble(0x3fed943dfda73438L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 14, 2, "\udaf2\udf92", "\u3dba\u2da6\ua025\u907f\u9286\ud235\u8fc7\ubaf5\u4b1e\u0803\u59c2\u751b\ud43e\u7e18", "\uda61\udf63\uecb2\uda22\udf3d\uda41\udc8e\ud9a5\udf24\ud907\udea6\udb23\udfa3\ud997\udd9c\ud834\udee5\uda59\udee1\u555e\udb85\udda9\ud971\ude0a\uda49\uddff\udb3d\ude64\ud9a8\udc88\ud914\uddb1\u55a1\udaf8\udf61\ud9e1\udfac",
        21, 92690, -942281070, -3871149832423908074L, 84677L, false, true, (char) 15403, (char) 1143,
        Double.longBitsToDouble(0x3fd0afbafa5e3998L), Double.longBitsToDouble(0x3fdbdbf97e16780cL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 19, 1, "\ud9d1\udeaf", "\u3dba\u3823\u8857\u9b53\u03aa\u7897\u8fc7\u1b91\uc013\u66f8", "\udb60\udeb2\udad7\udd47",
        21, 42, -310689602, -7154607321655255015L, 13158L, true, false, (char) 55862, (char) 48878,
        Double.longBitsToDouble(0x3fe52dc18696b085L), Double.longBitsToDouble(0x3fdbac9f31496c0eL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 5, "\ud880\udfe3\ud9c4\uddbc", "\u769b\u54b7\uc4d4\u1427\u4930\u595d\u1702\ubd3e\uc7b8\ub178", "\udbd0\udf84\udacf\udd81\ud859\udce0\uda89\udc42\ud870\udc2c\ud8cb\udcfe\ud8ba\uddeb\ud9a5\ude4e\uda54\ude5b\udae7\ude58\uda92\udc04\ud935\udf39",
        9, 95320, -672425244, -6586302768115253891L, -63777L, true, false, (char) 20878, (char) 31130,
        Double.longBitsToDouble(0x3fe18725f8e009e4L), Double.longBitsToDouble(0x3fedb42eae7c7b1eL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<> |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[]]\0121=com.fasterxml.jackson.databind.type.TypeBindings:<> |a1=[Lcom.fasterxml.jackson.databind.JavaType;:[[]]\012",
        Z.run(T, 2, 9, 9, 10, "\udaf7\udd18\ud952\udd08\udb28\uddb4\ud974\udf6a\udbe9\udc8b\ud9ae\udd27\udaf2\udd95\ud925\udfe6\ud9fd\udcf9\uda70\udf7e", "\u0873\u9e9f", "\udaee\ude01\udac2\udf8e\ud949\ude57\uda99\udd24\uda48\udfbf",
        16, 62420, -1945614854, 2082058534668970702L, -34402L, true, true, (char) 47238, (char) 12651,
        Double.longBitsToDouble(0x3fed515198a73438L), Double.longBitsToDouble(0x3fba0d79f129e170L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.type.TypeBindings:<>\0121=com.fasterxml.jackson.databind.type.TypeBindings:<>\012",
        Z.run(T, 2, 10, 10, 8, "\udaf2\udf92\u7dd1\ud804\udcff\ud974\udf6d", "\u7a7f\uca7b\u9ea7\u8fc7\u1b91\u06c7", "\ud87f\udd36\ud823\udd4b\udac0\udf41\uda82\udc92\uda3e\uddcd\uda61\udfa6\uecb2\udbec\udf42\ud927\udc61\ud9c3\udc57",
        59, 85732, 1487277169, 6864497650418605049L, -75737L, true, true, (char) 23617, (char) 30079,
        Double.longBitsToDouble(0x3fdfe862f4353c4aL), Double.longBitsToDouble(0x3fe1e96fc9fe01b8L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 9, 10, "\udb63\udc70\ud928\uddcd", "\ud610\u7bbf\u488b\u6765\u2c48\u8fc7\u4946\u829c\u0873", "\uda11\ude5c\udb0b\udd2c\udb53\ude4c\ud949\ude57\ud886\udc39\uda48\udfbf\ud93d\udc78\uda41\udc8e",
        46, 67029, -1065112882, 6387806802868502590L, -95348L, true, false, (char) 12765, (char) 1754,
        Double.longBitsToDouble(0x3fba0d74712f6050L), Double.longBitsToDouble(0x3fe3db3d9773a23aL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 1, 15, "\udaf2\udf57", "\u3dba\u2da6\ua025\u9100\u12f0\ud1a7\u8fc7\u22b9\uc11b\u0873\u59c2\u751b\ud43e\u7e18", "\uda8d\udfa6\ud8b4\udfef\ud9b2\udcf3\uda2f\udcb4\ud9a5\udf24\ud907\udea6\udb23\udfa3\ud997\udd9c\ud861\ude5b\udb4f\udf41\udbb8\udf9e\udb85\udda9\udb2a\ude66\uda49\ude76\udb3d\ude64\uda0f\udd83\u93d1\u45bd\udaf8\udf61\ud9e1\udfac",
        21, 92690, 1321987730, 7260599737877779322L, 84677L, false, true, (char) 28864, (char) 31278,
        Double.longBitsToDouble(0x3fea36e8f82c2a03L), Double.longBitsToDouble(0x3fd15bf63c2be0feL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 14, 18, "\ud85b\udfd4", "\u3dba\u2da6\ua025\u9100", "\uda70\udf7e\udb8f\uded7\uda81\ude6e\ud9de\uddce",
        33, 99874, -1870354336, -3730595169594973655L, -51038L, false, false, (char) 64718, (char) 41808,
        Double.longBitsToDouble(0x3fdfae7c746b1810L), Double.longBitsToDouble(0x3fe4a61d10638a44L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 5, "\ud880\udfe3\ud9c4\uddbc", "\u769b\u54b7\uc4d4\u1427\u4930\u595d\u1702\ubd3e\uc7b8\ub178", "\uda2e\ude93\udb06\udd11\ud859\udce0\uda89\udc42\ud86a\udd3f\ud8cb\udcfe\ud8ba\uddeb\ud9a5\ude4e\uda54\ude5b\udb1e\udd3c\uda92\udc04\ud935\udf39",
        9, 95320, -301984284, 4271076793662653053L, -63777L, true, false, (char) 20878, (char) 31130,
        Double.longBitsToDouble(0x3fe18725f8e009e4L), Double.longBitsToDouble(0x3fec1c76ae7c7b1eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.type.TypeBindings|asKey|java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeBindings:[Ljava.lang.String;,[Lcom.fasterxml.jackson.databind.JavaType;,[Ljava.lang.String;",
    "M|com.fasterxml.jackson.databind.type.TypeBindings|equals|java.lang.Object|new:com.fasterxml.jackson.databind.type.TypeBindings:[Ljava.lang.String;,[Lcom.fasterxml.jackson.databind.JavaType;,[Ljava.lang.String;",
    "M|com.fasterxml.jackson.databind.type.TypeBindings|hashCode||new:com.fasterxml.jackson.databind.type.TypeBindings:[Ljava.lang.String;,[Lcom.fasterxml.jackson.databind.JavaType;,[Ljava.lang.String;",
    "M|com.fasterxml.jackson.databind.type.TypeBindings|toString||new:com.fasterxml.jackson.databind.type.TypeBindings:[Ljava.lang.String;,[Lcom.fasterxml.jackson.databind.JavaType;,[Ljava.lang.String;",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_bindingsForSubtype|com.fasterxml.jackson.databind.JavaType,int,java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromClass|com.fasterxml.jackson.databind.type.ClassStack,java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructSpecializedType|com.fasterxml.jackson.databind.JavaType,java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeBindings|create|java.lang.Class,com.fasterxml.jackson.databind.JavaType|static",
    "M|com.fasterxml.jackson.databind.type.TypeBindings|create|java.lang.Class,com.fasterxml.jackson.databind.JavaType,com.fasterxml.jackson.databind.JavaType|static",
    "M|com.fasterxml.jackson.databind.type.TypeBindings|create|java.lang.Class,[Lcom.fasterxml.jackson.databind.JavaType;|static",
    "M|com.fasterxml.jackson.databind.type.TypeBindings|create|java.lang.Class,java.util.List|static",
    "M|com.fasterxml.jackson.databind.type.TypeBindings|createIfNeeded|java.lang.Class,com.fasterxml.jackson.databind.JavaType|static",
    "M|com.fasterxml.jackson.databind.type.TypeBindings|createIfNeeded|java.lang.Class,[Lcom.fasterxml.jackson.databind.JavaType;|static",
    "M|com.fasterxml.jackson.databind.type.TypeBindings|emptyBindings||static",
    "M|com.fasterxml.jackson.databind.type.TypeBindings|findBoundType|java.lang.String|new:com.fasterxml.jackson.databind.type.TypeBindings:[Ljava.lang.String;,[Lcom.fasterxml.jackson.databind.JavaType;,[Ljava.lang.String;",
    "M|com.fasterxml.jackson.databind.type.TypeBindings|getBoundName|int|new:com.fasterxml.jackson.databind.type.TypeBindings:[Ljava.lang.String;,[Lcom.fasterxml.jackson.databind.JavaType;,[Ljava.lang.String;",
    "M|com.fasterxml.jackson.databind.type.TypeBindings|asKey|java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeBindings:[Ljava.lang.String;,[Lcom.fasterxml.jackson.databind.JavaType;,[Ljava.lang.String;",
    "M|com.fasterxml.jackson.databind.type.TypeBindings|equals|java.lang.Object|new:com.fasterxml.jackson.databind.type.TypeBindings:[Ljava.lang.String;,[Lcom.fasterxml.jackson.databind.JavaType;,[Ljava.lang.String;",
    "M|com.fasterxml.jackson.databind.type.TypeBindings|hashCode||new:com.fasterxml.jackson.databind.type.TypeBindings:[Ljava.lang.String;,[Lcom.fasterxml.jackson.databind.JavaType;,[Ljava.lang.String;",
    "M|com.fasterxml.jackson.databind.type.TypeBindings|toString||new:com.fasterxml.jackson.databind.type.TypeBindings:[Ljava.lang.String;,[Lcom.fasterxml.jackson.databind.JavaType;,[Ljava.lang.String;",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_bindingsForSubtype|com.fasterxml.jackson.databind.JavaType,int,java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|_fromClass|com.fasterxml.jackson.databind.type.ClassStack,java.lang.Class,com.fasterxml.jackson.databind.type.TypeBindings|new:com.fasterxml.jackson.databind.type.TypeFactory:",
    "M|com.fasterxml.jackson.databind.type.TypeFactory|constructSpecializedType|com.fasterxml.jackson.databind.JavaType,java.lang.Class|new:com.fasterxml.jackson.databind.type.TypeFactory:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
