package com.fasterxml.jackson.databind.ser.std;
import org.junit.Test;
import static org.junit.Assert.*;
public class DateTimeSerializerBase_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 8, 2, 3, "\uda14\udc5c\udaa5\udc15\ud93b\udddc", "\ua1a6\u0e2c\ud43a\u5f1f\u81f0\u4e38\u4972", "\uda2e\udcc5\u933b\uda20\udf8d\uda2a\udd56\uda2c\udde0\udb8d\udd9d\ud95b\udebe",
        53, 21485, 2102385578, -4792437715184035335L, 52534L, false, true, (char) 42969, (char) 16459,
        Double.longBitsToDouble(0x3fd6316f835eb3e8L), Double.longBitsToDouble(0x3fdd9fbe841b55b6L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 8, 2, 3, "\uda14\udc5c\udaa5\udc15\ud93b\udddc", "\ua1a6\u0e2c\ud4f8\u5f1f\u81f0\u4e38\u4972", "\uda2e\udcc5\u933b\uda20\udf8d\uda2a\udd56\uda2c\udde0\udb8d\udd9d\ud95b\udebe",
        53, 32589, -954201189, -4792437075233908231L, 52534L, false, true, (char) 42969, (char) 16459,
        Double.longBitsToDouble(0x3fd6316f835eb3e8L), Double.longBitsToDouble(0x3fdd9fbe841b55b6L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 2, 3, "\uda14\udc5c\udaa5\udc15\ud93b\udddc", "\ua1a6\u0e2c\ud43a\u5f1f\u81f0\u4e38\u4972", "\uda2e\udcc5\u933b\uda20\udf8d\uda2a\udd56\uda2c\udde0\udb8d\udd9d\ud95b\udebe",
        53, 21485, 2102385578, -4792437715184035335L, 52534L, false, true, (char) 42969, (char) 12363,
        Double.longBitsToDouble(0x3fd63e3dc35eb3e8L), Double.longBitsToDouble(0x3fdd9fbe841b55b6L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 8, 2, 3, "\uda14\udc5c\udaa5\udc15\ud93b\udddc\ud837\udf57\ud8da\ude04\u4341\udbe8\udfb0\udb59\udd77", "\u4e38\u825f", "\uda2e\udcc5\u933b\uda20\udf8d\uda2a\udd56\uda2c\udde0\udb8d\udd9d\ud95b\udebe\udada\ude53\uda29\udf08\ud9fe\udf0c\uda5e\udf5e\ud930\udf85\udbd6\udf34",
        47, 30574, 577384339, 1655105716772686179L, -65657L, true, false, (char) 64275, (char) 62303,
        Double.longBitsToDouble(0x3f930e2ff6f52240L), Double.longBitsToDouble(0x3fbfe0a0d7ddf478L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 1, "\ud86e\ude58\udac5\udd4a\ud93b\udddc", "\ua1a6\u0e2c\ud43a\u5f1f\u436e\u4e0b\ua52b", "\uda2e\udcc5\u933b\uda20\udf8d\udb04\udeac\uda1f\udf49\ud8ec\udc8c\ud95b\udebe",
        53, 21485, 2102385578, -4792437715184035335L, 52534L, false, true, (char) 42969, (char) 16459,
        Double.longBitsToDouble(0x3fd6316f835eb3e8L), Double.longBitsToDouble(0x3fd4f33e841b55b6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 4, 8, "\uda2f\udddc\udaa4\udf4b\ud93b\udddc\udb27\udf4f\ud8da\ude04\udbda\udce4\ud820\udc4a\uda24\udcf6\uda3f\udd29\uda3a\udf5f\uda26\udcd0\udb61\udcfb\uda87\uddc6\udb99\udf81\uda1f\udfce\u933b\uda20\udf8d", "\u52d8\u3eac\u4a45\u3377\ua794\u68d4\uc91b\ud036\u3835", "\ud9fd\udf3b",
        23, 87110, 1054898649, -6354495700879366729L, 56534L, false, true, (char) 20279, (char) 39706,
        Double.longBitsToDouble(0x3fe85032a9bae50eL), Double.longBitsToDouble(0x3fee6526e354111aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 2, 3, "\uda14\udc5c\u6631\ud959\ude9d", "\ua1a6\u0e2c\u540a\u5f1f", "\udb47\ude15",
        45, 75473, -1806467298, 4007455948864936889L, -62590L, true, true, (char) 40486, (char) 48149,
        Double.longBitsToDouble(0x3fea53ea79f9bd7dL), Double.longBitsToDouble(0x3fd8d1a458b5b074L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 9, 4, 1, "\uda14\udc5c\ud8bf\ude07\ud93b\udddc\ud837\udf57\ud8da\ude04\u4341\udbe8\udfb0\udb59\udd77\uda3f\uddcb\udb2d\udc39\ud87f\ude56\udb47\ude15\ud959\udfe4\ud92d\udcaa", "\u484f\u4c2b\ube84\ud3e2\ua703", "\ud989\udc08\uda5e\udf5e\ud930\udf85\udbd6\udf34",
        47, 30574, 577388951, 1655105716772723722L, 97830L, true, false, (char) 38661, (char) 52356,
        Double.longBitsToDouble(0x3fb83680e321dc78L), Double.longBitsToDouble(0x3fe40f174d671b5aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 6, 3, "\uda29\udc64\udb6f\udd31\ud9da\udff2", "\u1d80\u0e7b\ud43a\u0a61\ud4a1\u4e38\u7512\u2c15\ua349\u3690\u29de\u7d4e\u4c2b\ube84", "\udada\ude53\uda29\udf08\ud9fe\udf0c",
        37, 88633, -667279987, -7500274406002335954L, -92351L, true, true, (char) 13219, (char) 35521,
        Double.longBitsToDouble(0x3fe2d939562854cbL), Double.longBitsToDouble(0x3fdff6d4da24ee0eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 7, 2, 2, "\uda14\udc5c\udbcb\udfa9\ud834\udef9", "\ua1a6\u0e2c\u8191\u4b0f\u8240\u4708\u48e3\u2c15\u0724\u4f80\u8515\u4836\u4c2b\ube84\ud3e2\u3e9a\u64a4\uc821\u382f\u228a\uacdc\ud357\u35cd\u75bb", "\ud82f\udeb0\ud8fc\udd71\ud9d5\udcd4\ud9c8\udc94\ud9ad\udf2f\ud980\udfec\uda99\udfe5\uda01\udf3a\ud9e0\udf73\udb71\udef0\uda71\ude1e\uda7b\uddf7\udbe4\ude59\uda58\udcdb\ud82f\ude9a\uda6e\udcbd\udaea\ude71",
        5, 36846, 1285650407, -150580802332287231L, -71480L, true, true, (char) 41774, (char) 22105,
        Double.longBitsToDouble(0x3fcf8f6d602a5320L), Double.longBitsToDouble(0x3fe93d30acec357eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 2, 3, "\udaf6\udce9\uda1a\ude6c\ud936\udc45", "\ua1a6\u0e2c\ud43a\u5f1f\u81f0\u4e38\u4972", "\uda2e\udcc5\u933b\uda20\udf8d\ud86f\udf4f\uda2c\udde0\ud815\ude31\udab5\udda3",
        53, 21485, 2102385578, -4792437715184035335L, 52534L, false, true, (char) 42969, (char) 16459,
        Double.longBitsToDouble(0x3fd6316f835eb3e8L), Double.longBitsToDouble(0x3fdd9fbe841b55b6L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 4, 3, "\uda14\udfbb\uda35\ude1a\ud857\udde9", "\ua1a6\u0e2c\u463f\u7a97\u54ea", "\uda28\ude86\udaa1\udcc3\uda19\udf3a\ud992\ude45\uda69\uddf2\uda2a\udcfc\udae8\uddfe\udb27\udce8\udb8e\udc03\udadf\udce0\uda29\udf08\ud9fe\udf0c\uda5e\udf27\ud930\udf85\udbd6\udf34\ud9e3\udd65\uda27\ude44\udb11\ude14",
        25, 55441, -68626001, -6135176092451415539L, 50690L, false, true, (char) 9574, (char) 7090,
        Double.longBitsToDouble(0x3fc6d30feb6b0874L), Double.longBitsToDouble(0x3fe9d4af69404ff3L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 4, 5, "\uda14\udc5c\udaa5\udc15\ud93b\udddc", "\ua1a6\u0e2c\ud43a\u5f1f\u81f0\u4e38\u4972", "\uda2e\udcc5\u933b\uda20\udf8d\uda2a\udd56\uda2c\udde0\udb8d\udd9d\ud95b\udebe",
        53, 21485, 2102385578, -4790748867082233351L, 52534L, false, true, (char) 42969, (char) 16459,
        Double.longBitsToDouble(0x3fd6316f835eb3e8L), Double.longBitsToDouble(0x3fdd9fbe841b55b6L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 7, 2, 3, "\ud9a0\udc62\udaa5\udc15\ud93b\udddc", "\u0b7c\uc9be\u84c4\u218f\u5708\u4e61\u4972", "\uda2e\udcc5\ud8df\udf66\udbe0\ude00\uda2a\udd56\ud9e1\udf1b\udb86\udca2\ud95b\udebe\udada\ude53\uda29\udf08\ud9fe\udf0c\uda5e\udf5e\ud930\udf85\ud9d7\udc94\udb59\udd14\ud910\udf0b\u016d\ub76e\ud8f7\udd6d\ud8fc\udd23\ud9d5\udcd4\uda12\udf3a\udb9f\udcff",
        50, 98626, 898199281, -6196076415796027748L, -52109L, false, true, (char) 55390, (char) 42391,
        Double.longBitsToDouble(0x3feeff747eb49798L), Double.longBitsToDouble(0x3fe8bc920ca4cc2cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 1, 4, 9, 4, "\uda14\udc5c", "\ud31f\u6eac\ua1a6\ua715\ud43a\u5f1f\u81f0\u4e38\u4972\u2c15\u0724\u4f80\u29de\u484f", "\uda60\udec6\uda14\ude2b\ud831\udf70\uda29\udf08\ud9fe\udf0c\uda5e\udf5e\ud80b\uddf2\ud042\ud9cd\udd88\ud959\udcb7\ud89c\udd9a\ud9fd\udf3b\ud82f\udeb0",
        19, 86001, 1437915661, -8114201597312824132L, -39512L, true, true, (char) 4007, (char) 33572,
        Double.longBitsToDouble(0x3fe6577657e586afL), Double.longBitsToDouble(0x3fe02af7edda78f3L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 6, 4, "\uda14\udc5c\udaa5\udc15\uda21\udeaf", "\ubac8\u0e2c", "\ud8e6\udf15\ud87f\ude38\udb47\ude15\uda08\udd6b\udb43\udec2\uda2e\udcc5\uda87\udfe7\ud86f\ude3c\uda7b\udc9f\udbc1\uddb9",
        42, 95606, 356671763, -9048988507039648701L, 73575L, true, true, (char) 33892, (char) 30487,
        Double.longBitsToDouble(0x3fec9bc235e1226aL), Double.longBitsToDouble(0x3fd63e3dcce0b3e8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 2, 3, "\uda14\udc5c\udaa5\udc15\uda89\udd63", "\u86eb\u0e2c\u52c4", "\ud8b6\udf56",
        2, 10456, 536879273, -7758717965270427660L, 92636L, false, true, (char) 20867, (char) 5913,
        Double.longBitsToDouble(0x3fd13871fc9b2e50L), Double.longBitsToDouble(0x3fda08b6fe94fa9eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 3, "\uda14\udc5c\ud9ce\ude6b\ud93b\uddb6\ud837\udf57\ud8da\ude04\u4341\udbe8\udfb0\udb59\udd77", "\u4e38\u825f", "\uda2e\udcc5\u933b\uda20\udf8d\uda2a\udd56\ud805\ude4c\udbb4\ude1d\ud95b\udebe\ud868\udffa\uda29\udea0\ud9fe\udf0c\uda1c\udd91\ud930\udf85\udbd6\udf34",
        47, 30574, 577384339, 1655105716772686179L, -65657L, true, false, (char) 64275, (char) 62953,
        Double.longBitsToDouble(0x3f930e2ff6f52240L), Double.longBitsToDouble(0x3fbfe0a0d7ddf478L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=java.lang.Long:0 |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 9, 4, 8, "\uda2f\udddc\udaa4\udf4b\ud93b\udddc\udb27\udf4f\ud8da\ude04\udbda\udce4\ud806\ude4a\uda24\udcf6\uda3f\udd29\uda3a\udf5f\uda26\udcd0\udb61\udcfb\uda87\uddc6\udb99\udf81\uda1f\udfce\u933b\uda20\udf8d", "\u5ca1\u373f\u4a45\u3377\ua794\u68d4\uc91b\ud036\u3835", "\ud997\udec8",
        23, 87110, 1054898649, -6354495700879366729L, 56534L, false, true, (char) 20279, (char) 39706,
        Double.longBitsToDouble(0x3fcac0caa6eb9678L), Double.longBitsToDouble(0x3fe91526e354111aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 8, "\uda2f\udddc\udaa4\udf4b\ud93b\udddc\udb01\udd7d\uda76\udf3e\udbda\udce4\ud820\udc4a\uda24\udcf6\uda3f\udd29\uda3a\udf5f\uda26\udcd0\udb61\udcfb\uda87\uddc6\udb99\udf81\uda1f\udfce\u933b\uda20\udf8d", "\u85f8\u3e51\u4a45\u3377\ua794\u68d4\uc91b\ud036\u3835", "\ud9fd\udf3b",
        23, 87110, 1054898649, -6354495700879366729L, 56534L, false, true, (char) 20279, (char) 39706,
        Double.longBitsToDouble(0x3fe85032a9bae50eL), Double.longBitsToDouble(0x3fee6526e354111aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 5, "\uda14\udc5c\ud91b\ude31\ud959\ude9d", "\ua1a6\u0e2c\u540a\u5f1f", "\udb47\ude15",
        45, 75473, -1806467298, 4007455948864936889L, -62590L, true, true, (char) 40486, (char) 48149,
        Double.longBitsToDouble(0x3fea53ea79f9bd7dL), Double.longBitsToDouble(0x3fd8d1a458b5b074L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 9, 7, 3, "\ud914\udd5e\u6631\ud93c\ude47\uda0c\ude4e\ud8da\ude04\uda09\udf41", "\u5f1f\ua903\u3b06\u7831\u2bd8\u0724\u4f80\u29de\u4142\u4c2b\u0243\ud05d", "\uda29\udf08\ud9fe\udf0c\ud8bc\ude6d\ud91a\uddbd\udbd6\udf34\ud8da\udc51\ud908\ude8f\uda0d\udd45\ud9f9\udc20\ud8ca\udfc0\udba6\udd0b\uda5c\udcb7\ud9d9\udec8\ud958\udff1\ud9c3\udf95",
        28, 19985, -829714524, 8777716595577854695L, 55395L, true, false, (char) 29851, (char) 21959,
        Double.longBitsToDouble(0x3fe073fe1b64491cL), Double.longBitsToDouble(0x3fe541617888df9aL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 0, "\udbbb\udcb0\ud929\udc12\u151e\uda05\udfec\ud891\udd74", "\u3724\uba09\u8395\u4e00\u4972\u2c15\u0724\u4f80\u29de\u484f\u859b\ua57b\u0c1e\u3e99\uaad5\uc457", "\uda29\udfe6",
        -2, 7482, 2088318316, 2550259474974475493L, 57685L, true, true, (char) 40328, (char) 49058,
        Double.longBitsToDouble(0x3fb99baada354658L), Double.longBitsToDouble(0x3fe98e6599112ef1L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 7, 7, 3, "\udaea\ude06\ud9f1\uddf8\ud921\udc32", "\ub454\u3e3d\u187a\ua6d1", "\udb47\ude10\udba3\udff4\ud951\ude97\uda2e\udcc5\u933b\ud9d6\udfac\ucc54\udadf\ude59\udb91\uddd8\ud95b\udebe\udada\ude53\uda29\udf08",
        8, 20642, 440752633, -2865945722223547371L, 57299L, true, true, (char) 49496, (char) 60050,
        Double.longBitsToDouble(0x3fc4f71d1131d108L), Double.longBitsToDouble(0x3fda00f0d52acb94L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 9, "\uda14\udc5c\u6631\ud959\ude9d\uda0c\ude4e", "\u0e2c\u540a\u5f1f\u824c\u4e38\u4972\u2c15\uc183\u5018", "\udbac\udc37\ud94a\ude85\ud9a6\uddf7\ud95b\uddea\udada\ude53\udacb\udd03\ud9fe\udf0c\uda5e\udf5e\ud930\udf85\udbd6\udf34\uc69d\udbbd\udf7c\ud85f\uddd6\uda41\ude40\ud937\udc6d\uda32\udda0\ud9e1\udc73\ud888\udee8\ud95d\udebe\ud9f5\udf38\ud876\udcf8\uda17\udd93\ud8c3\udd79",
        44, 33908, -2000685788, -2918418107910440232L, 14227L, true, false, (char) 15982, (char) 55960,
        Double.longBitsToDouble(0x3fc9b0b454d4d248L), Double.longBitsToDouble(0x3fe33fa0f442a2bdL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 2, "\ud90f\udeb9\ud821\udd38\ud959\ude9d\ud8b9\ude24", "\u0e2c\u549b\u61a3\u2215\uc801\u1b85\u2c71\u24f5\u4f80", "\uda2a\udd56\udadf\ude2c\udb20\udc7f\uda98\udd89\udaeb\udd7a\udb7a\udfe1\ud9fe\udf0c\uda5e\udf5e\ud930\udf85\ud9e7\udd10\ud9d3\udd10\ud951\udfed\udb15\udffe\ud822\ude5e\udb5d\udc88\ud92e\uddae\udbf7\udfb0\ud925\udd94\ud89d\udc69\ud89d\udc95\udbf6\udefc\ud9fe\udc22\udbfc\uddc1",
        44, 52799, -750330744, -1149973971356476232L, 78443L, false, false, (char) 35400, (char) 25997,
        Double.longBitsToDouble(0x3fed8d6d017e62e9L), Double.longBitsToDouble(0x3fe0da3ef2e9242aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=java.lang.Boolean:false |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 7, 7, 9, "\uda14\udc7c\u6631\ud959\ude9d", "\u24b7\u0a29\ud7cb\u5f09\u824c\u4e38\u4972\u2c15\u7424\u4f80\u29de\u0dc6\u4c3b\u4990\u0c1e\u3e71\u4a45", "\uda5e\udf5e\ud930\udf85",
        59, 15962, 2047050264, -2042253776063497707L, -19621L, true, false, (char) 19299, (char) 34642,
        Double.longBitsToDouble(0x3fef164c0575f199L), Double.longBitsToDouble(0x3fd7b42e7ca662e2L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=java.lang.Long:0 |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 4, 4, 1, "\ue98e\udbe8\ude29", "\uaff8\u2e43\u9249\ud4f9\u1cfc\u81f0\u946a\u9235\u5331\u55a1\u9c13\u0e7d\ubecd\u270d\ud685\u49e7\ubaba\u4a45\ud73d", "\ud930\udf85\udbd6\udf34\ud939\udfa1\udbab\udf28\ud915\uddfc\ud92e\uddd3\ubaa5\ud8fc\udd71\udb9a\udc06",
        46, 23023, 523063870, 4293198550670095460L, -16730L, true, true, (char) 52870, (char) 65128,
        Double.longBitsToDouble(0x3fd6492c430dce5eL), Double.longBitsToDouble(0x3fef3efbff0d41cdL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\0121=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@? |this=com.fasterxml.jackson.databind.ser.std.CalendarSerializer:@?\012",
        Z.run(T, 2, 9, 9, 9, "\uda14\udc5c\ud9ce\ude6b\ud93b\uddb6\ud837\udf57\udab6\udf36\udaae\udf78\udbe8\udfb0\udb59\udd77\uda3f\uddcb\udb2d\udc39\udbed\udd3e\udba8\udeb9\ud8f4\ude5d\ud92d\udc9b", "\u484f", "\udbb4\ude1d\ud95b\udebe\ud868\udffa\uda29\udea0\ud9fe\udf0c\uda1c\udd91\ud930\udf85\udbd6\udf34\udaa5\ude07\uda27\ude44\ud89c\udd9a\ud9fd\udf3b\ud82f\udeb0",
        19, 86001, 340646413, -983501300992900208L, -42583L, true, false, (char) 53642, (char) 40318,
        Double.longBitsToDouble(0x3feb956d1de9eeb5L), Double.longBitsToDouble(0x3fe83276fb382f55L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 8, 2, 3, "\uda96\udc9c\udaa5\udc15\ud839\uddda", "\u4a28\ub4bc\u8bac", "\ud87f\ude56\ud876\uddcc\uda02\udeb8",
        11, 30182, 415787370, -164977981837454331L, -3675L, false, true, (char) 59442, (char) 3859,
        Double.longBitsToDouble(0x3fe8723da74adda0L), Double.longBitsToDouble(0x3fb9af5f6c68d228L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|createContextual|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|_acceptJsonFormatVisitor|com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper,com.fasterxml.jackson.databind.JavaType,boolean|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|_asTimestamp|com.fasterxml.jackson.databind.SerializerProvider|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|_serializeAsString|java.util.Date,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|_timestamp|java.lang.Object|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|acceptJsonFormatVisitor|com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper,com.fasterxml.jackson.databind.JavaType|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|getSchema|com.fasterxml.jackson.databind.SerializerProvider,java.lang.reflect.Type|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|isEmpty|com.fasterxml.jackson.databind.SerializerProvider,java.lang.Object|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|serialize|java.lang.Object,com.fasterxml.jackson.core.JsonGenerator,com.fasterxml.jackson.databind.SerializerProvider|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|withFormat|java.lang.Boolean,java.text.DateFormat|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
    "M|com.fasterxml.jackson.databind.ser.std.DateTimeSerializerBase|createContextual|com.fasterxml.jackson.databind.SerializerProvider,com.fasterxml.jackson.databind.BeanProperty|fld:com.fasterxml.jackson.databind.ser.std.CalendarSerializer:instance",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
