package com.fasterxml.jackson.databind.node;
import org.junit.Test;
import static org.junit.Assert.*;
public class TreeTraversingParser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 8, "\uda32\udee1\uda25\udc7e\ud8b2\ude87\udaa4\udec6\ud8fa\udc38\udbbf\udcec\ud9b3\udc7d\ud83a\ude96\ud901\udc63\udb26\udce4\udb79\uded9\ud945\udf20\ud82d\udc93\udb87\udccd\ud89f\udec9\ud96d\ude6a\ud912\udf82", "\u2f28\u58c2\u906c\u9fe8\ub0de\u4511", "\uda64\udcfc\udbe4\udf97\udab7\udd4f\udaec\udca4\ud8dd\udca2\ud9c3\udd9c\uda94\udf2c\ud97d\udd79",
        11, 75809, -1267215409, 6661883534322422542L, -45206L, false, true, (char) 40322, (char) 39635,
        Double.longBitsToDouble(0x3fc095798c93c930L), Double.longBitsToDouble(0x3fe62f0330d1602aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 8, "\udb20\ude6b\uda25\udc62\ud9a5\udccd\uda5b\udf41\ud9dc\udeed\ud887\udf16\ud945\uddb3\ud854\uddff\ud901\udc63\udb26\udce4\udb79\uded9\ud945\udf20\uda58\udde1\ud9b2\udfdb\ud80c\udcb3\ud8b1\udf3f\ud912\udfbe", "\u9627\u58c2\u906c\u3e8d\u1c20\u4511\u64ca\u9050\uc8a9\u5b79\u4acb", "\uda72\udcf4\ud938\udc60\ud97d\udcdc\udae5\ude6e\uda85\udf71\ud9c6\udd05\udb18\udd39\ud80f\udeba\udad4\udd22\udad0\udc55\udb6a\udcb6\ud8d3\udd51\ud96b\udfe8\uda67\udda6",
        31, 84036, -113853660, 3459034851183167300L, -54178L, true, true, (char) 46091, (char) 30270,
        Double.longBitsToDouble(0x3fd2cba4ce7c0aa8L), Double.longBitsToDouble(0x3fe0f6f00c52c6eeL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 16, 11, "\uda32\udee1\uda25\udc7e\ud8b2\ude87\udbf2\udecd\ud90c\udf2a\ud933\udf66\ud99b\udd24\ud83a\ude96\ud901\udc63\udafe\udfe4\udb79\uded9\ud882\ude6e\ud82d\udc93\udb87\udccd\ud89f\udec9\ud96d\ude6a\ud912\udf82", "\u2f28\u58c2\u906c\u9fe8\ub0de\u4511", "\uda64\udcfc\udbe4\udf97\ud831\udd4c\udaec\udca4\ud8dd\udc6e\ud9c3\udd9c\uda94\udf2c\ud97d\udd79",
        11, 75809, -1267215409, 6661883534322422542L, -52204L, true, false, (char) 48314, (char) 48031,
        Double.longBitsToDouble(0x3fca9095c07b6ad4L), Double.longBitsToDouble(0x3fc095798c93c930L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 10, 9, "\ud93f\udc64\uda67\udf2f\udb5f\udc7c\udaa4\udec6\ud85b\udc09\udaea\udd86\ud97b\udda6\udb38\udcd4\ud91f\udfe6\udb26\udce4\ud898\udd9e\uda31\udc0d\ud8fd\uded2\ud941\udc24\ud89f\udec9\uda99\udcfb\ufa6a", "\u2f12\u58c2\u906c\u9fe8\u9fc4\u00e1\ub602\u17e9\u0bfb\u9fd7", "\ud849\udf83\ud9c3\udd9c",
        48, 7047, 1588937957, -3856944997455113265L, -91294L, false, false, (char) 53027, (char) 41889,
        Double.longBitsToDouble(0x3fe46f7f78d16017L), Double.longBitsToDouble(0x3fe04faca31d2ea8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 15, "\uda32\udee1\uda25\udc7e\ud8b2\ude87\udaa4\udec6\ud8fa\udc38\udbbf\udcec\ud97c\udd7d\ud83a\ude96\ud901\udc63\udb26\udce4\udb79\uded9\ud945\udf20\ud99f\ude8b\udb79\udd5d\ud89f\udec9\ud96d\ude6a\ud9fa\udeb5", "\u8a2b\u4046\u1834\u9fe8\ub0de\u4511", "\uda64\udcfc\udbe4\udf97\udab7\udd4f\uda39\udf2b\ud8dd\udca2\ud9c3\udd9c\uda94\udf2c\ud97d\udd79\ud908\ude1f",
        39, 30591, 1551090631, 4490039411327411886L, 88675L, false, false, (char) 8916, (char) 55947,
        Double.longBitsToDouble(0x3fe9279262c5e066L), Double.longBitsToDouble(0x3fca2c055c039fa0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 2, 3, "\uda32\udee1\uda25\udc7e\ud8b2\ude87\udaa4\udec6\ud8fa\udc38\uda60\ude8d\udb62\ude12\uda5b\uddef\ud85b\udf69\udb26\udce4\udb79\uded9\ud945\udf20\ud82d\udc93\udb87\udccd\ud89f\udec9\ud96d\ude6a\ud912\udf82", "\u2f28\u58c2\u906c\u9fe8\ub0de\u4511", "\uda64\udcfc\udbe4\udf97\udab7\udd4f\udaec\udca4\ud8dd\udca2\ud9c3\udd9c\uda94\udf2c\ud97d\udd79",
        11, 75809, -1267215409, 6661883534322422542L, -45206L, false, true, (char) 40322, (char) 39635,
        Double.longBitsToDouble(0x3fc095798c93c930L), Double.longBitsToDouble(0x3fb7afb3068b0150L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 16, "\uda5a\udf87", "\u9328", "\ud8ce\udd7d\ud83a\ude96\ud96e\udf9b\udb26\udce4\udb79\uded9\ud945\udf20\ud82d\udc93\udbf9\udcc6",
        29, 67803, -1893499122, 1286850485537945683L, -4850L, false, true, (char) 14042, (char) 27291,
        Double.longBitsToDouble(0x3fe803a5c2d2747eL), Double.longBitsToDouble(0x3fe765f14a955f03L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 6, 8, "\ud974\udee2\uda3c\ude7e\ud95b\udd82\udaa4\udec6\ud8fa\udc38\udbbf\udcec\ud87e\udc1d\ud827\udee6\ud87d\udeb5\udbd3\udc97\udb79\uded9\ud945\udf20\ud82d\udc93\udbf8\ude26\uda61\udfd2\ud8d2\uddf2\ua34e", "\u2f28\u58c2\ub06c\u6b25\ua38e\u7688\u64d3\ubb3b\uc27f\u5b79\u86f0\u4094\uc3dc\u2fd7\u8bfe\u3cd8\u2558\u78b8", "\ud80f\udeba\udb90\udd40",
        44, 48744, 1557932534, -8885916661188120063L, 7835L, true, false, (char) 63015, (char) 63793,
        Double.longBitsToDouble(0x3fc84c5b98f2b0d8L), Double.longBitsToDouble(0x3fa101ce20e99300L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 8, "\uda32\udee1\uda25\udc7e\ud8b2\ude87\udaa4\udec6\udad2\udf3e\udbbf\udcec\ud9b3\udc7d\ud83a\ude96\ud901\udc63\udb26\udce4\udb79\uded9\ud945\udf20\ud82d\udc93\udb87\udccd\ud89f\udec9\ud96d\ude6a\ud912\udf82", "\u2f28\ua560", "\udbb1\udd68\ud9c2\udddd\udaf9\udef0\ud9b4\udc85\uda64\udcfc\udbe4\udf97\udab7\udd4f\udaec\udca4\ud8dd\udca2",
        22, 17288, -120484371, 6392090995562471465L, -84583L, false, true, (char) 58620, (char) 53808,
        Double.longBitsToDouble(0x3fe34543d9f69d7cL), Double.longBitsToDouble(0x3fde0d9bf1a9095cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 3, "\ud86d\udf6f\ud842\udd77\ud8b2\ude87", "\u119e\u1b9d", "\udb26\udce4\udb79\uded9\ud945\udf20\ud82d\udc93\ud81d\udf99\ud89f\udf7e\ud96d\ude6a\ud912\udf82\udad1\udc20",
        21, 10177, -834047058, -938402542557055777L, -19996L, false, false, (char) 47381, (char) 45464,
        Double.longBitsToDouble(0x3fccfc9ddca9c62cL), Double.longBitsToDouble(0x3fe2cb427af4e315L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 2, 8, "\udbb8\udee4\uda25\udc7e\udba6\udc81\uda68\udc63\ud910\udc1e\udb69\ude01\ud973\udf3a\ud83a\ude96\ud901\udc63\udb26\udce4\udb79\uded9\ud945\udf20\udbab\ude53\ud81b\udf22\ud89f\udf35\ud98a\udfe2\udb44\udd19", "\u1528\u66a5\u6382\ua7ce", "\udaf9\udef0\ud97c\udf0a\udb46\udf9e\uda6a\ude26\u2331\udaa2\ude41",
        25, 79087, -1065147400, -992043677366774234L, 14954L, false, true, (char) 27280, (char) 4688,
        Double.longBitsToDouble(0x3fd843ad3752cdf2L), Double.longBitsToDouble(0x3fe62f0330d1602aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 10, 8, "\uda32\udee1\uda25\udc7e\ud8b2\ude87\udaa4\udec6\udaaf\ude73\udbbf\udcec\uda93\udccc", "\u158b\u84e6\uc543\u2a45\u66a6\uc3cc\u8aa5\ubdb4\u200a", "\u00c0\ud9ff\udf17\uda9b\udd05\udbb1\udd68\ud9c2\udddd",
        22, 12364, -454143339, 8181638539982645034L, 30316L, true, true, (char) 62713, (char) 32882,
        Double.longBitsToDouble(0x3fccbf0ac0a562d4L), Double.longBitsToDouble(0x3fee7e53cbc7b477L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 8, "\uda32\udee1\uda25\udc7e\ud8b2\ude87\udaa4\udec6\ud8fa\udc38\udbbf\udcec\ud9b3\udc7d\ud83a\ude96\ud901\udc63\udb26\udce4\udb79\uded9\ud945\udf20\ud82d\udc93\udb87\udccd\ud89f\udec9\ud96d\ude6a\ud912\udf82", "\u2f28\u58c2\u906c\u9fe8\ub0de\u4511", "\uda64\udcfc\udbe4\udf97\udab7\udd4f\udaec\udca4\ud8dd\udca2\ud9c3\udd9c\uda94\udf2c\ud97d\udd79\ud908\ude1f\ud9c9\udd01\ud9cd\udf5b\udb18\udd39",
        36, 80150, -1468291451, -7098787471491651082L, -23156L, false, false, (char) 52304, (char) 44400,
        Double.longBitsToDouble(0x3fe62f0330157b2aL), Double.longBitsToDouble(0x3fe8cfbbd435d171L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 12, 8, "\uda79\udf85\uda4c\udc74\ud8b2\ude73\udb88\udf61\ud8f6\udd37\udbb3\udce6\udaa9\udc90\ud980\udd25\ud8dd\udc32\udb26\udca0\udb72\udcf4\udb59\ude75\ud944\udf5c\u1b61\udbca\ude5a\ud90d\udd66\ud8ae\uddaf", "\u2f28\u58c2", "\udb70\udd48\ud9ee\udf7f\ud948\udd2c\udb08\udc8f\uda64\udcfc\udbe4\udf97\uda87\udffa\ud86d\udd85\ud8dd\udc7c\ud9c3\udd9c\uda94\udf2c\ud96e\udf7f\ud8ea\udd3c",
        39, 30591, -1080835129, 4490888685275621038L, -65358L, true, false, (char) 55456, (char) 40322,
        Double.longBitsToDouble(0x3fd399291fb2f864L), Double.longBitsToDouble(0x3fe48f7e5ac5dde9L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 4, 8, "\ud824\udd13\uda25\udcb2\ud8b2\ude87", "\u119e\uac2f", "\ud97c\udfc5\udb8a\udf46\ud945\udf20\udb7b\udd1a\ud8dc\udca3\udab6\udec9\ud92f\udd7f\ud912\udf82",
        42, 96491, 360480177, 4951834981236903838L, -53272L, false, true, (char) 26448, (char) 47381,
        Double.longBitsToDouble(0x3fe4aaf81ce7e4eeL), Double.longBitsToDouble(0x3fe1538c5a596ec9L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 13, 8, "\ud941\udc6e\uda25\udc75\ud8b2\ude87\udaa4\udec6\ud8fa\udc38\udbbf\udcec\ud9b3\udc7d\ud83a\ude96\ud901\udc63\udb26\udce4\udb79\uded9\ud945\udf20\ud99d\udcc3\ud8ba\uddd2\ud89f\udeef\ud96d\ude6a\udb72\udde9", "\u2f28\u58c2\u906c\u9fe8\u877b\u4511", "\uda64\udcfc\udbe4\udf97\udab7\udd4f\udaec\udca4\ud8dd\udca2\ud9c3\udd9c\ud899\udc27\ud97d\udd79",
        11, 88424, -663235633, 6661883533282235150L, -45206L, false, true, (char) 40322, (char) 39635,
        Double.longBitsToDouble(0x3fec655e6324f24cL), Double.longBitsToDouble(0x3fe62f0330d1602aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 6, 8, "\uda32\udee1\ud835\ude65\ud8b2\ude5f\udaa4\udec6\ud8fa\udc38\udbbf\udcec\ud9b3\udc7d\ud83a\ude96\ud901\udc63\udb26\udce4\udb79\uded9\ud945\udf20\ud82d\udc93\udb87\udccd\ud89f\udec9\ud96d\ude6a\ud912\udf82", "\u2f28\u58c2\u906c\u9fe8\ub0de\u08eb", "\uda64\udcfc\udbc4\udd87\udade\udc0a\udaec\udca4\ud8dd\udca2\ud9c3\udd9c\uda94\udf2c\ud97d\udd79\ud908\ude1f\ud9c9\udd01\ud9cd\udf5b",
        46, 67766, 732735150, -6306263764694201752L, -26752L, false, false, (char) 39635, (char) 52304,
        Double.longBitsToDouble(0x3fe9279262c5e066L), Double.longBitsToDouble(0x3fca2c055a1855a8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 8, "\udb20\ude6b\ud96c\ude65\ud8cd\udc99\uda5b\udf41\ud9dc\udeed\ud887\udf16\ud9ef\udea7\u6541\ud8fc\udd0f\udad9\udf1e\uda3b\udd32\u21b7\uda58\udde1\ud86f\udc12\u8801\ud8b1\udf3f\ud912\udfbe", "\u0525\u5334\u906c\u3151\u993c\u34f6\u64ca\u9050\uc8a9\u5b79\u4acb", "\uda72\udcf4\ud831\udd7d\uda85\udfd0\udae5\ude6e\uda85\udf71\ud9c6\udd05\udb18\udd39\ud8d0\udf7b\udad4\udd22\udad0\udc55\udb6a\udcb6\uda3b\ude64\udadd\udfd2\uda67\udda6",
        8, 82294, -1685557724, 7422201617026520612L, -14526L, false, true, (char) 10994, (char) 53976,
        Double.longBitsToDouble(0x3fe2a6689e813da6L), Double.longBitsToDouble(0x3fe2eaad7a3d0e7bL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 9, 8, "\udbcd\ude90\uda25\udc62\ud9a5\udccd\uda5b\udf41\ud9dc\udeed\ud80b\udd3c\ud846\udfbc\ud84c\udc71\ud901\udc63\udb26\udce4\udb79\uded9\ud945\udf20\ud968\ude69\uda7f\udd5b\ud9a7\uddb1\ud8b1\udf3f\ud912\udfbe", "\u9627\u58c2\u906c\u3e8d\u6ad8\u4e66\u5cb9\u92ab\uc8a9", "\uda16\ude34\ud90c\udcee\uda72\udcf4\ud938\udc60\ud97d\udcdc",
        53, 10531, -1267223175, -1929295704840219890L, -95311L, true, false, (char) 39605, (char) 7970,
        Double.longBitsToDouble(0x3feeea87201eda75L), Double.longBitsToDouble(0x3fc095798c93c930L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 7, 11, "\uda32\udee1\ud918\udd17\ud814\udf4f\udbf2\udecd\ud90c\udf2a\ud933\udf66\udbe1\udc87\u76b9\ud901\udc63\udafe\udfe4\udb79\uded9\ud882\ude6e\ud82d\udc93\udb87\udccd\udb9f\udd6b\ud803\udfa2\ud912\udf82", "\u2f28\uafca\u901d\u9fe8\ub0de\u4511\u9660\ucb88", "\ud831\udd4c\udaec\udca4\ud8dd\udc6e",
        22, 27664, -128545524, 6392090995562471465L, -84583L, false, true, (char) 58620, (char) 51687,
        Double.longBitsToDouble(0x3fe76a2e05d30ee8L), Double.longBitsToDouble(0x3fde0d9bf1a9095cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 10, 9, "\ud93f\udc64\uda67\udf2f\udb5f\udc7c\udaa4\udec6\ud85b\udc09\udaea\udd86\ud98d\udcb2\ud94c\udcc2\udafc\udc6e\udb26\udce4\ud898\udd9e\uda31\udc0d\ud8fd\uded2\ud941\udc24\ud89f\udec9\udae1\udf20\uce69", "\u2f12\u58c2\u906c\u9fe8\u9fc4\u00e1\ub602\u55da\u0bfb\u9fd7", "\ud849\udf83\ud9c3\udd9c",
        48, 7047, 1588937957, -3856944994812374065L, -91294L, false, false, (char) 53027, (char) 41889,
        Double.longBitsToDouble(0x3fe46f7f78d16017L), Double.longBitsToDouble(0x3fe04faca31d2ea8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 10, 9, "\ud93f\udc64\udb2d\uddf2\ud91d\udf43\udaa4\udec6\ud85b\udc09\udaea\udd86\ud97b\udda6\udb57\ude11\ud91f\udfe6\udb08\udc3d\ud898\udd9e\uda31\udc0d\ud8fd\uded2\uda71\udfbd\ud8c1\udce7\uda99\udcfb\ufa6a", "\u2f12\u58c2\u906c\u9fe8\u9fc4\u00e1\ub602\u17e9\u0bfb\u9fd7", "\ud865\uddfb\ud9c3\udd9c",
        5, 7129, 1588937957, -3856944997455113265L, -91294L, false, false, (char) 53027, (char) 41889,
        Double.longBitsToDouble(0x3fe46f7f78d16017L), Double.longBitsToDouble(0x3fe8bdc4a31d2cbdL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 10, 9, "\ud93f\udc64", "\u8e00\000\000\000\u13fe\u1011\u158b\u894d\u7f06\000\000\000\000\u0424\u6a1d\u8b88\u009b\u58c2\u906c\u34df\000\000\000\000\u9165\u9fd7", "\ud849\udf83\ud9c3\udd9c",
        -5, -1000, 1588937728, -3856944997455113265L, -100000L, false, false, (char) 51058, (char) 62375,
        Double.longBitsToDouble(0x3fe0109398000020L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 13, 1, "\ud943\udf97\ud9e9\udef9\ud9a2\uddb8\ud8f2\udf3d\ud8b8\udc17\udbbf\udcec\ud8ce\udd7d\udb04\udf30\ua257\uda21\udcb4\udb79\ude15\ud945\udf37\ud82d\udc93\udbf9\udcc6\ud8d5\udf43\ud9f5\udeb6\ud912\udc67\ud990\udfbd\ud8cd\uddd2\ud8bd\udec0\udbf0\udcbf\u2c39\udb6b\udf1c\u8d51\uda99\udf7c\udaf9\udef0\ud9b4\udc85\uda27\udffe\ud9f2\udf50\udb07\udfc6", "\u0751\u5862\u3081\u32fb\u5889\u3d8d\u4af0\u4eb9\u31b9\ucb66\ua62e\ucac7\uc449\u1650\u64f0\u06c1\ucba7\u343e\ubeca\ucca2\u4e20\uc16c\u1265\u2ae3\u6b32\u9ab6\ub31b\u3710\u2a03\u29df\uadce\u40d9\uba60\ud322\u8597\u608a\u997b\uad4a\u1a77\ud7f3\u1073\u3596\u596f\u7da3\uae7a", "\udb74\udd22\u29ff\u5fbf",
        3, 51966, 365078949, -3563824527240334504L, 37914L, true, true, (char) 11139, (char) 52692,
        Double.longBitsToDouble(0x3fec68d1765d4923L), Double.longBitsToDouble(0x3fb40fbad0e6acf8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 8, "\uda32\udee1\uda25\udc7e\ud8b2\ude87\udaa4\udec6\ud8fa\udc38\udbbf\udcec\ud9b3\udc7d\ud83a\ude96\ud901\udc63", "\uc543\u2a45\u66a6\uc3cc\u8aa5\ubdb4\u200a\u6dfc\u2f28\u58c2\u906c\u9fe8", "\udaf9\udef0\ud9b4\udc85",
        21, 75167, 1750050602, -2083668712182447372L, 9560L, true, true, (char) 15676, (char) 47326,
        Double.longBitsToDouble(0x3fee7e53cbc7b477L), Double.longBitsToDouble(0x3fe872e39eae3e4fL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getIntValue||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getLongValue||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|_handleEOF||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|close||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|currentNode||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|currentNumericNode||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getBigIntegerValue||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getBinaryValue|com.fasterxml.jackson.core.Base64Variant|new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getCodec||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getCurrentLocation||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getCurrentName||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getDecimalValue||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getDoubleValue||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getEmbeddedObject||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getFloatValue||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getNumberType||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getIntValue||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
    "M|com.fasterxml.jackson.databind.node.TreeTraversingParser|getLongValue||new:com.fasterxml.jackson.databind.node.TreeTraversingParser:com.fasterxml.jackson.databind.JsonNode",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
