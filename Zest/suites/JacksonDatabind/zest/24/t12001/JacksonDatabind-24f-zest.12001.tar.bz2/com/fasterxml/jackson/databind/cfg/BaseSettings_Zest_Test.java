package com.fasterxml.jackson.databind.cfg;
import org.junit.Test;
import static org.junit.Assert.*;
public class BaseSettings_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=sun.util.calendar.ZoneInfo:sun.util.calendar.ZoneInfo[id=\"Europe/London\",offset=0,dstSavings=3600000,useDaylight=true,transitions=242,lastRule=java.util.SimpleTimeZone[id=Europe/London,offset=0,dstSavings=3600000,useDaylight=true,startYear=0,startMode=2,startMonth=2,startDay=-1,startDayOfWeek=1,startTime=3600000,startTimeMode... |this=com.fasterxml.jackson.databind.cfg.BaseSettings:@?\012",
        Z.run(T, 1, 8, 8, 2, "\udbbf\ude58\ud9a5\uddbe\ud81a\ude06\ud8f7\ude4f\ud8ee\udf3c\udbb9\udfe5\ud950\udc4f\ud889\udf29\udb60\udd4d\ud952\udc74\ud966\udce4\ud93c\udc08\udb3c\udc8b", "\ud2ee", "\uda71\udfa6\udbf4\udd17\uda10\udf29\udaa9\udf69\uda19\udcb1\ud985\udcf1\udb80\ude23\udae9\udc71\uda16\udea1\ud9f1\udc04\uda58\udd7e\udbf1\ude13\ud98a\udce0\ud91e\uded7\ud852\udf14\ud942\udd59\ud966\udd2d\ud985\udc6a\udbba\udf36\ud8cd\udc74\u58c1\ud9df\udc55\ud893\udf70\u81b6\ud8f9\udea7\udbd5\udeb0\udb6e\udd9b\ub0e3\ud905\ude16\udb06\udf5f\ud813\udc3f",
        -1, 8684, -1370846235, 2057471480867328586L, -71805L, true, false, (char) 20852, (char) 6581,
        Double.longBitsToDouble(0x3fcdf66cc95ff604L), Double.longBitsToDouble(0x3fd804f1efb63b98L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=sun.util.calendar.ZoneInfo:sun.util.calendar.ZoneInfo[id=\"Asia/Bangkok\",offset=25200000,dstSavings=0,useDaylight=false,transitions=3,lastRule=null] |this=com.fasterxml.jackson.databind.cfg.BaseSettings:@?\012",
        Z.run(T, 1, 8, 8, 2, "\udbbf\ude58\ud9a5\uddbe\ud81a\ude06\ud8f7\ude4f\ud8ee\udf3c\udbb9\udfe5\ud950\udc4f\ud889\udf29\udb60\udd4d\ud952\udc74\uda90\udee9\ud92c\uddf3\udb3c\udc8b", "\ud2ee\u098e\u700d\u5df7\u1bff\u8231\ub722\uab1f\ub3c5\u5c37\u41fe\u92f3\u37c9\u6111\u07b2\ub2c1\u44d9\u4b17", "\ud8bf\udc67\ud9bd\ude3d\ud8cd\udc2d\u58c1\ud9df\udc55\ud893\udf70\u81b6",
        30, 95973, -1047712438, 7990901252748135758L, -68390L, false, true, (char) 58691, (char) 8377,
        Double.longBitsToDouble(0x3feb4d72524a1c8dL), Double.longBitsToDouble(0x3fd4130983bb4accL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.fasterxml.jackson.databind.cfg.BaseSettings:@? |this=com.fasterxml.jackson.databind.cfg.BaseSettings:@?\012",
        Z.run(T, 1, 13, 8, 2, "\udbbf\ude58\ud9a5\uddbe\ud9be\udc58\ud91b\udd9b\ud8ee\udf3c\udbb9\udfe5\ud950\udc4f\ud889\udf29\udb60\udd4d\ud866\udfde\ud977\udde4\ud93c\udc08", "\u78b6\u359c\u098e\u700d\u5df7\u0f90\u73d8\ub734\u0403", "\udae9\udc71\uda16\udea1\ud9f1\udc04\uda58\udd7e\udbf1\ude13\ud98a\udce0\udba1\udc17\udada\udfe7\udab4\udece\ud860\udc00\ud985\udc6a\udb79\udf16\ud9d2\udfa8\u58c6\udb16\udc71\uda3c\udce5\u81de",
        30, 95973, -1047712438, 7990901252748135758L, -25638L, false, true, (char) 14780, (char) 19085,
        Double.longBitsToDouble(0x3feb4d730a4a1c8dL), Double.longBitsToDouble(0x3fd41306e3bb4accL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=com.fasterxml.jackson.databind.cfg.BaseSettings:@?\012",
        Z.run(T, 1, 11, 8, 2, "\udbbf\ude58\ud8cc\uddb1\ud967\udfcc\ud8f7\ude4f\ud8ee\udf3c\udbb9\udfe5\ud950\udc4f\ud889\udf29\udb60\udd4d\ud952\udc74\ud966\udce4\ud93c\udc08\udb3c\udc8b", "\ud2ee", "\uda71\udfa6\udb87\udcae\uda1b\udf9d\udaa9\udf69\uda19\udcb1\ud985\udcf1\udb80\ude23\udae9\udc71\uda22\udca1\ud9f1\udc04\uda58\udd7e\udbf1\ude13\ud98a\udce0\ud91e\uded7\ud852\udf14\ud803\udf7a\udae1\ude80\ud985\udc6a\udbba\udf36\udaae\udd6d\u58c1\ud9df\udc55\ud893\udf70\udb26\udf98\ud844\udff2\udbf0\udce0\udab7\udd31\ud873\ude49\ud8cc\ude0b\ud8db\udd98\ud050",
        36, 25655, 1089120229, 2073586908073038410L, 64399L, true, false, (char) 20852, (char) 6581,
        Double.longBitsToDouble(0x3fcdf66cc95ff604L), Double.longBitsToDouble(0x3fd804f1efb63b98L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=sun.util.calendar.ZoneInfo:sun.util.calendar.ZoneInfo[id=\"Asia/Bangkok\",offset=25200000,dstSavings=0,useDaylight=false,transitions=3,lastRule=null] |this=com.fasterxml.jackson.databind.cfg.BaseSettings:@?\012",
        Z.run(T, 1, 8, 8, 2, "\ud928\udf4d\ud8f5\ude55\ud81a\ude8e\ud8f7\ude4f\ud8ee\udf3c\udbb9\udfe5\ud985\udd0f\ud889\udf29\udb60\udd4d\ud952\udc74\ud966\udce4\ud986\udd64\udafe\udc56", "\u3ef0\u098e\u95f9\uaa2b\u1bff\u8231\ub722\uab1f\ub3c5\u829c\u3f7a\u92f3\u37c9\u6111\u07b2\ub2c1\u44d9\u3290\u878e\u58b1\u128d", "\u58c1\ud9df\udc55\ud893\udf70\u81b6",
        30, 95973, 1972186442, 2802754206417997134L, -91174L, true, true, (char) 10308, (char) 30348,
        Double.longBitsToDouble(0x3fe34d725592ebb2L), Double.longBitsToDouble(0x3fd671b803bb4accL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|withDateFormat|java.text.DateFormat|new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|getAnnotationIntrospector||new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|getBase64Variant||new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|getClassIntrospector||new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|getDateFormat||new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|getHandlerInstantiator||new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|getLocale||new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|getPropertyNamingStrategy||new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|getTimeZone||new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|getTypeFactory||new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|getTypeResolverBuilder||new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|getVisibilityChecker||new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|with|com.fasterxml.jackson.core.Base64Variant|new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|with|java.util.Locale|new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|with|java.util.TimeZone|new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|withAnnotationIntrospector|com.fasterxml.jackson.databind.AnnotationIntrospector|new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
    "M|com.fasterxml.jackson.databind.cfg.BaseSettings|withDateFormat|java.text.DateFormat|new:com.fasterxml.jackson.databind.cfg.BaseSettings:com.fasterxml.jackson.databind.introspect.ClassIntrospector,com.fasterxml.jackson.databind.AnnotationIntrospector,com.fasterxml.jackson.databind.introspect.VisibilityChecker,com.fasterxml.jackson.databind.PropertyNamingStrategy,com.fasterxml.jackson.databind.type.TypeFactory,com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder,java.text.DateFormat,com.fasterxml.jackson.databind.cfg.HandlerInstantiator,java.util.Locale,java.util.TimeZone,com.fasterxml.jackson.core.Base64Variant",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
