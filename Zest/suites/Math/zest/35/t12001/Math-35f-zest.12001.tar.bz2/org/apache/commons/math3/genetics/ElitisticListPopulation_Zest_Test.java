package org.apache.commons.math3.genetics;
import org.junit.Test;
import static org.junit.Assert.*;
public class ElitisticListPopulation_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\012",
        Z.run(T, 1, 4, 0, 1, "\ud81d\udc24\ud8e1\udefc\uda54\udfd8\ud8f3\udd64\udb09\udea7\ud942\udc6c\ud9ef\udf17", "\u58ef\u75fe\u3477\u1810\ud4bc\ud0a7\u2378\ua448", "\udb1b\ude4a\ud9ca\ude82\ud8f1\ude79\uda14\ude0d\udaac\udf2d\ud800\udf48\udacd\udcc4\ud8f7\udc0f\ud96c\udc06\udb40\udd22\ud9cc\udcf8\uda4d\udea6\udb50\udd22",
        51, 41251, 1322643180, 8701966402115541767L, -90555L, true, true, (char) 15709, (char) 22489,
        Double.longBitsToDouble(0x3fee2d4406b1b048L), Double.longBitsToDouble(0x3fe181acc0257f31L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Double:0.9430256014579834 |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\012",
        Z.run(T, 1, 2, 4, 1, "\ud927\udec5\ud8e1\udefc\uda54\udfd8\ud8f3\udd64", "\u2736\ub5a5\u8f3c\u58c3\u75fe\u3477\u1810\ud4d4", "\ud866\udd15\udb1d\udd22\ud821\udf30\udb1b\ude4a\ud9ca\ude82\ud8f1\ude79\uda14\ude0d\udaac\udf2d\ud800\udf48\uda1c\uddea\ud8f7\udc0f\ud96c\udc06\udb40\udd22\ud9cc\udcf8",
        15, -174, -1407936796, 4474560199458680556L, -90555L, true, true, (char) 15709, (char) 16037,
        Double.longBitsToDouble(0x3fee2d4406b1b048L), Double.longBitsToDouble(0x3fe186f4c0257f31L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.genetics.ElitisticListPopulation:[\ud81d\udc24\ud8e1\udefc\uda54\udfd8\ud8f3\udd64\udb1d\udc17\ud942\udc6c\ud9ef\udf17]\012",
        Z.run(T, 1, 5, 4, 5, "\ud81d\udc24\ud8e1\udefc\uda54\udfd8\ud8f3\udd64\udb1d\udc17\ud942\udc6c\ud9ef\udf17", "\u58ef\u75fe\u3477\u1810\ud4bc\ud0a7\u2378\ua448", "\udb95\uddd1\ud9c1\uded4\udbde\udcd0\ud830\udcce\udaac\udf2d\ud800\udf48\udac3\udcbf",
        31, 6569, 833838492, 8905271982410186228L, -61375L, true, false, (char) 33153, (char) 23272,
        Double.longBitsToDouble(0x3fd9c0cc3ab6b272L), Double.longBitsToDouble(0x3fdf4f5a0c588d62L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 5, "\ud956\udf58\ud8e1\udefc\uda54\udfd8\ud8f3\udd64\udb30\udc8e", "\u2929\ub5b5\ubab9\u75fe\u3477\u794b\u0649\u939e\uc7ab\ucd78\u00a2\uc557\u87cd", "\uda14\ude0d\udb6a\ude8b\ud926\udcb3\udacd\udcb3\ud8f7\udc0f\ud801\udc90\uda8a\udde6\uda17\udcdf\udaa5\udc29\udb50\udd37\uda98\uddfa\udbd0\udc77\ud948\udf91\udbb5\udd27\ud962\uddf3\udaa3\ude26\ud9d7\udc34\ud9d0\udeab\udb6b\uddbd\udbbd\uded7\udbc6\udf26\udb20\udd79\udb98\uddae\uda89\uddf5\udb9c\udff0\ud806\udff1\ud827\udcf9\ud98f\udec4\ud8c9\udc2b\ud8d5\udfe3\ud94f\udf26\ud995\udf6a\udaed\udf07\uda3c\ude0b\uda07\udda8\udabd\udf09",
        55, 62533, 1948992493, 3586861404776496736L, 73706L, false, true, (char) 27921, (char) 47397,
        Double.longBitsToDouble(0x3fd104fecfa5fa30L), Double.longBitsToDouble(0x3fef569ddf8af7b9L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\0121=new org.apache.commons.math3.genetics.ElitisticListPopulation:[\u4628\ud8e1\udefc\uda54\udfd8\ud8f3\udd64\udb09\udea7\ud942\udc6c\ud9ef\udf17]\012",
        Z.run(T, 2, 4, 0, 1, "\u4628\ud8e1\udefc\uda54\udfd8\ud8f3\udd64\udb09\udea7\ud942\udc6c\ud9ef\udf17", "\u8447\u75fe\u3477\u1810\ud4bc\ud0a7\u8c99\u1f5b", "\udb1b\ude4a\ud9ca\ude82\ud8f1\ude79\ud88b\udeea\uda7e\udc4f\ud86d\udd8f\udacd\udcc4\ud8f7\udc0f\ud96c\udc06\udb40\udd22\ud8bb\udf70\udb3e\udd08\udb3d\udd49",
        51, 41251, 1322643180, 8701910327022525191L, -90555L, true, true, (char) 15709, (char) 22489,
        Double.longBitsToDouble(0x3fee2d4406b1b048L), Double.longBitsToDouble(0x3fe181acc0257f31L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.genetics.ElitisticListPopulation:[]\012",
        Z.run(T, 1, 1, 0, 1, "\ud81d\udc24\ud8e1\udefc\uda54\udfd8\ud8f3\udd64\udb09\udea7\ud942\udc6c\ud9ef\udf17", "\u4394\u269c\u3477\u1810\ud4bc\ud0a7\u2378\ua448", "\udb1b\ude4a",
        31, 20373, 1376230712, -3187266743104540746L, 15492L, true, false, (char) 25467, (char) 37219,
        Double.longBitsToDouble(0x3fed7630ef12d81fL), Double.longBitsToDouble(0x3fe709186ccbac14L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NotPositiveException\012",
        Z.run(T, 1, 4, 0, 1, "\ud81d\udc24\ud8e1\udefc\uda54\udfd8", "\u8006\u2736\u5dff", "\udb5d\udee0\ud9ea\udefa\ud941\udcaf\ud83c\udf71\udaed\uddd1\ud85f\uddf1\ud866\udd15\udb1d\udd22\ud821\udf30\udb1b\ude4a\ud9ca\ude82",
        -1, 3712, -742093367, -5416018675534114616L, -84265L, true, false, (char) 4963, (char) 47260,
        Double.longBitsToDouble(0x3fe8949e66e1230dL), Double.longBitsToDouble(0x3fc975829bb0f978L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.apache.commons.math3.genetics.ElitisticListPopulation:[] |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\012",
        Z.run(T, 1, 3, 0, 1, "\ud81d\udc24\ud8e1\udefc\uda54\udfd8\ud8f3\udd64\udb09\udea7\ud942\udc6c\ud9ef\udf17", "\u58ef\u75fe\u3477\u1810\ud4bc\ud0a7\u2378\ua448", "\udb1b\ude4a\ud9ca\ude82\ud8f1\ude79\uda14\ude0d\udaac\udf2d\ubc1f\udaba\udd78\ud8f7\udc0f\ud96c\udc06\udb40\udd22\ud9cc\udcf8\uda4d\udea6\udb50\udd22",
        51, 41251, 1322643180, 8701966402115541767L, -90555L, true, true, (char) 15709, (char) 22489,
        Double.longBitsToDouble(0x3fee2d4406b1b048L), Double.longBitsToDouble(0x3fe181acc0257f31L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NotPositiveException\012",
        Z.run(T, 1, 4, 0, 1, "\ud81d\udc24\ud8e1\udefc\uda54\udfd8\ud8c9\udcaf\000\000\ud9e0\ude90", "\u58ef\u75fe\u3477\u1810\ud4bc\u6b88\u2378\u3c2d", "\uda50\ude48\ud9ca\ude82\ud8f1\ude79\ud9a9\udd38\udaac\ude64\ud800\udf48\udacd\udcc4\ud9dd\udce2\ud93b\udd7d\u8e35\ud9cc\udc48\uda4d\udea6\udb2f\udf12",
        -5, -1000, 0, 8646911286522354439L, 96608L, true, true, (char) 15709, (char) 22489,
        Double.longBitsToDouble(0x3e48000000000000L), Double.longBitsToDouble(0x3fe181acc0257f31L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.genetics.ElitisticListPopulation:[\ud891\ude56\ud8e1\udefc\uda54\udfd8\ud8f3\udd64\udb09\udea7\ud942\udc6c\ud9ef\udf17\ud9ab\udf12\uda5f\udc32\uda32\udd7b\ud9ca\udf20\ud9c6\udc49\ud90b\udcf3\ud919\ude5e\udaf1\uddad\ud80d\udc87\ud866\udd1f\udb33\udc8d\ud821\udfaf\udb1b\ude4a\ud9ca\ude82\ud945\udfe3\uda83\udc13\udaac\ude84\ud800\udf48\udacd\udcc4\ue410\ud96c\udc06\ud936\udd7d\ud809\ude35\ud8a1\udf76\udb50\udd22\udbc0\uddee\udbd0\udc77\ud864\ude9f\udba3\udf73\ud962\uddf3\ud922\udc65\ud833\udf44\uda38\udf4f\udbb9\udd49\udad6\udfa6\ud9a6\udfb1\uda26\ude0a\udb98\uddae\ud971\udf7e\ud9e5\udc48\ud96c\udf64\udb72\ude2c]\0121=new org.apache.commons.math3.genetics.ElitisticListPopulation:[\ud891\ude56\ud8e1\udefc\uda54\udfd8\ud8f3\udd64\udb09\udea7\ud942\udc6c\ud9ef\udf17\ud9ab\udf12\uda5f\udc32\uda32\udd7b\ud9ca\udf20\ud9c6\udc49\ud90b\udcf3\ud919\ude5e\udaf1\uddad\ud80d\udc87\ud866\udd1f\udb33\udc8d\ud821\udfaf\udb1b\ude4a\ud9ca\ude82\ud945\udfe3\uda83\udc13\udaac\ude84\ud800\udf48\udacd\udcc4\ue410\ud96c\udc06\ud936\udd7d\ud809\ude35\ud8a1\udf76\udb50\udd22\udbc0\uddee\udbd0\udc77\ud864\ude9f\udba3\udf73\ud962\uddf3\ud922\udc65\ud833\udf44\uda38\udf4f\udbb9\udd49\udad6\udfa6\ud9a6\udfb1\uda26\ude0a\udb98\uddae\ud971\udf7e\ud9e5\udc48\ud96c\udf64\udb72\ude2c]\012",
        Z.run(T, 2, 5, 0, 1, "\ud891\ude56\ud8e1\udefc\uda54\udfd8\ud8f3\udd64\udb09\udea7\ud942\udc6c\ud9ef\udf17\ud9ab\udf12\uda5f\udc32\uda32\udd7b\ud9ca\udf20\ud9c6\udc49\ud90b\udcf3\ud919\ude5e\udaf1\uddad\ud80d\udc87\ud866\udd1f\udb33\udc8d\ud821\udfaf\udb1b\ude4a\ud9ca\ude82\ud945\udfe3\uda83\udc13\udaac\ude84\ud800\udf48\udacd\udcc4\ue410\ud96c\udc06\ud936\udd7d\ud809\ude35\ud8a1\udf76\udb50\udd22\udbc0\uddee\udbd0\udc77\ud864\ude9f\udba3\udf73\ud962\uddf3\ud922\udc65\ud833\udf44\uda38\udf4f\udbb9\udd49\udad6\udfa6\ud9a6\udfb1\uda26\ude0a\udb98\uddae\ud971\udf7e\ud9e5\udc48\ud96c\udf64\udb72\ude2c", "\u7490\u9c73\u8871\u6b12\ua7a7\ud05f\u5998\u4ec5\u312d\u6100\u38cd\u7c08\u92bb\u02dd\u45ea\u2379\u21cd\u0957\ua63b\ubefb\u1a0e\u74f5\uce69", "\uda9f\udcd6\ud963\udc94\uda9e\udfa4\udb17\ude66\ud853\udf58\udb17\udd00",
        18, 30001, 1245479836, -8813189571918507713L, -75040L, true, false, (char) 59106, (char) 24209,
        Double.longBitsToDouble(0x3fe68725b8dd7424L), Double.longBitsToDouble(0x3fa9b20ab6a5cd40L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.genetics.ElitisticListPopulation:[]\0121=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\012",
        Z.run(T, 2, 1, 4, 3, "\ud927\udec5\ud8e1\udefc\uda54\udfd8\ud8f3\udd64", "\u2736\ub5a5\u8f3c\u58c3\u7eb3\u1e4a\ub08b\ud4d4", "\ud866\udd15\udb1d\udd22\ud821\udf30\udb34\udc95\ud9ca\ude82\ud8f1\ude79\uda14\ude0d\udaac\udf2d\ud800\udf48\uda1c\uddea\ud8f7\udc0f\ud96c\udc06\udb40\udd22\ud9cc\udcf8",
        15, -174, -1407936796, 4474560199458680556L, -90555L, true, true, (char) 15709, (char) 11591,
        Double.longBitsToDouble(0x3fe3b2115ce855aaL), Double.longBitsToDouble(0x3fcc51c4c095c17cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\0121=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\012",
        Z.run(T, 2, 4, 4, 1, "\ud927\udec5\ud8e1\udefc\uda54\udfd8\ud8f3\udd64", "\u2736\ub004\u1f64\u58c3\u75fe\u3477\u1810\ud4d4", "\ud866\udd15\udb1d\udd22\ud821\udf30\ud8a1\ude4c\ud817\udc47\ud8f1\ude79\uda14\ude0d\udaac\udf2d\ud9fa\udfc4\uda1c\uddea\ud8f7\udc0f\ud96c\udc06\udb40\udd22\ud9cc\udcf8",
        58, -182, -1407936796, -2234300212928216816L, -90555L, true, true, (char) 15709, (char) 54585,
        Double.longBitsToDouble(0x3fee2d4046b1b048L), Double.longBitsToDouble(0x3fe186f4c0257f31L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NumberIsTooLargeException\012",
        Z.run(T, 1, 5, 4, 5, "\ud81d\udc24\ud8e1\udefc\uda54\udfd8\ud8f3\udd64\udb43\udeab\ud942\udcc5\ud9ef\udf17", "\u58ef\u75fe\u3477\u1810\ud4bc\ud0a7\u2378\ua448", "\uda70\ude9d\udbc8\uded7\ud888\udffc\ud877\udd33\udaac\udf43\ud800\udf48\udae1\udf5a",
        0, 6569, 830576287, -3416576598075490828L, -61375L, true, false, (char) 18561, (char) 612,
        Double.longBitsToDouble(0x3fd9c0c71ab6b272L), Double.longBitsToDouble(0x3fdf4f5a0c588d62L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Double:0.26592932608756126 |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 5, "\ud956\udf58\ud8e1\udefc\uda54\udfd8\udb37\udd66\udb94\udf74", "\u2929\ub5b5\ubab9\u75fe\u3477\u794b\u0649\u939e\uc7ab\ucd78\u00a2\uc557\u33f4", "\uda14\ude0d\udb6a\ude8b\ud926\udcb3\udacd\udcb3\ud8f7\udc0f\ud801\udc90\uda8a\udde6\uda17\udcdf\udaa5\udc29\udb50\udd37\uda98\uddfa\udbd0\udc77\ud948\udf91\udbb5\udd27\ud962\uddf3\udaa3\ude26\ud9d7\udc34\ud9d0\udeab\udb6b\uddbd\udbbd\uded7\udbc6\udf26\udb20\udd79\udb98\uddae\uda89\uddf5\udb9c\udff0\ud806\udff1\ud827\udcf9\ud98f\udec4\ud8c9\udc2b\uaf13\ud819\udd6e\ud8b1\udf78\udaed\udf07\uda3c\ude0b\uda07\udda8\udabd\udf09",
        55, 58397, 1948992493, 3586861404776496736L, 73706L, false, true, (char) 14353, (char) 39185,
        Double.longBitsToDouble(0x3fd104fc6fa5fa30L), Double.longBitsToDouble(0x3fef569ddf8af7b9L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.math3.genetics.ElitisticListPopulation:[] |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\0121=org.apache.commons.math3.genetics.ElitisticListPopulation:[] |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\012",
        Z.run(T, 2, 3, 3, 5, "\ud956\udf58\ud8e1\udefc\uda54\udfd8\ud8f3\udd64\udb30\udc8e\udb28\udf65\ud818\udc65\ud89b\udda6\udabc\udc8e\uda7a\ude85\ud9ca\udf20\ud9ea\udf4f\ud8be\ude5d\u3046\u2e81\ud80e\uddd1\ud880\udefb\u0851\udbf9\ude1e\ud856\uddff\ud952\udc46\udb6b\ude09\ud9fe\udef2\udb6a\ude8b", "\ubcc6\u0350\u791e\u2011\u7264\u98b2\u7c56\ud6b6\ua45b\u952b\u421d\u56ec\ua022\ub98c\ub67f", "\udb20\udd79\udb98\uddae",
        3, 39407, -896222604, -2736387840452011656L, 42829L, true, true, (char) 18131, (char) 64339,
        Double.longBitsToDouble(0x3fea16cc4f50eb6cL), Double.longBitsToDouble(0x3fa7b5d730aec8f0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 2, "\ud9a5\ude28\ud8e1\udf56\uda54\udfd8\ud8f3\udd64\ud868\udfc3\ud891\udc72\ud9ef\udf17", "\u356a\u75fe\u4264\u801c\u18cf\u44f8\uce0d\u5bdb\u7b0e\ucd93\u90d8\ub535", "\udab6\udedf\uda97\ude50\ud839\ude0c\ud97e\udc23\ud9eb\udda0\udb40\udd22\ud9cc\udcf8\uda4d\udea6\udb50\udd22\uda8e\uddf5",
        6, 47180, 2026084438, 8465389640466225808L, 94597L, true, false, (char) 34867, (char) 6577,
        Double.longBitsToDouble(0x3febf48e71266f7fL), Double.longBitsToDouble(0x3fef268501b09280L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "C|org.apache.commons.math3.genetics.ElitisticListPopulation|<init>|java.util.List,int,double",
    "C|org.apache.commons.math3.genetics.ElitisticListPopulation|<init>|int,double",
    "M|org.apache.commons.math3.genetics.ElitisticListPopulation|getElitismRate||new:org.apache.commons.math3.genetics.ElitisticListPopulation:int,double",
    "M|org.apache.commons.math3.genetics.ElitisticListPopulation|nextGeneration||new:org.apache.commons.math3.genetics.ElitisticListPopulation:int,double",
    "M|org.apache.commons.math3.genetics.ElitisticListPopulation|setElitismRate|double|new:org.apache.commons.math3.genetics.ElitisticListPopulation:int,double",
    "C|org.apache.commons.math3.genetics.ElitisticListPopulation|<init>|java.util.List,int,double",
    "C|org.apache.commons.math3.genetics.ElitisticListPopulation|<init>|int,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
