package org.apache.commons.math.linear;
import org.junit.Test;
import static org.junit.Assert.*;
public class OpenMapRealVector_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 10, 5, "\uda9d\udc71\udaa7\udf15\uda5c\udc68\uda60\udca9\ud8af\ude23\uda4c\uddce\uda1e\ude95", "\u9e2c\u4351\u5386\ub7ea\u992b", "\udabf\uddcd\udb8b\udf0c\udb61\udcc8\ud938\udd1c\ud8fe\udf48",
        10, 29082, -1053549999, 6742010727225146820L, 68232L, true, false, (char) 42653, (char) 58607,
        Double.longBitsToDouble(0x3fdeec824e7d0b68L), Double.longBitsToDouble(0x3fe7f78501987b59L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 10, 5, "\uda9d\udc71\udaa7\udf15\uda5c\udc68\uda60\udca9\ud8af\ude23\uda4c\uddce\uda1e\ude95", "\u9e2c\u4351\u5386\ub7ea\u992b", "\udabf\uddcd\udb8b\udf0c\udb61\udcc8\ud938\udd1c\ud8fe\udf48",
        10, 29082, -1053549999, 6742010727225146820L, 68232L, true, false, (char) 42653, (char) 58607,
        Double.longBitsToDouble(0x3fdeec82447d0b68L), Double.longBitsToDouble(0x3fe7f791d1987b59L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 0, 6, "\000\000\uda5b\udfdd\uda31\udfa9\ud8af\ude23\u62b5\ud936\ude1b", "", "\ud822\ude86\udae8\udf75\uda7e\udf74\udb3c\udfba\ud8cd\uddf9\udabf\uddcd",
        -5, -1000, 891092992, 51578992402104320L, -93263L, true, true, (char) 6996, (char) 58206,
        Double.longBitsToDouble(0x3fe6c747e4003885L), Double.longBitsToDouble(0x3fea7f5a70706480L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 1, 6, 10, 5, "\uda9d\udc71\udaa7\udf15\uda5c\udc68\uda60\udca9\ud88f\udc23\uda4c\uddce\uda1e\ude95", "\u9e2c\u1c0f\u4345\ub7ea\u992b", "\udabf\uddcd\udb8b\udf0c\udb61\udcc8\ud938\udd1c\ud8fe\udf48",
        10, 29082, -1053549999, 5647453552650069585L, -6095L, true, false, (char) 42648, (char) 58530,
        Double.longBitsToDouble(0x3fdeec824e7d0b68L), Double.longBitsToDouble(0x3fe7f78501987b59L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 10, 5, "\uda9d\udc71\udaa7\udf15\uda5c\udc68\uda60\udca9\ud8af\ude23\uda4c\uddce\uda1e\ude95", "\u9e2c", "\uda67\uddb3",
        1, 95110, 1024483936, -2590150413764438093L, 43877L, false, false, (char) 27305, (char) 3838,
        Double.longBitsToDouble(0x3fe2884a4709c134L), Double.longBitsToDouble(0x3fdc45d90e7e4840L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 1, 0, 10, 6, "", "\ua648\u3a98\u99bf\000\000\u8cd3\ucd95", "\000\000\u0500\u1884\000\udabf\uddcd",
        49, 24821, 891145723, 5455898545956331250L, -93263L, true, true, (char) 0, (char) 48990,
        Double.longBitsToDouble(0x3f4d1f8000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[27958.5, 28192.5, 27963.5, 28530.5, 27926.0, 28188.0, 27928.0, 28220.5]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 1, 7, 6, 5, "\uda9d\udc71\udaa7\udf15\uda5c\udc68\uda60\udca9\ud8af\ude23\uda4c\uddce\uda1e\ude95", "\u9e27\u4351\ud7f7\u6693\u45fb", "\udabf\uddcd\udb8b\udf0c\udb61\udcc8\ud938\udd1c\ud8fe\udf48",
        1, 93676, -1154213295, 3067074328948735313L, 68232L, true, false, (char) 11034, (char) 1995,
        Double.longBitsToDouble(0x3fc579ab7e90f758L), Double.longBitsToDouble(0x3fe7f7850198bc59L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 2, 7, 18, "\udaa0\udcbb\udaa7\udf15\udaa0\udea9\uda64\ude6f\ud8c6\udd23\uda4c\uddce\udb7f\uddb2", "\u702c\u43b1\u6ac2\ua9b8\ud272", "\udb96\uddb8",
        31, 48133, 1265687650, 8184163507265924679L, -75971L, true, true, (char) 6975, (char) 50270,
        Double.longBitsToDouble(0x3fe2b65c14113885L), Double.longBitsToDouble(0x3fea7f5a70706494L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 1, 15, 10, 18, "\uda9d\udc71\ud98d\udee8\udb11\udf5b\uda60\udca9\ud8af\ude23\ud912\udf31\uda66\uded6", "\u521a\u6bf6", "\u8a48\u8241\ud8cd\ude11\udabf\uddcd\udb8b\udf0c\ud988\ude31\ud8c1\udc2d\udbd6\udd94\ud846\udd70\ud80f\ude3e\uda5f\ude9d",
        -4, 23508, -386089153, 4072783311183223057L, -67120L, false, true, (char) 61881, (char) 43757,
        Double.longBitsToDouble(0x3fe7876af0c13757L), Double.longBitsToDouble(0x3fe04d322303eb1aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 1, 10, 9, 5, "\uda9d\udc71\udaa7\udf15\uda5c\udc68\uda60\udca9\ud8af\ude23\uda4c\uddce\uda1e\ude95", "\u9e2c\u4351\u5386\ub7ea\u992b", "\udabf\uddcd\udb8b\udf0c\udb61\udcc8\ud938\udd1c\ud8fe\udf48",
        10, 29082, -1053549999, 6742010727225146820L, 68232L, true, false, (char) 42653, (char) 58607,
        Double.longBitsToDouble(0x3fdeec824e7d0b68L), Double.longBitsToDouble(0x3fe7f78501987b59L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 2, 10, 5, "\uda9d\udc71", "\u3a98\u00bf\ub5e5\u1ab8\u487e\ucd95\u9e2c\001\u2269\ub7ea\u992b\ub559\u825f\u8d51\u838a\u833c\u2cef\u208f", "\uda5f\ude9d\uda25\udc8c\uc7e5\udb8d\udf4d\udac6\udd54\ud411\000\000\u0500",
        19, 68686, -772984424, -99746549105615773L, -8247L, true, false, (char) 42516, (char) 51240,
        Double.longBitsToDouble(0x3fc7853cc512ebb0L), Double.longBitsToDouble(0x3fe4bf0125f70173L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[D:[[]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 1, 14, 3, 12, "\uda9d\udc71\udaa7\udf15\uda5c\udc68\uda60\udca9\udac8\udc46\ud973\udf2a\uda1e\ude95", "\u9dd7\u4351\u5386\ub7ea\u992b", "\udabf\uddcd\udb8b\udf0c\udb61\udcc8\ud938\udd1c\ud8fe\udf48",
        10, 1506, -1044072897, 6742010727225146820L, 68232L, true, false, (char) 42653, (char) 58607,
        Double.longBitsToDouble(0x3fdeec824e7d0b68L), Double.longBitsToDouble(0x3fe7f78501987b59L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 1, 6, 6, 5, "\uda9d\udc71\udaa7\udf15\uda5c\udc68\uda60\udca9\ud8af\ude23\uda4c\uddce\uda1e\ude95", "\u9e2c\u4351\u5386\ub7ea\u992b", "\udabf\uddcd\udb8b\udf0c\udb61\udcc8\ud938\udd1c\ud8fe\udf48",
        10, 29082, -1043259567, 6742010727225146820L, 68232L, true, false, (char) 42653, (char) 58607,
        Double.longBitsToDouble(0x3fdeec824e7d0b68L), Double.longBitsToDouble(0x3feff7850603d811L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 6, 0, "\000", "\u5925\u592c\u409b\u1ab8\u487e\ucd95\u9e2c\u4351\u241e\000\u9874\u2259\u5a73\000", "\ud938\udd1c\ud8fe\udf48",
        10, 29138, 0, 0L, 68232L, true, false, (char) 42653, (char) 58607,
        Double.longBitsToDouble(0x3fdeec824e7d0b68L), Double.longBitsToDouble(0x3fe7f78501987b59L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 0, 8, 8, "\ud9aa\uddee\udaa7\udfb2\uda5c\udc68", "\u4d58\u8df5\u6c39\u954c\u9e1b\u10cb\u5386\u2882\u77cc\ua4e3", "\udb8b\udf0c\ud89b\udc83\ud8ae\udf40\udb13\udf33\udb09\udfec",
        -5, 99193, 1569746856, 2603289233745297215L, 73414L, true, true, (char) 58607, (char) 36159,
        Double.longBitsToDouble(0x3fed9e94b33df0a0L), Double.longBitsToDouble(0x3feca3da3fdb24a8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 12, 5, "\uda9d\udc71\udaa7\udf15\udba2\uddff\uda64\udf48\ud8af\ude23\ud907\udde4\uda1e\ude95", "\u9e2c\u4351\u5386\ub7ea\u992b", "\uda4c\udd53\uda3d\udfab\uda29\udc85\ud938\udccb\ud8fe\udf48",
        10, 29082, -1053549999, 6742010727225146820L, 68232L, true, false, (char) 42653, (char) 8939,
        Double.longBitsToDouble(0x3fdeec824e7d0b68L), Double.longBitsToDouble(0x3fe7f785039a7b59L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 1, 13, 16, 13, "\uda8b\udc68\udaa7\udf15\uda5c\udc68\uda60\udca9\ud8af\ude23\uda4c\uddce\uda1e\ude95", "\u9e2c\u4351\u5386\ub7ea\u992b", "\udabf\uddcd\udb8b\udf0c\udb61\udcc8\ud938\udd1c\ud8fe\udf48",
        10, 29082, -1053549999, 6742010727225146820L, 68232L, true, false, (char) 42653, (char) 58607,
        Double.longBitsToDouble(0x3fdeec824e7d0b68L), Double.longBitsToDouble(0x3fe8c7850198d071L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[-24.0]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 1, 7, 0, 10, "\000", "\u5997", "\ud936\ude1b\000\000\udaea\udc94\uda2c\udf4e\udb9f\ude81\udae8\udf75\ud867\ude9a\udb3d\udc1c\ud8cd\uddf9\uda91\udecd\000",
        -5, 69992, 12009170, 155713536L, -51041L, false, false, (char) 3205, (char) 42653,
        Double.longBitsToDouble(0x3fbc192001540c30L), Double.longBitsToDouble(0x3fee5f3ccd5c9d62L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[-24.0, -24.0, 27925.5, 28630.5, 27872.0, 28364.0, 27858.0, 28576.5]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 1, 7, 2, 13, "\000\000\uda5b\udfdd\ud9f0\uddc8\ud9d4\udf71\u628d\ud936\ude1b", "", "\ud822\ude86\udae8\udf75\uda7e\udf74\uda12\udd24\ud837\uddd1\ud854\ude41",
        44, 13063, 891092992, 51578992402104320L, -93263L, true, true, (char) 6996, (char) 58206,
        Double.longBitsToDouble(0x3fe6c747e4003885L), Double.longBitsToDouble(0x3fed375a704c0500L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 1, 6, 10, 5, "\uda9d\udc71\udaa7\udf15\uda5c\udc68\uda60\udca9\ud88f\udc23\uda4c\uddce\uda1e\ude95", "\u9e2c\u1c0f\u4345\ub7ea\u992b", "\udabf\uddcd\udb8b\udf0c\udb61\udcc8\ud938\udd1c\ud8fe\udf48",
        10, 29082, -1053549999, 5647453552650069585L, -6095L, true, false, (char) 42648, (char) 128,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe7f78001987b59L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 6, 10, 5, "\udb8e\udcbc\ud8e6\udfdc\uda69\udeba\uda69\udd5f\ud88f\udc39\uda4c\udd30\ud847\udf88", "\u5fbe\uc901\u04c7\uaeb4\u86ff\u0c0b\u94ab\u6567\u838a\u2eb9\u2cef\u208f\u0adb\ud648\u9fe3\u9df9\u31d7\u36b9\u0b9f\ub39c\uba6c", "\ud829\ude56",
        56, 27664, 538250100, 5536939723412251311L, 21937L, false, false, (char) 53411, (char) 54277,
        Double.longBitsToDouble(0x3fead6d13a7efe1eL), Double.longBitsToDouble(0x3fef27b8ea875bb5L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=java.lang.Boolean:false |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 13, 13, 16, "\uda9d\udc71\udb5d\udd14\uda5c\udc68\uda60\udca9\ud88f\udc23\udaf3\udccd\uda1e\ude95\ud9b4\udf10\ud9bf\udcb0\udaf8\udf11\ud837\udd53\ud89d\udedb", "\ub559\u82bf\u8d51\u6d5e", "\ud8fe\udf48",
        -3, 4620, -1053549999, 5647453552650069585L, -6095L, true, false, (char) 42648, (char) 58530,
        Double.longBitsToDouble(0x3fe68d2fbf3e8593L), Double.longBitsToDouble(0x3fe7f78503da6d12L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 1, 13, 10, 5, "\uda9d\udc71\udaa7\udf15\uda5c\udc68\uda60\udca9\ud8af\ude23\uda4c\uddce\uda1e\ude95", "\u9e2c", "\uda67\uddb3",
        1, 95110, 1024483936, -2590150413764438093L, 43877L, false, false, (char) 27305, (char) 3838,
        Double.longBitsToDouble(0x3fe2884a4709c134L), Double.longBitsToDouble(0x3fdc45d90f6420acL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[27680.0, 28552.5, 16181.0, 27650.5, 28148.0]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 13, 7, 18, "\ud870\udf41\u7e9a\ud835\udc18", "\u2efe\u537b\u3ddf\u9414\u92ad\u692d\u6555", "\uda23\ude92\ud8bb\udcc6\udabf\udd75\uda07\udeeb\ud909\udf4f\udb84\ude74\ud865\udf6d\ud9d5\udc24\u6735\uda5f\ude9d\ud91b\ude47\udb97\udc24\udbfd\udd82\uda51\udea2\uda7f\udc6b\ud828\udd0a\ud94e\udf27\uda13\ude95\ud99a\udca8\ud933\udeb7",
        19, 47233, 758371806, -6465922863190324743L, -56827L, false, true, (char) 2774, (char) 30278,
        Double.longBitsToDouble(0x3fd9d25267dde4bcL), Double.longBitsToDouble(0x3fe43b65c63e55e1L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 1, 18, 10, 6, "", "\u7070\u3a98\u99bf\000\000\u041b\ucd95", "\000\000\u0500\u1884\000\udabf\uddcd",
        0, 5384, 891145723, 5455898545956331250L, -93263L, true, true, (char) 46880, (char) 49021,
        Double.longBitsToDouble(0x3f4d1f80024c0000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 0, 10, 6, "", "\ua648\u3a98\u99bf\000\000\u8cd3\ucd95", "\000\000\u0500\u1884\000\udabf\uddcd",
        49, 24821, 891145723, 5455898545956331250L, -93263L, true, true, (char) 43008, (char) 48990,
        Double.longBitsToDouble(0x3f4d1f8000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[D:[[]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 4, 7, "\uda9d\udc71\udaa7\udf15\uda5c\udc68\uda60\udca9\u99bf\uaaf7\udb34\udf9a\ud98f\udfe9\udb96\udcbc\udaf8\udf11\ud818\udd5dl\ud899\udf8c\u0500", "\u9e2b\u838a\u9366", "\ud846\udd70\ud891\udd3d\uda5f\ude9d\u6f09",
        16, 32847, 0, 0L, -22831L, false, true, (char) 3229, (char) 58360,
        Double.longBitsToDouble(0x3fe4a076f30e0215L), Double.longBitsToDouble(0x3fea4a7a95e20a39L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 6, "", "\u8481\u3a98\u99bf\u2301\000\ub4b4\u4169", "\000\000\u0500\u1884\000\udabf\uddcd",
        49, 24821, 891145723, 5455898545956331250L, 75881L, true, true, (char) 0, (char) 48990,
        Double.longBitsToDouble(0x3f4d1f8000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 10, 10, 4, "", "\u3e1f\u3a98\ubff5\u4b7b\u00e2\u8cd3\ucd95", "\000\ud9be\udedf\u0500\u1884\uda4b\uddf2\udabf\udd0b",
        59, 45052, -1432633583, 5467690934651002610L, -25706L, false, false, (char) 0, (char) 48734,
        Double.longBitsToDouble(0x3fe5ff39bd28d48eL), Double.longBitsToDouble(0x3fe8f4d15e3c0000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[27958.5, 28192.5]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 1, 7, 11, 6, "\uda9d\udc71", "\u3a98\u24a6N\u385b\u8cd3\ucd95\u9e2c\u9673\000\000\u0500\u797a\ua5a1\uc2ec\u3a2c\ub84f\u08e9\u3fab", "\udb25\udd60",
        -1, 99296, -386089153, 0L, 31072L, true, false, (char) 58162, (char) 63053,
        Double.longBitsToDouble(0x3feb3082e4512847L), Double.longBitsToDouble(0x3fd5a7d8728e4bbcL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[27958.5, 28192.5, 27963.5, 28530.5, 27926.0, 28188.0, 27928.0, 28220.5]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 7, 6, 5, "\uda9d\udc71\udaa7\udf15\uda5c\udc68\uda60\udca9\ud8af\ude23\ud9e1\uddd1\uda1e\ude95", "\u9e18\u4351\ud7f7\u6693\u45fb", "\udabf\uddcd\uda10\udcaf\udb62\udd9e\ud938\udd1c\ud8fe\udf48",
        1, 93676, -1154213295, 3067074328948735313L, 68232L, true, false, (char) 11034, (char) 1995,
        Double.longBitsToDouble(0x3fc579ab7e90f758L), Double.longBitsToDouble(0x3fe7f7850198bc59L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[-24.0, -24.0, -24.0, -24.0, 27911.0, 28365.0, 27918.0, 28276.5]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 1, 7, 6, 5, "\000\000\000\000\uda3e\uddca\uda4c\udd19\uda1e\ude95", "x\000\000\u6661\u45fb", "\uda83\udde1\udb8b\udf0c\udb61\udcc8\ucdfb\ud8fe\udf48",
        1, 93676, -1154213376, 3067074328948735313L, 68232L, true, false, (char) 0, (char) 1995,
        Double.longBitsToDouble(0x3fc579ab60000000L), Double.longBitsToDouble(0x3fe000000198bc59L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 9, 5, "\uda9d\udc71\udaa7\udf15\uda5c\udc68\ud8f2\udcd2\udab4\udf9e\uda5c\udf9c\ud9f7\udc95", "\u9e2c\u4351\u6d0b\ub7c4\u09c3", "\ud9db\udf12\udb8b\udf0c\udb1d\ude45\ud938\udd1c\uda5e\udc99\ud846\udd70\ud813\udd3e\ud83c\udd2a\ud9a3\udca1",
        58, 32847, 948268760, -1491165292091360433L, 49770L, false, true, (char) 24479, (char) 44273,
        Double.longBitsToDouble(0x3fc16ddac57e796cL), Double.longBitsToDouble(0x3f930f8f2be09540L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 6, 6, 5, "\uda9d\udc71\udaa7\udf15\uda54\udc68", "\u409b\u1ab8\u6f32\u1cae\u9d45\u01be\u5386\ub7ea\u992b\u1a64", "\udba6\udc07\ud95c\udc96\udb59\ude64\ud873\udc68\ud801\udc3b\ud91e\udd0d\udb0d\udee2\ud98c\ude12\ud94f\udc6b\ud966\udd23",
        2, 81561, -1960339763, -6773301981870011665L, 94562L, true, false, (char) 46433, (char) 55517,
        Double.longBitsToDouble(0x3fe0f894f4fba638L), Double.longBitsToDouble(0x3fea604f5d66aa80L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 12, 1, "\udb9b\udd3e\ud86d\ude77\uda57\udd9a\uda60\udca9\ud8af\ude23\ud88c\uddce\uda1e\ude95", "\u1e6f\ud56b\u5fc5\u53c1", "\ud8cd\uddf9\uda2b\udec2\ud915\ude93\ud80e\udca8\u8f70\udad2\udda7\ud846\udd56\ud897\udce0\udb72\udfa6\ud985\ude88\ud8b3\udf85\udb39\ude61\udaed\udcc0\udb44\udf96\uda22\udd3f\ud90b\udd25\udbd5\udeb8",
        32, 87201, -223310297, -7507232666727444276L, 65307L, true, false, (char) 40443, (char) 63214,
        Double.longBitsToDouble(0x3fded8f986e3589aL), Double.longBitsToDouble(0x3fd605f0c00c9490L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=!org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 2, 15, 16, 13, "\uda8b\udc68\udaa7\udf15\uda5c\udc68\uda60\udca9\ud8af\ude23\uda4c\uddce\uda1e\ude95", "\u9e2c\u4351\u5386\ub7ea\u992b", "\ud8ab\udf83\udbc2\udf9c\udb28\udf3b\ud938\udc2b\ud8fe\udf48",
        10, 29082, -1053549999, 6742010727225146820L, 68232L, true, false, (char) 42653, (char) 58607,
        Double.longBitsToDouble(0x3fdeec824e7d0b68L), Double.longBitsToDouble(0x3fe8c78501c4da71L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[27.0, 27710.5, 28624.0, 28105.0, 28151.0, 27650.0, 28537.5, 27776.5]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=!org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 2, 7, 0, 10, "f\ud8ad\udfd0\udbc2\udc1e\ud834\udf23\ud931\udf6f\ud805\udf4d\udbf2\udc40\udb31\udcc1\000\ud834\ude8a\ud86e\udcb6\ud819\udf27\uda17\udd74\udb8a\udffd\udb24\uddc3\uda40\udc95", "\000\u5bc2\u0c71", "\uda5f\ude9d\uda25\udc8c\ud850\udeb5\ud9f7\udca2\u2f89\udb44\udf56\uda66\udd11\udbd3\udd69\udb91\udeb9\ud8cd\uddfb\ud97b\udd80\udbe4\udc07\ud829\udf0f\ud9b0\uddad\uda5b\udc6c\ud89d\udd72",
        17, 91193, 283188414, -4197372007347386498L, -35612L, false, false, (char) 19463, (char) 9693,
        Double.longBitsToDouble(0x3fe1a1f715144d47L), Double.longBitsToDouble(0x3fe5e6c6cb921761L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 9, 5, "\udb8e\udcbc\ud8e6\udfdc\uda69\udeba\uda69\udd5f\ud88f\udc39\uda4c\udd30\ud847\udf88", "\u5fbe\uc901\u04c7\uaeb4\u86ff\u0c0b\u8bca\u8ee5\u4dd3\u2eb9\u2cef\u87ab\u905b\ud6a0\u9fe3\u9df9\u31d7\u36b9\u0b9f\ub39c\uba6c", "\ud829\ude56",
        39, 64604, -364039179, -4136634526233209610L, 68273L, false, false, (char) 50901, (char) 7417,
        Double.longBitsToDouble(0x3fead6d13a7efe1eL), Double.longBitsToDouble(0x3fef27b8ea875bb5L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 6, 6, 6, "\udb8b\udc90\ud8e6\udfdc", "\u9d5e\u2289\ubf1c", "\uda48\udd59\uda8f\udcd7",
        -2, 82049, -2000745054, 7555526589487711348L, 31549L, false, false, (char) 2680, (char) 29708,
        Double.longBitsToDouble(0x3fbb6c6dda2a5c60L), Double.longBitsToDouble(0x3fe2884a5916c134L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=java.lang.Boolean:false |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 13, 13, 16, "\uda9d\udc71\udb5d\udd14\uda5c\udc68\ud90b\udce0\ud88f\udc23\udaf3\udccd\u6a94\ud9b4\udf10\ud9bf\udcb0\udaf8\udf11\ud837\udd53\ud89d\udedb", "\ub559\u82bf\u8d51\u6d5e", "\ud8fe\udf48",
        -3, 74724, 1412709970, 5647329247706588753L, 61634L, true, false, (char) 40167, (char) 35883,
        Double.longBitsToDouble(0x3fe00c55a6d68da1L), Double.longBitsToDouble(0x3fe35dad0038d6f9L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 18, 18, 6, "", "\ua648\u3a98\u99bf\u5700\000\u8cd3\ucd95", "\udbb9\udeec\000\u0500\u1884\000\uda82\udf83",
        54, 79733, 891145723, 5455898544113262322L, -93263L, true, true, (char) 43008, (char) 48990,
        Double.longBitsToDouble(0x3f4d1f8000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[28086.0, 28353.0, 27766.0, 28309.0, 27682.5, 28540.5, 27645.5, 28561.5]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[28086.0, 28353.0, 27766.0, 28309.0, 27682.5, 28540.5, 27645.5, 28561.5]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 7, 7, 7, "\udb9c\uddb2\ud91c\udd5a\ud875\udf29\ud82b\udf53\udbd3\udd43\uaaf7\ud9a5\udd6f\udb42\uddbb\udbbc\udf5d\u8f09\ud81b\udf7e\ud888\ude12\udbe0\udd96\udabf\udfa8", "\u217e\u6826\u9c93\ucecc\u9bde\u1b25\u5064\u5516\u1db7\u197b\u996c\u20dd\ubb00\000\u8cb0\u3c7f\u0df3\u3996\u4bdc\u110c\ub911\u7db5\u7e42\u0f5c\ub2e2\u2950\u8d46\u360a\u659c", "\ud913\udccf\uda35\udcfc\ud94f\udd15\udb18\udf61\udbcc\udc0b\uda1b\udee9\udbd3\udec3\udb56\udef2\ud8b0\ude3e\uda27\udc24\ud8e3\ude2d\ud8c0\ude13\u6b44\ud95f\udc9f\uda8b\udcad\udb46\udd77\ud8d0\ude42\ud993\udd9b\udaf4\udcad\ud9b0\uddce\udb64\ude79\udb45\udfa1\ud921\uddc2\u9bf8",
        14, 72872, -965920492, 139317950114053262L, -96145L, true, true, (char) 45126, (char) 12370,
        Double.longBitsToDouble(0x3f7c9e7bb9b05b80L), Double.longBitsToDouble(0x3fea00e3f9447d7aL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=[D:[[]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=[D:[[]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 14, 14, 7, "\uda9d\udc71\udaa7\udf15\uda5c\udc68\ud8d8\udf07\udb1d\udce8\ud922\udfae\udb34\udf9a\udbaf\udd3a\uf5ec\udaf8\udf11\ud818\udd5dl\ud899\udf8c\ud841\udf1f", "\u9e2b\u838a\u9366\u2c96\u208f\u7913\u47a1", "\udb84\udc5f\ud8de\udd37\ud86c\ude8d\ud811\udcf3",
        -5, 48040, -312290693, -2131934337829688781L, -14348L, false, true, (char) 17051, (char) 49178,
        Double.longBitsToDouble(0x3fe76e9fc95f226eL), Double.longBitsToDouble(0x3fea65844d8dde60L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 0, 16, 13, "", "\u8481\u3a98\u99bf\u2301\000\ub4b4\u4169", "\000\000\u0500\uda0c\udd8f\000\udabf\uddcd",
        49, 24821, 891145723, 5455898545956331250L, 75881L, true, true, (char) 0, (char) 48990,
        Double.longBitsToDouble(0x3f3a7f0000000000L), Double.longBitsToDouble(0x3e40000000000000L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 10, 5, "\uda9d\udc71\udbb5\ude0b\ud95f\udd18\uda60\udc88\udb5b\ude19\uda4c\uddce\uda1e\ude95", "\u9e2c\uc221\u68ca\ub7ea\u992b", "\udabf\uddcd\udb8b\udf0c\udb61\udcc8\ud938\udd1c\ud8fe\udf48",
        10, 29082, -1053549999, 6711575145856679364L, -98604L, false, false, (char) 52754, (char) 28146,
        Double.longBitsToDouble(0x3fe7f78501987b59L), Double.longBitsToDouble(0x3feeffecb05d6a1eL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=org.apache.commons.math.linear.OpenMapRealVector:@? |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 6, 6, 16, "\udb8b\udc90\udbcd\uddaf", "\u18f1", "\udbc4\udd5c",
        19, -1000, 1797828096, 5025298236200278257L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fca400001b40000L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[-24.0, -24.0, -24.0, 27645.5, 28561.5, 28113.5, 28297.5, -24.0]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\0121=org.apache.commons.math.linear.OpenMapRealVector:@? |a0=[D:[[-24.0, -24.0, -24.0, 27645.5, 28561.5, 28113.5, 28297.5, -24.0]] |this=org.apache.commons.math.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 7, 7, 7, "\000\000\000\ud82b\udf53\udbd3\udd43\000\ud9a5\udd6f\udb42\uddbb\udbbc\udf5d\u8f09\ud81b\udf7e\ud888\ude12\udbe0\udd96\udabf\udfa8", "\u217e\u6826\u9c93\ucecc\u9bde\u1b25\u5064\u4fc0\u1db7\u2a5e\000\000\000\000\u8cb0\u3c7f\u0105\u3963\u4bdc\u110c\ub911\u7db5\u7e42\u0f5c\ub2e2\u2950\000\u8d1c\u659c", "\ud913\udccf\uda35\udcfc\ud94f\udd15\udb18\udf61\udbcc\udc0b\uda1b\udee9\udbd3\udec3\udb56\udef2\ud8b0\ude3e\uda27\udc24\ud8e3\ude2d\ud8c0\ude13\u6b44\ud95f\udc9f\012\udba1\udff0\ud8d0\ude42\ud993\udd9b\udaf4\udcad\ud9b0\uddce\udb64\ude79\udb45\udfa1\ud921\uddc2\u9bf8",
        14, 14048, -965920492, 139317950114053262L, -96145L, true, true, (char) 45126, (char) 12370,
        Double.longBitsToDouble(0x3f7c9e7bb9b05b80L), Double.longBitsToDouble(0x3fea00e3f9447d7aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.linear.OpenMapRealVector|ebeDivide|[D|new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|ebeDivide|org.apache.commons.math.linear.RealVector|new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|ebeMultiply|[D|new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|ebeMultiply|org.apache.commons.math.linear.RealVector|new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|add|org.apache.commons.math.linear.OpenMapRealVector|new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|add|org.apache.commons.math.linear.RealVector|new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|append|double|new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|append|[D|new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|append|org.apache.commons.math.linear.OpenMapRealVector|new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|append|org.apache.commons.math.linear.RealVector|new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|copy||new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|dotProduct|org.apache.commons.math.linear.OpenMapRealVector|new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|dotProduct|org.apache.commons.math.linear.RealVector|new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|equals|java.lang.Object|new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|getData||new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|getDimension||new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|ebeDivide|[D|new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|ebeDivide|org.apache.commons.math.linear.RealVector|new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|ebeMultiply|[D|new:org.apache.commons.math.linear.OpenMapRealVector:",
    "M|org.apache.commons.math.linear.OpenMapRealVector|ebeMultiply|org.apache.commons.math.linear.RealVector|new:org.apache.commons.math.linear.OpenMapRealVector:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
