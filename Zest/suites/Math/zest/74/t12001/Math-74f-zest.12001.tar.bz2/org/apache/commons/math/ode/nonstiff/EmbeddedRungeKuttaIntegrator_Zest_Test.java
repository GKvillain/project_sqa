package org.apache.commons.math.ode.nonstiff;
import org.junit.Test;
import static org.junit.Assert.*;
public class EmbeddedRungeKuttaIntegrator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 1, 0, "\ud91d\udd83\udb79\udd83\ud8a4\ude10\ud84f\udee8\ud9a0\udef6\ud970\udc12\ud907\udc8a\ud890\udee6\ud9dc\udd3f\udbb6\udfd4\udb3c\udf89\udad7\uddeb\ud9e5\udf23\uda73\udc90\uda24\udc31\ud88d\ude4a\ud988\ude3e\ud9b5\udca3\ud96b\udd8d\u3b89\udaf5\udfdb\ud8d9\udca7\ud975\udd30\udbe5\ude11\udbbc\ude3a", "\u9c0b\ubc6d\u50fd\u00b0\u79a5\u9928\u8ad9", "\u28e8\udaec\udd4f\ud8ed\ude85\ud951\udcec\ud886\udf9b",
        29, 43519, 360270232, 1033546750750034604L, -77784L, true, true, (char) 62314, (char) 30239,
        Double.longBitsToDouble(0x3feff56d149e5ef5L), Double.longBitsToDouble(0x3f986792b68c7280L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 1, 0, "\ud91d\udd83\udb79\udd83\ud8a4\ude10\ud84f\udee8\ud9a0\udef6\ud986\udeca\ud907\udc8a\ud890\udee6\ud9dc\udd3f\udbb6\udfd4\ud8ad\udc62\uda3c\udf28\ud9e5\udfc4\uda73\udc90\uda24\udc31\ud88d\ude4a\ud988\ude3e\udb93\udf93\ud96b\udd8d\u3b89\udaf5\udfdb\ud8d9\udca7\ud975\udd30\udbed\uddf1\uda4d\udeae", "\u287c\u37d9\uaf67\u00b0\u79a5\u9928\u8ad9\u729d\u07f5\uc214\u43c5\u8e48\u707f\ud245\u90b4\u3a47\u5b0b\uce4a\ua67b\ud6c0\u676e\u5ed7\u9bc3\ub733\ua489\u7f5f\ube1d\u8461\ub11f\u6817\u4d5e\u6a8b\ubc4d\u43c2\u504a\uadad\uc76a\u795d\u176b\u70f0\uaa2a\uacea\u9f8b\ub40f\u139b\u426f\u21a1\u53bf\ucde5\u599c", "\ud823\udeac\ud8d4\udcc6\ud8b0\udda4\ucb37\ud80f\udcf3\udba6\udd44\udb38\uddf4\udb97\udeab",
        43, 27985, -63639871, -3129927586764389769L, -8745L, false, false, (char) 47354, (char) 64807,
        Double.longBitsToDouble(0x3fd01e9b457586c0L), Double.longBitsToDouble(0x3fd61d2a8f12dff6L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 1, 1, "\ud91d\udd83", "\u6e0e\ua25a\uc38d\uc175\uc898\000\u9941\u0d36\u650d\u9b08\000\u06e6\u4690\u1b01\u6765\u85ed\000", "\ud975\udd30",
        47, 17000, 773103302, -1699047943689197684L, -18236L, true, false, (char) 50835, (char) 8165,
        Double.longBitsToDouble(0x3fc9253a36ff49f8L), Double.longBitsToDouble(0x3fd7e119bfec1868L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Double:10.0 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=java.lang.Double:0.2 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 2, 3, 0, "\000\udb79\udccb\ud8a4\ude10\ud846\udc43\uda84\udda2\ud970\udc12\ud907\udc8a\ud890\udee6\ud9dc\udd3f\udbb6\udfd4\udb3c\udf89\udad7\uddeb\ud9e5\udf23\uda73\udc90\uda24\udc31\ud88d\ude4a\ud988\ude3e\ud9b5\udca3\udb95\udf42\u3b11\udaf5\udfdb\u00bd\000\udba9\udd13\udbbc\ude3a", "\u9c0b\ubc6d\u50fd\u00b0\u79a5\u9928\u8ad9", "\u28e8\udaec\udd4f\ud8ed\ude85\ud951\udcec\ud886\udf9b",
        29, 43519, 360270232, 1033546750750034604L, -77784L, true, true, (char) 62314, (char) 30239,
        Double.longBitsToDouble(0x3feff56d149e5ef5L), Double.longBitsToDouble(0x3f986792a0001280L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 5, "\udbad\udf9c\ueae9\ud8b7\udc5d\ud84f\udee8", "\u6992\u3255\u9188", "\uda10\udd52",
        57, 14988, -1568496204, -1517959881724090673L, -93653L, false, true, (char) 15164, (char) 22134,
        Double.longBitsToDouble(0x3fde90f871fd6216L), Double.longBitsToDouble(0x3fea82b156c63182L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 4, 1, 0, "\ud92f\udd83\udb79\udd83\ud8a4\ude10\ud84f\udee8\ud9a0\udef6\ud970\udc12\ud907\udc8a\ud890\udee6\ud9dc\udd3f\udbb6\udfd4\udb3c\udf89\ud9aa\udc74\uda1e\udfd3\uda73\udc90\uda24\udc31\ud88d\ude4a\ud988\ude3e\ud9b5\udca3\ud96b\udd8d\u3b89\udaf5\udfdb\ud8d9\udca7\ud975\udd30\udbe5\ude11\udbbc\ude3a", "\u9c0b\ubc6d\u50fd\u00b0\u79a5\u9928\u8ad9", "\u28e8\udaec\udd4f\ud8ed\ude85\ud951\udcec\ud886\udf9b",
        29, 43519, 360270232, 1033546750750034604L, 64866L, false, false, (char) 59305, (char) 59719,
        Double.longBitsToDouble(0x3fea3138ea3de50dL), Double.longBitsToDouble(0x3fc4c0370c9c7b1cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 4, 6, 0, "\ud91d\udd02", "\u03b9\ua294\ubb80\uc175\u7ef5\u4659\u996d\u0d36\ubcc1\u8ef5\ua7f6\uab93\u4690\u1b01\u6765\u85ed\ub6dc", "\udaff\udd0a\u68e4\udbd4\udf3e\ud898\udcc3\ud8ea\udf82\ud899\udc13\u672b\ud9f4\udd9c\udacd\udf11\ud96e\ude3c\udb75\udf97\udab1\udf50\ud827\ude3d\ud97a\udf60\u28e8\udbad\udd2f\udab0\udf65\ud951\udcec\udae5\udca2\ud851\udf05",
        44, 2232, 240641355, 4122775718482923950L, 22014L, false, false, (char) 17130, (char) 64817,
        Double.longBitsToDouble(0x3fe44bc6b188c969L), Double.longBitsToDouble(0x3fec574d0a02662dL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 7, 1, 0, "\ud91d\udd83\udb07\udcf5\ud924\ude38\udade\udd30\u6f68\uda81\udf0c\ud9ae\udd85\udb6c\udf23\ud9db\udfeb\udbb6\udf98\udb3c\udf89\udae6\ude3b\udb15\udf1b\udae1\udf86\udb02\udc59\ud903\udd45\ud988\ude3e\ud9b5\udca3\ud96b\udd8d\ud8b2\udf9a\ud856\udc3a\ud8d1\uddbc\ud975\udd41\udbe5\ude11\uda9a\ude08", "\u4aea\u90a4\uc33c4\u9f57\uaec7\u9be1", "\u28e8\udaec\udd4f\ud8ed\ude85\ud951\udcec\ud886\udf9b",
        29, 43519, 360270232, 1033546750750034604L, -77784L, true, true, (char) 62314, (char) 30239,
        Double.longBitsToDouble(0x3feff56d149e5ef5L), Double.longBitsToDouble(0x3feab33c951a5872L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 0, "\ud91d\udd83\udb79\udd83\ud8a4\ude10\ud84f\udee8\ud9a0\udef6\ud970\udc12\ud907\udc8a\ud890\udee6\ud9dc\udd3f\udbb6\udfd4\udb3c\udf89\udad7\uddeb\ud9e5\udf23\uda73\udc90\uda24\udc31\ud88d\ude4a\ud988\ude3e\ud9b5\udca3\ud96b\udd8d\u3b89\ud90f\udd39\udb31\uddf9\ud975\udd30\udbe5\ude11\udbbc\ude3a", "\u9c0b\ubc6d\u50fd\u00b0\u79a5\u9928\u8ad9", "\u28e8\udaec\udd4f\udb58\udd1f\ud95c\udd82\ud886\udf9b",
        12, 43519, 360270232, -1914820069694769156L, -69755L, true, true, (char) 62314, (char) 46604,
        Double.longBitsToDouble(0x3fc62843de780958L), Double.longBitsToDouble(0x3fc8741276d18e50L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 6, 8, 3, "\ud91d\udd83\udb79\udd83\ud8a4\ude10\ud94c\udfc9\ubb31\ud92b\udc65\ud907\udc1f\ud890\udee6\ud9dc\udd3f\udbb6\udfd4\udb3c\udf89\udad7\uddeb\ud9e5\udf23\uda73\udc90\uda24\udc31\ud88d\ude4a\u446f\udb5a\udc3f\ud96b\udd8d\u3b89\ud921\udeb1\ud978\udda5\ud975\udd30\udbe5\ude11\udbbc\ude3a", "\u9c0b\ubc6d\u50fd\u00b0\u79a5\u9928\u6032", "\u28e8\udaec\udd4f\ud8ed\ude85\ud951\udcec\ud886\udf9b",
        29, 43519, 360270232, 1033546750750034604L, -77784L, true, true, (char) 62314, (char) 30239,
        Double.longBitsToDouble(0x3feff56d149e5ef5L), Double.longBitsToDouble(0x3f986792b68c7280L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 1, 1, "\ud91d\udd83", "5", "",
        45, 29856, 0, 0L, 14151L, false, true, (char) 10461, (char) 0,
        Double.longBitsToDouble(0x3fe6780005c0b28aL), Double.longBitsToDouble(0x3fe9af691d78e3ebL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=java.lang.Double:NaN |a0=[[D:[[[27766.5, 28329.5, 28068.5, 28329.5, 27706.0, 28400.0, 27663.5, 28508.0]]] |a1=[D:[[]] |a2=[D:[[27874.0, 28322.5]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 4, 1, 0, "\ud91d\udd83\udb79\udd83\ud8a4\ude10\ud84f\udee8\ud9a0\udef6\ud970\udc12\ud907\udc8a\ud890\udee6\ud9dc\udd3f\udbb6\udfd4\000\u00a4\ud9d5\udd0a\uda73\udc90\uda24\udc31\ud88d\ude4a\ud988\ude3e\ud9b5\udca3\ud96b\udd8d\u3b89\000\000\ud975\udd30\uda02\udd00\000", "", "\ud9f4\udd75",
        51, 27331, 701622168, -3279112246351123009L, 72022L, true, true, (char) 51317, (char) 62257,
        Double.longBitsToDouble(0x3fe180c3dab3d432L), Double.longBitsToDouble(0x3f97c1913317cb20L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 5, " \000\000\ud84f\udeb3", "\u6992", "\udbf7\udfaa\000\uda10\udc94\ud9eb\udc22",
        13, 32796, -353427576, -5581465380500294208L, -30622L, false, false, (char) 12674, (char) 3939,
        Double.longBitsToDouble(0x3fc38c1b24741bf8L), Double.longBitsToDouble(0x3fe01471f0b3f111L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 7, "", "\u6f20", "\u2dc0\000\000\000\udbd2\udd29\000\uda10\udd52",
        57, 14988, 42420, -1585267068834414385L, -93653L, false, true, (char) 15164, (char) 22134,
        Double.longBitsToDouble(0x3fde90f870000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[27766.5, 28329.5, 28068.5, 28329.5, 27706.0, 28400.0, 27663.5, 28508.0]]] |a1=[D:[[]] |a2=[D:[[27874.0, 28322.5]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=java.lang.Double:NaN |a0=[[D:[[[27766.5, 28329.5, 28068.5, 28329.5, 27706.0, 28400.0, 27663.5, 28508.0]]] |a1=[D:[[]] |a2=[D:[[27874.0, 28322.5]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud91d\udd83\udb79\udd83\ud8a4\ude10\ud84f\udee8\ud886\udec9\udb89\udc4e\ud907\udc8a\ud890\udee6\ud9dc\udd3f\udbb6\udfd4\000\u00a4\ud9d5\udd0a\uda73\udc90\uda24\udc31\ud88d\ude4a\ud988\ude3e\uda04\udfad\ud96b\udd8d\udbed\ude88\000\000\ud975\udd30\uda02\udd00\000", "", "\ud9f4\udd75",
        51, 27331, 701622168, -3279112246351123009L, 72022L, true, true, (char) 8310, (char) 62257,
        Double.longBitsToDouble(0x3fe180c3dab3d432L), Double.longBitsToDouble(0x3f97c1913317cb20L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=java.lang.Double:NaN |a0=[[D:[[[27766.5, 28329.5, 28068.5, 28329.5, 27941.5, 28213.0, 27690.0, 28218.0]]] |a1=[D:[[]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 4, 1, 0, "\ud91d\udd83\udb79\udd83\uda7b\udc9a\ud884\udca4\ud9bb\uddbb\ud970\udc12\ud907\udc8a\ud890\udee6\ud9dc\udd3f\udbb6\udfd4\000\u00a4\ud9d5\udd0a\uda73\udc90\uda24\udc31\ud88d\ude4a\ud988\ude3e\ud9b5\udca3\ud96b\udd8d\u3b89\000\000\ud975\udd30\uda02\udd00\000", "", "\ud9f4\udd75",
        51, 27331, 690546584, -3279112246351123009L, 72022L, true, true, (char) 51317, (char) 62257,
        Double.longBitsToDouble(0x3fe180c3dab3d432L), Double.longBitsToDouble(0x3f97c1913317cb20L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[27873.0, 28575.5, 28055.5, 28496.0, 27706.0, 28400.0, 27663.5, 28508.0]]] |a1=[D:[[]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=java.lang.Double:NaN |a0=[[D:[[[27873.0, 28575.5, 28055.5, 28496.0, 27706.0, 28400.0, 27663.5, 28508.0]]] |a1=[D:[[]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud9f2\udf6f\udb5f\uded0\ud8a4\ude10\ud84f\udee8\ud9a0\udef6\ud970\udc12\ud907\udc8a\udbdb\udff3\ud9dc\udd3f\udbb6\udfd4\000\u00a4\udb09\udec3\uda73\udc90\udafd\udfbe\uda09\udf7b\ud988\ude3e\ud9b5\udca3\ud96b\udd8d\u3b89\000\ud8be\udc00\ud86f\udc4c\uda02\udced\u7d8a", "", "\ud9f4\udd75",
        2, 35791, 701622117, -3279112248511986304L, 93363L, true, true, (char) 51317, (char) 7911,
        Double.longBitsToDouble(0x3fe97c801ab3bcf9L), Double.longBitsToDouble(0x3f97c1913317cb20L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[27766.5, 28329.5, 28068.5, 28329.5, 27706.0, 28400.0, 27663.5, 28508.0]]] |a1=[D:[[]] |a2=[D:[[27874.0, 28322.5]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\ud91d\udd83\udb79\udd83\ud8a4\ude10\ud84f\udee8\ud886\udec9\udb89\udc4e\ud907\udc8a\ud890\udee6\ud9b9\udf3b\udb94\uddd4\000\u00a4\ud9d5\udd0a\uda73\udc90\ua5b4\ud885\udec2\ud988\ude3e\uda04\udfad\ud96b\udd8d\udbed\ude88\000\000\000\uda02\udd00\000", "", "\ud9f4\udd75",
        18, -1000, 687865856, -3279112246351123009L, -100000L, true, true, (char) 8310, (char) 62257,
        Double.longBitsToDouble(0x3fe180c3dab3d432L), Double.longBitsToDouble(0x3f97c1913317cb20L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[27766.5, 28329.5, 28068.5, 28329.5, 27706.0, 28400.0, 27663.5, 28508.0]]] |a1=[D:[[]] |a2=[D:[[27928.0, 28570.0, 27891.5, 28285.5, 27807.0, 28422.0, 28092.0, 28399.0]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=java.lang.Double:NaN |a0=[[D:[[[27766.5, 28329.5, 28068.5, 28329.5, 27706.0, 28400.0, 27663.5, 28508.0]]] |a1=[D:[[]] |a2=[D:[[27928.0, 28570.0, 27891.5, 28285.5, 27807.0, 28422.0, 28092.0, 28399.0]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud91d\udd83\udb79\udd83\ud8a4\ude10\ud84f\udee8\ud886\udec9\udb89\udc4e\ud907\udc8a\ud890\udee6\ud9dc\udd3f\udbb6\udfd4\000\u00a4\ud9d5\udd0a\uda73\udc90\uda24\udc31\ud88d\ude4a\ud988\ude3e\uda04\udfad\ud96b\udd8d\udbed\ude88\000\000\ud975\udd30\uda02\udd00\000", "", "\uda60\udf64\uda17\udd2b\ud96e\ude3c\udba8\ude0e\ud9b3\ude1a\uda7f\udec8\ud84a\ude36\u28e8\udaec\udd4f\udb13\udd6e\uda74\udfe0\ud886\udff3\ud851\udf05\uda05\udc38\uda4e\udcd5\ud93f\udf5c\ud822\ude26\udae6\udcac\ud958\udfec\ud95b\udd7e\ud079\ud9f2\udec1\ud86f\udfe0\ud9cf\udc78\ud811\udf0a\udbbe\udf63\uda77\udc5f",
        4, 34079, 215723139, -3697668498876968742L, -37038L, false, true, (char) 62248, (char) 30110,
        Double.longBitsToDouble(0x3fe9ac039259fc91L), Double.longBitsToDouble(0x3fec32a86601f826L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 1, 0, "\ud98d\uddac\udb79\udd5d\ud8a4\ude10\ud84f\udee8\ud9a0\udef6\ud970\udc12\ud907\udc8a\ud890\udee6\ud9dc\udd3f\udbb6\udfd4\udb3c\udf89\udad7\uddeb\ud9e5\udf23\uda73\udc90\uda24\udc31\udad4\udfde\ud9d4\udf5d\ud9b4\udfe6\ud96b\udd8d\u3b89\udaf5\udfdb\udb1d\udc2a\ud975\udd30\udbe5\ude11\udbbc\ude3a", "\u2e01\ubc6d\u50fd\u00b0\ub3a5\u9928\u8ad9", "\u28e8\udaec\udd4f\ud8ed\ude85\ud951\udcec\ud886\udf9b",
        29, 71593, -1119065841, 1033458536416742060L, -77784L, true, true, (char) 62314, (char) 30239,
        Double.longBitsToDouble(0x3feff56d149e5ef5L), Double.longBitsToDouble(0x3f986792b68c7280L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|integrate|org.apache.commons.math.ode.FirstOrderDifferentialEquations,double,[D,double,[D|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|estimateError|[[D,[D,[D,double|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|getMaxGrowth||new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|getMinReduction||new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|getOrder||new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|getSafety||new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|setMaxGrowth|double|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|setMinReduction|double|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|setSafety|double|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|integrate|org.apache.commons.math.ode.FirstOrderDifferentialEquations,double,[D,double,[D|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
