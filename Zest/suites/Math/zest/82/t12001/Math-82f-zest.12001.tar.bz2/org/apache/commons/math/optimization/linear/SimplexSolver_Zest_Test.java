package org.apache.commons.math.optimization.linear;
import org.junit.Test;
import static org.junit.Assert.*;
public class SimplexSolver_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 4, "\ud8f6\udee0\uda9a\udcb2\ud9f6\udf82\uda8d\uddbe\udafd\ude3c\ud960\udd7f", "\ud24d\u764c\u74df", "\ud8a4\ude91\ud9c9\ude40\ud891\udd2a\udb83\udfe4\ud9e1\udfea\ud88c\udc62\uda73\udef2\ud822\uddda\udb95\udd45\ud9d0\udc32\udab3\udd9b\uda2f\uddf0\uda88\udf34\ud84f\udf79",
        0, 39048, -416637936, 5130370865122051240L, 82803L, false, false, (char) 20200, (char) 60743,
        Double.longBitsToDouble(0x3fd2b8e466c83c20L), Double.longBitsToDouble(0x3f9415a9c9a016e0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 0, "\ud8f6\udee0", "\ua168\u7b0a\u81bb", "\ud848\ude27\u15a9\ud8bd\uddd2",
        38, 90563, 1892963307, -819234105022591796L, -50628L, false, false, (char) 28823, (char) 16618,
        Double.longBitsToDouble(0x3fe67ae4955ec2dcL), Double.longBitsToDouble(0x3fd679bfcf41a302L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 8, 4, "\ud8f6\udee0\uda9a\udcb2\ud9f6\udf82\uda8d\uddbe\udafd\ude3c\ud960\udd7f", "\ud24d\u764c\u74df", "\ud8a4\ude91\ud9c9\ude40\ud891\udd2a\udb83\udfe4\ud9e1\udfea\ud88c\udc62\uda73\udef2\ud822\uddda\udb95\udd45\ud9d0\udc32\udab3\udd9b\uda2f\uddf0\uda58\ude34\ud84f\udf79",
        1, 38941, -416637936, 5130370865122051240L, 82803L, false, false, (char) 20200, (char) 65094,
        Double.longBitsToDouble(0x3fd2b8e466c83c20L), Double.longBitsToDouble(0x3f9415a929a016e0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 4, "\ud9ac\udedb\ubefe\000\000\000\ud960\udd68", "\ud199\u764c\u00d9", "\ud8a4\ude91",
        0, 41892, 0, 0L, 31072L, false, true, (char) 18647, (char) 28823,
        Double.longBitsToDouble(0x3fbf0c1bb67ae490L), Double.longBitsToDouble(0x3fd5ec2dc2cf37f8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.linear.SimplexSolver:@?\0121=new org.apache.commons.math.optimization.linear.SimplexSolver:@?\012",
        Z.run(T, 2, 7, 8, 2, "\ud995\udc24\ud8ab\udd2b\udb2a\udedc\uda39\ude6f\udb58\udd1d\ud8ff\udd0c\uda14\ude88\ud8a3\udc64\ud848\ude16\u15a9\ud8bd\uddd2\udada\udcb5\udbb0\udd97\ud8a4\ude91\ud9c9\ude40\ud891\udd2a\udb83\udfe4\ud9eb\udfcf\uda67\udd37\ud881\udef9\udb16\ude6a\udb95\udd2d\ud9d0\udc32\ud8f4\udcac\ud965\udfb9\uda88\udf34\ud84f\udf79\uda0b\udea9\udbaa\udd0a\ud93a\ude99\ud856\udd51\udafc\udc45\udb44\udeb5\ud96d\udf30\udbcc\uddb1\ud826\udeaf\ud800\udf72\ud829\udc77\ud94d\udfd8\ud871\udcc9\ud886\uddf2\udbfb\udca2\ud85c\udf28\ud88e\udd78\ud859\udce5\udba3\udebc\u876d\udbcc\udfcf\udaca\udd8d\ud90c\udc80\ud8b9\udf12\uda4b\udc96\udae0\udddf\udbc6\udfeb", "\u1689\u7377\ud60c\u406a\u85af\u186b\uce47\uc0a8\u0f6c\u102e\u6fa4\u44ba\u453d\u51f1\u334d\ub836\u48cc\u5ad9\u5276\ubf6c\u73c1", "\ud814\udd73\udb6f\udf7f\udb12\udf07\uda1f\udeab\ud92c\uddb8\ud9fe\ude8a\ud8a4\udcc5\udbca\ude60\ud901\ude5a",
        34, 45953, 797452875, -1276691093172786397L, 20305L, false, false, (char) 28715, (char) 11584,
        Double.longBitsToDouble(0x3feb2bc97d34a526L), Double.longBitsToDouble(0x3fec0afdaebed95dL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 0, "\udb4e\udf6b\udb3e\ude45\ua137\udac1\udc5f\udafd\ude3c\ud960\udd7f", "\u5e61\u57fb\u2b4c", "\ud8a4\ude91\ud9c9\ude40\ud871\udc03\udbab\udd6b\ud9e1\udfea",
        14, 52218, -852853543, 537130276100269622L, -49317L, true, false, (char) 27706, (char) 46547,
        Double.longBitsToDouble(0x3fefb31a9410904eL), Double.longBitsToDouble(0x3fd1fe12aff31038L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 4, "\ud8f6\udee0\uda9a\udcb2\ud9f6\udf82\uda8d\uddbe\udafd\ude3c\ud960\udd7f", "\ud24d\u764c\u20d9", "\ud8a4\ude91\ud9c9\ude40\ud891\udd2a\udb83\udfe4\ud9e1\udfea\ud88c\udc62\uda73\udef2\ud822\uddda\udb95\udd45\ud9d0\udc32\udab3\udd9b\uda2f\uddf0\uda88\udf34\ud84f\udf79",
        0, 39048, -416637936, 5130370865122051240L, 82803L, false, false, (char) 20200, (char) 60743,
        Double.longBitsToDouble(0x3fd2b8e466c83c20L), Double.longBitsToDouble(0x3f9415a9c9a016e0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.linear.SimplexSolver:@?\0121=new org.apache.commons.math.optimization.linear.SimplexSolver:@?\012",
        Z.run(T, 2, 8, 8, 4, "\ud8f6\udf53\uda9a\udcb2\ud9f6\udf82\u37e5\udafd\ude67\udbb4\udfe9", "\u0f50\u5475\u209f", "\ud8a4\ude91\ud9c9\ude40\ud891\udd2a\udb83\udfe4\ud9e1\udfea\ud88c\udc62\uda73\udef2\ud822\uddda\udb95\udd45\ud9d0\udc32\udab3\udd9b\uda2f\uddf0\uda88\udf34\ud84f\udf79",
        0, 54784, -416634877, 5130370865122051240L, 82803L, false, false, (char) 20200, (char) 60743,
        Double.longBitsToDouble(0x3fd2b8e466c83c20L), Double.longBitsToDouble(0x3f9415a9c9a016e0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 4, "\ud8d3\udd8c\uda9a\udcb2\ud9f6\udf82\uda8d\uddbe\udafd\ude3c\ud960\udd7f", "\ud24d\u764c\u74df", "\ud8a4\ude91\ud9c9\ude40\ud891\udd2a\udb83\udfe4\ud9e1\udfea\ud88c\udc62\uda73\udef2\ud822\uddda\udb95\udd45\ud9d0\udc32\udab3\udd9b\uda2f\uddf0\uda88\udf34\ud84f\udf79",
        0, 39048, -416637936, 5130370865122051240L, 82803L, false, false, (char) 20200, (char) 60743,
        Double.longBitsToDouble(0x3fd2b8e466c83c20L), Double.longBitsToDouble(0x3f9415a9c9a016e0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 5, 4, "\ud953\udd8e\uda9a\udc7a\ud9f6\udf82\uda8d\uddbe\udafd\ude3c\ud961\udd06", "\ud24d\u764c\u74df", "\ud8a4\ude91\ud9c9\ude40\ud891\udd2a\udb83\udfe4\ud9e1\udfea\ud88c\udc62\udb9b\udca5\ud815\udd21\udb95\udd45\ud9d0\udc32\udab3\udd9b\uda2f\uddf0\uda88\udf34\udb15\udca3",
        50, 39048, 2087033872, 5130370865122051240L, 82803L, false, false, (char) 20200, (char) 60743,
        Double.longBitsToDouble(0x3fd2b8e46d683c20L), Double.longBitsToDouble(0x3fc2e709a01c02dcL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 4, "\ud8f6\udee0\uda9a\udcb2\ud88f\udc4e\udaf5\ude0c\uda4f\udc10\ud960\udd7f", "\ud24d\u764c\u763e", "\uda5a\udf95\ud9c9\ude40\ud891\udd2a\ud967\udecb",
        1, 90139, 2064695218, -3668375365844254940L, -39528L, false, false, (char) 21345, (char) 10299,
        Double.longBitsToDouble(0x3fd679bfcf41a302L), Double.longBitsToDouble(0x3f90904ea3fce540L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.linear.SimplexSolver:@?\012",
        Z.run(T, 1, 7, 6, 5, "\ud8f6\udee0\udaad\udc90\ud8ee\udc60\udbb9\udd9e\udafd\ude3c\udb30\udd46", "\u9b88\u0a8a\uc4d8\u0486\u807c\u64a6\u6172\u4432\u5b32\u8dce\u4a1d\u135b\ud713", "\udab3\uddcb\udbfc\udc0d\uda72\udc86",
        27, 54495, -1873930592, -1789446308198433505L, -97107L, true, false, (char) 33718, (char) 20200,
        Double.longBitsToDouble(0x3fe9bbd0812bf2ecL), Double.longBitsToDouble(0x3feb20f0801415a9L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 4, 7, "\ud8f6\udee0\uda9a\udcb2\ud9f6\udf82", "\u81bb\u57ad\ub7d0", "\ud8ef\udfa6\uda33\udc01",
        58, 20307, -190742804, 449881452366546444L, 67349L, false, true, (char) 63465, (char) 3151,
        Double.longBitsToDouble(0x3fc90d01eb05f758L), Double.longBitsToDouble(0x3fbf0c1bb67ae490L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 2, 4, "\ud8f6\udee0\uda9a\udcb2\ud9f6\udf82\uda8d\uddbe\udafd\ude3c\ud960\udd7f", "\u9085\u764c\u74df", "\ud8a4\ude91\ud9c9\ude40\ud891\udd2a\ud9b0\udce0\ud9e1\udfea\ud88c\udc62\uda73\udef2\ud926\udf3b\u2f4d\ud930\ude60\ud810\uddf5\ud921\udd61\udb96\udd3c\ud8e0\udc0e",
        54, 39035, 841653264, 5130371715525575848L, 82803L, false, false, (char) 20200, (char) 60743,
        Double.longBitsToDouble(0x3faec3a33641e790L), Double.longBitsToDouble(0x3fd1415a9c9a016eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 4, "\ud8f6\udee0\uda9a\udcb2\ud9f6\udf82\uda8d\uddbe\udafd\ude3c\ud960\udd7f\uda14\ude88\ud882\ude54\ud848\ude27\u15a9\ud8bd\uddd2\uda33\udc27", "\u6172\u4432\u5b32\u8dce\u33e4\u898d\u4099\u0279\u3ded\u4428\u1633\u3e59\u5ed4\u824b", "\ud856\udd51",
        49, 29139, -821376493, 8153328259053968834L, -55716L, false, false, (char) 48903, (char) 25375,
        Double.longBitsToDouble(0x3fd3698fec3aa770L), Double.longBitsToDouble(0x3fd4b8ae1fb4115eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.linear.SimplexSolver:@?\0121=new org.apache.commons.math.optimization.linear.SimplexSolver:@?\012",
        Z.run(T, 2, 8, 8, 4, "\uda1d\udfd3\uda9a\udc6a\ud9f6\udf82\uda8d\uddbe\udafd\ude3c\udb4d\udd15", "\ud1b4", "\ud9ec\udd31",
        -2, 20167, -190742804, 449881450118020876L, -33162L, false, true, (char) 5752, (char) 41353,
        Double.longBitsToDouble(0x3feffb40780de27eL), Double.longBitsToDouble(0x3fbf0c1bb67e6f30L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.linear.SimplexSolver:@?\012",
        Z.run(T, 1, 8, 0, 4, "\ud8f6\udee0\udb3e\udca4\ud91b\udf95\uda8d\uddbe\ud9fa\udc3d\udb38\udd8b", "\ud24d\u764c\u74df", "\ud8c1\udc3b\udb1b\udd37\ud891\udd2a\udb83\udfe4\ud9e1\udfea\ud88c\udc62\uda73\udef2\udb66\udddc\uda10\udc43\ud9cf\udfa2\udab3\udd9b\uda2f\uddf0\udb56\ude12\ud84f\udf79",
        1, 90407, 104456387, 5343457184952681640L, 82803L, false, true, (char) 20186, (char) 65094,
        Double.longBitsToDouble(0x3fd2b8e466c83d26L), Double.longBitsToDouble(0x3f9415a929a016e0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 0, "\ud8f6\udee0\uda9a\udcb2\ud9f6\udf82\uda8d\uddbe\udafd\ude3c\ud960\udd7f", "\ud24d\u50f6\u7409", "\ud8a4\ude91\ud9c9\ude40\ud891\udd2a\udb83\udfe4\ud9e1\udfea\ud88c\udc62\uda73\udef2\ud822\uddda\udb95\udd45\ud9d0\udc32\udab3\udd9b\uda2f\uddf0\uda88\udf34\ud84f\udf79",
        0, 39048, -416637936, 5130370868393608360L, 82803L, false, false, (char) 20200, (char) 60743,
        Double.longBitsToDouble(0x3fef14b303641eddL), Double.longBitsToDouble(0x3f9415a9c9a016e0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 4, "\ud8f1\ude21\uda52\udfbf\u46f0\uda9c\ude87\udaed\udf11\uda5b\udea4\ud9d5\udece\ud892\udcb9\uda31\ude12\udad8\udc31\ud8bd\uddd2\ud980\udeae", "\u436f\u8aee\u5b32\u8dce\u33e4\u898d\u4099\u0279\u3ded\u4428\ucaaa\u6ea7\ub1a5\u69d9\ud321\u366a\u6181", "\ud96d\udf30\ucf85\uda1d\udcf3\udafb\udcc6\uda44\udee6",
        56, 96697, -1652532902, -4332145752891911072L, 39055L, true, true, (char) 17554, (char) 39002,
        Double.longBitsToDouble(0x3fefe811bb622ac8L), Double.longBitsToDouble(0x3fc9ec92d07c3998L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.optimization.linear.SimplexSolver|getPivotRow|int,org.apache.commons.math.optimization.linear.SimplexTableau|new:org.apache.commons.math.optimization.linear.SimplexSolver:",
    "M|org.apache.commons.math.optimization.linear.SimplexSolver|doIteration|org.apache.commons.math.optimization.linear.SimplexTableau|new:org.apache.commons.math.optimization.linear.SimplexSolver:",
    "M|org.apache.commons.math.optimization.linear.SimplexSolver|doOptimize||new:org.apache.commons.math.optimization.linear.SimplexSolver:",
    "M|org.apache.commons.math.optimization.linear.SimplexSolver|getPivotColumn|org.apache.commons.math.optimization.linear.SimplexTableau|new:org.apache.commons.math.optimization.linear.SimplexSolver:",
    "M|org.apache.commons.math.optimization.linear.SimplexSolver|isOptimal|org.apache.commons.math.optimization.linear.SimplexTableau|new:org.apache.commons.math.optimization.linear.SimplexSolver:",
    "M|org.apache.commons.math.optimization.linear.SimplexSolver|isPhase1Solved|org.apache.commons.math.optimization.linear.SimplexTableau|new:org.apache.commons.math.optimization.linear.SimplexSolver:",
    "M|org.apache.commons.math.optimization.linear.SimplexSolver|solvePhase1|org.apache.commons.math.optimization.linear.SimplexTableau|new:org.apache.commons.math.optimization.linear.SimplexSolver:",
    "C|org.apache.commons.math.optimization.linear.SimplexSolver|<init>|",
    "C|org.apache.commons.math.optimization.linear.SimplexSolver|<init>|double",
    "M|org.apache.commons.math.optimization.linear.SimplexSolver|getPivotRow|int,org.apache.commons.math.optimization.linear.SimplexTableau|new:org.apache.commons.math.optimization.linear.SimplexSolver:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
