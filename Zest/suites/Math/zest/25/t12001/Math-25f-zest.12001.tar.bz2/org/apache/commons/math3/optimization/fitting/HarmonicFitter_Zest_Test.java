package org.apache.commons.math3.optimization.fitting;
import org.junit.Test;
import static org.junit.Assert.*;
public class HarmonicFitter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NumberIsTooSmallException\012",
        Z.run(T, 2, 0, 0, 0, "\udb0e\uddaa\udaaf\udc24\udb7d\udc59\uda3f\ude54\ufeb8\udb23\udd35\udabd\udc15\ud906\udf13\ud83c\udf7f\ud8d3\udcb0\ud836\udcf5\udacd\udd59\ud952\uddc5\udadf\udde6\uda8c\uded8\ud949\udce4\ud80f\udd67\uda3a\udea6\ud993\udf79\uda1e\uddc2\uda16\uddae\ud927\udfe9\udbf9\udeb9", "\u93f5\uaf74", "\ud884\udde3\ud8c5\udd01\ud826\udeed\udb1d\udd7a\ud986\udfe4\ud919\udf61\ud946\udc27\ud8f6\udf71\udb0e\udc9b\uda33\udf30",
        21, 4015, 519886018, -7964150575058848378L, -79240L, false, true, (char) 50952, (char) 35257,
        Double.longBitsToDouble(0x3fbb278ca67bdf60L), Double.longBitsToDouble(0x3fefcdf691cb1b2dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NumberIsTooSmallException\012",
        Z.run(T, 2, 0, 0, 0, "\udb0e\uddaa\ud98a\udd00\ud84a\udc5a\uda3f\ude54\ufeb8\udb23\udd35\udabd\udc15\ud906\udf13\ud83c\udf7f\ud8d3\udcb0\ud836\udcf5\udab4\ude59\ud952\uddc5\udadf\udde6\uda8c\uded8\ud949\udce4\ud80f\udd67\uda3a\udea6\ud993\udf79\uda1e\uddc2\uda16\uddae\ud927\udfe9\udbf9\udeb9\ud869\ude15", "\uaf74\u9137\ud06e\u32f5\u3e63\u02f5", "\ud919\udf61\ud946\udc27\ud8f6\udf71\udb0e\udc9b\uda33\udf30\udb8f\udea6\ud89e\udf29\ud9dd\ude95\uda22\udcbb\ud9a9\udc5a\ue1a4\u5aad\ud92f\udc95\ud8d4\udf77\udb09\udca5\udae2\udf27\ud9be\udf29\uda56\udfb9\udac0\udcf7\u2193\udb6d\uddb2\ud96e\udffd\u47bd\udbce\udd83\ud986\udd3a\ud9c5\udf7d\ud8aa\udf2a\udad3\udfa0\ud99e\udeaa\udb25\uddf3\ud8b4\uddc5",
        32, 21464, 666759102, -3242352390675503324L, -12897L, false, true, (char) 29038, (char) 24704,
        Double.longBitsToDouble(0x3fefce5a281416a0L), Double.longBitsToDouble(0x3fdc389c6f9a353cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\udbca\udda8\udaaf\udc24\udb08\udcdf\uda3f\ude54\ufeb8\udb01\uddf5\ud91a\ude8d\ud975\ude9a\ud83c\udf7f", "\u721e\u41f1\u6b86\u3b30", "\uda3a\udea6\ud993\udf79\uda1e\uddc2\uda16\uddae\udab3\udd6f\udbfa\uddf1\ud869\ude15\ud82d\ude85\udb79\udf5a\ud968\udd1a\ud86a\uded9\ud8ae\udcb2\ud884\udde3\ud8c5\udd01\ud9a8\uddce\udb1d\udd7a\ud986\udfe4\ud919\udf61\uda32\udd7e\udbe5\uddbd\udb0e\udc9b\uda33\udf30\ud845\udc40",
        19, 48820, -980590579, -4547240310284088318L, 72534L, false, true, (char) 17958, (char) 50952,
        Double.longBitsToDouble(0x3fcdae1991b278c8L), Double.longBitsToDouble(0x3fc9ef7d9fe6fb48L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NumberIsTooSmallException\012",
        Z.run(T, 2, 0, 0, 0, "\udb0e\uddaa\udaaf\udc34\udb7d\udc59\uda3f\ude54\ud9df\udda8\u7212\ud9b8\uddff\uda8a\uded7", "\u0a91\u721e\u41f1\u940a\u7a00\uc5e1\u575f\u23a8\ud1bc", "\uda47\udee0\udbf9\udeb9\ud869\ude15\ud9f6\ude4a",
        12, 18756, -24292625, -1558966329894440384L, 13725L, true, false, (char) 37765, (char) 56618,
        Double.longBitsToDouble(0x3fcadb5ee079f0b0L), Double.longBitsToDouble(0x3fd7e386d9335a42L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 1, 0, "\udb0e\uddaa\ud813\udd16\udb7d\udd08\uda3f\ude54\uda0f\udee1\udac7\udce8\udb0b\udeb1\ud906\udfbb\ud869\udfb5\ud961\udcd5\ud83a\udf95\udacd\udd59\ud952\uddc5\ud8bf\udff7\ud88e\udeda\ud80b\udd79\ua9f2\uda3a\udea6\ud993\udf79\uda1e\uddc2\uda33\udd9d\ud927\udfe9\udbf9\udeb9", "\u3edd\u4414", "\ud884\udde3\ud8c5\udd01\ud826\udeed\udb1d\udd7a\udaf9\ude96\uda8c\uddfd\ud8b2\udec0",
        33, 88088, 730099510, -4165405177493926586L, 8401L, false, true, (char) 26467, (char) 52501,
        Double.longBitsToDouble(0x3fd7368882306a74L), Double.longBitsToDouble(0x3fe1194202815054L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\udaba\uded0\udaae\udf65\udbca\udd81", "\u8c0c\u4e85\ua75e\u825e\u3520\u0a91\u8fb9\u0881\u2c02\u8967\uad07\u5794\u4ba9\ud17a\u4909\ub4fa\u273e\uc28d\u842b\uc8ac\u93f5\uaf74\ud7aa\uc0bf\u7f2c\u41e4\u7ab9\u3ad4\u57f4\u0dac\ucc01\u6ec3\uc6f4\u68ba", "\ud897\ude92\uda22\udcbb\ud9a9\udc5a\ue1a4\u5aad\ud92f\udc95\ud8d4\udf77\udb09\udca5\udae2\udf27\ud9be\udf29\uda56\udfb9\udac0\udcf7\u2193\ud89d\udc89\udbb3\udd2c\udb5f\udd6d\udad4\ude3a\uda50\udea9",
        59, 49956, 146768034, 445266267026496488L, -36107L, false, false, (char) 25878, (char) 54300,
        Double.longBitsToDouble(0x3fd0f9415d4ea266L), Double.longBitsToDouble(0x3fefad69df31c249L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\udbca\udda8", "\u5592\u0db5\u2688\u7f40\ub2e7\u5190\u751f\u0a91", "\udad5\udd62\ud989\ude16\ud947\ude53\ud80f\udd67",
        18, 73412, 2275339, -2347304493185839760L, -8566L, false, false, (char) 0, (char) 45216,
        Double.longBitsToDouble(0x3fe20382e848f9d8L), Double.longBitsToDouble(0x3fee1e433aa9ded2L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\u4c4d", "\u5592\u0db5\u2688\u7f40\ub2e7\u5190\u3520\u0a91", "\udad5\udd62\ud989\ude16\ud947\ude53\ud80f\udd67",
        18, 73412, 488814603, -2347303831760876176L, -8566L, false, true, (char) 37222, (char) 45216,
        Double.longBitsToDouble(0x3fe20382e848f9d8L), Double.longBitsToDouble(0x3fee1e433aa9ded2L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NumberIsTooSmallException\012",
        Z.run(T, 2, 0, 0, 0, "\udb0e\uddaa\udaaf\udc24\udbfe\udefb\uda5f\udd44\ufeb8\udb23\udd35\udabd\udc15\ud906\udf13\ud83c\udf7f\udbc6\udf49\ud909\udceb\udacd\udd59\ud952\uddc5\udadf\udde6\uda8c\uded8\ud949\udce4\ud80f\udd67\uda3a\udea6\ud993\udf79\uda1e\uddc2\uda16\uddae\ud927\udfe9\udbf9\udeb9", "\u93f5\uaf74", "\ud884\udde3\ud8c5\udd01\ud826\udeed\udb1d\udd7a\ud986\udfe4\ud919\udf61\ud946\udc27\ud8f6\udf71\udb0e\udc9b\uda33\udf30",
        21, 4015, 519886018, -7964150575058848378L, -79240L, false, false, (char) 15398, (char) 35257,
        Double.longBitsToDouble(0x3fbb278ca67bdf60L), Double.longBitsToDouble(0x3fefcdf691cb1b2dL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.optimization.fitting.HarmonicFitter|fit||new:org.apache.commons.math3.optimization.fitting.HarmonicFitter:org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer",
    "M|org.apache.commons.math3.optimization.fitting.HarmonicFitter|fit|[D|new:org.apache.commons.math3.optimization.fitting.HarmonicFitter:org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer",
    "C|org.apache.commons.math3.optimization.fitting.HarmonicFitter|<init>|org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
