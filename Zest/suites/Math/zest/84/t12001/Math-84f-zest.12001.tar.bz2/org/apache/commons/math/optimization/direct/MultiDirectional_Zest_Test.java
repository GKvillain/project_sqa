package org.apache.commons.math.optimization.direct;
import org.junit.Test;
import static org.junit.Assert.*;
public class MultiDirectional_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 2, "\udbca\udf1d\uc736\udbae\udf17", "\u481c\u708b\uad42\u7cc4\u6332", "\uda85\udd38\udb04\udd46\udb13\udd2f",
        51, -30, 1553465950, 234014896854090086L, -10712L, false, false, (char) 55566, (char) 3468,
        Double.longBitsToDouble(0x3fe02ead910da276L), Double.longBitsToDouble(0x3fb9b6f82387e338L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 2, "\udbca\udf1d\uc736\udbae\udf17", "\u481c\u708b\uad42\u7cc4\u6332", "\uda85\udd38\udb04\udd46\udb13\udd2f",
        51, -30, 1553465950, 234014896854090086L, -10712L, false, false, (char) 55566, (char) 3468,
        Double.longBitsToDouble(0x3fe02ead910da276L), Double.longBitsToDouble(0x3fb98a782387e338L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\012",
        Z.run(T, 1, 3, 2, 2, "\udbca\udf1d\uc736\udbae\udf17", "\u481c\u708b\uad42\u7cc4\u6332", "\uda85\udd38\udb04\udd46\udb13\udd2f",
        51, -30, 1544746008, 2244589554879579663L, -10712L, false, false, (char) 55566, (char) 3468,
        Double.longBitsToDouble(0x3fe02ead910da276L), Double.longBitsToDouble(0x3fb9b6f823865810L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 0, 2, "\udbca\udee7\ubbc7\ud94a\udf0e", "\u481c\u181a\u16d5", "\udb5e\udc40\ud8e4\udf42\uda81\udc54\udb04\udd46\udb36\udc2f\udbb2\udf3c",
        20, 84950, 54479974, 1090787439658154455L, 3106L, true, false, (char) 64387, (char) 5191,
        Double.longBitsToDouble(0x3fbc3f19f66f3ba0L), Double.longBitsToDouble(0x3fbd60f935d8b930L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\012",
        Z.run(T, 1, 2, 0, 2, "\udbca\udf1d\uc736\udbae\udf17", "\u481c\u708b\uad42\u7cc4\u6332", "\uda85\udd38\udb04\udd46\udb13\udd2f",
        57, 932, 1543701086, 234014896854090086L, -48902L, false, false, (char) 59514, (char) 21648,
        Double.longBitsToDouble(0x3fe7031fb30a6748L), Double.longBitsToDouble(0x3fe886ab5c0f0c41L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 2, "\ud842\uddfa\uc736\udbae\udf17\udab7\udc2f\uda7e\udf9a\ud96d\udf69", "\u7cc4\u4cf9\u6f73\u444f\u214f\ucebc\u96be\u71a3\u2319\u201c", "\ud895\udd99\ud8fa\udfd9\uf098\ud8f8\udcaa\udb1e\udebf\udb5c\udc81\udb02\udcbb\udae2\udc2f\udace\ude19\udb88\udf40\uda65\udf90\ud97f\udfe5\udba7\ude28\ud878\udee0\ud8c8\udeda",
        14, 38649, -436934421, 7870336555531396150L, 24881L, true, false, (char) 8613, (char) 33343,
        Double.longBitsToDouble(0x3fe39cc54e0c1bb6L), Double.longBitsToDouble(0x3fe5a4c6b8c0a1cfL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\012",
        Z.run(T, 1, 2, 1, 2, "\udbca\udf1d\uc736\udbae\udf17", "\u481c\ud206\u9d78\u7cc4\u6332", "\udb6f\udc2c\udb04\udd46\udb13\udd2f",
        51, 91172, -2105200489, 234015549689119078L, -10712L, false, false, (char) 55566, (char) 3468,
        Double.longBitsToDouble(0x3fe02ead910da276L), Double.longBitsToDouble(0x3fb9b6f8154faf08L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 3, "\udbca\udf1d\uc736\udbae\udf17", "\u481c\u708b\uad42\u7cc4\u6332", "\uda85\udd38\udb04\udd46\udb13\udd2f",
        31, 110, 1553465950, 234014896892100966L, 64552L, false, false, (char) 55566, (char) 3468,
        Double.longBitsToDouble(0x3fe02ead910da276L), Double.longBitsToDouble(0x3fb9b6f82387e338L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 2, "\udbca\udf1d\uc736\udbae\udf17", "\u481c\u708b\uad42\u7cc4\u6332", "\uda85\udd38\udb04\udd46\udb13\udd2f",
        51, 54464, 543677180, 266170462300750182L, -10712L, false, false, (char) 55566, (char) 3468,
        Double.longBitsToDouble(0x3fe2d6ad910d8215L), Double.longBitsToDouble(0x3fb9b6f82387e338L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\012",
        Z.run(T, 1, 3, 0, 2, "\udbca\udf1d\ud9c5\udfde\udbae\udeb5", "\u481c\u708b\uad42\u7cc4\u6332\u1901\u7c6a\u156d\u497d", "\ud83e\ude54\uda6a\udfd3\ud8d5\udfc5",
        22, 26079, -253469496, -2972240747658829555L, -5285L, false, true, (char) 5191, (char) 57559,
        Double.longBitsToDouble(0x3fddb01f898d3e2aL), Double.longBitsToDouble(0x3fbf75a1b4d102a0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 2, "\uda7f\udee0\uc736\udbae\udf17", "\u481c\u2b86\u7d48\u7c53\u6332", "\uda85\udd38",
        14, 64458, -877018959, 2608393641107391070L, -67282L, false, true, (char) 55566, (char) 3468,
        Double.longBitsToDouble(0x3fec2fad910da2d1L), Double.longBitsToDouble(0x3fe336df03157d45L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 1, 2, "\udbca\udf1d\uc736\udacb\udc6b\uda21\udc55\ud896\ude08\uda08\udc6f\udb70\udc98\udaf8\udc05\udade\uddd3\ud8d4\udc6a\uda35\udfbe\udbeb\udd18\uda97\udce3\udb1a\udeb8\ud9d5\udc4b", "\uc5fc\u4f13\u40f8\u8dc9\u6d5c\u9a8f\u10fe\u52d5\u9728\ua570\u331e\u4ad6\ub878\u045d\u36d6", "\ud8b4\ude73\udb05\udeb1\ud82e\udef0\ud82b\udd7c\uda17\udea4\udafb\udef1",
        25, 3639, -927875256, -3789083554398737690L, 61238L, true, false, (char) 49866, (char) 48208,
        Double.longBitsToDouble(0x3fe0470c7da5da81L), Double.longBitsToDouble(0x3fea6db53e6b0a4dL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\0121=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\012",
        Z.run(T, 2, 3, 2, 0, "\udbca\udf1d\uc736\udbae\udf17", "\u5f10\u708b\uad42\ucb24\ua9b8", "\ud85d\udc4d\udb80\udeb6\udb13\udd57",
        51, -30, -648974824, 8847797587333235385L, -63623L, true, false, (char) 23707, (char) 30653,
        Double.longBitsToDouble(0x3fea60822c0dd343L), Double.longBitsToDouble(0x3fa5d157ee607020L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\0121=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\012",
        Z.run(T, 2, 3, 2, 0, "\u4bcc\ud9e0\udf57\udbae\udea5\ud93f\udc08\ud990\uddda\uda32\udc30\ud8a3\udd9e\ud95a\udf88\udba6\ude50\udad1\uddda\uda1d\udfd1", "\u5431\u4a96\u318a", "\ud947\udc37\uda91\uddd9",
        44, 87344, -624919862, -3138035462468358755L, -14253L, false, false, (char) 19445, (char) 58620,
        Double.longBitsToDouble(0x3fe443734368522cL), Double.longBitsToDouble(0x3fe6b49337253495L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 1, 2, "\udbca\udf1d\uc736\udbae\udf17", "\u481c\u708b\uad42\u7cc4\uc2ee", "\ud8bc\uddb6\udb04\udd46\udafa\udf7c\ud860\udefc\udb50\udd96\u97d2\udbc5\udc24\udb52\udf0f",
        44, 13114, -860424228, -6895575286609187522L, -33735L, false, true, (char) 21204, (char) 62338,
        Double.longBitsToDouble(0x3fbc9fccc2868f98L), Double.longBitsToDouble(0x3fed2b3c44c30446L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 2, "\udbca\udee7\ubbc7\ud94a\udf0e", "\u8f3a\u1776\uc3e7", "\ud87d\udfdd\udac2\udcc9\ud8e0\udf61",
        30, 50764, 1322163864, 2636488630174275010L, 56464L, false, false, (char) 13774, (char) 2031,
        Double.longBitsToDouble(0x3fd6ed5b28b20c70L), Double.longBitsToDouble(0x3fd4cf2e0fab883aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 3, "\ud85f\udea2\uc7a2\udbae\udf17", "\u481c\u708b\uad42\u7cc4\u6332", "\uda85\udd38\udb04\udd46\udb13\udd2f",
        31, 110, 1553465950, 234014896892100966L, 64552L, false, false, (char) 55566, (char) 3468,
        Double.longBitsToDouble(0x3fe02ead910da276L), Double.longBitsToDouble(0x3fb9b6f82387e338L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\0121=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\012",
        Z.run(T, 2, 3, 3, 2, "\ud9d7\udd70\uc736\udbae\udf17\udb3a\udf51\uda7e\udfb4\ud9a5\ude48", "\u153e\ua807\ub84c\u6670\ud6e8\u1deb\u4d28\u62ba\u5896\ua13a", "\ud82e\uddf7\ud8fe\udcb0\ud81d\udd98\ud907\ude31\ud81b\udc09\ud802\ude53\ud94f\udc28\udabc\udf2c\ud9c0\udfaf\ud927\ude94\ud8e1\udd7b\ud96d\ude63\ud985\udc37\udbf2\udfb4\ud9e3\udc9a\ud97f\udc35",
        -4, 44689, 1010305216, 3214467835993031650L, 46118L, true, true, (char) 29806, (char) 40880,
        Double.longBitsToDouble(0x3fc4fe7f9e5aa6b4L), Double.longBitsToDouble(0x3fc383518564bd0cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\0121=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\012",
        Z.run(T, 2, 3, 3, 3, "\udbca\udf1d\ud8e7\ude66\ud851\udfb1", "\u481c\u708b\uad42\ub637", "\uda23\udfa6\uda73\udd44\ud92b\udfe4",
        48, 58731, -1725356199, -6910520293794552885L, 3106L, true, false, (char) 32746, (char) 5191,
        Double.longBitsToDouble(0x3fbc3f19c966e018L), Double.longBitsToDouble(0x3fd12cca51f3849eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 2, "\udbca\udf1d\udbbb\udc7b\udbae\udede", "\u481c\ub0c1\u6a91\ua74d\u6332", "\ud9fa\ude11\udabc\ude8d\udb13\udcc7",
        51, -30, 1553465950, 234014896854090086L, -10712L, false, false, (char) 55566, (char) 3468,
        Double.longBitsToDouble(0x3fe02ead910da276L), Double.longBitsToDouble(0x3fb9b6f82387e338L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.MultiDirectional:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 1, 0, "\ud9d6\udf9c\u8da1\ud94a\udeb3", "\u8f3a\u1776\uc3e7\u4473\u7379\ub5b3\u53ff", "\udb70\udfcc\u28c2\udbad\udd0f\udb4a\udeb6",
        4, 53703, -1438102825, -7660169076026410294L, 3775L, false, true, (char) 19089, (char) 61397,
        Double.longBitsToDouble(0x3fc4959ae5b98bf4L), Double.longBitsToDouble(0x3febaf2333b16489L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.optimization.direct.MultiDirectional|iterateSimplex|java.util.Comparator|new:org.apache.commons.math.optimization.direct.MultiDirectional:",
    "M|org.apache.commons.math.optimization.direct.MultiDirectional|evaluateNewSimplex|[Lorg.apache.commons.math.optimization.RealPointValuePair;,double,java.util.Comparator|new:org.apache.commons.math.optimization.direct.MultiDirectional:",
    "C|org.apache.commons.math.optimization.direct.MultiDirectional|<init>|",
    "C|org.apache.commons.math.optimization.direct.MultiDirectional|<init>|double,double",
    "M|org.apache.commons.math.optimization.direct.MultiDirectional|iterateSimplex|java.util.Comparator|new:org.apache.commons.math.optimization.direct.MultiDirectional:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
