package org.apache.commons.math3.ode;
import org.junit.Test;
import static org.junit.Assert.*;
public class AbstractIntegrator_Zest_Test {
  @Test
  public void test0() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test0() throws Throwable {
//     assertEquals("0=java.lang.String:Adams-Bashforth |this=org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:@?\012",
//         Z.run(T, 1, 12, 6, 4, "\ud9f8\uddee\udbc9\udf05\ud9d8\uddc3\udaeb\udc16\udb32\udea8", "\u8996", "\udabb\udd0e\ud94b\ude8d\uda8e\udc17\u733d\udafd\udea0\udb03\udda0\uda8f\udc6c\uda80\udccf\ud996\udc26\ud92c\udfa9\udb7e\udc99\ud8cd\udcc2\ud863\udd8d\uda83\udfec\uda26\udd35\ud82e\uddee\ud972\udc44\ud8c4\udefa\ud89d\udedd\udb68\udd47\udab5\udfd1\uee3b\ud9d0\udf5e\ud905\udea2\ud8de\uddcc\udbf4\udee1\udba4\ude1f",
//         45, 42143, -214150059, -5849305975265099090L, 30063L, true, false, (char) 1642, (char) 9625,
//         Double.longBitsToDouble(0x3fa15366ab57eb50L), Double.longBitsToDouble(0x3fec5cdb0b82151dL)));
//   }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NumberIsTooSmallException\012",
        Z.run(T, 1, 12, 6, 4, "\ud9f8\uddee\udaa2\uddb2\udba8\ude8e\udaeb\udc16\udb32\udea8", "\u8996", "\ud903\ude0e\ud94b\ude8d\udb1a\udf7b\udbda\uddeb\udad6\udeca\udbee\udc5a\uda7e\uddcf\uda80\udccf\ud996\udc26\ud92c\udfa9\udb7e\udc99\ud8cd\udcc2",
        -4, 73104, 1699045904, -5315516089965415957L, 77254L, false, true, (char) 35398, (char) 51089,
        Double.longBitsToDouble(0x3fbadee2e1719098L), Double.longBitsToDouble(0x3fed2426b1f1c7f8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:Adams-Bashforth |this=org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:@?\012",
        Z.run(T, 1, 12, 6, 4, "\ud9f8\uddee\udaa9\udcb2\udbea\ude8f\udaeb\udc16\udb32\udea8", "\ub2f5", "\udab4\udd79\ud94b\ude8d\uda8e\udc17\u733d\udafd\udea0\udb03\udda0\ud81d\ude68\uda80\udccf\ud996\udc26\ud92c\udf67",
        15, 71500, 1618216926, 8886975077686796816L, 77254L, false, true, (char) 35398, (char) 51089,
        Double.longBitsToDouble(0x3fa36545f2e32130L), Double.longBitsToDouble(0x3fe52346c1d5add3L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:Adams-Bashforth |this=org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:@?\012",
        Z.run(T, 1, 12, 6, 4, "\ud9f8\uddee\udaa2\uddb2\udba8\ude8e\udaeb\udc16\udb32\udea8", "\u8996", "\udabb\udd0e\ud94b\ude8d\uda8e\udc17\u733d\udafd\udea0\udb03\udda0\u540c\uda80\udccf\ud996\udc26\ud92c\udfa9\udb7e\udc99\ud8cd\udcc2\ud863\udd8d\uda83\udfec\uda26\udd35\ud82e\uddee\ud972\udc44\ud8c4\udf98\ud89d\udedd\udb68\udd47\udb0c\udf9e\udb5f\udc90\ud9d0\udf5e\ud905\udea2\ud8de\uddcc\udbf4\udf0d\uda9b\udcd9",
        21, 42143, -214150059, 7985752080255001262L, 12604L, true, false, (char) 1642, (char) 9625,
        Double.longBitsToDouble(0x3fa15366ab57eb50L), Double.longBitsToDouble(0x3fec5cdb0b82151dL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:Adams-Bashforth |this=org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:@?\012",
        Z.run(T, 1, 12, 6, 4, "\ud9f8\uddee\udaa2\uddb2\udba8\ude8e\udaeb\udc16\udb32\udea8\ud8f6\udd3d\ud932\ude38\ud8d5\udf01\udb8f\udfa2\ud8bd\udf01\ud9c0\udca1\ud91e\udc40\uda8e\udc17", "\ud749\u0223", "\ud92c\udfa9\udb5a\ude75\ud8cd\udcc2\udadb\udc6a\uda51\udf77\udb8c\ude85\ud82e\uddee\ud972\udc44\ud8c4\udefa\ud89d\udedd\udb68\udd47",
        26, 98713, 840147051, -7579443624289963307L, 44927L, true, false, (char) 45689, (char) 29057,
        Double.longBitsToDouble(0x3fe50ece0bf19bc2L), Double.longBitsToDouble(0x3fe10cf7528753e3L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:Adams-Bashforth |this=org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:@?\012",
        Z.run(T, 1, 12, 6, 4, "\ud9a9\udda9\udaa2\uddb2\udba8\ude8e\udaeb\udc16\udb32\udea8\ud8f6\udd3d\ud932\ude38\udb64\udd49\ud8f6\udedc", "\u1661\u7f36\u3529\u7c33\ud749\u12b4\u2af8\ud72c\u8078\uc97c\u72dd\u222f\u52d4\u29cb", "\ud8c4\udf2e\ud89d\udedd\udb68\udd47\udb0c\udf9e\udb5f\udc90\uda48\udd3b\ud905\udea2\ud8de\uddcc",
        29, 4446, 1996491430, -7522196518313634731L, -33778L, true, false, (char) 40883, (char) 25867,
        Double.longBitsToDouble(0x3fd8753e39a11744L), Double.longBitsToDouble(0x3fa15366ab57eb50L)));
  }
  @Test
  public void test6() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test6() throws Throwable {
//     assertEquals("0=java.lang.String:Adams-Bashforth |this=org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:@?\012",
//         Z.run(T, 1, 12, 6, 4, "\ud9f8\uddee\udaa2\uddb2\udba8\ude8e\udaeb\udc16\udb32\udea8", "\u8996", "\udabb\udd0e\ud94b\ude8d\udaca\udd55\ud884\udd6c\udafd\udea0\udb03\udda0\ud891\udc79\ud9ca\udeb5\ud995\udf58\ud92c\udfa9\udb7e\udc99\ud8cd\udcc2\ud863\udd8d\uda83\udfec\uda26\udd35\ud82e\uddee\ud972\udc44\ud8c4\udefa\ud89d\udedd\udb68\udd47\udb0c\udf9e\ud84e\ude68\ud902\udfcd\ud905\udf2b\ud8de\uddcc\udbf4\udf0d\udba4\ude1f",
//         45, 42143, -211459941, -8875724924858012954L, 30063L, true, false, (char) 1642, (char) 9625,
//         Double.longBitsToDouble(0x3fa15366ab57eb50L), Double.longBitsToDouble(0x3fec5cdb0b82151dL)));
//   }
  @Test
  public void test7() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test7() throws Throwable {
//     assertEquals("0=java.lang.String:Adams-Bashforth |this=org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:@?\0121=!java.lang.NullPointerException\012",
//         Z.run(T, 2, 12, 6, 4, "\ud9f8\uddee\udaa2\uddb2\udba8\ude8e\udaeb\udc16\udb32\udea8", "\u8996", "\udabb\udd0e\ud94b\ude8d\uda8e\udc17\ud922\udf50\udad0\ude13\udb03\udda0\uda8f\udc6c\uda80\udccf\ud996\udc26\ud92c\udfa9\udb7e\udc99\ud8d7\udc76\udb20\udd74\udb4f\udccb\uda40\uded2\ud82e\uddee\ud972\udc44\ud8c4\udefa\ud89d\udedd\udb68\udd47\udb0c\udf9e\udb5f\udc90\ud9d0\udf5e\ud905\udea2\ud8de\uddcc\udbf4\udf0d\udba4\ude1f",
//         45, 42143, -210348971, 7985752080017064622L, 30063L, true, false, (char) 1642, (char) 9625,
//         Double.longBitsToDouble(0x3fa15366ab57eb50L), Double.longBitsToDouble(0x3fec5cdb0b82151dL)));
//   }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:@?\012",
        Z.run(T, 1, 2, 6, 4, "\ud99e\udca6\u4426\ud89c\udd96\udafc\udea4\udaa5\udd2a", "\uce12", "\udabb\udd4f\udb78\udd57\ud910\ude0a",
        23, 86655, -332765492, 5811261852158029863L, 45626L, false, false, (char) 31093, (char) 19767,
        Double.longBitsToDouble(0x3fc50c0e8841ed50L), Double.longBitsToDouble(0x3fe23bca29ebb63bL)));
  }
  @Test
  public void test9() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test9() throws Throwable {
//     assertEquals("0=!java.lang.NullPointerException\012",
//         Z.run(T, 1, 0, 6, 4, "\000\000\ud926\udef2\000\ucf5a", "\u8996", "\udabb\udd0e\ud94b\ude8d\uda8e\udc17\000\000\000\uda8f\udc6c\uda80\udccf\ud996\udc26\ua8e8\000\ud8cd\udcc2\ud863\udd8d\uda83\udfec\uda26\udd35\ud82e\udda7\ud972\udc44\ud8c4\udef8\ud89d\udedd\udb68\udce1\udb0c\udf9e\udb5f\udc47\ud9d0\udf5e\ud905\udea2\ud8de\uddcc\udbf4\udf0d\udba4\ude1f",
//         45, 7823, -214150059, 7926360860585427630L, -100000L, false, false, (char) 0, (char) 9370,
//         Double.longBitsToDouble(0x3f44d9aad5fad400L), Double.longBitsToDouble(0x3fec5cdb0b82151dL)));
//   }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:@?\012",
        Z.run(T, 1, 5, 6, 4, "\udbd4\udebd\udac8\uddc6\udba8\ude8e\udaeb\udc16\udb32\udea8", "\u89ad\u7ff7\u59d4\u5386\u3b84\u6264\u34c1\u7c33", "\uda80\udccf\ud996\udc26\uda2d\ude08\udb7e\udc47",
        10, 95710, -1379558168, 8738498471603699271L, -81310L, false, false, (char) 49467, (char) 35398,
        Double.longBitsToDouble(0x3fd4992480d6f716L), Double.longBitsToDouble(0x3fa71909ea46d850L)));
  }
  @Test
  public void test11() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test11() throws Throwable {
//     assertEquals("0=!java.lang.NullPointerException\012",
//         Z.run(T, 1, 15, 14, 2, "\ud9f8\uddee\udaa2\uddb2\udba8\ude8e\udaeb\udc16\udb32\udea8", "\u8996", "\ud949\udc04\ud94b\ude8d\uda8e\udc17\u733d\udafd\udea0\udb90\udeb0\uda8f\udc12\uda80\udccf\ud996\udc26\ud92c\udfa9\udb7e\udc99\ud8cd\udcc2\ud863\udd8d\uda83\udfec\uda26\udd35\ud82e\uddee\ud972\udc44\ud8c4\udefa\ud89d\udedd\udb68\udd47\udb0c\udf9e\udb5f\udc90\ud9d0\udf5e\ud905\udea2\ud8de\uddcc\udbf4\udf0d\udba4\ude1f",
//         45, 42143, -214150059, 7985752080017109537L, -92411L, true, false, (char) 1642, (char) 23758,
//         Double.longBitsToDouble(0x3fa138bd2b57eb50L), Double.longBitsToDouble(0x3fec5cdb0b82b81dL)));
//   }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:Adams-Bashforth |this=org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:@?\012",
        Z.run(T, 1, 12, 10, 4, "\ud9f8\uddee\ud84b\udca6\u0b0f\udaeb\udc16\udb32\udea8\ud8f6\udd3d\ud92c\udc38\ud867\udc0b\u3548\u08e4\ud9ef\udf30\ud919\udce7\uda8e\udc17\u733d", "\u12b4\u3d73\uc728\u8078\uc97c\u5ae5\u8376\u66ad\u29cb\ubc93", "\ud89d\udedd\udb68\udd47\udb0c\udf9e\udb5f\udc90\ud9d0\udf15\ud905\udea2\ud8de\uddcc\udbf4\udf0d\udba4\ude1f\ud90c\udda9\ud824\udff8\ud994\udf94\udbd7\ude63\udb17\udf99\udaea\udcb8\ud90f\ude38\udbd1\udeb9\ud9e9\udd99\ud91d\udc2e\uda6f\udf99\u0cc7\uda3e\udcc9\ud910\ude92\udadb\udf88\udbdc\udf4d\uee4c",
        8, 21513, 1984591352, -851946569368829828L, 26054L, true, true, (char) 5146, (char) 51993,
        Double.longBitsToDouble(0x3fe6577b1fdb58beL), Double.longBitsToDouble(0x3fe37bee103206caL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:Adams-Bashforth |this=org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:@?\012",
        Z.run(T, 1, 12, 6, 4, "\ud9f8\uddee\udaa2\uddb2\udba8\ude8e\udaeb\udc16\udb32\udea8", "\u8996", "\udabb\udd0e\ud94b\ude8d\uda8e\udc17\u733d\udafd\udea0\udb03\udda0\uda8f\udc6c\uda80\udccf\ud996\udc26\ud92c\udfa9\udb7e\udc99\ud8cd\udcc2\ud863\udd8d\uda83\udfec\uda26\udd35\ud82e\uddee\ud972\udc44\ud8c4\udefa\ud89d\udedd\udb68\udd47\udb1f\udff9\udb2b\udc9b\ud9e1\udcd7\ud905\udea2\ud8de\uddcc\udbf4\udf0d\udba4\ude1f",
        6, 42260, -214150059, 7985752080017064622L, 30063L, true, false, (char) 1642, (char) 9625,
        Double.longBitsToDouble(0x3fa15366ab57eb50L), Double.longBitsToDouble(0x3fec5cdb0b82151dL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:Adams-Bashforth |this=org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:@?\012",
        Z.run(T, 1, 12, 6, 4, "\ud9f8\uddee\udaa2\uddb2\udba8\ude8e\udaeb\udc16\udb32\udea8", "\u8996\u7ff7\u59d4\u77fb", "\ud8e2\udd8b\ud965\udca7\udb11\udc7d\uda8f\udc6c\uda80\udccf\ud996\udc26",
        3, 80790, 1170110636, 6950188777072812200L, -81310L, false, false, (char) 49467, (char) 35398,
        Double.longBitsToDouble(0x3fd4992480d6f716L), Double.longBitsToDouble(0x3fa71909ea46d850L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |a1=[D:[[27858.0, 28210.5, 27961.0, 28353.0, 28092.0, 28463.0, 27997.5, 28147.0]] |this=org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:@?\012",
        Z.run(T, 1, 14, 6, 14, "\ud9d4\udc95\udaa2\uddb2\udba8\ude8e\udaeb\udc16\udb32\udea8", "\u8996", "\ud8ed\udd03\ud9ef\udfb3\uda8e\udc17",
        5, 86655, -332765492, -4204743720814099617L, 45626L, false, false, (char) 47746, (char) 19767,
        Double.longBitsToDouble(0x3fc50c0e8841ed50L), Double.longBitsToDouble(0x3fe23bca29ebb63bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.ode.AbstractIntegrator|acceptStep|org.apache.commons.math3.ode.sampling.AbstractStepInterpolator,[D,[D,double|new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
    "M|org.apache.commons.math3.ode.AbstractIntegrator|addEventHandler|org.apache.commons.math3.ode.events.EventHandler,double,double,int|new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
    "M|org.apache.commons.math3.ode.AbstractIntegrator|addEventHandler|org.apache.commons.math3.ode.events.EventHandler,double,double,int,org.apache.commons.math3.analysis.solvers.UnivariateSolver|new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
    "M|org.apache.commons.math3.ode.AbstractIntegrator|addStepHandler|org.apache.commons.math3.ode.sampling.StepHandler|new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
    "M|org.apache.commons.math3.ode.AbstractIntegrator|clearEventHandlers||new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
    "M|org.apache.commons.math3.ode.AbstractIntegrator|clearStepHandlers||new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
    "M|org.apache.commons.math3.ode.AbstractIntegrator|computeDerivatives|double,[D,[D|new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
    "M|org.apache.commons.math3.ode.AbstractIntegrator|getCurrentSignedStepsize||new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
    "M|org.apache.commons.math3.ode.AbstractIntegrator|getCurrentStepStart||new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
    "M|org.apache.commons.math3.ode.AbstractIntegrator|getEvaluations||new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
    "M|org.apache.commons.math3.ode.AbstractIntegrator|getEventHandlers||new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
    "M|org.apache.commons.math3.ode.AbstractIntegrator|getMaxEvaluations||new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
    "M|org.apache.commons.math3.ode.AbstractIntegrator|getName||new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
    "M|org.apache.commons.math3.ode.AbstractIntegrator|getStepHandlers||new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
    "M|org.apache.commons.math3.ode.AbstractIntegrator|initIntegration|double,[D,double|new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
    "M|org.apache.commons.math3.ode.AbstractIntegrator|integrate|org.apache.commons.math3.ode.ExpandableStatefulODE,double|new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
    "M|org.apache.commons.math3.ode.AbstractIntegrator|acceptStep|org.apache.commons.math3.ode.sampling.AbstractStepInterpolator,[D,[D,double|new:org.apache.commons.math3.ode.nonstiff.AdamsBashforthIntegrator:int,double,double,double,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
