package org.apache.commons.math.optimization.direct;
import org.junit.Test;
import static org.junit.Assert.*;
public class BOBYQAOptimizer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 7, 7, 7, "\udbff\udd5b\ud9f0\udffd\udab7\udeb1\uda96\udc09\ud86b\ude02", "\u3678\u37ac\u6b2d\ua86e\uc06a\u94b5\u313d\u806b\u2a97\u4085\ubdb7\u433d\u3b8d\u09e4", "\udaa3\udc60\udb7a\udc47\ud989\ude21\udb11\udf31\ud860\udc6c\uda6d\udf33\udb74\uddaa\ud8df\udeee",
        28, 96061, -465316419, 4013468900463077642L, -43831L, true, false, (char) 2727, (char) 50835,
        Double.longBitsToDouble(0x3fe51d5ce0e91fc9L), Double.longBitsToDouble(0x3fe3efbc2be2c152L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 7, "\udbff\udd5b\ud9f0\udffd\udab7\udec2\ud86c\udf3f\ud810\udc9d", "\u3678\u37ac\u6b2d\u83a9\uc0f0\u7fe4\u79f8\u806b\u2a97\u4085\ubdb7\u433d\u3b8d\u09e4", "\udaa3\udc60\udb7a\udc47\ud989\ude21\udb11\udf31\ud860\udc6c\uda6d\udf33\udb74\uddaa\ud8df\udeee",
        28, 72293, -465316419, 4013468899573882122L, -43831L, true, false, (char) 2727, (char) 50835,
        Double.longBitsToDouble(0x3fe51d5ce62b3ac9L), Double.longBitsToDouble(0x3fe3efbc2facc152L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 13, 6, "\udbff\uddcd\ud9f0\udffd\ud877\udca8\uda96\udc09\ud86b\udd8b\uda89\ude7f", "\u37ac\u6b2d\ua86e\uc06a\u94b5\u263d\u806b\u2a97\u4085", "\ud870\udd02\ud9ca\ude9f\ud8ce\udfaf\ud857\udc51\udaa3\udc60\ud83f\udd0a\uc912\udb11\udf31\ud860\udc6c\uda6d\udf33\udb74\uddaa\ud8df\udeee\ud80f\udc0c\ud9e1\udc6e\uda31\udc1a\ud8ff\udffb\ud815\udec4\udb1b\udec7\u24b9\udb49\ude24\udb5f\udeae\u44b9\uda1b\udc82\ud802\udc69\ud966\udecb\udbde\ude03\udbad\udce2\udbfd\udfaf\uda95\udd62\udaaf\udd3d\uda1a\udf48\ud819\udeba\udb80\ude80\udbe8\udcfa\ud916\udf33\uda83\udde4\ud949\udfc7\udaa5\udd7e\udb80\udcc0\udb32\ude99",
        32, 61294, -2128286354, -3509537525463846995L, -70410L, true, false, (char) 25118, (char) 48665,
        Double.longBitsToDouble(0x3fed6c1fa0aa2d96L), Double.longBitsToDouble(0x3fdd84efd76c0bbaL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 4, 7, "\udbff\udd5b\ud9f0\udffd\uda5e\ude75\uda96\udc09\ud86b\ude02", "\u3678\u37ac\u6b2d\u33be\uc06a\u94b5\u313d\u806b\u2a97\u4085\ubdb7\u433d\u3b8d\u09e4", "\udaa3\udc60\udb7a\udc47\ud989\ude21\udb11\udf31\ud860\udc6c\uda6d\udf33\udb74\uddaa\ud8df\udeee",
        50, 45541, -465316419, 4013468900463077642L, -43831L, true, false, (char) 2727, (char) 50835,
        Double.longBitsToDouble(0x3fe51d5ce0e91fc9L), Double.longBitsToDouble(0x3fe3efbc2be2c152L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 9, 7, "\udb71\udc13\ud9f0\udfe4\ud9f8\udc72\ud872\udc66\ud92b\udc41", "\u01ba\u37ac\u6b2d\ua86e\u868f\u1e49\u64cb\u806b\ua27d\u4085\ubdb7\ua5dd\ub8f7\u660f", "\ud977\udc54\udb7a\udc47\ud989\ude21\udb11\udf31\ud92a\udfc7\uda6d\udf33\udb74\uddaa\ud8df\udeee",
        28, 96061, -465316419, 4013468900463077642L, -79221L, true, false, (char) 65442, (char) 36202,
        Double.longBitsToDouble(0x3fe5190718e91fc9L), Double.longBitsToDouble(0x3fbf7de16be5ed48L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 7, 7, 7, "\udbff\udd5b\ud9f0\udffd\udab7\udeb1\ud84e\udf86\udb06\udc16", "\u3678\u37ac\u12fe\ua86e\uc06a\u94b5\u313d\u806b", "\udb66\uddbe\uda12\udf8a\ud870\udd02\ud9ca\ude9f\ud8bc\udd89",
        -5, 66759, -1106639829, 4911918788973594366L, -24343L, false, false, (char) 32313, (char) 36769,
        Double.longBitsToDouble(0x3fd757066b7b553aL), Double.longBitsToDouble(0x3fc67c886428dec8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 0, "\udbff\udd5b\ud9f0\udffd\udab7\udeb1\uda96\udc09\udb2b\ude02", "\u3678\u37ac\u6b2d\u146f\u914d\u6124\u7216\u427b\u728f\u2031\u9dbd\u433d\u3b8d\u09e4", "\udaa3\udc60\udb7a\udc47\ud989\ude21\udb11\udf31\ud860\udc6c\ud813\udc45\udb74\ude1d\ud8c9\udd8c",
        28, 31365, 1445305021, 4013468900463077642L, 87241L, false, false, (char) 2779, (char) 50835,
        Double.longBitsToDouble(0x3fe51d5ce0e91fc9L), Double.longBitsToDouble(0x3fe3efbc2fe2c152L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 7, 7, 7, "\udbff\udd5b\ud9f0\udffd\uda43\udd56\uda93\udc1c\ud86b\udd7b", "\u3678\u37ac\u6b2d\ua86e\uc06a\ua598\u0a92\u8116\u2a97\u4085\ubdb7\u433d\u3b8d\u09e4", "\udaa3\udc60\udb7a\udc47\ud989\ude21\ud9ee\udfbd\udaf0\udf8b\ud928\udc8f\udbb1\udf50\ud8b8\udd8b",
        -3, 23637, -465356577, -5570191106581337846L, -43831L, true, false, (char) 2727, (char) 50835,
        Double.longBitsToDouble(0x3fe51d5ce0e91fc9L), Double.longBitsToDouble(0x3fe703642be2c1e2L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.BOBYQAOptimizer:@?\0121=new org.apache.commons.math.optimization.direct.BOBYQAOptimizer:@?\012",
        Z.run(T, 2, 12, 13, 0, "\udbff\udd5b\ud9f0\udffd\udab7\udeb1", "\u8b6f\u3458\u3678\u37ac\u6b2d\ua86e\uc06a\u94b5\u313d\u806b\u2a97\u4085", "\u6378\udb5a\udf4c\uda47\udf0f\ud856\udffd\udaa3\udc60\udb7a\udc47\ud989\ude21\udb11\udf31\ud860\udc6c\uda6d\udf33\udb74\uddaa\ud8df\udeee\ud80f\udc0c\ud9e1\udc6e\uda31\udc1a\uda03\udcbd\ud831\udeba\ud872\udef3\u24f2\udb49\ude24\udb5f\ude94\udb83\udfc0\uda1b\udc82\ud802\udc69\ud966\udecb\udb99\udd61\uda4a\ude74\ud928\ude65\ud9aa\udc54\udb2c\udffe\uda63\udfa7\uda2b\udd0e\udaa6\udeb2\udbfd\uddfb\ud941\ude80\uda12\udc84\ueb17\ud806\udfbe\udb40\udd1d\udb28\udd85",
        42, 93347, -693269250, 6471374978855594073L, -3130L, false, true, (char) 51655, (char) 58883,
        Double.longBitsToDouble(0x3fee4a3028e5ce37L), Double.longBitsToDouble(0x3fb6ec8aa9b24f58L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 13, 0, "", "\uaf6c\000\000\u6bf0\000", "\ud837\udc2d\ue003\udaea\udfd6\ud800\udccf\ud9c8\udd9a\udb25\ude75\u2625\udbeb\udd45\udb44\udebe\uda12\udf8a\ud870\udd02\ud9ca\ude9f\ud8bc\udd89\ud857\udc51\000\000\000\uda9e\udf2e\ud860\udc6c\uda6d\udf33Q\000\ud959\udd0b",
        -5, 35864, 934458547, 7002253038580662272L, -66063L, true, true, (char) 60051, (char) 5696,
        Double.longBitsToDouble(0x3fcd23f939f7de14L), Double.longBitsToDouble(0x3f482a408a266000L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.BOBYQAOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 3, 7, "\udbff\udd5b\ud9f0\udffd\udab7\udeb1\uda96\udc09\ud86b\ude02", "\u0570\u37ac\uc0e4\ua86e\uc06a\u6b25", "\ufe0c\udbeb\udd45\udb66\uddbe\uda12\udf8a\ud870\udd02\ud9ca\ude9f\ud8bc\udd89\ud857\udc51\udaa3\udc60\udb9c\ude47\ud989\ude21\ud827\ude8b\udbec\udd1d\uda6d\udf33\udb74\uddaa\udb56\udfea\uda28\udd6e\ud857\udc23\uda20\ude10\u10d8\ud831\udec4\ud842\uddf3\u24f2\udb49\ude24\uda96\udda7\udb83\udfc0\ud91e\uddd1\ud827\udec9",
        47, 43562, 1291137708, 4757788993942797886L, 62369L, true, true, (char) 25319, (char) 12398,
        Double.longBitsToDouble(0x3fcd549b6e3ecbb4L), Double.longBitsToDouble(0x3fe41d664c353542L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 7, "\ud86b\udf33\udae7\udf4f\udab7\udeb1\uda96\udc09\ud86b\ude02", "\u3678\u37ac\u6b2d\ua86e\uc06a\u94b5\u313d\u806b\u2a97\u4085\ubdb7\u6a29\u1b1a\ub6e2", "\udaa3\udc60\udb7a\udc47\ud989\ude21\udb11\udf31\ud860\udc6c\uda6d\udf33\udb74\uddaa\ud8df\udeee",
        28, 96061, -465316419, 4013426019509594378L, -43831L, true, false, (char) 2727, (char) 50835,
        Double.longBitsToDouble(0x3fe51d5ce0e91fc9L), Double.longBitsToDouble(0x3fe3efbc2be2c152L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 7, "\udbff\udd5b\ud9f0\udfab\udab7\udeb1\uda96\udc09", "\u3458\u3678\u37ac", "\udaea\udfd6\ud800\udccf",
        40, 51435, -528166937, -2102824952886316502L, 89526L, false, true, (char) 16185, (char) 37504,
        Double.longBitsToDouble(0x3fe0fa1d7c2b9e8aL), Double.longBitsToDouble(0x3fe0edf053fe442aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 10, "\udbff\udd5b\ud9f0\udffd\udab7\udeb1\uda96\udc09\ud86b\ude02", "\u4dbf\u37ac\u6b2d\ua86e\u7d52\000\u5df0\u806b\u2a97\u4085\ubdb7\u433d\u1b6f\u0994", "\udaa3\udc60\udb7a\udc47\ud989\ude21\udb11\udf31\ud860\udc6c\udbfc\udeda\udb74\udd59\ud8df\udeee",
        33, 44424, 189, 1627389952L, -43831L, true, false, (char) 2727, (char) 59865,
        Double.longBitsToDouble(0x3fe51d5800e91fc9L), Double.longBitsToDouble(0x3fe3efbc2be2c152L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 7, 7, "\udbff\udd5b\ud9f0\udffd\udab7\udeb1\uda96\udc09\ud86b\ude02", "\u3678\u37ac\u6b2d\ua86e\uc06a\u94b5\u313d\u88b7\u2a97\u4085\ubdb7\u433d\u3b8d\u09e4", "\udaa3\udc60\udb7a\udc47\ud989\ude21\udb11\udf31\ud860\udc6c\uda6d\udf33\udb74\uddaa\ud8df\udeee",
        16, 96061, -465316419, 4013468900463027210L, -43831L, true, false, (char) 2727, (char) 44435,
        Double.longBitsToDouble(0x3fbb7b8c4748fce8L), Double.longBitsToDouble(0x3fe3efbc2be2c152L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 7, "\udbff\udd5b\ud9f0\udffd\udab7\udeb1\uda96\udc09\ud86b\ude02", "\u3678\u37ac\u6b2d\ua86e\uc06a\u94b5\u313d\u806b\u2a97\u4085\ubdb7\u433d\u3b8d\u09e4", "\udaa3\udc60\udb7a\udc47\ud989\ude21\udb11\udf31\ud860\udc6c\uda6d\udf33\udb74\uddaa\ud8df\udeee",
        28, 96061, -461843011, 4013468900463077642L, -43831L, true, false, (char) 2727, (char) 50835,
        Double.longBitsToDouble(0x3fe51d5ce0e91fc9L), Double.longBitsToDouble(0x3fe3efbc2be2c152L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.BOBYQAOptimizer:@?\0121=new org.apache.commons.math.optimization.direct.BOBYQAOptimizer:@?\012",
        Z.run(T, 2, 13, 13, 6, "\udbff\udd5b\ud9f0\udffd\udab7\udeb1\uda17\uddea\ud86b\ude05\uda89\ude7f\udbba\udeb1\ud920\ude05\ud8b2\udc25\ud837\udc2d\ue003", "\u313d\u6069\u2a57\u4085\ubdb7\u433d\u32c4\u09e4\u7108\u788c\u969c", "\udb11\udf31\ud860\udc6c\udba3\udc16\udb74\ude4c\ud8df\udeee\udbbe\udea4\ud9e1\udca4",
        51, 5547, 1630398730, 4242108803212696425L, 26947L, false, false, (char) 5696, (char) 8370,
        Double.longBitsToDouble(0x3fe3efbc2be2c152L), Double.longBitsToDouble(0x3fe5afe2627b9cdeL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 11, 6, "\udb68\udf76\ud961\udd37\udaa8\udd30", "\u8b6f\u3458", "\udb46\udce6\ud918\udf39\u61c3\ud806\udd76\ud9c8\udd9a\udb3e\udc75\ufe0c\udb25\ude82\udbbd\udee2",
        42, 40279, 1906333215, -5941163280862386092L, 30005L, true, false, (char) 59431, (char) 18517,
        Double.longBitsToDouble(0x3fe6af2a6051c265L), Double.longBitsToDouble(0x3fe8b0b76d67b97dL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 8, "\udbff\udd5b\ud9f1\udffd\ud829\udeaa\uda96\udc09\ud86b\ude02", "\u3678\ud0e2\u936f\ua86e\uc06a\u94b5\u313d\u640b\u9fa4\u4085\ubdb7\u433d\u3b8d\u09e4", "\udaa3\udc60\ud8f1\ude83\ud989\ude21\uda18\udd14\ud85f\udf86\uda6d\udf33\udb7c\udeaa\ud8df\udeee",
        28, 96061, -465316419, 4013468900463077642L, -43831L, true, false, (char) 2727, (char) 50835,
        Double.longBitsToDouble(0x3fe0dd5ce1af7d7dL), Double.longBitsToDouble(0x3fe3ecd4abe2c152L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 7, "\udbff\udd5b\ud9f0\udf5d\uda98\udeb1\uda96\udc09\ud98d\udc5c", "\u3678\u37ac\u6b17\ua86e\uc06a\u94b5\u313d\u806b\u2a97\u4085\ubdb7\u433d\u3b8d\u09e4\u7108", "\udb7a\udc47\ud989\ude21\udb11\udf31\ud860\udc6c\uda6d\udf33\udb74\uddaa\ud8df\udeee\ud80f\udc0c\ud91c\udc62\ud8bd\uddd7\ud8db\udf37\ud831\udec4\ud872\udef3\u24f2\udb49\ude24\udb5f\ude94\udb83\udfc0\uda1b\udc82\ud802\udc69\ud966\udecb\udad4\udd5d\uda55\udd76\uda07\udd0d\ud9a0\ude0d\uda34\udf44",
        28, 28694, -2026601587, -7325824994121470902L, 29815L, true, false, (char) 17774, (char) 3272,
        Double.longBitsToDouble(0x3feaba269e0a7e70L), Double.longBitsToDouble(0x3fe15d9ef0729ab3L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 7, 7, "\udbff\udd5b\ud9f0\udffd\udab7\udeb1\uda96\udc09\ud86b\ude02\uda89\ude7f\ud9a2\udde4\ud9ed\udf07\ud965\udce7\ud837\udc2d\ue003\ud8e5\udc64\ud9c6\udea1\udb4b\ude22\uda63\udc22\udb63\udcdb", "\u5d24", "\ud8bc\udd89\uda86\udfea\ud97f\udd8e\udb97\udddf\ud989\ude21",
        29, 35511, -1033518379, 1651976985024248598L, 77331L, false, true, (char) 6474, (char) 52039,
        Double.longBitsToDouble(0x3fc223419f8c6b10L), Double.longBitsToDouble(0x3fc75d3b2b0aae70L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[D:[[0.17567543879135017, 0.17567543879135017, 0.17567543879135017, 0.17567543879135017, 0.17567543879135017, 0.17567543879135017, 0.17567543879135017, 0.17567543879135017, 0.17567543879135017, 0.17567543879135017, 0.17567543879135017, 0.17567543879135017, 0.17567543879135017, 0.17567543879135017, 0.17...\0121=void\012",
        Z.run(T, 2, 6, 8, 7, "\udbff\udd5b\udaf8\udf21\udaa2\udf1d\uda96\udc09\ud86b\ude02", "\u8e78\u37ac\ud53f\u9f15\uc06a\u94b5\u313d\u806b\u2a97\u013d\ubdb7\u433d\u3b8d\u648e", "\udaa3\udc60",
        51, 43229, 911647742, -1924143154913230123L, 13430L, true, true, (char) 10806, (char) 32886,
        Double.longBitsToDouble(0x3fc67c886428dec8L), Double.longBitsToDouble(0x3febdb096b693adeL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 7, "\udbff\udd5b\ud9f0\udffd\udab7\udeb1\uda96\udc09\ud86b\ude02", "\u5122\u37ac\u6b2d\ua86e\uc06a\u94b5\u313d\u806b\u2a97\u4085\ubdb7\ub204\u3b8d\u09e4", "\udaa3\udc60\udb7a\udc47\udbc3\ude1e\udb11\udf31\ud860\udc6c\uda6d\udf33\udb74\uddaa\ud8df\udeee",
        28, 96061, -465316419, 4013468900463077642L, -43831L, true, false, (char) 2727, (char) 50835,
        Double.longBitsToDouble(0x3fe51d5ce0e91fc9L), Double.longBitsToDouble(0x3fe3efbc2be2c152L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.BOBYQAOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 0, 7, "\udbff\udd5b\ud9f0\udffd\udab7\udec2\ud86c\udf3f\ud810\udc9d", "\u3678\u37ac\u6b2d\ucc4f\uc0f0\u7fe4\u79f8\u806b\u2a97\u4085\ubdb7\u433d\u3b8d\u09e4", "\udaa7\ude6e\udb7a\udc47\ud989\ude21\udb11\udec9\ud860\udc6c\uda6d\udf33\udb74\uddaa\ud8df\udeee",
        28, 72293, 719118269, 5231959926132039131L, -43831L, true, false, (char) 2727, (char) 50835,
        Double.longBitsToDouble(0x3fe51d5ce62b3ac9L), Double.longBitsToDouble(0x3fe3efbc2facc152L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 10, 3, "\udbff\udd5b\ud9f0\udffd\udab7\udec2\ud880\udc89\ud810\udc9d", "\u3678\u37ac\u3e78\u8374\uc0f0\u7fe4\u79f8\u806b\u2a97\u4085\ubdb7\u433d\u3b8d\u09e4", "\udaa3\udc60\udb7a\udc47\ud989\ude21\udb11\udf31\ud860\udc6c\uda6d\udf33\udb74\uddaa\ud8df\udeee",
        28, 72293, -465316419, 4013468899573882122L, -43831L, true, false, (char) 2727, (char) 50835,
        Double.longBitsToDouble(0x3fe51d5ce62b3ac9L), Double.longBitsToDouble(0x3fe3efbc2facc152L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 2, 6, "\udbff\uddcd\uda6b\ude6b\uda38\udfec\udbd0\ude57\ud916\udf39\uda8c\uded5", "\u0f60\u6ab7\ua86e\uc06a\u94b5\u263d\u806b\u2a97\u568a\ubcdb\ubb82\u8df2\u9ba9\ubb2e\u788c\u969c", "\udb11\udf31\ud860\udc6c\uda6d\udf33\udb74\uddaa\ud8df\udeee\udab2\udc7e\ud813\udea7\ud831\udf14\ud8dc\udd78\ud815\udec4\udb1b\udec7\u24b9\udb49\ude24\udb5f\udeae",
        10, 12731, -142278423, -4516505156975176734L, 38133L, true, false, (char) 51487, (char) 14720,
        Double.longBitsToDouble(0x3fc0b8113fdeded0L), Double.longBitsToDouble(0x3fe0695025b47596L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 8, 13, "\uda8a\udc25\udb13\udcf1\ud877\udca8\uda96\udc09\ud86b\udd8b\uda89\ude7f", "\u37ac\u6b2d", "\ud800\udccf\ud9c5\ude9a\udb3e\udc75\udaa4\udfd1\udbeb\udc84\udb66\uddbe\uda12\udf8a\ud870\udd02\ud9ca\ude9f\ud90a\uddf3\udb92\udcd0\udaa1\udee7\uda51\udff4",
        19, 20604, -447999489, -4438927637235302319L, 95225L, true, true, (char) 32886, (char) 39158,
        Double.longBitsToDouble(0x3fd0a37b2ef6c25aL), Double.longBitsToDouble(0x3fe9849094911a0cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 2, 6, 13, 6, "\udbff\uddcd\ud8b6\uddc0\ud877\udca8\udb3d\udffd\ud86b\udd8b\ud84b\udf01", "", "\000\ud8b3\udd5b",
        -5, 87872, 0, -2268459720837610535L, -57248L, true, true, (char) 37504, (char) 50637,
        Double.longBitsToDouble(0x3fa5cf4556b870a0L), Double.longBitsToDouble(0x3feff5b1d1ff0000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 13, 6, "\udbff\uddcd", "", "\u1f7f\000\udb19\uddde\ud965\udc5e\ud837\udc2d\ue003\udaea\udfd6\udb03\ude91\000\udb3e\udc75\ufe0c\udbeb\udd45",
        37, 3558, 1587092335, 4047794127843098675L, 64383L, true, false, (char) 7285, (char) 0,
        Double.longBitsToDouble(0x3e36a80000000000L), Double.longBitsToDouble(0x3fb4709958b0b768L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 10, 6, "\udbff\uddcd\ud9f0\udffd\ud877\udca8\uda96\udc09\ud86b\udd8b\uda89\ude7f", "\u37ac\u6b2d\ua86e\uc075\u94b5\u263d\u806b\u2a97\u4085", "\ud870\udd02\ud9ca\ude9f\ud8ce\udfaf\ud857\udc51\udaa3\udc60\ud83f\udd0a\uc912\udb11\udf31\ud860\udc6c\uda6d\udf33\udb74\uddaa\ud8df\udeee\ud80f\udc0c\ud9e1\udc6e\uda31\udc1a\ud8ff\udffb\ud815\udec4\udb1b\udec7\ud841\ude55\udb5e\udd7f\udb5f\udeae\u44b9\uda1b\udc82\ud802\udc69\ud966\udecb\udbde\ude03\udbad\udce2\udbfd\udfaf\uda95\udd62\udaaf\udd3d\uda1a\udf48\ud819\udeba\udb80\ude80\udbe8\udcfa\ud916\udf33\uda83\udde4\udb35\udfbd\udaa5\udd7e\udb80\udcc0\udb32\ude99",
        32, 61294, -2128286354, -3509537525463846995L, -70410L, true, false, (char) 25118, (char) 48665,
        Double.longBitsToDouble(0x3fed6c1fa0aa2d96L), Double.longBitsToDouble(0x3fdd84efd76c0bbaL)));
  }
  @Test
  public void test30() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test30() throws Throwable {
//     assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
//         Z.run(T, 2, 4, 6, 3, "\udbff\udd5b\ud9f0\udffd\uda5e\ude75\uda96\udc09\ud86b\ude02\uda89\ude7f\udbba\udeb1\udb19\ude47\ud965\udc5e\ud9e6\udde4\u5893\udbda\udf4e\ud800\udca6\ud9c8\udd9a\udbc2\udc77\ufe0c\udbeb\udd45\udac8\udeca\uda26\udc32\ud870\udd02\ud9ca\ude9f", "\u969c\u77c5\u03ab\ud464\u0259\u4aa6\ud37c\u860f", "\uda31\udc1a\ud8ff\udffb\udacd\uddd2\ud838\udd10\u24f2\udb49\ude24\udb5f\ude94\udb83\udfc0\uda18\udf82\ud802\udc69\uda0b\udf7e\ud8d2\uddfd\ud95e\udf91\ud9e5\udfeb\ud9f9\ude38\uda8c\uddee\uda77\udc58\udaf1\udecf\udb20\udeda\udbb7\udea7\udbc1\udfe2\ud852\uded5\u2d6c\ud854\udca6\ud9c3\udc20",
//         19, 18402, -1621374597, 5157008098423086823L, 33539L, false, false, (char) 4598, (char) 22324,
//         Double.longBitsToDouble(0x3fd735b198519674L), Double.longBitsToDouble(0x3fe62cca882c6f60L)));
//   }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.BOBYQAOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 0, 0, "", "\u8668", "\uda89\ude7f\udbba\udeb1\udb19\ude47D\000\ud881\ude3f\udaea\udfd6\ud9fc\udfae\ud979\udcc1\udb3e\udd20\ufe0c\u00d9",
        11, 3558, 1587092335, 4047794127845984013L, 64383L, true, false, (char) 47143, (char) 19409,
        Double.longBitsToDouble(0x3fd8dbd9e6a93434L), Double.longBitsToDouble(0x3fdf758c642c2ddaL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.direct.BOBYQAOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 6, "\udbff\udd5b\ud9f0\udffd\udab7\udeb1\uda96\udc09\ud86b\ude02", "\u0570\u37ac\uc0e4\ua86e\uc06a\u6b25", "\ufe0c\udbeb\udd45\udb66\uddbe\uda12\udf8a\ud870\udd02\ud9ca\ude9f\ud8bc\udd89\ud857\udc51\udaa3\udc60\udb9c\ude47\ud989\ude21\ud827\ude8b\udbec\udd1d\uda6d\udf33\udb74\uddaa\udb56\udfea\uda28\udd6e\ud857\udc23\uda20\ude10\u10d8\ud831\udec4\ud842\uddf3\u24f2\udb49\ude24\uda96\udda7\udb83\udfc0\ud91e\uddd1\ud827\udec9",
        47, 43562, 1291137708, 4757788993942797886L, 62369L, true, true, (char) 25319, (char) 12398,
        Double.longBitsToDouble(0x3fcd549b6e3ecbb4L), Double.longBitsToDouble(0x3fe41d664c353542L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=[D:[[0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226...\0121=[D:[[0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226, 0.2599780996925226...\012",
        Z.run(T, 2, 6, 6, 10, "\ud86b\udf33", "\ud649\u9cff\u8b6f\u3458\u8b33\u37ac\ub4f4", "\ud8ad\ude80\udae2\udf3b\udb3e\udc75\ufe0c\uda27\udf64\udb66\uddbe\ud96c\udeef\udb70\udc5a\uda5e\udfcd\uda59\ude79\uda70\ude08\ud8ff\udecb\udb7a\udc47",
        49, 20742, -447999489, -4438927637235302319L, -33081L, true, true, (char) 32886, (char) 57490,
        Double.longBitsToDouble(0x3fd0a37b2ef6c25aL), Double.longBitsToDouble(0x3feb49d6f4911a0cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 7, 7, 7, "\udbff\udd5b\ud9f0\udffd\udab7\udeb1\uda96\udc09\ud86b\ude02", "\u3678\u37ac\u3834\ua86e\uc06a\u94b5\u313d\u806b\u2a97\u4085\ubdb7\u433d\u3b8d\u09e4", "\udaa3\udc60\udb7a\udc47\ud989\ude21\udb11\udf31\ud860\udc6c\uda6d\udf33\udb74\uddaa\ud8df\udeee",
        28, 96061, -465316419, 4013468900463077642L, -43831L, true, false, (char) 2727, (char) 50835,
        Double.longBitsToDouble(0x3fe51d5ce0e91fc9L), Double.longBitsToDouble(0x3fe3efbc2be2c152L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.optimization.direct.BOBYQAOptimizer|prelim|[D,[D|new:org.apache.commons.math.optimization.direct.BOBYQAOptimizer:int",
    "M|org.apache.commons.math.optimization.direct.BOBYQAOptimizer|altmov|int,double|new:org.apache.commons.math.optimization.direct.BOBYQAOptimizer:int",
    "M|org.apache.commons.math.optimization.direct.BOBYQAOptimizer|bobyqa|[D,[D|new:org.apache.commons.math.optimization.direct.BOBYQAOptimizer:int",
    "M|org.apache.commons.math.optimization.direct.BOBYQAOptimizer|bobyqb|[D,[D|new:org.apache.commons.math.optimization.direct.BOBYQAOptimizer:int",
    "M|org.apache.commons.math.optimization.direct.BOBYQAOptimizer|caller|int|static",
    "M|org.apache.commons.math.optimization.direct.BOBYQAOptimizer|doOptimize||new:org.apache.commons.math.optimization.direct.BOBYQAOptimizer:int",
    "M|org.apache.commons.math.optimization.direct.BOBYQAOptimizer|fillNewArray|int,double|static",
    "M|org.apache.commons.math.optimization.direct.BOBYQAOptimizer|printMethod||static",
    "M|org.apache.commons.math.optimization.direct.BOBYQAOptimizer|printState|int|static",
    "M|org.apache.commons.math.optimization.direct.BOBYQAOptimizer|setup|[D,[D|new:org.apache.commons.math.optimization.direct.BOBYQAOptimizer:int",
    "M|org.apache.commons.math.optimization.direct.BOBYQAOptimizer|trsbox|double,org.apache.commons.math.linear.ArrayRealVector,org.apache.commons.math.linear.ArrayRealVector,org.apache.commons.math.linear.ArrayRealVector,org.apache.commons.math.linear.ArrayRealVector,org.apache.commons.math.linear.ArrayRealVector|new:org.apache.commons.math.optimization.direct.BOBYQAOptimizer:int",
    "M|org.apache.commons.math.optimization.direct.BOBYQAOptimizer|update|double,double,int|new:org.apache.commons.math.optimization.direct.BOBYQAOptimizer:int",
    "C|org.apache.commons.math.optimization.direct.BOBYQAOptimizer|<init>|int",
    "C|org.apache.commons.math.optimization.direct.BOBYQAOptimizer|<init>|int,double,double",
    "M|org.apache.commons.math.optimization.direct.BOBYQAOptimizer|prelim|[D,[D|new:org.apache.commons.math.optimization.direct.BOBYQAOptimizer:int",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
