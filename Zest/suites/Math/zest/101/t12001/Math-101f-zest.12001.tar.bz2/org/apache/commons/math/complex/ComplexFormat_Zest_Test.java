package org.apache.commons.math.complex;
import org.junit.Test;
import static org.junit.Assert.*;
public class ComplexFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:i |this=org.apache.commons.math.complex.ComplexFormat:@?\012",
        Z.run(T, 1, 9, 2, 8, "\udbc6\udf66\udaa8\udff3\ud87a\udcda\uda23\udccb", "\u0e7c\u9b70\u0a85\u93d6\ub30f\ubc5a\u19b2\u23f9\u2f9f", "\u95c5\udad3\uddda\ud9e7\udfa1",
        39, 44275, 1216650303, 843163914290067216L, -69458L, false, false, (char) 51817, (char) 21631,
        Double.longBitsToDouble(0x3facbff442934dd0L), Double.longBitsToDouble(0x3fe79b80b387d960L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 2, 8, "\udbc6\udf66\udaa8\udff3\ud87a\udcda\uda23\udccb", "\u0e7c\u9b70\u0a85\u93d6\ub30f\ubc5a\u19b2\u23f9\u2f9f", "\u95c5\udad3\uddda\ud9e7\udfa1",
        39, 96819, 1216650359, 843163914290067216L, -69458L, true, false, (char) 51817, (char) 21631,
        Double.longBitsToDouble(0x3facbff442934dd0L), Double.longBitsToDouble(0x3fe79b80b387d960L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=[Ljava.util.Locale;:[[nn, , ar_JO, bg, kea, nds, zu, am_ET, fr_DZ, ti_ET, bo_CN, hsb, qu_EC, ta_SG, lv, en_NU, en_MS, zh_SG_#Hans, en_GG, en_JM, vo, kkj, sv_SE, sr_ME, es_BO, dz_BT, mer, sah, en_ZM, fr_ML, br, ha_NG, ar_SA, fa_AF, dsb_DE, sk, os_GE, ml, en_MT, en_LR, ar_TD, en_GH, en_IL, cs, sv, el, tzm_MA, af, sw_UG, ...\012",
        Z.run(T, 1, 6, 2, 8, "\udbc6\udf66\udaa8\udff3\ud87a\udcda\uda23\udccb\udbd9\udeec\ud8c5\udc8f\udaea\udd61\ud9dd\udcd8", "\ub30f\ubc5a\u19b2\u23f9\u2f9f\u71a6\u835c\u4780\u69b3\u5ab9\u6f5d\uc85b\uc24b\u42fb\u6f94\uc3f2\u654a\u9981\u1050\u3e01\ubae0\u6902", "\ud9a3\uddfd\udaa3\udf34\ud88f\udc99\udb44\udd53\ud855\udc7e",
        54, 50504, 1219060006, 8192388184271147062L, -70721L, true, false, (char) 53985, (char) 19384,
        Double.longBitsToDouble(0x3feb14759d05d9c5L), Double.longBitsToDouble(0x3fcf814a071dba08L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 0, "\udbc6\udf66\udaa8\udff3\ud87a\udcda\uda23\udccb", "\u0e7c\ua537\u3d20\u0dea\ub30f\ubc5a\u19b2\u23f9\u2f9f", "",
        54, 57152, -1383955330, -6519697134892542605L, -100000L, false, true, (char) 36492, (char) 51817,
        Double.longBitsToDouble(0x3fe344b0bc397fe8L), Double.longBitsToDouble(0x3fa49a6eaf370160L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:i |this=org.apache.commons.math.complex.ComplexFormat:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 2, 13, "\udbc6\udee9\udaa8\udff3\ud87a\udcda\uda23\udccb\udbd9\udeec\uda7a\udeca", "\u0a85\u93d6\ub30f\ubc5a\u19b2\u23f9\u06b5\u8ec9\u23ed\u79de\u0c5b\u2841\u06e7\u94c1\u2f7f\u42fb\u6f94\uc3bd\u04ab\u98cd", "\uda15\udf56\ud83c\udd47\ud902\udc63\uda68\uddc8\ud249\ud8c4\udd52\ud9ea\uddc4\ud9e1\udfee\ud9f3\udf52\ud883\udda2\udbfa\ude41\ud9ec\ude81\ud98f\udf62\uda53\udef9\udb3e\ude43\ud829\ude12\udb11\uddfe\udba4\udc62\uda0c\udf31\udbb3\udf48\udbcc\udc40\ud81f\udd12\uda0a\udec4\udb3b\udd7c\udab8\udc2a",
        -5, 57553, -1529444920, -7956782258788185100L, 56409L, false, false, (char) 16214, (char) 61995,
        Double.longBitsToDouble(0x3fc7a3f581588344L), Double.longBitsToDouble(0x3fc1a27ac9d5cf04L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 2, 0, "\udbc6\udf66\udaa8\udff3\ud87a\udcda\uda23\udccb", "\000\u9b5b\000\000\ub30f\ubc5a\u19b2\u23f9\027", "\000",
        -5, 78072, -1517985126, -6370036613056783297L, -69458L, false, false, (char) 51817, (char) 21631,
        Double.longBitsToDouble(0x3facbff442934dd0L), Double.longBitsToDouble(0x3fe79b80b387d960L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 16, 2, 10, "\uf750\uda95\uddd5\udbaa\udcdd\uda23\udd7b\udbd9\udeec\ud8a8\udca0\udaff\udeab\ud9ec\uded8\ud840\udc6e\uda71\udfab\uda38\udda4\udbd3\udffb\udb1b\udd02\u8c53\ud964\udf34\ud9f1\udfde\ud92e\udc4f\ud9f1\ude3c", "\u1531\u361e\u0d9e\ubadb\ubd9a\u1dd1\u9524\u9981\u1050\u3e01\ubae0\u9d17\ucd2b\u547d\u8794\u4c78\u2c6a\u9bb1\uba5d\u9590\u1adc\u5884\u3bdc\u56f6\u068d\u511f\u10d3\u2585\u1369\ubc1e\u30a9\u2e56\u16bd\u570b\u7102\u4e60", "\udbdf\udc15\ud969\udf66\ud8d5\ude34\ud9de\udc75",
        33, 47604, 1876739150, -2338140287382137794L, -29195L, true, true, (char) 7160, (char) 2650,
        Double.longBitsToDouble(0x3fe7dd45e7fc8e17L), Double.longBitsToDouble(0x3fd75249891dfcc6L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.ComplexFormat:@?\012",
        Z.run(T, 1, 11, 2, 8, "\uda61\ude74\ud3fa\ud87a\udcda\uda19\uddcb\udbd9\udeec\ud8c5\udc8f\udaea\udd61\ud9dd\udcd8", "\ub30f\ubc5a\u19b2\u23f9\u2f9f\u71a6\u835c\u4780\u69b3\u5ab9", "\ud085\uda03\uddcd\ud9e2\udc62\udaec\udcd3\ud93f\ude5d",
        57, 31030, 2145959528, 3809311057681775657L, 60889L, false, true, (char) 18765, (char) 42609,
        Double.longBitsToDouble(0x3fdaf523dc64de32L), Double.longBitsToDouble(0x3fe4fcd736a89068L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.text.DecimalFormat:@? |this=org.apache.commons.math.complex.ComplexFormat:@?\012",
        Z.run(T, 1, 13, 2, 8, "\udbea\ude3b\udaa8\udff3\ud87a\udcda\uda23\udccb\udbd9\udeec\ud8c5\udc8f\udaea\udd61\ud9dd\udcd8\udafc\udd8c\uda96\udcc5\uda38\udda4\udbd3\udffb\udb1b\udd02\u8c53\uda1e\udd31\uda70\ude77\ud9b0\udd92\uda93\udebe\udb54\ude34", "\u94ac\uc231\u5263\ua8ba\u552f", "\ud8a3\udf98\udac5\uddf1\uda15\udf56\ue2c4\ud902\udc71\ud84e\ude3c\uda5b\udc46\udba0\ude62\udbc8\udf70\uda23\uddca\ud946\ude0e\uda63\udd2b\udad6\udf88\udbd0\udc64\u985d\udaa0\udf4d\udb73\udfd6\ud907\ude1d\ud8ab\udc86\ud9c2\udf87\uda05\udd5e\udab6\udc12\udbac\udf34\uda00\ude16\ud8fd\udd70\ud98e\udc31\udab3\udd4c\udbea\udd28\udb1c\udebc",
        48, 46749, -649528128, 7992498904344331673L, 64093L, true, true, (char) 32994, (char) 27236,
        Double.longBitsToDouble(0x3fe1cc2b8cced25fL), Double.longBitsToDouble(0x3fee423ec0a8fe4cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 9, 0, "\udb21\udeb3", "\ua5c3\u2cad\u56b0\u0e7c\000\u0c72\u93d6\ub30f\ubc5aG\000\000\000\000\u4780\u6fbf\000", "\ud085\000",
        -5, -1000, 1996488704, 41377646210187264L, -8807L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe62a51f7ea20a1L), Double.longBitsToDouble(0x3fb586499f723138L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:i |this=org.apache.commons.math.complex.ComplexFormat:@?\012",
        Z.run(T, 1, 9, 12, 8, "\udbc6\udf66\ud98e\udfc6\udbc5\udd3c\udb95\udfde", "\ud3f2\u374a\u0a85\u93d6\ub30f\ubc5a\u64c6\u2440\uc378", "\udb18\ude5d\udad3\uddda\ud95f\udedd",
        2, 44288, 1216650449, 843163914290067216L, 70660L, false, true, (char) 6243, (char) 21631,
        Double.longBitsToDouble(0x3facbff452934dd0L), Double.longBitsToDouble(0x3fefde85697cd960L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.text.DecimalFormat:@?\012",
        Z.run(T, 1, 8, 0, 9, "\uc6bc\udbed\uddcd\ud87a\udcda\uda23\udccb", "\u0e7c\u9b70\u0a85\u93d6\ub30f\ubc5a\u19b2\u23f9\u2f9f", "\u95c5\udad3\uddda\ud9e7\udfa1",
        2, 44275, 1216650303, 843163914290067216L, -69458L, false, false, (char) 51817, (char) 21631,
        Double.longBitsToDouble(0x3facbff442934dd0L), Double.longBitsToDouble(0x3fe79b80b387d960L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.text.DecimalFormat:@? |this=org.apache.commons.math.complex.ComplexFormat:@?\0121=java.text.DecimalFormat:@?\012",
        Z.run(T, 2, 13, 7, 13, "\udb89\udd67\ud872\udc8e\udb7c\udc3d\uda2c\udfa7", "\u0e7c\u9b70\u0a85\u93d6\ub30f\ubc5a\u39a6\u09af\u2c03", "\u95f6\udad3\uddda\ud9e7\udfa1",
        39, 44275, 1216650303, 843163914290067216L, -69458L, false, false, (char) 51817, (char) 21631,
        Double.longBitsToDouble(0x3facbff445034dd0L), Double.longBitsToDouble(0x3fe228ad1e0d2346L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 0, 2, 8, "\udbe3\udc50\udaa8\udff3\ud87a\udcda\uda23\udccb", "\u0e7c\u9b70\u0a85\uc8df\u3817\u91a0\ub1b5\u23f9\u2f9f", "\u95c5\udad3\uddda\ud9e7\udfa1\udbed\udd44",
        45, 51759, 196314494, -2400428426797110364L, 95625L, true, false, (char) 25831, (char) 44988,
        Double.longBitsToDouble(0x3fe16606a319ce66L), Double.longBitsToDouble(0x3fe6d2c110ffcb3cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.ComplexFormat:@?\0121=org.apache.commons.math.complex.ComplexFormat:@?\012",
        Z.run(T, 2, 12, 11, 14, "\udbc3\uddf5", "\u87c8\u4cf8\u5c27\ua77e\u9b70\u35c7\u4777\ub250\ubc5a\u19b2\u23f9\u2f9f\ub358\u4154\u943d\u62c7\u7518", "\ud106\udac9\udc90\ud991\udd19\udaec\udcd3\ud93f\ude5d\ud8ce\udf43\udb98\udf71\udaa0\udf67\ud941\udecc\ud9b9\udf4a\udb7b\udc39",
        26, 55624, -1537013381, -913649141912828811L, -7296L, true, false, (char) 10571, (char) 52261,
        Double.longBitsToDouble(0x3fe9526ec4dc5a29L), Double.longBitsToDouble(0x3fe8d41efb173d29L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 2, 8, "\udbc6\udf66\udaa8\udff3\uda87\udea0\uda23\udcca\udbb4\uddec\ud8c5\udc8f\udaea\udd61", "\u459e\u14cd\ubcd4", "\uda1e\udd31\uda70\ude77\ud965\udecd\ud80d\udf6a\udad3\uddda",
        30, 43874, 2103514483, 5225473502767973661L, 19279L, false, true, (char) 32243, (char) 51817,
        Double.longBitsToDouble(0x3fe344b0bc397fe8L), Double.longBitsToDouble(0x3fa49a6eaf370160L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.text.DecimalFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 8, "\udbc6\udf66\udaa8\udff3", "\u2ccd\u56b0\u17d6\u9b70\u0a85\u93d6\ub30f\ubc5a\u19b2", "\udbef\udf85\ud958\ude07",
        41, 85759, -1383955330, -6519696469877582477L, -36397L, false, true, (char) 32243, (char) 25369,
        Double.longBitsToDouble(0x3fe344b0bc397fe8L), Double.longBitsToDouble(0x3fa49a6eaf370160L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.text.DecimalFormat:@? |this=org.apache.commons.math.complex.ComplexFormat:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 2, 8, "\udad3\udd14\udaa8\udff3\ud87a\udcda\uda23\udccb\udbd9\udeec", "\u02d6\uc06e\ucb9e", "\udb1b\udd02\udb28\udd96\ud99d\ude82\udbc2\udff7\ud9b0\ude02\ud80c\udcc5\udad3\udda5\ud835\udf87\udbed\udcc6\udbc7\udcf3\u98f4\ud9f4\udce5\ud991\udd19",
        42, 88590, 1284712674, -7631492683333583256L, -35447L, false, false, (char) 25946, (char) 21778,
        Double.longBitsToDouble(0x3fd553c445f795beL), Double.longBitsToDouble(0x3fed9cb2aa508f1aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.ComplexFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 14, 6, "\udbc6\udf66\udaa8\udff3\uda28\udc64\udbf8\udc55\udb9c\uded3", "\u4b29\ua857\ucb47", "\ud9db\ude0e\udbb0\udf58\uda1e\udd8c\uda70\ude77\ud8a9\udeaf\uda34\udce3\udad3\uddce\ud9e7\udfa1\ud9d4\udc6f\ud94c\udfc0\udb90\udd95\ud9f9\udf3a\ud8b3\ude92\udae5\udcfe\udbdb\udd6b\ud938\ude2d",
        31, 65913, 886924345, 8076920234111417075L, -71276L, false, false, (char) 51907, (char) 913,
        Double.longBitsToDouble(0x3fecfe70b082d44aL), Double.longBitsToDouble(0x3fedc465a57ece23L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.text.DecimalFormat:@? |this=org.apache.commons.math.complex.ComplexFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 0, "\udbc6\udf4f\udaa8\udff3", "\u21e0\ua882\u4932\ub68f\u0e1f\u37fa", "\uda3c\uded8\uda78\udec8\ud848\ude7a\ud9fd\ude28\udbe8\udd0c\udb24\udca9\uda9c\udc5f\ub54a",
        25, 10060, 466828274, 6355967142405508464L, -2017L, true, false, (char) 37812, (char) 21680,
        Double.longBitsToDouble(0x3facbff44e334dd0L), Double.longBitsToDouble(0x3fce6e02c3385334L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 0, 0, 0, "\000\udaa8\udf97\u00d0", "\u56b0\u0e7c\ua537\u3d20\u0dea\ub30f\u397a\u626a\u23f9\u69de", "",
        54, 32872, -1383955330, -6519697133399370381L, -99971L, false, true, (char) 57007, (char) 52992,
        Double.longBitsToDouble(0x3fe603be60000093L), Double.longBitsToDouble(0x3f42c010e4000000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.ComplexFormat:@?\0121=org.apache.commons.math.complex.ComplexFormat:@?\012",
        Z.run(T, 2, 12, 12, 13, "\udbc6\udee9\udaa8\udff3\ud95d\udf69\ud958\udc81\uda0a\udcad\uda7a\udeca", "\u0aa3\u93d6\ub30f\ubc5a\u19b2\u23f9\u06b5\u8ec9\u23ed\u79de\ubcb8\u9cff\u0768\u94c1\u2f7f\ubbfa\u6f94\uc3bd\u04ab\u98cd", "\uda15\udf56\ud83c\udd47\ud902\udc63\uda68\uddc8\ud249\ud8c4\udd52\ud9ea\uddc4\ud9e1\udfee\ud9f3\udf52\u2ce7\uda4f\udc3c\ud915\ude49\udaeb\udd82\ud915\udd64\ud878\udf52\ud829\udddb\udb11\uddfe\udba4\udc62\udbd3\udc53\udbb3\udf48\ud97e\udfda\ud81f\udd12\uda0a\udec4\udb3b\udd7c\udab8\udc2a",
        -5, 57553, -587627064, -7976294811432072204L, 56409L, false, true, (char) 53132, (char) 11806,
        Double.longBitsToDouble(0x3fc7a3f581588344L), Double.longBitsToDouble(0x3fc1a27ac9d5cf04L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:i |this=org.apache.commons.math.complex.ComplexFormat:@?\0121=[Ljava.util.Locale;:[[nn, , ar_JO, bg, kea, nds, zu, am_ET, fr_DZ, ti_ET, bo_CN, hsb, qu_EC, ta_SG, lv, en_NU, en_MS, zh_SG_#Hans, en_GG, en_JM, vo, kkj, sv_SE, sr_ME, es_BO, dz_BT, mer, sah, en_ZM, fr_ML, br, ha_NG, ar_SA, fa_AF, dsb_DE, sk, os_GE, ml, en_MT, en_LR, ar_TD, en_GH, en_IL, cs, sv, el, tzm_MA, af, sw_UG, ...\012",
        Z.run(T, 2, 9, 6, 11, "\udbc6\udee9\udaa8\udff3\ud87a\udcda\uda23\udccb\udbd9\udeec\uda7a\udeca", "\u0a85\u449b\u570b\u5abc\u1a56\u23f9\u06b5\u8ec9\u23ed\u79de\u0c5b\u2841\ucd23\u94c1\u147e\u7cf6\u6fd1\uc3bd\u04ab\u98cd", "\uda15\udf56\ud83c\udd72\udbb1\udcbb\ud8da\udd96\ud249\ud8c4\udd52\ud9ea\uddc4\uda0c\udf4f\uda1a\udd0e\ud883\udda2\udbfa\ude85\ud9bf\udf69\ud8e2\udf55\ud9b0\uddf3\udb3e\ude43\ud829\ude12\udb11\uddfe\ud966\udfa3\ud9e6\udee9\ud80f\udc36\ud8a2\udebf\ud930\udd1b\u5b0e\udb3b\udd7c\udab8\udc2a",
        16, 77618, -1537546015, -7956782258788185100L, 56409L, false, false, (char) 16214, (char) 61995,
        Double.longBitsToDouble(0x3fc7a3f593db3744L), Double.longBitsToDouble(0x3fc1bcc109d5cf04L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:i |this=org.apache.commons.math.complex.ComplexFormat:@?\0121=java.lang.String:i |this=org.apache.commons.math.complex.ComplexFormat:@?\012",
        Z.run(T, 2, 9, 9, 13, "\udbc6\udee9\udaa8\udff3\ud87a\udcda\uda23\udccb\udbd9\udeec\uda7a\udeca", "\u0a85\u93d6\ub30f\ubc5a\u19b2\u23f9\u06b5\u8ec9\u23ed\u79de\u0c5b\u2841\u06e7\u94c1\u2f7f\u42fb\u6f94\uc3bd\u9a82\u1158", "\uda15\udf56\ud83c\udd47\ud902\udc63\uda68\uddc8\ud249\ud8c4\udd52\ud9ea\uddc4\ud9e1\udfee\ud9f3\udf52\ud883\udda2\udbfa\ude41\ud9ec\ude81\ud98f\udf62\uda53\udef9\udb3e\ude43\ud829\ude12\udb11\uddfe\ud975\ude2a\ud9fb\ude93\udbb3\udf48\udbcc\udc40\ud81f\udd12\uda0a\udec4\udb3b\udd7c\udab8\udc2a",
        -5, 57553, -1529444920, -7956782258788185100L, 56409L, false, false, (char) 16214, (char) 61995,
        Double.longBitsToDouble(0x3fc7a3f581588344L), Double.longBitsToDouble(0x3fc1a27ac9d5cf04L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:i |this=org.apache.commons.math.complex.ComplexFormat:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 4, 13, "\udbc6\udee9\udaa8\udff3\ud87a\udcda\uda23\udccb\ubc7e\uda7a\udeca", "\u0a85\u93d6\ub30f\ubc5a\u19b2\u23f9\u06b5\u8ec9\u23ed\u79de\u0c5b\u2841\u06e7\u94c1\u2f7f\u42fb\u6f94\uc3bd\u0faf\u98cd", "\udba8\udeff\ud838\udcc9\ud8ae\udc62\uf442\u61aa\ud8c4\udd52\ud9ea\uddc4\ud9e1\udfee\ud9f3\udf52\ud883\udda2\udbfa\ude41\ud9ec\ude81\ud98f\udf62\uda53\udef9\udbce\udd26\uda24\udc29\udb11\ude07\udba4\udc62\uda0c\udf31\udbb3\udf48\udbcc\udc40\ud81f\udd12\uda0a\udec4\udb3b\udd7c\udab8\udc2a",
        -5, 57553, -1467972152, -7956782258788185100L, -9127L, false, true, (char) 16168, (char) 12201,
        Double.longBitsToDouble(0x3fe5e8fd605620d1L), Double.longBitsToDouble(0x3fd9074f04366efeL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.text.DecimalFormat:@? |this=org.apache.commons.math.complex.ComplexFormat:@?\0121=java.text.DecimalFormat:@? |this=org.apache.commons.math.complex.ComplexFormat:@?\012",
        Z.run(T, 2, 13, 13, 11, "\udbc6\udee9\udaa8\udff3\ud86a\udcd2\uda23\udccb", "\u0a0b\uadd3\u131c\u93d6\ub30f\ubc5a\u19b2\u23f9\u06b5", "\udb65\udf85\udabc\udc82\ud823\uddf4\ud8cf\udeb5\ud91a\udc52\udadd\uddf4\uda03\uddcd",
        34, 17199, 950671023, 5517778211396713686L, -8807L, true, false, (char) 2497, (char) 25831,
        Double.longBitsToDouble(0x3fd5f6a290a0a6c6L), Double.longBitsToDouble(0x3fe5ac4af442f00fL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 16, 2, 0, "\udbcd\udff9\uaad5\ud87a\udccf\uda23\udccb\udbd9\udeec\udb8b\udc52", "\000\u8840\u748b\u2896", "\ud977\udc12\ud93f\udd81\ud8ec\udda3;\u00f3",
        42, 43874, -1483139725, 5225473262863676189L, -49208L, true, false, (char) 12550, (char) 43785,
        Double.longBitsToDouble(0x3fec3fdb04b1f952L), Double.longBitsToDouble(0x3fe99f612baa4170L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 16, 2, 10, "\uf750", "\ua673\u4f4b\uc3d3\u63c6", "\ud86f\udf89\uda38\udcff\udbd3\udffb\ud8fc\udea7\uda01\ude1d\ud964\udf34\ud9f1\udfde\ud92e\udc4f\ud9f1\ude3c\ud989\udc86\ud836\udcb7\ud88b\udd1e\udab7\uddec\ufbf1\ud8d0\udd11\ud9ce\udef6\ud94d\udd77\uda7c\udc92\uda93\udfd1",
        36, 11528, 886924345, 8081964793467124467L, -14553L, true, false, (char) 45030, (char) 15328,
        Double.longBitsToDouble(0x3fc3da3e6b48d364L), Double.longBitsToDouble(0x3fc9eb7c39c18e68L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 0, 9, 0, "", "\u00d0", "\ud8c5\udc8f",
        20, -1000, 855638016, 120259084288L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e48640000000000L), Double.longBitsToDouble(0x3fedffd378000000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.ComplexFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 5, 8, "\udbe3\udcb8\udaa8\udff3\ud9ff\udfdc\udaaa\udf5c", "\u0e7c\u9b70\u0417\u2b8e\u3866\u91a0\ub1b5\u23f9", "\ud9e0\udeb0\ud9ac\udcfe\udb4b\udd6a\ud9e7\udfa1\udbed\udd44",
        45, 51759, 196314494, -2400428426797110364L, 95625L, true, false, (char) 25831, (char) 44988,
        Double.longBitsToDouble(0x3fe16606a319ce66L), Double.longBitsToDouble(0x3fe75864c8ffcb3cL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.ComplexFormat:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 4, 14, "\udad3\udd14\udaa8\udff3\ud87a\udcda\uda31\udecb\udbd9\udeec", "\u775d\uc06e\ucb9e\ucda4\ubbf9\u19b2\u3412\ubb33\ub20f\u83cc\u0281\u697e", "\udae0\udecf\u98f4\ud9f4\udce5\ud991\udd19\udaec\udcd3\u2904\uda34\udc93\uda75\udda2\udac6\udf33\uda15\udf55\ud809\udead\ud997\ude93\ud8cc\udc70\uda85\udfdf\ud9c8\ude33\udb79\udfea\ud9e2\udfd2\udb09\udcc7\uda35\ude9e\ud9c1\uddfa",
        -2, 56939, -879627621, 7401987088250076072L, -38779L, false, true, (char) 15836, (char) 7743,
        Double.longBitsToDouble(0x3fd6931075ae1754L), Double.longBitsToDouble(0x3fe9325c37a6e5f3L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=[Ljava.util.Locale;:[[nn, , ar_JO, bg, kea, nds, zu, am_ET, fr_DZ, ti_ET, bo_CN, hsb, qu_EC, ta_SG, lv, en_NU, en_MS, zh_SG_#Hans, en_GG, en_JM, vo, kkj, sv_SE, sr_ME, es_BO, dz_BT, mer, sah, en_ZM, fr_ML, br, ha_NG, ar_SA, fa_AF, dsb_DE, sk, os_GE, ml, en_MT, en_LR, ar_TD, en_GH, en_IL, cs, sv, el, tzm_MA, af, sw_UG, ...\0121=[Ljava.util.Locale;:[[nn, , ar_JO, bg, kea, nds, zu, am_ET, fr_DZ, ti_ET, bo_CN, hsb, qu_EC, ta_SG, lv, en_NU, en_MS, zh_SG_#Hans, en_GG, en_JM, vo, kkj, sv_SE, sr_ME, es_BO, dz_BT, mer, sah, en_ZM, fr_ML, br, ha_NG, ar_SA, fa_AF, dsb_DE, sk, os_GE, ml, en_MT, en_LR, ar_TD, en_GH, en_IL, cs, sv, el, tzm_MA, af, sw_UG, ...\012",
        Z.run(T, 2, 6, 6, 4, "\uda64\ude1e\u569f\ud87a\udcda\udb03\udfd0\ud8d4\ude32", "\uba24\u4d38\uc1a9", "\udb05\uddac\uda18\udc0e\ud99d\ude6a\udbc2\udff7\ud9b0\ude02\ud80c\udcc5",
        21, 34614, -1517985252, -606836464906115922L, -69458L, false, false, (char) 51659, (char) 30797,
        Double.longBitsToDouble(0x3faca5ad42934dd0L), Double.longBitsToDouble(0x3fca85560e1f674cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 0, 0, 15, "\034\udaa8\udf97\u00d0", "\u56b0\u0e7c\ua537\u3d20\u0dea\u8522\u397a\u626a\u7bf8\u69e9", "",
        54, 32872, -1383955330, -6519697133399370381L, -99971L, false, true, (char) 57007, (char) 52992,
        Double.longBitsToDouble(0x3fe011ce60000093L), Double.longBitsToDouble(0x3f42c010e4000000L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 0, 0, 16, "\034", "\u1fb7\u2cad\u56b0\u0e7c\ua537\u3d20\u0dea\u8522\u397a\uc13a\u3e75\u69e9\000\000\u70e3\u50e3\u9513", "\udbad\udda5\ue314\ud991\udd09\uda61\udd2f\udbee\ude67\uda97\ude0a\udb40\uddc0\000\ud9bf\udecb",
        48, 14416, -476028036, 2628914729275664486L, 95094L, true, false, (char) 55447, (char) 13047,
        Double.longBitsToDouble(0x3f85cd96405d6580L), Double.longBitsToDouble(0x3fd6f9aeb71c18e6L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.ComplexFormat:@?\012",
        Z.run(T, 1, 0, 9, 0, "2", "\u1fb7\u2cad\u56b0\u7225\ua537\u3d20\ua653\u845f\u397a\uc13a\uac74\u69e9\000\uc86c\u1999\ubee7\u1513", "\udbad\udda5\ue314\ud991\udd09\uda61\udd2f\udbee\ude67\uda97\ude0a\uda81\udc36\000\ud9bf\udecb",
        24, 87981, 531640180, 2628915476599973990L, 28161L, true, false, (char) 55447, (char) 13047,
        Double.longBitsToDouble(0x3f85cd96405d6580L), Double.longBitsToDouble(0x3fd6f9aeb71c18e6L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 0, 9, 0, "2\udaa8\udf97", "\u2c8f\u56b0\u7225\ua537\u3d20\u0d53\u845f\u397a\uc13a\uac74\u69e9\000\uc86c\u1999", "\ud895\udd43\ud8a5\udc50\udbad\udda5\ue314\ud828\udcc8\uda0c\udde2\ud846\uddd5\ud93a\uddc7\ud94a\udf65\ud802\udd92\ud9bf\udecb\ud861\udfd5\u83d6\ud80a\udd52\ud980\uded9\uda2e\udd48\ud857\uddb0\udb0d\udf43\u9f0a\udb3a\udc5d",
        4, 81858, -1695846143, 897172276509973390L, 49503L, false, false, (char) 64569, (char) 6409,
        Double.longBitsToDouble(0x3f87e7d9acf26900L), Double.longBitsToDouble(0x3fcfa8deb98e51c8L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:i |this=org.apache.commons.math.complex.ComplexFormat:@?\012",
        Z.run(T, 1, 9, 2, 8, "\udbc6\udf66\udb85\ude21\ud87a\udcda\uda23\udccb", "\u0e7c\u9b70\u0a85\u93d6\ub30f\ubc5a\u19b2\u23f9\u2f9f", "\u95c5\udad3\uddda\uda8e\ude59",
        39, 44275, 1216650303, 843163914290067216L, -69458L, false, false, (char) 51817, (char) 21631,
        Double.longBitsToDouble(0x3facbff44a488dd0L), Double.longBitsToDouble(0x3fd41351670f72fcL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 0, 0, 15, "0\udaa8\udf97\u00d0\uda01\udebf\udbd9\udeec\ud8c5\udc8f\udaea\udd61\ud9b3\udc23\ud816\udf0a\ud8cd\udd26\udb31\udfc1\u397a\udaf7\uddbb\udaa7\uddf5\udbe3\udc32\000\000\ud9cb\udfa5\ud85d\ude0e\ud9e7\udfa1\udbed\udcaa\u5d7c\000\035\ud991\udd09\uda61\udd2f\udbee\ude67\uda97\ude0a\udb40\uddc0\000\ud993\uddb6\udb13\udfaf\uda83\udc82", "\u077d\u77da\u3ea5\u9efe\ud2d2\ub61e", "\udb7d\udc02\ud82b\udecb\ud9d9\udf4c",
        3, 26473, -1708070179, -2535873328555635295L, -32645L, true, false, (char) 62321, (char) 37298,
        Double.longBitsToDouble(0x3fa3c162d4c946c0L), Double.longBitsToDouble(0x3fe508f5f42b8f71L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 0, 11, 16, "E", "\u1fb7\u2cad\u56b0\u0e7c\ua537\u3d20\u0dea\u8522\u397a\uc13a\u3e75\u69e9\u9000\000\u70e3\u50e3\u9513", "\udbad\udda5\ud963\udccd\ud991\udd09\uda61\udd2f\udbee\ude67\uda97\ude0a\udb40\uddc0\000\ud9bf\udecb",
        48, 14416, -476028036, 2628914729275664526L, 95094L, true, false, (char) 55447, (char) 13047,
        Double.longBitsToDouble(0x3f85cd96405d6580L), Double.longBitsToDouble(0x3fd6f9aeb71c18e6L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 0, 0, 6, "-", "\u1fb7\u67e5\u56b0\u7225\ua537\u3eea\u4200\u3a21\u01b6\uc13a\u6c48\u69e9\u7c5e\ud30d\ubef9\u3e68\u203e\u317a\u5125\ud078\u0315\u6f84\u484c\ubb80\u46b0\u1d1d\u179b\u6b85\ube80", "\udb22\udfca\uda2e\udd48\uda2d\uddfb\udb37\udef8\ud9ba\udcf2\ud932\udd5a\udafa\udfd0\u3af8\udbf9\udfef\ud98a\ude09",
        23, 42425, -1878346746, -199086355062589853L, -90489L, true, false, (char) 2127, (char) 7925,
        Double.longBitsToDouble(0x3fc8246667e88534L), Double.longBitsToDouble(0x3fedf30a5be38da1L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 0, 11, 16, "E\udaa8\udf97\u00d0\uda01\udebf\udbd9\udeec\ud8c5\udc8f\udaea\udd61\ud9b3\udc23\ud816\udf0a", "\u397a\uc13a", "\u9000\000",
        54, 32872, -784432002, -2998570832774955810L, -23006L, false, true, (char) 57007, (char) 52992,
        Double.longBitsToDouble(0x3fe011ce60000093L), Double.longBitsToDouble(0x3f42c010e4000000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String:i |this=org.apache.commons.math.complex.ComplexFormat:@?\012",
        Z.run(T, 1, 9, 2, 8, "\udae1\udd5c", "\ua5c3\u2cad\u56b0\u0e7c\u9b70\u0a85\u136d\u18e2\ubc5a\u1434\u23f9\u2f9f\u71a6\u835c\u4780\u69b3\u5ab9", "\ud085\uda03\uddcd\ud991\udd19\udaec\udcd3\ud93f\ude5d",
        57, 1854, 902066953, 1960926244394933333L, 90074L, false, false, (char) 3228, (char) 54700,
        Double.longBitsToDouble(0x3fe4019c432ca229L), Double.longBitsToDouble(0x3fe5fec1a3ece470L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 0, 7, 7, ".\ud877\udf5e\ubf95\uda01\udebf\ud861\uddb0\ud8b3\udca4\ud844\udc0e\ud92e\udd2a\ud816\udf0a", "\u397a\u626a\u7bf8\u69e9\u1d85\ucf34", "\ud940\udd8e\udbed\udcaa\u5d7c\u6759\035\ud991\udd09\ud947\udd02",
        36, 43426, -1778343936, -158768071L, 87740L, true, false, (char) 55544, (char) 12457,
        Double.longBitsToDouble(0x3fe484fffb46c955L), Double.longBitsToDouble(0x3fd603d0e033cf04L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 0, 14, 3, ",\udaa8\udf97\udb40\ude90\ud9cc\udc01\udacf\udde8\ud90c\udd56\ud880\udcc9", "\ub832\u3e02\u2bae\u4485\ud620\u62e3", "\ud86b\udfc3\ud9ec\ude92\uda43\uddfe",
        -5, 64738, 35716750, 3940259295222822865L, -58272L, false, true, (char) 129, (char) 38400,
        Double.longBitsToDouble(0x3f99000067d6cc60L), Double.longBitsToDouble(0x3fee27b288d51b91L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.ComplexFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 15, 5, "2", "\u677c\u2cad\u56b0\u7225\ua537\u3d20\ua653\u82c3\u397a\uc13a\uac74\u69e9\000\uc86c\u1999\ubee7\u944d", "\udbad\udda5\ue314\ud991\udd09\uda61\udd2f\udbee\ude67\uda97\ude0a\uda81\udc36\000",
        -5, 55659, 374798981, 2924577183652757445L, -12354L, true, true, (char) 2721, (char) 55447,
        Double.longBitsToDouble(0x3fd4d65aa879b796L), Double.longBitsToDouble(0x3fd017596adf35d6L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.text.ParseException\012",
        Z.run(T, 1, 0, 7, 7, ".\000\ubf95\uda01\udebf\ud861\uddb0\ud8b3\udca4\ud844\udc0e\ud92e\udd2a\ud816\udf0a", "\u397a\u626a\u7bf8\u69e9\u1d85\ucf34", "\ud940\udd8e\udbed\udcaa\u5d7c\u6759\035\ud991\udd09\000",
        -5, -1000, -1778384896, -158768071L, 87740L, true, false, (char) 55544, (char) 22184,
        Double.longBitsToDouble(0x3fe484fffb46c955L), Double.longBitsToDouble(0x3fd603d0e033cf04L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.ComplexFormat:@?\0121=org.apache.commons.math.complex.ComplexFormat:@?\012",
        Z.run(T, 2, 16, 12, 9, "2", "\u677c\u2cad\u56b0\u7225\ua537\u3d20\ua653\u259d\u33e4\u2da6\u4a62\u69e9\000\uc86c\u1999\ud520\u3bd6", "\ud915\uddee\uaf3d\ud991\udd09\udade\udfae\ud869\ude60\ud887\ude02",
        58, -1000, 732259385, -7287890951730169211L, 14629L, false, true, (char) 12465, (char) 55769,
        Double.longBitsToDouble(0x3fc1e842498398dcL), Double.longBitsToDouble(0x3fd4d65aa879b796L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.ComplexFormat:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.ComplexFormat:@?\012",
        Z.run(T, 2, 16, 0, 2, "2", "\ua872\u2cca\u56b0\u7225", "\ud9dd\udf8e\udb27\udfed\ud90a\udd80",
        35, 91692, 335206178, 1382205128L, -19475L, false, false, (char) 53015, (char) 4189,
        Double.longBitsToDouble(0x3fe05661073ded32L), Double.longBitsToDouble(0x3fe804880000deafL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.complex.ComplexFormat|parse|java.lang.String|new:org.apache.commons.math.complex.ComplexFormat:",
    "M|org.apache.commons.math.complex.ComplexFormat|parse|java.lang.String,java.text.ParsePosition|new:org.apache.commons.math.complex.ComplexFormat:",
    "M|org.apache.commons.math.complex.ComplexFormat|format|java.lang.Object,java.lang.StringBuffer,java.text.FieldPosition|new:org.apache.commons.math.complex.ComplexFormat:",
    "M|org.apache.commons.math.complex.ComplexFormat|format|org.apache.commons.math.complex.Complex,java.lang.StringBuffer,java.text.FieldPosition|new:org.apache.commons.math.complex.ComplexFormat:",
    "M|org.apache.commons.math.complex.ComplexFormat|formatComplex|org.apache.commons.math.complex.Complex|static",
    "M|org.apache.commons.math.complex.ComplexFormat|formatDouble|double,java.text.NumberFormat,java.lang.StringBuffer,java.text.FieldPosition|new:org.apache.commons.math.complex.ComplexFormat:",
    "M|org.apache.commons.math.complex.ComplexFormat|getAvailableLocales||static",
    "M|org.apache.commons.math.complex.ComplexFormat|getDefaultNumberFormat||static",
    "M|org.apache.commons.math.complex.ComplexFormat|getDefaultNumberFormat|java.util.Locale|static",
    "M|org.apache.commons.math.complex.ComplexFormat|getImaginaryCharacter||new:org.apache.commons.math.complex.ComplexFormat:",
    "M|org.apache.commons.math.complex.ComplexFormat|getImaginaryFormat||new:org.apache.commons.math.complex.ComplexFormat:",
    "M|org.apache.commons.math.complex.ComplexFormat|getInstance||static",
    "M|org.apache.commons.math.complex.ComplexFormat|getInstance|java.util.Locale|static",
    "M|org.apache.commons.math.complex.ComplexFormat|getRealFormat||new:org.apache.commons.math.complex.ComplexFormat:",
    "M|org.apache.commons.math.complex.ComplexFormat|parseAndIgnoreWhitespace|java.lang.String,java.text.ParsePosition|new:org.apache.commons.math.complex.ComplexFormat:",
    "M|org.apache.commons.math.complex.ComplexFormat|parseNextCharacter|java.lang.String,java.text.ParsePosition|new:org.apache.commons.math.complex.ComplexFormat:",
    "M|org.apache.commons.math.complex.ComplexFormat|parse|java.lang.String|new:org.apache.commons.math.complex.ComplexFormat:",
    "M|org.apache.commons.math.complex.ComplexFormat|parse|java.lang.String,java.text.ParsePosition|new:org.apache.commons.math.complex.ComplexFormat:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
