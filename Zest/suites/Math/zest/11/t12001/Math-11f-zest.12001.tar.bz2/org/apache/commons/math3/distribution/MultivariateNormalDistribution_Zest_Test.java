package org.apache.commons.math3.distribution;
import org.junit.Test;
import static org.junit.Assert.*;
public class MultivariateNormalDistribution_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.DimensionMismatchException\012",
        Z.run(T, 1, 7, 3, 0, "\u5af8\ud8d2\udef4\uda0e\udcf1\u1a85\uda7a\udf17\ud8ca\udf6e\ud9a7\udfbf\udb86\udfaa\udbb5\udd40\udaf8\ude22\ud95c\udfc3", "\u582b\u28ca\u2141\uc0e4\u3361\uc275\u6563\u69ea\ua56e\u8b18\uce20\uc5b8\u750e\u77e2\u7eed\ub0dd\uaf08\u51ec\u976a\u5f03", "\udb82\udc12\ud87b\udc8c\ud99b\udd91",
        37, 18157, -1190053896, 8024134568183660386L, -20195L, true, false, (char) 10277, (char) 37558,
        Double.longBitsToDouble(0x3feffae52c515e2cL), Double.longBitsToDouble(0x3fded6835306e05eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.DimensionMismatchException\012",
        Z.run(T, 1, 7, 3, 0, "\u5af8\ud8d2\udef4\uda0e\udcf1\u1a85\uda7a\udf17\ud8ca\udf6e\ud9a7\udfbf\udb86\udfaa\udbb5\udd40\udaf8\ude22\ud95c\udfc3", "\u582b\u28ca\u2141\uc0e4\u3361\uc275\u6563\u69ea\ua56e\u8b18\uce20\uc5b8\u750e\u77e2\u7eed\ub0dd\uaf08\u7d2e\u976a\u5f03", "\udb82\udc12\ud87b\udc8c\ud99b\udd91",
        37, 18157, -1190053896, 8024134568183660386L, -20195L, true, false, (char) 10277, (char) 37558,
        Double.longBitsToDouble(0x3feffae5288d0a2cL), Double.longBitsToDouble(0x3fbcdc5ecc1b8510L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 3, 0, "\u5af8\ud8d2\udef4\ud952\uddd8\uda27\udf30\udb94\udf71\ud8c2\udc6e\ud997\uddbf\udb86\udfaa\udbb5\udd40\udaf8\ude22\ud95c\udfc3", "\u58d0\u28ca\u2141\uc0e4\u3361\uc275\u6563\u69ea\u83de\u5c2d\uce20\u2c89\uad47\u77a0\u7eed\u2381\u4c90\ub6dc\u2fe8\u5f03", "\udb82\udc12\ud87b\udc8c\ud9d2\ude5b",
        5, 87322, -1827418691, 8024134477989347170L, -20195L, true, false, (char) 10277, (char) 37558,
        Double.longBitsToDouble(0x3feffae52c515e2cL), Double.longBitsToDouble(0x3fded68359881d8eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.DimensionMismatchException\012",
        Z.run(T, 1, 7, 3, 0, "\u5af8\ud8f1\udff4\uda0e\udcf1\udbe4\ude8a\ud8ac\udcaf\ud9b6\uddeb\udabc\udd77\ud9ca\udea0\udbb5\udd40\udaf8\ude22\ud95c\udfc3\ud82c\udf51", "\u28ca\ucc8c\u6245\u5cda\u165e", "\uda07\udf6f\uc12d\udbd8\udda8\ud9c3\udf05\ubb09\udb49\udd72",
        18, 4180, 772629129, -4831364244132531230L, -78530L, true, true, (char) 31658, (char) 49495,
        Double.longBitsToDouble(0x3feb1423a8782514L), Double.longBitsToDouble(0x3fc5aa4a7fe3ef50L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.DimensionMismatchException\012",
        Z.run(T, 1, 5, 3, 1, "\u5af8\ud8d2\udec4\uda0e\udcf1\u1a85\uda7a\udf17\ud8ca\udf6e\ud9a7\udfbf\udb86\udfaa\udbb5\udd40\udaf8\ude22\ud8e7\ude69\ud942\udff9\ud98d\udfdb\ud97d\udc96\ud9b5\udc97\uda6b\udfd6\ud8b8\udfcd\udad7\ude31\ud850\udf3e\udad1\udcb7\udb16\udef9\ud8e9\udf37\uc12d", "\ud042\u77e2\u6738\ub0dd\uaf08\uca2d", "\ud8c3\ude8d\udbe8\uddd5\ud8d6\udf67\ud8ef\ude93\ud9a3\udea1\u4552\ud816\udc6e\uda94\udf64\udbfe\ude6f\udb90\udf89\ud920\udf47\udb71\udc8d\uc4b4\ud9a2\ude37\udab9\udf5e\udaf2\udd8b\ud884\ude75\ud9dc\udc89\udb58\udf09\uda87\udcb4\ud96a\udd5e\uda9d\udce0\ud941\udcd1\udaca\udc99\ud9c1\udf4b\ud84d\uddc6\udb8a\udf6c\udb68\udd38\udb55\uddd7\udbac\ude0b\udb8c\udf31\ud8ec\udce3\ud839\udd69\ud8f0\udda0\udba8\ude57\udaa6\udc55\uda2a\uddcd\udb58\udee4\udbc7\udde5\ud9f1\udc1b\ud8d3\ude67\ud89e\udcf1\udab7\udfa0",
        11, 43713, 847328705, 5292290851618805357L, 57149L, true, true, (char) 57036, (char) 47525,
        Double.longBitsToDouble(0x3fee24a2014e340dL), Double.longBitsToDouble(0x3fdc84bc0aee67d0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 7, 4, "\u5af8\ud8d2\udef4\ud990\udc42\u1a85\uda7a\udf17\ud8ca\udf6e\ud9a7\udfbf\udb86\udfaa\udbb5\udd40\udaf8\udc22\ud9cc\udf5b", "\u4c73\u2fbe\ud0ee\u91fe\u223e\u4512\u8336\u69ea\ua4ab\u4b18\uce20\uc5b8\u750e\u41f0\u6414\u45a5\uaf08\u51ec\u976a\u1dc3\u29d3\u93eb\u1fa9\ucdc7\u8453\u311f\u08bb\ucc03\ua698\u17f7\ud0ca\u9a5d\u0224\u9686\ua176", "\ud9ea\udc89\ud825\udd3d",
        35, 13610, 720616617, -5965927903090071186L, 78568L, false, true, (char) 41466, (char) 52315,
        Double.longBitsToDouble(0x3fd46b99e207609aL), Double.longBitsToDouble(0x3fd71773e6bf00b6L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.DimensionMismatchException\012",
        Z.run(T, 1, 2, 3, 0, "\u5af8\ud8d2\udef4\uda0e\udcf1\u1a85\uda7a\udf17\ud8ca\udf6e\ud9a7\udfbf\udb86\udfaa\udbb5\udd40\udaf8\ude22\ud95c\udfc3", "\u582b\u28ca\u2141\uc0e4\u3361\uc275\u6563\u69ea\ua56e\u7e49\u69f4\ua124\ub748\u7651\u2e0a\ua416\uaf08\u51ec\u66d2\uc015", "\udb82\udc12\ud87b\udc8c\ud99b\udd91\u4552\ud816\udc6e\udb70\udfc9\udbfe\ude6f\udb90\udf89",
        23, 52957, 1268914239, 6975473854619922921L, 89L, true, true, (char) 39346, (char) 36118,
        Double.longBitsToDouble(0x3fe2d29393b88d4fL), Double.longBitsToDouble(0x3fec35413a3aad13L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.DimensionMismatchException\012",
        Z.run(T, 1, 7, 3, 0, "\u00ae", "\u04ae\u707f\ua6ad\u915a\u40c9\u2481\u4f31\000\u0474\u7f00\u582b\u28ca\u2141\uc0e4\u3361\u0f19\u6563\u69ea\ua56e\u8b18\uce20\uc5b8\u750e\u77e2\u7eed\ub0dd\uaf08\u51ec\u976a", "\udbe8\uddd5\udb82\udc12\ud87b\udc8c\ud99b\udd91\u4552\ud816\udc6e\udb70\udfc9\000\000\udbb2\udfb0\ud8c7\udd19\uc4b4\ud9a2\ude37\udab9\udf5e\udaf2\udd8b\ud884\ude75\ud9dc\udc89\uda7b\udd9a\u7638",
        -2, 17726, 2146865908, -8805427521839140985L, -21027L, true, true, (char) 289, (char) 47456,
        Double.longBitsToDouble(0x3fe33f5f0cba9b9aL), Double.longBitsToDouble(0x3fc5940627dd0ed0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.DimensionMismatchException\012",
        Z.run(T, 1, 7, 3, 0, "", "\u3150\u04ae\u707f\ua6ad\u915a\ud6c8\u2481", "\ud942\udf9c\ud98d\udfdb\ud97d\udc96\uda39\udce9\udb3a\udf96\000\udad7\ude31\ud850\udf3e\u0091\uda74\ude79\ud8ff\udcd0\uc12d\udbd8\udda8\ud9c3\udf05\ubb09\udb49\udd72\ud96b\udfd8",
        -3, 79593, 1758733742, 5761441644916980850L, -100000L, false, true, (char) 11608, (char) 28533,
        Double.longBitsToDouble(0x3fbe0945056a9298L), Double.longBitsToDouble(0x3fefc7dea3e0b911L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.DimensionMismatchException\012",
        Z.run(T, 1, 7, 3, 0, "\000", "", "\ud8ca\udf6e\ud9a7\udfbf",
        22, -1000, 927190528, 9215240296546361495L, -77915L, true, false, (char) 25205, (char) 39667,
        Double.longBitsToDouble(0x3f31958438000000L), Double.longBitsToDouble(0x3fc9055060000230L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.DimensionMismatchException\012",
        Z.run(T, 1, 7, 3, 0, "\udb88\uddaf", "", "\ud8ca\udf6e",
        -5, 74840, 703859400, 3982253963434204218L, 95883L, true, true, (char) 37256, (char) 22303,
        Double.longBitsToDouble(0x3f995a44a147ad60L), Double.longBitsToDouble(0x3fe8cc5ed5914656L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.distribution.MultivariateNormalDistribution:@? |a1=[D:[[63.0]] |a2=[[D:[[[575.0]]]\012",
        Z.run(T, 1, 7, 3, 0, "\u00ae", "\u04ae", "\ud9a7\udfbf\udb86\udfaa\udbb5\udd40\udbfb\udee4\000\ud942\udf9c\ud98d\udfdb\udb05\udfb9\ud8c0\udf47\udb75\udeda\ud95a\udd02",
        0, 67637, 2035877265, 3063502758092780744L, -46506L, false, true, (char) 38283, (char) 3027,
        Double.longBitsToDouble(0x3fc77bd4a853c3e8L), Double.longBitsToDouble(0x3fe44ee9d5ae624bL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 3, 0, "\u00ae", "\u04ae", "\ud9a7\udf73\udb86\udfaa\udbb5\udd40\udbfb\udee4\000\ud942\udf9c\ud98d\udfdb\udb05\udfb9\ud8c0\udf47\udb75\udeda\ud95a\udd02",
        0, 67637, 2035877265, 3063502758092780744L, -46506L, false, true, (char) 38283, (char) 3027,
        Double.longBitsToDouble(0x3fc77bd4a853c3e8L), Double.longBitsToDouble(0x3fe44ee9d5ae624bL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=[D:[[23.979157616563597]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 1, 4, 3, 0, "\u00ae", "\u04ae", "\ud9a7\udfbf\udb86\udfaa\udbb5\udd40\udbfb\udee4\000\ud942\udf9c\ud98d\udfdb\udb05\udfb9\ud8c0\udf47\udb75\udeda\ud95a\udd02",
        0, 67637, 2035877265, -3263836276326091576L, -46506L, false, true, (char) 38283, (char) 3027,
        Double.longBitsToDouble(0x3fe162952eb75815L), Double.longBitsToDouble(0x3fe44ee9d6ae624bL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.DimensionMismatchException\012",
        Z.run(T, 1, 0, 3, 0, "\u00ae", "\u04ae", "\ud9a7\udfbf\u5c53\ud867\udcda\ud8a9\udedc\000\ud942\udf9c\ud98d\udfdb\udb05\udfb9\udb7c\udd24\udb6c\udc97\ud95a\udd02",
        0, 67637, -1303771759, 3063502281351410888L, -46506L, false, true, (char) 38283, (char) 3027,
        Double.longBitsToDouble(0x3fc77bd4a853c3e8L), Double.longBitsToDouble(0x3fe44ee9d5ae624bL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.linear.NonPositiveDefiniteMatrixException\012",
        Z.run(T, 1, 7, 3, 0, "\u00ae", "\000", "",
        16, 74840, 703859400, 19086289202577408L, 95883L, true, true, (char) 22736, (char) 15009,
        Double.longBitsToDouble(0x3fde7d3c713c0000L), Double.longBitsToDouble(0x3fbf5fa0ac8e97f8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{575.0}} |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 1, 1, 3, 0, "\u00ae", "\u04ae", "\ud9a7\udfbf\u2660\udbe2\udc1f\udbfb\udee4\000\ud942\udf9c\ud98d\udfdb\udb05\udfb9\ud8c0\udf47\udb75\udeda\ud95a\udd02",
        0, 38221, 2035877265, 3063502758092780744L, -46506L, false, true, (char) 38283, (char) 3027,
        Double.longBitsToDouble(0x3fc77bd4a853c3e8L), Double.longBitsToDouble(0x3fe44ee9d5ae624bL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=[D:[[63.0]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 1, 3, 3, 0, "\u00ae", "\u04ae", "\ud9a8\udc16\udb86\udfaa\udbb5\udd40\udbfb\udee4\ud8a2\ude60\ud810\udffc\uda66\udfa0\udb2d\udce0",
        11, 57374, 2023260647, 9116086769356275888L, -18019L, false, false, (char) 41334, (char) 38283,
        Double.longBitsToDouble(0x3feb5163498eb6a5L), Double.longBitsToDouble(0x3fe0a787d289dd3aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{575.0}} |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 1, 1, 3, 0, "\u00ae", "\u04ae", "\ud9a7\udfbf\udb86\udfaa\udbb5\udd40\udbfb\udee4\uda4a\udfbe\ud866\udf85\ud98d\udfdb\udb05\udfb9\ud8c0\udf47\udb75\udeda\ud95a\udd02",
        38, 67637, 2035877265, 3063502758097634248L, -46506L, false, true, (char) 64734, (char) 10451,
        Double.longBitsToDouble(0x3fc77bd4a853c3e8L), Double.longBitsToDouble(0x3fe44ee9d5ae624bL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{15748.5}} |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 1, 1, 3, 0, "\u00ae", "\u7b39", "\udbf7\udff5\udacc\udd3e\udbb0\uddcf",
        29, 96294, -1417486185, -3637498008862979303L, -79894L, true, true, (char) 20790, (char) 65278,
        Double.longBitsToDouble(0x3fddfd28bfc28422L), Double.longBitsToDouble(0x3fc160d077480230L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.distribution.MultivariateNormalDistribution:@? |a0=[D:[[63.0]] |a1=[[D:[[[575.0]]]\0121=[D:[[63.0]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 2, 6, 3, 0, "\u00ae", "\u04ae", "\u4d22\udb86\udfaa\uda22\udf78\ud879\udcb5\ud8f8\udc3e\ud91c\udd0a\udb7b\udcdd\udb27\udf84\ud897\udc8a\uda2e\udd82\u5f1a",
        0, 67637, 2035877265, 3063502758092780744L, -46506L, false, true, (char) 38283, (char) 3027,
        Double.longBitsToDouble(0x3fc77bd4a853c3e8L), Double.longBitsToDouble(0x3fe44ee9d5ae83f6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.distribution.MultivariateNormalDistribution:@? |a1=[D:[[63.0]] |a2=[[D:[[[10619.0]]]\0121=new org.apache.commons.math3.distribution.MultivariateNormalDistribution:@? |a0=[D:[[63.0]] |a1=[[D:[[[10619.0]]]\012",
        Z.run(T, 2, 7, 6, 6, "\u00ae", "\u5326", "\ud981\uddf0\udb86\udf77\uda79\udd3a\udbfb\udee4\000\ud942\udf9c\ud98d\udfdb\udb05\udfb9\ud8c0\udf47",
        9, 27647, 2122504350, -3242731930288323183L, -53720L, true, false, (char) 57566, (char) 41334,
        Double.longBitsToDouble(0x3fe746690794c169L), Double.longBitsToDouble(0x3fc77bd4a853c3e8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.DimensionMismatchException\012",
        Z.run(T, 1, 2, 3, 0, "\u00ae", "\u983c", "",
        26, 74840, 703859400, 19086289202577408L, 95883L, true, true, (char) 20104, (char) 15009,
        Double.longBitsToDouble(0x3fde7d3c713cf130L), Double.longBitsToDouble(0x3fbf5fa0ac8e97f8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[D:[[63.0]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\0121=[D:[[63.0]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 2, 3, 3, 0, "\u00ae", "\u04ae", "\uda5c\udf4f\udb86\udfaa\udbb5\udd40\udbfb\udee4\000\ud86d\uddb0\ud98d\udf92\udb05\udfb9\ud8c0\udf47\uda7c\udefd",
        -3, 89350, -755007363, 305339009928068793L, -37591L, false, false, (char) 41334, (char) 57227,
        Double.longBitsToDouble(0x3fccf3e58eba00f8L), Double.longBitsToDouble(0x3fdef434a5127158L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.distribution.MultivariateNormalDistribution:@? |a1=[D:[[63.0]] |a2=[[D:[[[575.0]]]\0121=[D:[[63.0]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 2, 7, 3, 0, "\u00ae", "\u04ae", "\ud9a7\udfbf\udb86\udfaa\udbb5\udd40\udbfb\udee4\ud896\udc0a\ud942\udf9c\ud98d\udfdb\ud900\udd35\ud855\udc3c\udb75\udf09\ud95a\udd02",
        51, 67637, 2035877265, -3263836276326091576L, -46506L, false, true, (char) 38283, (char) 3027,
        Double.longBitsToDouble(0x3fe162952eb75815L), Double.longBitsToDouble(0x3fe44ee9d6ae624bL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{9.0}} |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 1, 1, 0, 0, "\u00ae", "B", "",
        16, 74840, 703859385, 484927051556382663L, 95883L, true, true, (char) 22736, (char) 15009,
        Double.longBitsToDouble(0x3fde7d3c713c0000L), Double.longBitsToDouble(0x3fbf5fa09e38eff8L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.distribution.MultivariateNormalDistribution:@? |a0=[D:[[63.0]] |a1=[[D:[[[575.0]]]\0121=!org.apache.commons.math3.exception.DimensionMismatchException\012",
        Z.run(T, 2, 6, 0, 0, "\u00ae", "\u04ae", "\ud9a7\udfbf\ud8ba\udc24\ud9b6\udd54\udbfb\ude1b\000\ud91b\udf25\ud8fe\udc18\udb37\udd34\ud8c0\udf47\udb75\udeda\ud95a\udd02",
        5, 56533, 2038957380, 3084147188415902920L, -46506L, false, true, (char) 38283, (char) 51154,
        Double.longBitsToDouble(0x3fc76d972853c3e8L), Double.longBitsToDouble(0x3fe44ee9d5ae624bL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{9630.0}} |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 1, 1, 3, 0, "\u00ae", "\u4b6c", "\ud9a7\udfbf\u2660\udbe2\udc1f\udbf6\udfe4\ud8bf\udc3e\udbaf\udd55\ud98d\udfdb\udb05\udfb9\ud8c0\udf47\udb75\udeda\ud95a\udd02",
        0, 38221, 2035877265, 3063502758092780744L, -33369L, true, true, (char) 38283, (char) 3027,
        Double.longBitsToDouble(0x3fe6f8d7c5d30dceL), Double.longBitsToDouble(0x3fe281e766056fe0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{12200.0}} |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 1, 1, 3, 0, "\u00ae", "\u5f80", "\ud8f8\udeb1\u7415\udbb5\udd03\udbfb\udee4\000",
        10, 63997, 1317538585, -8562738962902830730L, 86526L, true, false, (char) 6198, (char) 14484,
        Double.longBitsToDouble(0x3fc9055060f40230L), Double.longBitsToDouble(0x3fcec1fd356a1070L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{23086.0}} |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\0121=java.lang.Double:1.0 |a0=[D:[[63.0]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 2, 1, 2, 0, "\u00ae", "\ub48c", "\udae5\udef8\udb78\udf0c\udbd1\udd40\udbfb\udee4\uda4a\udfbe\ud812\udf34\ud9bc\udc4b\udb05\udfb9\udbf5\ude00\uda49\udd11\uda69\udf35\ud974\udefd\ud8fd\udcca\udb8a\udd06\ud9fe\udcd8\uda8a\udfd4",
        33, 92718, -786424486, 5313582260713545578L, 1868L, false, false, (char) 37829, (char) 16730,
        Double.longBitsToDouble(0x3fd4e0b59f74cb96L), Double.longBitsToDouble(0x3fe2cc7778c71451L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.distribution.MultivariateNormalDistribution:@? |a1=[D:[[63.0]] |a2=[[D:[[[15748.5]]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 2, 0, "\u00ae", "\u7b39", "\udbf7\udff5\udacc\udd3e\udbb0\uddcf",
        15, 96294, -1417486185, -3637498008862979303L, 86525L, true, false, (char) 30856, (char) 59927,
        Double.longBitsToDouble(0x3fd6d7a07f3bdf68L), Double.longBitsToDouble(0x3fe7d6dc993b81a9L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=[D:[[63.0]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\0121=java.lang.Double:0.016637043168099594 |a0=[D:[[63.0]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 2, 3, 0, 0, "\u00ae", "\u04ae", "\uda5c\udf4f\udb86\udfaa\udbb5\udd40\udbfb\udee4\000\ud86d\uddb0\uda29\udda0\ud8ab\udf7e\uda6e\udc30\u6892",
        -3, 89350, -755007363, 305339009928068793L, -37591L, false, false, (char) 41334, (char) 57227,
        Double.longBitsToDouble(0x3fccf3e58eba00f8L), Double.longBitsToDouble(0x3fdef434a5127158L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{14645.5}} |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\0121=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{14645.5}} |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 2, 1, 1, 7, "\u00ae", "\u729b", "\uda5c\udf4f\udb86\udfaa\udbb5\udd40\udbfb\udee4\000\ud86d\uddb0\ud98d\udf92\udb05\udfb9\ud8c0\udf47\uda7c\udefd",
        46, 89350, -755007363, 305339009928068793L, -37591L, false, false, (char) 41334, (char) 57227,
        Double.longBitsToDouble(0x3f9c9f2c75d007c0L), Double.longBitsToDouble(0x3fdef434a5127158L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[D:[[627.0]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\0121=[D:[[14902.5]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 2, 0, 3, 0, "\u749d", "\u0538", "\u0516",
        17, 53360, 4453412, 1451417751L, 51178L, true, true, (char) 20790, (char) 65278,
        Double.longBitsToDouble(0x3fab697feb9043c0L), Double.longBitsToDouble(0x3f69b6a3c962f000L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.distribution.MultivariateNormalDistribution:@? |a1=[D:[[63.0]] |a2=[[D:[[[575.0]]]\0121=new org.apache.commons.math3.distribution.MultivariateNormalDistribution:@? |a1=[D:[[63.0]] |a2=[[D:[[[575.0]]]\012",
        Z.run(T, 2, 7, 7, 3, "\u00ae", "\u04ae", "\ud96e\udd9f\udbd4\ude19\uda97\udf3e\udbe4\ude32\ud896\udc0a\ud942\udf9c\ud98d\udfdb\ud900\udd35\udb6d\udc48\udb75\udf09\ud8d7\udd07",
        3, 91435, 2035877265, -3263836276992612408L, -46506L, true, true, (char) 50197, (char) 3027,
        Double.longBitsToDouble(0x3fe1629529d05815L), Double.longBitsToDouble(0x3fe44e5886ae624bL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{9630.0}} |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\0121=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{9630.0}} |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 2, 1, 1, 4, "\u00ae", "\u4b6c", "\ud9a7\udfbf\u2660\udbe2\udc1f\udbf6\udfe4\ud8bf\udc3e\udb3a\udd59\ud98d\udfdb\uda2f\udde1\udb94\udcd5\udaf7\udf9c\ud95a\udd02",
        0, 38221, 2035877265, 3063502758092780744L, 72359L, true, true, (char) 38283, (char) 3027,
        Double.longBitsToDouble(0x3fe6f8d7c5d30dceL), Double.longBitsToDouble(0x3fdd127ec601c642L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=[D:[[151.94077793666847]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\0121=[D:[[151.94077793666847]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 2, 4, 4, 7, "\u00ae", "\ub48c", "\udae5\udef8\udb78\udf0c\udbd1\udd40\udbfb\udee4\uda4a\udfbe\ud812\udf34\ud9bc\udc4b\udb05\udfb9\udbf5\ude00\uda49\udd11\uda69\udf35\ud974\udefd\ud8fd\udcca\udaba\udc33\ud9f3\ude5c\uda8a\udfd4",
        33, 24862, -786424486, 5313582260713545578L, 1773L, false, false, (char) 37829, (char) 16730,
        Double.longBitsToDouble(0x3fd4e0b59f74cb96L), Double.longBitsToDouble(0x3fe2cc7778c71451L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[D:[[627.0]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\0121=java.lang.Double:0.015720528133656316 |a0=[D:[[14902.5]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 2, 0, 0, 0, "\u749d", "\u0538", "\u0516",
        17, 53360, 4453412, 1451417751L, 51178L, true, true, (char) 20790, (char) 65278,
        Double.longBitsToDouble(0x3fab697feb9043c0L), Double.longBitsToDouble(0x3f69b6a3c962f000L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[D:[[635.0]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\0121=[D:[[14902.5]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 2, 2, 3, 0, "\u749d", "\ub658", "\u0526",
        17, 53360, 4453412, 1451417751L, -31510L, true, true, (char) 20790, (char) 65278,
        Double.longBitsToDouble(0x3fab697ffcd8aa90L), Double.longBitsToDouble(0x3f6b8f03c962f000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Double:1.501799284E-315 |a0=[D:[[13939.0]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\0121=[D:[[14902.5]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 2, 0, 3, 0, "\u749d", "\u0538", "\u6d16",
        17, 53360, 1333192740, 194520520253591L, 51178L, true, true, (char) 20790, (char) 65278,
        Double.longBitsToDouble(0x3fab0b9eeb9043c0L), Double.longBitsToDouble(0x3f69b6a3c962f000L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Double:9.553109615E-314 |a0=[D:[[13939.0]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 1, 2, 4, 7, "\u749d", "\u0538", "\u6d16",
        -3, 90294, 1333192915, -8718774358155296560L, 87038L, true, false, (char) 57202, (char) 25333,
        Double.longBitsToDouble(0x3f69a6a39a6bd300L), Double.longBitsToDouble(0x3fde9df76b73bc86L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Double:1.501799284E-315 |a0=[D:[[13939.0]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\0121=java.lang.Double:0.015720528133656316 |a0=[D:[[14902.5]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 2, 0, 0, 0, "\u749d", "\u0538", "\u6d16",
        37, 2289, 377254401, -5312934565870352448L, 51178L, true, true, (char) 20790, (char) 65247,
        Double.longBitsToDouble(0x3fd36173dd720878L), Double.longBitsToDouble(0x3f69b6a2c962f000L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.DimensionMismatchException\012",
        Z.run(T, 1, 7, 3, 0, "\u5af8\ud8d2\udef4\uda0e\udcf1\u1a85\uda7a\udf17\u22b9\udbd0\udc38\udb7f\udec6\udbb5\udd40\udaf8\ude22\ud95c\udfc3", "\u582b\u28ca\u2141\uc0e4\uaa64\uc275\u6563\u69ea\ua56e\u8b18\uce20\uc5b8\u750e\u77e2\u7eed\ub0dd\u02ba\u213d\u9b52\u5f63", "\udb82\udc12\ud87b\udc8c\udaab\udf19\udb07\udec5\udb71\udd61\udac6\udcd4\u1c6b\udb90\udf89\udbb2\udfb0\ud8c7\udd19\uc4b4",
        22, 40089, 1579965439, 7509158992135815661L, 32389L, false, true, (char) 19823, (char) 472,
        Double.longBitsToDouble(0x3fd04736688f5b10L), Double.longBitsToDouble(0x3fe239f526075c99L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Double:1.0735288152822E-310 |a0=[D:[[13946.5]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\0121=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{644.0}} |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 2, 0, 1, 0, "\u749d", "\u0538", "\u6d25",
        17, 53360, 1333192740, 2438330768787611211L, 51178L, true, true, (char) 20790, (char) 65278,
        Double.longBitsToDouble(0x3fb8414f547f4e28L), Double.longBitsToDouble(0x3f69b09bc962f000L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Double:0.015720528133656316 |a0=[D:[[-24.0]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\0121=java.lang.Double:0.015720528133656316 |a0=[D:[[-24.0]] |this=org.apache.commons.math3.distribution.MultivariateNormalDistribution:@?\012",
        Z.run(T, 2, 0, 0, 0, "\000", "\u0538", "\000",
        56, 50800, 1333192740, 1005022347264L, -100000L, false, false, (char) 45311, (char) 40429,
        Double.longBitsToDouble(0x3f3e260000000000L), Double.longBitsToDouble(0x0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.distribution.MultivariateNormalDistribution|density|[D|new:org.apache.commons.math3.distribution.MultivariateNormalDistribution:[D,[[D",
    "M|org.apache.commons.math3.distribution.MultivariateNormalDistribution|getCovariances||new:org.apache.commons.math3.distribution.MultivariateNormalDistribution:[D,[[D",
    "M|org.apache.commons.math3.distribution.MultivariateNormalDistribution|getExponentTerm|[D|new:org.apache.commons.math3.distribution.MultivariateNormalDistribution:[D,[[D",
    "M|org.apache.commons.math3.distribution.MultivariateNormalDistribution|getMeans||new:org.apache.commons.math3.distribution.MultivariateNormalDistribution:[D,[[D",
    "M|org.apache.commons.math3.distribution.MultivariateNormalDistribution|getStandardDeviations||new:org.apache.commons.math3.distribution.MultivariateNormalDistribution:[D,[[D",
    "M|org.apache.commons.math3.distribution.MultivariateNormalDistribution|sample||new:org.apache.commons.math3.distribution.MultivariateNormalDistribution:[D,[[D",
    "C|org.apache.commons.math3.distribution.MultivariateNormalDistribution|<init>|[D,[[D",
    "C|org.apache.commons.math3.distribution.MultivariateNormalDistribution|<init>|org.apache.commons.math3.random.RandomGenerator,[D,[[D",
    "M|org.apache.commons.math3.distribution.MultivariateNormalDistribution|density|[D|new:org.apache.commons.math3.distribution.MultivariateNormalDistribution:[D,[[D",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
