package org.apache.commons.math.optimization.general;
import org.junit.Test;
import static org.junit.Assert.*;
public class LevenbergMarquardtOptimizer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 5, "\u88af\u0b9f\u47b2\ud9a8\udf22\udbb4\udedc\udac6\udd98", "\u6b63\ub559\u56b6\u4f22\u9452\u2628\u10ec", "\uda53\udd57\ud89d\udc3d\udb89\udc5c\ud9ad\udfa3\ud85d\udea2\udba5\udf99",
        6, 17237, 842733896, -2341414978461839809L, 29381L, true, true, (char) 44614, (char) 53877,
        Double.longBitsToDouble(0x3fe87958107429d5L), Double.longBitsToDouble(0x3feab298f8b149e4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 5, "\u88af\u0b9f\u47b2\ud9a8\udf22\udbb4\udedc\uda8a\ude36", "\u6b63\ub559\u56b6\u4f22\u9452\u2628\u10ec", "\uda53\udd57\ud89d\udc3d\udb89\udc5c\ud999\udea2\u1918\udba5\udf64",
        6, 17237, 842733896, -2341414978461839809L, 29381L, true, true, (char) 44614, (char) 53877,
        Double.longBitsToDouble(0x3fe87958107429d5L), Double.longBitsToDouble(0x3feab298f8b149e4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 9, 5, "\u889b\u0b9f\u47b2\ud9a8\udeec\ud86c\udee9\udac6\ude0e\ud802\udd00\ud972\udc66\ud9fd\udf8c\udb69\udf48", "\u9452\u2628\u10ec\u14bf\ubf72\u2aa6\uca63\u9b39\u2aee\u0bb6\u09dc\u4f89\u53b8\u94d0\u00f9\u2402|\u6454", "\udb75\udd00\ud870\udd86\ue55a\uda49\udf92\u42ee\ud9b7\udc39\u53fa\uda27\udf25\ud9ee\udcb8\ud8dc\udebc\ud83e\udd07\ud909\ude8a\udab2\udcd9\ud9ce\udf10\udbf9\uddca\ud882\udcec\ud8b6\udd03\ud903\ude9c\uda79\udc02\ud908\udd9e\uda94\udd7e\ud99a\udeea\uda5c\udf39",
        58, 84735, -192089173, 7338710417690567062L, 60850L, true, false, (char) 8583, (char) 8294,
        Double.longBitsToDouble(0x3fee7a1119c91335L), Double.longBitsToDouble(0x3feaecb7d17688e3L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 8, 1, 1, "\ud80d\udc7f\ub69f\ud848\udf2c\ud91a\udcb5\udb7b\ude7b\udac6\ude37", "\u6b63\ud229\u96a2\u4f22\uacd9\u2628\u7971", "\udb40\udd51\udb98\udc87\ud9bc\udca9\ud99d\ude0e\ud8cc\udf99",
        43, 5659, -684403713, 3619514655152158663L, -32401L, false, false, (char) 13136, (char) 62556,
        Double.longBitsToDouble(0x3feb39c1c321fdedL), Double.longBitsToDouble(0x3fd746425db9b8c0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 3, 5, "\udabd\udd34\u0c24\u47b2\ud819\udd14\ud989\udc9d\ud833\udd07", "\u2877\u80cb\ud250\u579a\u9462\u2628\u10ec", "\ud8a2\udcd2\ud8c7\udeb9\udb89\udc5c\ud9ad\udfa3\ud85d\udea2\udba5\udf99",
        38, 17237, -1933416325, 1775317884033475610L, 29381L, true, true, (char) 44614, (char) 49782,
        Double.longBitsToDouble(0x3fe8795cbad729d5L), Double.longBitsToDouble(0x3fe0e3c320b14bcfL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 5, "\u88af\u0b9f\u47b2\ud9a8\udf22\udbb4\udedc\udac6\udd98", "\u61d4\ud4bb\u577b\u4f22\u8167\u9e3a\u4b49\u349f\u4fdc\u1015\u0cb0", "\ud85d\udea2\udba5\udf99\ud8c4\udcdf\udbf4\udf9d\ud942\ude03\ud9a1\udc7e\uef54\udafd\udfe4\udb8a\udd3f\u473a\ud84b\udee6\udb75\udd00\ud870\udd86\ue55a\udb07\uddb0\udba5\ude82\ud8dc\udc66\ud801\ude03\udb8d\udc04\uda08\ude18\udbea\udf28\udbb5\udda4\ud81d\udda2\udad8\ude33\udb96\udc90\uda3a\udfa8\udb47\udc11\udbce\udd80\udb14\udc01\ud823\udea9\ud828\udcc5\ud812\udee1\ud8c7\udf0a\ud8cb\udf20\uda32\udfbe\ud92d\ude72\udafa\udcdd\ud8e0\uddfc\udadc\udfe9\ud9ee\udde4\ua0d9\uda96\udefb\ud982\udd56\ud91b\udfa0\uda6e\udc2f\uda38\udc3e\uda34\udef7\ud9b0\udf25\udb30\udf20\ud894\udc3c\ud8da\uddb5\ue433",
        54, 31515, 914336381, 6777399767329804141L, -30292L, true, false, (char) 56513, (char) 46952,
        Double.longBitsToDouble(0x3fe39599095fdf57L), Double.longBitsToDouble(0x3fe80be870eba5e6L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |a0=[D:[[27929.5, 28399.5, 27904.0, 28219.0, 9153.0, 27652.5, 28413.5, 27646.0]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 4, 5, 5, "\uda63\ude0f\uda30\udca6\u47b2\ud839\ude2b\ud82c\udc09\uda2f\udeec", "\u6b63\ub559\u57a1\u9df8\u93f1", "\ud987\udc2a",
        55, 96558, -324179390, 3103722042596440356L, 35609L, true, true, (char) 23274, (char) 41656,
        Double.longBitsToDouble(0x3fd856b20a061764L), Double.longBitsToDouble(0x3fe79b166da32b02L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 10, 1, "\u88af\u0b9f\u47b2\ud9a8\udf22\udbb4\udedc\udb9b\udd9e\udb14\udd7d\uda87\udf79\ud9ae\udfd6\ud9f3\udd94\ud9e0\udcd9\uda2f\udeab\ud8d2\udf24\ud886\udde8\u53fd\ud986\udf6d\ud9ea\ude3e\uda53\udd57\uda0e\udce4\udb89\udc68\udba1\udf9d\ud85d\udea2", "\ua0e6\u2f41\u762d\ubb4f\u8c64\u02e4\u2a75", "\uda76\udffc\uda9f\udcbc\ud8f2\udd66\ud8e1\udf5e\udbdb\udf5d\uda6d\ude67\ud96f\udfd3\ud89d\udce2\ud85c\udf86\ud9fb\udf40\ud8da\udd21\ud9a9\udc2b\udb4a\udd7c\udb2e\ude73\udbf3\udf90\ud983\udc98\udacc\udd57\udb92\udc40\ud881\udf23\udb4c\ude2b\udaf3\udd99\udbd4\udf1f\udb1c\udc47\udb20\udc97\ud88d\uddeb\udbfe\udc08\ud866\uddf8\ud8f4\udf68\uda1f\udf0d\uda9d\ude1c\ud9a0\udfc7\uda31\ude0a\udb56\udc84\ud8ba\udd25\uda5f\udc6d\ud877\udcb4\ud9f4\udef3\udb7c\udecb\ud8af\udf7f\udbb2\udf71\ud9d3\udec7\uda82\udc88\ud9b2\udd5f\ud9d9\udc16\udb8d\udf6e\uda0b\udd2f\ud9d7\udc1b\udbee\udef4\uda0a\udee7\udabe\uddfb\udb46\udef2\uda0b\udfdb\u85ca\ud861\udd9c\ud872\udf19\ud89e\udf96\uda75\udca4\ud8eb\ude2c\udbb9\udf65\udb8d\ude10\ud97e\uddf0",
        49, 18610, -1353403941, 5204902183430717621L, 61859L, true, false, (char) 9627, (char) 21146,
        Double.longBitsToDouble(0x3fed8f53fc808297L), Double.longBitsToDouble(0x3fb45f2826d189a0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 5, "\u88af\u0b9f\u47b2\ud9a8\udf22\udbb4\udedc\udac6\udd98", "\ub063\u2da2\u77df\uc7c3\u9452\u2628\ua8a3", "\uda53\udd57\ud89d\udc3d\udb89\udc5c\ud9ad\udfa3\ud8ab\udce9\udba5\udf99",
        6, 40005, 842789121, -2341414978461839809L, 44040L, false, false, (char) 10769, (char) 53832,
        Double.longBitsToDouble(0x3feab298f8b149e4L), Double.longBitsToDouble(0x3f9bdff37d2329e0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 8, 8, 5, "\u88af\u0b9f\u47b2\ud9a8\udf22\udbb4\udedc\udac6\udd98", "\u2fa2\ub559\u56b6\u4f22\u9452\u2628\u10ec", "\uda53\udd57\ud89d\udc3d\udb89\udc5c\ud9ad\udfa3\ud85d\udea2\udba5\udf99",
        6, 62437, 2103967960, -2369179219021214145L, 29381L, true, false, (char) 48549, (char) 53877,
        Double.longBitsToDouble(0x3fe87958107429d5L), Double.longBitsToDouble(0x3feab298f8b149e4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |a0=[D:[[27735.5, 28381.5, 28133.0, 28643.5, 27645.5, 28230.5, 27786.5, 28464.5]] |a2=[D:[[13721.5, 23188.5, 5792.5, 10064.5, 19682.0, 15234.5]] |a3=[D:[[28064.5, 28612.5, 27921.5, 28284.5, 27702.5, 28166.5, 28076.5, 28182.0]] |a4=[D:[[27735.5, 28381.5, 28133.0, 28643.5, 27645.5, 28230.5, 27786.5, 28464.5]] |a5=[D:[[13721.5, 23188.5, 5792.5, 10064.5, 19682.0, 15234.5]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 9, 3, 0, "\ud8df\uddeb\udbfa\udff7\ud82b\udcbd\ud945\ude91\udbb4\udedc\udac7\udd98", "\u6b63\ub559\u2d71\u4ed1\u99f4\u7735", "\udb71\udfb9\uda53\udd29\ud89d\udc3d\udb89\udc5c",
        45, 17928, 118440527, 8810093976964207213L, -73376L, true, true, (char) 50065, (char) 2622,
        Double.longBitsToDouble(0x3fd79a24f550c752L), Double.longBitsToDouble(0x3fe3f8d7f70f2b02L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 9, 7, 5, "\u88af\u0c17\ud818\uddf3\udad6\uddb1\ud981\udd11\udac1\udc24", "\u6b63", "\ue718\u33c8\ud9d5\udc5f\ud800\udc87\ud986\udf6d\uda12\udec9\uda5a\udf57\ud89d\udc3d",
        16, -625, -947228289, -2445663121805072750L, 29381L, true, true, (char) 42310, (char) 6765,
        Double.longBitsToDouble(0x3fc4c5604e2c5e48L), Double.longBitsToDouble(0x3fe8d09cd0b1d06eL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |a0=[D:[[17471.5, 1463.5, 9153.0, 27836.0, 28537.0, 28098.0, 28502.0, 27979.0]] |a2=[D:[[16329.5, 23188.5, 11075.0, 7223.0, 18961.0, 8342.0, 2086.0]] |a3=[D:[[27749.5, 28292.5, 27715.5, 28288.0, 28076.5, 28182.0, 27838.5, 28601.5]] |a4=[D:[[17471.5, 1463.5, 9153.0, 27836.0, 28537.0, 28098.0, 28502.0, 27979.0]] |a5=[D:[[16329.5, 23188.5, 11075.0, 7223.0, 18961.0, 8342.0, 2086.0]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |a0=[D:[[17471.5, 1463.5, 9153.0, 27836.0, 28537.0, 28098.0, 28502.0, 27979.0]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 3, 4, 5, "\u88af\u0b9f\u47b2\ud9a8\udf22\udbb4\udedc\udac6\udd98", "\u7fc3\ub559\u56b6\u389e\u9452\u415c\u107c", "\ud8fb\udd39\ud8b7\udd30\udb89\udc5c\ud9ad\udfa3",
        18, 79079, 814294531, 5124893435290655048L, 29381L, true, true, (char) 44614, (char) 53877,
        Double.longBitsToDouble(0x3fe87958107429d5L), Double.longBitsToDouble(0x3fd56531f74c7e6cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |a0=[D:[[27875.5, 28545.0, 27841.5, 28352.5, 28029.5, 28503.0, 27806.5, 28567.5]] |a2=[D:[[10105.0, 21825.0, 4860.0, 2142.0, 2631.5, 16099.5, 5435.0, 23961.5]] |a3=[D:[[27822.0, 28332.5, 27652.0, 28360.0, 28017.5, 28336.5, 30537.5, 28006.5]] |a4=[D:[[27875.5, 28545.0, 27841.5, 28352.5, 28029.5, 28503.0, 27806.5, 28567.5]] |a5=[D:[[10105.0, 21825.0, 4860.0, 2142.0, 2631.5, 16099.5, 5435.0, 23961.5]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 5, "\ud9f7\udf32\ud9b3\uddb1\udb2b\udede\ud96d\udf5f\udada\ude04\ud80b\udd44\udbc4\udf8c\ud8b7\udfb3\ud948\udfbd", "\u4f22\uaab2\u2628\u10ec\u14bf\u7df7\u2aa6\ubb63\u631e\u61c6\u0b4a", "\ud98c\udd89\ud838\uddc0\udb13\udd91\ueec3\udafd\udfe4\udb8a\udd3f\u473a",
        3, 41808, 701890319, 7338883273571286159L, -71432L, true, false, (char) 40303, (char) 7970,
        Double.longBitsToDouble(0x3fdcaf020dda8742L), Double.longBitsToDouble(0x3fd7c9922bdc6900L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |a0=[D:[[17471.5, 1463.5]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 6, 4, 8, "\u88af\u0b9f", "\uc304\u7be2", "\uda31\udc8d\ud9f3\udd94\ud9e0\udcd9\uda2f\udeab\ud8d2\udf24\ud886\udde8\u53fd",
        7, 27244, -278454702, 2952700900540819838L, -25104L, false, false, (char) 63506, (char) 56655,
        Double.longBitsToDouble(0x3fd48471fef86476L), Double.longBitsToDouble(0x3fe1fefc0e2d8100L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |a0=[D:[[27630.5, 28199.5, 23351.5, 27660.0, 28542.0, 27765.0, 28226.5, 28069.5]] |a2=[D:[[13721.5, 26876.5, 19257.0, 10105.0, 22100.5, 4860.0, 15520.5]] |a3=[D:[[28040.0, 28304.5, 28084.0, 28203.5, 27846.0, 28220.5, 27830.5, 28399.0]] |a4=[D:[[27630.5, 28199.5, 23351.5, 27660.0, 28542.0, 27765.0, 28226.5, 28069.5]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 8, 3, 6, "\ud80d\udc7f\ub69f\ud848\udf2c\ud91a\udcb5\udb7b\ude7b\udac6\ude37", "\u6b63\ud229\u96a2\u4f22\uacd9\u2628\u7971", "\udb40\udd51\udb98\udc87\ud9bc\udca9\ud99d\ude0e\ud8cc\udf99",
        43, 5659, -684403713, 3619514655152158663L, -32401L, true, false, (char) 13136, (char) 62556,
        Double.longBitsToDouble(0x3feb39c1c321fdedL), Double.longBitsToDouble(0x3fd746425db9b8c0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud80d\udc7f\ub69f\ud8f5\ude02\ud91a\udd16\udb7b\ude7b\udac6\ude37", "\u6b63\ud229\u96a2\u4f22\uacd9\u2bf7\ua7f3", "\udb40\udda8\udb98\udc87\ud9bc\udca9\ud99d\ude0e\ud8cc\udf99",
        43, 5659, -684403713, 3619514655152158663L, -32401L, false, false, (char) 13136, (char) 62556,
        Double.longBitsToDouble(0x3feb39c1c321fdedL), Double.longBitsToDouble(0x3fd746425db9b8c0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 1, 1, 1, 1, "\ud80d\udc7f\ub757\udaaa\ude5c\ud91a\udd1b\u6d77\udad3\udc4d", "\u645e\ud031\u6a38\u4fc0\uab35\u2628\u7971\u8070\ud188\u49e7\u5fb1\u9aa4", "\ud946\uddcf\ud931\udf55\uda26\udd97\ud9f7\udd94\ud87f\udddf\udab5\udd7e\udb91\udf37\ud8b8\ude36\u473a\ud84b\udee6",
        1, 12461, -149271705, -4695142920127097511L, -94022L, false, false, (char) 29222, (char) 46344,
        Double.longBitsToDouble(0x3f9ab6b129b864c0L), Double.longBitsToDouble(0x3fe1f25acac220adL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |a0=[D:[[27917.0, 28202.0, 27737.0, 28475.5, 27989.5, 28224.0]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 7, 4, 6, "\uda4a\udc84\ud8e2\udea7\udadb\udcb0", "\u41ef\u5d99\u6a0f\u4e87\u2bed\u4185\u4efd\u5655\u6c17\u801e", "\ud91b\udf43",
        9, 33525, 1830677883, 6846459874404421442L, 85209L, true, true, (char) 27084, (char) 44521,
        Double.longBitsToDouble(0x3fe96c08069b95acL), Double.longBitsToDouble(0x3fe49d28f59b489eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "", "\u53bb", "",
        27, 47072, 90581787, -2843827271226051617L, -95986L, true, true, (char) 62379, (char) 26575,
        Double.longBitsToDouble(0x3e3314eb98000000L), Double.longBitsToDouble(0x3feb09aa4000002eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |a0=[D:[[27974.5, 28290.0, 1530.0, 27765.5, 28482.5, 27650.5, 28146.0, 27656.5]] |a2=[D:[[5329.5, 16461.5, 1903.5, 14629.0, 18969.0, 4860.0, 2142.0, 18119.5]] |a3=[D:[[28130.0, 28598.5, 27818.0, 28352.0, 27970.0, 28604.5, 28133.5, 28457.5]] |a4=[D:[[27974.5, 28290.0, 1530.0, 27765.5, 28482.5, 27650.5, 28146.0, 27656.5]] |a5=[D:[[5329.5, 16461.5, 1903.5, 14629.0, 18969.0, 4860.0, 2142.0, 18119.5]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |a0=[D:[[27974.5, 28290.0, 1530.0, 27765.5, 28482.5, 27650.5, 28146.0, 27656.5]] |a2=[D:[[5329.5, 16461.5, 1903.5, 14629.0, 18969.0, 4860.0, 2142.0, 18119.5]] |a3=[D:[[28130.0, 28598.5, 27818.0, 28352.0, 27970.0, 28604.5, 28133.5, 28457.5]] |a4=[D:[[27974.5, 28290.0, 1530.0, 27765.5, 28482.5, 27650.5, 28146.0, 27656.5]] |a5=[D:[[5329.5, 16461.5, 1903.5, 14629.0, 18969.0, 4860.0, 2142.0, 18119.5]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 3, 3, 5, "\udabd\udd34\u0c24\ud91b\udeb5\ud835\udc14\ud841\udeda\ud992\udd85", "\u29d3\u80cb\u0f0f\u727a\u9462\u2628\u10ec\u8dbf\u0585\u03ba\u4317\u7381\uac1c\u856d", "\udbf4\udf9d\ud984\uddb0\udab4\udfa9\udbfb\ude83\udafe\udcac\ud9de\udda9\u473a",
        3, 5576, -7756568, 6706576723340695176L, -3769L, false, false, (char) 18456, (char) 18804,
        Double.longBitsToDouble(0x3fda87b3061bf366L), Double.longBitsToDouble(0x3fc892c79b34e198L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 5, 5, 8, "\uda63\ude0f\uda30\udca6\u47b2\ud839\ude2b\ud82c\udc09\uda2f\udeec", "\u6b63\ub530\u5ef29\u93e7", "\ud987\udc2a\ud9cc\udfae\uda06\udf28\ud9c1\ude37\ud9d3\udf4e\udb33\udca2\ud809\udd38\ud9c9\udf74\udbc6\uddec\udbfe\ude42\uda3c\udee7\udaab\udd5e\ue591",
        29, 57792, 270252713, 7119513287229868787L, 15342L, true, true, (char) 2105, (char) 51914,
        Double.longBitsToDouble(0x3fdc396ab9e78f60L), Double.longBitsToDouble(0x3fdf82351445274cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |a0=[D:[[27975.5, 28336.0, 28112.0, 28292.5, 9153.0, 27652.5, 28413.5, 27646.0]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |a0=[D:[[27975.5, 28336.0, 28112.0, 28292.5, 9153.0, 27652.5, 28413.5, 27646.0]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 4, 4, 5, "\udabf\udd90\udbd0\udd39\u47b2\ud839\ude2b\ud82c\udc09\uda2f\udeec", "\u6b63\u9959\u57a1\u9df8\u93f1", "\ud987\udc2a",
        55, 96558, 2056022594, 328556931763171326L, -98713L, false, false, (char) 25966, (char) 51354,
        Double.longBitsToDouble(0x3fe23d0a8d0df099L), Double.longBitsToDouble(0x3fdea8100a0d6b64L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 4, 4, 3, "\uda63\ude0f\uda30\udca6\u47b2\ud839\ude1d\ud82c\udc09", "\u778a\u6b63", "\ud9a3\udd05\ud8d2\udec3\u8397\udb22\udcd6",
        0, 2745, -1382592442, -1392339877364587839L, -25104L, true, false, (char) 34106, (char) 25966,
        Double.longBitsToDouble(0x3fbf0c07f23d0a88L), Double.longBitsToDouble(0x3fd0df099a3b0200L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 1, 1, 0, 2, "\000", "\u9bad", "\000\000\uda57\udcac",
        2, -1000, 0, -8113797676929686573L, -99944L, false, false, (char) 0, (char) 61498,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3feb8734124f1900L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 7, "\u88ce", "\u9bad\uc304\u485e\ubb6f\u2181\u6b63\ub559\u56b6\u4f22\u9452\u2628\u10ec\u14bf\ubf72\u2aa6\uca63\u9b39\u2aee\u0bb6\u13dc", "\udb33\udc3d\udb64\udcda",
        29, 45477, -645921165, 8907829728652440232L, 30831L, false, false, (char) 36469, (char) 19093,
        Double.longBitsToDouble(0x3fe622ccd8d74463L), Double.longBitsToDouble(0x3fefb5d7d016cae2L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|doOptimize||new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "C|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|<init>|",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|determineLMDirection|[D,[D,[D,[D|new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|determineLMParameter|[D,double,[D,[D,[D,[D|new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|qTy|[D|new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|qrDecomposition||new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|setCostRelativeTolerance|double|new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|setInitialStepBoundFactor|double|new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|setOrthoTolerance|double|new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|setParRelativeTolerance|double|new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|doOptimize||new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "C|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|<init>|",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
