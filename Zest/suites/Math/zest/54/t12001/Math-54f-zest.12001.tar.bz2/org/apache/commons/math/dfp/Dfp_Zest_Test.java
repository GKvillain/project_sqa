package org.apache.commons.math.dfp;
import org.junit.Test;
import static org.junit.Assert.*;
public class Dfp_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 22, 10, "\ua70e\ud9b4\udeb9\ud9e9\udeaa\udabb\udd93\ud8f3\udc03\u849c", "\u9428", "\udafe\udea2\uda19\ude40\ud8eb\udc11\uda2a\udf24\u7f29",
        31, 50293, 616521698, -2567524359424762061L, 86905L, true, false, (char) 3430, (char) 29080,
        Double.longBitsToDouble(0x3fd5547ee7ae664aL), Double.longBitsToDouble(0x3fe870278dca07a7L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 22, 10, "\ua70e\ud818\ude4c\ud9e9\udeaa\udabb\udd93\ud8f3\udc03\ud836\uddf5", "\u9428", "\udafe\udea2\uda19\ude40\ud8eb\udc11\uda2a\udf3b\u7f29",
        40, 85148, -1006199555, 2576673745983300568L, 86931L, true, false, (char) 3430, (char) 29080,
        Double.longBitsToDouble(0x3fd5547ee7ae664aL), Double.longBitsToDouble(0x3fe870278dca07a7L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 14, 18, "\ua70e\ud9b4\udeb9\ud9e9\udeaa\udbb8\uddd1\udbe8\ude2f\ua6b8", "\u9428\ua047\u2ec5\u14b7\u54e4\u4fa6", "\ud967\udc5d\uda6a\udc9b\ud96e\ude0c\ud9a2\udc19\ud971\udc27",
        1, 71943, 1032666209, -1598549338262468920L, -19145L, false, true, (char) 11995, (char) 57265,
        Double.longBitsToDouble(0x3fe1f58e8c0d2ff1L), Double.longBitsToDouble(0x3fd5c6467d6bced0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 23, 18, 12, "\ud9e7\udc6e\uda96\udcda\udb7e\uded5\udbcb\udd2a\ud8f3\udc03\u849c", "\u7a33", "\udb51\udc49\uda92\ude40\ud8e7\udcec",
        46, 27259, 1008547141, 4328402843159731624L, -88092L, false, true, (char) 22810, (char) 39725,
        Double.longBitsToDouble(0x3fe377b90bfde200L), Double.longBitsToDouble(0x3fef372f9207729dL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 19, 15, 10, "\ud892\udc31\ud88a\udc1e\ud87e\udd03\ud93e\udfeb\ud8f2\udf8e\u849c", "\ubaa3\u0830\u2ec5\u14b7\u54e4\u4fa6\u0a4c\u9e83\u3b84", "\ud9a2\udc19\ud971\udc27",
        1, 71943, 1032666209, -1598549335594858552L, -19145L, false, true, (char) 23921, (char) 12444,
        Double.longBitsToDouble(0x3f9b6353e0425a80L), Double.longBitsToDouble(0x3fcccd5344eb6210L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 4, 10, "\ua75c\ud9b4\udeb9\ud94a\ude7b\uda67\udf25\ud8f3\udc03\uda0d\udc91", "\u9428", "\ud8e4\udfd4\udaf0\uddf2\uda8c\udf53\udb8d\uddff\ud977\udcb0",
        30, 23169, 90689509, -2567496566691389645L, 86905L, true, false, (char) 3430, (char) 28999,
        Double.longBitsToDouble(0x3fd5547ee7ae664aL), Double.longBitsToDouble(0x3fe870278dca07a7L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 22, 7, "\ua70e\ud9b4\udeb9\ud9e9\udeaa\uda61\udf79\ud8f3\udc03\u849c", "\u9428", "\udafe\udea2\uda19\ude40\ud8eb\udc11\uda2a\udf24\ud8fb\udc2f",
        31, 50293, 616521698, -2567524359424762061L, 86905L, true, false, (char) 3430, (char) 29080,
        Double.longBitsToDouble(0x3fea5a3f73d73350L), Double.longBitsToDouble(0x3fe870278dca07a7L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 22, 22, 14, "\ua70e\ud91c\udfae\uda83\udca0\udaa4\udcb8\ud8f3\udc03\u849c", "\u9428", "\udbce\udfcd\ud97d\uddd7\ud8eb\udc11\udb7a\udd2c\udaa6\udcc6",
        34, 84159, -1809967660, 1163968468862836531L, 46164L, true, false, (char) 18563, (char) 2201,
        Double.longBitsToDouble(0x3fdd8b78f7ae664aL), Double.longBitsToDouble(0x3fe870278dca07a7L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 9, 10, "\udaf6\udc12\ud8c5\udda7\ud9fc\udc91\udabb\udd93\udaed\udc60\udaad\udcd3", "\u3873", "\udafe\udea2\uda64\udd05\ud819\udc00\udbb9\udd87\ud91a\uded5",
        31, 50293, 616521698, 7346024319054078469L, 86905L, true, false, (char) 3430, (char) 29080,
        Double.longBitsToDouble(0x3fd5547ee7ae664aL), Double.longBitsToDouble(0x3fd0e04f1b940f4eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 20, 22, 10, "\ud921\udc66\ud8b7\udeb6\uda7c\ude4f\udabb\udd93\ud8f3\udc03\u849c", "\u9428", "\udafe\udea2\uda19\ude40\ud8eb\udc11\uda2a\udf24\u7f29",
        11, 50293, 616521698, -2567340738806981994L, -24761L, true, false, (char) 42219, (char) 51259,
        Double.longBitsToDouble(0x3fd720e6c7af51caL), Double.longBitsToDouble(0x3fe870278dca07a7L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 22, 10, "\ud94d\uddc0\ud9a1\udde4\ud962\udc01\udb0f\ude79\ud8f3\udc03\ud837\ude06", "\u9428", "\u1b61\ud94d\udeb9\ud88d\udfe9\uda2a\udf24\u7f29",
        32, 50293, 616521698, -2567524359424762061L, 86905L, true, false, (char) 3430, (char) 29080,
        Double.longBitsToDouble(0x3fd5547ee7ae664aL), Double.longBitsToDouble(0x3fe870278dca07a7L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 6, 2, "\ud824\udc2b\ud86f\udc01\ud9e9\udeaa\udabb\udd93", "\u05b2\u38ac\u3c59\u79d0", "\udb44\ude7b\ud935\udec5\ud9c0\udeab\ud98f\udfee\ud967\udc5d\uda6a\udca9\ud96e\ude0c",
        16, 73232, -1845437440, -3523392815792047007L, 38189L, true, false, (char) 23999, (char) 29877,
        Double.longBitsToDouble(0x3fefdd6e4731803dL), Double.longBitsToDouble(0x3feeef66fd68c1ebL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 9, 19, "\udaa2\udc3d\ud93a\ude32\ud8aa\udf84\uda84\udce4\ud989\udf6e\u81e7", "\u2edb\u3f4d\u750b\u461c\uc863\u2fdb\u79a8\u9f51\u1dec\ucdcc\u56fd\u48dc\u80c2\u06fe\u6a89\uc2b5\u6560\ubdcb", "\ud95f\udd62",
        8, 37678, -54611711, 1686887780768733916L, -75346L, false, true, (char) 22014, (char) 21798,
        Double.longBitsToDouble(0x3feb8e6598a11149L), Double.longBitsToDouble(0x3fd4cf0527db17b4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 22, 10, "\ua70e\ud9b4\udeb9\ud9e9\udeaa\udabb\udd93\ud8f3\udc03\u849c", "\u9428", "\udafe\udea2\uda19\ude40\ud8eb\udc11\uda2a\udf24\u7f29",
        31, 50293, 1312467170, 8747890756624268727L, 86905L, true, false, (char) 3430, (char) 29080,
        Double.longBitsToDouble(0x3fd5547ee7ae664aL), Double.longBitsToDouble(0x3fe870278dca07a7L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.dfp.Dfp|toDouble||new:org.apache.commons.math.dfp.Dfp:org.apache.commons.math.dfp.Dfp",
    "C|org.apache.commons.math.dfp.Dfp|<init>|org.apache.commons.math.dfp.DfpField,long",
    "C|org.apache.commons.math.dfp.Dfp|<init>|org.apache.commons.math.dfp.DfpField",
    "C|org.apache.commons.math.dfp.Dfp|<init>|org.apache.commons.math.dfp.DfpField,int",
    "C|org.apache.commons.math.dfp.Dfp|<init>|org.apache.commons.math.dfp.DfpField,byte",
    "C|org.apache.commons.math.dfp.Dfp|<init>|org.apache.commons.math.dfp.DfpField,java.lang.String",
    "C|org.apache.commons.math.dfp.Dfp|<init>|org.apache.commons.math.dfp.DfpField,byte,byte",
    "C|org.apache.commons.math.dfp.Dfp|<init>|org.apache.commons.math.dfp.Dfp",
    "C|org.apache.commons.math.dfp.Dfp|<init>|org.apache.commons.math.dfp.DfpField,double",
    "M|org.apache.commons.math.dfp.Dfp|add|org.apache.commons.math.dfp.Dfp|new:org.apache.commons.math.dfp.Dfp:org.apache.commons.math.dfp.Dfp",
    "M|org.apache.commons.math.dfp.Dfp|align|int|new:org.apache.commons.math.dfp.Dfp:org.apache.commons.math.dfp.Dfp",
    "M|org.apache.commons.math.dfp.Dfp|ceil||new:org.apache.commons.math.dfp.Dfp:org.apache.commons.math.dfp.Dfp",
    "M|org.apache.commons.math.dfp.Dfp|classify||new:org.apache.commons.math.dfp.Dfp:org.apache.commons.math.dfp.Dfp",
    "M|org.apache.commons.math.dfp.Dfp|compare|org.apache.commons.math.dfp.Dfp,org.apache.commons.math.dfp.Dfp|static",
    "M|org.apache.commons.math.dfp.Dfp|complement|int|new:org.apache.commons.math.dfp.Dfp:org.apache.commons.math.dfp.Dfp",
    "M|org.apache.commons.math.dfp.Dfp|copysign|org.apache.commons.math.dfp.Dfp,org.apache.commons.math.dfp.Dfp|static",
    "M|org.apache.commons.math.dfp.Dfp|toDouble||new:org.apache.commons.math.dfp.Dfp:org.apache.commons.math.dfp.Dfp",
    "C|org.apache.commons.math.dfp.Dfp|<init>|org.apache.commons.math.dfp.DfpField,long",
    "C|org.apache.commons.math.dfp.Dfp|<init>|org.apache.commons.math.dfp.DfpField",
    "C|org.apache.commons.math.dfp.Dfp|<init>|org.apache.commons.math.dfp.DfpField,int",
    "C|org.apache.commons.math.dfp.Dfp|<init>|org.apache.commons.math.dfp.DfpField,byte",
    "C|org.apache.commons.math.dfp.Dfp|<init>|org.apache.commons.math.dfp.DfpField,java.lang.String",
    "C|org.apache.commons.math.dfp.Dfp|<init>|org.apache.commons.math.dfp.DfpField,byte,byte",
    "C|org.apache.commons.math.dfp.Dfp|<init>|org.apache.commons.math.dfp.Dfp",
    "C|org.apache.commons.math.dfp.Dfp|<init>|org.apache.commons.math.dfp.DfpField,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
