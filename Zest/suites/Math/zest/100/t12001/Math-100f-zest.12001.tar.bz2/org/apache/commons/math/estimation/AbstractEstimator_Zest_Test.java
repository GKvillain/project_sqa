package org.apache.commons.math.estimation;
import org.junit.Test;
import static org.junit.Assert.*;
public class AbstractEstimator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\012",
        Z.run(T, 1, 9, 11, 9, "\udb11\ude3e\u461d\ud801\udfff\ud944\udc0d", "\uca38\uaac4\u0fa5\u1b22\u97cb\u372d\u7d7e\u9600\u1647\ub3d3", "\ud8a3\uddc9",
        18, 95697, 742501555, -8132663940034130652L, -68140L, false, true, (char) 51322, (char) 48292,
        Double.longBitsToDouble(0x3fdd1c2922018c0cL), Double.longBitsToDouble(0x3fe2e0c77c111609L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\012",
        Z.run(T, 1, 9, 11, 9, "\udb11\ude3e\u461d\ud801\udfff\ud944\udc0d", "\uca38\uaac4\u0fa5\u0eb1\u97cb\u372d\u7d7e\u9600\u1647\ub3d3", "\ud8a3\uddc9",
        18, 95697, 742501555, -8132663940034130652L, -34604L, false, true, (char) 51322, (char) 48292,
        Double.longBitsToDouble(0x3fdd1c2922018c0cL), Double.longBitsToDouble(0x3fb7063bc0000048L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\012",
        Z.run(T, 1, 11, 8, 9, "\udb2f\udeec\u461d\ud801\udfff\ud944\udc0d", "\ubbf5\uc8fa\u0fa5\u1b22\u97cb", "\ud95d\udea5\udb06\udc4d\udbe2\udd69\udbb3\udd97\ud80f\udf07\udba3\udc09\u8f32\ud867\udf97\udaa3\udf4e\udab0\udd9a\ud95a\udcef\udacb\udd1a\uda8a\udd00\ud862\udf64\udaa0\udd24\ud8d4\udcce\ud936\ude66\ud8aa\ude78\ud9a3\udfa8\udbfe\udf10\udacc\udf84\uda9f\udf12\ud93b\uded5\ud955\ude21\u875d\udae8\udcc0\ud837\udfdc\ud818\udfb7\uda0c\udc1b\ud917\udcd1",
        18, 52527, 1866775454, -971545999291444813L, -32082L, true, true, (char) 3283, (char) 3335,
        Double.longBitsToDouble(0x3fcfdcf8fc3e2f18L), Double.longBitsToDouble(0x3fe3cac8561d9117L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\012",
        Z.run(T, 1, 9, 11, 3, "\udb11\ude3e\u461d\ud801\udfff\ud944\udc0d", "\uca38\uaac4\u0fa5\u1b22\u97cb\u372d\u7d7e\u9600\u1647\ub3d3", "\ud8a3\uddc9",
        18, 95697, -815863629, -8132702233962541788L, -68140L, false, true, (char) 51322, (char) 48292,
        Double.longBitsToDouble(0x3fdd1c2922018c0cL), Double.longBitsToDouble(0x3fe2e0c77c111609L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 8, 9, "\udadf\udf45\udaf0\udc9d\udb8b\udc34\ud8c8\udf72", "\uca38\uaac4\u2224\u77eb\ub371\u25cb\u05ea\u9600\u3ef1\ua277", "\ud8a3\uddc9\ud965\udd21\udb85\ude97\ud8d9\udd59\ud97a\udd1b\udbad\udc15\ud8c0\udf6a\uda97\udce1\ud85b\udde1\u88b0\ud8d4\udcbe\ud936\ude66\udb98\udf90\ud840\ude28\udbda\udf1e\ud80a\udcc9\ud8d5\ude99\udbe7\udda5\ud9c3\ude05\ud98f\udf9e\u236d\ud9f9\udea7\ud967\udf5c\ud9f8\udf5c\uda2a\ude61\uda75\udd48\ud996\udd51\ud916\udca1\ue3a3\ud9c3\udc86\ud9b0\udec2\ud896\uddc8\udb71\udcc4\ud9f9\ude17\uda32\udeb0\ud95f\udd78\uda49\udf9c\ud85b\udcd6\ud919\ude97\ud865\udcb2\udaab\udd74\ud89c\udf1e\ud8c8\ude47\u0924\ud979\udc11\ud8f5\udf62\ud913\udc68\ud97c\ude57\ud828\udc7a\udb72\ude4a\ud93b\ude08\ud96f\udee7\udbc4\udceb\udb59\udff9\ud925\uddc5",
        20, 18151, 802086917, 6628073060204314279L, -22535L, true, false, (char) 48410, (char) 17635,
        Double.longBitsToDouble(0x3f8dfa2994ff3100L), Double.longBitsToDouble(0x3fe6bcd80d627a00L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 1, 9, "\ud949\ude18\u461d\ud801\udfff\ud944\udc0d", "\uca38\uaac4\u0fa5\u1b22\u97cb\u372d\u7d7e\u6bc8\u48ac\u2d17", "\ud8a3\uddc9",
        18, 95697, 742501555, -8132663940034130652L, -68140L, false, true, (char) 51322, (char) 48292,
        Double.longBitsToDouble(0x3fdd1c2922018c0cL), Double.longBitsToDouble(0x3fe2e0c77c1116b4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\012",
        Z.run(T, 1, 5, 1, 9, "\udb11\ude3e\u461d\ud801\udfff\ud944\udc0d", "\ud6aa", "\ud87c\udd8c",
        54, 59520, -1707090409, -7208613110492660262L, 42563L, false, true, (char) 37380, (char) 64595,
        Double.longBitsToDouble(0x3fd7148c93f10656L), Double.longBitsToDouble(0x3fd3c98a7a491e44L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 8, 9, "\uda4b\ude39\ud840\udd12\ud837\udf33\ud944\udc0d\uda38\udd6d\ud9a4\udfe7\ud9c7\udc98\udbf1\ude8f\udba7\udc75", "\u2d0f\u7d7e\u9600\u1647\ub3d3\u6a35\u0086\u7c3d\u618d\u7c23\u87d4", "\udbe0\udcc8\udaff\udeb7\ud862\udf64\udaa0\udd24\udb13\udc6e\u63f3\udbd5\udeb1\ud9a3\udfa8\udacb\udc37\udac3\udd82\ud98a\udc19\ud928\udfa6\ud9a4\udff9\ud9eb\ude02\udb5a\udd63\udb4b\udf0f\udb13\udd19\udbe7\udd46\ud9fa\udc97\u2d41\ud9a6\udf6c",
        25, 79735, 1180175227, 9109496566408445102L, 4460L, false, true, (char) 65437, (char) 34815,
        Double.longBitsToDouble(0x3fd8fc5e99489482L), Double.longBitsToDouble(0x3fe4d7dc9656b9c9L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 11, 9, "\udb11\ude3e\u45d5\ud801\udfff\ud944\udc0d", "\uca38\uaac4\u0fa5\ua10e\u55ea\u372d\u7d7e\u9600\u1647\ub3d3\u6a35\u0086\u7c3d\u618d\uc46f\u0127\uab77\u5044\u23ba\u7060", "\ud8d4\udcce\ud936\ude66\ud8aa\ude78\ud9a3\udfa8\ua1e7\u2d34\ud903\ude97\uda3e\udd74\ud9fe\udcbd",
        5, 86979, 951826848, -1107255382902278623L, -27636L, true, true, (char) 16183, (char) 52372,
        Double.longBitsToDouble(0x3fdf7c287cd94c8aL), Double.longBitsToDouble(0x3fc909b0a653e960L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.apache.commons.math.estimation.EstimationException\012",
        Z.run(T, 1, 11, 9, 9, "\ud8aa\uddca\ud874\udfc2\ud80c\ude50\udb4d\udfff", "\uca38\uaac4", "\ud821\udf04\udb71\ude0d",
        0, 18909, -1400676351, 2201732024924777699L, -34543L, false, false, (char) 55064, (char) 25310,
        Double.longBitsToDouble(0x3fd3c2c41a491e44L), Double.longBitsToDouble(0x3fef39c51eebc9daL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!org.apache.commons.math.estimation.EstimationException\012",
        Z.run(T, 1, 11, 0, 0, "\udb2f\udeec\u461d\ud801\udfff\ud944\udc0d", "\ubb8a\uc8fa\u0fa5\u1b22\u97cb", "\ud95d\udea5\udbf9\udde6\uda4a\uddc4\udbb3\udd97\ud80f\udf07O\000\ud867\udea6\udaa3\udf4e\udab0\udd9a\ud95a\udcef\udacb\udd1a\uda8a\udd00\000\000\ud8d4\udcce\ud936\ude66\ud8aa\ude78\\\udbfe\udf10\udacc\udf84\uda9f\udf12\ud93b\uded5\ud955\ude21\uda88\udc51\udae8\udcc0\u1684\000z\000",
        -5, 52288, 1866775454, -971545999291444813L, -32082L, true, true, (char) 23471, (char) 56319,
        Double.longBitsToDouble(0x3fcfdcf8fc3e2f18L), Double.longBitsToDouble(0x3fe3cac8561d9117L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\0121=void |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\012",
        Z.run(T, 2, 11, 7, 5, "\ud879\udd10", "\u77a6\ucbd9\ua1bd\ubc6a\uc8fa\u33cb\u609d\u30da\u51f6\ucf87\u756c\u1647\ub3d3\u6954\ua91d\u3561\uc9cd\ub407\ub380", "\udacb\udd65\uda8a\udd00\ud862\udf64\udaa0\udd24\ud8d4\udcce\uda9e\udf79\ud95a\udc80\udbff\uddbe\udb62\udf3e\udacc\udf84\uda9f\udf12\ud941\uddd5\ud955\ude21\u875d\udae8\udcc0\ud837\udfdc\ud9ca\udfd1\uda0c\udc1b\ud917\udcd1\uda15\udd05",
        12, 92454, 651070736, -6731495812672020470L, -58435L, false, true, (char) 3335, (char) 16912,
        Double.longBitsToDouble(0x3fcae5fdc9e566fcL), Double.longBitsToDouble(0x3fe0ec88b8d2e435L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 8, 9, "\udb2f\udeec\u461d\ud801\udfff\ud948\ude0d", "\u19a5\u611e\ubd1e\ud253\u15b8", "\ud95d\udea5\udb06\udc4d\udbe2\udd69\udbb3\udd97\ud80f\udf07\udba3\udc09\u8f32\ud9f9\udd1a\udaaf\udc4e\udab0\udd9a\udb31\ude2e\udad5\udcb4\uda8a\udd00\ud862\udf64\udaa0\udd24\ud8d4\udcce\ud936\ude2b\udafb\udec1\ud884\udcdc\udb7c\uddaf\udacc\udf84\ud90f\udc29\ud87f\uded7\udbe7\ude6d\ud922\udf49\uda7a\udf4f\udb24\ude33\ud818\udfb7\uda0c\udc1b\ud8c1\udcc6",
        18, 69423, 1866775454, -971545998495247029L, 94226L, true, true, (char) 32518, (char) 3411,
        Double.longBitsToDouble(0x3fcfdcf8e9ea2f18L), Double.longBitsToDouble(0x3febcac8561d7175L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 10, 9, "\udb11\ude3e\u461d\ud801\udfff\ud837\udd67", "\uc1c4", "\ud87c\udd8c",
        54, 59520, -1764827625, 6208911619280661436L, 42563L, false, true, (char) 26372, (char) 64595,
        Double.longBitsToDouble(0x3fd7148c93f10656L), Double.longBitsToDouble(0x3fd3c98a7a482a16L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 6, 9, "\ud8b6\ude2e\ud840\udd12\ud837\udf33\ud944\udc0d\uda38\udd6d\ud9a4\udfe7\ud9c7\udc98\udbf1\ude8f\udba7\udc75", "\u2d0f\u7d7e\u9600\u498d\u433d\u6a35\u0086\u7c3d\u618d\u7c23\u87d4", "\udbe0\udcc8\udaff\udeb7\ud862\udf64\udaa0\udd24\ud8e2\ude35\u63d2\udbd5\udeb1\ud9a3\udfa8\udacb\udc37\udac3\udd82\ud98a\udc19\ud928\udfa6\ud9a4\udff9\ud9eb\ude02\udb5a\udd63\udb4b\udf0f\udb13\udd19\udbe7\udd46\ud9fa\udc97\ud95c\udce8\ud8a3\udef7",
        42, 79640, 1180175227, 9109496566408445102L, 4460L, false, true, (char) 44183, (char) 34815,
        Double.longBitsToDouble(0x3fd8fc5e99489482L), Double.longBitsToDouble(0x3fe4d7dc9656b9c9L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 0, "\udb2f\udeec\u461d\ud801\udfff\ud944\udc0d", "\ubb8a\uc8fa\u0fa5\u1b22\u97cb", "\ud95d\udea5\udbf9\udde6\uda4a\uddc4\udbb3\udd97\ud80f\udf07O\000\ud867\udea6\udaa3\udf4e\udab0\udd9a\ud95a\udcef\udacb\udd1a\uda8a\udd00\000\000\ud8d4\udcce\ud936\ude66\ud8aa\ude78\\\udbfe\udf10\udacc\udf84\uda9f\udf12\ud93b\uded5\ud955\ude21\uda88\udc51\udae8\udcc0\u1684\000z\000",
        -5, 52288, 1866775454, -971545999291444813L, -32082L, true, true, (char) 41223, (char) 56546,
        Double.longBitsToDouble(0x3fcfdcf8fc3e2f18L), Double.longBitsToDouble(0x3fe3cac8561d9117L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\0121=void |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\012",
        Z.run(T, 2, 11, 11, 2, "\ud879\udd10", "\u77a6\ucbd9\ua1bd\ubc6a\u2827\u40ef\u6ff6\u30da\u51f6\ucf87\u55af\u85e4\uab46\uc283\u68e5\u589a\uc9cd\ub407\ub380", "\ud85f\udf1c\ud88e\uddf4\ud86f\ude0a\uda2a\udc5d\ud8d4\udcdd\uda9e\udf79\ud95a\udc80\udbff\uddbe\udb62\udf3e\udacc\udf84\uda9f\udf12\ud941\uddd5\ud955\ude21\u875d\udae8\udcc0\ud837\udfdc\ud9ca\udfd1\uda0c\udc1b\ud97c\udd22\uda07\udc67",
        12, 86662, 588099218, -6721914664052613110L, -58435L, false, true, (char) 3335, (char) 16912,
        Double.longBitsToDouble(0x3fcae5fdc9e566fcL), Double.longBitsToDouble(0x3fe0ec88b8d2e435L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 9, "\ud879\udd10", "\u549e\ucbd9\ua1bd\ubc6a\uc8fa\u33cb\u609d\u30da\u7a53\u6eff\u756c\u68a0\u1e73\u6e00\ua91d\u3561\uc9cd\ub407\ub380", "\udacb\udd65\uda8a\udd00\ud862\udf64\udaa0\udd24\ud8d4\udcce\uda9e\udf79\ud8f5\udf12\udbff\uddbe\ud8e0\udd2d\udab0\udc2c\uda9f\udf12\ud941\uddd5\ud955\ude21\u875d\udae8\udcc0\ud837\udfdc\ud9ca\udfd1\udb97\udda1\uda7e\udd50\uda15\udcd7",
        12, 92454, 651070736, -6731495812672020470L, -67498L, false, true, (char) 3335, (char) 18704,
        Double.longBitsToDouble(0x3fd3385645329ebeL), Double.longBitsToDouble(0x3fe7f0b0b8a5e435L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\0121=java.lang.Integer:0 |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\012",
        Z.run(T, 2, 5, 4, 2, "\udb2f\udeec\ud815\udefe\udbe6\udd18\uda49\udf5b", "\u19a5\u611e\ubd1e\ud253\u15b8", "\uda86\udeb7\udac6\udef0\udb40\uddf6\udbb3\udd97\ud80f\udf07\udba3\udc09\u8f32\ud9f9\udd1a\udaaf\udc4e\udab0\udd9a\udb31\ude2e\udad5\udcb4\ud92c\ude50\ud862\udf64\uda15\udfb7\ud8d4\udcce\ud936\ude2b\udafb\udec1\ud884\udcdc\udb7c\uddaf\udacc\udf84\ud90f\udc29\ud87f\uded7\udbe7\ude6d\udaae\udf4f\uda7a\udf4f\udb24\ude33\ud818\udfb7\udb4d\udf1d\udad7\udc4d",
        18, 69423, 1866775454, -971545998501669557L, -77255L, true, true, (char) 55561, (char) 22594,
        Double.longBitsToDouble(0x3febcac8561d7175L), Double.longBitsToDouble(0x3f82e91058e56b40L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\0121=void |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\012",
        Z.run(T, 2, 9, 9, 9, "\ud8b6\ude2e\ud845\udf2a\uda66\udd82\uda05\udfde\udb6c\udfd6\ud9a4\udf2b\ud9c7\udc98\udba5\ude0a\udba7\udc75", "\u2d0f\u7d7e\u9600\u498d\uc999\u3916\u791f\u55e3\u7ec2\u7c23\u87d4", "\udbe0\udcc8\udaff\udeb7\ud862\udf64\ud85e\udfba\uda69\uded7\u63d2\udbd5\udeb1\udb6f\udc0d\udacb\udd09\udac3\udd82\ud98a\udc19\ud928\udfa6\ud9a4\udff9\ud9eb\ude02\uda57\udef3\udb4b\udf0f\udaf9\udf4b\udb72\udeaa\ud9e6\udcee\ud970\udee8\udaa3\udef7",
        42, 79640, 963443323, 9085022120473245870L, 4460L, false, true, (char) 44183, (char) 34815,
        Double.longBitsToDouble(0x3fd8fc5e994894dcL), Double.longBitsToDouble(0x3fd9afb92cad7358L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\012",
        Z.run(T, 1, 9, 11, 9, "\udb11\ude3e\u461d\ud801\udfff\ud944\udc0d", "\uca38\uaac4\u0fa5\u1b22\u97cb\u372d\u7d7e\u9600\u1647\ub3d3", "\ud8a3\uddc9",
        18, 95697, 742501555, -8132663940034130652L, -43048L, false, true, (char) 51322, (char) 48292,
        Double.longBitsToDouble(0x3fdd1c2922018c0cL), Double.longBitsToDouble(0x3fe2e0c77d566e3cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\0121=!org.apache.commons.math.estimation.EstimationException\012",
        Z.run(T, 2, 9, 11, 3, "\udb11\ude3e\u461d\ud801\udfff\ud944\udc0d\uda38\udd6d\ud9a4\udfe7\ud9c7\udc98\udbf1\ude8f\udba7\udc75\ud87c\udd8c\ud821\udf04\ud83d\udd71\udbb8\udc17\udaeb\udeac\udb06\udc4d\udbe2\udd69", "\uad6a", "\ud93f\uddd5\ud87b\udfcb\ud9b2\udc7a\ud83a\udcb6\uda8a\udd00\ud862\udf64\udaa0\udd24\ud8d4\udcce\ud936\ude66\ud8aa\ude78\ud9a3\udfa8\ud830\udc89\ud820\udc6d\ud993\ude77",
        37, -372, 493758540, -5808179439861197047L, 51949L, true, false, (char) 795, (char) 47190,
        Double.longBitsToDouble(0x3feee6a497a5d8e9L), Double.longBitsToDouble(0x3fdfacb465f2b350L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\0121=!org.apache.commons.math.estimation.EstimationException\012",
        Z.run(T, 2, 9, 11, 3, "\udb11\ude3e\u461d\ud801\udfff\ud944\udc0d\ud82e\uddc8\ud9a4\udfe7\ud9c7\udc98\udbf1\ude8f\udba7\udc75\ud87c\udd8c\ud821\udf04\ud944\udc54\udb80\ude00\udaeb\udeac\u00da\000", "\uad6a", "\000\000\udb5a\udf4c\ud83a\udcb6\uda8a\udd00\ud862\udf64\udaa0\udd24\ud8d4\udcce\ud936\ude66\ud8aa\ude78\ud9a3\udfa8\ud830\udc89\ud820\udc6d\ud993\ude77",
        37, -1000, 493758464, 28485679100985344L, 51949L, true, false, (char) 11291, (char) 32586,
        Double.longBitsToDouble(0x3feee6a497a5d8e9L), Double.longBitsToDouble(0x3fdfacb46000b200L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\0121=!org.apache.commons.math.estimation.EstimationException\012",
        Z.run(T, 2, 9, 11, 0, "\udb11\ude3e\u461d\ud801\udfff\ud944\udc0d\ud9c0\udd71\udbaa\udfea\udb16\udc7e\udbf1\udeaf\ua10c\ud87c\uddf4\ud821\udf04\ud83d\udd71\ue105\ud8fd\udd23\udb06\udc4d\u386a", "\uad75", "\ud8ce\udd15\udbb0\udf3a\ud9b2\udc7a\ud83a\udcb6\uda8a\udd00\ud8c4\udd94\udaa0\udd24\uda35\udd9f\u2f58\uda86\ude55\ud838\ude3a\ud91f\udd41\ud9db\udc9c\udb4b\uddee",
        8, -85, 1961712862, -2584934483607159066L, -44723L, false, true, (char) 46190, (char) 57486,
        Double.longBitsToDouble(0x3fdfacb465f2b350L), Double.longBitsToDouble(0x3fd62376a2dc355eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.estimation.GaussNewtonEstimator:@?\0121=!org.apache.commons.math.estimation.EstimationException\012",
        Z.run(T, 2, 9, 11, 3, "\udb11\ude3e\ud8ef\ude4b\ud801\udfff\ud944\udc0d\uda38\udd6d\ud9a4\udfe7\ud9c7\udc98\udb6a\udc4c\udbca\ude81\ud87c\udd8c\ud821\udf04\ud83d\udd71\udbb8\udc17\udaeb\udeac\ud896\ude7c\udb34\udcb4", "\uad6a", "\udaeb\udf31\ud87b\udfae\ud9b2\udc7a\udba2\udec9\uda94\udcb3\ud862\udf64\udaa0\udd24\ud8d4\udcce\ud936\ude66\ud805\udda8\ud9a3\udfa8\ud830\udc89\ud8b0\udc1d\uda35\uddd1",
        24, -410, 493758540, -5808179439858617079L, 51949L, false, false, (char) 7933, (char) 21740,
        Double.longBitsToDouble(0x3f863cccc6288c80L), Double.longBitsToDouble(0x3fdfacb46cd8b750L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.estimation.AbstractEstimator|getCovariances|org.apache.commons.math.estimation.EstimationProblem|new:org.apache.commons.math.estimation.GaussNewtonEstimator:int,double,double",
    "M|org.apache.commons.math.estimation.AbstractEstimator|guessParametersErrors|org.apache.commons.math.estimation.EstimationProblem|new:org.apache.commons.math.estimation.GaussNewtonEstimator:int,double,double",
    "M|org.apache.commons.math.estimation.AbstractEstimator|estimate|org.apache.commons.math.estimation.EstimationProblem|new:org.apache.commons.math.estimation.GaussNewtonEstimator:int,double,double",
    "M|org.apache.commons.math.estimation.AbstractEstimator|getChiSquare|org.apache.commons.math.estimation.EstimationProblem|new:org.apache.commons.math.estimation.GaussNewtonEstimator:int,double,double",
    "M|org.apache.commons.math.estimation.AbstractEstimator|getCostEvaluations||new:org.apache.commons.math.estimation.GaussNewtonEstimator:int,double,double",
    "M|org.apache.commons.math.estimation.AbstractEstimator|getJacobianEvaluations||new:org.apache.commons.math.estimation.GaussNewtonEstimator:int,double,double",
    "M|org.apache.commons.math.estimation.AbstractEstimator|getRMS|org.apache.commons.math.estimation.EstimationProblem|new:org.apache.commons.math.estimation.GaussNewtonEstimator:int,double,double",
    "M|org.apache.commons.math.estimation.AbstractEstimator|incrementJacobianEvaluationsCounter||new:org.apache.commons.math.estimation.GaussNewtonEstimator:int,double,double",
    "M|org.apache.commons.math.estimation.AbstractEstimator|initializeEstimate|org.apache.commons.math.estimation.EstimationProblem|new:org.apache.commons.math.estimation.GaussNewtonEstimator:int,double,double",
    "M|org.apache.commons.math.estimation.AbstractEstimator|setMaxCostEval|int|new:org.apache.commons.math.estimation.GaussNewtonEstimator:int,double,double",
    "M|org.apache.commons.math.estimation.AbstractEstimator|updateJacobian||new:org.apache.commons.math.estimation.GaussNewtonEstimator:int,double,double",
    "M|org.apache.commons.math.estimation.AbstractEstimator|updateResidualsAndCost||new:org.apache.commons.math.estimation.GaussNewtonEstimator:int,double,double",
    "M|org.apache.commons.math.estimation.AbstractEstimator|getCovariances|org.apache.commons.math.estimation.EstimationProblem|new:org.apache.commons.math.estimation.GaussNewtonEstimator:int,double,double",
    "M|org.apache.commons.math.estimation.AbstractEstimator|guessParametersErrors|org.apache.commons.math.estimation.EstimationProblem|new:org.apache.commons.math.estimation.GaussNewtonEstimator:int,double,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
