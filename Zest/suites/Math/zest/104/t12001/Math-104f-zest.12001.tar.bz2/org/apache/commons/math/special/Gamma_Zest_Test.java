package org.apache.commons.math.special;
import org.junit.Test;
import static org.junit.Assert.*;
public class Gamma_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Double:0.6119026914934771\012",
        Z.run(T, 1, 2, 1, 1, "\ud827\udc88\ud970\udeac\uda4b\udfda\udb29\udeff", "\uaa56\u0812\u8c59\u4902\u570a\u829e\u6ced\u3957\u2047\u42d9\u7191\u0943\ud6e6\u875a\u241b\ud58d\u6966\u0968\u3b3b\u11f1\u9aed\u05cd\u7730", "\uda21\ude0d",
        11, 99504, -1989533644, -3388335888947797446L, 61207L, true, true, (char) 8472, (char) 19264,
        Double.longBitsToDouble(0x3fe73676785886feL), Double.longBitsToDouble(0x3fe98bcdbbf62d5bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Double:0.41261394758562253\012",
        Z.run(T, 1, 4, 4, 4, "\ud827\udc88\ud970\udeac\ud885\udeb8\ud887\udc8f", "\uaa56\u5e96\u8c59\u4902\u2143\ubd2d\u6ced\u5376\u155e\u423e", "\ud8fe\ude20\uda33\udd50\udba6\ude32\u84de\uda2f\udfd6\ud8e1\ude0b\ud9d4\ude68\ud8b4\uded6\uda5a\uddf9\ud8e5\udfdb\udb4a\ude1d\udb4e\udd03\udb67\udcd9\uda17\udcb7\udaf9\udd2d\udafc\udd2c\udbcc\udd36\ud9cb\uddd3\u19b8\udacf\udef0\udb5f\udd54\ud860\ude41\uda2f\udf50\ud92a\ude28\uda56\udf92\ud987\ude6c",
        52, 29047, -1275187482, -1617694282219618967L, 95800L, true, true, (char) 30629, (char) 27250,
        Double.longBitsToDouble(0x3fe80c9a3a47719bL), Double.longBitsToDouble(0x3fe783258b546a8cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Double:0.7266854609635524\012",
        Z.run(T, 1, 2, 1, 1, "\ud827\udc88\uda31\udf70\uda4b\udfda\udb29\udeff", "\uaa56\u0812\u8c59\u4902\u570a\u829e\u6ced\u3957\u2047\u42d9\u7191\u0943\ud6e6\u875a\u241b\ud58d\ub227\u0968\u3b3b\u11f1\u9aed\u05cd\u7730", "\uda21\ude0d",
        11, 99504, -1989533644, -3388335888947797446L, 61207L, true, true, (char) 8472, (char) 4523,
        Double.longBitsToDouble(0x3fe3392c885886feL), Double.longBitsToDouble(0x3fe98bcdbbf62d5bL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 2, 1, 1, "\ud827\udc88\ud970\udeac\uda4b\udfda\udb29\udeff", "\uaa56\u0812\u8c59\u4902\u570a\u829e\u6ced\u3957\u2047\u3d38\u7174\u0943\ud6e6\u875a\u241b\ud58d\u6966\u0968\u3b3b\u11f1\u9aed\u05cd\u7730", "\uda21\ude0d",
        11, 99504, -1989533644, -3388335888947797446L, 61207L, true, true, (char) 8472, (char) 19264,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 1, 1, 4, "\ud827\udc88", "\000\u338e\u3da5\uaa56", "\u2d85\000\u7daf",
        10, 77680, 21248, 1464401920L, 31072L, true, false, (char) 4242, (char) 2393,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MaxIterationsExceededException\012",
        Z.run(T, 1, 2, 1, 1, "\ud827\udc88\ud970\udeac\uda4b\udfda\udb29\udeff", "\u4f80\u0812", "\ud9f5\ude64\ud80f\uddfe\udb16\udd1a\ud8c5\udf74\ud804\uddbb",
        -2, 61853, 16203806, -7973735232158293631L, -76898L, true, true, (char) 51843, (char) 4846,
        Double.longBitsToDouble(0x3fea084aca58b144L), Double.longBitsToDouble(0x3fddff9bea764360L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Double:0.535043795876152\012",
        Z.run(T, 1, 1, 3, 0, "\ud827\udc88\ud970\udeac\uda4b\udfda\ud953\udeb4", "\u2276\u086f\u8c59\u4902\uaad0\u82f1\u6ced\u3957\u2094\u42d9\u7191\ub410\ucea1\u86e6\u241b\ud58d\u6966\u585f\u62e0\u152c\u1ff9\u1d5d\u7730", "\udb39\udf42",
        10, 99504, -1606763044, -3388335983437077958L, 66480L, true, true, (char) 5258, (char) 19154,
        Double.longBitsToDouble(0x3fe73676795886feL), Double.longBitsToDouble(0x3fdf335cefd1777cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MaxIterationsExceededException\012",
        Z.run(T, 1, 2, 1, 1, "\ud82b\udf68\ud970\udeac\uda4b\udfda\udb29\udeff", "\uaa56\u0812\u8c59\u825d\u56fc\u829e\u7c55\ub0c4\u2047\u42d9\u7191", "\ud916\udf08\ud9d3\udd3d\udb94\udfb6",
        2, 87704, 464133671, -5673146138736305576L, -76378L, false, false, (char) 3106, (char) 14959,
        Double.longBitsToDouble(0x3faa1b33c3d836a0L), Double.longBitsToDouble(0x3fe1d687d2e80f8fL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:0.9483223910562935\012",
        Z.run(T, 1, 2, 1, 1, "\ud827\udc88\ud970\udeac\uda4b\udfda\udb29\udeff", "\uaa56\u0812\u8c59\u4902\u570a\u829e\u6ced\u3957\u4347\u42d9\u7191\u0943\u5be6\u875a\u241b\ud58d\u6966\u0968\u3b3b\u11f1\u9aed\u05cd\u7730", "\uda21\ude0d",
        11, 99504, -1989533644, -3388335888947797446L, -24560L, false, false, (char) 50320, (char) 34131,
        Double.longBitsToDouble(0x3fc0b8925e1de2e4L), Double.longBitsToDouble(0x3fe73740e85886feL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Double:2.9488048736980343\012",
        Z.run(T, 1, 0, 1, 1, "\ud827\udc88\u40b8\ud9de\udd26\ud847\udd5c", "\uaa56\u0812\u8c59\u4902\u326d\u828b\u6ced\u3c4d", "\udb85\udf41\udaf5\ude19\uda1a\udfe9\ud916\udf08\ud9d3\udd3d\ud99e\udd5b\ud96e\udf0c\ud9e7\udd32",
        -1, 95633, -104965544, 2427631371903522107L, -21851L, false, false, (char) 3106, (char) 14959,
        Double.longBitsToDouble(0x3faa1b33e87896a0L), Double.longBitsToDouble(0x3fe1d687d2e80f8fL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MaxIterationsExceededException\012",
        Z.run(T, 1, 2, 3, 1, "\ud827\udc88\ud970\udeac\uda4b\udfda\udb29\udeff", "\uaa56\u0812\u8c59\u4902\u570a\u829e\u6ced\u3957\u2047\u42d9\u7191\ub1da\u4222\u5c63\u8b9f\ud58d\u6966\u0968\u9b27\ua6ed\u9aed\u05cd\u7730", "\uda21\ude0d",
        0, 43035, -1989533644, -3388335888746470854L, -95977L, true, true, (char) 8472, (char) 19264,
        Double.longBitsToDouble(0x3fe736767f3227feL), Double.longBitsToDouble(0x3fa54aec3f62dba0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Double:0.5084261497550098\0121=java.lang.Double:0.5084261497550098\012",
        Z.run(T, 2, 1, 1, 1, "\ud827\udc88\ud970\udeac\uda4b\udfda\ud9dc\ude37", "\uaa56\u0812\u8c59\u05a1", "\udb16\udd1a\ud8c5\udf74\ud800\uddb9\ud84e\udc14\udb85\udf41",
        16, 51094, -1842339455, -1096215139896285758L, 62357L, true, false, (char) 63641, (char) 45232,
        Double.longBitsToDouble(0x3fd66816ba7643e6L), Double.longBitsToDouble(0x3fbcf7f9d7304248L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Double:0.04113171878802779\012",
        Z.run(T, 1, 3, 1, 0, "\u9067\uda9b\ude00\uda4b\udfda\udb29\udeff", "\uaa56\u0812\u8c59\u4902\u570a\u829e", "\ud82e\udfab\ud84c\udee9\ud93a\udf9c\uda2e\udd03\uda1a\udf88\ud916\udf08\u0f77\uda58\udfdf\udbe1\udd6d\udbe4\udccc\ud803\uddb0\udb78\udef5\uda38\udee3\ud8f9\udd8f",
        -3, 34187, -1026557210, -2772343450568871269L, -94253L, false, false, (char) 54071, (char) 49684,
        Double.longBitsToDouble(0x3faf5cdde1609970L), Double.longBitsToDouble(0x3fdb74ed93dac6ccL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Double:0.5485937271393868\0121=java.lang.Double:0.4535194457317685\012",
        Z.run(T, 2, 4, 1, 1, "\ud827\udc88\ud9f6\ude14\uda4b\udfeb\udb29\udeff", "\u47ab\u74eb\u0488\u92b2\u4d7c\u829e\u6ced\u3957\u2047\uccdf\u0704\u0943\u0da7\u87af\u8879\uca1b\u6966\u0968\u3b3b\u11f1\u9aed\ucace\uc424", "\uda21\ude0d",
        4, 99649, -1989533644, 6267381712134585487L, -65207L, true, false, (char) 35658, (char) 31661,
        Double.longBitsToDouble(0x3fdb74ed93dac6ccL), Double.longBitsToDouble(0x3fc0b8924a1de2e4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:0.23077768627001038\012",
        Z.run(T, 1, 0, 4, 1, "\uda41\udcd4\ud970\udeac\uda48\udf8e\udb29\udeff", "\uaa56\u0812\u8c59\u4902\u570a\u829e\u6ced\u8cd9\u9b34\u42d9\u7191\u0943\ud6e6\u875a\u241b\ud58d\u6966\u0968\u47f4\u02ed\u90ee\u05cd\u7730", "\uda21\ude0d",
        11, 99504, -1989533644, -3388335888947797446L, 61207L, true, true, (char) 8472, (char) 19264,
        Double.longBitsToDouble(0x3fe73676785886feL), Double.longBitsToDouble(0x3fe98bcdbbf62d5bL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MaxIterationsExceededException\012",
        Z.run(T, 1, 2, 1, 1, "\ud827\udc88\ud970\udeac\uda4b\udfda\udb29\udeff", "\uaa56\u0812\u8c59\u4902\u570a\u829e\u6ced\u3957\u2047\u42d9\u7191\u0943\ud6e6\u875a\u241b\ud58d\u6966\u0968\u3b3b\u11f1\u9aed\u05cd\u7730", "\uda21\ude0d",
        11, 15632, 0, -3458764513559502278L, 61207L, true, true, (char) 8472, (char) 0,
        Double.longBitsToDouble(0x3e06218000000000L), Double.longBitsToDouble(0x3fe98bcdbbf62d5bL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\012",
        Z.run(T, 1, 4, 4, 4, "\ud827\udc88\ud970\udeac\ud885\udeb8\ud887\udc8f", "\uaa56\u5e96\u8c59\u4902\u2143\ubd2d\u6ced\u5376\u155e\ub440", "\ud8fe\ude20\uda33\udd50\udba6\ude32\u84de\uda2f\udfd6\ud8e1\ude0b\ud9d4\ude68\ud8b4\uded6\uda5a\uddf9\ud8e5\udfdb\udb4a\ude1d\udb4e\udd03\udb67\udcd9\uda17\udcb7\udaf9\udd2d\udafc\udd2c\udbcc\udd36\ud9cb\uddd3\u19b8\udacf\udef0\udb5f\udd54\ud860\ude41\uda2f\udf50\ud92a\ude28\uda56\udf92",
        36, 96552, -825240953, -5476888531835237473L, -60074L, false, false, (char) 38339, (char) 30629,
        Double.longBitsToDouble(0x3fa7092200193470L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Double:0.4126144795103386\0121=java.lang.Double:0.5873855204896614\012",
        Z.run(T, 2, 4, 2, 1, "\ud827\udc88\ud970\udeac\ud885\udeb8\udaaf\udcde", "\u1f06\ub685\u39c9\ua3c3\u2143\ucb6d\u3651\u5376\u155e\u423e", "\ud8fe\ude20\uda33\udd50\udba6\ude32\u84de\uda1c\uddd6\ud8e1\ude0b\ud9d4\ude68\ud8b4\uded6\uda5a\uddf9\u220e\udb4a\ude1d\udb4e\udd03\udb67\udcd9\uda17\udcb7\udab6\udcb3\ud99f\udfc3\udbf3\udce1\ud9cb\uddd3\u19b8\udacf\udef0\ud8a9\udcba\ud860\ude49\uda2a\udee7\udaa2\udf1b\uda4d\udcd9\ud987\ude6c",
        52, 29047, -361593626, -1617694956529484439L, 95800L, true, true, (char) 30629, (char) 27250,
        Double.longBitsToDouble(0x3fe80c99b247719bL), Double.longBitsToDouble(0x3fe783202b546a8cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 3, 1, 1, "\ud827\udc88\ud970\udeac\uda4b\udfda\udb29\udeff", "\uaa56\u0812\u8c59\u4902\u570a\u829e\u6ced\u3957\u2047\u3d38\u7174\ubd1c\ud6e6\u875a\u241b\ud58d\u6966\u0968\u3b3b\u11f1\u9aed\u05cd\u7730", "\uda21\ude0d",
        11, 99504, -1989533644, -3388335888947797446L, -44399L, false, false, (char) 50320, (char) 34131,
        Double.longBitsToDouble(0x3fb4f124943bc5c8L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 0, 1, 1, "\ud9f7\udeb0\udb95\udeea\udb26\uddfe\udb29\udeff", "\u9308\u3f1a\u05ba\u4902\u570a\u829e\u6ced\u3957\u2047\u3d38\u7174\u0943\ud6e6\u875a\u241b\ud58d\u6966\u0968\u3b3b\u11f1\u9aed\u05cd\u7730", "\uda21\ude0d",
        11, 99504, -1989533644, -3388335888947797446L, 61207L, true, true, (char) 34148, (char) 19238,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 4, 4, 1, "\ud827\udc88\udbf8\udc42\udb70\udff8\udb29\udeff", "\uba8c\u0812\u8c59\u4902\u570a\u829e\u6ced\u3957\u5a68\ub518\u27bd\ub7fd\ud6e6\u875a\u241b\ud58d\u6966\u0968\u3b3b\u11f1\u9aed\u05cd\u7730", "\uda27\udc47",
        11, 99504, -1989533644, -3388335887877594566L, 61207L, true, true, (char) 8472, (char) 19264,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MaxIterationsExceededException\012",
        Z.run(T, 1, 2, 1, 1, "\ud827\udc88\ud970\udeac\uda4b\udfda\udb29\udeff", "\ucb42\u0812", "\000\ud913\udda8",
        10, 66184, 1768248197, -2067516326225641443L, -73902L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e40000000000000L), Double.longBitsToDouble(0x3fe6f5007f410959L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Double:0.9240075787821315\0121=java.lang.Double:0.9240075789440573\012",
        Z.run(T, 2, 3, 4, 4, "\ud9a4\uddb5\uda3f\udd84\udaad\udf15\ud8dd\udde6\udbb6\udefb\uda41\udc66\ud988\ude5c\ud893\udccc\ud811\udff3\ud809\udfc1\udb7a\udf66\uc517\udabe\udcec\uda29\udeb1\ud804\uddbb\uc13c\ud8af\udc88\ud9d7\udf0c\ud8f2\uddd2\ud916\udf07\uda3a\udff1", "\u5d3b\u5d8a\u724d\u9aed\u3911\u4932\ud166\u9476", "\uda0c\udcdd\ud91d\ude09\ud8c9\udd39",
        3, 98551, -301987224, -4335429432523280308L, -68290L, true, false, (char) 63611, (char) 7994,
        Double.longBitsToDouble(0x3fd22cee0fb3231aL), Double.longBitsToDouble(0x3f14b90c58c2c000L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Double:0.7697032615523756\0121=!org.apache.commons.math.MaxIterationsExceededException\012",
        Z.run(T, 2, 1, 2, 2, "\ud827\udc88\ud970\udeac\uda34\udeda\udb29\udeff", "\u4f80\u0812", "\ud9f5\ude64\ud80f\uddfe\udba5\udc62\ud8c5\udf74\ud804\uddbb",
        -2, 61853, 16203806, -7973735229897339007L, 96680L, false, false, (char) 63641, (char) 2973,
        Double.longBitsToDouble(0x3fddff9bea764360L), Double.longBitsToDouble(0x3fe567cb7bbdfa3eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Double:0.800312732574115\0121=java.lang.Double:0.800312732574115\012",
        Z.run(T, 2, 1, 1, 4, "\ud82b\udf68\ud970\udeac", "\u068f\u8224\uc0a3\u0876\u8c59\u825d\u9aa7\uacde\u276c\u1bf9", "\uda8d\uddea\udbd2\udc1e\ud822\udd60\ud987\udf5e\ud9d4\udde9\udb94\udfb6\u0c3e",
        39, 34280, -1320882267, -450823578121622049L, 87350L, false, true, (char) 25184, (char) 3106,
        Double.longBitsToDouble(0x3fdf8f9769f1ed52L), Double.longBitsToDouble(0x3fe9effbba060773L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Double:0.39803847831535866\0121=java.lang.Double:0.39803847831535866\012",
        Z.run(T, 2, 3, 3, 1, "\udb2e\udc6b\ud970\udf17\uda4b\udfda\ud80f\udf3a", "\ua9c0", "\ud8c9\udfc4\u9e1d\ud9d6\udfac\uf62a\ud8c5\udf74\ud800\uddb9\ud9b8\udf89\udb27\udf32\udb14\udd62\uda63\ude78\u92d3\udb97\udd3c\udb64\udfca\ud89a\udf7c",
        23, 16827, -1314042942, -450823578121622049L, -43795L, true, true, (char) 28079, (char) 46081,
        Double.longBitsToDouble(0x3fe75823b0343667L), Double.longBitsToDouble(0x3fe3b44b53f2d0faL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Double:0.06520341552554365\0121=java.lang.Double:0.06520341552554365\012",
        Z.run(T, 2, 3, 3, 1, "\ud827\udc88\ud970\udeac\uda4b\udfda\udb55\ude01", "\uaa56\u0812\u8c59\u4902\u570a\u829e\u36ff\u744e\u2047\u42d9\u7191\ub1da\u4222\u5c63\u8b9f\ud58d\u6966\u0968\u9b27\ua6ed\u9aed\u05cd\u7730", "\uda21\ude76\ud93e\udede\udb26\ude1f\udbcc\udd36\uda42\udfb0\udb08\udfd9\uda92\udc78\udaa5\udd59\udae6\ude77",
        39, 8158, 1663045559, -4282322991859540859L, 19066L, false, true, (char) 25090, (char) 51631,
        Double.longBitsToDouble(0x3fcd9362b5e83a3cL), Double.longBitsToDouble(0x3feee94fdfe3f6a2L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Double:0.40555860720699305\0121=java.lang.Double:0.594441392793007\012",
        Z.run(T, 2, 2, 4, 1, "\udbf0\udd0d\ud970\udeac\uda4b\udfda\udb29\udeff", "\uaa56\u0812\u9e6c\u6dd2\u570a\u829e\u6ced\u3957\u2047\u42d9\u7191\u0943\ud6e6\u875a\u241b\ud58d\u7919\u0963\u3b3b\u11f1\u9aed\u05cd\ub530", "\uda21\ude0d",
        11, 15632, 0, -3458764513559502278L, -24560L, false, false, (char) 50320, (char) 34131,
        Double.longBitsToDouble(0x3fc0b89245c80000L), Double.longBitsToDouble(0x3f4459a162180000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 4, 4, 4, "\ud827\udc88\ud970\udeac\ud885\udeb8\ud83d\udeea", "\uaa56\u5e96\u9110\u4902\u2143\ubd2d\u6255\u8dda\ub031\ub440", "\ud8fe\ude20\uda52\udc50\udba6\ude32\u84de\uda2f\udfd6\ud8eb\udf08\ud9d4\ude68\ud8b4\uded6\uda5a\uddf9\ud8e5\udfdb\udab8\udeb4\udb4e\udd03\udb37\udf55\udbb9\udc7a\ud94a\udfd0\udb27\udd49\udbcc\udd36\ud8a4\udd8d\uda6b\ude13\udacf\udef0\udb5f\udd54\udbc5\ude33\uda39\udd94\ud92a\ude28\uda56\udf92",
        36, 97896, -825240953, 1065619069804006361L, -60074L, false, false, (char) 28603, (char) 30629,
        Double.longBitsToDouble(0x3fe1709220b2c716L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 2, 2, 1, "\ud827\udc88\ud970\udeac\uda4b\udfda\ud9db\udd00", "\uaa56\u0812\u8c59\u4902\u570a\u829e\u6ced\u393b\u2047\u3d38\u7174\u3b65\ud7a0\u875a\u241b\ud58d\u6966\u0968\u3b3b\u11f1\u9aed\u05cd\u7730", "\uda21\ude0d",
        11, 99504, -1989533644, -3388335888947797446L, -44399L, false, false, (char) 50320, (char) 34131,
        Double.longBitsToDouble(0x3fb4f124943bc5c8L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\0121=java.lang.Double:NaN\012",
        Z.run(T, 2, 3, 3, 3, "\ud931\udd8c\ud9f7\udf39\ud85f\udc24\udb29\udef1", "\uaa56\u0812\u8c59\u4902\u570a\u829e\u6ced\u3957\u2047\u3d38\u7174\ubd1c\ud6e6\u875a\u241b\ud58d\u6966\u0968\u629f\u55fe\u9af8\u05cd\u7730", "\uda21\ude0d",
        11, 99504, -1989533644, -3388335888947797446L, 61207L, true, true, (char) 8422, (char) 19264,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fef27b30f9b0777L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\0121=java.lang.Double:NaN\012",
        Z.run(T, 2, 1, 1, 1, "\ud9f7\udeb0\udb95\udeea\udb26\uddfe\udb29\udeff", "\ua0e2\ucc59\u05ba\u4902\u570a\u829e\u6ced\u3957\u2047\u3d38\uacb9\u5f82\ud7b4\u875a\u241b\ud58d\u6966\u0968\u3b3b\u11f1\u9aed\u05cd\u7730", "\uda21\ude0d",
        11, 99504, -1989533644, -3388335888947797446L, 61207L, true, true, (char) 34148, (char) 36826,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Double:0.6119026914934771\012",
        Z.run(T, 1, 2, 1, 1, "\u8435\ud970\udeac\uda4b\udfda\udb29\udeff", "\uaa56\u0812\u8c59\u4902\u570a\u829e\u6ced\u3957\u2047\u42d9\u7191\u0943\ud6e6\u875a\u241b\ud58d\u6966\u0968\u3b3b\u11f1\u9aed\u05cd\u7730", "\uda21\ude0d",
        11, 99504, -1989533644, -3388335888947797446L, 61207L, true, true, (char) 8472, (char) 19264,
        Double.longBitsToDouble(0x3fe73676785886feL), Double.longBitsToDouble(0x3fe98bcdbbf62d5bL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\0121=java.lang.Double:NaN\012",
        Z.run(T, 2, 0, 0, 0, "\ud827\udc88\ud970\udeac\udba4\uded2\udb29\udeff", "\u4f80\u0812", "\ueec7",
        -5, 95016, 743124184, 7594568176844537856L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fb216f086f50078L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.special.Gamma|logGamma|double|static",
    "M|org.apache.commons.math.special.Gamma|regularizedGammaP|double,double|static",
    "M|org.apache.commons.math.special.Gamma|regularizedGammaP|double,double,double,int|static",
    "M|org.apache.commons.math.special.Gamma|regularizedGammaQ|double,double|static",
    "M|org.apache.commons.math.special.Gamma|regularizedGammaQ|double,double,double,int|static",
    "C|org.apache.commons.math.special.Gamma|<init>|",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
