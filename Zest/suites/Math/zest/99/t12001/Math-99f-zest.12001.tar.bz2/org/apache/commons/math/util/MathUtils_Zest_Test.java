package org.apache.commons.math.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class MathUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Double:3.3452526613163927E49\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 13, 12, 0, "\udbf9\udd77\udb50\uddc0\udb5d\ude0e\u8c93\ud900\udd14", "\u80f9\u1a69\ub0c2\u9931", "\ud856\ude17\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda62\udc3d\uda76\udcef\udb15\udda0",
        41, 69835, -295586022, 3332054234431337114L, -13979L, true, true, (char) 3187, (char) 14969,
        Double.longBitsToDouble(0x3febfa74de33fa98L), Double.longBitsToDouble(0x3fee7b4811bd0a43L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Double:6.402373705728E15\0121=java.lang.Integer:2\012",
        Z.run(T, 2, 13, 0, 0, "", "\u8d71", "\uda58\uddd9\udb3d\ude9a\ud8a2\ude73\ud95b\udd41",
        18, 56008, 15517, 1706056704L, 42080L, true, true, (char) 58984, (char) 40456,
        Double.longBitsToDouble(0x3fee9b755b8dcefdL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Double:4.790016E8\0121=java.lang.Long:479001600\012",
        Z.run(T, 2, 13, 12, 16, "\udbf9\udd77\udb50\uddc0\udb5d\ude0e\ud811\udf88\udb4f\udffd\uda58\uddd9\udb3d\ude9a\ud8a2\ude73\ud95b\udd41\uda4a\udd07\uda83\udfd3\ud90c\udcb4\ud90d\udd93", "\u31bd\u9d2d\u2ad8\u4bd8\u94da\u3950", "\ud8fc\udc36\udac8\udc5b\ud89b\ude10\uda6a\udc65\ud8f6\udffe\udab2\udff0\ud842\ude98\uda62\uddad\uda3b\uddba\ud835\udc1b\ud936\udd96\ud8d3\udcaf\udb2a\ude1b\u8ede",
        12, 71221, -462531598, -7151156569973561022L, -69591L, true, true, (char) 61962, (char) 45993,
        Double.longBitsToDouble(0x3fd8ec28951702a2L), Double.longBitsToDouble(0x3fdba8b9195b1f5cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Double:1.1240007277776115E21\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 13, 12, 0, "\udb12\ude55", "\u51e5", "\udb3d\ude9a\ud8a2\ude73\ud95b\udd41\uda4a\udd07\ud8dd\udd04\uda08\udd47\ud90d\udd93\ud856\ude17",
        22, 62143, -56692341, -3213927865897962995L, 51992L, true, true, (char) 35466, (char) 16493,
        Double.longBitsToDouble(0x3feedab59495b272L), Double.longBitsToDouble(0x3fdac9b2d5345c7aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Long:-3213927865898047264\0121=java.lang.Long:-3213927865898047264\012",
        Z.run(T, 2, 2, 2, 15, "\udbf9\udd77\uda3b\udcc2", "\u7fed\u18de", "\ud95b\udd41\ud96c\udef7\u56b8\ud9ea\ude0a\ud90d\ude0c\ud856\ude17",
        22, 71047, -56692341, -3213927865897964787L, -82477L, false, false, (char) 39565, (char) 36748,
        Double.longBitsToDouble(0x3fda9ee615345c7aL), Double.longBitsToDouble(0x3fe8a0bce80530e4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 10, 12, "\ud868\udc0f\ud8cb\udc7a\udaba\udea0\ud9b6\udcf2\ud93d\ude84", "\u961d", "\ud9b0\udd01\ud981\udf35\ud9c6\udf8e\ud84b\ude8a\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c",
        36, 22227, -1686127731, -8308397021099572294L, -43943L, false, true, (char) 18039, (char) 13846,
        Double.longBitsToDouble(0x3fec4c07e97a22e6L), Double.longBitsToDouble(0x3fe08e033b7f4e9bL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Double:3.3452526613163927E49\0121=java.lang.Integer:-505937684\012",
        Z.run(T, 2, 13, 15, 0, "\udbf9\udd77\udb50\uddc0\udb5d\ude0e\u8c93\ud900\udd14", "\u80f9\u1a69\ub0c2\u9931", "\ud856\ude17\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda62\udc3d\uda76\udcef\udb15\udda0",
        41, 69835, -295586022, 3332054234431337114L, -13979L, true, true, (char) 3187, (char) 14969,
        Double.longBitsToDouble(0x3febfa74de33fa98L), Double.longBitsToDouble(0x3fee7b4811bd0a43L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[32037.5, 28105.0, 28570.5, 27741.5, 28610.5, 27901.0, 28405.5, 27865.0]] |a1=[D:[[18175.5, 11197.0, 26246.0, 11747.0, 1059.5, 16108.5, 21878.0]]\012",
        Z.run(T, 1, 11, 12, 2, "\ufa7b\udbc2\udf65\ud8eb\udfb5\uda2a\ude1b\ud9e2\uddb0", "\u8e2f\u57aa\ucd3c\u5bf6\u0877\u7e09\uab1c", "\ud8a4\udf59\udb06\udf1b\uda49\udf03\ud853\udc1e\udb38\udd1c\uda74\uddef\ud8fd\udc53\ud8a4\uddf4\ud90e\udedd\ud89b\ude10\uda6a\udc65\ud8f6\udffe",
        -2, 309, -1828790363, -4582580990796213814L, 61290L, true, true, (char) 44288, (char) 49330,
        Double.longBitsToDouble(0x3fbdcdc1abd7c000L), Double.longBitsToDouble(0x3fec8dcb8a16f213L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:2.6313083693369503E35\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 10, 0, "\udbf9\udcc3", "\u51e5\u7fed\u0391\u78f8\u80f9\u1a69\ub0c2\u9931\u47df\u8be4\u9c9e\u5c64\u388e\u9d89\u18c5\u65ec\ubd6f\u64e2", "\udbe2\ude09\ud8e8\udd86\ud89b\ude10\uda6a\udc65\ud8f6\udffe\ue914\udba8\udc74\uda64\udd98\uf17a\000\ud9ce\udf2d\ud8c1\udc63\udb44\udc69\ud97b\udfdc",
        32, 87189, 387979293, 3425166055573476994L, 51438L, true, false, (char) 38555, (char) 54928,
        Double.longBitsToDouble(0x3fb26911bb023738L), Double.longBitsToDouble(0x3feb969601a40187L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:172765015\0121=java.lang.Integer:2\012",
        Z.run(T, 2, 15, 0, 7, "\udbf9\udd77", "\u51e5\u7fed\u18de\u838d\u80f5\u1a69#\u9838\u0877\u8be4\u9c9e\u5c64\u31bd\u5247\u584d\u2b8d\u2a72\u64e2", "\000\ud8e8\udcab\ud89b\ude10",
        12, 87842, 805306368, -9152070885325598839L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4c2f5734000000L), Double.longBitsToDouble(0x3fe0fa1135f62bbdL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Double:1.3868311854569213E80\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 13, 12, 8, "\udbe7\udf6f\ud820\udf03\ud877\udc5c\uda83\uddeb\ud903\udfab", "\u80f9\u1a69\u1404\u9910\u68f3\u6fa1\u419e\u5c64\u1e29\u9d89", "\ud925\udf7c\uda58\udd39\udafe\udd5a\udb15\udda0\udbe2\ude09\ud8e8\udd86\ud89b\ude10\uda6a\udc65\ud8f6\udffe\udab2\udff0\udb5a\udc88\uda64\udd98\uda3b\ude34\udba3\udec7\u2776\ud8ed\udc0e\ud9d6\ude23\ud95c\udeb7",
        59, 51599, 95066433, -7472641865532023754L, 99220L, false, true, (char) 28823, (char) 7833,
        Double.longBitsToDouble(0x3fe7c6c41eacc3ecL), Double.longBitsToDouble(0x3fb88156aa77b4c0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Long:8088418390887988070\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 2, 12, 0, "\udbf9\udd77\udb50\uddc0\udb5d\ude0e\u8c93\ud900\udd14", "\u80f9\u1a69\ub0c2\u9931", "\ud856\ude17\udbab\udf6a\ud9f0\udcfe\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda69\udd3d\uda76\udcef\udb15\udda0",
        41, 69835, -295586022, 8088418390888002049L, -13979L, true, false, (char) 3187, (char) 14969,
        Double.longBitsToDouble(0x3febfa74de33fa98L), Double.longBitsToDouble(0x3fee7b4811bd0a43L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Double:1.5511210043331066E25\0121=java.lang.Integer:58393\012",
        Z.run(T, 2, 13, 3, 6, "\udbf9\udd77\udb50\uddc0\udb5d\ude0e\u8c93\ud900\udd14", "\u80f9\u1aec\ub0c2\u9965", "\ud856\ude17\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\uda3d\ude28\uda61\udfe2\uda76\udcef\uda7b\udec7",
        25, 58368, 1095281764, 5165607134944923564L, -13979L, true, true, (char) 27809, (char) 15046,
        Double.longBitsToDouble(0x3fe3fa74dfdf23e6L), Double.longBitsToDouble(0x3febe43759bd0a43L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 1, 7, "\uda16\udc66\udadd\ude7e\udb59\udd5e\u8c93\ud900\udd14", "\u80f9\uc1d0\ub16f\u9931", "\ud856\ude17\uda13\udfc8\ud9f3\uddf3\u598d\ud834\udf01\ub16c\ud90e\udeb8\u7ed7\ud928\udf8b\udb15\udda0",
        41, 69835, -295586022, 3332054234431337114L, -13979L, true, true, (char) 3187, (char) 14969,
        Double.longBitsToDouble(0x3fe3fa74da33faf6L), Double.longBitsToDouble(0x3fc8755a824e8ba8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Long:3332054234431323135\0121=java.lang.Integer:-640162889\012",
        Z.run(T, 2, 4, 15, 0, "\udbf9\udd77\udb50\uddc0\uda67\ude12\ud846\udead\ud900\udd14", "\u80f9\u1a69\ub0c2\u9931", "\ud856\ude17\ud936\udef0\uda24\uded5\u3f58\ud834\udf01\uda21\udff7\ud925\udf7c\uda62\udc3d\uda76\udcef\udb15\udda0",
        41, 69835, -295587558, 3332054234431337114L, -13979L, true, true, (char) 56690, (char) 2675,
        Double.longBitsToDouble(0x3fe419c0e633fa77L), Double.longBitsToDouble(0x3fee7b4811bd0a43L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Long:5498906128151160673\0121=java.lang.Long:5498906128151160673\012",
        Z.run(T, 2, 2, 2, 5, "\uda74\udc75\udb50\uddc0", "\u71cc\u9385\u78f8\u80f9\ud611\u2999\u6a71\u0877", "\ud936\ude44\udadd\udd13",
        43, 78530, 1399597837, 5498906128151171512L, -10839L, true, true, (char) 39565, (char) 36748,
        Double.longBitsToDouble(0x3feeff730a9a3ab3L), Double.longBitsToDouble(0x3fd14179d00a6120L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 12, 0, "\udbf9\udd77\udb50\uddc0\udb5d\ude0e\u8c93\ud900\udd14", "\u80f9\u1a69\ub0c2\u9931", "\ud85a\udf79\u58aa\ud9f3\udd67\uda9b\udf7b\ud834\udf01\uda21\udff7\ud925\udd42\uda62\udc3d\uda76\udcef\udb15\udda0",
        -2, 69835, -295586022, 3332054234431337114L, -76450L, true, false, (char) 41169, (char) 64511,
        Double.longBitsToDouble(0x3fc773f2ade0c550L), Double.longBitsToDouble(0x3fe85c5973f6f7d0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[28132.5, 28277.5, 28048.0, 28360.0, 27954.5, 28344.0, 17969.5, 27864.0]]\0121=java.lang.Integer:482358\012",
        Z.run(T, 2, 11, 1, 8, "\udbf9\udd1b\udb50\uddc0\uda95\udda0\u8c93\ud9e0\udeb0\ud9a0\udce1\udb3d\ude9a\ud8a2\ude73\u9d89\uda4a\udda5\ud994\udf54\ud9b8\udd85\ud8cd\udf78\ud8a6\udced\ud9f2\udfde\uda12\udf9d", "\u57f6\u5eab", "\udb2c\udd22\udbe2\udd30\ud8e8\udd86\ud8aa\udf10\ud950\udc38\ud9a5\ude2c\ud989\udc11\ud803\udea4\udaf8\udd62\ud88f\ude29\udb71\udc75",
        51, 28374, 172194967, -1009947896989445170L, -71288L, false, true, (char) 28531, (char) 4456,
        Double.longBitsToDouble(0x3fd74d7c97dcc6b0L), Double.longBitsToDouble(0x3fd9147157421ad0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Double:1.0123358574559826\012",
        Z.run(T, 2, 9, 8, 3, "\udb98\udfc6\udb50\uddc0\udb5d\ude0e\udafd\udf01\ud91d\udf15", "\u9cbb\u415b\u99b7\ua14a", "\ud856\udec0\ud936\udef0\uda09\uddd5\u5958\ud834\udf01\uda21\udff7\ud934\ude7c\uda9d\udd1b\ud896\udd91\uda7d\udc3a",
        33, 42770, -300341195, -5581885709188383375L, -6101L, false, false, (char) 4731, (char) 62667,
        Double.longBitsToDouble(0x3fc415ab66f4290cL), Double.longBitsToDouble(0x3fd27511e1b509e8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Double:3.3452526613163927E49\0121=java.lang.Double:3.3452526613163927E49\012",
        Z.run(T, 2, 13, 13, 5, "\udbf9\udd77\udb50\uddc0\uda6d\ude6d\u8c93\ud900\udd14", "\u80f9\u1a69\ub0c2\u9931", "\udb19\udec7\udb86\ude7a\ud9f7\udfdd\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda62\udc3d\uda76\udcef\udb15\udda0",
        41, 69835, -295586022, 3332054234431337114L, -13979L, true, true, (char) 3187, (char) 14969,
        Double.longBitsToDouble(0x3febfa74de33fa98L), Double.longBitsToDouble(0x3fee7b4811bd0a43L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Integer:5118410\0121=java.lang.Integer:93117\012",
        Z.run(T, 2, 1, 3, 9, "\udbf9\udd77", "\u51e5\ud64d\u4601\u78b8\u80f9\u1a69\ub0c2\u9931\u0877\u8be4\u9c9e\u5c64\uafab\u638e\u3228\u4c04\uc893\u6511", "\udbe2\ude09\ud8fa\udf86\ud89b\ude10\uda6a\udc65\ud8f6\udffe\udab2\udff0\udb20\udcaa\udb07\uddfc\ud946\udf2a\udba3\udeb2\ud839\udf2a\ud8c1\udc63\udb44\udc69\ud90d\udd04",
        55, 93062, 641622672, -3090901088436835190L, 10158L, true, true, (char) 47947, (char) 48904,
        Double.longBitsToDouble(0x3fc4e8b4183075d8L), Double.longBitsToDouble(0x3fe65cb42dfbeba5L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Long:-5700359592641450146\0121=java.lang.Integer:388374\012",
        Z.run(T, 2, 4, 1, 6, "\udbf9\udd77\udbc1\ude86\udb23\udd1f", "\u18de\u83b2\ubb36\u4c3d", "\uda08\udd39",
        42, 64729, -1836534069, -5700359592641367669L, -82477L, false, false, (char) 39565, (char) 18542,
        Double.longBitsToDouble(0x3fdacee615345c7aL), Double.longBitsToDouble(0x3fd14179d74f6b20L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 4, 9, "\udbf9\udd77\udb50\uddc0\udac3\udc6d\udaff\udd71\udaa4\udd38\ubb8a\uda7f\udcda\udbdb\udfcd\ud907\udd3e", "\u0877\u52b5\u623f\u0c11\u31bd", "\ud977\udd02\ud925\udf7c\udb7f\ude36\uda3f\udfef\ud886\udf58\udbe2\udd97\ud8e8\udd86\ud87c\udf10\uda6a\udc65\ud8f6\udffe\uda5b\udc65\udbb3\udfa3\uda63\udd3a\ud84b\udd82\ud9c9\udc1b\uda54\udca7\udb5a\ude87\udb36\uddb3\udbcf\udf46\ud99d\udda5\udb48\udfb9\ud827\udd4c\ud928\udd30\udaf7\udf35\udb0b\udf77",
        22, 78032, -417768182, 541653295002403167L, -31432L, true, false, (char) 25694, (char) 4008,
        Double.longBitsToDouble(0x3f80c8bf84f7ba80L), Double.longBitsToDouble(0x3fe2ae592bc83afeL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Double:2.658271574788457E54\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 13, 10, 1, "\udbf9\udd77\udb50\uddc0\udb5d\ude0e\u8c93\uda73\udc6e\uda58\ude3d", "\u785f\ub0c2\u9931\u0877\u8be4\u9c9e\u5c64\u31bd\u9d89\u18c5\u65ec\u40e4\ubf42\u49bd\u273a\u333b\uc4f9\u5238\u60a0\u5697\u72a3\u1131\u30fc\u9e1a\u673b\u7d17\u3aa8\uabf8\u30d1\u7ef7", "\ud95c\udf0d\ud839\udd4a",
        44, 59200, 115565749, 3170965580458385228L, -82147L, false, true, (char) 47242, (char) 18887,
        Double.longBitsToDouble(0x3feba95039ce1926L), Double.longBitsToDouble(0x3fe639676c34da6fL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 0, 14, 4, "\udb20\ude0c\ud920\udfed\udb5d\ude0e\uc9c2\udbe7\udc50\ud8d4\udfb6\udb3d\udf08\ud84b\ude90\udac8\udc6e", "\u3da7", "\uda28\udd5b\udb90\udfe8\udb19\udd19\udad7\udf88\udb1e\udfb6",
        1, 37336, -822217773, -7241863460069137170L, 49655L, false, true, (char) 3543, (char) 63760,
        Double.longBitsToDouble(0x3f74c243c4c07e80L), Double.longBitsToDouble(0x3fd7a22f92d980ceL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[28132.5, 28323.5, 28048.0, 28360.0, 27832.5, 28559.5, 27720.0, 28313.5]] |a1=[D:[[21908.0, 15073.5, 1669.0]]\0121=java.lang.Boolean:false |a0=[D:[[28132.5, 28323.5, 28048.0, 28360.0, 27832.5, 28559.5, 27720.0, 28313.5]] |a1=[D:[[21908.0, 15073.5, 1669.0]]\012",
        Z.run(T, 2, 11, 11, 14, "\udbf9\udd77\udb50\uddc0\ud9a1\udf4f\ud8c0\udd63\ud8b4\udcca", "\uab58\u75f3\u0d3a", "\ud90d\udd93\ud856\ude17\ud936\udef0\uda24\uded5\u5958",
        12, 40043, 1280319430, 7974557415083209683L, -11150L, true, true, (char) 36748, (char) 50189,
        Double.longBitsToDouble(0x3fd9a2e3db3dd6feL), Double.longBitsToDouble(0x3fd562b7cf130152L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 14, 10, "\udbf9\udd77\ud8f4\udd53\udb64\udd76\u8c93\ud900\udd14\uda58\uddd0\udb3d\ude9a", "\ub0c2\u9931\ube24\u8be4", "\uda24\udf1d\ud915\uddd6\ud834\udf42\uda26\udef7\uda62\udedb\ud942\udfca\udb66\udce1\udb07\uddd2\udbe2\ude09\ud8e8\udd86\ud89b\ude10\uda85\udd47\udbea\uddef\ud9e0\udcea\udb18\ude9a\uda64\udd98\udbdd\udc0a\udba3\udeb2\ud9ce\udf2d\uda9d\udc71\udb44\udc69\ud844\udfd8\ud9f0\udd85",
        -2, 59078, 586576018, 6222622861106425518L, 6219L, false, false, (char) 64987, (char) 8270,
        Double.longBitsToDouble(0x3fcd920e5d8de88cL), Double.longBitsToDouble(0x3fbbc85770c2de68L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 6, 13, "\udbf9\udd77\udb50\uddc0\udb5d\ude0e", "\u18de\u78f8\u80f9\u459a\ub159\u9931\u0877\u8be4\u9c9e\u5c64\u31bd\u9d89\u18c5\u65ec\ubd6f\u051e\u49bd", "\ud8e8\udd86\ud89b\ude10\uda6a\udc65\ud8f6\udffe\udab2\udff0\udb5a\udc88\uda64\udd98\uda3b\uddba\udba3\udeb2\ud9ce\udf2d\ud8c1\udc63\udba9\uddd9\uc87b\ud9ac\udeb5\udaf1\udcc0\ud831\udcd0\uda4f\udd90\ud809\udd3d\udad8\udcda\udb9c\udcc3",
        40, 12792, 1072903353, 5941083734061353865L, 67548L, false, true, (char) 29482, (char) 55832,
        Double.longBitsToDouble(0x3feeed832f367dccL), Double.longBitsToDouble(0x3fd5f221b07b4ddcL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 16, 16, 0, "\udbf9\udd77\udb50\uddc0\udb5d\ude0e\u8c93\ud900\udd14", "\u80f9\u156b\ub17d\u46c3", "\uda57\ude06\ud936\udf14\uda24\uded5\u5958\ud834\udf01\udbe5\ude16\udb65\ude9d\uda62\udc3d\uda76\udcef\udb15\udda0\udbe2\ude09\ud8e8\udd86\ud89b\ude10\uda6a\udc65\udbeb\udeeb\udab3\udc99\udb5a\udc88\uda64\udd98\uda3b\uddba\udba3\udeb2",
        13, 25011, 172177359, 6402990189280134563L, 84907L, true, false, (char) 34996, (char) 6929,
        Double.longBitsToDouble(0x3fd9cabd323b979cL), Double.longBitsToDouble(0x3fdf14808e0155a0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27775.5, 28581.5, 27963.5, 28154.5, 28054.5, 28399.0, 17969.5, 27752.0]] |a1=[D:[[3356.5, 22601.0, 19584.5, 5307.5, 5326.5, 5357.5, 11802.0, 6342.5]]\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 11, 12, 0, "\ud92f\udf7b\udaa7\udc25\udb5d\ude0e\u8c93\ud900\udd14\uda33\udf2e", "\u1a69\ub0c2\u9931\u29a7\u29cd\u2a0b\u5c64\u31bd\u9d89\u18c5\u65ec\ubd6f\u64e2\u49bd\ud32d\u33af\uc4f9\u5238\u3c7a\u5697\u72a3\u517c\u3f34\u506c\u673b\u7d17\u3aa8\uabf8\u6558\u0822", "\ud92f\udcad\ud9ed\uddb8",
        58, 93638, 40850442, -7704245391422097054L, 23070L, true, true, (char) 12702, (char) 48365,
        Double.longBitsToDouble(0x3fd7dc9807e899e2L), Double.longBitsToDouble(0x3feb6858f402df09L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Integer:2\0121=java.lang.Long:-42380\012",
        Z.run(T, 2, 0, 2, 0, "\udbf9\udd77\udb50\uddc0\u8d71\u8c93\000", "\u80f9", "\ud9b0\udd01\uda08\udd39\ud90d\udd93\ud856\ude17\ud936\udef0\uda24\uded5\000\000\000\000\000\uda76\udcef",
        6, -1000, 0, 0L, -42380L, true, false, (char) 36998, (char) 3187,
        Double.longBitsToDouble(0x3fe08e033b7f4e9bL), Double.longBitsToDouble(0x3f4f531f3c000000L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Double:1.500219740016755\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 5, 3, "\udbf9\udd77\uda98\udfc4\uda70\udf78\ub3fc\ud900\udd14\uda31\udedc\udb21\udcfc\udbde\ude89\ud95b\udd41\udade\udd11", "\uc277\u2f39\ua7e0\u31bd\u9d89", "\ud925\udf7c\uda62\udc3d\uda76\udcef\udb15\udda0\u0239\ud925\ude02\ud803\uddb8\uda6a\udc65\ud8f6\udffe\ud815\udd90\ud9f1\udf18\uda3d\ude8e\ud861\udf80\uda6e\udd5a\ud9da\udcc0\ud8c1\udc63\udb44\udc69\udbfe\udebe",
        37, 32139, 1245337572, 6139416840782256796L, -46498L, false, false, (char) 41426, (char) 19079,
        Double.longBitsToDouble(0x3feecdc8ce3f108cL), Double.longBitsToDouble(0x3fe9c260c52eba7dL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Double:6.2270208E9\0121=java.lang.Double:6.2270208E9\012",
        Z.run(T, 2, 13, 13, 1, "\udbf9\udd77\udb50\uddc0\udb5d\ude43\u8c93\ud900\udd14\uda58\uddd9\udb3d\ude9a\ud8a2\ude73\ud95b\udd41", "\u0877", "\ud936\udef0\ud92c\udc87\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda62\udc3d\uda76\udcef\udb15\udda0\udbe2\ude09\ud8e8\udd86\ud89b\ude10\uda6a\udc65\ud8f6\udffe\udab2\udff0\udb5a\udc88\uda64\udd98\uda3b\uddba\udba3\udeb2",
        13, 25011, 172177359, -7147228289013145481L, 33965L, true, true, (char) 41263, (char) 16421,
        Double.longBitsToDouble(0x3fee3b79721732d9L), Double.longBitsToDouble(0x3fe09fbb57ec0680L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Double:3.3452526613163927E49\0121=java.lang.Long:3332054234431413183\012",
        Z.run(T, 2, 13, 2, 13, "\ud887\udcbf\ud821\udf21\udb5d\uddf5\u8c93\ud900\udd14", "\u80f9\u1a69\ub0c2\u9931", "\udbfb\udecb\uda65\udd6b\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda62\udc3d\uda76\udcef\udb15\udda0",
        41, 69835, -295586022, 3332054234431337114L, 76069L, true, true, (char) 32393, (char) 20100,
        Double.longBitsToDouble(0x3fd1c8369c67f530L), Double.longBitsToDouble(0x3fee7b4811bd0a43L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Double:8.841761993739751E30\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 7, 9, "\ud9e5\udf2d\uda9c\uddcd\udb41\ude07\udbf0\ude58\ud802\udecf", "\u8183\ubbe4\u6709\u0179", "\ud856\udc17\uda89\udcdf\ud9d0\udd06\ud9bf\uddf6\ud992\udf2d\u6814\ud925\udedf\uda62\udc3d\uda76\udcef\udb15\udda0\ud994\ude02",
        29, 19793, 775804332, 9195702389472191760L, 92631L, false, false, (char) 14969, (char) 4634,
        Double.longBitsToDouble(0x3fe19fd4c7cf6902L), Double.longBitsToDouble(0x3fe870521d0966cbL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Double:6.402373705728E15\0121=java.lang.Integer:2\012",
        Z.run(T, 2, 13, 0, 0, "", "\u8d71", "\uda58\uddd9\udb3d\ude9a\ud8a2\ude73\ud95b\udd41",
        18, 11648, 0, 0L, -100000L, false, false, (char) 0, (char) 11008,
        Double.longBitsToDouble(0x3fe7ea9b61b84c00L), Double.longBitsToDouble(0x3fee9b755b8dcefdL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Double:8.159152832479056E47\0121=java.lang.Integer:225360\012",
        Z.run(T, 2, 13, 1, 0, "\udaad\udf61\ud91f\uddcb\u8d71\ud89b\udfee\udb68\ude3b\ud956\udda8\ud95b\udd19\ud80f\udc08\ud86d\udeef\u0323", "\ubc83\u9863\u4347\u1bef\ua613", "\ud925\udf7c\uda62\udc3d\uda76\udcef\ubb8d\000\ud889\ude63\ud84d\udcf0\uda3e\udeef\udaff\udde5\ud961\udf48\udb02\udd32\udb0b\udff8\udbeb\udcce\ud82e\udd9d\udba8\udcca\ud8c8\udd00\uda8c\udc2f\ud9d7\ude1e",
        40, 45072, 360000506, -2776655639402650723L, -98158L, true, true, (char) 18205, (char) 11648,
        Double.longBitsToDouble(0x3febb7b0bfa468d0L), Double.longBitsToDouble(0x3fe1c89b6be3dab9L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Integer:2\0121=java.lang.Integer:2\012",
        Z.run(T, 2, 0, 0, 0, "", "\u8d71", "\uda58\uddd9\udb3d\ude9a\ud8a2\ude73\ud95b\udd41",
        18, 56008, 905985181, -946527116182135784L, -43295L, true, true, (char) 59082, (char) 44486,
        Double.longBitsToDouble(0x3fe7ea9b66b84c50L), Double.longBitsToDouble(0x3fee9b755b8dcefdL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[]] |a1=[D:[[18080.5]]\012",
        Z.run(T, 1, 11, 8, 0, "", "\u8d71", "\u8cd4\udb3d\udef1\udb50\udfaa\udaca\ude7f",
        31, 4905, -1923490182, 3831535709377813741L, -42785L, true, true, (char) 53662, (char) 65138,
        Double.longBitsToDouble(0x3fe5ba9b6727bd45L), Double.longBitsToDouble(0x3fd87fa299a92d8eL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 0, 0, 0, "", "\ucf6b", "\uda58\uddb0\udb3d\ude9a\ud8a2\ude73\udb9e\udc6c\ua96b\ud9b0\udc08\ud993\udf9e",
        -5, 5024, -822075282, -5700185489745776245L, -91808L, false, false, (char) 33629, (char) 54713,
        Double.longBitsToDouble(0x3fd4db2768dc47d2L), Double.longBitsToDouble(0x3fe64dd4dcd5bbe6L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Double:1.2413915592536315E61\0121=java.lang.Integer:8\012",
        Z.run(T, 2, 13, 0, 0, "", "\u8d71", "\uda58\uddd9\udb3d\ude9a\u0804\000",
        48, 56008, 15517, 0L, -100000L, false, false, (char) 21356, (char) 0,
        Double.longBitsToDouble(0x3fee9b755b8dcefdL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:4\012",
        Z.run(T, 2, 15, 0, 0, "", "", "\ud900\udd14",
        -4, 92576, 693045248, 1353485782861479936L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Integer:4\0121=java.lang.Integer:4\012",
        Z.run(T, 2, 0, 0, 0, "", "\u8d71", "\uda58\uddd9\udb3d\ude9a\uda8c\udc08",
        28, -1000, 1426063360, 0L, -100000L, false, false, (char) 41444, (char) 64512,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Double:2.5862324151117192E59\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 13, 0, 0, "", "\u7dfa", "\uda41\udc06\udb3d\ude9a\ud8a2\ude73\udaa0\udce8\u519e\uda20\udfea",
        47, 94083, 302193799, -1542574060152074398L, 20219L, true, true, (char) 58984, (char) 30245,
        Double.longBitsToDouble(0x3fded7e9aef49986L), Double.longBitsToDouble(0x3fe8b532464a38c6L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Integer:77619\012",
        Z.run(T, 2, 13, 0, 0, "\000\udb84\udd05\u8d71\ud882\udca1\ud93c\uddc1\uda30\ude95\udb3d\ude9a\ud8a2\ude73\ud95b\udd41\u0323\ud9b0\udc08\u3c9d\udb47\ude02\udadf\udf5e", "\u6f76", "\ud925\udf7c\uda62\udc3d\uda76\udcef\ubb8d\000\ud896\udc6a\uda5b\udfa7\ud924\udc5a\uda92\udd4f\ud8d1\udce3\udaf6\ude76\ud90e\uddcc\ud9f4\udc2d\udaef\ude00\ud985\udf26\uda00\udcb5\u61f7\udac3\udcb3",
        0, 77619, -1906366605, -5542923139090276142L, 87506L, true, false, (char) 21533, (char) 6928,
        Double.longBitsToDouble(0x3fd0798edfb0e3c0L), Double.longBitsToDouble(0x3fc471928dcdee2cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Integer:18405\0121=java.lang.Boolean:false |a0=[D:[[2025.0]] |a1=[D:[[6336.0]]\012",
        Z.run(T, 2, 3, 11, 2, "\u1002", "\u31b0", "\ud8c9\udc24\ud8a2\udf03\ud82b\udd09\u0347\ud8d1\udc19\ud8af\udd04\000\ud856\uddfe\udb24\udee7\ud979\udd9e\udbe6\udc28\ud816\udd09\uda21\udff7\ud925\udf7c\uda62\udc3d\uda76\udcef\ud9cd\udc5c\uc09f\ud9c8\udfd0\udba4\udd7d\uda07\uddec\ud8dc\ude07\uda04\udc3f\ud8c1\ude66\udb41\udcfd",
        48, 18357, -10383406, -3230040254549125137L, -62302L, true, true, (char) 4096, (char) 41028,
        Double.longBitsToDouble(0x3fe94737475cd898L), Double.longBitsToDouble(0x3fb113c3ac8809a8L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Long:6564513379838354378\0121=java.lang.Long:6564513379838354378\012",
        Z.run(T, 2, 4, 4, 7, "\u3d16\udb8e\udd29\u8d29\u526b\ud943\uddbb\uda20\udc7a", "\u6d16\u2193\u9851\u1f24\u852e\u9cc1", "\u5958\ud834\ude5f\uda21\udff7\ud913\ude72\uda62\udc3d\uda76\udcef\ubb8d\000\ud922\udc70\udbf0\ude5a\ud819\ude38\u9998\ud8d6\udfde\ud915\udd87",
        33, 49542, -263444719, 6564513379838317664L, 36714L, true, false, (char) 21894, (char) 52945,
        Double.longBitsToDouble(0x3fe06431d320f0eaL), Double.longBitsToDouble(0x3fe8664c2de11fe1L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 9, 10, 0, "\000\uda27\udc08\ud84e\udda7\uda61\udfd2\udb0d\udfb2\ud9e4\udcae\udb3d\ude9a\ud8e6\udcf6\uda3e\udd13", "\ud563\000\ucabd\u5db1\uce90\u79d6\u8794\u65ec\ubd6f\u64ee\u49bd\ubb8d\u6f68\u2522", "\ud9e5\udfec\udb82\udebc\uda8c\ude92\ud93b\udedd\ud931\udf4f\uf34c\udb45\udfbc\ud961\udea2\ud861\udd08\ud936\udf82\udbef\udda3\u552d\udbcf\uddc6",
        18, 84951, 467287789, 4182434741312859701L, 972L, false, false, (char) 33194, (char) 51526,
        Double.longBitsToDouble(0x3fe0e3262b765b99L), Double.longBitsToDouble(0x3fde0ab56ca04a84L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 0, "", "\ubba7", "\ud841\uddef\udb3d\ude73\ud82b\uddfe",
        -1, -197, 1432843008, 1513276119804018905L, -30763L, false, true, (char) 65138, (char) 30162,
        Double.longBitsToDouble(0x3fdb8977a7a6dca2L), Double.longBitsToDouble(0x3fe33e77ed8e21ddL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 0, 0, "", "", "",
        -5, -1000, 0, 0L, -100000L, false, false, (char) 0, (char) 23552,
        Double.longBitsToDouble(0x3fdcb65b00000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 0, 0, 0, "", "\ub232", "\uda58\uddd9\udb3d\ude9a\udba2\ude14\ud963\udf45",
        36, 11593, 660220979, 1706056704L, -42785L, true, true, (char) 53662, (char) 65138,
        Double.longBitsToDouble(0x3fe7ea9b61b84c50L), Double.longBitsToDouble(0x3fee9b755b8dcefdL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Integer:977988\012",
        Z.run(T, 2, 10, 1, 0, "\udb28\ude66\ud843\udd6d\udb5d\ude0e\u8c93\ud900\udd14\uda58\uddd9\udbac\udf9b\uda06\udf2a", "\u951d\u0885\ub4dd\u9c9e\u5c64\u31bd", "\uda23\udef7\ud925\udf7c",
        44, 22227, -1686127731, 6247236973924336603L, 41908L, false, false, (char) 2187, (char) 36637,
        Double.longBitsToDouble(0x3fc74b2d02cae970L), Double.longBitsToDouble(0x3fdd855c25c72c40L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[28132.5, 28323.5, 27909.5, 28233.0]] |a1=[D:[[16350.5, 3159.0]]\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 11, 10, 15, "\udbf9\udd77\uda3b\udcc2", "\u7fed\u18de", "\ud973\udfdd\ud96c\udef7\u56b8\ud9ea\ude0a\ud90d\ude0c\ud856\ude17",
        22, 71047, -56692341, -3213927865897964787L, 41911L, false, false, (char) 52912, (char) 33001,
        Double.longBitsToDouble(0x3fe8dd2f312770e2L), Double.longBitsToDouble(0x3fdb6e595d3db756L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Long:5207976072559648196\0121=java.lang.Long:5207976072559648196\012",
        Z.run(T, 2, 2, 2, 15, "\udbf9\udd77\uda3b\udcc2", "\u2c6f\ua52f\u45df\u54af\u52aa\u97fe\ucedf\ua8e1\u8c5d\u9c9e\u5c64\u20c3\u9d89\u51f1\u4480\u1484", "\udb15\udda0\udbe2\ude09\ud8e8\udd86\ud89b\ude10\uda6a\udc62\ud8f6\udffe\uda72\uddf5\udb2f\uded1\udb18\udf3b\uda8c\udd8b\ud815\ude96",
        35, 56853, -1314532534, 5207976072559552015L, 96181L, false, true, (char) 61308, (char) 3735,
        Double.longBitsToDouble(0x3feb0c8757973f43L), Double.longBitsToDouble(0x3fb969c604627128L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 15, "\ud8a9\ude90\udb57\udd70\udae6\udf76\ud9ad\ude29\ud900\udca7\uda58\uddd9\ud909\ude40\udb94\udc1c\ud95b\udd41\ud96c\udef7\u56b8\ud9ea\ude0a", "\u317b\u08b7\u62df\u3b86\uac20\uce89\u64e2\u49bd\u946f\u33af\u6fe2\u52c4\u3c77\u5697\uc106\ud1b2\u8434\u37e2\u0d7d", "\uda06\udcd1\ud9b7\udd3a\udbf0\udc31\udade\uddf5\ud9b0\ude8b\uc0bb",
        -2, 13597, -349438423, 6253541013721554171L, -54927L, true, true, (char) 23113, (char) 63436,
        Double.longBitsToDouble(0x3fd8c8d4eac1ca40L), Double.longBitsToDouble(0x3feca020d7746fb2L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Long:1\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 5, 10, 6, "\ud837\udf0f", "\ub65f", "\udb53\udf6a\ud98a\udf89\udb47\ude10\u81f8\ud9b0\udd01\ud981\udf35\ud9d4\udc54\ud84b\uddfe",
        22, -1000, 0, -3213927865897964787L, -82477L, false, false, (char) 53356, (char) 36748,
        Double.longBitsToDouble(0x3fe7cb39cd000078L), Double.longBitsToDouble(0x3f3958ec31848000L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 10, 10, 12, "\ud868\udc0f\ud8cb\udc7a\ud8ce\udd8a\ud9b6\udcf2\ud93d\ude84", "\ud07c", "\ud9b0\udd01\ud981\udf35\ud9c6\udf8e\ud84b\ude8a\ud936\udef0\uda24\uded5\u5958\ud834\udf01",
        22, 71925, 1856721336, -2378476940743852543L, -43943L, false, true, (char) 18039, (char) 13846,
        Double.longBitsToDouble(0x3fec4c07e97a22e6L), Double.longBitsToDouble(0x3fe08e033b7f4e9bL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 15, 5, "\ud9ae\udfb6\udb50\uddc0\udb5d\ude0e\u8c93\ud900\udd14", "\ud09b\u1a69\ub0c2\u8473", "",
        -5, -1000, -1327235072, -243491750528679936L, -62624L, false, true, (char) 28331, (char) 0,
        Double.longBitsToDouble(0x3d16400000000000L), Double.longBitsToDouble(0x3e44000000000000L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 9, 9, 5, "\udbf9\udd77\udb50\uddc0\udb5d\ude0e\u8c93\ud93d\udf13", "\u4749\u1a69\u23ba", "\ud817\uddfa",
        53, 91835, -1327177857, -243491751276980830L, -90573L, false, true, (char) 25214, (char) 35466,
        Double.longBitsToDouble(0x3fcdd36fef6d5ac8L), Double.longBitsToDouble(0x3fe8d6c395acee61L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Long:7625465254152415954\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 12, 8, "\udbf9\udd77\udb50\uddc0\udb5d\ude0e\u8c93\ud900\udd14\uda58\uddd9\udb3d\ude9a\ud8a2\ude73\ud95b\udd41\ud90a\ude87\ud8e7\udfbd\ud92d\udc00\uda43\udd7e\ud856\ude17\ud936\udef0\uda24\uded5\u5958\ud834\udf01\udb78\udd23", "\u78da", "\ud937\udd78\udb81\udc07\uda6a\udc65\ud8f6\udffe\udab2\udff0\udb5a\udc88\uda64\udd98\uda3b\uddba\udba3\udeb2\ud9ce\udf2d\ud896\udfae\ud9d5\ude42\udaa8\udcb2\ud92a\udfc3\udb3d\udec8\ud9dd\udea1\ud841\udeea\ud90c\ude3a\ud908\udc87\udb52\udcc0\uda46\ude70\uda70\udd34\ud8ca\ude49\ud96e\udf87",
        -1, 48696, -822586402, 7625465254152505707L, -89753L, false, true, (char) 4723, (char) 18309,
        Double.longBitsToDouble(0x3feb592ffea747afL), Double.longBitsToDouble(0x3fe6c5ff8e944321L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 15, 0, "\udbf9\udd77\udb50\uddc0\udb5d\ude0e\u8c93\ud900\udd14", "\u80f9\u1a69\ub0c2\u9931", "\000",
        -5, -1000, 0, -3213927867297551603L, 96608L, true, true, (char) 35466, (char) 16493,
        Double.longBitsToDouble(0x3feedab5971ad872L), Double.longBitsToDouble(0x3fdacee615345c7aL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Integer:5\012",
        Z.run(T, 1, 0, 0, 2, "\ufa7b\udbc2\udf65\ud8eb\udfb5\uda2a\ude1b\ud9e2\uddb0", "\u8e2f\u57aa\ucd3c\u5bf6\u0877\u7e09\uab1c", "\ud8a4\udf59\udb06\udf1b\uda49\udf03\ud853\udc1e\udb38\udd1c\uda74\uddef\ud8fd\udc53\ud8a4\uddf4\ud90e\udedd\ud89b\ude10\uda6a\udc65\ud8f6\udffe",
        -5, -1000, -1828790363, -4582580990796213814L, -99990L, false, false, (char) 0, (char) 49407,
        Double.longBitsToDouble(0x3fbdcdc1abd7c000L), Double.longBitsToDouble(0x3fec8dcb8a16f213L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Integer:2790048\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 1, 10, 0, "\udbf9\udcc3", "\u51e5\u7fed\u0391\u78f8\u80f9\u1a69\ub0c2\u9931\u47df\u8be4\u9c9e\u5c64\u388e\u9d89\u18c5\u65ec\ubd6f\u64e2", "\udbe2\ude09\ud9b8\udd8e\ud89b\ude10\uda6a\udc65\ud8af\udf5a\ud92a\udd70\uda0f\udca1\uda64\udd98\uf17a\000\ud9ce\udf2d\ud8c1\udc63\udb44\udc69\ud97b\udfdc",
        32, 87189, 394611229, 3425166054533289602L, -88291L, true, true, (char) 23851, (char) 18795,
        Double.longBitsToDouble(0x3fa90fb4c374aab0L), Double.longBitsToDouble(0x3fb26911bbd23738L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Integer:1235528325\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 15, 6, 7, "\udbf9\udd77", "\u51e5\u8969\u18f2\u838d\u80f5\u1a69#\u9838\u0877\u8be4\u9c9e\u5c64\u31bd\u5247\u584d\u2b8d\u2a72\u64e2", "\ud800\uddb8\udb8c\uddc3\ud89b\udea2\uda6a\udc65\uda2e\udc1a\ud8a5\udd7b\udb5a\udc88",
        26, -1000, 0, -4975070213138634000L, -34464L, true, true, (char) 23621, (char) 20915,
        Double.longBitsToDouble(0x3fe857df764cfd5aL), Double.longBitsToDouble(0x3fec510fa29536e6L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Integer:172765015\0121=java.lang.Integer:2\012",
        Z.run(T, 2, 15, 0, 7, "\udbf9\udd77", "\u51e5\u7fed\u18de\u838d\u80f5\u1a69#\u9838\u0877\u8be4\u9c9e\u5c64\u31bd\u5247\u584d\u2b8d\u2a72\u64e2", "\000\ud8e8\udcab\ud89b\ude10",
        12, -262, 805306368, -2090426668339313138L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4c2f5734000000L), Double.longBitsToDouble(0x3fe0fa1135f62bbdL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Long:7801478478906250616\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 14, 8, "\udbe7\udf6f\ud820\udf03\ud877\udc5c\uda83\uddeb\ud990\udfae", "\u80f9\u1a69\u05d8\u6b24\u70b1\u2340\u419e\u5c64\uaa91\ub6fc\u761a", "\u8679\udacf\udd62\udb15\udda0\uda46\udfbc\ud8f0\udfc8\ud995\udc2d\ud928\udf2b\udb6c\uddc3\udab2\udff3\udb5a\udc88",
        -5, 97620, -526028238, 7801478478906307162L, -56546L, false, true, (char) 2511, (char) 56872,
        Double.longBitsToDouble(0x3fee882b8860984bL), Double.longBitsToDouble(0x3fe7e5aecb624ce3L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Integer:132890\0121=java.lang.Integer:132890\012",
        Z.run(T, 2, 1, 1, 6, "\udb75\ude6b\udb50\uddc0\uda79\udc4d\udb7a\udd15\ud900\udd36", "\u21c1\u1a69\ub0c2\u9931", "\ud91e\ude1b\udbab\udf6a\ud9f0\udcfe\u5958\ud834\udf01\uda22\udc95\ud925\udf7c\uda69\udd3d\ud845\udeb6\udb15\udde5",
        -2, 66445, 1997597387, 8088418335053427201L, -13979L, true, false, (char) 62066, (char) 23039,
        Double.longBitsToDouble(0x3fc6d920f8cfe84cL), Double.longBitsToDouble(0x3fee786811bd0a43L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Integer:5\0121=java.lang.Integer:81560\012",
        Z.run(T, 2, 0, 3, 2, "\udbf9\udd77", "\u51e5\u7fed\u18e9\u78f8\u80f9\u1aec\ub0c2\u9965\u083e\u8be4\u9c9e\u5c64\u31bd\u9d89\u18c5\u65ec\u22bf\u1a88", "\ud9a4\ude42\ud9db\ude2e\ud9ad\ude65\ud9e6\udeae\ud8ee\udd10\udab2\udff0\ud985\ude47\uda64\udd98\ud81d\udded\udba3\udeb2\uda42\udc9c\ud914\udcbc\ud877\udc2d\udb80\uddcb",
        45, 81515, -864188000, 3704105292477888134L, 27348L, false, false, (char) 11079, (char) 36693,
        Double.longBitsToDouble(0x3fc42b8748fc7878L), Double.longBitsToDouble(0x3fd4d1658d044eb8L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Integer:31724\0121=java.lang.Integer:31724\012",
        Z.run(T, 2, 3, 3, 5, "\udbf3\udd77\udb50\uddc0\udb5d\ude0e\u8c93\ud900\udd14", "\u80f9\u1aec\ub0c2\u9965", "\ud856\ude17\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\udae9\ude1e\uda61\udfe2\uda76\udcef\uda7b\udec7",
        36, 31688, 1095281762, 5165607134944923564L, -13979L, true, true, (char) 27809, (char) 15046,
        Double.longBitsToDouble(0x3fe3fa74dfdf23e6L), Double.longBitsToDouble(0x3febe4375d7c0a43L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:6.579251212010101\012",
        Z.run(T, 2, 7, 14, 5, "\uda74\udc75\udb50\uddc0", "\u71cc\u9385\u78f8\u70f1\u3282\u29d3\u6a71\u0877", "\ud936\ude44\udadd\udd13",
        6, -393, 1399597837, 5498906128151171512L, -10839L, true, true, (char) 62348, (char) 30516,
        Double.longBitsToDouble(0x3feeff730a9a3ab3L), Double.longBitsToDouble(0x3fd14179d00a6120L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[28132.5, 28277.5, 27659.0, 28630.0, 27954.5, 28426.0, 17969.5, 27864.0]]\0121=java.lang.Boolean:false |a0=[D:[[28132.5, 28277.5, 27659.0, 28630.0, 27954.5, 28426.0, 17969.5, 27864.0]]\012",
        Z.run(T, 2, 11, 11, 7, "\udbf9\udd1b\ud846\udfdc\uda95\ude44\u8c93\ud9e0\udeb0\ud9a0\udce1\udb3d\ude9a\ud8a2\ude73\u9d89\uda4a\udda5\ud994\udf54\u3650\udae1\ude1b\ud8a6\uddcd\ud9f2\udfde\uda12\udf9d", "\u57f6\u5eab", "\uda4c\udd9e\uda19\uddcf\ud8e8\udd86\ud8aa\udf10\ud846\ude14\ud9a5\ude53\ud989\udc11\ud803\udea4\udaf8\udd62\ud88f\ude29\udb71\udc75",
        51, 28374, 172194967, -1009947896989445170L, -71288L, false, true, (char) 28531, (char) 4456,
        Double.longBitsToDouble(0x3fd74d7c97dcc6b0L), Double.longBitsToDouble(0x3fe2fa38aba10d68L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[28108.0, 28617.5, 28048.0, 28360.0, 27954.5, 28344.0, 17969.5, 27864.0]]\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 11, 1, 8, "\udbc8\udfc3\udb50\uddc0\uda95\udda0\u8c93\ud9e0\udeb0\ud9a0\udce1\udb3d\ude9a\ud8a2\ude73\u9d89\uda4a\udda5\ud994\udf54\ud9b8\udd85\ud8cd\udf78\ud8a6\udced\ud9f2\udfde\uda12\udf9d", "\u57f6\u5eab", "\ud8f4\udea7\udbe2\udd30\ud8e8\udd86\ud8aa\udf10\ud950\udc38\ud9a5\ude2c\ud989\udc11\ud803\udea4\udaf8\udd62\ud88f\ude29\udb71\udc75",
        0, 28374, 172194967, -1009947896989445170L, -71288L, false, true, (char) 28531, (char) 4456,
        Double.longBitsToDouble(0x3fd74d7c900000b0L), Double.longBitsToDouble(0x3fd9100007421ad0L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[D:[[]] |a1=[D:[[]]\012",
        Z.run(T, 1, 11, 0, 0, "", "", "\ud91d\ude97L\000\ud8f9\udf70\udb44\udf23\000\ud947\udd02\uda08\udd39\ud9e6\udf1f\ud856\udec0\ud936\udef0",
        49, 68659, -748300894, 6011226938747650301L, 55161L, false, false, (char) 41042, (char) 5792,
        Double.longBitsToDouble(0x3f46512000000000L), Double.longBitsToDouble(0x3fec329000cf7c47L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27626.5, 28200.0, 28037.5, 28149.5, 28054.5, 28399.0, 17969.5, 883.0]] |a1=[D:[[21488.5, 27000.0, 19584.5, 1059.5, 17882.0, 20023.0, 7255.0, 6342.5]]\0121=java.lang.Boolean:false |a0=[D:[[27626.5, 28200.0, 28037.5, 28149.5, 28054.5, 28399.0, 17969.5, 883.0]] |a1=[D:[[21488.5, 27000.0, 19584.5, 1059.5, 17882.0, 20023.0, 7255.0, 6342.5]]\012",
        Z.run(T, 2, 11, 11, 1, "\ud805\udc80\udb3b\udc1b\udb5d\ude0e\u8c93\u0716\udaaf\uddb4", "\ua811\ud320\u9931\u0877\u8be4\u9c9e\u38de\u31bd\u9d89\u18c5\u65ec\u40e4\u55cd\u0c9e\u273a\u4482", "\ud99a\ude56\ud8e4\udff5",
        37, 82517, 586747775, -4582437385674565615L, -26352L, true, true, (char) 33930, (char) 53628,
        Double.longBitsToDouble(0x3fe5b5cb3c94b4c1L), Double.longBitsToDouble(0x3fdced91fc1da296L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Integer:8\0121=java.lang.Integer:8\012",
        Z.run(T, 2, 0, 0, 0, "", "\u48f3\u51e5\u2195\u1942\u78f8\u2edf\u785f\ub0c2\u9931\u0877\u8be4\u9c9e\u5c64\u31bd\u9d89\u18c5\u65ec\u638f\000\ud4ff\u008d\u32c1\uc4f9\u5238\u60a0\u5697\u72a3\u1131\u30fc\u9e1a\u673b\u7d17\u3aa8\u37cf\ub88e", "\uda07\udf0a\ud9a7\uddd2\udbb5\udd3a\ud980\ude29\udbee\udeeb\udba9\udd1c\udb92\udefc",
        16, -1000, -797966336, 6320408431753971133L, -19587L, false, true, (char) 46459, (char) 51955,
        Double.longBitsToDouble(0x3fe639676800006fL), Double.longBitsToDouble(0x3fecf6c2c64035a0L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 14, 14, 4, "\ud932\ude15\ud920\udfed\udb5d\ude0e\uc9c2\udbe7\udc50\ud8d4\udfb6\udb3d\udf08\ud84b\ude90\udac8\udc6e", "\u3da7", "\uda28\udd5b\udb90\udfe8\ud9f7\ude30\udad7\udf88\udb42\udcb6",
        1, 37336, -822217773, -7241863460069137170L, 49655L, false, true, (char) 3543, (char) 2887,
        Double.longBitsToDouble(0x3f778c8bc4c07e80L), Double.longBitsToDouble(0x3fd7a22f92d980ceL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Integer:10\0121=java.lang.Double:148.47776695177305\012",
        Z.run(T, 2, 0, 14, 4, "\udb20\ude0c\ud920\udfed\udb5d\ude0e\uc9c2", "\u7966\u8d87\ub2bf\uc8c4\u8c31", "\ud856\ude17\uda28\udd5b\udb90\udfe8\udb19\udd19\udad7\udf88\udb1e\udfb6\ud925\udf0f\uda62\udc3d\uda76\udcef\udb15\udda0\udbe2\ude09\ud9f9\uddc2\ud99b\ude4c\uda6a\udc65\udbcc\udd03\udab2\udff0\udb5a\udc88\uda64\udd98\uda3b\uddba\ud89b\udfc1\ud9e4\udd5a\uda0b\udc42\udbe3\udc7b\u984f\udafa\udf8a",
        50, 5120, 63510444, 7899731418431236886L, -90208L, false, false, (char) 22449, (char) 10703,
        Double.longBitsToDouble(0x3fe7d1426b7d0bcfL), Double.longBitsToDouble(0x3fef95f54562b905L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 6, 13, "\udbf9\udd77\udb50\uddc0\udb5d\ude0e", "\u18de\u78f8\ud09b\u459a\ub159\u9931\u0877\u4e8f\u1bce\u5c64\u31bd\u9d89\u18c5\u65ec\ubd6f\u051e\u49bd", "\ud8e8\udd86\ud89b\ude10",
        -5, -1000, 814801172, -9152070884755173495L, -65713L, true, true, (char) 28876, (char) 45265,
        Double.longBitsToDouble(0x3fd416689274f540L), Double.longBitsToDouble(0x3fe7f0c931bcda00L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 7, 6, 14, "\000\udb50\uddab\udb5d\ude0e", "\u154d", "\ud90e\udd60\uda49\ude9e\ud947\uddfb\000\000\ud856\ude17\ud936\udef0\uda24\uded5\u58cd\ud834\udf01\u2b0d\ud901\udc7f\000\udb9e\udc0e\000\000\000\000\000\ud8f6\udffe\ue914\udb5a\udc83\uda64\udd98\uda3b\uddba\udaf3\udca9\ud9ce\udf2d\ud8c1\udc63\udba9\uddd9\uc87b\ud9ac\ude7b",
        8, -1000, 0, 239127287369641301L, -100000L, false, false, (char) 3640, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e44000000000000L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Integer:6\0121=java.lang.Long:59277777114716788\012",
        Z.run(T, 2, 0, 2, 15, "\udbf9\udd77\udb50\uddc0\ud84d\udc25\udb7c\udfb5\000", "\u80f9", "\ud9b0\udd01\uda08\udd39\ud90d\udd93\ud856\ude17\ud936\udef0\uda24\uded5\000\000\000\000\000\uda76\udcef",
        6, -384, -550135955, 59277777114759168L, -42380L, true, false, (char) 36998, (char) 3187,
        Double.longBitsToDouble(0x3fe08e033b7f4e9bL), Double.longBitsToDouble(0x3f4f531f3c000000L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 0, 0, 0, "\udbaf\udcb6", "\u1faa", "\udb3d\ude9a\ud8a2\ude73\udb9e\udc6c\ua96b\ud9b0\udc08\ud993\udf9e\000\ud81e\udca5",
        58, 62143, 2044588427, -3228766033012839667L, -91808L, false, true, (char) 33629, (char) 54713,
        Double.longBitsToDouble(0x3fd4db276adc47d2L), Double.longBitsToDouble(0x3fd76b6d938be6a2L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[28071.0, 28186.0, 27960.5, 28371.0, 27702.5, 28638.5, 28121.0, 28438.5]] |a1=[D:[[13339.5, 17447.5]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 13, 4, "\udb7e\udc64\udaa1\uddd6\ud89d\udfed\udbe2\ude5d\ud940\udc20\uda77\udc04\udb3d\udef0\ud8a2\ude73\ud87c\udeec", "\u6867\u887f", "\uda24\uded5",
        -4, 14022, -481855280, -5231814433218991060L, -26272L, false, false, (char) 33629, (char) 54713,
        Double.longBitsToDouble(0x3fee2c9da4477aaaL), Double.longBitsToDouble(0x3feb854dd9dfce97L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Integer:69541\0121=java.lang.Integer:69541\012",
        Z.run(T, 2, 0, 0, 0, "", "\u82df", "\uda58\uddb0\udb3d\ude9a\ud8a2\ude73\udb9e\udc6c\ud8bf\udd54\ud9b6\ude9a\ud880\udc2f\u5bfb\ud81e\udca5\udb01\udd8a\uda24\uded5\uda1c\udcb9\udb1b\uddf7\udbc2\udc10\uda10\udc04\uda62\udc3d\uda76\udcef\ubb8d\000\udb4e\ude82\udb2c\udfc2\udb86\udc87\ud8ea\udc0e\udb3c\udcb7\udb24\udcc1",
        0, 69541, -505801205, -1638209591123029788L, -33335L, false, false, (char) 35281, (char) 65260,
        Double.longBitsToDouble(0x3fec6c9a34929185L), Double.longBitsToDouble(0x3fd842e068d4dc68L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 1, 1, 0, "\000\udaba\udc2f\u8d71\ud882\udca1\ud8d3\udf93\ud8b6\udfe0\u4eba\uda68\uddce\ud95b\udd41\u0323\ud9b0\udc08\u3c9d\udb47\ude02\udadf\udf5e", "\u80fc", "\udbbb\uddc6\uda62\udc29\uda76\udcef\ud803\udd47\ud927\udd56\ud8c0\uddc1\uda5b\udfa7\udb7e\ude17\ud88a\ude65\ud8d1\udce3\udbc7\udc22\udae6\udf9d\udbbe\udf67\ubf1b\ud985\udf26\ud89d\udf80\u61f7\udac3\udcb3",
        0, 77619, -1906366605, -4398445883784748924L, 87506L, true, false, (char) 19737, (char) 64188,
        Double.longBitsToDouble(0x3fea1cc76fbed581L), Double.longBitsToDouble(0x3fbe2060db9bdc58L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 10, 12, "\ud868\udc0f\ud8cb\udc7a\ud8ce\udd8a\ud9b6\udcf2\ud93d\ude84", "\u9f49", "\ud9b0\udd01\ud993\udff4\ud9c6\udf8e\ud84b\ude8a\ud936\udef0\uda24\uded5\u5958\uda05\udd29",
        7, 87465, 1856721336, -2378476940743852543L, -43943L, false, true, (char) 18039, (char) 13846,
        Double.longBitsToDouble(0x3fc1301fa5e88b98L), Double.longBitsToDouble(0x3fe08e033b7f4e9bL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Integer:1000\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 7, 3, "\ud9ae\udfb6\udb50\uddc0\udb5d\ude0e\u8c93\ud900\udd14", "\ud09b\u1a69\ub0c2\u8473", "",
        -5, -1000, -1327235072, -243491750528679936L, -62624L, false, true, (char) 28331, (char) 0,
        Double.longBitsToDouble(0x3f9e000000001640L), Double.longBitsToDouble(0x3e422869d0000000L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 6, 6, 7, "\u5967", "\u51e5\u8969\u18f2\u6ec2\u7a1f\u1a69#\u9903\u1ccf\u8be4\u9c9e\u5c64\u31bd\u5247\u584d\u2c1f\u2a72\u64e2", "\ud800\uddb8\udb8c\uddc3\ud89b\udea2\uda6a\udc65\uda2e\udc1a\ud8d7\udf83\udb9a\udf2c",
        36, -1000, 0, -4975070214083114000L, -27777L, false, true, (char) 40696, (char) 19222,
        Double.longBitsToDouble(0x3fcd643e95131820L), Double.longBitsToDouble(0x3fe726f886cb889dL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 7, 7, 9, "\uda74\udc75\udb50\uddc0", "\u71cc\u9385\u78f8\u70f1\u3282\u29d3\u6a71\u0877", "\ud936\ude44\ud817\udd50",
        6, -393, -1251202291, -6889870803154021960L, -10839L, true, true, (char) 62348, (char) 30516,
        Double.longBitsToDouble(0x3feeff730a9a3ab3L), Double.longBitsToDouble(0x3fd14179d00a6120L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[-24.0, -24.0, 27732.0, 28389.0, 28099.0, 28251.5, 27766.5, 28467.5]] |a1=[D:[[-24.0, 2631.0, 1059.5, 26247.0, 24688.5, 15126.5, 20038.0, 20140.5]]\012",
        Z.run(T, 1, 11, 0, 0, "\000\000\ud8d8\uddfa\udbb6\udce7\ud91d\ude97L\u00d5", "\000\u14be\u0877\ucd3e\uc111\u765d\u9cbc\u9d89\u18c5\u65ec", "\ud896\udd91",
        9, 14553, -769822086, -1289955611466192762L, -100000L, false, true, (char) 5398, (char) 57559,
        Double.longBitsToDouble(0x3fe662b6f80a2ba4L), Double.longBitsToDouble(0x3fdc52aa2eab1280L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Long:8658159896260782633\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 5, 10, "\udbf9\udd77\udb50\uddc0\udb5d\ude0e", "\u18de\u78f8\ud09b\u459a\ub159\u9931\u0877\u4e8f\u1bce\u5c64\u31bd\u9d89\u18c5\u65ec\ubd6f\u051e\u49bd", "\ud8e8\udd86\ud8a1\udc39",
        -5, -1000, 1412420884, 8658159896260720911L, 61722L, true, true, (char) 28876, (char) 45265,
        Double.longBitsToDouble(0x3fd416689274f540L), Double.longBitsToDouble(0x3fe7f0c931bcac00L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Double:1.5511210043331066E25\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 13, 12, 0, "\udbf9\udd77\udb50\uddc0\ud87a\udf06\u8c93\ud900\udd14\udbe9\udfe3", "\u1a69\u6c9c\u9931\u0877\u90c6\ucd2d\uacf1\u2a4c\u9d89\u18c5\u65ec\ua8b1\u64be\u900c\u946f\u2492\u8d7e\u5238\u3c7a\u1edc\u97e9\ub9ed\u30fc\u9e1a\u673b\u7d17\u3aa8\uabf8\u3491\ubdaa", "\udb15\ude01\udb31\ude2c\udb83\uddb8\ud9ac\uddc9",
        25, 31103, 443737181, 9066806674997319007L, -48508L, false, true, (char) 36374, (char) 9860,
        Double.longBitsToDouble(0x3fb726604eeca0d8L), Double.longBitsToDouble(0x3feea880167146d6L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 0, 0, 0, "\udbf9\udd77\udb50\uddc0\udb5d\ude0e\u8c93\ud900\udd14", "\u80f9\u1aec\ub0c2\u9965", "\ud856\ude17\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\uda3d\ude28\uda61\udfe2\uda76\udcef\uda7b\udec7",
        25, 58368, 1095281764, 5165607134944923564L, -13979L, true, true, (char) 27809, (char) 15046,
        Double.longBitsToDouble(0x3fe3fa74dfdf23e6L), Double.longBitsToDouble(0x3febe43758bd0a43L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[-24.0, -24.0, -24.0, 28099.0, 28140.5, -24.0, -24.0, 82.5]] |a1=[D:[[-24.0, -24.0, -24.0, 26247.0, 24688.5, 15030.0, 20038.0, 20140.5]]\012",
        Z.run(T, 1, 11, 0, 0, "\000\000\000\udbb6\udc09\000\000\u00d5", "\000\000\000\ucd3e\uc111\u759c\u9cbc\u9d89\u18c5\u65ec", "\ud896\udd91",
        9, 14553, -769822086, -1289955611466192762L, -100000L, false, true, (char) 5398, (char) 57559,
        Double.longBitsToDouble(0x3fe662b6f80a2ba4L), Double.longBitsToDouble(0x3fdc52aa2eab1280L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 5, 8, "\udbf9\udd77\uda60\ude48\uda93\udfd5\udb52\udf77", "\u78f1", "\uda4a\udd07\ud9b0\udd01\uda08\udd39\ud90d\udd93",
        28, 7627, -1327177857, 0L, -100000L, false, true, (char) 62562, (char) 53130,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.Integer:32\0121=java.lang.Integer:32\012",
        Z.run(T, 2, 0, 0, 0, "", "\ucf6b", "\uda58\uddb0\udb3d\ude9a\ud8a2\ude73\udb9e\udc6c\ua96b\ud9b0\udc08\uda4d\ude24",
        32, 5024, -822075282, -5700185489745776245L, -91808L, false, false, (char) 33629, (char) 54713,
        Double.longBitsToDouble(0x3fd4db2768dc47d2L), Double.longBitsToDouble(0x3fe64dd4dc65a7e6L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.Long:11628\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 5, 10, 12, "\ud862\udff4\ud90e\udefd\ud9f2\uddbd\u27fa\ud917\udf8b", "\u158f", "\uda7c\udc48\uda79\udca6\ud994\udfff\ud84b\ude05\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda62\udc3d\uda76\udcef",
        19, 14, 936332730, 5131546223906976437L, -42380L, true, false, (char) 8350, (char) 50371,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.Long:23206929840\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 5, 10, 12, "\ud862\udff4\ud90e\udefd\ud9f2\uddbd\u27fa\ud917\udf8b", "\u158f", "\uda7c\udc48\uda79\udca6\ud994\udfff\ud84b\ude05\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda62\udc3d\uda76\udcef",
        40, 14, 936332730, 5131546223906976437L, -42380L, true, false, (char) 8350, (char) 50371,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Long:11628\0121=java.lang.Long:11628\012",
        Z.run(T, 2, 5, 5, 0, "\ud862\udff4\ud90e\udefd\ud9f2\uddbd\u27fa\ud917\udf8b", "\u158f", "\000\uda79\udca6\udab5\udcb0\udae9\uddf3\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda62\udc3d\uda76\udcef",
        19, 14, 936332730, 5131546223906976437L, -42380L, true, false, (char) 0, (char) 50371,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Double:11628.0\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 10, 12, "\ud862\udff4\uda67\udd68\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\uda7c\udc48\uda79\udca6\ud994\udfff\ud84b\ude05\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda54\udf04\uda76\udcef",
        19, 14, 936332730, 5131546224359961269L, -42380L, true, false, (char) 8350, (char) 50371,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Long:35240152720\0121=java.lang.Long:35240152720\012",
        Z.run(T, 2, 5, 5, 0, "\000\000\ud9db\uddcdZ\000", "\u158f", "\uda30\udc42\uda79\udca6\000\ud83f\uddfe\uda3d\uddd3\uda24\uded5\u5958\ud834\udf01\u2b0d\000\uda4d\udf3d\u00d3",
        41, 14, 922746880, 5131546222825308341L, -100000L, true, false, (char) 8214, (char) 73,
        Double.longBitsToDouble(0x3fe08e00012d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.Double:11628.0\0121=java.lang.Double:11628.0\012",
        Z.run(T, 2, 6, 6, 12, "\ud862\udff4\uda67\udd68\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\uda7c\udc48\uda79\udca6\ud994\udfff\ud84b\ude05\ud936\udef0\uda24\uded5\u5958\ud89c\udcac\ud8c3\udc33\udbe2\udc93\uda54\udf04\uda76\udcef",
        19, 14, 936332730, 5131546224359961269L, -42380L, true, false, (char) 8350, (char) 50371,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Long:1\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 5, 10, 12, "\ud862\udff4\ud90e\udefd\ud9f2\uddbd\u27fa\ud917\udf8b", "\u158f", "\uda7c\udc48\uda79\udca6\ud994\udfff\ud84b\ude05\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\ud824\udd3e\ud923\udf2f",
        14, 14, 936332730, 5131546223906976437L, -42380L, true, false, (char) 8350, (char) 50371,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 10, 12, "\ud862\udff4\uda67\udd68\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\ud9b0\udd01\ud8be\udfaf\ud994\udfff\ud84b\ude05\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\udb83\udfcb\u7ce8\uda76\udcef",
        14, 14, 936332730, 5131546224359961269L, -42380L, true, false, (char) 8350, (char) 50371,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd95067378e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.Double:171.0\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 10, 12, "\ud862\udff4\uda67\udd68\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\uda7c\udc48\uda79\udca6\ud994\udfff\ud84b\ude05\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda54\udf04\uda76\udcef",
        19, 2, 936332730, 5131546224359961269L, 37445L, false, true, (char) 14969, (char) 62151,
        Double.longBitsToDouble(0x3fd95067398e7aa0L), Double.longBitsToDouble(0x3fe23f8bf31befeaL)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 7, 10, 12, "\ud862\udff4\ud90e\udefd\ud9f2\uddbd\u27fa\ud917\udf8b", "\u158f", "\ud948\ude4d\udb49\ude08\udbe2\udcbc\ud9ef\udcd4\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda36\udfa3\udb23\udc1c\ud82f\udf60\ud923\udf2f",
        14, 14, 936332730, 5131546223906976437L, -42380L, true, false, (char) 8350, (char) 50371,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.Long:1\0121=java.lang.Long:1\012",
        Z.run(T, 2, 5, 5, 12, "\ud862\udff4\ud90e\udefd\u5bf0\000\000", "\u0099", "\ud82a\udfff\000\ud994\udf54\ud84b\ude05\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda17\udcea\udaee\udf01\ud824\udc86\ud923\udf2f",
        14, 14, 19898, 0L, -42380L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e20000000000000L), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 6, 6, 0, "\ud862\udff4\ud90e\udefd\uda63\udfc7\udb1a\udea7\ud93e\udd8b", "\u158f", "\ud91a\udf50\udb28\udef3\udbe2\udcbc\ud9ef\udcd4\udb70\udceb\uda24\uded5\u5958\ud834\udf01\uda36\udfa3\ud931\udd43\ud821\udc17\ud923\udf2f",
        14, 14, 936332730, 5131546223906976437L, -42380L, true, false, (char) 8350, (char) 50371,
        Double.longBitsToDouble(0x3fe08e033987619bL), Double.longBitsToDouble(0x3fd539e7398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.Double:15.0\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 10, 12, "\ud862\udff4\uda67\udd68\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\uda7c\udc48\uda79\udca6\ud994\udfff\ud84b\ude05\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda54\udf04\ud883\udcb5",
        15, 14, 936332730, 5131546224359961269L, -42380L, true, false, (char) 8350, (char) 50371,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.lang.Double:15.0\0121=java.lang.Long:15\012",
        Z.run(T, 2, 6, 5, 12, "\ud862\udff4\uda67\udd68\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\uda5f\udd48\uda79\udca6\ud994\udfff\ud84b\ude05\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda54\udf04\ud883\udcb5",
        15, 14, 936332730, 5131546222833234613L, -42380L, true, false, (char) 8350, (char) 50371,
        Double.longBitsToDouble(0x3fe08e033800009bL), Double.longBitsToDouble(0x3fd95000098e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Double:2.70805020110221\012",
        Z.run(T, 2, 9, 7, 13, "\ud862\udff4\uda67\udd68\ud9b2\udd14\u280b\ud917\udf8b", "\u158f", "\uda7c\udc48\uda79\udca6\ud994\udfff\uda53\udcea\udb21\udd47\ud801\ude68\udbf5\uddc0\ud834\udf01\uda21\udff7\ud925\udf7c\uda54\udf04\ud883\udcb5",
        15, 14, 936332730, 5131546224359961269L, -42380L, true, false, (char) 8350, (char) 50371,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=java.lang.Double:15.0\0121=java.lang.Double:15.0\012",
        Z.run(T, 2, 6, 6, 12, "\ud862\udff4\uda98\udd22\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\uda5f\udd48\uda79\udca6\ud994\udfff\ud84b\ude05\ud936\udef0\uda24\uded5\u5958\udb73\udc5f\udae9\udd6d\ud8b9\udc75\uda54\udf04\ud883\udcb5",
        15, 14, 936332730, 5131546222833234613L, -42380L, true, false, (char) 8350, (char) 50371,
        Double.longBitsToDouble(0x3fe08e033800009bL), Double.longBitsToDouble(0x3fd95000098e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.lang.Long:15\0121=java.lang.Long:15\012",
        Z.run(T, 2, 5, 5, 12, "\ud862\udff4\udb0b\udd5a\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\uda5f\udcfb\uda79\udca6\ud994\udfff\ud84b\ude05\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda54\udf04\ud883\udcb5",
        15, 14, 936332730, 5131546222833234613L, 23156L, true, true, (char) 36122, (char) 41464,
        Double.longBitsToDouble(0x3fe08e033800009bL), Double.longBitsToDouble(0x3fd95000098e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=java.lang.Double:2.70805020110221\0121=java.lang.Double:2.70805020110221\012",
        Z.run(T, 2, 7, 7, 13, "\ud862\udff4\uda67\udd68\ud9b2\udd14\u280b\ud917\udf8b", "\u14f6", "\uda7c\udc48\uda79\udca6\ud994\udfff\uda53\udcea\000\udbcc\udc05\000\u00a2\000\ud901\udc7f\uda54\udf04\ud883\udcb5",
        15, 14, 936332730, 15457047667077813L, -42380L, true, false, (char) 8350, (char) 73,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd9506730007aa0L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 10, 10, 1, "\udbf9\udd77\uda60\ude48\uda93\udfd5\udb52\udf77", "\u78f1", "\uda4a\udd07\ud9b0\udd01\uda90\uddfd\ud932\udd8f",
        14, 7627, -1327177857, 0L, -100000L, false, true, (char) 62562, (char) 53130,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 7, 7, 7, "\ud862\udff4\ud90e\udefd\uda03\udfbd\u27fa\ud917\udf8b", "\u158f", "\ud948\ude4d\udb49\ude08\udbe2\udcbc\ud9ef\udcd4\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda36\udfa3\udb23\udc1c\u3f51\udab7\udef4",
        14, 14, 936332730, 5131546223906976437L, -42380L, true, false, (char) 8350, (char) 50371,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Boolean:false |a0=[D:[[27673.0, 28642.0, 27931.5, 28316.0, 28087.0, 28292.0, 5093.0, 27763.5]] |a1=[D:[[2735.5]]\012",
        Z.run(T, 2, 6, 11, 16, "\ud862\udff4\uda67\udd68\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\uda7c\udc48\uda79\udca6\ud994\udfff\ud84b\ude0b\ud88e\udc1c\uda24\udf12\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\ud847\udd3e\ud9f4\udd74",
        34, 0, 936332730, 5131546224359961269L, -42380L, true, false, (char) 8350, (char) 42919,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=java.lang.Double:17.0\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 10, 12, "\u922a\uda67\udd9e\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\uda7c\udc48\u46f3\ud994\udfd2\ud84b\ude05\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda54\udf04\ud883\udcb5",
        17, 1, 936332730, 5131546224359961269L, -42380L, true, false, (char) 8350, (char) 50371,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd2c097398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Boolean:false |a0=[D:[[27673.0, 28642.0, 27931.5, 28316.0, 28087.0, 28292.0, 5093.0, 27763.5]] |a1=[D:[[2735.5]]\012",
        Z.run(T, 2, 7, 11, 0, "\ud862\udff4\uda67\udd68\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\uda7c\udc48\uda79\udca6\ud994\udfff\ud84b\ude0b\uda5a\uddc2\ud901\udce6\u5956\ud834\udf01\uda21\udff7\ud925\udf7c\ud847\udd3e\ud9f4\udd74",
        34, 0, 936332730, 5131546224359961269L, -42380L, true, false, (char) 8350, (char) 42919,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 6, 6, 4, "\ud862\udff4\uda67\udd68\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\ud89f\udedb\uda79\udca6\ud994\udfff\ud84b\ude0b\ud88e\udc1c\uda24\udf12\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\ud858\udd1f\uda06\ude17",
        34, 0, 936332730, 5131546224359961269L, -42380L, true, false, (char) 8350, (char) 42919,
        Double.longBitsToDouble(0x3fe08e033978c79bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=java.lang.Integer:34\0121=java.lang.Boolean:false |a0=[D:[[27652.0, 28555.5, 27931.5, 28316.0, 28087.0, 28292.0, 27766.0, 28486.5]] |a1=[D:[[2735.5]]\012",
        Z.run(T, 2, 0, 11, 16, "\ud838\udf47\uda67\udd68\udb9e\udd38\ud91c\udebd\ud917\udf8b", "\u158f", "\uda7c\udc48\uda79\udca6\ud994\udfff\ud84b\ude0b\ud88e\udc1c\uda24\udf12\u5958\udb7d\udd2e\udb2a\udc37\ud920\udc7c\ud847\udd3e\ud9f4\udd74",
        34, 0, 936332730, 5131546224359961269L, -42380L, true, false, (char) 32831, (char) 42919,
        Double.longBitsToDouble(0x3fe0de8b392d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 1, 7, 16, "\ud862\udff4\uda67\udd68\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\uda7c\udc48\uda79\udca6\ud994\udfff\ud874\udee0\ud987\udc78\udb07\udc20\ud8a4\udfac\ud83e\udf36\uda21\udff7\ud925\udf7c\ud847\udd3e\ud9f4\udd74",
        34, 0, 936332730, 5131546222078259893L, -46600L, true, false, (char) 8350, (char) 55806,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Long:1\012",
        Z.run(T, 2, 10, 5, 16, "\ud862\udff4\ud96d\udf4b\udabb\udfae\u2897\ud917\udf8b", "\u158f", "\u59f5\uda79\udca6\ud994\udfff\ud84b\ude0b\ud88a\udedb\uda24\udf12\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\ud845\ude3e\ud9f4\udd74",
        34, 0, 936332730, 5622013308625538833L, -42380L, true, false, (char) 8350, (char) 42919,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=java.lang.Double:17.0\0121=java.lang.Long:17\012",
        Z.run(T, 2, 6, 5, 16, "\u922a\uda67\udd9e\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\uda7c\udc48\u46f3\ud9a6\udfa1\ud84b\ude05\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda54\udf04\ud883\udcb5",
        17, 1, 936332730, 5131546224359961269L, -42380L, true, false, (char) 8350, (char) 50371,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd2c097398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Double:2.833213344056216\012",
        Z.run(T, 2, 16, 7, 9, "\u922a\uda67\udd9e\udb9e\udd38\u27fa\udbbf\ude4d", "\u158f", "\uda7c\udc48\u46f3\ud994\udfd2\ud84b\ude05\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda54\udf04\ud883\udcb5",
        17, 1, 936332730, -8758680927538070633L, -12639L, false, true, (char) 14969, (char) 62151,
        Double.longBitsToDouble(0x3fd2c097398e7aa0L), Double.longBitsToDouble(0x3fef0c2f6dbd50a6L)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 7, 7, 6, "\uda04\udc99\uda67\udd68\u5f56\udbed\ude3a\ud917\udf8b", "\u158f", "\uda88\uded2\uda79\udca6\ud994\udfff\ud84b\ude0b\uda5a\uddc2\ud8ec\udde6\u5956\ud834\udf01\uda21\udff7\udae9\udc9f\udbf2\udc58\ud9f4\udd74",
        34, 0, 936332730, 5131546224359961269L, -42380L, true, false, (char) 8350, (char) 42919,
        Double.longBitsToDouble(0x3fe88e03392d299bL), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=java.lang.Integer:34\0121=java.lang.Integer:34\012",
        Z.run(T, 2, 0, 16, 16, "\ud838\udf47\uda67\udd68\udb9e\udd38\ud91c\udebd\ud917\udf8b", "\u158f", "\uda7c\udc48\uda79\udca6\ud994\udfff\ud84b\ude0b\ud88e\udc1c\uda24\udf12\u5958\udb7d\udd2e\udb2a\udc37\ud920\udc7c\ud847\udd3e\ud9f4\udd74",
        34, 0, 936332730, 5131546224359961269L, -42380L, true, false, (char) 32831, (char) 42919,
        Double.longBitsToDouble(0x3fe0de8b392d299bL), Double.longBitsToDouble(0x3fdf9d47398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=java.lang.Double:17.0\0121=java.lang.Double:17.0\012",
        Z.run(T, 2, 6, 6, 8, "\u0a99\uda67\udcf2\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\uda7c\udc48\u46f3\ud96b\udfa1\ud84b\ude05\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\u92fd\uda4d\ude85\ud883\udcb5",
        17, 1, 936332730, 5131546224359961269L, -42380L, true, false, (char) 8350, (char) 50371,
        Double.longBitsToDouble(0x3fe08e03392d299bL), Double.longBitsToDouble(0x3fd2c097398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=java.lang.Long:41\0121=java.lang.Long:41\012",
        Z.run(T, 2, 5, 5, 16, "\u922a\uda67\udd9e\udb9e\udd38\u27b8\udaee\udf14", "\u158f", "\uda7b\udf5c\uda6b\udc5f\uda05\ude07\ud84b\uded3\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\udb90\udd0d\udae8\udd99\udb10\ude94",
        41, 1, 936332730, -3587422654222431010L, -42380L, true, false, (char) 8350, (char) 4537,
        Double.longBitsToDouble(0x3fe7bdab994e299bL), Double.longBitsToDouble(0x3fde0097398e7a72L)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=java.lang.Double:3.3452526613163927E49\0121=java.lang.Integer:69876\012",
        Z.run(T, 2, 13, 3, 0, "\uc1b4\udb50\uddab\udb5d\ude0e(\000", "\u80f9\u1a69\ub0c2\u9931", "\ud856\ude17\ud936\udef0\uda24\uded5\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\uda62\udc3d\uda76\udcef\udb15\udda0",
        41, 69835, -295586022, 396210842L, -100000L, false, true, (char) 3187, (char) 14969,
        Double.longBitsToDouble(0x3febfa74de33fa98L), Double.longBitsToDouble(0x3fee7b4811bd0a43L)));
  }
  @Test(timeout = 4000)
  public void test129() throws Throwable {
    assertEquals("0=java.lang.Long:1\0121=java.lang.Long:1\012",
        Z.run(T, 2, 5, 5, 16, "\ud862\udff4\uda67\udd68\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\ud989\udde0\uda9f\ude9d\ud994\udfff\ud84b\ude0b\uda89\uddb0\ud8d2\udf8a\u1326\udbd6\udcb2\uda22\udc5a\ud925\udf7c\ud847\udd3e\ud9f4\udd74",
        34, 0, 936332730, 4410970283980673365L, -42380L, true, false, (char) 48888, (char) 34187,
        Double.longBitsToDouble(0x3fe66eee412d48d3L), Double.longBitsToDouble(0x3fd95067398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test130() throws Throwable {
    assertEquals("0=java.lang.Double:2.833213344056216\0121=java.lang.Double:2.833213344056216\012",
        Z.run(T, 2, 7, 7, 9, "\u922a\uda67\udd9e\udb9e\udd38\u27fa\udbbf\ude4d", "\u158f", "\uda7c\udc48\u46f3\ud994\udfd2\ud858\udf05\ud936\udef0\uda24\uded5\u5958\ud834\udf01\ud914\uddb4\ud815\udf8f\ud9f0\ude7e\ud883\udcb5",
        17, 1, 924550932, -8758680927538070633L, 60681L, true, true, (char) 54807, (char) 5828,
        Double.longBitsToDouble(0x3fd9e0fc325a5234L), Double.longBitsToDouble(0x3fd2c097398e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test131() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 1, 1, 16, "\ud862\udff4\uda67\udd68\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\uda7c\udc48\ud978\udd48\ud995\udc15\ud84b\ude0b\udb0d\udefb\udb33\udfda\u5958\ud834\udf01\uda21\udff7\ud925\udf7c\ud847\udd3e\ud9f4\udd74",
        46, 0, 936332730, 5131546224359961269L, -42380L, true, false, (char) 8350, (char) 42919,
        Double.longBitsToDouble(0x3fe08e033b25c69bL), Double.longBitsToDouble(0x3fd0bf16e98e7aa0L)));
  }
  @Test(timeout = 4000)
  public void test132() throws Throwable {
    assertEquals("0=java.lang.Double:2.2314239266528E13\0121=java.lang.Long:22314239266528\012",
        Z.run(T, 2, 6, 5, 12, "\ud862\udff4\uda67\udd68\udb9e\udd38\u27fa\ud917\udf8b", "\u158f", "\uda5f\udd48\uda79\udca6\ud994\udfff\ud84b\ude05\ud936\udef0\udaa3\udcf4\u5958\ud970\udf21\uda22\udc9a\ud905\udda3\uda54\udf04\ud883\udcb5",
        48, 27, 931166394, 5131471116740129461L, 88692L, false, false, (char) 37343, (char) 50371,
        Double.longBitsToDouble(0x3fe08e033800009bL), Double.longBitsToDouble(0x3fd950000b447aa0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.util.MathUtils|gcd|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|lcm|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|long,long,java.lang.String|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|long,long|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficient|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficientDouble|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficientLog|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|cosh|double|static",
    "M|org.apache.commons.math.util.MathUtils|equals|double,double|static",
    "M|org.apache.commons.math.util.MathUtils|equals|double,double,double|static",
    "M|org.apache.commons.math.util.MathUtils|equals|[D,[D|static",
    "M|org.apache.commons.math.util.MathUtils|factorial|int|static",
    "M|org.apache.commons.math.util.MathUtils|factorialDouble|int|static",
    "M|org.apache.commons.math.util.MathUtils|factorialLog|int|static",
    "M|org.apache.commons.math.util.MathUtils|hash|double|static",
    "M|org.apache.commons.math.util.MathUtils|gcd|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|lcm|int,int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
