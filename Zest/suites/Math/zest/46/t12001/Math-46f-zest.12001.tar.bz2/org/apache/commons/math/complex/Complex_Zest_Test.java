package org.apache.commons.math.complex;
import org.junit.Test;
import static org.junit.Assert.*;
public class Complex_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.7702633183785633, -0.0) |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 9, 5, 13, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\udb58\udc2b\uda21\udd53\udbc3\udeb9\ud8d9\ude05\ud9b8\ude5d", "\u80c0\ud245\uc3ce\u5ced\u3411\u5c49\u8209\u102f\u9b45\u2537\u85b1\u0842\u9fa1\u8f32\ua159\u2e5c\u72b1", "\udbcb\udc17\ud93f\ude97\udab1\udec2\ud897\udd1f",
        20, 52962, -1150668822, 4176770180412870464L, -15755L, false, true, (char) 26510, (char) 64588,
        Double.longBitsToDouble(0x3fe6211d7a0feed8L), Double.longBitsToDouble(0x3fced61c63ba9c60L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.9970433128136158, -0.0) |this=org.apache.commons.math.complex.Complex:(0.07691742762341347, 0.0)\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 9, 5, 5, "\udbc2\udc39\udaf5\udfef\ud9b9\udd24\ud8b6\udf9a\udb2b\udf3c\ud93c\udcee\ud8e4\udc81\ud8d9\ude05\udad6\udcab\uda2f\udc5b\udb30\udcfb\uda0d\udd0f", "\u5ced\u3411\u2db9\u55d2\u102f\u9b45\u2407", "\udb53\udc51\udbeb\udf70\uda70\udfb2\ud99c\ude0c\ud9a3\ude2b\udba5\udcd2\ud9df\udf67\udbcb\udc17\ud93f\ude97\udab1\udec2\ud897\udd1f\ud948\ude7e\ud9e1\udeca\ud8eb\udeac\udb91\udeb1\udab9\uddb2\ud8dc\udc32\ud9ec\udd4e\udafd\udfa9\uda22\ude1f\udaa7\udc9c\uda71\udd22\udb0b\udcbe\u7861\ud974\udf49\ud88d\uddc1\ud9cb\udd65\udafe\udfb8",
        11, 96816, 2077131235, 102258233654674445L, 19399L, true, false, (char) 10119, (char) 50191,
        Double.longBitsToDouble(0x3fb3b0dc4c228fe0L), Double.longBitsToDouble(0x3fa6d8653a54e910L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.7702633183785633, -0.0) |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\012",
        Z.run(T, 1, 9, 5, 13, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\udb58\udc2b\uda21\udd53\udbc3\udeb9\ud822\ude02\u1e2a", "\u80c0\ud245\u58b3\u4e27\u3411\u5c49\u8209\u102f\u9b45\u2537\u85b1\u0842\u317c\u946a\ua159\u2e5c\u72b1", "\udbcb\udc17\ud93f\ude97\udab1\udec2\ud897\udd1f\ud948\ude7e\ud9e1\udeca",
        43, 51089, 2139351104, 6678471818910319359L, -15755L, false, true, (char) 26510, (char) 64588,
        Double.longBitsToDouble(0x3fe6211d7a0feed8L), Double.longBitsToDouble(0x3fced61c63ba9c60L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.7702633183785633, -0.0) |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\0121=org.apache.commons.math.complex.Complex:(1.0, 0.0) |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\012",
        Z.run(T, 2, 9, 16, 13, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\udb58\udc2b\uda21\udd53\udbc3\udeb9\ud8d9\ude05\ud9b8\ude5d", "\u80c0\ud245\uc3ce\u5ced\u3411\ub448\u51b3\u0ff7\u9b45\u2537\u85b1\u0842\u9fa1\u8f32\ua159\u2e5c\u72b1", "\udbcb\udc17\ud93f\ude97\udab1\udec2\ud897\udd1f",
        20, 52962, -1150668822, 4176770180412870464L, -15755L, false, true, (char) 26510, (char) 64588,
        Double.longBitsToDouble(0x3fe6211d7a0feed8L), Double.longBitsToDouble(0x3fced61c63ba9c60L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.8071741890710603, 1.1102230246251565E-16) |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\0121=org.apache.commons.math.complex.Complex:(1.2487980056489532, 0.0) |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\012",
        Z.run(T, 2, 3, 10, 1, "\udbc2\udc39\u33a7\uda72\ude7b\u705c\uda9e\udd24\udb3f\udf49\udbc3\udec9\ud8d9\ude05\ud9b8\ude5d", "\uaead\u35a9\uc3ce\u6704\u1011\u5c49\u8209\u102f\u471a\u88a9\u85b1\u0842\u9fa1\u4680\ua1f3\u2e5c\u72b1", "\udbcb\udc17\ud93f\ude97\udab1\udec2\ud897\udd1f",
        20, 70341, -1150634185, -4652536890705182260L, -14396L, false, true, (char) 60301, (char) 64588,
        Double.longBitsToDouble(0x3fe6211d7a0feed8L), Double.longBitsToDouble(0x3fcecfd143ba9c60L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.6996884236894031, -0.0) |this=org.apache.commons.math.complex.Complex:(0.7958350310488241, 0.0)\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 9, 5, 13, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\udb58\udc7a\udbfa\udfbf\ud869\udebb", "\u3fe2\u5fe3\u4cc1\ud245\u7116\u5ced\uadc9\u2ebc\u8209\u102f", "\udbbe\uddfa\ud87b\udeaf\udac6\udcf4\ud911\udee0\ud8ad\udc56\udb48\ude76\udbbd\udfc4\ud839\udee6\ud9da\udf67\ud89a\uddbf\uda33\udf7a\uda8a\udef7",
        9, 75517, 655538758, -4942000132440269223L, 76828L, true, false, (char) 17564, (char) 15097,
        Double.longBitsToDouble(0x3fe9777b06ebb4ffL), Double.longBitsToDouble(0x3fea25fb50dd66b1L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.8598761223269791, -0.0) |this=org.apache.commons.math.complex.Complex:(0.5357693621185389, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.5654186571304506, -0.0) |this=org.apache.commons.math.complex.Complex:(0.5357693621185389, 0.0)\012",
        Z.run(T, 2, 9, 6, 16, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\ud885\uded9\ud9d7\udc3c\uda11\udda1\udbfd\udd4c\ud9a6\udf8d", "\u80c0\ud245\uc3ce\u5ced\u3411\u5c49\u8209\u102f\u9b45\u2537\u85b1\u0842\u9fa1\u8f32\ua159\u2e5c\u72b1", "\udb90\udeb0\ud93f\ude97\udab1\udec2\ucbae",
        1, 53200, -1150668822, 4176770180412870464L, -15755L, false, true, (char) 26510, (char) 46796,
        Double.longBitsToDouble(0x3fe12505ca0feed8L), Double.longBitsToDouble(0x3fced61c63ba9c60L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.240909146018768, 0.6915423759487238) |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\0121=org.apache.commons.math.complex.ComplexField:@? |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\012",
        Z.run(T, 2, 11, 15, 13, "\udbc2\udc39\udaa3\uddb2\uda1f\ude0d\ud888\udc3c\ud8b3\udff7\uda21\uddf6\udbc3\udeb9\ud8d9\ude05\ud9b8\ude5d", "\u80c0\ud245\uc3ce\u5ced\u3411\u5c49\u8209\u3e11\u243b\u34d4\u85b1\ub0dd\uc2ce\u2927\ua159\u2e5c\u72b1", "\u6e80\uda58\ude3a\udab1\udec2\ud897\udd1f",
        20, 52962, -1150668822, 4176770177159370304L, -15755L, false, true, (char) 65166, (char) 64588,
        Double.longBitsToDouble(0x3fe6211d7a0feed8L), Double.longBitsToDouble(0x3fced61c63ba9c60L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 1, 1, 11, 13, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\udb58\udc2b\uda21\udd53\udbc3\udeb9\ud8d9\ude05\ud9b8\ude5d", "\u80c0\ud245\uc3ce\u5ced\u3411\u5c49\u8209\u102f\u9b45\u2537\u85b1\u0842\u9fa1\u8f32\u2e16\u2df9\u72b1", "\udbcb\udc17\ud93f\ude97\udbd5\udd94\udbfc\ude94",
        20, 52962, -1150668822, 4176770180412870464L, -51361L, true, false, (char) 15097, (char) 10895,
        Double.longBitsToDouble(0x3fe75da7fb44bf6aL), Double.longBitsToDouble(0x3fcbacd624bc0c78L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.00119250889507716, -0.0) |this=org.apache.commons.math.complex.Complex:(0.00119250889507716, 0.0)\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 8, 5, 0, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\udb58\udc2b\uda21\udd53\udbc3\udeb9\ud8d9\ude05\udbf4\udfa5", "\u6884\u487f\u4fe8\u5ced\u3411\u5c49\u8209\u102f\u9b45\u2537\u85b1\u0edd\ua6bd\u8f32\ua159\u2e5c", "\ud9df\udf67\udbcb\udc17",
        31, 59589, -546916597, -217990636242845438L, -25849L, false, true, (char) 12976, (char) 40877,
        Double.longBitsToDouble(0x3f5389bead174600L), Double.longBitsToDouble(0x3fe2862b06ebb4ffL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.3156798797341869, 0.6915423759487238) |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 11, 5, 13, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\udb58\udc2b\uda21\udd53\ud873\udeb1\ud8d9\ude05\ud9b8\ude5d", "\u80c0\ud245\uc3ce\u5ced\u3411\u5c49\u8209\u10b9\u9b45\u2537\u88b9\u0842\u9f05\u8e65\u3b94\u129b\u72b1", "\udac4\ude1c\ud86b\udf33\udaa0\udea6\ud897\udd1f",
        20, 52962, -1150668822, 4176770180412870464L, -15755L, false, true, (char) 26510, (char) 64588,
        Double.longBitsToDouble(0x3fe6211d7a0feed8L), Double.longBitsToDouble(0x3fd4341961ddaabcL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.complex.Complex:(0.19214917112563057, 0.0)\0121=java.lang.Boolean:false |this=org.apache.commons.math.complex.Complex:(0.19214917112563057, 0.0)\012",
        Z.run(T, 2, 12, 12, 6, "\udbc2\udc39\udb13\udd89\ud984\ude57\ud9cb\ude6c\ud8a7\udc5c\uda26\udd74\udbc3\udeb9\ud8d9\ude05\ud9b8\ude5d\uda2f\udc5b\udbb8\uddbf\uda38\udf4e\ud8b2\udf90\ud962\udd92\udbc7\udc02\ud94d\udf4e\uda58\uddfc\udb93\udde8\udb2f\uddbd\udbe4\udc18\ud8f7\udd74", "\u9fa1\u7f38\ua159\u2e5c\u72b1\u97b6\ub693\uc3b4\u6461\u3dc1\ucc41\u2162\ua46c\u4ea0\u1b0c\u96e6\u0895\u8d16\030\u7ba2\u1a49\u087e\u8533\ub3aa\u0372\uc26e\u7c4b\ubca0", "\udb82\uddba\udb7a\udd0b\ud855\udeed\ud8ad\udc06\ufa79",
        6, 43199, -1208092249, 8176295083877774206L, 64136L, false, false, (char) 49080, (char) 39370,
        Double.longBitsToDouble(0x3fc8985812f8135cL), Double.longBitsToDouble(0x3feacd46da114812L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.7450525956193365, -0.0) |this=org.apache.commons.math.complex.Complex:(0.7301826358434316, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.6306968908565124, 0.0) |this=org.apache.commons.math.complex.Complex:(0.7301826358434316, 0.0)\012",
        Z.run(T, 2, 9, 7, 1, "\udbc2\udc39\u33a7\ud876\udc9d\ud8db\ude6a\uda63\udf07\uda21\udd53\udbc3\udeb9\ud8d9\ude05\ud9b8\ude5d", "\u80c0\u58b2\u39af\u96e5\u348d\u5c49\u8209\u102f\u180a\u2537\u85b1\u0842\u9fa1\u8f32\ua159\u0f7b\u62e9", "\uda11\udc99\ud93f\ude97\udab1\udec2\ud897\udd1f",
        20, 52962, -1150668822, 4176770176738660160L, -12961L, true, false, (char) 15097, (char) 10895,
        Double.longBitsToDouble(0x3fe75da7f9a1bf6aL), Double.longBitsToDouble(0x3fcbaccf04bc0c78L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math.complex.Complex:(0.8127211085266013, 0.0)\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 14, 5, 13, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\udb58\udc2b", "\u79ad\u30ee", "\uda0d\udd0f\ud8b3\udc13\ud962\udd92\udbc7\udc02\ud94d\udf4e\u1fb4\udb93\udde8\udb2f\uddbd\udbe4\udc18\ud8f7\udd74\udbbe\uddfa\ud87b\udeaf\udac6\udcf4\ud911\udee0\ud9bf\udd3a\udb48\ude93\udbbd\udfc4",
        48, 41144, -1590304338, 5460959932380993125L, 61108L, false, true, (char) 2637, (char) 39363,
        Double.longBitsToDouble(0x3fea01cfb2bc7ff4L), Double.longBitsToDouble(0x3fe7fae57401389bL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(2.046587690228043, 0.0) |this=org.apache.commons.math.complex.Complex:(0.7161738649099506, 0.0)\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 13, 5, 13, "\udbc2\udc39\u33a7\uda14\ude6c\uda72\udf1a\udb58\udc2b\udb37\udf5f\ud92c\udd2d\ud8d9\ude05\ud9b8\ude5d\uda2f\udc5b\udb30\udcfb\uda0d\udd0f", "\u5ced\u3411\u5c49", "\udbe4\udc18\ud8f7\udd74\udbbe\uddfa\udbef\udea9\udac6\udcf4\ud911\udee0\ud9bf\udd3a\udb48\ude93\udbbd\udfc4\ud839\udee6\ud9df\udf67",
        22, 89816, 1547032165, -2348988897805366612L, 18806L, true, false, (char) 18742, (char) 12976,
        Double.longBitsToDouble(0x3fe6eae57401389bL), Double.longBitsToDouble(0x3feab45d1b2e8f88L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.7702633183785633, -0.0) |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\0121=org.apache.commons.math.complex.Complex:(1.2487980056489532, 0.0) |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\012",
        Z.run(T, 2, 9, 10, 5, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\udb58\udc2b\uda21\udd53\udbc3\udeb9\ud8d9\ude05\ud9b8\ude5d", "\u80c0\ud245\uc3ce\u5ced\u3411\u5c49\u8209\u102f\u9b45\u2537\u85b1\u0842\u9fa1\u8f32\ua159\u2e5c\u72b1", "\udbcb\udc17\ud93f\ude97\udab1\udec2\ud897\udd1f",
        20, 52962, -1150668822, 4176770180412870464L, -15755L, false, true, (char) 26510, (char) 64588,
        Double.longBitsToDouble(0x3fe6211d7a0feed8L), Double.longBitsToDouble(0x3fced61c63ba9c60L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(1.205024321008522, 0.0) |this=org.apache.commons.math.complex.Complex:(0.979348701146461, 0.0)\0121=org.apache.commons.math.complex.Complex:(1.519138533893958, 0.0) |this=org.apache.commons.math.complex.Complex:(0.979348701146461, 0.0)\012",
        Z.run(T, 2, 0, 10, 15, "\udbc2\udc39\u33a7\udbbc\udd03\ud9ab\udf45\udba8\udcb3\uda21\udd53\udbc3\udeb9\ud8d9\ude05", "\u9d20\u9ac9\u484d\uc3ce\u5ced\u3411\u5c49\u8209\u102f\u9b45", "\ud87b\udeaf\udac6\udcf4\ud911\udee0\ud9bf\udd3a",
        7, 12887, -583710477, -5791848199714840097L, 20421L, true, true, (char) 43537, (char) 15868,
        Double.longBitsToDouble(0x3fef56d31659bb6aL), Double.longBitsToDouble(0x3fea01cfb25e64a1L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 12, 5, 13, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\udb58\udc2b\uda21\udd53\udbc3\udeb9\ud8d9\ude05\ud9b8\ude5d", "\u80c0\ud245\uc3ce\u5ced\u3411\u5c49\u8209\u102f\u9b45\u2537\u85b1\u0842\u9fa1\u8f32\ua159\u2e5c\u72b1", "\udbcb\udc17\ud93f\ude97\udab1\udec2\ud897\udd1f\ud948\ude7e\ud9e1\udeca\ud8f6\udfdf\ud9ce\uddc3",
        0, 56892, 949699327, -8384844883078107306L, -15755L, false, true, (char) 26510, (char) 64588,
        Double.longBitsToDouble(0x3fe6211d7a0feed8L), Double.longBitsToDouble(0x3fced61c63ba9c60L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(1.1180326927635749, 0.0) |this=org.apache.commons.math.complex.Complex:(0.5168777704099613, 0.0)\0121=org.apache.commons.math.complex.Complex:(1.0, 0.0) |this=org.apache.commons.math.complex.Complex:(0.5168777704099613, 0.0)\012",
        Z.run(T, 2, 16, 0, 13, "\udbc2\udc39\udbad\udf0e\ud839\ude8f\u8ef4\udb58\udc2b\uda21\udd53\udbc3\udee6\ud8d9\uddc6\udbec\udeb6", "\u787b\ud245\uc3ce\u5ced\u3411\u5c49\ua5e6\ub027\u9b45\u1731\u853f\u0842\u2d43\u8e5d\ua159\ub022\u6d30", "\ud9e0\udd58\ud92d\ude65\udab1\udec2\ud897\udd52",
        20, 56546, -26062358, 4176761876656820032L, 22604L, false, false, (char) 49323, (char) 49852,
        Double.longBitsToDouble(0x3fe08a433ffe15f5L), Double.longBitsToDouble(0x3fdd967cf7da3c1aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.6671048281937563, -0.0) |this=org.apache.commons.math.complex.Complex:(0.8404806605315358, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.6989415711815469, -5.551115123125783E-17) |this=org.apache.commons.math.complex.Complex:(0.8404806605315358, 0.0)\012",
        Z.run(T, 2, 9, 7, 11, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a", "\u119c\u79ad\u30ee", "\udac8\udc1d\udaae\udefd\ud9df\udef6\udb2c\udf5a\ud8ba\udd6e\u1fb4\udb93\udde8\udb2f\uddbd\udbe4\udc18\ud8f7\udd74\udbbe\uddfa\ud87b\udeaf\udac6\udcf4\ud911\udee0\ud9bf\udd3a\udb48\ude93\udbbd\udfc4",
        48, 41144, -1590304338, 5460959932380993125L, 61108L, false, true, (char) 2637, (char) 39363,
        Double.longBitsToDouble(0x3feae537b2bce8daL), Double.longBitsToDouble(0x3fe7fae57401389bL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.21793307480284957, 1.1102230246251565E-16) |this=org.apache.commons.math.complex.Complex:(0.21621205133132881, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.21293437070129803, 0.0) |this=org.apache.commons.math.complex.Complex:(0.21621205133132881, 0.0)\012",
        Z.run(T, 2, 6, 7, 5, "\ud914\ude06\u33a7\ud8ed\udd79\uda72\udf1a\udb58\udc2b\uda21\udd53\udbc3\ude40\ud8d9\ude05\ud9b8\ude5d", "\u80c0\ud245\uc3ce\u5ced\u3411\u5c49\u8209\u102f\u9b45\u2537\u15db\u0842\u9fa1\u1488\u95e9\u5a84\u72b5", "\udbcb\udc17\ud93f\ude97\udab1\udec2\udbd0\udfbc",
        13, 52962, -1150668822, 4176770180412870464L, -55089L, false, true, (char) 27626, (char) 61959,
        Double.longBitsToDouble(0x3fcbacd624bc0c78L), Double.longBitsToDouble(0x3fe6211d7a0feed8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Double:0.21621205133132881 |this=org.apache.commons.math.complex.Complex:(0.21621205133132881, 0.0)\0121=org.apache.commons.math.complex.Complex:(1.0, 0.0) |this=org.apache.commons.math.complex.Complex:(0.21621205133132881, 0.0)\012",
        Z.run(T, 2, 2, 16, 15, "\udbc2\udc39\udabb\uddfe\ud8ed\udd65\uda72\udf1a\udb58\udc2b\udb6b\udeb9\udbc3\udea7\uda21\ude09\ud92a\ude56\uda08\uddc7\udb30\udcfb\uda0d\udd0f\ud8a1\udd13\udab2\ude83\udbc7\udc03\ud94d\udf4e\ud95d\udcb9\udb93\udde8", "\u954d\u3547\u0842\ud32f\u8f11\u93bb\u62aa\u5819\u573e\ub693", "\udaf4\uddc4\udb8d\ude17\ud894\udef6\ud9e1\udeca",
        43, 51089, 2146701120, 4516743994995486462L, -69645L, false, true, (char) 27626, (char) 4270,
        Double.longBitsToDouble(0x3fcbacd624bc0c78L), Double.longBitsToDouble(0x3fe5721b0a0feed8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.7347195435730081, 0.1542248714475487) |this=org.apache.commons.math.complex.Complex:(0.1542248714475487, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.3084497428950974, 0.0) |this=org.apache.commons.math.complex.Complex:(0.1542248714475487, 0.0)\012",
        Z.run(T, 2, 11, 4, 5, "\ud8ab\uddb0\uda07\udf42\ud8ed\udd79\uda72\udf1a", "\u8929\u1d2c\u9c16\ua834\u473d\u80c0\u332a\u06fd\u5c5e\u3411\u5c49\u8209\u368a\uaa0a\u2537\u5d30\u0842\u9fa1\u8f32\u9f71\u692b\uc4fc\ua495\u322b\u691e\u63f2\u611c\u18aa\u1716\ua46c\u4ea0\u1b0c\u96e6", "\ud91a\udf1d\udad0\ude93",
        29, 1603, 1993284821, 224657477720865071L, -65711L, true, false, (char) 60945, (char) 50576,
        Double.longBitsToDouble(0x3fc3bda3fd8c6b58L), Double.longBitsToDouble(0x3fe782d28f6c1988L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.ComplexField:@? |this=org.apache.commons.math.complex.Complex:(0.5318649679342055, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.4888134382669839, 0.0) |this=org.apache.commons.math.complex.Complex:(0.5318649679342055, 0.0)\012",
        Z.run(T, 2, 15, 7, 13, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\udb52\ude2b\udb43\udca4\udbc3\ude46\ud8d9\ude05\udb82\udc62", "\u80c0", "\udbc7\udc02\ud94d\udf4e\u1fb4\udb93\udde8\udb2f\uddbd\ud8bf\udfca\ud8d0\udfeb",
        30, 76209, 1779923266, 20647790717327143L, 23651L, true, false, (char) 48279, (char) 21142,
        Double.longBitsToDouble(0x3fe10509ae654bc9L), Double.longBitsToDouble(0x3fe85831ac61df66L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.ComplexField:@? |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 15, 5, 13, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\udb58\udc2b\uda21\udd53\udbc3\udeb9\ud8d9\ude05\ud9b8\ude5d", "\u80c0\ud245\uc3ce\u5ced\u3411\u5c49\u8209\u102f\u9b45\u2537\u85b1\u0842\u9fa1\u8f32\ua159\u2e5c\u72b1", "\udbcb\udc17\ud93f\ude97\udab1\udec2\ud897\udd1f",
        20, 52962, -1150668822, 4165107660577050432L, -15755L, false, true, (char) 26510, (char) 64588,
        Double.longBitsToDouble(0x3fe6211d7a0feed8L), Double.longBitsToDouble(0x3fced61c63ba9c60L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.9719026867134979, -0.0) |this=org.apache.commons.math.complex.Complex:(0.2376126454318298, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.9719026867134979, -0.0) |this=org.apache.commons.math.complex.Complex:(0.2376126454318298, 0.0)\012",
        Z.run(T, 2, 9, 9, 9, "\ud8ed\udda2\uda80\uddb6\ud86a\udd95", "\ub856\u1269\u79ab\u30ee\uccea\u9f0c\u80c0\ud245\uc3ce", "\ud8be\udddc\ud8a6\ude37",
        38, 30794, 353952822, -8587202677694484004L, -26564L, true, true, (char) 39184, (char) 60792,
        Double.longBitsToDouble(0x3fce6a17569f74d4L), Double.longBitsToDouble(0x3fe505c63a207505L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(1.0, -0.0) |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 9, 5, 3, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\ud892\udc68\uda10\udc07\udbc3\udeb9\ud8d9\ude05\ud9b8\ude5d", "\u80c0\ua703\ua341\u5ced\u3411\u5c49\u8209\u102f\u9b45\u9119\u34ce\u0819\u9fa1\u8f32\ua159\u2e5c\u72b1", "\udbcb\udc17",
        31, 4805, 46859, -217990636242845438L, -25849L, false, true, (char) 32944, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe9700006ebb4ffL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(1.0, -0.0) |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\0121=org.apache.commons.math.complex.Complex:(NaN, NaN) |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\012",
        Z.run(T, 2, 9, 16, 3, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\udb58\udc2b\uda21\udd53\udbc3\udeb9\ud8d9\ude05\ud9b8\ude5d", "\u80c0\ud245\uc3ce\u5ced\u3411\ub448\u51b3\u0ff7\u9b45\u2537\u00e1\u5639\u9fa1\u8f32\ua159\u2e5c\u72b1", "\udbcb\udc17\ud93f\ude97\udab1\udec2\ud897\udd1f",
        20, 52962, -1150668822, 4176770180412870464L, -15755L, false, true, (char) 26510, (char) 30,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fced61c63ba9c60L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.3121011807885044, -0.0) |this=org.apache.commons.math.complex.Complex:(0.307058986561629, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.29792028123127895, 0.0) |this=org.apache.commons.math.complex.Complex:(0.307058986561629, 0.0)\012",
        Z.run(T, 2, 6, 7, 2, "\udbc2\udc39\udbdf\udfa6\ud8ed\udd79\u049a\uda69\udc90\uda4c\udcc2\udbe4\udc81\uda1f\udfd1\ud9b8\ude5d\uda2f\udc5b\udb34\udf6e\uda0d\udd0f\uda5d\udeb0\ud80a\udf7b\udba1\udf62\ud97f\udc45\uda8c\uddf7\ud900\udcbb\ud9ba\udc5e\ud9be\ude2c\ud9ee\udf84\udbf3\udcd8\uda0f\udef9\ud95e\udcdf", "\u2e4b\u72b1\u97b6\ub693\uc3b4\u8a1c\ua31f\ub4ac\u1716\ua46c\u4ea0\u9b1b\u21af\u299f\u40a3\uca18\u7ba2\ua367\u5ed3\u850d\uac8e\u037b\ub56e", "\ud852\udd24\uda88\ude8f\ud866\uddea",
        52, 79282, 1710379795, -5677781768255860379L, -22489L, true, true, (char) 57578, (char) 56366,
        Double.longBitsToDouble(0x3fd3a6dabc4e680aL), Double.longBitsToDouble(0x3fe9dd168c41737fL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.3913528977076821, 1.1102230246251565E-16) |this=org.apache.commons.math.complex.Complex:(0.38143937415284135, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.3644041628468004, -5.551115123125783E-17) |this=org.apache.commons.math.complex.Complex:(0.38143937415284135, 0.0)\012",
        Z.run(T, 2, 6, 7, 13, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\udb58\udc2b\uda21\udd53\udbc3\udeb9\u9d64\uda6a\udde6", "\u5f45\u0c44\u5818\u90ff\u9441\ub448\u564c\u0ff7\u9b45\u2537", "\udac6\udcf4\ud911\udee0\ud9bf\udd3a\udb48\ude93\udbbd\udfc4\ud839\udee6\u2161\udbcb\udc17\ud93f\ude97\udab1\udec2\ud897\udd1f\ud948\ude7e\ud9e1\udeca\ud89c\uddf1\ud8e8\ude03\ud986\ude77\ud8ed\udce3\udbfd\ude54\u19c2\ud8b7\ude39\ud9b7\udec2\ucb90\ud904\udd51\u790c\ud974\udf49\ud88d\uddc1\ud8d0\udd06\udaea\udfea",
        45, 2995, 136704563, 7416321873435347658L, 47252L, false, false, (char) 16228, (char) 27044,
        Double.longBitsToDouble(0x3fd86980b159298eL), Double.longBitsToDouble(0x3fcae40bda671dbcL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.8171364383117262, 0.7958350310488241) |this=org.apache.commons.math.complex.Complex:(0.7958350310488241, 0.0)\0121=org.apache.commons.math.complex.Complex:(1.0, 0.0) |this=org.apache.commons.math.complex.Complex:(0.7958350310488241, 0.0)\012",
        Z.run(T, 2, 11, 16, 13, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\udb37\ude9b\ud96a\udf81\udbc3\udeb9\ud8d9\ude05\ud909\udea5", "\u80c0\u7b41\uc44c\u5552\ucb2a\ub448\u51b3\u0ff7\u9b45\u2537\u85b1\u5651\u9107\u4090\u6a0e\u39a5\u53d6", "\uda46\udf61\ud93f\udf4c\ud997\udcd4",
        54, 20166, -1807892506, -4942085018173907367L, 94474L, true, false, (char) 17564, (char) 15070,
        Double.longBitsToDouble(0x3fe9777b06ebb4ffL), Double.longBitsToDouble(0x3fea25fb50dd66b1L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.8071741890710603, 1.1102230246251565E-16) |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.6050271244264964, 0.0) |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\012",
        Z.run(T, 2, 3, 7, 1, "\uda63\udd7a\ud918\udd45\uda72\udedd\u705c\uda9e\udd24\udb3f\udf49\uda75\udf42\ud8d9\ude05\ud9b8\ude5d", "\uaead\u35a9\ua553\u8e8f\u7296\u9949\u819e\u102f\u471a\u88a9\u870e\u0842\u9fa1\ucf8a\ua1f3\u2e5c\u72b1", "\udbcb\udc17\ud93f\ude97\udab1\udec2\ud897\udd1f",
        20, 68565, -1150634185, -4652536890705182260L, -14396L, false, true, (char) 60301, (char) 64588,
        Double.longBitsToDouble(0x3fe6211d7a0feed8L), Double.longBitsToDouble(0x3fcecfd143ba9c60L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(1.161023782451315, 0.0) |this=org.apache.commons.math.complex.Complex:(0.5601407231135219, 0.0)\0121=org.apache.commons.math.complex.Complex:(1.161023782451315, 0.0) |this=org.apache.commons.math.complex.Complex:(0.5601407231135219, 0.0)\012",
        Z.run(T, 2, 10, 10, 0, "\udbc2\udc39\u33a7\uda72\ude7b\ud8ca\uddb3\uda9e\udd24\udb3f\udf49\udbc3\udec9\ud8d9\ude05\ud9b8\ude5d", "\uaead\u35a9\ubf73\u4cd4\u1011\u5c49\u8209\u102f\u471a\u88a9\u85b1\u0842\u9fa1\u4680\ua1f3\u2e5c\u72b1", "\udaa0\udf4f\ud937\udd92\udab1\udec2\ud897\udd1f\ud948\ude7e",
        -4, 57815, -1083253159, 2098116453641138876L, 99681L, false, false, (char) 10895, (char) 25266,
        Double.longBitsToDouble(0x3fe1ecac3cddc593L), Double.longBitsToDouble(0x3fd2f031ed88475eL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.8071741890710603, 1.1102230246251565E-16) |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.7636221377238364, 1.1102230246251565E-16) |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\012",
        Z.run(T, 2, 3, 6, 13, "\udbc2\udc39\u33a7\udb0b\udc02\udb03\udf9b\ud85f\udf68\ud892\udeee\udbe8\udf29\ud8d9\ude05\ud9b8\ude5d", "\uaf5c\u3645\uc3ce\u6704\u1011\u5c49\u8209\u258a\u7f15\u88a9\u31e4\u1791\u9fa1\u2e81\ua1f3\u5222\u72b1", "\udbcb\udc17\ud93f\ude97\udab1\udec2\ud897\udd1f\ud948\ude7e\ud989\udc6d\ud918\udf2c\udb9a\ude8a",
        55, 26512, 1404783077, -8384844883078107306L, -14396L, false, true, (char) 60301, (char) 64588,
        Double.longBitsToDouble(0x3fe6211d7a0feed8L), Double.longBitsToDouble(0x3fcecfd143ba0bccL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(1.5707963267948966, -0.0) |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\0121=org.apache.commons.math.complex.Complex:(1.0, 0.0) |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\012",
        Z.run(T, 2, 3, 10, 1, "\udbc1\udc39\u33a7\uda72\ude7b\u705c\uda9e\udd24\udb3f\udf49\udbc3\udec9\ud8d9\ude05\ud9b8\ude5d", "\u5e85", "\ud8a2\uddaf\ud944\udf4e\u1fb4\udb93\udde8\udb2f\uddbd\ud81c\udc55\ud8da\udce7",
        30, 76209, 1052802370, -7317471039305285439L, 89187L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe8580002acdf66L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.6050271244264964, 0.0) |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.6050271244264964, 0.0) |this=org.apache.commons.math.complex.Complex:(0.6915423759487238, 0.0)\012",
        Z.run(T, 2, 7, 7, 1, "\udbc2\udc39\u33a7\uda72\ude7b\u705c\uda9e\udd24\udb3f\udf49\udbc3\udec9\ud8d9\ude05\ud9b8\ude5d", "\uaead\u35a9\uc3ce\u6704\u1011\u5c49\u8209\u102f\u471a\u88a9\u85b1\u0842\u9fa1\u4680\ua1f3\u2e5c\u72b1", "\udbcb\udc17\ud93f\ude97\udab1\udec2\udb87\udd97",
        15, 70341, -1403406537, 2560539629826474444L, -14396L, false, true, (char) 60301, (char) 64588,
        Double.longBitsToDouble(0x3fe6211d7a0feed8L), Double.longBitsToDouble(0x3fcecfd143ba9c60L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(1.196687437738357, -0.0) |this=org.apache.commons.math.complex.Complex:(0.3654431982463282, 0.0)\0121=java.lang.Boolean:false |this=org.apache.commons.math.complex.Complex:(0.3654431982463282, 0.0)\012",
        Z.run(T, 2, 3, 12, 13, "\udbc2\udc39\u33a7\uda72\ude7b\u705c\uda9e\udd24\udb3f\udf49\udbf4\udc02\udba1\udc06\ud9b8\ude5d\uda2f\udc5b\udaf7\udede\ud913\udef2\ud88b\udf77\ud962\udd92\ud8a2\uddaf\ud944\udf4e", "\u307a\uaa11\u9824\ucb2b\u870a\u9fa1\u4680\ua1f3\u2e5c\u72b1\u70b6\ub69d\u8955\u63f2\u7143", "\ud9b1\udf0e\ud918\udf2c\udb9a\ude8a\ud8f0\udf83\ud8dc\udc32\udbfd\ude54\ud9cb\udd25",
        55, 16414, 345158044, -4740993258725931780L, -81884L, true, false, (char) 26496, (char) 56069,
        Double.longBitsToDouble(0x3fd7636bde40df38L), Double.longBitsToDouble(0x3fb2c96c7f769190L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(1.1559664916192256, 1.1102230246251565E-16) |this=org.apache.commons.math.complex.Complex:(0.40303420394106326, 0.0)\0121=org.apache.commons.math.complex.Complex:(1.1559664916192256, 1.1102230246251565E-16) |this=org.apache.commons.math.complex.Complex:(0.40303420394106326, 0.0)\012",
        Z.run(T, 2, 3, 3, 5, "\udbc2\udceb\u33a7\uda72\ude7b\u705c\uda9e\udd24\udb3f\udf49\udbc3\udec9\ud8d9\ude05\ud9b8\ude5d\uda2f\udc5b\udaf7\udede\ud913\udef2\ud88b\udf77\ud962\udd92", "\u5c49\u0925\u71bf\u200d\u8898\u85b1\u6b41\u9fa1\u9931\u2f8c\u2e5c\u72b1", "\udbcb\udc17\ud93f\ude97\udab1\udec2\ud897\udd1f",
        20, 70341, -1150634185, -4652536890705182260L, -99940L, true, true, (char) 11667, (char) 10895,
        Double.longBitsToDouble(0x3fd9cb4ff9462924L), Double.longBitsToDouble(0x3fcbacd624bc0c78L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.22608807448612878, -0.0) |this=org.apache.commons.math.complex.Complex:(0.22608807448612878, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.22608807448612878, -0.0) |this=org.apache.commons.math.complex.Complex:(0.22608807448612878, 0.0)\012",
        Z.run(T, 2, 8, 8, 8, "\udbc2\udc39\u33a7", "\uced2\u0714\u59b4\u237f\u376b\u3fe2\u5fe3\u4cc1\u3141\u11fc\u3a29\u4a88\u2e7c\u8209\u102f\u9996\u5e36\u85b1\uccb3\u9f85\u8f32\ud686\u2e3f\u5fca\u0c7d\ua293\uc132\u1b80\u09d0\ub44a\uafc5\u4095\u9bc6\u1b0c", "\ud945\udd8d\ud849\udccd\uda69\udec6",
        10, 1603, 1722915652, -7239816928759441335L, -66769L, true, false, (char) 31468, (char) 33979,
        Double.longBitsToDouble(0x3fccf0743af77e14L), Double.longBitsToDouble(0x3fef0ef516f9a083L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.9984017527012945, -0.0) |this=org.apache.commons.math.complex.Complex:(0.05654508312223605, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.05657525892945732, -0.0) |this=org.apache.commons.math.complex.Complex:(0.05654508312223605, 0.0)\012",
        Z.run(T, 2, 9, 6, 16, "\udbc2\udc39\ud8f1\udcde\udbcb\udd51\uda72\udfe0\ud885\uded9\ud9d7\udc3c\uda11\udda1\udbfd\udd4c\ud9a6\udf8d", "\u80c0\u439a\u7dd9\u5d04\u3411\u5c49\u8209\u102f\u49db\u2537", "\uda07\udcf0\ud911\ude1d\ud9bf\udd3a\udb48\ude93\udbbd\udfc4\ud839\udee6\udbd0\udf40\udb90\udeb0\ud93f\ude97\udab1\udec2\ucbae\udb32\udd40\ud9e1\udfb8\ud8f6\udfdf\ud9ce\uddc3\ud95b\udeca\ud8dc\udc32\udbfd\ude54\ud9cb\udd25\ud8b7\ude5b\udbdb\udf20\ud9d1\udc73\ud904\uddfc\ud96a\ude92\uda4c\udff0\ud88d\udd21\ud9cb\udd65\udafe\udfb8",
        18, 31884, 1807957971, 962208027638799154L, -23598L, true, false, (char) 20492, (char) 4655,
        Double.longBitsToDouble(0x3facf37a2584eb00L), Double.longBitsToDouble(0x3fe2bc64b7d0cb38L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(1.0, -0.0) |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.0, -0.0) |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\012",
        Z.run(T, 2, 9, 6, 16, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\ud885\uded9\ud9d7\udc3c\uda11\udda1\udbfd\udd4c\ud9a6\udf8d", "\u80c0\ud245\uc3ce\u5ced\u3411\u5c49\u8209\u102f\u650c\u2537\u50e3\u0842\u9fa1\u8f32\ua159\u2e5c\u6be0", "\udb90\udeb0",
        31, 59589, -973031669, -3772625503079218704L, -25849L, false, true, (char) 12976, (char) 23726,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(1.1171769527841566, 0.0) |this=org.apache.commons.math.complex.Complex:(0.7610424049109648, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.8649185122963383, -0.0) |this=org.apache.commons.math.complex.Complex:(0.7610424049109648, 0.0)\012",
        Z.run(T, 2, 4, 6, 16, "\ud80c\udc59\u43fc\ud81e\ude32\udb06\ude71\ud885\ude96\ud967\udf20\udade\udebc", "\uccea\u9f0c\u80c0\ud245\uc3ce\u428e", "\udb60\udee3\uda91\udc3b\uda95\ude7f\ud880\udf5b\ud892\ude14\ud871\udfef",
        30, 75962, 511750119, 753831340930687747L, -85472L, true, true, (char) 32210, (char) 50726,
        Double.longBitsToDouble(0x3fe85a7599fec6eeL), Double.longBitsToDouble(0x3fd6cae88f05d4aeL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.0011925091777173452, -2.2204460492503128E-16) |this=org.apache.commons.math.complex.Complex:(0.00119250889507716, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.0011925091777173452, -2.2204460492503128E-16) |this=org.apache.commons.math.complex.Complex:(0.00119250889507716, 0.0)\012",
        Z.run(T, 2, 6, 6, 16, "\udbc2\udc39\u33a7\ud8ed\udd79\uda72\udf1a\ud885\uded9\ud9d7\udc3c\uda11\udda1\udbfd\udd4c\ud9a6\udf46", "\u80c0\ud245\uc3ce\u5ced\u3411\u5c49\u8209\u102f\u9b45\u2537\u4649\u0842\u9fa1\u8f32\ua159\u2e5c\ubb48", "\udb90\udeb0",
        31, 59589, -957434101, -3772625503079218704L, 87993L, false, true, (char) 12976, (char) 40877,
        Double.longBitsToDouble(0x3f5389bead174600L), Double.longBitsToDouble(0x3fe9777b06ebb4ffL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.ComplexField:@? |this=org.apache.commons.math.complex.Complex:(0.5357693621185389, 0.0)\0121=org.apache.commons.math.complex.ComplexField:@? |this=org.apache.commons.math.complex.Complex:(0.5357693621185389, 0.0)\012",
        Z.run(T, 2, 15, 15, 16, "\udbc2\udc39\u33a7\ud8ed\udd79\ud969\udfbf\udb25\udf74\ud9d7\udc3c\uda11\udda1\udbfd\udd4c\ud9a6\udf8d", "\u80c0\ud245\u1566\u3945\u59ac\u5c33\u8209\u102f\u9b45\u2537\u85b1\u0842\uc412\u75d5\ua159\u2e5c\u72b1", "\udb90\udeb0\ud93f\ude97\udab1\udec2\ucbae",
        1, 53200, -1150669000, 4176770180412870464L, -15755L, false, true, (char) 26510, (char) 46796,
        Double.longBitsToDouble(0x3fe12505ca0feed8L), Double.longBitsToDouble(0x3fced61c63ba9c60L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.2529181538473717, 0.7607658704282414) |this=org.apache.commons.math.complex.Complex:(0.7607658704282414, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.7607658704282414, 0.2529181538473717) |this=org.apache.commons.math.complex.Complex:(0.7607658704282414, 0.0)\012",
        Z.run(T, 2, 11, 11, 4, "\ubbba\udaa3\udd2e\uda1f\ude0d\ud888\udc3c\ud8b3\udff7\uda21\uddf6\udbc3\udeb9\ud8d9\ude05\ud9b8\ude5d\uda2f\udc5b", "\u9045\uc3ce\u5ced", "\udb93\udde8\ud924\udfbc\ub4c8\ud839\udda8\udb60\uddeb\uda1c\udf0d",
        44, 887, 1729793662, 753844921617277699L, 71630L, false, true, (char) 30672, (char) 8720,
        Double.longBitsToDouble(0x3fe85831aaacdf66L), Double.longBitsToDouble(0x3fd02fcf9fd5b4c4L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math.complex.Complex:(0.07086387076140943, 0.0)\0121=java.lang.Double:0.0 |this=org.apache.commons.math.complex.Complex:(0.07086387076140943, 0.0)\012",
        Z.run(T, 2, 14, 14, 4, "\u1e7e\udbbf\udd6f\ud9e0\udc6d\ud8db\ude6a\uda7a\ude72\uda55\ude40\udbc3\udeb9\ud8d9\ude05\ud9b8\ude5d", "\u8d63\u6770\u39af\u9052\ud127\u6536\u8209\u4454\ucce4\u4103\ub78e\u0841\u9fa1\u8cea\uc2e3\u42d5\u7720\u97b6\u1d1e\u2c68\u63f2\u3dc1\u1868\u1716", "\ud9ce\uddc3\ud988\udde2\ud8d2\udfc3\udaf9\udfb1\ud9cb\ude15\ud8b7\ude5b\ud9b7\udec2\uda90\udf1c\udba5\udfaa",
        49, 7351, 1751002054, -7333891820778922866L, -88088L, true, false, (char) 34471, (char) 47042,
        Double.longBitsToDouble(0x3fb22422776362a8L), Double.longBitsToDouble(0x3fe11f6b39f71587L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(1.2304280556029419, 0.0) |this=org.apache.commons.math.complex.Complex:(0.20736212152727618, 0.0)\0121=org.apache.commons.math.complex.Complex:(1.2304280556029419, 0.0) |this=org.apache.commons.math.complex.Complex:(0.20736212152727618, 0.0)\012",
        Z.run(T, 2, 13, 13, 15, "\udbc2\udc01\u33a7\uda14\ude6c\ud80c\udd86\udb58\udc2b\udb37\udf5f\ud92c\udd2d\ud8d9\ude05\ud9b8\ude5d\uda2f\udc5b\ud9c8\udfa6", "\uc3ce\u5ced\u3411\u87a8\u8209\u102f\u9b45\u2537\u85b1\u9fd9\u9fa1\u8f32\ua159\u2e5c\u72b1\u97b6\ub693\u8955\u63f2\uabae\u1868\u1716\ua46c", "\udb99\udec9\ud8dc\udc32\udbfd\ude32\ud9cb\udd25\ud8ed\udcb5\ua69b\udb29\udc25\udb0c\udec6\ud8e6\udf70\udbb0\udff2\uda82\ude98\u8a3f\ud902\udd69\uda13\ude88\ud96e\udfe1\ufb75\ud9fc\udc62\ud99a\udcd3\ud865\udd68",
        44, 81189, -686029256, 4461176737311663888L, -1272L, true, false, (char) 48855, (char) 22043,
        Double.longBitsToDouble(0x3fca8ad78d31c524L), Double.longBitsToDouble(0x3febbb06568dd383L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.8889444150205568, 0.0) |this=org.apache.commons.math.complex.Complex:(0.1542248714475487, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.3084497428950974, 0.0) |this=org.apache.commons.math.complex.Complex:(0.1542248714475487, 0.0)\012",
        Z.run(T, 2, 4, 4, 5, "\ud8ab\uddb0\uda07\udf42\ud8ed\udd79\uda72\udf1a", "\u8929\u1d2c\u9c16\ua834\u473d\u80c0\u332a\u06fd\u5c5e\u3411\u3282\u8209\u368a\uaa0a\u2537\u5d30\u51da\u9f98\u8f32\u9f71\u692b\uc4fc\ua495\u322b\u691e\u63f2\u611c\u18aa\u80af\u8d4c\u4ea0\u1b0c\u96e6", "\ud91a\udf1d\udad0\ude93",
        29, 1603, 1993284821, 159699206956851734L, -65711L, true, false, (char) 60945, (char) 50576,
        Double.longBitsToDouble(0x3fc3bda3fd8c6b58L), Double.longBitsToDouble(0x3fe782d28f6c1988L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(1.0, -0.0) |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\0121=java.lang.Double:0.0 |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\012",
        Z.run(T, 2, 9, 2, 13, "\udbc1\udcf8\udb56\udf2d\udb77\udcef\uda72\udef8", "\u10f4\u79ad\u30ee", "\ud9f0\udd62\udae0\udd04\ud918\udc13\ud8e5\uddb1\ud94d\udf43\ud8ae\udf10\udba0\udee0\udb2f\uddbd\udbe4\udc18\ud959\udd92\udb22\udfec\ud87b\ude86\udac6\udcf4\ud911\udee0\ud9bf\udd3a\udb48\ude93\udbbd\udfc4",
        15, 41144, -1590304338, 5461027685490032741L, 43338L, true, false, (char) 18742, (char) 32944,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e39700000000000L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\0121=java.lang.Double:0.0 |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\012",
        Z.run(T, 2, 2, 2, 3, "\udbc2\udc39\ud940\udda5\ud8ed\uddec\udaf1\udd39\uda3d\udfe7\uda28\udc05\u7067\ud84e\udee2\udb44\udd86", "\u89b3\ua703\ua341\u5ced\u3411\u5c49\u8209\u102f\u9b45\u9119\u348e\u0819\uc542\u6a3b\uaac1\uacfc\u7d5e", "\udb59\udfec",
        50, 23381, 46859, -217990634714480382L, -25849L, false, true, (char) 32944, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc0c00011037d08L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.8821584305089334, -0.0) |this=org.apache.commons.math.complex.Complex:(0.49037050138991567, 0.0)\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 9, 5, 13, "\udbc2\udc39\u33a7\udab5\udfc1\udb38\ude62\udb58\udc2b\uda21\udd53\udbc3\udeb9\ud8d9\ude05\ud9b8\ude5d", "\u03e1\u4367\uc3ce\u5ced\u3411\u4365\u819e\u102f\u9b45\u2537\u85b1\u0842\u9fa1\u46ff\ua19d\u2e5c\u72b1", "\ud80f\udc19\ud93f\ude97\udab1\udec2\udbd7\uddfe",
        20, 52962, -1150668822, 4176770180412870464L, -15755L, false, true, (char) 26510, (char) 64588,
        Double.longBitsToDouble(0x3fdf623af49923ceL), Double.longBitsToDouble(0x3fced61c63ba9c60L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(1.5707963267948966, -0.0) |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\0121=org.apache.commons.math.complex.Complex:(1.5707963267948966, -0.0) |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\012",
        Z.run(T, 2, 3, 3, 5, "\udbc1\udc39\u33a7\ue715\ud85f\ude58\ud9c2\udfdc\udb3f\udf49\udbc3\udec9\ud8d9\ude05\ud9b8\ude47", "\u5e85", "\ud8a2\uddaf\ud944\udf4e\u1fb4\udb93\udde8\udb37\udeaa\ud81c\udc55\ud8da\udce7",
        30, 76209, 1052802370, -7317471039305285439L, 89187L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe8580002acdf66L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(NaN, NaN) |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\0121=org.apache.commons.math.complex.Complex:(NaN, NaN) |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\012",
        Z.run(T, 2, 0, 0, 15, "\udbc1\udcf8\udb56\udf2d\udb77\udcef\udb2e\udf16", "\u2515\u78bb\u30ee", "\ud9f0\udd62\udae0\udd04\ud918\udc13\ud8ca\udce4\ud8f3\udd55\ud8ae\udf10\udba0\udee0\udb2f\uddbd\udbe4\udc18\u61f3\udb22\udf0b\ud87b\ude86\udac6\udcf4\ud911\udee0\ud9bf\udd3a\udb48\udd9d\udbbd\udfc4",
        15, 41144, -1590304338, 5461027685490032741L, 43338L, true, false, (char) 14902, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:(0.0, -0.0) |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\0121=org.apache.commons.math.complex.Complex:(0.0, -0.0) |this=org.apache.commons.math.complex.Complex:(0.0, 0.0)\012",
        Z.run(T, 2, 6, 6, 6, "\udbc1\udcf8\udb56\udf2d\udb77\udcef\uda72\udef8\ud892\udc68\uda02\udf41\udbc3\ude4e\ud836\udd13\ud891\udf9a", "\uc5ee\u249b\ud1ee\uaebb\u3406\ucc76\ub701\u102f\u9b45\ubacd\u34ce\u0819\u9fa1\u8f32\ua159\u2e5c\u72b1", "\udbcb\udc17",
        11, 4805, 46859, -2108939529085086423L, -25849L, false, true, (char) 32944, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe9700002dc0c6bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.complex.Complex|divide|double|new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|divide|org.apache.commons.math.complex.Complex|new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|abs||new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|acos||new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|add|double|new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|add|org.apache.commons.math.complex.Complex|new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|asin||new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|atan||new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|conjugate||new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|cos||new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|cosh||new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|createComplex|double,double|new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|equals|java.lang.Object|new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|exp||new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|getArgument||new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|getField||new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|divide|double|new:org.apache.commons.math.complex.Complex:double",
    "M|org.apache.commons.math.complex.Complex|divide|org.apache.commons.math.complex.Complex|new:org.apache.commons.math.complex.Complex:double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
