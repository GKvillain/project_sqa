package org.apache.commons.math.linear;
import org.junit.Test;
import static org.junit.Assert.*;
public class EigenDecompositionImpl_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 8, 17, "\ud80e\ude8e\u5a75\udac2\udd47\ud8c7\udcec\ud95e\udcca\udb63\udfa9\udb9b\udedf\ud98c\udea3\uda4d\udf36\ud912\udeb2\uda2c\udd2e\uda37\udddc\udaf7\uddc0\ud8cf\udf0d\ud830\udedf\udad0\udcca\ud851\uddab\ud830\udcdf", "\u6d94\u0320\u7ea5\ud466\u7738\u1b94\u68ce\u7d22\uc46f\u1f23", "\ud929\udc99\ud82f\ude6c\ud9ef\ude15\uda81\udee8\ud93e\udddd\ud8ac\udd08\ud8ab\udc53\ud9a3\ude0d\udb6d\udde6\udbac\udfea\ud82b\udee7",
        55, 85941, -1213443983, -6440083080305628801L, 46506L, true, false, (char) 13226, (char) 61394,
        Double.longBitsToDouble(0x3fe309937ee537d0L), Double.longBitsToDouble(0x3fe598cd21c1e15fL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 8, 17, "\ud80e\ude8e\u5a75\udac2\udc9e\uda71\udcdfd\udb63\udfa9\udb9b\udedf\ud98c\udea3\uda4d\udeda\ud912\udeb2\000\uda37\uddbb\udaf7\uddc0\ud8cf\udf0d\u00a4\uda31\udc05\000\000", "\u6cb9", "\u29a5\udad2\ude99\ud839\udc43\udbfe\udd28\udb14\udf27\ud94b\udf60",
        16, 84798, -1173247819, 173525427608377825L, -35704L, true, true, (char) 7363, (char) 188,
        Double.longBitsToDouble(0x3fe62b3004117b95L), Double.longBitsToDouble(0x3e33f00000000000L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 8, 17, "\ud80e\ude34\ud8a3\udca1\udbc1\ude01\udb8d\udc97\ud95e\udd62\udb63\udfa9\udb9b\udedf\ud98c\udea3\udb93\udef9\ud912\udeb2", "\u7f02\u9d2e\u15a7\u592c\ud0f8\uab77", "\ud83e\udc20\ud9c1\udc39\uda21\udf64\u24a5\ud863\ude9c\ud839\udc43\ud803\udfac\uda5d\uddeb\udb0f\udd1b\ud950\udc7f",
        6, 65510, 48967688, 5555288965109503898L, -25501L, true, false, (char) 43022, (char) 42339,
        Double.longBitsToDouble(0x3f917b95cc92eca0L), Double.longBitsToDouble(0x3fe3f2ee4faeccd7L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 13, "\uda78\udd9a\ud9f9\udd8a\uda7d\udcaa\uda0a\udd30\udbb9\udf5c\ud8df\udc06\udb9b\ude7f\ud98c\udea3\udb3c\udcee\ud912\udeb2\uda2c\udd2e\uda37\udddc\udaf7\uddc0\ud8c8\udf8a\ud92f\udf11\udad0\udcca\ud851\uddab\ud830\udcdf", "\u6d94\u0320\u7ea5\ud466\u7738\uca0a\u461e\u1a9f\uc46f\u1f23\u3762\u05d3\u8f4f", "\udbdc\ude09\ud93e\udddd\ud8ac\udd08\ud8ab\udc53",
        46, 90545, 1573484132, -789437811291584410L, -79407L, true, false, (char) 53279, (char) 16238,
        Double.longBitsToDouble(0x3fc9ded3adfad7bcL), Double.longBitsToDouble(0x3fc6424da3fdff84L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 8, 17, "\ud80e\ude8e\u5a75\udac2\udd47\ud8c7\udcec\ud95e\udcca\udb63\udfa9\udb9b\udedf\ud98c\udea3\uda4d\udf36\ud912\udeb2\udba0\udd28\uda37\udddc\udaf7\uddc0\ud8cf\udf0d\ud830\udedf\udad0\udcca\ud851\uddab\ud830\udcdf", "\u6d94\u0320\u7ea5\ud466\u7738\u1b94\u68ce\u7d22\uc46f\u1f23", "\ud929\udc99\ud82f\ude6c\ud9ef\ude15\uda81\udee8\ud93e\udddd\ud8ac\udd08\ud8ab\udc53\ud9a3\ude0d\udb6d\udde6\udbac\udfea\ud82b\udee7",
        55, 85941, -1213443983, -6440083080305628801L, 46506L, true, false, (char) 13226, (char) 61394,
        Double.longBitsToDouble(0x3fe309937ee537d0L), Double.longBitsToDouble(0x3fe598cd21c1e15fL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 17, 17, "\ud925\udf01\u0607\udac2\udd47\ud8c7\udcec\udb7f\udd0e\ud9d4\uddaa\ud9f1\ude33\udb96\udd84\udb27\udf63\udb78\udc1c\uc3cb\udbd4\udcf7\ud865\udff0\udacf\udefd\udbde\udd76\udad0\udd02\ud851\uddae\udb2d\udce0", "\u2035\u02dd\u4988\uc096\u182a\u19e6\u3374\u5cb2\u5140\u8f5e\u72f9\u2bcd\uc191\uaea1\uade0", "\udab6\udd5a\ud8bc\udf63\ud90f\udd03\udbf0\udf66\udb36\ude74\uda91\udd49\ud81a\uddfa\udb51\udc5a\ud9dc\ude54\udaa8\udd6d\udaed\udcef\udb6b\udd10\ud9d5\udc5e\udbb6\udeb3\ud8fc\ude3f\udbbc\udf1d\udad0\ude60\ud9e4\udecb\ud80e\uddab\udb62\udc67\udbb6\udce4\ud8d0\ude05\ud843\udf9b\ud833\udcb4",
        15, 83979, 1493995019, 7770809443780429652L, -871L, false, false, (char) 12968, (char) 4747,
        Double.longBitsToDouble(0x3fe7f2f7656c7a38L), Double.longBitsToDouble(0x3fbf641fe0b4b4e0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 8, 17, "\ud80e\ude8e\u5a75\udac2\udd47\ud8c7\udcec\ud95e\udcca\udb63\udfa9\udb9b\udedf\ud98c\udea3\uda4d\udf36\ud912\udeb2\uda2c\udd2e\uda37\udddc\udaf7\uddc0\ud8cf\udf0d\ud830\udefd\udad0\udcca\ud851\uddab\ud830\udcdf", "\u6d94\u0320\u7ea5\ud466\u7738\u1b94\u68ce\u7d22\uc46f\u1f23", "\ud929\udc99\ud82f\ude6c\ud9ef\ude15\uda81\udee8\ud93e\udddd\ud8ac\udd08\ud8ab\udc53\ud9a3\ude0d\udb6d\udde6\udbac\udfea\ud82b\udee7",
        55, 85941, -1213443983, -6440083080305628801L, 46506L, true, false, (char) 1917, (char) 61370,
        Double.longBitsToDouble(0x3fe309937ee537d0L), Double.longBitsToDouble(0x3fe598cd21c1e15fL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|computeGershgorinCircles||new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|computeShiftIncrement|int,int,int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|processGeneralBlock|int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|computeSplits||new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|countEigenValues|double,int,int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|decompose||new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|dqd|int,int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|dqds|int,int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|eigenvaluesRange|int,int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|findEigenVectors||new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|findEigenvalues||new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|findEigenvector|double,[D,[D|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|flipIfWarranted|int,int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|getD||new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|getDeterminant||new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|getEigenvector|int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|computeGershgorinCircles||new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|computeShiftIncrement|int,int,int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|processGeneralBlock|int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
