package org.apache.commons.math3.geometry.euclidean.threed;
import org.junit.Test;
import static org.junit.Assert.*;
public class SubLine_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.SubLine:@?\012",
        Z.run(T, 1, 14, 8, 4, "\ud9cc\udfdc\uda15\udea9\udbdb\udc67\udb7d\udebc\u9bef\ud930\udfe4", "\u658b\u94f5\u52f0\uab96\u2fc5\u2e84\u63fd\ubbeb", "\ud9e7\udc8b\ud96d\ude5f\udb11\udee3\ud852\udde3\ud9b2\udde4\udb28\udf25\ud9e1\ude81\udab2\udeef\u9258\ud9c9\udeef\udbe5\udf75\ud9b0\udc0e\udbe6\udc6b",
        19, 89375, -1258495751, 8302242172015921889L, 91974L, false, false, (char) 2693, (char) 60988,
        Double.longBitsToDouble(0x3fe3794eb5f7ba52L), Double.longBitsToDouble(0x3fdacc73fac65ebeL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.SubLine:@?\012",
        Z.run(T, 1, 14, 8, 4, "\uda32\udd2e\udb9f\udf31\ud997\uddc9\ud99b\uddc3\uec4c\ud930\udfe4", "\u658b\u94f5\u6d8e\uab96\u2fc5\u9f7a\u644c\ubbeb", "\ud9e7\udc8b\ud96d\ude5f\udb11\udee3\udba1\udf45\ud9b2\udde4\udb28\udf25\ud9e1\ude81\udab7\uddef\u9258\ud9c9\udeef\udbe5\udf75\ud9b0\udc0e\udbe6\udc6b",
        19, 89375, -1258495751, 3664129321059570420L, -13031L, false, true, (char) 19472, (char) 60988,
        Double.longBitsToDouble(0x3fe3794eb5f7ba52L), Double.longBitsToDouble(0x3fdacc73fac65ebeL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 8, 4, "\ud9cc\udfdc\uda15\udea9\udb28\udeee\udb7f\uddfb\ud813\udebd\ud98f\udd87", "\u6529\u94f5\u52f0\uc2ff\ub3f6\u1c33\u6408\ubbeb", "\udae7\udd9a\ud8f0\udcb4\udb2c\udc67\ud852\udde3\ud9b2\udde4\udb9e\ude4a\ud9e1\ude81\udab2\udeef\u9258\ud805\udc7b\udbe9\udcf7\ud9b0\udc74\udbe6\udc6b",
        14, 89375, -1258495751, 8302242172015921889L, 91974L, false, false, (char) 2693, (char) 60988,
        Double.longBitsToDouble(0x3fe3794eb5f7ba52L), Double.longBitsToDouble(0x3feb0e39fd63dfcfL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 8, 4, "\ud9cc\udfdc\uda15\udea9\udbdb\udc67\udb7d\udebc\u9bef\ud930\udfe4", "\u658b\u94f5\u52f0\uab96\u2fc5\u2e84\u63fd\ubbeb", "\ud9e7\udc8b\ud96d\ude5f\udb11\udee3\ud852\udde3\ud9b2\udde4\udb28\udf25\ud9e1\ude81\udab2\udeef\u9258\ud9c9\udeef\udbe5\udf75\ud9b0\udc0e\udbe6\udc6b",
        19, 89375, -1258495751, 8302242172015921889L, 91974L, false, false, (char) 2693, (char) 60988,
        Double.longBitsToDouble(0x3fe3794eb5f7ba52L), Double.longBitsToDouble(0x3fdacc73fac65ebeL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 4, "\ud82d\uddd2\uda15\udea9\udbdb\udc67\udb7d\udebc\u34ef\ud930\udfe4", "\000", "\000",
        3, 9518, 235250432, 0L, 78591L, false, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 11, 12, "\ud9cc\udfdc\uda15\udea9\ud9de\udd88\udbe1\udee7\u9bef\ud930\udfe4", "\u3b49\u94f5\u52f0\uab96\u2fc5\ua0e2\u63fd\ubbeb", "\ud9e7\udc8b\ud96d\ude5f\udb00\udfe3\ud852\udde3\ud9b2\udde4\udb28\udf25\udad5\udcbb\ud895\udc86\u9258\ud8d9\udef7\udbe5\udf75\ud9b0\udc0e\ud837\udc34",
        19, 88983, -1266603843, 8302242172015921889L, 91974L, false, false, (char) 2693, (char) 22844,
        Double.longBitsToDouble(0x3fe3794eb5f7ba52L), Double.longBitsToDouble(0x3fdacc73f2a65ebeL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.SubLine:@?\012",
        Z.run(T, 1, 14, 8, 6, "\ud9cc\udfdc\uda15\udea9\udbdb\udc67\udb7d\udeb6\u9bef\ud930\udfe4\ud866\ude8d\ud933\udff1\udb3d\ude3d\ud9d6\udf55\ud92d\ude47\ud9c5\udd13", "\u63fd\ubbeb\u1772\u0e01\ua97e\u58c7\u1f5a\u0d6e\u1540", "\udab2\udeef\u9258\ud9c9\udeef\udbe5\udf75\ud9b0\udc0e\udbe6\udc6b\ud952\udda7",
        51, 30156, 1933009946, -5888796395713704020L, -86620L, true, true, (char) 60988, (char) 37957,
        Double.longBitsToDouble(0x3fdf7ba52b598e7eL), Double.longBitsToDouble(0x3feb197af96dda0eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 14, 4, "\ud9cc\udfdc\uda15\udea9\udbdb\udc67\udb7d\udebc\u9bef\ud930\udfe4\ud866\ude8d\ud9dc\udec5\ud90e\udf46\ud9d6\udf55", "\u2fc5\u2e84\u63fd\ubbeb\u16ee\u0e01\ua97e\u839d\u1f8d\u0d6e\u5561\u27dc\ucb1b\u46f9\u738f\u9d8e\u70cd\u1d21\u9277\u7084\u9998\u4811\u3654\u0a05\ubef0\uc103\u3190\ud14c\ua4b9", "\udabe\udc76\udb75\ude6e\ud915\udf0a\ud9a3\uded5\uda55\udc7f\udac1\ude06\ud882\udeb3\uda4b\udc0e\ud929\uddc7",
        38, 59013, 127699258, -7033035771313459788L, -72696L, false, true, (char) 20653, (char) 58499,
        Double.longBitsToDouble(0x3fd7b129849aa978L), Double.longBitsToDouble(0x3fe2b98a29863cb1L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.SubLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 8, 4, "\ud9cc\udfdc\uda15\udea9\udbdb\udc67\udb7d\udebc\u9bef\ud930\udfe4", "\u658b\u94f5\u52f0\uab96\u2fc5\u2e84\u63fd\ubbeb", "\ud9e7\udc8b\ud96d\ude5f\udb11\udee3\ud852\udde3\ud9b2\udde4\udb28\udf25\ud8a8\udce5\udab2\udf59\u9afc\ud9c9\udeef\udbe5\udf75\ud9b0\udc0e\udbe6\udc6b",
        19, 89375, -1258495751, 8302242172015921889L, 91974L, false, false, (char) 2693, (char) 60988,
        Double.longBitsToDouble(0x3fe3794eb5f7ba52L), Double.longBitsToDouble(0x3fdacc73fac65ebeL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 8, 4, "\ud9cc\udfdc\uda15\udea9\ud969\uddc3\udbe6\udcbd\ud8f0\udcba\ud96a\uddf0", "\u658b\u94f5\u52f0\uc9c7\u3000\u2e84\u63fd\ud73a", "\udb27\udf4c\ud96c\ude64\ud878\udf32\ud852\udde3\ud9b2\udde4\udb28\udf25\udb6d\udd47\udab2\udeed\u9258\ud9c9\udeef\udbe5\udf75\ud9b0\udc0e\udbe6\udc6b",
        4, 89375, -1258495751, -2434339339635340614L, 91961L, false, false, (char) 2693, (char) 60988,
        Double.longBitsToDouble(0x3fe3794eb5f7ba52L), Double.longBitsToDouble(0x3fdacc73fac65ebeL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 4, "\ud9cc\udfdc\uda15\udea9\udb1b\ude28\udb68\udd71\u9bef\ud930\udfe4", "\u42fa\uac9b\u52f0\uab96\u2fc5\u2e84\u6420\u0d78", "\uda13\udebf\ud96d\ude5f\udb11\udee3\ud852\udde3",
        9, 14215, -50598225, 3032480052434770862L, -82983L, false, true, (char) 30062, (char) 29557,
        Double.longBitsToDouble(0x3fa3ca388f98b180L), Double.longBitsToDouble(0x3fd0eb4fc5c3dcbeL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.SubLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 12, 4, "\ud840\udebc\ud83c\udc3d\udad5\uddb0\ud8cc\udcb2\uda87\udc14\ud98f\udd87\uda3a\udd56\ud9dc\udec5\ud96d\udfb7\ud72f\ud9ff\udcd0\ud8cf\udea3\uda26\uded7\ud99a\udfaa\ud917\udc80\uda71\udd1e\ud8b6\udda5", "\ub0c4\ud07a\u7bb2\u64dd\u46ee", "\ud8fa\udde9\ud805\udc7b\udbe9\udcf7\ud9b0\udc74\udbe6\udc6b\udad4\udea7\ud95f\udd34\udb93\udcae\udba8\udfe7\udbe8\udd76\ud9b7\udf1d\ud960\udf19\uda76\udf0c\udbb1\uddab\udbc9\udf2b\udb46\udd97",
        28, 28364, -1542750906, -3967043109377765378L, -6109L, false, false, (char) 60183, (char) 3072,
        Double.longBitsToDouble(0x3fa9a46905fd0d60L), Double.longBitsToDouble(0x3fed9f4fa66a200bL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.threed.SubLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 4, "\udb69\udcaa\udba1\udc2f\uda1e\udd25\udbc4\udc98\uda26\uddbc\uda80\udfec", "\ub93e", "\000",
        3, 9518, 235250432, 0L, 78591L, false, true, (char) 0, (char) 42415,
        Double.longBitsToDouble(0x3fcdfeecd10cef40L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.threed.SubLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 3, 12, "\ud9cc\udfdc\udbf6\udca8\ud819\udde7\ud883\ude81\u9bef\ud930\udfe4", "\u3b49\ub4aa\u5310\uab96\u2fc5\ua0e2\u63fd\ubbeb", "\ud9e7\udc8b\ud96d\ude5f\udb00\udfe3\ud852\udde3\uda9e\udf3b\udb28\udf25\uda33\udfca\uda85\udddf\u92a7\ud8d9\udef7\udbe5\udf75\ud9b0\udc0e\ud837\udc34",
        35, 23025, -1122424643, 5187417104189672161L, 1113L, false, false, (char) 2693, (char) 22844,
        Double.longBitsToDouble(0x3fe3794eb5f7ba52L), Double.longBitsToDouble(0x3fdacc73f2a65ebeL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.SubLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 8, 6, "\ud9cc\udfdc\uda15\udea9\udbdb\udc67\udb7d\udeb6\u9bef\ud92b\udfe4\ud866\ude8d\ud933\udff1\udb3d\ude3d\ud9d6\udf55\ud92d\ude47\ud9c5\udd13", "\u63fd\ubbeb\u1772\u14d2\u3e97\u58c7\u1f5a\u3af4\u1548", "\udab2\udeef\udbc5\udd6c\ud8a0\udc2d\uda0d\udeba\ud90a\udce6\udbe6\udc6b\ud952\udda7",
        51, 30156, 1933009946, -5888796395713704020L, -86620L, true, true, (char) 60988, (char) 37957,
        Double.longBitsToDouble(0x3fe30d5296618641L), Double.longBitsToDouble(0x3fe10891b16d6bd4L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.SubLine:@?\0121=new org.apache.commons.math3.geometry.euclidean.twod.SubLine:@?\012",
        Z.run(T, 2, 14, 14, 6, "\ud9cc\udfdc\uda15\udea9\udbdb\udc67\udb7d\udeb6\u9bef\ud930\udfe4\ud866\ude8d\ud933\udff1\udaa2\udc2f\ud9d9\udd22\ud9ed\udc86\ud9c5\udd13", "\u9210\ubbeb\u1772\u0e01\ua97e\u58c7\u1f5a\u7cd6\ub213", "\udab2\udeef\u9258\ud9c9\udeef\udbe5\udf75\ud9b0\udc0e\udbe6\udc6b\ud952\udda7",
        51, 30156, 1933009946, -5888796395713704020L, -86620L, true, true, (char) 60988, (char) 37957,
        Double.longBitsToDouble(0x3fdf7ba52b598e7eL), Double.longBitsToDouble(0x3feb197af96dda0eL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.SubLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 7, 4, "\ud9cc\udfdc\uda15\udea9\udbdb\udc67\udb7d\udebc\u9bef\ud930\udfe4", "\u658b\u94f5\u52f0\uab96\u2fc5\u2e84\u63fd\ubbeb", "\ud9e7\udc8b\ud96d\ude5f\udb11\udee3\ud852\udde3\ud9b2\udde4\udb28\udf25\ud8a8\udce5\udab2\udf59\u9afc\ud9c9\udeef\udbe5\udf75\ud9b0\udc0e\udbe6\udc6b",
        19, 89518, -1258495751, 8302242172015921889L, -86570L, false, false, (char) 2693, (char) 60988,
        Double.longBitsToDouble(0x3fe3794eb5f7ba52L), Double.longBitsToDouble(0x3fdacc73fac65ebeL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.SubLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 2, 11, "\ud9cc\udfdc\uda15\udea9\udbdb\udc67\ud8e1\udfae\uda2b\udd8d\ud8f0\ude41", "\ubf89\u94f5\u52f0\uab96\u2fc5\u2e84\u63fd\ubbeb", "\ud895\udf57",
        43, 73243, -185566582, 8924263745324735421L, 58003L, true, true, (char) 38510, (char) 5443,
        Double.longBitsToDouble(0x3fe8f5fcd19e53d0L), Double.longBitsToDouble(0x3feff39bbc279471L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.SubLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 13, 1, "\ud9cc\udfdc\uda15\udea9\udbdb\udc67\udb7d\udebc\u9bef\ud930\udfe4", "\ud448\u9a0e\u52f0\uab96\u5140\u2e84\u6f04\uac38\u16ee\u0e01\ua97e\u58c7\u1f5a\u0d6e", "\ud8a8\udce5\udb14\udeb1\udab6\ude74\ud8a4\udefb\udaba\udf85\uda75\uded1\ud898\udedf\ud93d\uddda\udb16\udc68\udb35\udc1e\udab0\udd00\ud91f\udfc9\ud937\udf9a\uda93\udda0\udbb7\uddb8\ud88f\ude36\ud87b\udd9b\udb23\ude53\udae3\udfa5\udabe\udc76\udbb3\udd8c\udb0a\udca1\ud414\ud8e9\udd88\udbc9\ude07\ud8a4\ude13\uda72\udd2a\ud856\udd7d\ud9ce\udc22\udb47\udfba\ud90d\ude2e\ud886\udc51",
        51, 70858, 1753159576, 5949425275600397932L, 10125L, true, false, (char) 62033, (char) 13178,
        Double.longBitsToDouble(0x3fd34ebc2b8bc36eL), Double.longBitsToDouble(0x3f77c166148bb080L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.SubLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 5, 5, "\ud9cc\udfdc\uda15\udea9\udbdb\udc67\udb7d\udebc\u9bef\ud930\udfe4", "\u658b\u94f5\u52f0\uab96\u2fc5\u2e84\u63fd\u11d9", "\ud9e7\udc8b\ud96d\ude5f\ud93a\uddcb\ud845\udf68\ud952\ude64\udb28\udf25\ud8a8\udce5\udab2\udf59\u9afc\ud9ad\udd6b\udbe5\udf75\ud9b0\udc0e\udbe6\udc6b",
        19, 89375, -1258495751, 8302242172015921889L, 91974L, false, false, (char) 2693, (char) 60988,
        Double.longBitsToDouble(0x3fe3794eb5f7ba52L), Double.longBitsToDouble(0x3fdacc73fac65ebeL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.SubLine:@?\012",
        Z.run(T, 1, 14, 8, 4, "\ud9cc\udfdc\uda15\udea9\udbdb\udc67\udb7d\udebc\u9bef\ud930\udfe4", "\u658b\u94f5\u52f0\uab96\u2fc5\u2e84\u63fd\ubbeb", "\ud9e7\udc8b\ud96d\ude5f\udb11\udee3\ud852\udde3\ud9b2\udde4\udb28\udf25\ud9e1\ude81\udab2\udeef\u9258\ud9c9\udeef\udbe5\udf75\ud9b0\udc0e\udbe6\udc6b",
        19, 89375, -1258495751, 8302242172015921889L, 91971L, false, false, (char) 2693, (char) 60988,
        Double.longBitsToDouble(0x3fe3794eb5f7ba52L), Double.longBitsToDouble(0x3fdacc73fac65ebeL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.threed.SubLine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 14, "\ud986\udff4", "\u3c74\ud0d0\u2b89", "\ud9e4\udf09\ud8cd\ude0f\ud92d\ude67\udbd5\udfc5\ud875\udeb5",
        46, 17711, -1388142340, -3538816506686101486L, 74636L, true, false, (char) 4200, (char) 20361,
        Double.longBitsToDouble(0x3fb82576798404a8L), Double.longBitsToDouble(0x3fe788965b79ede1L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.geometry.euclidean.threed.SubLine|intersection|org.apache.commons.math3.geometry.euclidean.threed.SubLine,boolean|new:org.apache.commons.math3.geometry.euclidean.threed.SubLine:org.apache.commons.math3.geometry.euclidean.threed.Segment",
    "M|org.apache.commons.math3.geometry.euclidean.twod.SubLine|intersection|org.apache.commons.math3.geometry.euclidean.twod.SubLine,boolean|new:org.apache.commons.math3.geometry.euclidean.twod.SubLine:org.apache.commons.math3.geometry.euclidean.twod.Segment",
    "M|org.apache.commons.math3.geometry.euclidean.threed.SubLine|buildIntervalSet|org.apache.commons.math3.geometry.euclidean.threed.Vector3D,org.apache.commons.math3.geometry.euclidean.threed.Vector3D|static",
    "M|org.apache.commons.math3.geometry.euclidean.threed.SubLine|getSegments||new:org.apache.commons.math3.geometry.euclidean.threed.SubLine:org.apache.commons.math3.geometry.euclidean.threed.Segment",
    "C|org.apache.commons.math3.geometry.euclidean.threed.SubLine|<init>|org.apache.commons.math3.geometry.euclidean.threed.Segment",
    "C|org.apache.commons.math3.geometry.euclidean.threed.SubLine|<init>|org.apache.commons.math3.geometry.euclidean.threed.Vector3D,org.apache.commons.math3.geometry.euclidean.threed.Vector3D",
    "C|org.apache.commons.math3.geometry.euclidean.threed.SubLine|<init>|org.apache.commons.math3.geometry.euclidean.threed.Line,org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet",
    "M|org.apache.commons.math3.geometry.euclidean.twod.SubLine|buildIntervalSet|org.apache.commons.math3.geometry.euclidean.twod.Vector2D,org.apache.commons.math3.geometry.euclidean.twod.Vector2D|static",
    "M|org.apache.commons.math3.geometry.euclidean.twod.SubLine|buildNew|org.apache.commons.math3.geometry.partitioning.Hyperplane,org.apache.commons.math3.geometry.partitioning.Region|new:org.apache.commons.math3.geometry.euclidean.twod.SubLine:org.apache.commons.math3.geometry.euclidean.twod.Segment",
    "M|org.apache.commons.math3.geometry.euclidean.twod.SubLine|getSegments||new:org.apache.commons.math3.geometry.euclidean.twod.SubLine:org.apache.commons.math3.geometry.euclidean.twod.Segment",
    "M|org.apache.commons.math3.geometry.euclidean.twod.SubLine|side|org.apache.commons.math3.geometry.partitioning.Hyperplane|new:org.apache.commons.math3.geometry.euclidean.twod.SubLine:org.apache.commons.math3.geometry.euclidean.twod.Segment",
    "M|org.apache.commons.math3.geometry.euclidean.twod.SubLine|split|org.apache.commons.math3.geometry.partitioning.Hyperplane|new:org.apache.commons.math3.geometry.euclidean.twod.SubLine:org.apache.commons.math3.geometry.euclidean.twod.Segment",
    "C|org.apache.commons.math3.geometry.euclidean.twod.SubLine|<init>|org.apache.commons.math3.geometry.euclidean.twod.Segment",
    "C|org.apache.commons.math3.geometry.euclidean.twod.SubLine|<init>|org.apache.commons.math3.geometry.euclidean.twod.Vector2D,org.apache.commons.math3.geometry.euclidean.twod.Vector2D",
    "C|org.apache.commons.math3.geometry.euclidean.twod.SubLine|<init>|org.apache.commons.math3.geometry.partitioning.Hyperplane,org.apache.commons.math3.geometry.partitioning.Region",
    "M|org.apache.commons.math3.geometry.euclidean.threed.SubLine|intersection|org.apache.commons.math3.geometry.euclidean.threed.SubLine,boolean|new:org.apache.commons.math3.geometry.euclidean.threed.SubLine:org.apache.commons.math3.geometry.euclidean.threed.Segment",
    "M|org.apache.commons.math3.geometry.euclidean.twod.SubLine|intersection|org.apache.commons.math3.geometry.euclidean.twod.SubLine,boolean|new:org.apache.commons.math3.geometry.euclidean.twod.SubLine:org.apache.commons.math3.geometry.euclidean.twod.Segment",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
