package org.apache.commons.math.optimization.linear;
import org.junit.Test;
import static org.junit.Assert.*;
public class SimplexTableau_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 7, 5, "\ud84e\udced\udbe1\ude95\udb1f\udde5\udb40\udd66\ud8e3\ude30\udb1d\udd6f\udbfa\ude6f\ud99c\udc8b\ufddb\ud977\udf1d\ud8af\udc99\udb4b\udddd", "\u993f\u6917", "\uda40\udd04\udbeb\ude64\ud85f\udf98\uda94\udf15\udbcc\udc7f\ud9f3\uddd8\ub460\ud81e\udd5a\ud913\udcd2\udaed\udefa",
        32, 10442, -276741261, 4152775749815240590L, -7149L, true, false, (char) 23920, (char) 53066,
        Double.longBitsToDouble(0x3fe8d152636ec417L), Double.longBitsToDouble(0x3fefd32b32f8bc58L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 7, 5, "\ud84e\udced\udbe1\ude95\uda93\udf00\udb40\udd66\udaf9\udd09\udb1d\udd72\udbfa\ude6f\ud99c\udc8b\ufddb\ud977\udf1d\ud8af\udc99\udb4b\udddd", "\u993f\u6917", "\uda40\udd04\udbeb\ude64\ud85f\udf98\udaab\udf1a\ud900\ude33\ud9f3\ude54\ub460\ud81e\udd5a\ud913\udcd2\ud802\udffd",
        32, 10442, -276741261, 4152776162132101006L, -7149L, true, false, (char) 23920, (char) 53066,
        Double.longBitsToDouble(0x3fe8d152636ec417L), Double.longBitsToDouble(0x3fefd32b32f8bc58L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 7, 5, "\ud84e\udced\udbe1\ude95\udb1f\udde5\udb40\udd66\udb82\ude9d\ud9c6\udfea\udbfa\ude6f\ud99c\udc8b\ufddb\ud977\udf1d\ud8af\udc99\udb4b\udddd", "\u993f\u6917", "\uda40\udd04\udbeb\ude64\ud85f\udf98\uda94\udf15\udbcc\udc7f\ud9f3\uddd8\ub460\ud81e\udd5a\ud913\udcd2\udaed\udefa",
        32, 10442, -276741261, 4152775749815240590L, -7149L, true, false, (char) 23920, (char) 53066,
        Double.longBitsToDouble(0x3fe8d152636ec417L), Double.longBitsToDouble(0x3fefd32b32f8bc58L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 7, 5, "\ud84e\udced\udbe1\ude95\udb1f\udde5", "\u6424\u297b\ud06f\ua61d\ucfca\u78c6\u31ce\u0a52\u8055", "\udb54\udf9a\ud98a\udfd2\ud82c\udf43\ud81d\uddc6\ud85f\udf8e\uda94\udf15\udbcc\udc7f\ud9f3\uddd8\udb26\udd35",
        58, 64764, 1732313317, -5310554395422270766L, 55765L, false, true, (char) 48549, (char) 49417,
        Double.longBitsToDouble(0x3fe147d2454d9676L), Double.longBitsToDouble(0x3fb1fda4b4f1b690L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 2, 5, "\ud868\ude5d\udbe1\ude95\uda96\udfc5\udbde\udf4e\ud8e3\ude30\udba0\ude31\udbd0\udc98\ud99c\udc8b\ufddb\ud977\udf1d\ud8af\udc99\udb4b\udddd", "\ua70b\u6917", "\uda40\udd04\udbeb\ude64\ud85f\udf98\uda8f\udc50\ud821\udd2f\udaed\udd97\ub460\ud81e\udd5a\ud913\udcd2\udaed\udefa",
        32, 10442, -276741261, 4152775749815240590L, 69370L, true, false, (char) 23920, (char) 53066,
        Double.longBitsToDouble(0x3fd1a2a4c6dcc644L), Double.longBitsToDouble(0x3fefd3861e841f58L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 11, 10, "\ud86e\udff2\uda0e\udc6d\udaee\udf54\udb40\udd66\ud8e3\ude30\udb1d\udd6f\udbfa\ude6f\ud989\udd8b\u73cb\ud977\udefb\ud8af\udc99\udb4b\udddd\udadd\ude2f\udab0\udd16\udb43\udd10\udbb8\udf9a\ud99b\udfcc\udbc2\udea7\uda40\udd04\ud803\udf07\ud882\udda9\ud968\udd47\udbcc\udc77\ud9f3\uddd8\ub460\ud966\udd5e\ud913\udcd2\ud842\udecc\ud858\udde2\udbfa\ude23", "\u8cb3\u4525\u0214\ub1f6\u2422\u7940\uccdf\u5ae5\u2168\u531a\u9ed4\u9c8d\u63ee\u1399\ucca5\u20a5\u5540\u58f1", "\ud9d4\udecf\u2b9a\ud819\udc42\ud9ef\udf52\uda85\udc60\udbaf\udc76\ud9ab\ude60\ua027\udb15\ude4d\udbc9\udfa2\ud9ab\udca7\ud9e5\udffb\ud8b4\udf62\udbf6\udfb5\ud98b\udf61\udbb5\udc27\udbb1\udc05\udb17\udc70\udb62\ude1d\ud9e1\udf90\ud819\udf2f\udb8d\udfef\ud94f\uddbb\ud8f7\udf3d\ud840\uddce\ud8a0\udcff\ud8cb\udf58\ud963\udc61\uebc9\uda89\udd7c\udb8d\udefd\uda2d\udcc7\uc8ae\ud895\udf6d\ud8ea\udefb\udb95\udd27\udbb8\udd0e\udaa5\ude25\ue92f\uda1a\ude2b\udb1e\udc71\ud875\udca2\ud816\udfd0\ud8cc\udd36\udad2\udd3b\udb49\udc07\uda69\udd97\ud8ca\ude60\ud95d\udfea\ud806\udee2\ud8e3\ude90\udbf7\uddce\ubaa8\u7f37",
        54, 43977, -1425650962, 7052363689457158517L, 18950L, false, false, (char) 63853, (char) 16607,
        Double.longBitsToDouble(0x3fe29198feb98c54L), Double.longBitsToDouble(0x3fea8a0e26233b91L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 7, 5, "\ud84e\udced\udbe1\ude95\udb1f\udde5\udb40\udd66\ud8e3\ude30\ud93f\uddcc\u123b\ud99c\udc8b\ufddb\ud977\udf1d\ud8af\udc99\ud9cd\uddde", "\u993f\u562f", "\udb77\udd20\u23e1\ud85f\udf98\ud93c\udd15\udbcc\udc7f\ud9f3\uddd8\ub460\ud81e\udd5a\ud913\udcd2\udaed\udefa",
        32, 10442, -276741261, 4152775749815246905L, 88315L, false, false, (char) 17719, (char) 29107,
        Double.longBitsToDouble(0x3fe7b9dd70c3f687L), Double.longBitsToDouble(0x3f9a2a4c6ddc9aa0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 8, 5, "\ud84e\udced\udbe1\ude95\udb1f\udde5\udb40\udd66\ud8e3\ude30\udb1d\udd6f\udbfa\ude6f\ud861\udfdd\ufddb\ud977\udf1d\ud8af\udc99\udb4b\udddd", "\u993f\u6917", "\uda0a\udfe9\ud94d\udd2d\ud886\udf47\uda94\udf15\udbcc\udc7f\ud9f3\uddd8\ub460\ud81e\udd5a\ud913\udcd2\udaed\udefa",
        32, 10442, -276741261, 2940028718029922760L, -7149L, true, false, (char) 23920, (char) 53066,
        Double.longBitsToDouble(0x3fe8d152636ec417L), Double.longBitsToDouble(0x3fefd3e19af8bc58L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 8, "\ud84a\udf0d\udbe1\ude95\udb1f\udde5\u598a\ud83d\udd3e\udaca\udf84\udbfa\ude6f\ud99c\udc8b\ufddb\ud977\udf1d\ud8af\udc99\udb4b\udddd", "\u6ef7\ud0a4\ub7b1\u3bfa\u0607\u0ea4\ubd2f\u1cf2\u6c84\u2867", "\ud913\udcd2\ud8ff\udc59\udbb1\udfc0\ud9c5\udd73\ud9ee\udc8f\ud9b4\udef0\u6c3b\udb54\udd71\ud939\udfbb\ud879\ude1a\ud8d2\udc7f",
        53, 58086, 709679299, -4316929927394428050L, -31128L, true, true, (char) 22950, (char) 36986,
        Double.longBitsToDouble(0x3fdc4bb950e29f56L), Double.longBitsToDouble(0x3fc049c8c6952cecL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 15, 3, "\udbb8\udc62\u1e0b\ud8eb\uddec\udb40\udd66\ud8e3\ude30\ud9c9\udd65\udbfa\ude6f\ud99c\udc8b\ufddb\ud977\udf1d\ud8af\udc99\udb4b\udddd", "\u993f\u6917", "\udbfc\udd61\udbeb\ude64\ud85f\udf98\udad5\udc43\uda24\udd18\ud9fd\udfa0\ub460\ud8f2\udc95\ud913\udcd2\ud915\udf05",
        28, 10367, -276711309, 4152775749815240590L, 12759L, true, true, (char) 53986, (char) 53066,
        Double.longBitsToDouble(0x3fe8d152636ec417L), Double.longBitsToDouble(0x3fd6a18665f178b0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 7, 5, "\ud84e\udced\udbe1\ude95\udb1f\udde5\udb40\udd66\ud8e3\ude30\udb1d\udd6f\udbfa\ude6f\ud99c\udc8b\ufddb\ud977\udf1d\ud8af\udc99\udb4b\udddd", "\u993f\u6917", "\uda40\udd04\udbeb\ude64\ud85f\udf98\uda94\udf15\udbcc\udc7f\ud9f3\uddd8\ub460\ud81e\udd5a\ud913\udcd2\udaed\udefa",
        32, 10442, -276741261, 4152775749815240590L, 73901L, false, false, (char) 11203, (char) 18138,
        Double.longBitsToDouble(0x3fe4f1b690c3f687L), Double.longBitsToDouble(0x3fe8d152636ec417L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getSolution||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|copyArray|[D,[D,int|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|createTableau|boolean|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|discardArtificialVariables||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|divideRow|int,double|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|equals|java.lang.Object|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getArtificialVariableOffset||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getBasicRow|int|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getConstraintTypeCounts|org.apache.commons.math.optimization.linear.Relationship|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getData||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getEntry|int,int|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getHeight||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getInvertedCoeffiecientSum|org.apache.commons.math.linear.RealVector|static",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getNormalizedConstraints||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getNumArtificialVariables||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getNumDecisionVariables||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getSolution||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
