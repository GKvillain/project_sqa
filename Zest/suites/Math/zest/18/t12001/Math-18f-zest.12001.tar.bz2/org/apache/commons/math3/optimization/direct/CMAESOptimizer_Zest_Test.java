package org.apache.commons.math3.optimization.direct;
import org.junit.Test;
import static org.junit.Assert.*;
public class CMAESOptimizer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0....\012",
        Z.run(T, 1, 5, 8, 2, "\ud82d\udf13\udbf7\udfec\ud820\ude11\ud8d3\udea1\udb12\udd80\uda02\udd8a\udacc\udfc2\ud434\uda3d\udf74", "\u3180\uaef8\u3f9a\ua1e1\u17df\uaf87\ua98e\u8c24\ua7b8\u9a17\u74a4\u9b99\u797c", "\udb35\udd56\ud88c\udf84\udaef\udd2b\ud92d\uddd2\udb3e\udd1e\udae6\ude81\udb18\udd35",
        46, 31300, 1683272766, 4238527884756656661L, -30804L, false, false, (char) 1773, (char) 3609,
        Double.longBitsToDouble(0x3fe2d33058305176L), Double.longBitsToDouble(0x3feef58fe5509d58L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.math3.optimization.direct.CMAESOptimizer:@?\012",
        Z.run(T, 1, 6, 8, 0, "\ud82d\udf13\udbf7\udfec\ud820\ude11\ud8d3\udea1\udb12\udd80\ud918\ude96\000\000\000", "\u3180", "\udb76\udf84\udb1c\udf79\ud9fc\udc0e\ud9e9\udeca\ud918\udf83\uda84\uddbe\udac7\udeb9\uda8f\uded9\ud9d8\udffb\ud829\udd67",
        8, 35807, -1264623160, -1771105463604728262L, -68305L, true, false, (char) 17076, (char) 61750,
        Double.longBitsToDouble(0x3fc3821280000000L), Double.longBitsToDouble(0x3fe54322a2153ad2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0....\012",
        Z.run(T, 1, 5, 8, 2, "\ud82d\udf13\udbf7\udfec\udb54\udc98\ud943\udf93\ud890\udf52\ud974\udd8b\udb8e\udcd2\ud434\uda3d\udf74\ud84a\udd66", "\uaf8c\u9799\ua1e1", "\ud9db\ude5e\uda34\ude4e\udbf4\udebc\udade\udd07\uda8f\uded9\ud9d8\udffb\ud829\udd67\ud9ca\udee6\ud9dd\udf15\uda2b\ude7f\ud87b\ude78\udb0c\ude9d\ud92d\uddd2\u3687\ud9d9\uddca\ud832\udc30\udaa4\udd30\ud90c\udfaa\udbcf\udcee\ud87a\udce2\ud913\udf81\udaf3\udd3a",
        22, 59628, 281511928, 7352995685837095788L, -8221L, false, true, (char) 24183, (char) 56706,
        Double.longBitsToDouble(0x3fe2b6707fc48b71L), Double.longBitsToDouble(0x3fef662fc2f234bbL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0....\012",
        Z.run(T, 1, 5, 8, 9, "\ud82d\udf13\udbf7\udfec\ud820\ude11\ud8d3\udea1\udb12\udd80\u01ae\udacc\udfc2\ud434\uda3d\udf74", "\u2914\uaf41\u3f9a\ua1e1\u17df\uaf87\ua98e\u8bc3\ua7b8\ub2d4\ubfe6\u19ce\uaeab", "\ud9ca\udea8\ud88c\udf84\udaed\udd00\ud92d\uddd2\udb3e\udd1e",
        15, 42509, 278141031, 7578094294420206797L, 39797L, false, false, (char) 4928, (char) 39949,
        Double.longBitsToDouble(0x3fef2bf7ab3eaadaL), Double.longBitsToDouble(0x3fe2d33058305176L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 1, 5, 10, 2, "\ud844\udfab\udbf7\udfec\ud820\ude11\ud928\udc0b\udb0e\udfd4\uda02\udd8a\udaf4\udf09\ud3a2\uda3d\udf74", "\u12e2\u858e\u3f9a\ua1bb\uca40\uaf87\ua98e\u8c24\uced9\ud532\u4217\u9b99\u930d", "\udbd7\udfa6\udb8d\udd90\uda55\uddae\ud831\udf5f\ud886\udf6b\udae6\ude81\udb62\udd2a",
        -4, 31300, 1683272766, 4238527884756656661L, -18029L, true, false, (char) 20405, (char) 3609,
        Double.longBitsToDouble(0x3fe2d33058305176L), Double.longBitsToDouble(0x3fda7d4a1babcc7eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\ub313", "\ucbac", "\udacc\udf3b\u0094",
        26, 2677, 0, -3703368467495329997L, 31072L, false, false, (char) 52317, (char) 0,
        Double.longBitsToDouble(0x3e26046b10000000L), Double.longBitsToDouble(0x3fe665e4c3d7bde1L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|checkParameters||new:org.apache.commons.math3.optimization.direct.CMAESOptimizer:",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|copyColumn|org.apache.commons.math3.linear.RealMatrix,int,org.apache.commons.math3.linear.RealMatrix,int|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|diag|org.apache.commons.math3.linear.RealMatrix|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|divide|org.apache.commons.math3.linear.RealMatrix,org.apache.commons.math3.linear.RealMatrix|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|doOptimize||new:org.apache.commons.math3.optimization.direct.CMAESOptimizer:",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|eye|int,int|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|getStatisticsDHistory||new:org.apache.commons.math3.optimization.direct.CMAESOptimizer:",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|getStatisticsFitnessHistory||new:org.apache.commons.math3.optimization.direct.CMAESOptimizer:",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|getStatisticsMeanHistory||new:org.apache.commons.math3.optimization.direct.CMAESOptimizer:",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|getStatisticsSigmaHistory||new:org.apache.commons.math3.optimization.direct.CMAESOptimizer:",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|initializeCMA|[D|new:org.apache.commons.math3.optimization.direct.CMAESOptimizer:",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|inverse|[I|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|log|org.apache.commons.math3.linear.RealMatrix|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|max|[D|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|max|org.apache.commons.math3.linear.RealMatrix|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|min|[D|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
