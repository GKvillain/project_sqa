package org.apache.commons.math.optimization.fitting;
import org.junit.Test;
import static org.junit.Assert.*;
public class GaussianFitter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.fitting.GaussianFitter:@?\012",
        Z.run(T, 1, 2, 1, 2, "\udaf9\udc86", "\ud4d2", "\udbae\udd63\uda6b\uded1\udb1c\uddd9\udb7e\udff0\ud9d0\udc52\ud804\udf4b\udbcf\udf07\udb29\udd00\uda08\udcf8\udba2\udc2e\udbf3\ude0b",
        15, 19213, 1098544284, 1980277113060943549L, -38799L, true, false, (char) 25157, (char) 60076,
        Double.longBitsToDouble(0x3fe1c00db7a3c29aL), Double.longBitsToDouble(0x3fe19e4c0ccab16eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.fitting.GaussianFitter:@?\012",
        Z.run(T, 1, 2, 1, 2, "\udaf9\udc86", "\ud4d2", "\udbae\udd63\uda6b\uded1\udb1c\uddd9\udb7e\udff0\ud9d0\udc52\ud804\udf4b\udbcf\udf07\udb29\udd00\uda08\udcf8\udba2\udc2e\udbf3\ude0b",
        15, 19213, 1098544284, 1980277113718046909L, -100000L, true, false, (char) 25157, (char) 60076,
        Double.longBitsToDouble(0x3fe1c00db7a3c29aL), Double.longBitsToDouble(0x3fe19e4c0ccab16eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.fitting.GaussianFitter:@?\012",
        Z.run(T, 1, 2, 1, 2, "\udaf9\udc86", "\ud4d2\u7089\ub2f3\ud230\u6fcd\ua1e0\ubb93\u0f92", "\udb29\udd00\uda08\udcf8\udba2\udc2e\udbf3\ude0b\ud87f\ude8d\uda72\ude2e\udb56\udc77",
        10, 1829, 878779104, -5428826496256753047L, 4550L, false, false, (char) 27197, (char) 65460,
        Double.longBitsToDouble(0x3fc9562dd53d115cL), Double.longBitsToDouble(0x3fd10f0d421d941aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.fitting.GaussianFitter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\udb09\udf30", "\u6a1a", "\udadd\ude9b\uda6b\udf7e\udb1c\uddd9\udb7e\udff0\ud9d0\udc52\udb8c\uddd0\u729d\ud8f6\ude97",
        17, 75520, 653880234, -613014760562119620L, 965L, false, true, (char) 21434, (char) 52498,
        Double.longBitsToDouble(0x3febc95942e2974dL), Double.longBitsToDouble(0x3feaa41890e001b6L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 3, 2, "\udaf9\udc86", "\ud453", "\udba5\udebf\ud90f\udf4c\udb1c\uddd9\udb7e\udff0\ud9d0\udc52\ud804\udf4b\ud921\udef0\udbca\uddf4\ud858\udddd\udba2\udc2e\udbf3\ude0b",
        15, 19213, 1098544284, 1980277113060943549L, 81098L, true, false, (char) 25157, (char) 60076,
        Double.longBitsToDouble(0x3fe1c00db7a3c29aL), Double.longBitsToDouble(0x3fe19e4c0ccab16eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 2, "\udadc\udef8\ud9a2\ude41\udbc6\udea2\ud80c\udeef\udbf5\udda3\ud93d\ude88\udbb3\udd88", "\u02e2\u0f92\u334e", "\uda08\udcf8",
        52, 5066, 1203446355, 5548282618572338332L, -8163L, false, false, (char) 9074, (char) 63249,
        Double.longBitsToDouble(0x3fe714bb1f9a8312L), Double.longBitsToDouble(0x3fe1c00db7a3c29aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NumberIsTooSmallException\012",
        Z.run(T, 1, 3, 1, 2, "\udaf9\udc86", "\ud4d2", "\udbae\udd63\uda6b\uded1\udb1c\uddd9\udba2\uded6\ud9d0\udc52\ud804\udf4b\udbcf\udf07\udb29\udd00\uda08\udcf8\udb13\udee6\udb81\uddf1",
        57, 52749, 1098544284, 1980277113060943549L, -38799L, true, false, (char) 25157, (char) 60076,
        Double.longBitsToDouble(0x3fe1c00db7a3c29aL), Double.longBitsToDouble(0x3fe19e4c0ccab16eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.fitting.GaussianFitter:@?\0121=!org.apache.commons.math.exception.NumberIsTooSmallException\012",
        Z.run(T, 2, 2, 0, 1, "\udaf9\udc86", "\ud4d2", "\udbae\udd63\uda08\udde2\uda6d\ude65\udba9\udee3\ud914\ude19\ud804\udf4b\ud961\udea7\uda6a\udf86\uda08\udcea\udba2\udc2e\udbf3\ude0b",
        15, 19213, 1098544284, -7154430306131943232L, -38799L, false, false, (char) 25270, (char) 60076,
        Double.longBitsToDouble(0x3fe7860db7a3c2c4L), Double.longBitsToDouble(0x3feade4c0ccab16eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 3, "\udaf9\udc86\ud9a2\ude41", "\u1b80\uc325", "\udb1c\uddd9\udbec\udca5\ud9d0\udc51\ud804\udf4b",
        59, 65389, 1898887757, -3740235925054460992L, 78588L, true, false, (char) 62389, (char) 9074,
        Double.longBitsToDouble(0x3feb4da542707fdeL), Double.longBitsToDouble(0x3fecd418923801b6L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NumberIsTooSmallException\012",
        Z.run(T, 1, 3, 1, 2, "\ud861\udd99", "\uab46", "\uda6e\udfaf\ud83f\uddeb",
        25, 11306, -1088880989, 9213726853631545938L, 83485L, false, false, (char) 14280, (char) 18764,
        Double.longBitsToDouble(0x3fda547bb93899feL), Double.longBitsToDouble(0x3fec5a0bd6bd1b7bL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.fitting.GaussianFitter:@?\0121=!org.apache.commons.math.exception.NumberIsTooSmallException\012",
        Z.run(T, 2, 2, 3, 0, "\udaf9\udc7d\uda38\ude0d\udad8\udddb", "\ub9bc\ud230\u5766\u917d\u410f\u14fd\u80be\u669d\u7a66\u0872\ud5b8\u41f1\u1757\u7d0c\u63d9\u6972\u57d9", "\uda0c\udfc7",
        0, 26953, 1109571386, 8395175498074516275L, -83871L, false, true, (char) 57102, (char) 16942,
        Double.longBitsToDouble(0x3fe4cd8e13eb91dfL), Double.longBitsToDouble(0x3fe1863e9a92cb17L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.fitting.GaussianFitter:@?\0121=new org.apache.commons.math.optimization.fitting.GaussianFitter:@?\012",
        Z.run(T, 2, 2, 2, 2, "\udaf9\udc86", "\ud4d2", "\udbae\udd63\uda6b\uded1\udb1c\uddd9\udb7e\udff0\ud9d0\udc52\ud804\udf4b\udbcf\udf07\udb29\udd00\uda08\udcf8\udba2\udc2e\udbf3\ude0b",
        15, 62789, 1098542048, 1980277113055635133L, -38799L, true, false, (char) 25157, (char) 60076,
        Double.longBitsToDouble(0x3fe14b65b3a18589L), Double.longBitsToDouble(0x3fb7ef93a6558b70L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.fitting.GaussianFitter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\u4d15", "\u6a1a", "\udadd\ude9b\uda6b\udf7e\udb1c\uddd9\udb7e\udff0\ub421\000\u724b\ud8f6\ude97",
        17, -840, 653880064, 35503586953592832L, 965L, false, true, (char) 21434, (char) 52498,
        Double.longBitsToDouble(0x3febc95942e2974dL), Double.longBitsToDouble(0x3e921c0020000000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.fitting.GaussianFitter:@?\012",
        Z.run(T, 1, 2, 1, 2, "\udaf9\udc86", "\ud4d2", "\udbae\udd63\uda6b\uded1\udb1c\uddd9\ud8d9\ude3d\ud9bf\ude7b\ud804\udf4b\udbcf\udf07\udb29\udd00\uda08\udcf8\udba2\udc2e\udbf3\ude0b",
        15, 19213, -1954909028, 1980277113060943549L, -38799L, true, false, (char) 43333, (char) 65529,
        Double.longBitsToDouble(0x3fac00db7a3c2f80L), Double.longBitsToDouble(0x3fe19e4c0ccab16eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.fitting.GaussianFitter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\u4d15", "\u6a1a", "\udadd\ude9b\uda6b\udf7e\udbbf\udc29\udb7e\udf6d\ub421\000\u724b\ud8f6\ude97\udbc8\uddb9\u00a0\udbf3\udd4b\ud998\ude5a\ud954\udc09\ud860\udc08\uda87\udf36\udacd\udcaf\udaf0\udc44\udba7\udeec\ud9ad\uddb3\ud836\udee3\ud820\udc0f\ud95c\udd24\udb36\udf84",
        14, 60580, -1662146900, 8036371241651835259L, 50029L, false, false, (char) 40099, (char) 22099,
        Double.longBitsToDouble(0x3fb678658ea47f98L), Double.longBitsToDouble(0x3fe89721db892839L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.fitting.GaussianFitter:@?\012",
        Z.run(T, 1, 2, 1, 2, "\udaf9\udc86", "\ud4d2", "\udbae\udd63\uda6b\uded1\udb1c\uddd9\udb7e\udff0\ud9d0\udc52\ud804\udf4b\udbcf\udf07\udb29\udd00\uda08\udcf8\udba2\udc2e\udbf3\ude0b",
        15, 19213, 1098544284, 1980277113060943549L, -38799L, true, false, (char) 25157, (char) 60076,
        Double.longBitsToDouble(0x3fe1c197ada3c29aL), Double.longBitsToDouble(0x3fe19e4c0c6eeb27L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.optimization.fitting.GaussianFitter|fit||new:org.apache.commons.math.optimization.fitting.GaussianFitter:org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer",
    "M|org.apache.commons.math.optimization.fitting.GaussianFitter|fit|[D|new:org.apache.commons.math.optimization.fitting.GaussianFitter:org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer",
    "C|org.apache.commons.math.optimization.fitting.GaussianFitter|<init>|org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer",
    "M|org.apache.commons.math.optimization.fitting.GaussianFitter|fit||new:org.apache.commons.math.optimization.fitting.GaussianFitter:org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer",
    "M|org.apache.commons.math.optimization.fitting.GaussianFitter|fit|[D|new:org.apache.commons.math.optimization.fitting.GaussianFitter:org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
