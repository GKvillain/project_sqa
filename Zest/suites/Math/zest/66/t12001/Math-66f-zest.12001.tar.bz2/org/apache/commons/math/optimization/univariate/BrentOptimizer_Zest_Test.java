package org.apache.commons.math.optimization.univariate;
import org.junit.Test;
import static org.junit.Assert.*;
public class BrentOptimizer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 1, "\udac1\udf4a\ud8a1\ude81\ud951\udcbb\udaf3\udc75\ud9bd\udd56\ud9e6\ude1b\ud8ff\uded6", "\u2523\u982b\u33b3", "\uda9f\udfa4\udaeb\udd0c\uda62\ude23\udb60\udf99",
        52, 44740, 1908115898, -6494032396309752765L, -58391L, true, false, (char) 49734, (char) 41086,
        Double.longBitsToDouble(0x3fb2464c255e1d38L), Double.longBitsToDouble(0x3feeb627c435a3adL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.BrentOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 1, "\udac1\udf4a\ud8a1\ude81\ud8da\ude44\udbfe\udc04\ud9ad\udfef\ud9e6\ude1b\udac2\uddd7", "\u2523\u9d81\u33b3\ucb1e\ub335", "\uda62\ude23\udb61\udc4a\udb23\ude5b\ud8c9\udf85\udb4c\udc6d",
        37, 35163, -1962992408, -3242770439597720911L, -62816L, false, true, (char) 27225, (char) 31747,
        Double.longBitsToDouble(0x3fd00546ac60cc78L), Double.longBitsToDouble(0x3fe7bacd361710b4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 0, "\u6f5c\udbcc\udfa6\ud8db\udcf4\udaf3\udc75\udae1\udc28\ud9e6\ude1b\ud8ff\uded6", "\u3c00\u9ab0\u6e5f", "\ud972\udd5e\uda63\udca8\udbb4\udcaf\udb61\udc27\uda7e\udda8\udb94\udd61\udb45\ude24\ud944\udea1\uda25\udff3\udb6f\udecc\ud80a\uded0",
        43, 79451, 422631891, 3324948972051934379L, -39637L, false, true, (char) 51098, (char) 59183,
        Double.longBitsToDouble(0x3fdc86e7b06117beL), Double.longBitsToDouble(0x3fda62f93ab800f4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 4, "\uda49\uddaf", "\u6665\u8970", "\udb56\udd79\udbac\ude2a\udb28\udce0\udb7d\udd32",
        20, 83908, -1061406017, 676683052352502438L, -18830L, false, true, (char) 50160, (char) 57247,
        Double.longBitsToDouble(0x3fd59d6830704524L), Double.longBitsToDouble(0x3fcd0d326e8bd37cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.BrentOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 1, "\udac1\udf4a\ud8a1\ude81\ud951\udcbb\udaf3\udc75\ud9bd\udd56\ud83e\udca6\ud8bb\udd61", "\u5875\u93d0\u0b9a", "\uda9f\udfa4\udaeb\udd34\uda62\ude23\udb60\udf99\udb23\ude5b\ud8c9\udf85",
        8, 60257, 1108612163, -8430988195411305097L, 67978L, false, false, (char) 21859, (char) 43079,
        Double.longBitsToDouble(0x3fdca84026297330L), Double.longBitsToDouble(0x3fef3d00908dae00L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.BrentOptimizer:@?\0121=new org.apache.commons.math.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 2, 2, 2, 4, "\udac1\udf4a\ud8a1\ude81\ud951\udcbb\udaf3\udc75\ud9bd\udd56\ud9e6\ude1b\ud8ff\uded6\ud80b\udee1\udb3f\udd4e\ud80a\udf07", "\u0d58\u395a\u4238\u220d\u31b4\u5869\u6c4f", "\ud944\udea1\udb90\udc27\ud918\udf0a",
        3, 61473, -1543213405, 6205055292945147977L, -5930L, true, false, (char) 57698, (char) 6020,
        Double.longBitsToDouble(0x3fb14c387ff58c68L), Double.longBitsToDouble(0x3fc0160b4a5c598cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 1, 2, 1, 1, "\ud8a4\ude5b\udaa4\udc4e\ud96a\ude7f\udaf3\udc75\ud9bd\udd56\ud9e6\ude1b\ud8ff\uded6", "\u2523\u5eb1\u33b3", "\uda9f\udfa4\udaeb\udd0c\uda62\ude23\u961d",
        3, 44740, 1908115898, -6494032396309752765L, -58391L, true, false, (char) 52164, (char) 7510,
        Double.longBitsToDouble(0x3fb2464c2884e3a8L), Double.longBitsToDouble(0x3f98242309ff61a0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 3, "\udb20\ude23\ud917\udff5\ub4c0\udaf3\udc75\ud9bd\udd56\ud8bf\udcbe\uda1f\udea0\ud80b\udee1\udb3f\udd4e\ud91d\udc56\uda2a\uddda\udb09\uddd3\u30af\udbef\udccb\uda9f\udfa4\udaeb\udd0c\uda62\ude23", "\u9a4a\uced8\u7d20\u0a94\u5561\ubb78\u85d2\u32b0\u2fae\uc8c2\uceb4\u226a", "\ud8d9\udd2e\udbc1\udd3a\ud865\udd18\ud949\udeaf\udbd1\udd14\udb4a\udc3c\udbb9\udcb5\ud980\udc28",
        44, 68343, 132915587, -7756032795774416794L, 54646L, false, true, (char) 40648, (char) 3941,
        Double.longBitsToDouble(0x3fd988252c4bd350L), Double.longBitsToDouble(0x3fe9c20ec4a2befcL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.BrentOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 1, "\uda94\ude54\ud8a1\ude81\udbb1\udefa\uda81\ude19\udb11\udf71\ud9e6\ude1b\ud974\ude50", "\u2523", "\udb67\udcbc\udad5\udfdf\uda9f\udfa4\udaeb\udd0c\uda62\ude23\udb61\udc4a\udb23\ude5b\udb1d\uddeb\uda36\udc3c\ud9f0\uddd4\udb90\udc27\udb3b\ude02\ud80a\uded0\udb5b\udf9e\ud81a\udf42\udaf2\udfbf\uda5a\udf4f\ud81e\udcc6\ud87a\udd97",
        41, 43770, 1420259008, -2913851136150236470L, -53161L, true, false, (char) 19787, (char) 64995,
        Double.longBitsToDouble(0x3f8da0adcfc533c0L), Double.longBitsToDouble(0x3fda607ee25c975eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 1, 2, 1, 1, "\u8cfc\ud865\udf72\ud8da\ude44\udbfe\udc04\ud9ad\udfef\ud9e6\ude1b\udac2\uddd7", "\000", "\udb67\udcbc\udad5\udfdf\uda9f\udfa4\udaeb\udd0c\uda62\ude23\udb61\udc4a\udb23\ude5b\ud8c9\udf85\udb4c\udc6d\ud9ff\udc98\udb90\udc27\udb3b\ude02\ud80a\uded0\udb5b\udf9e\ud81a\udf42\udaf2\udfbf\uda2d\udc79\ud9b6\udd30\ud87a\udd97",
        41, 44218, 1420259008, -2913851136150236470L, -94624L, false, false, (char) 4253, (char) 30411,
        Double.longBitsToDouble(0x3fd6630612d3392cL), Double.longBitsToDouble(0x3fe8c0ce0a500e00L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NotStrictlyPositiveException\012",
        Z.run(T, 2, 1, 0, 0, "\u00fc", "\000\u8970", "\000",
        5, -1000, 0, -8121816357214792172L, -100000L, false, false, (char) 0, (char) 31900,
        Double.longBitsToDouble(0x3eca200000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NotStrictlyPositiveException\012",
        Z.run(T, 2, 1, 0, 0, "\000\ud8a1\ude81\ud951\udcbb\ud84e\udc06\ud9bd\udd56\ud9e6\ude1b\ud8ff\uded6\ud80b\udee1\udb3f\udd4e\ud80a\udf07", "\u0d58\u395a\u3321\uabd4\u314f\u5869\u6c4f", "\ud8bf\udffe\000\udb52\udc08",
        -5, 20928, -1543213405, 6205055293957603401L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc000000a5c598cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.BrentOptimizer:@?\0121=!org.apache.commons.math.exception.NotStrictlyPositiveException\012",
        Z.run(T, 2, 2, 1, 2, "\uda94\ude54", "\u6f03", "\ud974\ude50\ud89d\udca6",
        3, 33396, 728164864, 59747948052L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e35880000000000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.BrentOptimizer:@?\0121=!org.apache.commons.math.exception.NotStrictlyPositiveException\012",
        Z.run(T, 2, 2, 1, 1, "\000\000\udbb1\udefa)\udb11\udf71\000\000", "\u3f22", "\udb67\udcbc\uda0b\udfda\udb10\udc87\udaeb\udd0c\uda62\ude23\udb61\udc4a\udb23\ude5b\u32e4\uda36\udc3c\ud9f0\uddd4\udb90\udc27\udb3b\ude02\000\udb5b\udeed",
        43, 21432, 933701640, -8721220679951880440L, -100000L, false, false, (char) 16507, (char) 143,
        Double.longBitsToDouble(0x3fe1a8000500cbbeL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 1, "\udbc5\udcea\ud89b\udd12\ud951\udcbb\udaf3\udc75\ud9bd\udd56\ud9e6\ude1b\ud8ff\uded6", "\u2523\u982b\u33b3", "\ud92a\udc89\ud85c\udfa2\ud9df\uddb5\udaad\uddc5",
        52, 44740, 1908115898, -6494032396309752765L, -58391L, true, false, (char) 49734, (char) 41086,
        Double.longBitsToDouble(0x3fb2464c255e1d38L), Double.longBitsToDouble(0x3fe8ce27c435a3adL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.BrentOptimizer:@?\0121=new org.apache.commons.math.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 2, 2, 2, 4, "\udac1\udf4a\ud8a1\udeec\ud844\udd54\ud8c7\udd7a\udba4\udfe1\ud9e5\ude7e\udbd4\ude79\ud80b\udee1\udac0\udf2f\uda8b\udf90", "\u0d58\u395a\u4238\u4676\u9084\u6df1\u6c4f", "\ud944\udea1\udb90\udc27\ud918\udf0a",
        3, 61473, -1543213405, 8006332416172435529L, -5930L, true, false, (char) 57698, (char) 6020,
        Double.longBitsToDouble(0x3fb14c387ff08f88L), Double.longBitsToDouble(0x3fc0160b45e8598cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.optimization.univariate.BrentOptimizer|doOptimize||new:org.apache.commons.math.optimization.univariate.BrentOptimizer:",
    "M|org.apache.commons.math.optimization.univariate.BrentOptimizer|localMin|boolean,double,double,double,double,double|new:org.apache.commons.math.optimization.univariate.BrentOptimizer:",
    "C|org.apache.commons.math.optimization.univariate.BrentOptimizer|<init>|",
    "M|org.apache.commons.math.optimization.univariate.BrentOptimizer|doOptimize||new:org.apache.commons.math.optimization.univariate.BrentOptimizer:",
    "M|org.apache.commons.math.optimization.univariate.BrentOptimizer|localMin|boolean,double,double,double,double,double|new:org.apache.commons.math.optimization.univariate.BrentOptimizer:",
    "C|org.apache.commons.math.optimization.univariate.BrentOptimizer|<init>|",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
