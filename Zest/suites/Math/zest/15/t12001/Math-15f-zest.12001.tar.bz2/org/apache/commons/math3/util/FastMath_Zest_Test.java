package org.apache.commons.math3.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class FastMath_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Long:8911944812000894304\012",
        Z.run(T, 1, 6, 6, 15, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u23d6\u5a13\u1a0d\u820b\u9751\u83e0\u51b6\u063d\u7b0d\u714a\u3510\u1cb8\u0717\uacb1\u67b9\ub8e1\uba3b\u69a5", "\ud9d3\udd1d\udb13\udeea\u1a47",
        7, 56519, 803981719, 8911944812000894304L, -81592L, true, true, (char) 60412, (char) 56215,
        Double.longBitsToDouble(0x3fee77ea7d3b27d2L), Double.longBitsToDouble(0x3f93b7b6583aae60L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Long:8911944812000894304\012",
        Z.run(T, 1, 6, 6, 15, "\ud3da\udacf\udfdb\ud904\udfe4\ud8b2\udd4e\ud8c1\uded2\ud9df\udc21\ud8d1\udf32\udb6e\udd9c\udb15\udf1a\ud98d\udf93\udaab\udcfe", "\u23d6\u5a13\u1a0d\u820b\u9751\u83e0\u51b6\u063d\u7b0d\u714a\u3510\u1cb8\u0717\uacb1\u67b9\ub8e1\uba3b\u69a5", "\ud9d3\udd1d\udb13\udeea\u1a47",
        -5, 56519, 803981719, 8911944812000894304L, -81592L, true, true, (char) 60412, (char) 56215,
        Double.longBitsToDouble(0x3fee77ea7d3b27d2L), Double.longBitsToDouble(0x3f93b7b6583aae60L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Double:0.3610807604509049\012",
        Z.run(T, 1, 10, 6, 15, "\udadd\udfb3\ud920\udec1\uda49\udfd0\uda10\udcd4\ud897\udce7\uda52\ude3b\ud951\udfd2\uda48\udd89\uc68d\ud9b5\uded7\uda9a\uddda", "\u42de\u5a13\ubb23\u81ec\u5af3\u5a42\u51b6\u06c7\ub778\u3ae7\uac4e\u1cb8\u0eff\u10f0\u6855\ub8e1\uba3b\u69a5\u8d9d\u4efc\u11de\u2b14", "\uda46\udf3a\udaa9\udf83",
        52, 78432, 393998463, -6214888422580626143L, -37357L, false, false, (char) 63229, (char) 8138,
        Double.longBitsToDouble(0x3fd79d573670f9c2L), Double.longBitsToDouble(0x3fc0fe772b592794L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Long:409554464608825261\012",
        Z.run(T, 1, 6, 16, 13, "\ud8d6\udd50\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe\u441c\udbf4\uded2\uf7a0\ud94f\udf31\udae0\udca7\ud898\udc85\ud98f\udfd4\ud87e\ude8d\ud9b3\ude68\udacf\uded0", "\u3510", "\uda6e\udf74",
        28, 55431, -1951408184, -409554464608825261L, 41690L, false, true, (char) 56984, (char) 30791,
        Double.longBitsToDouble(0x3fec7c5a17e59280L), Double.longBitsToDouble(0x3fea28a14d6028a3L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Double:0.7263036953034745\012",
        Z.run(T, 1, 7, 6, 15, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u23d6\u5a13\u1a0d\u820b\u9751\u83e0\u51b6\u063d\u7b0d\u714a\u159d\u3024\u0f43\uacb1\u67b9\ub8e1\uba3b\u69a5", "\udaa6\ude34\udb9a\udf2d\ub9a7\ud80c\ude2e\uda4c\udc4b\udbd9\udc69\udb7b\udde0",
        17, 97357, -1447016472, 6137382790098294481L, -11367L, true, true, (char) 44683, (char) 61492,
        Double.longBitsToDouble(0x3fe7ec9eaec695c0L), Double.longBitsToDouble(0x3fe6746766134a31L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Double:0.8631771627288664\0121=java.lang.Long:8911944812000894304\012",
        Z.run(T, 2, 1, 6, 15, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u23d6\u5a13\u1a0d\u272c\u16ea\u8490\u51b6\u5730\u01b7\u714a\u3510\u1cb8\u0717\u67be\u496a\u4e7c\uba3b\u69a5", "\ud9d3\udd1d\udb13\udeea\ud929\udf18",
        3, 56519, 803981719, 8911944812000894304L, -81592L, true, true, (char) 60412, (char) 56215,
        Double.longBitsToDouble(0x3fee77ea7d3b27d2L), Double.longBitsToDouble(0x3fd13b7b6b968302L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Double:-2.3708989936075477\012",
        Z.run(T, 1, 11, 6, 15, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u23d6\u5a13\u1a0d\u820b\u9751\u83e0\u51b6\u063d\u7b0d\ud0e6\u3510\u1cb8\u0717\uacb1\u67b9\ub8e1\uba3b\u69a5", "\ud9d3\udd1d\udbfa\udefd\u1a7d",
        7, 56519, 803981719, 8911944812000894304L, -81592L, true, true, (char) 60412, (char) 56215,
        Double.longBitsToDouble(0x3fee77ea7d3b27d2L), Double.longBitsToDouble(0x3f93b7b6583aae60L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Long:2316756463652826343\012",
        Z.run(T, 1, 6, 6, 6, "", "\u1aaa", "\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93",
        -3, 97209, 499304722, 2316756463652826343L, 87340L, false, false, (char) 12928, (char) 39127,
        Double.longBitsToDouble(0x3fd441c5f71b358aL), Double.longBitsToDouble(0x3fee725c34b42ca5L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:1.2441819737455832E-9\0121=java.lang.Double:1.0673697333052563\012",
        Z.run(T, 2, 1, 13, 15, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud854\ude4a\ud9c4\uddcf\ud9fd\uddf4\ud951\udfd2\uda31\ude1e\ud929\ude79\udb4b\uded2\udaab\udcfe\udbe3\udedf\udbf7\udcd2\uf7a0\udb7f\udc48\udaca\udef7\udb64\udc71\ud98f\udfd4\ud87e\ude8d\ud9b3\ude68\udacf\uded0\ud9f2\ude7b\udb4e\udf4c\u0de3\ud921\udc7b\ud990\udeb5", "\ub8e1\u4d33\u6a25\ua7cf\ua421\u6cba\u8f61\ubd13\u152e\u4311\uba62\u712c\u584d\u3075\ud1ae\u9213\u1c68\u9def\u7700\u678e\u05a5\u82d4\ud4b5\ua1b6\uc92c\u6f71\u4d65\u2c10\u3ce6\u4b71\u6c4f\u5eab\ua571\u829f\u9335\u197d\ucafd\u7d21\uc710\u93b3\u0751\u45d0\u4875", "\ud815\udd18\uda94\udc58\ud9cb\udc01\udb70\udc6f\ud92d\uddc7",
        38, 31618, -1429570818, 1659946454522794860L, -22032L, true, false, (char) 35895, (char) 56671,
        Double.longBitsToDouble(0x3fe2a7c90158a314L), Double.longBitsToDouble(0x3fd48c9fb407bef2L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Double:0.9885748883606816\012",
        Z.run(T, 1, 16, 10, 15, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u23d6\u5a13\u1a0d\u820b\u9751\u83e0\u51b6\024\u21a0\u714a\u3510\u1cb8\u0717\uacb1\u67b9\000\uba24", "\udbb7\udf14\ud9d3\udd1d\ud86e\udd37\u1a47\udb06\udca9\uda4c\udc4b\udbd9\udc69\udb7b\udde0\udbfd\udd62",
        7, 9528, 1428970785, -7892673997596309216L, 81504L, true, false, (char) 0, (char) 53033,
        Double.longBitsToDouble(0x3fef210d6958a960L), Double.longBitsToDouble(0x3fdaa71c988c5d96L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Float:0.021278247\012",
        Z.run(T, 1, 4, 6, 15, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u23d6", "\ud898\udc44\ud98f\udfd4\ud87e\ude8d\ud9b3\ude68\udacf\uded0\ubb19\udb4e\udf4c\ud982\udc00\udacc\udea8\ud8ef\udf2a\uda79\udd9c\udbee\udc7b\udb7d\uddc5\ud8b3\udd3c\ud8d4\udc0c",
        21, -620, 1031612794, -2804712093509876347L, -57416L, true, false, (char) 12937, (char) 22637,
        Double.longBitsToDouble(0x3f95c9f6fd02ef60L), Double.longBitsToDouble(0x3fd21a9c0da2aa58L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Double:1.2601564675045007\012",
        Z.run(T, 1, 9, 6, 15, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud8e9\udd8a\udaab\udca2", "\u23d6\u5a13\ud60d\u820b\u9751\u83e0\u51b6\u063d\u7b0d\u6f84\u353f\u1cb8\u0717\uacb1\u67b9\ub8e1\ub7d1\ub1de", "\ud95d\udd22\udab5\udfda\u1a47",
        1, 56519, 2026976887, -6748279184344124090L, -81592L, true, true, (char) 60412, (char) 56215,
        Double.longBitsToDouble(0x3fee77ea7d3b3ee9L), Double.longBitsToDouble(0x3f93b7b6ac7aae60L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Double:0.969683307086672\012",
        Z.run(T, 1, 0, 0, 12, "\000\ud920\udec1\ud904\udef3\ud8b2\udd4e\u008a\uda52\ude3b\ud951\udfd2f\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u23d6\u5a13\u1a0d\u00d6\u3058\u83e0\u2854\000\u792f\u714a\u3510\u1cb8\u0717\u8f1f\033\000\000\000", "z\000\u1a47",
        43, -1000, 0, 8911944163460832608L, -100000L, true, true, (char) 0, (char) 18720,
        Double.longBitsToDouble(0x3fc9dfa9f4000000L), Double.longBitsToDouble(0x3f93b7b6001aae60L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Double:0.9837845402156464\012",
        Z.run(T, 1, 15, 6, 15, "\ud9a9\ude79\ud9d9\udd23\udb1b\udc6c\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\udaf4\udcc3\udb60\udc4d\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u23d6\u5a13\uca5d\ucbf2\ub0f8\u83e0\u5b54\u8062\u946c\u714a\u3510\u1cb8\uae6e\u7bf6\u8d11\ub8e1\uba3b\u69a5", "\ud9d3\udd1d\udb13\udeea\u1a47",
        7, 56519, 803981719, 8911944812000894304L, -96864L, true, true, (char) 60412, (char) 56215,
        Double.longBitsToDouble(0x3fee77ea7d3b27d2L), Double.longBitsToDouble(0x3f93b7b6583aae60L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:1.8541812257094565\012",
        Z.run(T, 1, 14, 6, 15, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u23d6\u5a13\u1a0d\u9926\u9751\u83e0\u51b6\u063d\u7b0d\ubfdb\u5ebb\u1cb8\ua132\u0e02\u67b9\ub8e1\uba3b\u69a5", "\ud9d3\udd1d\udb13\udeea\u1a47",
        7, 56519, 711510423, -4716542217040019145L, -81592L, true, true, (char) 33942, (char) 42154,
        Double.longBitsToDouble(0x3fee77ea7d3b27d2L), Double.longBitsToDouble(0x3f93b7b6583aae60L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:31\012",
        Z.run(T, 1, 5, 9, 2, "\uda84\uddf3\udbad\udfd4\ud825\ude0b\ud859\udd40", "\u056e\u9fbf\u7842\u0b0d\ucd00\u51bc\ub457\u1c0c\u6695\uc847\u3447\u7bcf\u84a0\u51b6\u527a\u7b0d\uc8b3\u21ef\u394c\u0717\uacb1\u67b9\u117a\uba7e\u69a5", "\ud9d3\udd1d\udb13\udeea\u1a47",
        31, 11178, 795731229, -2401233791394157923L, -81655L, false, false, (char) 54872, (char) 43948,
        Double.longBitsToDouble(0x3fdcefdfda764fa4L), Double.longBitsToDouble(0x3f93b7b6583aae60L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 8, 10, 15, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\uda3f\udd6b\ud84d\udccc\udbb7\udd2d\uda64\uddb8\uda48\udd89\udb17\ude5f\ud98d\udf93\uda7e\udcfe", "\u23d6\u5a13\u1a0d\u820b\u5a9b\u317b\u51b6\u063d\u7b0d\u47c8\uaed1\ubca8\u0717\uacb1\u67b9\ub8e1\u036c", "\udbb7\udf14\ud9d3\udd1d\udb13\udeea\u1a47\udb06\udca9\uda4c\udc4b\udbd9\udc69\ud864\udf25\ud8c9\udc9e",
        23, 9339, -687280095, 3485120795336025761L, 43419L, true, false, (char) 61492, (char) 52153,
        Double.longBitsToDouble(0x3fba5de46b7ba540L), Double.longBitsToDouble(0x3fe86bce074169f4L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Double:0.6121595437200903\012",
        Z.run(T, 1, 12, 6, 15, "\ud8d6\uddb9\ud920\udec1\uda9d\udd3f\ud8b2\udd4e\ud8c1\uded2\udb66\ude5e\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u23ab\u5a13\u1a0d\u820b\u9751\ubc04\u51b6\u063d\u7b0d\u714a\u921a\u6b0d\u0738\u1bce\u4edc\ub65b\uba3b\u69a5", "\ud9d3\udd1d\udb13\udeea\u1a47",
        7, 56519, 803981719, 8911944813846388064L, -81592L, true, true, (char) 60412, (char) 56215,
        Double.longBitsToDouble(0x3fe677ea7d3b27d2L), Double.longBitsToDouble(0x3f93b7b6583aae60L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Double:0.6754603265293806\0121=java.lang.Long:2426760962040300266\012",
        Z.run(T, 2, 1, 6, 7, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud8b2\udd4e\udac1\udfd2\uda52\ude86\uda31\udc52\uda5a\udeda\udb17\ude5f\udb6f\ude15\ud8c7\ude34\udadd\udfdc", "\u5a13\u1a0d\u4a50\u9751\u83e0\u3f36", "\udb4e\udf4c\ud982\udc00\uda1a\ude6f\udb7d\ude03\uda6e\udf74\udbee\udc7b\udb7d\uddc5\ud8b3\udd3c\ud8d4\udc0c\udbd7\ude43\udbb7\udf14\ud9d3\udd1d\udb13\udeea\u1a47",
        8, 56519, -1293366889, 2426760962040300266L, -43401L, false, false, (char) 12567, (char) 63792,
        Double.longBitsToDouble(0x3fee77ea7d6e27d2L), Double.longBitsToDouble(0x3f93b7b6583aae60L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Double:1.0002050884710041E-25\012",
        Z.run(T, 1, 1, 10, 15, "\ud9ec\udfcf\ud902\udcb8\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b", "\u2ca9\u1b65\u1bd2\u50e0\u7006\u23d6\u5a13\u1a0d\u820b\u9548\u4f0c\u6dce\u0684\u0fc8\u714a\u3510\u50b5\u0717\uacb1", "\udb35\ude20\ud8d4\udc57\udbd7\ude43\udbb7\udf14\ud9d3\udd1d\udb13\udeea\ud955\udc40\ud869\udd64\ud951\udf36",
        29, 28847, -919413408, 1692210056545716200L, 26002L, true, true, (char) 8138, (char) 15392,
        Double.longBitsToDouble(0x3fc195c713ea0fc0L), Double.longBitsToDouble(0x3fd7849f6a9bd3eaL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Double:0.13237869535205024\012",
        Z.run(T, 1, 10, 6, 15, "\udadd\udfb3\ud920\udec1\uda49\udfd0\uda10\udcd4\ud897\udce7\uda52\ude3b\ud951\udfd2\uda48\udd89\uc68d\ud9b5\uded7\udace\udd34", "\u42de\u5a13\ubb23\u81ec\u5af3\u5a42\u51b6", "\u5690\ud99f\udf3e\uda1a\ude6f\udb68\udf39\uda10\udec6\udbee\udd17\udb7d\uddc5\ud8b3\udd3c\ud8d4\udc0c\udafc\udec0\ud849\ude9e\ud9bf\udd13\udb13\udeea\u1a47\ud91e\udeb4\uda46\udf3a\udaa9\udf83\udb7b\uddb3\ud954\udd8e",
        48, 9528, 1432673569, 5005635337261610163L, 81631L, true, false, (char) 38636, (char) 18457,
        Double.longBitsToDouble(0x3fc0fe772b592794L), Double.longBitsToDouble(0x3fe2b2f96f0b433dL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Double:0.6360515735342949\012",
        Z.run(T, 1, 3, 16, 15, "\udadd\udfb3\ud920\udec1\uda49\udfd0\uda10\udcd4\ud897\udce7\uda52\ude3b\ud951\udfd2\uda48\udd89\uc68d\ud9b5\uded7\ubc66", "\u42de\u5a13\ubb23\u81ec", "\ud9c1\udc26\udacf\udf5a\ud9d3\udfee\u5734\ud99f\udf3e\uda1a\ude6f\udb68\udf39",
        16, 83959, -1264549321, -8381299962917357470L, -24341L, false, false, (char) 15684, (char) 47982,
        Double.longBitsToDouble(0x3fe45a88d45cc5b8L), Double.longBitsToDouble(0x3fdf253f2a435380L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Double:0.08191790922628422\012",
        Z.run(T, 1, 10, 6, 12, "\udadd\udf33\ud920\udec1\uda49\udfd0\uda10\udcd4\ud897\udce7\uda29\udd3b\ud951\udfd2\uda48\udd89\uc68d\ud9b5\uded7\uda9a\uddda", "\u42de\u5a13", "\uda46\udea6\u1747",
        49, 98830, 469833288, -3305086579793012021L, 10775L, true, false, (char) 22711, (char) 33809,
        Double.longBitsToDouble(0x3fb4fe94158b6800L), Double.longBitsToDouble(0x3f4d13e000000000L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Double:0.016594292973153728\012",
        Z.run(T, 1, 10, 6, 15, "\udadd\udfb3\ud920\udec1\uda49\udfd0\uda10\udcd4\ud897\udce7\u9b7d\ud941\udf0f\uda48\udd89\uc68d\ud9b5\uded7\uda9a\uddda", "\u42de\u5a23\ubb23\u81ec\u5af3\u5a42\u51b6\u06c7\u78f3\u7503\uac4e\u1cb8\u0eff\u10ae\u6855\ub8e1\uba3b\u69a5\u8d9d\u4efc\u11de\u2b14", "\uda46\udf47\udaa9\udf83\udaef\uddad\ud954\udd8e\ud902\udde1\udb24\udcd2\ud90a\ude29\u5ae9\udbac\udfc9\udae7\udf50",
        28, 9995, 2095169913, -884452409016299385L, 5398L, false, true, (char) 61952, (char) 1950,
        Double.longBitsToDouble(0x3f90fe4b42ca4e00L), Double.longBitsToDouble(0x3fdd8e363cd9e270L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Double:1.713633537291642E-6\012",
        Z.run(T, 1, 10, 6, 0, "\udadd\udfb3\ubec9\000\uda10\udcd4\ud996\udca9\000\000\uda47\udc23\uc68d\ud9b5\uded7\uda38\udfaa", "\u42de\u5a13\ubb23\u81ec\u5af3\u5a42\u51b6\u06c7\ub778\u3ae7\ub36a\000\000\u107c\u6855\ub8e1\u9554\u69a5\u8d9d\u4efc\uc191\u59dd", "\udbec\ude4c\000",
        18, 78336, 393998463, -6214888422580626143L, -37357L, false, false, (char) 63229, (char) 8119,
        Double.longBitsToDouble(0x3ebcc00000000000L), Double.longBitsToDouble(0x3e36b24f28000000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Double:4.799983118766228E-15\012",
        Z.run(T, 1, 1, 6, 15, "\udab7\ude77\ud94a\udf76\ud90c\udc75\udae7\udf4b\ud89d\udc9c\uda52\ude3b\ud951\udfd2\uda48\udd89\uc68d\ud9b5\uded7\uda9a\uddda", "\u42de\u5a13\ubb23\u81ec\u5af3\u5a42\u51b6\ub0d9\ua33e\uc9fe\u31ef\u787a\ud40b\u10f0\u6855\ub8e1\u623c\u3127\u8d3c\u09be\u99c0\u5c20", "\uda46\udf3a\ud952\udd57",
        33, 43436, -773793361, -6214736425624478431L, 10988L, false, false, (char) 11631, (char) 13106,
        Double.longBitsToDouble(0x3fd790c9e670f9c2L), Double.longBitsToDouble(0x3fc0fe772b592794L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Double:1.0972424965463432\0121=java.lang.Double:1.0972424965463432\012",
        Z.run(T, 2, 7, 7, 16, "\udadd\udfb3\ud920\udec1\uda49\udfd0\udb86\udccf\u728b\uda27\ude06\ud951\udf6a", "\uc872\u2816\u831b\ubd1f\u5500\u0aab\ubb23\u75c5\u680b\u6a80", "\ud9d3\udfee\u5690\ud99f\udf3e\udb8b\udee3\ud94d\ude89\udaab\uddf4\udbd0\udd81\udb7d\uddc5\ud8b3\udd3c\ud8d4\udc0c\udafc\udec0\udb68\udd4e\ud9bf\udd13\udb13\udeea\ud98c\udfe9\ud987\udc4f\ud82f\udc8b\udaa9\udf83\ud82d\udd51",
        32, 40123, -1446407780, 6153286125864064721L, -51974L, true, true, (char) 8138, (char) 3618,
        Double.longBitsToDouble(0x3fdd2ff4502eb15cL), Double.longBitsToDouble(0x3fe6b24f2829c385L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\012",
        Z.run(T, 1, 15, 13, 14, "\udadd\udfb3\ud920\udec1\ufc0b\000\000\uda52\udd93\ud951\udfd2\uda48\udd89\uc68d\ud9b5\uded7\uda9a\uddda", "\u42de\u5a13\ubb23\u81ec\u5af3\u5a42\u51b6\u06c7\ub778\u3ae7\uac4e\u1cb8\u0eff\u10f0\u6855\ub8e1\uba3b\u69a5\u7c53\u4e4b\u11de\u2b14", "\uda46\udf3a\udaa9\udf83",
        36, 78432, 393998463, -6214888422580626143L, -37357L, false, false, (char) 50685, (char) 47030,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc0fe600b592794L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Double:2.45124101589699E-5\012",
        Z.run(T, 1, 12, 11, 12, "\udadd\udfb3\ud920\udec1\uda49\udfd0\uda10\udcd4\ud897\udce7\uda52\ude3b\ud951\udfd2\uda48\udd89\uc68d\u41c6\uda71\ude37", "\u42de\u5a13", "\000",
        -5, -1000, 0, 0L, -11986L, false, false, (char) 0, (char) 46518,
        Double.longBitsToDouble(0x3ef9b40000000000L), Double.longBitsToDouble(0x3fb88000229fd280L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Integer:3\012",
        Z.run(T, 1, 5, 14, 11, "\ud8d6\udd50\ud94e\udeb8\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udad3\ude9e\ud98d\udf93\udaab\udcfe\uda5b\udc20\udbf4\uded2\uf7a0\ud94f\udf31\udae0\udca7\ud898\udc85\ud98f\udfd4\ud87e\ude8d\ud9b3\ude68\udacf\uded0", "\u1905", "\uda6e\udf74\udbee\udc7b\uda9e\udf36\ud8c2\udced\ud8d4\udc0c\udbd7\ude43",
        -3, 15634, -653022922, 5817530888567531403L, 59771L, true, true, (char) 1539, (char) 6243,
        Double.longBitsToDouble(0x3fc56bacdd73c208L), Double.longBitsToDouble(0x3fe20eabeb1060ffL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Double:0.9945624242873659\012",
        Z.run(T, 1, 0, 8, 16, "\ud8f3\udc77\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udb09\udf4f\udbac\udd22\udbf4\udf6d\uf7a0\ud94f\udf31\udae0\udca7\udbe6\udd0c\udb4d\udfd3\ud87e\ude8d\ud9b3\ude68\ud992\ude12\ud80e\udfb6\udb4e\udf4c\ud982\udc00\udada\udcaf", "\u929d\u92fb\u1d9b", "\udbb7\udf14\ud9d3\udd1d\udb13\udeea\u1a47\udb23\udea9\ua11b\udb3f\udc12\u2c1b\ud8f2\udcf8",
        15, 55195, 1874561986, 7153185151229863068L, -40911L, false, true, (char) 60935, (char) 3828,
        Double.longBitsToDouble(0x3fefca89eecdb3faL), Double.longBitsToDouble(0x3feaa5f4efe72e97L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Long:1905312490849260618\0121=java.lang.Double:0.8417298060304872\012",
        Z.run(T, 2, 6, 16, 13, "\ud8d6\udd50\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe\udbf0\udfb3\udbca\udcd2\ud80d\udec9\ud9cd\udf30\udafd\udf9a\uda7b\udc4f\uda12\ude23\ud9bb\ude3d\uda50\udc3f\ud932\udcea", "\u3510", "\uda6e\udf74",
        28, 55431, -1750081592, -1905312490849260618L, -54118L, false, true, (char) 4754, (char) 58145,
        Double.longBitsToDouble(0x3fea28a14d6028a3L), Double.longBitsToDouble(0x3feb5ada6e6ba94aL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Double:0.9092850163670605\0121=java.lang.Double:0.9092850163670605\012",
        Z.run(T, 2, 0, 16, 13, "\ud8d6\udd50\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe\u441c\udbf4\uded2\uf7a0\ud94f\udf31\udae0\udca7\ud898\udc85\ud98f\udfd4\ud87e\ude8d\ud9b3\ude68\udbdf\udc0d", "\u3510", "\udb0a\udd82",
        28, 44679, -1951408184, -409554464608825261L, 41690L, false, true, (char) 18731, (char) 30791,
        Double.longBitsToDouble(0x3fec7c5a17e59280L), Double.longBitsToDouble(0x3fea28a14d6028a3L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Double:0.860720134445585\0121=java.lang.Double:0.860720134445585\012",
        Z.run(T, 2, 1, 1, 15, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u23d6\u5a13\u1a0d\u0a22\u7b5f\u1f48\u51b6\u580a\u01b7\u714a\u64c3\u389a\u0717\u67be\u496a\u4e7c\uba3b\u69a5", "\ud85b\udce1\udabc\udfee\ud929\udf18",
        3, 56519, 803981719, 8911944812000894304L, 13729L, true, true, (char) 59457, (char) 56215,
        Double.longBitsToDouble(0x3fee7082153b27d2L), Double.longBitsToDouble(0x3fd13b7b6b968302L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Double:1.1585107243089927\0121=java.lang.Double:0.3106398592925428\012",
        Z.run(T, 2, 1, 7, 11, "\ud915\udfdc\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\uc4f2\u5a13\u1a0d\u272c\u16ea\u8490\u51b6\u5730\u01b7\u0900\u818c\u1cb8\u0717\u67be\u496a\ud7d8\uba3b\u69a5", "\ud9d3\udd1d\udb13\udeea\ud929\udf18",
        -3, 30049, 803981719, 8911944812000894304L, -81592L, true, true, (char) 60412, (char) 56215,
        Double.longBitsToDouble(0x3fee77ea7d3b27d2L), Double.longBitsToDouble(0x3fe89dbdb5cb5ef6L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Double:-2.2708617909035462\0121=java.lang.Double:0.9868811447505513\012",
        Z.run(T, 2, 11, 0, 9, "\u0080\ud8f0\udff8\ud904\udef3\ud8b2\udd4e\udafc\udfc7\uda52\ude3b\u00fc\u0566\udb17\ude06\ud98d\udf93\udaab\udcfe", "\u23d6\u5a13\u1a0d\u272c\u16ea\u00e4\u51b6\u5730\u16c0\u2145\u3b9f\u1cb8\u6b16\u67be\u496a\u4e7c\uba3b\u69a5", "\ud9d3\udd1d\udb13\udeea\ud929\udf18",
        3, 56519, 0, 8911779236716666208L, -81592L, true, true, (char) 60412, (char) 56215,
        Double.longBitsToDouble(0x3fee77ea783b27d2L), Double.longBitsToDouble(0x3fd13b7b6b968302L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Double:3.535141354707794\0121=java.lang.Long:684960834815124040\012",
        Z.run(T, 2, 1, 6, 15, "\ud8d6\uddb9", "\u23d7\u4d8c\u91b2\u720b\u9fbf\u2ca9\u1b65\u1bd2\u50e0\ub457\u23d6\u5a13\u1a0d\u272c\u16ea\u8490\u51b6\u5730\u01b7\u714a\u3510\u1cb8\u0717", "\ue764\ud8b3\udd3c\ud8d4\udc0c\udbd7\ude43\udbb7\udf14",
        -1, 42078, 448529797, 684960834815124040L, 4087L, false, true, (char) 47431, (char) 24419,
        Double.longBitsToDouble(0x3fd21a9c0da2aa58L), Double.longBitsToDouble(0x3fd209277f9dfa9eL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Double:0.0014908062478165274\0121=java.lang.Double:0.0014908062478165274\012",
        Z.run(T, 2, 0, 0, 15, "", "\u1aaa\u23d7\ubb8a", "\uda48\udd89\udb17\ude06\ud98d\udf93\udaab\udcfe\u441c\udbf4\uded2",
        34, 64239, -694222056, 3729114449718598719L, -70048L, false, true, (char) 65106, (char) 41812,
        Double.longBitsToDouble(0x3f26528000000000L), Double.longBitsToDouble(0x3fe8000007d2cc05L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Double:1.2601564675023538\0121=java.lang.Double:1.2601564675023538\012",
        Z.run(T, 2, 9, 9, 16, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud800\ude47\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u23d6\u5a13\u1a0d\u272c\u8e39\u8490\u51b6\u5730\u01b7\u714a\u3510\ub4b7\u0717\u67be\u496a\u3aee\ucde8\u69d9", "\ud9d3\udd1d\udb13\udeea\ud929\udf18",
        3, 56519, 1054448535, 8911944812000894304L, -81592L, true, true, (char) 60412, (char) 56215,
        Double.longBitsToDouble(0x3fee77ea7d3b27d2L), Double.longBitsToDouble(0x3fd13b7b6b968302L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Double:1.0029194229983927\0121=java.lang.Double:0.7442331893769478\012",
        Z.run(T, 2, 11, 12, 6, "\ud915\udc99\ud891\udc35\ud904\udef3\ud8b2\udd4e\ud900\ude8e\ud904\udc39\ud951\udf6e\uda48\udd89", "\u1bd2\u50e0\ub457\u23d6\u5a13\u1a0d\u0dfd\u3a31\u8490\u0438\u4e9d\ubd12\u80c8\u4aaf\u5dc2\u261c", "\udb62\udf60\ud8b3\udd3c\ud8d4\udc0c\udbd7\ude43\udbb5\uddb6",
        52, 95173, 443435158, 7591231563472324495L, -61449L, false, false, (char) 21767, (char) 24419,
        Double.longBitsToDouble(0x3fed77de06d1552cL), Double.longBitsToDouble(0x3fee4c93b8e16d47L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Double:5.487804936932296E-5\0121=java.lang.Double:5.487804936932296E-5\012",
        Z.run(T, 2, 1, 1, 15, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u23d6\u5a13\u1a0d\u272c\u16ea\u8490\u51b6\u5730\u01b7\u714a\u9e55\u1c06\u0717\u67be\u5c2f\u4e7c\uba3b\u69a5", "\ud9d3\udd1d",
        28, 88797, 1767471168, 900798605783976343L, 87744L, false, false, (char) 24419, (char) 1762,
        Double.longBitsToDouble(0x3fe68aa961209277L), Double.longBitsToDouble(0x3fee77ea7d3b27d2L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Double:2.2152982281508866E-99\0121=java.lang.Double:2.2152982281508866E-99\012",
        Z.run(T, 2, 1, 1, 11, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u23d6", "\udaf9\udce2\ud8a0\uddca\ud87e\udf3d\ud9b3\ude68\ud931\ude82\ud976\ude07\udb4e\udf4c\ud982\udc00\uda1a\ude6f\ud929\udd0c\ud9e6\ude82\u8a3f\udb62\udf60\ud8b3\udd3c\ud8d4\udc0c",
        59, -688, 1035872634, -2804712093079829115L, 49391L, false, true, (char) 40242, (char) 50596,
        Double.longBitsToDouble(0x3f95c95bea62e300L), Double.longBitsToDouble(0x3fd21a9c0da2aa58L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Double:3.141592653589793\012",
        Z.run(T, 1, 11, 6, 15, "\udbfa\udd8b\ud8f0\udff8\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f~\ud823\ude30", "\u23d6\u5a13\u1a0d\u820b\u0fea\u83acT\000\000\ud0a2\u3510\u00ce\000\000\u679e\ub8e1\uba3b\u69a5", "\ud9d3\udd1d\udbfa\udefd\u1a7d",
        7, 56519, 15452567, 8863084065745722720L, -81592L, true, true, (char) 22013, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Long:2316756463652826343\0121=java.lang.Long:2316756463652826343\012",
        Z.run(T, 2, 6, 6, 6, "", "\u1aaa", "\udb11\udc8a\ud951\udfd2\uda48\udd89\uda2d\udf6b\ud98d\udf93",
        -3, 97209, 499304722, 2316756463652826343L, 9804L, true, true, (char) 5539, (char) 65106,
        Double.longBitsToDouble(0x3fd234486968594aL), Double.longBitsToDouble(0x3f570cf447838600L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Double:0.3277687576065768\0121=java.lang.Double:0.3277687576065768\012",
        Z.run(T, 2, 14, 14, 0, "", "\u1aaa", "\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93",
        -5, 97346, 499304722, 2316756466790165735L, 87340L, false, false, (char) 12928, (char) 39127,
        Double.longBitsToDouble(0x3fd441c5f71b358aL), Double.longBitsToDouble(0x3feba5b433c42ca5L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\0121=java.lang.Double:NaN\012",
        Z.run(T, 2, 8, 8, 15, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud854\ude4a\ud9c4\uddcf\ud9fd\uddf4\ud951\udfd2\uda31\ude1e\ud929\ude79\udb4b\uded2\udaab\udcfe\udbe3\udedf\udbf7\udcd2\uf7a0\udb7f\udc48\udaca\udef7\udb64\udc71\ud98f\udfd4\ud87e\ude8d\ud9b3\ude68\udacf\uded0\ud9f2\ude7b\udb4e\udf4c\u0de3\ud921\udc7b\ud990\udeb5", "\ub8e1\u4d33\u6a25\ua7cf\ua421\u6cba\u8f61\ubd13\u402a\u4311\uba62\u712c\u584d\u3075\ud1ae\u9213\u1c68\u9def\u7700\u678e\u05a5\u1d33\u242c\ua1b6\uc92c\u6f71\u4d65\ub440\u0700\u4b71\u1ce7\u0f87\ua571\u829f\u9335\u197d\ucafd\u7d21\uc710\u93b3\u0751\u45d0\u4875", "\ud815\udd18\uda94\udc58\ud9cb\udc01\udb70\udc6f\ud92d\uddc7",
        38, 31618, -1429570818, 1659946454522794860L, -22032L, true, false, (char) 35895, (char) 56671,
        Double.longBitsToDouble(0x3fe2a7c90158a314L), Double.longBitsToDouble(0x3fd48c9fb407bef2L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Integer:38\0121=java.lang.Integer:38\012",
        Z.run(T, 2, 5, 5, 15, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud86d\udd4a\ud9c4\uddcf\ud83f\uddf5\ud951\udfd2\uda31\ude1e\ud929\ude79\udb4b\uded2\udaab\udcfe\udbe3\udedf\udbf7\udcd2\uf7a0\ud96c\ude5e\udaca\udf49\udb64\udc71\ud98f\udfd4\ud87e\ude8d\ud9b3\ude68\udacf\uded0\ud9f2\ude7b\udb4e\udf4c\u0de3\ud921\udc7b\ud990\udeb5", "\ud79b\u4d54\u6a25\ua7cf\ua421\u6cba\u8f61\ubd13\u152e\u4311\u9e88\u712c\u584d\u3075\ud1ae\u9213\u1c68\u9def\u7700\u678e\u05a5\u82d4\u5424\ua1b6\uc92c\u6f71\u4d65\u2c10\u3ce6\u4b71\u6c4f\u5eab\ua571\u829f\u9335\u197d\ucafd\u7d21\uc710\u93b3\u0751\u45d0\u4875", "\ud866\udc61\ud9c8\ude83\ud8fa\udcf9\udb70\udc0a\ud92d\uddc7",
        38, 31618, -1429570818, 1659946454522794860L, -22032L, true, false, (char) 35895, (char) 56671,
        Double.longBitsToDouble(0x3fe2a7c90158a314L), Double.longBitsToDouble(0x3fd48c9fb407bef2L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Double:0.7400370177737439\0121=java.lang.Double:0.7400370177737439\012",
        Z.run(T, 2, 3, 3, 9, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud854\ude4a\ud8e2\udee6\uda47\ude7e", "\u24cd\u4e51\u1bd2\u73a3\ube57\u74d4\004\u17ad\u6c31\u9751\u83e0\u51b6\u063d\u2dc9\u714a\uc686\u4ace\u4f68\u7c4d", "\uda6f\udfb9\ud8d4\udc8c\ud8bd\udd16\udb9d\udda1\uf4d2\ud8e3\udcd8\u1a26\udb06\udca9\ud907\udcc9\udbd9\udc69\udb7b\udde0\uda51\udc95\ud82d\ude0a\uda4f\udf39\udbe2\ude25\uda91\udde6\ud982\udcf7\udb10\ude26\ud9ac\udcf8\ud817\udd91\uda6e\udc53\ud869\udd70\ud896\ude01\ud9fd\udf74\uda30\udc67\udba1\udf74\udae6\udc08\ud8c3\udd93\udad0\udc62\ud84f\udc98\udaa7\ude00\ud911\udc73\udb88\udc2a\udad4\udf69\udbd0\udf47\udb42\udeb4\ud8cf\udde8",
        30, 89021, 2105469588, 215242893817398606L, -20435L, true, false, (char) 21140, (char) 32930,
        Double.longBitsToDouble(0x3fe7ae621ca55cfcL), Double.longBitsToDouble(0x3fd17133e2b45ce6L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Double:2.0050487489134667\0121=java.lang.Double:2.0050487489134667\012",
        Z.run(T, 2, 1, 1, 0, "\ud8d6\uddb9\ud999\udc5c\ud9ee\udc23\u803e\udad0\ude7f\ud9fd\udda2\ud951\udfd2\uda31\ude1e\ud929\ude79\udabc\udf92\udabb\udd74\ud8de\udc15\ud97a\udcea\ucf0d\udbb1\ude7e\udaa4\udfcd\udb64\udc71\ud98f\udfd4\ud87e\ude8d\ud9b3\ude68\udacf\uded0\ud9f2\ude7b\udb4e\udf4c\u0de3\ud921\udc7b\ud990\udeb5", "\ub8e1\u4d33\u6a25\ua7cf\u9590\u808c\u8f61\ubd13\u152e\u4311\uba62\u712c\u584d\u3075\ud1ae\u9213\u1c68\u3726\u7700\u678e\u0134\u82d4\ud4b5\ua1b6\uc92c\u6f71\u4d65\u6165\u2bd4\u4b71\u6c4f\u5eab\ua571\u829f\u9335\u197d\ucafd\u7d21\uc710\u93b3\u0751\u45d0\u4875\ud0de", "\uda94\udc58\ud9cb\udc01\ud9f8\udc34\uda6a\ude46\udb15\udfd3\ud97a\ude9e\ud9d3\uddf8\uda0c\udddc\udaba\ude05\u0964\udbdf\udca4\udb75\udfc4\uda4f\uddaf\ud922\udc4c\ud88b\udcda\uc629\ud8fd\udf5d\ud888\ude90\ud8b5\udcdb\ud9af\ude1a\ud9d7\udd03\udb42\udd7c\ud826\udebe\udb22\ude74\ud959\ude54\udad7\udc7e\ud95c\udeb3\ud984\udddd\ud96e\udead\ud8d2\uddee\udaaf\udfd4\uda6a\udddb\ud95e\udebd\udbc1\udf61\uda9f\udc24\uda0c\udfc9\ud944\ude74\udab9\udc11\ue1ce\udb8d\udc27\ud8b8\ude0b\ud89c\udedc\ud971\udc04\udaf5\ude66\udbe7\udf1a\udb9c\udf2e\udb39\udca8\ud8aa\ude24\ud90b\uddc2\ud961\udf50\ud87d\udc7c\ud849\udccc\uda0d\ude55\uda2c\udf6a\udbaa\udd51\uda01\udf41\udb7b\udc6b",
        -1, 50959, 1983879678, -7522110737851504114L, 33680L, false, true, (char) 27856, (char) 19505,
        Double.longBitsToDouble(0x3fdfeb5f555c43b2L), Double.longBitsToDouble(0x3fe578b5ec94a363L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\012",
        Z.run(T, 1, 9, 10, 15, "\u0080\ud8f0\udff8\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u2ded", "\000\ud98f\udfd4\u2434\ud9b3\ude68\024\u61acD\ud982\udc00\uda1a\ude6f\udb7d\ude03\uda6e\udf74\uda22\udc75\000\ud8b3\udd25\ud8d3\udfaa",
        9, -688, 1035872634, 5534075305330053L, 4087L, false, true, (char) 61510, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e4f3bf53c000000L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\012",
        Z.run(T, 1, 16, 10, 0, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2", "\u1b65\u1bd2", "\uf7a0\ud94f\udf31\udae0\udca7\ud898\udc85\000\ud87e\ude8d\ud9b3\ude68\024\u61ac\udb4e\udf4c\ud982\udc00\uda1a\ude6f\udb7d\ude03\uda6e\udf74\udbee\udc7b\000\ud8b3\udd25",
        50, 59419, 1028584312, 4449038561866656054L, 41195L, true, true, (char) 54806, (char) 12418,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fef40bbdd21a9c0L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\012",
        Z.run(T, 1, 13, 6, 15, "\000", "\u23d7\u4d8c\u91b2\u720b\u0566\000\u64e6\u1bd2\u29cb\ub457\u23d6\u14e8\000\u8135", "\ud9b3\ude68\u5314\000\000\000\ud86a\uded4\ud8ef\udf2a\uda79\udd9c\udbee\udc7b\udb7d\uddc5\ud8b3\udd3c\ud9cc\udc07",
        21, -620, 1031612794, -2804712093509876347L, -57416L, true, false, (char) 12937, (char) 31501,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd000000da2aa58L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\012",
        Z.run(T, 1, 3, 16, 15, "\udadd\udfb3\ud920\udec1\uda49\udfd0\uda10\udcd4\ud897\udce7\uda52\ude3b\ud951\udfd2\uda48\udd89\uc68d\ud9e1\udecd\ubc66", "\u42de\u14e8\u725e\u81ec", "\ud85d\ude20",
        20, 75656, -769525272, 5442037200472856526L, -100000L, true, false, (char) 33388, (char) 22711,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe000000000e89fL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\012",
        Z.run(T, 1, 12, 0, 0, "\udadd\udfb3\ubec9\000\uda10\udcd4\ud996\udca9\000\000\000\000\000\u00a3", "\u42de\u5a13\u0b23\u00b7\000\u42fb\u2854\u0629\ua130D\000\000\000\u028f\000\000\u9554\u69a5\000\000\u297a\000", "\udbec\ude4c",
        -5, -1000, 0, 0L, -100000L, false, false, (char) 46848, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fcac93cb247ce44L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Double:0.08882428027241274\0121=java.lang.Double:1.5707963267948966\012",
        Z.run(T, 2, 15, 13, 16, "\ud9d8\udd58\ud93b\udead\udb08\udf3a\uda9d\udcbd\ud996\udca9\ud945\ude71\000\uda47\udc23\uc68d\uda6c\ude33\udb34\udec2\ud85d\udfae\uda81\udcad\udb04\udfd3\ud94f\udf31\u6525\ud898\udc66\uda46\udea6\udb1d\udfd2\ud9b3\ude68\udacf\udf5a\ud9d3\udfee\u5690", "\000\u107c", "\udb74\udd1a\udb28\ude76\ud8f1\udcd7\ud92c\udd50\ud967\ude65\udae9\ude8f\u1a47\ud91e\udeb4\udbec\ude4c",
        -5, 63128, -1087185664, 1682077661758769128L, 94001L, true, false, (char) 48306, (char) 50941,
        Double.longBitsToDouble(0x3f46f6c00001cc00L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Double:0.5127861386396033\0121=java.lang.Double:0.019701186914641337\012",
        Z.run(T, 2, 11, 12, 0, "\udadd\udfcf\ubec9\000\uda10\udcd4\ud996\udca9\000\000\uda47\udc23\uc68d\ud9b5\uded7\uda38\udfaa", "\u42de\u5a13\ubb23\u81ec\ub38a\u5a42\u51b6\u06c7\ub778\u3ae7\ub36a\000\000\u4f01\u114d\u7171\u9554\u69a5\u8d9d\u4efc\uc191\u59dd", "\udbec\ude4c\000",
        18, 30976, 393998463, -6214888422580626143L, 81631L, false, false, (char) 38705, (char) 0,
        Double.longBitsToDouble(0x3f942d375ad89ba0L), Double.longBitsToDouble(0x3fe162c69e437c8eL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Float:0.0\012",
        Z.run(T, 1, 4, 0, 5, "\ud986\ude48\u0551\000\uda10\udcd4\ud996\udca9\ud857\udc3c\uda8f\ude5e\uda13\udc88\uc65f\udb8b\udf22\ud856\ude2b", "\u01a5\u29a5\uc0ba\u81ec\u39e9\u5aa1\u51b6\u06c7\ub778\u3ae7\ub36a\ua235\000\u107c\u6855\u1a49\uc268\u6a0f\u6299\u4f08\uc191\u59e8", "\udb3c\udc1d",
        20, 98988, -182590304, -2605423576626438341L, 58101L, true, true, (char) 8031, (char) 49818,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe6b24f292fb217L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Double:1.5707963267948966\0121=java.lang.Double:1.5707963267948966\012",
        Z.run(T, 2, 7, 7, 16, "\000\ud920\udec1\uda49\udfd0\udb4c\udc86\u728b\uda27\ude06\ud951\udf6a", "\uc872\u2816\u831b\ubd1f\u5500\u0aab\ubb23\u75c5\u680b\u6a80", "\ud9d3\udfee\u5690\udbc6\uded2\udaef\ude77\ud94d\ude89\udaab\uddf4\udbd0\udd81\udb7d\uddc5\ud8b3\udd3c\ud8d4\udc0c\udafc\udec0\udb68\udd4e\ud9bf\udd13\udb13\udeea\ud98c\udfe9\ud987\udc4f\ud82f\udc8b\udaa9\udf83\ud82d\udd51",
        32, 40123, 156, 1165465297L, -61107L, false, false, (char) 39191, (char) 174,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe2fba24174ad2bL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Double:0.8491866350522572\0121=java.lang.Double:0.9847660934100074\012",
        Z.run(T, 2, 10, 15, 3, "\udadd\udfb3\ud920\udec1\ufc0b\udb8c\udd4b\uda3e\udc05\ufa4b\ud951\udfd2\uda48\udd89\uc68d\ud9b5\uded7\ud91b\udd5c", "\u52a8\u7f4f\ubb23\u81ec\u5af3\u5a42\u51b6\u06c7\u8079\u3ae7\uac4e\u1cb8\u0eff\u10f0\u6855\ub8e1\uba3b\u2fa7\u21f4\u2ad5\u11de\u2b14", "\uda46\udf3a\udaa9\udf83",
        36, 78432, 393998463, -6235162319117248763L, -37357L, false, false, (char) 38056, (char) 37133,
        Double.longBitsToDouble(0x3fee8f4933f7d636L), Double.longBitsToDouble(0x3fe0f4f7fd10c8d1L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:1.5707963267948966\012",
        Z.run(T, 2, 14, 7, 11, "\ud915\udfdc", "\u23d7\u4d8c\u91b2\u720b\u9fbf\u2ca9\u1b65\ua75f\u3d6e\u5dcc\uc4f2\u592c\u1a0d\u0c72?\000\000\uab8d\u01b7\u0900\u818c\u1cb8\u0717", "\udadd\udd58\ud8b3\udd3c\ud8d4\udc0c\udbd7\ude43\udbb7\udf14",
        -1, 42078, 436207749, 206453374413473961L, 4087L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Double:0.774376427089556\0121=java.lang.Double:0.774376427089556\012",
        Z.run(T, 2, 11, 11, 16, "\ud915\udfdc\uda34\uddcc\ud968\uddff\ud8a4\udfae\ud8c1\uded2\uda52\ude3b\udb45\udfcc\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\uc4f2\ud51d\uc979\ub776\u6bcf\u944f\u51b6\u5730\ud5aa\u870e\ud32e\uac4b\u06e0\u4369\ucb5d\u52c1\ubb20\u69a5", "\udb00\ude94\udaa0\udfe7\u6604",
        -3, 30049, 803949950, 8911944811211447648L, -47861L, false, false, (char) 2933, (char) 21000,
        Double.longBitsToDouble(0x3fd72e4cdb79420eL), Double.longBitsToDouble(0x3fe89dbdb3e137f6L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Long:2981661025348297770\0121=java.lang.Long:2981661025348297770\012",
        Z.run(T, 2, 6, 6, 6, "", "\uaa30", "\udb11\udc8a\ud951\udfd2\uda48\udd89\uda2d\udf6b\ud98d\udf93\udaab\udcfe\u441c",
        2, 47907, -1625428761, -2981661025348297770L, 76452L, false, false, (char) 35674, (char) 39127,
        Double.longBitsToDouble(0x3feab0e2fa01c175L), Double.longBitsToDouble(0x3fa1a27747aae270L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Integer:5\0121=java.lang.Integer:5\012",
        Z.run(T, 2, 5, 5, 15, "\000", "\ub4db\u4988\u3d03\ub50a\uab01\u24cd\u4e51\u1bd2\u73a3\ube57\u23d6\ub2d6\u17ff\u6c31\u9751\u83e0\u51b6\u063d\u2dc9\u714a\uc686\u4ace\u4f68", "\u6933\uda6f\udfda\ud8d4\udc8c\udbd7\ude43\udbb7\udf14\uf4d2\ud8e3\udcd8\u1a26\udb06\udca9\ud907\udcc9\ud82c\udfd3\ud8bb\udea1\ud98b\udd09\ud874\udece\udb26\uded2\udbe2\ude25\uda91\udde6\ud982\udcf7\udb10\ude26\ud9ac\udcf8\ud817\udd91\uda6e\udc53\udb4d\udf38\ud896\ude01\ud9fd\udf74\uda30\udc67\udba1\udf74\udae6\udc08\ud8c3\udd93\udad0\udc62\ud84f\udc98\udaa7\ude00\ud81b\udc77\udb79\udd23\udad4\udf69\udbd0\udf47\udb42\udeb4\ud8cf\udde8\ud985\uddc3\udac4\udc7f\ud908\uddf9\ud808\ude73\000",
        -5, 71576, -1527806529, 4363019307588578842L, 71008L, true, true, (char) 63436, (char) 2239,
        Double.longBitsToDouble(0x3fc035594db05c24L), Double.longBitsToDouble(0x3fda270000e17006L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Double:0.41585537966893543\0121=java.lang.Double:0.41585537966893543\012",
        Z.run(T, 2, 13, 13, 16, "\ud9d8\udd58\ud93b\udead\udb08\udf3a\uda9d\udcbd\ud996\udca9\uda4c\udd54\uda2e\uddb8\uda47\udc23\uc68d\uda6c\ude33\udb34\udec2\ud85d\udfae\uda81\udcad\udb04\udfd3\ud94f\udf31\u6525\ud898\udc66\uda46\udea6\udb1d\udfd2\ud9b3\ude3e\udacf\udf5a\ud9d3\udfee\u5690", "\000\u107c", "\udb9c\udf2f\udb28\ude76\ud8f1\udcd7\ud92c\udd50\ud967\ude65\udae9\ude8f\u1a47\ud91e\udeb4\udbec\ude4c\000\ud8bb\ude0a\ud954\udd2e\ud87e\ude19\udb26\uded2\ud8ea\ude2c\uda81\uddf2\udb99\udd4b\uda3f\udc7c\ud9ac\udd3c",
        54, -1000, 0, 4359853873463298729L, 29363L, false, true, (char) 49229, (char) 46598,
        Double.longBitsToDouble(0x3fda6d5522829544L), Double.longBitsToDouble(0x3fedebd730c5189dL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Double:0.08882428027241274\0121=java.lang.Double:0.08882428027241274\012",
        Z.run(T, 2, 15, 15, 16, "\ud9d8\udd58\ud93b\udead\udb08\udf3a\uda9d\udcbd\udbbd\udc3d\ud945\ude71\000\uda61\udf23\uc68d\uda6c\ude33\udb34\udec2\ud85d\udfae\uda81\udcad\udb04\udfd3\ud94f\udf31\u6525\ud898\udc66\uda46\udea6\udb1d\udfd2\ud9b3\ude68\udacf\udf5a\ud9d3\udfee\u5690", "\000\u107c", "\udb74\udd1a\ud999\udd2c\ud8f1\udd29\ud825\udc9b\ud967\ude65\udae9\ude8f\u1a47\ud91e\udeb4\ud8da\udcc2",
        35, 63128, -1087185664, 1682077661758769128L, 94001L, true, false, (char) 48306, (char) 50941,
        Double.longBitsToDouble(0x3f46f6c00001cc00L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Double:0.5656202245226223\0121=java.lang.Double:0.5656202245226223\012",
        Z.run(T, 2, 10, 10, 10, "\ud9d8\udd58\ud93b\udead\ud816\ude40\udaac\uddc5\ud877\udf41\ud951\udc6a\u1abe\ud96a\ude34\u79f8\udad3\udf31\udb68\udebc\ud85d\udfae\uda81\udcad\udb04\udfd3\ud94f\udf31\ud90f\udcde\ueea3\uda72\udf40\ud89e\udd8a\ud8a6\ude31\udb7a\udc19\ud9d3\udfee\u5690\udbc6\uded2\udb6d\udc0e\000\uda0d\udc52\uda46\uddd6\udb7d\uddc5\udb44\udc40\udb28\ude5e\ud8f1\udcd7\ud837\ude7d\ud952\udfaa\udbb5\udc79", "\ud285\000", "\ud87e\ude19\udb26\uded2",
        2, 47429, 2018289205, 107880119109010815L, -91350L, true, true, (char) 18121, (char) 1244,
        Double.longBitsToDouble(0x3fe3149c0b8c2fdeL), Double.longBitsToDouble(0x3fe732dd0c8096feL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Double:0.1608539498862503\0121=java.lang.Double:0.1608539498862503\012",
        Z.run(T, 2, 10, 10, 14, "\udadd\udfb3", "\u46f6\u9054\u1204\u720b\u9fbf\u6037\u4340\u5b6e\u4ae2\ubd1f\u52a8\u7f4f\ubb23\u81ec\u5af3\u5a42\u51b6\u06c7\u8079\u3ae7\uac4e\u1cb8\u0eff", "\udb7d\uddc5\ud8b3\udd3c\udbbb\udebc\udbf6\udd0e\uda49\udc6d",
        9, 20150, 1353664390, 3865539331111426634L, -96031L, false, false, (char) 16509, (char) 55937,
        Double.longBitsToDouble(0x3fc4ad9f1199e130L), Double.longBitsToDouble(0x3fe9501c366c6aa1L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Double:-2.267937920840982\0121=java.lang.Double:-2.267937920840982\012",
        Z.run(T, 2, 11, 11, 16, "\ud915\udfdc\uda34\uddcc\ud968\uddff\ud8a4\udfae\ud97c\ude6f\uda45\udf7a\udb45\udfcc\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\uc459\ud51d\uc979\ub776\u6bcf\u944f\u51b6\u5730\ud5aa\u870e\ud32e\uac4b\u06e0\u4369\ucb5d\u52c1\ubb20\u69a5", "\uda85\ude96\ud907\udde6\u12e9",
        31, 30049, 803949950, 8911944814634179680L, 9948L, true, false, (char) 45631, (char) 26307,
        Double.longBitsToDouble(0x3fe89dbdb3e137f6L), Double.longBitsToDouble(0x3fe1871e2ab6462dL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Double:1.5707963267948966\0121=java.lang.Double:1.5707963267948966\012",
        Z.run(T, 2, 13, 13, 16, "\ud9d8\udd58\ud93b\udead\udb08\udf3a\uda9d\udcbd\ud996\udca9\uda4c\udd54\uda2e\uddb8\uda47\udc23\uc68d\uda6c\ude33\udb34\udec2\ud899\udd14\uda81\udcc3\udb04\udfd3\ud94f\udf31\u6525\ud898\udc66\uda46\udea6\udb97\udfcf\ud9b3\ude3e\udacf\udf5a\ud9d3\udfee\u5690", "\ub407\u107c", "\udb9c\udf2f\udb28\ude76\ud8f1\udcd7\ud92c\udd50\ud967\ude65\udae9\ude8f\u1a47\udb52\udf52\uda0a\udd43",
        38, 5595, 1363003483, -299763898091812888L, 94001L, true, false, (char) 48306, (char) 50941,
        Double.longBitsToDouble(0x3fc3b6f6c00001ccL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Double:0.03829317511396512\0121=java.lang.Double:0.03829317511396512\012",
        Z.run(T, 2, 10, 10, 10, "\ud9d8\udd58\ud93b\udead\ud816\ude40\udaac\uddc5\uda79\udf42\ud951\udc6a\u1abe\ud96a\ude34\u79f8\udad3\udf31\udb68\udebc\ud85d\udfae\uda81\udcad\udb04\udfd3\ud94f\udf31\ud90f\udcde\ueea3\uda72\udf40\ud89e\udd8a\ud8a6\ude31\udb7a\udc19\ud9d3\udfee\u5690\udbc6\uded2\udb6d\udc0e\000\uda0d\udc52\uda46\uddd6\udb7d\uddc5\udb70\udffc\udb28\ude5e\ud8f1\udcd7\ud837\ude7d\ud952\udfaa\udbb5\udc79", "\ud300\000\u9ecd\ud048\u9c63\ud1ae\u84f0\u9861\u54c9\u362c\uaae8\u7bd2\u8a31\ub70e\u30d2\u74c7\u7b1e\uc025\u6271\ubccc\u5d6e\u17a3\u38bb\uc180\u91bc\u51af\u308b\u7e5c\u6f38\u62e6\u3ae5\u4e70\ua32b\u4776\u66ad\u49f6\u63bf", "\ud9ec\uddc2\uda8e\udd46\uda33\ude97\ud865\udcfa\ud92d\udd64\ud855\udde7\udada\ude63\udbc1\udefc\ud8b5\udd91\udb5a\udc6e\udbe1\udf08",
        21, 79218, -1647047627, 4902057835153468026L, 95209L, false, false, (char) 54291, (char) 37568,
        Double.longBitsToDouble(0x3fa39c63c9932b80L), Double.longBitsToDouble(0x3fedb310dff8d9c0L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Double:9.414056210918484E-4\0121=java.lang.Double:9.414056210918484E-4\012",
        Z.run(T, 2, 10, 10, 10, "\ud9d8\uddd1\ud93b\udead\ud816\ude40\udaac\uddc5\ud877\udf41\ud951\udc6a\udba8\udeae\ud96a\udec1\u79f8\udad3\udf31\udb68\udebc\ud85d\udfae\uda81\udcad\udb04\udfd3\ud94f\udf31\ud90f\udcde\ueea3\uda72\udf40\ud89e\udd8a\ud8a6\ude31\udb7a\udc19\ud9d3\udfee\u5690\udbc6\uded2\udb6d\udc0e\000\uda0d\udc52\uda46\uddd6\udb7d\uddc5\udb44\udc40\udb28\ude5e\ud8f1\udcd7\ud837\ude7d\ud952\udfaa\ud94e\udc2e", "\ud285", "\ud9d6\udd2f",
        50, 9528, -342407903, 160710930840987189L, 16095L, true, true, (char) 10386, (char) 22717,
        Double.longBitsToDouble(0x3f4ed91579ddf800L), Double.longBitsToDouble(0x3fe3149c0b8c2fdeL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Long:8911917500303859040\012",
        Z.run(T, 1, 6, 6, 15, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u23d6\u5a13\u1a0d\u820b\u9751\u442b\ub3d6\u0648\u7b0d\u714a\u3510\u1cb8\u0717\uacb1\u67b9\ub8e1\uba3b\u69a5", "\ud9d3\udd1d\udb13\udeea\u1a47",
        7, 56519, -1712600681, 8911917500303859040L, -81592L, true, true, (char) 60412, (char) 56215,
        Double.longBitsToDouble(0x3fee77ea7d3b27d2L), Double.longBitsToDouble(0x3f93b7b6583aae60L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Double:0.5455838450943882\0121=java.lang.Double:0.5455838450943882\012",
        Z.run(T, 2, 12, 12, 11, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udad7\udf37\ud93e\udd2b\ud884\udff4", "\u23d6\u5a13\u1a0d\u2e75\u9b3a\u8e9e\u51b6\u063d\u7b0d\u8713\u5f12\u69ea\u1e4d\u1a72\u67b9\ub8e1\uba3b", "\ud94f\udf60\ud9d3\udd1d\udb13\udeea\u1a47\udb06\udca9\uda4c\udc4b\udb33\udc16\ud9e7\uddfc\u9381",
        45, 98185, 137125153, -3236547020549306011L, 81563L, true, false, (char) 61492, (char) 58869,
        Double.longBitsToDouble(0x3fe36cea7ae17125L), Double.longBitsToDouble(0x3fed004171f5e5e9L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Double:0.2081610055177737\0121=java.lang.Double:0.2081610055177737\012",
        Z.run(T, 2, 1, 1, 10, "\ud938\udc55\ud920\udec1\ud904\udef3\ud8b2\udd4e\udb90\udea4\udb1e\udcd3\ud951\udfd2\uda48\udd89\udb17\ude12\ud98d\udf93\udaab\udcfe", "\uc4f2\u7ae7\u6d08\ubbcd\ud436\u83fa\u51b6\u077d\u7832\u6d9c\u3d3b\u7f5c\u3bfe\u6dab\u496a\ud7d8\uba3b\u7c6e", "\ud9d3\udd1d\uda6b\udc16\ud852\ude69",
        32, 77439, 803981719, 8909374153818237280L, -81592L, true, true, (char) 39367, (char) 19430,
        Double.longBitsToDouble(0x3fee77ea7d3b27d2L), Double.longBitsToDouble(0x3fd95b7b6b2a35a0L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 11, 12, 0, "\udadd\udfcf\ubec9\000\uda10\udcd4\ud996\udca9\000\000", "\uc872", "\ud838\udc14\ud8c9\udcc6",
        -5, 6942, 1333582775, 4353393076157284352L, -100000L, false, false, (char) 5445, (char) 44268,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe00000038e6978L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Double:0.01809668189959607\0121=java.lang.Double:0.01809668189959607\012",
        Z.run(T, 2, 10, 10, 14, "\udadd\udfb3", "\u46f6\u9054\u1204\u720b\u9fbf\u6037\u4340\u5b6e\u4ae2\ubd1f\u52a8", "\uda0f\udc2a\udaa4\udc63\ud8a4\udeec\ud88e\udd04\ud87d\udc37\uda31\udd49\udbd2\udc0c\ud99f\udf3e\uda1a\ude6f\udb68\udf39",
        56, 62351, -756483676, -8361877296300466584L, 36665L, true, false, (char) 65517, (char) 47134,
        Double.longBitsToDouble(0x3f9288320d565620L), Double.longBitsToDouble(0x3fd60ea000ff7e64L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 0, 16, 13, "\ud8d6\udd50\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\u1f59\000\udaab\udcfe\u441c\udbf4\uded2\uf7a0\ud94f\udf31\udae0\udca7\ud898\udc85\ud98f\udfd4\ud87e\ude8d\ud9b3\ude68\udbdf\udc0d", "\u3510", "\udb0a\udd82",
        28, 44679, -1951408184, -409554464608825261L, 41690L, false, true, (char) 18731, (char) 30791,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fea28a0056028a3L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Float:0.9512339\0121=java.lang.Float:0.9512339\012",
        Z.run(T, 2, 4, 4, 0, "\ud8d6\uddb9\ud920\udec1\ud904\udef3\ud8b2\udd4e\ud8c1\uded2\ud80a\ude37\ud951\udfd2\uda48\udd89\udb17\ude5f\ud98d\udf93\udaab\udcfe", "\u23d6\u5a13\u1a0d\u0a22\u7b5f\u1f48\u51b6\u580a\u01b7\u714a\u7723\u799f\u06ac\u67be\u496a\u4e7c\uba3b\u69a5", "\ud85b\udce1\udabc\udfee\ud8c2\udc64",
        40, 56519, 803981719, 8911944812000894304L, 13729L, true, true, (char) 59457, (char) 56215,
        Double.longBitsToDouble(0x3fee7082153b27d2L), Double.longBitsToDouble(0x3fd13b7b6b968302L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Double:3.141592653589793\0121=java.lang.Double:3.141592653589793\012",
        Z.run(T, 2, 11, 11, 15, "\udbc4\udc03\ud981\ude11\ud8d9\udca5\ud8b2\udd4e\ud8c1\uded2\uda52\ude3b\ud951\udfd2\uda48\udd89\udb17\ude5f~\ud823\ude30", "\u23d6\u5a13\u1a0d\u820b\u0fea\u83acT\000\u3bda\u98c3\u5171\u6c44\000\000\u679e\ub8e1\uba3b\u69a5", "\ud9d3\udd1d\udbfa\udefd\u1a7d",
        7, 56519, 15452567, 8863084065745722720L, -81592L, true, true, (char) 22013, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 9, 9, 16, "\000\ud920\udec1\uda4a\udc0b\udb4c\udc86\u728b\uda27\ude06\ud951\udf6a", "\uc872\u2816\u831b\ubd1f\u5500\u0aab\ubb23\u75c5\u680b\u6a80", "\ud9d3\udfee\u5690\udbc6\uded2\udaef\ude77\ud94d\ude89\udaab\uddf4\udbd0\udd81\udb7d\uddc5\ud8b3\udd3c\ud8d4\udc0c\udafc\udec0\udb68\udd4e\ud9bf\udd13\udb13\udeea\ud98c\udfe9\ud987\udc4f\ud82f\udc8b\udaa9\udf83\ud82d\udd51",
        32, 40123, 156, 1165465297L, -61107L, false, false, (char) 39191, (char) 174,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe2fba24174ad2bL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Double:0.999018173229918\0121=java.lang.Double:0.999018173229918\012",
        Z.run(T, 2, 0, 0, 7, "\uda39\udd3b", "\u2e56\u8d28\u0b69\u717e\u9fbf\u2c50\u1b65\u1bd2\u50e0\ub457\u23d6\u5a13\u1a0d\u272c\u16ea\u8490\u51b6\000\u00db\u714a\u3510\u1cb8\000\000\u4965\uc768\u6e87\u03b8\u1aeb\u0b63\u3659\u061f\u87a5\ucb95\uc4a7\u42b2\u13e1\u7502\u40b0\ub92c\u0d95\u41b7\ua2ef\u578f\u797f\uc667\u53bc\ub9b6\u0a0a\ua7c0\u6f97", "\ud9f6\udd4d\ub1cb\ud80e\udcf4\udb2b\udcbe\ud95f\ude95",
        5, 9373, 1519070896, 4345800448993096638L, 68160L, false, false, (char) 64504, (char) 27205,
        Double.longBitsToDouble(0x3fefdd9a8693980dL), Double.longBitsToDouble(0x3fcde20212c6bcc4L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 13, 13, 16, "\ud9d8\udd58\ud93b\udead\udb08\udf3a\uda9d\udcbd\ud996\udca9\uda4c\udd54\uda2e\uddb8\ud87b\ude5c\udb78\udcd1\uda69\udeed\udb34\udec2\udb12\udc2c\uda86\udf63\udb04\udfd3\ud94f\udf31\u6525\ud898\udc66\uda46\udea6\udb97\udfcf\ud9b3\ude3e\udacf\udf5a\ud9d3\udfee\u5690", "\ub407\u107c", "\udb9c\udf2f\udb28\ude76\ud8f1\udcd7\ud92c\udd50\udb1d\ude60\ud9bd\uddd8\udab1\udc11\udb52\udf52\uda0a\udd43",
        38, 92003, -2047183842, -3456248961025698250L, 45793L, false, true, (char) 64319, (char) 10816,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd4630ac7b1b114L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 15, 15, 16, "\ud9d8\udd58\ud93b\udead\udb08\udf3a\uda9d\udcbd\udbbd\udc3d\ud945\ude71\000\uda61\udf23\uc68d\ud886\udec4\udb34\udec2\ud85d\udfae\uda7f\udfdf\udb04\udfd3\ud94f\udf31\u6525\ud94e\udca1\uda7a\udcbf\udb1d\udfd2\ud9b3\ude68\udacf\udf5a\ud9d3\udfee\u5690", "\000\u107c", "\udb74\udd1a\ud999\udd2c\ud8f1\udd29\ud825\udc9b\ud967\ude65\udae9\ude8f\u1a47\ud91e\udeb4\ud8da\udcc2",
        35, 63128, -1087185664, -7788710878034706024L, -65810L, false, true, (char) 8119, (char) 115,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe9dc97822f67fdL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 3, 3, 16, "\000\ud920\udec1\uda49\udfd0\udb4c\udc86\u728b\uda27\ude06\ud951\udf6a", "\uc872\u2816\u831b\ubd1f\u5500\u0aab\ubb23\u75c5\u680b\u6a80", "\ud9d3\udfee\u5690\udbc6\uded2\udaef\ude77\ud94d\ude89\udaab\uddf4\udbd0\udd81\udb7d\uddc5\ud8b3\udd3c\ud8d4\udc0c\udafc\udec0\udb68\udd4e\ud9bf\udd13\udb13\udeea\ud98c\udfe9\ud987\udc4f\ud82f\udc8b\udaa9\udf83\ud82d\udd51",
        17, 13056, 156, 1165465297L, -61107L, false, false, (char) 39191, (char) 174,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe2fba24174ad2bL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Float:0.0\0121=java.lang.Float:0.0\012",
        Z.run(T, 2, 4, 4, 15, "\udadd\udfb3\ubec9\000\uda10\udcd4\ud8f2\udf2d\000\u6a00\000\000\000\u00a3\udb92\udc99\ud838\udc14\ud9f4\ude4a\uda18\udcb5\u244d\udb90\udcbe\000\udb18\udc8b\u2854\ud9c2\ude96\udbc6\udfa9", "\000", "\000",
        -5, -272, -95356830, 70087269216505891L, -24480L, false, false, (char) 50, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe0000006b9f6a4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.util.FastMath|pow|double,double|static",
    "M|org.apache.commons.math3.util.FastMath|pow|double,int|static",
    "M|org.apache.commons.math3.util.FastMath|IEEEremainder|double,double|static",
    "M|org.apache.commons.math3.util.FastMath|abs|double|static",
    "M|org.apache.commons.math3.util.FastMath|abs|float|static",
    "M|org.apache.commons.math3.util.FastMath|abs|int|static",
    "M|org.apache.commons.math3.util.FastMath|abs|long|static",
    "M|org.apache.commons.math3.util.FastMath|acos|double|static",
    "M|org.apache.commons.math3.util.FastMath|acosh|double|static",
    "M|org.apache.commons.math3.util.FastMath|asin|double|static",
    "M|org.apache.commons.math3.util.FastMath|asinh|double|static",
    "M|org.apache.commons.math3.util.FastMath|atan|double,double,boolean|static",
    "M|org.apache.commons.math3.util.FastMath|atan|double|static",
    "M|org.apache.commons.math3.util.FastMath|atan2|double,double|static",
    "M|org.apache.commons.math3.util.FastMath|atanh|double|static",
    "M|org.apache.commons.math3.util.FastMath|cbrt|double|static",
    "M|org.apache.commons.math3.util.FastMath|pow|double,double|static",
    "M|org.apache.commons.math3.util.FastMath|pow|double,int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
