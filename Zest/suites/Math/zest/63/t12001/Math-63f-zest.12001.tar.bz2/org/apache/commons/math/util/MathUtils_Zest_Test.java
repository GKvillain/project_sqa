package org.apache.commons.math.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class MathUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Long:2770806050297775245\012",
        Z.run(T, 1, 6, 2, 10, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce\udbfd\udd38\ud92d\udd8d\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\uda20\udcc2\udb73\udc45\ud8c2\udfc7\uda21\udf16\udb95\udec9\ud8ed\udca5\ud911\udc4b\u67cc",
        54, 57376, 496490944, 2770806050297779688L, -4443L, false, false, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a23f5e2d0L), Double.longBitsToDouble(0x3fe9910244b16ebbL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |a0=[D:[[27682.0, 28628.0]]\012",
        Z.run(T, 1, 12, 2, 10, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce\udbfd\udd38\ud92d\udd8d\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\uda20\udcc2\udb73\udc45\ud8c2\udfc7\uda21\udf16\udb95\udec9\ud8ed\udca5\ud911\udc4b\u67cc",
        54, 57376, 1654118848, 2770805831254447592L, -4443L, false, false, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a23f5e2d0L), Double.longBitsToDouble(0x3fe9910244b1b3bbL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 7, 2, 10, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce\udbfd\udd38\ud92d\udd8d\ud87a\udea6\ud982\udf3d\ud9b7\uddce\uda20\udcc2\udb73\udc45\ud8c2\udfc7\uda21\udf16\udb95\udec9\ud8ed\udca5\ud911\udc4b\u67cc",
        54, 57376, 496490944, 2770806050297779688L, -4443L, false, false, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a23f5e2d0L), Double.longBitsToDouble(0x3fe9910244b16ebbL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Long:2770806050297810760\012",
        Z.run(T, 1, 6, 2, 10, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce\udbfd\udd38\ud92d\udd8d\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\uda20\udcc2\udb73\udc45\ud8c2\udfc7\uda21\udf16\udb95\udec9\ud8ed\udca5\ud911\udc4b\u67cc",
        54, 57376, 496490944, 2770806050297779688L, 31072L, false, false, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe0380000f5e2d0L), Double.longBitsToDouble(0x3fe9910004b16ebbL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Long:-7225483079498170394\012",
        Z.run(T, 1, 6, 2, 2, "\uda13\udde2", "\ub42d\u8957\u024b", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce\udbfd\udd38\ud92d\udd8d\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\uda20\udcc2\udb73\udc45\ud8c2\udfc7\uda21\udf16\ud8bc\uddbc\ud9ae\udf19\ud911\udc4b\u67cc",
        54, 57376, 496490944, -7225483079498165951L, -4443L, false, false, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a23f5e2d0L), Double.longBitsToDouble(0x3fe9910244b16ebbL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27682.0, 28628.0, 27715.5, 28221.5, 27925.5, 28438.5]] |a1=[D:[[269.5, 25103.0, 10327.5]]\012",
        Z.run(T, 1, 3, 2, 10, "\ud874\udfd8\ud8b7\udcab\uda5b\ude5d", "\u024b\uc44e\u50df", "\ud9ad\udd28\ud88e\ude21\ud9b6\udd48\ud925\uddb7\u11ba\ud951\ude89\ud9e9\udc41\udb40\uddce\udbfd\udd38",
        -2, 23785, -533330659, -4320322761103149897L, -55504L, true, false, (char) 14248, (char) 15738,
        Double.longBitsToDouble(0x3fcfb5c0c947d0e0L), Double.longBitsToDouble(0x3fecfe07f8c83d3dL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Long:6701226852078723386\012",
        Z.run(T, 1, 6, 2, 10, "\ud874\udfd8\uda96\udf9b\ud8d9\ude4b\ud821\udffa\uda95\udff8\ud9ff\udf3f\uda83\udf4f\u6051\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce", "\u4bbe\uaf6f", "\udb73\udc45\ud8c2\udfc7\uda21\udf16",
        56, 410, -197604099, 6701226852078785010L, -61624L, false, false, (char) 45610, (char) 43646,
        Double.longBitsToDouble(0x3fd3079ac5713cb6L), Double.longBitsToDouble(0x3fe5dd0bc87c085eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 1, 4, "\000", "\ub42d", "\uda83\udf4f\udb71\udf4e\uda6c\udcc2\ud804\udfc5\udb47\udea4\uda77\udef5",
        59, 54632, 22784, 0L, -42999L, false, false, (char) 0, (char) 32464,
        Double.longBitsToDouble(0x3fe1ac4518758733L), Double.longBitsToDouble(0x3fbeb8ec27e80000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Long:2770806050692564109\012",
        Z.run(T, 1, 4, 2, 7, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce\ud9d9\udc07\udaba\udf90\ud87c\udc06\ud982\udf3d\ud885\udc72\udb7f\udca2\udb72\udfe7\ud8c2\udfc7\uda21\udf16\udb95\udec9\udacd\udfce\ud911\udc4b\u67cc",
        31, 99072, 496490944, 2770806050692568552L, -4443L, false, false, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a23f5e2d0L), Double.longBitsToDouble(0x3fef98ac69b16ebbL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 2, 2, 10, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\uda6c\udcc2\uda22\uddf2\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce\ud9a8\udece\udb23\udd88\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\udb58\udd0c\ud8a9\udec6\uda04\udd79\ud954\ude9e\udb95\udec9\uda22\ude40\u5c4f\u67cc",
        54, 57376, 496490944, 2770806049120687592L, -72822L, false, false, (char) 8914, (char) 61715,
        Double.longBitsToDouble(0x3fe5dd0bc87c085eL), Double.longBitsToDouble(0x3fc31215507b8b20L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 1, 11, 18, 14, "\ud874\udfd8\udab8\udfcb\udb78\udf5a\ud90a\udd02", "\u883b\ubf01\u31ca\u137e\u766b\ua0e8", "\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce\ud816\ude5b\ud941\udf46\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\uda20\udcc2\ud8a1\udedf",
        32, 97534, 565227637, -5906860885934551811L, -61624L, true, false, (char) 45749, (char) 43646,
        Double.longBitsToDouble(0x3fd3079ac5713cb6L), Double.longBitsToDouble(0x3feddd0bca3c4e5aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 5, 10, "\ud874\udfd8", "\ub42d\u81c2\u4cf5", "\ud99e\udcbb\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce\udbfd\udd38\ud92d\udd8d\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\uda20\udcc2\udb73\udc45\ud8c2\udfc7\uda21\udf16\udb95\udec9\ud8ed\udca5\ud911\udc4b\u67cc",
        54, 57376, 496490944, 2770806050297779688L, -4443L, false, false, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a23f5e2d0L), Double.longBitsToDouble(0x3fe9910244b16ebbL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Long:2770806050297697455\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 2, 6, "\ud89e\udfd8", "\u33e2\u815c\u024b", "\uda6c\udcc2\ud9d8\udd5f\udbaf\udd58\udaa6\udfe7\ud8f0\udd45\ud925\uddb7\ud87e\udd35\ud8ae\ude84\ud9e9\udc41\uda5e\udcc0\udb5a\ude58\udaf3\ude44\udbee\udcd5\udaf1\ude34\ud866\ude0b\udbd3\udc27\udb73\udc45\ud8c2\udfc7\udbd7\udfd0\udb95\udec9\ud8ed\udca5\uda06\udc23\ubbb6",
        51, 71869, 489740736, 2770806050297779688L, -82233L, false, false, (char) 60911, (char) 47891,
        Double.longBitsToDouble(0x3fe5dd0c187c085eL), Double.longBitsToDouble(0x3fc3120c107b8b20L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 8, 17, 10, "\ud874\udfd8", "\ub419\u81c2\u024b", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud8f3\udc10\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce\udbfd\udd38\ud34c\udb65\uded6\ud982\udfa9\ud9b7\uddce\uda8b\udf18\udb72\udfdf\ud8c2\udfc7\uda21\udf16\udb95\udec9\ud8ed\udca5\ud911\udc4b\u67cc",
        54, 57984, -1869096512, 2760198052307310056L, 31431L, true, false, (char) 57318, (char) 15094,
        Double.longBitsToDouble(0x3fdbba1790f810a4L), Double.longBitsToDouble(0x3fed3c85521ee2c8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 2, 10, 10, "\udb82\udc38", "\ub42d\u81c2\u024b", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb1b\udf18\udbfd\udd38\ud84f\udff2\ud9a4\udfa7\ud982\udf3d\ud9b7\uddce\ud823\udd03\udb73\udc45\ud8c2\udfc7\uda21\udf16\udb95\udec9\ud8ed\udca5\ud97a\ude4a\u67bd",
        54, 57376, 496490944, -2337401828019897885L, -4443L, false, false, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a23f5e2d0L), Double.longBitsToDouble(0x3fe9910244b16ebbL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Double:54047.358811509 |a0=[D:[[27705.5, 28500.0, 27715.5, 28221.5, 27925.5, 28438.5, 27945.0, 28555.0]] |a1=[D:[[11231.5, 737.5, 15282.0, 3658.0, 15010.5, 9009.0, 27550.5, 4543.5]]\012",
        Z.run(T, 1, 15, 2, 13, "\ud8a3\uded8\ud8b7\udcab\uda5b\ude5d\uda82\udf46\ud9d9\ude05\udb00\udd48\uda7c\udede", "\u57ef\u05f3\u7794\u1cc4\u7575\u4692\ud76d\u23af", "\ud92d\udd8d\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\uda20\udcc2\udb73\udc45\ud9ab\udc68\uda30\udde4",
        20, 463, 1908255229, 6701226852330443250L, -4443L, false, true, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe0389e53f5e2d0L), Double.longBitsToDouble(0x3fe9910244b16ebbL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 1, 5, 11, "\ud874\udfd8", "\u369b\u81c2", "\u6051",
        9, 8291, 1717298338, 8726518787378898534L, -11994L, false, true, (char) 59701, (char) 51304,
        Double.longBitsToDouble(0x3fd57e0362058816L), Double.longBitsToDouble(0x3f8c40cc7bd6a3c0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Double:12907.205013092494 |a0=[D:[[27682.0, 28628.0]] |a1=[D:[[23038.5, 16585.0, 269.5]]\012",
        Z.run(T, 1, 15, 17, 3, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9ad\uddea\uda2d\udeac\u85aa\ud92d\udd8d\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\uda20\udcc2\udb73\udc45\ud8c2\udfc7\uda21\udf16\udb95\udec9\ud8ed\udca5\ud911\udc4b\u67cc",
        54, 57376, 496490944, 2770806050297779688L, -4443L, false, false, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a23f5e2d0L), Double.longBitsToDouble(0x3fe9910244b16ebbL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 13, 4, 10, "\ud874\udfd8", "\ub42d\u81c2\u1f29", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\udb67\udefc\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce\ud8c3\ude49\ud94d\udcf6\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\uda20\udcc2\ud93c\udcab\ud8c2\udfc7\uda21\udf16\udb95\udec9\ud8ed\udca5\ud911\udc4b\u67cc\ud905\udd91",
        57, 27676, 645128556, 2414094222773946566L, -78619L, true, true, (char) 61715, (char) 11316,
        Double.longBitsToDouble(0x3fe4e042f4e25717L), Double.longBitsToDouble(0x3f9ee2c8c0fca880L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 7, 10, "\ud874\udfd8\ud8b7\udcab\ud924\udfc2", "\u29f7\uc448\u50df", "\ud8cc\udeaa",
        7, 18994, 1307037984, -8902955647281671115L, -58044L, false, true, (char) 32691, (char) 45828,
        Double.longBitsToDouble(0x3fd1dc34b2afc06cL), Double.longBitsToDouble(0x3fc518816692f788L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 1, 12, 0, 9, "\ud874\udfd8\ud8b7\udcab", "\u81c2\u7a8e\ua512\ua469\uc5e9\u50da\u05f3\u7794", "\u11ba\ud9c4\ude70\udae2\ude5e\udb81\udf0f\udbfd\udd12\udb2a\udc8b\ud87c\udc1b\ud982\udf3d\ud9b7\uddce\uda0e\udcc2\udb57\uddf8",
        43, 97509, -474959755, -5906935482694185731L, 49819L, true, true, (char) 3445, (char) 65282,
        Double.longBitsToDouble(0x3fde8267318c4300L), Double.longBitsToDouble(0x3fac053603f3a3f0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 13, 11, "\ud874\udfd8", "\u3807\u6189\u1087", "\ud8de\udef3\ud804\udfed\ud8cc\ude5e\ud996\ude33\ud9b6\udd48\ud925\uddb7\ud8ed\udead\udbe6\udd60\udbb5\udd7c\uda19\udcdb\ud8d2\udc77\ud929\udd1d\ud87c\udc1d\uc055\u0f7a\uda20\udcc2\ud9bb\udc49\ud8c2\udfc7\uda21\udf16\uda9b\udcf2\ud8ed\udc3b\ud911\udc4b\udbb4\udf7a\ud8e1\udf84\ud9f2\udda7\ud9b4\udf7e\ud842\udfb0\ud838\udf10\ud985\udf48\ud8d3\udebf\ud999\udcfe\udba6\udf76\udbaf\udd25\ud8e0\udf39\ud93e\uddec\ud8c0\udedf\udaa8\ude8a\udaac\udf4e\ubddc\uda3c\uddb8\ud86e\udd72\ud9d9\ude7c\uda26\ude48\ud851\udda4\ud9a9\udcb9\ud8a9\udc69\udbda\uddf5\ud97f\udfcc\udbfe\udcea\ud5ef\udab0\ude89\udb13\udc29",
        45, 46818, -1754322325, -5720390836896312742L, 60312L, true, true, (char) 36757, (char) 48183,
        Double.longBitsToDouble(0x3fed5cda45bf7437L), Double.longBitsToDouble(0x3fdc5df878d591c8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 18, 10, "\ud874\udfd8", "\u2618\ua5f8\ub54b", "\uda6c\udcc2\udb8f\udcca\uda71\ude7f\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\ud8f0\udd51\ud97d\udf24\u8dcd\udbfd\udd0d\ud92d\udd8d\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\uda20\udcc2\uda40\udde3\ud8c2\udfc7\uda21\udf58\udb95\udec9\udb61\udea0\uda3e\udcbb\ud8e4\udc63",
        19, 59930, 496443443, 2770806050297779688L, 33152L, false, true, (char) 40037, (char) 61715,
        Double.longBitsToDouble(0x3fe5dd0bc87c085eL), Double.longBitsToDouble(0x3fc31215587b8b20L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Long:-7804075672121453175\012",
        Z.run(T, 1, 4, 16, 3, "\ud874\udfd8", "\u2b7b\u65e2\u4d8c", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\udb4b\uddaa\u11ba\udbd3\udd03\ud939\udecc\ud911\udc8e\ud8fd\udd69\ud8d4\udd9d\ud875\udd54\uda46\udd80\ud9b7\uddce\uda20\udcc2\udb73\udc45\ud8c2\udf18\uda21\udf16\udb95\udecf\udb99\ude9a\udafd\udfdf\u67cc",
        27, 57376, -1878078748, -7804075672121462023L, 8848L, false, true, (char) 64336, (char) 22294,
        Double.longBitsToDouble(0x3fc30a84907b8b20L), Double.longBitsToDouble(0x3fe03f2a23f5e2d0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 13, 2, 10, "\ud874\udfd8", "\ub42d\u81c2\u3f4b\uc44e\u50df\u1675\u57ef\u05f3\u0e98\u1d81\u426f\u7e62\ud76d\ubf34\u79b9\u2db9", "\uda9c\udf6a\ud9b7\uddce\uda20\udcc2\ud989\udeb0\ud8c2\udf1f\uda21\udf16\ud9a2\ude8f\ud8ed\udca5\ud911\udc4b\u67cc\ud905\udd91\ud9da\udf0f\ud9b4\udf7e\ud842\udfb0",
        22, 67449, 986263744, -3698457779724823527L, -4443L, true, true, (char) 26884, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a23f5e2d0L), Double.longBitsToDouble(0x3fe9910244b1a8bbL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:97043\012",
        Z.run(T, 1, 5, 2, 18, "\ud874\udfd8", "\000", "f\u5fba\uda6c\udcc2\ud804\udfc5\u00a2\uda99\udef5",
        59, 96984, -2072880894, 4086968512306530183L, -64239L, true, true, (char) 398, (char) 28851,
        Double.longBitsToDouble(0x3fda4bde25a05954L), Double.longBitsToDouble(0x3fe1ac4518758733L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Double:1.1316774430501724\012",
        Z.run(T, 1, 14, 6, 2, "\ud874\udfd8", "\ucf3e\u81c2\u024b", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\ud886\udee7\udb8c\udd93\uda99\udcbb\ud805\uddf8\uda7e\udde4\uda4b\udfa9\ud878\uddca\udbfd\udd38\ud81d\udd29\ud87c\udc1d\udb4f\udce3\ud86c\ude96\uda30\udc27\ud93e\udfeb\ud8c2\udfc7\uda21\udf16\udb95\udec9\ud8ed\udca5\ud910\udf92\u67cc",
        27, 92444, 496490977, 5725167723686197640L, -4443L, false, true, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a2425e2d0L), Double.longBitsToDouble(0x3fef94f749deac8fL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |a0=[D:[[27682.0, 28628.0]]\012",
        Z.run(T, 1, 12, 2, 10, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\ud9b3\udfb1\ud9cc\ude45\udb40\uddce\udbfd\udd38\ud92d\udd8d\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\uda20\udcc2\ud9d4\udd4a\ud8c2\udfc7\uda21\udf16\udb95\udec9\ud88a\udc5f\ud911\udc4b\u67cc",
        54, 55320, 502454720, 2770806049264836840L, -8482L, true, false, (char) 8924, (char) 61715,
        Double.longBitsToDouble(0x3fe5dd0bc87c085eL), Double.longBitsToDouble(0x3fc31215507b8b20L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 2, 18, 10, "\udaea\uddf3\udaf1\udfd9\uda5b\ude9b\uda82\udf46\ud9d9\ude05\udb00\udd48\uda83\udf4f\u8abf\uda7e\udd75\ud804\udf7e\uda60\ude15\ud9f4\udcfb\udb1c\udeef\ud931\udd42\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce\udbfd\udd38", "\uaf6f\u5a47\ud64b\u6e94\u0558\u0f09\u5ee7\u9051\u4f07\ub889\u2e0d\u65c9\uccd2\u7fa2\u059d\u49ae\u81d8", "\udbaf\udd25\ud8e0\udf39\ud93e\uddec",
        -2, 27006, -489660921, 2326254297684882226L, 94095L, true, true, (char) 9873, (char) 62945,
        Double.longBitsToDouble(0x3fa8b07b00e2c6e0L), Double.longBitsToDouble(0x3fe83da5e84a07bdL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 9, 2, 10, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\uda03\ude2e\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce\udbfd\udd38\ud92d\udd8d\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\uda20\udcc2\udb73\udc45\ud8c2\udfc7\uda21\udf16\udb95\udec9\ud8ed\udca5\ud911\udc4b\u67cc",
        54, 57376, 496490944, 2770806050297779688L, -52214L, true, false, (char) 8924, (char) 61715,
        Double.longBitsToDouble(0x3fe5dd0bc87c085eL), Double.longBitsToDouble(0x3fc31215507b8b20L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |a0=[D:[[28012.0, 28335.0]]\012",
        Z.run(T, 1, 11, 2, 11, "\udb08\udd8e", "\u501f\ubf65\u27ec\ud206\u81c2\u0a63\u57ef", "\ud9b6\udd48\ud925\uddb7\uda44\udc69\ud8b0\udff5\ud9e9\udc41\udb40\uddce\udbfd\udd38\ud9bf\udff8\ud87b\udff6",
        56, 55471, -16018248, 3218588995732853456L, -42760L, true, true, (char) 18726, (char) 3394,
        Double.longBitsToDouble(0x3fde8a49d18c4300L), Double.longBitsToDouble(0x3fd676cc307e747eL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 12, 10, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\udb89\udf10\ud8ef\ude63\ud9e2\udf09\ud84c\udf46\ud9b3\udfb9",
        39, 42106, 951571509, 5781715405955965924L, -90980L, true, true, (char) 51304, (char) 394,
        Double.longBitsToDouble(0x3fc518816692f788L), Double.longBitsToDouble(0x3fe5e35d52dba9b9L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 1, 12, 2, 10, "\ud874\udfd8\ud8b7\udcab\uda5b\ude5d\uda82\udf46\ud9d9\ude05\udb00\udd48\uda83\udf4f\u6051\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\udbf7\ude68\ud92a\ude5a\u11ba\udaa5\udf8c\ud9e9\udc41", "\ub1d8\u4bbe", "\uda20\udcc2",
        38, 64648, -2026668491, -2039936616016488070L, -69873L, false, true, (char) 26175, (char) 109,
        Double.longBitsToDouble(0x3fd396297bd04ce6L), Double.longBitsToDouble(0x3fc8c430159db30cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 1, 12, 2, 10, "\ud98e\udc50", "\ub42d\u81c2\u024b\uc44e\ua8f6\ub944\u3990\u05f9\u7794\u1cc4\u7575\u4692\u7764\u117b\u03f2\u5c9f\ub1d8\u4bbe\uaf6f", "\udb73\udc36",
        23, 97509, -276673675, 516778371892834510L, -61624L, false, false, (char) 45610, (char) 43646,
        Double.longBitsToDouble(0x3fd3079ac5713cb6L), Double.longBitsToDouble(0x3fe5250bc87c08ceL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |a0=[D:[[27682.0, 28628.0]]\0121=java.lang.Long:2770805831254443149\012",
        Z.run(T, 2, 12, 6, 10, "\ud874\udfd8", "\ub42d\u53d5\u84b6", "\uda6c\udcc2\ud804\udfc5\udbe6\udedc\ud90c\udc78\ud9cc\ude27\ud8dc\ude9e\u11ba\udaa5\udf8c\udbc5\udd10\u4d23\ud91a\udf61\ud92d\udd8d\ud87c\udc1d\udac8\udfff\ud9b2\udf36\uda20\udc40\ud8f7\udf47\uda55\udec9\ud83d\udf43\udb31\udf9b\ud82d\udd95\ud911\udc30\u67cc",
        54, 57376, 1654118848, 2770805831254447592L, -4443L, false, false, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a23f5e2d0L), Double.longBitsToDouble(0x3fe9910244b1b396L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |a0=[D:[[5818.0]]\012",
        Z.run(T, 1, 12, 2, 10, "\u2da4", "\ub42d", "\uda83\udf4f\u6051\030\000\000\u8800",
        57, 96984, -2072880894, 4086968510960369664L, -16452L, false, false, (char) 1753, (char) 14248,
        Double.longBitsToDouble(0x3ec6000000000000L), Double.longBitsToDouble(0x3fe2880001f25cffL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\012",
        Z.run(T, 1, 13, 11, 12, "\ud874\udfd8", "\ub42d\u6da1\u024b", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48",
        39, 42106, 951571509, 5781715405955965924L, -90980L, true, true, (char) 51304, (char) 398,
        Double.longBitsToDouble(0x3fc518816692f788L), Double.longBitsToDouble(0x3fe68165563588a3L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27741.5, 28145.5]] |a1=[D:[[25666.5, 8915.0]]\012",
        Z.run(T, 1, 3, 12, 10, "\ud8eb\udc13", "\uc8b5\u45d6", "\u6051\uda6c\udcc2",
        16, 95338, -467433318, 2781992024141189408L, -88789L, true, true, (char) 62495, (char) 48174,
        Double.longBitsToDouble(0x3fe9e2e3bbb12754L), Double.longBitsToDouble(0x3fd1dc34b2afc06cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27682.0, 28628.0]] |a1=[D:[[22947.0, 16585.0, 269.5]]\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 3, 2, 10, "\ud874\udfd8", "\ub376\u81c2\u024b", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce\udbfd\udd38\ud92d\udd8d\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\uda20\udcc2\ud93b\uddca\ud99a\udc0a\udb8e\udd02\udb9b\udff0\ud8ed\udca5\ud911\udc4b\u67cc",
        47, 57203, 1654118848, 2770805831254447592L, -4443L, false, false, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a2321e2d0L), Double.longBitsToDouble(0x3fe991003cb1b3bbL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Long:1\012",
        Z.run(T, 1, 7, 2, 9, "\ud874\udfd8\ud8b6\udfff", "\u81c2\u3836\u0467\ud190\ua4e2\u5799\u4260\u7375", "\ud8bc\ude54\udaa8\udc14",
        49, -700, -1659873338, 2833928607540938298L, -16502L, false, false, (char) 1753, (char) 14248,
        Double.longBitsToDouble(0x3fd7ae3b09fb5c0cL), Double.longBitsToDouble(0x3fe28fa1c11c94c0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 18, 7, 13, "\uda13\udde2\udb45\udc4e\ud8e6\udced\udac0\udc9b\ud886\udd1c", "\ua092", "\ud8f6\udf5f\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\ud877\udfb6\ud9e9\udc41\udb98\udf03\udbfd\udd1c",
        57, 68808, -524560379, -4320322761095205720L, -54827L, false, true, (char) 31697, (char) 32393,
        Double.longBitsToDouble(0x3fdf25cff1907aeeL), Double.longBitsToDouble(0x3fdc026adad83b2eL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 17, 16, 2, "\uda13\udde2", "\ub42d\u8957\u024b", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce\udbfd\udd38\ud92d\udd8d\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\uda20\udcc2\ud9e0\ude7d\udb3a\udc41\uda21\udf16\ud8bc\uddbc\ud9ae\udf19\ud911\udc4b\u67cc",
        54, 57376, -1425516096, -7225696947394670271L, -4443L, false, false, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a23f5e2d0L), Double.longBitsToDouble(0x3fe9910244b16ebbL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 2, 4, "\ud874\udfd8\ud956\udeb5\uda5b\ude0f", "\u024b\uc4ae\u6763", "\uda9e\udf73\ud88e\ude7f\udbfd\udeec\u6764\u1241",
        21, 51103, 1515290530, 6303335480768602940L, 29763L, true, true, (char) 14531, (char) 62260,
        Double.longBitsToDouble(0x3fe182759c2f954dL), Double.longBitsToDouble(0x3fd01824b27dc672L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27682.5, 28137.5, 27715.5, 28221.5, 27925.5, 28438.5, 27945.0, 28555.0]]\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 3, 16, 2, "\ud875\udc03\ud8b7\udcab\uda5b\ude5d\uda82\udf46\udb31\udf4c\udaf3\udc68\uda0d\ude17\u6051\udb8e\udc59\udb30\uddec\ud8ed\ude50\ud8de\udc83\ud974\udd6f\ud891\ude93\ud8c7\udd47\uda24\udff0\ud9e9\udcb5\udb40\uddce\udbfd\udd38\uc25b\ueff9\uda44\ude16\udb6e\udd5a\ud984\udcca\udabc\udc6a\udbf2\udf1f\ud8d1\udd92\uda26\udf3a\ud8ed\udc46", "\u8434", "\udaa6\udd36\ud993\udd30",
        55, 62765, 833615783, 7318762181273558803L, -93776L, true, true, (char) 2199, (char) 65152,
        Double.longBitsToDouble(0x3fe28e103bb87766L), Double.longBitsToDouble(0x3fe985f00abe06b9L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 8, 0, 10, "\ud874\udf34", "\000\000\u4074\uc266\000\u70e3\u00ab\000\u7794\u5fba\uab42\002", "",
        -5, -1000, 0, -4374402613593635555L, -13128L, false, false, (char) 32634, (char) 1753,
        Double.longBitsToDouble(0x3fe3ac39997ae3dfL), Double.longBitsToDouble(0x3fcfb5c0c947d0e0L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Long:2132412367887780619\0121=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 2, 6, 12, 10, "\udafe\ude8f\udb2e\udf1c\ud8d9\ude4b\ud821\udffa\udb01\udf85\udb3c\ude95\ud912\udf1b\u6051\ud9fb\udf4a\ud80f\uddc4\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce", "\u4bea\u3a05\u9f9d\u43c1\u6e94", "\uda81\udccc\ud8ed\udca5\ud911\udc4b",
        56, 2554, 648882376, 2132412367887851884L, -71265L, false, true, (char) 61715, (char) 11316,
        Double.longBitsToDouble(0x3fbf0217b1af4f90L), Double.longBitsToDouble(0x3fe0d4a8c9b5f1a2L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 0, 0, 0, "\000", "\ub42d", "\ud8c4\ude09\000\uda6c\udcaa\ud804\udfc5\u00a2\000",
        57, 54632, 22784, 0L, -99823L, false, false, (char) 398, (char) 11,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 1, 11, 12, 15, "\006\uda46\udfe0\udb4c\udd17\ud96a\udd31\ud9d9\ude05\ud902\udd38", "\u3ed4\u8b49\u0e94\uc793\u44c4\u284c\uaf71\u06c8\u9a34\ucbc6\u932d\u6c89\u09d6\u107e\u2964\u4a70\u4df0\u6834\ud572\u3965\u9212\ubb68\u6420", "\ud946\udda5\udbde\udc71\uda38\udd8d\uda6b\udda5",
        11, 38852, -1306153063, 6824359976964991725L, -11281L, true, false, (char) 6562, (char) 18166,
        Double.longBitsToDouble(0x3fda2ddf199e8e22L), Double.longBitsToDouble(0x3fad2a39deae50d0L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |a0=[D:[[27649.0, 28356.0]]\0121=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 2, 11, 12, 8, "\ud832\uddb8", "\u8d2d\u81c2\u5feb\uc4b9", "\ud804\udfc5\udbd8\udead\udb3b\udedc\ud987\ude7f\ud9d3\udc1b",
        35, 35920, 4950117, 7205759403398485958L, -70225L, true, false, (char) 25329, (char) 62151,
        Double.longBitsToDouble(0x3fc7d12c2b917fa0L), Double.longBitsToDouble(0x3fe1ac4518758733L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 1, 12, 1, 4, "\000\udb13\udced\udb51\udd7d", "\u4717", "\uda6c\udcc2\ud804\udfc5\udb47\udea4\uda77\udef5\udb9c\udcbc\udb15\udf94\u59dc\000\udb20\udcaf\uda8b\udde4\ud9d7\udd37\udac9\udc64\ud834\udefb\ud85a\ude9a\udb76\udf36\udae7\udd46\udb30\ude97\ud8c2\udfc7\u6481\ud9ed\udf00",
        10, 35172, -728673147, 2959377615648211129L, -28202L, false, true, (char) 51358, (char) 47688,
        Double.longBitsToDouble(0x3fef8bf405723aafL), Double.longBitsToDouble(0x3fdf8ad9b860c634L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[-24.0]] |a1=[D:[[11224.0]]\012",
        Z.run(T, 1, 3, 1, 4, "\000", "\u57e0", "\uda83\udf4f\udb71\udf4e\uda6c\udcc2\udae2\udc72\udb59\udf1a\ud81e\udd0c",
        11, 54632, 22784, 0L, -42999L, false, false, (char) 18432, (char) 46904,
        Double.longBitsToDouble(0x3fe52503bfcfcea9L), Double.longBitsToDouble(0x3fbeb8ca27e80000L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 17, 1, 10, "\000\000\uda5b\ude5d\ud832\ude0e\uda5d\uddd1", "\ud7c7\u0a63", "\udb64\udf50\ud9b6\udd48\uda95\udc89\u5900\000\000\uda8b\udde4\udab9\udd36\udba1\udccb\ud93c\udc6f\ud9a3\ude7d\ud876\udc0c\u00ff",
        39, 64648, -2026668491, -2039936614641172358L, 12428L, true, false, (char) 59479, (char) 32879,
        Double.longBitsToDouble(0x3fc003712148b090L), Double.longBitsToDouble(0x3feb907288232734L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 16, 16, 14, "\ud874\udfd8\ud89e\udd1e\ud956\ude4c\ud854\udf11", "\u7539\u72ba\u31ca\u0e82\ud208\u2a30", "\u11ba\udaa5\udf8c\uda4d\udc53\udb40\uddce\udb6e\udd87\uda3b\uded0\udbcd\udee9\uda4e\udef8\ud9b7\uddc3\ud873\udd40\ud80d\udcca",
        21, 97709, 565227637, -5907007340024378115L, -92404L, true, false, (char) 8924, (char) 61715,
        Double.longBitsToDouble(0x3fdbba1798d416f8L), Double.longBitsToDouble(0x3fe4e543e94062aeL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 1, 9, 15, "\ud890\udfd8", "\ud13b\u9c6c\u162b\ua19b\u50ed\u99df", "\uda78\udf3b\ud8ae\udf8f\ud925\uddb7\u11ba\ud8f7\ude3d\ud8bc\ude00\udb28\udd52\udb52\ude84\ud872\udde6\ud882\udc1e\ud9aa\uddb1\ud927\ude66\udb47\uddd6\ud84b\udf29\ud8ca\ude6e\uda21\udee6\ud9b5\ude99\ud92c\udc28\ud987\udfa5\ud8bb\udcb1\udadc\udfc4\ud916\udf27\udb47\udff0\uda84\udcd0\ud897\ude57\udb54\ude8b\udaf0\udd60\ud86d\udd66\udba6\udf6e\ud9fa\udfc2\uda2b\udf34\ud9ff\udee1",
        15, 12486, -756854794, 8875131261600765541L, -59554L, true, true, (char) 17911, (char) 53856,
        Double.longBitsToDouble(0x3fbc31c345ca1010L), Double.longBitsToDouble(0x3fd3f7c897f50036L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Integer:3720\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 5, 8, 14, "\ud874\udfd8\udab8\udfcb\udb64\udf5a\ud90a\udd02\ud9d9\ude05\ud80a\udd32\ud8e2\udfa3\udbdf\udd15\udb35\udfd9\ud96f\uddda\ud8f9\udca7\ud9db\udd84\ud84a\udc0f\ud925\uddb7\ud948\udfdb\udaa5\udfbd\udbdf\ude9c\udbd1\ude9f\udadf\udfd4\ud8f9\udda9\ud87c\udc1d", "\ud64b\u2092", "\ud8e6\ude71\ud8fe\udc7d\ud911\udc4b\u67cc\ud905\udd91\ud896\udf2e",
        7, 3713, -1837066776, 7837112325902386674L, -1627L, false, true, (char) 64437, (char) 39008,
        Double.longBitsToDouble(0x3fe81b586463f89aL), Double.longBitsToDouble(0x3fd403c57360b3feL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Integer:70544\0121=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 2, 5, 11, 0, "\udb33\udc3b\ud933\udfe8\udb78\udf5a\ud93d\udcc1", "\u06e7\u7758\u4eaa\u137e\ucd9e\ubfce", "\udbfa\udfcd",
        28, 70516, 1684579478, 4791368228854191792L, 29763L, true, false, (char) 50327, (char) 55383,
        Double.longBitsToDouble(0x3fe7c20b79f839e5L), Double.longBitsToDouble(0x3fbd7ba7aa910d80L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\012",
        Z.run(T, 1, 8, 6, 18, "\ud8f3\udf36\udb16\udf31\uda34\ude7d", "\u8abb\u21f3\ud352\u4f79\u0f0b\u5135\u7387\ucfe8\u7651\u4692\u317b\ud6f5\u4ea6\u8a64\u10d6\u8e8f\u540a\u6ed4\ua531\ub03e\u4fb9\ucdd3\u1823\u7e59\u2711\u0459\uc795\u012e\u3893\u587c\u2346\u015a\u0174", "\udbaf\udc98\udba3\udcdb\ud80c\ude12\ud902\udc76\ud980\udfbf\udb74\udc76",
        51, -134, -2083740495, 6482093903356239914L, -94342L, false, false, (char) 23844, (char) 39712,
        Double.longBitsToDouble(0x3fc617bbe9c38230L), Double.longBitsToDouble(0x3fbad153e2458510L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Double:1.13167744286514\0121=java.lang.Double:1.13167744286514\012",
        Z.run(T, 2, 14, 14, 10, "\udb82\udc38", "\u7f33\u81c2\u024b", "\uda6c\udcc2\ud97d\ude00\ud8d0\ude07\udbfa\udfc6\ud99f\udf67\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb1b\udf18\udbfd\udd38\ud84f\udff2\ud9a4\udfa7\ud982\udf3d\ud9b7\uddce\ud823\udd03\udb73\udc45\ud8c2\udfc7\uda21\udf16\ud941\udc5f\uda59\udd43\ud97a\ude4a\u67bd",
        54, 57376, 502188736, -2337401828019897885L, -4443L, false, false, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a23f5e2d0L), Double.longBitsToDouble(0x3fccd989135da718L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 13, 13, 10, "\udb82\udc38", "\u86bd\u81c2\u024b", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\ub319\uda80\ude86\ud9e8\udff9\udb1b\udf18\udbfd\udd38\ud963\udf9b\ud9a4\udf9e\ud982\udf3d\ud9b7\uddce\ud823\udd03\udb73\udc45\ud8c2\udfc7\uda21\udf16\udb95\udec9\ud8ed\udca5\ud97a\ude4a\u67bd",
        54, 57376, 496490944, -2337401828019897885L, -4443L, true, true, (char) 29786, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a23f5e2d0L), Double.longBitsToDouble(0x3fe9910244b16ebbL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 1, 12, 0, 9, "\ue7da\udab4\uddce", "\u81c2\u7a8e\ua512\ua469\uc5e9\ub9fa\u1050\u7727", "\u11ba\ud9c4\ude70\udae2\ude5e\udbb2\ude79\udbfd\udd12\udb2a\udc8b\ud87c\udc1b\uda22\udfa9\udb49\udd9a\uda0e\udcc2\udb57\uddf8",
        43, 97509, -474959755, 3797590079491198362L, 49819L, true, true, (char) 3445, (char) 42376,
        Double.longBitsToDouble(0x3fde8b8672f8d772L), Double.longBitsToDouble(0x3fac2ed903f3a3f0L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=void |a0=[D:[[27682.0, 28628.0]]\0121=void |a0=[D:[[27682.0, 28628.0]]\012",
        Z.run(T, 2, 12, 11, 16, "\ud874\udfd8", "\ub42d\u81c2\u3f4b\uc44e", "\ud804\udfc5\ud8cc\udeaa\udbc7\udf4e\ud86b\ude34\uda19\ude21\udbae\udcc0\udb49\udc90\ud813\udccb",
        6, 79200, -1089580482, 2255233669396170013L, -13128L, false, true, (char) 42962, (char) 46109,
        Double.longBitsToDouble(0x3fbd73330bd11d80L), Double.longBitsToDouble(0x3fe7ed7036f10968L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 2, 16, 12, 18, "\ud887\udee4", "\000", "\uda62\ude25\ud823\udfc6\ud9e1\udefe\ud952\udc42\ud827\udc5d\uda99\udef5",
        59, 1751, -2064164013, 4086968512306493319L, -35481L, false, true, (char) 45940, (char) 1309,
        Double.longBitsToDouble(0x3fb5c74da543ae38L), Double.longBitsToDouble(0x3fda4bde210e5954L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\012",
        Z.run(T, 1, 9, 2, 10, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\uda03\ude2e\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c",
        49, -700, 1551325126, 2833928805109435313L, -16452L, false, false, (char) 1753, (char) 6162,
        Double.longBitsToDouble(0x3fd7ae3b09fb5c0cL), Double.longBitsToDouble(0x3fe28fa1c1f25cffL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27741.5, 28145.5]] |a1=[D:[[14395.0, 8915.0]]\0121=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 2, 3, 12, 10, "\ud8eb\udc13", "\u70a6\u45d6", "\u6051\uda6c\udcc2\ud804\udfc5\uda4b\udfaa\ud85f\udef8",
        59, 53184, -510895780, -6566166664209012310L, -56889L, false, true, (char) 22103, (char) 30678,
        Double.longBitsToDouble(0x3fe0df30206f02f7L), Double.longBitsToDouble(0x3fee262b63026184L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[D:[[]] |a1=[D:[[]]\012",
        Z.run(T, 1, 3, 12, 4, "", "", "\ud9e2\ude65\udaa1\udd4c\uda8f\ude4f\u6051\ud862\udd1d\000\ud893\ude08\uda99\udef5\ud9b6\udd48\ud882\udf67\uda3f\udf90\udb8f\udf81\uc787\udb40\udcea\udbfd\udd38\ud92d\udd8d\ud87c\udc1d",
        56, 88208, 1924618180, 7196819168413210811L, 22936L, true, false, (char) 16346, (char) 444,
        Double.longBitsToDouble(0x3fdbc09e8760152eL), Double.longBitsToDouble(0x3fcd3d2c1be33318L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 17, 1, 5, "\uda13\udde2\ud8b7\udcab\uda5b\ude5d", "\u024b\uc44e\uce7f", "\udbe4\ude50",
        7, 51746, 1307037984, -8902955647189330891L, -58044L, false, true, (char) 32583, (char) 45828,
        Double.longBitsToDouble(0x3fd1d944a2afc06cL), Double.longBitsToDouble(0x3fc518816692f788L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27703.0, 28265.5, 27715.5, 28221.5, 27707.5, 28441.5, 27945.0, 28555.0]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 12, 1, "\ud89e\udd03\ud8b7\udcab\ud8a7\ude63\uda82\udf46\udb31\udee5\uda39\udf36\ud9d9\udfdc\udaba\udf19\udb8e\udc59\udb30\uddec\ud8ed\ude50\udae7\udc44\ud974\uddb5\ud891\ude93\ud96c\udcaf\uda2e\udf2f\ud9e9\udcb5\udb40\uddce\udbfd\udd38\u185e\ueff9\uda65\udc26\udac7\udfc7\ud987\ude3e\ud8b6\udc67\udbf2\udf1f\ud8d1\udd92\uda26\udf3a\uda89\udd7e", "\u8434", "\udaa6\udd36\ud993\udd30",
        57, 11221, 833615783, -522933861232107757L, 19720L, false, false, (char) 9010, (char) 26467,
        Double.longBitsToDouble(0x3fe28e103bb87766L), Double.longBitsToDouble(0x3fe985f00abe06b9L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27682.5, 28137.5, 27715.5, 28221.5, 27925.5, 28438.5, 27945.0, 28555.0]]\0121=java.lang.Long:7318762181273452274\012",
        Z.run(T, 2, 3, 4, 1, "\ud875\udc03\ud8b7\udcab\uda5b\ude5d\uda82\udf46\udb31\udf4c\udaf3\udc68\uda0d\ude17\u6051\ud9e5\ude05\udb30\uddfa\ud8ed\ude50\ud8de\udc83\ud974\udd6f\ud891\ude93\ud8c7\udd47\uda24\udff0\ud9e9\udcb5\udb40\uddce\udbfd\udd38\uc25b\ueff9\uda44\ude16\udb6e\udd5a\ud984\udcca\udabc\udc6a\udbf2\udf1f\ud8d1\udd92\uda26\udf3a\ud8ed\udc46", "\u8434", "\udaa6\udd36\ud993\udd30",
        55, 62765, 833615783, 7318762181273546050L, -93776L, true, true, (char) 2199, (char) 65152,
        Double.longBitsToDouble(0x3fe28e103bb87766L), Double.longBitsToDouble(0x3fe985f00abe06b9L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27874.0, 28169.0, 27708.0, 28529.0, 27925.5, 28438.5, 27945.0, 28555.0]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 2, "\ud9f4\udc42\ud8a8\udf12\uda5b\ude5d\uda82\udf46\udb31\udf4c\udaf3\udc68\uda0d\ude17\u6051\udb8e\udc59\udb30\uddec\ud8ed\ude50\ud8de\udc83\ud974\udd6f\ud891\ude93\ud8c7\udd47\uda24\udff0\ud9e9\udcb5\udb40\uddce\udbfd\udd38\uc25b\ueff9\uda44\ude16\udb6e\udd5a\ud984\udcca\udabc\udc6a\udbf2\udf1f\ud8d1\udd92\uda26\udf3a\ud8ed\udc46", "\u8434", "\udaa6\udd36\ud993\udd30",
        55, 62765, 833615783, 7318762181273558803L, -93776L, true, true, (char) 2199, (char) 65152,
        Double.longBitsToDouble(0x3fe28e103bb87766L), Double.longBitsToDouble(0x3fe985f00abe06b9L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27682.5, 28137.5, 27715.5, 28221.5, 27925.5, 28438.5, 27945.0, 28555.0]]\0121=java.lang.Boolean:false |a0=[D:[[27682.5, 28137.5, 27715.5, 28221.5, 27925.5, 28438.5, 27945.0, 28555.0]]\012",
        Z.run(T, 2, 3, 3, 2, "\ud875\udc03\ud8b7\udcab\uda5b\ude5d\uda82\udf46\udb31\udf4c\udaf3\udc68\uda0d\ude17\u6051\udb8e\udc59\udb30\uddec\ud8ed\ude50\ud8de\udc83\ud974\udd6f\ud891\ude93\ud8c7\udd47\uda24\udff0\ud9e9\udcb5\udb40\uddce\udbfd\udd38\uc25b\ueff9\uda44\ude16\udb6e\udd5a\ud984\udcca\udabc\udc6a\udbf2\udf1f\ud8d1\udd92\uda26\udf3a\ud8ed\udc46", "\u8434", "\udaa6\udd36\ud993\udd30",
        55, 62765, 833615783, 7318762181273558803L, -93776L, true, true, (char) 2199, (char) 57440,
        Double.longBitsToDouble(0x3fe391e073f875e1L), Double.longBitsToDouble(0x3fe985f00fbe06b9L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27687.0, 28551.0, 28067.0, 28199.0, 27669.5, 28310.5, 28087.0, 28414.5]] |a1=[D:[[3624.5]]\0121=java.lang.Boolean:false |a0=[D:[[27687.0, 28551.0, 28067.0, 28199.0, 27669.5, 28310.5, 28087.0, 28414.5]] |a1=[D:[[3624.5]]\012",
        Z.run(T, 2, 3, 3, 11, "\ud87e\udf3e\udb76\udc7e\ud85b\udd5d\udb9e\ude2d\ud821\udcc4\udb0e\udd67\uda0d\ude17\ud997\udca9\ud9e1\udc1e", "\u1c81", "\ud9f5\ude42\uda4f\udca5\uda19\udf27\ud935\udef2\udbfd\udcd9\ud25d\ueff9\uda61\udd16\udb6e\udd5a\ud984\udcca",
        59, 95921, 1811828505, 2457700097803573531L, -69873L, true, true, (char) 26117, (char) 55832,
        Double.longBitsToDouble(0x3fe7b229d541a7d2L), Double.longBitsToDouble(0x3feceab652fd337fL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Long:-447793398\0121=java.lang.Long:-447793398\012",
        Z.run(T, 2, 4, 4, 16, "\ud96d\udeaf", "\000\000\u4074\uc266\ubc60\u70e3\u00ab\000\u7794", "\ud8d9\udf6e\udb05\udcb3",
        -5, -1000, 0, -447695611L, -97787L, true, false, (char) 48774, (char) 32634,
        Double.longBitsToDouble(0x3fe1ac451e758733L), Double.longBitsToDouble(0x3fd7ae3df7975c0cL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=void |a0=[D:[[28007.0, 28463.5]]\0121=void |a0=[D:[[28007.0, 28463.5]]\012",
        Z.run(T, 2, 12, 12, 18, "\udafe\ude8f", "\u94f3\ub080\u185a\u1014\u2e34\u1d02\u6da0\u0fd3\ucc74\u1cc4\u75b6\ubbb9\ua651\u0e46\u7e14\u4584\u5b3b\u44ce\u6d76\u9f9d\u2bf7\ub571\ucc76\u3862\u8cfe\ud743\u80f4\u53f9", "\ud9b4\udf7e\ud8e1\udeff\ud98a\udf9d\udb90\udcab\ud825\udc87",
        14, 25168, -1585884488, 603071935507757180L, 53062L, true, false, (char) 45274, (char) 45987,
        Double.longBitsToDouble(0x3fea6d760af70015L), Double.longBitsToDouble(0x3fd798f3811449a2L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Long:-2026823838866441437\0121=java.lang.Long:-2026823838866441437\012",
        Z.run(T, 2, 6, 4, 9, "\udb14\udc8f\udb2e\udf1c\ud8d9\ude4b\ud821\udffa\u2269\ud9e3\udf62\ud920\udcb6\u083b\uda1e\udcb1\ud80f\uddc4\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce", "\u4bea", "\udaeb\ude80",
        30, 23308, -2026644171, -2026823838866514345L, 72908L, false, true, (char) 26175, (char) 8045,
        Double.longBitsToDouble(0x3fd6c1d97bd04d34L), Double.longBitsToDouble(0x3fc8c4301d9db30cL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Long:7948407607587534338\0121=java.lang.Long:7948407607587534338\012",
        Z.run(T, 2, 6, 4, 9, "\udafe\ude8f\udb2e\udf1c\ud8d9\ude4b\ud821\udffa\udb01\udf85\udb3c\ude95\ud912\udf1b\u6051\ud9fb\udf4a\ud80f\uddc4\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\ud9fe\udc35\udaa5\udfad\ud9e9\udc41\udb40\uddce", "\u4bea\u3a05\u9f9d\u2917\u6e94", "\udbb9\udcc8\ud8ed\udca5\ud911\udc4b\u67cc\ud905\udd91\ud9da\udf0f\ud9b4\udf7e\ud9a7\ude71\ud999\udfe1\ud9a9\udd88\udb42\udf7c\uda75\udf6a\ud8a8\udfef\udbaf\udd40\u8153\ud905\udf2f\ud8c1\udfe8\udac2\udd45\ud8ad\ude93\u9893\udbdd\udcfa\uda61\udc64\udbda\ude0c\ud92c\udf5d\uda52\udf96\ud935\udc98\uda5e\udfeb",
        17, 57998, 1820529797, 7948407607587634055L, -99717L, false, true, (char) 13030, (char) 3705,
        Double.longBitsToDouble(0x3fe6d234d28feee2L), Double.longBitsToDouble(0x3feb0c7ce353b0a8L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Long:-8532111549734104003\0121=java.lang.Long:-8532111549734104003\012",
        Z.run(T, 2, 6, 6, 10, "\udafe\ude8f\udb2e\udf1c\ud8d9\ude4b\ud821\udffa\udb01\udf85\udb3c\ude95\ud912\udf1b\u6051\ud9fb\udf4a\ud80f\uddc4\ud977\udfe1\uda87\udccb\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce", "\u821b\ub0b7\u05cf\uacd5\u499a", "\uda81\udccc\ud8ed\udca5\ud910\udfa3",
        56, 2554, 648882376, -8532111549734178409L, 74406L, true, false, (char) 19802, (char) 12605,
        Double.longBitsToDouble(0x3fc5c423b415248cL), Double.longBitsToDouble(0x3fe0d4a8c9b5f1a2L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 0, 0, 0, "\000", "\ub42d", "\ud8c4\ude09\000\uda6c\udcaa\ud804\udfc5\u00a2\000",
        57, 54632, 22784, 39220L, -99823L, false, false, (char) 398, (char) 11,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 1, 12, 9, 2, "\uea8b\004\udbdb\ude5d", "\u024b\uaab9\000", "\udb35\udff5\u96c0",
        57, 54632, 22784, 1454637389719007380L, 8602L, false, true, (char) 26045, (char) 0,
        Double.longBitsToDouble(0x3fd57e036100d216L), Double.longBitsToDouble(0x3d98d96000000000L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 1, 2, 15, "\000\udbb8\udf5b", "\uae9a\u024b\uaab9\u3f0a\u0a4b\u57ef\u00a2", "\uda95\udc89",
        3, -1000, 13587200, 7205759405344118726L, -99823L, false, false, (char) 398, (char) 204,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=void |a0=[D:[[27674.5, 28561.0]]\0121=void |a0=[D:[[27674.5, 28561.0]]\012",
        Z.run(T, 2, 11, 11, 11, "\ud865\udf52", "\u8d2d\u81c2\u2fdc\uc4b9", "\ud804\udfc5\udbd8\udead\udb3b\udedc\ud987\ude7f\ud9d7\ude1b",
        35, 35920, 4950117, 6189916212999701397L, -70225L, true, false, (char) 25329, (char) 62151,
        Double.longBitsToDouble(0x3fc7d12c2b917fa0L), Double.longBitsToDouble(0x3fe1ac4518758733L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[D:[[-24.0]] |a1=[D:[[-24.0]]\012",
        Z.run(T, 1, 3, 0, 11, "\000", "\000", "",
        -5, -1000, -100663296, 7067628492980555056L, -77216L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3f39001800000000L), Double.longBitsToDouble(0x3fed893800000000L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Integer:-1005\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 5, 9, 14, "\u00a4\000\udbf9\udf7b\ud90a\udd02\ud99b\ude6c\ud80a\udd32\u66bf\udbdf\udd15\udb35\udfd9\ud96f\uddda\ud8f9\udca7\ud9db\udd84\ud84a\udc0f\ud925\uddb7\ud948\udee2\udaa5\udfbd\udbdf\ude9c\udbd1\ude9f\udadf\udfd4\ud8f9\udda9\ud87c\udc1d", "\ud64b", "\ud8a1\ude9f\ud8e6\ude71\ud8fe\udc7d\ud911\udc4b\000",
        -5, -1000, 255076864, 2766743683146487272L, -99758L, true, false, (char) 8980, (char) 91,
        Double.longBitsToDouble(0x3fc7742f20000000L), Double.longBitsToDouble(0x3e1b3ee000000000L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=void |a0=[D:[[22787.0, -9.0]]\012",
        Z.run(T, 1, 12, 6, 9, "\ub236\036", "\u81c2\u7a8ef\ua469\uc5e9\ub9fa\u1050\u7727", "\u11ba\ud9c4\ude70\udae2\ude5e\udba1\udc79\udbfd\udd12\udb2a\udc8b\000\ud8d2\udd88\udb49\udd9a\u00a8\udb57\uddf8",
        5, 97509, -474959755, 3797590079491198362L, 31072L, true, true, (char) 7456, (char) 42376,
        Double.longBitsToDouble(0x3fde8b8670000172L), Double.longBitsToDouble(0x3dff9d1f80000000L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=void |a0=[D:[[29653.0, 24574.0]]\012",
        Z.run(T, 1, 12, 0, 9, "\ue7da\uc02c", "", "\udaf8\udf73\ud955\udf2a\udaee\udffa\ud807\udfce\ud9f8\ude12\uda99\ude88",
        59, 96984, -2072903680, 4100306554182223751L, -56896L, false, true, (char) 58832, (char) 58728,
        Double.longBitsToDouble(0x3fe718d24ca82e1fL), Double.longBitsToDouble(0x3e4c430400000000L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[-24.0, -24.0, 28066.0, 28306.0, 27716.5, 28436.5, 27865.0, 28442.5]] |a1=[D:[[-24.0, 26767.5, 15282.0, 3658.0, 7918.0, 14986.0, 10641.5, 7122.0]]\012",
        Z.run(T, 1, 3, 12, 4, "\000\000\udb74\udd54\ud8b9\ude59\ud9e2\ude65\udaa1\udd4c\uda8f\ude4f", "\000\ud14f\u7794\u1cc4\u3e0c\u7544\u5353\u37d4", "\ud92d\udd8d\ud87c\udc1d",
        56, 88208, 1924618180, 7196819168413210811L, 22936L, true, false, (char) 16346, (char) 444,
        Double.longBitsToDouble(0x3fdbc09e8760152eL), Double.longBitsToDouble(0x3fcd3d2c1be33318L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27874.0, 28169.0, 27708.0, 28529.0, 27925.5, 28438.5, 27945.0, 28555.0]] |a1=[D:[[720.0, 474.5, 24483.5, 19017.5, 9029.5, 10425.5, 27582.0, 1906.0]]\0121=java.lang.Double:54745.03661292044 |a0=[D:[[27874.0, 28169.0, 27708.0, 28529.0, 27925.5, 28438.5, 27945.0, 28555.0]] |a1=[D:[[720.0, 474.5, 24483.5, 19017.5, 9029.5, 10425.5, 27582.0, 1906.0]]\012",
        Z.run(T, 2, 3, 15, 6, "\ud9f4\udc42\ud8a8\udf12\uda5b\ude5d\uda82\udf46\udb31\udf4c\udaf3\udc68\uda0d\ude17", "\u05d0\u03e5\ubf77\u94c3\u46bb\u51a3\ud7ac\u0f14", "\uc25b\ueff9",
        57, 3020, -1117162313, -1496398339155406288L, 34241L, false, false, (char) 55832, (char) 47523,
        Double.longBitsToDouble(0x3fd41a7d2cb9fdccL), Double.longBitsToDouble(0x3fe7e99e3fa76f3cL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27682.5, 28137.5, 27715.5, 28221.5, 27925.5, 28438.5, 27945.0, 28555.0]] |a1=[D:[[10425.5, 27582.0, 1906.0, 8538.5, 11926.5, 4328.5, 19965.0, 14662.0]]\0121=java.lang.Boolean:false |a0=[D:[[27682.5, 28137.5, 27715.5, 28221.5, 27925.5, 28438.5, 27945.0, 28555.0]] |a1=[D:[[10425.5, 27582.0, 1906.0, 8538.5, 11926.5, 4328.5, 19965.0, 14662.0]]\012",
        Z.run(T, 2, 3, 3, 2, "\ud875\udc03\ud8b7\udcab\uda5b\ude5d\uda82\udf46\udb31\udf4c\udaf3\udc68\uda0d\ude17\u6051\udb8e\udc59\udb30\uddec\ud8ed\ude50\ud8de\udc83", "\u51a3\ud7ac\u0f14\u42e5\u5d5d\u2201\u9c2a\u72bc\uc7c9\uca21", "\ud8d1\udd92\uda26\udf3a\ud8ed\udc46\ud8fb\udf72\ud9f5\ude9a\udbb5\udf3a\ud918\udeee\ud929\udebd\udaa6\udd36\ud993\udd30\ud967\udf0d\uc95a\uda5a\ude94\ud88c\udd8c",
        30, 61909, -1178068912, 2747584349267092086L, -46L, false, true, (char) 39217, (char) 30327,
        Double.longBitsToDouble(0x3fecec47d9bc2732L), Double.longBitsToDouble(0x3fe809f2bf8bff4aL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Long:7415557513943354020\0121=java.lang.Long:7415557513943354020\012",
        Z.run(T, 2, 6, 4, 9, "\udb14\udc8f\udb2e\udf1c\ud8d9\ude4b\ud821\udffa\u2269\ud9e3\udf62\ud920\udcb6\u083b\uda1e\udcb1\ud80f\uddc4\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce", "\u4bea", "\udaeb\ude80",
        11, 25992, -732907346, 7415557513943281112L, 72908L, false, true, (char) 26175, (char) 8045,
        Double.longBitsToDouble(0x3fe360ecbde8269aL), Double.longBitsToDouble(0x3fc8c4301d9db30cL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.Integer:54689\0121=java.lang.Integer:54689\012",
        Z.run(T, 2, 5, 5, 8, "\000", "\ub42d", "\ud8c4\ude09\000\uda6c\udcaa\ud804\udfc5\u00a2\ud9a4\udc00",
        57, 54632, 22784, -1958497390394566345L, -99823L, false, false, (char) 398, (char) 53,
        Double.longBitsToDouble(0x3fdb4db980541efeL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=void |a0=[D:[[29997.5, -22.0, -24.0]]\012",
        Z.run(T, 1, 12, 9, 2, "\uea8b\004\000", "\u024b\uaab9\000", "\udb35\udff5\u96c0",
        57, 54632, 22784, 1454637389719007380L, 8602L, false, true, (char) 26045, (char) 0,
        Double.longBitsToDouble(0x3fd57e036100d216L), Double.longBitsToDouble(0x3d98d96000000000L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 1, 12, 15, 2, "\000\000\udaeb\udc72\000\000", "\u59d7", "\udb59\udf1a\ub5b6\ud87b\udf9e\uda95\udc89\u5900\000\000",
        24, 84157, 654320580, 153593159090176L, -41777L, false, false, (char) 20687, (char) 21137,
        Double.longBitsToDouble(0x3fedd42c802b5459L), Double.longBitsToDouble(0x3fdcb73d276da814L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 1, 12, 0, 9, "\ue742\uc02c\000\000\ud9d9\ude05\ud848\udd4c\udaf8\udf73\udb8a\udd27\udaee\udffa\ud807\udfce\ud9f8\ude12\uda7a\udc29\ud9b6\udd48\ud925\uddb7\udbee\udcb7\ud9c4\ude70\udae2\ude5e\udbdd\ude19\ud86c\udf10\ud926\ude78\udbff\uded7\uda22\udfa9\udb49\udcd9\u64a8\ud83d\udfcd\ud96d\udd0d\uda08\ude11\u287d\udaa4\udd78\ud80d\udd31\ud91c\udfad\ud9e4\udf84\udb78\udc75\u2826\ud909\udf11\ud972\ude49\ud92b\uddbe\udb44\ude02\ud9a3\udc32\ud8ac\udd99\u518f\ud82a\ude9a\udb74\udd87\ud9c2\udd52", "\u9b24\u4578\u5e78\u1171\uc300\u1007\u5458\ub973\uadac\u7cff\u8a3c\uc097\u682f\ub9e1\u20ae\u8fbc", "\uda2b\uddf7\u59e3\udbec\udef9\ud82c\ude1d\ud987\udf38\udb07\udf1a\udae9\ude28\ubb66\uda27\ude51\uda59\udfc5\udb0a\udff9\udbab\udee0\u5362\ud814\udcac\ud96e\udd3b\ud8d6\udead\ud896\udde9\uda5c\uddee\udb36\udc88\uda28\udcb5",
        9, 90467, 649895634, -27157292773229704L, 35443L, true, true, (char) 18072, (char) 36301,
        Double.longBitsToDouble(0x3fe179c679cc2863L), Double.longBitsToDouble(0x3fb17f5790805188L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 1, 12, 0, 9, "\u97eb\uc02c\ud870\udf58\ua13f\ud9d9\ude05\ud848\udd4c\udaf8\udf73\ud955\udf2a\udaee\udffa\ud807\udfce\ud9f8\ude12\uda99\ude88\ud9b6\udd48\ud925\uddb7\udbee\udcb7\ud9c4\ude70\udae2\ude5e\udbb2\ude79\uda37\ude11\udb2a\udc8b\ud87c\udc1b\uda22\udfa9\udb49\udd9a\u64a8\uda13\udc49\uda01\udd37\ud905\udd45\ud941\udd16\udbe0\udeb0\ud8ad\udd73\ud83a\ude4b\udb50\udfb2\ud897\uddcc\u2707", "\u3f91\u8690\u12d9\u8fd2\ua03b\u1a80\uad65\u2e95", "\ud98a\udeca\ud877\udf06\ud970\udc17\ud975\udcc8",
        2, 96085, -178858424, -3526607956844987173L, -58039L, true, false, (char) 40260, (char) 40013,
        Double.longBitsToDouble(0x3fd6ae996e3ee98aL), Double.longBitsToDouble(0x3fd0c73aa923f7acL)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 1, 12, 13, 8, "\ue7bf\uc02c\000\000\ud9d9\ude05\ud848\udd4c\udaf8\udf73\udbd6\uddbf\udaee\udffa\ud800\udd9a\ud9f8\ude12\uda99\ude88\ud9b6\udd48\ud925\uddb7\udbee\udcb7\ud9c4\ude70\udae2\ude5e\udbb2\ude79\udbfd\udd12\udb2a\udc8b\ud87c\udc1b\uda22\udfa9\udb49\udd9a\u64a8\uda13\udc49\uda80\uddb6\ud938\udddc\ud9dc\udd5e\ud95d\udd40\uda39\udf50\u3708\ud9d3\udc39\u9550\uda21\udc57\ud845\udc61\udbe1\udf30\udbf2\uddfa\ud885\udf8b\ud8ca\ude14\uda69\udfcb\ud991\udc5b\uda67\udf59\udb00\ude6a\ud8e7\udc0a\ud9fe\udc35\u3984\udac1\udfaa\ud87c\udf79\udbe5\udc26\udb3d\ude12\uda71\udc90", "\u2303\u4c99\u8add\ua4b1\u0465\u7c6b\ucff9\u6f89\u9d9f\u8081\u5eaf\u1e9d\uc0f3\ua968\ubd54\u5065\uc33b\u92c9\u0857\ucecf\ucad3\uc431\u3562\u1e9c\u1622\u807b\u9b2e", "\ud84f\uddb6\u01a2\uda49\ude9e\udbd9\udeaf\ud85e\udf21\udb75\udef0\udba2\ude4a\ud92e\udd31\udbcf\udfff\ud845\ude06\uda62\udce1\u74a4\ud9f7\udd75\udbac\udc63\uda12\udebf\ud9fd\udd4d\udaa4\udf38",
        -1, 99213, -1760749294, 2151813701305175921L, 56957L, false, true, (char) 18222, (char) 832,
        Double.longBitsToDouble(0x3fab1e346c76aa40L), Double.longBitsToDouble(0x3fef458daa4b6567L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.Long:2770806048089882017\012",
        Z.run(T, 1, 6, 2, 10, "\ud874\udfd8", "\ube41\u6593\u024b", "\uda6c\udcc2\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud85f\udef4\udae4\udd08\udaa5\udf8c\ud9e9\udc41\udb40\uddce\udbfd\udd38\ud92d\udd8d\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\uda20\udcc2\udb73\udc45\ud86b\udffa\uda75\udd48\ud829\ude8d\ud9c0\uddc4\ud9d7\udc99\u67cc",
        54, 57376, 496490944, 2770806048089886460L, -4443L, false, false, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a23f5e2d0L), Double.longBitsToDouble(0x3fe9910244b16ebbL)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.Double:15190.933060546347 |a0=[D:[[27649.0, 28356.0]] |a1=[D:[[18046.5, 16585.0, 12253.5, 1766.5]]\0121=java.lang.Double:15190.933060546347 |a0=[D:[[27649.0, 28356.0]] |a1=[D:[[18046.5, 16585.0, 12253.5, 1766.5]]\012",
        Z.run(T, 2, 15, 15, 8, "\ud832\uddb8", "\u8d2d\u81c2\u5feb\u0dfd", "\ud804\udfc5\udbd8\udead\udb3b\udedc\ud987\ude7f\ud9d3\udc1b",
        35, 35920, 4950117, 7205759403398485958L, -70225L, true, false, (char) 25329, (char) 8427,
        Double.longBitsToDouble(0x3fc7d12c2b917fa0L), Double.longBitsToDouble(0x3fe1ac4518758733L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 13, 13, 10, "\ud874\udfd8", "\u942d\u4634\u9fa7\uc44e\u1550\u1675\u57ef\u05f3\u9e2d\u2eae\u426f\u7e62\ud76d\ubf34\u79b9\u9bf1", "\uda9c\udf6a\ud9b7\uddce\uda20\udcc2",
        47, 4066, -2026668491, 2571749402410899834L, -69873L, false, true, (char) 26052, (char) 109,
        Double.longBitsToDouble(0x3fd6c1d97bd04ce6L), Double.longBitsToDouble(0x3fe9310c00408637L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Long:1\012",
        Z.run(T, 2, 9, 7, 13, "\uda13\ude0a\udb45\udc4e\u984d\udad3\ude4a\udba7\udc37", "\u96f1", "\ud8f6\udf5f\uda99\udef5\uda51\udf56\udaba\udea2\udbf4\udd8c\ud877\udfb6\ud93b\uddcb\ud8cb\udf83\udbfb\udf10\udb6c\ude32\udb55\udc79\ud8d9\ude37\ud889\udfd5\uda20\udcc2\udb73\udc45\ud8c2\udfc7\ud967\udc05\ud921\udc57\uda89\udc65\ud8db\udcff\u67cc\ud905\udd91\ud9da\udf0f\ud9b4\udf7e\udaae\udfb6\ud9d0\udc46\udb64\udeb8\uda9b\udc1e\u4a44\uda5d\udea8\ud982\udc7d\udaae\udf66\ud978\udd47\uda96\udcdc\ud996\udc36\uda1d\udfe1\ud96e\udc9c\udb2b\udec1\ud97f\ude80\udbb0\udf59\udb8b\udd02\udb63\udf6c",
        10, -490, 776630381, -2080695535791431399L, 60601L, false, true, (char) 4342, (char) 30738,
        Double.longBitsToDouble(0x3fc0891f7a6a7af0L), Double.longBitsToDouble(0x3fee64eed8791acdL)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[-24.0, -24.0, 28066.0, 28306.0, 27716.5, 28436.5, 27865.0, 28322.5]] |a1=[D:[[-24.0, -24.0, 12112.0, 20329.0, 7918.0, 14986.0, 10641.5, 7122.0]]\012",
        Z.run(T, 1, 3, 12, 4, "\000\000\udb74\udd54\ud8b9\ude59\ud9e2\udd75\udaa1\udd4c\uda8f\ude4f", "\000\000\u5ed0\u9f02\u3e0c\u7544\u5353\u37d4", "\u233c\000",
        -5, 88600, 1924618180, 7196819167373220027L, -100000L, true, false, (char) 16346, (char) 444,
        Double.longBitsToDouble(0x3f03d0ec00000000L), Double.longBitsToDouble(0x3fcd3d2c1be33318L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 1, 12, 15, 8, "\ue7bf\uc02c\u2455\000\ud9d9\ude05\ud898\udcab\uda14\udf8e\udbd6\uddbf\udaee\udffa\ud800\udd9a\ud9f8\ude12\ud996\uddc6\ud89e\udfd9\udb72\udfd7\udb23\ude51\ud942\ude6f\udae2\ude5e\udbd6\udc61\ud8c7\udee0\udb2a\udc8b\ud87c\udc1b\uda22\udfa9\udb49\udd9a\u64a8\uda13\udc49\ud8f3\uddcf\ud90c\udc38\ud9dc\udd5e\udb6b\udd79\ud9a6\ude95\ud974\ude49\ud9d3\udc39\u9550\uda21\udc57\ud845\udc61\udbe1\udf30\udbf2\uddfa\ud9f9\udc06\udb21\udeb5\uda69\udfcb\ud991\udc5b\uda67\udf59\udb00\ude6a\ud8e7\udc0a\ud813\ude21\u3984\udac1\udfaa\ud87c\udf79\udbe5\udc26\udb3d\ude12\uda71\udc90", "\u2303\u4c99\u8add\ua4b1\u0465\u76ca\u0384\u6f89\u9d9f\u8081\u5eaf\u1e9d\uc0f3\u5427\u56d9\uc94a\u663b\u92c9\u0857\ucecf\ucad3\uc431\u3562\u1e9c\u1622\u807b\u9b2e", "\ud84f\uddb6\u01a2\uda49\ude9e\udbd9\ude16\ud85e\udf21\udb9c\udfc1\udb97\udf4a\ud92e\udd31\udbcf\udfff\ud845\ude06\uda62\udce1\u74a4\ud9f7\udd75\udbac\udc63\uda12\udebf\ud9fd\udd4d\udaa4\udf38\uda28\udfd0\ud819\udd95\udbb8\uddfa\ud9f8\udd51\udb7a\udceb\uda1f\udc57\u272e\udb3a\ude49\udbd4\udffa",
        21, 80373, 1013497910, 7684311075280737991L, 74510L, true, false, (char) 21418, (char) 21033,
        Double.longBitsToDouble(0x3fee0297015c4620L), Double.longBitsToDouble(0x3fd8b5624e98f754L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.Double:31.295861910686444\012",
        Z.run(T, 1, 9, 2, 10, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\uda03\ude2e\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c",
        49, 28, 332794331, 2823243901434563505L, -16452L, false, false, (char) 1753, (char) 6162,
        Double.longBitsToDouble(0x3febd71d84d328f0L), Double.longBitsToDouble(0x3fe28fa1c1f25cffL)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Double:3.9049918716424E13\012",
        Z.run(T, 1, 8, 2, 10, "\ud874\udfd8", "\ucbb4\u81c2\u2966", "\uda03\ude34\udb38\uddbe\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud8e7\uddb8\u129a\udaa5\udf8c",
        49, 28, 332794331, 2823243901434563505L, -16452L, false, false, (char) 1880, (char) 5959,
        Double.longBitsToDouble(0x3febd71d867d99f0L), Double.longBitsToDouble(0x3fe0a04ab9f25cffL)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.Double:8.410720946905721\012",
        Z.run(T, 1, 9, 2, 10, "\ud874\udfd8", "\u7d7b\uba1d\u3959", "\ud857\udc1f\ud10a\ud8cc\udeaa\uda99\ude61\ud9b6\udd48\ud925\ude40\u11ba\udaea\udf4e",
        31, 28, 332794331, 2823243901434563505L, 59455L, true, false, (char) 59896, (char) 2526,
        Double.longBitsToDouble(0x3f994f8034d439e0L), Double.longBitsToDouble(0x3fee8f79d9bbbd21L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.Double:15.721271105440144\012",
        Z.run(T, 1, 9, 2, 10, "\ud874\udf68", "\ub42d\u81c2\u024b", "\uda03\ude2e\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\uda84\udd5b",
        35, 28, 332794331, 2823243901434563505L, -16452L, false, false, (char) 1753, (char) 6162,
        Double.longBitsToDouble(0x3febd71d84d328f0L), Double.longBitsToDouble(0x3fe28fa1c1f25cffL)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.Double:24.690917079824857\012",
        Z.run(T, 1, 9, 2, 10, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\uda03\ude2e\ud804\udfc5\udbac\udffb\udaad\udc35\ud9b6\udd48\ud91f\uddb4\ud955\udfd0\ud916\udf4f",
        42, 28, 332794221, 2823243901434563505L, -81988L, false, false, (char) 1753, (char) 6162,
        Double.longBitsToDouble(0x3febd71d84d328f0L), Double.longBitsToDouble(0x3fe28fa1c1f25cffL)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.Double:3.367295829986474\012",
        Z.run(T, 1, 9, 2, 10, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\uda03\ude2e\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\ud819\udfa7",
        29, 28, 332794331, 2823243901434563505L, -16452L, false, false, (char) 1753, (char) 6162,
        Double.longBitsToDouble(0x3febd71d84d328f0L), Double.longBitsToDouble(0x3fe28fa1c1f25cffL)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.Long:29\012",
        Z.run(T, 1, 7, 2, 10, "\ud874\udfd8", "\ub42d\u1550\u024b", "\uda03\ude2e\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\ud6b1\ud819\udfa7",
        29, 28, -30930469, 2823243901434563505L, -16452L, false, false, (char) 1753, (char) 6162,
        Double.longBitsToDouble(0x3febd71d84d328f0L), Double.longBitsToDouble(0x3fe28fa1c1f25cffL)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.Double:29.0\012",
        Z.run(T, 1, 8, 2, 10, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\uda03\ude2e\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\udad2\udd87\udbed\udccb\ud819\udfa7",
        29, 28, -321517093, 2823243901434563505L, 46965L, false, false, (char) 1753, (char) 6162,
        Double.longBitsToDouble(0x3febd71d84d328f0L), Double.longBitsToDouble(0x3fe28fa1c1f25cffL)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.lang.Long:2770806050297775245\012",
        Z.run(T, 1, 6, 2, 10, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\ud9cc\udd2b\ud95d\udc7c\udbae\udc09\uda19\udd86\ud9b6\ude09\ud925\uddb7\uda4c\uddbd\udaa5\udf8c\ud9e9\udc41\udb40\uddce\udbfd\udd38\ud92d\udd8d\uda5f\udeae\ud9eb\udd26\ud9b7\uddce\uda20\udcc2\udb73\udc45\ud8c2\udfc7\uda21\udf16\udb95\udec9\ud8ed\udca5\ud911\udc4b\u67cc",
        54, 57376, 496490944, 2770806050297779688L, -4443L, false, false, (char) 21826, (char) 7911,
        Double.longBitsToDouble(0x3fe03f2a23f5e2d0L), Double.longBitsToDouble(0x3fe9910244b16ebbL)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 1, 12, 0, 17, "\000\000\000\uda4f\udc47\ud9d9\ude05\udb00\udd48\uda83\udf4f\u6051\uda6c\udcc2\u42ab\ud8cc\udeaa\uda99\udef5\udbf7\ude68\ud92a\ude5a\002\udaa5\udf57\ud9e9\udc41", "\ub1d8\u4bbe", "\uda20\udcc2",
        38, 64648, -2026668491, -2039936616016488070L, -100000L, false, false, (char) 26175, (char) 109,
        Double.longBitsToDouble(0x3fd396297bd04ce6L), Double.longBitsToDouble(0x3fc8c430159db30cL)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 8, 9, 14, "\udabb\udfc1\000\ud9a0\uddb7\ud980\udcae\udb60\udeaf\ud80a\udd32\u66bf\udbdf\udd15\udb35\udfd9\ud96f\uddda", "\u65a8\u7575\ub169\u0856\ub089\u2adf\u71cc", "\u5267\ud8b3\udde8\uda20\udc3b\ud8a1\udedf\udbee\ude7c\ud8b2\udc00\udada\udf4c\ud8fe\udc82",
        15, -1000, 0, 255076864L, -61624L, false, true, (char) 28027, (char) 43583,
        Double.longBitsToDouble(0x3fd3079e40f400b6L), Double.longBitsToDouble(0x3fee525bca0037a5L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 9, 9, 13, "\uda13\ude0a\udb45\udc4e\u984d\udad3\ude4a\udba7\udc37", "\u96f1", "\ud8f6\udf5f\uda99\udef5\uda51\udf56\udaba\udea2\udbf4\udd8c\ud877\udfb6\ud93b\uddcb\ud8cb\udf83\udbfb\udf10\udb6c\ude32\udb55\udc79\ud8d9\ude37\ud889\udfd5\uda20\udcc2\udb73\udc45\ud8c2\udfc7\ud967\udc05\ud921\udc57\uda89\udc65\ud8db\udcff\u67cc\ud905\udd91\ud9da\udf0f\ud9b4\udf7e\udaae\udfb6\ud9d0\udc46\udb64\udeb8\uda9b\udc1e\u4a44\uda5d\udea8\ud982\udc7d\udaae\udf66\ud978\udd47\uda96\udcdc\ud996\udc36\uda1d\udfe1\ud96e\udc9c\udb2b\udec1\ud97f\ude80\udbb0\udf59\udb8b\udd02\udb63\udf6c",
        5, -490, 776630381, -2080695535791431399L, 60643L, false, true, (char) 4342, (char) 30738,
        Double.longBitsToDouble(0x3fc0891f7a6a7af0L), Double.longBitsToDouble(0x3fee64eed8791acdL)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=java.lang.Double:52240.632076478556 |a0=[D:[[28029.5, 28609.0, 27777.5, 28636.0, 28045.0, 28278.0, 27976.0, 28457.0]] |a1=[D:[[859.5, 8766.5, 10045.0, 2471.0, 26295.0, 24527.0, 4899.0, 21498.5]]\0121=java.lang.Double:52240.632076478556 |a0=[D:[[28029.5, 28609.0, 27777.5, 28636.0, 28045.0, 28278.0, 27976.0, 28457.0]] |a1=[D:[[859.5, 8766.5, 10045.0, 2471.0, 26295.0, 24527.0, 4899.0, 21498.5]]\012",
        Z.run(T, 2, 15, 15, 0, "\udb2b\udfb2\ud933\udfe8\udb4a\udd1c\udac0\ude82", "\u06e7\u44ad\u4eaa\u137e\ucd9e\ubfce\u2676\ua825\u73db\u8415", "\ud917\udfd5\udabc\ude43\uda9b\udfbb\ud98d\udf8b\ud83b\udd72\ud80e\ude13",
        21, 53874, 1458954488, -4372925761407028859L, -66059L, true, true, (char) 57685, (char) 27159,
        Double.longBitsToDouble(0x3fdea091f1077fd2L), Double.longBitsToDouble(0x3fefef6dcfdd7290L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\012",
        Z.run(T, 1, 9, 2, 10, "\uda52\udda7", "\ub42d\u81c2\u024b", "\uda03\ude2e\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\ud819\udfa7",
        28, 28, 332794331, 2823243901434563505L, -16452L, false, false, (char) 1753, (char) 6162,
        Double.longBitsToDouble(0x3febd71d84d328f0L), Double.longBitsToDouble(0x3fe28fa1c0afa5c0L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.Long:1\012",
        Z.run(T, 1, 7, 2, 10, "\ud874\udfd8", "\ub42d\u1550\u024b", "\uda03\ude2e\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\ud6b1\ud819\udfa7",
        28, 28, -30930469, 2823243901434563505L, -16452L, false, false, (char) 1753, (char) 6162,
        Double.longBitsToDouble(0x3febd71d84d328f0L), Double.longBitsToDouble(0x3fe28fa1c1f25cffL)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 8, 8, 14, "\udabb\udfc1\000\ud9a0\uddb7\ud980\udcae\udb60\udeaf\ud80a\udd32\u66bf\uda0b\udc2b\udb35\udfd9\ud96f\uddda", "\u65a8\u7575\ub169\u0856\u359f\u2adf\u71cc", "\udb4d\ude83\udb50\udd75\uda20\udd0d\ud8a1\udedf\udbee\ude7c\ud8b2\udc00\udada\udf4c\ud8fe\udc82",
        15, -1000, 45148, 255076864L, -61624L, false, true, (char) 28027, (char) 43583,
        Double.longBitsToDouble(0x3fd3079e40f400b6L), Double.longBitsToDouble(0x3fee525bca0037a5L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\012",
        Z.run(T, 1, 8, 2, 3, "\ud874\udfd8", "\u6e41\u14c8\u024b", "\uda03\ude2e\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\ud6b1\ud819\udfa7",
        28, 28, -30930469, 2823243901434563505L, -16452L, false, false, (char) 1753, (char) 6162,
        Double.longBitsToDouble(0x3febd71d84d328f0L), Double.longBitsToDouble(0x3fe28fa1c1f25cffL)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=java.lang.Long:2770806050297854072\012",
        Z.run(T, 1, 6, 2, 10, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\uda6c\udce9\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\udaa5\udf8c\ud9e9\udc41\udb40\uddce\udbfd\udd38\ud92d\udd8d\ud87c\udc1d\ud982\udf3d\ud9b7\uddce\uda20\udcc2\udb73\udc45\ud8c2\udfc7\uda82\uddc6\ud8cd\udca7\ud977\uddf2\ud911\udc4b\u67cc",
        26, 71330, 496490944, 2770806050297779688L, 74384L, false, false, (char) 64771, (char) 32986,
        Double.longBitsToDouble(0x3fc31215507b8b20L), Double.longBitsToDouble(0x3fe03f2a23f5e2d0L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 1, 12, 13, 8, "\ue7bf\uc02c\000\000\000\ud81d\udded\udaf8\udf73\udbd6\uddbf\udaee\udffa\ud800\udd9a\ud9f8\ude12\uda99\ude88\ud9b6\udd48\ud925\uddb7\udbee\udcb7\ud9c4\ude70\udae2\ude5e\udbb2\ude79\udbfd\udd12\udb2a\udc8b\ud87c\udc1b\uda22\udfa9\udb49\udd9a\u64a8\uda13\udc49\uda80\uddb6\ud938\udddc\ud9dc\udd5e\ud95d\udd40\uda39\udf50\u3708\ud9d3\udc39\u9550\uda21\udc57\ud845\udc61\udbe1\udf30\udbf2\uddfa\ud885\udf8b\ud8ca\ude14\uda69\udfcb\ud991\udc5b\uda67\udf59\udb00\ude6a\ud8e7\udc0a\ud9fe\udc35\u3984\udac1\udfaa\ud87c\udf79\udbe5\udc26\udb3d\ude12\uda71\udc90", "\u2303\u4c99\u8add\ua4b1\u4b3a\u7c6b\ucff9\u6f89\u9d9f\u8081\u5eaf\u1e9d\uc0f3\u08c4\ubd54\u5065\uc33b\u92c9\uc556\ucecf\ucad3\uc431\u3562\u1e9c\u1622\u807b\u9b2e", "\ud84f\uddb6\u01a2\uda49\ude9e\udbd9\udeaf\ud85e\udf21\udb75\udef0\udba2\ude4a\ud92e\udd31\udbcf\udfff\ud845\ude06\uda62\udce1\u74a4\ud9f7\udd75\udbac\udc63\uda12\udebf\ud9fd\udd4d\udaa4\udf38",
        -1, 99213, -1760749294, 2151813701305175921L, 56957L, false, true, (char) 18222, (char) 832,
        Double.longBitsToDouble(0x3fab1e346c76aa40L), Double.longBitsToDouble(0x3fef458da84b6567L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NonMonotonousSequenceException\012",
        Z.run(T, 2, 12, 0, 9, "\u97eb\uc02c\ud870\udf58\uf929\ud9e9\ude05\ud848\udd4c\udaf8\udf73\ud955\udf2a\udaee\udffa\ud807\udfce\ud8a3\ude49\udb11\udf18\ud9b6\udd48\ud9e9\udcaf\u0fdb\ud9c4\ude70\ud8c1\udf4e\uda06\udee3\ud800\uddf1\udb59\udffa\ud88a\udefb\uda35\udf73\ud90c\ude46\u64a8\uda13\udc49\uda88\ude3a\ud905\udd45\ud941\udd16\udbe0\udeb0\ud8ad\udd73\ud83a\ude4b\udb50\udfb2\ud897\uddcc\u2707", "\u3f91\u8690\u12d9\u8fd2\ua03b\u0822\u6399\u6b5e", "\udb2b\uddb8\udba7\udd4d\ud970\udc17\ud975\udcc8\ud956\ude8e",
        16, 84734, 1242495167, 9098072594516601632L, 49733L, true, true, (char) 47529, (char) 40260,
        Double.longBitsToDouble(0x3fd280726ad5d32cL), Double.longBitsToDouble(0x3fe8f941329b73aaL)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=java.lang.Double:30.0\012",
        Z.run(T, 1, 8, 6, 18, "\ud8f3\udf36\ud8ed\udddd\ud887\udec2", "\u8abb\u21f3\ud352\u4f79\u0f0b\u5135\u7387\ucfe8\u7651\ua39c\u317b\ud6f5\u4ea6\u8a64\u10d6\u8e8f\u540a\u6ed4\ua531\ub03e\u4fb9\ucdd3\u1823\u7e59\u2711\u0459\uc795\u012e\u3893\u587c\u2346\u015a\u0174", "\udbaf\udc98\udba3\udcdb\ud80c\ude12\ud902\udc76\ud980\udfbf\udb74\udc76",
        30, 1, -2083740495, 6482093903356673066L, -94342L, false, false, (char) 23844, (char) 39712,
        Double.longBitsToDouble(0x3fc609bbe9c38230L), Double.longBitsToDouble(0x3fbad153dd658510L)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 17, 17, 1, "\udbbc\udc09", "\ub42d", "\ud8c4\ude09\udb8a\udda4\ud837\uddd6\uda6e\udfeau\udb18\udc0b",
        57, 54632, 22784, -4125626010978395423L, -99823L, false, false, (char) 398, (char) 11,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test122() throws Throwable {
    assertEquals("0=java.lang.Long:30\012",
        Z.run(T, 1, 7, 6, 18, "\ud8f3\udf36\ud8ed\udddd\ud887\udec2", "\u8abb\u21f3\ud352\u4f79\u0f0b\u5135\u1d8b\ub236\u7651\ua39c\u317b\ud6f5\u4ea6\u8a64\u10d6\u8e8f\u540a\u95f0\ube0c\u7ba2\u6ced\u2058\u089d\u7e59\u2711\u0459\uc795\u012e\u3893\u587c\u2346\u015a\u8273", "\udbaf\udc98\udba3\udcdb\ud80c\ude12\ud902\udc76\ud980\udfbf\udb74\udc76",
        30, 1, 94414001, 6482094173939612714L, -94342L, false, false, (char) 23844, (char) 39712,
        Double.longBitsToDouble(0x3fc609bbe9c38230L), Double.longBitsToDouble(0x3fbad153dd658510L)));
  }
  @Test(timeout = 4000)
  public void test123() throws Throwable {
    assertEquals("0=java.lang.Double:3.4011973816621555\012",
        Z.run(T, 1, 9, 6, 18, "\ud8f3\udf36\ud9e1\uddd7\ud887\udec2", "\u8abb\u21f3\ud352\u4f79\u0f0b\u5135\u7387\ucfe8\u7651\ua39c\u317b\ud6f5\u4ea6\u8a64\u10d6\u8e8f\u5172\u6ed4\ua491\ucfd2\u4fb9\ucdd3\u1823\u7e59\ucaf3\u0451\uc795\u012e\u3893\u587c\u2346\u015a\u0174", "\udbaf\udc98\ud87f\udd09\u1cd8\ud927\udf2d\ud980\udfbf\udb74\udc76",
        30, 1, -2083740495, 6482093903356673066L, -94342L, false, false, (char) 23844, (char) 39712,
        Double.longBitsToDouble(0x3fc609bbe9c38150L), Double.longBitsToDouble(0x3fbad153dd658510L)));
  }
  @Test(timeout = 4000)
  public void test124() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\012",
        Z.run(T, 1, 9, 2, 10, "\uda52\udda7", "\ub42d\u81c2\u024b", "\uda03\ude2e\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\ud8e6\udeac",
        14, 0, 332794331, 2823243901434563505L, -16452L, false, false, (char) 1753, (char) 6162,
        Double.longBitsToDouble(0x3febd71d84d328f0L), Double.longBitsToDouble(0x3fe28fa1c0afa5c0L)));
  }
  @Test(timeout = 4000)
  public void test125() throws Throwable {
    assertEquals("0=java.lang.Long:1\012",
        Z.run(T, 1, 7, 7, 10, "\uda52\udda7", "\ub42d\u41c7\u024b", "\uda03\ude2e\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\ud8e6\udeac",
        14, 0, 332794331, 2823243903141120945L, 33261L, false, false, (char) 30598, (char) 32634,
        Double.longBitsToDouble(0x3fe1ac4518df8733L), Double.longBitsToDouble(0x3febd71d84d328f0L)));
  }
  @Test(timeout = 4000)
  public void test126() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\012",
        Z.run(T, 1, 8, 9, 10, "\uda52\udda7", "\ub42d\u41c7\u024b", "\uda03\ude2e\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\ud925\uddb7\udbba\uddd3\uda21\ude58",
        52, 0, 332794331, 2823243903141120945L, 33261L, false, false, (char) 30598, (char) 32634,
        Double.longBitsToDouble(0x3fe1ac4518df8733L), Double.longBitsToDouble(0x3febd71d84d328f0L)));
  }
  @Test(timeout = 4000)
  public void test127() throws Throwable {
    assertEquals("0=java.lang.Double:29.0\0121=java.lang.Double:29.0\012",
        Z.run(T, 2, 8, 8, 12, "\ud874\udfd8", "\ub42d\u81c2\u024b", "\uda03\ude2e\ud804\udfc5\ud8cc\udeaa\uda99\udef5\ud9b6\udd48\udad2\udd87\udbed\udccb\ud849\udf9f",
        29, 28, -321517093, 8307920896525175849L, 46965L, true, false, (char) 1753, (char) 6162,
        Double.longBitsToDouble(0x3febd71d84d328f0L), Double.longBitsToDouble(0x3fe28fa1c1f25cffL)));
  }
  @Test(timeout = 4000)
  public void test128() throws Throwable {
    assertEquals("0=java.lang.Long:1\0121=java.lang.Long:1\012",
        Z.run(T, 2, 7, 7, 10, "\uda52\udda7", "\ub42d\u41c7\u024b", "\uda03\ude2e\udba3\uddf4\ud8c6\uddfe\uda99\udef5\ud9b6\udd48\ud925\uddb7\u11ba\ud8e6\udeac",
        14, 0, 332794331, 2823243903141120945L, 33261L, false, false, (char) 30598, (char) 32634,
        Double.longBitsToDouble(0x3fe1ac4518df8733L), Double.longBitsToDouble(0x3fa971d84d328f00L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.util.MathUtils|equals|double,double|static",
    "M|org.apache.commons.math.util.MathUtils|equals|double,double,double|static",
    "M|org.apache.commons.math.util.MathUtils|equals|double,double,int|static",
    "M|org.apache.commons.math.util.MathUtils|equals|[D,[D|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|long,long,org.apache.commons.math.exception.util.Localizable|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|long,long|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficient|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficientDouble|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficientLog|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|checkBinomial|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|checkOrder|[D|static",
    "M|org.apache.commons.math.util.MathUtils|checkOrder|[D,org.apache.commons.math.util.MathUtils$OrderDirection,boolean|static",
    "M|org.apache.commons.math.util.MathUtils|compareTo|double,double,double|static",
    "M|org.apache.commons.math.util.MathUtils|cosh|double|static",
    "M|org.apache.commons.math.util.MathUtils|distance|[D,[D|static",
    "M|org.apache.commons.math.util.MathUtils|equals|double,double|static",
    "M|org.apache.commons.math.util.MathUtils|equals|double,double,double|static",
    "M|org.apache.commons.math.util.MathUtils|equals|double,double,int|static",
    "M|org.apache.commons.math.util.MathUtils|equals|[D,[D|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
