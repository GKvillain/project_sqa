package org.apache.commons.math.fraction;
import org.junit.Test;
import static org.junit.Assert.*;
public class BigFraction_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:8431443017093099360 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 3, 6, 15, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud985\udf19\udb9b\udd08\ud807\ude91\udb5a\ude31", "\u0acc\u0ad6\u3906\uac71\u99ee\u48e0", "\uda51\udc57\uda36\ude10\ud975\udec8\uda8e\udd26\ud86f\uddcc\ud8f7\udfb7\ud93f\ude97\udb5b\udef3\ud96e\udf8e\ud852\udd6a\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53\ud93d\uded1\udace\udcef\udb24\udf56\uda53\udd1d",
        39, 83238, 247751395, 8431443017093099321L, 20163L, false, true, (char) 9573, (char) 9737,
        Double.longBitsToDouble(0x3fed1b7914acd9c7L), Double.longBitsToDouble(0x3fd43b558a9c34d8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:8431443017093099360 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 3, 6, 15, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud985\udf19\udb9b\udd08\ud807\ude91\udb5a\ude31", "\u0acc\u0ad6\u3906\uac71\u99ee\u48e0", "\uda51\udc57\uda36\ude10\ud975\udec8\uda8e\udd26\ud86f\uddcc\ud8f7\udfb7\ud93f\ude97\udb5b\udef3\ud96e\udf8e\ud852\udd6a\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53\ud93d\uded1\udace\udcef\udb24\udf56\uda53\udd1d",
        39, 83238, 247751395, 8431443017093099321L, 20163L, false, true, (char) 22879, (char) 9567,
        Double.longBitsToDouble(0x3fed1b7914acd9c7L), Double.longBitsToDouble(0x3fd43b558a9c34d8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:8431443017093099360 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\0121=java.lang.Boolean:false |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\012",
        Z.run(T, 2, 3, 15, 15, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud985\udf19\udb9b\udd08\ud807\ude91\udb5a\ude31", "\u0acc\u0ad6\u3906\uac71\u99ee\u48e0", "\uda51\udc57\uda36\ude10\ud975\udec8\uda8e\udd26\ud86f\uddcc\ud8f7\udfb7\ud93f\ude97\udb5b\udef3\ud96e\udf8e\ud852\udd6a\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53\ud93d\uded1\udace\udcef\udb24\udf56\uda53\udd1d",
        39, 83238, 247751395, 8431443017093099321L, 20163L, false, true, (char) 9573, (char) 9737,
        Double.longBitsToDouble(0x3fed1b7914acd9c7L), Double.longBitsToDouble(0x3fd43b558a9c34aeL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:8431443017093099321 / 46 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 11, 6, 15, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud818\uded7\udb9b\udd08\ud807\ude91\udb5a\ude31", "\u0acc\u0ad6\u3906\uac71\u99ee\u48e0", "\uda51\udc57\uda36\ude10\ud975\udec8\uda8e\udd26\ud86f\uddcc\ud8f7\udfb7\ud93f\ude97\udb5b\udef3\udbb5\ude72\ud852\udc8c\ud81a\udc70\udbcd\udddc\ud8d8\udebf\uda50\udfdd\ud843\udd33\udb4a\udd19\ud952\udc1f",
        46, 83238, 247751395, 8431443017093099321L, 20163L, false, true, (char) 9573, (char) 9737,
        Double.longBitsToDouble(0x3fed1b7914acd9c7L), Double.longBitsToDouble(0x3fd43b558e7034d8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Float:8.4314433E18 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 1, 6, 15, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud985\udf19\udb9b\udd08\ud807\ude91\udb5a\ude31", "\u141b\u0ad6\u3906\uac71\u99ee\u48e0", "\uda51\udc57\uda36\ude10\ud975\udec8\ud810\uddc9\ud86f\uddcc\ud8f7\udfb7\ud93f\ude97\udb5b\udef3\ud96e\udf8e\ud852\udd6a\ud9f9\udfb0\ud943\udecb\ud87e\ude4b\ud93d\uded1\ud9f7\ude92\ud91b\udeb2\ub426",
        7, 83238, 247751395, 8431443017093099321L, 20163L, false, true, (char) 9573, (char) 9737,
        Double.longBitsToDouble(0x3fecc6936cacd9c7L), Double.longBitsToDouble(0x3fd43b558a9c34d8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:-7191390464544323193 |this=org.apache.commons.math.fraction.BigFraction:-7191390464544323248\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 3, 6, 15, "\udb1d\udf99\udb7f\udcbb\ud8e1\udc76", "\u35aa\u2c0c", "\ud8df\udcd4\uda57\udf35\udb36\uddd4\ud958\udc6f\udad9\udeb0\ud8dd\udd61\ud931\udfb8\ud9de\udfd1\uda51\udc57\udba0\udea5\ud975\udec8",
        55, 2055, 1252500305, -7191390464544323248L, -79028L, false, false, (char) 9884, (char) 43199,
        Double.longBitsToDouble(0x3fedc9e334b37865L), Double.longBitsToDouble(0x3fee860133827fb7L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 15, 15, "\ud9bf\uddef\udb7f\udcbb\ud8e5\uddba\ud985\udf19\udb9b\udd08\ud807\ude91\ud81d\udfbe", "\u0acc\u0ad6\u3906\uccd5\u3014\u48e0", "\uda51\udc57\uda36\ude10\ud975\udec8\uda8e\udd26\ud86f\uddcc\ud8f7\udfb7\ud93f\ude97\udb5b\udef3\ud96e\udf8e",
        3, 54850, -1242938239, -1523319950345427015L, 89280L, false, true, (char) 56769, (char) 36740,
        Double.longBitsToDouble(0x3fe9cba8172d99c8L), Double.longBitsToDouble(0x3fc59cf82d99e450L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 7, 15, "\udb1d\udf99\udb7f\udcbb\udbcd\udfb2\ud985\udf19\udb9b\udd08\ud807\ude91\udb5a\ude31", "\u0acc\u0ad6\u3906\uac71\u99ee\u48e0", "\uda51\udc57\uda36\ude10\ud975\udec8\uda8e\udd26\ud86f\uddcc\uda29\udd71\uda84\udc18\udb5b\udef1\ud96e\udf8e\ud852\udd6a\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53\ud93d\uded1\udace\udcef\ud8f3\udd5f\uda3a\ude71",
        39, 83238, 247751395, 8431443017093099321L, 20163L, false, true, (char) 9573, (char) 61960,
        Double.longBitsToDouble(0x3feed7f294ac16e0L), Double.longBitsToDouble(0x3fd43b558a9c34d8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:3131727288373364829 / 10 |this=org.apache.commons.math.fraction.BigFraction:6263454576746729658\0121=org.apache.commons.math.fraction.BigFraction:6263454576746729678 |this=org.apache.commons.math.fraction.BigFraction:6263454576746729658\012",
        Z.run(T, 2, 11, 3, 4, "\ud9bf\udd2b\uda30\udf0b\uda2c\ude94\ud985\udf32\udb9b\udd08\udadc\udfeb\udbe1\udc01", "\uc043\u0ace\u3906\u6aa7\u8b7c\u27d8", "\uda51\udc57\udb8b\udd5a\udab6\udced\udb20\udc8f\udb7d\udfb7\ud8b3\udd8a\ud95c\udf2f\udb5b\udef3\ud9e0\udce7\ud852\udd6a\ud9a5\uddf6\uda81\udcf0\udab0\udcfd\udb3b\udc04\ubb9d\uda23\udd7d\u1c8d",
        20, 2698, -608279834, 6263454576746729658L, 20163L, false, false, (char) 13686, (char) 37254,
        Double.longBitsToDouble(0x3fd4be61101f9ec8L), Double.longBitsToDouble(0x3fe11ef244437f30L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.math.BigDecimal:-7815870151090110227 |this=org.apache.commons.math.fraction.BigFraction:-7815870151090110227\0121=org.apache.commons.math.fraction.BigFraction:-15631740302180220454 |this=org.apache.commons.math.fraction.BigFraction:-7815870151090110227\012",
        Z.run(T, 2, 7, 5, 16, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud985\udf19\udb9b\udd08\ud807\ude91\udb5a\ude31\ud82b\udc24", "\u0ad6\u3906\uac71", "\ud931\udfb8\ud9df\udc71\uda51\udc57\uda36\ude10\ud9e3\ude00\uda83\udd30\ud86b\udf3e\ud99c\udcf5\uda10\udccb\udbe6\ude1a\ud955\uddb6\udb5b\ude73\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53",
        5, 76227, 2142720976, -7815870151090110227L, -74733L, true, false, (char) 42043, (char) 41205,
        Double.longBitsToDouble(0x3fe4ef3e0b66797eL), Double.longBitsToDouble(0x3fe0e81a4743a6c5L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.fraction.BigFraction:8431336630753177401\0121=org.apache.commons.math.fraction.BigFraction:1 |this=org.apache.commons.math.fraction.BigFraction:8431336630753177401\012",
        Z.run(T, 2, 15, 13, 15, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud985\udf19\ud8c3\udd6e\ud807\ude5f\udb5a\ude31", "\u2a87\u1bf8\uce94\uac71\u99ee\u48e0", "\ud9fe\udfd4\uda36\ude10\ud975\udec8\uda8e\udd26\ud899\ude81\ud8ea\uddb6\ud93f\ude97\udb5b\udebe\ud96e\udf8e\ud852\udd6a\ud8f1\udcdd\ud915\ude67\udb00\udffb\ub26c\udabf\udf59\ud8b1\udfc9\uda53\udd1d",
        39, 83238, -2065734941, 8431336630753177401L, -86227L, false, true, (char) 28233, (char) 16452,
        Double.longBitsToDouble(0x3fee5b7914acd92dL), Double.longBitsToDouble(0x3fd43b5586ceceb4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:8431443017093099321 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 2, 6, 15, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud985\udf19\udb9b\udd08\ud807\ude91\udb5a\ude31", "\u0acc\u9cba\u3906\uac71\u99ee\u48e0", "\ud8cb\udd8e\ud8e8\udecc\udb7a\udf1e\uda8e\udd26\ud99c\udf43\uda6c\udf83\ud93f\ude97\udb5b\udef3\ud96e\udf8e\ud852\udd6a\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53\ud93d\uded1\ud9ce\ude4e\udb24\udf4e\u3f9b",
        39, 83238, 247751243, 8431443017093099321L, -52452L, true, true, (char) 23237, (char) 30323,
        Double.longBitsToDouble(0x3fea518595f4174fL), Double.longBitsToDouble(0x3fe5c97312b88857L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:8308577343106507690 |this=org.apache.commons.math.fraction.BigFraction:-8308577343106507690\0121=java.lang.Boolean:false |this=org.apache.commons.math.fraction.BigFraction:-8308577343106507690\012",
        Z.run(T, 2, 2, 15, 5, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95", "\u7fbc\u56bd\u15be\u630c\u0acc\u0ad6", "\udad9\udf05\ud8dd\udd61\ud931\udfb8\ud9de\udfd1\uda51\udc57\uda36\ude10\ud975\udec8\uda8e\udd26\ud86f\uddcc\ud998\udee8\ud93f\udf06\udb5b\udef3\ud96e\udf8e\ud852\udd6a\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53\ud93d\uded1",
        57, 4976, -1819774078, -8308577343106507690L, -1845L, true, true, (char) 41205, (char) 4703,
        Double.longBitsToDouble(0x3feb33cbf21d0348L), Double.longBitsToDouble(0x3fea1d362ba36f22L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Float:6.0235645E18 |this=org.apache.commons.math.fraction.BigFraction:6023564502860538705\0121=java.math.BigDecimal:6023564502860538705 |this=org.apache.commons.math.fraction.BigFraction:6023564502860538705\012",
        Z.run(T, 2, 1, 7, 15, "\udb1d\udf99\udbb3\udc15\u91b8\000\udb9b\udc26\ud848\udeb1\udb5a\uddbf", "\u0acc\u0ad6\u3906\uac71\u99ee\u48e0", "\ud9cf\uddc6",
        22, 50659, 31919, 6023564502860538705L, -100000L, false, false, (char) 9884, (char) 43199,
        Double.longBitsToDouble(0x3fedc9e334b37865L), Double.longBitsToDouble(0x3fee860133827fb7L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:8431443017093099360 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\0121=java.lang.Double:8.4314430170930995E18 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\012",
        Z.run(T, 2, 3, 0, 13, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud985\udf19\udb9b\udd08\ud807\ude91\udb5a\ude31", "\u0acc\u0ad6\u3906\uac71\u99ee\u48e0", "\uda51\udc57\uda36\ude10\ud975\udec8\uda8e\udd26\ud88b\uddc3\ud8f7\udfb7\ud93f\ude97\udb5b\udef3\ud96e\udf8e\ud852\udd6a\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53\ud93d\uded1\udace\udcef\udb24\udf56\uda53\udd1d",
        39, 83238, 247751395, 8431443017093099321L, 20163L, false, true, (char) 9573, (char) 9737,
        Double.longBitsToDouble(0x3fed1b7914acd9c7L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 4, 6, 16, "\udb92\udf13\udadd\udfe7\ud802\udf1d\udbdd\udfd2\u09af\ud807\ude91\uda4a\udca9", "\u0acc\u0ad6\u3906\uac71\u99ee\ub978", "\uda51\udc57\uda36\ude10\ud98c\ude33\uda8e\udcc1\udb43\udf74\uda1a\ude47\ud93f\ude97\udb5b\udef3\ud96e\udf8e\ud852\udd6a\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53\ud93d\uded1\udace\udcef\udb24\udf56",
        42, 83008, 2061393238, -7604401760685096798L, -36935L, false, false, (char) 34020, (char) 9573,
        Double.longBitsToDouble(0x3fea1d362b1a9922L), Double.longBitsToDouble(0x3fc59b38f50ed560L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:8431443017093099360 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\0121=org.apache.commons.math.fraction.BigFraction:8431443017093099321 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\012",
        Z.run(T, 2, 3, 2, 15, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud985\udf19\udb9b\udd08\ud807\ude91\udb5a\ude31", "\u0acc\ud1fd\u3906\uac71\u3d60\u3556", "\uda51\udc57\uda36\ude10\ud975\udec8\uda8e\udd26\ud86f\uddcc\ud8f7\udfb7\ud93f\ude97\udb5b\udef3\ud96e\udf8e\ud852\udd6a\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53\ud93d\uded1\udace\udcef\ud8f3\udd5f\uda53\udd1e",
        39, 83238, 247751395, 8431443017093099321L, 20163L, false, true, (char) 9573, (char) 9737,
        Double.longBitsToDouble(0x3fed1b7914acd9c7L), Double.longBitsToDouble(0x3fd43b558a9c34d8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:-8718264363938191187 / 20163 |this=org.apache.commons.math.fraction.BigFraction:-8718264363938191187\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 13, 4, 15, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud985\udf19\udb9b\udd08\ud807\ude91\udb5a\ude31", "\uca64\u0f4b\u1c5d\uac71\u99ee\u48e0", "\uda51\udc57\uda31\udf10\ud975\udead\uda8e\udd26\ud86f\uddcc\ud8f7\udfb7\ud93f\ude97\udb5b\udef3\ud96e\udf8e\ud852\udd6a\ud9a5\ude90\ud93f\udf24\udb00\ude45\ud9c6\udcd7\ud896\udf66\udb53\udccf\uda6a\udcdb",
        54, 83238, 247751395, -8718264363938191187L, 20163L, true, false, (char) 46728, (char) 9544,
        Double.longBitsToDouble(0x3fea7819fcacd9c7L), Double.longBitsToDouble(0x3fd43da09a9c34d8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 14, 4, 15, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud86f\udf3b\ud89b\ude7a\u1e92\udb5a\ude31", "\u0acc\ud6cc", "\udad9\udf05\ud8dd\udd61\udaef\udfb7\ud9de\udfd1\uda81\udfb1\ud86c\udc47\ud975\udec8\uda8e\udd26\ud86f\uddcc\ud8f7\udfb7\ud82f\udd0f\udb69\uddc1\ud96e\udf8e\ud852\udd6a\ud9a5\uddf6\uda29\ude18\uda22\udf6e\udbd9\udf7a\u87e9\udb24\udf56\ud9ea\udc73\ud9a8\udd60\uda95\udc93",
        55, 93685, -1716793794, -1747107288549807459L, -84761L, false, true, (char) 56120, (char) 8788,
        Double.longBitsToDouble(0x3fa239abd9600560L), Double.longBitsToDouble(0x3fe3d85b8f69ed94L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:6515672892958440855 |this=org.apache.commons.math.fraction.BigFraction:6515672892958440855\0121=org.apache.commons.math.fraction.BigFraction:6515672892958440855 |this=org.apache.commons.math.fraction.BigFraction:6515672892958440855\012",
        Z.run(T, 2, 3, 3, 14, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\uda6a\udf4b\udba4\udee8\ud807\ude91\udb5a\ude31\ud82b\udc24\udbe7\uddc1\ud8df\udcd4\ud83d\udca9\udbf3\uddde\ud9e2\ude8f\udad9\udf05\ud8dd\udd61\ud931\udfb8\ud9de\udfd1\udb40\udfcf\uda96\udd7d\ud8d4\udff1\ud935\ude82\ud84c\udeec\ud886\udc13\ud993\udcca\ua7a6\ud97e\udc9f\ud852\udd6a\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53\ud93d\uded1\udace\udcef\ud867\udc3f\uda53\udd1d\ud9a8\ude21\uda95\udc93\ud81d\udf84", "\u6270\u6a9b\u54eb", "\ud97a\udd62\udada\udc45\uda67\uded1\ud96d\udecb\udbc5\udc24\udb1a\udf27\udbfb\udc3b\ud9c1\udd52",
        0, 38004, 1184822528, 6515672892958440855L, 84834L, false, false, (char) 16649, (char) 13343,
        Double.longBitsToDouble(0x3fe7b77750c2d14fL), Double.longBitsToDouble(0x3fecc1e72351170aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:8754481579509057136 |this=org.apache.commons.math.fraction.BigFraction:8754481579509057126\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 9, 15, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud985\udf19\udb9b\udd08\ud807\ude91\udb5a\ude31", "\u47c5\u0ae3\u3906\uaa66\u397c\u8689", "\uda51\udc57\uda36\ude10\ud975\udec8\uda8e\udd26\uda5b\udd0d\ud8f7\udfb7\ud93f\ude97\udb5c\udef3\uda2a\udfac\udafa\udecf\ud9a5\uddf6\ud93f\udf24\ud84c\udd0a\udba0\udcaf\udace\udcef\udb24\udf56\uda53\udd1d\udb16\uddff\u6315\u7cde",
        10, 77963, -406780115, 8754481579509057126L, -1507L, true, true, (char) 30323, (char) 55963,
        Double.longBitsToDouble(0x3fd4e1a6c9da30aeL), Double.longBitsToDouble(0x3fd5a3863cfeb7b0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:51 |this=org.apache.commons.math.fraction.BigFraction:0\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 3, 6, 15, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud985\udf19\udb9b\udd08\ud807\ude91\udb5a\ude31", "\u0acc\u0ad6\u6391\uabdd\ua4e5\000", "",
        51, 56632, 433038659, 0L, -99879L, false, true, (char) 37705, (char) 1160,
        Double.longBitsToDouble(0x3e38000000000000L), Double.longBitsToDouble(0x3fe625afd8b93c66L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Double:-2.8226669254947364E16 |this=org.apache.commons.math.fraction.BigFraction:-28226669254947365\0121=java.lang.Double:-2.8226669254947364E16 |this=org.apache.commons.math.fraction.BigFraction:-28226669254947365\012",
        Z.run(T, 2, 0, 16, 15, "\udb1d\udf31\udb7f\udd0f\udb3b\ude22\udbc7\udcac\ud935\uded4\ud807\ude91\uda7b\udc41", "\u0acc\u8cd5\u3906\uac71\u99ee\u63ec", "\uda51\udc57\uda36\ude10\ud8b4\udf0e\uda8e\udd08\ud86f\uddcc\u2d63\ud93f\udeba\udb5b\udef3\ud96e\udf8e\ud85e\udfc7\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53\ud93d\uded1\udace\udcef\udb24\udf56\uda53\udd1d\ud83c\ude41\uda95\udcfa\udb16\udfc1\ud8ed\udfa6\udb7e\udd32\uda67\ude3f\uda9b\udf93\udb92\udead\ud92b\udc77\ud8f0\ude89\ud97a\udd62\udada\udc45\ud8ba\udfea\uda62\udd2d\uda58\udd70\udb8e\ude58\uda9d\ude4b\uda67\ude18\uda77\udee3\udbc2\udc1a\udb40\udffd\ud8a5\udc08\ud92f\udf4b\ud92e\ude90\ud91a\udf2c\ud9ac\udd8d\u2e5c\ud93c\udcba\udb62\udcb3\ud885\ude05\udb6b\udfc8\ud97b\udd3c",
        5, 11682, 2108068278, -28226669254947365L, -60438L, true, true, (char) 32831, (char) 28887,
        Double.longBitsToDouble(0x3fd268697c0d97c0L), Double.longBitsToDouble(0x3fecbf65beb612ceL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:-7132997998191772538 |this=org.apache.commons.math.fraction.BigFraction:-7132997998191772578\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 3, 14, 1, "\udb1d\udf99\udb7f\udcbb\udb7a\udd21\udada\ude13\udb86\udf01\ud88e\udd82\udb5a\ude31", "\u1a25\u4dfb\u1906\ucc98\u083b\u47be", "\uda51\udc1c\ud809\udf4a\ud95b\udd48\udaf1\ude03\udb72\udfae\ud9f7\ude88\ud9ae\udf4f\udb5b\udef0\ud975\udc12\ud84a\udc2c\udbe8\udf10\ud9b8\udcbf\ud855\udd13\ud96f\udcbb\udad8\udc2a\udb24\udf56\u9891",
        40, 28166, -1601894872, -7132997998191772578L, 20233L, true, false, (char) 62821, (char) 9737,
        Double.longBitsToDouble(0x3fed1b7914acd9c7L), Double.longBitsToDouble(0x3fd43b558a9c34d8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Double:8.942340177273986E18 |this=org.apache.commons.math.fraction.BigFraction:8942340177273986393\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 16, 6, 15, "\ud923\udec2\udb7f\udcdf\udb8f\udced\uda29\ude1b\udbab\udd3a\ud9fd\udd6c\ud9fa\udd81", "\u0ad0\u0ad6\u3906\uac71\u99ee\u48e0\u1895\u3e14\uacb5\u47dc\u5bda\ub80f\ua36c\u33cc\u22ee\u1f7b\u9c61", "\ud93f\udf24\ud8dd\ude53\ud93d\uded1\ud9e7\uddfb\uda7e\udc01\uda53\udd1d\ud8e0\udf22\ud9e0\udf39\udb26\udd75\ud8e9\udcd6\udb7e\udd32\udb67\udcfe\uda41\uddf6\uda09\udcea\udb43\udcda\ud907\uddc2\udbb1\udfdd\udada\udc45",
        47, 64510, 628932633, 8942340177273986393L, 97775L, true, false, (char) 27679, (char) 13239,
        Double.longBitsToDouble(0x3fe472a29f80662cL), Double.longBitsToDouble(0x3fec5cfd25af55dbL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:8754481579508106627 |this=org.apache.commons.math.fraction.BigFraction:8754481579508108134\0121=org.apache.commons.math.fraction.BigFraction:17508963159016216268 |this=org.apache.commons.math.fraction.BigFraction:8754481579508108134\012",
        Z.run(T, 2, 5, 5, 6, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud985\udf19\udb9b\udd08\ud807\ude91\udb9a\udcc5", "\ub005\u0ad6\u3906\u0465\u99ee\ucf96\u5dbf\u046a\u732c\u318a\u5bda\u55a3\ua3f2\u33cc\u2e30\uc2bd\u70a9\u27b8\u89d7", "\ud93d\uded1\udace\udcef\udb24\udf56\uda48\udcf6\udae5\ude9a\uda80\udf3b\udb16\udfd1",
        20, 13305, -406780115, 8754481579508108134L, -1507L, true, true, (char) 7564, (char) 55963,
        Double.longBitsToDouble(0x3fd4e1a6c77d69e0L), Double.longBitsToDouble(0x3fe8a391e71b6282L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Float:8.4314433E18 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\0121=org.apache.commons.math.fraction.BigFraction:8431443017093099321 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\012",
        Z.run(T, 2, 1, 2, 15, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud985\udf19\udb9b\udd08\ud807\ude91\udb5a\ude31", "\u9313\u7fa9\u3906\uac71\u99ee\u48e0", "\uda51\udc57\uda36\ude10\ud975\udec8\uda8e\udd26\ud86f\uddcc\ud8f7\udfb7\ud93f\ude97\udb5b\udef3\ud96e\udf8e\ud852\udd6a\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53\ud93d\uded1\udace\udcef\udb24\udf56\uda53\udd1d",
        39, 83238, 639656675, 8431443017093099321L, 20163L, false, true, (char) 9573, (char) 9737,
        Double.longBitsToDouble(0x3fed1b7914acd9c7L), Double.longBitsToDouble(0x3fd43b558a9c34d8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Double:8.4307385007226348E18 |this=org.apache.commons.math.fraction.BigFraction:8430738500722634553\0121=java.lang.Boolean:false |this=org.apache.commons.math.fraction.BigFraction:8430738500722634553\012",
        Z.run(T, 2, 0, 15, 15, "\udb1d\udf99\udb6a\udcb4\udb5f\udf95\ud985\udf19\udb9b\udd08\u00b1\udb40\udebf", "\u0acc\u0ad6\u3906\uac71\u99ee\u48e0", "\uda51\udc57\uda36\ude10\ud975\udec8\000\000\000\ud93f\ude1eP\ud94a\udc44\ud852\udd6a\ud9a5\uddf6\ueb81\000\u2700\udace\udc3c\udb24\udf56\uda53\udd1d",
        37, -1000, 0, 8430738500722634553L, 20163L, false, true, (char) 9573, (char) 9737,
        Double.longBitsToDouble(0x3fed1b7914acd9c7L), Double.longBitsToDouble(0x3fb0ed5600000000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:-8431443017093099321 / 95805 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\0121=java.math.BigDecimal:8431443017093099321 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\012",
        Z.run(T, 2, 13, 7, 15, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud985\udf19\udb9b\udd08\ud807\ude91\udb5a\ude31", "\u0acc\u7ce9\ua8ab\u0262\ubb22\u4846", "\uda51\udc57\uda36\ude10\ud975\udec8\uda8e\udd26\ud86f\uddcc\ud8f7\udfb7\ud93f\ude97\udb5b\udef3\ud831\ude4f\ud84a\ude73\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53\ud93d\uded1\udace\udcef\udb24\udf56\uda53\udd1d",
        39, 45366, -116408330, 8431443017093099321L, -95805L, false, true, (char) 9573, (char) 9737,
        Double.longBitsToDouble(0x3fed1b7914acd9c7L), Double.longBitsToDouble(0x3fd43b558a9c34d8L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 6, 6, 15, "\ud8d1\udd5c\udb7f\udd08\udb5f\udf95", "\u7fbc\u56bd\u15be\u7b0c\u0acc\u3b52\u8e1b\uac71\u99ee\u6560\ucf2c\uc526\u51ad\uadd7\u9499", "\ud8f7\udfb7",
        4, 52768, 76059466, -620280773490251262L, -31000L, true, false, (char) 7405, (char) 5111,
        Double.longBitsToDouble(0x3fee13fdb8ed9388L), Double.longBitsToDouble(0x3fb5a32c971a6e80L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:-3637700250940287811 / 27 |this=org.apache.commons.math.fraction.BigFraction:-3637700250940287811\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 12, 6, "\udb18\uddb6", "\uaf1b\ua17c\u7fbc\ud167\u5f12\u630c\u0acc\u0ad6\u7bc9\ucac3\u6444\u48e0\ua62a\u11bc\u6dd6\u30a3\u6595\u55a3\ua3f2\u8cfb\u2e30\uc2bd\ua85d\u077d\u353e\u05eb\uaa5a\u5e6a\u36f4\u9b2e\u9af3\u7539\uc6f5\u7463\u7135\u903b\u6270\u1cae\u67de\u74cd\u9b16\ub656\u0c31\u586e\u40f3\u9672\ua8a8\u1598\u636f\u727b\u47ab\u5508\ub1c2\u75c5\u237a\u4739\uce39", "\udb18\udfcf\udb92\udd87\udb7e\udd5f\ud8b2\uddd1\ud863\uded1\udb6c\udf6c\uda50\udd8b",
        27, 36198, 371366347, -3637700250940287811L, 3053L, true, false, (char) 27356, (char) 1798,
        Double.longBitsToDouble(0x3fdbaa69949e7a2aL), Double.longBitsToDouble(0x3fba6122b9b3e758L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.fraction.BigFraction:-7191390464544323248\0121=java.lang.Boolean:false |this=org.apache.commons.math.fraction.BigFraction:-7191390464544323248\012",
        Z.run(T, 2, 15, 15, 15, "\udb27\ude99\udb7f\udcbb\u13dc\ud8f0\udcc9\udb9b\udd08\ud807\ude91\udadc\udc12", "\u2dc2\u0a65\ub956\uc74e", "\udb13\udc46\udb8a\ude32\ud8ba\udc1e\uda36\udd2a\ud9b2\udc21",
        40, 1950, 1252500305, -7191390464544323248L, 21377L, true, false, (char) 25169, (char) 43180,
        Double.longBitsToDouble(0x3f8383812cde2100L), Double.longBitsToDouble(0x3fee860133b44be8L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:4356092190253135559 / 23 |this=org.apache.commons.math.fraction.BigFraction:4356092190253135559\0121=org.apache.commons.math.fraction.BigFraction:1 |this=org.apache.commons.math.fraction.BigFraction:4356092190253135559\012",
        Z.run(T, 2, 11, 13, 7, "\udb1d\udf99\udb4e\uddb0", "\u5239\u8433\u3c7f\uabc6\u630c\u32a7\u9471\ub473\uac71\u99ee\u48e0\u57c0\uc7d4\u732c\ub66d\u6091\uad57\ua3f2\u7cdf", "\ud96e\udf8e",
        23, -15, -1241804415, 4356092190253135559L, -55920L, false, true, (char) 38556, (char) 59912,
        Double.longBitsToDouble(0x3fe71bd6f5c198c4L), Double.longBitsToDouble(0x3fe9cd64a72d99c8L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:8431443019795869497 / 20163 |this=org.apache.commons.math.fraction.BigFraction:8431443019795869497\0121=org.apache.commons.math.fraction.BigFraction:1 |this=org.apache.commons.math.fraction.BigFraction:8431443019795869497\012",
        Z.run(T, 2, 13, 13, 15, "\ud8b4\udd1d\udb85\udea5\ud801\udfe5\ud890\udf21\ud811\udc23\ud807\ude91\udb5a\ude31\ud82b\udc24\udbe7\uddc1\ud8df\udcd4\ud83d\udca9\udbf3\uddde\ud9e5\udd24", "\ubeb6", "\uda36\uddf8\ud975\udec8\uda8e\udd26\u369d\ud995\udc5d\ud825\ude51\udb41\udd3d\ud9f7\udd33\udb00\udd85\uda4a\udd89\ud920\udd8a\ud8bb\udf44\ud96e\udfdf\uda35\udea7\udb24\udf56\udae9\uddfc",
        7, 83238, 247751395, 8431443019795869497L, 20163L, false, true, (char) 56019, (char) 9737,
        Double.longBitsToDouble(0x3fecb37914acd9c7L), Double.longBitsToDouble(0x3fd43b558a9c34aeL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:8431512092666244921 / 46 |this=org.apache.commons.math.fraction.BigFraction:8431512092666244921\0121=org.apache.commons.math.fraction.BigFraction:8431512092666244921 / 46 |this=org.apache.commons.math.fraction.BigFraction:8431512092666244921\012",
        Z.run(T, 2, 11, 11, 8, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud818\uded7\udaf4\uded5\ud807\ude91\udb5a\ude31", "\u0acc\u0ad6\u3906\uac71\u99ee\u48e0", "\u88a2\uda36\ude10\ud975\udec8\uda8e\udd26\ud86f\uddcc\uda3c\udc99\ud991\udcbd\udb0f\udf4a\udbb5\ude72\ud852\udc8c\ud81a\udc70\udbcd\udddc\ud8d8\udebf\uda50\udfdd\ud843\udd33\udb4a\udd19\ud952\udc1f",
        46, 83238, 2022585020, 8431512092666244921L, -29791L, true, true, (char) 9573, (char) 9737,
        Double.longBitsToDouble(0x3fed1b7914acd9c7L), Double.longBitsToDouble(0x3fd43b558e7034d8L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:4215721508514215580 / 7 |this=org.apache.commons.math.fraction.BigFraction:8431443017028431160\0121=org.apache.commons.math.fraction.BigFraction:1 |this=org.apache.commons.math.fraction.BigFraction:8431443017028431160\012",
        Z.run(T, 2, 11, 13, 9, "\udb1d\udf99\ud881\ude5d\ud806\ude43\ud818\ude97\udb9b\udd08\ud807\ude91\udb5a\ude31", "\u0a7f\u0ad6\u3906\uac71\u99ee\u48e0", "\uda51\udc57\uda36\ude10\ud975\udec8\uda8e\udd26\ud835\uddcf\ud8f7\udfb7\ud9fa\udd3b\udb6a\udc73\u91b5\ud852\udc8c\ud804\udc70\udbcd\udddc\ud8d8\udebf\uda50\udff2\ud843\udd33\ud827\udc11\ud952\udc1f",
        14, 35606, 247751395, 8431443017028431160L, 92534L, false, true, (char) 33215, (char) 9652,
        Double.longBitsToDouble(0x3fed1df912acd9c7L), Double.longBitsToDouble(0x3fdbc92261b034d8L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.ZeroException\012",
        Z.run(T, 2, 11, 6, 14, "\udb1d\udf99", "\u7938\u67f0\u7b96\u077d\u58d2\u630c\u7106\u9e14\u6a91\uac71\u62ee\u2ecb\u627c\u046a\u732c\ua859\u5bda\u55a3\ua3f2\u33cc\u2e30\uc2bd\u71f2\u26da\u1353\u744f\u51e9\u92b8\u56e2\u8684\u0228\u0fc9\u29f6\u7463\u3b6f\u2f36\u9150\u3332\ub354\u89c5\u58ce\u4fd4\u0c1a\uc493\uc55e\ucfcc\ud55b\u96eb\u9504\u243d\u4b94\u25a6\u3035\u2b05\ua6fc\000\ub98e", "\ud9c4\udedf\udbb0\udfa4\udbcc\udd1d\ud968\udee3\ud9fa\udd35\ud940\uddb0",
        0, 6288, -474534639, 1410644044536142094L, -51836L, true, true, (char) 15216, (char) 15857,
        Double.longBitsToDouble(0x3fc76444ea33d6c4L), Double.longBitsToDouble(0x3fdde425bc4019c0L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Float:5.2892287E18 |this=org.apache.commons.math.fraction.BigFraction:5289228969692755762\0121=java.lang.Float:5.2892287E18 |this=org.apache.commons.math.fraction.BigFraction:5289228969692755762\012",
        Z.run(T, 2, 1, 1, 4, "\u1c04\ud855\udfe1\ud985\udd30\udb6c\udf03\udb9b\udd1c\ud807\ude91", "\u71e9\u18b9\u63ea\u3906\uac71\u99ee\u48e0\u627c\u046a\u732c\u318a", "\udb39\uddd1\ud8f5\udeb7\udad2\udf31\udb5b\udef3\ud96e\udf8e\ud852\udd6a",
        -5, 62014, 1017730744, 5289228969692755762L, 7178L, true, false, (char) 36740, (char) 42043,
        Double.longBitsToDouble(0x3fe96cce429de7c1L), Double.longBitsToDouble(0x3feb33cbf21d0348L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:5571349385951214583 |this=org.apache.commons.math.fraction.BigFraction:-5571349385951214583\0121=org.apache.commons.math.fraction.BigFraction:5571349385951214583 |this=org.apache.commons.math.fraction.BigFraction:-5571349385951214583\012",
        Z.run(T, 2, 2, 2, 4, "\udb1d\udf99\udb7f\udcbb\ud8e1\udc76\udaaa\udee3\ud9e4\udeb8\ud97e\udf83\udb6a\udc2d\ud9fd\udce2\ud8c4\udde9\udbb4\udec5\ud8af\udd43\udb36\uddd4\ud958\udc6f\udad9\udeb0\ud8dd\udd61\ud931\udfb8\udbd9\udc4d\ud8e2\udef1\udbab\udfed\ud975\udec8\uda8e\udc79\ud9c5\udf57\ud95c\udd2c\ud93f\ude97\udb5b\udef3\ud96e\udf8e\ud852\udd6a\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53\udaf2\udfb7\udace\udcef", "\u1923\uc373\u63c6\ucdd1\u9b35\ub299\u0d69\u3172\uc6ab\u5928\u9b30\u738c\u25ba\u6d34\u698a\u4adf\uaf19\u93a9\u3ae1\u5666\u366d\u6ed7\uad44\u3fe4\u3005\u6d67", "\ud88a\udd85\uda6d\udcf5\u7896\uda78\udf67\udae6\udd47\udadf\udd02\uda3b\udd3a\ud91c\uddd8",
        35, 35859, -635199743, -5571349385951214583L, -42789L, false, false, (char) 25686, (char) 60498,
        Double.longBitsToDouble(0x3fefb5c01a972fc7L), Double.longBitsToDouble(0x3fd9d8007fc5f6c0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Double:-1.49737096090276096E18 |this=org.apache.commons.math.fraction.BigFraction:-1497370960902760848\0121=!org.apache.commons.math.exception.ZeroException\012",
        Z.run(T, 2, 0, 11, 2, "\udb1d\udf99\udb7f\udcbb\udb7e\udc64", "\u35aa\u2c0c\u8bcf\u6712\u9b80", "\ud958\udc93",
        0, 31061, 994561082, -1497370960902760848L, -43903L, false, true, (char) 37152, (char) 58914,
        Double.longBitsToDouble(0x3fea52fda1ecda88L), Double.longBitsToDouble(0x3fe29f5347c1665cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:5365877008055922708 / 5 |this=org.apache.commons.math.fraction.BigFraction:-5365877008055922708\0121=org.apache.commons.math.fraction.BigFraction:1 |this=org.apache.commons.math.fraction.BigFraction:-5365877008055922708\012",
        Z.run(T, 2, 11, 13, 2, "\udaf9\udda2\uda30\udf0b\uda2c\ude94\ud985\udf32\udb9b\udd08\udab7\udffa\udbe1\udc01", "\uc043\u0ace\u3906\u6aa7\u02d4\u26a8", "\uda51\udc57\udb8b\udd5a\udab6\udced\udb20\udc8f\udb7d\udfb7",
        -5, 8716, 1602759700, -5365877008055922708L, 39988L, false, true, (char) 52064, (char) 46215,
        Double.longBitsToDouble(0x3fdf46fbbfd2ffccL), Double.longBitsToDouble(0x3fed8275f68dc4b2L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.math.BigDecimal:0 |this=org.apache.commons.math.fraction.BigFraction:0\0121=org.apache.commons.math.fraction.BigFraction:0 |this=org.apache.commons.math.fraction.BigFraction:0\012",
        Z.run(T, 2, 7, 5, 16, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud950\udec7\udb9b\udd08\ud807\ude91\udb5a\ude31\ud82b\udc24", "\u0a50\u3906\uac71", "\ucc3a\ud9de\udfc6\ud843\ude91\000\ud9e3\uddbd\uda83\udd30\ud86b\udf3e\000\000\udbe6\uddca\u6d7a\u2c00\ud9a5\uddf4\ud93f\udf24\ud8dd\ude53",
        5, -821, 0, 0L, -100000L, false, false, (char) 30011, (char) 2037,
        Double.longBitsToDouble(0x3fe4ef3e0b000000L), Double.longBitsToDouble(0x3fe0e81a4743a6c5L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:8431443017093099321 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\0121=org.apache.commons.math.fraction.BigFraction:8431443017093099321 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\012",
        Z.run(T, 2, 2, 2, 15, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\ud985\udf19\udb9b\udd08\ud818\udd91\udb5a\ude31", "\u0acc\u9cba\u3906\uac71\u99ee\u48e0", "\ud8cb\udd8e\ud8e8\udecc\udb87\udcf8\udaff\uddff\ud99c\udf43\uda6c\udf83\ud93f\ude97\udb5b\udef3\ud96e\udf8e\ud852\udd6a\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53\ud93d\uded1\ud9ce\ude4e\udb32\udd4e\u3f9b",
        39, 83238, 247751243, 8431443017093099321L, -52452L, true, true, (char) 23237, (char) 30323,
        Double.longBitsToDouble(0x3fea518595f4174fL), Double.longBitsToDouble(0x3fe5c97312b88857L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.BigFraction:8431443017093099360 |this=org.apache.commons.math.fraction.BigFraction:8431443017093099321\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 3, 6, 15, "\udb1d\udf99\udb7f\udcbb\udb5f\udf95\udb52\udcbf\udb9b\udd08\ud807\ude91\udb5a\ude31", "\u0acc\u0ad6\u3906\uac71\u99ee\u48e0", "\uda51\udcb4\uda36\ude10\ud975\udec8\uda8e\udd26\ud86f\uddcc\ud8f7\udfb7\ud93f\ude97\udb5b\udef3\ud96e\udf8e\ud852\udd6a\ud9a5\uddf6\ud93f\udf24\ud8dd\ude53\ud93d\uded1\udace\udcef\ud912\uddde\udbdb\udf22",
        39, 83238, 818176739, 8431443017093099321L, 20163L, false, true, (char) 9573, (char) 9737,
        Double.longBitsToDouble(0x3fed1b7914acd9c7L), Double.longBitsToDouble(0x3fd43b558a9c34d8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.fraction.BigFraction|doubleValue||new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|floatValue||new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|abs||new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|add|int|new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|add|java.math.BigInteger|new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|add|long|new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|add|org.apache.commons.math.fraction.BigFraction|new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|bigDecimalValue||new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|bigDecimalValue|int|new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|bigDecimalValue|int,int|new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|compareTo|org.apache.commons.math.fraction.BigFraction|new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|divide|int|new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|divide|java.math.BigInteger|new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|divide|long|new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|divide|org.apache.commons.math.fraction.BigFraction|new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|equals|java.lang.Object|new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|doubleValue||new:org.apache.commons.math.fraction.BigFraction:long",
    "M|org.apache.commons.math.fraction.BigFraction|floatValue||new:org.apache.commons.math.fraction.BigFraction:long",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
