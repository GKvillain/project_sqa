package org.apache.commons.math3.random;
import org.junit.Test;
import static org.junit.Assert.*;
public class BitsStreamGenerator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.random.ISAACRandom:@?\012",
        Z.run(T, 1, 10, 1, 6, "\ud956\udf8b\ud9a4\udf61\udb9b\udf35\udbdb\udf35\ud92c\udeca\udb4b\ude1a\uda72\udfe0\udb3f\udc14\ud9cf\udc5c\ud86f\udc4d\udb56\udfab\uda6a\udfb3\udb57\udcc5\u2baa\ud81f\udf5d\ud911\udf4a\ud92b\udfb7\ud942\udc7c\ud8a8\udedc\u7a29\udbcb\udef4\ud946\udecc\uda40\ude35\u2646\ud8b9\udebb\ud91e\udd1d\u524b\ud871\udf29\udb1e\udde6\uda31\uddd4\ud87c\uddf9\ud8ed\udda0\uda04\udc33\udb9e\ude7e\ud8fa\udc08\ud8e2\udefa\udb7a\udd24\ud978\udc54\ud873\udc82\ud9b8\udd30\ud8bc\udcd5\ud8cf\udf88", "\u2bb3\u6d93\u1978\u18f3\uca0e\uc3f9\u253d\u1d38\u4652\u9a7e\uc269\u4afe\u839f\uba2d\u7277\u3df1\ub04c\ua950\u9187\u675a\u3ebb\u4a7e\u5f4a\u2466\ubc1d", "\ud900\udfa6\uabc8\ud9b8\udfa9\udb23\udc84\uda80\udf8d\udaea\udc79",
        50, 71074, 313859327, -3987522599546794893L, -86429L, false, false, (char) 52321, (char) 22691,
        Double.longBitsToDouble(0x3fa4a2ee43bac7d0L), Double.longBitsToDouble(0x3fda2033e68cadd0L)));
  }
  @Test
  public void test1() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test1() throws Throwable {
//     assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.random.ISAACRandom:@?\012",
//         Z.run(T, 1, 2, 9, 3, "\ud956\udf8b\ud9a4\udf61\udb9b\udf35\udaf5\udff2\ud8f7\udea5\udb4b\ude1a\uda72\udfe0\udb3f\udc14\ud997\udee1\ud86f\udc4d\udb56\udfab\uda6a\udfb3\uda81\uded9\u2baa\ud81f\udf5d\ud911\udf4a\ud92b\udfb7\ud942\udc7c\uda30\udd00\u7a52\udbcb\udef4\ud946\udecc\uda40\ude35\u2646\ud8b9\udebb\ud91e\udd1d\u524b\ud871\udf29\udb1e\udde6\uda31\uddd4\ud87c\uddf9\ud8ed\udda0\uda04\udc33\udb9e\ude7e\ud8fa\udc08\ud8e2\udefa\udb7a\udd24\ud978\udc54\ud873\udc82\ud9b8\udd30\ud8bc\udcd5\ud8cf\udf88", "\u2bb3\u6d93\u1978\u18f3\uca0e\uc3f9\uad93\ua55b\u011d\u9902\u4a32\u4afe\u839f\uba2d\u7277\u3df1\uac4c\ua950\u9187\u675a\u3ebb\u4a7e\u5f4a\u2466\u0d73", "\ud900\udfa6\uabc8\ud9b8\udfa9\ud9c8\uddb8\udaf7\uddd6\uda15\udecb",
//         50, 71074, 313859327, -4981973692263838605L, -86429L, false, false, (char) 52321, (char) 22691,
//         Double.longBitsToDouble(0x3fa4a2ee43bac7d0L), Double.longBitsToDouble(0x3fda2033e68cadd0L)));
//   }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |a0=[I:[[55590, 57179, 55668, 57137, 56171, 57093, 56235, 57093]] |this=org.apache.commons.math3.random.ISAACRandom:@?\0121=void |this=org.apache.commons.math3.random.ISAACRandom:@?\012",
        Z.run(T, 2, 11, 0, 6, "\ud956\udf8b\ud9a4\udf61\udb9b\udf35\udbdb\udf35\ud92c\udeca\udb4b\ude1a\uda72\udfe0\udb3f\udc14\ud997\udee1\udb60\udf17\udb56\udfab\uda6a\udfb3\uda81\uded9\u2baa\ud81f\udf5d\ud911\udf4a\ud99f\udc5c\ud8bc\udd95\uda62\ude33\udbf8\udec2\udbcb\udef4\ud946\udecc\uda40\ude35\u2646\ud8b9\udebb\ud91e\udd1d\ud8c5\uddd9\uda90\udf10\udb1e\udde6\uda31\uddd4\ud87c\uddf9\uda51\udd92\uda04\udc33\udb9e\ude7e\ud8fa\udc08\ud8e2\udefa\udb7a\udd24\ud8c7\ude5c\ud8b1\uddf1\ud9b8\udd30\ud8bc\udcd5\ud8cf\udf88", "\u2bb3\u6d93\u0fd5\u18f3\uca0e\uc3f9\ud4f0\u87eb\u1b5b\u0ba4\u188c\u4afe\u839f\uba2d\u7277\u3df1\ub04c\ua950\u93a7\u675a\u3ebb\u4a7e\u5f4a\u2466\u8657", "\ud900\udfa6\uabc8\ud9b8\udfa9\ud9c8\uddb8\udaf7\uddd6\ud8fb\udc5f\ud9c3\ude28\ud969\udcfc\ud8bd\ude19\udb9b\udf3f\ud987\udddd\ud8a8\udf40\ud9ba\udc60\udbd3\udc96",
        56, 59456, -1401069527, 233839989810049442L, 16394L, true, true, (char) 65426, (char) 51738,
        Double.longBitsToDouble(0x3fe85df0fac93993L), Double.longBitsToDouble(0x3fd59960babb3112L)));
  }
  @Test
  public void test3() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test3() throws Throwable {
//     assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.random.ISAACRandom:@?\012",
//         Z.run(T, 1, 2, 1, 6, "\ud956\udf8b\ud9a4\udf61\udb9b\udf35\udbdb\udf35\ud92c\udeca\udb4b\ude1a\uda72\udfe0\udb3f\udc14\ud997\udee1\ud86f\udc4d\udb56\udfab\uda6a\udfb3\uda81\uded9\u2baa\ud9e4\udc9f\ud911\udf13\ud92b\udfb7\ud947\udf7c\ud817\ude02\ud850\udf6c\ud8f7\udc19\ud946\udecc\uda40\ude35\u2646\ud8b9\udebb\ud91e\udd1d\u524b\ud871\udf29\udb1e\udde6\uda31\uddd4\udb90\udee8\ud8b9\udf33\udb65\udcb1\udbab\udd9c\ud8fa\udc08\ud8e2\udefa\udb7a\udd24\ud978\udc54\ud873\udc82\ud9b8\udd30\ud9e2\ude68\ud8cf\udfde", "\u2bb3\u6d93\u1978\u18f3\uca0e\uc3f9\u253d\u8633\u8c66\u9a9b\u2d09\u87fb\u839f\uba2d\u7277\u3df1\ub04c\ua950\u91af\u8cfb\u81a0\u4a7e\u5f4a\u2466\u0d73", "\u78a6\uabc8\ud9b8\udfa9\ud9c8\uddb8\udaf7\uddd6\uda15\udecb",
//         50, 71074, 303635711, 854691424808284087L, -86429L, false, false, (char) 52321, (char) 22691,
//         Double.longBitsToDouble(0x3fa4a2ee43bac7d0L), Double.longBitsToDouble(0x3fda2033e68cadd0L)));
//   }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NotStrictlyPositiveException\012",
        Z.run(T, 1, 8, 8, 3, "\ud956\udf8b\ud9a4\udf61\udb9b\udf35\udbdb\udf35", "\ua0e5\u8f5b", "\udb56\udfab\uda6a\udfb3\uda81\uded9\u2baa\ud81f\udf5d\ud911\udf4a\ud92b\udfb7\ud942\udc7c\uda30\udd00\u7a52\udbcb\udef4\ud946\udecc\uda40\ude35\u2646\ud815\udec1\ud91e\udd1d\u524b\ud871\udf29\ud9df\udce6\ud90f\udfc3\ud87c\uddf9\ud8ed\udda0\uda04\udc33\udb9e\ude7e\ud8fa\udc08\ud8e2\udefa\udb7a\udd24\ud978\udc54\ud873\udc82\ud9b8\udd30",
        -1, 33924, -1212904806, -3113198746527914861L, -62853L, true, false, (char) 2120, (char) 22634,
        Double.longBitsToDouble(0x3fe1178be61144c8L), Double.longBitsToDouble(0x3fdd21eba2b13680L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |a0=[I:[[55590, 57179]] |this=org.apache.commons.math3.random.ISAACRandom:@?\012",
        Z.run(T, 1, 11, 4, 10, "\ud956\udf8b", "\ua1e9\ub06b\u6214\ua0e5\u8f5b\u698e\u6770\u5da1\u98f5\u9c34\ubc28\u7763\uc118\u8598\u263e\u4f56\u042f\u1123\u567d\u1193\u5be9\u8c86\u8144\u9d67\u7e9f\u98cc\u802d\u4110\ub019\ub578\ud100\u9bd8\u3aa5\u58d7\ud598\uc6c5\uaaad\u8d60\ud66e\ub4ea", "\udbee\udd1c\uda0f\udf26\uda41\udc6f",
        -5, 2629, 167663973, 1543694997612205434L, -58574L, true, false, (char) 27054, (char) 5268,
        Double.longBitsToDouble(0x3fd29c5fdaaf6034L), Double.longBitsToDouble(0x3feccaf809e139f7L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 0, 6, "\uda30\ude79\udadd\ude84\ud9d7\udf0d\udb21\udd48\u90ef\udac2\udf84\uda72\udf19\udb3f\udc14\ud997\udee1\uda6d\udeb5\udbbc\ude44\ud9cf\udfab\uda8d\udfd6\u1862\ud81f\udf5d\ud967\ude34\ud97a\udfd1\uda80\udd00\udbd4\udf9c\ud95c\ude58\udb0c\udcbb\ud888\udecd\uda40\ude35\u2646\ud886\ude47\ud9d5\udcae\uda9d\uddda\ud813\udc5f\udb1e\udde6\uda31\uddd4\uda01\udea3\ud8ed\udd5e\ud985\udf6b\uda63\udf44\ud8f9\udf5d\ud8e2\udefa\ud99b\ude56\ud9a7\udc3a\ud873\udc82\ud9b8\udd30\ud8bc\udcd5\ud8cf\udf88", "\u319e\uccd8\ud73e\u4797\u8b1b\uca07\u8d49\uc486\u7cab\ua056\ud608\ua45d\ub848\uba2d\uca48\u3dbd\u4622\ua950\u9f82\u66dd\uba14\uca42\ua3a9\ub85e\u35d3", "\ud900\udfa6\uabc8\ud9b8\udfa9\ud9c8\uddb8\udaf7\uddd6\uda15\udecb\ud9c3\ude28\ud808\udc2b",
        5, 10531, -1874498094, -5792605496457311491L, 86286L, false, false, (char) 42398, (char) 24229,
        Double.longBitsToDouble(0x3fda2033e3c0fc36L), Double.longBitsToDouble(0x3fdaeef3faee1948L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.random.ISAACRandom:@?\012",
        Z.run(T, 1, 11, 0, 8, "\ud956\udf8b\ud9a4\udf61\udaaf\ude5f\udbdb\udf73\ud8b5\udd69\uda32\udc60\uda72\udfe0\udb3f\udc14\udbab\udddc\ud86f\udc4d\udb56\udfab\uda78\udfba\uda81\uded9\u2baa\ud81f\udf5d\ud911\udf4a\ud92b\udfb7\ud83a\udcbe\uda30\udd1d\ud818\udd3f\udb8a\ude12\ud946\udecc\uda7f\ude96\udb4d\ude4f\ud8a6\udd93\ud850\udf3f\ud833\ude30\ud871\udee1\udb1e\udde6\uda31\uddd4\ud87c\uddf9\ud8ed\udda0\uda04\udc33\udb9e\ude7e\ud8fa\udc08\ud8e2\udefa\udb7a\udd24\udbfd\ude16\ud86f\udce3\ud9b8\udd30\ud8bc\udcd5\ud8cf\udf88", "\u2bb3\u1e2b\u5d21\ua8ad\u06c5\uc3f9\u253d\u1d38\u0ba8\u9a7c\uc269\u3527\u82f6\uba2d\u7277\ubc99\ub021\ua950\u096c\u675a\uabc3\u4a52\u5f4a\u6c04\u0d73", "\ud900\udfa6\uabc8\ud9b8\udfa9\ud9ad\udcb8\udaf7\uddd6\uda15\udecb",
        50, 71074, -2001396481, -4981973691726967693L, -86429L, false, false, (char) 52321, (char) 22691,
        Double.longBitsToDouble(0x3fa4a2ee43bac7d0L), Double.longBitsToDouble(0x3fda2033e68cadd0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |a0=[I:[[55590, 57241, 55668, 57137, 56171, 57093]] |this=org.apache.commons.math3.random.ISAACRandom:@?\012",
        Z.run(T, 1, 11, 0, 6, "\ud956\udfc9\ud9a4\udf61\udb9b\udf35", "\u6214", "\ud997\udee1",
        30, 9774, -199474073, 7177058829237223268L, -87387L, true, false, (char) 11815, (char) 39815,
        Double.longBitsToDouble(0x3fe9fe6664b4ac6aL), Double.longBitsToDouble(0x3f893cfd3369bc00L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |a0=[I:[[55590, 57179, 55668, 57137, 56171, 57093, 56235, 57093]] |this=org.apache.commons.math3.random.ISAACRandom:@?\0121=void |this=org.apache.commons.math3.random.ISAACRandom:@?\012",
        Z.run(T, 2, 11, 10, 6, "\ud956\udf8b\ud9a4\udf61\udb9b\udf35\udbdb\udf35\ud92c\udeca\udb4b\ude1a\uda72\udfe0\udb3f\udc14\ud997\udee1\udb60\udf17\udb56\udfab\uda6a\udfb3\uda81\uded9\u2baa\ud81f\udf5d\ud911\udf4a\ud99f\udc5c\ud8bc\udd95\uda62\ude33\udbf8\udec2\udbcb\udef4\ud946\udecc\uda40\ude35\u2646\ud8b9\udebb\ud91e\udd1d\ud8c5\uddd9\uda90\udf10\udb1e\udde6\uda31\uddd4\ud87c\uddf9\uda51\udd92\uda04\udc33\udb9e\ude7e\ud8fa\udc08\ud8e2\udefa\udb7a\udd24\ud8c7\ude5c\ud8b1\uddf1\ud9b8\udd30\ud8bc\udcd5\ud8cf\udf88", "\u2bb3\u6d93\u0fd5\u18f3\uca0e\uc3f9\ud4f0\u87eb\u1b5b\u0ba4\u188c\u4afe\u839f\uba2d\u7277\u3df1\ub04c\ua950\u93a7\u675a\u3ebb\u4a7e\u5f4a\u2466\u8657", "\ud900\udfa6\uabc8\ud9b8\udfa9\ud9c8\uddb8\udaf7\uddd6\ud8fb\udc5f\ud9c3\ude28\ud969\udcfc\ud8bd\ude19\udb9b\udf3f\ud987\udddd\ud8a8\udf40\ud9ba\udc60\udbd3\udc96",
        56, 59456, -1401069527, 233839989810049442L, 16394L, true, true, (char) 65426, (char) 51738,
        Double.longBitsToDouble(0x3fe85df0fac93993L), Double.longBitsToDouble(0x3fd59960babb3112L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |a0=[I:[[55590, 57179, 55668, 57137, 56171, 57093, 56235, 57093]] |this=org.apache.commons.math3.random.ISAACRandom:@?\0121=void |a0=[I:[[55590, 57179, 55668, 57137, 56171, 57093, 56235, 57093]] |this=org.apache.commons.math3.random.ISAACRandom:@?\012",
        Z.run(T, 2, 11, 11, 6, "\ud956\udf8b\ud9a4\udf61\udb9b\udf35\udbdb\udf35\ud92c\udeca\udb4b\ude1a\uda72\udfe0\udb3f\udc14\ud997\udee1\udb60\udf17\udb56\udfab\uda6a\udfb3\uda81\uded9\u2baa\ud81f\udf5d\ud911\udf4a\ud99f\udc5c\ud8bc\udd95\uda62\ude33\udbf8\udf08\udbcb\udef4\ud946\udecc\uda40\ude35\u2646\ud8b9\udebb\ud91e\udd1d\ud8c5\uddd9\uda90\udf10\udb1e\udde6\uda31\uddd4\ud87c\uddf9\uda51\udd92\uda04\udc33\udb9e\ude7e\ud8fa\udc08\ud8e2\udefa\udb7a\udd24\ud8c7\ude5c\ud8b1\uddf1\ud9b8\udd30\ud8bc\udcd5\ud8cf\udf88", "\u2bb3\u6d93\u0fd5\u18f3\uca0e\uc3f9\ud4f0\u87eb\u1b5b\u0ba4\u188c\u4afe\u839f\uba2d\u7277\u3df1\ub04c\ua950\u93a7\u675a\u3ebb\ub14f\u5f4a\u2466\u8657", "\ud900\udfa6\uabc8\ud9b8\udfa9\ud9c8\uddb8\udaf7\uddd6\ud8fb\udc5f\ud9c3\ude28\ud969\udcfc\ud8bd\ude19\udb9b\udf3f\ud987\udddd\ud8a8\udf40\ud9ba\udc60\udbd3\udc96",
        56, 59456, -1401069527, 233839986460635554L, -80244L, true, true, (char) 65426, (char) 51738,
        Double.longBitsToDouble(0x3fe85df0fac93993L), Double.longBitsToDouble(0x3fd59960babbff48L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.random.ISAACRandom:@?\0121=void |this=org.apache.commons.math3.random.ISAACRandom:@?\012",
        Z.run(T, 2, 10, 10, 7, "\u2b57\ud960\udd20\udb0d\udded\ud957\udffb\udbe9\udca3\udb4b\ude1a\uda72\udfe0\udbc3\udeb7\udb73\udfab\udade\ude4b\udb56\udfab\uda6a\udfb3\ud88c\udfad\ud87e\udde0\ud81f\udf5d\ud911\udf4a\ud92b\udfb7\ud942\udc7c\uda30\udd00\u7a52\udbcb\udef4\ud946\udecc\uda40\ude35\u2646\udbd0\uddc7\uda5f\udd6b\ud912\udfa9\ud871\udf29\ud98c\udced\udabf\udf1c\u05b5\ud8ed\udda0\uda04\udc33\udb33\udfc9\ud8fa\udc08\ud8e2\udefa\ud9a5\udc19\ud978\udc54\ud873\udc82\ud9b8\udd30\ud9c2\udfb8\ud991\ude0b", "\u84b3\u8d07\u1978\u18f3\uca0e\u1a49\u472c\u1cfb\u0ba8\u17a8\u022b\u4afe\u2217\uc8bd\u727c\u3df1\ub04c\ua950\u16a9\u675a\u3ebb\u4a7e\ud7cd\u2466\u101e", "\uda7b\ude2e\udbed\udef4\ud934\udefc\ud9c8\ude56\ud8ed\ude31\uda2c\udc04\ud9c3\ude34\ud969\udcfc\ud8bd\ude19\u8a15\ud8c5\ude58\ud8a8\udf25\ud9ba\udc60\udbd3\udc96\ud8aa\udd41\udbcf\udce5\udafc\udf9b\udbd3\udc6b\uda0f\udfb2\ud901\udfe0\ud8fb\udea2\ud831\uddfe\udb5f\udfa4\udac6\udcd9\udb01\ude4c\udabb\udd92\ud890\udd95\uda80\udf77\uda9f\udde9\ud9be\udf51",
        47, 13570, 630621278, -4525732791490574680L, -94412L, false, false, (char) 32616, (char) 57588,
        Double.longBitsToDouble(0x3fe1107131725013L), Double.longBitsToDouble(0x3fe7398c51dcdd60L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.random.ISAACRandom:@?\0121=void |this=org.apache.commons.math3.random.ISAACRandom:@?\012",
        Z.run(T, 2, 11, 11, 7, "\ud95e\udd59\ud960\udd20\udb0d\udded\ud957\udffb\udbe9\udca3\udb4b\ude1a\uda72\udfe0\udbc3\udeb7\udb73\udfab\udade\ude4b\udb56\udfab\ud9b2\uddb6\uda81\ude9f\u2baa\ud81f\udf5d\ud911\udf4a\ud92b\udfb7\ud942\udc7c\uda30\udd00\u7a52\udbcb\udef4\ud946\udecc\uda40\ude35\u2646\udbd0\uddc7\uda5f\udd6b\ud912\udfa9\ud871\udf29\udb1e\udde6\uda31\uddd4\ud87c\uddf9\ud8ed\udda0\uda04\udc33\udb33\udfc9\ud8fa\udc08\ud8e2\udefa\udb7a\udddb\ud978\udc54\ud873\udc82\ud9b8\udd30\ud9c2\udfb8\ud991\ude0b", "\u84b3\u8d07\u1978\u18f3\uca0e\u1a49\u472c\u1cfb\u0c57\u17a8\u022b\u4afe\u2217\uba2d\u7277\u3df1\ub04c\ua950\u16a9\u675a\u3ebb\u4a7e\u99a9\u2466\u101e", "\uda7b\ude2e\udbed\udef4\ud883\udd8f\ud9c8\ude0f\ud8ed\ude31\uda2c\udc04\ud9c3\ude34\ud93d\udcfb\ud8bd\ude19\u8a15\ud8c5\ude58\ud8a8\udf25\ud9ba\udc60\udbb4\udf96\ud8aa\udd41\udbcf\udce5\ud840\udf3d\udbd3\udc6b\uda0f\udfb2\ud8d2\udde0\ud8fb\udea2\ud831\uddfe\udb5f\udfa4\udac6\udcd9\udb01\ude4c\udabb\udd92\ud890\udd95\uda80\udf77\uda9f\udde9\ud9be\udf51",
        47, 13570, 630621278, -4525732142950512984L, -94412L, false, false, (char) 32616, (char) 57588,
        Double.longBitsToDouble(0x3fe1107135725013L), Double.longBitsToDouble(0x3fe73962a9dcdd60L)));
  }
  @Test
  public void test13() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test13() throws Throwable {
//     assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.math3.random.ISAACRandom:@?\0121=!java.lang.NullPointerException\012",
//         Z.run(T, 2, 2, 3, 8, "\udb45\udf9b\ud960\udd20\uda92\udd1a\ud952\udd35\udbe9\udca3\udb66\uddac\ud8c5\udfd4\ud89a\udfcd\ud9af\ude3e\udade\ude4b\udb56\udfab\uda6a\udfb3\uda81\uded9\u2baa\ud81f\udf5d", "\u26d7\u4f56\u042f\u1123\u567d\u1193\u4588\u1d85\u675f\ua80c\u5645\u73bc\u802d\u4110\ub019\ub578\ua28d\u63d9\u3aa5\u58d7\ud598", "\ud9c2\udfb8\ud991\ude0b\ud91d\ude57\ud895\udfb0\udac8\udd27\ud8af\udda4\udb1b\udf93",
//         12, 96061, -1564565296, 7740910103837822511L, 76401L, true, true, (char) 14865, (char) 39478,
//         Double.longBitsToDouble(0x3fde1daf7c98ff8aL), Double.longBitsToDouble(0x3fd8d730e7ca5acaL)));
//   }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.random.ISAACRandom:@?\0121=void |a0=[I:[[35448]] |this=org.apache.commons.math3.random.ISAACRandom:@?\012",
        Z.run(T, 2, 10, 11, 10, "\u8aa8", "\u8f21\u270b\u7386\ua0e5\u4b8b\u698e\u34c0\u52d6\u656c\uce8b\u217c\u7763\uc118\u7846\u26d7\u4f56\u042f\u1123\u6132\u1193\ubb0b\u0d5a\u429f\u37a3\u94fe\u93d7\u6e90\u4110\ub019\ub578\ud100\u9bd8\ube6f\u27e9\ud598\ubb45\ua02d\u8d53\u0410\ub4e5", "\uda02\ude65\ud857\udd3e\uda45\udf20",
        7, 2629, 167663973, -1045874789549290974L, 91139L, true, false, (char) 37650, (char) 18465,
        Double.longBitsToDouble(0x3f7ebf79ec363480L), Double.longBitsToDouble(0x3fe33f3c37439e2cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.random.ISAACRandom:@?\0121=!org.apache.commons.math3.exception.NotStrictlyPositiveException\012",
        Z.run(T, 2, 10, 8, 3, "\ud956\udf8b\ud9a4\udf61\udb9b\udf35\udbdb\udf35", "\ud069\u1a7f", "\uda6f\udcc2\udbb6\ude44\udaf0\ude39\ud829\udd24\ud81f\udf5d\ud911\udf4a\ud92b\udfb7\ud942\udc7c\uda30\udd00\u7a52\udbcb\udef4\ud946\udecc\uda40\ude35\u2646\ud8f4\udf52\ud91e\udd1c\u524b\ud871\udf29\ud9df\udce6\ud90f\udfc3\ud87c\uddf9\ud8ed\udda0\uda04\udc33\ud910\udfb8\udbe6\ude9f\udb6f\ude9b\udb70\udf26\ud9b6\udf53\udac1\udd65\udb81\udd9e",
        -1, 33924, -1212904806, -3113198746527914861L, -62853L, true, false, (char) 2120, (char) 22634,
        Double.longBitsToDouble(0x3fe1178be31144c8L), Double.longBitsToDouble(0x3fdd21eba2b13680L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.random.BitsStreamGenerator|clear||new:org.apache.commons.math3.random.ISAACRandom:",
    "M|org.apache.commons.math3.random.BitsStreamGenerator|next|int|new:org.apache.commons.math3.random.ISAACRandom:",
    "M|org.apache.commons.math3.random.BitsStreamGenerator|nextBoolean||new:org.apache.commons.math3.random.ISAACRandom:",
    "M|org.apache.commons.math3.random.BitsStreamGenerator|nextBytes|[B|new:org.apache.commons.math3.random.ISAACRandom:",
    "M|org.apache.commons.math3.random.BitsStreamGenerator|nextDouble||new:org.apache.commons.math3.random.ISAACRandom:",
    "M|org.apache.commons.math3.random.BitsStreamGenerator|nextFloat||new:org.apache.commons.math3.random.ISAACRandom:",
    "M|org.apache.commons.math3.random.BitsStreamGenerator|nextGaussian||new:org.apache.commons.math3.random.ISAACRandom:",
    "M|org.apache.commons.math3.random.BitsStreamGenerator|nextInt||new:org.apache.commons.math3.random.ISAACRandom:",
    "M|org.apache.commons.math3.random.BitsStreamGenerator|nextInt|int|new:org.apache.commons.math3.random.ISAACRandom:",
    "M|org.apache.commons.math3.random.BitsStreamGenerator|nextLong||new:org.apache.commons.math3.random.ISAACRandom:",
    "M|org.apache.commons.math3.random.BitsStreamGenerator|setSeed|int|new:org.apache.commons.math3.random.ISAACRandom:",
    "M|org.apache.commons.math3.random.BitsStreamGenerator|setSeed|[I|new:org.apache.commons.math3.random.ISAACRandom:",
    "M|org.apache.commons.math3.random.BitsStreamGenerator|setSeed|long|new:org.apache.commons.math3.random.ISAACRandom:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
