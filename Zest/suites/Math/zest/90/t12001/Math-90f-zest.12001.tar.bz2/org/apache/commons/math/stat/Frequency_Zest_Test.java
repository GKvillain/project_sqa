package org.apache.commons.math.stat;
import org.junit.Test;
import static org.junit.Assert.*;
public class Frequency_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 14, 9, 17, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud899\ude06\udb2d\udf38\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\uda67\udd7f", "\u9895", "\udb57\udd57\ud9e6\udedb\udaa8\ude1a\uda0d\udd13\udb40\udf2f\ud805\uddd0\udb04\ude38\ud904\udcfc\ud8dd\udd20\uda1f\udd5b\uda22\udc17\uda87\ude82",
        25, 53470, 1976202083, 1375667694118462455L, -1116L, true, true, (char) 21270, (char) 9420,
        Double.longBitsToDouble(0x3fe10fc3cae1e062L), Double.longBitsToDouble(0x3fd1d7ba4ccba030L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01225\0111\011100%\011100%\012\012",
        Z.run(T, 1, 17, 9, 17, "\uda43\udc01\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud899\ude06\udb48\udd85\udadc\ude04\uda44\udd94\udaf3\ude9b\udb33\udd9c\udb12\udd55\uda83\ude5d\uda67\udd7f", "\u9895", "\udb57\udd57\ud9e6\udedb\udbf3\ude1c\uda0d\udd13\udb40\udf2f\ud805\uddd0\udb04\ude38\ud904\udcfc\ud8dd\udd20\ud8ac\udd0c\uda22\udc86\udb27\udc7c",
        25, 53470, 1976202083, 1375667694118462455L, -1116L, true, true, (char) 21270, (char) 9420,
        Double.longBitsToDouble(0x3fe10fc3cae1e062L), Double.longBitsToDouble(0x3fd1d7ba4ccba030L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 14, 9, 17, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud899\ude06\udb2d\udf38\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\uda67\udd7f", "\u9895", "\udb57\udd57\ud9e6\udedb\udaa8\ude1a\uda0d\udd13\udb40\udf2f\ud805\uddd0\udb04\ude38\ud904\udcfc\ud8dd\udd20\uda1f\udd5b\uda22\udc17\uda87\ude82",
        25, 53470, 1976202083, 1375667694118462455L, -1116L, true, true, (char) 21270, (char) 9420,
        Double.longBitsToDouble(0x3fe10fc3cae1e062L), Double.longBitsToDouble(0x3fd1d7ba4ccba030L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 14, 9, 0, "\uda43\udcdd", "\u0418", "\000\000\000",
        15, 39907, 0, -8149263524716345736L, -29841L, true, true, (char) 15755, (char) 612,
        Double.longBitsToDouble(0x3fcc0c80088ba2fcL), Double.longBitsToDouble(0x3fdbaf7f1ff13592L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 16, 17, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda3b\udd7c\udba9\udf8f\uda2e\udd56\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud899\ude06\udb2d\udf38\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\uda67\udd7f", "\u9895", "\udb57\udd57\ud9e6\udedb\udaa8\ude1a\uda0d\udd13\udb40\udf2f\ud805\uddd0\udb04\ude38\u00cb\udaf3\udc98\uda1f\udd5b\uda5a\udd0a\uda49\udf82",
        21, -1000, 0, 1375667165837485047L, -1116L, true, true, (char) 0, (char) 9420,
        Double.longBitsToDouble(0x3fe10fc3cae1e062L), Double.longBitsToDouble(0x3fd1d7ba4ccba030L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\uda35\udedd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\udbd8\udf65\uda37\uddff\ud8d7\udec1\udb84\udc19\u8348\ud99c\udec8\udb2b\ude54\uda52\ude7f\uda44\udd94\ud803\ude26\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\uda67\udd7f\0111\011100%\011100%\012\012",
        Z.run(T, 1, 18, 4, 17, "\uda35\udedd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\udbd8\udf65\uda37\uddff\ud8d7\udec1\udb84\udc19\u8348\ud99c\udec8\udb2b\ude54\uda52\ude7f\uda44\udd94\ud803\ude26\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\uda67\udd7f", "\u9895", "\udb46\udfee\ud9e4\udc5d\uda9d\ude94\uda71\udc29\udb40\udf2f\ud805\uddd0\udb04\ude38\ud904\udcfc\udb40\udfaf\uda55\ude17\udb96\udd78\uda87\ude82",
        6, 22905, 1976202083, 78805823784575939L, -1116L, true, true, (char) 21270, (char) 9420,
        Double.longBitsToDouble(0x3fe10fc3cc9fe062L), Double.longBitsToDouble(0x3fd1ddda4ccba030L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 15, 9, 18, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63", "\u65cd\u6b74\u7a38\u7d22", "\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e",
        49, 61443, -390073120, -580495815646570054L, 18862L, true, false, (char) 57659, (char) 4480,
        Double.longBitsToDouble(0x3f97742a625599a0L), Double.longBitsToDouble(0x3fdd52e891978578L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u5316\0111\011100%\011100%\012\012",
        Z.run(T, 1, 16, 9, 17, "\uda43\udcdd\ud98d\udd8d\ud8c1\udebc\udb3b\udfc4\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\uda50\udce3\udb7f\udee3\uda8e\udeff\ud899\ude06\udb2d\udf38\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udad4\udf56\uda11\udec1\ud8cb\udd62", "\u9895", "\udb57\udd57\ud9e6\udedb\udaa8\ude1a\uda0d\udd13\udb40\udf2f\ud805\uddd0\udb04\ude38\ud904\udcfc\ud8dd\udd20\ud8cc\udd51\uda22\udc17\uda87\ude82",
        1, 35414, 1976202239, 1375667694118462455L, -43261L, true, true, (char) 21270, (char) 9420,
        Double.longBitsToDouble(0x3fa0fc3cae1e0050L), Double.longBitsToDouble(0x3fd1d7ba4ccba030L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \0124041798673521781159\0111\011100%\011100%\012\012",
        Z.run(T, 1, 5, 9, 17, "\uda43\udcdd\udb0a\udd7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda78\udf68\udba9\udf8f\ud88c\udc65\ud994\udcf6\udb7f\ude4d\uda8e\udf3d\ud899\ude06\uda2a\ude76\ud8f7\uddf1\uda44\udd94\ud803\ude23\u7367\udbe5\udf7f\ud9c5\ude78\uda67\udd7f", "\u9895", "\udb57\udd57\ud954\udeab\udaa8\ude5d\uda0d\udd13\udb40\udf87\ud805\uddd0\udb04\ude38\ud91c\udca8\ud831\udff1\uda1f\udd5b\uda22\udc17\uda87\ude82",
        33, 53470, 1976202083, 4041798673521781159L, -1116L, true, true, (char) 21270, (char) 9420,
        Double.longBitsToDouble(0x3fe10fc3cae1e062L), Double.longBitsToDouble(0x3fd1d7ba4ccba030L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 8, 10, 8, "\ud87f\udc6c\udb7a\udd76\ud8e7\udf46\udb3b\udf04\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\udb7f\udee3\uda2d\udeed\ud886\udfd3\udb2d\udf38\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\uda67\udd7f", "\ud4ba", "\ud875\udd96\ud9e6\ude78\udaa8\ude1a\udbe3\udd5e\ud9c5\udf2d\ud805\uddd0\udb04\ude38\ud904\udcfc",
        58, 10038, -1996924397, -1560902172391188314L, -22795L, true, false, (char) 47481, (char) 6793,
        Double.longBitsToDouble(0x3fdbcd713a2ab47cL), Double.longBitsToDouble(0x3fe2a26610f173dbL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 11, 4, "\uda19\udc28\ud886\ude6e\ud8f4\ude60\udb3b\udf04\udb65\udc63", "\ua4cc\ua4e6\u7a38\u7d22", "\udadc\ude04",
        38, 43859, 829037762, -884655996466399381L, 72641L, false, false, (char) 5106, (char) 2242,
        Double.longBitsToDouble(0x3fea08726fb2bbb7L), Double.longBitsToDouble(0x3fe3eec7df194a23L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 7, 19, 12, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udbaf\ude2b\udaf9\udee0\uda73\udf32\udb51\uddb1\uda2e\udd56\ud994\udcc5\udbce\udf29\ud8ef\udf90\ud89f\udd22\udab8\udd5d\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud848\uddb7\uda67\udd7f", "\u9895", "\ud928\udf9f\ud9ab\udcb8\udaa8\ude1a\uda0d\udd13\udb40\udf2f\ud9ad\udd83\uda6b\ude7b\u2509\ud9bf\udd85\u52e7\uda22\udc17\ud9f7\udd9d",
        26, 53470, 1976202083, 1375667694118462455L, -1116L, false, true, (char) 7077, (char) 53528,
        Double.longBitsToDouble(0x3fe24dc00ae1e062L), Double.longBitsToDouble(0x3fd1d7ba4ccba030L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01225\0111\011100%\011100%\012\012",
        Z.run(T, 1, 3, 9, 17, "\uda43\udc13\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb2d\udee8\uda6d\udd6c\udba9\udf8f\ud9ed\udd36\udbcc\udc06\udaf9\udd2f\ud9a9\ude84\ud899\ude06\udb2d\udf38\udb8c\ude1e\uda44\udcb5\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\uda67\udd7f", "\u9c33", "\udb57\udd57\ud9e6\udedb\udaa8\ude1a\uda0d\udd13\udb40\udf2f\uda83\ude70\udada\udfbc\udb8a\uddc0\ud91a\udd6f\uda1f\udd5b\uda8a\uddea\uda87\ude82",
        25, 53470, -1765194653, 1375667758542971895L, -45452L, true, false, (char) 14184, (char) 52442,
        Double.longBitsToDouble(0x3fed09d3cae1e085L), Double.longBitsToDouble(0x3fedebdd26f07c06L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\ud8e7\udc9a\ud8a6\udcf7\ud886\udd12\u2180\ud849\ude27\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud9fd\uddd7\ud8d7\udd85\udaf8\udc04\uda44\udd94\ud916\udcf7\udb63\udd5e\udb12\udd55\ud9c5\ude5e\udaff\udd6c\0111\011100%\011100%\012\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 16, 17, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\ud8e7\udc9a\ud8a6\udcf7\ud886\udd12\u2180\ud849\ude27\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud9fd\uddd7\ud8d7\udd85\udaf8\udc04\uda44\udd94\ud916\udcf7\udb63\udd5e\udb12\udd55\ud9c5\ude5e\udaff\udd6c", "\u15da\u019f\ubdee\ua863\ua65b\u2aac\u1fe9\u7d7b\u6a39\uba0b\u0867", "\uda22\udc17\uda87\ude82\ud852\udfbf\ud8fa\ude28\ud802\ude54\u5b9b\ud9cd\udf11\ud9f4\udef2\ud9dc\uddb6\uda40\udd1e\udb6b\udd27\ud9ca\udc7f",
        46, 29737, -803697379, -5453166021353054952L, 73582L, true, true, (char) 53884, (char) 17218,
        Double.longBitsToDouble(0x3fb3bf294eed2cc0L), Double.longBitsToDouble(0x3fe3fdc8658f0c92L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 13, 9, 17, "\uda43\udcdd\udaf2\udc7f\uda6c\ude9c\udb3b\udfb0\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\udbad\uddb9\uda8e\udf3d\ud899\ude06", "\u8073\uc91c\u17fa\ud381\u962c\u2b9d\u80b9\u8151\u9895\u31c4\ube95\ua863\ua65b", "\udb40\udf2f\ud805\uddd0\udb04\ude38\ud904\udcfc\ud8dd\udd20\ud855\udd56\uda22\udc17\uda87\ude82\ud852\udfbf\ud8fa\ude28\ud802\ude54\u5b9b\ud9cd\udf11\uda59\udc18\udaf8\udd08\uf19b\udb6b\udd27",
        30, 8281, 2074368737, -3451853959740295579L, 78431L, true, false, (char) 57571, (char) 11769,
        Double.longBitsToDouble(0x3fd62f946bbd01f2L), Double.longBitsToDouble(0x3fd0dee7df3b1042L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\uda23\uddcb\ud8cd\udf53\udb87\uddf3\ud899\ude06\udb2d\udf38\udae4\udfae\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\uda67\udd7f\0111\011100%\011100%\012\012",
        Z.run(T, 1, 20, 9, 17, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\uda23\uddcb\ud8cd\udf53\udb87\uddf3\ud899\ude06\udb2d\udf38\udae4\udfae\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\uda67\udd7f", "\u9895", "\udb81\ude7f\ud9e6\udedb\udaa8\ude1a",
        44, 85143, 780737298, -4414383239498268469L, -5445L, true, true, (char) 32799, (char) 13078,
        Double.longBitsToDouble(0x3fecb1d2b363a3e2L), Double.longBitsToDouble(0x3fe3dbae53f71317L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 12, 6, 17, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\ud8f1\udd9b\udbba\uddbe\udb43\udf80\udb2d\udf38\udadc\ude04\uda44\udd94\udadd\udecb\ud970\udc3d\udb12\ude3c\ud9c5\ude5e\udabb\udd86", "\u9895", "\udb57\udd57\ud9e6\udedb\udaa8\ude1a\uda0d\udd13\udb40\udf2f\ud805\uddd0\udb04\ude38",
        -3, 37987, 1139372379, -8585066927544076353L, -67615L, false, false, (char) 53317, (char) 16391,
        Double.longBitsToDouble(0x3fe4116075bcd713L), Double.longBitsToDouble(0x3fd155a3eca89984L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 11, 3, 17, "\udb4d\udc09\udaf2\udc7f\ud8f4\ude73\udae7\udc59\ud9ed\udc0a\ud9ad\udf43\ud823\udeea\uda2e\udd56\ud994\udcc5\uda65\udc45\uda8e\udf3d\ud899\ude06\udb2d\udf38\ud80d\udf06\uda53\ude29\ud803\ude23\udb18\udfaa\ud9f4\ude54\ud8af\udef2\uda7e\udccf", "\u9941\u31c4\ube95\u5a64\ua65b\u2aac\u2057\u7d7b\u4298\u4d39", "\uda1f\udd5b\uda22\udc17\uda87\ude82\ud852\udfbf\ud8fa\ude28\ud802\ude54\u5b9b\ud9cd\udf11\ud98d\udcd1\ud914\ude00\ud8a5\udc20\udb8e\udd79\ud873\udd00\ud88e\udf05\ud92c\ude2a\ud8fe\ude4a\ud92f\udc8c\ud8a1\udf7d\udabd\udef5",
        45, 12491, 150002585, -8099379783331416422L, -88746L, true, false, (char) 4797, (char) 63795,
        Double.longBitsToDouble(0x3fd01fe60df8aa6eL), Double.longBitsToDouble(0x3fde7b647ffa6eccL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 14, 15, 17, "\udab9\udf90\udaf2\udc9b\uda3b\udd89\udb49\udfd7\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\udb7f\udee3\ud842\udf37\ud899\ude06\udb2d\udf38\udadc\ude04\ud810\udc70\ud9ff\udcb5\udb36\udff2\uda4d\udd37\ud9e7\udc5b\uda67\udd7f", "\u9895", "\udb57\udd57\ud9e6\udedb\ud866\ude59\ud936\udfab\udb38\udc46\ud8cb\uddd3",
        21, 65924, 1248942720, 4893567103771836735L, 80303L, false, true, (char) 5958, (char) 54074,
        Double.longBitsToDouble(0x3fefbd11c682ace9L), Double.longBitsToDouble(0x3fdcc3113a2ab47cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-2876058869234950531\0111\011100%\011100%\012\012",
        Z.run(T, 2, 8, 5, 1, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\udaa0\udf27\ud859\udf15\udb2a\ude21", "\ua388\u2027\uc64c\u8073\uc91c\u17fa\ud381\ubed5", "\ud819\udf28",
        59, 37498, -1152022536, -2876058869234950531L, 4901L, false, false, (char) 6835, (char) 13631,
        Double.longBitsToDouble(0x3fc7185781ecb18cL), Double.longBitsToDouble(0x3fd5b4ed403a87d2L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 6, 15, 17, "\ud9bf\udce9\udb58\udebf\ud94c\udcde\uebed\udb65\udd19\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\udb7f\udee3", "\ucfd8\uc5db\u8073\uc91c\u17fa\ud381\u7a52\u2b33\u80b9\u8151", "\udbd4\udc71\ud816\udc86\ud9e6\udedb\udaa8\ude1a\uda0d\udd13\udb40\udf2f\ud805\udea2\udb04\ude38\ud904\udcfc\ud8dd\udd20\uda1f\udd5b\ud8ab\udd3b\uda87\ude82\ud852\udfbf\ud8fa\ude28\ud802\ude54\u5b9b\ud9cd\udf11\uda59\udc18\ud9c4\udf0d\uf19b\udb6b\udd27\ud9ca\udc7f\u2c44\ud92c\ude2a\ud8fe\ude4a\ud99e\udfe5\uda5c\udca4\uda3d\ude9b\ud85e\udc4c\ud8df\udd18\ud9a7\udeb6\ud9ed\udcca\udb3f\udc63\uda78\ude3b\udbc7\ude95\udb92\udc5a\ud93b\uddd5\ud924\udeee\udb80\udf99\ud9f3\udd89",
        58, 76877, -520405009, -1564919824320431014L, -53020L, false, false, (char) 64582, (char) 60371,
        Double.longBitsToDouble(0x3feee93d8897149fL), Double.longBitsToDouble(0x3fc0f069ef8cbffcL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 10, 14, 14, "\uda43\udcdd\000\ud850\udc07\udb3b\udf04\udbac\udd07\uda04\udc01\000\000\ud8d2\udc0c\u00d5\000\ud89b\udc0d\udb2d\udf38\udadc\ude04\u00fd\u7e10\u1cc2\udb0d\udf46\u8f6e\000", "\u3d55", "\u00b2\ud9e6\udedb\udaa8\ude1a\ud9df\ude3d\000\ud805\uddbe\udb04\ude38\ua0cf\000\000\uda5a\udced\uda87\ude82",
        25, 53470, 1976202083, 526886961152L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 7, 8, 17, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud899\ude06\udb2d\udf38\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\uda67\udd7f", "\u9895", "\udb57\udd57\ud9e6\udedb\udaa8\ude1a\uda0d\udd13\udb40\udf2f\ud805\uddd0\udb04\ude38\ud904\udcfc\ud8dd\udd20\uda1f\udd5b\uda22\udc17\uda87\ude82",
        25, 53470, 1976202083, 1375667694118462455L, -1116L, true, true, (char) 21270, (char) 9420,
        Double.longBitsToDouble(0x3fe10fc3cae1e062L), Double.longBitsToDouble(0x3fd1d7ba4ccba030L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01225\0111\011100%\011100%\012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01225\0111\011100%\011100%\012\012",
        Z.run(T, 2, 17, 9, 17, "\uda60\udea7\ud94e\udcb3\ud957\udc20\udbcd\uddcd\ud94b\uddb7\uda6d\udd25\uec96\ud9d6\udcf9\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud899\ude06\udb48\udd85\udadc\ude04\uda44\udd94\udaf3\ude9b\udb33\udd06\udb12\udd55\uda83\ude5d\uda67\udd7f", "\u9895", "\udb57\udd57\udbe0\udd59\uda94\uddb2\uda0d\udd13\ud911\udcee\ud805\ude24\udb04\ude38\ud904\udcfc\ud8dd\udd20\ud8ac\udd0c\uda22\udc86\udb27\udc7c",
        25, 81446, 1976202083, 1375667694118462455L, -1116L, true, true, (char) 21270, (char) 9420,
        Double.longBitsToDouble(0x3fb3be1e570f0310L), Double.longBitsToDouble(0x3fd1d7ba4ccba030L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01225\0111\011100%\011100%\012\012",
        Z.run(T, 2, 12, 17, 5, "\uda43\udc01\udb2e\udef0\udab9\udee2\udbcb\udfb1\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud98d\uddc0\udb39\udd94\ud8d4\udd69\ud8c5\udc47\udb48\udd85\udadc\ude04\uda44\udd94\udaf3\udee5\udb33\udd9c\udb12\udd55\ud9b4\udcf5\uda7e\udc35", "\ub667", "\udb7b\udd88\ue6bd\ud860\udfc0\ud82c\ude04\udb40\udf2f\ud805\uddd0\udb04\ude38\udbd2\udea6\ud8dd\udd20\ud8ac\udd0c\uda22\udc86\udb27\udc7c",
        25, 53470, 1976202083, 1375667694118462455L, -1050L, true, true, (char) 21270, (char) 56964,
        Double.longBitsToDouble(0x3fe10fc3cae1a982L), Double.longBitsToDouble(0x3fd1d7ba4ccba030L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \0121375667694118462455\0111\011100%\011100%\012\012",
        Z.run(T, 2, 14, 5, 12, "\uda42\udfef\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud899\ude06\udb2d\udf38\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\uda63\udf5e", "\u9895", "\udb57\udd57\ud9e6\udedb\udaa8\ude1a\uda0d\udd13\udb40\udf2f\ud805\uddd0\udb04\ude38\ud904\udcfc\ud8dd\udd20\uda1f\udd5b\uda22\udc17\udb15\udfca",
        25, 53470, 1976202083, 1375667694118462455L, -1116L, true, true, (char) 21270, (char) 9420,
        Double.longBitsToDouble(0x3fe10fc3cae1e062L), Double.longBitsToDouble(0x3fd1d7ba4ccba030L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb60\udf63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud899\ude06\udb2d\udf38\udadc\ude04\uda44\udd94\ud803\ude23\udb5b\udfa7\udb12\udd55\ud9c5\ude5e\uda67\udd7f\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb60\udf63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud899\ude06\udb2d\udf38\udadc\ude04\uda44\udd94\ud803\ude23\udb5b\udfa7\udb12\udd55\ud9c5\ude5e\uda67\udd7f\0112\011100%\011100%\012\012",
        Z.run(T, 2, 20, 2, 17, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb60\udf63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud899\ude06\udb2d\udf38\udadc\ude04\uda44\udd94\ud803\ude23\udb5b\udfa7\udb12\udd55\ud9c5\ude5e\uda67\udd7f", "\u9895", "\udb57\udd57\ud9e6\udedb\ud864\uded8\ud9eb\udd9c\udb5f\ude03\ud805\uddd0\udb04\ude38\ud904\udcfc\ud8dd\udd20\uda1f\udd5b\uda22\udc17\uda87\ude82",
        25, 97046, 1974580470, 1375667694118462455L, -1116L, true, true, (char) 21270, (char) 9420,
        Double.longBitsToDouble(0x3fe10fc3cae1e062L), Double.longBitsToDouble(0x3fd1d7ba4ccba030L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01226\0111\011100%\011100%\012\012",
        Z.run(T, 2, 14, 3, 17, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud899\ude06\udb2d\udf38\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\uda67\udd7f", "\u9895", "\udb57\udd57\ud9e6\udedb\udaa8\ude1a\uda6b\udd22\udbf2\ude8a\uda36\ude9a\udad9\uddfe\ud8f9\udd85\ud8dd\udd20\uda1f\udd5b\uda22\udc17",
        26, 72855, -1545447530, 8487723317092375163L, -79138L, false, true, (char) 3923, (char) 21270,
        Double.longBitsToDouble(0x3fce27a4d887e1e4L), Double.longBitsToDouble(0x3fe70f03151d7ba4L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u4a53\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u4a53\0112\011100%\011100%\012\012",
        Z.run(T, 2, 16, 0, 17, "\ud8cb\udca1\udae3\udd1a\ud8f4\ude60\udb3b\udf04\udb65\udc63\ud83d\ude3e\udae0\ude8f\udbc5\udd41\ud981\udf79\udb7f\udebf\uda8e\udf3d\ud899\ude06\udb2d\udf38\udadc\ude04\uda4b\ude98\udb0e\udd41\udbd7\udf6b\udb12\udd55\ud9c5\ude5e\ud99a\ude7a", "\u9895\u31c4\u4dd2\ua863", "\uda0d\udd13\udb40\udf2f\ud805\uddd0\udb04\ude38\ud904\udcfc\ud8dd\udd20\uda1f\udd5b\uda22\udc17",
        26, 72855, -1545447530, -3329722105127793285L, -79138L, false, true, (char) 19027, (char) 59491,
        Double.longBitsToDouble(0x3fbb5526710fc3c8L), Double.longBitsToDouble(0x3fe70f03151d7b68L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 14, 12, 11, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud899\ude06\udb2d\udf38\udadc\ude04\uda44\udd94\ud803\ude8c\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\ud9e9\udd4d", "\u73c5\u8914\ube95\ua863\ua36a\ua607\u1fe9\ub52f", "\ud840\udcfa\ud8dd\udd20\uda1f\udd5b\uda22\udc17\uda87\ude82",
        25, 86558, 1912988547, 1375667694118462455L, -98119L, true, true, (char) 21270, (char) 9420,
        Double.longBitsToDouble(0x3fe10fc3cae1845eL), Double.longBitsToDouble(0x3fd1d7ba4671a030L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 13, 9, 11, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\ud8a9\udfee\uda2e\udd56\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud899\ude06\udb2d\udf38\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\ue189", "\u9895\u31c4\u6395\u40b3\ua65b\u2aac\u1fe9\u7d7b\u6a39\u4d39\u5caa\ua5e8\u49d8\ub9e7\u0fc9\ua2c8\u8af1\u0951\u8768\uc956\u5601\u30b1\u69d6\u29b0\u8bbf\u08cc\u7d6b\u3c56\u59d5\u7a00\u9c66\ub0ef\u4f6d\u4d48\u6c57\u14b8\u41d4\u2676\ub631\ua187\u2f12\u3353\ud017", "\ud92d\udc5f\uda61\ude67\u959c\ud8ba\ude14\udbf4\udc27",
        16, 85194, 543780046, -1231651302969664249L, -35800L, false, false, (char) 45912, (char) 21133,
        Double.longBitsToDouble(0x3fc93ce667a3a220L), Double.longBitsToDouble(0x3fd263644773a194L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\uf0f3\ud8aa\udd5b\udaad\udf9b\udb3b\udf04\ud98e\udf9e\ud8cd\udd5a\ud955\udf56\ud8be\uddb2\ud994\udd79\udb7f\udee3\uda8e\udf3d\ud824\ude79\udb2d\udf16\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\uda67\udd7f\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\uf0f3\ud8aa\udd5b\udaad\udf9b\udb3b\udf04\ud98e\udf9e\ud8cd\udd5a\ud955\udf56\ud8be\uddb2\ud994\udd79\udb7f\udee3\uda8e\udf3d\ud824\ude79\udb2d\udf16\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\uda67\udd7f\0112\011100%\011100%\012\012",
        Z.run(T, 2, 20, 20, 17, "\uf0f3\ud8aa\udd5b\udaad\udf9b\udb3b\udf04\ud98e\udf9e\ud8cd\udd5a\ud955\udf56\ud8be\uddb2\ud994\udd79\udb7f\udee3\uda8e\udf3d\ud824\ude79\udb2d\udf16\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\uda67\udd7f", "\u4f02", "\u4264\ud977\udc3a\udb67\ude71\udbc9\udf68\udb3f\udcca\ud805\uddd0",
        29, 78011, 1322529953, 4893567103771850525L, 86549L, true, true, (char) 25933, (char) 23346,
        Double.longBitsToDouble(0x3fdbcd713a2ab47cL), Double.longBitsToDouble(0x3fe2a26610f173dbL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 7, 7, 12, "\ud87f\udc6c\udb7a\udd76\ud8e7\udf46\udb3b\udf04\ud82e\udee9\ud9ff\udd2e\udba9\udf8f\uda2e\udd56\ud95a\udc1c\udb7f\udee3\uda2d\udeed\ud886\udfd3\udb2d\udf38\udadc\ude8a\uda44\udd94\uda30\ude03\udac7\udfda\udb12\ude45\ud9c5\ude5e\uda67\udd7f", "\ud4ba", "\ud813\udffd\ud9e5\udd63\udaa8\ude1a\udbe3\udd5e\ud9c5\udf2d\ud805\uddd0\uda7b\udc34\ud904\udcfc",
        58, 10038, -1998102200, -1560902172391188410L, -22795L, false, false, (char) 62323, (char) 6793,
        Double.longBitsToDouble(0x3fdbcd713a2ab47cL), Double.longBitsToDouble(0x3fe31957d8f173dbL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01259\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01259\0112\011100%\011100%\012\012",
        Z.run(T, 2, 3, 3, 4, "\uda19\udc28\ud886\ude6e\ud8f4\ude60\udb3b\udf04\udb65\udc7c", "\ucc67\ua4e6\u7a38\u7d22", "\udadc\ude04",
        59, 40646, 1703044138, -884655996466399381L, 72641L, false, false, (char) 5106, (char) 2242,
        Double.longBitsToDouble(0x3fea08726fb2bbb7L), Double.longBitsToDouble(0x3fe3eec7df194a23L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 8, 8, 3, "\uda43\udc13\udaf2\udc7f\ud8f4\ude60\u4c36", "\ua13a", "\udaf9\udd2f",
        38, 67804, -1897394717, -8836615141967768546L, -41826L, true, false, (char) 34440, (char) 36770,
        Double.longBitsToDouble(0x3fde368819c0c888L), Double.longBitsToDouble(0x3fe281b2f1baf778L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\uda31\udd4b\udaf2\udc7f\ud8f4\ude60\ud8e7\udc9a\ud8a6\udcf7\ud886\udd12\u2180\ud849\ude27\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud9fd\uddd7\udb36\ude1a\udaf8\udc04\uda44\udd94\ud916\udcf7\udb63\udd5e\udb12\udd55\uda43\ude5d\udaff\udd6c\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\uda31\udd4b\udaf2\udc7f\ud8f4\ude60\ud8e7\udc9a\ud8a6\udcf7\ud886\udd12\u2180\ud849\ude27\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud9fd\uddd7\udb36\ude1a\udaf8\udc04\uda44\udd94\ud916\udcf7\udb63\udd5e\udb12\udd55\uda43\ude5d\udaff\udd6c\0112\011100%\011100%\012\012",
        Z.run(T, 2, 2, 2, 17, "\uda31\udd4b\udaf2\udc7f\ud8f4\ude60\ud8e7\udc9a\ud8a6\udcf7\ud886\udd12\u2180\ud849\ude27\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud9fd\uddd7\udb36\ude1a\udaf8\udc04\uda44\udd94\ud916\udcf7\udb63\udd5e\udb12\udd55\uda43\ude5d\udaff\udd6c", "\u15da\u019f\u1558\ua863\ua65b\u2aac\u1fe9\u7d7b\u6a39\uba0b\u0867", "\uda22\udc17\uda87\ude82\ud852\udfbf\ud8fa\ude28\ud802\ude54\u5b9b\ud9cd\udf11\ud9f4\udef2\ud9dc\uddb6\uda40\udd1e\udb6b\udd27\ud932\udff4",
        15, 29737, -1105687267, -2192381486752695306L, -38749L, false, true, (char) 6917, (char) 38499,
        Double.longBitsToDouble(0x3fe78afc5fc6637cL), Double.longBitsToDouble(0x3fb3bf295eed2cc0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01246\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-5453166022676751080\0111\01150%\01150%\01246\0111\01150%\011100%\012\012",
        Z.run(T, 2, 17, 5, 11, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\ud8e7\udc9a\ud8a6\udcf7\ud886\udd12\u2180\ud849\ude27\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud9fd\uddd7\ud8d7\udd85\udaf8\udc04\uda44\udd94\ud916\udcf7\udb63\udd5e\udb12\udd55\ud9c5\ude5e\udaff\udd6c", "\u15da\u019f\ubdee\ua863\ua65b\u2aac\u1fe9\u7d7b\u6a39\uba0b\u0867", "\uda22\udc17\uda87\ude82\ud852\udfbf\ud8f2\udc5b\ud802\ude54\u5b9b\ud9cd\udf11\ud9f4\udef2\ud9dc\uddb6\uda40\udd1e\udb6b\udd27\ud9ca\udc7f",
        46, 29717, -804002531, -5453166022676751080L, 40622L, false, true, (char) 6917, (char) 38499,
        Double.longBitsToDouble(0x3fe78afc5fc6637cL), Double.longBitsToDouble(0x3fb3bf294eed2cc0L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01228\0111\011100%\011100%\012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01228\0111\011100%\011100%\012\012",
        Z.run(T, 2, 1, 14, 17, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\ud90e\udd67\udb07\udf79\ud8a6\uddb0\udbd8\udc18\ua0d8\ud99b\udeb5\udb7f\udee3\uda8e\udf3d\ud9fd\uddd7\ud8d7\udd85\udaf8\udc04\uda44\udd94\ud916\udcf7\udb63\udd5e\uda15\udd50\ud9c5\ude5e\udaff\udd6c", "\u15da\u019f\ubdee\ua863\ua65b\u2aac\u1fe9\u7d7b\u6a39\u31bf\u3a10", "\uda22\udc17\uda87\ude82\ud852\udfbf\ud8fa\ude28\ud802\ude54\u5b9b\ud9cd\udf11\ud9f4\udef2\ud9dc\uddb6\uda40\udd1e\udb6b\udd27\ud9ca\udc7f",
        28, 29737, -803697379, -5453166022024143592L, 73582L, true, true, (char) 53884, (char) 17218,
        Double.longBitsToDouble(0x3fb3bf294eed2cc0L), Double.longBitsToDouble(0x3fe3fdc8658f0c92L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01246\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01246\0112\011100%\011100%\012\012",
        Z.run(T, 2, 17, 17, 17, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\ud8e7\udc9a\ud8a6\udcf7\ud886\udd12\u2180\ud849\ude27\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud9fd\uddd7\ud8d7\udd85\udaf8\udc04\uda44\udd94\ud916\udcf7\udb63\udd5e\udb12\udd55\ud9c5\ude5e\udaff\udd6c", "\u15da\u019f\ubdee\ua863\ua65b\u2aac\u1fe9\u7d7b\u6a39\uba0b\u0867", "\uda22\udc17\uda87\ude82\ud852\udfbf\ud8fa\ude28\ud802\ude54\u5b9b\ud9cd\udf11\ud9f4\udef2\ud9dc\uddb6\uda40\udd1e\udb6b\udd27\ud9ca\udc7f",
        46, 29737, -803697379, -5453166021353054952L, 73582L, true, true, (char) 53884, (char) 17218,
        Double.longBitsToDouble(0x3fb3bf294eed2cc0L), Double.longBitsToDouble(0x3fe3fdc8658f0c92L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 15, 15, 9, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\ud8e7\udc9a\ud8a6\udcf7\ud886\udd12\u2180\ud849\ude27\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud9fd\uddd7\ud8d7\udd85\udaf8\udc04\uda44\udd94\ud916\udcf7\udb63\udd5e\udb12\udd55\ud9c5\ude5e\ud843\udd3d", "\u15da\u019f", "\ud9e6\udedb\udaa8\ude1a\uda0d\udd13\udb40\udf2f\ud805\uddd0\ud98e\udd73\udbb5\udfd4\ud8dd\udcaa\uda1f\udd5b\uda22\udc17\uda87\ude82\ud852\udfbf\ud8fa\ude28\ud802\ude54\u5b9b\udbc1\udf0b\ud9f4\udef2\ud9dc\uddb6",
        53, 88844, -126242575, -2278234128431949087L, 763L, false, true, (char) 9933, (char) 39793,
        Double.longBitsToDouble(0x3fd5e1183c1ce9eeL), Double.longBitsToDouble(0x3fd05a95e5e2bf16L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \0121375624649956227063\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \0121375624649956227063\0112\011100%\011100%\012\012",
        Z.run(T, 2, 5, 5, 12, "\uda42\udfef\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\udb7f\udee3\udbf6\udc92\udba3\udc35\uda03\udff7\udb0d\ude14\uda44\udd94\ud803\ude23\ud90c\udf85\udb12\udd55\uda7b\uddf8\uda63\udf5e", "\u9895", "\udb57\udd57\ud9e6\udedb\udaa8\ude1a\ud9c6\udc91\ud8ae\udf6a\udac1\udd9b\udaac\udf61\ud904\udcfc\ud967\udc26\uda49\udc50\ud836\udf16\udb15\udfed",
        25, 53470, -2083909915, 1375624649956227063L, -1071L, true, true, (char) 21270, (char) 9420,
        Double.longBitsToDouble(0x3fe10fc3c9e1e062L), Double.longBitsToDouble(0x3fe7e75d1e65d0fbL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 9, 11, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\ud8a9\udfee\uda2e\udd56\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud899\ude06\udb2d\udf38\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\ue189", "\u9895\u31c4\u6395\u40b3\ua65b\u2aac\u1fe9\000\000\000\u5bdf\ua5e8\u49d8\ub9e7\u0fc9\ua2c8\u8af1\u0951\u8768\uc956\u5601\u30b1\u69d6\u29b0\u8bbf\u08cc\u7d6b\u3c56\u59d5\u7a00\u9c66\ub0ef\u4f6d\u4d48\u6c57\u14b8\u41d4\u2676\ub631\ua187\u2f12\u3353\ud017", "\ud92d\udc5f\uda61\ude67\u959c\ud8ba\ude14\u00ea",
        -5, -1000, 0, -1231651302969664249L, -35800L, false, false, (char) 45912, (char) 21133,
        Double.longBitsToDouble(0x3fc93ce667a3a220L), Double.longBitsToDouble(0x3fd263644773a194L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01226\0111\011100%\011100%\012\012",
        Z.run(T, 1, 19, 9, 17, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud899\ude06\udb2d\udf38\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\uda67\udd7f", "\ucb80", "\udb57\udd57\ud9e6\udedb\udaa8\ude1a\uda0d\udd13\udb40\udf2f\ud805\uddd0\udb04\ude38\ud904\udcfc\ud8dd\udd20\uda1f\udd5b\uda22\udc17\uda87\ude82",
        26, 53347, 1976202083, 1375667694118462455L, -1116L, true, true, (char) 21270, (char) 9420,
        Double.longBitsToDouble(0x3fe10fc3cae1e062L), Double.longBitsToDouble(0x3fd1d7ba4ccba030L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 10, 10, 12, "\uda43\udcdd\ud88b\ude4b\ud8ee\udcfc\udb3b\udf04\udb65\udc63\uda6d\udd25\udba9\udf8f\uda2e\udd56\ud971\udc52\udb7f\ude0f\udac3\uddb8\ud9e5\udf1c\udb2d\udf38\udadc\ude04\ud807\udfd5\ud87a\udec2\udb2b\udfb3\udb40\udf55\ud9c5\ude5e\ud91f\ude7c\udab9\udfaf\u8953\ud9b8\udda8\uda12\udfff\udbc4\udeab\uda64\udc9f\ud9ab\uddfb\udaa8\ude77", "\u6a39", "\ud8dd\udda2\uda1f\udd5b\uda22\udc17\uda87\ude82\ud852\udfbf",
        -1, 74555, 149910927, 7877378050660478533L, 77429L, false, false, (char) 9420, (char) 3739,
        Double.longBitsToDouble(0x3fda46562ae441d0L), Double.longBitsToDouble(0x3f8287ae31ce3240L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 11, 11, 6, "\uda43\udc9f\udaf4\udfdb\ud8f4\ude60\ud9d8\uddf6\ud8a6\udd45\ud886\udd12\udaf8\udd77\ud853\udccc\ueac8\udb7f\udee3\uda8e\udf3d\ud9fd\uddd7\ud8d7\udd85\ud88c\ude2f\uda44\udd07\ud916\udcf7\udb24\udd4c\udb16\udeda\ud9c5\ude5e\udaff\udd6c\u184b\uda0d\udd3a\ud809\udd14\udb23\ude5e\ud80a\udf45\udaf9\udd2b\ud9e6\udedb\udaa8\ude1a\uda0d\udd13\udb16\ude7a\ud805\uddd0", "\ua572\u49d8\ub9e7", "\ud90f\udc5b\ud802\ude54\u5b9b\ud9cd\udf11\ud98d\udc3e\ud8c3\ude93\uda75\udfec\udb6b\udd5c\ud9ca\udc7f\u2cd4\ud92c\ude16\u4a4a",
        15, 800, -1158026195, 1272788829710293359L, -95141L, true, false, (char) 17218, (char) 57587,
        Double.longBitsToDouble(0x3fddda598731da6cL), Double.longBitsToDouble(0x3fe9a8b13268528cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 12, 12, 11, "\u3dc4\udaf2\udc83\ud8f4\ude60\ud8e7\udc9a\ud8a6\udcf7\ud886\udd12\ud88d\udf7f\ud849\ude27\ud994\udcc5\udb7f\udee3\uda8e\udf3d\ud9fd\uddd7\ud8d7\udd85\udaf8\udc04\udbd6\udf5c\ud847\udd8b\udb63\udd5e\udb12\udd55\ud9c5\ude5e\udaff\udd6c", "\u15da\ub47e\u4274\u0679\u58ac\u2aac\ud554\u7d7b\u6a39\uba0b\u0867", "\uda22\udc17\uda62\udf08\ud852\udfbf\ud8f2\udc5b\ud802\ude54\u5b9b\ud9cd\udf11\ud9f4\udef2\ud9dc\uddb6\uda40\udd1e\udb6b\udd27\ud9ca\udc7f",
        46, 29717, -804002531, -2177360242823590851L, 40622L, false, true, (char) 6917, (char) 38499,
        Double.longBitsToDouble(0x3fe78afc5fc6637cL), Double.longBitsToDouble(0x3fb3bf294eed2cc0L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 13, 13, 11, "\uda43\udcdd\udaf2\udc7f\ud8f4\ude60\udb3b\udf04\udb65\udc63\uda6d\udd25\ud8a9\udfee\ud98f\udd27\ud994\udd75\udb7f\udee3\uda8e\udf3d\ud899\ude06\udb2d\udf38\udadc\ude04\uda44\udd94\ud803\ude23\udb2b\udfb3\udb12\udd55\ud9c5\ude5e\ue189", "\u9895\u5003\u5705\uafd7\ua65b\u2aac\u1fe9\000\000\000\u5bdf\ua5e8\u49d8\ub9e7\u0fc9\ua2c8\u8af1\u0951\u8768\uc956\u5601\u30b1\u69d6\u29b0\u8bbf\u08cc\u7d6b\u3c56\u59d5\u0fee\u78a9\ub9c9\u9bec\u343f\u4e91\uc4a9\u32dd\ub90c\ub631\ua187\u2f12\u3353\ud017", "\uda27\udd3d\ud9b4\udc77\u9508\ud8ba\ude14\u00ea",
        -5, -1000, 0, -1231651302969664249L, -35800L, false, false, (char) 45912, (char) 21133,
        Double.longBitsToDouble(0x3fc93ce667a3a220L), Double.longBitsToDouble(0x3fd263644773a194L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.stat.Frequency|addValue|char|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|int|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|java.lang.Comparable|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|java.lang.Integer|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|java.lang.Object|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|long|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|clear||new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCount|char|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCount|int|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCount|java.lang.Object|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCount|long|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCumFreq|char|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCumFreq|int|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCumFreq|java.lang.Object|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCumFreq|long|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCumPct|char|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|char|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|int|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|java.lang.Comparable|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|java.lang.Integer|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|java.lang.Object|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|long|new:org.apache.commons.math.stat.Frequency:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
