package org.apache.commons.math.geometry;
import org.junit.Test;
import static org.junit.Assert.*;
public class Vector3D_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 10, 6, "\udad2\udd2d\ud9c9\udd9e\ud94e\udef9\udad4\udee8\ud9c8\ude51\ud868\udc28\ud979\udcb1\udab6\udf32\ud8c5\udcb2\udac2\ude7d\udb8f\udf0b\ud9c3\udfe5\udb1e\uddaa\udb35\uddde\ue063", "\uc133\ucc20\uc7ad", "\ud882\udf67\ud93c\udcc9\ud89e\udfc2\uda4e\udf67\ud91c\udd85\ud9eb\udddf",
        28, 96573, 1460959792, 2706450024206519531L, 85332L, true, false, (char) 40801, (char) 22397,
        Double.longBitsToDouble(0x3fec27ea0478a12cL), Double.longBitsToDouble(0x3fdd827ffdb0ad6eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 10, 13, "\udad2\udd6f", "\ua6ba\u10b1\u351f\u443f\u71e1\u28f4\ub903\u5091\u7f73\u8c0e\u88c0", "\udbf3\udd57\udab9\udde0",
        16, 8399, 1305773934, 3170387130263351315L, 71335L, true, true, (char) 834, (char) 56621,
        Double.longBitsToDouble(0x3fd12ec8e0571dfeL), Double.longBitsToDouble(0x3fe1850567f55714L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 10, 6, "\udad2\udd2d\ud9c9\udd9e\ud94e\udef9\udad4\udee8\ud9c8\ude51\ud868\udc28\ud979\udcb1\udab6\udf32\ud85f\udc4a\udb2b\udc27\udb8f\udf0b\ud9c3\udfe5\udb1e\uddaa\udb35\uddde\ue063", "\uc133\ucc20\uc7ad\u22e2\u49ab\u01dd\ud4e4\u6d68\u8c74\uc72a\u3861\u77b8\u6677\u7534\u0a79\uab59\u5aea\uaa7f\u4c60", "\ud981\udced\ud993\uded3\ud8d1\udef4\ud92e\udfdb\udbb8\udda3\udb5a\udd6b\u99de\udb28\udc99\ud812\udfa4\udb8a\ude78\udb0a\ude11\ud80c\ude0d",
        44, 23488, 605253375, -3174883886205491246L, -13426L, false, true, (char) 15417, (char) 41125,
        Double.longBitsToDouble(0x3fdf4c215251263cL), Double.longBitsToDouble(0x3fddbdcd80f4d006L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 10, 6, "\udad2\udd2d\ud9c9\udd9e\ud94e\udef9\udad4\udee8\ud9c8\ude51\ud868\udc28\ud8ed\uddcc\udab6\udf32\ud8c5\udcb2\udac2\ude7d\ua839\000\udb1e\uddaa\udb35\uddde\ue063", "\uc133\ucc20\uc7ad", "\ud882\udf67\ud93c\udcc9\ud89e\udfc2\uda4e\udf67\ud91c\udd85\ud9eb\udddf",
        28, 96573, 1459649072, 2706450023549239296L, 85332L, true, false, (char) 40801, (char) 22397,
        Double.longBitsToDouble(0x3fc09fa811e00000L), Double.longBitsToDouble(0x3fdd827ffdb0ad6eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 10, 8, "\udae9\udea3\u3220\ud937\udec9\udbc7\udcb5\u994d\uda3d\ude63\ud979\udc51\udab6\udf32\ud8c5\udcb2\udb88\udd40\udb8f\udf0b\ud9c3\udfe5\udb1e\uddaa\udb35\uddde\ud821\udc33\udbcf\udddf\udb95\udc32\udab9\udde0\udbbc\udd95\uda13\udc38", "\u5aa7\ud4e4\u05ac\u5469\u2ff7\u3861\u77b8\u3749\u2965\u0a79\u1382\u5aea\ua257", "\uda19\udc95",
        34, 5872, 483809752, 4040938088370112989L, -9128L, false, false, (char) 10030, (char) 53152,
        Double.longBitsToDouble(0x3f370b28ce7d9000L), Double.longBitsToDouble(0x3fe1635e439407baL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 6, "\ud92f\udf95\ud9b3\uddef\ud94e\udef9\udad4\udee8\ud9ec\udce9\udb45\udcdd\ud979\udcb1\udb32\udd09\ud8c5\udcb8\udac2\ude7d\udb8f\udf0b\ud9c1\udfe5\uda31\udda7\udb35\uddca\udb54\ude47", "\uc133\ucc20\u879d\ub9a4\u49ab\u5a61\ud4e4\u05ac\u8cd5\uc72a\uc0d4\u77a8\u4f1f\u819d\u0a79\uab59\u5aea\uaa7f", "\uda12\udf95",
        34, 5872, 1454856664, 2784243643337727524L, 78530L, false, true, (char) 10024, (char) 58573,
        Double.longBitsToDouble(0x3fe69c7e10aad570L), Double.longBitsToDouble(0x3fcfcf5bb0e79c48L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 10, 6, "\udad2\udd2d\ud9c9\udd9e\ud94e\udef9\udad4\udee8\ud9c8\ude51\ud868\udc28\ud979\udcb1\udab6\udf32\ud8c5\udcb2\udac2\ude7d\udb8f\udf0b\ud9c3\udfe5\udb1e\uddaa\udb35\uddde\ue063", "\u26e6\ucc20\uc7a1", "\ud8a2\udfaf\udbc8\udc59\uda69\udeb4\u7ed0\ud8fd\ude9b\ud9eb\udddf",
        28, 96573, 1460959792, 2706450024206519531L, 85332L, true, false, (char) 40801, (char) 22397,
        Double.longBitsToDouble(0x3fec27ea0478a12cL), Double.longBitsToDouble(0x3fdd827ffdb0ad6eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.geometry.Vector3D|crossProduct|org.apache.commons.math.geometry.Vector3D,org.apache.commons.math.geometry.Vector3D|static",
    "M|org.apache.commons.math.geometry.Vector3D|add|double,org.apache.commons.math.geometry.Vector3D|new:org.apache.commons.math.geometry.Vector3D:double,org.apache.commons.math.geometry.Vector3D",
    "M|org.apache.commons.math.geometry.Vector3D|add|org.apache.commons.math.geometry.Vector3D|new:org.apache.commons.math.geometry.Vector3D:double,org.apache.commons.math.geometry.Vector3D",
    "M|org.apache.commons.math.geometry.Vector3D|angle|org.apache.commons.math.geometry.Vector3D,org.apache.commons.math.geometry.Vector3D|static",
    "M|org.apache.commons.math.geometry.Vector3D|distance|org.apache.commons.math.geometry.Vector3D,org.apache.commons.math.geometry.Vector3D|static",
    "M|org.apache.commons.math.geometry.Vector3D|distance1|org.apache.commons.math.geometry.Vector3D,org.apache.commons.math.geometry.Vector3D|static",
    "M|org.apache.commons.math.geometry.Vector3D|distanceInf|org.apache.commons.math.geometry.Vector3D,org.apache.commons.math.geometry.Vector3D|static",
    "M|org.apache.commons.math.geometry.Vector3D|distanceSq|org.apache.commons.math.geometry.Vector3D,org.apache.commons.math.geometry.Vector3D|static",
    "M|org.apache.commons.math.geometry.Vector3D|dotProduct|org.apache.commons.math.geometry.Vector3D,org.apache.commons.math.geometry.Vector3D|static",
    "M|org.apache.commons.math.geometry.Vector3D|equals|java.lang.Object|new:org.apache.commons.math.geometry.Vector3D:double,org.apache.commons.math.geometry.Vector3D",
    "M|org.apache.commons.math.geometry.Vector3D|getAlpha||new:org.apache.commons.math.geometry.Vector3D:double,org.apache.commons.math.geometry.Vector3D",
    "M|org.apache.commons.math.geometry.Vector3D|getDelta||new:org.apache.commons.math.geometry.Vector3D:double,org.apache.commons.math.geometry.Vector3D",
    "M|org.apache.commons.math.geometry.Vector3D|getNorm||new:org.apache.commons.math.geometry.Vector3D:double,org.apache.commons.math.geometry.Vector3D",
    "M|org.apache.commons.math.geometry.Vector3D|getNorm1||new:org.apache.commons.math.geometry.Vector3D:double,org.apache.commons.math.geometry.Vector3D",
    "M|org.apache.commons.math.geometry.Vector3D|getNormInf||new:org.apache.commons.math.geometry.Vector3D:double,org.apache.commons.math.geometry.Vector3D",
    "M|org.apache.commons.math.geometry.Vector3D|getNormSq||new:org.apache.commons.math.geometry.Vector3D:double,org.apache.commons.math.geometry.Vector3D",
    "M|org.apache.commons.math.geometry.Vector3D|crossProduct|org.apache.commons.math.geometry.Vector3D,org.apache.commons.math.geometry.Vector3D|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
