package org.apache.commons.math.optimization.linear;
import org.junit.Test;
import static org.junit.Assert.*;
public class SimplexTableau_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 3, 1, "\ud97d\udf6e\udbd1\udfe3\udb3d\udf2c\ud862\udf1a\udbf9\udf86\udad7\udf77\uda89\udea2\udab5\udebf\uda23\udcad\ud9df\uddff\ud9b6\udea1\udb43\udf60\ud90e\ude7f\ud985\udfa3\ud8df\udef2\ud9fb\udcc4\ud92d\udfa2\udb3d\udd4a\ud943\ude57\ud83f\udf77\uda2d\udd98", "\ua1f1\u16a5", "\udae6\ude81\udb5c\udd9e\udbac\uded8\udbf4\udcde\uda1b\udc75\uda6d\udd86\ud98e\udd19\uda8d\udfed\udb43\uddd4\ufe83\uda99\udde3\uda7f\udd88\udbc4\uddcc\udba5\udc6f\ud8da\udf00\u51f5\ud944\ude2f",
        16, 48162, -1709061432, 5019473278473356301L, -95314L, true, false, (char) 21574, (char) 48179,
        Double.longBitsToDouble(0x3fe0de78b7391b99L), Double.longBitsToDouble(0x3fe18bfdb86efb78L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 1, "\ud94a\ude53\udbd1\udfe3\udbd3\udcb6\uda6c\udc3c\udbf9\udf86\udad7\udf77\uda57\udda2\udab5\udebf\uda23\udcad\ud9df\uddff\ud9b6\udea1\udb43\udf60\ud90e\ude7f\ud9d3\udccb\ud8df\udef2\ud9fb\udcc4\ud92d\udfa2\udb3d\udd4a\udb95\ude60\ud83f\udf77\uda2d\udd98", "\ua1f1\u16a5", "\uda3d\ude23\udafe\udd8f\udbac\udfc4\udbf4\udcde\uda1b\udc75\uda6d\udd86\ud98e\udd19\uda8d\udfed\udb43\uddd4\ufe83\uda99\udde3\uda7f\udd88\udbc4\uddcc\udba5\udc6f\ud8da\udf00\u51f5\ud944\ude2f",
        16, 47042, -1697718978, 5019473278473356301L, -37202L, false, false, (char) 21574, (char) 48179,
        Double.longBitsToDouble(0x3fe0de78b7391b99L), Double.longBitsToDouble(0x3fe18bfdb86efb78L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 3, 1, "\ud97d\udf6e\udbd1\udfe3\udb3d\udf2c\ud862\udf1a\udbf9\udf86\udad7\udf77\uda89\udea2\udab5\udebf\uda23\udcad\ud9df\uddff\ud9b6\udea1\udb43\udf60\ud90e\ude7f\ud985\udfa3\ud8df\udef2\ud9fb\udcc4\uda0e\uddb1\ud8e9\udc2e\ud8f8\udd49\ud85a\udf7c\ud89b\udf8e", "\ubeac\u15ea", "\udae3\udcb5\udb5c\udd9e\udbac\uded8\udbf4\udcde\uda1b\udc75\uda6d\udd86\ud98e\udd19\uda8d\udfed\udb43\uddd4\udbcc\udd29\uda85\udf2b\uda7f\udd88\udbc4\uddcc\udba5\udc6f\ud8da\udf00\u51f5\ud944\ude2f",
        58, 48072, -1709061432, 5019473278464224013L, -95314L, true, false, (char) 21574, (char) 48179,
        Double.longBitsToDouble(0x3fe0de78b7391b99L), Double.longBitsToDouble(0x3fe18bfdb86efb78L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "\u008a\ud939\ude05\udb3d\ude6d\ud862\udf1a\udbf9\udf86\udad7\udf77\uda89\udea2\udab5\udebf\uda23\udcad\ud9df\uddff\ud9b6\ude76\udb43\udf60\ud90e\ude7f\ud985\udfa3\ud8df\udef2\ud9fb\udcc4\ud92d\udfa2\uda4d\uddd2\ud943\ude57\ud83f\udf77\uda2d\udd98", "\ua1f1", "\ud9d5\ude09\udae6\ude81\udb5c\udd9e",
        34, 10111, 2138000627, 8323275225235980404L, 58970L, true, true, (char) 26498, (char) 808,
        Double.longBitsToDouble(0x3fc0c7f1742237acL), Double.longBitsToDouble(0x3fed23ed5bd73905L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 4, 1, "\ud97d\udf6e\udbd1\udfe3\udb3d\udf2c\ud862\udf1a\udbf9\udf86\udad7\udf77\uda89\udea2\udab5\udebf\uda23\udcad\ud9df\uddff\ud9a9\udfc6\udbb6\ude40\ud90e\udd9b\udb6f\udd38\ud88b\udcb8\uda05\ude99\ud92d\udfa2\udb3d\udd4a\ud943\ude57\ud83f\udf77\uda2d\udd98", "\ua1f1\u16a5", "\udae6\ude81\udb5c\udd9e\udbac\uded8\udbf4\udcde\ud855\udcbc\ud85d\ude7b\ud98e\udd19\uda8d\udfed\udb43\uddd4\ufe83\uda99\udde3\udbd8\ude6c\udb98\uddb6\udba5\udc6f\ud8da\udf00\u51f5\ud944\ude2f",
        16, 54538, -1709061592, 4972571140706288653L, -95314L, true, false, (char) 21574, (char) 48179,
        Double.longBitsToDouble(0x3fe0de78b7391b99L), Double.longBitsToDouble(0x3fe18bfdb86efb78L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 1, "\ud8f5\udc69\udbd1\udfe3\udb3d\udf2c\ud862\udf1a\ud854\udd93\ud8ca\ude6d\ud9dd\uddd6\udab5\ude6c\ud860\uddac\ud897\udcbc\uda52\udf89\udb43\udf60\udaf7\udcbb\ud985\udfa3\ud9bf\udf41", "\u6346\u2047\u5151\u4d91\u9dbd\u58ca\u9208\u6d88\u9efb\ub909\ud798\ucef7\u2543\u2c9e\uc12d", "\uda8d\udfed\udb43\uddd4\ufe83\uda99\udde3",
        10, 15494, 1219750045, 4108742026481124188L, -51500L, true, false, (char) 46683, (char) 23163,
        Double.longBitsToDouble(0x3f8a8b51e6cebe00L), Double.longBitsToDouble(0x3fc3068c3c78d31cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 1, "\ud97d\udf6e\udbd1\udfe3\udb3d\udf2c\ud931\udd2d\ud800\ude9c\ud99b\ude04\uda89\udea2\uda3a\udec1\uda30\udc98\ud9df\uddff\ud9b6\udea1\udad8\ude8b\ud892\udedf\udba9\udfea\ud8df\udeb1\ud939\udc22\ud90f\ude3f\udb3d\udd4a\ud89f\udc06\ud83f\udf02\uda2d\udd98", "\u15b5\u8b2d\uc9be\u2c3c\u442d\u7b61\u2543\u402c\ub23d\ubfba\u5c0b\u65f6\u396b", "\uda7f\udd88\udbc4\uddcc\ud815\udc67\ud8da\udf00\u51f5\ud944\ude2f",
        15, 48162, -1709061432, 2101140719937274892L, 21607L, true, false, (char) 24585, (char) 22821,
        Double.longBitsToDouble(0x3fe0de78b7391b53L), Double.longBitsToDouble(0x3fe18bfdb86efb78L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 4, 1, "\ud939\udee0", "\u2e82", "\uda89\udea2\udab5\udebf",
        46, 51579, 985800491, -975187455005626377L, -71119L, true, false, (char) 52036, (char) 56641,
        Double.longBitsToDouble(0x3fefb7b89e846c43L), Double.longBitsToDouble(0x3f91885d50524680L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 2, "\ud97d\udf6e\udb84\udebb\ud877\uddc7\ud977\ude2d\u2cad\ud9bd\udf65", "\u1e46\u67e7\u04cf", "\ud985\udfa3\ud8df\udef2\ud9fb\udcc4\ud92d\udfa2\udb3d\udd4a\u85b7\ud891\uddaa\uda2d\uddeb\uda18\udf5b\udb7b\udd5c\ud8ab\udee6\udb7e\udf77\udb22\udc5e\ud9d5\ude6c\udae6\ude81\udb5c\udd9e\udbac\uded8\udbf4\udcde\uda1b\udc75\uda6d\udd86\ud98e\udd19",
        23, 33378, 805687017, 98724093562126794L, -54184L, false, true, (char) 40156, (char) 8452,
        Double.longBitsToDouble(0x3feda0a62c7a8256L), Double.longBitsToDouble(0x3fef6e9405157413L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 3, 1, "\ud97d\udf6e\udbd1\udfe3\udb3d\udf2c\ud862\udf1a\udbf9\udf86\udad7\udf77\uda89\udea2\udab5\udebf\uda23\udcad\ud9df\uddff\ud9b6\udea1\udb43\udf60\ud90e\ude7f\ud985\udfa3\ud8df\udef2\ud9fb\udcc4\ud92d\udfa2\udb3d\udd4a\ud943\ude57\ud83f\udf77\uda2d\udd98", "\ua1f1\u16a5", "\udae6\ude81\udb5c\udd9e\udbac\uded8\udbf4\udcde\uda1b\udc75\uda6d\udd86\ud98e\udd19\uda8d\udfed\udb43\uddd4\ufe83\uda99\udde3\uda7f\udd88\uda8b\udd1f\ud92d\udc5a\ud8da\udf00\u51f5\ud944\ude2f",
        16, 48162, -1709061432, 5019473278473356301L, -95314L, true, false, (char) 21574, (char) 48179,
        Double.longBitsToDouble(0x3fe0de78b7391b99L), Double.longBitsToDouble(0x3fe18bfdb86efb78L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getBasicRow|int|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|copyArray|[D,[D,int|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|createTableau|boolean|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|discardArtificialVariables||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|divideRow|int,double|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|equals|java.lang.Object|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getArtificialVariableOffset||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getConstraintTypeCounts|org.apache.commons.math.optimization.linear.Relationship|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getData||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getEntry|int,int|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getHeight||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getInvertedCoeffiecientSum|org.apache.commons.math.linear.RealVector|static",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getNormalizedConstraints||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getNumArtificialVariables||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getNumDecisionVariables||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getNumObjectiveFunctions||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getBasicRow|int|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
