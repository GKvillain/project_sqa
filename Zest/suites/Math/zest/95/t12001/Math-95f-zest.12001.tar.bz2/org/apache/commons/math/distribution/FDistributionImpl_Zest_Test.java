package org.apache.commons.math.distribution;
import org.junit.Test;
import static org.junit.Assert.*;
public class FDistributionImpl_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.FDistributionImpl:@?\012",
        Z.run(T, 1, 0, 6, 0, "\ud968\udf26\ud864\udd0a\ud96c\udead\ud98c\ude1b\udbcc\udc19\ud991\udc39", "\ua4b4", "\ud9e2\udf07\ud82e\udf45\ud819\udcbe",
        30, 83862, 1615684217, -6974103578238415879L, -84132L, true, true, (char) 25868, (char) 36512,
        Double.longBitsToDouble(0x3fd8ad59411e9814L), Double.longBitsToDouble(0x3f5c02d3a6630c00L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.FDistributionImpl:@?\012",
        Z.run(T, 1, 0, 6, 0, "\ud968\udf26\ud864\udc7b\ud96c\udead\ud98c\ude1b\udbcc\udc19\ud991\udc39", "\ua4b4", "\ud9e2\udf07\ud82e\udf45\ud819\udcbe",
        30, 83862, 1615684217, -6974103578238415879L, -84168L, true, true, (char) 25868, (char) 36512,
        Double.longBitsToDouble(0x3fd8ad59411e9814L), Double.longBitsToDouble(0x3f5c02d7a6630c00L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.FDistributionImpl:@?\012",
        Z.run(T, 1, 0, 6, 0, "\ud968\udf26\ud864\udd0a\ud96c\udead\ud98c\ude1b\udbcc\udc19\ud991\udc39", "\ua4b4", "\ud9e2\udf07\ud82e\udf45\udadf\udc81",
        39, 53518, 1510248738, -1353611242634521514L, 87390L, true, true, (char) 25868, (char) 36512,
        Double.longBitsToDouble(0x3fd542ccb11e9814L), Double.longBitsToDouble(0x3fa360169d331860L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.distribution.FDistributionImpl:@?\012",
        Z.run(T, 1, 7, 6, 9, "\uda26\udfef\udb66\udd0b\ud87d\udd39\ud956\udca1\ud8ff\udfc9\udb4a\udcea\ud8eb\udd20\ud871\ude07\ue43c\ua9e5\uda75\udfa4\u9309\ud82e\udf45", "\ub1af\u4cb4\u1f09\ub4f0", "\udbd4\udfc2\ud9da\udf3d\ud9fe\ude0f\udb63\udfd8\udb2b\udede\ud858\udeec\ud98b\udf7c",
        31, 23119, -1387485318, 8185493857100919555L, -23709L, false, true, (char) 40787, (char) 24818,
        Double.longBitsToDouble(0x3fce692f52c71b28L), Double.longBitsToDouble(0x3fd387c19779c428L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.distribution.FDistributionImpl:@?\012",
        Z.run(T, 1, 8, 6, 0, "\ud968\udf26\ud864\udd0a\udb65\udf6b\ud98c\ude47\ud9d2\ude16\ud991\udc39", "\ua4b4", "\ud9e2\udf07\ud9d2\udc63\ud819\udcbe",
        30, 83862, 1615684217, -6974103578238415879L, 36816L, true, true, (char) 4696, (char) 1463,
        Double.longBitsToDouble(0x3fd8ab894fc69814L), Double.longBitsToDouble(0x3f5c8c13a6630c00L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.FDistributionImpl:@?\0121=java.lang.Double:115.73165719778281 |this=org.apache.commons.math.distribution.FDistributionImpl:@?\012",
        Z.run(T, 2, 0, 6, 6, "\ud809\ude57\ud8ba\ude62\ud956\udc53\ud98c\ude1b\udbcc\udc19\ud991\udc39", "\ua4b4\u2839\uae73\u4410\u040a\uc7ef\u487f\u23df\ud131\ud4aa\u4ade\u2c92\u8d7a\ua979", "\ud87a\udc69\ud841\udcbe\ud938\udfbb\ud925\udd9d\ud806\udc18\ud94f\uddbd\ud8d3\udd1e\u12e6\udb41\udecb\udbd6\udc63\ud9ca\udef4\udb6b\udda1\udb33\udfd3\ud96e\udca8\udb02\udc24\ud8ac\udf90\uda42\udc0a\u59ce\ud83f\uddb7\u8036\udb81\udfe9\udbb2\udcb0\ud85a\udf59\ud908\udc88\ud843\udea2\udb79\ude65\uda46\udc73\udae4\udff2",
        50, 6582, 290786953, 8142247000337928986L, 29742L, false, false, (char) 19211, (char) 18556,
        Double.longBitsToDouble(0x3fe6062969697c8aL), Double.longBitsToDouble(0x3fd3cd5db0d3e00aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Double:0.43472202275777994 |this=org.apache.commons.math.distribution.FDistributionImpl:@?\012",
        Z.run(T, 1, 1, 1, 5, "\ud968\udf26\ud864\udd0a\ud96b\udfad\ud98c\ude1b\udbcc\udc19\ud991\udc39\ud91c\udecf\ud871\ude07", "\uae73\u5035\ub8f0\uc7ef\u6d4d\u3516\u4c9c", "\udb9a\udc0f\ud8cb\ude90\ud80f\uddb5\ud9da\udf25\u485a\uda04\ude05\udbd5\ude68\ud828\uddd0\udac9\ude5b\ud9ce\udfdc\uda7b\udc71\uda91\udd40\udbda\udf1b\ud9b0\udf89\ub746\udb9e\udf77",
        59, 85186, -1138032192, -515961160364182279L, -64952L, true, true, (char) 63568, (char) 63721,
        Double.longBitsToDouble(0x3fefc1618452d26bL), Double.longBitsToDouble(0x3fe44c55f374ddf7L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.FDistributionImpl:@?\012",
        Z.run(T, 1, 9, 1, 2, "\ud968\udf26\ud849\udf7e\ud96f\udeb7\udab8\ude59\ud815\udc40\udb59\ude21\ud91c\udecf\ud871\ude07\udb26\udff3\ua9e5", "\u035e", "\ud9f5\ude7a\udb74\udc25\udb5a\udfe5\udb83\udc68\ud909\ude7a\ud8cb\ude90\ud9d5\udcdc\udaaf\ude48\udb05\udca1\udab1\udfe2\uda72\udea4\udbc8\udd39\ud818\udf07\udbd3\udce0\ud8cd\udc7b\u0e42\ud87f\udd45\udac2\udca7\udb00\udd10\udb8c\udd7e\udaed\udd09\ud91b\ude98\ud8fe\udd37\ud94e\udce2",
        -1, 90922, 1145708056, 5526491730739181085L, 56625L, true, false, (char) 62755, (char) 40421,
        Double.longBitsToDouble(0x3fd8c31e6b352ab6L), Double.longBitsToDouble(0x3fceda2557e92c28L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:0.6054212962340034 |this=org.apache.commons.math.distribution.FDistributionImpl:@?\012",
        Z.run(T, 1, 1, 2, 4, "\ud968\udf26\ud86c\udd0a\ud989\udead\udaed\udeec\uda1b\udf6d\ud9ef\udea7", "\u0ed8", "\udb0b\udcb0\ud82e\udeef",
        7, 1089, -619954120, 6939338362083279295L, -94507L, true, true, (char) 36512, (char) 32542,
        Double.longBitsToDouble(0x3fc1e981440748fcL), Double.longBitsToDouble(0x3fd881672ab4a628L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.FDistributionImpl:@?\0121=java.lang.Double:1.5189262952472453 |this=org.apache.commons.math.distribution.FDistributionImpl:@?\012",
        Z.run(T, 2, 0, 6, 2, "\ud968\udf68\ud864\udd0a\ud96c\udead\ud98c\ude1b\udbcc\udc19\ud991\udc39", "\ua4b4\u8949\uae73\u3f79\u779c\u911a\u0ede\u2ebd\u7fce\u8441\u99a7", "\ud973\udd56\uda2e\udcf4\u4872\udb32\udf2e\ud841\udd1c\udba2\udc0c\udbaf\uddc4",
        22, 26563, -1524537725, 1971419160133996186L, -72723L, false, false, (char) 29839, (char) 51639,
        Double.longBitsToDouble(0x3fe2dfc345c6c69fL), Double.longBitsToDouble(0x3fe88d974eb0b3fdL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math.distribution.FDistributionImpl:@?\012",
        Z.run(T, 1, 6, 4, 0, "\ud968\udf26\ud864\udd0a\ud96c\udead\ud98c\ude1b\udbcc\udc19\ud991\udc39", "\ua4b4", "\udb7b\udd53\ud9c7\udf66\ud8b3\udcae",
        2, 70509, 1615684217, -6974103577953072135L, 74639L, false, false, (char) 32542, (char) 25753,
        Double.longBitsToDouble(0x3f5c02d604630c00L), Double.longBitsToDouble(0x3fdd4ad152587cf2L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Double:4917.647144725486 |this=org.apache.commons.math.distribution.FDistributionImpl:@?\012",
        Z.run(T, 1, 6, 2, 2, "\udb4f\udc14", "\u9d16\ucd2b\u13c7\u33c0\u6a53\ua4b4\u2839\uae73", "\ud819\udcbe\udb44\udeba\ud9f5\uddf8\udb74\udc25\udb57\udc0a\ud83c\udf85\udb7f\udf57\ud8cb\ude90\ud9d5\udcdc",
        30, 44202, -1758517727, -1421370830284385308L, 78436L, false, false, (char) 17483, (char) 14675,
        Double.longBitsToDouble(0x3fe9fc45125ba452L), Double.longBitsToDouble(0x3fd342b95792c55cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Double:0.8981088949061183 |this=org.apache.commons.math.distribution.FDistributionImpl:@?\012",
        Z.run(T, 1, 1, 5, 0, "\ud8ae\udd3e\u55a9\ud904\udc4d", "\uce2e\u1e5c\u32ff\ua4b4\u2839\uae73\ubd1d\u03f1\uc7ef\u1d29\u345a\u4c9c\u1f09\u4ade\u2272\u9070\ua979\ub77a\u6afc\u03aa\u06db\ud7bb\ud09f\u9a1f\u86f9\u7abb\u522c\u88b8\u1dc9\u29c4\u1621\ud510\u7b05\u6853\u535c\u166b\ua133\ubbcd\u8c78\u6d53\u7f77\u2017\uc161", "\ud8fa\udc86\udac8\udc35\udb2e\udf9e\ud834\udea8\ud842\udca2\udbe0\uddd1\uda7d\uddb0\ud835\udc0a\ud85a\uddec\ubf21\udbee\udf3d\uda8e\udfa2\ud8e5\udcb4\ud916\udcf0\udba1\udf66\u81ac\ud88d\ude09\udbe6\udcc0\udad3\udf97",
        37, 51895, -110099022, -3011541461930306497L, 96632L, false, true, (char) 18003, (char) 40002,
        Double.longBitsToDouble(0x3f95b8f19bb86560L), Double.longBitsToDouble(0x3fe2b85d98f75c0dL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 4, 0, "\uda6a\udfd4\ud864\udd0a\u8bea", "5", "\ue43c",
        -3, 37396, 905969664, 1000931386L, 96608L, true, false, (char) 3419, (char) 12,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe6d218018a0094L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:0.7187550748098813 |this=org.apache.commons.math.distribution.FDistributionImpl:@?\012",
        Z.run(T, 1, 2, 6, 4, "\ud968\udf26\ud864\udd0a\udb82\udf79\udb18\udf9a\udad2\udd1b\udb6b\udf66", "\ucec9\u013a\u59d7\u501a\uaf8e\u3bb9\u032f\u4e9a\u1127\u4359\u3944\u4f47\u2be1\ua979", "\ud8a3\ude05\ud841\udccc\ud883\udfd6\ud9d8\udcc4\udb92\udffe\udb58\udf4f\uefed\ud85b\ude07\udb69\ude62\udaec\udc3e\ud960\uddae\uda63\udde2\udb28\udcfa\ud83c\ude35\ud970\udc33\udbc9\ude7d\udb36\udfd4\udb4d\udd4a\ud830\udd18\uda4f\ude08\ud929\udd3b\udaab\udfbb\ud887\udd9e\udb13\udd8b\ud8ca\udddd\ud82a\udf8f\uda33\udd28\udbad\ude13",
        51, 83064, 2138956293, -4093683617565293031L, -68427L, false, false, (char) 61223, (char) 53627,
        Double.longBitsToDouble(0x3fe6cd3409ba4c8cL), Double.longBitsToDouble(0x3fe7000aa4848f25L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.distribution.FDistributionImpl|getInitialDomain|double|new:org.apache.commons.math.distribution.FDistributionImpl:double,double",
    "M|org.apache.commons.math.distribution.FDistributionImpl|cumulativeProbability|double|new:org.apache.commons.math.distribution.FDistributionImpl:double,double",
    "M|org.apache.commons.math.distribution.FDistributionImpl|getDenominatorDegreesOfFreedom||new:org.apache.commons.math.distribution.FDistributionImpl:double,double",
    "M|org.apache.commons.math.distribution.FDistributionImpl|getDomainLowerBound|double|new:org.apache.commons.math.distribution.FDistributionImpl:double,double",
    "M|org.apache.commons.math.distribution.FDistributionImpl|getDomainUpperBound|double|new:org.apache.commons.math.distribution.FDistributionImpl:double,double",
    "M|org.apache.commons.math.distribution.FDistributionImpl|getNumeratorDegreesOfFreedom||new:org.apache.commons.math.distribution.FDistributionImpl:double,double",
    "M|org.apache.commons.math.distribution.FDistributionImpl|inverseCumulativeProbability|double|new:org.apache.commons.math.distribution.FDistributionImpl:double,double",
    "M|org.apache.commons.math.distribution.FDistributionImpl|setDenominatorDegreesOfFreedom|double|new:org.apache.commons.math.distribution.FDistributionImpl:double,double",
    "M|org.apache.commons.math.distribution.FDistributionImpl|setNumeratorDegreesOfFreedom|double|new:org.apache.commons.math.distribution.FDistributionImpl:double,double",
    "C|org.apache.commons.math.distribution.FDistributionImpl|<init>|double,double",
    "M|org.apache.commons.math.distribution.FDistributionImpl|getInitialDomain|double|new:org.apache.commons.math.distribution.FDistributionImpl:double,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
