package org.apache.commons.math.stat.clustering;
import org.junit.Test;
import static org.junit.Assert.*;
public class KMeansPlusPlusClusterer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 4, 8, 1, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e\uda32\uddb7\udab3\udfe0\ud805\udfff\udaf1\udd42\udb45\udfbc\ud936\udd56\udbd0\udd3f\uda57\udcf9\udbca\udca6\ud85c\udfc3", "\u630d\u4a8e\ua13f\u1ad5\u3063\ucc89\u0ded\uad26\u78cb\ua3d7\uab9b\u54b8\u814a", "\udbc0\udd90\ud8dc\udc95\udb0c\udde3\udb8c\udc64\ud98f\udf88\ud95c\udcd6\udbb8\udd55\udae5\ude52\udba1\udd47\ud8f1\uddfa\ud9f2\ude61\ud9a4\udc1b\uda71\uddea\ud88f\udfa4\uda83\udce0\ud867\ude7b\ud8ea\udd71\ud9cf\udc1f\ud852\ude76\udaff\udd06\ud96e\uddd3\uf272\ud9ac\udc1f\ud84f\udeca\udbcf\udee0\ud8d3\ude85\ud871\udca2\udb06\udd84\ud910\ude82\ud816\uded2\ud94b\ude9a\ud8bc\udd61\ud9f8\udfd5\ud92e\udd4f\uda13\udd66\ud86e\udc16\ud927\udf44\udb9e\udea9\ud960\udf35\udb63\uddae\uda09\ude03\udba4\ude1a\ud9e2\udc91\ud803\udf4c\udaee\udf53\uda2f\udd32",
        5, 85470, -1206774546, -1691727179462410152L, -60724L, true, false, (char) 44686, (char) 47747,
        Double.longBitsToDouble(0x3fdd9949f845da5eL), Double.longBitsToDouble(0x3fe82e088f8ba661L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 4, 8, 1, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e\uda32\uddb7\udab3\udfe0\ud805\udfff\udaf1\udd42\udb45\udfbc\ud936\udd56\udbd0\udd3f\uda57\udcf9\udbca\udca6\ud85c\udfc3", "\u630d\u4a8e\ua13f\u1ad5\u3063\ucc89\u0ded\uad26\u78cb\ua3d7\uab9b\uc1c0\u401e", "\udbc0\udd90\ud8dc\udc95\udb0c\udde3\udb8c\udc64\ud98f\udf88\ud95c\udcd6\udbb8\udd55\udae5\ude52\udba1\udd47\ud8f1\uddfa\ud9f2\ude61\ud9a4\udc1b\uda71\uddea\ud88f\udfa4\uda83\udce0\ud867\ude7b\ud8ea\udd71\ud9cf\udc1f\ud852\ude76\udaff\udd06\ud96e\uddd3\uf272\ud9ac\udc1f\ud84f\udeca\udbcf\udee0\ud8d3\ude85\ud871\udca2\udb06\udd84\ud910\ude82\ud816\uded2\ud94b\ude9a\ud8bc\udd61\ud9f8\udfd5\ud92e\udd4f\uda13\udd66\ud86e\udc16\ud927\udf44\udb9e\udea9\ud960\udf35\udb63\uddae\uda09\ude03\udba4\ude1a\ud9e2\udc91\ud803\udf4c\udaee\udf53\uda2f\udd32",
        5, 85470, -1206774546, -1691727179462410152L, -60724L, true, false, (char) 44686, (char) 47747,
        Double.longBitsToDouble(0x3fdd9949f845da5eL), Double.longBitsToDouble(0x3fe82e088f8ba661L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 0, 8, 1, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e\uda32\uddb7\udab3\udfe0\ud805\udfff\udaf1\udd42\udb45\udfbc\ud95d\udd0b\uad07\uda57\udcf9\udbca\udca6\ud85c\udfc3", "\u630d\u4a8e\ua13f\u1ad5\u3063\ucc89\u0ded\uad26\u78cb\ua3d7\uab9b\u54b8\u814a", "\udbc0\udd90\ud8dc\udc95\udb0c\udde3\udb8c\udc64\ud98f\udf88\ud95c\udcd6\udbb8\udd55\udae5\ude52\udba1\udd47\ud8f1\uddfa\ud9f2\ude61\ud9a4\udc1b\uda71\uddea\ud88f\udfa4\uda83\udce0\ud867\ude7b\ud8ea\udd71\ud9cf\udc1f\ud852\ude76\udaff\udd06\ud96e\uddd3\uf272\ud9ac\udc1f\ud84f\udeca\udbcf\udee0\ud8d3\ude85\ud871\udca2\udb06\udd84\ud910\ude82\ud816\uded2\ud94b\ude9a\ud8bc\udd61\ud9f8\udfd5\ud92e\udd4f\udb11\udf69\ud86e\udc16\ud927\udf44\udb9e\udea9\ud960\udf35\udb63\uddae\uda09\ude03\udba4\ude1a\ud9e2\udc91\ud803\udf4c\udaee\udf53\uda2f\udd32",
        5, 85470, -1206774546, -1691727179462410152L, -60724L, true, false, (char) 44686, (char) 47747,
        Double.longBitsToDouble(0x3fdd9949f845da5eL), Double.longBitsToDouble(0x3fe82e088b8ba661L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 3, 6, 1, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e\uda32\uddb7\udab3\udfe0\ud805\udfff\udaf1\udd42\ud98f\ude2a\ud99e\udd90\udbd0\udd90\uda57\udcf9\udbca\udca6\ud85c\udfc3", "\u630d\u4a8e\ua13f\u1ad5\u3063\ucc89\u0ded\uad26\u78cb\ua3d7\uab9b\u54b8\u814a", "\udbc0\udd90\ud8dc\udc95\udb0c\udde3\udb8c\udc64\ud98f\udf88\ud95c\udcd6\udbb8\udd55\udae5\ude52\udba1\udd47\ud8f1\uddfa\ud9f2\ude61\ud9a4\udc1b\uda71\uddea\ud88f\udfa4\uda83\udce0\ud867\ude7b\ud8ea\udd71\ud9cf\udc1f\ud852\ude76\udaff\udd06\ud96e\uddd3\uf272\ud9ac\udc1f\ud84f\udeca\udbcf\udee0\ud8d3\ude85\ud871\udca2\udb06\udd84\ud910\ude82\ud816\uded2\ud94b\ude9a\ud8bc\udd61\ud9f8\udfd5\ud92e\udd4f\uda13\udd66\ud86e\udc16\ud927\udf44\udb9e\udea9\ud960\udf35\udb63\uddae\uda09\ude03\udba4\ude1a\ud9e2\udc91\ud803\udf4c\udaee\udf53\uda2f\udd32",
        5, 85470, -1206774546, -1691727179462410152L, -60724L, true, false, (char) 44686, (char) 47747,
        Double.longBitsToDouble(0x3fdd9949f845da5eL), Double.longBitsToDouble(0x3fe82e088f8ba661L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:@?\012",
        Z.run(T, 1, 8, 8, 1, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e\uda32\uddb7\udab3\udfe0\ud805\udfff\ud873\udd43\udb45\udfbc\ud936\udd56\udbd0\udd3f\uda57\udcf9\udbca\udca6\ud85c\udfc3", "\u630d\u4a8e\ua13f\u1ad5\u3063\ucc89\u0ded\uad26\u78cb\ua3d7\uab9b\u54b8\u814a", "\udbc0\udd90\ud8dc\udc95\udb0c\udde3\udb8c\udc64\ud98f\udf88\ud95c\udcd6\udbb8\udd55\udae5\ude52\udba1\udd47\ud8f1\uddfa\ud9f2\ude61\ud9a4\udc1b\uda71\uddea\ud88f\udfa4\uda83\udce0\ud867\ude7b\ud8ea\udd71\ud9cf\udc1f\ud852\ude76\udaff\udd06\ud96e\uddd3\uf272\ud9ac\udc1f\ud84f\udeca\udbcf\udee0\ud8d3\ude85\ud871\udca2\udb06\udd84\ud910\ude82\ud816\uded2\ud94b\ude9a\ud8bc\udd61\ud9f8\udfd5\ud92e\udd4f\uda13\udd66\ud86e\udc16\ud927\udf44\udb9e\udea9\ud960\udf35\udb63\uddae\uda09\ude03\udba4\ude1a\ud9e2\udc91\ud803\udf4c\udaee\udf53\uda2f\udd32",
        5, 85470, -1206774546, -1691727179462410152L, -60724L, true, false, (char) 44686, (char) 40713,
        Double.longBitsToDouble(0x3fd232f23845da5eL), Double.longBitsToDouble(0x3fe82e088f8ba661L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 4, 8, 8, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e\uda32\uddb7\udab3\udfe0\ud805\udfff\udaf1\udd42\udb45\udfbc\ud936\udd56\udb5b\uddc5\udbe0\udc7a\udadd\udcf6\uda6a\udf03", "\u630d\u4a8e\ua13f\u1ad5\u3063\ucc89\u0ded\uad26", "\ud8ca\udd89\ud9e1\ude35\ud84e\ude0f\ud9c4\udd9b\ud878\udc2d\udbc0\udd90\ud8dc\udc95\uda12\udfc6\udb6e\udf01\ud98f\udf88\udbea\udf1e\udbb8\udd57\udae5\ude52",
        25, 66516, 1261653491, 7892524979838090306L, -76120L, true, false, (char) 14755, (char) 47267,
        Double.longBitsToDouble(0x3fe173c257e73ddeL), Double.longBitsToDouble(0x3fe4751b3fb4d6bcL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 5, 4, 1, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e\udabb\udf9b\u6361\uda54\udc0e\udaf1\udd42\udb45\udfbc\ud936\udd56\udbd0\udd3f\uda57\udcf9\udbca\udca6\ud85c\udfc3", "\u6aee\u4a8e\ua13f\u1ad5", "\udbc3\udfbe\udb3d\udde8\uda50\uddc9\ud953\uded8\ud88a\udce3\udad0\ude9d\ud84e\ude0f\ud9c4\udd9b\ud878\udc2d\udbc0\udd90",
        52, 86449, -357090906, 8250656953426206805L, 15512L, true, false, (char) 8922, (char) 42488,
        Double.longBitsToDouble(0x3fd272f9c879d744L), Double.longBitsToDouble(0x3fe120e12ffc1977L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 2, 8, 1, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e", "\u1c16\ub9c6\u35e1\u8f17\u1f30\u5309\u265c\ubfc6\u5c60\ubb4c\u630d\u4a8e\ua13f", "\ud946\udc37\udbc3\udfbe\ud831\udf7a\udad9\udf06\ud953\uded8\ud89f\udce3\ud9ad\udf8b\ud84e\ude0f\ud9c4\udd9b\ud878\udc2d\udbc0\udd90\ud8dc\udc95\udb0c\udde3\udb8c\udc64\ud98f\udf88\ud95c\udcd6",
        30, 28688, 354651145, -6083638570880916359L, -74971L, false, false, (char) 371, (char) 40042,
        Double.longBitsToDouble(0x3fd485aafd277db8L), Double.longBitsToDouble(0x3fe9deb33df07ab3L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 6, 8, 1, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e\uda32\uddb7\udab3\udfe0\ud805\udfff\udaf1\udd42\udb45\udfbc\ud936\udd56\udbd0\udd3f\uda57\udcf9\udbca\udca6\ud85c\udfc3", "\u630d\u4a8e\ua13f\u1ad5\u3063\ucc89\u0ded\uad26\u78cb\ua3d7\uab9b\u54b8\u814a", "\udbc0\udd90\ud8dc\udc95\udb0c\udde3\udb8c\udc64\ud98f\udf88\udac2\ude29\ud8b5\udc90\udae8\udc92\udba1\udd47\ud8f1\uddfa\ud9f2\ude61\ud9a4\udc1b\uda71\uddea\ud88f\udfa4\uda83\udce0\ud867\ude7b\ud8ea\udd71\ud9cf\udc1f\ud852\ude76\udaff\udd06\ud96e\uddd3\uf272\ud9ac\udc1f\ud84f\udeca\udbcf\udee0\ud8d3\ude85\ud871\udca2\udb06\udd84\ud910\ude82\ud816\uded2\ud94b\ude9a\ud8bc\udd61\ud9f8\udfd5\ud92e\udd4f\uda13\udd66\ud86e\udc16\ud927\udf44\udb9e\udea9\ud960\udf35\udb63\uddae\uda09\ude03\udba4\ude1a\ud9e2\udc91\ud803\udf4c\udaee\udf53\uda2f\udd32",
        5, 85470, -1206774546, -1691727179462410152L, -60724L, false, false, (char) 40188, (char) 47747,
        Double.longBitsToDouble(0x3fdd9949f845da5eL), Double.longBitsToDouble(0x3fe82e088f8ba661L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:@?\012",
        Z.run(T, 1, 7, 8, 1, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e\uda32\uddb7\udab3\udfe0\ud805\udfff\udaf1\udd42\udb45\udfbc\ud936\udd56\udbd0\udd3f\uda59\ude88\udbca\udca6\ud85c\udfc3", "\u630d\u4a8e\ua13f\u1ad5\u3063\ucc89\u0ded\uad26\u78cb\ua3d7\uab9b\u54b8\u814a", "\udbc0\udd90\ud8dc\udc95\udb0c\udde3\udb8c\udc64\ud98f\udf88\ud95c\udcd6\udbb8\udd55\udae5\ude52\udba1\udd47\ud8f1\uddfa\ud9f2\ude61\ud9a4\udc1b\uda71\uddea\ud88f\udfa4\uda83\udce0\ud867\ude7b\ud8ea\udd71\ud9cf\udc1f\ud852\ude76\udaff\udd06\ud96e\uddd3\uf272\ud9ac\udc1f\ud84f\udeca\udbcf\udee0\ud8d3\ude85\ud871\udca2\udb06\udd84\ud910\ude82\ud816\uded2\ud94b\ude9a\ud8bc\udd61\ud9f8\udfd5\ud92e\udd4f\uda13\udd66\ud86e\udc16\ud927\udf44\udb9e\udea9\ud960\udf35\udb63\uddae\uda09\ude03\udba4\ude1a\ud9e2\udc91\ud803\udf4c\udaee\udf53\uda2f\udd32",
        5, 85470, -1206774546, -1691727179462410152L, -60724L, true, false, (char) 44686, (char) 47747,
        Double.longBitsToDouble(0x3fdd9949f845da5eL), Double.longBitsToDouble(0x3fe82e088f8ba661L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 1, 1, 5, "\uda67\udfa0\udb00\udf6d\udb7e\udf06\udad0\udf6e\uda5d\udeac\uda86\udd0a\ud843\udce8\udaf1\udd42\udb45\udfbc\ud936\udd56\udbd0\udd3f\uda57\udcf9\udbca\udca6\ud85c\udfc3", "\u630d\u4a8e\ua13f\u1ad5\u3063\ucc89\u0ded\uad26\u78cb\ua3d7\uab9b\u54b8\u814a", "\ud808\udd94\ud8dc\udc95\udb0c\udde3\udb8c\udc64\ud98f\udf88\ud95c\udcd6\udbb8\udd55\udafb\udfbd\udab2\udfe9\ud8f1\uddfa\ud9f2\ude61\ud9a4\udc1b\uda71\uddea\ud88f\udfa4\uda83\udce0\ud867\ude7b\ud8ea\udd71\ud9cf\udc1f\ud852\ude76\udaff\udd06\ud96e\uddd3\uf272\ud9ac\udc1f\ud84f\udeca\uda14\udcc3\ud8d3\ude85\ud871\udca2\udb06\udd84\ud910\ude82\ud816\uded2\ud94b\ude9a\ud8bc\udd61\ud9f8\udfd5\ud92e\udd4f\uda13\udd66\ud86e\udc0f\ud927\udf44\ud849\udc7e\ud960\udfdc\udb63\uddae\uda09\ude03\udba4\ude1a\ud9e2\udc91\ud803\udf4c\ud8fe\udc3a\udb24\udc4b",
        5, 85470, -579529490, 6322596256304926405L, -60724L, true, false, (char) 44686, (char) 47747,
        Double.longBitsToDouble(0x3fdd9949f845da5eL), Double.longBitsToDouble(0x3fe82e088f8ba661L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 4, 7, "\udaaf\udddc", "\u6906", "\ud805\udfff\udaf1\udd42\udb45\udfbc\ud95d\udd0b\uad07\uda57\udcf9\udbca\udca6\ud85c\udfc3\ud9c1\ude82\udba9\ude94\ud9b2\udd5b\ud95c\ude68\ud9a3\ude80",
        37, 61243, 1714102649, -7140034123664346418L, 44056L, true, true, (char) 9261, (char) 57860,
        Double.longBitsToDouble(0x3fd372c65a89ffeeL), Double.longBitsToDouble(0x3fe0854d2485b3b3L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 6, 1, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udba8\udc09\uda32\uddb7\udab3\udfe0\ud805\udfff\udaf1\udd42\udb45\udfbc\udb50\udd0f\uad07\uda57\udcf9\uda17\udea6\ud85d\udc5e", "\u630d\u4a8e\ua13f\u1ad5\u3063\u5df6\u50c2\uad26\u78cb\u2dcf\uab9b\u212a\u5553", "\udbc0\udd90\ud8dc\udc95\udb0c\udde3\ud955\udf8a\uda15\udfb1\ud966\ude10\udae4\ude0d\ud90e\ude7c\udba1\udd47\ud8f1\uddfa\ud939\udfa6\udb3f\udc0f\uda85\udda3\ud88f\udfa4\udbbb\udd7c\ud843\udf41\ud8ea\udd71\ud9d5\ude1f\ud852\ude76\ud852\udf11\ud96e\uddd3\uf272\ud9ac\udc1f\ud98f\udcec\ud81f\udc99\uda49\udc3e\ud8ad\udc44\uda50\ude0c\ud8f3\udeec\ud816\udfac\ud94b\ude9a\ud8bc\udd61\ud9f8\udfd5\ud92e\udd4f\udbf9\udd6e\ud884\udf27\ud927\udf44\ud856\udea6\ud95d\udc7a\udb63\uddae\uda09\ude03\udba4\ude1a\ud9cd\udc91\ud803\udf4c\udaee\udf53\uda2f\udd32",
        5, 85470, -1206774546, -1691727178841653160L, -60724L, true, false, (char) 11090, (char) 47585,
        Double.longBitsToDouble(0x3fdd9949f845da5eL), Double.longBitsToDouble(0x3fe82e088b8ba661L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:@?\012",
        Z.run(T, 1, 7, 6, 1, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e\uda32\uddb7\udab3\udfe0\uda44\udcbf\udaf1\udc77\ud869\udef2\udae1\udd34\udb6e\ude9b\uda72\udc4a\udbca\udca6\ud85c\udfc3\ue07b", "\u4a8e\ua13f\uc10c\u1b15\u5b5f\u89ba\u81c0\u78ea\ua3d7\u643b\ub3a7\u111d\ub3f1\u1eea\u79aa\u1e3e\u9875\u106c\u087e\ud27e\uc2b5\uabca\uad16\u9dc9\u23d5\u0b78\u7b3e\u8452", "\ud8ea\udd71\udbf9\uddf3\ud852\ude76\udaff\udd06\ud96e\uddd3\uf272\ud9ac\udc1f\udb08\udd9f\udbb6\udff8\ud8d3\ude85\ud871\udca2\udb06\udd84\ud910\ude82\ud816\uded2\ud94b\ude9a\uda4f\udf2b\ud953\udca9",
        51, 16685, 714120596, 7528981855828582463L, -50379L, false, true, (char) 39552, (char) 12263,
        Double.longBitsToDouble(0x3fcc0c9e0384a464L), Double.longBitsToDouble(0x3feb550e5f3f6223L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 0, 1, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e\ud871\uddc4\udab3\udfe0\ud805\udfff\udaf1\udd42\ud98f\ude2a\ud99e\udd90\udbd0\udd90\uda57\udcf9\udbca\udca6\ud85c\udfc3", "\u630d\u4a8e\ua13f\u1ad5\u3063\ucc89\u0ded\uad26", "\ud88a\udce3\ud9ad\udf8b\ud84e\ude0f\ud9c4\udd9b\ud878\udc2d\udbc0\udd90\ud8dc\udc95\udb0c\udde3\udb8c\udc64\ud98f\udf88\ud95c\udcd6\udbb8\udd55\udae5\ude52",
        25, 66516, 1261653491, 7892524979838090306L, -76120L, true, false, (char) 14755, (char) 47267,
        Double.longBitsToDouble(0x3fe173c257e73ddeL), Double.longBitsToDouble(0x3fe4751b3fb4d6bcL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 5, 3, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e\ud8e4\ude6f\udab3\udfe0\ud9a8\udeea\ud8af\udd9e\udb45\udfbc\udb1f\udeeb\ud81b\uded7\udaa5\udd75\u9005\udb8f\udc35", "\u630d\u4a8e\ua13f\u1ad5\u3063\u2d8a\u0ded\ua626\u78cb\u2bd7\u33e7\u54b8\u814a", "\udbc0\udd90\ud8dc\udc95\udb0c\udde3\udbb2\udef8\udb84\ude68\ud95c\udcd6",
        18, 28688, 354651145, -6083638570891487245L, -76120L, true, false, (char) 14755, (char) 10878,
        Double.longBitsToDouble(0x3fe3157086f746deL), Double.longBitsToDouble(0x3fe48d1617b4d6a4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 1, 4, "\ud865\udf5e\udaf3\udc6f\udb7e\udf06\udad0\udf6e\uda32\uddb7\udab3\udfe0\ud805\udfff\ud873\udd43\udb45\udfbc\ud936\udd56\udbd0\udd3f\uda57\udcf9\udbca\udca6\ud85c\udfc3", "\u630d\u4a8e\ua13f\u1ad5\u3063\ucc89\u0ded\uad26\u78cb\ua3d7\uab9b\u54b8\u814a", "\udbc0\udd90\ud8dc\udc95\udb0c\udde3\udb8c\udc64\ud98f\udf88\ud95c\udcd6\udbb8\udd55\udae5\ude52\udba1\udd47\ud8f1\uddfa\ud9f2\ude61\ud9a4\udc1b\uda71\uddea\ud88f\udfa4\uda83\udce0\ud867\ude7b\ud8ea\udd71\ud9cf\udc1f\ud852\ude76\udaff\udd06\ud96e\uddd3\uf272\ud9ac\udc1f\ud84f\udeca\udbcf\udee0\ud8d3\ude85\ud871\udca2\udb06\udd84\ud910\ude82\ud816\uded2\ud94b\ude9a\ud8bc\udd61\ud9f8\udfd5\ud92e\udd4f\uda13\udd66\ud86e\udc16\ud927\udf44\udb9e\udea9\ud960\udf35\udb63\uddae\uda09\ude03\udba4\ude1a\ud9e2\udc91\ud803\udf4c\udaee\udf53\uda2f\udd32",
        5, 85470, -1206774546, -1691727179462410152L, -60724L, true, false, (char) 44686, (char) 40713,
        Double.longBitsToDouble(0x3fd232f23845da5eL), Double.longBitsToDouble(0x3fe82e088f8ba661L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:@?\0121=new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:@?\012",
        Z.run(T, 2, 8, 8, 1, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e\uda32\uddb7\udab3\udfe0\ud805\udfff\ud873\udd43\udb45\udfbc\ud936\udd56\udb1d\udfc6\uda57\udcf9\udbca\udca6\ud85c\udfc3", "\u630d\u4a8e\ua13f\u1ad5\u3063\ucc89\u0ded\uad26\u78cb\ua3d7\uab9b\u54b8\u814a", "\udbc0\udd90\ud8dc\udc95\udb0c\udde3\udb8c\udc64\ud98f\udf88\ud95c\udcd6\udbb8\udd55\udae5\ude52\udba1\udd47\ud8f1\uddfa\ud9f2\ude61\ud9a4\udc1b\uda71\uddea\ud88f\udfa4\uda83\udce0\ud867\ude7b\ud8ea\udd71\ud9cf\udc1f\ud852\ude76\udaff\udd06\ud96e\uddd3\uf272\ud9ac\udc1f\ud84f\udeca\udbcf\udee0\ud8d3\ude85\ud871\udca2\udb06\udd84\ud910\ude82\ud816\uded2\ud94b\ude9a\ud8bc\udd61\ud9f8\udfd5\ud92e\udd4f\uda13\udd66\ud86e\udc16\udb8b\udd16\ud987\udfd6\ud960\udf35\udb63\uddae\uda09\ude03\udba4\ude1a\ud9e2\udc91\ud803\udf4c\udaee\udf53\uda2f\udd32",
        5, 85470, -1206774546, -1691727179462410152L, -60724L, true, false, (char) 44686, (char) 40713,
        Double.longBitsToDouble(0x3fd232f23845da5eL), Double.longBitsToDouble(0x3fe82e088f8ba617L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 0, 8, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e\uda32\uddb7\udab3\udfe0\ud805\udfff\ud873\udd43\udac8\udea8\ud932\ude3a\udbd0\udd3f\uda57\udcf9\udbca\udca6\ud8a7\udcda", "\u630d", "\ud9ba\udcd3\udb67\udca4\udb10\udc3c\ud9e7\udc50",
        18, 49698, -1832268472, 8875198078669362264L, -99504L, true, false, (char) 55779, (char) 36253,
        Double.longBitsToDouble(0x3fc93d56e155ca00L), Double.longBitsToDouble(0x3fe428449cc8ebe9L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:@?\0121=new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:@?\012",
        Z.run(T, 2, 8, 8, 8, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e\uda32\uddb7\udab3\udfe0\ud805\udfff\udaf1\udd42\udb45\udfbc\ud936\udd56\udb5b\uddc5\udbe0\udc7a\udadd\udcf6\uda6a\udf03", "\u0c40\u4a8e\ua13f\u1ad5\u3063\ucc89\u0ded\uad26\u78cb", "\ud9e1\ude35\ud84e\ude0f\ud9c4\udd9b\ud87a\udd0c\udbc0\udd90",
        52, 41361, -352672705, 8250656951798816853L, 15512L, true, false, (char) 43030, (char) 25119,
        Double.longBitsToDouble(0x3fe7c0ad275945e7L), Double.longBitsToDouble(0x3fe120e12ffc1977L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 2, 1, "\udb66\udebd\ud98b\udc71\udb7e\udfec\udba8\udc09\ud806\udcb4\udab3\udfe0\ud805\udfff\ud999\udf16\udb46\udc80\udb50\udd0f\uad07\uda57\udcf9\uda17\udea6\ud85d\udc5e", "\u630d\u4a8e\ua13f", "\udbca\udcaf\uda30\udec1\ud831\udf7a\udad9\udf06\ud8ac\udce3\ud88a\udce3\udbab\udc64\ud843\ude18\ud9c4\udd9b\udbcf\udf59\udbc0\udd89\ud8dc\udc95\udb0c\udde3\ud955\udf8a\uda15\udfb1\ud966\ude10",
        51, 42907, 354651145, -6083638571747815949L, -53928L, false, false, (char) 371, (char) 6029,
        Double.longBitsToDouble(0x3fd485aaf483cd0eL), Double.longBitsToDouble(0x3fe9d933f5f07ab3L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 4, 5, "\ud865\udf5e\udb06\uddf5\udb83\udf88\udba8\udc09\uda32\uddb7\udab3\udfe0\ud805\udfff\udaf1\udd42\udb45\udfbc\udb50\udd0f\uad07\uda57\udcf9\uda17\udea6\ud85d\udc5e", "\u63b9\u4a8e\ua13f\u1ad5\u3063\u5df6\u50c2\uad26\ud1b7\u14ac\uaba6\u212a\u5553", "\udbc0\udd90\ud8dc\udc95\udb0c\udde3\ud955\udf8a\uda15\udfb1\ud966\ude10\udae4\ude0d\ud90e\ude7c\udba1\udd47\ud8f1\uddfa\ud939\udfa6\udb3f\udc0f\uda85\udda3\ud88f\udfa4\udbbb\udd7c\ud843\udf41\ud8a5\udc71\uda61\udeb8\ud861\udcb0\ud852\udf11\ud96e\uddd3\uf272\ud9ac\udc1f\ud98f\udcec\ud81f\udc99\uda49\udc3e\ud8ad\udc44\uda50\ude0c\udaee\uddeb\udb63\udc9c\uda37\udca3\ud8e9\udd47\ud9f8\udfd5\ud92e\udd4f\udbf9\udd6e\ud884\udf27\ud927\udf44\ud856\udea6\ud95d\udc7a\udb63\uddae\uda09\ude03\udba4\ude1a\ud9cd\udc91\ud803\udf4c\udaee\udf53\uda2f\udd32",
        5, 85470, -1206774546, -1691727178841653160L, -60724L, true, false, (char) 11090, (char) 47585,
        Double.longBitsToDouble(0x3fdd9949f845da5eL), Double.longBitsToDouble(0x3fe82e088b8ba661L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 3, 1, "\ud865\udf5e\u8223\ud9b0\udf0e\udba4\udc10\uda32\uddb7\udb04\uddc7\ud805\udfff\udaf1\udd42\udb45\udfbc\udb50\udd0f\uad07\uda57\udcf9\uda17\udea6\ud85d\udc5e", "\u630d\u4a8e\ua13f\u1ad5\u3063\u5df6\u50c2\uad26\u78cb\u2dcf\uab9b\u212a\u5553", "\udbc0\udd90\ud8dc\udc95\udb0c\udde3\ud955\udf8a\uda15\udfb1\ud966\ude10\udae4\ude0d\ud90e\ude7c\udba1\udd47\ud8f1\uddfa\ud939\udfa6\ud874\udc86\ud867\udf13\ud890\udc09\udbbb\udd7c\ud843\udf41\ud8ea\udd71\ud9d5\ude1f\ud852\ude76\ud852\udf11\ud96e\uddd3\uf272\ud9ac\udc1f\ud98f\udcec\ud81f\udc99\uda49\udc3e\ud8ad\udc44\uda50\ude0c\ud8f3\udeec\ud816\udfac\ud94b\ude9a\ud8bc\udd61\ud9f8\udfd5\ud92e\udd4f\udbf9\udd6e\ud884\udf27\ud927\udf44\ud856\udea6\ud95d\udc7a\udb63\uddae\uda09\ude03\udba4\ude1a\ud9cd\udc91\ud803\udf4c\udaee\udf53\uda2f\udd32",
        5, 85470, -1206774546, -1691727178841653160L, -60724L, true, false, (char) 11090, (char) 53217,
        Double.longBitsToDouble(0x3fdd9949f845da5eL), Double.longBitsToDouble(0x3fe82e088b8ba661L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 0, "\udb66\udebd\ud98b\udc71\udb7e\udfec\udba8\udc09\ud806\udcb4\udab3\udfe0\ud805\udfff\ud999\udf16\udb46\udc80\ud9f8\udda2\ud9d4\udf70\uda57\udcf9\uda17\udea6\ud85d\udc5e\udbce\uddc6\udb9e\udc2b\ud9b2\udd5b\ud95c\ude68\ud9a3\ude80\ud9ba\udcd3\udb67\udca4\udbca\udcaf\ud94e\udc0f\ud831\udf7a\udad9\udf06\ud885\udce3", "\u5553\u5991\u4e52\u739b\u1e3e\u9875\ud3da\uc1b7\u227c\u17da\u335f\uc0f3\u85f4\u2742\u687b", "\udbbb\udd7c",
        2, 94624, 645839425, -7085460482264711696L, -76247L, false, false, (char) 31724, (char) 17287,
        Double.longBitsToDouble(0x3fc2f0e5273479d0L), Double.longBitsToDouble(0x3fdaa8b1a7f0a946L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 4, 8, 1, "\ud865\udf5e\udb06\uddf5\udb7e\udf06\udad0\udf6e\ud942\ude3f\ud8f2\udfe8\ud92d\udf36\udaf1\udd42\udb45\udfbc\ud936\udd56\udbd0\udd3f\uda57\udcf9\udbca\udca6\ud85c\udfc3", "\u630d\u4a8e\ua13f\u1ad5\u3063\ucc89\u0ded\uad26\u78cb\ua3d7\uab9b\u54b8\u814a", "\udbc0\udd90\ud8dc\udc95\udb0c\udde3\udb8c\udc64\ud98f\udf88\ud95c\udcd6\udbb8\udd55\udae5\ude52\udba1\udd47\ud8f1\uddfa\ud9f2\ude61\ud9a4\udc1b\uda71\uddea\ud88f\udfa4\uda83\udce0\ud867\ude7b\ud8ea\udd71\ud9cf\udc1f\ud852\ude76\udaff\udd06\ud96e\uddd3\uf272\ud9ac\udc1f\ud84f\udeca\udbcf\udee0\ud8d3\ude85\ud871\udca2\udb06\udd84\ud910\ude82\ud816\uded2\ud94b\ude9a\ud8bc\udd61\ud9f8\udfd5\ud92e\udd4f\uda13\udd66\ud86e\udc16\ud927\udf44\udb9e\udea9\ud960\udf35\udb63\uddae\uda09\ude03\udba4\ude1a\ud9e2\udc91\ud803\udf4c\udaee\udf53\uda2f\udd32",
        5, 85470, -1206774546, -1691727179462410152L, -60724L, true, false, (char) 44686, (char) 47747,
        Double.longBitsToDouble(0x3fdd9949f845da5eL), Double.longBitsToDouble(0x3fe82e088f8ba661L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 0, 4, "\ud865\udf5e\udb06\uddf5\uf906\000\ud9fe\udfb7\udab3\udfe0\ud805\udfff\ud873\udd43\udac8\udea8\ud932\ude3a\udbd0\udd3f\uda57\udcf9\udbc9\udfbf\ud8a7\udcda", "\u630d", "\uda1b\udf03\udb66\udfd8\udb10\udc3c\ud9e7\udc50",
        18, 49698, -1832268472, 8875198078669357056L, -99504L, true, false, (char) 55779, (char) 36253,
        Double.longBitsToDouble(0x3fc93d56e155ca00L), Double.longBitsToDouble(0x3fe4284498c8ebe9L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer|chooseInitialCenters|java.util.Collection,int,java.util.Random|static",
    "M|org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer|assignPointsToClusters|java.util.Collection,java.util.Collection|static",
    "M|org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer|cluster|java.util.Collection,int,int|new:org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:java.util.Random",
    "M|org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer|getFarthestPoint|java.util.Collection|new:org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:java.util.Random",
    "M|org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer|getNearestCluster|java.util.Collection,org.apache.commons.math.stat.clustering.Clusterable|static",
    "M|org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer|getPointFromLargestNumberCluster|java.util.Collection|new:org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:java.util.Random",
    "M|org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer|getPointFromLargestVarianceCluster|java.util.Collection|new:org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer:java.util.Random",
    "C|org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer|<init>|java.util.Random",
    "C|org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer|<init>|java.util.Random,org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer$EmptyClusterStrategy",
    "M|org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer|chooseInitialCenters|java.util.Collection,int,java.util.Random|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
