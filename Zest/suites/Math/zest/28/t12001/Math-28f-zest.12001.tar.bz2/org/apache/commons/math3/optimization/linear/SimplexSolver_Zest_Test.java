package org.apache.commons.math3.optimization.linear;
import org.junit.Test;
import static org.junit.Assert.*;
public class SimplexSolver_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 6, "\ud885\udf5c\udb58\uddf8\udb3b\udde9\uda0a\udd30\udb2e\udd7e\ud8de\uddb8\uda84\udfae\udaed\udcdc\udb75\udf68\ud887\udf72\udafa\udc33\ud999\udc9c", "\u79b5\u6342\ua7cf\uc8c8\uc762\ucbcb\ua4ea\u6d28\u9670\ub2f3\ubc66\u8dbb", "\uda0f\udc38\ud833\udec1\udabb\udcc6\udb1c\udfa2\ua66d\udb92\udf04\udba5\udd67\ud955\udc18\ud841\udd99\ud90b\ude49\ud915\udd44\udaac\uddca\udb6c\udef9",
        35, 3241, 1987690548, -1056766266742731777L, 38872L, false, false, (char) 5688, (char) 35365,
        Double.longBitsToDouble(0x3fdeba2355baa73cL), Double.longBitsToDouble(0x3fee589e0ab1dd79L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 6, "\ud885\udf5c\udb58\uddf8\udb3b\udde9\uda0a\udd30\udb2e\udd7e\ud8de\uddb8\uda84\udfae\udaed\udcdc\udb75\udf68\ud887\udf72\udafa\udc33\udb3b\udd8d", "\u79b5\u6342", "\ud94e\ude63\udada\udf1a\ud883\udcb3\udbb7\udf6f\ud97d\udf35\ud870\udd44\udb8e\udfb1\ud9b3\udf87\uf20f\ud88c\udcaf\uda0f\udc38\ud833\udec1\udabb\udcc6",
        20, 78870, 79956669, 8071504751070434650L, -46497L, true, false, (char) 56171, (char) 49441,
        Double.longBitsToDouble(0x3fe0336fa7343df6L), Double.longBitsToDouble(0x3fd34e7a49b91256L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 6, "\ud885\udf5c\udb58\uddf8\udb3b\udde9\uda0a\udd30\udb2e\udd7e\ud8de\uddb8\uda84\udfae\udaed\udcdc\u27e7\ud97d\udcda\ud9ca\uddb0\ud858\udddb", "\u79b5\u6342\u981c", "\ud9d3\ude70\uda4f\udf6f\udbb7\udf6d\ud9c7\udf3a\ud870\udd44\udb8e\udfb1\ud9b3\udf87\uf20f\ud88c\udcaf\uda0f\udc38\ud833\udec1\udabb\udcc6\udb1c\udfa2\ua66d\udb92\udf04\udba5\udd67",
        59, 72983, 1506070783, -4722242870708602124L, 72550L, true, true, (char) 42968, (char) 4903,
        Double.longBitsToDouble(0x3fefff8aaf83ec2fL), Double.longBitsToDouble(0x3fd88b74f0255ab2L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.linear.SimplexSolver:@?\0121=new org.apache.commons.math3.optimization.linear.SimplexSolver:@?\012",
        Z.run(T, 2, 6, 6, 6, "\ud885\udf5c\udb58\uddf8\udb3b\udde9\uda0a\udd30\uda57\udfd4\ud8de\uddb8\uda84\udfae\udaed\udcdc\udb75\udf68\ud887\udf72\udafa\udc33\ud999\udc9c", "\u79b5\u6342\ua7cf\uc8c8\uc762\ucbcb\ua47e\u7a28\u9670\ub2f3\ubc66\u8dbb\ud558\ucc3f\u98b3\u5efc\u4652\u9894\u44acc\u9390\ub4f9\ua17a\u0364\u0b75\u8398\u26d1\u6b76\ub1f3\u0a08\u224d", "\ud83b\udca9\uda15\udca7\ud982\udd52\u42a7\uda19\uded8",
        40, 3227, 1190985724, 5563378257907598826L, 46671L, true, true, (char) 8435, (char) 20916,
        Double.longBitsToDouble(0x3fe1192087018d22L), Double.longBitsToDouble(0x3fe61c1e7e74e002L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 3, "\ud885\udf5c\udb58\uddf8\udb3b\udde9\uda0a\udd30\udb2e\udd7e\ud8de\uddb8\uda84\udfae\udaed\udcdc\udb75\udf68\ud887\udf72\udafa\udc33\ud999\udc9c", "\u79b5\u6342\ua7cf\uc8c8\uc762\ucbcb\ua4ea\u6d28\u9670\ub2f3\uc8b7\u8dbb", "\uda0f\udc38\ud833\udec1\udabb\udcc6\udb1c\udfa2\ua66d\udb92\udf04\ud9a1\ude46\u868a\ud841\udd8f\ud90b\ude49\ud915\udd44\udaac\uddca\udb6c\udef9",
        35, 3241, 1987690548, -1056766266742731777L, 38872L, false, false, (char) 5688, (char) 35365,
        Double.longBitsToDouble(0x3fdeba23539aa73cL), Double.longBitsToDouble(0x3fab1c672b1916e0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 0, "\ud885\udf5c\udb58\uddf8\udb36\udce9\uda48\udc9f\udb2f\uded5\ud8de\uddb8\uda84\udfae\udaed\udcdc\udb75\udf68\ud887\udf72\udafa\udc33\ud999\udc9c", "\u79b5\u6342\ua7cf\uc8c8\uc762\ucbcb\ua4ea\u6d28\u9670\ub2f3\ubc66\u8dbb", "\uf118\ud833\udea3\udabb\udcc6\udb1c\udfa2\ua66d\udb92\udf04\ud8ca\udcfe\ud972\udd6f\ud841\udd99\ud90b\ude49\ud915\udd44\udaac\uddca\udb6c\udef9",
        35, 3241, 1987690548, -1056766266742731777L, 38872L, false, false, (char) 5688, (char) 35365,
        Double.longBitsToDouble(0x3fdeba2355baa73cL), Double.longBitsToDouble(0x3fee589e0ab1dd79L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 6, "\ud885\udf5c\udb58\uddf8\udb3b\udde9\uda0a\udd30\udb2e\udd7e\ud8de\uddb8\uda84\udfae\udaed\udcdc\udb75\udf68\ud887\udf72\udafa\udc33\ud999\udc9c", "\u79b5\u6342\ua7cf\uc8c8\uc762\ucbcbo\u6d28\u9670\ub2f3\ubc66\u8dbb", "\uda0f\udc38\ud833\udec1\udabb\udc14\udb1c\udfa2\u966b\udb92\udf04\udba5\udd67\ud955\udc18\ud841\udd99\ud90b\ude49\ud915\udd44\udaac\uddca\udb6c\udef9",
        35, 3241, 1987690548, -1056766266742731777L, 38872L, false, false, (char) 5688, (char) 35365,
        Double.longBitsToDouble(0x3fdeba2355baa73cL), Double.longBitsToDouble(0x3fee589e0ab1dd79L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.linear.SimplexSolver:@?\0121=new org.apache.commons.math3.optimization.linear.SimplexSolver:@?\012",
        Z.run(T, 2, 5, 6, 2, "\ud885\udf5c\udb58\uddf8\udb3b\udde9\uda0a\udd30\udb2e\udd7e\ud8de\uddb8\uda84\udfae\udaed\udcdc\udb75\udf68\ud887\udf72\udafa\udc33\ubd9d", "\u79b5\u6342\ua7cf\uc8c8\uc762\ucbcb\ua4ea\u2d29\u2c85\ub2f3\u3128\u06bc", "\uda0f\udc38\ud833\udec1\udabb\udcc6\uda5a\uddde\ud80f\udc2f\udb92\udf04\udba5\udd67\ud955\udc18\ud841\udd99\ud90b\ude49\ud915\udd44\udaac\uddca\udb6c\udef9",
        35, 3241, 1987690548, -1056766266742731777L, 38872L, false, false, (char) 5688, (char) 35365,
        Double.longBitsToDouble(0x3fdeba2355baa73cL), Double.longBitsToDouble(0x3fee589e0ab1dd79L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 6, "\ud885\udf5c\udb58\uddf8\udb3b\udde9\uda0a\udd30\udb2e\udd7e\ud8de\uddb8\uda84\udfae\udaed\udcdc\uda22\uddba\ud8aa\udf7a\udafa\udc33\uda0f\ude98", "\u84f7\u301f\u4ea0\uc97d\uc762\ucbcb\u8faf\u8f33\u2633\ubf1f\u778d\uc9c6", "\uda0f\udc38\ud87a\udf65\ud88d\ude61\udb1d\udc4d\ua66d\udb92\udf04\udbe9\udfe1\udb32\udfad\ud841\udd99\ud90b\ude49",
        13, 76508, -349903009, 4464934226829287201L, 71182L, true, true, (char) 24681, (char) 35668,
        Double.longBitsToDouble(0x3f92ad5905d8cb80L), Double.longBitsToDouble(0x3fa704fc1eba2350L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.linear.SimplexSolver:@?\0121=new org.apache.commons.math3.optimization.linear.SimplexSolver:@?\012",
        Z.run(T, 2, 6, 6, 0, "\ud885\udf5c\udb58\uddf8\udb3b\udde9\uda0a\udc77\udb2e\udd7e\000\uda84\udfae\udaed\udcdc\ud98e\ude5b\ud887\udf72\udafa\udc33\ud999\udc9c", "\u79b5", "\udb5a\udcac\ud94e\ude63",
        41, 19143, -510510791, -3121405997702878597L, -81774L, false, false, (char) 0, (char) 17408,
        Double.longBitsToDouble(0x3fe9280affc6c476L), Double.longBitsToDouble(0x3fe5ef4916ce04c4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.linear.SimplexSolver:@?\012",
        Z.run(T, 1, 5, 6, 6, "\ud885\udf5c\udb58\uddf8\ud9aa\udf62\uda0a\udd30\udb2e\udd7e\ud8de\uddb8\uda84\udfae\udaed\udcdc\udb75\udf68\ud887\udf72\udafa\udc33\ud999\udc9c", "\u79b5\u6342\ua7cf\u2c54\u9c50\ub014\ua575\u6d28\u69fe\uc87b\u4120\uc4ef", "\uda03\udc99\u1b37\ud984\ude87\udb14\udcc6\u4213\udb92\udf04\udba5\udd67\ud955\udc18\ud841\udd99\ud90b\ude49\ud915\udd44\uda14\udddd\udb6c\udf23",
        35, 12667, 1348134852, 6365540140854004888L, -63451L, false, false, (char) 5688, (char) 35365,
        Double.longBitsToDouble(0x3fdeba2355baa73cL), Double.longBitsToDouble(0x3fee589e0ab1dd79L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.linear.SimplexSolver:@?\012",
        Z.run(T, 1, 5, 5, 3, "\ud895\udc5c\uda41\udc2e\ud9f2\udc54\ud800\udc02\udb2e\udd7e\ud8de\uddb8\ud9cf\udc14\udb12\udcf1\udb75\udf68\ud887\udf72\udafa\udc33\ud999\udc9c", "\u79b5", "\ud8e1\udeb1\ud882\udf0a",
        41, 19143, 1737698361, -3126729545241761157L, 2154L, true, false, (char) 18973, (char) 43714,
        Double.longBitsToDouble(0x3fe5f10f94b20034L), Double.longBitsToDouble(0x3fe9280afd80797bL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 2, "\uda65\ude4c", "\u09a5\u423f\u2e8b\u107c\u26f7\u07f3\u8f58\uc63e\u7b64\ub22b\u23b5\u79b5\u6342\ua7cf\uc8c8\uc762\ucbcb\ua4ea\u6d28\u9670\ub2f3\ubc66\u2dee\ub41a\ucc3f\uc5d4\u5efc\u4652", "\udb92\udf04\udba5\udd67",
        59, 72983, 1506070783, -4722242870708602124L, 72550L, true, true, (char) 42941, (char) 60543,
        Double.longBitsToDouble(0x3fefff8a6365ec2fL), Double.longBitsToDouble(0x3fd88b74f0255ab2L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 3, 6, "\000\000\udb3b\udde9\uda0a\udd30\udb2e\udd7e\ud8de\uddb8\uda84\udfae", "\u8f58\uc63e\u9080H\u2326\u79b5\u6342\ua7cf4\000\000\000\u33ef\ua60a\ub2f3\ubc66\u8dbb\ud558\ucc3f\u98b3\u5efc", "\ua66d\udb92\udf04\udba5\udd67\ud955\udc18",
        33, 58783, -1099476385, 1828716544L, -59244L, false, true, (char) 9735, (char) 16888,
        Double.longBitsToDouble(0x3fb79aa444041ad8L), Double.longBitsToDouble(0x3febee3f0c2f42c9L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 5, "\ud885\udf5c\ud92f\udfa5\udb3b\udde9\uda0a\udd30\udb2e\udd7e\ud8de\uddb8\ud87c\udfaa\udaed\udcdc\ud951\udce9\ud97d\udd07\ud9ca\uddb0\ud852\udcdb", "\u79b5\u6342\u981c", "\udb62\ude17\ud98e\ude9c\udbb7\udf6d\ud9c7\udf3a\ud870\udd44\udb8e\udfb1\ud9b3\udf87\udb2c\ude07\ud88c\udcaf\uda0f\udc38\ud833\udec1\udabb\udcc6\udb1c\udfa2\udbc1\udcd8\ud920\udc3a\ud8fa\udce3",
        11, 72983, 1983993406, 4976259243086143398L, 72550L, true, true, (char) 42968, (char) 4903,
        Double.longBitsToDouble(0x3fefff8aaf83ec2fL), Double.longBitsToDouble(0x3fd88b74f0255ab2L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 6, "\udbbd\udcf8", "\u84b3", "\ud9ab\udfa1\udbf6\udd21\ud8c4\udd6e\udbff\udceb\ud8c4\udf23",
        33, 72246, -439305792, 450415269092719523L, 17153L, true, true, (char) 12849, (char) 34391,
        Double.longBitsToDouble(0x3fd395ab0f867724L), Double.longBitsToDouble(0x3fe526a5b25b7308L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 6, "\ud977\udc43\uda2f\udf87\udb52\udfb6\uda0a\udd30\udb2e\udd7e\ud8de\uddb8\uda84\udfae\udaed\udcdc\uda22\uddba\ud8aa\udf7a\udafa\udc33\uda0f\ude98", "\u84f7\u301f\u4ea0\uc97d\uc762\ucbcb\u8faf\u8f33\u2633\ubf1f\u778d\uc9c6", "\udacf\udf38\ud87a\udf65\ud88d\ude61\udb1d\udc4d\ua66d\udb92\udf04\udbe9\udfe1\udb32\udfad\ud841\udd99\ud90b\ude49",
        13, 76508, -349903009, 4464934226829287201L, 24827L, true, true, (char) 24681, (char) 35668,
        Double.longBitsToDouble(0x3f92ad5905d8cb80L), Double.longBitsToDouble(0x3fa704fc1eba2350L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.optimization.linear.SimplexSolver|getPivotRow|org.apache.commons.math3.optimization.linear.SimplexTableau,int|new:org.apache.commons.math3.optimization.linear.SimplexSolver:",
    "M|org.apache.commons.math3.optimization.linear.SimplexSolver|doIteration|org.apache.commons.math3.optimization.linear.SimplexTableau|new:org.apache.commons.math3.optimization.linear.SimplexSolver:",
    "M|org.apache.commons.math3.optimization.linear.SimplexSolver|doOptimize||new:org.apache.commons.math3.optimization.linear.SimplexSolver:",
    "M|org.apache.commons.math3.optimization.linear.SimplexSolver|getPivotColumn|org.apache.commons.math3.optimization.linear.SimplexTableau|new:org.apache.commons.math3.optimization.linear.SimplexSolver:",
    "M|org.apache.commons.math3.optimization.linear.SimplexSolver|solvePhase1|org.apache.commons.math3.optimization.linear.SimplexTableau|new:org.apache.commons.math3.optimization.linear.SimplexSolver:",
    "C|org.apache.commons.math3.optimization.linear.SimplexSolver|<init>|",
    "C|org.apache.commons.math3.optimization.linear.SimplexSolver|<init>|double,int",
    "M|org.apache.commons.math3.optimization.linear.SimplexSolver|getPivotRow|org.apache.commons.math3.optimization.linear.SimplexTableau,int|new:org.apache.commons.math3.optimization.linear.SimplexSolver:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
