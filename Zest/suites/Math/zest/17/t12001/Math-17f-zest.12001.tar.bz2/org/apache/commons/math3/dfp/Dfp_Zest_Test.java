package org.apache.commons.math3.dfp;
import org.junit.Test;
import static org.junit.Assert.*;
public class Dfp_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 11, "\ud939\uddba\ud996\ude81\ud940\udc31\ud9e4\udd7e\ud83a\udee5\udaaf\udfec\ud82b\udd74\ud91d\udcf0", "\uba30\u813d\u0198\u49de\u49af\u77cc\u7b0f\u912c", "\ud802\ude79\udb7e\udce3\uda8f\udd72\ud8fb\ude3e",
        46, 2383, -1830767165, 2568220246615299295L, 36742L, false, false, (char) 35026, (char) 47769,
        Double.longBitsToDouble(0x3fd81a0d28859d04L), Double.longBitsToDouble(0x3fdc18188489c244L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 11, "\ud939\uddba\ud996\ude81\ud940\udc31\ud9e4\udd7e\ud83a\udee5\udaaf\udfec\ud82b\udd74\ud91d\udcf0", "\uba30\u813d\u0198\u49de\u7a47\u45c5\u7b0f\u912c", "\ud802\ude79\udb9f\udee3",
        38, 43751, -1771042144, 6818786211551819203L, -61889L, true, true, (char) 51424, (char) 29441,
        Double.longBitsToDouble(0x3fe9818d1425de74L), Double.longBitsToDouble(0x3fd81a0d28859d04L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 6, 16, "\ud939\uddba\ud996\ude81\ud940\udc31\ud9e4\udd7e\ud83a\udee5\udaaf\udfec\ud82b\udd74\ud91d\udcf0", "\uba30\u813d\u0198\u49de\u305b\u4f5b\u7b0f\u1a2d\u8e4c\u8ccf\u3330\u1782\u0b1b\u0d94\u0583\uba16", "\ud9d7\uddd7\uda0e\udd9f\ud83a\udcb9\udab8\udef7\ud955\udc11\ud84c\udf01\ud95b\ude96\u94ce\uda3c\udc3e\ud97e\ude08\udb2b\ude61\ud817\udcc3\ud93a\udfe9",
        41, 31435, -364645652, -8903835049894205955L, -98936L, false, false, (char) 42060, (char) 65263,
        Double.longBitsToDouble(0x3fbd8d213a2b4640L), Double.longBitsToDouble(0x3f86647f11631800L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 14, 11, "\ud939\uddba\uda2c\udc0b\ud940\udc31\ud9e4\udd7e\ud83a\udee5\udaaf\udfec\ud82b\udd74\ud91d\udcf0", "\uba30\u813d\u0198\u49de\u49af\u7276\u96c6\u876a", "\uda56\udc83\udb7e\udce3\uda8f\udd72\ud8fb\udede\ud975\udc55\uda75\udf82\udacf\udf54\udabe\udcce\ud9d7\uddd7",
        8, 23268, 832754216, 7526375549746470036L, -65829L, true, true, (char) 46135, (char) 51133,
        Double.longBitsToDouble(0x3fe67987f23887f3L), Double.longBitsToDouble(0x3fd1e79602a63336L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 9, 16, "\ud939\uddba\ud996\ude81\ud93a\udc28\ud9e4\udd7e\ud83a\udee5\uda00\ude2d\ud82b\udd74\ud91d\udcf0", "\u064d\u4f40\u48fd\u79e4\u9514\u77cc\u7b0f\u8f5e", "\ud802\ude79\udb7e\udce3",
        38, 55527, -1304084052, 9165736206861826092L, -61889L, true, true, (char) 51424, (char) 29441,
        Double.longBitsToDouble(0x3fe9818d1425de74L), Double.longBitsToDouble(0x3fd81a0d28859d04L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 1, 11, "\ud939\uddba\ud996\ude81\ud940\udc31\ud9e4\udd7e\udb33\ude81\udaaf\udfec\ud82b\udd74\ud91d\udcf0", "\uba30\u813d\u0198\u49de\u49af\u2cac\u38c4\u912c", "\ud802\ude79\udb7e\udce3\uda8f\udd72\ud8fb\ude3e",
        46, 2383, -815451709, -9108706996869622644L, 36742L, false, false, (char) 35026, (char) 47769,
        Double.longBitsToDouble(0x3fd8116d28859d04L), Double.longBitsToDouble(0x3fb7606234ce0910L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 11, "\ud939\uddba\ud996\ude81\ud940\udc31\ud9e4\udd7e\ud83a\udee5\udaaf\udfec\ud82b\udd74\ud91d\udcf0", "\u4afb\u813d\u0198\u49de", "\ud890\ude5c",
        54, 45648, -1994294943, -5053013928146236122L, 75377L, true, true, (char) 47509, (char) 47234,
        Double.longBitsToDouble(0x3fec8883c1dadf06L), Double.longBitsToDouble(0x3fd3062d9e606344L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.dfp.Dfp|multiply|int|new:org.apache.commons.math3.dfp.Dfp:org.apache.commons.math3.dfp.Dfp",
    "M|org.apache.commons.math3.dfp.Dfp|multiply|org.apache.commons.math3.dfp.Dfp|new:org.apache.commons.math3.dfp.Dfp:org.apache.commons.math3.dfp.Dfp",
    "M|org.apache.commons.math3.dfp.Dfp|abs||new:org.apache.commons.math3.dfp.Dfp:org.apache.commons.math3.dfp.Dfp",
    "M|org.apache.commons.math3.dfp.Dfp|add|org.apache.commons.math3.dfp.Dfp|new:org.apache.commons.math3.dfp.Dfp:org.apache.commons.math3.dfp.Dfp",
    "M|org.apache.commons.math3.dfp.Dfp|align|int|new:org.apache.commons.math3.dfp.Dfp:org.apache.commons.math3.dfp.Dfp",
    "M|org.apache.commons.math3.dfp.Dfp|ceil||new:org.apache.commons.math3.dfp.Dfp:org.apache.commons.math3.dfp.Dfp",
    "M|org.apache.commons.math3.dfp.Dfp|classify||new:org.apache.commons.math3.dfp.Dfp:org.apache.commons.math3.dfp.Dfp",
    "M|org.apache.commons.math3.dfp.Dfp|compare|org.apache.commons.math3.dfp.Dfp,org.apache.commons.math3.dfp.Dfp|static",
    "M|org.apache.commons.math3.dfp.Dfp|complement|int|new:org.apache.commons.math3.dfp.Dfp:org.apache.commons.math3.dfp.Dfp",
    "M|org.apache.commons.math3.dfp.Dfp|copysign|org.apache.commons.math3.dfp.Dfp,org.apache.commons.math3.dfp.Dfp|static",
    "M|org.apache.commons.math3.dfp.Dfp|dfp2sci||new:org.apache.commons.math3.dfp.Dfp:org.apache.commons.math3.dfp.Dfp",
    "M|org.apache.commons.math3.dfp.Dfp|dfp2string||new:org.apache.commons.math3.dfp.Dfp:org.apache.commons.math3.dfp.Dfp",
    "M|org.apache.commons.math3.dfp.Dfp|divide|int|new:org.apache.commons.math3.dfp.Dfp:org.apache.commons.math3.dfp.Dfp",
    "M|org.apache.commons.math3.dfp.Dfp|divide|org.apache.commons.math3.dfp.Dfp|new:org.apache.commons.math3.dfp.Dfp:org.apache.commons.math3.dfp.Dfp",
    "M|org.apache.commons.math3.dfp.Dfp|dotrap|int,java.lang.String,org.apache.commons.math3.dfp.Dfp,org.apache.commons.math3.dfp.Dfp|new:org.apache.commons.math3.dfp.Dfp:org.apache.commons.math3.dfp.Dfp",
    "M|org.apache.commons.math3.dfp.Dfp|equals|java.lang.Object|new:org.apache.commons.math3.dfp.Dfp:org.apache.commons.math3.dfp.Dfp",
    "M|org.apache.commons.math3.dfp.Dfp|multiply|int|new:org.apache.commons.math3.dfp.Dfp:org.apache.commons.math3.dfp.Dfp",
    "M|org.apache.commons.math3.dfp.Dfp|multiply|org.apache.commons.math3.dfp.Dfp|new:org.apache.commons.math3.dfp.Dfp:org.apache.commons.math3.dfp.Dfp",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
