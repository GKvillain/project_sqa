package org.apache.commons.math.geometry.euclidean.threed;
import org.junit.Test;
import static org.junit.Assert.*;
public class Rotation_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 0, 3, "\uda18\udd02\udb21\udcc7\ud97c\ude8c\udb4a\udddc\uda95\udcfc\udb4a\udc42\uda6a\ude92", "\u1951\u0631\u9d2e\uae9d\u1c60\u6e23\u1569\u63e9\ucf9f\u2e28\ub779\u82e3\u61e8\u8f3b\uc73c\u8cde\u9296\u724d\u42c5\u28c1\u7407", "\ud909\ude78",
        43, 79401, -889699128, 677016465586260703L, -13522L, false, true, (char) 28207, (char) 38457,
        Double.longBitsToDouble(0x3fcb8a1984f2b17cL), Double.longBitsToDouble(0x3fc162db55191b74L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 0, 3, "\uda18\udcea\udb21\udcc7\ud97c\ude8c\udb4a\udddc\uda95\udcfc\udb4a\udc42\uda6a\ude92\udb66\udf9b\ud9cc\udfca\udb49\udf48\udb52\uddaf\uda02\udc7c\ud840\udecf\ud9da\udd3b\ud9ae\ude0b\udabb\udf6b\ud8cd\ude0b\udb3a\udf10\ud839\udf7e\uda79\ude7c\udbd9\ude04\udaf9\udff9\ud967\ude90", "\u9296\u724d\u42c5\u531c\u824b", "\ud965\udd58",
        15, 79401, -889699128, 677016465586260703L, -13522L, false, true, (char) 28207, (char) 38457,
        Double.longBitsToDouble(0x3fcb8a1984f2b17cL), Double.longBitsToDouble(0x3fc162db55c51b74L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 20, "\uda18\udd02\udb21\udcc7\ud97c\ude8c\udb4a\udddc\uda95\udcfc\udb37\udc7c\udb06\udd4d", "\u8493\u8f52\u494e\uae9d\u1c60\u6e23\u1569\u9a79\ucf9f\uc227\ub779\u82e3\u61e8\u8f3b\uc73c\u8cde\u9296\u724d\u42c5\u28c1\u851a", "\u74d0\ud867\udccc\ud9a7\udd33\udbd0\udda7\udaeb\udf70\ud900\udd9c\ud909\udf8a\uda2c\udc71",
        39, 85013, 1355585721, -7353352110540676874L, -60448L, true, false, (char) 32174, (char) 17407,
        Double.longBitsToDouble(0x3fd88f452a6c1ce8L), Double.longBitsToDouble(0x3feb718ed48128a4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 0, 3, "\uda18\udd02\udb21\udcc7\ud97c\ude8c\udb4a\udddc\uda95\udd4a\udb4a\udc42\uda6a\ude92", "\u1951\u0631\u9d2e\uae9d\u1c60\u6e23\u1569\u63e9\ucf9f\u2e28\ub779\u82e3\u61e8\u8f3b\uc73c\u8cde\u9296\u724d\u42c5\u28c1\u7407", "\ud909\ude78\ud8ae\udd70\ud9a7\udd33\udbd0\udda7\udaeb\udf70\ud900\udd9c\ud909\udf8a\uda2c\udc71\udabd\udf82\ud93f\ude3c\ud8c7\udd89\ud93f\udfb1\u7117\udb50\udecd\ud98a\udede\ud92c\udfad\u95e4\uda4d\udecf\uda2f\ude93\uda68\udea5\udab8\udd66\ud9f1\udfe0",
        28, 59414, -1674869881, 2033097995110675343L, -89049L, true, false, (char) 40164, (char) 32921,
        Double.longBitsToDouble(0x3fe7c3a86b87eda8L), Double.longBitsToDouble(0x3fdd828234308d44L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 16, "\uda18\udd02\udb21\udcc7\udb1d\udd4d\udb4a\udddc\uda95\udcfc\u0091\ud996\udc0a", "\u2750", "\ud868\udfbf\000\udbfe\ude0b\ud46b\ud8cd\ude0b\udb3a\udf10\ud839\udf7e\udb18\udeab\000",
        -5, 71552, -912648266, -8454259335013964392L, -100000L, false, false, (char) 15725, (char) 29799,
        Double.longBitsToDouble(0x3fcc0f05c0000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 20, 0, 7, "\uda18\udd02\uda73\udd33\ud9ac\ude0a\udb19\udf90\uda95\udd48\udb4a\udc42\ud939\udefa", "\u1948\u0631\u25ab\u789e\u44ac\ucf56", "\udb3a\udf10\ud839\udf7e\uda79\ude7c\udbd9\uddc1\ud916\uddc6\u1c64\ud91d\udc3e\udbc6\udd02\ud948\udc6a",
        35, 27232, -1875674764, 1250942336750740835L, -69905L, false, false, (char) 2524, (char) 5188,
        Double.longBitsToDouble(0x3fe91392e632c309L), Double.longBitsToDouble(0x3fd1826265fa7664L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.math.geometry.euclidean.threed.Rotation:@?\012",
        Z.run(T, 1, 3, 11, 0, "\uda18\udd02\udb21\udcc7\ud97c\ude8c\udb4a\udddc\uda95\udcfc\udb4a\udc42\uda6a\ude92", "\u5e78\u0fa3\u9d2e\uae9d\u1c60\u6e23\u7268\u63e9\ucf9f\u2e28\ud441\u403d\u1ff5\u8f3b\uc73c\u8cde\u7c5d\u72ac\u42c5\u28c1\u9407", "\uda3c\udff0",
        43, 79401, -889699146, 677016465586260703L, -13522L, false, true, (char) 28207, (char) 38341,
        Double.longBitsToDouble(0x3fcb8a1984f2b17cL), Double.longBitsToDouble(0x3fc162db55191b74L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 8, 3, "\uda18\udd02\udb21\udcc7\ud97c\ude8c", "\u00a6\u6edd\u30b4", "\ud8cd\ude0c\ud914\udcb9\ud868\udfbf\ud9da\udd3b\udbfe\ude92\uda62\udfa0",
        42, 85376, -19894384, -5055015018818214234L, 35878L, false, true, (char) 14728, (char) 61508,
        Double.longBitsToDouble(0x3feb6b4bb43b5a2dL), Double.longBitsToDouble(0x3fd429985adb2066L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.math.geometry.euclidean.threed.NotARotationMatrixException\012",
        Z.run(T, 1, 5, 16, 13, "\uda18\udd02\ud99b\udfc5\ud97c\ude8c\udb4a\udddc\uda95\udcfc\udb4a\udc42\uda6a\ude92\udb66\udf9b\ud9cc\udfca\udb49\udf48\ud8ee\udc1c\ud914\udc34\ud868\udfbf\ud9da\udd3b\udbfe\ude92\uda62\udfa0\ud8cd\ude0b\udb3a\udf10\ud839\udf7e\uda79\ude7c\udbd9\ude04\ud84e\udcc3\ud900\udc60\ud91d\udc81\udbc6\udd02\ud80a\udfcf\ud9a5\udcbd\udbb5\ude30\ud947\udeab\ud967\udf58\ud842\udeea\ud861\udff5\ud909\ude78\ud867\udccc\ud9a7\udd33\udbd0\udda7\udaeb\udf70\ud900\udd9c\ud909\udf8a\uda2c\udc71\ud825\udc95\ud902\uded7\udbed\udd7b\ud955\udfee\udb10\ude94\ud82a\udcb8\ud93b\udfe5", "\u3fcd\uc334\u4e08\u3e2c\u076e\u78fb\u3d48\u2b71\u0b4c\u444b\u8325\ua071\u8278", "\udafe\udf49\u531f\ud9b7\udf7c\ud85e\udc1f\ud975\udd95\ud823\ude5e\uda53\udcb9\uda61\udf2e\ud82d\udd37\ud92d\udd1e\udb2e\udc61\udb11\udf07\uda35\udc80",
        54, 24594, -628799445, -8774902376069826705L, 5986L, false, true, (char) 2131, (char) 33556,
        Double.longBitsToDouble(0x3fec58872cc401b9L), Double.longBitsToDouble(0x3fd9b7165a8dfda0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.math.geometry.euclidean.threed.Rotation:@?\012",
        Z.run(T, 1, 3, 0, 3, "\uda3f\ude58\udb1d\udea6\udb2a\udebb\ud80b\ude36\uda95\udcfc\udb4a\udc42\udb70\udf55", "\ub446\u0660\u9d2e\uae9d\u1c60\u6e23\u13b2\u296d\ucf9f\u7c0b\uba4f\u82e3\u61e8\u8f3b\uc690\u8cde\u9296\u724d\u42c5\u28c1\u7407\u6245\uabb9\u30ca\u8b1d\u590c\ucded\u9a05\u2269\u72e1\u7369\u4f41\u9806\u707c", "\ud838\ude6c\u280d",
        14, 77774, 1531178117, -348535187937867808L, -92995L, true, false, (char) 48362, (char) 63078,
        Double.longBitsToDouble(0x3fe449928f57a9adL), Double.longBitsToDouble(0x3fd1ad00244621b6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 12, "\ud90d\udd73\udb21\udcc7\ud97c\ude8c\udb4a\udddc\ud884\udd85\ud975\uddd3\uda5e\ude6f", "\u1951\u0631\u9d2e\uae9d\ub39f\u0141\uc34f\u9229\u5444\u2e28\ub779\u82e3\u61e8\u8f3b\uc73c\u1fa2\u9296\u724d\u42c5\u28c1\uc552", "\ud8bf\udc65\ud89c\udf1c",
        18, 8897, 157630179, 8240473373080571170L, 89481L, true, false, (char) 18233, (char) 5544,
        Double.longBitsToDouble(0x3fe8f562fc8b16daL), Double.longBitsToDouble(0x3fd4646ddf2ea6d0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 0, 3, "\uda18\udcea\udb21\udcc7\ud97c\ude8c\udb4a\udddc\uda95\udcfc\udb4a\udc42\uda6a\ude92\udb66\udf9b\ud976\udfbf\udb49\udf48\udb52\uddaf\uda02\udc7c\ud840\udecf\ud9da\udd3b\ud819\udcc8\ud8cd\udf63\ud8cd\ude0b\udb3a\udf10\ud839\udf7e\ud8e5\ude72\udbd9\ude04\udaf9\udff9\ud99a\uddb3", "\u9296\u724d\u4c8c\u48ee\u4c75", "\ud965\udd58\ud9c5\udce6\uda4c\udcd6\udbfa\udc23\udb26\ude8b\udabd\udfa3\ud9c9\udf44\uda9d\uddca\ud825\udc95\ud902\uded7\udbed\udd7b\ud955\udfee",
        26, 30027, 722853489, -3149196731537633889L, 67284L, true, false, (char) 59248, (char) 37513,
        Double.longBitsToDouble(0x3fcac8e657350f80L), Double.longBitsToDouble(0x3fde724a36250f54L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 8, "\uda18\udd02\udb21\udcc7\ud97c\ude8c\udb4a\udddc\uda95\udcc2\udb37\udc7c\udb06\udd4d", "\u8493\u8f52\u5da2\uae51\u1c60\u6e23\ucdf1\u9a79\ucf9f\uc227\ub779\u82e3\u61e8\u8f3b\uc73c\u8cde\u9296\u724d\u42c5\u9a30\u9441", "\u74d0\ud867\udccc\udb45\udee2\ud86e\udfd6\udaeb\udf70\ud900\udd9c\ud909\udf8a\uda2c\udc71",
        39, 85013, 1355585721, -7353352110540676874L, 93862L, false, false, (char) 56838, (char) 26979,
        Double.longBitsToDouble(0x3fe400f1da03a72cL), Double.longBitsToDouble(0x3fd567858d588aa6L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.math.geometry.euclidean.threed.Rotation:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 0, 20, "\uda18\udd02\udb21\udcc7\ud97c\ude8c\udb4a\udddc\uda95\udcfc\udb37\udc7c\udbef\udc83", "\u8493\u8f52\u494e\uae95\u1c60\u6e23\u1569", "\ud828\udf7e\uda79\ude7c\udabf\uddd7\ud9a7\udc0d\uda24\udd0d",
        8, 64539, 1769366936, 6498121883169664059L, 10976L, true, true, (char) 32313, (char) 10754,
        Double.longBitsToDouble(0x3fdb9deba4e3e098L), Double.longBitsToDouble(0x3fc914e27b8f2be0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!org.apache.commons.math.geometry.euclidean.threed.NotARotationMatrixException\012",
        Z.run(T, 1, 5, 0, 20, "\uda11\udef8\udb21\udcc4\ud97c\ude8c", "\u61a5\u6bf1\u30b4", "\udb78\ude0b\ud8ff\udcd9\ud882\udf30\ud9da\udd3b\udbfe\ude92\uda62\udfa0",
        35, 73712, -19911792, -5055015018818214234L, 35878L, false, true, (char) 14728, (char) 27489,
        Double.longBitsToDouble(0x3fefa3b358b4bc14L), Double.longBitsToDouble(0x3fd429985d012066L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!org.apache.commons.math.geometry.euclidean.threed.NotARotationMatrixException\012",
        Z.run(T, 1, 5, 16, 13, "\uda18\udd02\ud99b\udfc5\ud97c\ude8c\udb4a\udddc\uda95\udcfc\udb4a\udc42\uda6a\ude92\udb66\udf9b\ud9cc\udfca\udb49\udf48\ud8ee\udc1c\ud914\udc34\ud868\udfbf\ud9da\udd3b\udbfe\ude92\uda62\udfa0\ud8cd\ude0b\udb3a\udf10\ud839\udf7e\uda79\ude7c\udbd9\ude04\ud84e\udcc3\ud900\udc60\ud91d\udc81\udbc6\udd02\ud80a\udfcf\ud9a5\udcbd;\000\ud967\udeeb\ud842\udeea\ud861\udff5\ud909\ude78\ud867\udccc\ud9a7\udd33\udbd0\udda7\udaeb\udf70\ud900\udd9c\ud909\udf8a\uda2c\udc71\ud825\udc95\ud902\uded7\udbed\udd7b\ud955\udfee\udb10\ude94\ud82a\udcb8\ud93b\udfe5", "\u3fcd\uc334\u4e08\u3e2c\u076e\u78fb\u3d48\u2b71\u0b4c\u444b\u8325\ua071\u8278", "\udafe\udf49\u531f\ud9b7\udf7c\ud85e\udc1f\ud975\udd95\ud823\ude5e\uda53\udcb9\uda61\udf2e\ud82d\udd37\ud92d\udd1e\udb2e\udc61\udb11\udf07\uda35\udc80",
        54, 24594, -628799445, -8774902376069826705L, 5986L, false, true, (char) 2131, (char) 63507,
        Double.longBitsToDouble(0x3fec58872cc401b9L), Double.longBitsToDouble(0x3fd9b7165a8dfda0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!org.apache.commons.math.geometry.euclidean.threed.NotARotationMatrixException\012",
        Z.run(T, 1, 5, 16, 13, "\uda18\udd02", "\u880f\u493a\u85ec\u596a\u401c\u67eb\u4f0f\u67ac\u9ca9\uae9d\u1c60\u6e23\u1569\u63e9\ucf9f\u2e28\ub779", "\ud900\udc60\ud91d\udc81\udbc6\udd02\ud80a\udfcf\uda16\ude16\udbac\udf58\ud947\udeab\ud967\udf58\uda82\udeea\ud861\udff5\ud909\ude78",
        43, 79401, -889699128, 677016465586260703L, -13522L, false, true, (char) 28207, (char) 38457,
        Double.longBitsToDouble(0x3fcb8a1984f2b17cL), Double.longBitsToDouble(0x3fc162db55191b74L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.math.geometry.euclidean.threed.Rotation:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 3, "\uda3f\ude58\udb1d\udea6\udb2a\udebb\ud80b\ude36\ud955\uded3\udb4a\udc42\udb70\udf55", "\u8659\u0660\u9d2e\uae9d\u1c60\u6e23\u13b2\u296d\u30ee\u7c0b\uba4f\u82e3\u61e8\u8f3b\uc690\u8cde\ud5d7\u4267\u42c5\ua441\u7407\u6245\uabb9\u30ca\u8b1d\u590c\ucded\u9a05\u2269\u72e1\uc397\u4f41\u9806\u967f", "\ud838\ude6c\u280d",
        14, 77774, 1531178117, -348535187937867808L, -92995L, true, false, (char) 48362, (char) 63078,
        Double.longBitsToDouble(0x3fe449928f57a9adL), Double.longBitsToDouble(0x3fd1ad00244621b6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.math.geometry.euclidean.threed.Rotation:@?\0121=new org.apache.commons.math.geometry.euclidean.threed.Rotation:@?\012",
        Z.run(T, 2, 19, 3, 20, "\uda18\udd02\udb21\udcc7\ud97c\ude8c\udb4a\udddc\uda95\udcfc\udb37\udc7c\udbef\udc83", "\u8493\u8f52\u494e\uae95\u1c60\u6e23\u1569", "\ud828\udf7e\uda79\ude7c\udabf\uddd7\ud9a7\udc0d\uda24\udd0d",
        8, 451, 1769366936, 6498121883169664059L, 10976L, true, true, (char) 32313, (char) 10754,
        Double.longBitsToDouble(0x3fdb9deba4e3e098L), Double.longBitsToDouble(0x3fc914e27b8f2be0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.math.geometry.euclidean.threed.Rotation:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 8, 5, "\uda18\udd02\udb21\udcc7\udae0\udfb4\udb4a\ude47\uda95\udcfc\udb37\udc7c\udbef\udc83", "\u8493\u8f52\u494e\uae95\u1c60\u6e23\u1569", "\ud828\udf7e\uda8a\udd64\u013f\udb22\ude5d\uda24\udd0d",
        8, 64539, 1769366936, 6498121883169664059L, 10976L, true, true, (char) 32313, (char) 10754,
        Double.longBitsToDouble(0x3fdb9deba4e3e098L), Double.longBitsToDouble(0x3fc914e27b8f2be0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.math.geometry.euclidean.threed.Rotation:@?\0121=new org.apache.commons.math.geometry.euclidean.threed.Rotation:@?\012",
        Z.run(T, 2, 19, 19, 6, "\uda1e\udf72", "\u880f\uc004\u0566\ua079\u7c85\u5646\u8493\u2860\ud445\u1c90\u948d\u8874\u4a78\u9a79\u2630\u2fc9\u753c\ua92c\u0ef6\u1a39\u66a5", "\ud9e1\udcb4\udbb5\uded6\ud947\udefe\udb1e\udeb8\ufbfe\ud883\udca6\udbba\udddc\ud970\udc57\ud9a7\udd6e\udbd0\udda7\uda8a\ude1d\udbc1\ude63\udb64\udfea",
        15, 1786, 1641015319, -2096993547251577023L, -13977L, false, false, (char) 41044, (char) 4717,
        Double.longBitsToDouble(0x3fe2402e4c4a1be5L), Double.longBitsToDouble(0x3fe0068ee8c29649L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.math.geometry.euclidean.threed.Rotation:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 15, 5, "\uda3b\udc02\uda1d\udd26\ud97e\udc2d\udb4a\ude03\uda95\udcfc\udb37\udc7c\udbef\udc83", "\u8493\u8f52\u494e\uae95\uc201\ubfb3\u5abe\ub030\u1a4b\ua130\u0741\u4f55\uca0f\u5ab2\u15f3\u02b6\u535b\u8cc5\u980b\u2914\u851a\u0dd6\u4ede\u7f56\u6dc8\u0572\u8bb7\ub7b3\u61c9", "\u1b47\udb22\udc84\ud80f\uddc4\ud9ed\udf8c\uda02\udd85\udb7b\udc2c\ud9a9\udda0\ud951\uddc1\ud90d\udefb\ud9fc\udff3\udace\udced\udb0f\udfd7\udb73\udd53\udb69\udf4e",
        19, 69892, -2028580687, -334366814454155715L, -65094L, false, false, (char) 51982, (char) 11301,
        Double.longBitsToDouble(0x3fc3322e38d74628L), Double.longBitsToDouble(0x3fe801284574426dL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.math.geometry.euclidean.threed.Rotation:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 10, 15, "\ud917\udd81\udb0d\udf91\udabb\udf88", "\u84bd\u6aa0\u7663", "\udb6e\udcf6\ud8ff\udcd9\ud868\udfb7\ud9da\udd3b\ud9fe\ude92\ud83b\uddee\udb5b\udf62\udb3a\udf10\ud9f7\udf66\uda79\ude7c\udabf\uddd7\ud9a7\udc0d",
        36, 50188, -142591501, 7599372529256232813L, -89141L, false, false, (char) 13502, (char) 17217,
        Double.longBitsToDouble(0x3fe63019e5b9debaL), Double.longBitsToDouble(0x3fe38f8260c8a713L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.math.geometry.euclidean.threed.Rotation:@?\0121=new org.apache.commons.math.geometry.euclidean.threed.Rotation:@?\012",
        Z.run(T, 2, 19, 19, 14, "\uda18\udd02\uda4a\udf79\udbb8\udf8a\ua754\uda87\udd41", "\ucf0e\u2e18\u840f\u3964\u78dd\uc7c4\u862e\u6e23\u1540\ud651\uc6b1\u37c5\ub779\u4f55\u382a\u9338\u2c5c\u04ed\uacbe\u8a4e\u42c5\u2914\u851a\u0dd6\u1e8a\u221b\u8b1d", "\ud914\ude04\uff9c\udbe1\uddf0\uda2d\udd6a\udabc\udfc0\udabb\udc35\uda0d\udcfe\ud913\udcaa\uda36\udcd6\u1b67\udab2\uddee\ud856\udd7f\udbbb\udf37\ud91d\uded1",
        53, 20254, 331443707, -8491087863265115467L, -52800L, true, true, (char) 30013, (char) 18145,
        Double.longBitsToDouble(0x3fb8404e749d8aa8L), Double.longBitsToDouble(0x3fe9ce908051a39eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 0, 3, "\uda18\udd02\udb21\udcc7\ud97c\ude8c\udb4a\udddc\uda95\udcfc\udb4a\udc42\uda6a\ude92", "\u1951\u0631\u9d2e\uae9d\u1c60\u6e23\u1569\u63e9\ucf9f\u2e28\ub779\u82e3\u61e8\u8f3b\u1ba2\u565a\u9213\u724d\u42c5\u28c1\u4c66", "\ud909\ude78",
        43, 79401, -889699128, 677016465586260703L, -13522L, false, true, (char) 59241, (char) 38457,
        Double.longBitsToDouble(0x3fcb8a1984f2b17cL), Double.longBitsToDouble(0x3fc162db55191b74L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!org.apache.commons.math.geometry.euclidean.threed.NotARotationMatrixException\012",
        Z.run(T, 1, 5, 16, 13, "\000", "\000", "\uda6a\ude92\udb66\udf9b\ud9cc\udfca",
        -4, 87100, -1721127360, -3911034388384579519L, 19915L, false, false, (char) 2639, (char) 4139,
        Double.longBitsToDouble(0x3fe4fff680a6b9d8L), Double.longBitsToDouble(0x3e4c000000000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.math.geometry.euclidean.threed.Rotation:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 3, "\uda3f\ude58\udb1d\udea6\udb2a\udebb\ud80b\ude36\ud955\uded3\udb4a\udc42\udb70\udf55", "\u8659\u0660\u9d2e\uae9d\u1c60\u6e23\u13b2\u296d\ubab5\000\u93d9\u82e3\ua5ec\u8f3b\uc690\u8cde\ud5d7\u4267\u42c5\ua441\u7407\u6245\uabb9\u30ca\u8b1d\u590c\ucded\u9a05\u2269\u72e1\uc397\u4f41\u9806\u967f", "\ud838\ude6c\u280d",
        14, 77774, 1531178117, -348535187937867808L, -92995L, true, false, (char) 48362, (char) 63078,
        Double.longBitsToDouble(0x3fe449928f57a9adL), Double.longBitsToDouble(0x3fd1ad00244621b6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "C|org.apache.commons.math.geometry.euclidean.threed.Rotation|<init>|org.apache.commons.math.geometry.euclidean.threed.RotationOrder,double,double,double",
    "C|org.apache.commons.math.geometry.euclidean.threed.Rotation|<init>|org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D",
    "C|org.apache.commons.math.geometry.euclidean.threed.Rotation|<init>|org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D",
    "C|org.apache.commons.math.geometry.euclidean.threed.Rotation|<init>|double,double,double,double,boolean",
    "C|org.apache.commons.math.geometry.euclidean.threed.Rotation|<init>|org.apache.commons.math.geometry.euclidean.threed.Vector3D,double",
    "C|org.apache.commons.math.geometry.euclidean.threed.Rotation|<init>|[[D,double",
    "M|org.apache.commons.math.geometry.euclidean.threed.Rotation|applyInverseTo|org.apache.commons.math.geometry.euclidean.threed.Rotation|new:org.apache.commons.math.geometry.euclidean.threed.Rotation:org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D",
    "M|org.apache.commons.math.geometry.euclidean.threed.Rotation|applyInverseTo|org.apache.commons.math.geometry.euclidean.threed.Vector3D|new:org.apache.commons.math.geometry.euclidean.threed.Rotation:org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D",
    "M|org.apache.commons.math.geometry.euclidean.threed.Rotation|applyTo|org.apache.commons.math.geometry.euclidean.threed.Rotation|new:org.apache.commons.math.geometry.euclidean.threed.Rotation:org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D",
    "M|org.apache.commons.math.geometry.euclidean.threed.Rotation|applyTo|org.apache.commons.math.geometry.euclidean.threed.Vector3D|new:org.apache.commons.math.geometry.euclidean.threed.Rotation:org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D",
    "M|org.apache.commons.math.geometry.euclidean.threed.Rotation|distance|org.apache.commons.math.geometry.euclidean.threed.Rotation,org.apache.commons.math.geometry.euclidean.threed.Rotation|static",
    "M|org.apache.commons.math.geometry.euclidean.threed.Rotation|getAngle||new:org.apache.commons.math.geometry.euclidean.threed.Rotation:org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D",
    "M|org.apache.commons.math.geometry.euclidean.threed.Rotation|getAngles|org.apache.commons.math.geometry.euclidean.threed.RotationOrder|new:org.apache.commons.math.geometry.euclidean.threed.Rotation:org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D",
    "M|org.apache.commons.math.geometry.euclidean.threed.Rotation|getAxis||new:org.apache.commons.math.geometry.euclidean.threed.Rotation:org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D",
    "M|org.apache.commons.math.geometry.euclidean.threed.Rotation|getMatrix||new:org.apache.commons.math.geometry.euclidean.threed.Rotation:org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D",
    "M|org.apache.commons.math.geometry.euclidean.threed.Rotation|getQ0||new:org.apache.commons.math.geometry.euclidean.threed.Rotation:org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D",
    "C|org.apache.commons.math.geometry.euclidean.threed.Rotation|<init>|org.apache.commons.math.geometry.euclidean.threed.RotationOrder,double,double,double",
    "C|org.apache.commons.math.geometry.euclidean.threed.Rotation|<init>|org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D",
    "C|org.apache.commons.math.geometry.euclidean.threed.Rotation|<init>|org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D,org.apache.commons.math.geometry.euclidean.threed.Vector3D",
    "C|org.apache.commons.math.geometry.euclidean.threed.Rotation|<init>|double,double,double,double,boolean",
    "C|org.apache.commons.math.geometry.euclidean.threed.Rotation|<init>|org.apache.commons.math.geometry.euclidean.threed.Vector3D,double",
    "C|org.apache.commons.math.geometry.euclidean.threed.Rotation|<init>|[[D,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
