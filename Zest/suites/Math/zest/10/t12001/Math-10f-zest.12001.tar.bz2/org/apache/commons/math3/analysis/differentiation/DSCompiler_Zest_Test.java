package org.apache.commons.math3.analysis.differentiation;
import org.junit.Test;
import static org.junit.Assert.*;
public class DSCompiler_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 2, 8, 10, 8, "\uda17\udc79\ud966\udd6a\uda52\uded7\ud9f7\udf42\udbd0\udc3f\uda03\udfc3\uda41\udd5b\ud92e\udd17\ua29f\ud90a\ude29\ud936\udfb4\ud94d\udecf\udb35\uddda\ud8d5\udf0c\ud848\udcaa\ub1c7\udb0f\udcdc\ud829\udc73\ud887\udc5d\udaea\udfb4", "\u9dac\u391f\u119b\u76ad\ub96d\u886c\ud1a1\u0c60\uc958\ua3f1", "\udbea\udd46\u789b\udab1\udd47\ud827\udc16\uda0a\uded1\uda51\udf04",
        -3, 97322, -1191794751, 8719965182183995576L, 2693L, true, true, (char) 23762, (char) 62081,
        Double.longBitsToDouble(0x3fcf7f21de30e7a0L), Double.longBitsToDouble(0x3fecbaed7a022133L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 2, 8, 6, 8, "\ud9f5\ude9b\udb1b\udfa5\uda52\uded7\ud9f7\udf42\udbd0\udc3f\ud9d2\uddd2\uda41\udd5b\ud92e\udd17\ua29f\ud90a\ude29\ud936\udfb4\ud94d\udecf\udb5a\udccc\ud809\udc56\ud848\udcaa\ub1c7\udb0f\udcdc\ud829\udc73\ud887\udc5d\udaea\udfb4", "\u9dac\u391f\u119b\u76ad\u96e5\u886c\ud1a1\u0c60\uc958\ua3f1", "\udbea\udd46\u789b\ud882\ude3d\ud827\udc16\uda0a\uded1\ud823\uddfc",
        -3, 97322, -1207374497, 8719965182183995576L, 2693L, true, true, (char) 23762, (char) 62081,
        Double.longBitsToDouble(0x3fcf7f21de30e7a0L), Double.longBitsToDouble(0x3feedc7cdc799bccL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 10, 8, "\uda84\udd5a\ud9f4\udeb2\uda52\uded1\ud9f7\udf42\udbd0\udc3f\ud954\udf8b\uda54\udccb\ud92e\udd17\ua29f\ud90a\ude29\ud936\udfb4\ud94d\udecf\udb35\uddda\ud8d5\udf0c\ud848\udcaa\ub1c7\udb0f\udcdc\ud829\udc73\udae1\udf4b\uda52\udf44", "\u9dac\u391f\u119b\u76ad\ub96d\u886c\ud1a1\u0c60\uc958", "\ud881\udd24\udbea\udd46\u789b\ud94c\ude55\uda79\udf5a\uda19\udf96\uda51\udf04\ucc72\ud845\udd44\ud90a\udf91\udaa8\udd43\udbb6\udcd3\uda28\udc4a",
        27, 27609, -394308118, -500451503913766661L, 67085L, true, false, (char) 10135, (char) 32082,
        Double.longBitsToDouble(0x3fddf0cebfc52a1eL), Double.longBitsToDouble(0x3fec46ec5c5efc6eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 8, "\udad6\uddf9\ud966\udd6a\uda52\uded7\ud9f7\udf42\udbd0\udc3f\uda03\udfc3\uda41\udd5b\ud92e\udd17\ua29f\ud8a5\uddd8\udbd7\udf2e\ud80f\ude9f\udb35\uddda\ud8d5\udf0c\ud848\udcaa\ub1c7\udb0f\udcdc\ud829\udc73\ud887\udc5d\udaea\udfb4", "\u9dac\u391f\u119b\u76ad\u2c6d\u886c\ud1a1\u0c60\uc958\ua3f1\u46f2\u976b\uaa08\ua952\u2892\u12e9\u21bd\u1f84\u3fd1\u8ab8", "\udbb6\udcd3\uda28\udc4a\udbfe\udc91",
        39, 95882, -116520446, 4172850017157980044L, -40094L, true, true, (char) 48615, (char) 39440,
        Double.longBitsToDouble(0x3fd8383a5ac8bcccL), Double.longBitsToDouble(0x3fe29c43d0420cedL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 10, 8, "\uda17\udc79\ud966\udd6a\uda52\uded7\ud9f7\udf42\udbd0\udc3f\uda03\udfc3\uda41\udd5b\ud92e\udd17\ua29f\ud90a\ude29\ud936\udfb4\ud94d\udecf\udb35\uddda\ud8d5\udf0c\ud848\udcaa\ub1c7\udb0f\udcdc\udbe1\ude00\ud97a\udff5\ud967\udc0a", "\u9dac\u391f\u119b\ud3f9\u2d03\u886c\u19d6\u0c60\uc958\ua3f1", "\udbea\udd46\u789b\udab1\udd47\ud827\udc16\udaf5\udce7\udaa5\udf60",
        -3, 97322, -1191794751, 8719965182183995576L, 2693L, true, true, (char) 23762, (char) 62081,
        Double.longBitsToDouble(0x3fcf7f21de30e7a0L), Double.longBitsToDouble(0x3fecbaed7a022133L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 8, "\uda17\udc79\ud966\udd6a\uda52\uded7\ud9f7\udf42\udbd0\udc3f\uda03\udfc3\ud8d2\udd63\ud92e\udd17\ua29f\ud90a\ude29\ud95f\udeb4\ud94d\udecf\udb35\uddda\ud8d5\udf0c\ud848\udcaa\ub1c7\udb0f\udcdc\ud829\udc73\ud887\udc5d\udaea\udfb4", "\u9160\u391f\u119b\u9481\ub96d\u886c\ud1a1\u0c60\uc958\ucb0d", "\udbea\udd46\u789b\udab1\udd47\ud827\udc16\ud822\udc9d\uda40\udc88",
        57, 87703, -1495969087, 7137486333092497250L, 2693L, true, true, (char) 23762, (char) 12078,
        Double.longBitsToDouble(0x3fe9b7c8778c3918L), Double.longBitsToDouble(0x3fecbaed7dd65733L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 2, 15, 10, 8, "\uda17\udc79\ud8a1\udfe9\udbdc\udc31\ud9f7\udf42\ud8fd\uddf7\uda03\udff6\uda41\udd5b\ud92e\udd17\udb51\udd52\udb45\udebb\ud936\udfb4\ud94d\udecf\udb35\uddda\ud8d5\udf0c\ud848\udcaa\ub1c7\udb0f\udcdc\ud829\udc73\ud887\udc5d\udaea\udfb4", "\u9dac\u391f\u119b\u76ad\ub96d\u886c\ud1a1\u0c60\uc958\ua3f1", "\udbea\udd46\u789b\udab1\udd47\ud827\udc16\uda0a\uded1\uda51\udf04",
        8, 97322, -1191794751, 8719965182183995576L, 2693L, true, true, (char) 23762, (char) 62081,
        Double.longBitsToDouble(0x3fd23740ef1873d0L), Double.longBitsToDouble(0x3fecbaed7a022133L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 3, "\uda09\udf57\ud966\udd6a\uda64\uddd7\uda01\udf42\udbd0\udc3f", "\uc457\u82ee\u63b5\u90a8\uc090\u9a48", "\uaf04\udb0f\udcdc\ud829\udc73\ud887\udc5d\udae5\ude09\udbe5\udea5",
        0, 18699, -1767772946, -2833643749150101016L, 62795L, false, false, (char) 42850, (char) 8293,
        Double.longBitsToDouble(0x3fca9adf9833c6f4L), Double.longBitsToDouble(0x3fb66f7402d4e398L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 10, 8, "\uda17\udc79\ud966\udd6a\uda52\uded7\ud9f7\udf42\udbd0\udc3f\uda03\udfc3\uda41\udd5b\ud92e\udd17\ua29f\ud90a\ude29\ud936\udfb4\ud94d\udecf\udb35\udda9\ud8d5\udf0c\ud848\udcaa\ub1c7\udb0f\udcdc\ud829\udc73\ud887\udc5d\ud8be\ude11", "\u9dac\u391f\u119b\u76ad\ub96d\u27ae\u9ece\u0c60\uc958\ua3f1\u46f2\u976b\uaa08\ua952", "\uda0a\uded1\uda51\udf04\ud991\udeef\ud845\udd40\ud90a\udf91\udaa8\udd43\udbb6\udcd3",
        50, 8741, 179761193, -1674215180226131454L, -40094L, true, false, (char) 57613, (char) 21289,
        Double.longBitsToDouble(0x3fdfe4eb4a15fcbcL), Double.longBitsToDouble(0x3fa0a1e1aafa9ff0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 13, 7, "\uda17\udc79\ud966\udd6a\uda52\uded7\ud9f7\udf42\udbb9\udc3f\uda03\udfc3\uda41\udd5b\ud92e\udd17\ud815\uddb4\ud8d9\uddee\ud936\udfb4\ud94d\udecf\udb35\uddda\ud8d5\udf0c\ud848\udcaa\ub1c7\udb0f\udcdc\ud853\udc68\ud887\udc5d\udaea\udfb4", "\u9dac\ua757\u28e1\u76ad\ub96d\u886c\ud1a1\u0c60\u98a5\u4cf9", "\udbea\udd46\ud9ea\udc40\ud88f\udd80\udbf4\udf39\uda02\udff0\uda51\udf04\ud991\udeef\ud845\udd40\ud90a\udf91",
        36, 54200, 1913377170, -702120478677393639L, 28510L, false, false, (char) 22900, (char) 47430,
        Double.longBitsToDouble(0x3fe0110998077521L), Double.longBitsToDouble(0x3fe94d1a078364f8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 12, 8, "\ud9e8\udcc7\ud966\udd6a\uda52\uded7\ud9f7\udf42\udbd0\udc3f\uda03\udfc3\uda41\udd5b\ud92e\udd17\ua29f\ud90a\ude29\ud936\udfb4\ud94d\udecf\udb35\uddda\ud8d5\udf0c\ud848\udcaa\ub1c7\udb0f\udcdc\ud829\udc73\ud887\udc5d\udaea\udfb4", "\ud2da\u0576\u119b\u76ad", "\ud95d\udd74\uda5b\udfc9\udbbd\udf32\u70c6\ud9cc\udd7d",
        3, 75688, 1798236746, 5328850090095728095L, 40808L, false, false, (char) 61490, (char) 42370,
        Double.longBitsToDouble(0x3fe115c7b0b87903L), Double.longBitsToDouble(0x3fd9201d924ae416L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 6, 8, "\uda87\uddf8\udb1b\udfa5\uda52\uded7\ud9f7\udf42\udbd0\udc3f\ud9d2\uddd2\uda41\udd5b\ud90c\udcc5\u1f2f\ud90a\ude29\ud936\udfb4\ud94d\udecf\udb5a\udccc\ud809\udc56\ud848\udcaa\ub1c7\udb0f\udcdc\ud829\udc73\ud8f8\ude0c\udaea\udecf\ud830\udd2b\ud92d\udc87\ud34d\uda12\udd06\ud9fc\udcec\udb4a\udc7f\ud875\udd79\ud966\udca3\ud95d\udd74\uda5b\udfc9\udbbd\udf32\u70c6\ud9cc\udd7d\ud881\udd24\udbea\udd46\u789b\ud882\ude3d\ud827\udc16\uda0a\uded1\ud823\uddfc\ud991\udeef\uda6f\ude3e\ud900\udd21\udaa8\udd43\udbb6\udcd3\uda28\udc4a\udbfe\udc91\uda1b\ude62\ud991\udc4f\ud8b2\udd99\uda91\udc64\ud948\udcec\ud90f\uddf3\uda69\udc61\udab6\udecc\udaa6\ude5a\udbd1\udeb1\ud962\ude58\ud926\udcaf\udb8e\udd18\ud85b\udea9\udac9\udf6d\udaec\udd0c\ud84e\udc8a\udaf4\uddbd\ud996\udcf0", "\u93c2\ub7de\u1c9b\u8caf\u4822\ua086", "\ud86b\udc1d\udb3c\uddc5\ud923\udc1c\ud8f6\udfd7\ud978\ude71\ud815\udd17\uda10\udff6\ud96f\udd05\uda3c\uded2\u3011\udb4d\udf9f\udb06\udfd9\ud931\udd12\ud9fc\udc4f\ud906\ude55\ud9c2\udeb4\uda5d\udc74\udb7e\udd24\uda31\udd03\uda6e\udc21\udb59\udd51\udb38\udc7d\ud847\udc94\ud81e\udcf4\udb1e\udeb3\udb4b\udc18\ud9e6\udd8f",
        35, 82422, 1156886196, -7377689224031591652L, 78868L, false, false, (char) 44015, (char) 34999,
        Double.longBitsToDouble(0x3f82dde5d007ea00L), Double.longBitsToDouble(0x3fe9c43d703aec86L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 10, 8, "", "\u3ad9", "\uda03\udfc3\uda41\udd5b\ud92e\udd17",
        2, 58632, -363262725, 154581091791793246L, 98903L, true, true, (char) 51705, (char) 62223,
        Double.longBitsToDouble(0x3fe38cfa881cee81L), Double.longBitsToDouble(0x3fd514afd652cb18L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=[[[I:[[[[1, 0]]]] |a4=[[I:[[[55783, 56393, 55606, 56634, 55842, 56999, 55751, 57106]]] |a5=[[I:[[[54075, 14575, 43899, 7141, 10806, 34876, 6566, 3120]]]\0121=[[I:[[[]]]\012",
        Z.run(T, 2, 9, 10, 8, "\uda17\udc79\ud966\udd6a\uda52\uded7\ud9f7\udf42\udbb4\uddb5\uda03\udfc3\uda41\udd5b\ud92e\udd17\ua29f\ud9d3\udd83\ud938\udd9e\udb28\uded2\udb35\uddda\ud8d5\udf0c\udbe0\udff6\udbe9\udcb3\udb0f\udc0d\udbe1\ude00\ud813\udff9\uf4fc", "\ud36b\u391f\uabab\u1c15\u2a66\u886c\u19d6\u0c60\uc958\uc31e", "\udbc1\udca6\uda3c\udeb2\ud83e\udcfb\udac7\udf3a\udaf5\udce7\udb1f\udf5e\uda02\ude53\udbef\udf04\ud90a\udf91\udac1\ude49\udbb2\udc07\uda28\udc4a\udbfe\udc91\ud899\udf81\ud991\udc87\ud8b2\udd99",
        0, 95964, 557013911, -2167662975395949769L, 61976L, true, false, (char) 42849, (char) 51045,
        Double.longBitsToDouble(0x3fe2dd4ad29c4aa7L), Double.longBitsToDouble(0x3fe6622f7855e7d9L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 13, 13, "\ud9de\udc79", "\u0450\u65a0\u03c5", "\ua267\udbf2\udcbe\udb59\udf73\udb3d\udcbb\uda85\udd71\ud8cf\ude02\ud848\udcaa\ud976\udc95\udb0f\udcdc\udbe1\ude00\ud97a\udff5\ud967\udc0a\ud830\udd69\udb58\ude3d\ud34d\uda12\udd06\ud9fc\udcec\ud914\udd45\ud9e3\udcea\udae7\udf84\ud897\udf52\ud890\udf6d\udb9a\udecc\u70c6\ud9cc\udd7d\ud881\udd24\udbea\udd46",
        41, 34596, 2018808605, -7299321110566337138L, -26942L, true, true, (char) 17176, (char) 29115,
        Double.longBitsToDouble(0x3fd9201d924ae416L), Double.longBitsToDouble(0x3fe8cfb20dea06e8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 10, 8, "\000", "\u176a", "\u6b88\ud92e\udd17\ua29f\ud8d1\udf29\ud936\udfb4\ud94d\udecf\udb35\uddda",
        30, 72531, 5111808, 1375731712L, 83875L, true, false, (char) 16030, (char) 14414,
        Double.longBitsToDouble(0x3fe94b2c65136387L), Double.longBitsToDouble(0x3fa9dcc9b82032f0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=[[[I:[[[[1, 0, 0]]]]\0121=[[I:[[[]]]\012",
        Z.run(T, 2, 12, 10, 8, "\uda17\udc79\ud8a1\udfe9\udbdc\udc31\ud9f7\udf42\ud8fd\uddf7\uda03\udff6\udb72\udcad\ud946\udf75\udb51\udd52\udb45\udebb\ud936\udfb4\ud94d\udecf\udb35\uddda\ud8d5\udf0c\ud848\udcaa\ub1c7\udb0f\udcdc\ud823\udc70\ud887\udc5d\udaea\udfb4", "\u9dac\u391f\u119b\u76ad\ub96d\u886c\ud1a1\u0c60\uc958\ua3f1", "\udbea\udd46\u789b\udab1\udd47\ua760\uda7a\ude41\uda51\udf04",
        0, 97322, -1191794751, 8719965182183995576L, 2693L, true, true, (char) 31765, (char) 21535,
        Double.longBitsToDouble(0x3fd23740ef1873d0L), Double.longBitsToDouble(0x3fecbaed7a022133L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 1, 3, "\uda09\udf57\ud966\udd6a\uda64\uddd7\udb12\udcca\udbcf\udf7b", "\uc457\u82ee\u63b5\u90a8\uc090\u9a48", "\udbcd\udef4\uda80\udeea\ud829\udd18\ud887\udc5d\udae5\ude09\udbe5\udea5",
        0, 51619, -1768207754, -2833643749150101016L, 62795L, false, true, (char) 14984, (char) 8293,
        Double.longBitsToDouble(0x3fca7adf84663ef4L), Double.longBitsToDouble(0x3fb66f743ad4e398L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=[[I:[[[]]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 1, 3, "\uda09\udf57\ud966\udd6a\uda64\uddd7\uda01\udf42\udbd0\udc3f", "\uc457\u82ee\u63b5\u90a8\uc090\u9a48", "\uaf04\udb0f\udcdc\ud829\udc73\ud887\udc5d\udae5\ude09\udbe5\udea5",
        0, 18699, -1767772946, -2833643749150101016L, -85375L, false, true, (char) 29648, (char) 38857,
        Double.longBitsToDouble(0x3fb66f7402d4e398L), Double.longBitsToDouble(0x3fe88b18113342eeL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 1, 3, "\uda09\udf57\ud966\udd6a\uda64\uddd7\uda01\udf42\udbd0\udc3f", "\uc457\u82ee\u63b5\u90a8\uc090\u9a48", "\uaf04\udb0f\udcdc\ud829\udc73\ud887\udc5d\udae5\ude09\udbe5\udea5",
        0, 18699, -1767772946, -2833643749150101016L, 62795L, false, false, (char) 42850, (char) 8293,
        Double.longBitsToDouble(0x3fca9adf9833c6f4L), Double.longBitsToDouble(0x3fb66f741584e398L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 1, 3, "\uda09\udf57\ud966\udd6a\uda64\uddd7\ud9f1\udfd8\udbd0\udc3f", "\uc457\u82ee\u63b5\u90a8\uc090\u9a48", "\uaf04\udac8\udfe3\ud829\udc73\ud887\udc5d\udae5\ude09\udbe5\udea5",
        0, 18699, 238, -2833890065524526616L, -100000L, false, false, (char) 42785, (char) 8293,
        Double.longBitsToDouble(0x3fca9adf9833c6f4L), Double.longBitsToDouble(0x3fb66f7402d4e398L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[I:[[0]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 1, 3, "\uda09\udf57\ud966\udd6a\uda64\uddd7\uda01\udf42\udbd0\udc3f", "\uc457\u82ee\u63b5\u771a\uc090\u9a48", "\uaf04\udb0f\udcdc\ud0bb\ud887\udc5d\udae5\ude09\udbe5\udea5",
        0, 18699, -643699474, -2833643465682259480L, 62631L, false, false, (char) 42850, (char) 8293,
        Double.longBitsToDouble(0x3fe6a6b7e60c97a4L), Double.longBitsToDouble(0x3fb66f7402d4e398L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[I:[[0]]\0121=void |a0=[D:[[27884.5, 28563.5, 27803.0, 28317.0, 27930.0, 28371.5, 27880.5, 28553.0]] |a2=[D:[[25107.5, 16735.0, 12738.5, 18492.0, 24624.0, 19724.0]] |a3=[D:[[25107.5, 28015.5, 28246.0, 27644.5, 28193.5, 27691.5, 28182.5, 27994.5]] |this=org.apache.commons.math3.analysis.differentiation.DSCompiler:@?\012",
        Z.run(T, 2, 11, 14, 3, "\uda09\udf57\ud966\udd6a\uda64\uddd7\uda01\udf42\udbd0\udc3f", "\uc457\u82ee\u63b5\u90a8\uc090\u9a48", "\uaf8f\udb0f\udcdc\ud829\udc73\ud887\udc5d\udae5\ude09\udbe5\udea5",
        0, 18699, 62130616, -4398252592226438680L, 62795L, false, false, (char) 42850, (char) 8293,
        Double.longBitsToDouble(0x3fcba37f9833c5b8L), Double.longBitsToDouble(0x3fb66f741b77c240L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[[[I:[[[[1, 0]]]] |a4=[[I:[[[55769, 57127, 55606, 56634, 55860, 56743, 55761, 57106]]] |a5=[[I:[[[50159, 33470, 25477, 36984, 49248, 39448]]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 1, 3, "\uda09\udf57\ud966\udd6a\uda64\uddd7\uda01\udf42\udbd0\udc3f", "\uc41f\u82ee\u63b5\u90a8\uc090\u9a48", "\uaf04\udb0f\udcdc\ud829\udc73\ud887\udc5d\udae5\ude09\udbe5\udea5",
        0, 18699, -1767772946, -2833643749150101016L, 62795L, false, false, (char) 42850, (char) 8293,
        Double.longBitsToDouble(0x3fca9adf9833c6f4L), Double.longBitsToDouble(0x3fb66f7402d4e398L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |a0=[D:[[27884.5, 28563.5, 27889.5, 28625.0, 27961.0, 28376.0, 27880.5, 28553.0]] |a2=[D:[[25107.5, 16735.0, 12738.5, 18492.0, 24624.0, 19724.0]] |a3=[D:[[25107.5, 28015.5, 28246.0, 27644.5, 28193.5, 27691.5, 28182.5, 27994.5]] |this=org.apache.commons.math3.analysis.differentiation.DSCompiler:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 1, 3, "\uda09\udf57\uda13\udfd2\udaa2\udde0\uda01\udf42\udbd0\udc3f", "\uc457\u82ee\u63b5\u90a8\uc090\u9a48", "\u74f9\udb0f\udcdc\ud829\udc73\ud887\udc5d\udae5\ude09\udbe5\udea5",
        0, 18699, 1970862252, -2833877945126817304L, -48053L, true, false, (char) 22503, (char) 8293,
        Double.longBitsToDouble(0x3fca9adf9cb7c6f4L), Double.longBitsToDouble(0x3fc66bef216a7108L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[I:[[0]]\0121=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 2, 11, 1, 3, "\uda09\udf57\ud966\udd6a\uda64\uddd7\uda01\udf42\udbd0\udc3f", "\uc457\u82ee\u63b5\ud50c\u3340\u46b7", "\uaf04\ud835\udfcf\ud9f8\udc5a\udb95\udd1a\udae5\ude09\udbe5\udea5\udbb9\udd5b\ud808\udceb\ud948\udfb8\udad5\uddb4\ud9fa\udda2\udb77\udc80\uda24\udd15\udb81\udcfd\udb15\ude6f\ud8c6\ude8a\udb78\udffc\ud944\udc62",
        29, -436, -1795871625, 7446152028270299714L, -66804L, false, true, (char) 26011, (char) 15771,
        Double.longBitsToDouble(0x3fcd67c68a4051bcL), Double.longBitsToDouble(0x3fef5129749cec3cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[[I:[[[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, ...\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 1, 3, "\uda09\udf57\ud966\udd6a\uda64\uddd7\uda01\udf42\udbd0\udc3f", "\u96b6\u82ee\u63b5\u90a8\uc090\u9a48", "\ud9f9\ude02\udb0f\udcdc\ud829\udc73\ud887\udc5d\udae5\ude09\udb4f\udca7",
        0, 18699, -1767772946, -2833643749150101016L, 62795L, false, false, (char) 42850, (char) 8293,
        Double.longBitsToDouble(0x3fca9adf9833c6f4L), Double.longBitsToDouble(0x3fb66f7402d4e398L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=[[[I:[[[[1, 0]]]] |a4=[[I:[[[55783, 56393, 55606, 56634, 55842, 56999, 55751, 57106]]] |a5=[[I:[[[54075, 14575, 43899, 7141, 10806, 34876, 6566, 3120]]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 0, 8, "\uda17\udc79\ud966\udd6a\uda52\uded7\ud9f7\udf42\udbb4\uddb5\uda03\udfc3\uda41\udd5b\ud92e\udd17\ua29f\ud9d3\udd83\ud938\udd9e\udb28\uded2\udb35\uddda\ud8d5\udf0c\udbe0\udff6\udbe9\udcb3\udb0f\udc0d\udbe1\ude00\ud813\udff9\uf4fc", "\ud36b\u391f\uabab\u1c15\u2a66\u886c\u19d6\u0c60\uc958\u6c9a", "\udbc1\udca6\uda3c\udeb2\ud83e\udcfb\udac7\udf3a\u00e0\000\uda02\ude30\udbef\udf04\ud90a\udf91\udac1\ude49\udbb2\udc07\uda28\udc4a\udbfe\udc91\ud899\udf81\ud991\udc87\ud8b2\udd99",
        0, 95964, 557013911, -2167662975395949769L, 61976L, true, false, (char) 42849, (char) 51045,
        Double.longBitsToDouble(0x3fe2dd4ad29c4aa7L), Double.longBitsToDouble(0x3fe6622f7855e7d9L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=[[[I:[[[[1, 0]]]] |a4=[[I:[[[55783, 56393, 55606, 56634, 55842, 56999, 55751, 57106]]] |a5=[[I:[[[54075, 14575, 43899, 42980, 10806, 9108, 6566, 3120]]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 3, 8, "\uda17\udc79\ud966\udd6a\uda52\uded7\ud9f7\udf42\udbb4\uddb5\ud9d9\udfaa\uda41\udd5b\udb0f\ude2e\ua29f\udad0\udfe1\udb7b\udf68\udb26\udc30\udb35\uddda\ud8d5\udf0c\uda95\ude10\udbe9\udcbb\udb0f\udc0d\udbe1\ude00\ud813\udff9\uf4fc", "\ud36b\u391f\uabab\ua814\u2a66\u23c4\u19d6\u0c60\u3b58\uc31e", "\udbc1\udca6\uda3c\udeb2\ud83e\udcfb\udac7\udf3a\udaf5\udce7\udb1f\udf5e\uda02\ude53\udbef\udf04\ud90a\udf91\udac1\ude49\udbb2\udc07\uda28\udc4a\udbfe\udc91\ud899\udf81\ud991\udc87\ud8b2\udd99",
        0, 95964, 557013911, -2167662975395949769L, 61976L, true, false, (char) 42849, (char) 51045,
        Double.longBitsToDouble(0x3fe2dd4ad29c4aa7L), Double.longBitsToDouble(0x3fe6622f7855e7d9L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=[[[I:[[[[1, 0]]]] |a4=[[I:[[[55783, 56393, 55606, 56634, 55842, 56999, 55751, 57106]]]\0121=[[I:[[[]]]\012",
        Z.run(T, 2, 9, 10, 8, "\uda17\udc79\ud966\udd6a\uda52\uded7\ud9f7\udf42\udbb4\uddb5\uda03\udfc3\uda41\udd5b\ud92e\udd17\ua29f\ud9d3\udd83\ud938\udd9e\udb28\uded2\udb35\uddda\ud8d5\udf0c\udbe0\udff6\udbe9\udcb3\udb0f\udc0d\udbe1\ude00\ud813\udff9\uf4fc", "\ud36b\u391f\uabab\u1c15\u2a66\u886c\ubbfb\u5262\uc8d0\uc31e", "\udbc1\udca6\uda3c\udeb2\ud83e\udcfb\udac7\udf3a\udaf5\udce7\udb1f\udf5e\uda02\ude53\udbef\udf04\ud90a\udf91\udac1\ude49\udb80\ude03\uda28\udc4a\udbfe\udc91\ud899\udf81\ud991\udc87\ud8b2\udd99",
        0, 95964, -1954733417, -2167662975395949769L, 61976L, true, false, (char) 42849, (char) 51045,
        Double.longBitsToDouble(0x3fe2dd4ad29c4aa7L), Double.longBitsToDouble(0x3fe6622f7855e7d9L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=[[[I:[[[[1, 0]]]] |a4=[[I:[[[55783, 56393, 55606, 56634, 55842, 56999, 55751, 57106]]] |a5=[[I:[[[39648, 14575, 43899, 7141, 10806, 34876, 6566, 3120]]]\0121=[[[I:[[[[1, 0]]]] |a4=[[I:[[[55783, 56393, 55606, 56634, 55842, 56999, 55751, 57106]]] |a5=[[I:[[[39648, 14575, 43899, 7141, 10806, 34876, 6566, 3120]]]\012",
        Z.run(T, 2, 9, 9, 8, "\uda17\udc79\ud966\udd6a\uda52\uded7\ud9f7\udf42\udbb4\uddb5\uda03\udfc3\uda41\udd5b\ud92e\udced\ua29f\ud9d3\udd83\ud938\udd9e\udb28\uded2\udb35\uddda\ud909\udf06\udbe0\udff6\ud86a\udef3\ud92c\udc8a\udbe1\ude56\ud813\udff9\uf4fc", "\u9b10\u391f\uabab\u1c15\u2a66\u886c\u19d6\u0c60\uc958\uc31e", "\udbc1\udca6\uda3c\udeb2\ud83e\udcfb\udac7\udf3a\udaf5\udce7\udb1f\udf5e\uda02\ude53\udbef\udf04\ud90a\udf91\udac1\ude49\udbb2\udc07\uda28\udc4a\udbfe\udc91\ud899\udf81\ud991\udc87\ud8b2\udd99",
        0, 95964, 557013911, -2167662975395949769L, 61976L, true, false, (char) 42849, (char) 51045,
        Double.longBitsToDouble(0x3fe2dd4ad29c4aa7L), Double.longBitsToDouble(0x3fe6622f7855e7d9L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=[[[I:[[[[1, 0, 0]]]] |a4=[I:[[55576, 56750, 55606, 56634, 55842, 56999, 55965, 56768]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 8, "\ud948\uddde\ud966\udd6a\uda52\uded7\udacd\uddf0\udbb4\uddd6\uda03\udfc3\uda41\udd5b\ud92e\udd17\ua29f\ud9d3\udd83\ud938\udd9e\udb28\uded2\udb35\uddda\udabb\udf1e\udbe1\udc44\udbe9\udcb3\udabe\udf80\udad8\udc3e\ud813\udff9\uf4fc", "\ud36b\u391f\uabab\u1c15\u2a66\u886c\u19d6\u0c60\uc958\uc31e", "\ud8c5\udca8\uda3c\udeb2\ud83e\udcfb\udac7\udf3a\udaf5\udce7\udb1f\udf5e\uda02\ude53\udac3\udf0d\ud90a\udf91\ud8eb\uddfe\udba4\udd45\uda28\udc4a\u7aa2\ud8d0\udf7f\ud8d0\udef9\ud8b2\udd99",
        0, 95964, 557013911, -2167662975394811081L, 25163L, false, false, (char) 22113, (char) 51045,
        Double.longBitsToDouble(0x3fe2dd4ad29c4aa7L), Double.longBitsToDouble(0x3fe6622f7855e7d9L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[[[I:[[[[1, 0, 0]]]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 0, 8, "\uda17\udc79\udb23\udde1\udbdc\udc31\ud9f7\udf42\ud8fd\uddf7\ud2af\udb72\udc25\ud946\udf75\udb51\udd52\udb45\udebb\ud936\udfb4\u00af\udb35\udd7c\ud8d5\udf0c\ud848\udcaa\ub1c7\u08f7\uda81\udf3f\ud887\udc5d\udaea\udfb4", "\u9dac\u391f\u119b\u76ad}\u87a2\ud1a1\u0c60\uc958\ua3f1", "\000\000\000\ua681\uda7a\ude41\uda51\udf04",
        0, 97322, -1191794751, 8719965182183995576L, 2693L, true, true, (char) 232, (char) 21535,
        Double.longBitsToDouble(0x3fd23740ef1873d0L), Double.longBitsToDouble(0x3fecbaed7a022133L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|atan2|[D,int,[D,int,[D,int|new:org.apache.commons.math3.analysis.differentiation.DSCompiler:int,int,org.apache.commons.math3.analysis.differentiation.DSCompiler,org.apache.commons.math3.analysis.differentiation.DSCompiler",
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|acos|[D,int,[D,int|new:org.apache.commons.math3.analysis.differentiation.DSCompiler:int,int,org.apache.commons.math3.analysis.differentiation.DSCompiler,org.apache.commons.math3.analysis.differentiation.DSCompiler",
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|acosh|[D,int,[D,int|new:org.apache.commons.math3.analysis.differentiation.DSCompiler:int,int,org.apache.commons.math3.analysis.differentiation.DSCompiler,org.apache.commons.math3.analysis.differentiation.DSCompiler",
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|add|[D,int,[D,int,[D,int|new:org.apache.commons.math3.analysis.differentiation.DSCompiler:int,int,org.apache.commons.math3.analysis.differentiation.DSCompiler,org.apache.commons.math3.analysis.differentiation.DSCompiler",
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|asin|[D,int,[D,int|new:org.apache.commons.math3.analysis.differentiation.DSCompiler:int,int,org.apache.commons.math3.analysis.differentiation.DSCompiler,org.apache.commons.math3.analysis.differentiation.DSCompiler",
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|asinh|[D,int,[D,int|new:org.apache.commons.math3.analysis.differentiation.DSCompiler:int,int,org.apache.commons.math3.analysis.differentiation.DSCompiler,org.apache.commons.math3.analysis.differentiation.DSCompiler",
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|atan|[D,int,[D,int|new:org.apache.commons.math3.analysis.differentiation.DSCompiler:int,int,org.apache.commons.math3.analysis.differentiation.DSCompiler,org.apache.commons.math3.analysis.differentiation.DSCompiler",
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|atanh|[D,int,[D,int|new:org.apache.commons.math3.analysis.differentiation.DSCompiler:int,int,org.apache.commons.math3.analysis.differentiation.DSCompiler,org.apache.commons.math3.analysis.differentiation.DSCompiler",
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|checkCompatibility|org.apache.commons.math3.analysis.differentiation.DSCompiler|new:org.apache.commons.math3.analysis.differentiation.DSCompiler:int,int,org.apache.commons.math3.analysis.differentiation.DSCompiler,org.apache.commons.math3.analysis.differentiation.DSCompiler",
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|compileCompositionIndirection|int,int,org.apache.commons.math3.analysis.differentiation.DSCompiler,org.apache.commons.math3.analysis.differentiation.DSCompiler,[[I,[[I|static",
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|compileDerivativesIndirection|int,int,org.apache.commons.math3.analysis.differentiation.DSCompiler,org.apache.commons.math3.analysis.differentiation.DSCompiler|static",
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|compileLowerIndirection|int,int,org.apache.commons.math3.analysis.differentiation.DSCompiler,org.apache.commons.math3.analysis.differentiation.DSCompiler|static",
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|compileMultiplicationIndirection|int,int,org.apache.commons.math3.analysis.differentiation.DSCompiler,org.apache.commons.math3.analysis.differentiation.DSCompiler,[I|static",
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|compileSizes|int,int,org.apache.commons.math3.analysis.differentiation.DSCompiler|static",
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|compose|[D,int,[D,[D,int|new:org.apache.commons.math3.analysis.differentiation.DSCompiler:int,int,org.apache.commons.math3.analysis.differentiation.DSCompiler,org.apache.commons.math3.analysis.differentiation.DSCompiler",
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|convertIndex|int,int,[[I,int,int,[[I|static",
    "M|org.apache.commons.math3.analysis.differentiation.DSCompiler|atan2|[D,int,[D,int,[D,int|new:org.apache.commons.math3.analysis.differentiation.DSCompiler:int,int,org.apache.commons.math3.analysis.differentiation.DSCompiler,org.apache.commons.math3.analysis.differentiation.DSCompiler",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
