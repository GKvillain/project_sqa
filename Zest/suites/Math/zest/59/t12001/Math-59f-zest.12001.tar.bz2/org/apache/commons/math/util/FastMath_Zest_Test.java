package org.apache.commons.math.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class FastMath_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Double:0.3994709185673331\012",
        Z.run(T, 1, 15, 12, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\u130e\u1f2c\u4194\ub06f\u52a7\u999e\u5593\ubf4f\u08b6\u05bb\u23d6\u8de8\u1c74\u99dc\uc62f\u23b7\uc5fa\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\ud873\udeba\ud976\udf5e\ud865\ude2f\ud84c\udf76",
        57, 24292, -943806576, 7920996059916774813L, 26777L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fd849aa4c5c1e80L), Double.longBitsToDouble(0x3fe46cea3cdf7342L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Double:0.3994709185673331\012",
        Z.run(T, 1, 15, 12, 9, "\uda17\ude56\udb24\udd4e\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfae", "\u2e36\u130e\u1f2c\u4194\ub06f\u52a7\u999e\u5593\ubf4f\u08b6\u05bb\u23d6\u8de8\u2f53\u99dc\uc62f\u23b7\u9e9f\u6272", "\udbae\ude8a\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\ud873\udeba\ud976\udf5e\ud865\ude2f\ud84c\udf76",
        57, 24292, -943806576, 7920996059916774813L, 26777L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fd849aa4c5c1e80L), Double.longBitsToDouble(0x3fe46cea3cdf7342L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Double:0.2918722813084857\012",
        Z.run(T, 1, 15, 12, 9, "\uda17\ude56\ud878\ude78\ud81c\udf94\udb8b\udff4\udb41\uddfd\uc68b\uda4d\udca3\udacc\udd26\ud95a\udf82\uda56\udf88\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd61\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udaf1\udf2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\u130e\u3b2c\u4194\ub052\u52a7\u999e\u33f4\u08f1\u08b6\u05bb\u23d6\u8de8\u1c74\u99dc\uc62f\u4c03\u9ad8\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\ud873\udeba\ud976\udf5e\ud865\ude2f\ud84c\udf76",
        42, 24292, -943806576, 7920996059916774813L, 26777L, true, true, (char) 40476, (char) 8957,
        Double.longBitsToDouble(0x3fd22ab72c5c1e80L), Double.longBitsToDouble(0x3fdff703c9bee722L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Double:0.8879069178122146\012",
        Z.run(T, 1, 16, 12, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\ud97e\udd0f\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\uda18\udce7\udb0f\udf28\ud956\udf03\u2319\udbde\udd33\udb24\udd2f\udae3\uded1\ud89a\udffa", "\ua822\ua73d\u3047\u41df\ub06f\u52a7\u999e\u5593\ubf4f\u08bf\u05bb\u23d6\u8de8\u1c74", "\ud81c\udcc6\udac9\udc11\ud886\udd38\ud971\udd88\udb58\udefd\udbae\ude8a\ud9cc\ude23\uda27\udf34\uda9f\uddec\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\ud9fc\ude16\udbff\ude00\ud873\udeba\ud976\udf5e\ud865\ude2f\ud84c\udf76\ud921\udec1\ud9d9\udc3d\ud909\udc3f\ud979\ude6d\ud93b\uddc4\udbfb\ude78\ud884\udec6\udad9\udd5d\udac7\ude6d\udb5a\udf60\ud844\ude6a\uda8e\udc5c\udb7b\udd57\ud99c\udfc7\udb50\uded1\ud90f\udea1\udb84\udc3d\udbb6\udee5\ud904\udc07\udb61\udc8e\uda46\uddd0",
        58, 26835, 18200266, -4633939172214018814L, 95798L, true, false, (char) 32581, (char) 23986,
        Double.longBitsToDouble(0x3fd2920e46c0b7daL), Double.longBitsToDouble(0x3fec69bbc4bca8efL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Double:1.4724072238133044\012",
        Z.run(T, 1, 15, 12, 12, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a", "\u1d4c\u3080\ub8c9\u38cf\u5a09\uc508\u1174\uc503\u31a2\uba18\ua1aa\ud0ac\u8758\ub9ad\u8195\ubbab\u2e57\u130e\u1f2c\u4194\ub06f", "\udbb5\udc2a\uda55\ude40\ud8cb\udd83",
        13, 35042, 1597895943, 1616627188821223847L, -92181L, false, false, (char) 37656, (char) 3778,
        Double.longBitsToDouble(0x3feccd17977bd580L), Double.longBitsToDouble(0x3fd48ac3660aabc4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Double:0.9863196397761299\012",
        Z.run(T, 1, 8, 6, 17, "\uda17\ude56\ud878\ude78\udb3a\udee2\udaf4\udf41\ud964\ude84\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\uda0d\udee9\ud89d\udf05\ud94c\udc20\udbdf\udea6\ud95e\udc0d", "\u8195\ubb10\u2e57\u130e\u1f2c", "\uda7f\udc45\ud97e\udd3c\udbb5\udc2a",
        -5, 1602, -1742125245, -4584471983055571705L, 9240L, true, true, (char) 46726, (char) 45820,
        Double.longBitsToDouble(0x3fe1a80ae8bd1f2cL), Double.longBitsToDouble(0x3fd1ce0149f0616aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Long:7920996059916774813\012",
        Z.run(T, 1, 3, 12, 9, "\udb99\udd37\udaa2\udeb7\udb3a\ude5a\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\u130e\u1f2c\u4194\ub06f\u52a7\u999e\u5593\ubf4f\u08b6\u05bb\u23d6\u8de8\u1c74\u99dc\uc62f\u23b7\uc5fa\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\ud873\udeba\ud976\udf5e\ud865\ude2f\ud84c\udf76",
        57, 24292, -943806576, 7920996059916774813L, 26777L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fd849aa4c5c1e80L), Double.longBitsToDouble(0x3fe46cea3cdf7342L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Float:0.37949616\012",
        Z.run(T, 1, 5, 3, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\u60a5\u1f2c\u9818\u9775\u52a7\u999e\u5593\ubf4f\u08b6\u05bb\u23d6\u8de8\u1c74\u99dc\uc62f\u23b7\uc5fa\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\ud873\udeba\ud976\udf5e\ud865\ude2f\ud84c\udf76",
        47, 24239, -943806576, 7920996059916774813L, 26777L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fd849aa4c5c1e80L), Double.longBitsToDouble(0x3fe46cea3cdf7342L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:0.9381386023889585\012",
        Z.run(T, 1, 12, 11, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\udab9\udfd0\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udba1\udf49\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\ubf3a\ud259\u1f2c\u4194\u73d7", "\udb33\udd2e",
        -5, 90440, 1891698712, -4584471738242435833L, 55303L, false, false, (char) 33800, (char) 16742,
        Double.longBitsToDouble(0x3fe79f6a6fa736e0L), Double.longBitsToDouble(0x3feccd17977bd580L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Double:0.6382952870295429\0121=java.lang.Double:-2.40532455595899\012",
        Z.run(T, 2, 0, 12, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\ud9ff\udc9d\ud89d\udde0\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\ud5b9\u821b\u4194\ub06f\u52a7\u999e\u5593\u4e6c\u7d18\u05a7\u23d6\u8de8\u1c74\u99dc\uc62f\u23b7\uc5fa\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\ud873\udeba\ud976\udf5e\ud865\ude2f\ud84c\udf76",
        57, 24292, -943806576, 7920996059916774813L, 26777L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fd849aa4c5c1e80L), Double.longBitsToDouble(0x3fe46cea3cdf7342L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:24375\012",
        Z.run(T, 1, 2, 12, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\uda2b\udff7\ud830\udc2c\uda4d\udc1d\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda80\udf12\uda82\udc0b\ud926\udc0a\udbbc\udd30\ud874\ude5e\ud96e\udf9e\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\u130e\u1f2c\u79c2\ub06f\u7589\u64ee\u5593\ubf4f\u9c21\u53d7\u23d6\u8de8\u1c74\u99dc\uc62f\u23b7\uc5fa\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1\ud860\udf25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud827\udc8d\ud873\uddff\ud976\udf5e\ud865\ude2f\ud84c\udf76",
        57, 24375, -943806576, -3786741191595545187L, 26777L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fd849aa43d6ddc0L), Double.longBitsToDouble(0x3fe46cea3cdf7342L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Double:6.97001927712763E-4\012",
        Z.run(T, 1, 15, 12, 9, "\uc1e3\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\udb4d\ude95\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\u130e\u1f2c\u4194\ub06f\u52a7\u999e\u5593\ubf4f\u08b6\u05bb\u23d6\u8de8\u8b73\u99dc\uc62f\u23b7\uc5fa\u52b4", "\udbae\ude8a",
        48, 40141, 1802811344, 98313416836127285L, 73796L, false, false, (char) 45496, (char) 12955,
        Double.longBitsToDouble(0x3f46d6e000000000L), Double.longBitsToDouble(0x3fb64000356146d0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Double:0.0876466343313656\012",
        Z.run(T, 1, 15, 12, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\u00ca\ucf5a\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\ude97\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\u130e\u1f2c\u4194\ub06f\u52a7\u999e\u5593\ubf4f\u08b6\u05bb\u23d6\u8de8\u1c74\u99dc\uc62f\u23b7\uc5fa\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1",
        4, 63376, 522983989, -2300036775253026532L, -22651L, false, true, (char) 50102, (char) 5849,
        Double.longBitsToDouble(0x3fb66158b56146d0L), Double.longBitsToDouble(0x3fec81c4eff3c7beL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:57\012",
        Z.run(T, 1, 6, 8, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udbe8\udd04\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\udac3\uddfe", "\u994e\u130e\u1f2c\u4194\ub06f\u52a7\u999e\u5593\ubf4f\u08b6\u05bb\u23d6\u8de8\u1c74\uc38d\u08f6\u53bf\u993d\u9b0b", "\udb5d\udee0\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\ud873\udeba\ud976\udf5e\ud865\ude2f\ud84c\udf76",
        57, 24292, -943806576, 7920996059916774813L, 26777L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fd849aa4c5c1e80L), Double.longBitsToDouble(0x3fe46cea3cdf7342L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:0.3892516669105632\012",
        Z.run(T, 1, 10, 12, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8e2\udf86\uda62\udf9d\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\u130e\u1f2c\ud56d\u4d89\u52a7\u999e\u5593\ubf4f\u08b6\u05bb\ud2b4\ua21a\u1c7f\u99dc\uc62f\u23b7\uc5fa\u52b4", "\ud996\udf2b\udab5\udf46\u831f\ud85b\ude0c\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\udb36\udd33\ud99a\uddc8\ud865\ude2f\ud84c\udf76",
        57, 24292, -943806576, 7920996058290448285L, 26777L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fd849aa4c5c1e80L), Double.longBitsToDouble(0x3fe46cea3cdf7342L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Double:0.08012734893185924\012",
        Z.run(T, 1, 15, 12, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\ud93d\udf28\uda56\udfd8\udb34\udcaa\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\udac5\ude17\uda3d\ude72\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\u130e\u1f2c\u4194\ub06f\u52a7\u999e\u5593\ubf4f\u08b6\u05bb\u23d6\u8de8\u1c74\u99dc\ud6c7\u23b7\uc5fa\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\ud873\udeba\ud976\udf5e\ud865\ude2f\ud84c\udf76",
        57, 47564, -943806579, 7920996059916774813L, 26777L, true, true, (char) 40476, (char) 28380,
        Double.longBitsToDouble(0x3fb4780433e3d480L), Double.longBitsToDouble(0x3fe46cea3cdf7342L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Double:0.023690018776749994\012",
        Z.run(T, 1, 15, 12, 18, "\ud966\udebd\ud878\ude78\udb3a\udee2\uda66\udc50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\udba0\udfdd\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55", "\uc508\u26b4\uc503\u31a2", "\udb24\udd2f\uda7b\udf5c\ud82a\ude7c\uda7b\udf4c\udb7a\udd97",
        48, 32842, 317677755, 4688603961554641325L, 80309L, false, true, (char) 19438, (char) 1822,
        Double.longBitsToDouble(0x3f984108e7ce1820L), Double.longBitsToDouble(0x3fd07c0603babe7aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Long:3502543099652706245\012",
        Z.run(T, 1, 7, 12, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\udba4\udecf\ud902\udfff\udb52\udc27\ud80f\ude34\udb34\udd32\ud86d\udd7e\uda1e\udeeb\udb73\udcc6\uda99\uded7\ud914\ude76\ud8cf\uddca\ud80a\udeba\uda85\udf4c\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\uda41\udec0\ud9a8\udccc", "\ubb34\uabe5\u1f2c\u4194\ub06f\u5768\u99e8\u5593\u6a3e\u2ef2\u1a95\u6c23\u8de8\u1c74\u99dc\uc62f\u23b7\uc5fa\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\ud873\udeba",
        13, 85623, 1544028848, -3502543099652706245L, 94573L, true, true, (char) 13628, (char) 51776,
        Double.longBitsToDouble(0x3fd1121e2ddfc2c6L), Double.longBitsToDouble(0x3fd4685ce937e348L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Long:7920996059916774813\012",
        Z.run(T, 1, 7, 11, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\ucd20\u06b4\u1f2c\u4fcc\u4c7c\u2492\ud2c4\u562e\ubf4f\u08b6\u05bb\u23d6\u8de8\u1c74\u99dc\uc62f\u23b7\uc5fa\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\udab1\ude21\udb54\udffa\ud8b2\udf13\ud873\udeba\ud976\udf5e\udaaf\ude34\ud84c\udf76",
        57, 24292, -943806576, 7920996059916774813L, 26777L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fd849aa4c5c1e80L), Double.longBitsToDouble(0x3fc1b3a8f0aade04L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 9, 12, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\uda49\ude27\ud90e\udc6f\uda90\udc82\ud941\udc2a\udb52\udc92\uda56\udfd8\udb34\udd0a\ud9c2\udec7\uda1e\udeeb\ud84b\udd5b\uda85\udd78\ud8be\udfe0\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\uf138\ud946\udca1\ud921\udf3c\ud876\udee4\uda25\udd4c", "\u2e57\uaf1b\u1f2c\u4194\ub06f\u8e2e\u999e\u662d\ubf4f\u08b6\u05bb\u23d6\u8de8\u1c74\u99dc\u29bf\u6dcf\u8235\u0c60", "\udbae\ude8a\udab6\ude57\uda39\udf46\ud838\udd05\uda3b\udf9c\ud8f5\udc0b\ud81a\udd55\ud87a\udc2c\u7c68\udaf8\uddb6\ud94e\udea3\ud9cd\udf6f\ud9c2\udee2\uda96\udfaf\udbae\udce4\ud8fe\udec3\ud979\ude6d\ud93b\uddc4\udbfb\ude78\ud884\udec6\ud8e6\udcf8\ud873\udfa0\ud8da\ude0e\udbd9\udf95\udbf7\udfd7\ud9b1\udff0\ud981\udf39\ud8d9\udd60\u2053\ud9e2\udc4f\ud89f\udd2c\ud8c5\udd9f\udaa4\udc58\ud821\udf70\ud948\udf2f\ue0be\ud8ae\uded9\udb0d\ude84\ud882\udf36\udb22\udc48\udbff\udc9b\ud90d\udebf",
        40, 91509, 202820621, -5934021114450407185L, 83164L, true, false, (char) 7398, (char) 1302,
        Double.longBitsToDouble(0x3fe5654895193375L), Double.longBitsToDouble(0x3fe77d61a5ed3f46L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Float:0.248703\012",
        Z.run(T, 1, 17, 5, 1, "\uda17\ude56\ud86b\uddb2\uda21\uddea\uda52\udf57\ud963\udd54\udbd4\udfd5\uda4d\udca3\ud940\udfa0\ud9fe\udf01\udabd\udcd0\udad3\udc7a\ud89c\udcd4\ua248\ud97c\uddc0\uda85\udd78\ud887\udf38\ud82c\udfb8\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30", "\ua1aa\u37d5\u8758\ub9ad\u5ce4\ubb10\u2e57\u130e\u1f2c\u4194\ub06f\u52a7\u999e\u8ff2\ubf4f\uac05\u05bb\u23d6\u8de8\u1c74\u99dc\uc62f\u23b7\u3ebd\u52b4\ud654\u6d3a\u842c\ud73e\ub97e", "\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\ud873\udeba\ud976\udf5e\ud9c2\ude3e\udae8\udd26\uda4e\udfdf\uda5d\udea7\ud906\ude3d\ud97f\udd1a\ud93b\uddc4\udbfb\ude78\ud884\udec6\ud8ec\udc66\udab5\udc92\udb5a\udf60\ud844\ude6a",
        14, 95709, -203004207, 4929104473381597847L, -85790L, true, false, (char) 22419, (char) 9604,
        Double.longBitsToDouble(0x3fcc7b657dd660d4L), Double.longBitsToDouble(0x3fcfd5800996ae00L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Double:0.3627066782516655\012",
        Z.run(T, 1, 13, 12, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\ud968\udf31\uda62\udc63\ud805\udc52\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udb04\ude15\ud88b\uddc9\ud94c\udc20\udbb4\ude6f\ud904\udd83\ud9bc\udd1d\ud817\udfc7", "\u2e57\u130e\u1f2c\u4194\u4770\u52a7\u999e\u5593\ubf4f\u08b6\u05bb\u23d6\u8de8\u1c74\u99dc\uc62f\u23b7\uc5fa\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\ud873\udeba\ud976\udf5e\uda8f\udfe4\ud98f\ude95",
        51, 24131, -943806576, 7921214862730702237L, 26777L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fd849aa4c5c1e80L), Double.longBitsToDouble(0x3fe46cea3cdf7342L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Double:0.37805111105388867\012",
        Z.run(T, 1, 4, 15, 7, "\uda17\ude56\ud878\ude78", "\u601a", "\ud940\udfa0\udb52\udc92\uda53\ude76\udb56\udc5f\ud86d\udd7e",
        10, 93998, 829686358, -6227149606501092468L, 41964L, true, false, (char) 54532, (char) 61051,
        Double.longBitsToDouble(0x3fd831fd498c58bcL), Double.longBitsToDouble(0x3fae31108fd84080L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Long:85093\012",
        Z.run(T, 1, 3, 5, 5, "\u6cff\ud984\udddd\udb3a\udec0\uda52\udf50\ud963\udd54\ud89c\udf9c\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63", "\u04ee\u3567\u31a2\u342c\u3a8e\u3821\u8758\ub9ad\u527c\ubb63\u54e6\u1334", "\udb87\udccb\uda7f\udc45\ud97e\udd3c\udbb5\udc2a\uda55\ude40\ud853\udf77\ud80f\udebd\ud86c\udf7e\udb78\udea3\ud9c0\udf2f\ud96b\udea9\udb38\ude44\ud81c\udcdb",
        32, 21267, -1561144162, -3062316249003966597L, 85093L, false, true, (char) 45820, (char) 7058,
        Double.longBitsToDouble(0x3fc7a3e588a3a850L), Double.longBitsToDouble(0x3fdf8305c3b7bfd2L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Double:0.19504346152194452\0121=java.lang.Double:0.19382752510016718\012",
        Z.run(T, 2, 4, 11, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda8a\udc37\udb1d\udefc\udbb1\udd99\ud9ea\udcbb\ud84b\udce6\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud8b5\uddcb\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud94b\ude6e\uda54\udce3", "\u2e57\u130e\u1f2c\u4194\ub06f\u52a7", "\uda55\ude40\ud853\udf77\ud80f\udebd\udb5c\udff6\ud915\udc07\ud9d0\udc8d\uf8d0\uda7d\udfff\ud81c\udcc6\udba6\udf09\udad8\ude54\ud859\udda8\udb5b\udd17\udbae\ude8a\ud991\ude83\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13",
        13, 78648, -703086510, -8835496563324601255L, 73968L, true, true, (char) 7050, (char) 13628,
        Double.longBitsToDouble(0x3fc8f72f24448788L), Double.longBitsToDouble(0x3fd6df4af2b55b4eL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Float:0.6572365\012",
        Z.run(T, 1, 1, 2, 1, "\uda17\ude56\ud878\ude78\udbc9\udc2a\uda74\udce8\ud963\udd54\udae1\ude92\uda4d\udca3\ud940\udfa0\uda58\udc95\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u7100V\u360c\u4194\ub06f\u52a7\u999e\u79e1\u6f52\u86c1\uc834\u23d6\u8de8\u2a11\u99dc\uc62f\u4c10\uc678\u52b4", "\ud8d9\udddb\ud97a\udddb\ud996\udd1d\uda55\udd11\uda3b\udf9c\uda3c\udeef\ud9a5\udedb\udb54\udffa",
        7, 36483, -1229494352, 1452706642102321840L, -18420L, false, true, (char) 53169, (char) 7050,
        Double.longBitsToDouble(0x3fe50814d8c7b979L), Double.longBitsToDouble(0x3fd1121e22dbe95eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Double:0.5363998513116136\012",
        Z.run(T, 1, 14, 17, 9, "\uda17\uddc9\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud978\udf69\uda9a\udf1f\udaa4\udf0b\ud8c7\udffb\udbbc\uddab\ud88b\uddc9\ud94c\udc20\ud998\udd02\udabc\udda7\udabe\ude08\ud817\udff0", "\u2e57\u130e\u1f2c\u4194\ub06f\u7a52\u999e\u5593\ubf4f\u08b6\u05bb\u23d6\u57af\u0a19\u9a0d\uc62f\u23b7\uc5fa\u70b4", "\udbae\ude8a\ud9a1\ude84\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\ud873\udeba\ud976\udf5e\ud865\ude2f\ud84c\udf76",
        57, 43492, -943806576, 7920996059916774813L, 26777L, true, true, (char) 18726, (char) 4321,
        Double.longBitsToDouble(0x3fd849aa4c5c1e80L), Double.longBitsToDouble(0x3fe46cea3f98ed8fL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Double:0.043095221057681696\012",
        Z.run(T, 1, 14, 15, 1, "\uda17\ude56\udb28\ude95\udb3a\ude94\uda52\udf50", "\u4667\uac43\u97fb\ucbba\u8ebe\u06d1\u2644\u1d0b\u3080\u4a00\u5855\u3b53\u6b98\u26e3", "\ud94b\udfe6\udbd7\udda6\udb24\udd2f\uac76\ud9bf\ude09\udb2c\udd58\ud90a\ude34\udb87\udca4\uda74\udebb\udb60\ude7f",
        19, 17637, 214233989, -8676536162186979482L, -60178L, false, false, (char) 8191, (char) 46439,
        Double.longBitsToDouble(0x3fa5e31ef1e266d0L), Double.longBitsToDouble(0x3fefb90b8c42c246L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Double:-2.513068500000916\0121=java.lang.Float:0.49945158\012",
        Z.run(T, 2, 12, 17, 9, "\uda17\ude56\ud878\ude78\ud81c\udf94\ud88a\udd93\ud9fc\udc69\uc68b\uda4d\udca3\udacc\udd26\ud95a\udf82\udb5a\uddaa\udb34\udd60\ud86d\udd77\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud8e9\udf17\uda80\udda4\udaa4\udf0b\ud926\udc0a\udbbc\udd61\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udaf1\udf2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\u130e\u96bf\u4194\ub052\u52a7\u999e\u33f4\uc13b\u2e85\u05bb\u55e9\u8e5d\u1c74\u99dc\uc62f\u4c03\u9ad8\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\udb1a\udec7\uda53\udf86\ud976\udf5e\ud865\ude2f\ud84c\udf76",
        42, 24292, 298357136, 3813379077069057417L, 26777L, true, true, (char) 40476, (char) 8957,
        Double.longBitsToDouble(0x3fd22ab72c5c1e80L), Double.longBitsToDouble(0x3fdff703c9bee722L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Double:0.28385714847579635\012",
        Z.run(T, 1, 16, 15, 9, "\uda17\ude56\ud878\ude78\ud81c\udf94\udb8b\udff4\udb41\uddfd\uc68b\uda4d\udca3\udacc\udd26\ud95a\udf82\uda56\udf88\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd61\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udaf1\udf2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\u130e\u3b2c\u4194\ub052\u52a7\u152d\u33f4\u08f1\u08b6\u05bb\u23d6\u8de8\u1c74\u99dc\uc62f\u4c03\u9ad8\u52b4", "\udbae\ude8a\u77ad\uda4e\udfe2\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\ud873\udeba\udaf6\udc5e\udb39\udff3\ud84c\udf35",
        42, 24292, -943806576, 7920996061745773469L, 26777L, true, true, (char) 40476, (char) 8957,
        Double.longBitsToDouble(0x3fd22ab72c5c1e80L), Double.longBitsToDouble(0x3fcc8e07937dcc0cL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Double:1.1049854571246818\0121=java.lang.Integer:5\012",
        Z.run(T, 2, 8, 6, 17, "\uda17\ude56\ud878\ude78\udb3a\udee2\udaf4\udf41\ud964\ude84\uda3d\udc4d\uda4d\udcb7\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\udbe1\udde4\udbc1\udcf2\ud81e\udfb2\ud8be\udf36\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\uda0d\udee9\udb8a\udd5c\ud94c\udc8c\udb4d\udd9c\ue6d6", "\u8195\u17a2\u3315\u130e\u1f2c", "\uda48\udf54\ud97e\udd3c\udbb5\udc2a",
        -5, 1602, -1742125245, -4584471983055571705L, 3622L, false, false, (char) 64350, (char) 24716,
        Double.longBitsToDouble(0x3fdcbed4d93c7448L), Double.longBitsToDouble(0x3feccd17977bd580L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Double:1.5707963267948966\012",
        Z.run(T, 1, 8, 6, 17, "\uda17\ude56\ud878\ude78\udb3a\udee2\udaf4\udf41\ud964\ude84\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\u009e\000\000\000\000\udaa4\ude97\ud926\udc0a\uc47b\ud882\udde0\ud94c\udc20\udbdf\udea6\ud95e\udc0d", "\u8195\ubb10\u2e57\u130e\u1f2c", "\uda7f\udc45\ud97e\udd3c\udbb5\udc2a",
        -5, 1602, -1742125245, -4584471983055571705L, 9240L, true, true, (char) 46726, (char) 27644,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e949f0600000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Double:1.48326169335608\0121=java.lang.Double:0.7294522000889754\012",
        Z.run(T, 2, 8, 12, 9, "\udb99\udd37\udaa2\udeb7\udb3a\ude5a\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud907\udd43\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\udb92\uddac\ud94c\udc21\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u3547\u2079\u4328\u413f\ub06f\u52a7\u999e\u5593\ubf4f\u08b6\u05bb\u23d6\u8de8\u863b\u61c5\uc62f\u6d9c\ua80c\u3d78\ud6a3\u6d3a", "\ud967\udc73",
        27, 63401, -13886923, -2300036775253026532L, -22651L, false, true, (char) 805, (char) 4967,
        Double.longBitsToDouble(0x3fb66158b56146d0L), Double.longBitsToDouble(0x3fec81c4eff3c7beL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Double:0.3627066782516655\0121=java.lang.Double:-2.40532455595899\012",
        Z.run(T, 2, 13, 12, 9, "\udb99\udd37\udaa2\udeb7\udb3a\ude5a\uda52\udebc\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\uda0b\udef2\udb2e\udca1\ud84b\udd47\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\u130e\u1f2c\u4194\ub06f\u52a7\u56bb\u5593\u2ad6\u08b6\ucf92\u058f\u8e83\u1c74\u99dc\uc62f\u23b7\uc5fa\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud83b\udd12\ud873\udeba\ud976\udf5e\ud87a\udced\uda9c\uddbf",
        27, 46332, -943806707, 7920996059916774813L, 26777L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fd849aa4c5c1e80L), Double.longBitsToDouble(0x3fe46cea3cdf7342L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Double:1.1473894119260178E-6\012",
        Z.run(T, 1, 11, 11, 9, "\ud9e7\udc73\u5287\000\ub1bd\000\uc69b\uda4d\udca3\ud9f3\udd19\ud936\ude1b\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\u009e\000\000\000\000\udba1\udf49\ud812\udf49\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\uf43c\000\ud815\udc49", "\ubf3a\u5e80\u1e71", "\000",
        -5, 16249, -1882062848, 4683743614344364032L, 55303L, false, false, (char) 33800, (char) 27654,
        Double.longBitsToDouble(0x3eb3400000000000L), Double.longBitsToDouble(0x3fc3345e5def5400L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Double:-2.4053245555479092\0121=java.lang.Double:-2.4053245555479092\012",
        Z.run(T, 2, 12, 12, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\ud9ff\udc9d\ud89d\udde0\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\ud5b9\u821b\u4194\ub06f\u52a7\u999e\u5593\u4e6c\u7d18\u05a7\u23d6\u8de8\u1c74\u99dc\uc62f\u23b7\uc5fa\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud955\udf7b\ud9a5\udf02\udb54\udffa\ud8b2\udf13\ud873\udeba\ud976\udf5e\ud865\ude2f\ud84c\udf76",
        57, 24292, -943806576, 5687210644733406596L, 26777L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fd849aa4c5c1ffaL), Double.longBitsToDouble(0x3fe46cea3d774242L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Long:2537875784902387171\0121=java.lang.Long:2537875784902387171\012",
        Z.run(T, 2, 7, 7, 0, "", "\u7516", "\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\ud9ff\udc9d\ud89d\udde0\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\udb30\udf1a\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\000\000\000\udb50\udcf3\ud833\uddc9\ud939\udd8d\uda7e\udc4b\udb87\udccb\u0085\000\udbb5\udc2a\ud84b\ude9b\uda37\udfa5\ud80f\udea9\udab7\udf43\udb78\udea3\ud9c0\udf2f\ud87e\udc78\uda7d\udfff\ud81c\udcc6\udba6\udf09\ud886\udd38\ud87d\udf22\udb5b\udd17\udb9e\udf0f\u5548\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ua0bd\udb3e\udede\ud8b2\udf13\ud873\udeba\ud976\udf5e\ud865\ude2f\ud84c\udf76\ud921\udec1\ud83e\ude02\000\000\ud93b\uddc4\udbfb\ude78\u10c7\ud8eb\udf55\udab5\udc92\udb5a\udf60\udb3e\udd87",
        14, 95709, 2049322207, 2537875784902387171L, 58879L, true, false, (char) 63055, (char) 244,
        Double.longBitsToDouble(0x3fef1620c2376f1fL), Double.longBitsToDouble(0x3fc753ddf7f199dcL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Double:0.6382952870295429\0121=java.lang.Double:0.6382952870295429\012",
        Z.run(T, 2, 0, 0, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\ud9ff\udc9d\ud89d\udde0\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\ud5b9\u821b\u4194\ub06f\u52a7\u999e\u5593\u4e6c\u7d18\u05a7\u23d6\u8de8\u1c74\u99dc\uc62f\u23b7\uc5fa\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\ud873\udeba\ud976\udf5e\ud865\ude2f\ud84c\udf76",
        57, 24292, -943806576, 7920996059916774813L, 26777L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fd849aa4c5c1e80L), Double.longBitsToDouble(0x3fe46cea3cdf7342L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:2\012",
        Z.run(T, 1, 2, 12, 9, "\uda17\ude56", "\u69ac\u8e09\u5306\u3d52\u2841\u97fb\ucbba\u8ebe\u06d1\u2644\u1d4c\u3080\u4a00\u5855", "\000",
        2, -767, 0, 0L, -97058L, true, true, (char) 18035, (char) 43228,
        Double.longBitsToDouble(0x3fe20ccb08bb9ecdL), Double.longBitsToDouble(0x3fbd84bbcd6ac6c0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Double:0.08731191311749933\012",
        Z.run(T, 1, 11, 10, 9, "\uda17\ude50\ud878\ude78\udbf7\udfed\uda52\udf50\uda2b\udff7\ud830\udc2c\ud995\udd13\ud940\udfa0\udb5a\ude92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\uda14\udec9\uda85\uddb6\ud8be\udf55\ud82c\udf63\uda80\udf12\ud8d6\udc75\ud9ea\uddb5\udbc1\udc6e\ud874\ude5e\ud96e\udf9e\udbdf\udea6\udb7b\udcbb\ud9ae\ude02\ud817\udfc7", "\u2e57\u130e\u1f2c\u79c2\ub06f\u7589\u64ee\u5593\ubf4f\ucb5f\ucc1a\u992c\u1c24\u1c74\u99dc\uc62f\u23b7\uc5fa\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1",
        50, 6736, 1996031649, -554478176857392083L, -22557L, true, true, (char) 59423, (char) 5849,
        Double.longBitsToDouble(0x3fb66158b7f946d0L), Double.longBitsToDouble(0x3fec81c772f3c7beL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Float:0.37949616\0121=java.lang.Float:0.37949616\012",
        Z.run(T, 2, 5, 5, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udbe8\udd04\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\ud8e9\uddaa\udb24\uddcf\ud9bc\udd1d\udac3\uddfe", "\u994e\u130e\u1f2c\u4194\ub06f\u52a7\u999e\u5593\ubf4f\u08b6\u05bb\u23d6\u8de8\u1c74\u729d\u6b2f\u53bf\u993d\u9b0b", "\udb5d\udee0\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\ud873\udeba\ud821\udc8f\ud865\ude2f\ud84c\udf76",
        57, 24292, -943806576, 7920996059916774813L, 26777L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fd849aa4c5c1e80L), Double.longBitsToDouble(0x3fe46cea3cdf7342L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Double:0.1150526088002223\0121=java.lang.Double:1.4552326698033282\012",
        Z.run(T, 2, 11, 8, 5, "\uda17\ude56", "\u3398\u601a\u5ae3\u3dd8\u2841\u97fb\ucbba\u4649\u06d1\u099d\u1d4c\u3080\u4a00\ud054", "\ud925\udf44\udbbc\udd30\ud953\udc69",
        31, 65362, 1409870908, 398657393970908030L, 2647L, true, true, (char) 48290, (char) 65416,
        Double.longBitsToDouble(0x3fbd84bbcd6a0888L), Double.longBitsToDouble(0x3fec29a7a4f259c4L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Long:46302\0121=java.lang.Long:46302\012",
        Z.run(T, 2, 3, 3, 14, "\ud966\udebd\ud878\ude78\udb3a\udee2\uda66\udc50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\udba0\udfdd\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud968\ude52\udbdf\udeba\udb24\udd2f\uda7b\udf5c\ud82a\ude7c\uda7b\udf4c\udb7a\udd97\udb50\uddea\ud86d\udfca\uda94\uddd8\uda7e\udc4b\ud996\udf05\uda7f\udc45\ud97e\udd3c\udbb5\udc2a\uda55\ude40\ud853\udf77\ud80f\udebd\ud86c\udf7e\udb78\udea3\u3f18\ud966\udc3c\uda6a\ude2c\udaac\udc11\udb40\ude93\udb34\udd60\udad6\udd92\udbe5\ude29\ud895\udeb1\udb0d\ude10\ud869\udfe8\ud86a\uddc3\uda2e\ude85\ud9e5\udf83\ud90b\uddb4", "\u10f2\u72dd\u4814\u1d5a\u89ce\u6c16\u53ab\u022f", "\udba5\uddcc\ud9f5\udda9\ud96e\udec1\udace\uddb7\udb52\udc78\ud9ed\udc44\ud950\udee0\ud9f5\udccc\ud98d\udeeb\udb8f\udfbf",
        -3, 74112, -2023288980, -1749111734298237649L, 46302L, false, false, (char) 19842, (char) 57466,
        Double.longBitsToDouble(0x3fe14221286ce08aL), Double.longBitsToDouble(0x3fe2ada145a35296L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Double:0.023683373952859618\012",
        Z.run(T, 1, 11, 13, 18, "\ud966\udebd\ud878\ude78\uda8a\uddcc\ud971\udc25\udbe1\udfb6\uc69b\uda4d\udca3\ud940\udfa0\ud942\udfda\udbeb\ude49\udb34\udd05\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55", "\u2e25\u4cdd\u9d63\u31a2", "\udb24\udd2f\uda7b\udf5c\ud82a\ude7c\uda7b\udf4c\udb7a\udd97",
        34, 32746, 317677755, 4688603961554641325L, 80309L, false, true, (char) 19438, (char) 1822,
        Double.longBitsToDouble(0x3f984108e7ce1820L), Double.longBitsToDouble(0x3fd07c0603babe7aL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Double:0.4318215825767767\0121=java.lang.Double:0.4318215825767767\012",
        Z.run(T, 2, 11, 11, 9, "\uda17\ude56\ud8fd\udd1b\uda43\ude92\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda8a\udc37\udb1d\udefc\udbb1\udd99\ud9ea\udcbb\ud84b\udce6\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud8b5\uddcb\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud94b\ude6e\uda54\udce3", "\u2e57\u130e\u1f2c\u4194\ub06f\u52a7", "\uda55\ude40\ud853\udf77\ud80f\udebd\u31df\ud915\udc07\ud9d0\udc8d\uf8d0\uda7d\udfff\ud81c\udcc6\udba6\udf09\uac50\ud859\udda8\udb5b\udd17\udbae\ude8a\ud991\ude83\ud9d4\udc33\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13",
        46, -214, -703086510, -8835496563324601255L, 73968L, true, true, (char) 7050, (char) 45683,
        Double.longBitsToDouble(0x3fdc80e6e55d52c6L), Double.longBitsToDouble(0x3fd6d03e22b55b4eL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Double:0.5640616579593939\0121=java.lang.Double:0.5640616579593939\012",
        Z.run(T, 2, 4, 4, 9, "\uda07\uddff\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b", "\u97fb\u28d5\ucc88", "\ud84b\udce6\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a",
        10, 51531, 744373635, -7484563914457813956L, 57159L, true, true, (char) 58060, (char) 54236,
        Double.longBitsToDouble(0x3fe20ccb08bb9ecdL), Double.longBitsToDouble(0x3fbd84bbcd6a0888L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\012",
        Z.run(T, 1, 14, 17, 17, "\uda17\uddc9\ud878\ude78", "\u2650", "\ud940\udfa0\udb52\udc92\uda56\udfd8\000\000",
        -5, 75840, -1384906154, -6227149606494080116L, 41964L, true, false, (char) 54399, (char) 61051,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Double:1.5707963267948966\012",
        Z.run(T, 1, 14, 15, 1, "\uda17\ude56\uda2f\udc78\000\uda44\udda2", "\u4667\uac43\u97fb\ucbba\u8ebe\u06d1\u2644\u1d0b\u3080\u4a00\u5855\u3b53\u6b98\u26e3", "\ud94b\udfe6\udbd7\udda6\ud9fd\udc3c\uac76\ud9bf\ude09\udb2c\udd58\000\000\uda4a\ude45\udb60\ude7f",
        19, 17637, 214233989, -8676536162186979482L, -60178L, false, false, (char) 8191, (char) 46439,
        Double.longBitsToDouble(0x3f48c7a07899b400L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Double:0.043095221057681696\0121=java.lang.Double:0.04272240842389514\012",
        Z.run(T, 2, 14, 13, 1, "\uda17\ude56\udb28\ude95\udb3a\ude94\uda52\udf50", "\u4667\uac43\u97fb\ucbba\u8ebe\u06d1\u2644\u1d0b\u3080\u4a00\u5855\u3b53\u6b98\u26e3", "\ud94b\udfe6\udbd7\udda6\ud935\udc78\uac76\ud9bf\ude09\udb2c\udd58\ud90a\ude34\udb87\udca4\uda74\udebb\udb60\ude7f",
        19, 17637, 214233989, -8676536162186979482L, -60178L, false, false, (char) 8191, (char) 46439,
        Double.longBitsToDouble(0x3fa5e31ef1e266d0L), Double.longBitsToDouble(0x3fefb90b8c42c246L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Double:1.1049854550399214\0121=java.lang.Double:1.1049854550399214\012",
        Z.run(T, 2, 8, 8, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\udaf4\udf41\ud964\ude84\uda3d\udc4d\uda4d\udcb7\ud941\udc1e\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\udbe1\udde4\udbc1\udcf2\ud81e\udfb2\ud8be\udf36\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud90f\udc37\uda0d\udee9\udb8a\udd5c\ud94c\udc8c\udb4d\udd9c\ue6d6", "\u8195\u17a2\u3315\u130e\u1f2c", "\uda48\udf54\ud97e\udd3c\udbb5\udc2a",
        -5, 1602, -1742125245, -4584471983055571705L, 3622L, false, true, (char) 15789, (char) 24765,
        Double.longBitsToDouble(0x3fdcbed4db3c7448L), Double.longBitsToDouble(0x3fe1de8affd624e5L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Integer:22207\0121=java.lang.Integer:22207\012",
        Z.run(T, 2, 2, 2, 17, "\ud9f6\udd62\ud9d5\uddd5\ud8bf\ude56\udaf4\udf41\ud964\ude84\uda93\udfe9\uda4d\udcb7\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\udbe1\udde4\udbc1\udcf2\ud818\udd61\ud8be\udf36\udbf1\udf4a\uda9a\uded8\ud8ba\udf16\ud926\udc0a\uda0d\udee9\udb8a\udd5c\ud94c\udc8c\udb4d\udd9c\ue6d6", "\u43f5\u4f0f\u0c4d\u97df", "\ud82e\ude20\uda48\udf54\udbcd\ude6a\ud985\udc32\uda55\ude40\ud90f\udf95\ud994\udd24",
        28, 22207, -374603641, -8399658357712326552L, 68924L, true, true, (char) 3778, (char) 6796,
        Double.longBitsToDouble(0x3febdeac009cc6d2L), Double.longBitsToDouble(0x3fd71367c8542e2eL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Integer:5\0121=java.lang.Integer:5\012",
        Z.run(T, 2, 6, 6, 17, "\uda17\ude56\ud878\ude78\udb3a\udee2\udaf4\udf41\ud964\ude84\ud939\udf8b\uda4d\udcb7\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud99c\ude38\ud9ac\udf8e\ud9e5\udc8d\ud81e\udfcf\ud8be\udf36\ud82c\udf63\uda9a\udf1f\udaac\udd0b\ud926\udc0a\uda0d\udee9\udb8a\udd5c\ud94c\udc8c\udb4d\udd9c\ue6d6", "\u8195\u17a2\u3315\u130e\u1f2c", "\udba3\udfa1\ud97e\udd6a\udb05\uddc0",
        -5, 1602, -1742125245, -4584471983055571705L, -15335L, false, false, (char) 46197, (char) 19610,
        Double.longBitsToDouble(0x3fec29bae651da70L), Double.longBitsToDouble(0x3fbafd12fe5e5300L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Double:0.7871024393229876\0121=java.lang.Double:0.7871024393229876\012",
        Z.run(T, 2, 11, 11, 13, "\ud9e7\udc73\u5287\000\ub1bd\000\uc69b\uda4d\udca3\ud9f3\udd19\ud936\ude1b\uda56\udfd8\udb34\udd0a\ud826\ude67\uda1e\ude56\u009e\000\000\000\000\udba1\udf49\ud812\udf49\ud9ab\udd3b\ud89c\udc90\ud94c\udc20\udbdf\udea6\uf43c\000\ud815\udc49\udb10\udf66\ud90a\udd9f\uda8a\udf27\ud833\udd99\uda94\udd1d", "\000", "\uda46\udd63",
        -5, 43192, -1067405506, 30441171421L, -6810L, false, false, (char) 0, (char) 41867,
        Double.longBitsToDouble(0x3febdea802f33bf7L), Double.longBitsToDouble(0x3f9dcf3e8d990020L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Long:7203386146481501329\0121=java.lang.Long:7203386146481501329\012",
        Z.run(T, 2, 7, 7, 0, "", "", "\ud98a\udf85",
        17, 91527, -407735025, -7203386146481501329L, -17087L, true, true, (char) 2463, (char) 54071,
        Double.longBitsToDouble(0x3fbb6b5d1c654ca0L), Double.longBitsToDouble(0x3fe800000574b0e6L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Double:0.5517630143812986\0121=java.lang.Double:0.5517630143812986\012",
        Z.run(T, 2, 0, 0, 11, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\udb75\ude7c\uda4e\udd39\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\ud9ff\udc9d\ud886\udee0\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\ud9c8\udfaa\udb24\udd2f\ud9bc\udd1d\ud817\udfc7\uda7b\udf4c\ud90a\udd9f", "\u821b\u4194\ub06f\u1a85\u1ebc", "\uda37\udfa5",
        47, 62494, 1597895943, 1616627188821223847L, 9240L, true, true, (char) 46726, (char) 45820,
        Double.longBitsToDouble(0x3fe1a80ae8bd1f2cL), Double.longBitsToDouble(0x3fd1ce0149f0616aL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Integer:29\0121=java.lang.Integer:29\012",
        Z.run(T, 2, 6, 6, 5, "\uda17\ude56\udae0\udd7d\ud835\udf60\udac6\udea3\ud913\udfe5\ud8fe\udeed\uda4d\udca4\udb5e\uddc4\udb3b\udd0f\ud9d6\udc57\udbf8\ude38\ud86d\udd82\udb7b\ude9b\uda1c\udd2e", "\u643e\u6cb1\u591d\u928d\uc503\u0670\u0ca9\ub2a4\u37d5\u8690", "\udba2\ude8c\ud8cf\udc68\uda55\udc39\uda94\uddd8\ud84d\udf54\ud994\udc91\ud8eb\udd11\u0f45\udbb4\udf4b\ud852\uddaf\ud8a3\ude62",
        29, 44341, -599138836, 2115576803993015350L, -7617L, false, true, (char) 24972, (char) 63684,
        Double.longBitsToDouble(0x3fd3da2a174b48b8L), Double.longBitsToDouble(0x3f7d1c8794d0e600L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Float:0.8922458\0121=java.lang.Float:0.8922458\012",
        Z.run(T, 2, 17, 17, 8, "\uda17\ude56", "\u3398\u601a\u0e71\u8dba\ub0d8\u3e19\ucbba\u4649\u06d1\u099d\u1d4c\u3080\u4a00\ud054", "\ud925\udf44\udbbc\udd30\ud953\udc69",
        31, 65362, 1409870908, 398657394981629092L, -40241L, true, true, (char) 48290, (char) 63635,
        Double.longBitsToDouble(0x3fec8d47100dd76dL), Double.longBitsToDouble(0x3fec29a7a4f259c4L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Long:835083248505651311\0121=java.lang.Long:835083248505651311\012",
        Z.run(T, 2, 3, 3, 14, "\ud966\udebd\ud878\ude78\udb3a\udee2\uda66\udc50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\udba0\udfdd\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud968\ude52\udbdf\udeba\udb24\udd2f\uda7b\udf5c\ud82a\ude7c\uda7b\udf4c\udb7a\udd97\udb50\uddea\ud86d\udfca\uda94\uddd8\uda7e\udc4b\ud996\udf05\uda7f\udc45\ud97e\udd3c\udb98\udf0c\uda55\ude40\ud853\udf77\ud80f\udebd\ud86c\udf7e\udb78\udea3\u3f18\ud966\udc3c\uda6a\ude2c\udaac\udc11\udb40\ude93\udb34\udd60\udad6\udd92\udbe5\ude29\ud857\udf4a\udb0d\ude10\ud869\udfe8\ud86a\uddc3\uda2e\ude85\ud9e5\udf83\ud90b\uddb4", "\000", "\udb6f\udecc\udb5c\ude9b\ud91c\udceb\ud9ac\udf09\000\000\uda58\udc2b\udba5\uddcc",
        28, -1000, 655804266, 835083248505651311L, -4105L, true, false, (char) 49571, (char) 26569,
        Double.longBitsToDouble(0x3fa2c3b3d2fe7b90L), Double.longBitsToDouble(0x3fdb714af905c084L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Double:0.12063690045244589\0121=java.lang.Double:0.12063690045244589\012",
        Z.run(T, 2, 11, 11, 13, "\ud9e7\udc73\u5287\000\ub1bd\000\uc69b\uda4d\udca3\ud9f3\udd19\ud936\ude1b\uda56\udfd8\udb34\udd0a\ud826\ude67\uda1e\ude56\u009e\000\000\000\000\udba1\udf49\ud812\udf49\ud9ab\udd3b\ud89c\udc90\ud94c\udc20\udbdf\udea6\uf43c\000\ud8bf\udc3e\udb10\udf66\ud90a\udd9f\uda8a\udf27\ud833\udd99\uda94\udd1d", "\000", "\uda46\udd63",
        -5, 43192, -1067405506, 30441171421L, -6810L, false, false, (char) 0, (char) 41867,
        Double.longBitsToDouble(0x3fbef5401799dfb8L), Double.longBitsToDouble(0x3f9dcf3e8d990020L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Float:0.9856509\0121=java.lang.Float:0.9856509\012",
        Z.run(T, 2, 17, 17, 4, "\uda17\ude56", "\u3398", "\ud84b\udca2",
        12, 12957, 117443439, -7852299245271466977L, 63742L, false, false, (char) 26081, (char) 15648,
        Double.longBitsToDouble(0x3fee4fea4d74b0e6L), Double.longBitsToDouble(0x3fef8a73bc57b0adL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Double:0.06663159355791552\0121=java.lang.Double:0.06663159355791552\012",
        Z.run(T, 2, 11, 11, 13, "\ud9e7\udc73\u5287\000\ub1bd\000\uc69b\ud8ec\uddf5\ud9f3\udd19\udb1e\udeb2\uda56\udfd8\udb34\udd0a\ud826\ude67\uda1e\ude56\u009e\000\000\uda52\udc08\000\udba1\udf49\ud812\udf49\ud9ab\udd3b\ud89c\udc90\ud94c\udc20\udba9\udcca\udb2c\udd80\025\ud891\udc47\ud8c7\udd41\ud8fe\uddb4\uda8a\udf27\ud833\udd99\uda94\udd1d", "\000", "\uda46\udd63",
        24, 92720, -1067405506, 30441171421L, 6192L, true, true, (char) 27654, (char) 77,
        Double.longBitsToDouble(0x3fb1120004cd1790L), Double.longBitsToDouble(0x3fbef5401799dfb8L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Double:1.147886223406861E-6\0121=java.lang.Double:1.147886223406861E-6\012",
        Z.run(T, 2, 11, 11, 13, "\udb0e\udda9\udb65\udc51\000\ub1bd\000\uc69b\ud8ec\uddf5\ud9f3\udd19\uda60\udeb3\uda56\udfd8\udb34\udd0a\ud826\ude67\uda1e\ude56\u009e\000", "\000", "\ud9ab\udd3b\ud89c\udc90\ud94c\udc20\udba9\udcca\udb2c\udd80\025\ud85b\udd7c\udb37\udeac\ud8fe\uddb4\uda8a\udf27\udade\udd2e\uda94\udd1d\u4476\udacd\udfcf\000",
        -5, 16048, 332529664, 5212104787382370472L, 55303L, false, false, (char) 46630, (char) 27654,
        Double.longBitsToDouble(0x3eb3422240000000L), Double.longBitsToDouble(0x3fc3345e41edbdd0L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Double:0.3994709185673331\012",
        Z.run(T, 1, 15, 12, 9, "\uda17\ude56\ud878\ude78\udb3a\udee2\uda52\udf50\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\udb52\udc92\uda56\udfd8\udb34\udd0a\ud86d\udd7e\uda1e\udeeb\ud84b\udd12\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud94c\udc20\udbdf\udea6\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\u130e\u1f2c\u4194\ub06f\u52a7\u999e\u5593\ubf4f\u08b6\u05bb\u23d6\u8de8\u1c74\u99dc\uc62f\u23b7\uc5fa\u52b4", "\udbae\ude8a\udab6\ude57\uda4e\udef1\ud85b\ude25\uda3b\udf9c\ud8f5\udc0b\ud9a5\udedb\udb54\udffa\ud8b2\udf13\ud873\udeba\ud976\udf5e\ud865\ude2f\ud84c\udf76",
        57, 24292, -943806576, 4332393516507049373L, 26777L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fd849aa4c5c1e80L), Double.longBitsToDouble(0x3fe46cea3cdf7342L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Double:0.3994709185673331\0121=java.lang.Double:0.3994709185673331\012",
        Z.run(T, 2, 15, 15, 9, "\uda17\ude56\udbe3\udece\udb3a\udee2\uda52\udedf\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\ud877\udcc8\uda56\udf80\udb34\udd0a\ud86d\udd7e\ud9ff\udc9d\ud89d\udde0\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\udbbc\udd30\ud88b\uddc9\ud807\udf3e\udbdf\ude2c\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\ud5b9\u821b\u4194\ua1d3\u7155\u3f1f\u9a58\u4e6c\u2468\ua3e3\u23d6\u8de8\u1c74\u7acf\uc62f\u23b7\uc5fa\u747a", "\udbae\ude8a\udab6\ude57\uda1d\udcef\udad6\udc2c\uda3b\udf9c\ud8f5\udc0b\ud9a5\udecf\udb54\udffa\uda77\udc35\ud8d5\udcc5\ud976\udf5e\ud880\udd2f\ud84c\udf76",
        57, 24292, -943806576, 7920996059916774813L, 35338L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fd849aa4c5c1e80L), Double.longBitsToDouble(0x3fe46cea3cdf7342L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\0121=java.lang.Double:NaN\012",
        Z.run(T, 2, 9, 9, 17, "\ud91c\ude33\ud878\ude78\udb3a\udee2\udaf4\udf41\udbd0\udc59\uda3d\udc4d\uda4d\udcb7\ud940\udfa0\udb52\udc92\uda56\udfdc\udb34\udd0a\ud88d\udf8e\udbe1\udde4\udbc1\udcf2\ud82f\uddbf\ud8be\udf36\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud926\udc0a\uda0d\udee9\udb8a\udd5c\udb89\udfc6\udb42\udd01\uf888", "\u8195\u17a2\u3315\u130e\ud097", "\udbcd\udcae\uda72\udeed\uda72\udc72\uda55\ude40",
        15, 1009, -1067405478, 6862910817221476367L, 2296L, true, true, (char) 24716, (char) 37656,
        Double.longBitsToDouble(0x3fc3c7449cb577c8L), Double.longBitsToDouble(0x3fc3a6d008907814L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Double:0.4221446937854622\0121=java.lang.Double:0.4221446937854622\012",
        Z.run(T, 2, 13, 13, 17, "\ufc47\u6489\ud9bc\udce3\udb03\udf1b\ud964\ude84\uda3d\udc4d\uda4d\udcb7\ud940\udfa0\udb52\udc92\uda7f\udcd8\udb34\udd0a\ud86d\udd7e\udbe1\udde4\uda43\udcb4\ud81e\udfb2\ud8be\udf36\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud99e\udda5\uda0d\udee4\udb96\udc34\ud94c\udc8c\udb4d\udd9c\ud927\udc4d", "\u8195\u17a2\u2fcb\u261b\u1f2c", "\uda48\udf54\ud97e\udd3c\udb90\ude25",
        -5, 75489, -1523982531, -5967601574359468761L, 3622L, false, false, (char) 64350, (char) 24716,
        Double.longBitsToDouble(0x3fdcbed4d2107bbaL), Double.longBitsToDouble(0x3feccd13c3a79f2cL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Integer:46\0121=java.lang.Integer:46\012",
        Z.run(T, 2, 2, 2, 14, "\udbda\ude1b\ud9e4\udd1e", "\u654a", "\ud998\udce1\udb92\udffa\ud973\udedb\udb4e\udeec\ud86d\udd7e",
        46, -849, 0, 0L, 20064L, true, false, (char) 56104, (char) 23279,
        Double.longBitsToDouble(0x3fdef9ea60bf3720L), Double.longBitsToDouble(0x3fae2ef8861b9080L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Double:1.024711538668429\0121=java.lang.Double:1.024711538668429\012",
        Z.run(T, 2, 10, 10, 5, "\uda17\ude56", "\u3398\u601a\u5ae3\ud004\u2841\u97fb\ucbba\u4649\u06d1\u099d\u1d4c\u3080\u937c\u1935", "\udad1\udeda\ud949\ude9e\uda03\udc8c",
        -5, 65478, 1409870908, 402639790726974334L, 2647L, true, true, (char) 48290, (char) 65416,
        Double.longBitsToDouble(0x3feb5897784908b7L), Double.longBitsToDouble(0x3fc0a69639a9ff0cL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Double:0.02715566760980999\0121=java.lang.Double:0.02715566760980999\012",
        Z.run(T, 2, 11, 11, 3, "\udb3b\udda9\ud8fd\udd11\ud95d\uddbf\ud936\udc3e\ud963\udd54\uc69b\ud835\udc97\ud940\udfa0\udb52\udc92\ud91d\udd62\udb1d\udf13\udbb1\udd99\ud9ea\udcbb\ud84b\udce6\uda85\udd78\ud8be\udf55\ud82c\udf63\udb94\ude1b\udbed\udf57\uda5e\udc06\udbbc\udd30\ud8b5\uddcb\ud8af\udd60\udbdf\udea6\udb24\udd2f\ud88b\ude6e\ud802\udcda", "\u2e57\ud50d\u9f7a\u4194\u0282", "\udbb5\udc2a\uda55\ude40\ud853\udf77\ud980\udeb7\ud99d\ude4f\ud8e4\udd5a\udb41\udf5e\udb49\ude93\uda9f\udfde\ud81c\udcc6\uda8c\udedc\ud8f2\ude4f",
        31, 10283, -1405687505, 6144327699074109508L, -16288L, true, false, (char) 49128, (char) 26996,
        Double.longBitsToDouble(0x3f9bcf91fe3f3e60L), Double.longBitsToDouble(0x3fe4897f2052b6d3L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 15, 15, 1, "\uda17\ude56\uda2f\udc78\000\uda44\udda2", "\u4667\ubb60\u60dc\ucbba\u8ebe\u06d1\u2644\u9250\u2c00\u4a00\uc763\ub6ac\u6b98\u25fd", "\ud84e\udfa8\udbd7\udce1\ud9fd\udc3c\uac76\ud9bf\ude09\udb2c\udd58\ud9df\udcef\000\uda4a\ude45\udb60\ude7f",
        49, 19117, 708099335, -3590330912657541713L, -55138L, true, true, (char) 50749, (char) 30615,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3f6e6b11aa235000L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Double:0.08584516521646784\0121=java.lang.Double:0.08584516521646784\012",
        Z.run(T, 2, 15, 15, 9, "\uda17\ude56", "\u693b\u601a\u5ae3", "",
        21, 80351, -1821767823, -8104583640073299039L, 34260L, true, true, (char) 34394, (char) 54236,
        Double.longBitsToDouble(0x3fb5ec2b5f4e5490L), Double.longBitsToDouble(0x3fd831fd48983abcL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Double:0.1302273799768\0121=java.lang.Double:0.1302273799768\012",
        Z.run(T, 2, 15, 15, 9, "\uda17\ude56\udbe3\udece\udb3a\udee2\uda52\udedf\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\ud877\udcc8\uda56\udf80\udb34\udd0a\ud86d\udd7e\ud9ff\udc9d\ud89d\udde0\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud925\udf53\udbbc\udd30\ud88b\uddc9\ud807\udf3e\udbdf\ude2c\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\ud5b9\u821b\u4194\ua1d3\u7155\u3f1f\u9a58\u987e\u0171\ua3e3\u23d6\u1d08\000\u2728\uc62f\u23b7\uc5fa\u747a", "\udbae\ude8a\udab6\ude57\uda1d\udcef\udad5\udf5c\uda3b\udf9c\ud8f5\udc0b\000\u5900\uda77\udc35\ud8d5\udcc5\ud976\udf5e\ud880\udd2f\ud84c\udf76",
        57, 24292, -943806576, 7920996059916774813L, 35338L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3fc0935480000000L), Double.longBitsToDouble(0x3fe46ce804df7342L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Double:0.0038095300900491446\0121=java.lang.Double:0.0038095300900491446\012",
        Z.run(T, 2, 15, 15, 9, "\uda17\ude56\udbe3\udece\udb3a\udee2\uda52\udedf\ud963\udd54\uc69b\uda4d\udca3\ud940\udfa0\ud877\udcc8\uda56\udf80\udb34\udd0a\ud86d\udd7e\ud9ff\udc9d\ud89d\udde0\uda85\udd78\ud8be\udf55\ud82c\udf63\uda9a\udf1f\udaa4\udf0b\ud925\udf53\udbbc\udd30\ud88b\uddc9\ud807\udf3e\udbdf\ude2c\udb24\udd2f\ud9bc\udd1d\ud817\udfc7", "\u2e57\ud5b9\u821b\u4194\ua1d3\u7155\u3f1f\u9a58\u987e\u0171\ua3e3\u23d6\u1d08\000\u2728\uc62f\u23b7\uc5fa\u747a", "\udbae\ude8a\udab6\ude57\uda1d\udcef\udad5\udf5c\uda3b\udf9c\ud8f5\udc0b\udada\udc0c\u5900\uda77\udc35\ud8d5\udcc5\ud976\udf5e\ud880\udd2f\ud84c\udf76",
        57, 24292, -943806576, 7920996059916774813L, 35338L, true, true, (char) 40476, (char) 59137,
        Double.longBitsToDouble(0x3f6f352000000000L), Double.longBitsToDouble(0x3fe46ce804df7342L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Double:1.2458623043482213\0121=java.lang.Double:1.2458623043482213\012",
        Z.run(T, 2, 14, 14, 3, "\uda17\ude56\udbd0\udda4\udb37\ude48\udaf4\udf41\ud966\udfd8\uda3d\udc4d\udb23\udfdb\ud940\udfa0\udb52\udc92\ud92c\udfe3\udb34\udd0a\ud86d\udd7e\udbe1\udde4\ud82a\udf0c\ud8f0\ude18\ud8be\udf89\ud9dc\udd1a\uda9a\udf1f\udbe4\udcdc\udaf6\udc60\ud9eb\udca9\udb8a\udd5c\uda4f\udd4e\udb4f\udf73\ud8f7\ude1d", "\u74d1\u6bd8\u32ce\u130e\u1f2c", "\udb39\ude49\ud99a\udffd\ud89f\udc03",
        10, 84137, -870089833, -4584653314593727225L, 3622L, false, false, (char) 41566, (char) 43770,
        Double.longBitsToDouble(0x3fef25064e351614L), Double.longBitsToDouble(0x3fd4fbd063562fb0L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Double:1.5707963267948966\0121=java.lang.Double:1.5707963267948966\012",
        Z.run(T, 2, 8, 8, 10, "\uda17\udd73", "\u3398\u00ca\000\000\u2832\u9784\u0b6f\u4708\u06b2\u08fc\u1d4c\u3080\u4a00\ud054", "\ud925\udf44\udbbc\udd30\ud953\udc69",
        18, 65288, 1409870908, 398657393970908030L, -71584L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e43c96400000000L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 14, 14, 3, "\uda17\ude56\udbd0\udda4\udb37\ude48\udaf4\udf41\ud966\udfd8\uda3d\udc4d\udb23\udfdb\ud940\udfa0\udb52\udc92\ud92c\udfe3\udb34\udd0a\ud86d\udd7e\udbe1\udde4\ud82a\udf0c\ud8f0\ude18\ud8be\udf89\ud9dc\udd1a\uda9a\udf1f\udbe4\udcdc\udac0\ude1f\ud9eb\udca9\udb8a\udd5c\uda4f\udd4e\udb4f\udf73\ud8f7\ude1d", "\u74d1\u6bd8\u32ce\u130e\u1f2c", "\000\ud99a\udf29\ud89e\udf7a",
        10, 84137, -870089833, -4584653314593727225L, 3622L, false, false, (char) 41566, (char) 45526,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd4fbd003562fb0L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Double:1.5707963267948966\0121=java.lang.Double:1.5707963267948966\012",
        Z.run(T, 2, 14, 14, 3, "\uda17\ude56\udbd0\udda4\udb37\ude48\udaf4\udf41\ud966\udfd8\ud930\udce6\000\000\ud936\ude1b\000\000\ud8ae\udd57\udbe1\udde4\ud82a\udf0c\ud8f0\ude18\ud8be\udf89\ud9dc\udd1a\ud813\udc12\udbe4\udcdc\udaf6\udc60\ud9eb\udca9\udb8a\udd5c\uda4f\udd4e\u009d\000", "\u74d1\u6bd8\u32ce\u7734\u9670", "\udb39\ude49\ud99a\udffd\ud89f\udc03",
        10, 84137, -870089833, -4584653314593727225L, 3622L, false, false, (char) 41566, (char) 43770,
        Double.longBitsToDouble(0x3fef250648001614L), Double.longBitsToDouble(0x0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.util.FastMath|max|double,double|static",
    "M|org.apache.commons.math.util.FastMath|max|float,float|static",
    "M|org.apache.commons.math.util.FastMath|max|int,int|static",
    "M|org.apache.commons.math.util.FastMath|max|long,long|static",
    "M|org.apache.commons.math.util.FastMath|abs|double|static",
    "M|org.apache.commons.math.util.FastMath|abs|float|static",
    "M|org.apache.commons.math.util.FastMath|abs|int|static",
    "M|org.apache.commons.math.util.FastMath|abs|long|static",
    "M|org.apache.commons.math.util.FastMath|acos|double|static",
    "M|org.apache.commons.math.util.FastMath|acosh|double|static",
    "M|org.apache.commons.math.util.FastMath|asin|double|static",
    "M|org.apache.commons.math.util.FastMath|asinh|double|static",
    "M|org.apache.commons.math.util.FastMath|atan|double,double,boolean|static",
    "M|org.apache.commons.math.util.FastMath|atan|double|static",
    "M|org.apache.commons.math.util.FastMath|atan2|double,double|static",
    "M|org.apache.commons.math.util.FastMath|atanh|double|static",
    "M|org.apache.commons.math.util.FastMath|max|double,double|static",
    "M|org.apache.commons.math.util.FastMath|max|float,float|static",
    "M|org.apache.commons.math.util.FastMath|max|int,int|static",
    "M|org.apache.commons.math.util.FastMath|max|long,long|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
