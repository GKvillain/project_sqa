package org.apache.commons.math3.optim;
import org.junit.Test;
import static org.junit.Assert.*;
public class BaseOptimizer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 14, 7, "\ud9a4\ude8c\udbda\ude43\ud93b\udd2d\u188b\ud811\ude00\ud913\ude4c\ud947\uddc9\ud9f6\udd72\udb33\uddf9\ud99e\udd4c", "\u492f\u2b86\ubdb6\u4d70\uca66\u276a", "\udaba\udc51\udae3\uded7\uda7e\udc26\ud9ae\ude96\uda48\udd09\udb3b\udc5b\ud906\udcab",
        33, 13278, -1222165358, 6396400780611583965L, 67276L, false, false, (char) 63091, (char) 16213,
        Double.longBitsToDouble(0x3fcf082c3b89ee14L), Double.longBitsToDouble(0x3fc94ce68be36cf0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 14, 7, "\ud9a4\ude8c\udbda\ude43\ud93b\udd2d\u188b\ud811\ude00\ud913\ude4c\ud947\uddc9\ud9f6\udd72\udb33\uddf9\ud99e\udd4c", "\u1d55\u2b86\ubdb6\u4d70\uca66\u276a", "\udaba\udc51\udae3\uded7\uda7e\udc26\ud9ae\ude96\uda48\udd09\u2dc4\ud906\udc59",
        33, -954, -1224736768, 6396400780611583965L, 67276L, false, false, (char) 63091, (char) 16213,
        Double.longBitsToDouble(0x3fcf082c3b89ee14L), Double.longBitsToDouble(0x3fc94ce68be36cf0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 1, 19, 14, 7, "\udbe2\udf7b\udb1f\ude38\ud9f9\udf82\ud818\ude50\ud808\udff9\uda17\udc8c\uda5b\ude25\uda19\udfdd\udb33\uddf9\ud99e\udd4c", "\u492f\u2b86\ubdb6\u4d70\uca66\u276a", "\udaba\udc51\udae3\uded7\uda7e\udc26\ud9ae\ude96\u83b8\udb3b\udc5b\ud906\udcab",
        33, 80774, -1222165358, 6396400780611583965L, -5132L, false, false, (char) 63091, (char) 16213,
        Double.longBitsToDouble(0x3fcf082c3b89ee14L), Double.longBitsToDouble(0x3fc94ce68be36cf0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 14, 7, "\ud9a4\ude8c\udbda\ude43\ud93b\udd2d\u188b\uda49\udc7b\ud913\ude4c\ud947\uddc9\ud9f6\udd72\udb33\uddf9\ud99e\udd4c", "\u492f\u2b86\ubdb6\u4d70\ucc41\u276a", "\udaba\udc51\udae3\uded7\uda7e\udc26\ud9ae\ude96\uda48\udd09\udb3b\udc5b\ud906\udcab\udaf1\ude94\u1dd0\udbf8\udc5c",
        56, 69109, -74434612, -1656917206117502860L, -21529L, false, false, (char) 2663, (char) 12798,
        Double.longBitsToDouble(0x3fe7c6df71b61d3fL), Double.longBitsToDouble(0x3fd21301041b3e90L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 17, 10, "\ud82b\udf39\uda8b\udf84\udb15\uddd8\ud84e\udf41\ud82f\udd52\ud913\ude4c\ud947\uddc9\ud9f6\udd72\udaa3\uddf1\ud99e\udd4c", "\ucb20\u2b86\ubdb6\uac9f\uca66\u276a", "\uda36\ude0c\ud829\udfb1\ud804\udc99\ud8ff\ude87\uda62\udca5\udbf2\udca7\ud908\ude1c",
        33, 13278, -1222165358, 6396400780611583965L, 67276L, false, false, (char) 63091, (char) 16213,
        Double.longBitsToDouble(0x3fcf082c3b89ee14L), Double.longBitsToDouble(0x3fc94ce68be36cf0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.TooManyEvaluationsException\012",
        Z.run(T, 1, 12, 17, 17, "\ud9a4\ude8c\udbda\ude43\ud93b\udd2d\u188b", "\u21cb\u0148\ub706\u548b\ub10f\ud0f3\u492f\u2b86\ubdb6\u7870\uca66\u276a\u85bc\u1740\u83b3\u3b4f\u8513\u9f82\u84a6\u3119\u1a01\u30f7", "\ud89e\uddda\udac6\udff5\ud809\udf89\uda01\udfa5\ud8ef\udec4\ud8a7\udc13\ud943\ude61\ud9e9\udc3f\u3cf7\ud947\ude9f\udb19\ude79\uda58\udfeb\ud8fa\udde2\udbdf\udf13\ud9b0\udebf\ud9b3\udd89",
        49, 6213, -931721770, 127451032872632537L, -95260L, false, false, (char) 64778, (char) 54922,
        Double.longBitsToDouble(0x3fddb806b4e6b994L), Double.longBitsToDouble(0x3fe1209450351648L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 15, 7, "\udb09\udfdf\udb68\udc77\ud93b\udd2d\ud9da\udc94\ud811\ude00\ud832\udfdc\ud974\udce6\ud9f6\udd72\ud878\udd5d\uda46\udce1", "\u09e7\u39a6\ubdb6\u6c81\uca66\u276a", "\udaba\udc51\ud8dd\udfef\uda7b\udd89\ud963\ude57\udb8d\udcdc\uda61\udcb7\uda5f\udd6c",
        17, 17059, -1222165358, 6396400780611583940L, 70604L, false, false, (char) 63091, (char) 18851,
        Double.longBitsToDouble(0x3fcf678c3b89ee14L), Double.longBitsToDouble(0x3fad991a2f8db3c0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 14, 17, "\ud9a4\ude8c", "\ua62d\u1d2c\ud3c3\u127c\u0106\u2d66\ud174", "\udbb2\ude43\udad5\udcc2\ud811\udf62\ud94d\udd02\udb90\udc66\ud9e7\ude7a",
        21, 25217, -1141310380, -8178231776287546602L, -98566L, false, true, (char) 53829, (char) 6907,
        Double.longBitsToDouble(0x3fe7a616ac920e3dL), Double.longBitsToDouble(0x3fc3f6e4e5c95310L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\012",
        Z.run(T, 1, 9, 14, 7, "\ud9a4\ude8c\udbda\ude43\ud93b\udd2d\u188b\ud822\udcc6\udbf6\udc1a\uda37\udd7c\ud9f6\udd72\ud894\udc93\udb0f\udd46", "\u492f\u2b86\ubdb6\u4d70\uca66\u276a", "\udadc\udf36\uda10\udc91\uda7e\udc26\ud9ae\ude96\uda48\udd09\udb3b\udc5b\ud906\udcab",
        33, 13278, -1222165358, 6396400780611583965L, 67276L, false, false, (char) 63091, (char) 16213,
        Double.longBitsToDouble(0x3fcf082c3b89ee14L), Double.longBitsToDouble(0x3fe65339a2f874e5L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\012",
        Z.run(T, 1, 10, 1, 7, "\ud9a4\ude8c\udbda\ude43\ud93b\udd2d\u188b\ud811\ude00\ud913\ude4c\ud947\uddc9\ud9f6\udd72\udb33\uddf9\ud99e\udd4c", "\u492f\u2b86\u9595\u3cd9\uca66\u276a", "\udaba\udc51\udae3\uded7\uda7e\udc26\ud9ae\ude96\uda48\udd09\udb3b\udc5b\ud906\udcab",
        33, 13278, -1222165358, 3300738989063700863L, 19788L, true, false, (char) 63091, (char) 16213,
        Double.longBitsToDouble(0x3fcf082c3b89ee14L), Double.longBitsToDouble(0x3fc94ce68be36cf0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 14, 7, "\ud84a\udec0\ud862\udd07\ud95b\udeea\udb13\udf2d\ud811\udde8\uda4f\udf46\ud89d\udcb5\uda1a\udd87\udb33\uddf9\ud828\udf73", "\u492f\u3973\u3996\u6fec", "\ud836\udf6a\ud82d\udd64\udaba\udc51\udae3\uded7",
        5, 74228, 1890056806, -1720324737688976814L, 55878L, false, false, (char) 19026, (char) 17940,
        Double.longBitsToDouble(0x3fee668b1294fb90L), Double.longBitsToDouble(0x3fbd15805a935910L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[null, null, null]] |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\012",
        Z.run(T, 1, 15, 14, 7, "\ud9a4\ude8c\udbda\ude43\ud93b\udd2d\u188b\udb47\ude5a\uda98\ude01\ud947\ude7a\ud9c6\udc39\ud819\udec5\ud99f\udfae\udb0d\udfe7\uda12\udcf5", "\ubdb6\u4d70\uca66", "\ud82d\udd64\udaba\udc51\udae3\uded7\udaca\udf0c\ud857\udf09\uda48\udd09\udb3b\udc5b\ud906\udcab\ud8b3\udc3f\udb91\udcbf\udbf8\udc46\ud89e\uddda\udae1\udd1d\ud809\udf89\uda01\udfa5\ud8ef\udec4\ud8a7\udc13\ud943\ude61\ud9e9\udc3f",
        3, 10042, -159642888, -583689072031876463L, 74873L, false, true, (char) 9551, (char) 25205,
        Double.longBitsToDouble(0x3fcf3ee1486a3b7cL), Double.longBitsToDouble(0x3febc183f972a591L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\012",
        Z.run(T, 1, 13, 14, 3, "\uf57f\uda2a\udc76\ud92d\ude72\u188b\ud811\ude00\ud956\udcdc\ud95c\udf0c\ud9f6\udd72\udb33\uddf9\ud99e\udd4c\udb0d\udfe7", "\u2b86\ubdb6\uc81a\u8fd4\ubaec\u85bc\u7fd7\u4daf\u2204", "\uda48\udd09\udb3b\udc5b\ud906\udcab\ud855\udc30\ud9cd\ude33\udaa6\udc44\ud89e\uddda\udae1\udd1d\ud809\udf89\ud924\udfd5\ud8ea\udf28\ud8a7\udc13\ud943\ude61\ud9e9\udc3f\ud8a1\udcfd",
        22, 12272, 811056257, 3469805015104159485L, -57710L, false, false, (char) 6414, (char) 12288,
        Double.longBitsToDouble(0x3fc033c053bfa81cL), Double.longBitsToDouble(0x3fd337ba31181cdcL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 14, 4, "\ud9a4\ude8c\udbda\ude43\ud93b\udd2d\u188b\ud811\ude00\ud96c\udf4b\ud9ff\udfc6\udadd\udfb8\ud91d\udd7c\ud99e\udd4c", "\u492f", "\ud94d\udd02\udb90\udc66\ud9e7\ude7a\udaab\udfe4\ud808\uddca\udaba\udc51\udae3\uded7\uda8c\uddb9\uda2c\udc5e\uda48\udd5e\udb8f\uddc5\ud8d8\udea5\uda2e\udd60\udb2e\udf04\udbf8\udc46\ud89e\uddda\udae1\udd1d\uf28f\udb70\udea6\ud8ef\ude6d\ud8a7\udc13\ud943\ude61\ud9c1\udc4c\ud8a0\udd02\ud947\ude82\ud8b7\udd91",
        51, 95285, -930281974, 6403314067863896131L, 74423L, false, false, (char) 2208, (char) 23190,
        Double.longBitsToDouble(0x3fd6b26290adccf4L), Double.longBitsToDouble(0x3fc94c995cdae0dcL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 14, 7, "\udbd6\udf09\udb6e\udfcc\ud93b\udcbe", "\u3866\u4821\u32c8\ub706\u59bc\u65cf\u0aba\u9c01", "\ud94d\udd02\udb90\udc66\ud9e7\ude7a",
        24, 25148, -1141310380, -1538602777995196281L, 18343L, false, true, (char) 35893, (char) 12808,
        Double.longBitsToDouble(0x3fe1704e58780e3dL), Double.longBitsToDouble(0x3fbc84cebeeac620L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[null]] |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\012",
        Z.run(T, 1, 15, 14, 7, "\ud9a4\ude8c\udbda\ude43\ud93b\udd2d\ud921\udcab", "\u4821\u228e\u10a3\ucd13\ub12d\ud087\uaedc\u424b\ubdb6\u4d70\uca66\u276a\u85bc\u7fd7\u0d2f\uc703\u932b\u2eda\u5750\u62d1\u1a01\ub813", "\ud894\udfda\udae7\udd23\ud809\udf89\uda01\udfa5\ud8ef\udec4\ud8a7\udc13\ud943\ude61\ud9e9\udc3f",
        1, 7669, -387187111, 172735815501707304L, 86979L, true, true, (char) 31573, (char) 22933,
        Double.longBitsToDouble(0x3fd23df3d06a7e4eL), Double.longBitsToDouble(0x3fe84321e547df64L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 1, 20, 16, 7, "\ud9a4\ude6f\udbda\ude43\ud9a1\udd1f\ud935\udee5\uda67\udd74\u27a5\ud956\ude74\ud9f6\udd72\udb33\uddf9\ud99e\udd4c", "\u492f\u2b86\ubdb6\u1c8f\u9665\u276a", "\udaba\udc51\udae3\uded7\uda7e\udc26\ud9ae\ude96\uda20\udf3c\udb3b\udc5b\ud906\udcab",
        34, 13278, -1222165358, 6396400780611583965L, 67276L, false, false, (char) 63091, (char) 16213,
        Double.longBitsToDouble(0x3fcf082c3b89ee14L), Double.longBitsToDouble(0x3fc94ce68be36cf0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:2147483647 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\012",
        Z.run(T, 1, 11, 6, 20, "\ud9a4\ude8c\udbda\ude43\uda10\udd7d\u189d\ud811\uddd7\ud913\ude4c\udbc7\udcad\uda19\udefe\udb33\uddf9\ud99e\udd4c", "\u0a39\u2b86\u0b26\u4d70\uca66\u276a", "\udaba\udc51\udae3\uded7\uda7e\udc26\ud9ae\ude96\uda24\udcd8\udb67\udd27\ud906\udcab",
        33, 13278, -1222165358, 6396400780611583965L, 67276L, false, false, (char) 63091, (char) 16213,
        Double.longBitsToDouble(0x3fcf082c3b89ee14L), Double.longBitsToDouble(0x3fc94ce68be36cf0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NumberIsTooSmallException\012",
        Z.run(T, 1, 2, 13, 8, "\ud9a4\ude8c", "\u9b36", "\ud947\uddc9\ud9f6\udd38\000\ud99b\udf4c\udb0d\udfe7\uda8d\udcf3\u00ee\udad2\udf48\000\000\udb62\udc91\ud9e7\ude7a\000\ud94e\udc06\000\000\000\ud9ae\ude3a\uda48\udd09\udb8f\uddc5\u9a5d\000",
        -5, -1000, 1489278111, -3358981784891017268L, 43476L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe7c6d9e3acd1e5L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\012",
        Z.run(T, 1, 8, 19, 0, "\ud89a\udd88\ud984\udd75\udb15\udd1e\ud448\ud811\ude00\ud913\ude4c\ud947\uddc9\ud9f6\udd72\udb33\uddf9\ud886\udf1b", "\u492f\u2b86\ubdb6\u4d15\uca66\u5c73", "\ud92c\udd0f",
        10, 27294, -1928599050, 8117732167810821572L, -45183L, false, false, (char) 19151, (char) 19398,
        Double.longBitsToDouble(0x3feeeac626ccd162L), Double.longBitsToDouble(0x3fe4a7dc80745601L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\012",
        Z.run(T, 1, 7, 17, 10, "\ud9a4\ude8c\udbda\ude43\ud93b\udd2d\u188b\ud811\ude00\ud913\ude4c\ud947\uddc9\ud9f6\udd72\udb33\uddf9\ud99e\udd4c", "\u492f\u2b86\ubdb6\u4d70\uca66\u276a", "\udaba\udc51\udae3\uded7\uda7e\udc26\ud9ae\ude96\uda48\udd09\udb3b\udc5b\ud906\udcab",
        33, 61070, -1222165358, 6561315010893913500L, 67334L, false, false, (char) 63091, (char) 16171,
        Double.longBitsToDouble(0x3fcf082c3b89ee14L), Double.longBitsToDouble(0x3fc94ce68be36cf0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 14, 7, "\udbe2\udf7b\udb1f\ude38\ud9f9\udf82\ud818\ude50\ud808\udff9\uda17\udc8c\uda5b\ude25\uda19\udfdd\udb33\uddf9\ud99e\udd4c", "\u492f\u2b86\ua1b0\u590b\u4344\u82b4\u9ad9\u465d", "\uda34\udca1\uda78\udc70\u83b8\udb3b\udc5b\ud906\udcab\ud855\udc30\ud8a6\udd28\ud97c\udf47\udb80\udf01\udac4\udc5e\ud837\ude5f\uda01\udfa5\ud8ef\udec4\ud8a7\udc13\ud943\ude61\ud9e9\udc3f\u3cf7\ud947\ude9f\ud9a5\ude48\uda3e\uddc0\ud946\udc2b\udad4\udcb9\uda4e\udf27\ucbdf\ud95c\udca7\udb3a\udcd7\udba4\udd7b\ud92d\udecf\ud8f1\udfcc\ud902\udedc\udbc1\uddc8\ud863\udcf9\ud80a\udd3b\ud868\uddd8\ud832\udd5f\u75d6\ud8ab\ude68\udb79\udc2c\ud9fa\udc2b\uda3b\udca0\ud826\udcef\udb95\udd31\ud811\udec6\ud912\udc60\ud821\udd3f\udac9\udf05\uda56\udee3\ud062",
        22, 39836, -1956242461, -7985116703566009696L, -49081L, false, false, (char) 50919, (char) 42711,
        Double.longBitsToDouble(0x3fed307d13b45da4L), Double.longBitsToDouble(0x3fefebe42d409424L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NumberIsTooSmallException\012",
        Z.run(T, 1, 2, 14, 4, "\uda9c\ude88", "\ua62d\u1d2c\ud3c3\u127c\u0106\u2d66\ud174", "\udbb2\ude43\udad5\udcc2\ud811\udf62\ud94d\udd02\udb90\udc66\ud9e7\ude7a",
        21, 25217, 0, -8178231776287546602L, -98566L, false, true, (char) 53829, (char) 55290,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc3e00005c95310L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 18, 14, "\udbe8\udf70", "\u9e1d\u1398\u0fdb\ub11e\u4f15\u0942\ud174\u8e60\uad03", "\udb8f\udcd7\udacb\udeb8\uda42\udca1",
        43, 44086, -1989395586, -4962933594043640440L, -91450L, true, false, (char) 11372, (char) 28741,
        Double.longBitsToDouble(0x3fa8e9e02d5c2d50L), Double.longBitsToDouble(0x3fdf0196408e4560L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 10, 3, 1, "\ud9a4\ude8c\udbda\ude43\ud865\udf27\u188b\ud811\ude00\ud8c8\udd0c\ud947\uddc9\udabe\udf36\udaeb\udf3b\ud949\udd24", "\u484a\u2b86\u5dc9\u3cd9\u130d\u69fc\u4f3c", "\udb04\udc60\uda7e\udc26\ud9ae\ude96\uda48\udd09\udb3b\udc5b",
        52, 26343, 238879278, 3691610918086638327L, 18629L, true, true, (char) 16213, (char) 26931,
        Double.longBitsToDouble(0x3fbb579ac65339a0L), Double.longBitsToDouble(0x3fe7c6d9e3aa18a0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 1, 16, "\udbe5\udefc\udbda\ude97\ud804\udc29\u500f\ud97d\udfbf\ud8ea\uddee\ud82b\udc12\uda3e\udcf9\ud9ac\udc55\ud99e\udd4c", "\u0eff\u7086\u9595\u9326\uc9d4\u276a", "\udaba\udc51",
        47, 43550, -1927812667, 8117732170872151496L, -84949L, false, false, (char) 4410, (char) 32990,
        Double.longBitsToDouble(0x3f949fd391cff6a0L), Double.longBitsToDouble(0x3fdcb0b8f3b761a4L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 13, "\u8a58\ud89b\udc35\ud9bf\udc3d\udafe\udeec\udb3d\udc00\uda1b\udd6a\ud8b6\udedb\ud9e6\ude2d\udb6d\uddb1\udba4\udc6b", "\u9426\u39ec", "\ud87f\uddce\udbe6\ude4a\uda10\udfe8\ud98c\ude64",
        50, 76272, -550861962, -8279892145236084122L, -13237L, false, true, (char) 32841, (char) 46641,
        Double.longBitsToDouble(0x3fdb44206fbb8c6cL), Double.longBitsToDouble(0x3fc69d05aa53ec18L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[null]] |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 14, 7, "\ud9a4\ude8c\udbda\ude43\ud93b\udd2d\u188b\udb47\ude5a\ud994\udca3\udb06\udc24\ud9c6\udc39\ud819\udec5\ud99f\udfae\udb0d\udfe7\uda12\udcf5", "\u7680\u842b\uc9e1\u276a\u80ed\u7fd7\u83b3\uc703\ubbb0\ub443\u47eb\u3178\u1a01\u3943\u5294", "\udae1\udd1d\ud809\udf89\uda7f\udcae\ud8ef\udec4\ud8a7\udc13\ud9d5\ude6a\ud9e9\udc3f\u3cf7\ud947\ude9f\ud9a4\ude68\udb20\udd67\ud9f3\udd83\udb95\udd21\ud8f6\ude7b\uda29\ude00",
        17, 18650, 2071876476, -645449649940869895L, -9000L, false, true, (char) 52545, (char) 60154,
        Double.longBitsToDouble(0x3fe129eaf2e6f2a7L), Double.longBitsToDouble(0x3fe911f2e666af6fL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[null, null, null]] |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 14, 7, "\ud9a4\ude8c\udbda\ude43\ud93b\udd2d\u188b\udb47\ude5a\uda98\ude01\ud947\ude7a\ud9c6\udc39\ud819\udec5\ud99f\udfae\udb0d\udfe7\uda12\udcf5", "\ubdb6\u4d70\uca66", "\ud82d\udd64\udaba\udc51\udae3\uded7\udaca\udf0c\ud857\udf09\udb5f\udd05\udb3b\udc5b\ud906\udcab\ud8b3\udc3f\udb91\udcbf\udbf8\udc46\ud82f\udee4\udae1\udd38\ud809\udf89\uda01\udfa5\ud8ef\udeee\ud8a7\udc13\ud943\ude61\ud9e9\udc3f",
        3, 10042, -159642888, -583689072031876463L, 74873L, false, true, (char) 9551, (char) 25205,
        Double.longBitsToDouble(0x3fcf3ee1486a3b7cL), Double.longBitsToDouble(0x3febc183f972a591L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Integer:2147483647 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=java.lang.Integer:2147483647 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\012",
        Z.run(T, 2, 11, 11, 7, "\ud8a2\ude6e\udbda\ude43", "\u7b54\u755b\u223a\u7a42\u9912\u04c9\ubd81\u4544", "\ud9b7\ude74\ud90b\udc1b\udbd6\udd0b",
        16, 30899, -1989370783, -4901890755752645240L, -94204L, true, false, (char) 40406, (char) 17745,
        Double.longBitsToDouble(0x3fead655da2ec4a8L), Double.longBitsToDouble(0x3fa6d93349fb7270L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NotStrictlyPositiveException\012",
        Z.run(T, 1, 2, 13, 8, "\ud9a4\ude8c", "\u9b36", "\ud947\uddc9\ud9f6\udd38\u9fec\ud9af\udcf7\udb0d\udfe7\uda8d\udcf3\u00ee\uda2d\udc23\ud85f\uddf3\uda46\udcb4",
        53, 46075, 0, 30399297484750848L, -100000L, false, true, (char) 34685, (char) 40555,
        Double.longBitsToDouble(0x3fe29001000000bbL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=void |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\012",
        Z.run(T, 2, 13, 13, 8, "\ud9a4\ude8c\ud8ff\udc43\ud9ea\ude11", "\u1da7\u4818\u10cd\000\uc656\u677b\ud087\ub056\u2a92\u3ec2\u60db\u12b4\u9699\u45a1\u668d\000\000\ub12e\uac12\u47eb\u1dea\ucb2f\000\uaecc\000\uc855\u3251\u46b0\u6e78\u709c\000\u3d0f\ucc96\u12f8\uca70\uca8a\u4757\u6263\u1dee\u6a23\ubae0\u36c9\u6a09\ubdf1\u8a20\u132f", "\ud84c\udd9a\ud8f7\udef7\uda01\udfb6",
        33, 44781, 1019564546, -1943201911642650923L, -90893L, false, false, (char) 57364, (char) 24622,
        Double.longBitsToDouble(0x3fd7341095e932f6L), Double.longBitsToDouble(0x3fe8a70481291338L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 9, 19, 0, "\ud89a\udd88\ud95e\udd45\udb15\udd1e\ud448\ud811\ude00\uda44\udde4\ud947\ude89\ud9f6\udd72\udb33\uddf9\ud886\ude73", "\u492f\u2b86\ubdb6\u4d15\uca66\u5c73", "\ud952\udd0f",
        10, 27294, -1928599050, 8117732167810821572L, -87415L, false, false, (char) 19151, (char) 19398,
        Double.longBitsToDouble(0x3feeeac626ccd162L), Double.longBitsToDouble(0x3fe4a7dc80745601L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 13, 4, 10, "\udbe2\udf7b\udb1f\ude38\ud9f9\udf82\ud818\ude24\ud808\udff9\uda17\udc8c\uda5b\ude25\uda19\udf95\udb33\uddf9\ud99e\udd4c", "\u492f\u2b86\ua1b0\u590b\u4344\u82b4\u9ad9", "\udae3\uded7",
        57, 77814, -564520791, -7737208386268699735L, 96074L, false, false, (char) 22548, (char) 42158,
        Double.longBitsToDouble(0x3fc197e946b7c0d8L), Double.longBitsToDouble(0x3fbd35071a935910L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 13, "\udbe2\udf7b\ud95b\uddb6\uda3a\udccc\ud8fe\udea2\ud833\udf3f\uda17\udc8c\uda5b\ude25\uda19\udfdd\udb33\uddf9\ud99e\udd4c", "\u30d1\u2b86\ua21b\u590b\ud201\u4c4c\u4cc0\u465d", "\uda34\udca1\ud8a8\udc8c\ud9c0\udef8\udb3a\udfa0\ud906\udcab\ud855\udc30\ud8a6\udd28\ud97c\udf47\udb80\udf01\udac4\udc5e\ud837\ude5f\uda01\udfa5\uda66\udfaf\ud8a7\udc13\ud943\ude61\ud9e9\udc3f\u3cf7\ud947\ude9f\ud9d0\udf48\uda3e\uddc0\ud946\udc2b\udad4\udcb9\uda4e\udf27\ucbdf\ud915\udd35\udb3a\udcd7\udba4\udd7b\ud92d\udecf\ud8f1\udfcc\ud902\udedc\udbc1\uddc8\ud863\udcf9\ud80a\udd3b\ud868\uddd8\ud832\udd5f\u75d6\ud8ab\ude68\udb79\udc2c\ud9fa\udc2b\uda3b\udca0\ud826\udcef\udb95\udd31\udae4\udf4f\ud912\udc4f\ud821\udd3f\udac9\udf05\uda56\udee3\ud062",
        54, 62355, -431440755, -7985130932792661344L, -49081L, false, false, (char) 50919, (char) 42711,
        Double.longBitsToDouble(0x3fed307d13b45da4L), Double.longBitsToDouble(0x3fefebe42d409424L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 7, "\udbe2\udf7b\udb1f\ude38\ud9f9\udf82\ud818\ude50\ud808\udff9\uda17\udc8c\ud83b\udd1f\udae7\udca5\ud892\udf9c\ud99e\udd4c", "\u492f\u2b86\ua1b0\u590b\u4344\u82b4\u9ad9\u465d", "\ud97c\ude9f\uda78\udc70\u83b8\udb3b\udc5b\ud906\udcab\ud855\udc30\ud8a6\udd28\ud97c\udf47\udb80\udf01\udac4\udc5e\ud837\ude5f\u212a\udb13\udc24\ud8a7\udc13\ud943\ude61\ud9e9\udc3f\u3cf7\ud947\ude9f\ud93d\ude2b\uda3e\uddc0\ud946\udc2b\udad4\udcb9\uda4e\udf27\ucbdf\ud95c\udca7\udb3a\udcd7\udba4\udd7b\ud92d\udecf\ud8f1\udfcc\ud902\udedc\udbc1\uddc8\ud863\udcf9\ud80a\udd3b\ud868\uddd8\ud832\udd5f\u75d6\ud8ab\ude68\udb79\udc2c\ud9fa\udc2b\uda3b\udca0\ud826\udcef\udb95\udd31\ud811\udec6\ud912\udc60\ud821\udd3f\udac9\udf05\uda56\udee3\ud062",
        22, 39836, -1956242461, -7985116703566009696L, -49081L, false, false, (char) 18407, (char) 42711,
        Double.longBitsToDouble(0x3fed307d13b45da4L), Double.longBitsToDouble(0x3fefebe42d409424L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=null |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\012",
        Z.run(T, 2, 7, 7, 7, "\udbe2\udf7b\udb1f\ude38\ud9f9\udf82\ud818\ude50\ud808\udff9\uda17\udc8c\uda5b\ude25\ud81d\udfac\udb33\uddf9\ud99e\udd4c", "\u492f\u2b86\ua1b0\u590b\u4344\u82b4\u9ad9\u465d", "\uda34\udca1\uda78\udc70\u83b8\udb3b\udc5b\ud906\udcab\ud855\udc30\ud8a6\udd28\ud97c\udf47\udb80\udf01\udac4\udc5e\ud653\ud891\ude44\uda68\udfc6\ud8a7\udc13\ud943\ude61\ud9e9\udc3f\u3cf7\ud947\ude9f\ud9a5\ude48\uda3e\uddc0\ud946\udc2b\udad4\udcb9\uda4e\udf27\ucbdf\ud95c\udca7\udb3a\udcd7\ud9ac\ude76\udb61\udd78\ud907\udd61\ud8d5\udcc1\ud9f4\udce8\ud871\udd93\ud80a\udd3b\ud868\uddd8\ud832\udd5f\u75d6\ud8ab\ude68\udb79\udc2c\ud9fa\udc2b\uda3b\udca0\ud826\udcef\udb95\udd31\ud811\udec6\ud912\udc60\ud821\udd3f\udac9\udf05\uda56\udee3\ud062",
        22, 39836, -1956242461, 4985250221888071825L, -49081L, false, true, (char) 50919, (char) 42711,
        Double.longBitsToDouble(0x3fed307d13b45da4L), Double.longBitsToDouble(0x3fefebe42d409424L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 18, 14, "\udba2\udc67", "\u9e1d\u1398\u0fdb\ub11e\u4f15\u8852\ud174\u8e60\ub430", "\udb8f\udcd7\udacb\udeb8\ucebb",
        0, 44086, 126, -4971973988617027448L, -100000L, false, false, (char) 65191, (char) 28741,
        Double.longBitsToDouble(0x3fa8e9e02d5c2d50L), Double.longBitsToDouble(0x3f196408e4400000L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\012",
        Z.run(T, 2, 10, 10, 19, "\udbdf\uddb3", "\u8f00\ud0e8", "\udaa0\udd31",
        13, 33027, -1446034752, 2551534258640760462L, 10077L, true, false, (char) 52510, (char) 11416,
        Double.longBitsToDouble(0x3fd96837660f677cL), Double.longBitsToDouble(0x3fdd3a96cb103eacL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!org.apache.commons.math3.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 10, 12, 14, "\udbe8\udf70", "\u0a8f\000\u0fbe\ub11e\u6db9\u0942\ud174\u8e60\uad03", "\udb8f\udcd7\u00d1\uda42\udca1",
        43, 44086, -1989395586, -4962933594046594936L, -34464L, true, false, (char) 11372, (char) 28741,
        Double.longBitsToDouble(0x3fa8e9e02d5c2d50L), Double.longBitsToDouble(0x3fdf0196408e4560L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[]] |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 1, 9, "\ud9ee\udec2\ud89b\ude22", "\u1398\u0fdb\u5516\u2501\u9527", "\udbda\udcc1\udaa8\udd38\udb11\udc02\udbb1\udc0a\u75f7\ud8f5\udd81\ud9b7\uddff\udb6e\udd62\udaba\udea4\ud857\ude4a\ud860\udfd5\udb15\udf99",
        52, 24097, -94536150, 630617305152558314L, -98480L, true, false, (char) 19656, (char) 60664,
        Double.longBitsToDouble(0x3fefdb33ef013103L), Double.longBitsToDouble(0x3fd820fbbe3d4062L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[null, null, null]] |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[null, null, null]] |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\012",
        Z.run(T, 2, 15, 15, 14, "\udbe8\udf74\ud83d\udf22\ud885\ude40\u0f3b\ud81d\udecd\ud9d1\udca1\ud922\udf82", "\ud174\u8e60\uad03\ubabf\u4f53", "\uda42\udca1\uda8f\udf04",
        55, 10765, 1367381809, -2076980185997871147L, -67801L, false, true, (char) 28741, (char) 59377,
        Double.longBitsToDouble(0x3fe6ae16adf01964L), Double.longBitsToDouble(0x3fb1c8ac3ef74268L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\012",
        Z.run(T, 2, 8, 8, 14, "\udbe8\udf70", "\u9e1d\u2c98\u0fdb\ub11e\u4f15\u0942\ud174\u8e60\uad03", "\ud8aa\udfab\udacb\udeb8\uda42\udca1\ud855\udd01\ud880\udcf4\ud815\udc81\udba8\ude21\ud860\udfd5\ud829\udea3\udb45\udda6\udab8\ude24\ud8c4\ude00\ud99b\udd89\ud890\udc96",
        35, 99200, -1905571769, 8282690819112289184L, -43566L, true, false, (char) 4564, (char) 57687,
        Double.longBitsToDouble(0x3fc218ac0739b088L), Double.longBitsToDouble(0x3fd39daff10b492eL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\012",
        Z.run(T, 2, 9, 9, 5, "\u8a58\ud89b\udc35\ud9bf\udc3d\udafe\udeec\udb3d\udc00\uda1b\udd6a\ud8b6\udedb\ud9e6\ude2d\udb6d\uddb1\udba4\udc6b", "\u9426\u39ec", "\ud87f\udd80",
        25, 44154, 1546237174, -4901920608360524408L, -94358L, false, false, (char) 40555, (char) 49675,
        Double.longBitsToDouble(0x3fed7271cf1ae12fL), Double.longBitsToDouble(0x3fe4c4bcc9b40c81L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[null, null, null]] |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 0, 7, "\ud9a4\ude8c\udbda\ude43\ud93b\udd2d\u188b\udb47\ude5a\ud994\udca3\udb50\udc83\ud9c6\udca0\ud819\udec5\ud99f\udfae\udb0d\udfe7\uda12\udcf5", "\u7680\u842b\uc9e1\u276a\u773d\u15e3\u83b3\uc703\ubbb0\uc3f5\u47eb\u3178\u1a01\u3943\u5294\u5f0d\u2b80\u489d\uba89\u763a\uc187\u6166", "\u3cf7\ud947\ude9f\ud9a4\ude68\udb20\udd67\udaa9\udd1d\uda10\udf50\ud8f6\udf31",
        35, 137, -1982677142, 7934265902313679058L, 43679L, false, true, (char) 12467, (char) 52545,
        Double.longBitsToDouble(0x3fec5f837d253de4L), Double.longBitsToDouble(0x3fe73790f7223e5cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!org.apache.commons.math3.exception.NumberIsTooSmallException\012",
        Z.run(T, 2, 10, 18, 14, "\udba2\udc67", "\u9e1d", "\udbe5\udd24\ud8af\udc01\u320c\ud8d1\ude4e\ud111\ud803\uddb6\ud841\udf20",
        -3, 54452, -27005231, -6557013753954200728L, -99770L, false, false, (char) 48008, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd00fea704a5000L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optim.linear.SimplexSolver:@?\0121=!org.apache.commons.math3.exception.NotStrictlyPositiveException\012",
        Z.run(T, 2, 10, 18, 14, "\ud969\ude33", "\u9e1d\u1398\u4614\ub0e9\u4f15", "\uda97\ude82",
        58, 84917, 680646462, 6175164496144810310L, -100000L, false, true, (char) 45540, (char) 0,
        Double.longBitsToDouble(0x3fc1176000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 1, 19, 1, 10, "\ud9a4\ude8c\udba1\uddaf\ud980\udd9f\udb32\udef8\ud923\udd8b\ud913\ude9f\ud947\uddc9\ud8a2\udd4b\udbe0\udce0\ud99e\udd4c\udb0d\udfe7\uda8d\udcf3\uda6c\udcda\udad5\udcc2\ud811\udf62\uda10\udce4\ud9bd\uddce\ud9e7\ude77\ud9d9\udc5b\ud812\udff8\udaba\udc51\ud84e\ude05\udb8b\udf24\ud9ae\ude96", "\u1a01", "\udbf8\udc46\ud89e\uddda\udae1\udd1d",
        10, 60254, 511528177, 872543759993221767L, -63422L, false, false, (char) 58932, (char) 42802,
        Double.longBitsToDouble(0x3fd04a90b8ce5204L), Double.longBitsToDouble(0x3fde3aca471b6d56L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer|doOptimize||new:org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer:org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer$Formula,org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer|doOptimize||new:org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer:int,double,boolean,int,int,org.apache.commons.math3.random.RandomGenerator,boolean,org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer|doOptimize||new:org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer:double,double",
    "M|org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer|doOptimize||new:org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer|doOptimize||new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer|doOptimize||new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math3.optim.BaseOptimizer|doOptimize||new:org.apache.commons.math3.optim.linear.SimplexSolver:",
    "M|org.apache.commons.math3.optim.BaseOptimizer|getConvergenceChecker||new:org.apache.commons.math3.optim.linear.SimplexSolver:",
    "M|org.apache.commons.math3.optim.BaseOptimizer|getEvaluations||new:org.apache.commons.math3.optim.linear.SimplexSolver:",
    "M|org.apache.commons.math3.optim.BaseOptimizer|getIterations||new:org.apache.commons.math3.optim.linear.SimplexSolver:",
    "M|org.apache.commons.math3.optim.BaseOptimizer|getMaxEvaluations||new:org.apache.commons.math3.optim.linear.SimplexSolver:",
    "M|org.apache.commons.math3.optim.BaseOptimizer|getMaxIterations||new:org.apache.commons.math3.optim.linear.SimplexSolver:",
    "M|org.apache.commons.math3.optim.BaseOptimizer|incrementEvaluationCount||new:org.apache.commons.math3.optim.linear.SimplexSolver:",
    "M|org.apache.commons.math3.optim.BaseOptimizer|incrementIterationCount||new:org.apache.commons.math3.optim.linear.SimplexSolver:",
    "M|org.apache.commons.math3.optim.BaseOptimizer|optimize|[Lorg.apache.commons.math3.optim.OptimizationData;|new:org.apache.commons.math3.optim.linear.SimplexSolver:",
    "M|org.apache.commons.math3.optim.BaseOptimizer|parseOptimizationData|[Lorg.apache.commons.math3.optim.OptimizationData;|new:org.apache.commons.math3.optim.linear.SimplexSolver:",
    "M|org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer|doOptimize||new:org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer:org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer$Formula,org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer|doOptimize||new:org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer:int,double,boolean,int,int,org.apache.commons.math3.random.RandomGenerator,boolean,org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer|doOptimize||new:org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer:double,double",
    "M|org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer|doOptimize||new:org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer|doOptimize||new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer|doOptimize||new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
