package org.apache.commons.math3.fraction;
import org.junit.Test;
import static org.junit.Assert.*;
public class Fraction_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 1, 3, 10, 15, "\ud94e\udff6\uda4e\ude41\ud9de\udf83", "\u113e\u9d13\u43e9\u09b3\u97b5\u230d\u3506\u3139", "\ud9a1\udd2a\ud8d7\ude0a\ud94c\udd59\ud898\ude5f\ud9c0\udd46\udbb2\uddb8\ud86a\udf24\uda76\udf17\udbb3\udfe7\ud997\udd00\ud827\ude77\ud8f5\udf2d\ud9ab\ude40\ud97c\udd1f",
        42, 385, 53853275, -350980883008687569L, -20494L, true, true, (char) 19972, (char) 15362,
        Double.longBitsToDouble(0x3fe18c4e63547dcbL), Double.longBitsToDouble(0x3fe3185b4b9fe6a7L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 1, 3, 10, 15, "\ud979\udf6f\uda4e\ude41\ud9de\udf83\ud98b\udf52", "\u9d13\u43e9\u09b3\u97b5\u230d\u2ddf", "\uda39\uded6\ud9a1\udd2a\ud87b\udf06\ud94c\udd59\ud898\ude5f\ud9c0\udd46\udbb2\uddb8\ud86a\udf24\uda76\udf17\udb89\udf12",
        52, 38212, 316141073, 2814085386706455373L, -99641L, true, false, (char) 5108, (char) 8637,
        Double.longBitsToDouble(0x3fe2e8ca8692214cL), Double.longBitsToDouble(0x3fd81906d0cfdb38L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 1, 3, 6, 15, "\udb60\udc1e\uda4e\ude3c\ud952\udf7d", "\u113e\u9d13\u440e\u09b3\u97b5\u2bc8\u70ae\u3139", "\ud9a1\udd2a\ud8d7\ude0a\ud946\ude56\ud928\udd05\ud9c0\udcaa\udbb2\uddb8\ud86a\udf24\uda76\udf17\udbb3\udfe7\udb91\udd7c\ud827\ude6c\ud8f5\udf2d\ud9ab\ude40\ud97c\udd1f\ud862\udc1a\ud842\udc59\ud991\udc8b\ud9f2\udc75\udb98\udfac\uda21\ude39",
        37, 19089, -779606937, 6902894607903065579L, -96487L, true, false, (char) 9141, (char) 20382,
        Double.longBitsToDouble(0x3faded69f709ae70L), Double.longBitsToDouble(0x3fe752f0c64c2353L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 1, 3, 9, 15, "\ud94e\udff6\uda4e\ude41\ud9de\udf83\ud98b\udf52\udaea\udc55\ud85a\udcb0\uda39\ude6d\uda8f\udf7d\ud849\udfb4\uda29\udf0f\u04bd\ud84d\udde1", "\ua0d8\u98cf\u4da6\u77ed\u9a85\ua308\u9394\u2fe6\u1da8#", "\ud8b5\udd9a\udb16\uddab\udacd\uddde\ud860\udd7b\ud842\udc59\ud991\udc8b\ud9f2\udc75\udb98\udfac\ue451\uda4d\udcf1\uda26\udfad\ud918\udf27\ud809\udd24\udb45\udd9a\ud863\udc00\uda69\udee4\ud9d1\udc9d\udac6\ude44\udae9\udcb0\ud831\ude14\udb08\udc4d\u1607\uda88\ude20\ud8a3\udcfe",
        2, 20352, 1550264290, -6561884997050571391L, 43086L, false, false, (char) 31855, (char) 11256,
        Double.longBitsToDouble(0x3fedf4ea608ed02eL), Double.longBitsToDouble(0x3fd992cc2c39858eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 1, 3, 10, 15, "\ud94e\udff6\uda4e\ude41\ud9de\udf83", "\u113e\u9d13\u43e9\u09b3\u97b5\u230d\u3506\u8ab0", "\ud9a1\udd2a\ud98d\ude24\udb14\udd73\ud898\ude5f\ud9c0\udd46\udbb2\uddb8\ud86a\udf24\uda76\udf17\udbb3\udfe7\ud997\udd00\ud827\ude77\ud8f5\udf2d\ud9ab\ude40\uda7a\udd7e",
        42, 82319, 53853401, -350980883008687569L, -20573L, true, true, (char) 25139, (char) 18147,
        Double.longBitsToDouble(0x3fe189814b547dcbL), Double.longBitsToDouble(0x3fe3185b4b9fe6a7L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Float:0.5483871 |this=org.apache.commons.math3.fraction.Fraction:17 / 31\012",
        Z.run(T, 1, 10, 10, 15, "\ud994\udff8\ud92e\udc6a\ud9de\udf83\udb66\uddc1\uda4c\udfcd\ud8fa\udcdb\udad9\udf2b\uda8f\udf7d\ud849\udfb4", "\u3506\u3139\u8c91\u33c6\u98cf\u4da6\u7f88\u99f2\ua308\u9394\u37d3\u1da8", "\uda02\udec4\ud8f2\ude99\udab0\udec3\ud97c\udcf7",
        56, 24643, 1392875476, -350817520501576401L, 82669L, true, true, (char) 19972, (char) 15362,
        Double.longBitsToDouble(0x3fe18c4e603d87cbL), Double.longBitsToDouble(0x3fe719e3a39fe6a7L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Float:0.5483871 |this=org.apache.commons.math3.fraction.Fraction:17 / 31\012",
        Z.run(T, 1, 10, 10, 15, "\ud983\ude27\uda48\udc0e\ud82e\udcf4", "\u113e\u9d13\u43e9\u09b3\u97b5\u620d\u047b\u3139", "\ud9a1\udd2a\ud8d7\ude0a\ud94c\udd59\ud898\ude5f\udbfe\udd64\udab9\ude79\udab6\uddfb\uda76\udf17\udbb3\udfe7\ud997\udd00\ud827\ude77\ud867\udf26\ud9ab\ude40\ud97c\udd1f",
        42, 385, 53853275, -350980883008687569L, -20494L, true, true, (char) 19972, (char) 15362,
        Double.longBitsToDouble(0x3fe18c4e63547dcbL), Double.longBitsToDouble(0x3fe3185b4b9fe6a7L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 1, 7, 0, 13, "\ud94e\udff6\u0bdc\ud9de\udf5b", "\uac51\u9d13\u07ea\u09b3\u97b5\u230d\u3506\u3139", "\ud9a7\uddae\ud8c9\ude39\ud819\uddee\ud898\ude5f\ud9c0\udd46\udbb2\uddb8\ud86a\udf24\uda76\udf17\udabb\udd79\udb3f\ude5b\ud814\ude51\ud8f5\udf2e\ud9ab\ude40\ud855\udc9b",
        19, 681, 53853275, -350980883008687569L, 82638L, true, true, (char) 10048, (char) 15362,
        Double.longBitsToDouble(0x3fe18c4e63547dcbL), Double.longBitsToDouble(0x3fe3185b4b9fe6a7L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:295 / 16524 |this=org.apache.commons.math3.fraction.Fraction:295 / 459\012",
        Z.run(T, 1, 6, 10, 15, "\ud94e\udff6\udb74\ude34\udaec\udeea", "\u585a\u9d5a\u43e9\u09b3\ubd0b\u090e\u35b7\u30e3\u5d12\u039e\ua27c\u8f89", "\ud9c0\udd46\udbb2\uddb8\ud86a\udf24\uda76\udf17\ub64d\udaec\uddea",
        36, 10073, 1375394496, -2957735486961607955L, 13755L, false, true, (char) 52456, (char) 10953,
        Double.longBitsToDouble(0x3fe4910a48d94c5fL), Double.longBitsToDouble(0x3fda7199435861d4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 1, 3, 10, 0, "\ud94e\udff6\uda46\udee2\ud9de\udf83", "\u84cc\u9d13\u43e9\u09b3\u97b5\u230d\u3506\000", "\ud9a1\udd2a",
        53, 66608, -840499885, 15989784598544384L, 28924L, false, false, (char) 305, (char) 19039,
        Double.longBitsToDouble(0x3f4f7ecf00480000L), Double.longBitsToDouble(0x3fbb8a9cd7685e10L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 1, 0, 0, 15, "", "\u7f80\u6558\u11ea\002\000\000", "\ud8c9\udfa0",
        -5, 10832, 387266870, 4487168L, -100000L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3de6f91a00000000L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.FractionField:@? |this=org.apache.commons.math3.fraction.Fraction:17 / 31\012",
        Z.run(T, 1, 12, 4, 14, "\ud94e\udff6\uda4e\ude41\ud9de\udf83", "\u113e\u9d13\u43e9\u09b3\u97b5\u22de\u3506\u3139", "\udb35\udd94\uda41\udf91\ud951\udd86\ud898\ude5f\ud9c0\udd46\udbb2\uddb8\ud86a\udf24\uda76\udf17\udbb3\udfe7\ud845\ude0b\ud827\udeae\ud8f5\udf2d\ud9ab\ude40\ud97c\udd1f",
        42, 385, 53853275, -350980883008687569L, 8434L, true, false, (char) 12251, (char) 9489,
        Double.longBitsToDouble(0x3fe18c4e63547dcbL), Double.longBitsToDouble(0x3fe3185b4b9fe6a7L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 1, 4, 10, 15, "\ud94e\udff6\uda4e\ude41\ud9de\udf83", "\u113e\u9d13\u43e9\ubebc\u31f1\u230d\u3506\u54b0", "\ud9a1\udd2a\ud8d7\ude0a\udbc2\udd54\ud898\ude5f\ud9c0\udd46\udbb2\uddb8\udadd\udf1e\udb60\udd10\ud98c\udd45\ud997\udd00\ud827\ude77\ud8f5\udf2d\ud9ab\ude40\ud97c\udd1f",
        12, 385, 1951972443, -7596725654938175670L, -20494L, true, true, (char) 19972, (char) 15362,
        Double.longBitsToDouble(0x3fe1ff6abb54d05eL), Double.longBitsToDouble(0x3fecf5cb4b9fe673L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 1, 3, 10, 15, "\000\uda4e\ude41\ud9de\udf83", "\u113e\u9d13\u43e9\u1509\u97b5\u230d\u3506\u3139", "\ud9a1\udd2a\udadc\uddfb\ud94c\udd59S\ud98c\udea6\udbb2\uddb8\ud86a\udf24\uda76\udf17\udbb3\udfe7\ud997\udd00\ud827\ude77\ud8f5\udf2d\uda9d\ude39\ud97c\udd1f",
        42, 385, 0, 424673280L, -100000L, true, true, (char) 19972, (char) 0,
        Double.longBitsToDouble(0x3fe0000000007dcbL), Double.longBitsToDouble(0x3e3cf80000000000L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:35 / 13794 |this=org.apache.commons.math3.fraction.Fraction:35 / 242\012",
        Z.run(T, 1, 6, 3, 15, "\ud8da\ude3b\uda4e\udebc\ud9de\udf83", "\u12ff\ua35f\u3eef\uc577\u032f\ucd1f\u5a2d\u021c\u5a53\u2cd4\u992f", "\ud898\ude5f\uda52\udc5f\uda49\udf44",
        57, 39532, -115732400, 4910836358492689942L, 9801L, true, false, (char) 35804, (char) 33624,
        Double.longBitsToDouble(0x3fc282e5c2fc0cd4L), Double.longBitsToDouble(0x3fe7dfd90a5d1950L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:8 / 2043 |this=org.apache.commons.math3.fraction.Fraction:24 / 227\012",
        Z.run(T, 1, 6, 10, 15, "\uda59\udf38\ud831\udccd\ud9de\udf39", "\u113e\u8de1\u6385\u09b3\u97b5\u230d\u3506\u36c1", "\udb95\udee5\ud8d7\ude0a\ud94c\udd59\ud898\ude5f\uda93\udd51\udbb2\uddb8\ud86a\udf24\uda76\udf17\udb2f\udd44\ud997\udd4f\uda07\udd67\ud8f5\udf2d\ud9ab\ude40\udb10\udddd\ud830\udfef",
        27, 19275, -81719105, 1824083395830168157L, -25420L, true, false, (char) 14919, (char) 26840,
        Double.longBitsToDouble(0x3fbb106bfbf009d8L), Double.longBitsToDouble(0x3fd0239b6de13446L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.fraction.Fraction:17 / 31\012",
        Z.run(T, 1, 9, 9, 15, "\ud94e\udfaa\uda4e\ude41\ud9de\uded1", "\u44ce\ud357\u43e9\u09b3\u97b5\u230d\u3506\u3139", "\ud9a1\udd2a\ud8d7\ude0a\ud94c\udd59\ud898\ude5f\ud9c0\udd46\udbb2\uddb8\ud86a\udf24\uda76\udf17\udbb3\udfe7\ud997\udd00\ud827\ude77\ud8f5\udf2d\ud9ab\ude40\ud97c\udd1f",
        42, 385, 53853275, -350980883008687569L, -20494L, true, true, (char) 19972, (char) 15362,
        Double.longBitsToDouble(0x3fe18c4e63547dcbL), Double.longBitsToDouble(0x3fe3185b4b9fe6a7L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.FractionField:@? |this=org.apache.commons.math3.fraction.Fraction:71 / 134\0121=java.lang.Float:0.5298507 |this=org.apache.commons.math3.fraction.Fraction:71 / 134\012",
        Z.run(T, 2, 12, 10, 15, "\ud841\udc85\uda63\udd38\ud846\udd37", "\u113e\uad84\u0f86\u0919\u97b5\u8406\u3506\u0a73\u8d3f\ua0d8\u98cf\u4da6\u3889\u99f2\ua308", "\uda4d\uded2\ua644\ud8ce\uded3\ud995\udd62\ud8ab\udecd\uda12\uddea\ud956\udfb4\ud861\udf3d\ud842\udc59\udaa9\udc57\ud9b9\udf8d\udac3\udcf3\ud9a2\udff9\udae6\udc0e",
        -1, 32343, -1983081197, 2739523591202218836L, -28463L, false, true, (char) 53866, (char) 44363,
        Double.longBitsToDouble(0x3fe0f49daeefdd55L), Double.longBitsToDouble(0x3fee7904487b864eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:19 / 16067\012",
        Z.run(T, 1, 14, 5, 15, "\ud97e\udd9d\ud8d7\udc18\ud8e6\ude71\ud90a\udd73", "\u9d13\u43e9\u09b3\u97b5\u230d\u3506\u74b2\u8c91\u8d4a\ub068\u4dad\u49fb", "\uda00\uddfd\uda13\uddc0\uda76\udf17\udbcb\udfe7\ud99e\udddd\udae8\udda7\uda5a\ude1f\udb15\udf0b\u3cc6\ud9b6\udc24\uc852\ud991\udc8b\ud9f2\udc75\udb98\udfac\udbe2\udfc7\udb04\udf35\uda1e\udc6b\udbca\udf40\udad5\ude08\udb45\udd9a\ud863\udc00\udabb\udf6d\udbd3\udd04\ud870\udfbd\uda58\udc3d\udae9\udeff\ud92e\udfb6\ud858\udfca\uda3d\udc15\ud87a\udd6a\u80c7\ud961\udff5\ud944\udc22\udbe3\ude6f\uda3c\ude1a\ud95d\udc66\ud8ab\udeba\ud95b\udf35",
        38, 32134, 432917560, 4284447788989397625L, 99213L, false, false, (char) 24789, (char) 18485,
        Double.longBitsToDouble(0x3fe50e6b99bc6b03L), Double.longBitsToDouble(0x3fe3be219c6235c1L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:426 / 779 |this=org.apache.commons.math3.fraction.Fraction:426 / 779\012",
        Z.run(T, 1, 1, 10, 15, "\udb92\udc10\ud979\udc6f\ud9de\udf0e", "\u113e\u9d13\ucc8b\u093a", "\ud87e\udd7e\ud8c7\udea6\ud8cf\udc92\uda39\uded6\ud9a1\udd2a\ud8d7\ude0a\ud94c\udd59\ud898\ude5f\ud9c0\udd46\ud9c8\uddd9\udbda\udce0\ud8aa\ude0f",
        30, 43742, -67731788, 1357815571055034307L, 17979L, true, false, (char) 32770, (char) 5108,
        Double.longBitsToDouble(0x3fe17fd90a5d1950L), Double.longBitsToDouble(0x3fe491092981906dL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:17 / 1612 |this=org.apache.commons.math3.fraction.Fraction:17 / 31\012",
        Z.run(T, 1, 6, 0, 15, "\ud94e\udff6\uda4e\ude41\ud9de\udf83", "\u113e\u9d13\uaa16\u09b3\u778d\u230d\u3506\u3139", "\udbd1\ude17\ud8d7\ude0a\ud94c\udd59\ud898\ude5f\ud9c0\udd46\udbb2\uddb8\ud86a\udf24\uda76\udf17\udabb\udc05\ud997\udd00\ud827\ude77\ud8f5\udf2d\ud9ab\ude40\ud97c\udd39",
        52, 2320, 53853275, -350980884204785105L, -20494L, true, true, (char) 19972, (char) 15362,
        Double.longBitsToDouble(0x3fe18c4e645e28cbL), Double.longBitsToDouble(0x3fe31ae0b633e6a7L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:12992 / 305 |this=org.apache.commons.math3.fraction.Fraction:182 / 305\012",
        Z.run(T, 1, 2, 10, 15, "\ud94e\udff6\uda4e\ude41\ud9de\udf83", "\u113e\u2477\u3b19\u0653\u97b5\u230d\u3506\u3139", "\ud9a1\udd2a\ud8d7\ude0a\udba3\ude26\ud8a3\udf2b\ud99f\udc87\uda28\udff0\ud86a\udf24\uda76\udf17\udbb3\udfe7\ud93b\udffb\ud824\uded8\ud8f5\udf2d\ud9ab\ude40\ud97c\udd1f",
        42, 56409, 53828772, -350980883008687569L, -59143L, true, true, (char) 18429, (char) 41247,
        Double.longBitsToDouble(0x3fe3185b48e963a7L), Double.longBitsToDouble(0x3fd0498865f8b0eaL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:6 / 55\012",
        Z.run(T, 1, 14, 10, 15, "\ud94e\udff6\uda4e\ude41\ud9de\udf83", "\u113e\u9d13\ud256\uc68c\u97b5\u230d\u3506\u3139", "\ud9a1\udd2a\ud8d7\ude0a\ud94c\udd59\ud898\ude5f\ud9c0\udd46\udbc8\udfb8\ud86a\udf1c\uda76\udf17\udbd2\udf26\ud9d0\ude21\ud827\ude77\udbbd\udd21\ud9ab\ude40\ud97c\udd1f",
        42, 385, 53853275, -350980883008687569L, -86030L, true, false, (char) 8289, (char) 15362,
        Double.longBitsToDouble(0x3fe18c4e63547dcbL), Double.longBitsToDouble(0x3fe31967439fe6a7L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:316 |this=org.apache.commons.math3.fraction.Fraction:11 / 316\0121=java.lang.Float:0.034810126 |this=org.apache.commons.math3.fraction.Fraction:11 / 316\012",
        Z.run(T, 2, 11, 10, 6, "\ud94e\udff6\ud9bd\udf61\uda40\udd00", "\u113e", "\ud849\udfb4\uda29\udf0f",
        58, 56269, -1636111154, 1663298541265862546L, -38798L, false, true, (char) 38707, (char) 40070,
        Double.longBitsToDouble(0x3fa1d29c49ed7080L), Double.longBitsToDouble(0x3fe4e375a622630eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:-14 / 277\012",
        Z.run(T, 1, 14, 10, 15, "\u6204\uda3c\udd86\ud9de\udf83", "\uc778\u9d13\u43e9\u09b3\u97b5\ubfce\u3b33\u3071", "\ud9a1\udd2a\ud8d7\ude0a\uda78\udd4f\ud898\ude5f\ud9c0\udd46\u31c6\ud86a\udf24\uda76\udf17\uda7a\ude4a\udaa4\ude17\udbe7\ude38\ud856\udd95\ud9ab\ude40\udbd6\uddb5",
        42, -831, 61690444, -350980883008687569L, -20494L, true, true, (char) 19972, (char) 33026,
        Double.longBitsToDouble(0x3fcf114641c6033cL), Double.longBitsToDouble(0x3fea7fd0739fe6a9L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:27 / 10073\012",
        Z.run(T, 1, 14, 12, 9, "\uda9a\udf6e\ud9e6\udc22\ud9de\udf3a", "\uab9d\u1cd0\ud6c8\u09b3\u97b5\u97cb\u9d84\uc07b", "\ud98a\udec7\udb13\udf81\ud94c\udd04\udbcf\udf7b\ud9c0\udd95\udbb2\uddb8\udba6\udcc8\uda76\udc13\ua362\ud9c0\udf36",
        27, 10073, 1047765952, -8479494774417122951L, -32442L, true, true, (char) 56781, (char) 32173,
        Double.longBitsToDouble(0x3fe491092981906dL), Double.longBitsToDouble(0x3fb9fb7a689d3778L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:7 / 685 |this=org.apache.commons.math3.fraction.Fraction:7 / 137\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 15, "\ud94e\udff6\uda4e\ude41\ud9de\udf83", "\u113e\u9d13\u3ec7\u09b3\u97b5\u230d\u3506\u4a4d", "\ud8d0\udd05\ud8d7\ude0a\uda2b\uddea\ud898\ude5f\ud9c0\udd46\udbb2\uddb8\ud86a\udf24\uda76\udf17\ud8dc\udc15\ud8cf\udfae\ud9d7\udc2e\udbc6\udd95\ud9ab\ude45\ud97c\udd1f\ud862\udc1a\ud842\udc59\ud991\udc8b\ud9f2\udc75\udb98\udfac\ue451\udae5\udffe\uda1e\udc6b\ud918\udf27\udaf5\ude1b\udb45\udd9a",
        5, 84371, 123229087, 2284529255201872756L, 46193L, false, true, (char) 8035, (char) 36112,
        Double.longBitsToDouble(0x3faa2876081fbf60L), Double.longBitsToDouble(0x3fccd90819f4ccd4L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:-526 / 4435 |this=org.apache.commons.math3.fraction.Fraction:526 / 887\0121=java.lang.Boolean:false |this=org.apache.commons.math3.fraction.Fraction:526 / 887\012",
        Z.run(T, 2, 6, 9, 3, "\ud979\udf6f\uda4e\ude41\uda50\udcdc\ud8a3\ude39\ud848\udc41\uda24\ude46\uda39\ude6d\uda8f\udf7d\ud830\udda7\ud9fe\udd9c\ud8b3\udc35\ud8a8\uddf3\udafb\udf35\ud8c8\ude92\uda39\uded6\ud81f\udd89\ud87b\udecf\ud997\ude62\ud898\ude5f\ud9c0\udd46\udbb2\uddb8\ud912\udc48", "\u6abd\u9456\u4723", "\ud862\udc1a\ud842\udc59\ud971\udf8b\ud852\ude85\udbf4\udf9d",
        -5, 42202, -308534911, -6184462194502728331L, -29858L, false, false, (char) 37316, (char) 4475,
        Double.longBitsToDouble(0x3fe2f9f26ca0ed7aL), Double.longBitsToDouble(0x3feb9fcedda6c426L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:11 / 14270\012",
        Z.run(T, 1, 14, 10, 15, "\udab4\udc0b\udbba\udefe\ud9c0\udc0b\ud9a8\ude09", "\u7456\u43e9\u09b3\u97b5\u230d\u2ddf\u3160\uced3\ub5d7\uc4ac\u2e54\u7645\u9576\u8998\u0e2b\u37d3\u4246\ub342\u8a3f\u4697\u4c66\u7933\u400c\ucdfd\u27aa\u0ba6\u1ac9\u449b\ud1d3\u662f\u0427\ucfdf", "\u8de3\uda65\udf68\uda50\udf0d\ud926\udc44\ud956\udd66\ud8e2\udca6\uda27\ude99\udb2c\udc95\udaed\ude85\ud9ad\udeec\udb24\udc91\ud9d9\ude00",
        44, 57080, -1062747939, 322337689510000932L, -91565L, false, true, (char) 20543, (char) 11068,
        Double.longBitsToDouble(0x3fe81c669ea52334L), Double.longBitsToDouble(0x3fb8373fd398d450L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:21911 / 1034 |this=org.apache.commons.math3.fraction.Fraction:197 / 1034\012",
        Z.run(T, 1, 2, 2, 7, "\udb3c\udd11", "\u314d\u792d\u7a30\ua80a\uc994\u09b3\u5326\u9c7d\u4843\u3ee0\u8cf2", "\ud87b\udf06\ud94c\udd59\ud898\ude5f\ud9c0\udd46\ud9f0\udf03\ud881\ude7d\uda88\udfda\udba3\udc75\ud997\udd00\ud827\ude77\ud8f5\udf2d\ud885\ude0d\ud851\udf16\ud93f\udc0a\ud8ca\udd1d\uda73\ude95\ud988\udfe0\udad2\ude04\ud99d\udde7\udbbd\udfe9\uda1e\udc24\uda15\udcc4",
        21, 84022, 2046778466, -1624051449119888208L, 50344L, true, false, (char) 48493, (char) 60160,
        Double.longBitsToDouble(0x3fc86306fbd9d354L), Double.longBitsToDouble(0x3fe65944044e0cf4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:13 / 9553\012",
        Z.run(T, 1, 14, 4, 15, "\uda7d\udf71\uda4e\ude41\ud9de\udf83\udafc\udceb", "\u9d13\ua7ae\u31aa\u97b9\u230d\u2ddf", "\uda39\uded6\ud9a1\udd2a\ud87b\udf06\ud961\udd37\ud898\ude5f\ud9c0\udd46\udbb2\uddb8\ud86a\udf24\uda76\udf17\udb89\udf12",
        52, 38212, 316141073, 2814085386706455373L, -99641L, true, false, (char) 5108, (char) 8637,
        Double.longBitsToDouble(0x3fe2e8ca8692214cL), Double.longBitsToDouble(0x3fd8eccfd0cf3d6eL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:1 / 88 |this=org.apache.commons.math3.fraction.Fraction:13 / 22\012",
        Z.run(T, 1, 6, 10, 15, "\ud979\udf6f\uda4e\ude41\ud9de\udf83\ud98b\udf52", "\u177d\u43e9\u09b3\u54dd\u230d\u2ddf", "\uda39\uded6\ud9a1\udd2a\ud87b\udf06\ud8bd\udc53\ud898\uded3\ud9c0\udd46\udbd4\udd88\ud86a\udeef\uda76\udf17\udb89\udf12",
        52, 37700, 316141073, 2814085386706455373L, -99641L, true, false, (char) 5108, (char) 8637,
        Double.longBitsToDouble(0x3fe2e8ca8692214cL), Double.longBitsToDouble(0x3fd81906d0cfdb38L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Float:0.3817734 |this=org.apache.commons.math3.fraction.Fraction:155 / 406\0121=java.lang.Float:0.3817734 |this=org.apache.commons.math3.fraction.Fraction:155 / 406\012",
        Z.run(T, 2, 10, 10, 15, "\uda84\udf8d\uda61\udedd\ud9dd\udcc9\udb66\uddc1\uda4c\udfcd\udb7c\udda4\udad9\udf2b\uda8f\udf7d\ud849\udfb4", "\u2178\u2f8c\u7d4b\u33c6\u98cf\u4da6\u7f88\ub59e\u35eb\uac52\u37e5\u1da8", "\ud8cf\ude5c\udbb1\udd0d\ud878\ude71\ud97c\udcf7\ud9a6\udd5c\udab2\udc99\ud9e6\udf4f",
        6, 41023, -2116072655, -8039709891490078335L, 24058L, false, true, (char) 64481, (char) 54594,
        Double.longBitsToDouble(0x3fd86f01284e2944L), Double.longBitsToDouble(0x3fef8f1a880ea793L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Float:0.7219101 |this=org.apache.commons.math3.fraction.Fraction:257 / 356\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 10, 4, 15, "\ud991\udff8\ud92e\udc6a\udb7a\udff0\udb51\udd15\ud9e8\udda7\ud989\udfdd\udad9\udf2b\uda8f\udf7d\uce4a\ud9f6\udd1e\udbea\udd51\ud954\udcc4\udafb\udf0e\ud971\udd66\udb93\udf50\ud968\udf24\ud82d\udc61", "\u964e\u3043\u377c\u6ca7#\u8a0e\u4498\u2105\u97ed", "\udb36\udfdb",
        24, 36110, -444238532, -9088462851241331085L, 53988L, false, false, (char) 21779, (char) 22296,
        Double.longBitsToDouble(0x3fe719e3a3aa5b0fL), Double.longBitsToDouble(0x3fd63ea2a2310f60L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Float:0.529595 |this=org.apache.commons.math3.fraction.Fraction:170 / 321\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 10, 7, 15, "\ud983\ude27\uda47\udfe3\ud9a6\udeb6", "\u89d1\u9d13\u43e9\u26b5\u8d77\u9a27\ud003\u2024\u6ee2\ua10e\u98cf\u4da6", "\udab2\udfb9\ud866\ude1f\udab6\uddfb\uda76\udf17",
        30, 92142, -74743594, 1323757097987580864L, 37965L, true, false, (char) 40967, (char) 44516,
        Double.longBitsToDouble(0x3fe0f2610e411950L), Double.longBitsToDouble(0x3fe68e01216a906dL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Double:54.685494223363285 |this=org.apache.commons.math3.fraction.Fraction:426 / 779\0121=java.lang.Double:54.685494223363285 |this=org.apache.commons.math3.fraction.Fraction:426 / 779\012",
        Z.run(T, 2, 0, 0, 13, "\ud94e\udff6\u0bdc\ud9de\udf5b", "\uac51\u9d13\u0d0e\ua089", "\ud854\udcc9\udafb\udf0e\ud8c8\ude92\ud8b3\udea9\ud9a1\ude2d\ud8c9\ude39\ud819\uddee\ud898\ude5f\ud9c0\udd46\udbb2\uddb8\ud86a\udf24\ud8c7\ude70",
        33, 84580, 558781017, 1357815574464537536L, 50966L, true, false, (char) 49082, (char) 5108,
        Double.longBitsToDouble(0x3fe17fd90e5d1950L), Double.longBitsToDouble(0x3fe49748d981906dL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.MathArithmeticException\012",
        Z.run(T, 1, 6, 10, 15, "\uda41\udcae\udb74\ude34\udaec\udeea", "\u585a\u6cc2\ua521\u09b3\ubd0b\u090e\u35b7\u30e3\u5d12\u6519\ua244\u8f89", "\ud9c0\udd46\udbb2\uddb8\ud9a7\udfc4\uda71\udf6b\ud946\udfeb\ud80c\udc9b",
        0, 41884, 1364318912, -2957735486961607955L, -9029L, true, false, (char) 31928, (char) 45339,
        Double.longBitsToDouble(0x3fec910d98d94c5fL), Double.longBitsToDouble(0x3fda7199435861d4L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:1 / 72 |this=org.apache.commons.math3.fraction.Fraction:1 / 2\012",
        Z.run(T, 1, 6, 10, 0, "\ud94e\udff6\udb74\ude34\udaec\udeea", "\000\u55a6\u8c80\u08ea\ubd0b\u009e\u34c9\000\000\u039e\ua27c\u8f89", "\ud9c0\udd46\udbb2\uddb8\000\uda76\ude7b\ub64d\ud8f5\udf8f",
        36, 50128, 1375394496, -2957735486961607955L, -99909L, false, true, (char) 15616, (char) 23497,
        Double.longBitsToDouble(0x3fe0000000d94c00L), Double.longBitsToDouble(0x3fda7199435861d4L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:74 / 6027 |this=org.apache.commons.math3.fraction.Fraction:592 / 861\012",
        Z.run(T, 1, 6, 7, 2, "\udba1\udff2\ud823\udf3c\ud8c9\udd77", "\u04ae", "\ud976\udfd8\udba5\udc68\ud9b8\udd1f",
        56, 87760, -875848974, 5775053576161129628L, 43932L, true, false, (char) 50044, (char) 18691,
        Double.longBitsToDouble(0x3fe60096bb3f51faL), Double.longBitsToDouble(0x3fe76eb7a699d0c1L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:0 |this=org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 1, 6, 10, 15, "\ud94e\udff6\udb74\ude34\udaec\udeea", "\u585a\u9d5a\u08e9\u09b3\ubd0b\u090e\u35b7\u30e3\u5d12\u039e\ua27c\u8f89", "\ud9c0\udd46\u1c23\000\uda76\udf17\ub64d\udaec\uddea",
        36, 10185, 1375394496, -2957735486961607955L, 13755L, false, true, (char) 52456, (char) 10953,
        Double.longBitsToDouble(0x3eb246ca60000000L), Double.longBitsToDouble(0x3fda7199435861d4L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:-5 |this=org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 1, 2, 0, 15, "", "\u7f80\u6558\u11ea\002\000\000", "\ud8c9\udfa0",
        -5, 10832, 387266870, 4487168L, -100000L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3de6f91a00000000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.FractionField:@? |this=org.apache.commons.math3.fraction.Fraction:67 / 71\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 12, 3, 7, "\uda3d\udecd\udb83\udf33\uda50\udcdc", "\u113e\u9d95\u43e9\ubb95\u41a9\uc185\u6677\u6a0c\u580c\ua0d8\u9ce9\u7106\u3466", "\uda92\udd07\u5d86\ud836\udefe",
        5, 86750, 1611206143, 3660368290831476382L, 37965L, true, true, (char) 55800, (char) 46867,
        Double.longBitsToDouble(0x3fee3274225d190bL), Double.longBitsToDouble(0x3fec91092a81f939L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:1 / 186 |this=org.apache.commons.math3.fraction.Fraction:16 / 93\012",
        Z.run(T, 1, 6, 10, 15, "\uda59\udf38\ud831\udccd\ud9de\udf39", "\u113e", "\ud849\udfb4\uda29\udf0f\ud8b3\udc35\ud854\udcc9\udadf\udfae\ud9e8\ude3b\uda6f\udf6e\udb95\udee5\ud8d7\ude0a\ud94c\udd59",
        32, -68, -687334365, 7977120266832181148L, 33221L, false, false, (char) 55303, (char) 46742,
        Double.longBitsToDouble(0x3fc6054e7ec74080L), Double.longBitsToDouble(0x3fe34a3fec5b1db3L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.fraction.Fraction:17 / 31\0121=java.lang.Boolean:false |this=org.apache.commons.math3.fraction.Fraction:17 / 31\012",
        Z.run(T, 2, 9, 9, 15, "\ud94e\udfaa\uda4e\ude41\ud9de\uded1", "\u44ce\ud357\u43e9\u09b3\u97b5\u230d\u3506\u3139", "\ud9a1\udd2a\ud8d7\ude0a\ud94c\udd59\ud898\ude5f\ud9c0\udd46\udbe7\udfb8\udbfc\ude2e\uda74\udd65\ud86c\udd7c\ud9aa\udc5f\ud827\ude77\ud8f5\udf2d\ud9ab\ude40\ud97c\udd1f",
        20, 385, 53853275, -350980883008687569L, -20494L, true, true, (char) 19972, (char) 15362,
        Double.longBitsToDouble(0x3fe18c4e62527dcbL), Double.longBitsToDouble(0x3fe29582cb9fe6a7L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:13 / 21101\0121=java.lang.Boolean:false |this=org.apache.commons.math3.fraction.Fraction:16 / 233\012",
        Z.run(T, 2, 14, 9, 7, "\ud94e\udfaa\uda4e\ude41", "\u30bb\u44ce\ud357\u3d13\u3be3\u5337\u22a0\u3506\u3139\u09a1\ua0d8\u987f\u4da6\u3889\u427b\u512c\u9544\ubd81\u0c2a#\u8a0e", "\ud9ab\ude40\ud97c\udd1f\udbdb\uddc3\ud83a\udf2e\ud991\udc8b\ud9f2\udc75\udb98\udfac",
        26, 42202, -303321800, -6417804950464850669L, 140L, true, false, (char) 23435, (char) 64443,
        Double.longBitsToDouble(0x3fb193f17f46eaa8L), Double.longBitsToDouble(0x3fe84bbb3910bcafL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:6 / 9055\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 14, 4, 7, "\ud80e\udeb2\uda2f\udda2\ud9de\uded1\ud98b\udf52\udbd9\udfcd\uda81\udc0b\ud92c\udee1", "\u4849\u230d\u3a25\u3139\u8c91\ua0d8\u98cf\u4da6\u10ec\u0687\u8c83\u459f\u37e2", "\ud997\udd00\ud827\ude77\ud8f5\udf2d\ud9ab\ude40\ud97c\udd1f\ud862\udc1a\ud842\udc59\ud991\udc8b\ud9f2\udc75\udb98\udfac\ue451\udae5\udffe\uda1e\udc6b\ud918\udf27\udaf5\ude1b",
        12, 18110, -425225629, 5880667156360829720L, 16670L, true, false, (char) 50615, (char) 4781,
        Double.longBitsToDouble(0x3fbec1e05cee40f0L), Double.longBitsToDouble(0x3fe614b8e91ad7c2L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:17 / 961 |this=org.apache.commons.math3.fraction.Fraction:17 / 31\0121=org.apache.commons.math3.fraction.Fraction:17 / 31 |this=org.apache.commons.math3.fraction.Fraction:17 / 31\012",
        Z.run(T, 2, 6, 1, 5, "\ud841\udc85\uda63\udd38\uda7d\udfb2", "a\uad84\u0f86\u4114\u97b5\u8406\u7867\u0a73\u8d3f\ua0d8\u98cf\u4da6\u3889\u99f2", "\ud86a\udf24\uda4d\uded2\u76be\uda7b\udf13",
        31, 31039, -1816504244, -3064587165115213296L, -20478L, false, false, (char) 30037, (char) 15337,
        Double.longBitsToDouble(0x3fe18c4e63542604L), Double.longBitsToDouble(0x3fe3185b4b9fe6a7L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.FractionField:@? |this=org.apache.commons.math3.fraction.Fraction:1559 / 1600\0121=org.apache.commons.math3.fraction.FractionField:@? |this=org.apache.commons.math3.fraction.Fraction:1559 / 1600\012",
        Z.run(T, 2, 12, 12, 1, "\ud841\udc85\uda63\udd38\ud846\udd37", "\u113e\uad84\u0f86\u0919\u97b5\u8406\u3506\u0a73\u8d3f\uc444\u98cf\u4da6\u3889\u99f2\ua308", "\uda4d\uded2\ua644\ud8ce\uded3\ud995\udd62\ud8ab\udecd\uda12\uddea\ud956\udfb4\ud861\udf3d\ud842\udc59\udaa9\udc57\ud9b9\udf8d\udac3\udcf3\ud9a2\udff9\udae6\udc0e",
        -1, 32343, -1983081197, 2739523591202218836L, -78593L, false, false, (char) 26616, (char) 39671,
        Double.longBitsToDouble(0x3fef2e14291efc2dL), Double.longBitsToDouble(0x3fe0f49daeefdd55L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:8 / 18859\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 5, 15, "\ud97e\udd9d\ud8d7\udc18\ud8e6\ude71\ud962\udcfe", "\ub21c\u755c\u09b3\u97b5\u230d\ub07b\u8870\u1c72\u9241\ub068\u45a0\u49fb\u6a5a\u43c5\u02c5\ua7ca\u1da8\u6023\u73dd\u7cc8\ud7a8\u3b16", "\u474c\u1906\ud9f2\udc75\udb98\udfac\udbe2\udfc7\udb04\udf35\uda1e\udc6b\udbca\udf40\udb74\ude37\ud986\ude61\ud863\udc00\udb8f\ude79\udbec\uddaf\ub272\ud818\uddfd\ud9db\udf5b\uda4e\udc58\ud828\udd75\uda46\udfdb",
        8, 18859, -571161220, 7576868697945071898L, -60340L, true, false, (char) 17859, (char) 42455,
        Double.longBitsToDouble(0x3fef7216c40fd979L), Double.longBitsToDouble(0x3fe480ce6a793b75L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 1, 14, 5, 15, "\ud97e\udd9d\ud8d7\udc18\ud8e6\ude71\ud90a\udd73", "\u9d84\u43e9\u09b3\u3fb5\u9cb8\u8c39\u5323\u8c91\u8d4a\ub068\ua402\u1e77", "\uda30\uddd5\ud9b6\ude24\ud9e9\udc25\udbcb\udfe7\ud99e\udddd\udae8\udda7\uda5a\ude1f\udb15\udf0b\u3d09\ud9b6\udc24\uc852\ud991\udc8b\ud9f2\udc75\udb98\udfac\udbe2\udfc7\udb04\udf35\uda1e\udc6b\udb90\udf62\udad5\ude62\udb45\udd9a\ud863\udc00\udabb\udf6d\udbd3\udd04\uda11\udc9a\udafb\udd5c\udb7f\udc26\ud92f\udc89\ud858\udfca\uda3d\udc15\ud87a\udd6a\u80c7\ud961\udff5\ud944\udc22\udbe3\ude6f\uda3c\ude1a\ud95d\udc66\ud8ab\udeba\ud95b\udf35",
        0, 95597, 432917560, 4284447788989397625L, 99213L, true, false, (char) 53522, (char) 51824,
        Double.longBitsToDouble(0x3fe50e6b99bc6b03L), Double.longBitsToDouble(0x3fe3be219c6235c1L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:21 / 69632\012",
        Z.run(T, 1, 14, 10, 15, "\u6204\uda3c\udd86\ud9de\udf83", "\uc778\u9d13\u43e9\u09b3\u97b5\ubfce\u0533\uc52f", "\ud9a1\udd2a\ud8d7\ude0a\uda78\udd4f\ud898\ude5f\ud9c0\udd46\u31c6\ud86a\udf24\uda76\udf17\uda7a\ude4a\udaff\udc05\udbf6\uddd4",
        21, 69632, 185671951, -3452542460665200999L, 11497L, true, false, (char) 8323, (char) 38280,
        Double.longBitsToDouble(0x3fd81906d0cfdb38L), Double.longBitsToDouble(0x3fe09d3778f88a32L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:137 / 1565 |this=org.apache.commons.math3.fraction.Fraction:137 / 313\0121=org.apache.commons.math3.fraction.Fraction:1702 / 313 |this=org.apache.commons.math3.fraction.Fraction:137 / 313\012",
        Z.run(T, 2, 6, 2, 8, "\ud945\udd51\uda4e\uddfb\ud9de\udf83\ud98b\udf52", "\u72d9\ubad7\u0eac\u87fa\u230d\u3506\u4a4d", "\ud8d0\udd05\ud8d7\ude0a\uda2b\uddea\uda7d\udfed\udbfd\udda1\ud981\udf7f\uda97\ude10\uda76\udf17\ud8dc\udc15\ud8cf\udfae\uda8c\udc0a\ud9cf\udc10\ud8fe\udfe7\udad4\udf73\ud862\udc1a\ud842\udc59\ud991\udc8b\ud9f2\udc75\udb98\udfac\ue451\udae5\udffe\ud920\udff1\ud918\udf27\udaf5\ude1b\udb45\udd9a",
        5, 84371, 123229087, 2284529255201872756L, 46189L, false, true, (char) 61495, (char) 59042,
        Double.longBitsToDouble(0x3fdc032c2f173060L), Double.longBitsToDouble(0x3fc8afcf59f4ccd4L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:11 / 18328 |this=org.apache.commons.math3.fraction.Fraction:11 / 316\0121=org.apache.commons.math3.fraction.Fraction:11 / 18328 |this=org.apache.commons.math3.fraction.Fraction:11 / 316\012",
        Z.run(T, 2, 6, 6, 0, "\ud94e\udff6", "\u6506\u11ea\u113e", "\ud849\udfb4\uda29\udf0f",
        58, 56269, 1889725646, 5411083402986423808L, 60974L, true, true, (char) 40459, (char) 40070,
        Double.longBitsToDouble(0x3fa1d29c49ed7080L), Double.longBitsToDouble(0x3fece375a2f63b19L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:304 / 473 |this=org.apache.commons.math3.fraction.Fraction:304 / 473\0121=org.apache.commons.math3.fraction.Fraction:304 / 473 |this=org.apache.commons.math3.fraction.Fraction:304 / 473\012",
        Z.run(T, 2, 1, 1, 3, "\udbd1\udf7a\uda60\udf40\uda50\udcdc\ud8a3\ude39", "\u9d13\u43e9\u28e6\uc241\u043d\u66cf", "\ud991\udd40\ud81f\udd89\ud87b\udecf\ud997\ude62\ud898\ude5f\ud9c0\udd46\udbb2\uddb8\ud8e0\udd8f\ud8fd\ude07\udbf6\udc67\ud99c\udf6d",
        34, 72556, -42362081, -2143278785626760467L, -18245L, true, false, (char) 19044, (char) 17245,
        Double.longBitsToDouble(0x3fe4910ca981906dL), Double.longBitsToDouble(0x3fb9fb672bad5160L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:-1 / 8758\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 14, 4, 15, "\ud997\udffb\ud8bc\udf11\udb7a\udff0\udb51\udd15\ud9e8\udda7\udbee\udfaf", "\u1cfb", "\ud954\udcc4\udafb\udf0e\ud971\udd66\udb93\udf50\ud968\udf24\ud82d\udc61\ud840\udf37\ud9f9\udfa0\udb19\udc55\udb79\ude85\ud852\udf22\ud99b\udef2",
        -4, 35032, -1606214008, 9183144552541103040L, 71363L, false, true, (char) 36228, (char) 51574,
        Double.longBitsToDouble(0x3fd3c6a1440072d6L), Double.longBitsToDouble(0x3fab8cf5a9d41020L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:37039 / 779 |this=org.apache.commons.math3.fraction.Fraction:426 / 779\0121=org.apache.commons.math3.fraction.Fraction:47 / 84580\012",
        Z.run(T, 2, 2, 14, 13, "\ud94e\udff6\u0bdc\ud9de\udf5b", "\u9b92\u6f77\u9047\ua089", "\ud852\udc7f\udafb\udf0e\ud8c8\ude92\ud8b3\udea9\ud9a1\ude2d\uda45\udde7\ud819\uddee\ud898\ude5f\ud9c0\udd46\udbb2\uddb8\ud86a\udf24\udb1b\udf39",
        47, 84580, 558781017, 1357815574464537536L, 50966L, true, true, (char) 22183, (char) 5108,
        Double.longBitsToDouble(0x3fe17fd90e5d1950L), Double.longBitsToDouble(0x3fe49748d981906dL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:1 / 256 |this=org.apache.commons.math3.fraction.Fraction:9 / 64\012",
        Z.run(T, 1, 6, 10, 0, "\ud94e\udff6\udb74\ude34\udb86\udd37", "\000\u55a6\u8c80\u08ea\ubd0b\u009e\u34c9\000\000\u039e\ua27c\u8f89", "\ud9c0\udd46\udbb2\uddb8\000\uda76\ude7b\ub64d\ud8f5\udf8f",
        36, 50128, 1375394496, -2957735485079086355L, -60989L, false, true, (char) 15616, (char) 23497,
        Double.longBitsToDouble(0x3fc2000603653000L), Double.longBitsToDouble(0x3fda7199435861d4L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:0\0121=!org.apache.commons.math3.exception.MathArithmeticException\012",
        Z.run(T, 2, 14, 6, 7, "\uda3d\udecd\udb83\udf33\uda50\udcdc", "\u7019", "\ud9a8\udc8c\ud9cf\udee5",
        0, 49377, -2040564940, 1675590286695448466L, 30387L, false, false, (char) 49499, (char) 33289,
        Double.longBitsToDouble(0x3fec1b750d0d1b7bL), Double.longBitsToDouble(0x3f9677f5bfe39260L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:1 / 179 |this=org.apache.commons.math3.fraction.Fraction:14 / 179\0121=org.apache.commons.math3.fraction.Fraction:1 / 179 |this=org.apache.commons.math3.fraction.Fraction:14 / 179\012",
        Z.run(T, 2, 6, 6, 0, "\ud94e\udff6\uda4e\ude41\ud9de\udf83\ud98b\udf00", "\u9d13\u3ec7\u09b3\u97b5\u230d\u3506\u4a4d\u60b0\u2734\uc822\u4da6\u22da", "\udbb2\uddb8\ud86a\udf24\uda76\udf17\udbb4\udce9\uda50\udf1a\udba3\ude17\ud89a\udf7e",
        14, 19643, -531609554, -989899446001479115L, 70304L, false, false, (char) 22397, (char) 16493,
        Double.longBitsToDouble(0x3fb4060c04cdffc8L), Double.longBitsToDouble(0x3fef463ab662a728L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:-11 / 948 |this=org.apache.commons.math3.fraction.Fraction:11 / 316\0121=org.apache.commons.math3.fraction.Fraction:-11 / 948 |this=org.apache.commons.math3.fraction.Fraction:11 / 316\012",
        Z.run(T, 2, 6, 6, 0, "\ud94e\udff6", "\u6506\u11ea\u113e", "\udb9d\ude1e\uda29\udf0f",
        -3, 33721, 1889725646, 5411083402986423808L, 60974L, true, true, (char) 40459, (char) 40070,
        Double.longBitsToDouble(0x3fa1d29c49ed7080L), Double.longBitsToDouble(0x3fece375a2f63b19L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:39 / 16096\0121=org.apache.commons.math3.fraction.Fraction:39 / 16096\012",
        Z.run(T, 2, 14, 14, 2, "\uda3d\udecd\udb83\udf33\udacb\udefa", "\u7019", "\udbbb\udc3f\uda90\udef9\ud9c1\udeb7\uda5e\udc17\uda10\udd52\udb37\udddb\uda1c\udee7\ud9d6\udc9a\ud884\udfb6\ud951\udd49\udb14\udddc\udaa2\udf93\u4062\ud920\uddc8\udb06\udf10\uda59\udd47\ud9a2\udded\ud819\udf9f\udb5d\udde0\ud9b4\ude1c\ud8d5\udd53\udae4\udc87",
        39, 16096, 1676948748, -1792025010734267095L, -56031L, false, true, (char) 11026, (char) 44791,
        Double.longBitsToDouble(0x3fc6c60ff2ed3458L), Double.longBitsToDouble(0x3feeace4f1c68f72L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:46 / 85809\0121=org.apache.commons.math3.fraction.Fraction:24 / 4301 |this=org.apache.commons.math3.fraction.Fraction:48 / 187\012",
        Z.run(T, 2, 14, 6, 7, "\uda3d\udecd\udb83\udf33", "\uc253\u9865\u9d55\u43e9\ubb95\u41a9\u19a9\u745b\u78be\u580c", "\ud8ef\udee3\ud951\udd49\udb14\udddc\ud91b\udc93\ud825\udd44\u5d86\ud9c7\ude40\ud9a6\udefd\ud845\uddc5\uda8a\ude42",
        46, 85809, 1146594682, 8525134733244356131L, 48451L, true, true, (char) 16790, (char) 47158,
        Double.longBitsToDouble(0x3fd06dac9c526344L), Double.longBitsToDouble(0x3feb046fc8e2306eL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:40 / 27637\0121=org.apache.commons.math3.fraction.Fraction:40 / 27637\012",
        Z.run(T, 2, 14, 14, 2, "\uda3d\udecd\udb83\udf33\udacb\udefa", "\u4f7c", "\udac7\udc25\udbd0\udef9\ud9c1\udeb7\uda5e\udc17\uda10\udd52\udb37\udddb\uda1c\udee7\ud9d6\udc9a\ud884\udfb6",
        40, 27637, -855789463, 6796708997381566246L, 68973L, true, false, (char) 30740, (char) 12515,
        Double.longBitsToDouble(0x3feb9e4afba2e94bL), Double.longBitsToDouble(0x3fe33ca7bac367fbL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:-39 / 1000\0121=org.apache.commons.math3.fraction.Fraction:-39 / 1000\012",
        Z.run(T, 2, 14, 14, 2, "\ud9fb\udecc\udb83\udf33\udacb\udefa", "\u7019", "\udbbb\udc3f\uda90\udef9\ud9c1\udeb7\uda5e\udc17\uda10\udd52\udb37\udddb\uda1c\udee7\ud9d6\udc9a\ud884\udfb6\ud951\udd49\udb14\udddc\udaa2\udf93\u4062\ud920\uddc8\udb06\udf10\uda59\udd47\u1ea1\ud819\udf9f\udb5d\udde0\u8373\ud8d5\udd53\udae4\udc87",
        39, -1000, 1676948748, -1792025010734267095L, -56031L, false, true, (char) 26130, (char) 0,
        Double.longBitsToDouble(0x3fc6c60ff2ed3458L), Double.longBitsToDouble(0x3ec3c71a3dc80000L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Double:25.97864768683274 |this=org.apache.commons.math3.fraction.Fraction:73 / 281\012",
        Z.run(T, 1, 0, 14, 15, "\ud96b\udc2a\uda4e\ude41\ud952\udf7d", "\u691d\u9d13\ucd55\ub1b0\ua886\u230d\u570d\u3790", "\ud9a1\udd2a\ud8d7\ude0a\ud843\udc55\ud878\udc37\ud9c0\udd46\udbb2\uddb8\ud86a\udf24\uda76\udf17\udbb3\udfe7\ud997\udd1c\ud827\ude77\u6700\u749a\ud98e\udcbd\ud954\ude2d\udab5\udde2\ud991\udc8b\udb30\udc74\udbdf\udcf0\ud97b\udd13\uda58\udd96\ud9f2\udce6\ud918\udf27\uda7f\ude6b\udb45\ude67\udb1d\uddb5\uda68\udce4\uda06\udd76\uda67\udfc0",
        18, 53832, -1412310101, -7430952455800123055L, 23420L, false, true, (char) 55578, (char) 13007,
        Double.longBitsToDouble(0x3fd0a03b594e0836L), Double.longBitsToDouble(0x3fd2c3df48914f1cL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:0\0121=org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 2, 14, 14, 6, "\uda3d\udecd", "\uadd3\u912c\u768b", "\ud9a8\udc8c\ud9cf\udee5",
        0, 12681, -1956283614, 7967243863776775854L, 84190L, false, true, (char) 24570, (char) 7073,
        Double.longBitsToDouble(0x3fa1d29c70153080L), Double.longBitsToDouble(0x3fec1b750d0d1b7bL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:0 |this=org.apache.commons.math3.fraction.Fraction:0\0121=org.apache.commons.math3.fraction.Fraction:0 |this=org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 2, 1, 1, 3, "\u00c6\uda46\udee2\uda50\udcdc\ud8a3\ude39", "\u9d13\u43e9\u28e6\uc241\u043d\u66cf", "\ud991\udd40\ud81f\udd89\ud87b\udecf\ud997\ude62\ud898\ude5f\ud9c0\udd46\udbb2\uddb8\ud8e0\udd8f\ud8fd\ude07\udbf6\udc67\ud99c\udf6d",
        34, 72556, -42362081, -2143278785626760467L, -18245L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fb9fb672bad5160L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:0 |this=org.apache.commons.math3.fraction.Fraction:0\0121=org.apache.commons.math3.fraction.Fraction:0 |this=org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 2, 6, 6, 0, "\000", "\u6474\u11ea\u113e", "\000",
        -5, -1000, -413597696, 8116309849242339248L, 30912L, false, false, (char) 45244, (char) 41227,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e81c00000000000L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:12 / 6449\0121=org.apache.commons.math3.fraction.Fraction:12 / 6449\012",
        Z.run(T, 2, 14, 14, 2, "\uda3d\udecd\u42da\u8c9f\ud834\udfae\ud929\udcc0\udaed\udc18\uda32\udede\udaa0\udfd8\ud9da\udece\udbd0\udfbf\ud9c1\udeb7\uda5e\udc17", "\u32a0\ud6ab\u8853\u61e4\u6c18\u2bf4\uc29d\uab4c\u03f5\u03e0", "\udb5d\udde0\ud9b4\ude1c\uda76\udd12\ud8e7\udcdc\ud864\udf54\udaef\udc0e\ud826\udfd6\uda78\udecc\ud945\udcd5\ud829\uddaa\udab9\udcb5\u517c\udba9\udd26\udac2\udc03\uda87\udc2d\ud80b\udd17\ud855\uddd2\ud841\ude2e\udaaf\udc72\udbb6\udc7a\ud885\udee6\ud94e\udf88\udb36\udddf\udadc\ude60\udbe2\udfce\udbd9\udefa\u5875\uda9f\udfcd\ud81c\udfa0\udb1b\udc02\udab2\udd81\udba7\udfda\uda83\udce0\ud8ce\ude7b\udb1b\udc6b\ud83a\uddf7\udb4c\udcdf\ub08d\ud854\udc3a\ud8d1\udfe9\udb7a\udd86\uda7e\udf1d\ud88a\ude7c\ud885\ude31\uda49\udf19\uda9d\udcd3\ud8c1\udcb8\ud8b4\udf15",
        48, 25796, 1228637809, 2974476875550257929L, -69211L, true, false, (char) 31842, (char) 486,
        Double.longBitsToDouble(0x3fded2aa97d9e1d8L), Double.longBitsToDouble(0x3fe37e606189fe80L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:3 / 383 |this=org.apache.commons.math3.fraction.Fraction:96 / 383\0121=org.apache.commons.math3.fraction.Fraction:3 / 383 |this=org.apache.commons.math3.fraction.Fraction:96 / 383\012",
        Z.run(T, 2, 6, 6, 0, "\ud94e\udff6\uda4e\ude41\ud9de\udf55\ud98b\udf00", "\u9d13\u3ec7\u09b3\u97b5\u230d\u3506\u4a4d\u60b0\ub91c\uc822\u4da6\u22da", "\udbb2\uddb8\ud86a\udf24\uda76\udf17\udbb4\udce9\uda50\udf1a\udba3\ude17\udb0d\udc31",
        32, 8244, -531609535, -989899446001479115L, 70304L, false, false, (char) 22397, (char) 32051,
        Double.longBitsToDouble(0x3fd00aa4b9aff0eaL), Double.longBitsToDouble(0x3fef463ab662a728L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.fraction.Fraction|percentageValue||new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|abs||new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|add|int|new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|add|org.apache.commons.math3.fraction.Fraction|new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|addSub|org.apache.commons.math3.fraction.Fraction,boolean|new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|compareTo|org.apache.commons.math3.fraction.Fraction|new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|divide|int|new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|divide|org.apache.commons.math3.fraction.Fraction|new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|doubleValue||new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|equals|java.lang.Object|new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|floatValue||new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|getDenominator||new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|getField||new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|getNumerator||new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|getReducedFraction|int,int|static",
    "M|org.apache.commons.math3.fraction.Fraction|hashCode||new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|percentageValue||new:org.apache.commons.math3.fraction.Fraction:double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
