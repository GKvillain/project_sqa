package org.apache.commons.math3.genetics;
import org.junit.Test;
import static org.junit.Assert.*;
public class ListPopulation_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 5, 2, 4, "\ud8c0\udde8\ud8f9\udcfc\udbf2\udd5e\uda85\udc76\udb07\udf21\u6802\uda7e\udffd\ud8fc\udd62\ud8b2\udf44\uda48\ude38\ud95f\udc44\udaec\ude33\ud992\ude2e\ud9a2\udff7\uda49\ude8e\ud84a\udd57", "\u3b93\u4d69\u7823\uc882", "\ud8ff\ude02\ud825\udeae\ud8b7\udf0c\ud9e6\udcf0\ud824\udd5e",
        34, 61697, 1931339514, 6248281892407561633L, 1997L, false, false, (char) 19833, (char) 45828,
        Double.longBitsToDouble(0x3fec1edd2a2288ffL), Double.longBitsToDouble(0x3fcdb819a67cfed4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 5, 2, 4, "\ud8c0\udde8\ud8f9\udcfc\udbf2\udd5e\uda85\udc76\udb07\udf21\u6802\uda7e\udffd\ud8fc\udd62\ud8b2\udf44\uda48\ude38\ud95f\udc44\udaec\ude33\ud992\ude2e\ud9a2\udff7\uda49\ude8e\ud84a\udd57", "\u3b93\u4d69\u7823\uc882", "\ud8ff\ude02\ud825\udeae\ud8b7\udf0c\ud9e6\udcf0\ud824\udd5e\udaec\udcbf\ud82a\ude6e\udacd\uddc2\ud892\udc63\ud83c\uddb5\ud9f7\udce5\uda46\udd7d",
        36, 30306, -609901285, -8575074130770191838L, 31487L, true, true, (char) 7593, (char) 57033,
        Double.longBitsToDouble(0x3fb14b9015417058L), Double.longBitsToDouble(0x3fd91487bf34b676L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\012",
        Z.run(T, 1, 9, 6, 4, "\ud8c0\udde8\ud8f9\udcfc\udbf2\udd5e\uda85\udc76\udb07\udf21\u6802\uda7e\udffd\ud8fc\udd62\ud8b2\udf44\uda48\ude38\ud95f\udc44\udaec\ude33\ud992\ude2e\ud9a2\udff7\uda49\ude8e\ud84a\udd57", "\u9322\u4d69\u7823\uc882", "\ud8ff\ude02\ud825\udeae\ud8b7\udf0c\ud9e6\udcf0\ud824\udd5e",
        34, 61697, 1931339514, 6248281892407561633L, 1997L, false, false, (char) 19833, (char) 45828,
        Double.longBitsToDouble(0x3fec1edd2a2288ffL), Double.longBitsToDouble(0x3fcdb819a67cfed4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NotPositiveException\012",
        Z.run(T, 1, 10, 2, 4, "\ud8c0\udde8", "\u6300\ucd7a\u65e3\ua467\u892d", "\ud95f\udc44\udaec\ude33\ud992\ude2e\ud9a2\udff7",
        -5, 72716, 774916601, 7444697674812999341L, 82259L, false, true, (char) 1981, (char) 13163,
        Double.longBitsToDouble(0x3fc0787f86dd3f08L), Double.longBitsToDouble(0x3fc7399012d9ad50L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:21 |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\012",
        Z.run(T, 1, 6, 2, 4, "\ud9ff\udeff", "\000\000\000\ua467\ube48", "\ud95f\udc44\udaec\ude33\uda20\udf76\000",
        21, 72716, 689642745, 8933754933603311372L, -50942L, false, true, (char) 1981, (char) 59896,
        Double.longBitsToDouble(0x3fd4f8f4136e9f84L), Double.longBitsToDouble(0x3fc7399002d9ad50L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection$1:@? |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\012",
        Z.run(T, 1, 0, 2, 1, "\ud8c0\uddfb\ud8f9\udcfc\udbf2\udd5e", "\u2459\u5658", "\ud9b6\udecf\ud9f7\udc31\udb5c\udd91",
        19, 45969, 1258406435, 2717651844407696580L, 6252L, false, true, (char) 41861, (char) 39456,
        Double.longBitsToDouble(0x3fb86c0fc46e8b58L), Double.longBitsToDouble(0x3fd8d922f76e9f84L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NotPositiveException\012",
        Z.run(T, 1, 1, 8, 4, "\ud8c0\udde8\ud8f9\udcfc\udbf2\udd5e\uda85\udc76\udb07\udf21\u09d7\000\ud8fc\udd62\ud8b2\udf44\uda48\ude38\u9949\udab3\udd59\ud992\ude2e\ud9a2\udff7\uda49\ude8e\ud84a\udd57", "\u3b93\u4d69\u7823\u7392", "\ud8ff\ude02\ud825\udeae\ud8b7\udf0c\ud9e6\udcf0\ud94b\ude51",
        -5, 61697, 1931339514, 6248281892407561472L, 1997L, false, false, (char) 19833, (char) 45828,
        Double.longBitsToDouble(0x3fec1edd2a2288ffL), Double.longBitsToDouble(0x3fcdb819a67cfed4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[null]\012",
        Z.run(T, 1, 1, 4, 3, "\ud8c0\udde8\ud8f9\udcfc\udbf2\udd5e\uda85\udc76\udb07\udf21\u6802\uda7e\udffd\ud871\udcfc\ud8da\udf27\uda48\ude38\ud943\ude44\udaec\ude33\ud992\ude2e\ud9a2\udff7\uda49\ude8e\ud84a\udd57", "\u3b93\u4d69\u7823\uc882", "\ud8ff\ude02\ud825\udeae\ud8b7\udf0c\ud9e6\udcf0\ud824\udd5e",
        34, 61697, 1931339514, 6248281892407561633L, 1997L, false, false, (char) 19833, (char) 13573,
        Double.longBitsToDouble(0x3fec1d87422288ffL), Double.longBitsToDouble(0x3fcdb819a67cfed4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[\ud8c0\udde8\ud8f9\udcfc\udbf2\udd5e\uda85\udc76\udb07\udf21\u6802\uda7e\udffd\ud8fc\udd62\ud8b2\udf44\uda48\ude38\ud95f\udc44\udaec\ude33\ud992\ude2e\ud9a2\udff7\uda49\ude8e\ud84a\udd57]\012",
        Z.run(T, 1, 2, 2, 4, "\ud8c0\udde8\ud8f9\udcfc\udbf2\udd5e\uda85\udc76\udb07\udf21\u6802\uda7e\udffd\ud8fc\udd62\ud8b2\udf44\uda48\ude38\ud95f\udc44\udaec\ude33\ud992\ude2e\ud9a2\udff7\uda49\ude8e\ud84a\udd57", "\u3b93\u10fa\u78bb\u5d50", "\ud8ff\ude02\udb27\udeaf\ud8b7\udf0c\ud9e6\udcf0\ud824\udd5e",
        34, 61697, 1931339514, -3479493302712709815L, 98917L, true, false, (char) 22159, (char) 48998,
        Double.longBitsToDouble(0x3fe92c36da226266L), Double.longBitsToDouble(0x3fcdb819a67cfed4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[null]\012",
        Z.run(T, 1, 1, 0, 4, "\ud8c0\udde8\u48e9\udbf2\udd5e\uda85\udc76\udb07\udf21\u09d7\uda7e\udffd\ud8fc\udd62\ud8b2\udf44\uda48\ude38\ud95f\udc44\udaec\ude33\uda20\udf76\000\ud9d9\udc6b\ud84a\udd57", "\u3b93\u4d69\u7823\000", "\ud8ff\ude02\ud825\udeae\ud8b7\udf0c",
        27, 71120, -370599411, 140915513353978L, -14591L, false, false, (char) 56428, (char) 25295,
        Double.longBitsToDouble(0x3f620bb81b0dea00L), Double.longBitsToDouble(0x3fec1edd282288ffL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\0121=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[\ud8d2\udf21\ud8f9\udcfc\udbf2\udd5e\udaf5\udee2\ud911\udf2c\ud852\udff0\ud9f9\udcb2\udb62\udd37\ud8b2\udf53\uda48\ude38\ud95f\udc44\udaec\ude33\ud954\udff1\uda0e\uddc7\uda49\ude9d\udae1\udc21\udbe2\udf45\uda83\udea6\udb34\udfa1\udb37\udfe1]\012",
        Z.run(T, 2, 4, 8, 6, "\ud8d2\udf21\ud8f9\udcfc\udbf2\udd5e\udaf5\udee2\ud911\udf2c\ud852\udff0\ud9f9\udcb2\udb62\udd37\ud8b2\udf53\uda48\ude38\ud95f\udc44\udaec\ude33\ud954\udff1\uda0e\uddc7\uda49\ude9d\udae1\udc21\udbe2\udf45\uda83\udea6\udb34\udfa1\udb37\udfe1", "\u7ed3\u55aa\ucfd6\u34ae\ud7ed\ua1c0\u81ce\ua7de\u787a", "\ud82d\udfb5\ud9f7\udce5\udb5f\udf38\udae5\ude49\udaf8\ude6b\uda78\udd79\ud929\udcdf\ud808\udcc9\ud8dc\udd49\ud9a8\udc7a\ud856\uddb8\ud8ff\uddb4\udb17\udf2a\udb7b\udd57\ud94f\udf35",
        16, 92276, 28199432, -8962859719088685165L, -82712L, false, true, (char) 5782, (char) 55857,
        Double.longBitsToDouble(0x3f8c33245d692200L), Double.longBitsToDouble(0x3fdb5d3e44e94e9eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NotPositiveException\012",
        Z.run(T, 1, 1, 0, 0, "\ud8c0\udde8\ud8f9\udcfc\udbf2\udd5e\uda85\udc76\u00af\u6802\uda7e\udffdt\ud8b2\ude96\u00fa\ud938\udefb\uda7b\udcda\000\000\000\000", "", "\ud838\udd32\udb94\udd6d\ud8ce\udd52\uf1e8\ud8e9\udcb3\ud825\udeae\ud8ed\udf07\ud9e6\udcf0\ud824\udd5e\udaec\udcbf\ud82a\ude6e\udacd\uddc2\000\udba1\udd06",
        -5, 78229, 1098329806, 65878346669860123L, 89918L, true, false, (char) 16565, (char) 46437,
        Double.longBitsToDouble(0x3fc25cadc1c26c70L), Double.longBitsToDouble(0x3fea4744db1897c2L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 1, 8, 2, 4, "\ud8c0\udde8\udb69\udd64\udbf2\udd8c\uda85\udc76\udb07\udf21\u6802\uda7e\udffd\ud8fc\udd62\ud8b2\udf44\uda48\ude38\ud95f\udc44\udaec\ude33\ud992\ude2e\ud9a2\udff7\uda49\ude8e\ud84a\udd57", "\u343b\u4d69\u7823\uc882", "\ud8ff\ude02\ud825\udeae\ud8b7\udf0c\ud9e6\udcf0\ud824\udd5e",
        34, 61697, -48730374, 6248281789328346529L, 1997L, false, false, (char) 19833, (char) 19973,
        Double.longBitsToDouble(0x3fec1bed222288ffL), Double.longBitsToDouble(0x3fcdb819a67cfed4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[\ud8c0\udde8\ud8be\udd3c]\0121=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[\ud8c0\udde8\ud8be\udd3c, \ud8c0\udde8\ud8be\udd3c]\012",
        Z.run(T, 2, 2, 2, 5, "\ud8c0\udde8\ud8be\udd3c", "\ucd7a\u65e3\uc625\ub448}\u7673\u2142\u4791\u1324\u7344\u8532\u30c5\u0db1\u4db8\u3b93\u4d69\u7823\uc882\uca7b\u86e4\ucfd6\u34ae\ud7ed\ua1c0\u2329\ua7de\u5ceb\uc769", "\ud9f7\udce5\uda28\udd7d\uda84\udea9\udba7\udcd3\uda20\udef6\uda86\udc7f\uda13\ude68\ud85c\udcae\ud9c1\udd3e\ud849\udc77\udbd7\udf20",
        24, 76125, 224980904, 6574001897317543834L, -18066L, false, true, (char) 58139, (char) 40530,
        Double.longBitsToDouble(0x3fe395ffa64212fbL), Double.longBitsToDouble(0x3fd5bba64ae00cfeL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NotPositiveException\012",
        Z.run(T, 1, 9, 6, 0, "\ud8c0\udde8\ud8f9\udcfc\udbb7\udc3a\uda34\udd2d\000\000\ud800\udd00\udb06\udde2\u00ae\000\000\ud833\udd59\ud992\ude2e\ud9a2\udff7\000\u00f4", "", "\ud9ae\udd2d",
        11, -1000, -1891559283, 98195845677056L, -51690L, false, false, (char) 90, (char) 0,
        Double.longBitsToDouble(0x3e3a3b9800000000L), Double.longBitsToDouble(0x3fda156b60977aeaL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\0121=java.lang.String:[] |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\012",
        Z.run(T, 2, 3, 10, 10, "\ud8c0\udde8\ud8f9\udcfc\udae1\udfd6\udaef\udd04\ud93b\udd47\u74f4\uda98\ude72\uda79\udec8\ud834\udd99\uda2e\udcac\ud95f\udc2d\udaec\ude33\ud992\ude2e\ud9a2\udff7\uda49\ude8e\ud84a\udd57", "\u9322\u4d69\u7823\uc882", "\ud8ff\ude02\ud825\udeae\ud8b7\udf0c\ud9e6\udcf0\ud824\udd5e",
        34, 61697, 1931339514, 6248281892407561633L, 1997L, false, false, (char) 19833, (char) 45828,
        Double.longBitsToDouble(0x3fec1edd2a2288ffL), Double.longBitsToDouble(0x3fd252d01f41619cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection$1:@? |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 5, 3, "\udb3f\ude21\ud9fd\udc9e\uda3e\udf85\ud8c0\udee1\uda7a\udf01\ud857\udfe7\u3511\udb3c\udee6\ud982\udcb6\uda56\udfb7\ud88b\udc42\ud8ef\udf54\uda32\udfec\ud974\udee1\udb5e\udd1c\ud827\udc49", "\u7366\u30c8\u91f7\ub253\u5edc\ua8af\ubbf1\u8f1d\u2ef5\u9ade\u3816\uc7dc\u7541\u24f4\u5389\u26bd", "\udbd8\udf38\ud8bb\udcf0",
        49, 55914, 859218507, 3077702634678558191L, -76691L, false, false, (char) 57709, (char) 37693,
        Double.longBitsToDouble(0x3fe33c803a1a626bL), Double.longBitsToDouble(0x3fc33204be7a5324L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[null]\0121=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[null, null]\012",
        Z.run(T, 2, 1, 1, 0, "\ud8c0\udde8\udac7\udd03\udbf2\udd5e\uda85\udc76\udb07\udf21\u6802\uda7e\udffd\ud871\udcfc\ud8da\udf27\uda48\ude38\udb91\udc6c\udaec\ude33\ud992\ude2e\ud9a2\udff7\udbfd\udc09\ud942\udde0", "\u3b93\u4d69\u7823\uc882", "\udbaa\udf19\ud825\ude2f\ud8b7\udf0c\ud80e\udce7\ud824\udd5e",
        40, 45553, 670948232, 6209971020350442913L, 1997L, true, false, (char) 45267, (char) 52677,
        Double.longBitsToDouble(0x3fec1d843a2288ffL), Double.longBitsToDouble(0x3fe73ae4849f1b82L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[null]\0121=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[null, null]\012",
        Z.run(T, 2, 1, 1, 1, "\ud8c0\udde8\u48e9\udbf2\udd5e\ud86f\udd6a\u8e97\u09d7\uda7e\udffd\ud8fc\udd62\ud8b2\udf44\uda48\ude38\ud95f\udc44\udaec\ude33\uda20\udf76\000\ud9d9\udc6b\ud84a\udd57", "\ud164\ua8df\ubdce\000", "\ud8ff\ude02\ue3ae\ud8b7\udf0c",
        27, 71120, -370599411, 140915513353978L, -14591L, false, false, (char) 56428, (char) 25295,
        Double.longBitsToDouble(0x3f620bb8a433c300L), Double.longBitsToDouble(0x3fec1edd282288ffL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[\ud8d2\udf21\ud8f9\udcfc\ud836\udd60\udaf5\udee2\ud911\udf2c\ud852\udff0\ud9f9\udcb2\udb62\udd37\ud8b2\udf53\uda48\ude38\ud95f\udc44\udaec\ude33\ud954\udff1\uda0e\uddc7\uda49\ude9d\udae1\udc21\udbe2\udf45\uda83\udea6\udb34\udfa1\udb37\udfe1]\0121=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[\ud8d2\udf21\ud8f9\udcfc\ud836\udd60\udaf5\udee2\ud911\udf2c\ud852\udff0\ud9f9\udcb2\udb62\udd37\ud8b2\udf53\uda48\ude38\ud95f\udc44\udaec\ude33\ud954\udff1\uda0e\uddc7\uda49\ude9d\udae1\udc21\udbe2\udf45\uda83\udea6\udb34\udfa1\udb37\udfe1]\012",
        Z.run(T, 2, 8, 8, 6, "\ud8d2\udf21\ud8f9\udcfc\ud836\udd60\udaf5\udee2\ud911\udf2c\ud852\udff0\ud9f9\udcb2\udb62\udd37\ud8b2\udf53\uda48\ude38\ud95f\udc44\udaec\ude33\ud954\udff1\uda0e\uddc7\uda49\ude9d\udae1\udc21\udbe2\udf45\uda83\udea6\udb34\udfa1\udb37\udfe1", "\u7ed3\u5b4c\ucfd6\u34ae\ud7ed\ua1c0\u81ce\ua7de\u787a", "\ud82d\udfb5\ud9f7\udce5\udb5f\udf38\udae5\ude49\udaf8\ude6b\udbf0\ude15\uda25\ude10\ud8c4\udeca\ud809\udcb7\udbdc\uddb1\ud854\udf57\uda55\udd87\udbc7\udc38\udb7b\udd89\ud94f\udf35",
        16, 92276, 28199432, 8475078038089875347L, -82712L, false, true, (char) 5782, (char) 55857,
        Double.longBitsToDouble(0x3f8c33245d692200L), Double.longBitsToDouble(0x3fa48b5cadd93d80L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 4, 8, 6, "\ud8d2\udf21\ud8f9\udcfc\udbf2\udd5e\udaf5\udee2\ud911\udf2c\ud852\udff0\ud9f9\udcb2\udb62\udd37\ud8b2\udf53\uda48\ude38\ud95f\udc44\udaec\ude33\ud954\udff1\uda0e\uddc7\uda49\ude9d\udae1\udc21\udbe2\udf45\udae4\udd35\udb34\udfa1\udb37\udfe1", "\u7ed3\u55aa\ucfd6\u34ae\ud7ed\u297d\u81ce\ua7de\u787a", "\ud82d\udfb5\uda07\udce5\udb5f\udf38\udae5\ude49\udaf8\ude6b\uda78\udd79\ud929\udcdf\ud808\udcc9\ud8dc\udd49\ud9a8\udc7a\ud856\uddb8\ud8ff\uddb4\udb17\udf2a\udb7b\udd57\ud94f\udf35",
        16, 92276, 1288593194, -8962764581268111469L, -82712L, false, true, (char) 5782, (char) 55857,
        Double.longBitsToDouble(0x3f8c33245d692200L), Double.longBitsToDouble(0x3fdb5d3e44e94e9eL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableCollection$1:@? |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\0121=java.util.Collections$UnmodifiableCollection$1:@? |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\012",
        Z.run(T, 2, 0, 0, 0, "\ud8d2\udf21\ud8f9\udcfc\udbf2\udd5e\udaf5\udee2\ud911\udf2c\ud852\udff0\ud9f9\udcb2\udb62\udd37\ud8b2\udf53\uda48\ude38\ud95f\udc44\udaec\ude33\ud954\udff1\uda0e\uddc7\uda49\ude9d\udae1\udc21\udbe2\udf45\uda83\udea6\udb34\udfa1\udb37\udfe1", "\u7ed3\u55aa\ucfd6\u34ae\ud7ed\ua1c0\u81ce\ua7de\u787a", "\ud82d\udfb5\ud9f7\udce5\udb5f\udf38\udae5\ude49\udaf8\ude6b\uda78\udd79\ud929\udcdf\ud808\udcc9\ud8dc\udd49\ud9a8\udc7a\ud856\uddb8\ud8ff\uddb4\udb17\udf2a\udb7b\udd57\ud94f\udf35",
        16, -900, 0, -8962859719088685165L, -82712L, false, true, (char) 5782, (char) 55857,
        Double.longBitsToDouble(0x3f8c33245d692200L), Double.longBitsToDouble(0x3fdb5d3e44e94e9eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[\ud8c0\udde8\udb69\udd64\udbf2\udd8c\uda85\udc76\udb07\udf21\u6802\uda7e\udffd\ud8fc\udd62\ud8b2\udf44\uda48\ude38\ud95f\udc44\udaec\ude33\ud992\ude2e\ud9a2\udff7\uda49\ude8e\ud84a\udd57]\0121=!org.apache.commons.math3.exception.NumberIsTooLargeException\012",
        Z.run(T, 2, 8, 2, 4, "\ud8c0\udde8\udb69\udd64\udbf2\udd8c\uda85\udc76\udb07\udf21\u6802\uda7e\udffd\ud8fc\udd62\ud8b2\udf44\uda48\ude38\ud95f\udc44\udaec\ude33\ud992\ude2e\ud9a2\udff7\uda49\ude8e\ud84a\udd57", "\u343b\u4d69\u7823\uc882", "\ud8ff\ude02\ud825\udeae\ud8b7\udf0c\ud9e6\udcf0\ud824\udd5e",
        1, 61697, -48730455, 6248281789328346529L, 1997L, false, false, (char) 18890, (char) 41277,
        Double.longBitsToDouble(0x3fdcc1ea45b0ce44L), Double.longBitsToDouble(0x3fcdb819a67cfed4L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\0121=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\012",
        Z.run(T, 2, 9, 9, 2, "\udaf7\udfe3\udbf5\uddee\uda23\udee8\udabd\ude95\udbd2\udc24\u00b0\ud838\udd07\uda7d\udf93\udaf4\uddd4\udb94\ude37\uda34\udf41\ud8a4\udd09\udb28\udf84\udaae\udfae\udaac\udf38\u0092", "\u7910", "\ua947\ud8a9\udc6a\uda15\udead\uf1a9\uda10\udc48",
        37, 47310, 5963264, 0L, 54439L, true, true, (char) 48576, (char) 1863,
        Double.longBitsToDouble(0x3fd67f062a75e05eL), Double.longBitsToDouble(0x3fee9c2f000161d9L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[null]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 3, "\udb3f\ude21\ud9fd\udc9e\uda3e\udf85\ud8c0\udee1\uda7a\udf01\ud857\udfe7\u3511\udb3c\udee6\ud982\udcb6\uda56\udfb7\ud88b\udc42\ud8ef\udf54\uda32\udfec\ud974\udee1\udb5e\udd1c\ud827\udc49", "\u7366\u30c8\u91f7\ub253\u5edc\ua8af\ubbf1\u8f1d\u2ef5\u9ade\u3816\uc7dc\u7541\u24f4\u5389\u26bd", "\udbd8\udf38\ud8bb\udcf0",
        49, 55914, 859218507, 3077702634678558191L, -76691L, false, false, (char) 57709, (char) 37693,
        Double.longBitsToDouble(0x3fe33c803a1a626bL), Double.longBitsToDouble(0x3fc33204be7a5324L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\0121=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[]\012",
        Z.run(T, 2, 9, 9, 10, "\ud8d2\udf21\ud8f9\udcfc\udb5c\udfd4\udaf5\udf4e\ud911\udf2c\ud852\udff0\ud9f9\udcb2\udb62\udd37\ud8b2\udf53\ud941\udc05\ud83c\ude8c\udbbb\udf9b\uda1e\udfbf\ud9f9\udf9e\uda49\ude9d\uda68\udf4a\udbe3\udc12\udae4\udd35\udb34\udfa1\udb37\udfe1\uda11\udf9e\ud9fb\udd09\ud86b\uddbd\udb92\ude37", "\u7c53\ub6c2\ubcb2\ua822\u787a\uc6f0\u8a0c\u14c3\u0ce1\uada9\u7120\u9170", "\ud808\udcc9\ud8dc\udd49\udaa7\ude20\ud856\udde4\ud8ff\uddb4\udb17\udf2a\udb7b\udd57\ud94f\udf35\udbca\udd02\ud8ed\uddc2\ud9a8\udf02\udaa6\udc78\udb68\udd73\ud9ac\udfaa\udb6d\udf2f\uda60\udd57\udb94\udc3d\udb2d\uddf4\ud813\udeaa\uda27\udedb\udbd2\udc7a\udbcb\udc53\ud9ac\udcce\udacf\udd8b",
        35, 18014, -1797305328, 2931595899576945619L, 11859L, false, true, (char) 34748, (char) 37885,
        Double.longBitsToDouble(0x3feb2e923d658540L), Double.longBitsToDouble(0x3fc46abf5f441200L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[\ud8c0\udde8\udb69\udd64\udbf2\udd8c\uda85\udc76\udb07\udf21\u6802\uda7e\udffd\ud8fc\udd62\ud8b2\udf44\uda48\ude38\ud95f\udc44\udaec\ude33\ud992\ude2e\ud9a2\udff7\uda49\ude8e\ud84a\udd57]\0121=!org.apache.commons.math3.exception.NumberIsTooLargeException\012",
        Z.run(T, 2, 8, 1, 4, "\ud8c0\udde8\udb69\udd64\udbf2\udd8c\uda85\udc76\udb07\udf21\u6802\uda7e\udffd\ud8fc\udd62\ud8b2\udf44\uda48\ude38\ud95f\udc44\udaec\ude33\ud992\ude2e\ud9a2\udff7\uda49\ude8e\ud84a\udd57", "\u343b\u4d69\u7823\uc882", "\ud8ff\ude02\ud825\udeae\ud8b7\udf0c\ud9e6\udcf0\ud824\udd5e",
        1, 61697, -48730455, 6248281789328346529L, 1997L, false, false, (char) 18890, (char) 41277,
        Double.longBitsToDouble(0x3fdcc1ea45b0ce44L), Double.longBitsToDouble(0x3fcdb819a67cfed4L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 5, 2, 4, "\ud8c0\udde8\ud8f9\udcfc\udbf2\udd5e\udb98\udd70\udb07\udf1d\u6802\uda7e\udffd\ud8fc\udd62\ud8b2\udf44\udb09\udfb2\uda75\udcbb\u3170\udb6f\udf6b\ud9a2\udff7\uda35\udf8e\ud84a\udd57\ud861\udf65\ud9a4\ude15\udbd7\udda2\udb37\udfe1\ud838\udd32\udb94\udd6d", "\u92d7\u5bfa\u38dd\ua309\u2329", "\udacd\uddc2\ud892\udc63\ud83c\uddb5\ud9f7\udce5\uda46\udd7d\u8dd1\udba7\udcd3",
        15, 26971, -1060300254, 4590598404855562655L, 83572L, false, true, (char) 2006, (char) 62990,
        Double.longBitsToDouble(0x3febfe5f757ad16fL), Double.longBitsToDouble(0x3fab0ddf8bbe40a0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[\ud989\ude66\udb88\udec5\udbf2\udd8c\uda85\udc76\udb07\udf21\u6802\uda6a\uddf6\ud8fc\udd62\udac4\udc8d\ubeb7\ud970\udd4a\udaec\ude33\ud992\ude2e\ud9a2\udff7\uda49\ude8e\udbfa\udc0e\ud88c\ude0e\uda6f\udd8c\uda8a\udcd5\udb37\udfe1\ud838\udd32\udb94\udd6d\ud8ce\udd52\udb02\udecf\ud8f4\udf21\ud825\udeae\ud8b7\udf0c\ud9e6\udcf0\ud824\udd5e\ud8e0\udf79\u8bbd\uda9a\udf43\ud8b0\udd0f\ud83c\uddb5\ud9f7\udce5\uda46\udd7d\ud933\udd01\ud98f\ude0b\ud8ee\udde9\udbb4\udfdf\uda13\udf1e\ud84a\udcae\uda60\udeaf\ud8a1\udca0\u08c5\udbdd\udca1\ud96b\udd88\ud8ff\udc2b\ud880\uddfb\ud890\udc36\udb8e\udc2f\uda20\udc57\udaa1\ude53\ud843\udec3\ud829\udd54\ud8e9\ude86\ud993\udc10\u3f3e\ud88d\udc47\ud861\udca0\udb5c\udee3\ud84f\udf40\udb1f\udf42\udbaa\udf0e\udbd0\udf5a\udb0c\udf3b\udb60\uddb2\uda91\udc7a\udba9\udf0a\udb53\udf54\udae5\ude91\udb26\udd75\ud7d5\ud8bf\udff4\udb73\udc11\u0c06\ud818\udc88\ud806\udc3d\ud8a6\udc01\udb42\udd0d\u3831\udac7\ude51\ud94a\uddaf\uda24\udde6\ud9be\udd9a\ud80a\udc57\uda7a\uddf9\ud8cd\udca9\ud902\udf23\uda7a\udf27\udafc\ude84\ud803\udfec\ud880\udc0c\uda0a\udee4]\0121=void |this=org.apache.commons.math3.genetics.ElitisticListPopulation:[\ud989\ude66\udb88\udec5\udbf2\udd8c\uda85\udc76\udb07\udf21\u6802\uda6a\uddf6\ud8fc\udd62\udac4\udc8d\ubeb7\ud970\udd4a\udaec\ude33\ud992\ude2e\ud9a2\udff7\uda49\ude8e\udbfa\udc0e\ud88c\ude0e\uda6f\udd8c\uda8a\udcd5\udb37\udfe1\ud838\udd32\udb94\udd6d\ud8ce\udd52\udb02\udecf\ud8f4\udf21\ud825\udeae\ud8b7\udf0c\ud9e6\udcf0\ud824\udd5e\ud8e0\udf79\u8bbd\uda9a\udf43\ud8b0\udd0f\ud83c\uddb5\ud9f7\udce5\uda46\udd7d\ud933\udd01\ud98f\ude0b\ud8ee\udde9\udbb4\udfdf\uda13\udf1e\ud84a\udcae\uda60\udeaf\ud8a1\udca0\u08c5\udbdd\udca1\ud96b\udd88\ud8ff\udc2b\ud880\uddfb\ud890\udc36\udb8e\udc2f\uda20\udc57\udaa1\ude53\ud843\udec3\ud829\udd54\ud8e9\ude86\ud993\udc10\u3f3e\ud88d\udc47\ud861\udca0\udb5c\udee3\ud84f\udf40\udb1f\udf42\udbaa\udf0e\udbd0\udf5a\udb0c\udf3b\udb60\uddb2\uda91\udc7a\udba9\udf0a\udb53\udf54\udae5\ude91\udb26\udd75\ud7d5\ud8bf\udff4\udb73\udc11\u0c06\ud818\udc88\ud806\udc3d\ud8a6\udc01\udb42\udd0d\u3831\udac7\ude51\ud94a\uddaf\uda24\udde6\ud9be\udd9a\ud80a\udc57\uda7a\uddf9\ud8cd\udca9\ud902\udf23\uda7a\udf27\udafc\ude84\ud803\udfec\ud880\udc0c\uda0a\udee4, \ud989\ude66\udb88\udec5\udbf2\udd8c\uda85\udc76\udb07\udf21\u6802\uda6a\uddf6\ud8fc\udd62\udac4\udc8d\ubeb7\ud970\udd4a\udaec\ude33\ud992\ude2e\ud9a2\udff7\uda49\ude8e\udbfa\udc0e\ud88c\ude0e\uda6f\udd8c\uda8a\udcd5\udb37\udfe1\ud838\udd32\udb94\udd6d\ud8ce\udd52\udb02\udecf\ud8f4\udf21\ud825\udeae\ud8b7\udf0c\ud9e6\udcf0\ud824\udd5e\ud8e0\udf79\u8bbd\uda9a\udf43\ud8b0\udd0f\ud83c\uddb5\ud9f7\udce5\uda46\udd7d\ud933\udd01\ud98f\ude0b\ud8ee\udde9\udbb4\udfdf\uda13\udf1e\ud84a\udcae\uda60\udeaf\ud8a1\udca0\u08c5\udbdd\udca1\ud96b\udd88\ud8ff\udc2b\ud880\uddfb\ud890\udc36\udb8e\udc2f\uda20\udc57\udaa1\ude53\ud843\udec3\ud829\udd54\ud8e9\ude86\ud993\udc10\u3f3e\ud88d\udc47\ud861\udca0\udb5c\udee3...\012",
        Z.run(T, 2, 8, 2, 4, "\ud989\ude66\udb88\udec5\udbf2\udd8c\uda85\udc76\udb07\udf21\u6802\uda6a\uddf6\ud8fc\udd62\udac4\udc8d\ubeb7\ud970\udd4a\udaec\ude33\ud992\ude2e\ud9a2\udff7\uda49\ude8e\udbfa\udc0e\ud88c\ude0e\uda6f\udd8c\uda8a\udcd5\udb37\udfe1\ud838\udd32\udb94\udd6d\ud8ce\udd52\udb02\udecf\ud8f4\udf21\ud825\udeae\ud8b7\udf0c\ud9e6\udcf0\ud824\udd5e\ud8e0\udf79\u8bbd\uda9a\udf43\ud8b0\udd0f\ud83c\uddb5\ud9f7\udce5\uda46\udd7d\ud933\udd01\ud98f\ude0b\ud8ee\udde9\udbb4\udfdf\uda13\udf1e\ud84a\udcae\uda60\udeaf\ud8a1\udca0\u08c5\udbdd\udca1\ud96b\udd88\ud8ff\udc2b\ud880\uddfb\ud890\udc36\udb8e\udc2f\uda20\udc57\udaa1\ude53\ud843\udec3\ud829\udd54\ud8e9\ude86\ud993\udc10\u3f3e\ud88d\udc47\ud861\udca0\udb5c\udee3\ud84f\udf40\udb1f\udf42\udbaa\udf0e\udbd0\udf5a\udb0c\udf3b\udb60\uddb2\uda91\udc7a\udba9\udf0a\udb53\udf54\udae5\ude91\udb26\udd75\ud7d5\ud8bf\udff4\udb73\udc11\u0c06\ud818\udc88\ud806\udc3d\ud8a6\udc01\udb42\udd0d\u3831\udac7\ude51\ud94a\uddaf\uda24\udde6\ud9be\udd9a\ud80a\udc57\uda7a\uddf9\ud8cd\udca9\ud902\udf23\uda7a\udf27\udafc\ude84\ud803\udfec\ud880\udc0c\uda0a\udee4", "\ua05d", "\ud85e\udfc7\udb36\udf6d\ud830\udc3c\udb64\udd07\udb9e\udebc\udb4a\udcc3",
        12, 2980, -795247335, 6584289630386840265L, 68781L, true, true, (char) 19606, (char) 2613,
        Double.longBitsToDouble(0x3febc3935adc3588L), Double.longBitsToDouble(0x3fe68f2d11278722L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.genetics.ListPopulation|iterator||new:org.apache.commons.math3.genetics.ElitisticListPopulation:int,double",
    "M|org.apache.commons.math3.genetics.ListPopulation|addChromosome|org.apache.commons.math3.genetics.Chromosome|new:org.apache.commons.math3.genetics.ElitisticListPopulation:int,double",
    "M|org.apache.commons.math3.genetics.ListPopulation|addChromosomes|java.util.Collection|new:org.apache.commons.math3.genetics.ElitisticListPopulation:int,double",
    "M|org.apache.commons.math3.genetics.ListPopulation|getChromosomeList||new:org.apache.commons.math3.genetics.ElitisticListPopulation:int,double",
    "M|org.apache.commons.math3.genetics.ListPopulation|getChromosomes||new:org.apache.commons.math3.genetics.ElitisticListPopulation:int,double",
    "M|org.apache.commons.math3.genetics.ListPopulation|getFittestChromosome||new:org.apache.commons.math3.genetics.ElitisticListPopulation:int,double",
    "M|org.apache.commons.math3.genetics.ListPopulation|getPopulationLimit||new:org.apache.commons.math3.genetics.ElitisticListPopulation:int,double",
    "M|org.apache.commons.math3.genetics.ListPopulation|getPopulationSize||new:org.apache.commons.math3.genetics.ElitisticListPopulation:int,double",
    "M|org.apache.commons.math3.genetics.ListPopulation|setChromosomes|java.util.List|new:org.apache.commons.math3.genetics.ElitisticListPopulation:int,double",
    "M|org.apache.commons.math3.genetics.ListPopulation|setPopulationLimit|int|new:org.apache.commons.math3.genetics.ElitisticListPopulation:int,double",
    "M|org.apache.commons.math3.genetics.ListPopulation|toString||new:org.apache.commons.math3.genetics.ElitisticListPopulation:int,double",
    "M|org.apache.commons.math3.genetics.ListPopulation|iterator||new:org.apache.commons.math3.genetics.ElitisticListPopulation:int,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
