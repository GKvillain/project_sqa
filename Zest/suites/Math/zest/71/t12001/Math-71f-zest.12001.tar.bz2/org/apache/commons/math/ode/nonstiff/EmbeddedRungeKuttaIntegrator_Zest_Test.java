package org.apache.commons.math.ode.nonstiff;
import org.junit.Test;
import static org.junit.Assert.*;
public class EmbeddedRungeKuttaIntegrator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Double:10.0 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 3, 7, 9, "\ud988\udcde\udbf9\udc79\ud84c\udc77\ud9f9\ude77\ud8c7\ude6c\ud8fa\uddaa\udbda\ude7f\ud82f\udf14\ud909\ude7b\ud9f1\uddfa\udac1\uddac\uda1b\ude4e\udaf5\udeaa\ud86f\udd73", "\u2a99\ubdee", "\ud8aa\udc37\udbc0\udc64\ud822\udf09\ud8e2\ude4b\udac0\uddf4\uda1a\udef9\ud8e9\ude85\ud848\udfe9\udb0b\udd7c\ud8ab\udd79\ud913\uddf2\ud889\udec3",
        13, 6477, 319644167, -678202389735725080L, 57047L, true, true, (char) 64558, (char) 15507,
        Double.longBitsToDouble(0x3feaceb96bfac477L), Double.longBitsToDouble(0x3fc9929dfaf18ab4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Double:10.0 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 3, 7, 9, "\ud988\udcde\udbf9\udc79\ud84c\udc77\ud9f9\ude77\ud8c7\ude6c\ud8fa\uddaa\udbda\ude7f\ud82f\udf14\ud909\ude7b\ud9f1\uddfa\udac1\uddac\uda1b\ude4e\udaf5\udeaa\ud86f\udd73", "\u2a99\ubdee", "\ud8aa\udc37\udbc0\udc64\ud822\udf09\ud8e2\ude4b\udac0\uddf4\uda1a\udef9\ud8e9\ude85\ud848\udfe9\udb0b\udd7c\ud8ab\udd79\ud913\uddf2\ud889\udec3",
        13, 6477, 319644167, -678202389735725080L, 57047L, true, true, (char) 64558, (char) 15507,
        Double.longBitsToDouble(0x3feaceb96bfac477L), Double.longBitsToDouble(0x3fe9fca77ebccc3eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 8, 7, 8, "\udb93\uddda\udbf9\udc79\ud84c\udc77", "\ub690\u1100\ua129\u2b93\u0380", "\ud801\udc70\udbf6\udeb7\ud9e2\udfd3\udb41\udfac\ud95b\udd19\udbb7\udcc8\udae8\udd32\ud802\udc65\udb8c\udfe9\udb49\udc43\ud899\udf52\ud99d\udf47\udab3\udd9d\uda1a\udef9\ud8e9\ude85\ud848\udfe9\udb0b\udd7c\ud8ab\udd79\ud913\uddf2\ud889\udec3\ud95a\udf26\ud9a5\udc0c\ud86a\udf51\u19f7\ud8ea\udcf7\udb8b\udc7a\u6196\udb76\udd15\uda94\udca7\ud85c\ude25\ud9e8\udedd",
        54, 67372, -1398713156, -9063718713685898181L, -82984L, true, false, (char) 26769, (char) 16506,
        Double.longBitsToDouble(0x3fe0a6313df97018L), Double.longBitsToDouble(0x3fe89b3ce7b8ed73L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 9, 8, 9, "\ud9fa\udf7b\ud983\udfff\udade\ude4a\ud8ce\udd00\udb69\udd08\udb46\udd00\udbda\ude34\ud82f\udf14\ud909\ude7b\udaf3\uddf0\udac1\uddac\uda1b\ude4e\udaf5\ude0f\uda5c\ude12", "\u2a99\u5e92", "\ud90a\udd3b\udbc0\udc64",
        -3, 57604, 860403425, -4167045295467511111L, -33832L, true, false, (char) 36896, (char) 59825,
        Double.longBitsToDouble(0x3fef0e9eb1cda851L), Double.longBitsToDouble(0x3fe61b20da85130dL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 10, "\ud988\udcde\udbf9\udc79\ud84c\udc77", "\ub690\u8943\u1a92\ud424\u7ab1", "\udaf5\udeaa\ud86f\udd73\udac8\ude1f\udb2a\udebf\ud95b\udd19\udbb7\udcc8\ud990\udec7\ud9c7\udd9b\ud8aa\udc37\udbc0\udc64\ud822\udf09\ud8e2\ude4b\udac0\uddf4\uda1a\udef9\uda7d\udf35\ud854\udfef\udb0b\udd7c\ud8ab\udd79\ud913\uddf2\ud889\udec3\ud897\ude39\udb5a\udcc2\ud998\udf26\u19f7\ud8ea\udcf7\uda85\udc6e\uda75\udf6c\ud877\udea2\uda94\udd42\ud85c\ude25\udb55\udfd6",
        54, 67372, -182438212, 8194636771854444603L, -79041L, false, false, (char) 30673, (char) 28999,
        Double.longBitsToDouble(0x3f92c4ac30efeb00L), Double.longBitsToDouble(0x3fb1962050893248L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 7, 9, "\ud988\udcde\udbf9\udc79\ud84c\udc77\ud9f9\ude77\ud8c7\ude6c\ud8fa\uddaa\udbda\ude7f\ud82f\udf14\ud909\ude7b\ud9f1\uddfa\udac1\uddac\uda1b\ude4e\udaf5\udeaa\ud86f\udd73", "\u2a99\ubdee", "\ud9b4\udc3f\ud881\udc6d\u6fb9\ud8e2\uddf6\udac0\uddf4\uda1a\udef9\ud8e9\ude85\ud848\udfe9\udb0b\udd7c\ud8ab\udd79\ud913\uddf2\ud889\udec3",
        13, 67541, 1192813638, 1901662058403538916L, 57047L, true, true, (char) 64558, (char) 15507,
        Double.longBitsToDouble(0x3feaceb96bfac477L), Double.longBitsToDouble(0x3fc9929dfaf18ab4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Double:10.0 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 3, 7, 9, "\ud988\udcde\ud9af\udf09\ud84c\udcb6\ud9f9\ude77\uda2c\udd5e\ud90f\ude62\udbda\ude7f\ud82f\udf14\ueca7\ud9f1\uddfa\udac1\uddac\uda1b\ude4e\udaf5\udeaa\ud86f\udd73", "\u2a99\ubdee", "\ud93a\udeea\udbc0\udc64\ud815\udc09\ud8e2\ude4b\udac0\uddf4",
        27, 66937, 2005187806, 3690984085952495285L, 5396L, true, true, (char) 23070, (char) 55330,
        Double.longBitsToDouble(0x3fe428986fe8f696L), Double.longBitsToDouble(0x3fecf08fdd7751b4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 7, 9, "\udab8\udf10\ud8b4\udf44\ud854\uded0\ud9f9\ude77\ud99e\uddf7\ud8fa\udd4e\udbda\ude7f\ud82f\udf14\ud909\ude7b\ud9f1\uddfa\udac1\uddac\udae9\ude94\udaf5\ude1d\ud86f\udd73", "\u2a99\ubdee", "\ud8aa\udc37\udbc0\udc64\ud822\udf09\ud8e2\ude4b\udac0\uddf4\uda1a\udef9\ud8e9\ude85\ud848\udfe9\udb0b\udd7c\ud8ab\udd79\ud913\uddf2\ud889\udec3",
        13, 14325, 2013852286, -678202389735725080L, 57047L, true, true, (char) 64558, (char) 15507,
        Double.longBitsToDouble(0x3feaceb96bfac477L), Double.longBitsToDouble(0x3fc9929dfaf18ab4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 4, 9, "\ud988\udcde", "\ucb98\000", "\ud82f\udf05\ud909\ude7b\ud9f1\uddfa",
        13, 25199, -1506006027, -9136250121238829360L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e0c800000000000L), Double.longBitsToDouble(0x3fd295300cf93024L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 0, "", "\uac8e", "",
        31, 7498, 290360847, 4968766072842235752L, -64207L, true, true, (char) 11048, (char) 10245,
        Double.longBitsToDouble(0x3fc7160e00a489d0L), Double.longBitsToDouble(0x3fbfb300331608b8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 9, 7, 9, "\udbf2\udef2\udbde\udf91\ud8a1\udcc1\ud9f9\ude77\ud8c7\ude6c\ud8fa\uddaa\udbda\ude7f\ud82f\udf7b\ud909\ude7b\ud9f1\uddfa\udac1\uddac\uda1b\ude4e\udaf5\udeaa\ud86f\udd73", "\u6570\ubdee", "\ud8aa\udc37\udbc0\udc64\ud822\udf09\ud847\udc3d\ud810\udfba\ud950\udf40\uda71\udca4",
        8, 65200, 1926332085, -8834623018499677108L, -79981L, true, false, (char) 40337, (char) 7807,
        Double.longBitsToDouble(0x3fef99667d7751b4L), Double.longBitsToDouble(0x3fe93a2f7741dcedL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 3, "\ud988\udcde\udbf9\udc79\ud84c\udc77\ud9f9\ude77\ud8c7\ude6c\udb2e\ude04\udbda\ude7f\ud82f\udf14\ud909\ude7b\ud9f1\uddfa\udac1\uddac\uda1b\ude4e\udaf5\udeaa\ud86f\udd73", "\u2a99\ubdee", "\ud8aa\udc37\udbc0\udc64\ud822\udf09\ud8e2\ude4b\udac0\uddf4\uda1a\udef9\ud96b\udf7e\ud848\udfe9\udb0b\udd7c\ud8ab\udd79\ud913\uddf2\ud889\udec3",
        5, 24757, 319679495, -678202389735725080L, 57047L, true, true, (char) 64558, (char) 15507,
        Double.longBitsToDouble(0x3feaceb96bfac477L), Double.longBitsToDouble(0x3fc9929dfaf18ab4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 2, "\udb93\uddec\udb2a\udd48\ud944\udf92", "\u9a39\u1100\ua129\u48e8\u1dd8\u726a\u31a1\u8b75\025\u8a50\u78ed", "\ud9ba\udfbb",
        -4, 85869, -265980008, -242640755933942522L, 84424L, true, true, (char) 56497, (char) 1077,
        Double.longBitsToDouble(0x3fd0ea651448eab4L), Double.longBitsToDouble(0x3f8560cffa3d9a40L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 10, "\ud988\udcde", "\u45f7", "\udbda\ude7f",
        57, 26003, -406442136, -2317894129100521425L, 62580L, false, false, (char) 6441, (char) 8861,
        Double.longBitsToDouble(0x3fbfb303800608b8L), Double.longBitsToDouble(0x3e2b5e3320000000L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:10.0 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=java.lang.Double:10.0 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 3, 3, 10, "\ud988\udcde\ud9f0\udcb3\ud850\udf77", "\u800c\u3524\u9868\ubfd2\u7276\u0972\u7bd6\u89c6\uca7b\u1b80\u6820\u60ac\ube01\u95e7\u29ee\u1b2d\u802e\u0097\ua235", "\uda7d\udf35\ud854\udfef\udb35\udf21\ud9a2\udc21\uda7c\udde0\ud87e\udf6a\udaa1\udfbf\uda2d\udd21\ud8b1\udeb6\u1a39\ud8ea\udcf7\uda85\udc6e\uda75\udf6c\ud877\udea2\ud960\udd4f\ud85c\ude25\udb76\udde6",
        36, 42701, -1423414246, 8194728901229728872L, -61405L, false, false, (char) 45152, (char) 58264,
        Double.longBitsToDouble(0x3fcd68158e54f1a0L), Double.longBitsToDouble(0x3fd179672d404c0eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[27797.0, 28350.5, 28132.5, 28196.5, 27662.0, 28195.5, 32116.5, 27700.0]]] |a1=[D:[[]] |a2=[D:[[-24.0]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 2, 7, 9, "\ud95a\uddad\udbf9\udc79\ud84c\udc77\ufb19\ud898\udf4c\ud8fa\uddaa\udbd0\udfda\000\ud8e3\udc7bh\udac1\uddac\uda1b\ude4e\udaea\udeb5\u84ec", "", "\000",
        9, 85791, 186, -1192948224L, -100000L, false, false, (char) 30096, (char) 31228,
        Double.longBitsToDouble(0x3fe5a998052c72d1L), Double.longBitsToDouble(0x3eb958014eb00000L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[27820.0, 28247.0, 69.5, 14880.0, 27876.5, 28451.5, 27683.0, 28537.5]]] |a1=[D:[[]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 2, 7, 9, "\ud988\udcde\u00bb\u7470\ud9f9\ude77\ud876\udf23\000\000\017\000\000\udac1\uddac\uda1b\ude4e\000\000", "", "\ud990\udec7",
        37, 86015, 0, 5277905847947955751L, -100000L, false, true, (char) 59825, (char) 10710,
        Double.longBitsToDouble(0x3fdcda80088db670L), Double.longBitsToDouble(0x3e981c834c800000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Double:0.9 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 10, "\ud988\udcde\udbf9\udc79\ud84c\udc77\ud9f9\ude77\ud8c7\ude6c\ud8fa\uddaa\udbda\ude7f\ud82f\udf14\ud909\ude7b\ud9f1\uddfa\udac1\uddac\uda1b\ude4e\udaf5\udeaa\ud86f\udd73", "\u0459\ubdee", "\ud9b4\udc3f\ud881\udc6d\ud8d6\ude3b\udbe1\udec2\udac0\uddf4\uda1a\udef9\ud8e9\ude85\ud848\udfe9\udb0b\udd7c\ud8ab\udd79\ud913\uddf2\ud889\udec3",
        13, 67541, 722996044, 9108265885802827399L, 57047L, true, false, (char) 56093, (char) 15507,
        Double.longBitsToDouble(0x3feaceb96b72bd77L), Double.longBitsToDouble(0x3fc9929df9f18ab4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 2, 1, "\ud8c1\udd54\udbfb\ude2c\ud84c\udcb6\ud870\ude11\u342f\udb33\udec1\ucdc2\ud82f\udfbb\ueca7\ud9f1\uddfa\ud8d6\udf17\ud848\udd4f\udaf5\ude7d\ud853\ude44", "\u8543\ub827\u49ea\ud05a\ud38c", "\ud952\udd3f\udac0\uddf4\uda1a\udef9\ud8e9\ude85\ud848\udfe9\ud989\ude9b\ud8ab\udd79\ud913\uddf2\ud889\udec3\ud897\udec6\udb5a\udcc2\ud998\udf26\uda77\udfef\udaf5\uddd6\uda65\udd6e\ud97f\udcb8\uda80\udf2f\ud8ad\udd07\uda2a\ude75\u508a\udb13\ude0a\ud934\udebd\udbe0\udecd\udb32\udebb\ud8e5\udcad\ud8da\udcba\udb5f\ude05\ud898\udee0",
        4, 82073, 1897097703, -510539692831050339L, -39915L, false, false, (char) 40766, (char) 21156,
        Double.longBitsToDouble(0x3fe2651bc7f34905L), Double.longBitsToDouble(0x3fcee39040320344L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 6, "\ud97b\ude42\ud9af\udf09\ud84c\udcb6\ud9f9\ude77\udabd\uddbe\u804c\udbda\ude7f\udbf8\ude98\u8137\ud9f1\uddfa", "\u2191\ud6a5\u6884\u018e\u2a99\ubdee\u2564\u2c7b\ubfc9\u06fa\ua6fb\ua235\u157e\ub7f4\u7636\u6285\u872d\u4eca\u0bdc\u05e2\u84ac\u75c8\u1ecf\u5d92\u9537\u5874\u0356\u2461\uc948\u5915\u4374", "\udb0f\udf13\uda0e\udf21\udb72\udf4f\ube71\udbf6\udc92\ud8c0\udeb1",
        42, 95752, -1604629041, -9213213712108497837L, -25768L, false, true, (char) 12023, (char) 24366,
        Double.longBitsToDouble(0x3fec3fe23423580aL), Double.longBitsToDouble(0x3fd63228fa1e9ca2L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Double:10.0 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 7, "\ud988\udd2e\udadd\udc80\uda84\udfe8\uda24\udfd5\uda2c\udd5e\ud90f\ude62\udbda\ude7f\ud82f\udf14\ueca7\ud92f\udd58\udac1\uddac\uda1b\ude4e\udaf5\udeaa\ud86f\udd73\udac8\ude1f\udb2a\udebf\ud95b\udd19\udbb7\udcc8\udbb0\udd0f\uda3f\udfc7\ud93a\udeea\udbc0\udc64\ud815\udc09\ud8e2\ude4b\udac0\uddf4\ud833\udeb7\ud8e9\ude53\ud848\udfe9\udb0b\udd7c\ud8ab\udd79\ud913\uddf2\ud889\udec3\ud897\udec6\udb5a\udcc2", "\u9537\u3437\u0aa3\u5d62\u3104\u2464\ua144\u2ee0\u5be9\u6a74\u66a7\u2428\u4304\u3279", "\uff54\udba1\udd05\ud884\udc48",
        41, 38574, 453516903, -8343037173381567007L, 85521L, false, false, (char) 36652, (char) 10355,
        Double.longBitsToDouble(0x3f869673a5480b80L), Double.longBitsToDouble(0x3fe08376e526b49cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[27820.0, 28247.0, 69.5, 14880.0, 27876.5, 28451.5, 27683.0, 28537.5], [-24.0, -24.0, 27976.5, 28350.0, 27893.5, 28431.0, -24.0, -24.0]]] |a1=[D:[[]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 2, 7, 9, "\ud988\udcde\u00bb\u7470\ud9f9\ude77\ud876\udf23\ud8ab\udd55\udb68\udf55;\000\000\udac1\uddac\uda1b\ude4e\000\000", "", "\ud990\udec7",
        37, 86015, 1761607680, 5277905847947955751L, 55424L, false, false, (char) 1472, (char) 7468,
        Double.longBitsToDouble(0x3fb3215940b94e20L), Double.longBitsToDouble(0x3fdcda800786f466L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 7, 9, "\ud988\udcde\u00bb\u7470\ud9f9\ude77\ud876\udf23\ud8ab\udd55\udb68\udf55;\000\000\udac1\uddac\uda1b\ude4e\000\000", "\uac06\u8bdb\u10ac\u14f4\ubed2\u7472\u9237\ua1e0\u4bb7\ub1d7\uc676\u81ce\ub130\000\u0bdc\u95cc\u8fca\u8aa2\u4d26\uad87", "\ud839\ude5e\ud80a\udfd2\ud89f\udcd7\uda53\ude17\ud8fe\udd1e\ud95d\udf49",
        37, 27992, -1580647650, 1767719188069773493L, -3815L, true, true, (char) 31113, (char) 30984,
        Double.longBitsToDouble(0x3fd0ac402e0d8cb0L), Double.longBitsToDouble(0x3fda64ae1ef43596L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 6, "\udbb6\udf95\udbcc\udc90\udae7\udf85\ud8a8\udd27\ud8a4\udd07\ud8fa\uddaa\uda1c\udd59\ud82f\udf14\ud909\ude7b\ud9f1\uddfa\udac1\uddac\ud873\udcd9\ud8c7\udc30\ud86b\udf5e\udac8\ude1f\udb2a\udebf", "\u95e7", "\udbc0\udc64\ud822\udf09\ud8e2\ude4b\udac0\uddf4\uda1a\udef9\ud8e9\ude85\ud829\udc42\udb27\udf7c\ud8ab\udd79\uda04\udd93\ud894\udc8f\ud897\udec6\udb5a\udcc2\udb01\udf2b\u19f7\ud8ea\udcf7",
        39, 34447, -588391641, -8068727319039202163L, -55962L, true, false, (char) 32393, (char) 25827,
        Double.longBitsToDouble(0x3fe9e40be47e5c6dL), Double.longBitsToDouble(0x3fe2582355ac5be4L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[27797.0, 28350.5, 28132.5, 28196.5, 27662.0, 28195.5, 32116.5, 27700.0]]] |a1=[D:[[]] |a2=[D:[[27671.5, 28223.5]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 1, "\ud95a\uddad\udbf9\udc79\ud84c\udc77\ufb19\ud898\udf4c\ud8fa\uddaa\udbd0\udfda\ud960\uded0\udbcc\udd9d\ud9d0\udfec\udac1\uddac\uda1b\ude4e\ud9bd\udf59\ud96c\udf8f", "", "\ud85f\udcaf",
        9, 85791, 186, -1192948224L, -100000L, false, false, (char) 30096, (char) 31348,
        Double.longBitsToDouble(0x3fe5a998052c72d1L), Double.longBitsToDouble(0x3eb958014eb00000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[-24.0, 28132.5, 28196.5, 27662.0, 28195.5, 32116.5, 27700.0, 28558.0]]] |a1=[D:[[]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "\000\udbf9\udc79\ud84c\udc77\ufb19\ud898\udf4c\ud8fa\uddaa\udbd0\udfda\ud960\uded0\ucf32\ud9d0\udfec\ud869\udd0e\uda1b\ude4e`\ud96c\udf8f", "", "\ud85f\udcaf",
        9, -1000, 0, 15011328L, -100000L, false, false, (char) 30096, (char) 132,
        Double.longBitsToDouble(0x3fe5a998052c72d1L), Double.longBitsToDouble(0x3eb958014eb00000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[-24.0, 28132.5, 28196.5, 28018.5, 28437.5, 32116.5, 27700.0, 28558.0]]] |a1=[D:[[]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 0, "\000\udbf9\udc79\udb15\ude5b\ufb19\ud898\udf4c\ud8fa\uddaa\udbd0\udfda\ud960\uded0\ucf32\ud9d0\udfec\ud869\udd0e\uda1b\ude4e`\ud96c\udf8f", "", "\ud85f\udcaf",
        9, -1000, 0, 15011328L, -100000L, false, false, (char) 30096, (char) 132,
        Double.longBitsToDouble(0x3fe5a998052c72d1L), Double.longBitsToDouble(0x3eb958014eb00000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[27928.0, 28352.0, 28132.5, 28196.5, 27662.0, 28195.5, 32116.5, 27700.0]]] |a1=[D:[[]] |a2=[D:[[27701.5, 28607.5]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=java.lang.Double:NaN |a0=[[D:[[[27928.0, 28352.0, 28132.5, 28196.5, 27662.0, 28195.5, 32116.5, 27700.0]]] |a1=[D:[[]] |a2=[D:[[27701.5, 28607.5]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 2, 2, 1, "\uda60\uddb0\udbf9\udc79\ud84c\udc77\ufb19\ud898\udf4c\ud8fa\uddaa\udbd0\udfda\ud960\uded0\udbcc\udd9d\ud9d0\udfec\udac1\uddac\ud85f\udf8f\ud9bd\udf59\ud8be\udcb6", "", "\ud89b\udfaf",
        3, 85791, 186, -1192948224L, -100000L, false, false, (char) 30096, (char) 64075,
        Double.longBitsToDouble(0x3fe5a99d652c72d1L), Double.longBitsToDouble(0x3eb958014eb00000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[-24.0, 28132.5, 28196.5, 28018.5, 28437.5, 10868.5, 27700.0, 28558.0]]] |a1=[D:[[]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=java.lang.Double:NaN |a0=[[D:[[[-24.0, 28132.5, 28196.5, 28018.5, 28437.5, 10868.5, 27700.0, 28558.0]]] |a1=[D:[[]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 2, 2, 1, "\000\udbf9\udc79\udb15\ude5b\u5519\ud898\udf4c\ud8fa\uddaa\ud905\udeca\ud960\udf35\ucf32\ud9d0\udfec\udb2f\udd11\uda03\udd07`\ud96c\udf8f", "", "\ud85f\udcaf",
        9, -1000, 0, 15011328L, 79712L, false, false, (char) 30096, (char) 132,
        Double.longBitsToDouble(0x3fe5a998052c72d1L), Double.longBitsToDouble(0x3eb958014eb00000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|integrate|org.apache.commons.math.ode.FirstOrderDifferentialEquations,double,[D,double,[D|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.RungeKuttaIntegrator|integrate|org.apache.commons.math.ode.FirstOrderDifferentialEquations,double,[D,double,[D|new:org.apache.commons.math.ode.nonstiff.ClassicalRungeKuttaIntegrator:double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|estimateError|[[D,[D,[D,double|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|getMaxGrowth||new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|getMinReduction||new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|getOrder||new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|getSafety||new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|setMaxGrowth|double|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|setMinReduction|double|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|setSafety|double|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|integrate|org.apache.commons.math.ode.FirstOrderDifferentialEquations,double,[D,double,[D|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.RungeKuttaIntegrator|integrate|org.apache.commons.math.ode.FirstOrderDifferentialEquations,double,[D,double,[D|new:org.apache.commons.math.ode.nonstiff.ClassicalRungeKuttaIntegrator:double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
