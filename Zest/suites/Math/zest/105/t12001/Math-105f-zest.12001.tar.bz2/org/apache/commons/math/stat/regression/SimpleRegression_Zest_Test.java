package org.apache.commons.math.stat.regression;
import org.junit.Test;
import static org.junit.Assert.*;
public class SimpleRegression_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 1, 10, 5, 8, "\udbc1\udee7\udaa5\udc7d\uda1e\udd60", "\uc262\u39b7\u63af\u81f6\u449e\u40c2", "\udbc4\udc59",
        37, 27004, 1356873909, -4329791859565617492L, 39266L, false, false, (char) 64617, (char) 46215,
        Double.longBitsToDouble(0x3fe3f4106aa19f24L), Double.longBitsToDouble(0x3fe70e57b93ac4b8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 1, 10, 10, 10, "\udb95\udfe7\ud82b\udf5f\uda15\udcf8", "\uc262\u39b7\u63af\u81f6\u449e", "\ud8e3\udecf\udbc4\udc59",
        -2, 22677, 1356873909, -4329791859565617492L, -89820L, true, false, (char) 64617, (char) 46215,
        Double.longBitsToDouble(0x3fe3f4106b170124L), Double.longBitsToDouble(0x3fe70cf9593ac4b8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[28105.5, 28215.5, 27962.5, 28198.5]]] |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 1, 2, 5, 8, "\udbc3\udc9f\udaa5\udc7d", "\u9667\uc0e7\u39b7\u70c2\u81f6\u449e\u40c2\u9489\u3b90\u7bc1\u776e\ub3eb\uc0b8\ub9ea\u2f39\ub1d6\u798a\u43c9\u2b3d\u960a", "\uda47\udd0f\udbaf\udf80\uda95\udf62\uda68\udc81\uda85\udf7c\udb81\udc65\ud855\udf75\ud9b7\ude25\udbe2\udffa\udb7c\udcb6\ua8a6\ud8e7\udeac\uda14\uddf7\ud824\udcd2\ud907\ude48\uda1d\udde3\ud97a\udf1b\uda32\udd7a",
        40, 7901, 2057802289, 8963526936705145802L, 67074L, true, false, (char) 27587, (char) 35339,
        Double.longBitsToDouble(0x3fc98da73e41447cL), Double.longBitsToDouble(0x3fbf1f6978a8c998L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 1, 4, 5, 8, "\uda5a\ude1b\udbb8\udef0", "\ud06d\ud425\u39b7\u63af\u5110\u5110\ud059\u9443\u3b90\u6fba\u0a75\u45e1\ub08f\u7606\u2f39\u66df", "\uda93\udc2a\ud82d\udd25",
        40, 60617, -1624973698, 961169566241147617L, 61710L, false, false, (char) 62105, (char) 283,
        Double.longBitsToDouble(0x3fabe1535e795720L), Double.longBitsToDouble(0x3fc4452aec7dfb44L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 2, 0, 5, 8, "\ud872\udf8f\udb38\ude55\uda1e\udd60", "\uc262\u39b7\u63af\ua16a\u449e\u590e\u7a1b\u3b90\u6fba\u0a75\u4fa8\u4936", "\udb75\udddc",
        25, 92345, -633724926, 1849992375369006666L, 50241L, true, false, (char) 11315, (char) 38067,
        Double.longBitsToDouble(0x3fbc4930f8baa0d0L), Double.longBitsToDouble(0x3fed78314c9be851L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 1, 10, 4, 8, "\ud8be\udfa7\udaa5\udc7d\uda1e\udd60", "\uc504\u39b7\u63af", "\udb33\udf87\udb75\udfb1\ud8e3\udecf\udbc4\udc59\udbf0\udfcd\udbef\udf48",
        9, 72494, 900532794, -7926166064085391262L, 62052L, false, false, (char) 64617, (char) 46215,
        Double.longBitsToDouble(0x3fe3f4106aa19f24L), Double.longBitsToDouble(0x3fe70e57b93ac4b8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 1, 9, 5, 8, "\udbc1\udee7\udaa5\udc7d\uda1e\udd60", "\uc262\u39b7\u63af\u81f6\u449e\u40c2", "\udbc4\udc59",
        33, 1365, 1356873909, -4329791859565617492L, 39266L, false, false, (char) 64617, (char) 46215,
        Double.longBitsToDouble(0x3fe3f4106aa19f24L), Double.longBitsToDouble(0x3fe23d37bf5fc4b8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 5, 4, "\udb77\udc22\udbcb\uddfb\ud9dd\udca7", "\uc262\u39b7\u63af\ub1c4\u6ed8\u40c2\ud734\u3b90\u6fba", "\ud85b\udd79",
        39, 59652, -676690658, -7534759286567761219L, -77540L, true, true, (char) 46215, (char) 24715,
        Double.longBitsToDouble(0x3fabfc922e113d50L), Double.longBitsToDouble(0x3fd3ac402d669c06L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 1, 7, 1, 8, "\udb7b\ude6a\udaa5\udc7d\uda1e\udd60", "\u5af9\u39b7\u63af\u81f6\u449e\u40c2", "\ud88d\udd78",
        37, 27004, 1356873909, -4329791859565617492L, 39266L, false, false, (char) 64617, (char) 53367,
        Double.longBitsToDouble(0x3fef727a530cc29cL), Double.longBitsToDouble(0x3fe0952489362244L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\0121=void |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 2, 11, 1, 8, "\udbc1\udee7\ud9e1\udc7b\uda89\ude35", "\u325a\u48ae\u9771\u620d\u57ff\u8c6c\u59fa\u03ad\u6fcf\u4a9a\u346e\ub08f\uc6bb\u2f39\ub1d6\u9a14\u43f7\u00fb\u2d36\uba8c\u83e8\u8bb2", "\uda89\udfd2\udbac\udcbb\ud9da\udd47\ud9fc\udc42\udaf6\udc08\udbee\ude00\ud83f\udea5\ud963\udf88\ud9d8\ude39\udad2\udedd\udb0b\uddf9\uce6a\udb2e\udff6",
        30, 86121, -925287767, 711761244080790999L, -94382L, true, false, (char) 50282, (char) 2946,
        Double.longBitsToDouble(0x3fe50467a628579eL), Double.longBitsToDouble(0x3fe8aa3e10e475cbL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 1, 1, 12, 8, "\udbc1\udee7\udaa5\udc7d\ud8d5\ude44\ud9c6\udc0b\udb12\udff8\udbbd\uddb8\udb2a\udeb2\udb2a\ude1e\udae9\udc7c\udbad\ude71\udb33\udf87\udb75\udfb1\ud9eb\uded3", "\u45e1\u3890\u7606\u36a0\u340b\u5473\u43f7", "\ud98d\udef1\udb72\uddc2\udb0c\udcc8\udbaf\udf80\uda95\udf62",
        20, 45160, -1667554083, 5216056613985134627L, 24311L, true, true, (char) 3565, (char) 43095,
        Double.longBitsToDouble(0x3fe6a21e1ff8996fL), Double.longBitsToDouble(0x3fef9395c7a42c99L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 1, 12, 8, 11, "\ud9c6\udfd2\udaa1\udced\uda1e\udd60", "\uc262\u39b7\u63af\u81f6\u449e\u40c2", "\udbc4\udc59",
        37, 13402, -551828291, -3164681346106730582L, 39266L, false, false, (char) 64617, (char) 46215,
        Double.longBitsToDouble(0x3fe3f4106aa19f24L), Double.longBitsToDouble(0x3fe70e57b93ac4b8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 1, 6, 5, 8, "\udbfd\udfe5", "\u8aac\ud06d", "\udb2a\ude1e\udae9\udc7c\udbad\ude71\udb33\udf87\udb75\udfb1\ud8e3\udecf\udbc4\udc59\udbf0\udfcd\udbef\udf48\ud85b\udd79\ud9ca\uddb3\ud87f\udd76\udb75\udddc\ud9b6\ude38\uda64\udd0c\ud855\uddc8\udab2\udc27\ud98d\udef1",
        58, 36174, -889732447, -4271581918280525510L, -51378L, false, true, (char) 19034, (char) 6401,
        Double.longBitsToDouble(0x3fe5960ee4e1246aL), Double.longBitsToDouble(0x3fd8caed6b970ad4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 15, 3, 14, "\udbc1\udee7\udaa5\udc7d\uda1e\udd60", "\u1319\u6a55\u63af\u8232\u449e\ua69e\u8bf2\u3b90\u6fba\u9e4e\uae07\u57fe", "\udb75\udddc\ud9b6\ude38\ud90f\udd43\ud9e1\udcbf\udba1\uddc0\ud98d\udee8\udb72\uddc2\udb0c\udcc8\udbaf\udf80\uda95\udf62\ud9f3\udda7\uda18\ude3a\udb53\udce1\ud830\ude8d\udbe2\ude70\ud90d\udc17\udbcb\ude13\ud8ac\ude26",
        -4, 33419, -1857923531, -5616951026918416767L, -30762L, true, true, (char) 61165, (char) 56141,
        Double.longBitsToDouble(0x3fbe633a0ad048b0L), Double.longBitsToDouble(0x3fe41fe635045d1cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 5, 8, "\udbc3\udc9f\udaa5\udc7d", "\u9667\uc0e7\u39b7\u70c2\u81f6\u449e\u40c2\u9489\u3b90\u7bc1\u776e\ub3eb\uc0b8\ub9ea\u2f39\ub1d6\u798a\u2730\u2c1e\u960a", "\uda47\udd0f\udbaf\udf80\uda95\udf62\uda68\udc81\uda85\udf7c\udb81\udc65\ud855\udf75\ud9b7\ude25\udbe2\udffa\udb7c\udcb6\ua8a6\ud8e7\udeac\uda14\uddf7\ud824\udcd2\ud907\ude48\uda1d\udde3\ud97a\udf1b\uda32\udd7a\ud96c\udc34\ud8b8\udec5\ud99c\udd6b\udaa1\udf96\udbf2\udd2e\ud879\uddb3\u3616\udbbe\udcb9\udbbc\udc0d\ud813\uddf6\ud8bb\udf8f\udb5e\udd31",
        19, 32240, 422784124, 2549449794811802692L, -21236L, false, false, (char) 17713, (char) 52747,
        Double.longBitsToDouble(0x3fe8820b0658f75fL), Double.longBitsToDouble(0x3fe2e9bf3b03aa4aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[944.5, 27910.0, 28355.5]]] |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 1, 2, 5, 8, "\u0791\uda3c\uddb7", "\u9667\uc0e7\u39b7\u70c2\u81f6\u449e\ubdca\u394a\u6ec4\u7bc1\u776e\ub3eb\uc0b8\ub9ea\u2f39\ub1d6\u798a\u43c9\u2b3d\u960a", "\uda47\udd0f\udbaf\udf80\uda95\udf62\uda68\udc81\uda85\udf7c\udb81\udc65\ud855\udf75\ud9b7\ude25\udbe2\udffa\udb7c\udcb6\ua8a6\ud8e7\udeac\uda14\uddf7\ud824\udcd2\ud907\ude48\uda1d\udde3\ud97a\udf1b\uda32\udd7a",
        40, 7901, 2057802289, 8963526936705145802L, 67074L, true, false, (char) 27587, (char) 35339,
        Double.longBitsToDouble(0x3fc98da73e41447cL), Double.longBitsToDouble(0x3fc7c9903e96b034L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[28105.5, 28232.5, 28001.5, 28313.5, 27895.0, 28306.5, 27851.0, 28141.5]]] |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 1, 2, 5, 8, "\udbc3\udcc1\udaf3\udd63\uda1e\udd55\ud9c6\udc0b\ud8a2\udee6", "\ua5d4\uc217\u449e\u40c2", "\uda86\udcca",
        8, 22796, -59779854, -4329717213032046932L, 62658L, false, false, (char) 23591, (char) 33406,
        Double.longBitsToDouble(0x3fe257f0f92f8358L), Double.longBitsToDouble(0x3fe222786aa1734eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[28105.5, 28215.5, 27962.5, 28213.5]]] |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 2, 2, 5, 8, "\udbc3\udc9f\udaa5\udc9b", "\u9667\uc0e7\u39b7\u70c2\u66f6\u3313\u40c2\u9489\u3b90\u7bc1\u776e\ub3eb\uc0b8\ub9ea\u2f39\ub1d6\u798a\u43c9\u2b3d\u51e4", "\uda47\udd0f\udbaf\udfa8\uda95\udf62\uda68\udc81\uda85\udf7c\udb81\udc65\ud959\uddc5\ud8e1\udd70\udbe2\udffa\udb7c\udcb6\ua8a6\ud8e7\udeac\uda14\uddf7\ud824\udcd2\ud907\ude48\uda1d\udde3\ud97a\udf1b\uda32\udd7a",
        40, 7901, 2057802289, 8963526936705145802L, 67074L, true, false, (char) 27587, (char) 35323,
        Double.longBitsToDouble(0x3fc98da73e416094L), Double.longBitsToDouble(0x3fbf1f6978a8c998L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 2, 9, 5, 8, "\udbc3\udd4a\udaa5\udc7d", "\u9667\uc0e7\u8717\u70c2\u90f6\u449e\u50dc\u9489\u3b90\u7bc1\u776e\ub3eb\uc0b8\ub9ea\u2f39\ub1d6\u798a\ub3be\u2b3d\u960a", "\uda44\udc0f\u93d0\udab8\udca8\uda68\udc81\uda85\udf7c\udb81\udc65\ud855\udf75\ud9b7\ude25\udbe2\udffa\udb7c\udcb6\ua8a6\ud8e7\udf21\uda14\uddf7\ud824\udcd2\ud907\ude48\uda1d\udde3\ud97a\udf1b\udb43\udfb3",
        26, 76026, 1126961009, 8963526936705145802L, 67074L, true, false, (char) 27587, (char) 14983,
        Double.longBitsToDouble(0x3fc98da73a41447cL), Double.longBitsToDouble(0x3fbf25b3b8a8c998L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 1, 4, 2, 8, "\uda5a\ude1b\uda0d\udf30", "\ud06d\ud425\u39b7\u98b8\ubda3\u5110\u7ec1\u9443\u3b90\u6a0c\u0a75\u8932\ub08f\u7606\u2f39\u66df", "\uda93\udc9e\uda6e\udfd0\ud8a3\udcd5\uda43\udd2f\udb0c\udcc8\ud8c4\udf6a\uda95\udf62\udb17\uddfa\uda3f\udf47\ud8a8\ude22\ud881\udd6b\ud99c\udfad\ud9e1\uddef\udb32\udfd0\ud85c\udc4b\ud9e9\udd7f\ub6f6\udb27\udf30\uda4b\ude03\ud839\udfc1\udb19\udce7\uda26\udfc8\udb2e\udf2c\uda71\udeb3\udbb1\udf75\udaf5\udd24\uda3d\ude5c\ud8e0\udf21\ud9a0\udcc0\udb8b\udf33\ud8e2\udd6c\uda6e\ude9f\udbad\udc69\udbf1\udde9\ud9b8\udeb0\ud8ef\udd20",
        1, 99290, -163948659, 6093415965186937436L, -9027L, false, true, (char) 46408, (char) 64935,
        Double.longBitsToDouble(0x3fe0d55e8b90ca1aL), Double.longBitsToDouble(0x3feef9ea4b426da3L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\0121=void |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 2, 7, 1, 11, "\udae4\udc2b\uda3f\udf1f\ud8ac\udc75", "\u68ea\u106e", "\ud860\udcd3\ud8bb\udf25\udb76\udc3d\ud8cd\udf8a\udab3\udf5b\ud83b\ude38\ud969\udf76\ud8af\udee3\ud87c\udf0d\ud900\udd9d\udb25\udcf6\udb11\udc03\ud809\udd29\ud8c5\uddda\udb6e\udc25\ud8bb\udf0c\udaa4\udf5f\udaca\udf11\ud83f\ude89\udb8d\udefe\uda4c\udce6\ud813\ude4a\udb53\udfac\uda19\udd10\ud867\udee8",
        46, 34458, 1071613193, 5303718398162053837L, -39609L, false, true, (char) 54270, (char) 30001,
        Double.longBitsToDouble(0x3fc342046f413b00L), Double.longBitsToDouble(0x3fdd0b38522449a8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 2, 5, 5, 8, "\ud872\udf8f\udb38\ude55\udacc\udf64", "\uc262\u39b7\u63af\ua16a\u449e\u590e\u7a1b\u3b90\u6fba\u0a75\u4fa8\u4936", "\udb75\udddc\ud9dd\udc44\ud905\udf75\ud855\uddc8\ud927\udfc7\udbc3\udeec\udb7c\udec2\uda23\udd92\ud8ea\udd79\udb67\ude8a\udabc\udf5d\ud828\ude6e\uda92\udcf0\udb34\udd65",
        2, 22967, -1578677093, 4924005882934917407L, 78309L, false, false, (char) 14980, (char) 41844,
        Double.longBitsToDouble(0x3fede3f4dd3cb881L), Double.longBitsToDouble(0x3fbe05157ce4dc78L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 15, 8, "\u01f6\udb38\ude55\uda1e\udd60", "\uc262\u1343\u698b\ua16a\u449e\u590e\u7a1b\u3b90\u09ba\uc7cc\u5c08\u0d1b", "\udb75\udddc",
        25, 92345, -633724926, 1849992375369006666L, 50241L, true, false, (char) 11315, (char) 38067,
        Double.longBitsToDouble(0x3fbc4930f8baa0d0L), Double.longBitsToDouble(0x3fed78314c9be851L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27639.0, 28236.5, 28005.5, 28236.5, 27685.0, 28328.0, 29372.5, 27672.5]]] |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\0121=void |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 2, 2, 3, 3, "\ud81e\udcc9\udafb\udcc9\ud87a\udd80\ue5a9\ud861\udea2\uda23\udf6c", "\u1841", "\ud95f\udc1e\udb08\uddb4\udba9\ude8a",
        46, 81307, -1504631927, -1313393703600862841L, -21218L, false, false, (char) 8726, (char) 55192,
        Double.longBitsToDouble(0x3fe4dac06b21d933L), Double.longBitsToDouble(0x3feda710ecd52406L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 5, 5, "\u1561", "\u8aac\u9667", "\ud804\udf2b\udae9\udc7c\u07dc\udbb5\ude4a",
        45, 68383, -806224714, -811135267317661902L, 47166L, false, false, (char) 7342, (char) 50673,
        Double.longBitsToDouble(0x3fc1f90e438faa60L), Double.longBitsToDouble(0x3fb1368eab6ff0f8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\udb23\udeff\ud888\ude65\ud91f\udec1\ud94d\udce2\udb12\udff8\ud820\ude15\udb2a\udeb2\ud819\udf96\ud9a2\udca2\ud932\udd73\ud844\udf7a\udb75\udf6b\ud83e\ude1c\udbfa\udec2\uda62\udef7", "\u7606\u2f39\u66df\uc040\u2e74\u3a6a\u119a\u4d25", "\ud808\udf4c\udb0b\udc2a\udb17\uddfa\uda3f\udf47\ud8ed\udc63\udb5e\uddfc\ud99c\udfad\udb9e\udc6c\uda86\uddbe\udb29\udf19\ud9e9\udd7f\ub6f6\udb27\udf30\uda4b\ude03\ud839\udfc1\udb19\udce7\udb4e\udcbb\ud923\uddb2\ud966\udcb2\udbb1\udf75\udaf5\udd24\uda3d\ude5c\ud8e0\udf21\ud9a0\udcc0\udb8b\udf33\ud8e2\udd6c\uda6e\ude9f\udbad\udc69\udbbb\udd03\ud9b8\udeb0\ud8ef\udd20\udb4f\udc6a\udb82\ude4c\uda2f\udef9\ud887\ude86\udba1\uddc1\ud9e9\udd68\ud9e0\udc2a\udb24\ude97\ud870\udfe0\ud86d\uddfe\udbdf\ude28\uda0e\udc9b\ud827\ude55\uda78\ude2f\udb2c\udee5\udaf2\ude93\uda5b\udfe9\ud9ad\ude87\udb6b\ude33\udb08\udc58\ud97c\udc5d\u2fc7\ud9bb\udd70\ud893\udc29\udae7\udff9\uda7d\udddf\ud8b0\ude44\udbc8\uddc4",
        21, 21242, 913137022, 4466048584961561449L, -98265L, true, false, (char) 20095, (char) 56458,
        Double.longBitsToDouble(0x3fdf79fd62499aa4L), Double.longBitsToDouble(0x3fea7a8120a3bf61L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 15, 8, "\udb98\udf41\ud9a1\ude55\udae5\ude23", "\ua01d\uaefe\u149d\u6070\ua45d\u240c\u7725\u5cb8", "\ud819\ude4e",
        27, 95855, -511038978, 5372738115396944494L, 39266L, false, false, (char) 6134, (char) 56635,
        Double.longBitsToDouble(0x3fe3f4106fc27824L), Double.longBitsToDouble(0x3fe708e8ea29a16bL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27709.5, 28172.0, 27989.0, 28564.0, 27935.0, 28448.5, 27803.5, 28641.0]]] |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\0121=void |a0=[[D:[[[27709.5, 28172.0, 27989.0, 28564.0, 27935.0, 28448.5, 27803.5, 28641.0]]] |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 2, 2, 2, 8, "\ud8ab\udc48\udada\udf58\uda6e\ude71\ud967\udff2\ud91f\udfad\ud910\udfc3\udb7f\udd24\udb40\udd2b\udb9d\udcb5\ud8ad\ude95\ud80a\udcb8\udaa9\udcd4\ud8e3\udecf", "\u5c08", "\uda3c\udee2\udb75\uddef\ud93d\udf54\ud831\udd27\udbb0\udd15\ud922\udc9f\udbc3\udeec\udbe7\udf97\udb22\udd92\uda2e\udfed\udbab\udef8",
        -3, 19822, 616820422, 6060196316433680151L, -14402L, false, false, (char) 21039, (char) 37260,
        Double.longBitsToDouble(0x3fe52e7062f6739dL), Double.longBitsToDouble(0x3fe2510151e6f179L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 2, 9, 9, 5, "\udb23\udeff\ud888\ude65\ud91f\udec1\udae5\udf2e\udb12\udffb\ud820\ude15\udb2a\udeb2\ud819\udf96\ud9a2\udca2\ud932\udd73\ud844\udf7a\udb75\udf6b\ud83e\ude1c\udbfa\udec2\uda62\udef7", "\u7606\u2f39\u1351\u41bb\u3c80\u3a6a\u119a\u4d25", "\ud808\udf4c\udb0b\udc2a\ud87e\udd9a\uda3f\udeef\ud8ed\udc63\udb5e\uddfc\ud99c\udfad\udb9e\udc6c\uda86\uddbe\udb29\udf19\ud9e9\udd7f\ub6f6\udb27\udf30\uda4b\ude03\ud839\udfc1\ud891\udc11\udb4d\udfcd\ud923\uddb2\ud966\udcb2\udbb1\udf75\udaf5\udd24\uda3d\ude5c\ud8e0\udf21\ud9a0\udcc0\udb8b\udf33\ud8e2\udd6c\uda6e\ude9f\udbad\udc69\udbbb\udd03\ud9b8\udeb0\ud8ef\udd20\udb4f\udc6a\udb82\ude4c\uda2f\udef9\ud887\ude86\udba1\uddc1\ud9e9\udd68\ud9e0\udc2a\udb24\ude97\ud870\udfe0\ud86d\uddfe\udbdf\ude28\uda0a\udc9b\ud827\ude55\uda78\ude2f\udb2c\udee5\udaf2\ude93\uda5b\udfe9\ud9ad\ude87\udb6b\ude33\udb08\udc58\ud97c\udc5d\u2fc7\ud9bb\udd70\ud893\udc29\udae7\udff9\uda7d\udddf\uda04\ude4e\udbc8\uddc4",
        21, 21242, 1440636286, 4466048314378621801L, -98265L, true, false, (char) 20095, (char) 56458,
        Double.longBitsToDouble(0x3fdf79fd62499aa4L), Double.longBitsToDouble(0x3fea7a8120a3bf61L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 2, 6, 6, 8, "\uda9a\udfd3", "\u525b\u3bb4\uc1b4\u1343\u3c8b\u7758\uccaf\u4cf9\u66d8\u91b4\u1af6\uc7cc", "\ud8cd\udd2f\uda3c\udee2\udb75\uddef\ud89a\udc66\ud9b7\udf7d",
        47, 71709, -2096300470, -3141443056280478082L, 97156L, true, true, (char) 27736, (char) 23707,
        Double.longBitsToDouble(0x3fc1b09ec85d5068L), Double.longBitsToDouble(0x3fde58c817ce57eaL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 1, 9, 5, 8, "\udbc1\udee7\uda4f\udd92\ud835\udd04", "\u9b98\u39b7\u63af\u81f6\u449e\u40c2", "\udb4b\udce2",
        2, 58030, 1356864803, -4329791859565617492L, 39266L, false, false, (char) 55363, (char) 46215,
        Double.longBitsToDouble(0x3fe3f4106aa19f24L), Double.longBitsToDouble(0x3fe70e57b93ac4b8L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 2, 12, 12, 6, "\ud884\udd51\udaaa\ude0c\uda1e\udd60\ud994\udf14\udb12\udf93\ud910\udfc3\udb2a\udeb2\udb44\udc1e\udae9\udc7c\uf9dc\udae4\udf9e\udb75\udfb1\ud8e3\udecf\udbc4\udc59\udac3\udeb6\udbd6\udf21", "\u2f39\ub1d6\u62ce", "\udab2\udc27\udad5\udef5\udb72\uddc2\uda01\udd80\ud91d\udf17\ud92a\udf4a\udb46\uddec\ud93b\udf73\ud8aa\udd41\udba5\udccd\ud808\udd76",
        36, 9532, -69113895, -786805803111528703L, 10764L, true, false, (char) 24408, (char) 30704,
        Double.longBitsToDouble(0x3fef6c9c73e1c90fL), Double.longBitsToDouble(0x3fdcef9b50e4e16aL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\0121=void |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 2, 1, 1, 8, "\uda03\udf16\udb38\ude55\uda1e\udd60", "\uc262\u1343\u2091\ua16a\u449e\u5657\u57a2\u2b45\u09ba\u1dba\u1fc3\u7f3d", "\udb75\udddc",
        25, 92345, -633724926, 1849992375369006666L, 90753L, false, true, (char) 26622, (char) 34899,
        Double.longBitsToDouble(0x3fede8a3b699a5edL), Double.longBitsToDouble(0x3fd0a24c3e2ea998L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\0121=void |this=org.apache.commons.math.stat.regression.SimpleRegression:@?\012",
        Z.run(T, 2, 1, 1, 8, "\ud9ad\udda3\udb38\ude55\uda1e\udd60\udb61\udf5a\udba1\udd25\ud910\udfc3\udb7f\udd24\ud9cb\udd26\ud935\udd01\udbad\ude71\udb3e\udd7c\udab0\udd9e\ud8df\ude84", "\u1fc3", "\ud87f\udcfb\udb75\udddc\ud9dd\udc44\ud905\udf75\ud855\uddc8\ud927\udfc7\udbc3\udeec\udb50\udefc\ud998\ude48\ud8ea\udd79",
        8, 36481, 1049154043, -2732338111921799134L, -42422L, true, false, (char) 13120, (char) 59962,
        Double.longBitsToDouble(0x3fcfc6e17cb53e7cL), Double.longBitsToDouble(0x3fe875cee2538001L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.stat.regression.SimpleRegression|getSumSquaredErrors||new:org.apache.commons.math.stat.regression.SimpleRegression:",
    "M|org.apache.commons.math.stat.regression.SimpleRegression|addData|double,double|new:org.apache.commons.math.stat.regression.SimpleRegression:",
    "M|org.apache.commons.math.stat.regression.SimpleRegression|addData|[[D|new:org.apache.commons.math.stat.regression.SimpleRegression:",
    "M|org.apache.commons.math.stat.regression.SimpleRegression|clear||new:org.apache.commons.math.stat.regression.SimpleRegression:",
    "M|org.apache.commons.math.stat.regression.SimpleRegression|getIntercept|double|new:org.apache.commons.math.stat.regression.SimpleRegression:",
    "M|org.apache.commons.math.stat.regression.SimpleRegression|getIntercept||new:org.apache.commons.math.stat.regression.SimpleRegression:",
    "M|org.apache.commons.math.stat.regression.SimpleRegression|getInterceptStdErr||new:org.apache.commons.math.stat.regression.SimpleRegression:",
    "M|org.apache.commons.math.stat.regression.SimpleRegression|getMeanSquareError||new:org.apache.commons.math.stat.regression.SimpleRegression:",
    "M|org.apache.commons.math.stat.regression.SimpleRegression|getN||new:org.apache.commons.math.stat.regression.SimpleRegression:",
    "M|org.apache.commons.math.stat.regression.SimpleRegression|getR||new:org.apache.commons.math.stat.regression.SimpleRegression:",
    "M|org.apache.commons.math.stat.regression.SimpleRegression|getRSquare||new:org.apache.commons.math.stat.regression.SimpleRegression:",
    "M|org.apache.commons.math.stat.regression.SimpleRegression|getRegressionSumSquares|double|new:org.apache.commons.math.stat.regression.SimpleRegression:",
    "M|org.apache.commons.math.stat.regression.SimpleRegression|getRegressionSumSquares||new:org.apache.commons.math.stat.regression.SimpleRegression:",
    "M|org.apache.commons.math.stat.regression.SimpleRegression|getSignificance||new:org.apache.commons.math.stat.regression.SimpleRegression:",
    "M|org.apache.commons.math.stat.regression.SimpleRegression|getSlope||new:org.apache.commons.math.stat.regression.SimpleRegression:",
    "M|org.apache.commons.math.stat.regression.SimpleRegression|getSlopeConfidenceInterval||new:org.apache.commons.math.stat.regression.SimpleRegression:",
    "M|org.apache.commons.math.stat.regression.SimpleRegression|getSumSquaredErrors||new:org.apache.commons.math.stat.regression.SimpleRegression:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
