package org.apache.commons.math.optimization.linear;
import org.junit.Test;
import static org.junit.Assert.*;
public class SimplexTableau_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 3, 5, "\udb7b\udc6b\ua416\ud8c1\udf63\u9a0c\uda97\udcd0\ud8cc\udf9e\u5392\ud828\udc43\uda9f\uded0\ud9f6\ude35\udb24\udd3b\udac6\udcdc\ud870\udc10", "\ubc27\u70f9\u4305\ua463\u5ad2\u1dfe\u4bdf\u6518", "\ud93a\udeb7\ud836\uddaf\ud8ed\udc78\udbac\udc06\ud931\udece\ud963\udc45\udb4d\udf3c\ud9ae\udeb1\ud825\udfbe",
        45, 35610, -1636544865, -5645920634635611387L, -35426L, false, true, (char) 2895, (char) 39974,
        Double.longBitsToDouble(0x3fd53106bf57c600L), Double.longBitsToDouble(0x3fe61f2e4d0fd77aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 10, "\udb7b\udc6b\ua416\ud8c1\udf63\u9a0c\uda97\udcd0\udb6c\udccd\000\ud827\udf95\uda9f\uded0\ud9f6\ude35\udb24\udd3b\udac6\udcdc\u237e", "\000\u70f9\u980e\000\000\000\u3318", "\uda6c\udc71\ud93a\udeb7\ud836\uddaf\u90d5\udbac\udc06\ud931\udece\ud963\udc45",
        10, -1000, -1240959974, 2777139384643257010L, 53319L, true, true, (char) 36163, (char) 31318,
        Double.longBitsToDouble(0x3f77b8ec1f258280L), Double.longBitsToDouble(0x3fc48f4000000000L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 11, 14, "\udb60\udedf\ua480\ud8c1\udf63\u9a0c\udae4\udd34\ud81b\udc41\udbc4\ude2e\ud828\udc43\ud9a2\udf92\ud939\udc68\ud80b\udd35\udb34\udf52\uda62\ude38", "\ubc27\u70f9\u4305\ua7ac\u401b\u3c32\u5331\u6518", "\ud93a\udeb7\ud836\uddaf\ud8ed\udc78\udaeb\udc5f\udae6\udfc8\ud899\udf61\ud8c8\udf99\ud98d\udd1b\udb74\udc45",
        36, 98495, -1636544986, -5645920634635611387L, -76701L, true, true, (char) 26930, (char) 24182,
        Double.longBitsToDouble(0x3fe61b5f850fd77aL), Double.longBitsToDouble(0x3fd687762b735036L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 3, 5, "\udb7b\udc6b\ua416\ud8c1\udf63\u9a0c\uda97\udcd0\ud8cc\udf9e\u5392\ud828\udc43\uda9f\uded0\ud9f6\ude35\udb24\udd3b\uda82\udf39\ud9c8\udef0", "\ubc27\u5db6\ub43d\u9546\u5b0b\u1dfe\u4bdf\u825c", "\ud93a\udeb7\ud836\uddaf\ud8ed\udc78\udbac\udc06\ud931\udece\ud997\udf7e\udb4d\ude7f\ud9ae\udeb1\ud825\udfbe",
        45, 25458, 404909575, -5645920157894241531L, -35426L, false, true, (char) 2895, (char) 39974,
        Double.longBitsToDouble(0x3fd53106bf57c600L), Double.longBitsToDouble(0x3fe61f2e4d0fd77aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 6, 17, "\udb40\udccf\ua49c\ud8c1\udf63\u9a0c\uda97\udcd0\ud8cc\udf9e\u5392\ud828\udc43\uda31\udd59\uda8e\udd95\udb24\udd3b\udac6\udcdc\ud870\udc10", "\ubc27\u1e95\uc578\u6298\u162e\u0491\u4c09\u6518", "\ud93a\udeb7\ud836\uddaf\ucf57\ud8d1\udea3\ud931\ude7e\ud963\udc45\udb4d\udf3c\ud9ae\udeb1\ud825\udfbe",
        45, 35610, -1639357793, -5645920634862497019L, -35426L, false, true, (char) 2895, (char) 39974,
        Double.longBitsToDouble(0x3fd53106bf57c600L), Double.longBitsToDouble(0x3fe61f2e4d0fd77aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 1, 5, "\udb7b\udc6b\ua416\ud8c1\udf63\u9a0c\ud8b5\uddf5\ud87a\ude6c\udbb7\udccb\ud828\udc43\uda9f\uded0\u55a5\udb3d\udd0e\udac6\udcdc\ud870\udc10", "\ubc27\u7159\u4305\ua463\u8f8d\u9ead\u4bdf\u6518", "\ud93a\udeb7\ud836\uddaf\ud8ed\udc78\udbac\udc06\ud931\udece\ud93c\uddb1\udb4d\ude7d\ud9ae\udeb1\ud825\udfbe",
        59, 35610, -1636544865, -5645920634635611387L, -35426L, false, true, (char) 2895, (char) 39974,
        Double.longBitsToDouble(0x3fd53106bf57c600L), Double.longBitsToDouble(0x3fe61f2e4d0fd77aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 17, 15, "\ud807\udf84\ua437\ud8f9\udc1f\ud8ae\udccf\ud8e8\udfea\ud83a\ude0f\u5392", "\ub2a5\u6189\u6955\u876b", "\ud9d4\ude7e",
        11, 14772, -125588157, -8432474066201147931L, 57424L, true, false, (char) 63418, (char) 17019,
        Double.longBitsToDouble(0x3fcdbd7595343374L), Double.longBitsToDouble(0x3fe71b0eecc018bdL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 3, 5, "\udb7b\udc6b\ua416\ud8c1\udf63\u9a0c\uda97\udcd0\ud8cc\udf9e\ud9a4\udeb8\ud808\udcda\uda9f\uded0\ud9f6\ude35\ud9bd\ude88\udb46\udea2\ud867\udfea", "\ubc27\u70f9\u4305\ua463\u5ad2\u1dfe\u4bdf\u6518", "\ud93a\udeb7\ud836\uddaf\ud8ed\udc78\udbac\udc06\udb65\udf28\ud963\udc45\udb4d\udf3c\ud9ae\udeb1\ud825\udfbe",
        45, 35610, -1636544865, -5645920634966622971L, 89476L, true, false, (char) 18243, (char) 14912,
        Double.longBitsToDouble(0x3fefec9ec5d31e53L), Double.longBitsToDouble(0x3fd53846bd57c600L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 3, 10, "\ud90f\udff7\udaa7\udd29\ud8d2\udc41\uba51\uda97\udcd0\udb6c\udccd\ud8e8\udd06\ud827\udf95\uda9f\uded0\ud9f6\ude35\udb24\udd3b\udac6\udcdc\u237e", "\000\u70f9\u980e\000\000\000\u3318", "\uda6c\udc71\ud93a\udeb7\ud836\uddaf\u90d5\udbac\udc06\ud931\udece\ud963\udc45",
        37, 51085, -1233591142, 2777139384643257010L, 53319L, true, true, (char) 36163, (char) 6197,
        Double.longBitsToDouble(0x3f77b8ec1f258280L), Double.longBitsToDouble(0x3fc48f4000000000L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 3, 5, "\udb7b\udc6b\ua416\ud8c1\udf63\u9a0c\uda97\udcd0\ud8cc\udf9e\u5392\ud828\udc43\uda9f\uded0\ud9f6\ude35\udb24\udd3b\udac6\udcdc\ud870\udc10", "\ubc27\u70f9\u4305\ua463\u5ad2\u1dfe\u4bdf\u6518", "\ud93a\udeb7\ud836\uddaf\ud8ed\udc78\udbac\udc06\ud931\udece\ud963\udc45\udb4d\udf3c\ud9ae\udeb1\ud825\udfbe",
        45, 35610, -1636544865, -5645920633663513339L, 57920L, true, false, (char) 18243, (char) 10304,
        Double.longBitsToDouble(0x3fefec9a8dd31e53L), Double.longBitsToDouble(0x3fd53106bf57c600L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getBasicRow|int|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getBasicRow|int,boolean|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getSolution||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|copyArray|[D,[D,int|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|createTableau|boolean|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|discardArtificialVariables||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|divideRow|int,double|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|equals|java.lang.Object|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getArtificialVariableOffset||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getBasicRowForSolution|int|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getConstraintTypeCounts|org.apache.commons.math.optimization.linear.Relationship|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getData||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getEntry|int,int|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getHeight||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getInvertedCoeffiecientSum|org.apache.commons.math.linear.RealVector|static",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getNegativeDecisionVariableOffset||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getBasicRow|int|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getBasicRow|int,boolean|new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
    "M|org.apache.commons.math.optimization.linear.SimplexTableau|getSolution||new:org.apache.commons.math.optimization.linear.SimplexTableau:org.apache.commons.math.optimization.linear.LinearObjectiveFunction,java.util.Collection,org.apache.commons.math.optimization.GoalType,boolean,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
