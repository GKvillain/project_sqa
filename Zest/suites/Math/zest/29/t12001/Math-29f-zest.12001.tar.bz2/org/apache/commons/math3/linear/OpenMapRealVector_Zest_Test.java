package org.apache.commons.math3.linear;
import org.junit.Test;
import static org.junit.Assert.*;
public class OpenMapRealVector_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=org.apache.commons.math3.linear.OpenMapRealVector:@? |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 10, 4, 6, "\uda07\uddcc\ud88b\udc3f\ud899\ude01\ud963\udd83\udb02\udfb5", "\u81fa\u386e\u9842\u6e8b", "\u08e4\ud8b6\udd00\u3f3e\uda4d\udf96\ud948\udf5a\udb10\ude9d\ud8e7\ude52\ud9f0\udda8\udbca\udd03\ud849\udd60\ud9bf\udf0a\ud9d2\udce2\ud99a\udec3\ud861\udcfe\ud88b\udcb7",
        36, 42749, -2040727089, 6333408084468245451L, 2795L, false, true, (char) 46389, (char) 9709,
        Double.longBitsToDouble(0x3fc847a48c7f9060L), Double.longBitsToDouble(0x3fe3918cdb763702L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=org.apache.commons.math3.linear.OpenMapRealVector:@? |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 10, 4, 6, "\uda07\uddcc\ud88b\udc3f\ud899\ude01\ud92a\udd4d\udb02\udfb5", "\u81fa\u386e\u803b\u6e8b\u170d\ud5ad\uaf82\u0d05\u3295", "\udb10\ude9d\ud8e7\ude52\ud9f0\udda8\udbca\udd03\ud849\udd60\uda91\udf13\ud9d2\udce2\ud99a\udec3\ud96a\ude44\u2024\ud82d\udcb3\uda33\udc98\udba6\udea3\u3e47\udbe2\udd37\uda44\udf63\ud9ef\udfef\ud979\udfbd\ud926\udc00\ud9b1\udf3e\u7f1d\ud989\ude0b\udbb8\uddaf\ud941\udde6\ud9eb\udecd\ud8a9\udf9c",
        22, 65590, -1246034734, 8375109311655512135L, -39675L, true, true, (char) 34684, (char) 23193,
        Double.longBitsToDouble(0x3fe77e75a6d79e57L), Double.longBitsToDouble(0x3fab18f8c822d9f0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 6, "\ud90a\udd8e\ud88a\udff1\ud899\ude01\ud963\udd83\udb02\udfb5", "\u81fa\u386e\u9842\u6e8b", "\udaab\udc2e\ud9ff\ude3c\ud879\udfaf\ud9c8\udc8f\udade\ude2b\udb10\ude9d\ud8e7\ude52\ud9f0\udda8\udbca\udd03\udb3e\udcdb\uda37\udfbb\ud93e\udd01\udb9f\udcf1\ud861\udcfe\ud88b\udcb7",
        36, 42749, -2040727089, 6333408084468245451L, 91343L, false, true, (char) 58978, (char) 40759,
        Double.longBitsToDouble(0x3fe3918cdb763702L), Double.longBitsToDouble(0x3fc4e07341002168L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 13, 6, "\uda07\ude25\ud80c\ude20\udb57\udee4\ud963\udd83\uda41\udf40", "\ua4f0\u99c9\u9842\ud282", "\udbe0\udf71\udbf7\ude86\ud81b\ude75\ud989\udcae\udb72\udefa\udb10\ude6b\ud8e7\ude52\ud9bd\udfa8\ud882\udcff\ud849\udd60\ud9d8\udd77\ud996\udd16\ud9e1\udf67\uda32\udddd\ud88b\udcb7",
        36, 42749, -2040727089, 5871495553058153818L, 2795L, false, true, (char) 14938, (char) 37760,
        Double.longBitsToDouble(0x3fc847a48c7f9060L), Double.longBitsToDouble(0x3fbc8c66dbb5a928L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.OpenMapRealVector:@? |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 6, "\uda07\uddcc\ud88b\udc3f\ud899\ude01\ud963\udd83\udb02\udfb5", "\u81fa\u386e\u38ba\u1893", "\u08e4\ud8b6\udd00\u3f3e\uda4d\udf96\ud948\udf5a\udb2e\udf91\ud8e7\ude52\udbfd\udf6e\udbca\udd03\ud849\udd60\ud9bf\udf0a\ud9d2\udce2\ud99a\udec3\ud861\udcfe\uda7a\udf8f",
        33, 8608, -2040769068, -1160581696533501772L, 2795L, false, true, (char) 46389, (char) 9709,
        Double.longBitsToDouble(0x3fc847a48c7f9060L), Double.longBitsToDouble(0x3fe3918cdb763702L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.OpenMapRealVector:@? |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 6, "\udad5\uddb3\ud88b\udc3f\ud899\ude01\ud963\udd83\udb02\udfb5\udb0b\udcaf\u8763\udbbf\ude53\u64e3\uda58\udf9d\uda05\ude8a\ud8cf\udff6\uf531\u08e4\ud8b6\udd00\u3f3e\ud913\udd97\ud948\udfcb\udb10\ude9d", "\u40b8\uc463\uc2bb", "\ud836\udd05\ud9c6\udfd4\ud2d4",
        -5, 66791, 418855665, -3070661303021152835L, -43332L, true, false, (char) 9709, (char) 58751,
        Double.longBitsToDouble(0x3fe8ff20c372319bL), Double.longBitsToDouble(0x3febb1b811975b60L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 8, 6, "\udbb5\udfcc\ud88b\udc61\ud899\ude01\ud963\udd83\udb02\udfb5", "\u92cb\u671c\u8ff6\u70ee\u6bec\u0e75\uaf2d\u0d05", "\ud948\udf5a\udb10\ude9d\ud8e7\ude52\udb8c\udca4\ud9af\udfb6\ud9fc\udd0f\ud9bf\ude88\ud9d2\udce2\ud99a\udec3\ud861\udcfe\ud88b\udcb7\udbba\ude37\uda86\udc13\udb93\udd34\u3e47\u56eb",
        53, 60339, 668358406, 4199895799337118628L, -82367L, false, false, (char) 45688, (char) 1804,
        Double.longBitsToDouble(0x3fe7d3f040924580L), Double.longBitsToDouble(0x3fe52e17e99cfdd7L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 4, 10, "\uda07\uddcc\ud918\udce6\uc0fa\ud979\udfd8\uda08\udc54", "\u81fa\u386e\u9842\u414b", "\u08e4\ud9f0\udcbc\u3173\uda4d\udf96\ud948\udf5a\udb10\ude9d\ud8e7\uded1\ud9f0\udda8\udaf4\udf92\udb36\udd67\ud9bf\ude66\ud9d2\udce2\ud99a\udec3",
        27, 65754, 8032094, -2077728257257702990L, -25301L, true, true, (char) 61804, (char) 18901,
        Double.longBitsToDouble(0x3fc234148e90e924L), Double.longBitsToDouble(0x3fe019e9231fe418L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 6, "\uda07\uddcc\ud88b\udc3f\ud899\ude01\ud832\udc9b\ud8cb\udce2", "\u11fb\ubcef\u7b37\u6e8b\u170d", "\ud8b6\udd00\u3f3e\uda4d\udf96\ud999\udd62\ud81b\udf9c\ud8e7\ude52\ud9f0\udda8\udbca\udd03\ud849\udd60\ud9bf\udf0a\udac7\ude4c\udaae\ude6c\ud861\udcfe\ud88b\udcb7\udbd7\udf37",
        44, 77911, 1474611481, -3147695308161231427L, -43332L, false, false, (char) 29437, (char) 58896,
        Double.longBitsToDouble(0x3fe8ff20c58f319bL), Double.longBitsToDouble(0x3febb1b8171681d1L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 9, 6, "\udb4d\udcbf\uda77\ude22", "\u79c6\u9ae8\u8866\u81fa\u386e\ub9c4\u4100\u170d\ud5ad\uaf82\u0d05", "\udbcb\udc9a\udb5c\udc6b\ud8e7\ude52\ud9f0\udda8\udbca\udd03\ud849\udd60\udab2\udca4\uda6c\udf34",
        45, 27847, -145474246, -188430600707084979L, -23645L, true, true, (char) 1382, (char) 26664,
        Double.longBitsToDouble(0x3fef509418c26094L), Double.longBitsToDouble(0x3fe8ff20c1517579L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 8, 6, "\uda07\uddcc\ud9bd\udc9f\uda8e\udec6\ud98e\udc9c\udb02\udfb5", "\u41e4\ub8b9\u5fcd\u72ec", "\u0887\udb40\udd02\ud98b\ude3b\uda4d\udecd\udb1e\udfa5\udb93\udd1b\uda47\udcd8\uda4f\udf6b\ud969\udd30\udb02\udd33\ud8bc\udd88\ud8b0\ude41\ud8e1\udce3\ud861\udd1e\ud88b\udcb7\ud883\ude2c\uda69\udddf\udb93\udfe9\u3e47\udbe2\udd37",
        32, 19388, -1599860710, 4199910741528341412L, -82507L, false, false, (char) 45688, (char) 63406,
        Double.longBitsToDouble(0x3fe8e8f300c47712L), Double.longBitsToDouble(0x3fe91855f94aafe5L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 12, 16, "\uda07\uddcc\ud88b\udc3f\ud899\ude01\ud963\udd83\udb02\udfb5\udb0b\udcaf\u8763\udbbf\ude53\u64e3\ud959\udcfc\uda05\ude8a\ud8cf\udff6\uf531", "\u3295", "\udb10\ude9d\ud8e7\ude52\ud9f0\udda8\udbca\udd03\ud849\udd60\ud9bf\udf0a\ud9d2\udce2\ud99a\udec3\ud861\udcfe\ud88b\udcb7\udbd1\udeb3\uda37\udee7\udba6\udea3\u3e47\udbe2\udd37\uda44\udf63\ud9fd\udeef\ud979\udfbd\ud926\udc00\ud9b1\udf3e\u7f1d\ud989\ude0b\udbb8\uddaf\uda2f\uddfe\udbfb\udd24\udb02\udcf7",
        25, 85344, -976316478, -6537593501488476646L, -54112L, false, true, (char) 11352, (char) 42988,
        Double.longBitsToDouble(0x3feeb676b393e2acL), Double.longBitsToDouble(0x3fd1a078c4473d32L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.OutOfRangeException\012",
        Z.run(T, 2, 15, 15, 6, "\uda07\uddcc\ud88b\udc3f\ud9a7\udea8\ud8a8\udcc3\udb1f\udd9f", "\u81fa\u0e5c\u9842\u6e8b", "\u08e4\ud8b6\udd00\u3f3e\uda4d\udf96",
        55, 71029, -1800329147, -8722825026335326102L, 10826L, false, true, (char) 42050, (char) 34493,
        Double.longBitsToDouble(0x3fd3aedceebdeea8L), Double.longBitsToDouble(0x3fd4dfd7a39fe814L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.OpenMapRealVector:@? |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=org.apache.commons.math3.linear.OpenMapRealVector:@? |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 7, 4, 6, "\uda07\uddcc\udadc\udc88\uda96\udce0\ud9a6\ude1f\udb02\udfb5", "\u81fa\u386e\u9842\u6e8b", "\u08e4\ud8b6\udd00\u3f3e\uda4d\udf96\ud948\udf5a\udb10\ude9d\ud8e7\ude52\ud92b\uddd2\uda87\udfa6\ud802\udcbc\udb5e\udd5a\ud85f\udf5e\uda6b\ude0b\ud861\udd5c\ud88b\udcb7",
        36, 42749, -2040727089, 6333408084468245451L, 2795L, false, false, (char) 46418, (char) 9709,
        Double.longBitsToDouble(0x3fc847a48c7f9060L), Double.longBitsToDouble(0x3fe3918cdb763702L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 6, 6, "\uda07\uddcc\ud88b\udc3f\ud899\ude01\ud963\udd83\udb02\udfb5", "\u81fa\u386e\u9842\u6e8b", "\ud8bd\udf01\udb4d\udf31\u3f9c\uda4d\udf96\ud948\udf5a\udb10\ude9d\ud8e7\ude52\ud9f0\udda8\udbca\udd03\ud849\udd60\ud9bf\udf0a\ud9d2\udce2\ud99a\udec3\ud861\udcfe\ud88b\udcb7",
        36, 42749, -2040727089, 6333408084468245451L, 20971L, true, false, (char) 39747, (char) 9709,
        Double.longBitsToDouble(0x3fc847a48c7f9060L), Double.longBitsToDouble(0x3fe3918cdb763702L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=java.lang.Boolean:false |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 10, 10, 11, "\uda07\uddd7\ud802\udc93\udb90\udc70\ud963\udd83\ud87e\udeaf\udb0b\udcaf\u8763\udbbf\ude53\ud9d1\udf3e\uda58\udf1f\uda05\ude8a\ud8cf\udff6\uf531\u08e4\ud8b6\udd00\u3f3e\uda4d\udf96\ud948\udf5a\ud81b\ude60", "\ua1e8\u9c8f\u90a8\ub292\u8cd6\u9ad6\u928f\u5d6b", "\ud9d2\udc1b\uda84\ude69\ud9af\udf79\ud940\udc24\ua85c\ud880\udd12\udb4c\udf75",
        33, 48567, 922938994, 2515677612080514626L, -66316L, true, false, (char) 13323, (char) 21189,
        Double.longBitsToDouble(0x3fea436c10c0b831L), Double.longBitsToDouble(0x3fea8cd864698b0cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.OpenMapRealVector:@? |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=org.apache.commons.math3.linear.OpenMapRealVector:@? |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 4, 4, 6, "\udab6\udd24\ud98e\udfd2\ud899\udef7\ud963\udd83\udb02\udfb5", "\u81fa\u386e\u9842\ub728", "\u08e6\ud8b6\udd00\u3f3e\uda4d\udf96\udb81\udf9d\udbec\udf9a\ud959\uddda\ud9bc\udea8\ud8da\udc20\ua348\ud9bf\udf0a\ud9d2\udce2\ud99a\udec3\ud88a\udf11\udae2\ude20\udaed\udd18\ud891\udec8\udba6\uddfd\udaba\ude7d",
        57, 96590, -181278497, -6871123743275936623L, -11989L, true, true, (char) 20461, (char) 13812,
        Double.longBitsToDouble(0x3fefe681ddee100bL), Double.longBitsToDouble(0x3fecbbc529ca2ba4L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=!org.apache.commons.math3.exception.OutOfRangeException\012",
        Z.run(T, 2, 11, 15, 6, "\uda07\uddcc\ud88b\udc3f\ud899\ude01\ud963\udd83\udb02\udfb5", "\u81fa\u386e\u9842\u6e8b", "\u08e4\ud994\udece\u3f3e\uda4d\udf96\ud8bf\ude95\ud860\udc05\ud8e7\ude52\ud9f0\udda8\udbca\udd03\ud849\udd60\ud9bf\udf0a\ud9d2\udce2\ud99a\udec3\ud861\udcfe\ud88b\udcb7",
        36, 42749, -2040727089, 6333408084468245451L, -31253L, false, true, (char) 44597, (char) 58881,
        Double.longBitsToDouble(0x3fd4faae437e4404L), Double.longBitsToDouble(0x3fe3918cdb763702L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=java.lang.Boolean:false |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 10, 10, 9, "\uda07\uddcc\ud88b\udc3f\ud899\ude01\ud92a\udd4d\udb02\udfb5", "\u81fa\u386e\u803b\u6e8b\u170d\ud5ad\uaf82\u0d05\u3295", "\udb10\ude9d\ud8e7\ude52\ud9f0\udda8\udbca\udd03\ud849\udd60\uda91\udf13\ud9d2\udce2\ud99a\udec3\ud96a\ude44\u2024\ud82d\udcb3\uda33\udc98\udba6\udea3\u3e47\udbe2\udd37\uda44\udf63\ud9ef\udfef\ud979\udfbd\ud926\udc00\ud9b1\udf3e\u7f1d\ud989\ude0b\udbb8\uddaf\ud941\udde6\ud9eb\udecd\ud8a9\udf9c",
        22, 65590, -1246034734, 8375109311655512135L, -39675L, true, true, (char) 34684, (char) 23193,
        Double.longBitsToDouble(0x3fe77e75a6d79e57L), Double.longBitsToDouble(0x3fab18f8c822d9f0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.OpenMapRealVector:@? |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=org.apache.commons.math3.linear.OpenMapRealVector:@? |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 4, 4, 6, "\uda07\uddcc\udb3d\udeb8\udb12\udee5\ud92a\udd79\udb02\udfb5", "\u81fa\u386e\u803b\u6e8b\u170d\ud5ad\uaf82\u0d05\u3295", "\udb10\ude9d\ud8e7\ude52\ud9f0\udda8\udbca\udd03\uda25\udd8e\uda91\udf13\ud9d2\udce2\ud99a\udec3\ud96a\ude44\u2024\ud82d\udcb3\uda33\udc98\udba6\udea3\u3e47\udbe2\udd37\uda44\udf63\ud9ef\udfef\ud979\udfbd\ud926\udc00\ud9b1\udf3e\u7f1d\ud989\ude0b\udbb8\uddaf\ud941\udde6\ud8cc\uded6\ud8a9\udf9c",
        22, 65590, -1246034734, 8375109311655512135L, -39675L, true, true, (char) 34684, (char) 23193,
        Double.longBitsToDouble(0x3fe77e75a6d79e57L), Double.longBitsToDouble(0x3fab18f8c822d9f0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=!org.apache.commons.math3.exception.OutOfRangeException\012",
        Z.run(T, 2, 10, 15, 5, "\uda07\uddcc", "\u54eb\u1ea2\uc862\u6e07\u81fa\u43b0\u689c", "\uf531\u08e4\ud8b6\udd00\u3f3e",
        -2, 31480, -2098707971, 7399739939879575693L, 10249L, false, false, (char) 58863, (char) 23232,
        Double.longBitsToDouble(0x3fb5fa6eaa6dc130L), Double.longBitsToDouble(0x3fdcff40a2330cb8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=org.apache.commons.math3.linear.OpenMapRealVector:@? |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 10, 4, 0, "\uda07\uddcc\ud88b\udc3f\ud899\ude01\ud8f5\udcda\u4f5f", "\u81fa", "\udacb\udd4d\ud9cb\udff4\uf531\u08e4\ud8b6\udd00\u3f3e\uda4d\udf96\ud948\udf5a\udb10\ude9d\ud8e7\ude52\ud9f0\udda8\udbca\udd03\ud87f\udd5b\uda91\udf13\ud994\udfe2\uda4d\udc3c",
        40, 54060, 2622686, -2046820352L, -25301L, true, true, (char) 61804, (char) 27861,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc840000c7f9060L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.OpenMapRealVector:@? |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=org.apache.commons.math3.linear.OpenMapRealVector:@? |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 7, 7, 4, "\ud9d5\ude85", "\u8b2e\u1ea2\u9a88\u791e9\u7506\u38ba", "\ud8c9\udcad\u08e4\ud8b6\udd00\u3f3e\uda4d\udf96",
        55, 89237, 1722886213, 8415785748336596601L, -37483L, true, false, (char) 44166, (char) 27222,
        Double.longBitsToDouble(0x3fedc6d59dd42d4eL), Double.longBitsToDouble(0x3fd19865c8bd87c8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.OpenMapRealVector:@? |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=org.apache.commons.math3.linear.OpenMapRealVector:@? |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 4, 4, 0, "\uda07\uddcc\ud88b\udc3f\ud899\ude01\ud8f5\udcda\u4f5f", "\u81fa", "\udacb\udd4d\ud9cb\udff4\uf531\u08e4\ud8b6\udd00\u3f3e\uda4d\udf96\ud948\udf5a\udb10\ude9d\ud8e7\ude52\ud9f0\udda8\udbca\udd03\ud87f\udd5b\uda91\udf13\ud994\udfe2\uda4d\udc3c",
        40, 54060, 2622686, -2046820352L, -25301L, true, true, (char) 61804, (char) 27861,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc840000c7f9060L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\0121=org.apache.commons.math3.linear.OpenMapRealVector:@? |this=org.apache.commons.math3.linear.OpenMapRealVector:@?\012",
        Z.run(T, 2, 10, 4, 6, "\uda07\uddcc\ud9ea\udc4f\ud899\udeea\ud963\udd83\udb02\udfb5", "\u81fa\u386e\u9842\u6e8b", "\u08e4\ud8b6\udd00\u3f3e\uda4d\udf96\ud948\udf5a\udb10\ude9d\ud8e7\ude52\ud9f0\udda8",
        3, 48255, 2069283289, -2491909819045186531L, -84326L, false, true, (char) 27414, (char) 60889,
        Double.longBitsToDouble(0x3fd19865c796afc8L), Double.longBitsToDouble(0x3fdbdd451316bff6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.linear.OpenMapRealVector|ebeDivide|org.apache.commons.math3.linear.RealVector|new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|ebeMultiply|org.apache.commons.math3.linear.RealVector|new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|add|org.apache.commons.math3.linear.OpenMapRealVector|new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|add|org.apache.commons.math3.linear.RealVector|new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|append|double|new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|append|org.apache.commons.math3.linear.OpenMapRealVector|new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|append|org.apache.commons.math3.linear.RealVector|new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|copy||new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|dotProduct|org.apache.commons.math3.linear.OpenMapRealVector|new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|dotProduct|org.apache.commons.math3.linear.RealVector|new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|equals|java.lang.Object|new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|getDimension||new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|getDistance|org.apache.commons.math3.linear.OpenMapRealVector|new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|getDistance|org.apache.commons.math3.linear.RealVector|new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|getEntries||new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|getEntry|int|new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|ebeDivide|org.apache.commons.math3.linear.RealVector|new:org.apache.commons.math3.linear.OpenMapRealVector:",
    "M|org.apache.commons.math3.linear.OpenMapRealVector|ebeMultiply|org.apache.commons.math3.linear.RealVector|new:org.apache.commons.math3.linear.OpenMapRealVector:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
