package org.apache.commons.math.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class MathUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Long:7763871041959074322\012",
        Z.run(T, 2, 14, 5, 9, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u5f29\u0ece\uaa8e\u8c1e\ud0e9\u495c\ud020\u1ebc\u310c\ucd33", "\ud8e3\udf78",
        12, 11419, -964280849, 7763871041959170864L, -96542L, true, false, (char) 43302, (char) 23978,
        Double.longBitsToDouble(0x3fe81ba12a146241L), Double.longBitsToDouble(0x3fdf5fba92dbd96eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Long:7763871041959074322\012",
        Z.run(T, 2, 14, 5, 9, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud99d\udf4e\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u5f29\u40f6\u4a62\u8c1e\ud0e9\u495c\ud020\u1ebc\u310c\ucd33", "\ud8e3\udf78",
        12, 11419, -964280849, 7763871041959170864L, -96542L, true, false, (char) 43302, (char) 23978,
        Double.longBitsToDouble(0x3fe81ba12a146241L), Double.longBitsToDouble(0x3fdf5fba92dbd96eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Long:-820947125170565497\012",
        Z.run(T, 2, 14, 3, 17, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d", "\u0440\u5c06", "\ud86f\udcdf\uda24\ude0b\ud8c7\udcc0\ud9f1\ude2c\udafa\udcac\ud8ad\udecb\ud807\udc60\ud870\udfaa\ud8d2\udcb9\uda9e\udd81",
        26, 82229, -961657928, -820947125170488389L, -77108L, true, true, (char) 11475, (char) 37493,
        Double.longBitsToDouble(0x3feb3eb95d383813L), Double.longBitsToDouble(0x3f71f5cec12e7800L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:-857823711 |a0=[D:[[27998.5, 28264.0, 27664.5, 28283.5, 27899.5, 28469.0, 28101.0, 28163.5]]\0121=java.lang.Long:6696989004000987938\012",
        Z.run(T, 2, 14, 5, 15, "\udaed\udd00\ud851\udd27\uda27\ude9a\udbba\udc37\ud9ea\ude81\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\uac2d\u916b\ua550\ud754\u8b44\u495c\ud020\u1ebc\u310c\u1c35", "\ud8e3\udf78\ud844\udc44\ud8fe\ude61\udb51\udc31\ud9e9\udded\uda1c\ude5b\udb76\uddd9",
        16, 46424, 2111630375, 6696989004000923010L, 64928L, false, false, (char) 50984, (char) 33877,
        Double.longBitsToDouble(0x3fdf5fba92dbd96eL), Double.longBitsToDouble(0x3fefebb399fa264cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27733.0, 28627.5, 27909.5, 28534.5, 27899.5, 28377.5, 28101.0, 28163.5]] |a1=[D:[[24231.5, 18198.0]]\0121=java.lang.Double:8.065817517094494E67\012",
        Z.run(T, 2, 8, 10, 2, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1", "\ubd7f\u8e5c", "\uc5e5\udb5f\udc53\uda11\udffb\udae5\udffe\ud8ad\udd52\ud870\udfaa\ud8d2\udcb9\udbef\udf29\udb3d\udc0f\ud9f4\ude86\ud825\udf73\ud843\udf9a\uda7c\udf36\udbaa\ude14\ud9e9\udded\uda1c\ude5b\udb76\uddd9\udbf6\ude23",
        52, 96032, 1559264260, 6353468026928988837L, 26680L, true, true, (char) 33877, (char) 11679,
        Double.longBitsToDouble(0x3fd6decb7fa97f8cL), Double.longBitsToDouble(0x3fe0db5cd0f3521dL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:459611937 |a0=[D:[[27797.0, 28258.5]]\0121=java.lang.Long:-2942226542994735925\012",
        Z.run(T, 2, 14, 5, 9, "\ud95a\udcf5", "\u480a", "\ud89e\ude2e\ud8a5\udca7\ud8e6\ude8c\uda20\ude28\ubb98\ud86f\udcdf\ud96b\uddcc\udb3a\ude2a\udb6c\udd89\uda11\udffb\udae5\udffe\u00fd\uda67\ude01\000\uda9e\udc9c\udba8\udc74\ud9f4\ude86\ud8e3\udf78\ud844\udc44\ud8fe\ude61\udb88\ude8b",
        57, 86632, 1978219239, -2942226542994667673L, -68252L, false, true, (char) 56016, (char) 43302,
        Double.longBitsToDouble(0x3fe6c37693037425L), Double.longBitsToDouble(0x3fe0a31209f5fba9L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Long:479001600\012",
        Z.run(T, 2, 14, 9, 9, "\ud8da\udfd7\ud9d0\ude48\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u5f29\u0ece\uaa8e\u8c1e\ud0e9\u495c\u3526\u1ebc\u310c\ucd33", "\ud8e3\udf78",
        12, 11419, -964280849, 7763871041959170864L, -96542L, true, false, (char) 43302, (char) 23978,
        Double.longBitsToDouble(0x3fe81ba12a146241L), Double.longBitsToDouble(0x3fdf5fba92dbd96eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:55196\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 4, 12, 7, "\ud8da\udfd7", "\u480a", "\ud8a4\udec1",
        53, 55143, 640047076, 3248072729900331903L, 96499L, false, true, (char) 7704, (char) 34751,
        Double.longBitsToDouble(0x3fcfa82478112618L), Double.longBitsToDouble(0x3fe136c0d8e5a3f2L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 16, 9, "\ud8da\udfd7\udbe3\udee9\uda27\udde3\udbba\udc37\ud9be\udf0a\ud917\ude4d\u1893\udae3\udd4e\udb07\ude6e", "\u8a04\u0f5d\uaad7\u8c1e\ud0e9\u495c\ud020\u1ebc\u310c\ucd33", "\ud9c3\uddfc\ud897\udc61",
        0, 65927, 1803093709, -1014696193634321689L, -14888L, false, true, (char) 56016, (char) 56358,
        Double.longBitsToDouble(0x3fe30371fb037425L), Double.longBitsToDouble(0x3fe0a31209f5fba9L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 5, 17, "\ud996\udf0c", "\u480a", "\000\ud8a5\udca77\000\000\ud86f\udc60\ud96b\uddccm\000\000\000\000\000\ud909\ude0e\000\udba8\udc74\uda82\udfce\ud8d6\udce3\ud829\udf54\ud8fe\ude61\udb88\ude8b",
        57, 86632, 1978204160, -2942226543935487897L, -100000L, false, true, (char) 56016, (char) 43302,
        Double.longBitsToDouble(0x3fe6c37690000025L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Double:1.2974641205128097\0121=java.lang.Long:7763871041959074322\012",
        Z.run(T, 2, 6, 5, 9, "\ud8da\udfd7\u00b2\000\000\000\000\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\177\000\ub12e\u8c1e\ud0e9\u495c\ud020\u1ebc\u310c\000", "\ud8bf\udc9f",
        12, 11419, -964280849, 7763871041959170864L, -96542L, true, false, (char) 43302, (char) 23978,
        Double.longBitsToDouble(0x3fe81ba12a146241L), Double.longBitsToDouble(0x3fdf5fba92dbd96eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:-334037151 |a0=[D:[[27733.0, 28627.5, 27909.5, 28534.5]]\0121=java.lang.Long:-820947125170510457\012",
        Z.run(T, 2, 14, 5, 9, "\ud8da\udfd7\uda3b\udf1d", "\u0194\u9529\u8493\u0440\u5c06\ubd7f\u8e5c\u5f29\u0ece\u96b5\u8e32\u939a\u495c\ud020", "\uda9e\udd81",
        26, 81557, -961637671, -820947125170488389L, -22068L, false, true, (char) 11475, (char) 37493,
        Double.longBitsToDouble(0x3feb3eb95d383813L), Double.longBitsToDouble(0x3f71f5cec12e7800L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 14, 7, 9, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udba8\udd37\uda04\udf0d\ud917\ude4d\ud8a4\ude30\ud8a5\udca7\ud8e6\ude8c", "\u5eaa\u0ece\000\u8bd4\ud0e9\u0429\000\u6897\u30e6\ucd33", "\ud8e3\udf78",
        12, 11419, -964280849, 7763871041959170864L, -96542L, true, false, (char) 43302, (char) 23978,
        Double.longBitsToDouble(0x3fe81ba12a146241L), Double.longBitsToDouble(0x3fdf5fba92dbd96eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Double:1.3614260557770594\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 2, 9, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\uda02\udc9c\ud8a5\udca7\ud8e6\ude8c", "\u5f29\u0ece\uaa8e\u9c18\ud0e9\u495c\ud020\u1ebc\u8689\ucd33", "\ud8e3\udf78\ud844\udc44\ud8fe\ude61\udb88\ude8b\udae9\udded\uda1c\ude5b\udb76\uddd9\udbb4\ude61\u294f\uda79\udc9c\ud856\udd7e\udb8d\ude66\uda40\udc31\ud8dc\ude3f\ud878\udd5c\ud92c\udccd\ud881\uddee\ud808\udcd2",
        34, 42970, 685848481, 4715939173450904831L, 29154L, false, false, (char) 14880, (char) 50926,
        Double.longBitsToDouble(0x3fea728b9ba7ef2dL), Double.longBitsToDouble(0x3fe4ccb2c9ed485cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:6.204484017332436E23\0121=java.lang.Long:-6014678879736570597\012",
        Z.run(T, 2, 10, 5, 9, "\ud8da\udf84\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\udb5f\udea9\udb01\udef2\ud901\udd28\ud8ee\ude38\ud96b\uddcc\udb64\udc58\udb6c\uddd3\uda11\udffb\udae5\udffe\ud8ad\udd52\ud870\udfaa\ud8d2\udcb9\uda9e\udd81\ud9bb\udc49\ud9f4\ude86\ud8e3\udf78", "\u21d0\u4747\u5a7f", "\ud928\udec1\uda79\udc9c\ud856\udd7e\ud8aa\udeb4\udafb\udcd1\udbb2\udec7\ud8ef\uddb0",
        24, 18228, -323538443, -6014678879736509604L, -60993L, true, true, (char) 47876, (char) 12358,
        Double.longBitsToDouble(0x3f9a4050438418c0L), Double.longBitsToDouble(0x3fe95b8bc8681f98L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:-262994943 |a0=[D:[[27808.0, 28372.0, 27901.5, 28647.0, 27939.0, 28193.0, 27845.5, 28542.0]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 17, 9, "\ud970\uddd8\uda2b\udffe\uda76\udc72\ud9bb\udf2c\uda04\ude53\ud917\ude4d\ud8a4\udec1\ud9de\udcd4\ud974\udf11", "\u5f29\u0ece\uaa8e\u8c1e\ud0e9\u495c\u8559\u5291\u314e\ucd33\u3bf7\u330b\ucee9\u336f\u7976", "\uda1c\ude5b\udb76\uddd9\udbf6\ude23\u3ab5\uda79\udc9c\ud856\udd7e\ud8aa\udeb4\udafb\udcd1\udbb2\udec7\ud8ef\uddb0",
        24, 18228, -323538443, 8843540717466900996L, 24212L, true, false, (char) 39422, (char) 9375,
        Double.longBitsToDouble(0x3fe0d9dfcf5ca304L), Double.longBitsToDouble(0x3fb11fa08c2daf88L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Double:2.43290200817664E18\012",
        Z.run(T, 2, 14, 10, 0, "\ud8da\udfd7\ud9ea\udfd4\u8e7c\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\udb8b\ude7a\ud8e6\ude8c", "\u5f29\u0ece\uaa8e\u8c1e\ud0e9\u9992\ube83\u476c\u310c\ucd33", "\ud82f\uddd8",
        20, 11419, -964280849, 7763871041959170864L, -96542L, true, false, (char) 33831, (char) 23916,
        Double.longBitsToDouble(0x3fe81f992a146241L), Double.longBitsToDouble(0x3fdf5fba92dbd96eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27723.0, 28643.5, 27909.5, 28534.5, 27899.5, 28377.5]] |a1=[D:[[19068.5, 16945.5, 520.0, 13133.5, 14933.5, 5416.0, 23889.5]]\0121=java.lang.Long:8130611113156199633\012",
        Z.run(T, 2, 8, 5, 15, "\ud8c6\udff7\uda3b\udf1d\uda27\udde3", "\u9529\u8493\u0440\u66cb\u74db\u2a80\ubad3", "\udb6c\uddd3\udb18\udede\udacb\udd7e\ud901\udebc\ud8a1\ude00\udaee\ude7a\ud9ce\udee4\udb3d\udc0f",
        2, 83329, -191141648, 8130611113156296175L, -96542L, true, false, (char) 43302, (char) 23978,
        Double.longBitsToDouble(0x3fe81ba12a146241L), Double.longBitsToDouble(0x3fdf5fba92dbd96eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 9, 16, 10, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud925\udc6a\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c\uda20\udd73", "\u5cb1\uaa8e\ua11e\ud0e9\u49b1\ud020\u1ebc\u310c\u60c1\u07bd\u330b\u930f\u291b\u6f29\uc84d\u4747\ubf85\u3b1f\u5167\u19ea\u1104\u94e6\uc217", "\ud8ef\uddb0\ud92c\udccd\uda06\uddd2",
        33, 66302, 1965174956, -3701417929438823830L, -70964L, false, true, (char) 28544, (char) 49917,
        Double.longBitsToDouble(0x3fdfef140aee29dcL), Double.longBitsToDouble(0x3fcc698e43be43f4L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Byte:1\012",
        Z.run(T, 2, 14, 15, 6, "\ud8da\udfd7\uda3b\udf1d\ud99f\udd1f\u439d\udb78\udd48\ud98e\udc63\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u1fc7\u0f92\uaa8e\u8c1e\ud0e9\u495c\ud020\u7413\u310c\ucd33", "\ud8e3\udf78",
        12, 11419, -964280849, 7763871041959170864L, -96542L, true, false, (char) 43302, (char) 23978,
        Double.longBitsToDouble(0x3fe81ba12a14c16dL), Double.longBitsToDouble(0x3fdf5fba92dbd96eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Long:-6907496247519947551\0121=java.lang.Long:-6907496247519947551\012",
        Z.run(T, 2, 3, 5, 9, "\udac1\udf53\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud9c6\udda5\ud8a4\udec1\ud8a5\udca7\ud8e6\udf24", "\u1f3d\u935d\uaa8e\u8c1e\ud0e9\u495c\ud020\u6f00\u310c\ucd33", "\ud8e3\udf78\ud844\udc44\ud996\udfc9\udb79\udf01\ud9e9\udded\uda1c\ude5b\udb76\uddd9\udbf6\ude23\u3ab5\uda79\udc9c\ud856\udd7e\ud8aa\udeb4\udafb\udcd1\uda29\udddb\udb10\udebb\udbfb\udffe\ud908\udf2f\ud808\udc5f\ud97f\uded9\udb68\udceb\ud902\uddab\udb44\uddaf\ud951\udf82\uda9e\uddd6\uda30\udc87\ud907\udf68\ud84a\uddd2\u466b\ud838\udf1b\ud888\udfa4\ud983\udf2a\uda0d\udfbf\uda0c\ude81\udb03\udf9e\ud8fc\udf65\udb5f\udfa3\ud897\udca1\ud913\udd27\udae0\udf97\ud97c\udd16\udb15\udc62\udac1\udf0a\udbde\udc35\ud889\udfba\ud905\ude70\uda58\ude92",
        19, 30624, 1137180941, -6907496247519930874L, -16677L, true, true, (char) 43980, (char) 22311,
        Double.longBitsToDouble(0x3feef7e754ad547bL), Double.longBitsToDouble(0x3fe3e6fb44a229f6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 5, 9, "\ud82f\udcd5\uda3b\udf1d\uda27\udde3\udb25\udc79\uda5d\udffb\uda0a\udc28\ud8a4\udec1\ud8a5\udca7\ud8d6\udd8c", "\uc2a1\u0ece\ub48e\ud5e5\uc8e6\u3c8e\ucfb1\u1ebc\u4b20\uaac9", "\ud8e3\udf78\ud844\udc44\udbaa\udc87",
        -4, 48060, -236252368, 8301860607807444150L, -96542L, true, false, (char) 31198, (char) 33864,
        Double.longBitsToDouble(0x3fb810a350a31578L), Double.longBitsToDouble(0x3fed0edd4d40ec3bL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Integer:-1070071777 |a0=[D:[[-24.0]]\0121=java.lang.Long:-6082369728148252229\012",
        Z.run(T, 2, 14, 5, 9, "\000", "", "\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c\uda20\ude28\ubaa8\ud86f\udcdf",
        30, 12877, 153313610, -6082369728148153304L, -98925L, true, false, (char) 12191, (char) 45142,
        Double.longBitsToDouble(0x3fdef70d5f298d0cL), Double.longBitsToDouble(0x3fe9835df2e7f1ebL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Long:7763862537923917827\012",
        Z.run(T, 2, 12, 5, 9, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\uc0d3\u0ece\uaa8e\u8c1e\ucdbb\u2176\u798c\u1ebe\u310c\ucd33", "\ud8e3\udf78",
        12, 8923, -790411567, 7763862537923924784L, -6957L, false, false, (char) 50984, (char) 33877,
        Double.longBitsToDouble(0x3fd1048a92dbd96eL), Double.longBitsToDouble(0x3fd48e63c22c98f8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 15, 9, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8a5\udca7", "\u8e5c\u5f29\u0ece\uaa8e\u8c1e\ud0e9\u495c\ud020\u1ebc\u5dfe\ucd33", "\ud8e3\udf78",
        12, 11419, -964280849, 7763871044107244336L, -96542L, true, false, (char) 43302, (char) 23978,
        Double.longBitsToDouble(0x3fe81ba12a146241L), Double.longBitsToDouble(0x3fdf4460d5ad8d9cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Long:6696989000842683771\0121=java.lang.Long:6696989000842683771\012",
        Z.run(T, 2, 5, 3, 11, "\ud8da\udfd7\ud9d9\udce9\udadd\udec0\uda89\udeac\uda59\udfe3\ud94b\udda7\uda75\udd14\ud8b8\udfab\ud8e6\ude8c", "\u8a29\u28fe\u8e86\u5856\ud023\u21fb\ud020\u1ebc\u354c\u95e4", "\udbdb\udd7c\ud844\udc44\udbbd\udf66\udb2b\udc27\udb78\ude9c\ud856\udd34\ud94c\ude23",
        56, 4327, 2104735032, 6696989000842694135L, -10364L, false, false, (char) 48807, (char) 32086,
        Double.longBitsToDouble(0x3fe1a2c0a5e24352L), Double.longBitsToDouble(0x3fe94d020d0d0a0fL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:4\0121=java.lang.Double:24.0\012",
        Z.run(T, 2, 12, 10, 9, "\ud88e\udc58\uda38\ude00\uda27\udde3\udbba\udc37\uda04\udf0d\ud93c\udc4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u5f29\u0ece\uce8e\u779a\uae0f\uca6f\u01ec\u1ebc\u4211\u8e2e", "\ud8e3\udf78\ud844\udc44\ud8fe\ude61\udb88\ude8b\ud9ec\udc1a\uda1c\ude5b",
        4, 41500, 940820327, -5876153835119045644L, -25740L, false, true, (char) 2853, (char) 44264,
        Double.longBitsToDouble(0x3fe50065b3bd3a7cL), Double.longBitsToDouble(0x3fd571b46c10dc2cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Long:7763871041959074322\012",
        Z.run(T, 2, 7, 5, 9, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud92d\udca9\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u5f29\u0ece\u2ad4\u6316\u0120\u8190\u781d\u1ebc\u310c\ucd33", "\ud8e3\udf78",
        12, 67443, -518233380, 7763871041959170864L, -96542L, true, false, (char) 43302, (char) 23978,
        Double.longBitsToDouble(0x3fe81ba12a146241L), Double.longBitsToDouble(0x3fdf5fba98dbd96eL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Integer:-1823340799 |a0=[D:[[32220.5, 27909.5, 28534.5, 27899.5, 28377.5, 28101.0, 28163.5, 27882.0]]\0121=java.lang.Long:1\012",
        Z.run(T, 2, 14, 16, 9, "\ufbe9\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u5f29\u0ece\uaa8e\u8c1e\ud0e9\u495c\ud020\u8e24\u30e6\ucd33", "\ud8e3\udf78",
        24, -1000, -964281088, 7763871041959170864L, -96542L, true, false, (char) 43302, (char) 23978,
        Double.longBitsToDouble(0x3fe81ba12a146241L), Double.longBitsToDouble(0x3fdf5fba92dbd96eL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27728.5, 28289.0, 27909.5, 28534.5, 27899.5, 28377.5, 28101.0, 28163.5]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 2, 16, "\ud8d1\udd32\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u5f29\u644e\uaa8e\u8c1e\ud0e9\u495c\ud020\u4467\u4512\ucd33", "\ud8e3\udf78",
        12, 11419, -964280849, 1326538324586468144L, 97176L, false, false, (char) 27250, (char) 56016,
        Double.longBitsToDouble(0x3fb00939f6c37228L), Double.longBitsToDouble(0x3fe81ba12a146241L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 5, 1, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u5f29\u0ece\uaa8e\u161d\u9f9d\u495c\ud020\u1ebc\u123c\u8c6f", "\ud8e3\udf78\ud844\udc44\ud8fe\ude61",
        -4, 69092, -236252368, 8496386935137967244L, -96542L, true, false, (char) 43302, (char) 23978,
        Double.longBitsToDouble(0x3fe81ba12a146241L), Double.longBitsToDouble(0x3fdf5fba92dbd96eL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Integer:4\0121=java.lang.Double:8.065817517094494E67\012",
        Z.run(T, 2, 12, 10, 1, "\ud95a\ude03\udb54\uddfb\ud8a4\udedd\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1", "\ubd7f\u8e5c\ucedc\u2507\uaa8e\u83f3\u0fa6\ua7ba\u63df\u1f94\u310c", "\ud9f4\ude86\uda5f\uddd5\ud860\ude44\u9497\udb88\ude8b\ud9e9\udded\u817d\udb76\uddd9\udbf6\ude23",
        52, 96032, 1559264260, 6353468026928988837L, -25740L, true, true, (char) 32292, (char) 18952,
        Double.longBitsToDouble(0x3f887116f6905200L), Double.longBitsToDouble(0x3fbabc48fd555ab0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 14, 5, 9, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\ub235\u0ece\uaa8e\u8c1e\ud0e9\u495c\ud020\u1ebc\u310c\ucd33", "\ud8e3\udf78",
        12, 11419, -964280849, 7763871041959170864L, -96542L, true, false, (char) 31271, (char) 23251,
        Double.longBitsToDouble(0x3fe81ba12a216241L), Double.longBitsToDouble(0x3fcebf7525b65a20L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:1953253217 |a0=[D:[[27733.0, 28627.5, 27870.5, 28476.5, 27675.5, 28258.0, 28101.0, 28163.5]]\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 14, 9, 1, "\ud8da\udfd7\ud9ed\udea9\ud867\udcf4\udbba\udc37\u2080\udbaa\udc18\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\ua429\u0ece\uac2d\u8c1e\u03ce\u2ad7\u216d\u2917\u9394\ucebc", "\udaaf\udf90\uda4e\udcbe\ud88e\udc8d\uda55\ude8b\uda98\ude3c\ud9e6\udc93",
        57, 99668, 513886539, -6608599632538088573L, -58614L, false, false, (char) 23978, (char) 4648,
        Double.longBitsToDouble(0x3fe0a31661f5fba9L), Double.longBitsToDouble(0x3fd6decb7401a744L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Byte:-1\012",
        Z.run(T, 2, 14, 15, 1, "\ud8d2\udd0d\uda3b\udf1d\uda6c\udf45\udb49\udf3e\ud90e\udc78\ud917\ude9e\ud8b9\udcc1\ud8a5\udca7\ud8e6\ude8c", "\uc7cd\ube6c\u718f\u8c1e\ud0e9\u495c\ud020\u2e6b\u142e\ucd33", "\uda28\udf2f",
        -4, 11419, -964280849, 7763871041556420144L, -96542L, true, false, (char) 43302, (char) 23978,
        Double.longBitsToDouble(0x3fe81ba12c096241L), Double.longBitsToDouble(0x3fe366a548cf4a48L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Double:4.790016E8\0121=java.lang.Double:19.987214495661885\012",
        Z.run(T, 2, 10, 11, 9, "\ud8da\udfd7\uda3b\udf1d\ud810\udd78\udbc0\udff8\uda04\udf0d\ud91d\udc70\ud970\udfbc\ud8a5\udca7\ud8e6\ude8c", "\u5f29\u0ece\uaa8e\u8c1e\uc42c\u4a00\ud020\u89bc\u20a0\u837b", "\ud8e3\udf78",
        12, 11419, -964280849, 7763871041959170864L, 34456L, false, false, (char) 5892, (char) 54015,
        Double.longBitsToDouble(0x3fb00939f6c37690L), Double.longBitsToDouble(0x3fe81ba12a146241L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27853.0, 28559.5, 11029.5, 27899.5, 28426.0, 28101.0, 28163.5, 27882.0]]\0121=java.lang.Boolean:false |a0=[D:[[27853.0, 28559.5, 11029.5, 27899.5, 28426.0, 28101.0, 28163.5, 27882.0]]\012",
        Z.run(T, 2, 8, 8, 9, "\ud9ca\udf4f\u565b\uda27\ude44\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\udbb9\udf15", "\u87f2\u0d10\u7114\u8c1e\ud0e9\u495c\ud020\u1ebc\u3153\u2ce8", "\ud8e3\udf78",
        12, 10395, -24756753, -3124069760065887213L, -96542L, false, false, (char) 43184, (char) 23978,
        Double.longBitsToDouble(0x3fe81ba12a146241L), Double.longBitsToDouble(0x3fdf5fba92dbd96eL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 12, 12, 12, "\ud8c9\udff0\udba9\udfb4\udac7\udc1b\uda8e\udf10\udb8c\udc78", "\u0440\u25cd", "\ud86f\udcdf\ud96b\uddcc\udb3a\ude2a\udb6c\uddd3\uda11\udffb\udab9\udf29\ud869\uddd8\ud870\udfaa\udb0c\udd89",
        46, 36437, 1914436557, -4130202348291547164L, -18609L, false, true, (char) 32494, (char) 4819,
        Double.longBitsToDouble(0x3fc18ebd33d35cacL), Double.longBitsToDouble(0x3fe9c1c09e047d14L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Double:1.2234468217988672\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 9, 8, "\ue600\udadc\udcdd\ud91c\udc04\udbbf\udede\uda04\udf0d", "\u913c\u84cf", "\ud86f\udcdf\ud96b\uddcc\udb3a\ude2a\ud824\uddd0\ud9d2\udc47\udae5\udffe\ud8ad\udd52\ud870\udfaa",
        -4, 5781, -2146481254, 8222442401620202201L, 21414L, true, false, (char) 20483, (char) 43879,
        Double.longBitsToDouble(0x3fe503328609346cL), Double.longBitsToDouble(0x3feb3c5f85383813L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Double:1.122582389378964\0121=java.lang.Boolean:false |a0=[D:[[27733.0, 28627.5, 27909.5, 28534.5, 27899.5, 28377.5, 28101.0, 28163.5]] |a1=[D:[[12156.5, 1871.0, 21807.0, 17911.0, 26716.5, 9366.0, 26616.0, 3910.0]]\012",
        Z.run(T, 2, 6, 8, 8, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u5f29\u0ece\uaa8e\u8c1e\ud0e9\u495c\ud020\u1ebc\u310c\ucd33", "\ud8e3\udf78\ud84d\udf44\ud8fe\ude61\udb88\ude8b\ud9e9\udded\uda1c\ude5b\udb76\uddd9",
        20, 4327, 2104735032, 6696989004000923010L, 64928L, false, false, (char) 50984, (char) 33877,
        Double.longBitsToDouble(0x3fdf5fba92dbd96eL), Double.longBitsToDouble(0x3fe808f07e3fd0e2L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 7, 7, 15, "\ud9f5\ude40\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d", "\u0440\uc090", "\ud86f\udcdf\ud88b\udd1c\ud80e\udcf1\udb6c\uddd3\uda11\udffb\udae5\udffe\ud8ad\udd52\ud870\udfaa\ud8d2\udcb9\uda9e\udd81",
        26, 81557, -961637671, -820792789815658107L, -22068L, false, true, (char) 11475, (char) 13096,
        Double.longBitsToDouble(0x3feb3eba25383813L), Double.longBitsToDouble(0x3f71f5cec12e7800L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Long:-4141554708806445263\0121=java.lang.Long:-4141554708806445263\012",
        Z.run(T, 2, 3, 3, 13, "\ud8da\udf9e", "\u05e1", "\udbd8\uddbc\udad2\udc50\ud8f8\ude00\uda20\ude28\ubb98\ud86f\udcdf\udac4\uded3\ud80e\udcf1\udb6c\uddd3\u3078\udae6\udc2d\uda1a\udcc9\udb27\udc8a\ud8d2\udcb8\uda9e\udd81\udb3d\udc0f\udab9\udfea",
        35, 50352, 1893055419, -4141554708806447212L, 1949L, false, true, (char) 31746, (char) 60746,
        Double.longBitsToDouble(0x3fe593eb9ec0876fL), Double.longBitsToDouble(0x3fe2fa9a244024e7L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Integer:2\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 17, 8, "\udbbc\udc3f\uda60\udd1e\ud96b\uddc5\uf19a\uda04\udf0d", "\ubbb5\ua805", "\ud8a5\udcdd\uda24\ude0b\ud8c7\udcc0\ud9f1\ude2c\udafa\udcac\ud8c4\udeda\ud807\udc60\ud870\udfaa\ud8a8\ude0d\udbd1\udf72",
        20, 56622, -961658004, -820947126908882245L, -48391L, true, true, (char) 59601, (char) 25149,
        Double.longBitsToDouble(0x3feb2ea2dc576253L), Double.longBitsToDouble(0x3f736f92ff7f7f80L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Integer:-35253759 |a0=[D:[[27733.0, 28627.5, 27909.5, 28534.5, 27899.5, 28377.5, 28101.0, 28163.5]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 10, 17, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d", "\u0440\u5c06", "\ud86f\udcdf\uda24\ude0b\ud8c7\udcc0\ud9f1\ude2c\udafa\udcac\ud8ad\udecb\ud807\udc60\ud846\udc54\uda2e\ude9f\uda38\ude82\ud88e\udce0\ud87c\udd3e\ud8d0\udc57\ud844\udc44\ud8fe\ude61",
        -4, 78180, -236238497, 8496386935137967244L, -42915L, true, true, (char) 59749, (char) 21576,
        Double.longBitsToDouble(0x3fbab6e1140fa938L), Double.longBitsToDouble(0x3fd88910b27f658eL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27673.5, 28646.0, 27825.0, 28498.0, 27899.5, 28377.5, 27794.5, 28474.0]] |a1=[D:[[15500.5, 11755.0, 24231.5, 3310.0, 12156.5]]\0121=java.lang.Boolean:false |a0=[D:[[27673.5, 28646.0, 27825.0, 28498.0, 27899.5, 28377.5, 27794.5, 28474.0]] |a1=[D:[[15500.5, 11755.0, 24231.5, 3310.0, 12156.5]]\012",
        Z.run(T, 2, 8, 8, 17, "\ud863\udffc\ud992\uded4\uda27\udde3\ud955\udea4\uda04\udf0d", "\u7949\u5c06\ubd7f\u1a0c\u5f29", "\ud9f1\ude2c\udafa\udcac\ud8e1\udecb\ud875\udc57\ud91c\udf80\ud9eb\ude4a",
        56, 70746, 102497229, -4130289349162228911L, 46927L, false, false, (char) 3535, (char) 63473,
        Double.longBitsToDouble(0x3fe9c9100f67d72bL), Double.longBitsToDouble(0x3fe56bed10fc920dL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Integer:3\0121=java.lang.Long:-2423446250784753340\012",
        Z.run(T, 2, 12, 5, 17, "\ud8e4\udc39\uda3b\udebe\uda27\udebe\udbb9\udfd7\uda04\udf0d", "\u0440\ud44c", "\udb4d\udd4d\uda24\ude0b\ud8c7\udcc0\ud9f1\ude2c\udafa\udcac\ud8ad\udecb\ud807\udc60\udbfe\udfb1\ud8d2\udcb9\uda9e\udd81\udb3d\udc0f\udbce\udcda\ud8c5\uddc6\ud844\udc44\ud8fe\ude61\udb88\ude8b\ud964\udf11\uda2a\udc8a\udb76\uddd9\udbf6\ude23\u3ab5",
        57, 25260, 1427639682, -2423446250784834974L, 81634L, true, true, (char) 12163, (char) 10878,
        Double.longBitsToDouble(0x3fd5e9a620a91462L), Double.longBitsToDouble(0x3fd7119b31beb4bcL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Integer:2\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 9, 3, "\ud99d\udd59\udbd3\uddd7\uda43\udeea\udbba\udc37\uda04\udf0d", "\u0440\u5c06", "\ud870\uddac\uda24\ude0b\ud8a0\udf8d\ud982\udcc6\udbba\udcf3\ud8ad\udecb\ud807\udc60",
        -2, 75318, 174231781, -9219066787304571955L, 82032L, false, true, (char) 28783, (char) 56443,
        Double.longBitsToDouble(0x3fdb54b065cfe3d6L), Double.longBitsToDouble(0x3fe70baf4ba324cbL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 11, 8, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\udb4d\udfcb\ud917\ude94\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c\uda20\ude28\udb27\ude66\ud86f\udcdf\uda24\ude0b\ud8c7\udcc0\udb2e\udecc\udb1f\udf26\ud8ad\udeb6\ud807\udc60", "\uc1f1", "\ud8d0\udc57\ud844\udc44\ud8fe\ude61",
        -4, 78180, -536789428, 8496405523756424332L, -31006L, true, true, (char) 39251, (char) 62800,
        Double.longBitsToDouble(0x3fded34a81ee104eL), Double.longBitsToDouble(0x3fc88b89028d0ebcL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 12, 12, 14, "\ud9ad\uddd0\uda3b\udf1d\udb31\udee7\udbba\udc94\uda04\udf0d", "\uabc4\u21b2", "\ud86f\udcdf\uda24\ude0b\ud85f\ude0c\ud9f1\ude2c\udafa\udcac\udbe4\udfe7\ud806\udfa3\ucbac\ud8d2\udcb9\udb4e\udf67",
        41, 8393, 1611350968, -820947125170494010L, -85511L, false, true, (char) 63863, (char) 27250,
        Double.longBitsToDouble(0x3fef3654b8f2e41bL), Double.longBitsToDouble(0x3fc49102b4579028L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Integer:3\0121=java.lang.Integer:3\012",
        Z.run(T, 2, 12, 12, 15, "\ud92b\udf55\ud8c8\udf04\udbdb\udef4\ud817\ude46\ud9ea\ude81\ud917\ude4d\ud8a4\udec1\u2a72\ua9ea\udbab\udfae\ud984\udf22", "\u159c\ud754\u8b44\u495c\ud020\u1ebc\u310c\u6d8f\u6d0c\u43e5\ucee9\u5e36\uc706\u7d2d\u36fc\u77ce\u9ea6\u619e\ua4a4\ud5eb\u5abb\u7602\u1ce1\u4718\ub880\ubf76\u54ef\u5152\u95d0\u5d89\u2458", "\ud8ca\uddfc\udb9a\udee3\ud9f6\udcfe\uda83\ude60\udabf\udc53\udb12\udc1f\ud929\udeed\udb79\ude84\ud971\udc55",
        48, 55029, 328837192, 4343501735970536475L, 88951L, false, false, (char) 48657, (char) 44044,
        Double.longBitsToDouble(0x3fb3d6653b6a5020L), Double.longBitsToDouble(0x3fd59ec7fce25c0cL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Integer:8\0121=java.lang.Long:6696989004000920039\012",
        Z.run(T, 2, 12, 5, 15, "\udaed\udd00\ud851\udd27\uda27\ude9a\udbba\udc37\u50c1\uda68\uddc5\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\uac2d\u916b\ua550\ud754\u8b44\u495c\ud020\u1ebc\u310c\u1c35", "\ud8e3\udf78\ud844\udc44\ud8fe\ude61\ud921\udd7c\ud8ab\udf1e\ud9e4\udd0d\udb76\uddd9",
        16, 46424, 2111630375, 6696989004000923010L, -2971L, false, false, (char) 50984, (char) 33877,
        Double.longBitsToDouble(0x3fdf5fba92dbd96eL), Double.longBitsToDouble(0x3fefebb399fa264cL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Integer:8\0121=java.lang.Integer:8\012",
        Z.run(T, 2, 12, 12, 12, "\uda4a\udd53\ud851\udd27\uda27\ude9a\uda83\udc1b\uda2b\uddfb\udafb\udf10\ud8a4\udec1\ud93d\udc94\ud8b8\udc4c", "\u24b2\u53dc\ua550\u141e\uc4b1\u495c\ud020\u1ebc\u310c\u1c35", "\ud8e3\udf78\ud844\udc44\ud8fe\ude61\udb51\udc31\ud9e9\udded\uda1c\ude5b\udb76\uddd9",
        16, 46424, 2111630375, 6696989001145453954L, 64928L, false, false, (char) 50984, (char) 34067,
        Double.longBitsToDouble(0x3fdf5fba9341d96eL), Double.longBitsToDouble(0x3fee43b399fa264cL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Long:-6633239301003272332\012",
        Z.run(T, 2, 2, 5, 15, "\udaed\udd00", "\u480a\u8daf\u9529\u7c02\u387d\u4ace\ubd7f\u70fc\000\uca7c", "\000",
        0, -747, 0, -6633239301003177755L, -94577L, true, false, (char) 12191, (char) 62619,
        Double.longBitsToDouble(0x3fe800000794c60eL), Double.longBitsToDouble(0x3fe9835df2e700ebL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Integer:1484775265 |a0=[D:[[28017.5, 28389.5, 28003.0, 28501.0, 27899.5, 28469.0, 29677.0, 27855.0]]\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 14, 17, 14, "\udb13\uddfb\udaf6\udeda\uda27\ude9a\ue80a\ud9ce\udf69\ud917\ude4d\ud9e2\udfbc\udb37\ude9a\udaac\udca1", "\uac2d\u916b\ua550", "\udaaf\uddd4\uda7a\uddf5\u1e38\ud98c\ude8c\ud8a1\udf65\uda41\udcd1\ud9f0\udd8a\ud8e3\udf78\udbcd\udfe8\ud8fe\ude87\ud813\ude3b\ud9e9\udded\uda1c\ude5b\udb76\uddd9\ud940\ude03\udaa2\udea9\udb53\udc1c\ud856\udd7e\udbaa\udd31\ud880\udff2\ud91e\ude89\udaf2\udd13\ud95b\udeed\ud80b\udcbc\udb06\udc00\udb3d\udc79",
        7, -616, -293196256, 7920727146171298629L, -70365L, true, true, (char) 56931, (char) 35260,
        Double.longBitsToDouble(0x3fe3f2e7d986eceeL), Double.longBitsToDouble(0x3fd966b7c962cb26L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 10, 10, 2, "\ud8d9\udcf0\udb03\udc80\uda27\ude1b\udbba\udc37\ud978\udf07\udafe\udd4e\ud8a4\udec1", "\ubd7f\u8e5c", "\uc5e5\udb5f\udc53\uda11\udffb\udae5\udffe\udbd8\udf08\ud870\udfaa\ud8d2\udcb9\udbef\udf29\uda74\ude0a\udbce\ude92\ud825\udf41\ud843\udf9a\uda7c\udf36\ud9f2\udda9\ud9c1\udf6c\uda1c\ude5b\udb76\uddd9\ud809\udd6d",
        1, 23433, 1559268700, 6353468026928988837L, 26680L, true, true, (char) 33877, (char) 11679,
        Double.longBitsToDouble(0x3fd6decb7fa97f8cL), Double.longBitsToDouble(0x3fe0db5cd0f3521dL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Double:8.683317618811995E36\0121=java.lang.Double:8.683317618811995E36\012",
        Z.run(T, 2, 10, 10, 0, "\uda7f\udf98\ud878\udc68\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8e2\udea6\uda82\udc5a\uda20\ude28\ubb98\ud86f\udcdf\ud96b\uddcc", "\ud0e9\u495c\ud020", "\udbec\udd29\udb3d\udc0f\ud9f4\ude86\ud825\udf73\ud843\udf9a\uda7c\udf36\udb36\udd2d\udbb5\udd4f\udb7d\ude5f\uda1b\ude47",
        33, 4327, 2107174200, 6696989002608414082L, -2784L, false, false, (char) 50984, (char) 33877,
        Double.longBitsToDouble(0x3fdf59fa42dbd96eL), Double.longBitsToDouble(0x3feea5fe361b6b9aL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Integer:26021\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 4, 12, 7, "\ud8b2\uded8", "\u487d\u1f9a\u8c8a\u8493", "\uda16\ude23\ubb98\uda5c\udc95\uda05\uddd1\udb3a\ude2a\ud82e\uddd4\uda11\udffb\udb02\udfed\ud931\udf3c\ud870\udfaa\ud8d2\udcb9",
        26, 25995, -1924204273, -8892901464630650169L, -65301L, true, false, (char) 10557, (char) 59745,
        Double.longBitsToDouble(0x3fe4e18b077c91a6L), Double.longBitsToDouble(0x3fe77e2ee8ddfa1cL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Integer:13053\0121=java.lang.Integer:13053\012",
        Z.run(T, 2, 4, 12, 7, "\ud8da\udfd7", "\ua3a7\u1f9a\u9529\u8493\u0440\u5c06", "\uda5c\udc95\ud96b\uddcc\udb3a\ude2a\udb6c\uddd3\uda11\udffb\udae5\udffe\ud8ad\udd52\ud870\udfaa",
        0, 13053, 92586486, -173877449761104503L, 59840L, false, false, (char) 1635, (char) 21708,
        Double.longBitsToDouble(0x3fd1805e673e6fc2L), Double.longBitsToDouble(0x3f99f0a1ef761200L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Integer:4885\0121=java.lang.Integer:4885\012",
        Z.run(T, 2, 4, 4, 5, "\ud8da\udfd7", "\u3b5d", "\ud8a4\udec1\ud8a5\udca7\udac2\udf5b\ud8ea\udd64\ubde1\ud9fe\udefd\ud951\udf3c\udb3a\ude2a\udb6c\uddd3\uda11\udffb",
        40, 4845, -669282812, -6695253794749640475L, 49269L, false, true, (char) 40515, (char) 939,
        Double.longBitsToDouble(0x3fe6337bf4240382L), Double.longBitsToDouble(0x3fcda7a217978e0cL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Integer:5\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 0, "\ud8da\udfd7", "\u47a6", "\u0891",
        -5, -1000, 0, 1448588159L, -99755L, false, false, (char) 16928, (char) 55177,
        Double.longBitsToDouble(0x3fe136c0d800a3f2L), Double.longBitsToDouble(0x3feaf4d1c80a86f3L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Long:1\0121=java.lang.Long:1\012",
        Z.run(T, 2, 0, 0, 0, "", "", "\ud8e9\udcf3",
        35, -1000, 0, 0L, -100000L, false, false, (char) 0, (char) 63255,
        Double.longBitsToDouble(0x3fcea12470a2ac00L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Integer:-1005\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 2, 7, "\ud8da\udfd7", "\u4764", "\u0091",
        -5, -1000, 0, 1448588032L, 96499L, false, true, (char) 7704, (char) 34751,
        Double.longBitsToDouble(0x3fcfa82478100218L), Double.longBitsToDouble(0x3fe136c0d8e5a3f2L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27733.0, 28627.5]] |a1=[D:[[15721.0, 4021.0]]\0121=java.lang.Boolean:false |a0=[D:[[27733.0, 28627.5]] |a1=[D:[[15721.0, 4021.0]]\012",
        Z.run(T, 2, 8, 8, 7, "\ud8da\udfd7", "\u7b02\u1f9a", "\ud8a5\udca7\udaa9\ude28",
        13, 62641, 1448588159, -6589387274536024402L, 31253L, false, false, (char) 34369, (char) 43223,
        Double.longBitsToDouble(0x3fd6219649bbb328L), Double.longBitsToDouble(0x3feb466118c510d8L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 12, 12, 14, "\uda1a\udc0b\ud938\ude0b\udb19\udf22\udb9c\udf52\uda52\uddd8\ud949\udd56\ud830\udfb4\uda21\udc46\ud825\udfea\uda36\udfc1\udb2c\udd29\uda36\uddac", "\u8c1e\u3529\u29a7\u5dda", "\uda3c\uddcc\ud926\udcd1",
        -3, 80497, -1864983875, -7945002145775980499L, 80584L, true, false, (char) 57663, (char) 18510,
        Double.longBitsToDouble(0x3fa68913f1a2b4d0L), Double.longBitsToDouble(0x3fd7d1d697c0a41aL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 5, 17, "\udb90\ude2c", "\u480a\u0194\u8c2c\000", "\uce72\000\ud86f\udc60\ud96b\uddccm",
        -5, -1000, 0, 0L, -99816L, false, false, (char) 31704, (char) 27694,
        Double.longBitsToDouble(0x3e9b777e93600000L), Double.longBitsToDouble(0x3fdef70d5532d70cL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Double:1.0007630365428253\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 1, 0, "", "", "",
        -5, -1000, 622987409, 5092507388550768951L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fa400000fd41230L), Double.longBitsToDouble(0x3fe0224c3600001bL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Long:7763871041959074322\0121=java.lang.Long:7763871041959074322\012",
        Z.run(T, 2, 5, 5, 9, "\ud8da\udfd7\u00b2\000\000\000\000\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u66ec\000\ub12e\u8c1e\ud0e9\u495c\ud020\u1ebc\u310c\000", "\ud8bf\udc9f",
        12, 11419, -964280849, 7763871041959170864L, -96542L, true, false, (char) 43302, (char) 23978,
        Double.longBitsToDouble(0x3fdb6137d5e39a88L), Double.longBitsToDouble(0x3fdf5fba92dbd96eL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Long:4715939171886579165\0121=java.lang.Long:4715939171886579165\012",
        Z.run(T, 2, 5, 3, 14, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udb14\udf04\ud9ec\ude08\udbd8\udcea\uda16\udeac\ud8a5\udca7\ud8e6\ude8c", "\u73f0\u0ebd\uaa8e\u4835\ub9e7\u495c\uaaca\ubb32\u8689\ucd33", "\ud8e3\udf78\ud844\udc44\ud8fe\ude61\udb88\ude8b\udae9\udded\uda1c\ude5b\ud94a\udfc5\udbb4\ude61\u294f\uda79\udc9c\ud856\udd7e\ud96c\udf56\uda40\udc31\ud8dc\ude3f\ud878\udd5c\ud93f\ude11\ud881\uddaa\ud808\udcd2",
        34, 42970, 685848481, 4715939171886546175L, 32990L, false, true, (char) 14880, (char) 50926,
        Double.longBitsToDouble(0x3fdf5437374f7616L), Double.longBitsToDouble(0x3fe4ccb2c9ed485cL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Byte:1\0121=java.lang.Byte:1\012",
        Z.run(T, 2, 15, 15, 6, "\ud8da\udfd7\uda3b\udf1d\ud99f\udd1f\ud92a\uddc9\uda8c\udf81\ud98e\udc63\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u1fc7\u0f92\uaa8e\u8c1e\ud0e9\u495c\ud020\u7413\u310c\ucd33", "\ud8e3\udf78",
        12, 11419, -964280849, 7763871041959170864L, -96542L, true, false, (char) 43302, (char) 23978,
        Double.longBitsToDouble(0x3fe81ba12a14c16dL), Double.longBitsToDouble(0x3fdf5fba92dbd96eL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Integer:5\0121=java.lang.Long:8740963590559482597\012",
        Z.run(T, 2, 12, 5, 10, "\ud8da\udfd7\uda3b\udf1d\ud827\udce3\udbb9\udfe1\uda04\udf0d\udb26\ude35\udbf0\udd97\uda52\udca6\ud8e6\ude8c", "\uc0d3\u0ece\uaa8e\u8c1e\ucdbb\u2176\u798c\u5c65\ubb61\uccc2", "\ud931\udca4",
        25, 37735, 328752717, 8740963590559480303L, 2294L, false, false, (char) 34827, (char) 63863,
        Double.longBitsToDouble(0x3fe9d9378731c04bL), Double.longBitsToDouble(0x3feb9957c6485605L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 2, 2, 9, "\ufbe9\uda3b\udf1d\uda27\udde3\ud944\udf60\udabf\udf44\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\uda71\udd35", "\ua90f\ua54b\u329a\u1ca8\ubc4f\ucdf9\uc99d\u0237\u7246\u7f7c", "\uda34\udee2",
        57, -1000, -964281088, 7763871041959170864L, -96542L, true, false, (char) 43302, (char) 23978,
        Double.longBitsToDouble(0x3fe81ba12a146241L), Double.longBitsToDouble(0x3fdf5fba92dbd96eL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Integer:2\0121=java.lang.Integer:2\012",
        Z.run(T, 2, 12, 12, 6, "\000\000\000\000\000\000\ud89e\ude2e\000\000", "", "",
        18, -926, 0, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Byte:-1\0121=java.lang.Byte:-1\012",
        Z.run(T, 2, 15, 15, 16, "\ud8d2\udd0d\uda3b\udf1d\uda6c\udf45\udb49\udf3e\ud90e\udc78\ud917\ude9e\ud8b9\udcc1\ud8a5\udca7\ud8e6\ude8c", "\uc7cd\ube6c\u718f\u8c1e\ud0e9\u495c\ud020\u2e6b\u142e\ucd33", "\uda28\udf2f",
        -4, 11419, -964280849, 7763871041556420144L, -96542L, true, false, (char) 43302, (char) 23978,
        Double.longBitsToDouble(0x3fe81ba12c096241L), Double.longBitsToDouble(0x3fe366a548cf4a53L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 12, 12, 12, "\ud809\udff0\udba9\udfb4\udac7\udc1b\uda8e\udf10\udb8c\udc78", "\u0440", "\ua398\ud86f\udcdf",
        30, 35029, 150336471, 4999274603222078647L, 68472L, true, false, (char) 31807, (char) 1268,
        Double.longBitsToDouble(0x3fef263573bbd399L), Double.longBitsToDouble(0x3fd6d1c6b646e31aL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Double:25.19122118273868\0121=java.lang.Double:25.19122118273868\012",
        Z.run(T, 2, 11, 11, 8, "\ud8da\udfd7\uda3b\udf1d", "\u0a2b\u0c96\u96c5\u573e\u5c38\ubd7f\u8e5c\u5f29\u0ece\uaa8e\u8c2c\ud0e9\u495c\u139d", "\uda9e\udd81",
        14, 81557, -961637671, -820904244217005125L, 11184L, true, true, (char) 40661, (char) 60746,
        Double.longBitsToDouble(0x3f71f5cec12e7800L), Double.longBitsToDouble(0x3f9ae222881f9860L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 17, 17, 14, "\udb13\uddfb\udaf6\udeda\uda27\ude9a\ue80a\ud9ce\udf69\ud917\ude4d\ud9e2\udfbc\udb37\ude9a\udaac\udca1", "\uac2d\u916b\ua550", "\udaaf\uddd4\uda7a\uddf5\u1e38\ud98c\ude8c\ud8a1\udf65\uda41\udcd1\ud9f0\udd8a\ud8e3\udf78\udbcd\udfe8\ud8fe\ude87\ud813\ude3b\ud9e9\udded\uda1c\ude5b\udb76\uddd9\ud940\ude03\udaa2\udea9\udb53\udc1c\ud856\udd7e\udbaa\udd31\ud880\udff2\ud91e\ude89\udaf2\udd13\ud95b\udeed\ud80b\udcbc\udb06\udc00\udb3d\udc79",
        7, -616, -293196256, 7920727146171298629L, -70365L, true, true, (char) 56931, (char) 35260,
        Double.longBitsToDouble(0x3fe3f2e7d986eceeL), Double.longBitsToDouble(0x3fd966b7c962cb26L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Integer:63879\0121=java.lang.Integer:63879\012",
        Z.run(T, 2, 12, 12, 9, "\ud8da\udfd7\udb52\udc12\uda27\ude51\ud930\udf94\ud9fe\udcc0\ud917\ude4d\ud9ea\udd72\uda45\udf44\ud8e6\ude8c\uda16\ude23\ubb98\ud893\udf73", "\u8c1e\ud0e9\u495c\ud020\u1ebc\uaca3\u4e23\u5880\ub884\u3fa8\u9d79\uad7f\u0bc3\u38e4\uac16\ucb52\u7967\ucdf2\u99fa\u674d\u74e7", "\udb1b\udd2b\ud974\udfe7\u1b04\ud87a\udeb3\udbfa\udf28\udb9c\udec0\udb14\udc89\ud8f6\udee9\udb0a\ude00\ud841\ude61\uaa61\ud874\udec8\ud821\udd70\udb86\udf44\ud804\udd30\udb76\udd3c\udbee\udd31\ud8fb\udc7b\ud9b2\udeb9\ud914\ude2f\uda65\udfc7\udbf1\udc4c\ud92f\udf3e",
        0, 63879, -206578111, -6048354745046792833L, -88989L, false, true, (char) 48417, (char) 48028,
        Double.longBitsToDouble(0x3fefdf129c5b5575L), Double.longBitsToDouble(0x3fdcce83ccded09cL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Integer:25\0121=java.lang.Integer:-84405755\012",
        Z.run(T, 2, 12, 13, 13, "\ud8da\udfd7\ud816\udd6a\uda27\udde3", "\u9529", "\ud8c8\udfe1",
        25, -1000, 1448588032, -6589387274536026003L, 31325L, false, false, (char) 34369, (char) 13527,
        Double.longBitsToDouble(0x3fe5a676c51db473L), Double.longBitsToDouble(0x3fec5dc4a73002fbL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[D:[[]] |a1=[D:[[]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 1, 4, "", "", "\ub6d6",
        8, 94353, 1185691897, 1629996538232788964L, -99873L, false, false, (char) 0, (char) 25700,
        Double.longBitsToDouble(0x3f4aa9b0a0000000L), Double.longBitsToDouble(0x3fc5282478112618L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 12, 12, 9, "\ud8da\udfd7\udb52\udc12\uda27\ude51\ud930\udf94\ud9fe\udcc0\ud917\ude4d\ud9ea\udd72\uda45\udf44\ud8e6\ude8c\uda16\ude23\ud800\udec1\udb85\udfc0", "\u8c99\u1b92\ua9d8\ud020\u1ebc\uaca3\u8036\u4d55\ub884\u8aa7\u9d79\uad7f\u0eb2\u7852", "\ud878\udd28\uda68\udf4a\uda0e\udc6a\udba3\udfaa\ud8f9\udce4\ud94e\udf51\ud910\uddb0",
        49, 85090, 779563079, -4665607700677713168L, 81277L, true, true, (char) 34232, (char) 29022,
        Double.longBitsToDouble(0x3fe7574dfa50f1aeL), Double.longBitsToDouble(0x3fc876f7de9d2c3cL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[D:[[]] |a1=[D:[[]]\0121=java.lang.Boolean:true |a0=[D:[[]] |a1=[D:[[]]\012",
        Z.run(T, 2, 8, 8, 4, "", "", "\udad1\udd18\uabb9\uda93\udc59\ud8a5\udd23\ud8e6\ude8c\uda20\ude28\ubb98\177\000\000\udb50\udddf\000\udae5\udffe\ud8ad\udcfe",
        27, 98351, 1301367596, 8414997181964229286L, -50054L, false, false, (char) 50145, (char) 18108,
        Double.longBitsToDouble(0x3fe1d9aec85a35caL), Double.longBitsToDouble(0x3fe44648eb477e8eL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Long:7763871041959143708\012",
        Z.run(T, 2, 14, 5, 9, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u5f29\u0ece\uaa8e\u8c1e\ud0e9\u495c\ud020\u1ebc\u310c\ucd33", "\udb0c\uddcb",
        28, 11419, -964280849, 7763871041959170864L, -27156L, true, true, (char) 60746, (char) 63863,
        Double.longBitsToDouble(0x3fd825cf054ab058L), Double.longBitsToDouble(0x3fb00939f6c37690L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27733.0, 28627.5, 27909.5, 28534.5, 27899.5, 28377.5, 28101.0, 28163.5]] |a1=[D:[[12156.5, 1871.0, 26396.5, 12656.0, 26533.0, 13137.5, 6413.5, 4033.5]]\0121=java.lang.Long:17672631900\012",
        Z.run(T, 2, 8, 16, 2, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\uda79\udd52\ud8a4\udec1\ud8e2\udea6\udb49\udf77", "\u5f29\u0ece\uce69\u6310\ucf7a\u66d3\u324b\u1fb3\u310c\u7efb", "\ud825\udf73",
        37, 19, -964246145, 7763871041957139248L, -41772L, true, true, (char) 19531, (char) 12771,
        Double.longBitsToDouble(0x3fd825cf0500b058L), Double.longBitsToDouble(0x3fb00939f13b7690L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27728.5, 28289.0, 27909.5, 28534.5, 27899.5, 28377.5, 28101.0, 28163.5]] |a1=[D:[[12156.5, 12815.0, 21807.0, 17911.0, 26716.5, 819.0, 10991.0, 8731.5]]\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 8, 12, 16, "\ud8d1\udd32\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u5f29\u644e\uaa8e\u8c1e\ud0e9\u0696\u560e\u4467\u4512\ucd33", "\ud8e3\udf78",
        12, 259, -957854631, 1326538324586468144L, 75824L, true, true, (char) 19900, (char) 56016,
        Double.longBitsToDouble(0x3fb00939f6c37228L), Double.longBitsToDouble(0x3fe81ba12ffad941L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Double:1.3221558659144894\0121=java.lang.Integer:36\012",
        Z.run(T, 2, 6, 12, 0, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\ud8e1\udc3b\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c\uda20\ude28\uda99\udf6c\ud86f\udcdf\ud96b\uddcc\udb3a\uddbd\udb6c\uddd3\uda11\udffb\udae5\udffe\ud8ad\udd52\ud8eb\udfa8\ud960\ude3d\uda9e\udd62\ud88d\udfb7\ud9f4\ude86\ud8ef\udcdc\ueeb2\ud8fa\udc9e\udb88\ude8b\ud9e9\udded\uda1c\ude5b\uda48\udca5\udb2a\udf5a\u3ab5\uda79\udc9c\ud856\udd7e\ud8aa\udeb4\uda80\udcd3\uda78\udd23\u4687\ud9c4\udde5\uda17\udf32\ud808\udcd2\ud9f0\udf32\ud881\udc3a", "\u8f5c\u1c0b\u52ab\u0901\u29c5\u9847", "\udb09\ude1c\udbf2\ude7c\ud9a0\ude6a\ud82d\udf8c\udbf1\udf50\ud85b\ude65\ud835\udf7f\ud94d\udd2e\ud89d\udfc6\u157a\ud8f2\udd53\udb37\udce7\udaf6\udd98\ud8a9\udef3\uda55\udc32\uda08\ude1e\uda8f\udc9d\udab4\udf0c\ud846\udc93\ud8e3\udfcf\ud92a\ude77\ud8a3\udee9\udb8c\udffe\ua206\u763b\udafe\udcf9\udbd4\udcbd",
        36, 36, 538501355, -4062675050044410896L, 60245L, false, false, (char) 53800, (char) 33557,
        Double.longBitsToDouble(0x3fe90acbf0665f62L), Double.longBitsToDouble(0x3feb4ef8f85e9e43L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Double:1.0007771080117522\0121=java.lang.Boolean:true |a0=[D:[[-24.0]] |a1=[D:[[-24.0]]\012",
        Z.run(T, 2, 6, 8, 12, "\000", "\000", "",
        51, 51773, 1664896823, 2772960509157800176L, -100000L, false, false, (char) 0, (char) 10870,
        Double.longBitsToDouble(0x3fa42efd0fd3c030L), Double.longBitsToDouble(0x3fe0224c3600001bL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Double:23.59528305955488\0121=java.lang.Long:17672631900\012",
        Z.run(T, 2, 2, 16, 2, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\uda79\udd52\ud8a4\udec1\ud864\udc87\udb43\udf40", "\u5f29\u0ece\uce69\u6310\ucf7a\u66d3\u324b\u1fb3\u310c\u7efb", "\ud825\udf73",
        37, 19, -964246145, 7763871042195423232L, -100000L, true, true, (char) 19531, (char) 12771,
        Double.longBitsToDouble(0x3fd825cf0100b058L), Double.longBitsToDouble(0x3fb00939f13b7690L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[14354.0, 27870.0, 28427.0, 27899.5, 28377.5, 28101.0, 28163.5, 27882.0]] |a1=[D:[[12156.5, 1871.0, 26396.5, 12656.0, 15038.0, 13137.5, 6413.5, 4033.5]]\0121=java.lang.Double:1.76726319E10\012",
        Z.run(T, 2, 8, 1, 12, "\u7054\ud9ec\ude46\uda27\udde3\udbba\udc37\uda04\udf0d\uda79\udd52\ud8a4\udec1\ud8e2\udea6\udb49\udf77", "\u5f29\u0ece\uce69\u6310\u75ac\u66d3\u324b\u1fb3\u310c\u7efb", "\udafc\udd90",
        37, 19, -964246145, 7763871041957139248L, -41772L, true, true, (char) 19531, (char) 12771,
        Double.longBitsToDouble(0x3fd825cf0500b058L), Double.longBitsToDouble(0x3fb00939f13b7690L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27733.0, 28627.5, 27909.5, 28534.5, 27899.5, 28377.5, 28101.0, 28163.5]] |a1=[D:[[12156.5, 1871.0, 26396.5, 24981.5, 19084.0, 13137.5, 6413.5, 4033.5]]\0121=java.lang.Long:1\012",
        Z.run(T, 2, 8, 16, 10, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\uda79\udd52\ud8a4\udec1\ud8e2\udea6\udb49\udf77", "\u5f29\u0ece\uce69\uc35b\u9548\u66d3\u324b\u1fb3\u310c\u7efb", "\ud825\udf73",
        19, 19, -964246145, 7721725661752857392L, -41772L, true, true, (char) 19531, (char) 12771,
        Double.longBitsToDouble(0x3fd825cf0a12a858L), Double.longBitsToDouble(0x3fdbf2975f5dfa84L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27733.0, 28627.5, 27909.5, 28534.5, 27899.5, 28377.5, 28101.0, 28163.5]] |a1=[D:[[12156.5, 1871.0, 26396.5, 12656.0, 26533.0, 13137.5, 6413.5, 4033.5]]\0121=java.lang.Long:227692286640\012",
        Z.run(T, 2, 8, 16, 2, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\uda79\udd52\ud8a4\udec1\ud8e2\udea6\udb49\udf77", "\u5f29\u0ece\uce69\u6310\ucf7a\u66d3\u324b\u1fb3\u310c\u7efb", "\ud825\udf73",
        58, 11, -964246145, 7763871041957139248L, -41772L, false, false, (char) 54365, (char) 12739,
        Double.longBitsToDouble(0x3fd825cf0500b058L), Double.longBitsToDouble(0x3fb00939f13b7690L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Double:4960.0\0121=java.lang.Double:2.6313083693369503E35\012",
        Z.run(T, 2, 17, 10, 13, "\uda61\udeba\uda3e\uddae\uda27\udde3\udbba\udc37\uda04\udf0d\uda79\udd52\ud8a4\udec1\ud8e2\udea6\udb49\udf77", "\u047f\u849a\u6024\u7497\u4dd0\uc597\u324b\u1fb3\u310c\u7efb", "\ud825\udf73",
        32, 3, -964246145, 7763871041957139248L, -41772L, true, true, (char) 19531, (char) 12771,
        Double.longBitsToDouble(0x3fd825cf0500b058L), Double.longBitsToDouble(0x3fb00939f13b7690L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[28074.5, 28283.5, 27696.0, 28318.5, 27899.5, 28485.0, 27786.5, 28294.0]] |a1=[D:[[12156.5, 1871.0, 6046.0, 23350.0, 16655.0, 25265.5, 6413.5, 23761.0]]\0121=java.lang.Long:42504\012",
        Z.run(T, 2, 8, 16, 2, "\udb85\udd27\ud890\udd6d\uda27\udeba\ud945\udd3c\ud8f7\uddc9\uda96\udf92\ud8a4\udec1\ud8e2\udea6\udb21\udf83", "\u5f29\u0ece\u2f6c\ub69c\u824e\uc593\u324b\ub9d2\u46d0\ud38b", "\ud825\udf73",
        24, 19, -964246145, 8124159012146779076L, -41772L, true, true, (char) 5061, (char) 56048,
        Double.longBitsToDouble(0x3fe324df5a4dd088L), Double.longBitsToDouble(0x3fc6449cfc1a390cL)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[D:[[-24.0]] |a1=[D:[[-24.0]]\0121=java.lang.Boolean:true |a0=[D:[[-24.0]] |a1=[D:[[-24.0]]\012",
        Z.run(T, 2, 8, 8, 12, "\000", "\000", "",
        0, 51773, -311144649, 9170393050672172714L, -47333L, false, false, (char) 0, (char) 10870,
        Double.longBitsToDouble(0x3fa42efd0fd3c030L), Double.longBitsToDouble(0x3fe3abec360000cbL)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.Double:1.76726319E10\0121=java.lang.Double:1.76726319E10\012",
        Z.run(T, 2, 17, 1, 12, "\u7054\ud9ec\ude46\uda27\udde3\udbba\udc37\uda04\udf0d\uda79\udd52\ud8a4\udec1\ud8e2\udea6\udb49\udf77", "\u5f29\ub0a8\u4130\u6310\u75ac\u66d3\u324b\u1fb3\u310c\u7efb", "\udafc\udd90",
        37, 19, -964246145, 7763871041957139248L, -41772L, true, true, (char) 19531, (char) 12771,
        Double.longBitsToDouble(0x3fd825cf0500b058L), Double.longBitsToDouble(0x3fb00939f13b7690L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[14354.0, 27870.0, 28427.0, 28040.5, 28400.0, 27757.0, 28646.0, 27868.0]] |a1=[D:[[12156.5, 1871.0, 26396.5, 12656.0, 15038.0, 13137.5, 6413.5, 1189.0]]\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 8, 1, 12, "\u7054\ud9ec\ude46\udb41\ude10\ud90a\udffc\ud9e8\udcf9\uda79\udd52\ud8a4\udec1\ud8e2\udea6\udb49\udf77", "\u5f29\u0ece\uce69\u6310\u75ac\u66d3\u324b\u097a\u319d\u7efb", "\udafc\udd90",
        19, 19, -964246145, 7763871041957139248L, -41772L, true, true, (char) 41198, (char) 12771,
        Double.longBitsToDouble(0x3fd825cf0500b058L), Double.longBitsToDouble(0x3fb00939f13b7690L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.Long:1\0121=java.lang.Long:1\012",
        Z.run(T, 2, 0, 16, 6, "\ud8da\udfd7\ud884\ude3e\ud9f1\udd1e\udbba\udc37\uda04\udf0d\uda79\udd52\ud8a7\udd71\ud8e2\udea6\udb49\udf77", "\u5f29\u380b\uce69\uc35b\ua8a5\u66d3\u324b\u1fb3\u310c\u7efb", "\ud825\udf73",
        19, 19, -964246145, 7721725661752857392L, 36248L, false, false, (char) 27250, (char) 18741,
        Double.longBitsToDouble(0x3fdbf2975f5dfa84L), Double.longBitsToDouble(0x3fdea39100c9c8f2L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Long:1\012",
        Z.run(T, 2, 2, 16, 17, "\ud8da\udfd7\uda3b\udf1d\ud8b8\udd6e\udbe2\udc1d\ud84e\udf12\uda79\udd52\ud8a4\udec1\ud8e2\udea6\udb49\udf77", "\u5f29\u01e0\uce4d\uc35b\u9548\u788d\u5b06\u1fb3\u310c\u7efb", "\ud825\udf73",
        19, 19, -964246145, 7721725661752857392L, -41772L, true, true, (char) 29003, (char) 38780,
        Double.longBitsToDouble(0x3fd829da2a12a858L), Double.longBitsToDouble(0x3fdbf2975f5dfa84L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 1, 1, 12, "\u7054\uda7a\ude4d\udb41\ude10\ud90a\udffc\ud9e8\udcf9\uda79\udd52\ud8a4\udec1\ud8e2\udea6\udbd1\udf7b", "\u5f29\u0ece\u4b39\u252e\u2a33\uc8c1\u324b\u150c\u319d\u2724", "\udafc\udd90",
        19, 19, -964246145, 7763871041957139248L, 14674L, true, true, (char) 38375, (char) 12771,
        Double.longBitsToDouble(0x3fd825cf0500b058L), Double.longBitsToDouble(0x3fb00939f13b7690L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27728.5, 28289.0, 27909.5, 28534.5, 27899.5, 28377.5, 28101.0, 28163.5]]\0121=java.lang.Double:2.4849066497880004\012",
        Z.run(T, 2, 8, 2, 12, "\ud8d1\udd32\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u5f29\u644e\uaa8e\u8c1e\ud0e9\u495c\ud020\u4467\u4512\ucd33", "\ud8e3\udeae",
        12, 11, -964280849, 1315543208308708144L, 97176L, false, false, (char) 27250, (char) 56016,
        Double.longBitsToDouble(0x3fb00939f6c37228L), Double.longBitsToDouble(0x3fe81ba12a146241L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Integer:16\0121=java.lang.Integer:16\012",
        Z.run(T, 2, 12, 12, 12, "\uda4a\udd53\ud851\udd27\uda27\ude9a\uda83\udc1b\uda2b\uddfb\udafb\udf10\ud8a4\udec1\ud93d\udc94\ud8b8\udc4c", "\u24b2\u0090\ua4dd\u141e\uc4b1\u495c\ud020\u689b\u8745\000", "\ud8e3\udf78\ud844\udc44\ud8fe\ude61\udb51\udc31\ucf94\uda1c\ude2b\udb76\uddd9",
        16, 47040, 0, 6696989001145453954L, 64928L, false, false, (char) 29733, (char) 0,
        Double.longBitsToDouble(0x3ec5268000000000L), Double.longBitsToDouble(0x3fee43b398fa264cL)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[14354.0, 27870.0, 28427.0, 28040.5, 28400.0, 27757.0, 28646.0, 28010.0]] |a1=[D:[[12156.5, 10448.5, 26396.5, 12656.0, 15038.0, 13137.5, 6413.5, 89.5]]\0121=java.lang.Double:20.0\012",
        Z.run(T, 2, 8, 1, 12, "\u7054\ud9ec\ude46\udb41\ude10\ud90a\udffc\udb04\ude75\uda79\udd52\ud8a4\udec1\ud8e2\udea6\udb49\udf77", "\u5f29\u51d1\uce69\u6310\u75ac\u66d3\u324b\u00e3\ucea5\u7efb", "\udae2\udfc2",
        20, 19, -964246145, 7763871041957139248L, -41772L, true, true, (char) 41198, (char) 12771,
        Double.longBitsToDouble(0x3fd825cf04301e58L), Double.longBitsToDouble(0x3fb00939f13b7690L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Boolean:false |a0=[D:[[27760.0, 28404.0, 27980.0, 28196.0, 27820.0, 28512.0, 28118.0, 28237.0]] |a1=[D:[[20522.5, 18626.0, 16316.0, 24501.5, 20645.5, 16695.5, 22506.0, 7179.0]]\012",
        Z.run(T, 2, 17, 8, 5, "\ud910\ude18\udac8\udc78\ud988\udef0\udbdc\udcca\ud9f5\udf07\uda79\udd52\ud98a\ude81\ud8e2\udea6\udb49\udf77", "\ua085\u91b4\u7fa8\ubf9b\ua17b\u829f\ub004\u3846\u20b6\u6b01", "\ud825\udf73",
        34, 0, -964246145, -112024206290652839L, -41772L, true, true, (char) 38530, (char) 38780,
        Double.longBitsToDouble(0x3fd829da2fcef99eL), Double.longBitsToDouble(0x3fef1701a9097589L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 2, 2, 17, "\ud8da\udfd7\uda3b\udf1d\ud8b8\udd6e\udbe2\udc1d\ud84e\udf12\uda79\udd52\ud8a4\udec1\ud8e2\udea6\udb49\udf77", "\u0fa7\u01e0\uce4d\uc35b\u9548\u788d\u5b06\u1fb3\u310c\u7efb", "\ud825\udf73",
        19, 19, -964246145, 7721725661752857392L, -41772L, true, true, (char) 29003, (char) 38780,
        Double.longBitsToDouble(0x3fd829da2a12a858L), Double.longBitsToDouble(0x3fdbf2975f5dfa84L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.Long:12\0121=java.lang.Double:2.4849066497880004\012",
        Z.run(T, 2, 16, 2, 6, "\ud93a\udea7\uda3b\udf1d\ud9a8\udfc4\ud91b\ude56\udbab\udcae\ud917\ude2c\ud8a4\udec1\udba8\udfb7\ud94f\udea6", "\u5f29\u644e\u474d\u3c77\ucfda\u7107\ud0fa\u4467\u87ee\u011d", "\ud8e3\udeae",
        12, 11, -964280849, 1315543208308708144L, 97176L, false, false, (char) 27250, (char) 56016,
        Double.longBitsToDouble(0x3fb00939f6c37228L), Double.longBitsToDouble(0x3fe81ba12a146241L)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.Long:12\0121=java.lang.Long:12\012",
        Z.run(T, 2, 0, 0, 12, "\ud8d1\udd32\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u5f29\u644e\uaa8e\u8c1e\ud0e9\u495c\ud020\u4467\u4512\ucd33", "\ud8e3\udeae",
        12, 11, -964280849, 1315543208308708144L, -99432L, false, false, (char) 25851, (char) 56016,
        Double.longBitsToDouble(0x3fb00939f6c37228L), Double.longBitsToDouble(0x3fe81ba12a146241L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.Double:2.4849066497880004\0121=java.lang.Double:2.4849066497880004\012",
        Z.run(T, 2, 2, 2, 12, "\ud8d1\udd32\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\ud917\ude4d\ud8a4\udec1\ud8a5\udca7\ud8e6\ude8c", "\u5f29\u644e\uaa8e\u8c1e\ud0e9\u495c\ud020\u4467\u4512\ucd33", "\ud8e3\udeae",
        12, 11, -964280849, 1315543208308708144L, 97176L, false, false, (char) 27250, (char) 56016,
        Double.longBitsToDouble(0x3fb0090eb6c37228L), Double.longBitsToDouble(0x3fe81ba12a146241L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.Double:20.0\0121=java.lang.Double:20.0\012",
        Z.run(T, 2, 17, 1, 12, "\u7054\ud9c2\udd91\ud85b\udccd\udbe6\udd27\ud996\udcb5\udaab\udd5d\ud8c1\udfd1\ud8e2\udea6\udb49\udf77", "\ua379\u03dd\uce69\u6310\u75ac\u66d3\u6eaa\u0081\uc47f\u7efb", "\udbb2\udcb5",
        20, 19, -964246145, 7763871041957139248L, -41772L, true, true, (char) 41198, (char) 12771,
        Double.longBitsToDouble(0x3fd825cf04301e58L), Double.longBitsToDouble(0x3fb00939f13b7690L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.Long:-112024206290694611\0121=java.lang.Long:1\012",
        Z.run(T, 2, 3, 16, 5, "\ud910\ude18\udac8\udc78\ud988\udef0\ud958\ude28\ud84b\udfc4\uda79\udd43\ud98a\ude81\ud8e2\udea6\udb49\udf77", "\u302f\u647b\u0d95\u8d14\u108b\u8358\ub004\u3846\u20b6\u6b01", "\ud805\udf70",
        26, 0, -964246145, -112024206290652839L, -41772L, false, false, (char) 38530, (char) 38780,
        Double.longBitsToDouble(0x3fd829da2fcef99eL), Double.longBitsToDouble(0x3fef1701a9097589L)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 17, 2, 5, "\ud910\ude18\udac8\udc78\ud988\udef0\udbdc\udcca\ud9f5\udf07\uda79\udd52\ud885\udfe0\uda95\udd83\udb49\udf77", "\ua085\u91b4\u7fa8\ubf9b\ua17b\u829f\ub004\u3846\u20b6\u6b01", "\ud825\udf73",
        34, 0, -964246145, -112024206290652839L, -41772L, true, true, (char) 38530, (char) 38780,
        Double.longBitsToDouble(0x3fd829da2fcef99eL), Double.longBitsToDouble(0x3fef1701a9097589L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 17, 1, 5, "\ud910\ude18\udac8\udc78\ud988\udef0\udbdc\udcca\ud9f5\udf07\uda79\udd52\ud98a\ude81\ud8e2\udea6\udb49\udf77", "\ua085\u91b4\u7fa8\ubf9b\ua17b\u829f\ub004\u3846\u20b6\u6b01", "\ud825\udf73",
        34, 0, -964246145, -112024206290652839L, -41772L, true, true, (char) 38530, (char) 38780,
        Double.longBitsToDouble(0x3fd829da2fcef99eL), Double.longBitsToDouble(0x3fef1701a9097589L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=java.lang.Long:1\0121=java.lang.Long:1\012",
        Z.run(T, 2, 0, 0, 5, "\ud910\uddf3\udac8\udc78\ud988\udef0\ud8a8\udcd3\ud9f5\udf07\uda79\udd52\ud98a\ude81\ud8e2\udea6\udb49\udf77", "\ua085\u91b4\u7fa8\u41ca\000\u7d65\u9b20\ub0e3\u00b9\u6b01", "\ud825\udf73",
        34, 0, -964246145, -112024206290652839L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fef170000007589L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.lang.Integer:30\0121=java.lang.Boolean:false |a0=[D:[[27760.0, 28404.0, 27980.0, 28196.0, 27836.0, 28256.0, 28118.0, 28237.0]] |a1=[D:[[20522.5, 18626.0, 16316.0, 24501.5, 20645.5, 16695.5, 22506.0, 7179.0]]\012",
        Z.run(T, 2, 12, 8, 5, "\ud910\ude18\udac8\udc78\ud9a8\udcf0\udbdc\udcca\ud9f5\udf07\uda79\udd52\ud98a\ude81\ud8e2\udea6\udb49\udf77", "\ua085\u91b4\u7fa8\ubf9b\ua17b\u829f\ub004\u3846\u20b6\u6b01", "\ud825\udf73",
        30, 0, -964246145, -112024206290652839L, -41772L, true, true, (char) 38530, (char) 38780,
        Double.longBitsToDouble(0x3fd829da2fcef99eL), Double.longBitsToDouble(0x3fef1701a9097589L)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 2, 2, 3, "\ud8fd\ude18\udac8\udc78\ud988\udef0\udbf9\udcb9\ud9f5\udf2e\uda79\udd52\udab7\uddc4\uda95\udda2\u7ffb\uda20\ude2f\uda1f\udc16\u24e5\ud8a7\udf6e\uda9d\udfc3\ud81f\udfb1\ud80d\udfd7", "\ubc18\u20b6\u6b01", "\ud825\udf73",
        34, 0, 948815231, -161286952894795431L, -41772L, true, true, (char) 38423, (char) 38780,
        Double.longBitsToDouble(0x3fe02e5c47e77c03L), Double.longBitsToDouble(0x3fe4b4827c842675L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=java.lang.Integer:30\0121=java.lang.Integer:30\012",
        Z.run(T, 2, 12, 12, 1, "\ud915\udd18\udac8\udc78\ud9a8\udd16\udbdc\udcca\ud9f5\udf07\uda79\udd52\ud998\udc9c\ud856\udfc1\ud818\uddfd", "\uc200\u5855\u7fa8\ubf9b\u9b39\u829f\ub004\u3846\u2de5\u051e", "\ud825\udf73",
        30, 0, -964246145, -112024124686274215L, -41772L, true, true, (char) 38530, (char) 38780,
        Double.longBitsToDouble(0x3fd45f5ed9c99768L), Double.longBitsToDouble(0x3fef1701aff69589L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[-24.0, -24.0, -24.0, 27757.0, 28646.0, -24.0, -24.0, -24.0]] |a1=[D:[[-24.0, -24.0, -24.0, -24.0, 15294.0, 56.0, 18018.5, 89.5]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 1, 12, "\000\000\000\ud90a\udffc\000\000\000\000\000", "\000\000\000\000\u77ac\u00a0\u8cf5\u00e3\ua44e\000", "",
        -5, 64976, 2103023019, -4141405658069073772L, -100000L, false, false, (char) 40594, (char) 41198,
        Double.longBitsToDouble(0x3f700002c12e7800L), Double.longBitsToDouble(0x3f0e590000000000L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27733.0, 28627.5, 27909.5, 28534.5, 27899.5, 28377.5, 28101.0, 28163.5]] |a1=[D:[[12156.5, 1871.0, 26396.5, 6571.5, 10273.5, 13137.5, 6413.5, 4033.5]]\0121=java.lang.Long:38\012",
        Z.run(T, 2, 8, 16, 10, "\ud8da\udfd7\uda3b\udf1d\uda27\udde3\udbba\udc37\uda04\udf0d\uda79\udd52\ud8a4\udec1\ud8e2\udea6\udb49\udf77", "\u5f29\u0ece\uce69\u3387\u5073\u66d3\u324b\u1fb3\u310c\u7efb", "\ud825\udf73",
        38, 1, -964246145, 7721725661752857392L, -41772L, true, true, (char) 19531, (char) 12771,
        Double.longBitsToDouble(0x3fd825cf0a12a858L), Double.longBitsToDouble(0x3fdbf2975f5dfa84L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=java.lang.Long:38\0121=java.lang.Long:38\012",
        Z.run(T, 2, 0, 16, 10, "\udb2b\udf32\uda3b\udf1d\ud854\udfb9\ud9ba\udffa\uda04\udf0d\uda79\udd52\ud8a4\udec1\ud919\udd82\uda90\udd3a", "\u3ac3\u0ece\uce69\u3387\u5073\u66d3\u324b\u1fb3\u310c\u7efb", "\ud825\udf73",
        38, 1, -964246145, 7721725660232160048L, -41772L, true, true, (char) 20555, (char) 12771,
        Double.longBitsToDouble(0x3fd825cf03fea858L), Double.longBitsToDouble(0x3fe08cbc65d1ca1fL)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=java.lang.Double:3.0\0121=java.lang.Long:3\012",
        Z.run(T, 2, 17, 16, 10, "\ud9dd\udca0\udb39\udc7b\uda08\udf34\udbba\udc37\udbfd\udca8\uda79\udd52\ud8a4\udec1\ud8e2\udea6\udb49\udf77", "\u5f29\u0ece\ubc56\u895f\u7c06\u66d3\u324b\u4a84\u31ad\u7efb", "\uda2a\ude6d",
        3, 1, -964246145, 7721725661752857392L, -41772L, true, true, (char) 19531, (char) 7471,
        Double.longBitsToDouble(0x3fd825cf0a12a858L), Double.longBitsToDouble(0x3fdbf2975f5dfa84L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=java.lang.Double:3.0\0121=java.lang.Double:1.0986122886681098\012",
        Z.run(T, 2, 17, 2, 10, "\uda9f\udd42\udb39\udc41\ud8ce\udfa9\udbba\udc37\udbfd\udca8\uda79\udd52\ud8a4\udec1\ud8e2\udea6\udb49\udf77", "\u5f29\u0ece\ubc56\u895f\u7c06\u66d3\u324b\u4a84\ua66b\u7efb", "\uda2a\ude6d",
        3, 1, -964246145, 7721725661752857392L, -29288L, true, false, (char) 27250, (char) 18741,
        Double.longBitsToDouble(0x3fdbf2975f5dfa84L), Double.longBitsToDouble(0x3fe126eb6a2b1bb0L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=java.lang.Double:3.0\0121=java.lang.Double:3.0\012",
        Z.run(T, 2, 1, 17, 10, "\uda9f\udd42\udb39\udc41\ud8ce\udfa9\udbcf\udf37\udbfd\udca8\uda79\udd52\ud8a4\udec1\ud8e2\udea6\udb49\udf77", "\u4762\u0ece\ubc56\u895f\u7c06\u66d3\u324b\u4a84\ua66b\u7efb", "\uda2a\ude6d",
        3, 1, -964246145, 7721725661752857392L, -29288L, true, false, (char) 27250, (char) 16693,
        Double.longBitsToDouble(0x3fa1470cfaefd410L), Double.longBitsToDouble(0x3fe126eb6a2b3bb0L)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=java.lang.Double:3.58351893845611\0121=java.lang.Double:3.58351893845611\012",
        Z.run(T, 2, 2, 2, 14, "\uda9f\udd42", "\u480a\u72dc\u340a\ub5dc\u7e34", "\u6493\ud86f\udcdf\ud96b\uddcc\ud85b\udc99\udbe6\udcd8\uda28\udd18\udab7\udd76\ud8db\uddd4\ud934\udf22\uda64\udf22\udbef\udf05\udb3d\udc0f\udac0\uddcd\uda2a\ude6d",
        36, 1, -964246145, 8580055016126996861L, -10410L, true, true, (char) 19531, (char) 7471,
        Double.longBitsToDouble(0x3fd825cf0a12a858L), Double.longBitsToDouble(0x3fdbf2975f63d684L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficient|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficientDouble|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficientLog|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|long,long,java.lang.String|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|long,long|static",
    "M|org.apache.commons.math.util.MathUtils|cosh|double|static",
    "M|org.apache.commons.math.util.MathUtils|equals|double,double|static",
    "M|org.apache.commons.math.util.MathUtils|equals|[D,[D|static",
    "M|org.apache.commons.math.util.MathUtils|factorial|int|static",
    "M|org.apache.commons.math.util.MathUtils|factorialDouble|int|static",
    "M|org.apache.commons.math.util.MathUtils|factorialLog|int|static",
    "M|org.apache.commons.math.util.MathUtils|gcd|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|hash|double|static",
    "M|org.apache.commons.math.util.MathUtils|hash|[D|static",
    "M|org.apache.commons.math.util.MathUtils|indicator|byte|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficient|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficientDouble|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficientLog|int,int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
