package org.apache.commons.math.stat;
import org.junit.Test;
import static org.junit.Assert.*;
public class Frequency_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01244\0111\011100%\011100%\012\012",
        Z.run(T, 1, 3, 6, 4, "\ud84e\udf82\udbe2\uddf7\udb14\udc95\ud909\udc14\ud806\udf50", "\u9515\uae3e\ub466", "\ud86c\uddde\ud942\udd29\ud914\udf49\uda24\udcbe\ud9f6\ude72\udb09\uded8\udb77\udc5d\u05b2\ud842\udf1a\ud89d\udf82\udaff\uddea\ud8c8\uddd5",
        44, 73453, -2087306862, 3638601978426157767L, -68522L, true, false, (char) 59250, (char) 34407,
        Double.longBitsToDouble(0x3fdd8932cc45c56aL), Double.longBitsToDouble(0x3fe2110af5a7f5e3L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \0123638601978426157767\0111\011100%\011100%\012\012",
        Z.run(T, 1, 5, 14, 4, "\ud84e\udf82\udbe2\uddf7\udb14\udc95\ud909\udc14\ud806\udf50", "\u9515\uae3e\ud5e1", "\ud86c\uddde\ud942\udd29\ud914\udf49\uda24\udcbe\ud9f6\ude72\udb09\uded8\udb77\udc5d\u05b2\ud842\udf1a\ud89d\udf82\udaff\uddea\ud8c8\uddd5",
        44, 73453, -2087306862, 3638601978426157767L, -68522L, true, false, (char) 59250, (char) 34407,
        Double.longBitsToDouble(0x3fdd8932cc45c56aL), Double.longBitsToDouble(0x3fe2110af5a7f5e3L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 10, 2, 20, "", "\000\ua631\000\000\000\000\000\u8eae\u7403", "\000",
        -5, -1000, 0, 0L, 96608L, true, false, (char) 39, (char) 5632,
        Double.longBitsToDouble(0x3feeadb806000073L), Double.longBitsToDouble(0x3fd000000273072cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01259\0111\011100%\011100%\012\012",
        Z.run(T, 2, 7, 1, 4, "\u0b08\udbe2\uddf7\u111c", "\u0581", "\ud8e9\udce0\u95fe\ud827\ude5f\ud826\udc40\ud86c\uddde\ud942\udd29\udadf\uddcd\uda1c\udde7\ub84f\udb09\uded8\udb77\udc5d\u05b2\ud842\udf1a\ud908\udf74\udbf5\ude29\ud8e8\uddd4\uda29\uddb8\ud9d0\udf61\u8a3d\udb2f\udc32\udb47\udd4d\ua970\udb9d\udea7\udae6\udf7b\udaeb\udd66\ud8aa\udf57\ud803\udfb4\ud8c2\udd71",
        59, 41033, -1385026146, -1507039106788237144L, 59989L, false, false, (char) 30533, (char) 33055,
        Double.longBitsToDouble(0x3fe53c4dcda8371cL), Double.longBitsToDouble(0x3fef34802d1d5d17L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\ud856\udda0\ud828\udefe\ud937\udd59\ud8be\udd4d\uda94\udd30\0111\011100%\011100%\012\012",
        Z.run(T, 1, 2, 6, 4, "\ud856\udda0\ud828\udefe\ud937\udd59\ud8be\udd4d\uda94\udd30", "\u946d\uae3e\ub466", "\ud885\udc36\ud942\udd29\ud914\udf49\uda24\udcbe\ud9f6\ude72\udb09\uded8\udb77\udc5d\u05b2\ud842\udf1a\ud89d\udf82\udaff\uddea\ud8c8\uddd5",
        44, 73453, -912901742, 3638602563005888455L, -68522L, true, false, (char) 50403, (char) 849,
        Double.longBitsToDouble(0x3fdd8932cc45c56aL), Double.longBitsToDouble(0x3fe2110af5a7f5e3L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 6, 17, 8, "\ud8a8\ude3e\udbe2\uddf7\udb14\udc95\ud909\udc14", "\u6bd8\u76e2\u51a4\uacc6\u2ce7\u8bd7\u1339\uad8b\u3322\u7f51\u2b0c\uaadb\u46aa\u5356\u4999\u462c\uc675\u98b3\u5b53\u527e\u5e1d\u0d12\ud15e\u8560", "\udafc\ude3d",
        47, 21248, 559863330, -728511930766441049L, 29917L, false, true, (char) 64379, (char) 55260,
        Double.longBitsToDouble(0x3fe97f9eb68785d3L), Double.longBitsToDouble(0x3fe4cbb7edcaea95L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 13, 4, 4, "\ud84e\udf82\udbe2\uddf7\udb14\udc95\ud909\udc14\ud8cc\udfe6", "\u9515\uae3e\ub466", "\ud86c\uddde\ud914\ude53\ud914\udf49\uda24\udcbe\ud9f6\ude72\udb09\uded8\udb77\udc5d\u05b2\ud91e\udc21\ud8ce\udcbb\udaff\uddea\ud8c8\uddd5",
        21, 23959, -2087306862, -6398795691075835193L, -68522L, true, false, (char) 59250, (char) 34407,
        Double.longBitsToDouble(0x3fdd8932cc45c56aL), Double.longBitsToDouble(0x3fe2110af5a7f5e3L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 14, 14, "\ud84e\udf82\udbe2\uddf7\udb14\udc95\ud909\udc14\ud8ac\udc03\ud807\udc26\u0c5c\ud845\udc88", "\u45f7\ud2df\uc9a2\u2ab0\u4308\u909e\u2af4\uaadb\u9a38\u5313", "\ud92c\udcc5\ud9e9\ude54\udb3a\ude1d\ud8e9\udc9b\u8a3d\udacd\ude02\udb3e\udddd\ua970\udb9d\udea7\uda06\udf2c",
        47, 6977, 1773480408, -3788042180352553276L, -46224L, false, true, (char) 10706, (char) 28288,
        Double.longBitsToDouble(0x3fde8e10e3343394L), Double.longBitsToDouble(0x3fa23cfd0f9a41b0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 15, 0, 19, "\ud95f\udfd2\udbe2\uddf7\udbb6\ude99\udbbb\ude8d\ud931\udf73\ud96d\udd2d\udb35\udc78\ud845\udc88\ud8e9\udce0\ud9ed\ude01\ud8cc\udcb3\ud826\udc40\ud86c\uddde\ud942\udd29\ud914\udf49\uda24\udcbe\ud957\ude43\uda61\ude8a\ud8fd\udf7f\udb50\udded", "\uc675\u98b3\u9d21\u527e\u1809\u0d12\u5cb3\u8560", "\udb0c\udc66\ud8aa\udf57\ud985\udf94\ud9a6\udc19\ud9c3\udda9\ud998\ude69\udb2c\udcb1\ud846\udc40\udb5c\uddcd\udbf8\udcfd\udbf6\udfd5\uda59\udc06\ud911\udc94\udac5\udef1\u5452\ud87f\udcc7\udbe7\udf2e\uda75\udc44\udb50\udf31",
        54, 62483, -962606808, 4565672560044534539L, -192L, true, true, (char) 28015, (char) 27047,
        Double.longBitsToDouble(0x3fd1cfa4f18ea7d8L), Double.longBitsToDouble(0x3fdec46e79c113d4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\udbc7\udf05\udbe2\udd7a\udb14\udc95\ud909\udc14\ud806\udf50\0111\011100%\011100%\012\012",
        Z.run(T, 1, 4, 11, 15, "\udbc7\udf05\udbe2\udd7a\udb14\udc95\ud909\udc14\ud806\udf50", "\u9515\uae3e\ub466", "\ud86c\uddde\udb45\ude7a\ud814\uddae\udb7c\ude03\ud9f6\ude72\udb09\uded8\udb77\udc5d\u05b2\ud842\udf1a\ud89d\udf82\udaff\uddea\ud8c8\uddd5",
        44, 73453, 227948946, 3638602768707086023L, -53262L, true, true, (char) 59250, (char) 34407,
        Double.longBitsToDouble(0x3fcb0b45990bdfc8L), Double.longBitsToDouble(0x3fe2110af2a7f5e3L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 10, 13, 17, "\ud84e\udf82\udbe2\uddf7\udb14\udc95\ud909\udc14\ud806\udf50", "\u9515\uae3e\ub466\u74d8\u87a9\u3862\uc39e\u4308\u909e\u2af4\uaadb\u9a38\u5313\u4999\u462c\uc675\u98b3", "\u8a3d\ud875\udc62",
        47, 80929, 460293386, 5782831655746443059L, 85896L, false, false, (char) 61343, (char) 15243,
        Double.longBitsToDouble(0x3fe990cde57626c0L), Double.longBitsToDouble(0x3fdf95f51867b268L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01244\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 3, 6, 4, "\ud84e\udf82\udbe2\uddf7\udb14\udc95\ud909\udc14\ud806\udf50", "\u9515\uae3e\ub466", "\ud86c\uddde\ud942\udd29\ud914\udf49\uda24\udcbe\ud9f6\ude72\udb09\uded8\udb77\udc5d\u05b2\ud842\udf1a\ud89d\udf82\udaff\uddea\ud8c8\uddd5",
        44, 73453, -2087306862, 3638601978426157767L, -68522L, true, false, (char) 59250, (char) 34407,
        Double.longBitsToDouble(0x3fdd8932cc45c56aL), Double.longBitsToDouble(0x3fe2110af5a7f5e3L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u0a59\0111\011100%\011100%\012\012",
        Z.run(T, 1, 0, 13, 4, "\ua670\udbe2\uddf75", "\000", "\ud8e9\udc18",
        42, 14317, 0, 504335350272L, 66565L, false, true, (char) 2649, (char) 6461,
        Double.longBitsToDouble(0x3fb900002a900000L), Double.longBitsToDouble(0x3e42896c9c000000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 8, 5, 10, "\ud9cd\udfa3\u7524\ud9e0\udf26\ud909\udc14\udbcf\udfd5", "\u9515\uae3e\ub466", "\ud86c\uddde\ud842\udfc4\ud914\udf49\u10c0\ub64d\udb21\udcf6\ud977\uddfe\u0577\ud842\udf1a\ud89d\udf82\udaff\uddea\ud8c8\uddd5",
        31, 34961, -2087306862, 3638507420426169031L, -68522L, true, false, (char) 59250, (char) 34407,
        Double.longBitsToDouble(0x3fdd8932cc55c96aL), Double.longBitsToDouble(0x3fe2110af5a7f5e3L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 12, 4, 1, "\ud84e\udf82\uda93\udddd\ucadb\udb46\udf4b\udac9\udcf8\ud806\udfb9\u0c5c\udb1c\uddb4\ud8cb\udc49\ud9ed\ude01\udbb6\udca8\ud8d8\uddb9\udab8\uddbc\ud928\udfff\ud950\udfb4\ud940\udfa5\ud93d\ude64", "\u3088\u7ff3\u6e4a\u4f5b\u179a\u09fe", "\uf7f7\ud971\udd02\udaac\udde2\uffe2\udbcc\udd37\ud8c3\udcfb\ud93f\udc3f\ud9c2\ude13\ufd7a\ud9ed\udee1\ud837\udd78\ud866\udd45\ud846\uddf8\ud95e\udd96\ud953\udd09\udab4\udf46\ud9f9\udd7e\ud9d8\udeba\ud937\uddaa\udbb8\udd5e\ud908\udc42",
        11, 2543, 181747827, -571133472945787988L, 21643L, false, false, (char) 57978, (char) 18547,
        Double.longBitsToDouble(0x3fabfe0e6ab32540L), Double.longBitsToDouble(0x3fcfa470cb8fcff4L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 11, 15, 4, "\ud84e\udf82\udbe2\uddf7\udb14\udc95\ud909\udc14\ud806\udf50", "\u7c36\u31ca\ub466", "\ud86c\uddde\ud942\udd29\ud914\udf49\uda24\udcbe\ud9f6\ude72\udb09\uded8\udb77\udc5d\u05b2\ud842\udf1a\ud89d\udf82\udaff\uddea\ud8c8\uddd5",
        44, 73453, -2087306862, 3638435952170363591L, -68522L, true, false, (char) 59250, (char) 34407,
        Double.longBitsToDouble(0x3fdd8932cc45c56aL), Double.longBitsToDouble(0x3fe2110af5a702c8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01244\0111\011100%\011100%\012\012",
        Z.run(T, 2, 13, 3, 7, "\ud979\udf19\ud963\udfb9\ud8cd\udfda\uda2f\udc89\ud883\ude96", "\u9515\uae3e\ub466", "\udb2c\udd1d\ud942\udc9e\ud914\udf49\uda24\udcbe\udae9\udc4d\uda76\udc00\udb3c\ude83\ud884\ude2a\ud842\udf1a\ud89d\udf82\udaff\uddea\ud8c8\uddd5",
        44, 6493, 1685395755, -7250339664945010455L, 69779L, true, true, (char) 6303, (char) 47319,
        Double.longBitsToDouble(0x3fe2110af5a7f5e3L), Double.longBitsToDouble(0x3fe3161862838d24L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01258\0111\011100%\011100%\012\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 19, 0, 19, "\ud8e1\udcd3\ud8e8\udfaa\ud946\udcda\ud87a\ude1e\ud83b\udf38", "\u9515\uae3e", "\ud802\udf1a\ud86c\uddde",
        58, 36710, 1436520283, 8733512453242065190L, -65186L, false, true, (char) 54334, (char) 4041,
        Double.longBitsToDouble(0x3fc3c2b95f56dfdcL), Double.longBitsToDouble(0x3fe02f1d38336f9cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01244\0111\011100%\011100%\012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01244\0111\011100%\011100%\012\012",
        Z.run(T, 2, 3, 9, 20, "\ud84e\udf82\udbe2\uddf7\udb14\udc95\ud909\udc14\ud806\udf50", "\u9515\u2254\u16d1", "\ud86c\uddde\ud8b1\udd01\ud93c\ude0e\uda24\udcbe\ud9f6\ude72\udb09\uded8\udb77\udc5d\u9098\ud9f8\udd73\ud808\uddf8\udaed\udf79\ud8c8\uddd5",
        44, 73453, -2087306862, 3638601978426157792L, -68522L, true, false, (char) 5235, (char) 62144,
        Double.longBitsToDouble(0x3fd722498ba7c52cL), Double.longBitsToDouble(0x3fe2110bc5a7f5e3L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 15, 13, 4, "\ud84e\udf82\udbe2\uddf7\ud8e6\udcbf\uda7a\udfe5\ud806\udf50", "\u9515\ua79f", "\udb55\udebe\ud86c\uddd6\ud91d\udf29\ud914\udf49\uda24\udcbe\ud9f6\ude72\uda33\udfac\ud875\udfe4\u05a0",
        43, 1763, 365606133, -5190655768278370859L, 14103L, true, true, (char) 25782, (char) 39772,
        Double.longBitsToDouble(0x3fe06455f7ccb37dL), Double.longBitsToDouble(0x3fee9ed24f58835eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 10, 15, 4, "\ud84e\udf82\uda00\udfd4\udb14\udc95\ud909\udc14\ud806\udf50", "\u9515\uae3e\ud5e1\u00da\u87a9\u3862\uc39e\u4308\u909e\u2af4\uaadb\u9a38", "\ud89d\udf82\udaff\uddea\ud8c8\uddd5\udb3a\ude6f\ud8e9\udc9b\u8a3d\udb2f\udc32",
        51, 80929, 460293386, 5782831655746443059L, 85896L, false, false, (char) 61343, (char) 15243,
        Double.longBitsToDouble(0x3fe01eabb5c96778L), Double.longBitsToDouble(0x3fcacd5e59e56084L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-728511933085432409\0111\011100%\011100%\012\0121=java.lang.Long:1 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-728511933085432409\0111\011100%\011100%\012\012",
        Z.run(T, 2, 5, 14, 4, "\ud84e\udf82\udbe2\uddf7\udb14\udc95\ud909\udc14\ud806\udf50\ud807\udc26\u0c5c\ud8d6\udff1\ud97a\udcd6", "\u87a9\u3862\uc39e\u4308\u909e\u2af4\uaadb\uae75\ua888\u7421\u1d27\uc675\u98b3\u5b53\u175a", "\udb47\udd4d\ua970\udb9d\udea7\udae6\udf7b\udb0c\udc66",
        47, 21248, 559863330, -728511933085432409L, -58195L, false, true, (char) 27707, (char) 36465,
        Double.longBitsToDouble(0x3fccb0493ffdbd58L), Double.longBitsToDouble(0x3fdb246a39a330c2L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-3471641671278292978\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-3471641671278292978\0111\01150%\01150%\01230\0111\01150%\011100%\012\012",
        Z.run(T, 2, 5, 17, 7, "\ud84e\udf82\ud942\udf70\ud803\udce8\ud909\udc14\ud806\udf50", "\u9dce\uae3e\uc1d4", "\uda36\ude83\ud849\udf56\ud93c\uddc8",
        30, 96343, -655257306, -3471641671278292978L, -23319L, false, true, (char) 26791, (char) 19769,
        Double.longBitsToDouble(0x3fe72c1cb6d24384L), Double.longBitsToDouble(0x3fb668cce85455f0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 12, 1, "\ud84e\udf82\udbe2\uddf7\udb14\udc95\ud894\udc9a\uda72\udf46", "\uc117\ucdb0\ud680", "\ud86c\uddde\ud942\udd29\ud914\udf49\uda24\udcbe\ud836\udd53\ud835\udf87\ud831\udc88",
        31, 32218, 1529293486, 1570266026761197076L, 44610L, false, true, (char) 27855, (char) 7493,
        Double.longBitsToDouble(0x3fb668c7f9cad3e8L), Double.longBitsToDouble(0x3f8d8f4f39f94380L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 7, 9, 14, "\ud84e\udf82\ud9ad\udcd1", "\ucea8", "\udb87\udc89\udb9f\uddde\udb6f\udce2",
        33, 29425, -737098862, 7834779841067562662L, -78318L, false, true, (char) 6461, (char) 54659,
        Double.longBitsToDouble(0x3fd525a03446c436L), Double.longBitsToDouble(0x3fc44b64e8505728L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 14, 11, 18, "\ud990\udc85", "\u6fc4\uaba4\015\000\u5d37\uaf3e\u17d2\u7403\ub5c5\000\u82ba", "\u4e03\000",
        53, -1000, 1645965790, 11103018741137408L, -40565L, false, false, (char) 14592, (char) 27855,
        Double.longBitsToDouble(0x3fea1fede22364a5L), Double.longBitsToDouble(0x3fb98678a53c3920L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0111\011100%\011100%\012\012",
        Z.run(T, 2, 9, 2, 20, "", "\ud40e\u5c1f\uc155\u98d6\ubc4f\u0a0c\u7bde\u4e2e\u7403", "\012",
        -5, -1000, 50331648, 0L, 96608L, true, false, (char) 26407, (char) 59149,
        Double.longBitsToDouble(0x3fe0aaa793249bcaL), Double.longBitsToDouble(0x3f3a4589cc1cb000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u65b5\0111\011100%\011100%\012\0121=java.lang.Long:1 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u65b5\0111\011100%\011100%\012\012",
        Z.run(T, 2, 0, 7, 16, "\ud91a\udca4\u9943\udb2c\udef6\ud9d1\udda1\udbc3\ude41\udb09\uddc1\000\000\000\udaa9\ude08\ud8cb\udfde\ub5c5\000\000", "", "",
        -5, -1000, 1645936640, 11103018741137408L, -40410L, true, true, (char) 26037, (char) 50496,
        Double.longBitsToDouble(0x3fed45951d9f7560L), Double.longBitsToDouble(0x3fed9235cfa11978L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 4, 12, "\u0b08\udbe2\uddf7\u111c", "\u0581", "\ud8e9\udce0\u95fe\ud827\ude5f\ud845\uded1\ud862\udc2e\ud942\udd29\udadf\uddcd\uda1c\udde7\ub84f\udb09\uded8\udb77\udcc6\u05b2\ud842\udf1a\ud908\udf74\udbf5\ude29\ud8e8\uddd4\ud826\ude55\uda32\udc52\u8a3d\udb2f\udc32\udb47\udd4d\ua970\udb9d\udea7\udae6\udf7b\udbe4\udd01\ud90a\udd76\ud803\udfb4\ud8c2\udd71",
        59, 41033, -1385026146, -1507039106785969055L, 59989L, false, false, (char) 30533, (char) 33055,
        Double.longBitsToDouble(0x3fe53c4dcda8371cL), Double.longBitsToDouble(0x3fef34802d1d5d17L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-5\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-5\0112\011100%\011100%\012\012",
        Z.run(T, 2, 17, 1, 4, "\u8df8\u2a00\ud906\udce2", "\u0085", "\ud8e9\udce0\u95fe\u9cd4\ud826\udc40\ud86c\uddde\ud942\udd29\udadf\uddcd\uda1c\udde7\ub84f\u9126\udb94\udc4c\000\000\uea00\000\000\ud9fe\ude9f\ud9d0\udf61\u8a3d\uf139\udbc8\ude84\udb54\udd64\u850a\udb37\ude03\000\000\000\000",
        -5, 92544, 0, 6170369060765696L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe0044dcda8371cL), Double.longBitsToDouble(0x3fef3480281d5d17L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u1cc7\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u1cc7\0112\011100%\011100%\012\012",
        Z.run(T, 2, 0, 0, 13, "\u0b08", "\u7750\u2e67\u0581\u0e3e\u9515", "\ud827\ude5f\ud826\udc40\ud86c\uddde\ud942\udd29\udadf\uddcd\ud870\udfdc\ub84f\udb09\uded8\udbe3\udc10\u05b2",
        46, 18252, -603860919, -4789308004551644391L, -100000L, true, true, (char) 7367, (char) 39800,
        Double.longBitsToDouble(0x3f85157c00000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 7, 7, 17, "\u0b08\udbe2\uddf7\u111c\ud909\udc14\ud83b\udfcd\udbd6\udea8", "\uae3e\uc420\u51c2\u7ffc", "\udadf\uddcd\uda1c\udde7\udb21\udde9\udb09\udf14\udb77\udc5d\u05b2\uda66\udf8d",
        15, 19149, 941231420, 3152957450556105107L, -28633L, true, false, (char) 53922, (char) 4040,
        Double.longBitsToDouble(0x3fe608db7b335040L), Double.longBitsToDouble(0x3fe12226b9d8932cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u0b08\udbe2\uddf7\udb98\udd25\udb4b\udc15\ud84e\udd17\ud806\udffc\udbe0\udd9b\ud845\udc88\ud8e0\ude7d\ud9f4\udfc4\0111\011100%\011100%\012\0121=java.lang.Long:1 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u0b08\udbe2\uddf7\udb98\udd25\udb4b\udc15\ud84e\udd17\ud806\udffc\udbe0\udd9b\ud845\udc88\ud8e0\ude7d\ud9f4\udfc4\0111\011100%\011100%\012\012",
        Z.run(T, 2, 4, 13, 4, "\u0b08\udbe2\uddf7\udb98\udd25\udb4b\udc15\ud84e\udd17\ud806\udffc\udbe0\udd9b\ud845\udc88\ud8e0\ude7d\ud9f4\udfc4", "\u3862\uc39e\ub68c\ua9fd\uc9ac\u4bdf\u9a38\u5313\u4999", "\ud8e8\uddd4\uda29\uddb8\ud9d0\udf61\ud9e0\udc7a",
        28, 62098, -1967196089, 6298430358224950440L, 98207L, false, true, (char) 22384, (char) 23071,
        Double.longBitsToDouble(0x3fdf1fd00b3c2734L), Double.longBitsToDouble(0x3fef5d6b90a8eb15L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01250\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01250\0112\011100%\011100%\012\012",
        Z.run(T, 2, 3, 19, 4, "\u0b08\udb8b\uddac", "\u28c6\u0581\u0c48\u329f\uae3e\uc420\u5194\u87a9\u3862\uac35\u2075\u3709\uc9ac\u5aa1\ud5e4\uaf36\u4999", "\ud8e8\uddd4\uda29\uddb8\ud9d0\udf61\u8a3d",
        50, 37631, -1976043431, 1976945040026549953L, 66104L, true, false, (char) 9020, (char) 31982,
        Double.longBitsToDouble(0x3fdf1fd17b3c2734L), Double.longBitsToDouble(0x3fef5d6b90a8eb15L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 11, 11, 4, "\udbce\udfad\uda08\ude0d\u11e2", "\u0581", "\ud862\ude8a\ud965\ude28\ud827\ude5f\ud826\udc40\ud89a\udc53\ud942\udd29\udadf\uddcd\uda1c\udde7\ud815\udc4f\udb09\uded8\udb56\ude4d\u05b2",
        46, 18252, -879439799, -4789308002401042663L, 16334L, true, true, (char) 7493, (char) 31828,
        Double.longBitsToDouble(0x3fc2dc175b046dbcL), Double.longBitsToDouble(0x3fd335040383189eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\ud856\udda0\ud828\udefe\ud937\udd59\ud8be\udd4d\uda94\udd30\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\ud856\udda0\ud828\udefe\ud937\udd59\ud8be\udd4d\uda94\udd30\0112\011100%\011100%\012\012",
        Z.run(T, 2, 2, 18, 4, "\ud856\udda0\ud828\udefe\ud937\udd59\ud8be\udd4d\uda94\udd30", "\u946d\ud534", "\ud8ef\udd24\ud885\udc36\ud942\udd29\ud914\udf49\uda24\udcbe\ud9f6\ude72\udb09\uded8\udb77\udc5d\ud8bb\udfea\ud842\udf1a\ud89d\udf82\udaff\uddea\ud8c8\uddd5\udb3a\ude6f\ud8e9\udc9b",
        48, 90177, -708134969, 5982705842996086081L, 57347L, true, true, (char) 48388, (char) 62423,
        Double.longBitsToDouble(0x3fe2110c451de1eaL), Double.longBitsToDouble(0x3fce40521fb23744L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 10, 10, 17, "\ud84e\udf82\udbe7\udcf7\udb14\udc95\ud909\udc14\ud806\udf50", "\u9515\uae3e\ub466\u74d8\u87a9\u3862\uc39e\u4308\u909e\u2af4\uaadb\u9a38\u5313\u4999\u462c\u11e2\u997d", "\ub1ba\ud88c\udc46\udb2d\udd89\ua970\udb9d\udea7\udae6\udf7b\udb0c\udc66\ud8aa\udf57",
        53, 19330, -169619902, 1854433730781814578L, -74919L, true, false, (char) 41039, (char) 26523,
        Double.longBitsToDouble(0x3fd32438fc9adc64L), Double.longBitsToDouble(0x3fec77645989435bL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \0123537793919703499485\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \0123537793919703499485\0112\011100%\011100%\012\012",
        Z.run(T, 2, 5, 5, 15, "\ud84e\udf82\udb6a\udc5c\ud94f\udc8c\udbd9\udc19\ud999\udc38", "\u6b03\uae3e\ub466\u74d8\u87a9\u3862\uc39e\u4308\u909e\u2af4\uaadb\u9a38\u5313\u874a\u462c\uc675\u0bce", "\u8a3d\ud875\udc62\udb2d\udd89\ua970\udb9d\udea7\udae6\udf7b\udb0c\udc66\udabe\udfad\ud818\udc1e\ud9a6\udc19\ud9c3\udda9\ud8db\udf2b\udade\udf93\u2314\udac5\udfaf\ud927\udf87\udb45\udd81\ud8bb\ude1e\ud89b\udd24\udbc0\ude1c\ud830\udfc7\ud861\udcd2\uda46\ude2e\ud905\ude7c\ud8f5\udc09\udb19\udf56\ud9a4\udfc2\ud869\udcd9",
        45, 88718, 822454399, 3537793919703499485L, 31496L, false, false, (char) 54542, (char) 26947,
        Double.longBitsToDouble(0x3fd2a6c4ac1fe856L), Double.longBitsToDouble(0x3fd379e7d0f5f3d2L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-5\0111\011100%\011100%\012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-5\0111\011100%\011100%\012\012",
        Z.run(T, 2, 3, 14, 5, "\ud84e\udf82\udbe2\uddf7\udb14\udc95\ud909\udc14\ud806\udf50", "\u9515\uae3e\u5e17", "",
        -5, -1000, -957153280, -5638096222755247282L, 77314L, false, false, (char) 53196, (char) 35448,
        Double.longBitsToDouble(0x3fd926fc5273072cL), Double.longBitsToDouble(0x3fe63993f059a31fL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 3, 7, "\ud979\udf19\ud963\udfb9\ud8cd\udfda\uda2f\udc89\ud883\ude96\ud805\udf54\u5b82\ud94a\uddab\u4838\uda02\udfc7", "\u9e64\uc34c\u3c41\u909e\u1681\u1615\u459f\ud03a\u4999\u1fe1\uc675\u98b3", "\uda1f\udf16\u282c",
        11, 24236, 460293386, 5782831655746443059L, 38126L, false, false, (char) 61343, (char) 15243,
        Double.longBitsToDouble(0x3fe3161862838d24L), Double.longBitsToDouble(0x3feb841b8189472eL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 15, 15, 3, "\ud8e1\udcd3\ud8e8\udfaa\ud930\udf95\uda92\udfbd\ud846\uddf9", "\u3357\u489e", "\uecdb\uda8b\udce9",
        0, 78067, -1361882013, -4889313470068435132L, -65186L, false, true, (char) 54334, (char) 4041,
        Double.longBitsToDouble(0x3fc3c2b94f56dfdcL), Double.longBitsToDouble(0x3fd9e8e0721a1156L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\ud84e\udf82\udbe2\uddf7\udb14\udc95\ud909\udc14\ud806\udf50\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\ud84e\udf82\udbe2\uddf7\udb14\udc95\ud909\udc14\ud806\udf50\0112\011100%\011100%\012\012",
        Z.run(T, 2, 4, 4, 13, "\ud84e\udf82\udbe2\uddf7\udb14\udc95\ud909\udc14\ud806\udf50", "\u9515\u2254\u16d1", "\ud86c\uddde",
        6, 86682, -1312721573, 8733512453242065190L, 91332L, true, false, (char) 24130, (char) 51169,
        Double.longBitsToDouble(0x3fb4699c55b2cdc0L), Double.longBitsToDouble(0x3feed4a78f296fc5L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 12, 12, 17, "\uda3f\udfb4\ud942\udf70\udac3\udce8\ud909\udc14\ud806\udf50\ud807\udc26\u0c5c\ud8ad\uddd8\ud8e9\udce0\ud9e4\udd62\udb3f\ude01\ud85e\uded4\uda36\ude83\ud849\udf56\ud861\udf5b\udaf3\udc4c", "\ucf30\u12bd\u647a\u99ae", "\udb05\udfec\ud9df\uddcf\uc0ba\ud9e0\uded8\udbde\udd59\ua970\udb36\udf50\udad2\udd1b\uda59\udc8e\ud912\udc3f\ud9f5\udcee\ud9a7\udc82\uda00\ude5c\ud84b\udeb6\udace\udcab\udb9e\udf18\udb07\udfa7\udb10\ude26\ud823\udc79\udb6e\udcf4\uda2f\udd21",
        36, 3763, -916655119, 3045121453639276354L, -53961L, false, true, (char) 30131, (char) 19210,
        Double.longBitsToDouble(0x3fcf61054a1c4788L), Double.longBitsToDouble(0x3fc76adfea92ef10L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 8, 8, 11, "\udbc9\ude2a\u7d9f\udb9f\udfe2", "\u300e\ucc58\u9a6b\uadb7\u91f9", "\uda98\udcc8\uda17\udc27\ud951\udde7\ud9d8\udc28\uda88\udca4\ud931\udcd6\udb46\udd60\udbf7\udf0c",
        37, 16655, 673703097, 8996450849368008212L, 82921L, true, true, (char) 33605, (char) 25648,
        Double.longBitsToDouble(0x3fe19a82069b2fa8L), Double.longBitsToDouble(0x3fdc43079ad51feeL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \0121\0111\011100%\011100%\012\012",
        Z.run(T, 1, 3, 6, 4, "\ud84e\udf82\udbe2\uddf7\udb14\udc95\ud909\udc14\ud806\udf50", "\u9515\uae3e\ub466", "\ud86c\uddde\ud942\udd29\ud914\udf49\uda24\udcbe\ud9f6\ude72\udb09\uded8\udb77\udc5d\u05b2\ud842\udf1a\ud89d\udf82\udb5d\uddf9\ud96d\ude8a",
        1, 73453, -2087289966, 3638601978426157767L, -68522L, true, false, (char) 59250, (char) 34407,
        Double.longBitsToDouble(0x3fdd8932cc45c56aL), Double.longBitsToDouble(0x3fe2110af5a7f5e3L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 13, 13, 17, "\ud84e\udf82\udbe2\uddf7\udb14\udc95\ud909\udc14\ud806\udf50", "\u9515\uae3e\ub466\u25ee\ud281\u386e\uc39e\u4308\u909e\u2af4\uaadb\u9a38\u5313\u4999\u462c\uc675\u98b3", "\u8a3d\ud875\udc62",
        47, 80929, 460293386, 5782831655746443059L, 85896L, false, false, (char) 61343, (char) 15243,
        Double.longBitsToDouble(0x3fe990cde57626c0L), Double.longBitsToDouble(0x3fdf95f51867b268L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.stat.Frequency|addValue|char|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|int|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|java.lang.Comparable|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|java.lang.Integer|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|java.lang.Object|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|long|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|clear||new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCount|char|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCount|int|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCount|java.lang.Object|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCount|long|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCumFreq|char|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCumFreq|int|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCumFreq|java.lang.Object|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCumFreq|long|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCumPct|char|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|char|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|int|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|java.lang.Comparable|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|java.lang.Integer|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|java.lang.Object|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|long|new:org.apache.commons.math.stat.Frequency:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
