package org.apache.commons.math.complex;
import org.junit.Test;
import static org.junit.Assert.*;
public class Complex_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:-2074648790 |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 14, 7, 15, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\ud9fa\udc61\ud9c7\udfc9\udba0\udc36\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud8cc\udd2e\udbf2\udfb1\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud942\udc00\udb94\udc9a\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\u3ccc\uc89c\u11da\u3f9d", "\ud8fe\udca9\ud8f4\udd6c\ud86e\udf2c\ud8d6\udc18\udb70\udff8\ud98b\udf7c\ud812\udc35",
        51, 83008, 457952097, 155007037785419431L, -90995L, false, false, (char) 58938, (char) 34195,
        Double.longBitsToDouble(0x3fcd5604e0aafc60L), Double.longBitsToDouble(0x3fe0a955ac35a84bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:-2074648790 |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 14, 7, 15, "\ud925\udc87\udb28\udcf3\ud831\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\udaa0\udd6e\uda91\udd08\u1dc8\u9e71\ud921\udc04\ud9c2\udd91\ud9c7\udfc9\udba0\udc36\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\ud9b3\udc25\udad1\udcbe\udb96\udfd9\udad7\udf19\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udaa5\udf5a\ud844\ude93\ud8e5\udc0c\ud84a\ude17\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\u3ccc\uc89c\uaa22\u3f9d", "\ud8fe\udca9\ud8f4\udd6c\ud9ed\udfbf\ud97d\uddf1\udb70\udff8\uf4b3\ud812\udc35",
        51, 83008, 457952097, -8694105534625567065L, -90995L, false, false, (char) 58938, (char) 34195,
        Double.longBitsToDouble(0x3fcd5604e0aafc60L), Double.longBitsToDouble(0x3fe0a955ac35a84bL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:-1861631908 |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 14, 7, 15, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\ud9fa\udc61\ud9c7\udfc9\udba0\udc36\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud8cc\udd2e\udbf2\udfb1\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud942\udc00\udb94\udc9a\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\u3ccc\uc89c\u11da\u3e6d", "\ud8e7\udfa9\ud8f4\udded\ud86e\udf2c\ud8d6\udc18\udb70\udff8\ud98b\udf7c\ud812\udc35\udb22\udc48\ud9c9\udd59\udb2b\udcfc\ud9ae\ude34\uda99\udc5c\udbe8\udfda\ud87b\udfa6\ud91f\ude38\ud815\ude88\ud973\udec5\udb3d\udd16\ud928\udeae\udb67\udce9\ud81c\udcc7\ud8e6\udcfa\udae1\udd8e\ud828\udc36\udbdf\udf3d",
        5, 79531, 649224786, 8517442483872547684L, -85845L, false, true, (char) 9470, (char) 32079,
        Double.longBitsToDouble(0x3fd7664bc32a25b6L), Double.longBitsToDouble(0x3fd93d57871ff768L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 8, 7, 15, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\ud9fa\udc61\ud9c7\udfc9\udba0\udc36\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud8cc\udd2e\udbf3\udc58\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud942\udc00\udb94\udc9a\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\ud8b5\udc7e", "\u3ccc\uc89c\u11da\u3f9d", "\ud8fe\udca9\ud8f4\udd6c\ud86e\udf2c\ud8d6\udc18\udb70\udff8\ud98b\udf7c\ud812\udc35",
        51, 83008, 457952097, 155007037047738791L, 16087L, false, true, (char) 16657, (char) 14147,
        Double.longBitsToDouble(0x3fe0a955ac35a84bL), Double.longBitsToDouble(0x3fc6026c4f62d75cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:1763066627 |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 14, 6, 9, "\ud925\udc87\udb28\udcf3\udb18\udcd1\ud8d8\udecf\ua4a5\ud990\udd17\ud9d3\udcb9\udaac\udc47\u7930\udb76\udda6\ud8de\udc97\ud912\udc12\udb5b\udc99\uda06\ude6a\ud9a9\udfa8\ud913\uddb2\ud938\udf9b\ud97c\udcb3\udb66\udfb3", "\u3252\u5da6\u016f\u3f2f\u13ba\ua120\u605a\uccca\u9d98\u0f07\ub01c\u35c1\ub827\ud298\u0c91\u0b66\u510e\u4a5b\u81c5\ube11\u2974\u9de5\u5de8\u9c47\ubf4e", "\ud827\udf45\ud9f2\udf52\udb83\udeab",
        28, 58021, -598347760, 6970775233836090379L, -80879L, true, false, (char) 3263, (char) 52574,
        Double.longBitsToDouble(0x3fe5381133e060e2L), Double.longBitsToDouble(0x3fde95be9b95966aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:127473622 |this=org.apache.commons.math.complex.Complex:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 10, 15, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\ud9fa\udc61\ud9c7\udfc9\udba0\udc36\ud848\udeee\udb42\ude6e\uda0f\udd25\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud8cc\udd2e\udbf2\udfb1\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud942\udc00\udb94\udc9a\ud84a\ude0a\udb0c\ude2a\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\u1a12\uc8c1\u0a48\u3f9d\u0bfc\u28af", "\ud86e\udf2c\ud820\udc1d\udb70\udff8\ud98b\udf7c\ud812\udc35\udb22\udc48\ud9c9\udd59\udb2b\udcfc\ud9ae\ude34",
        58, 9352, -1004002515, 2361016820826752375L, -36645L, true, false, (char) 7050, (char) 50548,
        Double.longBitsToDouble(0x3fe999202d17eacfL), Double.longBitsToDouble(0x3fecd1426d508cfdL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 11, 7, 15, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\ud9fa\udc61\ud9c7\udfc9\udba0\udc36\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\ud9bf\udd78\ud8cc\udd2e\udbf2\udfb1\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud942\udc00\udb94\udc9a\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\u3ccc\uc89c\u11da\u3f9d", "\ud8fe\udca9\ud8f4\udd6c\ud86e\udf2c\ud8d6\udc18\udb70\udff8\ud98b\udf7c\ud812\udc35",
        51, 83008, 457952097, 155007037785419431L, -90995L, false, false, (char) 58938, (char) 34195,
        Double.longBitsToDouble(0x3fcd5604e0aafc60L), Double.longBitsToDouble(0x3fe0a955ac35a84bL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 9, 7, 2, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\ud9fa\udc61\ud9f6\uddc9\udba0\udc36\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud8cc\udd2e\udbf2\udfb1\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud942\udc00\udb94\udc9a\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\ud9f1\udefd\ud9a4\udded", "\uc89c\u11da\u3f9d", "\ud8fe\udca9\ud8f4\udd6c\uda4e\udfe2\udba7\udfb4\udb70\udff8\ud98b\udf7c\ud812\udc35",
        51, 83008, 457952097, 155007037203275943L, -90995L, false, false, (char) 56890, (char) 34195,
        Double.longBitsToDouble(0x3fcd5604e0aafc60L), Double.longBitsToDouble(0x3fe0a955ac35a84bL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:443521791 |this=org.apache.commons.math.complex.Complex:@?\0121=java.lang.Integer:443521791 |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 14, 14, 15, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb8f\udd06\ud9ec\udf76\ud647\udb52\udce5\ud9cf\udfba\uda41\udd53\uda2f\ude60\udbd9\udf9e\ud93b\ude8a\udbe6\udcd0\ud913\udc88\ud960\ude41\ud9c7\udfc9\udba0\udc36\ud93c\udec8\uda74\uded0\uda0f\udd76\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud8cc\udd2e\udbd2\ude81\ud92e\udc8e\uda15\udcbc\udb5e\ude21\ud847\ude86\udb01\udd3d\ud942\udc00\udb94\udc9a\ud84a\ude0a\udb0c\ude23\ud9e8\udf33\ud971\udc0c\udab1\uddae\ud9de\ude35\ud9c8\udf44\udb31\ude8b\ud9f1\udefd", "\u3ccc\uc89c\u11da", "\ud952\ude9a\ud8fe\udca9\ud8f4\udd6c\udad3\udcbf\ud984\udfd8\u48f9\ud98b\udf7c",
        1, 76751, 1433981008, 1966889279785710100L, 82752L, true, true, (char) 51314, (char) 58938,
        Double.longBitsToDouble(0x3febd090c8eab027L), Double.longBitsToDouble(0x3fa55f8c1152ab50L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 5, 7, 15, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\udb5e\udd5e\uda31\udec6\uda21\uddcd\ud9fa\udc61\ud9c7\udfc9\udba0\udc3d\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud89f\ude14\ud8fa\udc9e\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud8cc\udd2e\udbf2\udfb1\ud8dc\udc89\ud8fb\udf60\udb5e\ude21\ud847\ude86\udb01\udd3d\ud8ed\ude96\udb94\udc9a\ud84a\ude0a\uda1a\udeec\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\udb44\udc39", "\u3ccc\uc89c\u11da\u3f9d\u0bfc\u28af\ubb5e\u2a88\u873b\ubc84\u6691\u4b12\uc865\ud0a3\u3771\ud3ba\u94a0\u417b\u11b4\uac95\u731f\ud2ea", "\ud928\udeae",
        -2, 7261, 615155204, -7245250903316312827L, 78486L, true, true, (char) 1449, (char) 10645,
        Double.longBitsToDouble(0x3fee4b930f056bb1L), Double.longBitsToDouble(0x3f9e5c3551cc1e80L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 6, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\ud9fa\udc61\ud9c7\udfc9\udba5\udd36\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud9a9\udf18\udaca\udc18\udb3b\udcb9\udbd5\udebe\udb41\uddf0\udbf4\udd54\udacc\ude2e\ud99f\udc70\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud942\udc00\udb94\udc9a\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\ud9f1\udefd\ud9a4\udded", "\uc89c\u11da\u3f9d", "\udab7\udd05\ud8c7\udce4\ud86e\udf2c\ud8d6\udc18\udb70\udff8\ud9a0\ude7c\ud812\udc35",
        51, 83008, 457952097, 155007037785419431L, -90995L, true, false, (char) 44896, (char) 34195,
        Double.longBitsToDouble(0x3f72c09c155f8c00L), Double.longBitsToDouble(0x3fe0a955ac35a84bL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 7, "\ud925\udc87\ud86f\udcf2\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\ud9fa\udc61\ud9c7\udfc9\udba0\udc36\ud848\udeee\uda7e\uddeb\udb43\uddab\ud9a9\udf18\ud89a\ude0b\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud8cc\udd2e\udbf2\udfb1\u5bc7\ud8fb\udfb7\udba8\udf41\uda06\udc73\ud90e\udd03\ud900\udea3\uda39\uddd7\ud8e1\udee0\ud8ff\udd50\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\u3ccc\uc89c\u11da\u3f9d", "\ud8fe\udca9\ud8f4\udd6c\ud86e\udf2c\ud8d6\udc18\udb70\udff8\ud98b\udf7c\ud812\udc35",
        51, 83008, 457952097, 155007037785419431L, -90995L, false, false, (char) 58938, (char) 34195,
        Double.longBitsToDouble(0x3fcd5604e0aafc60L), Double.longBitsToDouble(0x3fe0a955ac35a84bL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 5, 7, 15, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\ud9fa\udc61\ud9c7\udfc9\udba0\udc36\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud8cc\udd2e\udbf2\udfb1\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udbb7\udcd7\ud941\udfa0\udb94\udc9a\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\ud808\udf2d", "\u3ccc\uc89c\u11da\u3f9d", "\ud8fe\udca9\ud8f4\udd6c\udbb3\ude07\udbf2\ude2d\udb4c\udf5a\ud98b\udf7c\ud812\udc35",
        51, 83008, 457952097, 155007037785419431L, -90995L, false, false, (char) 58938, (char) 34195,
        Double.longBitsToDouble(0x3fcd5604e0aafc60L), Double.longBitsToDouble(0x3fe0a955ac35a84bL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:-15634718 |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 14, 5, 15, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\uda10\udcb5\ud962\udcad\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud92b\ude45\udb73\ude52\ud903\udd08\ud9fa\udc95\ud89c\udcc2\udba0\udc36\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud8cc\udd2e\udbf2\udfb1\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud942\udc00\udb94\udc9a\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud8f7\udefa\uda86\udcfa\ud9f1\udefd", "\u3ccc", "\udb1b\udca5\udae2\ude29\ud97c\udc60\ud8fe\udca9\ud8f4\udd6c",
        49, 84663, -141378440, -4888891059266111116L, -46672L, true, true, (char) 52574, (char) 45260,
        Double.longBitsToDouble(0x3fde060e265a4334L), Double.longBitsToDouble(0x3fd324128aee2392L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.complex.Complex:@?\0121=java.lang.Boolean:false |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud925\udc87", "\u7052\u5ae8\ud42f", "\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74",
        22, 65392, -926878813, 60590164501594112L, -93450L, false, false, (char) 18784, (char) 17920,
        Double.longBitsToDouble(0x3fe0e15d980000abL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 0, 7, 15, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc04\ud9e7\udef6\udbbf\udfce\udb81\udde0\ud889\udc74\udb73\ude52\uda06\ude6a\ud9fa\udc61\ud9c7\udfc9\udba0\udc36\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud8cc\udd2e\udbf2\udfb1\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud942\udc00\udb54\udd4a\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\000\000\u11da\u3f9d", "\ud8fe\udca9\ud8f4\udd6c\ud86e\udf2c\ud8d6\udc18\uda81\udc80\000\000",
        51, 83008, 457952097, 1625468583L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3df55f8c00000000L), Double.longBitsToDouble(0x3fe0a955ac35a84bL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.complex.Complex:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 3, 15, "\uc48e\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\ud9fa\udc61\ud9c7\udfc9\udba0\udc36\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\udadd\udf48\ud8b4\udff1\udbf2\udfb1\u5bc7\udbcf\udc40\ud86d\udc13\udaf0\udfd9\udb01\udd3d\ud942\udc00\udb94\udc9a\ud84a\ude0a\udb0c\ude23\u5a98\udbf4\udd8d\udbe2\udd88\udb1c\ude5d\ud9c8\ude58\udba0\udc8e\ud9f1\udefd", "\u3ccc\uc89c\u11da\u3f9d", "\ud8fe\udca9\ud8f4\udd6c\ud86e\udf2c\ud8d6\udc18\udb70\udff8\ud98b\udf7c\ud812\udc35",
        51, 13136, -2079873248, -1046223869773960651L, -90877L, false, false, (char) 58938, (char) 34195,
        Double.longBitsToDouble(0x3fcd5604e0aafc60L), Double.longBitsToDouble(0x3fe0a955a8aab64bL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 5, 7, 6, "\ud925\udc87\udb28\udcf3\uda96\udc91\udb72\udf5f\udb54\udd97\ud86b\udd86\uf2e5\ub4ba\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\ud8e6\udf4a\ud9c8\udc04\udba0\udc36\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\ud950\udf1d\ud8c7\udfd9\udbf2\udfb1\u5bc7\ud8fb\udfb7\udb5e\ude21\ud8a9\udcb6\ubd99\udbf7\udf10\uda62\udca1\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud8e2\ude37\ud9c8\udf44\udb7c\udf30\ud9f1\udefd", "\u6f24\uc850\u11da\u439d", "\udb09\udc98",
        52, 72619, 2118762663, -607215777297781892L, -15343L, false, false, (char) 8409, (char) 52719,
        Double.longBitsToDouble(0x3fe145b131e060e2L), Double.longBitsToDouble(0x3fe9690cd44ac428L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 2, 8, 12, "\ud925\udc87\udb28\udcf3\udb18\udcd1\uda24\udf51\ud81e\udf76\ud94c\udedd\udb39\udc56\udbd8\ude64\ud884\udce8\ud9c0\uddb6\ud80a\uded7\udb5b\udcca\udb7c\ude11\uda06\ude6a\u44cd\udaa4\udf0c\udb8b\ude7a\ud848\udeee\udbef\udff3\u9ede\ud99b\udf18\ud8fa\udd1a\ud831\udeec\udbe3\udf72\udb41\uddf0\udbf4\udd54\udbd3\udd11\udb50\udda1\uda93\udc33\ud8fb\udc01\udb5e\ude21\ud847\ude86\udb01\udd3d\ud9b4\udf79\ud8b6\ude37\ue6c1\udb33\udfd6\u668b\udb9f\udc86\uda80\udf6a\ud8fe\udfe0\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\u6c24\u1ecf\ud6e9\ub39b", "\ud8fe\udca9\udbde\udd60\udad4\udd9d\uda2f\udca6\ud97d\udc66\ud98b\udf03\ud812\udc35",
        2, 83678, 1296812897, 155007685342637735L, -90995L, false, false, (char) 58938, (char) 34195,
        Double.longBitsToDouble(0x3fcd5604e0aafc60L), Double.longBitsToDouble(0x3fe0a955ac35a84bL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 0, 7, 0, "\ud925\udc87", "\u7052\u5ae8\u3138", "\ud9e7\udef6\udbbf\udfce\000\000",
        37, 65392, -926878813, 6545773629053762615L, -93450L, false, false, (char) 18784, (char) 39833,
        Double.longBitsToDouble(0x3f25d9c20c3ab000L), Double.longBitsToDouble(0x3fd750079d4c106aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Integer:844747887 |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 14, 9, 9, "\ucf92", "\u7052\u5ae8\u2cc8", "\ud9e7\udef6\uda47\udf92\uda3f\udc35\udb9d\udce7",
        49, 65392, -926878813, 6545773629053762615L, -93450L, false, true, (char) 18784, (char) 39833,
        Double.longBitsToDouble(0x3fe0e15d9c20c3abL), Double.longBitsToDouble(0x3fd75d579d4c106aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 5, 4, 15, "\ud925\udc87\udb28\udcf3\ud893\udc35\udb89\udc5a\udb54\udd97\ud962\udd40\udb41\udd3a\ud94d\udcfc\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\udbe4\udc78\udbdf\udc32\ud823\udff8\ud86e\udfe9\ud984\udfff\ud8dd\udccb\ud9c8\ude1a\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud82d\ude96\udbf2\udfb1\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud8c1\uddfb\udb94\udc9a\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud9de\uddd1\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\u3ccc\uc89c\u11da\u3e6d", "\uda90\udd1e\ud8f4\udded\ud86e\udf2c\ud8d6\udc18\udb50\ude3f\ud98b\udf7c\ud812\udc35\ud9b4\udc67\ud9c9\udd59\udb2b\udcfc\ud9ae\ude34\uda99\udc5c\udbe8\udfda\ud87b\udfa6\ud91f\ude38\ud815\ude88\ud973\udec5\udb3d\udd16\ud928\udeae\udb67\udce9\ud81c\udcc7\ud8e6\udcfa\udae1\udd8e\ud828\udc36\udbdf\udf3d",
        5, 79531, 649224786, 8517442483872547684L, -85845L, false, true, (char) 9470, (char) 32079,
        Double.longBitsToDouble(0x3fd76642f32a25b6L), Double.longBitsToDouble(0x3fd93d57871ff768L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 7, 7, 15, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\ud8a5\udd3f\ud962\udd6f\udb39\udc56\ud984\udc85\ud9e7\udef6\udb7b\ude6c\ud828\udee0\udaa4\udd1b\ud814\udf27\ud8b8\udda5\ud9f4\uded8\ud9c7\udff2\udba0\udc36\udb8e\ude03\ud989\udc5d\ud8f5\ude07\ud9bf\udcf3\ud8e9\udc97\udb31\ude8d\udbd5\udf41\udb41\uddf0\udbf4\udd54\ud8cc\udd2e\udbf3\udc58\u5bc7\ud902\udd31\udb5e\ude21\ud847\ude86\udb01\udd3d\ud942\udc00\udb94\udc9a\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\ud8b5\udc7e", "\u3ccc\uc89c\u11da\u3f9d", "\ud8fe\udca9\udae3\udd72\ud86e\udf2c\ud8d6\udc18\udb70\udff8\ud98b\udf7c\ud812\udc35",
        51, 83008, 457952097, 155007037421652827L, -65146L, false, false, (char) 58938, (char) 34195,
        Double.longBitsToDouble(0x3fcd5604ecaafc60L), Double.longBitsToDouble(0x3fe0af7a2c35a84bL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 8, 8, 5, "\ud925\udc87\ud828\udd52\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\u49d4\udb2e\udcd5\ud8d8\udd99\ud8c5\udc74\udaaa\udc5c\uda03\ude72\ud9f3\ude61\ud9c7\udfc9\u6c35\ud8dc\udc28\uda7e\uddeb\uda0f\udd76\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\ud9e5\udd0b\ud9d8\udc2e\udbf2\udfc0\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud942\udc00\udb94\udc9a\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud83d\udcc4\ud9c8\udf44\udba0\udc8e\ud8b5\udc7e", "\u3ccc\u8397\u6c56\u3f9d", "\ud8fe\udca9\ud8f4\udd6c\ud86e\udf2c\ud958\udd7a\ud90c\udc24\ud981\udc64\u7f3c",
        1, 83129, 457952097, 155007037047754663L, 16087L, false, true, (char) 16657, (char) 14147,
        Double.longBitsToDouble(0x3fe0a955ac35a84bL), Double.longBitsToDouble(0x3fc6026c4f62d75cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 9, "\ud925\udc2b\udb28\udcf3\udb18\udcd1\ud8d8\udecf\ua4a5\ud990\udd17\ud9d3\udcb9\udaac\udc47\u7930\udb76\udda6\ud8de\udc97\ud912\udc12\udb5b\udc99\uda06\ude6a\ud9a9\udfa8\ud913\uddb2\ud938\udf9b\ud97c\udcb3\udb66\udfb3", "\u31da\u5da6\u016f\u3f2f\u13ba\ua120\u605a\uccca\u9d98\u0f07\ub01c\u35c1\u4928\ud298\u0c91\u0b66\u510e\u620f\ucea5\u0da2\u0b9c\u9de5\uc210\u54ea\ubf4e", "\ud827\udf45\ud9f2\udf52\udb83\udeab",
        28, 58021, -598347760, 6970775233836090379L, -80879L, true, false, (char) 3263, (char) 52574,
        Double.longBitsToDouble(0x3fe5381133e060e2L), Double.longBitsToDouble(0x3fc51cfa72a6c5f0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 9, 9, 9, "\ud925\udc87\udb28\udcf3\udb18\udcd1\ud8d8\udecf\ua4a5\ud990\udd17\ud9d3\udcb9\udaac\udc47\u7930\udb76\udda6\ud8de\udc97\ud912\udc12\udb5b\udc99\uda06\ude6a\ud9a9\udfa8\ud913\uddb2\ud938\udf9b\ud97c\udcb3\udb66\udfb3", "\u3252\u5da6\u016f\u3f2f\u13ba\ua120\u605a\uccca\u9d98\u0f07\ub01c\u35c1\ub827\u850f\u0c91\u0b66\u510e\u4a5b\u81c5\ube11\u2974\u4891\u5dd4\u9c47\u39ad", "\ud827\udf45\ud9f2\udf52\udb83\udeab",
        28, 58021, -598347760, 6970775233836090379L, -56405L, false, true, (char) 41003, (char) 40518,
        Double.longBitsToDouble(0x3feb0a0af2141b4bL), Double.longBitsToDouble(0x3fe5381133e060e2L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 6, 6, 9, "\ud925\udc87\uda01\udc00\udb18\udcd1\ud8d8\udecf\ua4a5\ud833\udcc2\ud9d3\udc6c\udaac\udc47\ud9e4\udc51\udb76\ude57\ud8de\udc97\ud912\udc12\ud99b\udc99", "\u0116\u8545\u8f11\u7ef4\u67ba\u90a7", "\ud932\ude99\ud97e\udfbf\uda34\udcb4\ud87a\udd26\ud9f0\udfee\uda94\udf48\ud8fb\udfb7\udb5e\ude0b\udb70\udf01\udb01\udcf1\ud942\udc00\ud870\udde8\udaa1\udd00\ud915\udfc8\ud805\udf2e\ud9b7\udd8e\ud92f\uddab\udac0\udc69\udb95\udfb5\ud886\udc47\udb3d\ude6c\ud9b3\udd81\u9b95\udb05\udd15\ud9eb\udeb7",
        -3, 36418, -777459353, -6264669865187487611L, 85564L, true, false, (char) 50630, (char) 33026,
        Double.longBitsToDouble(0x3fd74bc27345d5b8L), Double.longBitsToDouble(0x3fc37d5bf574d830L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:127473622 |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 14, 2, 5, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\ud9fa\udc61\ud9c7\udfc9\udba0\udc36\ud848\udeee\udb42\ude6e\uda0f\udd25\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud8cc\udd2e\udbf2\udfb1\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud942\udc00\udb94\udc9a\ud84a\ude0a\udb0c\ude2a\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\u4a11\uc8c1\u0a48\u3f9d\u0bfc\u28af", "\ud86e\udf2c\ud820\udc1d\udb70\udff8\ud98b\udf7c\ud812\udc35\udb22\udc48\ud9c9\udd59\udb2b\udcfc\ud9ae\ude34",
        58, 9352, -1004002515, 2361016820826752375L, -36645L, true, false, (char) 7050, (char) 50548,
        Double.longBitsToDouble(0x3fe999202d17eacfL), Double.longBitsToDouble(0x3fecd1426d508cfdL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 2, 4, 15, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb4d\udfa6\ud984\udcdf\u4c66\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\ud9fa\udc61\ud9c7\udfc9\udba0\udc36\ud848\udeee\udb42\ude6e\uda0f\udd25\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\u1935\ud94e\ude3a\u3b7e\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud942\udc00\udb94\udc9a\ud84a\ude0a\udb0c\ude2a\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\u1a12\uc8c1\u0a48\u3f9d\u0bfc\u28af", "\ud86e\udf2c\ud820\udc1d\udb70\udff8\ud98b\udf7c\ud812\udc35\udb22\udc48\ud9c9\udd59\udb2b\udcfc\ud9ae\ude34",
        58, 9352, -1004002515, 2361016820826752375L, -36645L, true, false, (char) 46316, (char) 50548,
        Double.longBitsToDouble(0x3fe999202d17eacfL), Double.longBitsToDouble(0x3fecd1426d508cfdL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 11, 11, 15, "\ud925\udc87\udb28\udcf3\udaea\uded1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\ud9fa\udc61\ud9c7\udfc9\udba0\udc36\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud9a9\udf18\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\ud9d3\udc15\ud8cc\udd2e\udbf2\udfb1\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud942\udc00\ud8f2\udd08\ud8e8\udf07\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\uda32\udd88\ud90c\ude8f\udba0\udc58\ud9f1\udefd", "\u3ccc\uc89c\u11da\u3f9d", "\udaca\udcaf\ud8f4\udd6c\ud86e\udf2c\ud954\udc17\udb80\udf9d\ud98b\udf7c\ud812\udc35",
        51, 83008, 457952097, 155007037785419431L, -90995L, false, false, (char) 58938, (char) 34195,
        Double.longBitsToDouble(0x3fcd5604e0aafc60L), Double.longBitsToDouble(0x3fe0a955ac35a84bL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.complex.Complex:@?\0121=java.lang.Boolean:false |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 0, 0, 15, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\ud9fa\udc61\ud9c7\udfc9\udba0\udc36\ud848\udeee\uda7e\uddeb\ud809\udd72\ud9a9\udf18\ud8e8\ude93\udb31\ude8d\udb30\ude97\udb41\uddf0\ud9bf\udd78\ud8cc\udd2e\udbf2\udfb1\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud942\udc00P\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\u3ccc\uc89c\u11da\u3f9d", "\ud8fe\udca9\ud8f4\udd6c\ud865\udd2c\ud8d6\udc18\udb70\udff8\ud98b\udf7c\ud812\udc35",
        51, 83008, 457952097, 155007037785419431L, -90995L, false, false, (char) 58938, (char) 34195,
        Double.longBitsToDouble(0x3fcd5604e0aafc60L), Double.longBitsToDouble(0x3fe0a955ac35a84bL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 5, 5, 13, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\udb5e\udd5e\uda31\udec6\uda21\uddcd\ud9fa\udc61\ud9c7\udfc9\udba0\udc3d\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud89f\ude14\ud8fa\udc9e\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud8cc\udd2e\udbf2\udfb1\ud8dc\udc89\ud8fb\udf60\udb5e\ude21\ud847\ude86\udb01\udd3d\ud8ed\ude96\udb94\udc9a\ud84a\ude0a\uda1a\udeec\u668b\udb37\uddd2\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\udb44\udc39", "\u3ccc\uc89c\u11da\u3f9d\u0bfc\u28af\ubb5e\u2a88\u873b\ubc84\u6691\u4b12\uc865\ud0a3\u3771\ud3ba\u94a0\u417b\u11b4\uac95\u731f\ud2ea", "\ud928\udeae",
        -2, 7261, 615155204, -7245250903316312827L, 78486L, true, true, (char) 1449, (char) 10645,
        Double.longBitsToDouble(0x3fee4b930f056bb1L), Double.longBitsToDouble(0x3fc9411c92c677a0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 5, 5, 15, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\udb5e\udd5e\uda31\udec6\uda21\uddcd\ud9fa\udc61\ud9c7\udfc9\udba0\udc3d\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud89f\ude14\ud8fa\udc9e\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud8cc\udd2e\udbf2\udfb1\ud8dc\udc89\ud8fb\udf60\udaf9\udc22\ud83a\uddcf\udb01\udd3d\ud8ed\ude96\udb94\udc9a\u8356\uda1a\udeec\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\udb44\udc39", "\u3ccc\uc89c\u11da\u3f9d\u0bfc\u28af\ubb5e\u2a88\u873b\ubc84\u6691\u4b12\uc865\ud0a3\u3771\ud3ba\u94a0\u417b\u11b4\uac95\u731f\ud2ea", "\ud928\udeae",
        -2, 7261, 615155204, -7245250903316312827L, 78486L, true, true, (char) 1449, (char) 10645,
        Double.longBitsToDouble(0x3fee4b930f056bb1L), Double.longBitsToDouble(0x3f9e5c3551cc1e80L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.complex.Complex:org.apache.commons.math.complex.Complex@0\0121=java.lang.Boolean:false |this=org.apache.commons.math.complex.Complex:org.apache.commons.math.complex.Complex@0\012",
        Z.run(T, 2, 0, 0, 0, "", "\u3292", "\ud86e\udfa7\ud96a\udd75\ud984\udc85\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74",
        22, 46960, -926878813, 60590164501594112L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 2, 2, 14, "\ud925\udc87\udb28\udcf3\udb18\udcd1\ud92d\udd55\ud81e\udf68\ud94c\udedd\udb39\udc56\udbd8\ude64\ud884\udce8\ud9c0\uddb6\ud80a\uded7\udb5b\udcca\udb7c\ude11\uda06\ude6a\u44cd\udaa4\udf0c\udb8b\ude7a\ud848\udeee\udbef\udff3\u9ede\ud99b\udf18\ud8fa\udd1a\ud831\udeec\udbe3\udf72\udb41\uddf0\udbf4\udd54\udbd3\udd11\udb50\udda1\uda93\udc33\ud8fb\udc01\udb5e\ude21\ud847\ude86\udb01\udd3d\ud9b4\udf79\ud959\udc87\ue6c1\udb33\udfd6\u668b\udb9f\udc86\uda80\udf6a\ud8fe\udfe0\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\u6c24\ucd5b\u8740\ub3d4", "\ud9a4\udc58\ud8ab\ude3b\ud9c0\ude02\ud819\udfd7\ud97d\udc66\ud98b\udf03\udabb\udcd7",
        2, 83678, 1296812897, 155007685342637735L, -90995L, false, true, (char) 58984, (char) 34195,
        Double.longBitsToDouble(0x3fcd5604e0aafc60L), Double.longBitsToDouble(0x3fe0a955ac35a84bL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 5, 4, 15, "\ud925\udc87\udb28\udcf3\ud893\udc35\udb89\udc5a\udb54\udd97\ud962\udd40\udb41\udd3a\ud94d\udcfc\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\udbe4\udc78\udbdf\udc32\ud823\udff8\ud86e\udfe9\ud984\udfff\ud8dd\udccb\ud801\udd17\ud8e8\ude93\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud82d\ude96\udbf2\udfb1\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud8c1\uddfb\udb94\udc9a\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud9de\uddd1\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\u3ccc\uc89c\u11da\u3e6d", "\uda90\udd1e\ud8f4\udded\ud86e\udf2c\ud8d6\udc18\udb50\ude3f\ud98b\udf7c\ud812\udc35\ud9b4\udc67\ud9c9\udd59\udb2b\udcfc\ud9ae\ude34\uda99\udc5c\udbe8\udfda\ud87b\udfa6\ud91f\ude38\ud815\ude88\ud973\udec5\udb3d\udd16\ud928\udeae\udb67\udce9\ud81c\udcc7\ud8e6\udcfa\udae1\udd8e\ud828\udc36\udbdf\udf3d",
        5, 79531, 649224786, 8517442483872547684L, -85845L, false, true, (char) 9470, (char) 32079,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd93d57871ff768L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 4, 4, 15, "\udb96\udd51\udb51\udcb5\ud8f1\udc44\udb89\udc5a\udb54\udd97\ud962\udd40\u125e\ud94d\udcfc\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\udbe4\udc78\udbdf\udc32\ud823\udff8\ud86e\udfe9\ud984\udfff\ud958\udfa8\ud9a5\udd3b\ud8fa\udd1a\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud83e\uded4\udaac\udfe3\u5c00\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud8c1\uddfb\udb94\udc9a\ud84a\ude0a\udb0c\ude23\ud87d\udd1d\uda56\udc55\udbce\udec7\ud9de\udd76\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\u1d75\u01c5", "\ud86d\ude9e\ud98d\udfe3\ud91f\udce3\ud8f4\udded\ud86e\udf2c\ud938\udcb8\udbba\uddef\ud98b\udf7c\udbca\udc31\ud9b4\udc67\udab9\udcd1\udb2b\udd6a\ud9ae\ude34\uda76\ude2b\udbe8\udfda\ud87b\udfa6\ud91f\ude38\ud815\ude88",
        6, 71922, -1464502230, -1499591216484956877L, 71000L, true, false, (char) 34473, (char) 60998,
        Double.longBitsToDouble(0x3fe29c927a52ebebL), Double.longBitsToDouble(0x3fca04d64d91d8d0L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 2, 2, 14, "\ud925\udc87\udb28\udcf3\udb18\udcd1\ud92d\udd55\ud81e\udf68\ud94c\udedd\udb39\udc56\udbd8\ude64\ud884\udce8\ud9c0\uddb6\ud80a\uded7\udb5b\udcca\udb7c\ude11\uda06\ude6a\u44cd\udaa4\udf0c\udb8b\ude7a\ud848\udeee\udbef\udff3\u9ede\ud99b\udf18\ud8fa\udd1a\ud831\udeec\udbe3\udf72\udb41\uddf0\udbf4\udd54\udbd3\udd11\udb50\udda1\uda93\udc33\ud8fb\udc01\udb5e\ude21\ud847\ude86\udb01\udd3d\ud9b4\udf79\ud959\udc87\ue6c1\udb33\udfd6\u668b\udb9f\udc86\uda80\udf6a\ud8fe\udfe0\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\u6c24\ucd5b\u8740\ub3d4", "\udafd\ude25\ud8ab\ude94\ud9c0\ude02\ud819\udfd7\ud97d\udc66\ud98b\udf03\udabb\udcd7",
        40, 83678, 1296812897, 155007685342637735L, -90995L, false, true, (char) 58984, (char) 34195,
        Double.longBitsToDouble(0x3fe75581382abf18L), Double.longBitsToDouble(0x3fe0a955ac35a84bL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:-486184275 |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 14, 7, 15, "\ud925\udc87\udb28\udcf3\uda5f\uded4\ud8e8\udc35\udb52\udd1f\ud962\udd40\udb39\udc56", "\u53e2\u0c3d\uc76a\u0ba1", "\ud9c7\udfc9\udba0\udc36\ud848\udeee\uda7e\uddeb\uda0f\udd76\ud9a9\udf18",
        27, 32356, 746150944, 591420108996959910L, -1526L, true, false, (char) 3234, (char) 15149,
        Double.longBitsToDouble(0x3fe52d230e3eb36fL), Double.longBitsToDouble(0x3fc361e52a1a6b28L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\0121=org.apache.commons.math.complex.Complex:@? |this=org.apache.commons.math.complex.Complex:@?\012",
        Z.run(T, 2, 5, 5, 15, "\ud925\udc87\udb28\udcf3\ud893\udc35\ud8a0\ude86\udb3c\ude0d\ud96c\udda6\uda37\udfe5\ud94d\udcfc\ud9e7\udef6\uda47\udf92\uda3f\udc35\ud889\udc74\udb73\ude52\uda06\ude6a\udbe4\udc78\udbdf\udc32\ud823\udff8\ud86e\udfe9\ud984\udfff\ud8dd\udccb\ud801\udd17\ud8e8\ude93\udb31\ude8d\udbd5\udebe\udb41\uddf0\udbf4\udd54\ud82d\ude96\udbf2\udfb1\u5bc7\ud8fb\udfb7\udb5e\ude21\ud847\ude86\udb01\udd3d\ud8c1\uddfb\udb94\udc9a\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud9de\uddd1\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\u3ccc\uc89c\u54ae\u9507", "\uda90\udd1e\ud8f4\udded\ud86e\udf2c\ud8d6\udc18\udb50\ude3f\ud98b\udf7c\uda2f\udd24\udb18\udedf\ud9c9\udd8e\udb2b\udcfc\ud9ae\ude34\uda99\udc5c\udbe8\udfda\ud87b\udfa6\ud91f\ude38\ud815\ude88\ud82f\udde3\udb3d\udc2c\ud928\udeae\udb67\udce9\ud81c\udcc7\ud8e6\udcfa\udae1\udd8e\ud828\udc36\udbdf\udf3d",
        5, 79531, 649224786, 8517442483872547684L, -85845L, false, true, (char) 9470, (char) 32079,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd93d57871ff768L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.complex.Complex:org.apache.commons.math.complex.Complex@0\0121=java.lang.Double:0.0 |this=org.apache.commons.math.complex.Complex:org.apache.commons.math.complex.Complex@0\012",
        Z.run(T, 2, 0, 1, 8, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc04\ud9e7\udef6\udbbf\udfce\udb81\udde0\ud889\udc74\udb73\udd6a\uda06\ude6a\ud9fa\udc61\ud9c7\udfc9\udba0\udc36\ud848\udeee\uda7e\uddeb\ud922\udfe4\uf24e\udbcd\udda3\udb5c\udd55\udb7a\udf51\udb41\uddf0\udbf4\udd54\ud8cc\udd2e\udbf2\udfb1\u5bc7\ud8fb\udfb7\udb5e\ude21\uda05\udcca\ud8fb\udcc8\ud941\udfa3\udb54\udd4a\ud84a\ude0a\udb0c\ude23\u668b\udb9f\udc86\udab1\uddf0\ud9de\ude35\ud9c8\udf44\udba0\udc8e\ud9f1\udefd", "\000\000\u11da\uc219", "\ud8f2\udc17\ud8f4\udd6c\ud86e\udf2c\ud8d6\udc18",
        9, -1000, 837222012, 2365402181134766160L, -100000L, true, false, (char) 24802, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math.complex.Complex:org.apache.commons.math.complex.Complex@0\0121=java.lang.Double:0.0 |this=org.apache.commons.math.complex.Complex:org.apache.commons.math.complex.Complex@0\012",
        Z.run(T, 2, 1, 1, 8, "\ud925\udc87\udb28\udcf3\udb18\udcd1\udb7f\udf9e\udb54\udd97\ud962\udd40\udb39\udc56\ud984\udc04\ud9e7\udef6\udbac\ude73\uda61\udd2f\ud9ce\udf9c\ud99c\udc1b\udaca\udc26\ud8f5\udfc7\udacb\ude64\udbac\udd89\ud848\udeee\uda7e\uddeb\ud922\udfe4\uf24e\udbcd\udda3\udb5c\udd55\udb7a\udf51\udb41\uddf0\udbf4\udd54\ud8bd\udfe7\ud95c\udfbc\udb9b\ude15\ud8fb\udfb7\udb5e\ude21\uda05\udcca\ud8fb\udcc8\ud941\udfa3\udb54\udd4a\ud89a\ude00\udb0c\ude23\u668b\udb9f\udc86\udb3b\udff6\udaec\udd66\udbbe\udce9\udba0\udc8e\udbd5\udd48", "\000\000\u11da\uc219", "\ud8f2\udc17\ud8f4\udd6c\ud86e\udf2c\ud8d6\udc18",
        9, -1000, 837222012, 2365402181134766160L, -100000L, true, false, (char) 24802, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.complex.Complex|equals|java.lang.Object|new:org.apache.commons.math.complex.Complex:double,double",
    "M|org.apache.commons.math.complex.Complex|abs||new:org.apache.commons.math.complex.Complex:double,double",
    "M|org.apache.commons.math.complex.Complex|acos||new:org.apache.commons.math.complex.Complex:double,double",
    "M|org.apache.commons.math.complex.Complex|add|org.apache.commons.math.complex.Complex|new:org.apache.commons.math.complex.Complex:double,double",
    "M|org.apache.commons.math.complex.Complex|asin||new:org.apache.commons.math.complex.Complex:double,double",
    "M|org.apache.commons.math.complex.Complex|atan||new:org.apache.commons.math.complex.Complex:double,double",
    "M|org.apache.commons.math.complex.Complex|conjugate||new:org.apache.commons.math.complex.Complex:double,double",
    "M|org.apache.commons.math.complex.Complex|cos||new:org.apache.commons.math.complex.Complex:double,double",
    "M|org.apache.commons.math.complex.Complex|cosh||new:org.apache.commons.math.complex.Complex:double,double",
    "M|org.apache.commons.math.complex.Complex|createComplex|double,double|new:org.apache.commons.math.complex.Complex:double,double",
    "M|org.apache.commons.math.complex.Complex|divide|org.apache.commons.math.complex.Complex|new:org.apache.commons.math.complex.Complex:double,double",
    "M|org.apache.commons.math.complex.Complex|exp||new:org.apache.commons.math.complex.Complex:double,double",
    "M|org.apache.commons.math.complex.Complex|getImaginary||new:org.apache.commons.math.complex.Complex:double,double",
    "M|org.apache.commons.math.complex.Complex|getReal||new:org.apache.commons.math.complex.Complex:double,double",
    "M|org.apache.commons.math.complex.Complex|hashCode||new:org.apache.commons.math.complex.Complex:double,double",
    "M|org.apache.commons.math.complex.Complex|isInfinite||new:org.apache.commons.math.complex.Complex:double,double",
    "M|org.apache.commons.math.complex.Complex|equals|java.lang.Object|new:org.apache.commons.math.complex.Complex:double,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
