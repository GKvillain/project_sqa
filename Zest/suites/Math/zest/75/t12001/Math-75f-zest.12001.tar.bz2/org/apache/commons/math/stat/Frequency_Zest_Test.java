package org.apache.commons.math.stat;
import org.junit.Test;
import static org.junit.Assert.*;
public class Frequency_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-707141270295516612\0111\011100%\011100%\012\012",
        Z.run(T, 2, 16, 10, 11, "\u6c28", "\u379d\u504a\uc848\u0dba\u2143\uc6b2\ubc38\u68bd\ua9de\ucaf2\u985f", "\ud8fb\udf94\ud984\udce1\ud92a\udf66\uda38\udc42\ud880\udc8e\uda84\udea7\ud9b2\udd11\ud9b9\udcf6",
        -3, 24913, -1100027412, -707141270295516612L, -65835L, false, true, (char) 55550, (char) 57186,
        Double.longBitsToDouble(0x3fdab2147e13d312L), Double.longBitsToDouble(0x3fed91a11679166cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-707141270295516612\0111\011100%\011100%\012\012",
        Z.run(T, 2, 16, 10, 11, "\u6c28", "\u379d\u504a\uc848\u0dba\u2143\uc6b2\ubc38\u68bd\ua9de\ucaf2\u985f", "\ud8fb\udf94\ud984\udce1\ud92a\udf66\uda38\udc42\ud880\udc8e\uda84\udea7\ud9b2\udd11\ud9b9\udcf6",
        -3, 24913, -1100027412, -707141270295516612L, -91992L, false, true, (char) 32498, (char) 18579,
        Double.longBitsToDouble(0x3fed91a11679166cL), Double.longBitsToDouble(0x3fd13e311aa9b018L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01215\0111\011100%\011100%\012\012",
        Z.run(T, 2, 12, 6, 12, "\u6c28", "\u8a78\u3b14\uc848\ubd32\u40d7\u7a01\u4353\u0efc\u8fcb\ucaf2\u209c", "\ud8fb\udf94\ud984\udce1\ud92a\udf66\uda38\udc42\ud880\udc8e\uda84\udea7\ud94c\ude1f\ud93a\ude2b",
        15, 8308, -1100027412, -707141270295516612L, -65835L, false, true, (char) 55550, (char) 57186,
        Double.longBitsToDouble(0x3fdab2147f68841cL), Double.longBitsToDouble(0x3fed91a11679166cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-707141270295516612\0111\011100%\011100%\012\012",
        Z.run(T, 2, 4, 10, 6, "\u6c28", "\u379d\u504a\u2139\u0d99\u2143\uc6b2\ubc38\u68bd\ua9de\ucaf2\u2845", "\udb96\udd26\ud985\ude1e\ud92a\udf66\uda38\udc42\ud880\udc8e\uda84\udea7\ud997\udd89\udae9\udcee",
        42, 24913, -1100027412, -707141270295516612L, -65835L, false, true, (char) 55550, (char) 57186,
        Double.longBitsToDouble(0x3fdab2147e13d312L), Double.longBitsToDouble(0x3fed91a11679166cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-556635302211362632\0111\011100%\011100%\012\012",
        Z.run(T, 2, 1, 10, 9, "\u6c28\udbd7\ude49\ud9f0\ude16\ud990\udd22\ud8f3\udf95\ud917\ude43\udade\udef7\ud90e\udc85\udb9b\udea6\ud8e1\udd71\ud9f9\udc95\ud8c9\udf02", "\u90d8\u6988\ua824\u68f1\u8661\ub646\u9de7\u38a2", "\udaf1\udd8e\udbad\udd18\udb13\udc24\udbc6\ude2e",
        18, 79283, 129202827, -556635302211362632L, -76021L, false, false, (char) 6553, (char) 1253,
        Double.longBitsToDouble(0x3fe4e051e245cd96L), Double.longBitsToDouble(0x3fef291e1aaa93c4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 16, 1, 6, "\ud858\ude0c", "\u379d\u504a", "\udb89\udf96\ud8de\ude41\ud93c\udefd\ud8cd\udefb\udbbf\ude3c\ud8a5\ude2c",
        57, 87460, -463821614, -4879971727125842818L, 50978L, false, false, (char) 11129, (char) 7854,
        Double.longBitsToDouble(0x3fef42cca07e11edL), Double.longBitsToDouble(0x3fee092e49ece759L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 12, 16, 17, "\u6c28\ud8a3\udf4e\ud9fc\udcae\udb22\udf61\udb01\udc09\ud88d\udd84\udb17\udf93\udb89\udf96\ud8de\ude41\uda19\udcab\ud8a8\ude4b\udbbf\ude3c\ud95e\ude08\udb7e\udf83\ud8d1\udfab\ud947\ude3a\ud8fb\udf94\ud984\udce1\ud92a\udf66\uda38\udc42\ud880\udc8e\uda84\udea7\ud9b2\udd11\ud9b9\udcf6\ud8ac\udf6d\ud835\uddb7\udb3f\ude0e\udbc6\ude2e\uda92\udc77", "\u25fc\u1722\u129e\u0b9a", "\ud92f\udc83\udad0\udffb\uda07\ude63\uda90\udd67",
        37, 42824, -1258563225, -4690563360663611177L, -73310L, true, true, (char) 14805, (char) 11573,
        Double.longBitsToDouble(0x3fc9a3e7e5d94c80L), Double.longBitsToDouble(0x3fd83316c718f582L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 12, 18, 16, "\u6c28", "\u379d\u504a\uc848\u0dba\u2143\uc6b2\ubc38\u68bd\uc192\uca78\u985f", "\ud8fb\udf94\ud984\udce1\ud92a\udf66\ud97c\udc24\ud880\udd24\ueaa2\ud9ab\udf0b\ud9b9\udcf6",
        -3, 24913, -1100027412, -707141270295516612L, -65835L, false, true, (char) 2120, (char) 56172,
        Double.longBitsToDouble(0x3fdab2147e13d312L), Double.longBitsToDouble(0x3fed91a11679166cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 2, 11, 7, "\udb8f\udd42\uda71\udcb8\ud9fc\udcae", "\uc530\u0d13\u2943\uc6b2\ubc38\u68bd\u7821\ua398\u98d4\u6d24\ubc13\uc34d\u5cc3\ubbae\u49bd\u3a2e\u3359\ua34a\u5927\u00f4\u9289\u3286\u5f21\ub6b2\u5201\u0960\u65fc\uc4cf\u6095\u9ee0\ub932\u7f5d\u4b3b\u5aa1\u7efd\u43b8", "\udb9e\udc2f\ud9f6\ude58\ud9d2\udcd1",
        2, 24099, -1038907091, 3413107679942560845L, 50631L, false, true, (char) 2643, (char) 24572,
        Double.longBitsToDouble(0x3fb727caaf9b3818L), Double.longBitsToDouble(0x3fdb3d762b8fb25cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-9124885803272683982\0111\011100%\011100%\012\012",
        Z.run(T, 2, 16, 10, 7, "\u6c28\ud8a3\udf4e\ud9fc\udcae\udb22\udf61\ud9a5\udfbc\udbd7\udcad\ud97d\ude69\u9c0f\ud8e9\udc83\ud93c\udefd\ud8da\udce4\udbbf\ude3c\ud8a5\ude2c\udb6e\udd0b\ud8d1\udfab\udba6\udf36\ud8fb\udf94\ud984\udce1\ud92a\udf66\uda8f\udc0f\ud92d\udfb1\uda84\udea7\ud9b2\udd11", "\u9289\u2c36\u5f21\ub6b2\u5201\u52fd\u25fc", "\ud833\udc58\ud9fe\ude1b\ud8f1\udd04\ud96f\ude12\uda29\udfaa\ud98e\udcc5\udb57\udc85\udae2\udd00",
        36, 55254, 1701672581, -9124885803272683982L, -78060L, true, false, (char) 26490, (char) 33190,
        Double.longBitsToDouble(0x3fdc2244fc6c15b0L), Double.longBitsToDouble(0x3fe081d91925c31cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 12, 19, 19, "\udb1e\udd69\ud8a3\udf4e\ud9f3\udfae\udb22\udf61\udb01\udc09\u038d\udb17\udf93\udb8d\udd96\ud8de\ude41\ud93c\udefd\u4594", "\u4ffa\ub08f\uad43\uc349\u33db\u083d\uc3db\uc2d4\ub73e\u531f\u5927\u9d46\u9289\u2c36\u5f21\ub6b2\ua100\uad29\u2f1d", "\ud8af\udddd\u1ae7\ud8f1\udd04\u9ace\udabf\ude69\ud821\udd18\uda6f\udca4\ud8e4\udc49",
        49, 21564, -1629945752, -5375293673998402954L, -78325L, true, true, (char) 29191, (char) 62422,
        Double.longBitsToDouble(0x3fd994cc504a9f0cL), Double.longBitsToDouble(0x3fda50e2cbadd2e2L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-3\0111\011100%\011100%\012\0121=java.lang.Double:0.0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-3\0111\011100%\011100%\012\012",
        Z.run(T, 2, 8, 18, 11, "\u6c28", "\u379d\u504a\uc848\u6f80\u2143\uc6b2\ubc38\u68bd\ua9de\ucaf2\u985f", "\udaae\uddf1\ud984\udcd6\ud92a\udf66\uda38\udc42\ud880\udc8e\uda84\udea7\ud9b2\udd11\ud9b9\udcf6",
        -3, 24913, -1100027412, -707141270295516612L, -65835L, false, true, (char) 55550, (char) 57186,
        Double.longBitsToDouble(0x3fe5590a3ff44221L), Double.longBitsToDouble(0x3fed91a11679166cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \0125\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \0125\0111\01150%\01150%\0122722760767032618945\0111\01150%\011100%\012\012",
        Z.run(T, 2, 8, 10, 11, "\u6c28\ud8a3\udf4e\ud9fc\udcae\udb22\udf61\udb01\udc09", "\u2143\uc6b2\ubc38\u68bd\ua9de\ucaf2", "\udba6\udf36\ud8fb\udf94\ud984\udce1\ud92a\udf66\uda38\udc42\ud880\udc8e",
        5, 24290, 300772328, 2722760767032618945L, -82275L, false, false, (char) 55919, (char) 26530,
        Double.longBitsToDouble(0x3fe9203d98b8f846L), Double.longBitsToDouble(0x3fd244e3fb56428eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \0129\0111\011100%\011100%\012\012",
        Z.run(T, 2, 17, 6, 11, "\u6c28", "\u49fd\u504a\uc848\u0dba\u25b4\uc6b2\ubc38\u68bd\ua9de\u7048\u7b4e\u6d24\u26bf\ubdaf\u33db\u083d\u4345\u28e9\u00c8\ua5f5\u5927\u9d46\u9289\u2c36\u5f21\u7667\ub47e", "\ud9f3\udd54\ud812\udf1a\ud833\udc58\ud9fe\ude1b\ud8f1\udd04\ud994\uddfe\ud874\udfbc\uda14\udf78\uda21\udfd1\ud880\udf91\udaa8\ude52\udab3\udf81\ud840\udcd2\udbbf\udf66",
        9, 39622, 475482062, -6421409045979797268L, -65717L, true, true, (char) 30310, (char) 56468,
        Double.longBitsToDouble(0x3fea44348e7be651L), Double.longBitsToDouble(0x3fcd7ca0fa808940L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 0, 0, 6, "\ud8be\udda3", "\u379d\u504a\uc848\u0dba\u21a0\uc6a2\ubc38\u68bd\ua9de\ucaf2\u985f", "\ud8fb\udf94\ud90a\udce4\ud92a\udf66\uda38\udc93\ud880\udc8e\uda84\udea7\ud9b2\udd11\ud9b9\udcf6",
        -3, 24913, 1676798861, -5445168650155951679L, -75053L, false, true, (char) 55550, (char) 10717,
        Double.longBitsToDouble(0x3fdab969be13d312L), Double.longBitsToDouble(0x3fed91a11679166cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 16, 14, 11, "\u6c28", "\u379d\u504a\uc848\u0dba\u2143\uc6b2\ubc38\u68bd\ua9de\ucaf2\u985f", "\ud8fb\udf94\ud984\udce1\ud92a\udf66\uda38\udc42\ud880\udc8e\uda84\udea7\ud9b2\udd11\ud9b9\udcf6",
        -3, 24913, -1100040038, -707141270295516612L, -65835L, false, true, (char) 55550, (char) 38573,
        Double.longBitsToDouble(0x3fdab2147e13d312L), Double.longBitsToDouble(0x3fed91a11679166cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Boolean:false |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 16, 12, 4, "\u6c28", "\u379d\u504a\uc848\u0dba\u663f\000\000\000\000 \000", "\ud880\udf96",
        -5, -1000, 0, 49152L, -6840L, false, false, (char) 38282, (char) 53573,
        Double.longBitsToDouble(0x3fe61df3723cf62fL), Double.longBitsToDouble(0x3fbaf88110000000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 1, 16, 10, 11, "\ud985\udd6e", "\u379d\u504a\uc848\u0dba\u2143\uc6b2\ubc62\u68bd\ua9ee\ucaf2\u985f\u4724\ubc13\uc34d\u33db", "\ud925\udd41\uda84\udea7\ud9b2\udd11\ud9b9\udcf6\ud802\udeb8\ud835\ude4d\udb3f\ude0e\udbc6\ude2e\uda92\udc77\udac3\udf4d\ud888\udeff\ud9b3\udeaf\ud9f3\udd54\ud812\udf1a",
        13, 6785, 376187826, -3002512849664254626L, 25637L, false, false, (char) 39176, (char) 13431,
        Double.longBitsToDouble(0x3fe3524b8cfc8c36L), Double.longBitsToDouble(0x3fe79225e2e9b637L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-707141270295516612\0111\011100%\011100%\012\012",
        Z.run(T, 2, 13, 10, 11, "\u6c28", "\u379d\u504a\uc848\u0dba\u2143\uc6b2\u4854\u0aff\u3f3f\u35af\u985f", "\ud966\udeb7\ud86e\udf58\uda9d\udd5e\uda13\udd79\ud960\udcb7\ud8a4\udd01\ud9b2\udd11\ud934\ude53",
        33, 55993, -1100027412, -707141270295516612L, -65835L, false, true, (char) 55550, (char) 57186,
        Double.longBitsToDouble(0x3fdab2147e13d312L), Double.longBitsToDouble(0x3fed91a11679166cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\uf4ac\0111\011100%\011100%\012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\uf4ac\0111\011100%\011100%\012\012",
        Z.run(T, 2, 5, 14, 13, "\ud86e\udf91", "\u51aa\u5f92\u8646\u9643\u0c2a\uba5b\ubf82\u40bd", "\udbe7\uddd3",
        51, 70392, -1136206958, -4416073562872566681L, -62558L, false, true, (char) 62636, (char) 50556,
        Double.longBitsToDouble(0x3fbf847b52820e48L), Double.longBitsToDouble(0x3fdeb42735877cdcL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-707141270295516612\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012-707141270295516612\0112\011100%\011100%\012\012",
        Z.run(T, 2, 10, 10, 11, "\u6c28", "\u6ae0\u68c0\uc847\u0dba\u2143\uc6b2\ubc38\u68bd\ua9de\u2d52\u2b4d", "\ud8fb\udf94\ud984\udce1\ud92a\udf66\uda38\udc42\ud414\ud928\udc57\ud9b2\udd11\ud9b9\udcf6",
        -3, 24913, -1100027412, -707141270295516612L, -45639L, false, true, (char) 55550, (char) 57186,
        Double.longBitsToDouble(0x3fdab2147e13d312L), Double.longBitsToDouble(0x3fed91a11679166cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u6c65\0111\011100%\011100%\012\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 9, 10, 17, "\u6c65", "\u379d\u504a\uc848\u0dba\u2143\uc6b2\ubc38\u68bd\ua9de\ucaf2\u985f", "\ud8e0\udfe5\ud984\udce1\udb0e\udc77\ud890\ude38\ud880\udc8e\uda84\udea7\ud90f\udec1\u175a",
        14, 24913, -1100027412, -707141270295516612L, -65835L, false, true, (char) 55550, (char) 57186,
        Double.longBitsToDouble(0x3fdab2147e13d312L), Double.longBitsToDouble(0x3fed91a11679166cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Boolean:false |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 12, 12, 4, "", "\u93f4\ubb11\u4f91\000\000\000\000\uc300\000\ua71c\u0087\u985f", "\ud83d\udc90",
        45, -897, 0, 0L, -100000L, false, false, (char) 9866, (char) 0,
        Double.longBitsToDouble(0x3e31e00000000000L), Double.longBitsToDouble(0x3fbaf881045f68b0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 13, 15, 11, "\ud973\uddec\ud8e2\udf5a\u59e9\uda7c\udd2c\udb01\udc09\u038d\udb17\udf93\udb89\udf96", "\u687f\ua9de\ucaf2\u985f\u6d24\ubc13\uc34d\u33db\u083d\u4345\u28e9\u00c8\ua5f5\u5927\u9d46\u9289\u2c36\u5f21\u146e\u0711\u83ab\u25fc\uc575\u7b24\u430b\u2cd3\u3e45\u9781", "\ud845\udc68\udb49\udf3a\ud82e\udcc8\ud81f\udea0\ud80f\udccf\udb23\ude61\uda80\udc0d\ud89b\udc87\udb74\udde2\ud99a\udf9a\uda24\uddf2\ud8d9\udc62\udb21\udeed\ud811\udf5b\ud9e9\udc50\uda21\udf96\uda94\udf97\udaad\udeca\ud9a6\udd17\udb4f\uddf5\ud8a5\udc50\udad4\udd98\udada\udcde\udacd\udce0\udb83\ude87\udbec\uddc7\ud99f\udc55\udb53\udc4f\ud93f\udfa3\udabe\udde6\uda0b\udfde\uda9f\udd68\ud979\udf90\ud891\udee5\udbb6\udc8a\u8d01\ud8ba\udc47\ud8ec\udea3\ud99b\udc38\udb74\udc5b\u5d49",
        24, 22473, 1409501032, -340389035332223521L, -73671L, true, false, (char) 15918, (char) 656,
        Double.longBitsToDouble(0x3fd4b36b5652928eL), Double.longBitsToDouble(0x3fd0fe7fcc7e2eb0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Boolean:false |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 12, 12, 11, "\u6c28", "\u379d\u504a\uc848\u3713\ucc08\u62ce\ubc38\u68bd\ua9de\u5b3c\u985f", "\ud980\udf65\ud984\udc86\ud92a\udf66\udb3e\udc45\ud880\udc8e\uda84\udea7\ud99f\udc11\ud9b9\udcf6",
        -3, 24017, -1100027412, -707141270295516612L, -65835L, false, true, (char) 55550, (char) 57186,
        Double.longBitsToDouble(0x3fddc2147e1375a4L), Double.longBitsToDouble(0x3fed91a11679166cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 18, 11, "\ud967\ude08", "\u379d", "\ud83e\udd72\u7eb4",
        52, 88104, 951080333, 4327021026532354695L, -25138L, false, false, (char) 28461, (char) 41274,
        Double.longBitsToDouble(0x3fe21330ea9d6adcL), Double.longBitsToDouble(0x3fedf5bc1be8175fL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 2, 11, "\u6c28", "\u379d\u504a\uc848\u0dba\u2143\uc6b2\ubc38\u68bd\ua9de\ucaf2\u985f\u6d24\ubc13\uc34d\u33db\u083d\u4345\u28e9\u00c8\ua5f5\u5927\u9d46\u9289\u2c36\u5f21\ub6b2\u5201\ub1eb", "\ud812\udf1a",
        13, 6785, 376187826, 1103081163382422892L, 87372L, true, true, (char) 14494, (char) 60154,
        Double.longBitsToDouble(0x3fe3193986bc0deaL), Double.longBitsToDouble(0x3fe1e9bd9ea46a58L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 4, 4, 7, "\u6cc0\ud8a3\udf4e\ud9fc\udcae\udb22\udf61\udb01\udc09\u038d\udb17\udf93\udb89\udf96\ud8cb\uddb8\udbdd\uddf3\ud8da\udce4\udbbf\ude52\udb82\udd5a\uda3b\udebb\uda78\uddc3\uda51\udcdf", "\u321a\u4345", "\ud9d5\udca0\ud9b9\udcf6\ud802\udeb8\ud844\udc4d\udb3f\ude0e\uda3a\udeb6\uda92\udc95\udbac\udca4\ud888\udeff\ud8b5\udeb0\ud9a8\udca9\ucb33",
        13, 41817, 385146708, -1975406261324892858L, 33630L, false, true, (char) 6533, (char) 3793,
        Double.longBitsToDouble(0x3fe6ad29a6d678d3L), Double.longBitsToDouble(0x3fa5ce8875b6d720L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01241\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01241\0112\011100%\011100%\012\012",
        Z.run(T, 2, 8, 8, 19, "\udbe5\udc9f\udae3\uddfb", "\u6281\u92ab\u4d13", "\udb1a\udcd7\u888b\udba5\udca4\ud881\uddfa\udb56\ude0b\udb8e\udcc9\udba6\ude9f\ud8f2\udcef\ud948\udd70\ud8a1\udc95\udb7b\udea3\udb83\udca4",
        41, 7627, 300762108, 2720594729319045420L, -82275L, false, false, (char) 64331, (char) 39358,
        Double.longBitsToDouble(0x3fe9203d9880c246L), Double.longBitsToDouble(0x3fe92271fdab2147L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u6c28\0111\011100%\011100%\012\0121=java.lang.Long:1 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u6c28\0111\011100%\011100%\012\012",
        Z.run(T, 2, 7, 15, 14, "\u6c28", "\u8a78\u217a\u6c1b\u2d9d\u69d1\u7a01\u4353\u0efc\u8fcb\ucaf2\u209c", "\ud9d0\udfb5\ud984\udce1\ud92a\udf66\uda38\udc42\ud880\udc8e",
        16, 50098, 292858148, -4615792848098851489L, -82275L, false, false, (char) 55919, (char) 2305,
        Double.longBitsToDouble(0x3fda27217171f19eL), Double.longBitsToDouble(0x3fd244e3fb56428eL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01215\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \01215\0112\011100%\011100%\012\012",
        Z.run(T, 2, 6, 6, 8, "\u6c28", "\u8a78\u3b14\uc848\ubd32\u40d7\ube85\ud3fb\u0efc\u8fcb\ucaf2\u209c", "\ud8fb\udf94\ud984\udce1\ud92a\udf66\ud9e9\udf5c\udbd1\udc5a\uda84\udea7\ud94c\ude1f\ud93a\ude2b",
        15, 8308, -1100027412, -707141270285686212L, -65835L, false, true, (char) 55550, (char) 57186,
        Double.longBitsToDouble(0x3fdab2147f688584L), Double.longBitsToDouble(0x3fed91a11679166cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 1, 17, 16, "\ud81f\uddaa", "\ucc3e\u63df\u1f7b\ubd32\u40d7\u7a01\u4353\u3245\u1a9a\ucaf2\u209c\u6d24\u6a00\u872b\ua098\ub4e8\u5e26\u28e9\u7b65\u361d\u3a86\u7555", "\udbc6\ude2e\uda92\udc77\udba4\udc79",
        14, 81244, 1312809144, -6897384719975481008L, 81487L, true, false, (char) 65426, (char) 15369,
        Double.longBitsToDouble(0x3fe4e21750056db7L), Double.longBitsToDouble(0x3fe73952be49ad98L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\ud8ee\udd37\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\ud8ee\udd37\0112\011100%\011100%\012\012",
        Z.run(T, 2, 9, 9, 16, "\ud8ee\udd37", "\u576a\u9d4f\uc86d\u23b4\u40d7\u6d9d\u0f26\u682f\u8fcb\ucaf2\u209c", "\ud971\udde1\ud984\udcfe\ud9af\ude09\uda30\udee5\udbae\udc30\udbdf\udda1\ud94c\udda9\ud93a\ude2b\uda4d\udd15\udac3\udcd0\udb3f\ude0e",
        58, 54157, -317261717, -3552360943775748293L, 2692L, true, true, (char) 41410, (char) 24532,
        Double.longBitsToDouble(0x3fe1b0b3676e9f70L), Double.longBitsToDouble(0x3fe42b7c34048a63L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 19, 19, 6, "\u6c28", "\u379d\u504a\u2139\u0d99\u8b55\uc6c8\ubc38\u68bd\ua9de\ucaf2\u2845", "\udb96\udd26\ud985\ude1e\ud92a\udf66\uda38\udc42\ud880\udc8e\uda84\udea7\ud997\udd89\udae9\udcee",
        42, 24913, -1100027412, -707145668342027716L, -65835L, false, true, (char) 55550, (char) 57186,
        Double.longBitsToDouble(0x3fdab2147e13d312L), Double.longBitsToDouble(0x3fed91a11679166cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u7ef2\0111\011100%\011100%\012\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 9, 14, "\u6c28", "\u6867\u6871\u2139\u7a3a\uc0af\ud491\ubc38\u68bd\ua9de\u238b\ud632", "\udb96\udd26\ud985\ude1e\ud92a\udf66\uda38\udc42\ud880\udc8e\uda84\udea7\ud997\udd89\udae9\udcee\udb7c\udd1c\ud835\ude4d",
        18, 85843, -503027140, -1362628698658604405L, -91992L, false, true, (char) 32498, (char) 18579,
        Double.longBitsToDouble(0x3fed91a11679166cL), Double.longBitsToDouble(0x3fd11d05a23c75ceL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u677a\0111\011100%\011100%\012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u677a\0112\011100%\011100%\012\012",
        Z.run(T, 2, 5, 5, 18, "\u6c28\ud8a3\udf4e\ud9fc\udcae\udb22\udf61\ud9a5\udfbc\udbd7\udcad\ud97d\ude69\u9c0f\ud8e9\udc83\ud93c\udefd\ud8da\udce4\udbbf\ude3c\ud991\udf0f\udb6e\udd0b\ud8d1\udfab\udba6\udf36\udb58\udc70\ud90e\ude5c\ud92a\udf0b\uda8f\udc0f\ud92d\udfb1\uda84\udea7\ud9b2\udd11", "\u9289\u2c36\u5f21\ub6b2\u5201\u52fd\u7d58", "\ud833\udc58\ud9fe\ude1b\ud8f1\udd04\ud96f\ude12\uda29\udfaa\ud98e\udcc5\udb94\ude84\udae2\udcf9",
        36, 55254, 1701672581, -9124885803272683982L, -78060L, true, false, (char) 26490, (char) 33190,
        Double.longBitsToDouble(0x3fdc2244fc6c15b0L), Double.longBitsToDouble(0x3fe081d91925c31cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 13, 13, 14, "\u6c28", "\u379d\u504a\uc848\u0dba\u2143\uc6b2\ubc38\u68bd\ua9de\ucaf2\u985f", "\udbce\udd9a",
        42, 27911, 1713187165, -3684909584626739630L, 68984L, false, false, (char) 38282, (char) 40947,
        Double.longBitsToDouble(0x3fe61df3723cf62fL), Double.longBitsToDouble(0x3fbaf881145f68b0L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\012",
        Z.run(T, 2, 14, 14, 11, "\u6c28", "\u379d\u15f2\uc119\u20b4\u2143\uc6b2\ubc38\u68bd\ua9de\ucaf2\u2601", "\ud8f7\udf94\ud99f\udc6c\ud85f\ude5e\uda47\udf6b\udae6\udfe5\uda84\udea7\ud9b2\udd11\ud9b9\udcf6",
        -3, 24913, -1100040038, -707141270295516612L, -65835L, true, false, (char) 55678, (char) 38573,
        Double.longBitsToDouble(0x3fdab2147e13d2c0L), Double.longBitsToDouble(0x3fed91a11679166cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\0121=void |this=org.apache.commons.math.stat.Frequency:Value \011 Freq. \011 Pct. \011 Cum Pct. \012\u6c28\0111\011100%\011100%\012\012",
        Z.run(T, 2, 16, 9, 15, "\u6c28", "\u379d\u504a\ud5ab\u0d19\u2143\uc6b2\ubc38\u68bd\ua9de\ucaf2\u985f", "\ud8fb\udf94\ud9f5\ude3a\ud92a\udfbf\uda38\udc42\ud880\udc8e\uda84\udea7\ud9b2\udd11\ud9b9\udcf6",
        -3, 24913, -1100027412, -950335651314309516L, -68651L, false, true, (char) 5785, (char) 57186,
        Double.longBitsToDouble(0x3fdab218ce13d312L), Double.longBitsToDouble(0x3fed91a11679166cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.stat.Frequency|getPct|char|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getPct|int|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getPct|java.lang.Comparable|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getPct|java.lang.Object|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getPct|long|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|char|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|int|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|java.lang.Comparable|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|java.lang.Integer|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|java.lang.Object|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|addValue|long|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|clear||new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|equals|java.lang.Object|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCount|char|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCount|int|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getCount|java.lang.Comparable|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getPct|char|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getPct|int|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getPct|java.lang.Comparable|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getPct|java.lang.Object|new:org.apache.commons.math.stat.Frequency:",
    "M|org.apache.commons.math.stat.Frequency|getPct|long|new:org.apache.commons.math.stat.Frequency:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
