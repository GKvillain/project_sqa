package org.apache.commons.math.analysis.solvers;
import org.junit.Test;
import static org.junit.Assert.*;
public class BracketingNthOrderBrentSolver_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 1, 1, 4, 8, "\udaa1\uded8\ud864\ude65\ud990\udc4a", "\u01e5\uc182\u5206", "\ud982\udc60\ud869\udf30\ud840\udf4a\uda03\udec2\ud81b\udc9a\udb1d\udc23",
        3, 38977, -80840851, 6712960723407755985L, 57612L, true, true, (char) 47047, (char) 25412,
        Double.longBitsToDouble(0x3fd39a26a7cff1ecL), Double.longBitsToDouble(0x3fc45334399e0540L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 1, 1, 4, 8, "\udaa1\uded8\ud864\ude65\ud990\udc4a", "\u01e5\uc182\u5206", "\ud982\udc60\ud869\udf30\ud840\udf4a\uda03\udec2\ud81b\udc9a\udb1d\udc23",
        3, 38977, -80840851, 6712960725100268753L, 57612L, true, true, (char) 47047, (char) 25412,
        Double.longBitsToDouble(0x3fd39a26a7cff1ecL), Double.longBitsToDouble(0x3fc45334399e0540L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 1, 1, 3, 3, "\udaa1\uded8\ud864\ude65\ud990\udc4a\udb12\udc27\udaf3\udfb0", "\u5206\u8494\ub819\u0d5a\u086b\u4422", "\udb1d\udc23\ud840\udf8d\udbb9\udc7a\ud90d\udefa\ud9cb\udfb3\ud8ba\udfa2\ud89d\uddce",
        0, 33779, -2105173932, -6818918891509508503L, 13351L, true, true, (char) 47683, (char) 30647,
        Double.longBitsToDouble(0x3feaa2fa620ecbefL), Double.longBitsToDouble(0x3fe438be0574f6f6L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NumberIsTooSmallException\012",
        Z.run(T, 1, 6, 4, 8, "\udaa1\uded8\ud864\ude65\ud990\udc4a", "\u01e5\uc182\u5206\u8494\ub819\u0d5a\u086b\u4422\u59ff\u8083\u38ce\u160b\u2d20", "\ud84e\udccb\ud89d\udec1\u128a\udb6e\udf4c\udbda\udd89\ud92d\udfd1\udbd9\udd71\ud873\ude60\udb3d\udcce\uda35\uddde\udad8\udd2a\ud9a1\udf18\udb6f\ude76\ud97a\udecd\ud9f4\uddfe\udb70\uddc7",
        -1, 25146, -1051801088, -533035435503134717L, -96132L, false, true, (char) 18807, (char) 29911,
        Double.longBitsToDouble(0x3fb1a88a0f5edd88L), Double.longBitsToDouble(0x3fb2e8741909b588L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NumberIsTooLargeException\012",
        Z.run(T, 1, 0, 4, 8, "\udaa1\uded8\ud864\ude65\ud8a3\udeb9", "\uc8e4", "\udab1\ude08\ud8a4\udec3\ud982\udc60\ud9a4\udd6d\ud840\udf4a",
        3, 32960, -1950790922, 8860546729798652185L, 10646L, true, false, (char) 29553, (char) 52353,
        Double.longBitsToDouble(0x3fc37e4481520714L), Double.longBitsToDouble(0x3fd658285cd342bcL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 1, 7, 3, 0, "\uda65\udddb\ud812\udde0\ud92a\ude25\udbff\udfc3\uda6f\uddcc\ud93c\udd15\udbad\udd8c", "\ua319\u0d5a\u3105\u81e0\u5ab7\u8083\u5f22\uade2\u3b02", "\ud8c8\udda0\udb7c\udec4\ud860\udc94\ud96a\udf58\udb4a\udc67\udadc\ude0e\udab9\udd1b\ud9ce\udead\udafd\ude93\uda30\ude99\udbf5\udda6\udb46\udc95\u3ba7\uda95\udd72\udbc3\udeb1\udabd\udec8\ud89f\ude5b\udbf1\uddde\ud8f5\udc38\ud905\udc7d\uda6a\udee5\udaf2\uddad\ud856\udd7f\ud829\uddf5\ud8c0\uddf4\ud9d3\udd55\ud8c7\udc6b\ud946\udf2f\ud932\udd93\uda2c\udd0a\udae8\udd5d\ud838\udf23\ud80b\ude2b\ud860\udfd0\udad5\udd7e\uda15\udc0d\ud8f6\ude94\uda43\udffa\ud887\udea7\udb3c\udfc0\udb65\udffd\u7d14",
        34, 5523, 1965166146, -3584368951964498952L, 65384L, false, false, (char) 14238, (char) 31000,
        Double.longBitsToDouble(0x3fb00bdc833fd9e8L), Double.longBitsToDouble(0x3feb026e95170714L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NumberIsTooSmallException\012",
        Z.run(T, 1, 5, 0, 3, "\udaa1\uded8\ud864\ude65\ud990\udc4a", "\u01e5\uc182\u5206\u8494\ub819\uaddf\u086b\u300e\u00c4\uacf5\u412e\u160b\u2d20\u8187", "\ud89d\uddce\udbab\udcdd\uda9b\udd2a\uda0e\ude9b",
        0, 55897, -1570051100, -515697528107099161L, -26383L, true, false, (char) 58665, (char) 64673,
        Double.longBitsToDouble(0x3fcaeff7302966b8L), Double.longBitsToDouble(0x3fe638d99cf8873eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 1, 6, 4, 1, "\udaa1\uded8\udb81\udc4d\ud990\udc4a\udb12\udc27\udaf3\udfb0\ud999\uddf8\udb26\udd60\udb90\udc29", "\u0d5a\u086b\u4422\u59ff\u8083\u412e", "\ud90d\udf24\ud9cb\udfb3\ud8ba\udf68\ud89d\uddce\udbab\udcdd\ud9a5\udd2e\udbda\udcb3\ud92d\udfd1\udbe5\uded8\ud9f5\udd86\udb3d\udcce\uda35\uddde\udad8\udd2a",
        31, 74114, 408158653, -806474333125850485L, 89918L, false, true, (char) 40595, (char) 32120,
        Double.longBitsToDouble(0x3fe2718ac8e6267fL), Double.longBitsToDouble(0x3f9253a0c4bc9f60L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 1, 4, 7, 0, "\udaa1\ude35\ud9e4\ude65\ud990\udc4a\ud95d\udd12\ud9c7\udd32\uda63\udc13\udb48\ude8e\ud879\udcfd\ud9a7\ude03\ud90e\udccc\ud982\udc60\ud869\udf30\ud840\udf4a\ud816\udf78\ud890\udf2d\ud88d\udd76\ud840\udf8d\ud944\udc00\ud90d\udf22\ud9cb\udfb3\ud812\ude42", "\u1c8b\ua198\u7d3c\u3cc4\u29fc\u5a39\u27bc\u727b\u03ad\u011e", "\ud93b\udd77\udbbe\udcc6\ud8e0\udcee\ud897\udca6\ud821\udf00",
        57, 42630, 332172870, -2398475931961521947L, -49511L, false, true, (char) 27816, (char) 22003,
        Double.longBitsToDouble(0x3fd0e96a408ac9b0L), Double.longBitsToDouble(0x3fe337c949ee5f1eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 1, 4, 4, 8, "\udaa1\uded8\ud864\ude65\ud990\udc4a", "\u01e5\uc182\u5206", "\ud982\udc60\ud869\udf30\ud840\udf4a\uda03\udec2\ud81b\udc9a\udb1d\udc23",
        3, 38977, -80840851, 6712960723407755985L, 57612L, true, true, (char) 47047, (char) 25412,
        Double.longBitsToDouble(0x3fd39a26a7cff1ecL), Double.longBitsToDouble(0x3fc45334399e0540L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 3, 7, 5, "\udaa1\uded8\ud864\ude65\udb86\udc49\udb12\udc27\ud9f4\ude72\udabe\udf06\udb26\udda4\udb90\udc29", "\u0d5a\u086b\u4422\u59ff\u8083\u0579", "\udb7d\udf5c\ud9cb\udfb3",
        29, 51737, -232508078, -9095594927952914348L, -40340L, false, true, (char) 59299, (char) 5342,
        Double.longBitsToDouble(0x3fe974cd0e496c1fL), Double.longBitsToDouble(0x3fe4a0afa7805483L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 3, 2, "\udbd4\udef0\udafc\udcdb\uda7b\udf94\udbd5\udeea\ud959\udc9f\ud882\udcc5", "\ua126\032\u257a\u084f\u4422\u8b7c\u14f6\u28c5\u2334\u2f48", "\udabf\udef9\ud8a7\udeb6\udbab\udcdd\uda9b\udd2a",
        43, 65725, 2006603903, -8472700385377822311L, -50503L, true, false, (char) 22136, (char) 31415,
        Double.longBitsToDouble(0x3fa1c189a7615580L), Double.longBitsToDouble(0x3fed92ebd898f232L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 1, 0, "\udaa1\uded8", "\ubba6\u31c8", "",
        -5, 52848, 466288681, 5948432136187937014L, 53132L, false, false, (char) 254, (char) 64511,
        Double.longBitsToDouble(0x3f997af600000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 1, 5, 4, 6, "\udaa1\uded8\ud864\ude65\ud990\udc4a", "\u01e5\uc182\ud296", "\uda13\udd1a\ud8a4\ude3b\udb1f\udd87\uda19\udf46\ud81b\udc9a\udb1d\udc23",
        3, 38977, -80840851, 7611289212520422182L, -75365L, true, false, (char) 6736, (char) 55274,
        Double.longBitsToDouble(0x3fe34d0af3e47760L), Double.longBitsToDouble(0x3fdf7002cfcff1ecL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 1, 4, 8, "\udaa1\uded8\ud864\ude65\ud990\udc4a", "\u01e5\uc182\u5206", "\ud982\udc60\ud869\udf30\ud840\udf4a\uda72\uddb2\ud81b\udc9a\udb1d\udc23",
        1, 38977, -80840851, 6761374419401988817L, -48048L, true, false, (char) 6681, (char) 46242,
        Double.longBitsToDouble(0x3fe34d0af3e47760L), Double.longBitsToDouble(0x3fd39a26a7cff1ecL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 1, 8, 4, 3, "\udab5\uded8\ud864\ude65\ud990\udc4a\udb12\udc27\udaf3\udfb0\ud823\ude21\udbd0\udce6\ud8eb\udca3\udbff\udef6\ud90e\udccc", "\u4422\u59ff\u8083\u0452\u2f9f\u7184\u01b7\u38a0\uc340\u2758\u90d0\u2700", "\udbd9\udd71\ud850\udfd7\udb3d\udcce\uda35\udd7d\udb30\udcb5\ud8b5\udc38\ud940\ude46\uda35\udef0\uda65\udf15\udb22\udf47",
        20, 57242, 1979321881, 2139096903906494924L, -36569L, true, true, (char) 61712, (char) 36718,
        Double.longBitsToDouble(0x3fc801928dd92b84L), Double.longBitsToDouble(0x3fd042aa00341b4aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 8, 8, "\u8a1a\ud864\ude28\ud990\udc4a", "\u01e5\uc182\u5206", "\ud981\udda2\ud869\udf30\ud840\udf4a\uda03\udec2\ud81b\udc9a\udb1d\udc23",
        3, 38977, -80840851, 6712960722258306257L, -95770L, true, false, (char) 15413, (char) 28184,
        Double.longBitsToDouble(0x3fd39a26a7cff1ecL), Double.longBitsToDouble(0x3fc4533430320540L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 6, 4, 5, "\udaa1\ude6f\ud866\udf65\udb14\udfd3", "\u01d1\uc108\u5a33\u9694\ub819\u0d5a\u29e6\u4422\u606b", "\u8de1\uda70\udd1c\udb58\udd55\uda09\udd82",
        19, 57398, -232507985, -746682076712329543L, -16610L, false, true, (char) 59514, (char) 30647,
        Double.longBitsToDouble(0x3feed7d74ff2f955L), Double.longBitsToDouble(0x3fe86db97be41ef8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 5, 3, 1, "\udaa1\uded8\ud864\ude65\ud807\udd1c", "\u8261\u0b66\uc94c\ud5a0\ub841\u0d5a\u086b\u4422\u59ff\u8083\u412e\u7ac0\u2d20\uc332\u5bb2\uc340\u2758\u1d42\ua4e1\u435a\u7d3c\u03e5\u0e61\u22d0\ua033\u0433", "\ud852\udeb0\uda41\ude0e\ud848\udf5c\udbe4\ude3d\uda13\udfac\ud8d4\ude93\ud96f\udc76\ud827\udd82\ud924\udd4b\ud85b\ude5c\ud8e8\udfeb\udb0e\ude03\uda4c\ude63\ud898\uddec\ud839\udef1\ud874\udc25\ud88f\udf94\uda06\udc1f\uda94\udf36",
        22, 82338, -547156764, 6604498973866156545L, -94694L, false, true, (char) 22381, (char) 42344,
        Double.longBitsToDouble(0x3fee409b14207664L), Double.longBitsToDouble(0x3fe48e0bef05a7a7L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 2, 5, "\udaaa\udcd8\ud860\ude65\ud990\udc4a", "\u01e5\uc182\u166c\u80ae\u4715\ud566\u086b", "\ud83a\ude9a",
        56, 77522, 824064959, 3745861564309305806L, -29059L, false, true, (char) 41262, (char) 589,
        Double.longBitsToDouble(0x3fb6a00af34d0af0L), Double.longBitsToDouble(0x3fef23bb0539a26aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NumberIsTooSmallException\012",
        Z.run(T, 1, 7, 3, 3, "\udaa1\uded8\ud864\ude65\ud990\udc4a\udb12\udc27\udaf3\udfb0", "\u5206\u8494\ub819\u0d5a\u086b\u4422", "\ud8e6\udda4\u6a08\ud99f\udd62\uda66\udfd0\ud9f5\udc14\ud8ba\udfa2\ud89d\uddce",
        0, 33779, -2105173932, -6818918891509508503L, -95449L, false, false, (char) 10504, (char) 30647,
        Double.longBitsToDouble(0x3feaa2fa620ecbefL), Double.longBitsToDouble(0x3fe438be0574f6f6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 7, 3, 3, "\udaa1\uded8\ud864\ude65\ud990\udc4a\udb12\udc27\udaf3\udfb0", "\u51e2\u8494\ub819\u0d5a\u086b\u4422\u8ded\u3cbf\u5474\u160b\uab0f", "\udaed\ude3b\ud89d\uddce\udbab\udcdd\uda9b\udd2a\udbda\udcd8\ud92d\udfd1\udb3a\udd42\udb82\udfe4\udb3d\udcce\uda50\udfde\udad8\udd2a\udafb\udc04\ud9fa\udc42\ud93a\udf74\uda9c\uddfe\udba1\udd1e",
        37, 71785, -1300452654, -5115402670949994061L, 71183L, true, true, (char) 56901, (char) 16356,
        Double.longBitsToDouble(0x3fea72d0cee87e78L), Double.longBitsToDouble(0x3fea330b2e4ef757L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 2, 1, 5, 2, "\udaa1\uded8\ud8c4\uddcc\ud8cb\udf80\udb12\udc27\udaf3\udfb0", "\u5206\u84af\ub83e\ub09b", "\uda22\udd24\ud81b\udc9a\udbf2\udf38\ud9ad\udfcc\udbb9\udc7a\ud90d\udefa\ud9cb\udfb3\udae9\udc90",
        14, 94015, -2117733221, 981952205669291365L, 94276L, true, true, (char) 27870, (char) 54895,
        Double.longBitsToDouble(0x3fe1f961fb5418baL), Double.longBitsToDouble(0x3fe0742f7a8717c0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 2, 7, 5, 4, "\udaa1\uded8\udbfa\udc6e\ud9ae\udeb7\u2a95\udba3\udd11", "\u1a3d\u379e", "\ud869\udf30\ud840\udf4a\uda03\ude9f\ud81b\udc9a\udb1d\udc23\ud86f\udd2b\ud928\ude00\ud921\udc0b\udbd5\udf65\ud94b\udf22\ud8cc\uded7\udbab\udcdd\ud858\udca7\udb05\ude73\ud93e\udef5\ud949\ude2a\ud89f\udf94\u8648\udbe5\udd4f\udad8\udd2a\udabd\ude04\ud9fa\udc42\ud813\udec5\uda9c\uddfe\udaf5\udf69\ud8f7\udf9f\ud810\udc78\uda21\udfe5\ud9c3\udf89",
        6, 81529, 1359636001, 4825579509416856913L, 40306L, true, true, (char) 33915, (char) 61450,
        Double.longBitsToDouble(0x3fd9540c18950abaL), Double.longBitsToDouble(0x3fcdbc4d1f9408e4L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 8, 3, 0, "\uda65\udddb\ud812\udde0\ud92a\ude25\udbff\udfc3\uda6f\uddcc\ud93c\udd15\udbad\udd8c", "\ua319\u0d5a\u3105\u81e0\u5ab7\u8083\u5f22\uade2\u3b02", "\ud8c8\udda0\udb7c\udec4\ud860\udc94\ud96a\udf58\udb4a\udc67\udadc\ude0e\udab9\udd1b\ud9ce\udead\udafd\ude93\uda30\ude99\udbf4\udc05\ud803\udc12\ud9a7\udd6e\ud971\udf45\udbc3\udef4\udabd\udec8\ud89f\ude5b\udbf1\uddde\ud8f5\udc30\ud905\udc7d\uda6a\udee5\udaf2\uddad\ud856\udd7f\ud829\uddf5\ud8c0\uddf4\ud9d3\udd55\ud8c7\udc6b\ud946\udf2f\ud932\udd93\uda2c\udd0a\udae8\udd5d\ud838\udf23\ud80b\ude2b\ud860\udfd0\udad5\udd7e\uda15\udc0d\ud8f6\ude94\uda43\udffa\ud887\udea7\udb3c\udfc0\udb65\udffd\u7d14",
        34, 5523, 1965166146, -3584368951964498952L, 65384L, false, false, (char) 14238, (char) 31000,
        Double.longBitsToDouble(0x3fb00bdc833fd9e8L), Double.longBitsToDouble(0x3feb026e95170714L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a1=[D:[[27684.0, 28410.5, 27769.5, 28240.5, 27773.0, 28410.5, 28135.5, 28617.5]] |a2=[D:[[20852.5, 1685.0, 6250.5, 16600.0, 11587.5, 16425.5, 12153.0, 22233.0]] |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 1, 2, 3, 3, "\ud878\ude25\ud923\udcd1\ud92a\ude25\udbff\udfc3\uda6f\uddcc\ud969\udfeb\udbad\udd8c", "\ua319\u0d5a\u3105\u81e0\u5ab7\u8083\u5f22\uade2\u3b02", "\ud8c8\udda0\udb7c\udec4\ud860\udc94\uda8b\udc09\000\uda03\udd20\udab9\udd1b\ud9ce\udead\ud8fd\udd93\uda2e\uddf7\ud83c\udc4a\udb06\ude43\u3ba7\022\000\000\ud89f\udda7\udbf1\uddde\ud8f5\udc38\ud905\udc7d\uda6a\udee5\ud81f\udd24\ud842\udd00\ud829\uddf5\ud8c0\uddf4\ud9d3\udd55\ud8c7\udc6b\ud946\udf2f\ud932\udd93\u00ab\000\ud838\udf23\ud80b\ude2b\ud860\udfd0\udad5\udd7e\uda15\udc0d\ud8f6\ude94\uda43\udffa\ud887\udea7\udb3c\udfc0\udb65\udffd\u7d14",
        15, -1000, 1965162496, -771751936L, 65384L, false, false, (char) 14238, (char) 31000,
        Double.longBitsToDouble(0x3fb00bdc833fd9e8L), Double.longBitsToDouble(0x3feb026e95170714L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=!org.apache.commons.math.exception.NumberIsTooLargeException\012",
        Z.run(T, 2, 1, 0, 3, "\udaa1\uded8\ud864\ude65\ud990\udc4a", "\u01b4\uc182\ucbc5\u8883\ua119\uaddf\u086b\u300e\u587b\u42c3\u412e\u160b\u2d20\u8187", "\ud89d\udeae\udbab\udcdd\uda9b\udd2a\uda0e\ude9b",
        55, 2381, -1570051100, -515697528107099161L, -26325L, true, false, (char) 58665, (char) 64673,
        Double.longBitsToDouble(0x3fcaeff7302bfeb8L), Double.longBitsToDouble(0x3fe638d99cf8873eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 2, 6, 6, 1, "\ud959\udd1c\udb81\udc4d\ud976\udf4a\ud9c2\ude3f\udaf3\udfb0\ud999\uddf8\udb26\udd60\ud884\udf29", "\u9f01\u0809\ube0a\u3511\u1123\u412e\u2869\ubb92\u67b6\u38a0\u2425\u0dde\u5aa8\u9366\u4361\u5d3c\u905e\u548d\uad39\ud00c\u72a4\u79dc", "\udbf1\ude2c\udb66\udd74\ud9f2\udffd\ud849\udf26\ud8e8\udee4\uda56\ude63",
        30, 7950, 1407142630, -1946931548303655395L, 13656L, true, false, (char) 9712, (char) 10980,
        Double.longBitsToDouble(0x3fd30b95c10ff4c2L), Double.longBitsToDouble(0x3fedb10dbbafc563L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 7, 5, "\udaa1\ude35", "\u9e4c", "\udb48\ude8e\ud879\udcfd\ud998\udcfc\000\000\000",
        -5, 10505, 30068, 0L, -100000L, false, false, (char) 0, (char) 12165,
        Double.longBitsToDouble(0x3fefbcd4203a0000L), Double.longBitsToDouble(0x3fb400002b2c1000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=java.lang.Integer:5 |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 2, 1, 1, 5, "\udaa1\uded8\ud864\ude65\udb86\udc49\udb12\udc27\ud9f4\ude72\udabe\udf06\udb26\udda4\udb90\udc29", "\u0d5a\u086b\u4422\u59ff\uce70\ub3bf", "\udb7d\udf5c\ud9cb\udfb3",
        29, 51737, -232508078, -9095594927952914348L, -40340L, false, true, (char) 59299, (char) 5342,
        Double.longBitsToDouble(0x3fe974cd0e496c1fL), Double.longBitsToDouble(0x3fe4a0afa7805483L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=!org.apache.commons.math.exception.NumberIsTooSmallException\012",
        Z.run(T, 2, 8, 6, 5, "\udaef\udfaf\ud888\udc0f\udb86\udc49\udb12\udc27\ud820\ude68\udb9e\udc5b\ud918\udead", "\u54de", "\ud840\udf4a",
        -1, 19084, 1147262061, 6091868006256123414L, 81706L, true, false, (char) 27473, (char) 45769,
        Double.longBitsToDouble(0x3fc37e4481520714L), Double.longBitsToDouble(0x3fd658285de986a6L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=!org.apache.commons.math.exception.NumberIsTooSmallException\012",
        Z.run(T, 2, 8, 7, 5, "\udaa1\uded8\ud864\ude65\ud8e3\udcd0\ud980\udc28\udae7\udddc\udbaa\ude86\udb26\udda4\uda0a\udf27", "\u0d5a\u243b\uc1ca\u4dd9\ud779\u0608", "\udb7d\udf5c\udab7\udd29",
        -3, 51761, -232508078, -9095594927952914348L, -40340L, false, true, (char) 59299, (char) 5342,
        Double.longBitsToDouble(0x3fe974cd0e496c1fL), Double.longBitsToDouble(0x3fe4a0afa7805483L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a1=[D:[[28114.0, 28512.0, 28006.0, 28245.5, 27941.5, 28594.0, 28114.5, 28509.0]] |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 1, 2, 3, 2, "\udbd4\udef0\udafc\udcdb\uda7b\udf94\udbd5\udeea\ud959\udc9f\ud882\udcc5", "\000\000\u0e6e\u084f\u4422\u8b7c\u14f6\u28c5\u2334\u2f48", "\udabf\udef9\ud8a7\udeb6\udbab\udcdd\uda95\udca6",
        -5, -1000, 1996488704, -8472700385377822311L, -50503L, true, false, (char) 22136, (char) 31415,
        Double.longBitsToDouble(0x3fa1c189a7615580L), Double.longBitsToDouble(0x3fed92ebd898f232L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 2, 5, 5, 4, "\udaa1\uded8\ud818\udf7a\ud8af\udffb\ud888\udd93\uda73\udefb\udbef\udf73", "\u68ad\u215b\u656c\u38eb\ua34f\u1346\u7783\u766a", "\ud89c\udd1b\uda42\udcee\udb01\udd70\u2989\ud8d8\udf0f\uda9b\udd2a\uda57\udf0c\ud858\udda8",
        45, 21377, -161495645, 7743552178274705424L, -51074L, true, false, (char) 33268, (char) 22107,
        Double.longBitsToDouble(0x3fd76ece53bc15a0L), Double.longBitsToDouble(0x3fccea0396ee060cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a1=[D:[[27960.5, 28500.0, 27674.0, 28442.5, 27824.0, 28173.0]] |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 2, 4, 8, "\udaa1\uded8\ud864\ude65\ud990\udc4a", "\u01e5\uc182\u5206", "\ud982\udc60\ud869\udf30\ud840\udf4a\uda72\uddb2\ud81b\udc9a\udb1d\udc23",
        9, -1000, -80840851, 6761374419401988817L, -48048L, true, false, (char) 6681, (char) 46242,
        Double.longBitsToDouble(0x3e1c8ee000000000L), Double.longBitsToDouble(0x3fd39a26a7cff1ecL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=!org.apache.commons.math.exception.NumberIsTooSmallException\012",
        Z.run(T, 2, 1, 5, 8, "\udaa1\uded8\ud864\ude65\ud990\udc4a", "\u01e5\uc182\u5206", "\ud982\udc60\ud869\udf30\ud840\udf4a\uda72\uddb2\ud81b\udc9a\udb1d\udc23",
        1, 38977, -80840851, 6963785250117843912L, -48048L, true, false, (char) 6681, (char) 46242,
        Double.longBitsToDouble(0x3fe34d0af3e47760L), Double.longBitsToDouble(0x3fd39a26a7cff1ecL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 2, 5, 5, 1, "\udaa1\uded8\ud864\ude65\ud807\udd1c", "\u8261\u0b66\uc94c\ud5a0\ub841\u0d5a\u086b\u4422\ud1f7\u808c\u412e\u7ac0\u2d20\uc332\u5bb2\uc340\u2758\u1d42\ua4e1\u8470\ub278\u03d4\u0c9b\u832a\ua033\u0433", "\ud852\udeb0\uda41\ude0e\ud848\udf5c\udbe4\ude3d\uda13\udfac\ud8d4\ude93\ud96f\udc76\ud81a\udd4e\ud924\udd4b\ud85b\ude5c\ud8e8\udfeb\udb0e\ude03\uda4c\ude63\ud898\uddec\ud839\udef1\ud874\udc25\ud88f\udf94\uda06\udc1f\ud997\udef8",
        22, 82338, -547156764, 6604498973866156545L, 43475L, true, true, (char) 17450, (char) 43317,
        Double.longBitsToDouble(0x3fed11ddb3742082L), Double.longBitsToDouble(0x3fe48e0c6605a7a7L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 3, 3, "", "\u39ed", "\ud969\udfeb\udbad\udd8c\uda8f\udc6d\udab1\ude08\ud908\udfcc\ud982\udc60\ud83d\udfcb\uda7a\udefd\uda03\udf7a\ud81b\udc9a\ud82a\ude12\uf73d",
        56, 91049, 118734390, -232883361696186368L, 81245L, false, false, (char) 0, (char) 62739,
        Double.longBitsToDouble(0x3fef23ba5593eb6aL), Double.longBitsToDouble(0x3e70000000000000L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a1=[D:[[27960.5, 28489.0, 27674.0, 28442.5, 27737.5, 28300.0, 27726.5, 28479.5]] |a2=[D:[[4786.0, 19567.5, 2281.0, 7588.5]] |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=java.lang.Integer:5 |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 2, 2, 1, 3, "\udaa1\udec2\ud864\ude65\ud8e3\udd48\ud8cd\udeaf\ud9c1\udd0d\ud8ab\ude6b\ud91c\udccc\udb51\udc6c\ud9c1\udc99\uda33\udd73\ud980\udd54\udaec\udfb1\uda67\udfff\ud8cc\udfb1\udb5c\uddb7\ud9f4\udd9a\ud9a3\udec4", "\u2594\u990f\u1202\u3b79", "\ud9c5\udf5d\udad7\uddfb\ud873\ude60\udb91\ude38\ud893\udf68\ud89d\udcca\ud9cb\udef3",
        21, -932, -706632841, -4491326355294240657L, -83060L, false, false, (char) 14897, (char) 64215,
        Double.longBitsToDouble(0x3fe78396356e86cdL), Double.longBitsToDouble(0x3fc5e1e50ba23b80L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 1, 1, 4, 8, "\udaa1\udf1e\ud864\ude65\ud990\udc4a", "\ud003\u4478\u3a50\u8494\u90a3\uc2bb\u230a\uc46d\u59ff\u8083\u412e\u160b\u2d20\u643d\u1933\uc340\u2758", "\udbda\udcee\ud84b\udd1f\ud90b\udf4a\udb43\udf10\udbbd\ude2e\udb7f\udf8c\ud9f5\ude93\udbd1\udee9\udb2b\udd1c\udb9d\udcf6\ud822\udd9a\ud99b\udd3e\ud95c\udc92\udaec\udcd7\ud86f\udc30",
        -5, 34652, -1225790054, -5856113552580561894L, 47405L, true, true, (char) 157, (char) 37118,
        Double.longBitsToDouble(0x3fed9e1087888fb5L), Double.longBitsToDouble(0x3fe9baca80c7a2dfL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 3, 2, "\ud88e\udfec\ud994\udcae\uda4b\udfe4\udbd5\udeea\ud959\udc9f\ud882\udcc5", "\000\000\u0e6e\u084f\u4422\u8b7c\u09ff\u2885\u2334\u2f48", "\ud886\udc3a\ud8a7\udeb6\udbab\udcdd\uda95\udca6",
        10, 11, 1996488704, -8472700385377822311L, -50503L, true, true, (char) 22136, (char) 1417,
        Double.longBitsToDouble(0x3fe204c8b060afa5L), Double.longBitsToDouble(0x3fedc7c17098f232L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a1=[D:[[27960.5, 28500.0, 27709.0, 28625.5, 27883.5, 28396.5]] |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=java.lang.Double:0.0 |a1=[D:[[27960.5, 28500.0, 27709.0, 28625.5, 27883.5, 28396.5]] |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 2, 2, 2, 8, "\udaa1\uded8\ud8aa\udfd3\uda07\ude09", "\u01e5\uc182\u5206", "\udaa1\udfee\ud869\udf30\ud840\udf4a\uda72\uddb2\ud81b\udc9a\udb1d\udc23",
        9, -1000, -80840851, 6761364523797338833L, -48048L, true, false, (char) 25097, (char) 9612,
        Double.longBitsToDouble(0x3fe9a088e0e47700L), Double.longBitsToDouble(0x3fd39a26a7cff1ecL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a1=[D:[[27791.0, 28241.5, 28100.5, 28565.0, 28118.5, 28394.5]] |a2=[D:[[1177.5, 24745.0, 10475.0]] |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=java.lang.Double:0.0 |a1=[D:[[27791.0, 28241.5, 28100.5, 28565.0, 28118.5, 28394.5]] |a2=[D:[[1177.5, 24745.0, 10475.0]] |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 2, 2, 2, 0, "\ud94e\udcd3\udbb9\udf5a\udbdd\ude05", "\u0963\uc182\u5206", "\udaa1\udfee\ud869\udf30\ud840\udf4a\uda72\uddb2\udb15\udca0\udb1d\udc23",
        9, -1000, 1865766131, -5476959807917958447L, 39631L, true, true, (char) 25097, (char) 44684,
        Double.longBitsToDouble(0x3fb15ed40723b800L), Double.longBitsToDouble(0x3fe9c93b93e7f8f6L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a1=[D:[[27791.0, 28191.5, 28100.5, 28565.0, 28118.5, 28394.5, 28001.5, 28605.0]] |a2=[D:[[24813.0, 11929.0, 20183.0, 12969.0, 8433.5, 25678.5, 4885.5, 17067.0]] |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=java.lang.Double:0.0 |a1=[D:[[27791.0, 28191.5, 28100.5, 28565.0, 28118.5, 28394.5, 28001.5, 28605.0]] |a2=[D:[[24813.0, 11929.0, 20183.0, 12969.0, 8433.5, 25678.5, 4885.5, 17067.0]] |this=org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\012",
        Z.run(T, 2, 2, 2, 0, "\ud94e\udc6f\udbb9\udf5a\udbdd\ude05\udaf3\udfaa\udaf3\udfb0\uda0f\udc1d\udb26\udda4\udb90\udc29\udab1\ude08\uda5f\udf16\udaa1\udfee\ud869\udf30\ud891\ude93\ud873\udcae\ud99c\udf63\udb1d\udc23\ud918\uded9\ud9da\udf0a\udb0a\udcbf\ud906\udd98\ud928\udffa\ud8bf\udc50\ud849\uddf8\ud876\ude2c\udb5b\udecd", "\uc20a\u5d62\u9dde\u6582\u4213\uc8cd\u265b\u8586\u883f\u1401\u2f60\u1796\u2a50\u55bc\ub534\u9bbe\u3b79", "\udb66\ude4f\ud993\udc41\udae0\udc45\ud904\udf7f\udafd\udeb4",
        57, -166, 406939116, 2360949426313353115L, 15642L, false, true, (char) 49359, (char) 46864,
        Double.longBitsToDouble(0x3fd76893e11d5dccL), Double.longBitsToDouble(0x3fe624c4b85c48f0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 2, 2, "\ud88e\udfec\ud994\udcae\uda07\udc57\udb5e\udd2f\ud9db\udfc2\ud882\udd3e", "\000\000\u0e6e\u084a\u4422\u8b7c\u09ff\u2885\u2334\u2f48", "\ud886\udc3a\ud9c3\udd5b\ud8c7\udfce\ud870\udff4",
        10, 11, 1996488704, -8472700385377822311L, -31142L, true, false, (char) 22136, (char) 51570,
        Double.longBitsToDouble(0x3fe204ce7060afa5L), Double.longBitsToDouble(0x3fedc7c17098f232L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver|doSolve||new:org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver|getMaximalOrder||new:org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver|guessX|double,[D,[D,int,int|new:org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver|solve|int,org.apache.commons.math.analysis.UnivariateFunction,double,double,double,org.apache.commons.math.analysis.solvers.AllowedSolution|new:org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver|solve|int,org.apache.commons.math.analysis.UnivariateFunction,double,double,org.apache.commons.math.analysis.solvers.AllowedSolution|new:org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:",
    "C|org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver|<init>|double,double,double,int",
    "C|org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver|<init>|double,double,int",
    "C|org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver|<init>|double,int",
    "C|org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver|<init>|",
    "M|org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver|doSolve||new:org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
