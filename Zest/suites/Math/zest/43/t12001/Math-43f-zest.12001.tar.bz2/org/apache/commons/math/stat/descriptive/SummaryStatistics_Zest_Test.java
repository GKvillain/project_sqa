package org.apache.commons.math.stat.descriptive;
import org.junit.Test;
import static org.junit.Assert.*;
public class SummaryStatistics_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 1, 14, 2, "\ud9f3\udfd0\udb25\udfa4\ud87f\udd72\ud9b9\ude98\ud96e\udca2\ud8d5\udddf\udbc7\udf46\ud82c\udc40\udb48\udf98", "\u3749\u5ccc\u23a6\u6d32\u3bcf\u667b\u48c4\u30c5\u235d\u6235\u3914\u2d41\u44f7\u8392\uadbe", "\ud89d\udde1\ud855\ude55\ud9b3\ude7e\udb8e\udda8\uda43\udef5\udbea\ude65\udb4a\udeb3\udb62\ude4c",
        6, 97848, 1203254786, 3168950835763099960L, -69372L, true, false, (char) 64079, (char) 50035,
        Double.longBitsToDouble(0x3fe424999dadbb35L), Double.longBitsToDouble(0x3fd55e92c952fbceL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 1, 14, 2, "\ud9f3\udfd0\udb25\udfa4\ud8aa\uddc5\ud9b9\ude98\ud96e\udca2\ud8d5\udddf\udbc7\udf46\ud82c\udc40\udaf1\udc0d", "\u3749\u5ccc\u23a6\u6d32\uc42c\u667b\u48c4\u30c5", "\udb25\ude2e\ud838\udd13\ud896\udd0d",
        52, 40913, -29069717, -8942011294293174002L, -46039L, true, true, (char) 10305, (char) 31923,
        Double.longBitsToDouble(0x3fd94e910abb12f8L), Double.longBitsToDouble(0x3fd2acc0632eaff8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=org.apache.commons.math.stat.descriptive.rank.Max:@? |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 8, 9, 4, "\ud9fa\udfd0\udb25\udfa4\ud87f\udd72\ud9b9\ude98\ud96e\udca2\ud8d5\udddf\udbc7\udf46\udb23\udcfa\udb48\udf50", "\u3749\u5ccc\u23a6\u6d32\u236d\uc750\u482e\u30c5\u235d\ub146\u3914\u2d41\u44f7\u8392\u98f0", "\ud89d\udde1\udbc0\udecb\ud80b\udeb1\udb8e\udda8\udb39\udeed\udbea\ude65\udb7c\udcb3\udb62\ude4c\ud812\udc3e",
        28, 72814, 1147971742, -3689560158227887768L, 28135L, false, false, (char) 50035, (char) 8631,
        Double.longBitsToDouble(0x3fc5b766a557a52cL), Double.longBitsToDouble(0x3fc52fbce3683a1cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.math.stat.descriptive.rank.Min:@? |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=java.lang.Boolean:false |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 13, 5, 2, "\ud843\ude13\udb25\udfa4\ud87f\udd72\ud9b9\ude98\ud96e\udca2\ud8f3\udddf\udbc7\udf46\ud82c\udc40\udb48\udf98", "\u3749\u5ccc\u23a6\u6d32\u3bcf\u667b\u48c4\u30c5\u235d\u6235\u3914\u2d41\u44f7\u8392\uadbe", "\ud89d\udde1\ud855\ude55\ud9b3\ude7e\udb8e\udda8\uda43\udef5f\udb4a\udeb3\udb62\ude4c",
        6, 97848, 1203254786, 3169009109879372088L, -69372L, true, false, (char) 64079, (char) 50035,
        Double.longBitsToDouble(0x3fe424999dadbb35L), Double.longBitsToDouble(0x3fd55e92c030fbceL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=java.lang.Long:0 |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 1, 14, 2, "\ud9f3\udfd0\udb25\udfa4\ud87f\udd72", "\uc0c2\u51a1\u6619\u1e23\ub4a2\u9f99\u3749\u5ccc\u23a6\u6d32\u3bcf\u667b\u48c4\u30c5\u235d\u48f7\u3984\u2d41\u44f7\u8392\u32a7\u3c5d\ubd06\u6133\u57ea\u295f\u672c\u1fe3\u0891\u674c\u97c2\u52a4", "\ud9c8\ude96\uda37\ude2c\ud85c\udec5\ud8c3\udf06\udbf8\udc77\ud80e\udf11\uda6b\udc3f\ud888\ude76\uda89\udc54\ud9d2\udcc0\ud978\udfb4\ud97f\udc17\udab6\ude5a\u5661\udb24\udd54\ud9e2\ude96\uda78\ude1b\ud808\udee2\ud948\udfdd\udaae\udd6f",
        28, 79784, 782771276, -1229910461548299133L, -22377L, true, false, (char) 25915, (char) 31825,
        Double.longBitsToDouble(0x3fe7772242614933L), Double.longBitsToDouble(0x3fe9f8d25e72d9f2L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 1\012min: 1.968231799764908E-9\012max: 1.968231799764908E-9\012mean: 1.968231799764908E-9\012geometric mean: 1.9682317997649104E-9\012variance: 0.0\012sum of squares: 3.8739364176058086E-18\012standard deviation: 0.0\012sum of logs: -20.046130260819\012\012",
        Z.run(T, 2, 1, 0, 2, "\ud9f3\udfd0\udb25\udfa4\ud87f\udd72\ud9b9\ude98\ud96e\udca2\ud8d5\udddf\udbc7\udf46\ud82c\udc40\udb48\udf98", "\000", "\udb46\udfe0",
        36, 30860, 294298618, -5459608969225378382L, -12985L, false, true, (char) 63446, (char) 32248,
        Double.longBitsToDouble(0x3e20e83000000000L), Double.longBitsToDouble(0x3e3e4ab000000000L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 1, 15, 1, "\ud9f3\udfd0\uda43\ude58\ud87f\udd72\ud9b9\ude98\ud9e7\udf98\udb8f\udcee\udbc7\udf46\ud82c\udc40\udb48\udf98", "\u3749\u5ccc\u23a6\u6d32\u3bcf\u667b\u0120\u5d12\u235d\u6235\u3914\u2d41\u44f7\u8392\uadbe", "\ud89d\udde1\ud855\ude55\ud9b3\ude7e\udb8e\udda8\uda43\udef5\udbea\ude65\udb4a\udeb3\uda31\ude4e",
        43, 95842, -1046465022, 3168950835763099960L, 20150L, false, true, (char) 64079, (char) 50035,
        Double.longBitsToDouble(0x3fe424999dadbb35L), Double.longBitsToDouble(0x3fd55e92c952fbceL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 4, 5, 2, "\ud9f3\udfd0\udb25\udfa4\ud87f\udd72\ud9b9\ude98\ud96e\udca2\ud8d5\udddf\udbc7\udf46\ud82c\udc40\udb48\udf98", "\u3749\u5ccc\u23a6\u6d32\u3bcf\u667b\u48c4\u30c5\u4d5c\u773e\u3914\u2d41\u44f7\u8392\uadbe", "\ud89d\udde1\ud855\ude55\ud9b3\ude7e\udb8e\udda8\uda43\udef5\udbea\ude65\udb4a\udeb3\udb62\ude4c",
        6, 97848, 1203254786, 3168950835763099960L, -69372L, true, false, (char) 64079, (char) 50035,
        Double.longBitsToDouble(0x3fe424999dadbb35L), Double.longBitsToDouble(0x3fd55e92c952fbceL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=java.lang.Boolean:false |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 1, 5, 2, "\ud9f3\udfd0\udb25\udfa4\ud87f\udd72\ud9b9\ude98\ud96e\udca2\ud8d5\udddf\udbc7\udf46\ud82c\udc40\udb48\udf98", "\u375a\ubaff\ud5a0\u6d32\u3bcf\ub57c\u5638\u8b98\u235d\u6235\u3914\u2d41\u44f7\u8392\ud260\u3c5d\ubd06\u6133\u57ea\u295f\u672c\u1fe3\u7f15\u674c\u97c2\uade2", "\uda78\udcf4\ud817\udefe\uda85\udecc\ud842\udf3a\udab9\udcc5\ud994\udf71\uda6b\udc3f\ud888\ude76\ud927\udf83\ud885\uddee\udaee\udc34\ud9ec\udf85\ud96f\udf30\ud94e\udf4a\uda58\udecb\u1d5f\ud97b\uddf7\udb3b\udc18\ud950\udef7\uda1d\udf00",
        0, 90203, 1369060966, 1048102598607439035L, 78333L, true, false, (char) 20648, (char) 63197,
        Double.longBitsToDouble(0x3fbd03a717c953a0L), Double.longBitsToDouble(0x3fd83c9ffabc0c8cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 1\012min: 0.2636718772903953\012max: 0.2636718772903953\012mean: 0.2636718772903953\012geometric mean: 0.2636718772903953\012variance: 0.0\012sum of squares: 0.06952285887384128\012standard deviation: 0.0\012sum of logs: -1.3330498379145421\012\0121=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 2\012min: 0.2636718772903953\012max: 0.2636718772903953\012mean: 0.2636718772903953\012geometric mean: 0.2636718772903953\012variance: 0.0\012sum of squares: 0.13904571774768257\012standard deviation: 0.0\012sum of logs: -2.6660996758290842\012\012",
        Z.run(T, 2, 0, 0, 2, "\ud9f3\udfd0\036\uda20\udd0f\ud9b9\ude98\ud96e\udca2\ud8d5\udddf\ubdda\000\000", "\u3749", "\udb46\udfe0\udae8\udef6\ud909\udcfc\ua3fa",
        11, 21736, 855825856, 4472953499195056377L, 16992L, false, false, (char) 60408, (char) 38495,
        Double.longBitsToDouble(0x3fd0e0000275943eL), Double.longBitsToDouble(0x3fee4ab523e2a637L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 5, 10, 11, "\udb9f\ude99\ud832\udfc7\ud8b1\ude07\ud9b9\ude98\ud96e\udca2\ud8d5\udddf\udbc7\udf46", "\ub4a2\u9f99\u3749\u5ccc\u23a6\u6d32", "\uda7b\udd02\ud9f2\udf19\ud913\udea5\uda3c\udcc1\ud9da\udf2a\udbff\udcc3\ud896\udd86\ud8fd\udfd8\ud854\udc57\udb67\ude50\udb44\udcca\ud89d\udde1\ud855\ude55\ud833\udffd\ud89c\udc4e\uda43\udf5b\udbea\ude65",
        56, 52323, 1465781016, 1522929742904833538L, 45720L, false, true, (char) 6080, (char) 23114,
        Double.longBitsToDouble(0x3fe295dfeaa9c8caL), Double.longBitsToDouble(0x3fe424999dadbb35L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 1\012min: 0.629467781029979\012max: 0.629467781029979\012mean: 0.629467781029979\012geometric mean: 0.629467781029979\012variance: 0.0\012sum of squares: 0.3962296873548056\012standard deviation: 0.0\012sum of logs: -0.46288060865033603\012\0121=java.lang.Long:1 |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 1\012min: 0.629467781029979\012max: 0.629467781029979\012mean: 0.629467781029979\012geometric mean: 0.629467781029979\012variance: 0.0\012sum of squares: 0.3962296873548056\012standard deviation: 0.0\012sum of logs: -0.46288060865033603\012\012",
        Z.run(T, 2, 0, 14, 14, "\ud9f3\udfd0\udb25\udfa4\ud87f\udd72\ud9b9\ude98\ud96e\udca2\ud8d5\udddf\udbc7\udf46\ud82c\udc40\udb48\udf98", "\u3749\u5ccc\u524b\u6d32\u3bcf\u667b\u48c4\u30c5\u235d\u6235\u3914\ud157\u44f7\u8392\uadbe", "\ud89d\udde1\ud811\udc14\ud9b3\uddbb\udb8e\udda8\uda43\udef5\ud958\uddfc\ud977\udcb7\udb7a\udd8c",
        6, 97848, 1203254786, 3130670238930450744L, -69372L, true, false, (char) 64079, (char) 50035,
        Double.longBitsToDouble(0x3fe424999dad1a35L), Double.longBitsToDouble(0x3fd55e92c952fbceL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 1, 1, 10, "\ud9f3\udfd0\udb25\udfa4\udbee\udc09\udbb9\udefa\uda04\udc36\ud8d5\udd8f\udbc7\udf46\ud82c\udc40\udb48\udf98", "\u3749\u5ccc\u23a6\u6d32\u3bcf\u667b\u48c4\u30c5\u235d\u6235\u459e\u6c3b\u75da\u8661\u8125", "\ud89d\udde1\ud855\ude55\ud9b3\ude7e\ud825\udc94\uda43\udf03\udaf4\udfdc\udbeb\udd1c\ud9ca\udc00",
        6, 97848, 1438135810, -4694897347047043271L, -69372L, true, false, (char) 64023, (char) 50035,
        Double.longBitsToDouble(0x3fe424999dadbb35L), Double.longBitsToDouble(0x3feaaf4963a97de7L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 1\012min: 0.2636718772903953\012max: 0.2636718772903953\012mean: 0.2636718772903953\012geometric mean: 0.2636718772903953\012variance: 0.0\012sum of squares: 0.06952285887384128\012standard deviation: 0.0\012sum of logs: -1.3330498379145421\012\012",
        Z.run(T, 2, 1, 0, 0, "\u8628\000\000\ud9b9\uddc3\ud96e\udca2\ud8d5\udddf\udbc7\udf46\ud82c\udc40\udb48\udf98", "\u3749", "\udab2\udc78\udae8\udef6\ud909\udcfc\uda7b\udd02",
        35, 80538, 855694784, 4472953499195056377L, -99917L, false, false, (char) 60408, (char) 65092,
        Double.longBitsToDouble(0x3fd0e0000275943eL), Double.longBitsToDouble(0x3ec48f8800000000L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 1, 2, 2, "\ud98b\udc5b\udb33\ude96\ud87f\udd72\ud9b9\ude98\ud96e\udca2\ud8d5\udddf\udbc7\udf46\ud82c\udc40\udb48\udf98", "\u3749\u2d19\u5082\u6d32\u3bcf\u667b\u48c4\u30c5\u235d\u6235\u41b0\ub572\u5dbe\u9550\uadbe", "\ud89d\udde1\ud855\ude55\ud9b3\ude7e\udb8e\udda8\uda43\udef5\udbea\ude65\udb4a\udeb3\udb62\ude4c",
        6, 97848, 1203254786, 3168950835763099960L, -69372L, true, false, (char) 64079, (char) 50035,
        Double.longBitsToDouble(0x3fe424999dadbb35L), Double.longBitsToDouble(0x3fd55e92c952fbceL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.apache.commons.math.stat.descriptive.moment.GeometricMean:@? |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=org.apache.commons.math.stat.descriptive.rank.Min:@? |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 6, 13, 8, "\ud9f3\udfd0\udb25\udfa4\ud87f\udd72\ud9b9\ude98\ud96e\udca2\ud8d5\udddf\udbc7\udf46\ud82c\udc40\udb48\udf98", "\u3749\u8b18\u293c\u95c9\u3bcf\u667b\u48c4\u30c5\u8b3d\u6235\u3914\u2d41\u44f7\u8392\uadbe", "\ud89d\udde1\ud855\ude55\ud998\udcef\udb38\udd30\uda43\udf68\udbea\ude65\udb4a\udeb3\udb45\udffe",
        12, 97848, 782906882, 3169092389295241528L, -69372L, true, false, (char) 64079, (char) 50035,
        Double.longBitsToDouble(0x3fe424999dadbb35L), Double.longBitsToDouble(0x3fd44fd08952fbceL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=org.apache.commons.math.stat.descriptive.moment.Mean:@? |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 1, 11, 0, "\ud9f3\udfd0\udb25\udfa4\ud87f\udd72\ud9b9\ude98\ud96e\udca2\ud8d5\udddf\udbc7\udf46", "\ub4a2\u9bbe\u1ea6\u5ccc\u23a6\u6d32", "\ud923\udcaf\ud96c\ude67\ud8db\udcb0\uda89\udcf5\ud9da\udf2a\udbff\udcc3\ud896\udd86\ud8fd\udfd8\ud854\udc57\udb71\udcf5\udb44\udcca\ud89d\udde1\ud855\ude55\ud9b3\ude7e\udb8e\udda8\ud9a4\ude05\udbea\ude65",
        4, 14405, 1465781031, -4359615795371149255L, 45720L, false, false, (char) 28490, (char) 23122,
        Double.longBitsToDouble(0x3fe295dfeaa9c8caL), Double.longBitsToDouble(0x3fe4249998adbb35L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 1, 1, 14, 2, "\udac2\udd52\udb25\udfba\ud883\ude72\ud98e\ude98", "\u51a1\u6619", "\udb5f\udeb2\udaa1\udcb0\uca6d\ud93d\udd0c\udb46\udfe0\udb9a\udec5",
        30, 37170, -1271138434, -7437442231079608896L, -58791L, true, true, (char) 10511, (char) 22619,
        Double.longBitsToDouble(0x3fe35bebf126c044L), Double.longBitsToDouble(0x3fe9641a593aca1fL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 1\012min: 0.9713371843099594\012max: 0.9713371843099594\012mean: 0.9713371843099594\012geometric mean: 0.9713371843099594\012variance: 0.0\012sum of squares: 0.9434959256232001\012standard deviation: 0.0\012sum of logs: -0.02908161627362208\012\0121=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 2\012min: 0.9713371843099594\012max: 0.9713371843099594\012mean: 0.9713371843099594\012geometric mean: 0.9713371843099594\012variance: 0.0\012sum of squares: 1.8869918512464001\012standard deviation: 0.0\012sum of logs: -0.05816323254724416\012\012",
        Z.run(T, 2, 0, 0, 2, "\ud9f3\udfd0", "\u8bda\000\uc0c2\u51a1\u1dce\000\ub47f\u9f99\u3749\u5ccc\u23a6d\u3bcf", "\udbb5\ude1a\udb4d\udf9c\uda3c\udcc1",
        36, 20345, 1593856999, -1808818314893520655L, -73403L, false, true, (char) 28959, (char) 31341,
        Double.longBitsToDouble(0x3fef1531b8000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012 |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 3, 12, 2, "\ud9f3\udfd0\udb25\udfa4\ud87f\udd72\ud9b9\ude98\ud96e\udca2\ud8d5\udddf\udbc7\udf46\ud82c\udc40\udb48\udf98", "\u79f4\u1275\u23a6\u6d32\u3bcf\u667b\u48c4\u30c5\u235d\u6235\u3914\u2d41\u44f7\u8392\uadbe", "\ud89d\udde1\ud855\ude55\ud9b3\ude7e\udb8e\udda8\uda43\udef5\udbea\ude65\udb4a\udeb3\udb62\ude4c",
        6, 97848, 1203254786, 3168950835763099960L, -69372L, true, false, (char) 64079, (char) 39454,
        Double.longBitsToDouble(0x3fe425ce5dadbb35L), Double.longBitsToDouble(0x3fd55e92c952fbceL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 8, 4, 6, "\ud9fa\udfd0\udb25\udfa4\ud87f\udd72", "\uc0c2\u51a1\u8e1a\u1ddb\ub4a2\u9f99\u3749\u5ccc\u23a6\u6d32\u236d\uc750\u482e\u30c5\u235d\ub146\u3914\u2d41\u44f7\u8392\u98f0\u5567\ubd06\u6133\uc088\u926f\u672c\ucbb8\u0891\u554d\u97c2\u52a4", "\ud8fd\udca6\ud9fa\udd91\ud85c\udec5\ud8e3\ude5b\udbf8\udc84\ud80e\udf11\uda6b\udc3f\ud888\ude76\ud9ba\udf56",
        11, 46297, 1715159258, 6633903203684879928L, 97732L, false, false, (char) 31347, (char) 40107,
        Double.longBitsToDouble(0x3fd62962f2697b5cL), Double.longBitsToDouble(0x3fe0bc95e12d9a89L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012 |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 8, 3, 2, "\ud9fb\udc5f\udb25\udfa4\ud948\ude56\ud98b\udce0\ud96e\udca2\ud8d5\udddf\udbc7\udf46\udb23\udcfa\udb48\udf50", "\u3749\u5ccc\u23a6\u6d32\u236d\uc750\u482e\u30c5\uaebe\u16cd\u3914\u2d41\u44f7\u8392\u98f0", "\ud89d\udde1\u06ec\ud95b\udd07\ud8b0\ude52\udb41\uddcb\udbea\ude65\udb7c\udcb3\udb62\ude4c\uda01\ude40",
        28, 72814, -1903359586, 2826317276081562848L, 28135L, false, false, (char) 50035, (char) 36791,
        Double.longBitsToDouble(0x3fa0a647855e94b0L), Double.longBitsToDouble(0x3fe4416d60da229cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012 |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=org.apache.commons.math.stat.descriptive.moment.GeometricMean:@? |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 3, 6, 4, "\ud9fa\udfd0\ud873\udddb\udb9a\udcfc\udb42\ude10\ud96e\udd48\ud8d5\udddf\udbc7\udf46\udb02\udeea\uda54\udc77", "\u3749\u5ccc\u23a6\u6d32\u1be8\u6626\ucc4d\u6ab2\u346e\u3952\u875e\u7979\u44f7\u8392", "\udb44\udcca\ud89d\udde1",
        26, 60832, -632880158, 5424975519065078720L, 27651L, false, true, (char) 51430, (char) 37776,
        Double.longBitsToDouble(0x3fc3c6825ecf79b0L), Double.longBitsToDouble(0x3fd687d9e0b91ec8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 4, 9, 4, "\ud9fa\udfd0\udb25\udfa4\ud87f\udd72\ud9b9\ude98\ud90a\ude3a\ud853\udede\ud8b7\udc1e\udb23\udcfa\udb48\udf50", "\u3930\u92e5\u28d5\u561e\u4e11\ub3ba\u482e\u30c5\u4fcf\ub0c1\ub28e\u2d11\u44f7\u8392\u98f0", "\ud89d\ude48\udbc0\udecb\ud80b\udeb1\udb8e\udda8\udb39\udeed\udbea\ude65\udb7c\udcb3\udb62\ude4c\ud9c7\udf7a",
        -2, 20171, 332430322, -3689560158227887768L, -15181L, false, false, (char) 50035, (char) 8631,
        Double.longBitsToDouble(0x3fc5b766a557a52cL), Double.longBitsToDouble(0x3fec959f3c169e7aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.math.stat.descriptive.rank.Min:@? |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 1\012min: 0.0\012max: 0.0\012mean: 0.0\012geometric mean: 0.0\012variance: 0.0\012sum of squares: 0.0\012standard deviation: 0.0\012sum of logs: -Infinity\012\012",
        Z.run(T, 2, 13, 0, 0, "\ud843\ude13\udb25\udfa4\uda20\udd68\ud9b9\ude98\ud96e\udca2\uda82\udd86\ud90c\udd66\ud82c\udc40\udb48\udf98", "\u3749\u5ccc\u23a6\u6d32\u14fe\u666f\u48c4\u30c5\u235d\u6235\u3914\u2d41\u44f7\u2a83\uadbe", "\ud89d\udde1\udab0\udd43\000\udb8e\udda8\uda43\udef5f\udb4a\udeb3\udb62\ude4c",
        6, 33952, 1203254786, 3169009109879372088L, 15118L, true, false, (char) 8631, (char) 47925,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe912017e5801eeL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=java.lang.Boolean:false |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 5, 5, 2, "\udb3f\udc14\udb25\udfa4\ud87f\udd72\ud8d3\uddc5\ud973\udea0\udb43\udeca\udbc7\udf46\ud82c\udc40\udb48\udf98", "\u3749\u5dfc\ud4e9\u9e62\u164c\u667b\u48c4\ua2d7\uc321\u1bde\uc8ad\u3f54\u470b\u1616\u0781", "\ud89d\udde1\ud814\udcd5\udb81\udfff",
        7, 75638, -384773696, 3873994617759804666L, 14943L, false, true, (char) 21950, (char) 10176,
        Double.longBitsToDouble(0x3fc0fd14f94aeff4L), Double.longBitsToDouble(0x3fd8caacaf2facb2L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 2, 2, 2, "\ud9f3\udfd0\udb25\udfa4\uda94\ude2a\ud911\udf84\ud96e\udcd1\ud8d5\udddf\udbc7\udf46\uda80\udeaa\udb48\udf98", "\000", "\udb46\udfe0",
        36, 30860, 294298618, -5459608969225378382L, 45326L, false, false, (char) 46875, (char) 10317,
        Double.longBitsToDouble(0x3fce3cdca1adf634L), Double.longBitsToDouble(0x3e20e83000000000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012 |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 10, 3, 11, "\ud89d\ude9d\udb25\udfa4\ud87f\udd72\ud9b9\ude98\ud96e\udca2", "\u6619\u29dc\u1f4e\000\000\000\u03f7\u6d32\u3bcf\u667b\u48c4", "\uda3c\udc0d",
        42, 51033, 6640615, -1808818671375806223L, -100000L, false, true, (char) 10240, (char) 2991,
        Double.longBitsToDouble(0x3fe6f98ce227717cL), Double.longBitsToDouble(0x3fedcd518f4edb8fL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 1\012min: 0.9952208638213415\012max: 0.9952208638213415\012mean: 0.9952208638213415\012geometric mean: 0.9952208638213415\012variance: 0.0\012sum of squares: 0.990464567785297\012standard deviation: 0.0\012sum of logs: -0.0047905927662682465\012\012",
        Z.run(T, 2, 1, 0, 2, "\ud9f3\udfd0\udb25\udfa4\ud87f\udd72\udb67\ude8b\ud96e\udca2\ud8d5\udddf\uda74\udc7c\ud82c\udc40\udb48\udf98", "\u9ef6\000\u03f7\u6d32\u3bcf\u667b\u48c4\u09c5\u235d\u6235\ud409\u240f\u145f\u833f\uadbek\u53d9\u010f", "\ud89e\udc2b\udb0b\ude73\udb8f\udc56\udaed\udd86\ud9a3\udc1e\u17a9\ud8f7\ude3d\ud8d1\udf55\ud9e6\ude03\ud854\udfa7\ud882\ude71\uda3f\uddab\ud8fa\udc3b\ud952\udfa9\uda66\udfb3\udabb\udc88\ud86c\udc17\ud970\udfb4\uda93\udc1a\udbf7\udee6\udafb\udfde\udbff\udc96\ud96b\udcac",
        36, 82174, 1122220307, 7749923178576616521L, 98123L, true, false, (char) 47349, (char) 16717,
        Double.longBitsToDouble(0x3fefd8d96ccd1ae1L), Double.longBitsToDouble(0x3f90a215d7df0620L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 1\012min: 0.0\012max: 0.0\012mean: 0.0\012geometric mean: 0.0\012variance: 0.0\012sum of squares: 0.0\012standard deviation: 0.0\012sum of logs: -Infinity\012\0121=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 2\012min: 0.0\012max: 0.0\012mean: 0.0\012geometric mean: 0.0\012variance: 0.0\012sum of squares: 0.0\012standard deviation: 0.0\012sum of logs: -Infinity\012\012",
        Z.run(T, 2, 0, 0, 2, "\ud9f3\udfd0\036", "\u3b91", "\ud82c\udc40\udb48\udf98\u6723\000\000\000\ud8ff\udd5e\udb46\udfe0\u00a4\ud909\udcf0\uda7b\udd02",
        35, 80538, 855825856, 4472953499189027065L, 16992L, true, false, (char) 32248, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fee4ab006d003c6L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.math.stat.descriptive.moment.GeometricMean:@? |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=org.apache.commons.math.stat.descriptive.moment.GeometricMean:@? |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 6, 6, 2, "\ud9f3\udfd0\ub288\ud810\uddaa\uda8d\udea0\ud92d\udcb9\udb51\udca0\udb9a\ude47\ud82c\udc40\ud889\udc95", "\000", "\udb46\udfe0",
        36, 30860, 294298618, -5459608969225378382L, -12985L, false, true, (char) 63446, (char) 41976,
        Double.longBitsToDouble(0x3e20e833b0000000L), Double.longBitsToDouble(0x3e3e4ab000000000L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.math.stat.descriptive.moment.Mean:@? |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=org.apache.commons.math.stat.descriptive.moment.Mean:@? |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 11, 11, 2, "\uda8b\udfbd\udb25\udfa4\ud917\udff4\ud858\udf51\ud96e\udd9c\ud8d5\udddf\udbc7\udf46\udaf2\udc43\udb48\udf98", "\u9752\u51a0\u03f7\u6d32\u3bcf\u9e42\u48c4\u30c5\u235d\u6235\u9539\u81ea\u13c5\u833f\uadbe", "\ue10e",
        1, 14538, -800565613, 4350788070598501125L, -63431L, true, true, (char) 63149, (char) 16351,
        Double.longBitsToDouble(0x3fcee2c4c5365c0cL), Double.longBitsToDouble(0x3fb3f9847b9be458L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012 |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 3, 15, 1, "\udaa7\udd21\uda43\ude58\ud9cc\udc33\udb3b\udd79\ud9e8\udc74\udb8f\udcee\udbc7\udf46\ud866\udfdc\udb47\udce6", "\u21c4\u6564\uca60\u6d32\u3bcf", "\ud8c0\ude4f\udb4d\udf9c\uda3c\udcc1",
        42, 20345, 1600476135, -1584482758462370001L, -73403L, false, true, (char) 15194, (char) 31341,
        Double.longBitsToDouble(0x3fef1531bc7eda47L), Double.longBitsToDouble(0x3fe940a9c994e910L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 1\012min: 0.9934263617798501\012max: 0.9934263617798501\012mean: 0.9934263617798501\012geometric mean: 0.9934263617798501\012variance: 0.0\012sum of squares: 0.9868959362791496\012standard deviation: 0.0\012sum of logs: -0.006595339737439337\012\0121=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 2\012min: 0.9934263617798501\012max: 0.9934263617798501\012mean: 0.9934263617798501\012geometric mean: 0.9934263617798501\012variance: 0.0\012sum of squares: 1.9737918725582992\012standard deviation: 0.0\012sum of logs: -0.013190679474878673\012\012",
        Z.run(T, 2, 0, 0, 2, "\ud9f3\udfd0\036\uda20\udd0f\ud9b9\ude98", "\ubdda\000\000\000\u9f99\u3749\u1345\u524c\u6d24\u3bcf\u6710\ua3fa", "\uda3c\udcc1",
        -3, 20345, 231, -1808818671375810560L, 30078L, true, true, (char) 22193, (char) 4979,
        Double.longBitsToDouble(0x3fefca2614da84e1L), Double.longBitsToDouble(0x3feebae083eb8183L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 1\012min: 0.26367218187653296\012max: 0.26367218187653296\012mean: 0.26367218187653296\012geometric mean: 0.26367218187653296\012variance: 0.0\012sum of squares: 0.06952301949553148\012standard deviation: 0.0\012sum of logs: -1.33304868274409\012\0121=!org.apache.commons.math.exception.MathIllegalStateException\012",
        Z.run(T, 2, 0, 1, 2, "\udac8\udce5\u4e18\uda20\udd0f\uda68\uddf0\udbac\udc58\udb65\udee2\ud9f2\udc42\uda72\uddf8\udb68\udeb3", "\u066f", "\ud8ee\udf4c\ud839\udef4\ud909\udd9b\ua3fa",
        9, 77768, 855825856, -3542046465237479967L, -35098L, false, false, (char) 6392, (char) 61363,
        Double.longBitsToDouble(0x3fd0e0014981943eL), Double.longBitsToDouble(0x3fee62b35925bc54L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 15, 15, 2, "\ud9f3\udfd0\036\ud950\udfa7\udb37\udd33\ud8b4\udc5b\ud9b0\uddb0\uc662\ud90b\udc25\udbe0\ude75", "\u12de\u210f\u46e0\u5bc9\u6220\u1a80\u0322\u0092\u15aa\u6235", "<\ud8fd\udf85\ud84f\udf66\ud9e9\udd90\ud800\udd79\ud89d\udde1\ud989\udc50\udbcf\udd25\udb77\udf81\ud936\udec1",
        29, 24885, 1061538048, -1009836937402178792L, -64554L, true, true, (char) 38648, (char) 43499,
        Double.longBitsToDouble(0x3fd8134449eec2d4L), Double.longBitsToDouble(0x3fc1b9fe424892b0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012 |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 3, 7, 11, "\ud9f3\udfd0\udb25\udfa4\udba3\udd44\ud9b8\udc3b\ud96e\udca2\ud8d5\udddf\udbc7\udf46\ud82c\udc40\uda5e\udc61", "\u3749\u5ccc\u524b\u6d32", "\uda7b\udd02\udbb5\ude1a\ud86c\udce5\uda3b\udf7e\ud9da\udf2a\udb1d\udc67\ud8a4\udf86\ud8fd\udfd8\ud854\udc57\udb67\ude50\udb44\udcca\ud89d\udde1\ud811\udc54\ud9b3\uddbb\ud95e\udd3a\uda43\udef5\ud958\uddfc\ud977\udcb7\udb7a\udd8c\ud812\udc3e\ud8c1\udcf7\u0a3c\ud9b8\ude8e\uda37\ude2c\ud85c\udec5",
        34, 11303, -926269870, -7839646922813632892L, 95243L, true, true, (char) 48187, (char) 38055,
        Double.longBitsToDouble(0x3fdafaa079c49150L), Double.longBitsToDouble(0x3fe4926d727b8549L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012 |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 3, 4, 9, "\ud9f3\udfd0\udb25\udfa4\ud87f\udd72\ud9b9\ude98\ud96e\udca2\ud8d5\udddf\udbc7\udf46\ud82c\udc40", "\u9f99\u484d\u1275\u23a6\u6d32\u3bcf", "\udbb5\ude1a\udb4d\udf9c\uda3c\udcc1",
        42, 37473, 295489226, -1808952674791649269L, -73403L, false, true, (char) 15194, (char) 31341,
        Double.longBitsToDouble(0x3fef1531be7eda47L), Double.longBitsToDouble(0x3fee003f6994e910L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012 |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012 |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 3, 3, 2, "\ud9f3\udfd0\udb25\udfa4\ud87f\udd72\ud9b9\ude98\ud96e\udca2\ud8d5\udddf\udbc7\udf46\ud82c\udc40\udb48\udf98", "\u79f4\u1275\u23a6\u6d32\u3bcf\u667b\u48c4\u30c5\u235d\u6235\u3914\u2d41\u44f7\u8392\uadbe", "\ud89d\udde1\ud855\ude55\ud9b3\ude7e\udb7b\udede\uda19\udcb3\udbea\ude65\udb4a\udeb3\udb62\ude4c",
        6, 97848, 1203254786, 3168950835763099960L, -69372L, true, false, (char) 64079, (char) 39454,
        Double.longBitsToDouble(0x3fe425ce5dadbb35L), Double.longBitsToDouble(0x3feaaf4964a97de7L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\0121=java.lang.Boolean:false |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 0\012min: NaN\012max: NaN\012mean: NaN\012geometric mean: NaN\012variance: NaN\012sum of squares: 0.0\012standard deviation: NaN\012sum of logs: 0.0\012\012",
        Z.run(T, 2, 5, 5, 5, "\udb2b\ude76", "\ubded\u0eb6\u03d6\u4e73\u6619\u4443\ub4a2\u9f99\u3749\u5dfc\ud4e9\u9e62\u164c", "\ud816\udcd7\ud9f9\udf55\ud974\uddb2",
        -5, 25531, -698710075, -627662359931971975L, -35458L, false, true, (char) 62158, (char) 19109,
        Double.longBitsToDouble(0x3fcf491b34e57564L), Double.longBitsToDouble(0x3febd5ef2602e95eL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.SummaryStatistics:SummaryStatistics:\012n: 1\012min: 1.7600682022944625E-9\012max: 1.7600682022944625E-9\012mean: 1.7600682022944625E-9\012geometric mean: 1.7600682022944598E-9\012variance: 0.0\012sum of squares: 3.097840076728061E-18\012standard deviation: 0.0\012sum of logs: -20.157913277343493\012\012",
        Z.run(T, 1, 0, 14, 2, "\ud9f3\udfd0\u5d1e\000\000\000\000\000\000\000", "\000", "",
        36, 19012, 1690670860, 1072470622208L, -25696L, false, true, (char) 57099, (char) 16476,
        Double.longBitsToDouble(0x3e1e3cdca0000000L), Double.longBitsToDouble(0x3fe35bec68000044L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|addValue|double|new:org.apache.commons.math.stat.descriptive.SummaryStatistics:",
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|checkEmpty||new:org.apache.commons.math.stat.descriptive.SummaryStatistics:",
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|clear||new:org.apache.commons.math.stat.descriptive.SummaryStatistics:",
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|copy||new:org.apache.commons.math.stat.descriptive.SummaryStatistics:",
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|copy|org.apache.commons.math.stat.descriptive.SummaryStatistics,org.apache.commons.math.stat.descriptive.SummaryStatistics|static",
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|equals|java.lang.Object|new:org.apache.commons.math.stat.descriptive.SummaryStatistics:",
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|getGeoMeanImpl||new:org.apache.commons.math.stat.descriptive.SummaryStatistics:",
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|getGeometricMean||new:org.apache.commons.math.stat.descriptive.SummaryStatistics:",
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|getMax||new:org.apache.commons.math.stat.descriptive.SummaryStatistics:",
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|getMaxImpl||new:org.apache.commons.math.stat.descriptive.SummaryStatistics:",
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|getMean||new:org.apache.commons.math.stat.descriptive.SummaryStatistics:",
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|getMeanImpl||new:org.apache.commons.math.stat.descriptive.SummaryStatistics:",
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|getMin||new:org.apache.commons.math.stat.descriptive.SummaryStatistics:",
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|getMinImpl||new:org.apache.commons.math.stat.descriptive.SummaryStatistics:",
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|getN||new:org.apache.commons.math.stat.descriptive.SummaryStatistics:",
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|getPopulationVariance||new:org.apache.commons.math.stat.descriptive.SummaryStatistics:",
    "M|org.apache.commons.math.stat.descriptive.SummaryStatistics|addValue|double|new:org.apache.commons.math.stat.descriptive.SummaryStatistics:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
