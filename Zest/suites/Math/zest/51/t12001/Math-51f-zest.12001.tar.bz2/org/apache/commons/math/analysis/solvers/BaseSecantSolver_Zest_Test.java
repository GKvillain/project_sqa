package org.apache.commons.math.analysis.solvers;
import org.junit.Test;
import static org.junit.Assert.*;
public class BaseSecantSolver_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 0, 0, 3, "\ud972\udf02\ud862\ude84\ud938\udf12\ud8e5\udf1b\ud982\udf3a\udb5a\ude98\ud8d4\udf96\udb94\udd39\ud82e\ude0f\udb40\udda6\ud855\udc98\ud989\udf1e\ud859\ude46\udbfd\udcf8\ud8bb\udf24\uda75\ude11\u2029\uda80\udcb7\udb21\udd50\ud901\uddfa\udbe6\udfab\uda37\ude2a\uda86\udffe\uda56\udf44\ud922\udeec\u1699\uda04\udd70\ud98a\udc29", "\u9ecc\ub031\u26d1\u9521\uc0f2\u3caa\u16bc\u6044\u9140\u1f67", "\ud8e5\udeac\ud9d9\udfa2\uda32\ude1d\udaf0\udd07\uda52\udc45",
        44, 70720, 2056467798, -414377499444921746L, -48336L, false, true, (char) 19181, (char) 63362,
        Double.longBitsToDouble(0x3fca307a615ff32cL), Double.longBitsToDouble(0x3fee3e435433bf1bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 0, 0, 3, "\ud972\udf02\ud862\ude84\ud938\udf12\ud8e5\udf1b\ud982\udf3a\udb5a\ude98\ud8d4\udf96\udb96\ude17\ud82e\ude0f\udb40\udda6\ud855\udc98\ud989\udf1e\ud859\ude46\udbfd\udcf8\ud8bb\udf24\uda75\ude11\u2029\uda80\udcb7\udb21\udd50\ud901\uddfa\udbe6\udfab\uda37\ude2a\uda86\udffe\uda56\udf44\ud922\udeec\u1699\uda04\udd70\ud98a\udc29\udac6\udfd5\ud941\uddc8\udb18\udf3c\udb57\udffd\ud882\uddaa\ud9c1\udc9d\udbaf\udfa7\uda43\udc9c\udab2\udc62\ud97e\udf2c\ud8bf\ude44\udac4\ude1c\uda4f\udfbc\uda95\udf05\ud8e5\udeac\ud9d9\udfa2\uda32\ude1d", "\uaeaf\ua983\ub69c\u270b\u854c\u7e28\uc1ee\u298d\ub026\u6977\u6a22\ubceb\u5d04\u2e76\ud2dd\ub485\uc299\u48ec\u0dd9\u8074\u933f\u9880\u6e5b\ub54a\u27c5\u6823\u8070\u7891\u2274\u4dc9\u23dc\u1615\ua659\u4fc7\ub374\u127f\uccee", "\ud38e\ud9d1\udd1e\ud8dc\udf63\uda21\udfb4\ud98a\udcf7\udbc7\udf50\udad2\udcb0\ud822\udf3d\ud97f\udc25\ud8ef\udc0d\ud879\udec6\udb17\udd8e\udaf9\udc81\uda1d\udeb3\ud9d8\udd34\uda59\udf6f\ud8f9\udd7b\udbc0\udf4d\udbae\udf40\udbad\udfbc\uda6e\uddcc\uda9a\uddf4\ud9af\udfe8\ud920\udf70\udbcb\uded6\udb8d\uddd8\ud80b\udec9\uf834\uda6c\ude0c\ud928\udcf4\udaca\udcae\ud8a3\udd43\udbe1\udcaf\udbb5\udfa7\udbf9\udc6d\ud8f5\udd23\ud946\udd5f\udb01\udf47\ud9c5\udc12\ud94f\udeb4\ud804\udc72\ud993\udfa2\ud985\uddd2\uda1f\udf6b\ud820\udd0f\ud9ca\udcf9\ud830\uddca\uda9c\ude61\udb1b\udd3a\uda26\udd56\udae8\udd6d\uda96\ude2e\udbca\udece\ud9b0\udcdd\ud887\ude9c\udbd7\udfb8\udb6f\uddc1\udb3e\udd50\udba7\ude8e\ud8f7\udf95\udacc\udf40\ud884\uddac\ud845\udfc7\uda9b\udf4f\udbb6\udc93\u7fc7\uda38\ude04\ud9ce\uddb0\udb12\uddaf\udba9\udfa2\ud94f\udd93\uda9b\udd95\udaf4\udde6\udac4\udecc\u690c\ud9af\ude94\ud9ba\uddb0",
        -2, 35385, 644973767, 912226117097036978L, 71753L, true, true, (char) 40273, (char) 37585,
        Double.longBitsToDouble(0x3fa04f71e6fa5d70L), Double.longBitsToDouble(0x3fedea0b60c50cecL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 1, 0, 3, "\ud972\udf02\ud862\ude84\ud938\udf12\ud8e5\udf1b\ud982\udf3a\udb5a\ude98\ud8d4\udf96\udb94\udd39\ud82e\ude0f\udb40\udda6\ud855\udc98\ud989\udf1e\ud859\ude46\udb62\udc2c\ud8bb\udf24\uda75\ude11\u2029\uda80\udcb7\udb21\udd50\ud901\uddfa\udbe6\udfab\uda37\ude2a\uda86\udffe\uda56\udf44\ud922\udeec\u1699\uda04\udd70\ud98a\udc29", "\u9ecc\ub031\u26d1\u9521\uc0f2\u3caa\u16bc\u6044\u9140\u1f67", "\ud8e5\udeac\ud9d9\udfa2\uda32\ude1d\udaf0\udd07\uda52\udc45",
        44, 70720, 2056467798, -414377499444921746L, -38061L, true, false, (char) 10933, (char) 62853,
        Double.longBitsToDouble(0x3fc370ca40627da8L), Double.longBitsToDouble(0x3fca307a615ff32cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 1, 2, 0, 3, "\ud972\udf02\ud862\ude84\ud876\ude70\uda67\ude87\uda3a\udff5\udb44\udecf\ud8d4\udf96\udb94\udd39\ud82e\ude0f\udb40\udda6\ud855\udc98\ud989\udf1e\ud859\ude46\udbfd\udcf8\ud8bb\udf24\uda75\ude11\u2029\uda80\udcb7\udb21\udd50\ud901\uddfa\udbe6\udfab\uda37\ude2a\uda86\udffe\uda56\udf44\ud922\udeec\u1699\uda04\udd70\ud98a\udc29", "\u9ecc\ub031\u26d1\u9521\uc0f2\u016e\u7d20\u6044\u9140\u1f67", "\ud8e5\udeac\ud9d9\udfa2\uda32\ude1d\udaf0\udd07\uda52\udc45",
        44, 70720, 2056467798, -414377499280491922L, -48336L, false, true, (char) 19181, (char) 63362,
        Double.longBitsToDouble(0x3fca307a615ff32cL), Double.longBitsToDouble(0x3fee3e435433bf1bL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 3, 0, 3, "\ud972\udf02\ud862\ude84\ud938\udf12\ud8e5\udf1b\ud982\udf3a\ud98d\udf11\ud88d\udd00\udb94\udd39\ud82e\ude0f\udb40\udda6\udbe4\ude24\ud98a\udc09\ud859\ude46\udbfd\udcf8\ud8bb\udf24\uda75\ude11\u2029\uda80\udcb7\udb21\udd50\ud901\uddfa\udbe6\udfab\uda37\ude2a\uda86\udffe\uda56\udf44\ud922\udeec\u63e3\uda04\udd70\ud98a\udc29", "\u9ecc\ub031\u26d1\u9521\uc0f2\u3caa\u16bc\u754d\u9140\u1f67", "\ud8e5\udeac\ud9d9\udfa2\uda32\ude1d\udaf0\udd07\uda52\udc45\udaff\ude54\ud9ee\udc37\ud8c3\udc8f",
        11, 87278, -672443643, -8654642464576637259L, 68366L, true, false, (char) 63362, (char) 60580,
        Double.longBitsToDouble(0x3fb5ff32fe3e41a0L), Double.longBitsToDouble(0x3fa9df8dbb0dd590L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 0, 0, 3, "\ud972\udf02\ud94e\ude7a\ud938\udf12\udb3a\udd85\udaca\udedc\udb5a\ude98\ud8d4\udf96\udb1b\udfb1\udac0\udeaa\udb2c\udca0\ud855\udc98\ud989\udf1e\ud859\ude46\udbfd\udcf8\ud8bb\udf24\uda75\ude11\u2029\uda80\udcb7\udb21\udd50\ud901\uddfa\udbe6\udfab\uda37\ude2a\uda86\udffe\uda56\udf44\ud922\udeec\u1699\uda04\udd70\ud98a\udc29", "\u9ecc\ub031\u26d1\u9521\uc0f2\u3caa\u16bc\u6044\u9140\u1f67", "\ud8e5\udeac\ud9d9\udfa2\uda32\ude1d\udaf0\udd07\uda52\udc45",
        44, 15316, 2056467822, -414377499444921746L, -48336L, false, true, (char) 36394, (char) 63362,
        Double.longBitsToDouble(0x3fca307a615ff32cL), Double.longBitsToDouble(0x3fee3e435433bf1bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.analysis.solvers.BaseSecantSolver|doSolve||new:org.apache.commons.math.analysis.solvers.IllinoisSolver:",
    "M|org.apache.commons.math.analysis.solvers.BaseSecantSolver|solve|int,org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double|new:org.apache.commons.math.analysis.solvers.IllinoisSolver:",
    "M|org.apache.commons.math.analysis.solvers.BaseSecantSolver|solve|int,org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double,org.apache.commons.math.analysis.solvers.AllowedSolution|new:org.apache.commons.math.analysis.solvers.IllinoisSolver:",
    "M|org.apache.commons.math.analysis.solvers.BaseSecantSolver|solve|int,org.apache.commons.math.analysis.UnivariateRealFunction,double,double,org.apache.commons.math.analysis.solvers.AllowedSolution|new:org.apache.commons.math.analysis.solvers.IllinoisSolver:",
    "M|org.apache.commons.math.analysis.solvers.BaseSecantSolver|doSolve||new:org.apache.commons.math.analysis.solvers.IllinoisSolver:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
