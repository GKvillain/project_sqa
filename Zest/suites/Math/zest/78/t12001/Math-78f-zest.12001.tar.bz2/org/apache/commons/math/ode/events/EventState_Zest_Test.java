package org.apache.commons.math.ode.events;
import org.junit.Test;
import static org.junit.Assert.*;
public class EventState_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Double:0.7728214862417613 |this=org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 1, 1, 10, 7, "\ud923\udeb0\udb01\udce5\ud9be\udde6\udb9a\ude8b\udb30\udd1d\udadb\udf3a\uda38\udee4\uda1a\ude61\udbd2\ude3d\ue7db\ud9a6\udf52\ud854\udfc2", "\u8abc\u5728\u3466\uc125\u3d94", "\ud96e\udca9\udaed\udda1",
        36, 90454, -1606697622, -5124160834841711146L, 37444L, false, false, (char) 14069, (char) 11502,
        Double.longBitsToDouble(0x3fd6987914acb6aaL), Double.longBitsToDouble(0x3fe8baf42021be4aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Double:0.7728214862417613 |this=org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 1, 1, 10, 7, "\ud923\udeb0\udb01\udce5\ud9be\udde6\udb9a\ude8b\udb30\udd1d\udadb\udf3a\uda38\udee4\uda1a\ude61\udbd2\ude3d\ue7db\ua5d6\ud97f\udcae", "\u8abc\u5728\u3466\uc125\u3d94", "\ud96e\udca9\udaed\udda1",
        36, 90454, -1606697622, -5124160834841711146L, 37444L, false, false, (char) 14069, (char) 11502,
        Double.longBitsToDouble(0x3fd6987914acb6aaL), Double.longBitsToDouble(0x3fe8baf42021be4aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Double:0.8266234922998325 |this=org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 1, 1, 10, 2, "\ud866\udec5\udafa\udd8b\ud9be\udde6\udb9a\ude8b\udb30\udd1d\udadb\udf3a\ud870\udf4e", "\u02b4\ua471\ubc4d\u064a\u7ad1\ua31c\u4bae\u1215\uc125\u777a\u8843\ua8d0\ucc0c\u1c1d", "\uda88\udde1\ud96f\udfdc\ud92d\udfe8\udba1\ude5a\udba9\udcb5\ud88f\ude4f\udb77\uddc4\ud84c\udf55\ud8b8\udd12\udb55\udeca\ud916\udde9",
        41, 95549, 1366859480, -5902064202271083848L, -45301L, true, true, (char) 19209, (char) 42954,
        Double.longBitsToDouble(0x3fcf548345d8629cL), Double.longBitsToDouble(0x3fea73b31c310f0fL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a1=[D:[[27769.5, 28480.0, 27690.5, 28635.5, 27847.0, 28346.0, 10540.5, 28032.0]] |this=org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 1, 7, 10, 4, "\ud923\udeb0\ud885\udfe7\ud9be\udda4\u5289\udb30\udd1d\udbf6\uddbc\udb7d\ude66\uda34\ude0f\ud852\udeee", "\u8880\u06b4\u343a\u8abc\u5728\u8221\uc125\ubc41\u6dbb\u4388\u0340\u193b\ua74d", "\ud87d\udcc4\ud947\udd42",
        52, 85684, 815977874, 3638915451571010158L, -3009L, true, true, (char) 46486, (char) 13123,
        Double.longBitsToDouble(0x3fe0e543ba23bd89L), Double.longBitsToDouble(0x3fe61177edb0c84cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 1, 9, 0, 7, "\ud923\udeb0\udb01\udce5\ud8c4\udfc9\udb9a\ude8b\udb30\udd1d\udadb\udf3a\uda38\udee4\ud971\udf8d\ud8ee\udcad\ud991\udd35\ud9a6\udf52\ud854\udfc2", "\u8abc", "\uda8d\udeb2\ud882\udfb6\ud8c5\udc2d\ud827\udd31\u7502",
        50, 6801, 148763454, -6900713742244031777L, -18200L, false, true, (char) 2054, (char) 14069,
        Double.longBitsToDouble(0x3fe3719401698791L), Double.longBitsToDouble(0x3fe2b2daaf175e84L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\ud923\udeb0", "\ud180\u47d6\u287a\u47af\u0d8e", "\ud9a6\udf52\u00ca\udbe5\udc91\uda92\udeb9\uda84\udc84\udb43\udf23\000\000\udab2\udc78\ud8c5\udc2d\ud958\udcc9\000\udaed\udd6a\ud990\udcbb\udb08\udfc3\ud8a5\udfc5",
        57, 96694, 805355640, -5110995258764537710L, 29646L, false, true, (char) 23979, (char) 28059,
        Double.longBitsToDouble(0x3fa0df2572bf6410L), Double.longBitsToDouble(0x3fdd2eee8715520eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:11 |this=org.apache.commons.math.ode.events.EventState:@?\0121=new org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 2, 5, 10, 5, "\ud8c1\udfe4\udbf7\ude51\ud9be\udde9\udb9a\ude8b\ud80c\udd5b\uda0e\udeb1\ud8d3\udff2\ud94b\udcf5\ud894\uded2\ue815\ud9a6\udf52\ud9b0\udc0f", "\u976c\u5728\uac63\u2f62\u4eaa\u3a38\u50ab\u485e\u3444", "\ud9c5\udc29\ufefc\udba6\udc98\uda6c\udcab",
        11, 35770, -345803037, -8688409678744143255L, -75083L, true, false, (char) 56091, (char) 14169,
        Double.longBitsToDouble(0x3fe3d66e038eeae7L), Double.longBitsToDouble(0x3fb38322fe222350L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a1=[D:[[27769.5, 28480.0, 28008.5, 28250.5, 27847.0, 28379.0, 28085.0, 28461.5]] |this=org.apache.commons.math.ode.events.EventState:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 7, "\ud923\udeb0\udb01\udce5\ud9be\udde6\udb9a\ude8b\udb30\udd1d\udadb\udf3a\uda38\udee4\uda1a\ude61\udbd2\ude3d\ue7db\ud9a6\udf52\ud854\udfc2", "\u8abc\u5728\u3466\u3ffe\u34a7", "\ud96e\udca9\udaed\udda1",
        36, 90454, -1606697622, -5124160834841711146L, -98381L, false, false, (char) 42362, (char) 44171,
        Double.longBitsToDouble(0x3fe8baf21821be4aL), Double.longBitsToDouble(0x3fec6941da1a005aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 1, 10, 10, 6, "\uda09\udfd5\udb6d\udef7\ud9be\udde6\udb9a\udeb1\udb30\udd1d\udadb\udf3a\uda38\udee4\uda1a\ude61\uda4e\udc33\ue7fa\ud9a6\udf52\ud854\udfc2\udbeb\udc5b\udb19\udc52\ud8e9\udda0\udb3c\uddb4", "\u3d94\ub13c\u692b\u4851\u3444\ubb2d\u2331\u733e\u9688\u52af\u9155\u2a20\u2a36\u51f9\u0bb2\u81cd\ud2f2", "\ud9f8\udc67\ud9c2\udf78\udb1f\uddc8",
        3, 93968, 1254950284, 5638000806410181884L, -46880L, false, true, (char) 54557, (char) 40891,
        Double.longBitsToDouble(0x3fe99f62d964a023L), Double.longBitsToDouble(0x3fe7935afdb40446L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 1, 10, 10, 7, "\ud923\udeb0\udb01\udce5\ud9be\udde6\udb9a\ude8b\ud88f\udd63\udadb\udf26\ud915\udc12\udbb6\udd65\udbd0\ude3b\ud9bd\udca5\ud9a6\udf52\ud854\udfc2", "\u8abc\u4682\uab8b\uc125\u3d94", "\ud96e\udca9\ud938\udcba\u0ea2",
        43, 38843, 354817663, -7845457072908094673L, -23583L, true, false, (char) 11502, (char) 48974,
        Double.longBitsToDouble(0x3fe2b2dbcf175e84L), Double.longBitsToDouble(0x3fa0df250a9fba40L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 1, 2, 10, 7, "\ud923\udeb0\udb01\udce5", "\u9624", "\uda1a\ude66\udb92\udfbf\uda36\ude9a\ud97e\udc4f\ud854\udfc2\udbeb\udf5b\ud95a\udebd\uda84\udc84\udb43\udef4\uda7f\uddb5\udae1\udebc\ud96c\udeaa\ud942\uddd8\ud827\udd31\udb45\udca0",
        50, 6801, 148763454, -6900713742244031777L, -18200L, false, false, (char) 2591, (char) 14069,
        Double.longBitsToDouble(0x3fe371940169d694L), Double.longBitsToDouble(0x3fe2b2daaf175e84L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Double:0.44692627533803964 |this=org.apache.commons.math.ode.events.EventState:@?\0121=java.lang.Double:0.06304273693131901 |this=org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 2, 1, 4, 7, "\udb12\udeca\udb01\udce5\udaab\udefb", "\u12ec\u1ea9\u3fdf\u2f59\u55bf\uad0f\u3eb4\uaf05\ua510\u8abc\u5728\u3466", "\ud8b5\udc2d\ud827\udd31\ud96e\udca9\udaed\udda1\ud9b0\udf7f\udb08\udfc3\ud8a5\udfc5\ud873\udeae\udbc3\udee9\ud9c3\ude9d\udbb4\udc2d\udba4\udcb9\udb40\udce1\u6ce6\ud914\udcbf\udba5\udfe7\ud9db\uddb8\udb78\ude20\ud87e\ude92",
        30, 70389, 86632091, -1146536845969236952L, 56365L, true, false, (char) 54947, (char) 21838,
        Double.longBitsToDouble(0x3fb023919d5ecf08L), Double.longBitsToDouble(0x3fdc9a70aa1332bcL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.ode.events.EventState:@?\0121=java.lang.Boolean:false |this=org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 2, 9, 9, 8, "\ud849\udf52\ud89f\udf7d\ud9ae\ude7c\ud825\udfc6\udbac\udd94\udadb\udf3a\uda38\udee4\udbca\udc18\udbd2\udded\ue7db\ud9a6\udf07\ud854\udfc2", "\u8abc\u5728\u3466\uc125\u3d94", "\udb1c\udcf1\uda20\udfe3",
        36, 90454, -2076459670, 6422959650717061995L, 37273L, false, false, (char) 14069, (char) 11502,
        Double.longBitsToDouble(0x3fd6987914acb6aaL), Double.longBitsToDouble(0x3fe8baf42421be4aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 0, 8, "\ud923\udeb0", "\ud180\u173e\u2935\ud717\u29a6", "\ud9a6\udf52\ud854\udfc2\udbeb\udf5b\ud95a\udebd\uda84\udc84\udb43\udf23\uda7f\uddb5\uda8d\udeb2\ud882\udfb6\ud8c5\udc2d\ud827\udd31\ud96e\udca9\udaed\udda1\ud990\udcbb\udb08\udfc3\ud8a5\udfc5",
        5, 96694, 809943160, -5110995258764537710L, 29646L, true, true, (char) 23979, (char) 28059,
        Double.longBitsToDouble(0x3eb2a57cc6700000L), Double.longBitsToDouble(0x3fd17edf3b0d307eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 5, 7, "\uda9d\ude96", "\ud180\u173e\u2935\ud692\u8902", "\ud9a6\udf52\ud854\udfc2\udbeb\udf5b\udb16\udd7c\uda84\udc84\udb32\udc23\uda7f\uddb5\uda8d\udeb2\ud882\udfb6\ud8c5\udc2d\ud827\udd31\udaf5\udc63\u9381\ud951\udcc3\udaf1\udf0a\ud8a5\udfc5",
        5, 91510, 814300109, -5110995258764537710L, 29646L, true, true, (char) 23979, (char) 28059,
        Double.longBitsToDouble(0x3fa0891582b2ff60L), Double.longBitsToDouble(0x3fde8a4c37a4f4b4L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 1, 7, 10, 2, "\ud866\udec5\udafa\udd8b\ud9be\udde6\udb9a\ude8b\udb30\udd1d\udadb\udf3a\uda3d\udff4", "\u02b4\ua471\ubc4d\u064a\u7ad1\ua31c\u4bae\u1215\uc125\u777a\u8843\ua82f\ucc0c\u211d", "\uda88\udd8f\ud96f\udfdc\ud8dd\udc85\ud9a3\udccf\ud84d\ude56\ud9c5\ude88\udb77\uddc4\ud84c\udf55\ud8b8\udd12\udb55\udeca\ud855\udfe8",
        5, 95549, 1366859480, -5902064202271083848L, -45301L, true, true, (char) 19209, (char) 42954,
        Double.longBitsToDouble(0x3fdfaa41a5d0c0c4L), Double.longBitsToDouble(0x3fea73b0847a0f0fL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.math.ode.events.EventState:@?\0121=new org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 2, 10, 10, 2, "\ud84e\udcc5\udafa\udd8b\ud9be\udde6\udb9a\ude8b\udb30\udd1d\uda38\udde8\ud83d\udd51", "\u12fb\ub684\ubc4d\u3045\u13c6\ua31c\ua841\u4a8d\uc125\u777a\u8843\ua8d0\u237b\u1c1d", "\uda88\udde1\ud94d\udc4b\ud906\udc3c\ud90e\uded8\udbf9\udfd7\ud8b9\udef6\udb77\uddc4\ud84c\udf55\ud8b8\udd12\udb55\udeca\ud916\udde9\udb0c\udefc\udbb1\udca0\ud9ad\udcf9\ud902\udf0d\ud8f5\udd45\uda76\ude98\uda37\ude1f\ud97c\uddd1\udb6d\udee3\udb0a\udf6b\uda49\udcb8\ud817\udfaa\udb81\udc7b",
        35, 98727, 1583182176, -1934096030692768948L, -3262L, true, true, (char) 2040, (char) 24905,
        Double.longBitsToDouble(0x3fc6b40b668fad20L), Double.longBitsToDouble(0x3f96f69c322a9560L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a1=[D:[[27675.0, 28490.5, 28005.0, 28333.5, 27847.0, 28379.0]] |this=org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 1, 7, 7, 3, "\ud866\udec5\udafa\udd8b\ud9be\udde6", "\u2935\u89c1\u7def\u1885", "\udaaf\uddef\udbeb\udef1\ud841\udeb1\udbcb\uddcb\ud9fe\udf2c\u0aeb\uda8d\udeb2\udbb1\udd92",
        13, 38021, -369981904, -9194640317219351454L, -38948L, true, false, (char) 58871, (char) 3779,
        Double.longBitsToDouble(0x3fcc861f424ae448L), Double.longBitsToDouble(0x3fe65ecd126e3280L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Double:0.7707862932079211 |this=org.apache.commons.math.ode.events.EventState:@?\0121=new org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 2, 1, 10, 2, "\ud866\udec5\udafa\udd8b\ud9be\udde6\udb9a\ude8b\udb30\udd1d\udadb\udf3a\ud870\udf4e", "\u02b4\ua471\ubc4d\u9cf9\u0fdb\ud29f\u28fc\u1215\uc125\u777a\u8843\ua8d0\ucc0c\u7b51", "\uda88\udde1\ud96f\udfdc\ud92d\udfe8\udba1\ude5a\udba9\udcb5\ud83d\ude25\udb77\uddc4\ud84c\udf55\ud8b8\udd12\udb55\udeca\ud916\udde9",
        41, 95549, 1366859480, -5902064202271083848L, -45301L, true, true, (char) 19209, (char) 42954,
        Double.longBitsToDouble(0x3fcf548345d8629cL), Double.longBitsToDouble(0x3fe8aa4804310f0fL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a1=[D:[[27769.5, 28480.0, 27690.5, 28635.5, 27847.0, 28346.0, 10540.5, 27996.0]] |this=org.apache.commons.math.ode.events.EventState:@?\0121=new org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 2, 7, 10, 4, "\ud923\udeb0\ud885\udfe7\ud9be\udda4\u5289\udae8\ude99\udbc9\udd8b\udb7d\ude66\uda34\ude0f\ud852\ude4f", "\u37b8\ub76d\ud23d\u8513\u4c60\u8221\uc125\ubc41\u91df\uaead\u0912\u05a5\ua74d", "\ud9fb\udf20\udb88\ude62",
        -5, 85684, 815977874, 3638915451571010158L, -3009L, true, true, (char) 46486, (char) 13123,
        Double.longBitsToDouble(0x3f9ca877555a9760L), Double.longBitsToDouble(0x3fe61177edb0c84cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a1=[D:[[27769.5, 28480.0, 28075.0, 28394.0, 27847.0, 28346.0, 10540.5, 28032.0]] |this=org.apache.commons.math.ode.events.EventState:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 6, 7, "\ud923\udeb0\udb86\ude04\ud9be\udda4\u5289\udb30\udd1d\uda75\ude9b\udb30\ude8c\ud992\udf80\ud828\uded9", "\u821e\u1a70\u3d1e\u8abc\u5728\u8239\u3ab8\ubcfa\u668a\u94b6\u1e86\u2695\u561f", "\ud87d\udcc4\uda1a\udccb",
        42, 35495, 815977874, 3638915454115510894L, -91391L, true, true, (char) 46486, (char) 13123,
        Double.longBitsToDouble(0x3fe0e543ba23bd89L), Double.longBitsToDouble(0x3fe61177edb0c84cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a1=[D:[[15004.5]] |this=org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 1, 7, 9, 0, "\u7569", "\u4928\uc212\u613f\u47af\u0d8e\u2d71\u02b4\ua471\u00ca\u736d\u68b4\u8abc\u5728\000\000\u7552\ub13c\ud11c", "\uda05\udc35",
        47, 26431, -1224715776, -6651344283334819744L, 10446L, true, false, (char) 55144, (char) 63376,
        Double.longBitsToDouble(0x3fe2b5a9f7175e84L), Double.longBitsToDouble(0x3fa0df257ca9c410L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a1=[D:[[27948.5, 28193.5, 28131.5, 28432.5, 27816.0, 28605.5, 28085.0, 28394.5]] |this=org.apache.commons.math.ode.events.EventState:@?\0121=java.lang.Boolean:false |a1=[D:[[27948.5, 28193.5, 28131.5, 28432.5, 27816.0, 28605.5, 28085.0, 28394.5]] |this=org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 2, 7, 7, 5, "\uda89\udc73\udbf7\ude51\ud980\udfab\udb9a\ude05\ud80c\udd5b\uda0e\udeb1\ud8d3\udff2\uc6c9\ud9d5\udd3f\ud80c\udcba\ud9a6\udf52\ud9b0\udc0f", "\u3f6e\u44a7\u9ebf\u1fe9\u1086\u4993\u01c7\u5751\u367c", "\ud846\udd56\ud97b\udc69\ud889\ude1c\uda6c\udcab",
        11, 35770, -345803037, -8688409678744143255L, 42055L, false, false, (char) 62493, (char) 30041,
        Double.longBitsToDouble(0x3fbeb3701be75628L), Double.longBitsToDouble(0x3fb38322fe222350L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math.ode.events.EventState:@?\0121=null |this=org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 2, 2, 2, 7, "\uda89\udc73\udbf7\ude51\ud980\udfab\udb9a\ude05\udaf7\udd54\uda0e\udeb1\ud8d3\udff2\ud9cf\udf98\ud9d5\udd5f\ud80c\udcba\ud9a6\udf52\ud835\udc02", "\u3f6e\u44a7\u9ebf\u4872\021\u4993\u01c7\u5751\uac32", "\ud846\udd56\ud97b\udc69\udac3\udefa\uda5a\udf5c",
        11, 35770, -345803037, -8688409678744143255L, 42055L, true, false, (char) 62493, (char) 30041,
        Double.longBitsToDouble(0x3fbeb3701be75628L), Double.longBitsToDouble(0x3fb38322fe222350L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Double:0.16481280138678567 |this=org.apache.commons.math.ode.events.EventState:@?\012",
        Z.run(T, 1, 1, 10, 10, "\ud923\udeb0\udb01\udce5\u00c6\udb87\udd03\udb30\udd1d\udadb\udf3a\uda38\udee4", "\u02b4\ua471\u8880\u06b4\u343a\u77bb\u5728\u3466\uc125\ud418\000\uafb3\u485e", "\udb08\udfc3",
        -5, -1000, 0, 3458764512630544612L, -100000L, false, false, (char) 59642, (char) 23979,
        Double.longBitsToDouble(0x3fe802f42021be4aL), Double.longBitsToDouble(0x3fc51895fbf58dbcL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.ode.events.EventState|evaluateStep|org.apache.commons.math.ode.sampling.StepInterpolator|new:org.apache.commons.math.ode.events.EventState:org.apache.commons.math.ode.events.EventHandler,double,double,int",
    "M|org.apache.commons.math.ode.events.EventState|getConvergence||new:org.apache.commons.math.ode.events.EventState:org.apache.commons.math.ode.events.EventHandler,double,double,int",
    "M|org.apache.commons.math.ode.events.EventState|getEventHandler||new:org.apache.commons.math.ode.events.EventState:org.apache.commons.math.ode.events.EventHandler,double,double,int",
    "M|org.apache.commons.math.ode.events.EventState|getEventTime||new:org.apache.commons.math.ode.events.EventState:org.apache.commons.math.ode.events.EventHandler,double,double,int",
    "M|org.apache.commons.math.ode.events.EventState|getMaxCheckInterval||new:org.apache.commons.math.ode.events.EventState:org.apache.commons.math.ode.events.EventHandler,double,double,int",
    "M|org.apache.commons.math.ode.events.EventState|getMaxIterationCount||new:org.apache.commons.math.ode.events.EventState:org.apache.commons.math.ode.events.EventHandler,double,double,int",
    "M|org.apache.commons.math.ode.events.EventState|reinitializeBegin|double,[D|new:org.apache.commons.math.ode.events.EventState:org.apache.commons.math.ode.events.EventHandler,double,double,int",
    "M|org.apache.commons.math.ode.events.EventState|reset|double,[D|new:org.apache.commons.math.ode.events.EventState:org.apache.commons.math.ode.events.EventHandler,double,double,int",
    "M|org.apache.commons.math.ode.events.EventState|stepAccepted|double,[D|new:org.apache.commons.math.ode.events.EventState:org.apache.commons.math.ode.events.EventHandler,double,double,int",
    "M|org.apache.commons.math.ode.events.EventState|stop||new:org.apache.commons.math.ode.events.EventState:org.apache.commons.math.ode.events.EventHandler,double,double,int",
    "C|org.apache.commons.math.ode.events.EventState|<init>|org.apache.commons.math.ode.events.EventHandler,double,double,int",
    "M|org.apache.commons.math.ode.events.EventState|evaluateStep|org.apache.commons.math.ode.sampling.StepInterpolator|new:org.apache.commons.math.ode.events.EventState:org.apache.commons.math.ode.events.EventHandler,double,double,int",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
