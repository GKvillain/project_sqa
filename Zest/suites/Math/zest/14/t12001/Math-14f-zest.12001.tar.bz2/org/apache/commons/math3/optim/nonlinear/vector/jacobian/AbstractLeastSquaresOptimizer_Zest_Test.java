package org.apache.commons.math3.optim.nonlinear.vector.jacobian;
import org.junit.Test;
import static org.junit.Assert.*;
public class AbstractLeastSquaresOptimizer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 10, 14, "\udad5\udc40\uda9c\udd6f\udb91\ude1a\udac7\udd3a\ud9cf\udf80\udb9d\udf9f\ud92f\udfe0", "\u3bf3\u1800\ud1a4", "\uda12\udfab\ud870\udea3",
        17, 35063, -641085344, -2101676505722344582L, 70235L, true, true, (char) 25576, (char) 54671,
        Double.longBitsToDouble(0x3fd3e750bfe9f23cL), Double.longBitsToDouble(0x3fe8b9a1721469f1L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 10, 10, "\udad5\udc40\uda9c\udd6f\udb91\ude1a\udad2\ude3a\ud9cf\udf80\udb9d\udf9f\ud92f\udfe0", "\u3bf3\u1800\uc419", "\uda12\udfab\uda53\udfb4",
        9, 24631, 57008010, 5162596604798213422L, 70235L, true, true, (char) 21099, (char) 47412,
        Double.longBitsToDouble(0x3fe4105c8ff4f91eL), Double.longBitsToDouble(0x3fe8b9a171baf615L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 10, 12, "\udad5\udc73", "\ucdc3\u5f5b\u51f9\u54b3\ua717\u7c7f\u3bf3\u1800\uceb7\u49cf\uaf52\u5f9c\u385b\ub484\ubf39\u1316", "\ud8f4\ude5b\ud89a\uded0\ud9b2\udf6f\ud986\uddff\udb49\udfc7\ud8a6\udcd6\ud8e4\udf07\ud931\udd55\udbc1\udd34\ud862\uddf6\uda60\uddc2\ud8f1\udf5e",
        27, 80756, -753164740, 3703849764519096481L, 90037L, true, false, (char) 58696, (char) 18078,
        Double.longBitsToDouble(0x3fee675c8e488b8fL), Double.longBitsToDouble(0x3fe98f0460a1bce9L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 10, 12, "\ud885\udf5a\uda9c\udd6f\udb91\ude1a\uda90\udec3\ud9cf\udf70\udb7f\udc9f\ud93f\udee0\ud94d\udc88\ud839\udec9\ud938\uddb8\udb54\udcc2\uda83\udc59\udb8b\udd4f\uda5d\uded1\uda12\udfab\ud870\udea3\ud81f\udcd0\ud806\udee6", "\ud30b\ucd7d\uaf6c\ub0a7\u28bb\u2399", "\ud89f\uddec\ud825\uddf9\ud9aa\udc41\ud9e5\udd82",
        53, 23811, -1594414693, -3433148826618871284L, 8583L, false, true, (char) 22425, (char) 59022,
        Double.longBitsToDouble(0x3fe7b1e7dc73acfcL), Double.longBitsToDouble(0x3fdc0883af3b7b78L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 10, 14, "\udad5\udc40\uda9c\udd6f\udb91\ude1a\udac7\udd3a\ud9cf\udf80\udb9d\udf9f\ud92f\udfe0\ud94d\udc88\ud839\udec9\udbea\udeef", "\ud26b\ud030\uaf95\u9b06\ub484\uca33\u1354\u65c8\ud30b\u5403", "\ud986\uddff\udb39\udfc7\ud8a6\udcd6\ud8e4\udf07\ud931\udd55\uda5a\udd40\ud824\ude7d\ud9c9\udc1b\uda7c\udfac\ud93f\udcf9\uda6c\udd3f\udb2c\udd96\ud81f\ude72\udbbf\udf5b\ud99e\udddc\udb79\udde1\uda89\udf17\ud933\udebb\udb59\udcf2\udb37\udda1\ud8ba\udff9\udb69\ude18\udad1\udfe1\uda8f\udd31\ud8b7\udcae",
        52, 92023, -170546362, 7949223934727276239L, 48732L, false, true, (char) 19730, (char) 45278,
        Double.longBitsToDouble(0x3f975e26d7ea7ea0L), Double.longBitsToDouble(0x3fe99eda3cd095c1L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 10, 14, "\udad5\udc40\uda70\udfc7\ud841\udf07\uda6e\udf20\ud928\uddde\udb9d\udf9f\ud832\udef8", "\uc8c7\uaecf\u9fa4\ud26b\ub40b\u9044\u8648\uc7ba\ubf04\ua94c\u46ac\u0bdb\u676c\u5810\ua0e8\u35e0\u7708\u8916\u2f9d\u2b93\u1d9b\ub34e\u9b73\u5565\u45b4\u3724\uc1e0\u3e53\u8a70\uac49\ub473", "\udbd5\udc88\ud97e\udf8b\uda6a\udfd9\udb9a\udfec\ud832\uddd2\udb16\udf20\ud8c2\udf78\ud887\udd48\ud859\udeae",
        11, 32886, -1202094195, 8855750695135889672L, -16114L, false, true, (char) 44273, (char) 34866,
        Double.longBitsToDouble(0x3fed3d50aacdef85L), Double.longBitsToDouble(0x3fe37d62e4fabb4eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28184.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,28013.5,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28380.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,27851.5,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28153.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,27966.5,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 6, 3, "\udad5\udc61\udb0b\udde8\ud9c7\udc22\udaad\uddbf\ud9cf\udf80\udb9d\udf9f", "\u7c7f\u3bf3\u1800\ud1a4\ud26b\ud030\u5fb3\u385b\ub484\ubf39\u1316\u48cd\u186d\u7f1d\u5ba8\u1ae4\u0350\u22fc\u8916\u97cc\u8651\u87b8\u8edf\u50b1\uc18e\u422b\ud00c\ubfb3\u71ac\ubfcc\ubbe5\uc01f\u658c", "\uda53\udeb7\ud8c0\udd5d\ud9d6\udd53\ud84b\udfc4\ud97d\udfd4\ud87e\udced",
        32, 59950, -1285348847, -2946948177404778L, -13836L, true, false, (char) 41195, (char) 39764,
        Double.longBitsToDouble(0x3f8519d6081f0480L), Double.longBitsToDouble(0x3fda7898b21e7a38L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28201.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,27958.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28319.5,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,27831.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28376.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,27979.5,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 1, 7, "\udad5\udc83\uda9c\udd6f\ud99e\udde0\udac7\udd97\udae0\udee7\udbd9\udccd\udbf8\udd83\ud9f5\ude05\udad1\udc22\udac8\udddd\udab7\ude42\ud89a\udfbc\ud9a8\udc3e\ud85d\udd89\uda5d\udc58", "\u558d\u7c59\ub79e\u2c9f\u5403\u7d57\u088f\u4d1f\u239b\u8916\uc876\u791b\u7003\u4792\u6e7b", "\udb4a\udf38\udbff\udfbc\udb8a\ude87\udbfe\udd09\uda36\ude00\ud83d\ude7d\ud8c2\udfb6\ud87c\udc7e\uda8a\udf28\ud840\udf80\uda62\udc8e\ud97c\ude0d\uda4f\udd66\uda2f\udd40\udb2a\udf84\ub82e\u1dd2\udb7a\udda4\u5e24\ud8d0\udf67\uc225\udbae\ude2d\ud825\udc46\uda30\udc5f\udb9b\udd24\ud8eb\udc23\uda29\udd73\udb61\udc18\ud8b2\udc1a\udacd\ude52\udbef\udcc0\udaa6\ude1c\uda42\udc44\udb62\udf15",
        7, 6883, -1810129663, -425611877438231034L, 16288L, false, true, (char) 47890, (char) 26299,
        Double.longBitsToDouble(0x3fe328d4ce04feccL), Double.longBitsToDouble(0x3feac6c2fa7e5adeL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\012",
        Z.run(T, 1, 13, 7, 14, "\ud966\ude23\udb49\udc41\udb91\ude1a\udac7\udd3a\ud9cf\udf80\udb9d\udf9f\ud92f\udfe0", "\u3bf3\u1800\u4fa1", "\uda12\udfab\ud870\udea3\ud8e2\udd1e\ud806\udedc\ud9f3\ude1f\udbe5\udea1\udb5c\uddd1",
        17, 42201, -1670714884, 2643269755213689058L, -30356L, false, false, (char) 11648, (char) 62765,
        Double.longBitsToDouble(0x3fe1e15de356b691L), Double.longBitsToDouble(0x3fe491e23605d4a6L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 10, 14, "\udad5\udc40\uda9c\udd6f\udbc8\udf95\udb4d\udef9\ud9d1\udcda\udb9d\udf9f\udb24\ude1a", "\u3b83\u1800\ud1a4\ud26b\u807d", "\udbe9\udf8f\udad8\udca9\udbf2\ude6f\ud809\udcd2\udb31\udc63\udab8\udf9a\ud89a\uded5\ud9f0\uddda\uda4e\udf44\udb39\udfc7\ud9f8\udf92\ud9d4\udca3\udb24\udf7c\udb3f\udc50\uda5b\udc9f\ud8f7\udd11\ud8a1\udd55\ud844\udd08\udb75\udd05\ud920\udeb0\ubb88\ud9d2\udffa\ud8ed\udf03\ue9f2",
        43, 56147, -801942554, -6230804082922910507L, 89943L, false, true, (char) 50247, (char) 58724,
        Double.longBitsToDouble(0x3fd52748abbcececL), Double.longBitsToDouble(0x3fe63ec2ff7684eeL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\012",
        Z.run(T, 1, 8, 11, 14, "\udad5\udc40\uda9c\udd6f\udb91\ude1a\ud82e\udf5a\udac2\udc29\udad7\udf6d\ud937\udf89", "\u3bf3\u1800\u30a0", "\ud955\udf6e\ud870\udecf",
        15, 35063, -322318240, -1940391344067138714L, 70235L, true, false, (char) 20323, (char) 56220,
        Double.longBitsToDouble(0x3fd765fa1fe9f3f0L), Double.longBitsToDouble(0x3fc42fe5d977c76cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 15, 11, "\ud9a7\udfb8\uda9b\udfee\ud06b\udbfb\udfbe\ud9cf\udebe\udb9d\udf9f\ud92f\udfe0\ud94d\udc88\ud839\udec9\udbea\udeef\udab7\ude42", "\ud030\u5fb3\u385b\u9199\ub29a\u1316\u65c8\u705a\u5403\u7d57\u859b\uadf7\u89a6\u8916\u15cd\uc4a7\u9bce\ub170\u3b53\u7d2b\u7f0c\u9a14\u09e4\u9e8c\u510b\uc6c2\u4ae9\ua8f0\u8d12\u566b\uad16\u2ba3\u65ce\ub7e2", "\ud895\udd11\ud848\udd78\udb9a\udcb1\uda14\udcd7",
        27, 2052, -740809880, -3567162412085850388L, 29963L, true, false, (char) 26218, (char) 32298,
        Double.longBitsToDouble(0x3fb1b642dfee3410L), Double.longBitsToDouble(0x3fef44285d490e14L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 11, 0, "\udad5\udc40\ud8b9\udcbf\udb91\udd89\udac7\udd3a\ud9cf\udf80\ud993\udf9a\ud80e\udfb0", "\u4605", "\u088c\uda5d\ude91\u3428\udb4f\udc39\udb50\ude17\ud806\udedc\ud9f3\ude1f\udbe5\udea1",
        52, 96972, -1750164389, -7180644002737436714L, 16503L, true, false, (char) 38012, (char) 41923,
        Double.longBitsToDouble(0x3fe6540089a0f5b1L), Double.longBitsToDouble(0x3fef2c2cdf9c8541L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 10, 14, "\udad5\udc3a\uda9c\udd6f\ud971\udfa9\ud883\udf07\ud999\uddaf\ud9ff\udc79\ud95b\udc17\ud94d\udcf6\udb9e\udc04\udbab\ude20\udae1\udea7\ud966\uddd8\udb8b\udd4f\ud8be\ude21\ud84f\uddd0\ud870\udf26\ud8e2\udd1e\udb7c\uded7\ud9f3\ude1f\udabb\udfcc\ud8eb\uddbe\ud8f4\ude5b\udbcf\udd2f\ud9b2\udfef\uda59\uddc6\ud8b7\uddfe\ud828\udde1\uda60\udf84\ud87a\uddb5\ud85e\udcd7\udaad\udc83\ud9a1\udf82\ud875\udf95\udbe8\ude12\udbc6\udcab\ud8e0\udf05\udae3\udf7d\ud839\udfd5\ud86e\udde7\ud933\udd55\udbb1\udccb\ud9e4\udcaf\ud968\udf59\udacb\udcd6\u0b70\udaeb\udf31", "\ua964\u2848\u4666\uca10\u4601\ua0b8\u2990\u542a\u2c17", "\u2a71\ud94a\udc11\udb6e\ude2a\ud9ab\ude5a\ud90c\udf71\ud967\ude12\udb25\udff8\ud912\udf4a\udae5\udd50\ud9fb\udc6e\ud839\udf6b\ud9b5\udd7e",
        21, 91458, -442896518, 4557961273605175609L, 14282L, false, false, (char) 58577, (char) 14056,
        Double.longBitsToDouble(0x3fd508656cec599eL), Double.longBitsToDouble(0x3fe61111712ed118L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 15, 9, "\ud8cc\ude44\udb71\udebc\udb91\ude1a\udac7\udd3a\ud9cf\udf80\udb9d\udf9f\ud92f\udfe0", "\u3bf3\u1800\u6727", "\uda12\udfab\ud870\ude92\ud8e2\udd1e\ud806\udedc\ud9f3\ude1f\udbe5\udea1\udb5c\uddd1\ud8f4\ude5b\ud89a\uded5\uda9c\udd7c\ud959\udead\udbce\udd3b\ud81f\ude78\udb79\udd75\ud931\udd55\uda6c\udcea\udb2e\ude0c\ud898\udfed\ud9d8\udc5b\udb73\udc30",
        19, -476, -872857889, -1319220090134894917L, -37947L, true, false, (char) 35629, (char) 26441,
        Double.longBitsToDouble(0x3febaabc94c51cabL), Double.longBitsToDouble(0x3feb0a484d760cf5L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[null]] |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\012",
        Z.run(T, 1, 12, 5, 7, "\udad5\udc69\uda9c\udd6f\udb74\ude2b\ud803\udc97\udb66\udfcb", "\u8117\ucfc2\u00e9\u1800", "\udab4\udc71\udbd7\ude60\ud870\udf4a\ud8e2\udd1e\udb98\udf4a\ud902\udebb\udbe5\udea1\udb5c\uddd1\udb83\udca3\ud891\udc7d\ud9de\udc38\ud898\uded4\ud8bd\ude0e\uda30\udc0b\ud8df\udc24\ud83c\udf9d\udb7d\udc10\ud959\udebc\ud9a7\udc03\udb49\ude19\udb67\udc45\uda3b\ude2a\ud8dc\udf50\ud86b\udd79\ud885\udf06\udb17\udcee\uda6d\udd64\ud982\udc79\udb83\udd20\uda46\udd0a\udbb3\udd7b\ud818\udc5c\ud913\udf49\ud8f1\udc8a",
        25, 15542, 1402383151, -5038776545728548483L, 49178L, false, false, (char) 57472, (char) 34323,
        Double.longBitsToDouble(0x3fbb19108f729c10L), Double.longBitsToDouble(0x3fdca1e90c1cd062L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optim.nonlinear.vector.Weight:@? |a0=[D:[[27986.5, 28168.0, 27958.0, 28319.5, 28080.5, 28405.0, 27979.5, 28293.0]]\012",
        Z.run(T, 1, 16, 10, 14, "\udad5\udc40\uda9c\udd6f\udb91\ude1a\udac7\udd3a\ud9cf\udf80\udb65\udd52\ud92f\udfe0", "\u3bf3\u1800\ud1a4", "\uda12\udfab\ud870\udea3",
        17, 35063, -641085344, 60051315415493498L, 70235L, true, true, (char) 25576, (char) 54671,
        Double.longBitsToDouble(0x3fd3e750bfe9f23cL), Double.longBitsToDouble(0x3fe8b9a1721469f1L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 10, 14, "\udad5\udc40\uda9c\udd6f\udb91\ude1a\udac7\udd3a\ud9cf\udf80\udb9d\udf9f\ud92f\udfe0", "\u3bf3\u1800\ud1a4", "\uda12\udfab\ud870\udea3",
        17, 35063, -641085344, -2101676505722344582L, 70235L, true, true, (char) 25576, (char) 54671,
        Double.longBitsToDouble(0x3fd3e750bfe9f23cL), Double.longBitsToDouble(0x3fe8b9a1721469f1L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 10, 14, "\ud8f2\udca0\uda9c\uddba\udae2\udec2\udb59\udcbc\uc311\udb9d\udf9f\ud92f\udfe0", "\u88c8\u1800\u8723", "\udaa5\ude9c\uda79\udea8",
        44, 87564, 382312287, -2151716860450395270L, 41326L, false, true, (char) 27808, (char) 30440,
        Double.longBitsToDouble(0x3fd3e750bfe9fa3cL), Double.longBitsToDouble(0x3fe8b9a1717976f1L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 10, 14, "\udad5\udc40\uda9c\udd6f\ud8f5\udf0c\udac7\udd3a\ud9cf\udf80\udb9d\udf9f\ud92f\udfe0", "\u4b0e\u1878\ud1a4", "\uda12\udfab\ud913\udcf3",
        8, 85723, -641085276, -2101676507862848052L, 70235L, true, true, (char) 44396, (char) 11348,
        Double.longBitsToDouble(0x3fb784cd7fa7c818L), Double.longBitsToDouble(0x3fe9dba9701469f1L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28168.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,27958.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28319.5,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,28080.5,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28405.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,27979.5,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 12, 14, "\udad5\udc40\uda9c\udd6f\udb91\ude1a\udac7\udd3a\ud9cf\udf80\udb9d\udf9f\ud92f\udfe0", "\u3bf3\u1800\ud1a4", "\uda12\udfab\ud870\udea3",
        17, 35063, -641085344, -2101676505722344582L, 70235L, true, true, (char) 25576, (char) 54671,
        Double.longBitsToDouble(0x3fd3e750bfe9f23cL), Double.longBitsToDouble(0x3fe8b9a1721469f1L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[null, null, null]] |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 15, 14, "\udad5\udc40\uda9c\udd6f\udb91\ude1a\udac7\udd3a\ud9cf\udf80\ud993\udda2\udaf6\udf7f\uda14\udef8\ud839\ude68\udbea\udeef\udab7\ude42\ud89b\udc44\ud934\udf98\ud8d7\udc9d\udadc\uddd3\ud88b\udd89\udba3\udfa3\ud806\udedc\udb34\udce0\ud9bb\udf19\udbea\udf78\ud8f3\ude5b\ud808\udf2a\udb99\ude08\ud844\udf6b\udb39\udfc7\ud8a6\udcd6\uda74\ude95\udb10\ude2b\u7bef\ud88d\udd09\ud9fd\udee1\uda81\uddd7\udbce\udf53\ud87a\udd2d\ud838\udd3f\uda8a\ude26\ud802\udc4b\ud8ba\udc22\ud917\udeaf\ud9aa\udd35\udbe9\udf62\udac0\udcfc\ud828\uddfa\udb1e\udff5\ud8bf\udebb", "\u4630", "\udb42\uddcf\ud92e\uddaf",
        19, 16778, -1954318978, -6058840657629017179L, -40613L, false, true, (char) 22987, (char) 63230,
        Double.longBitsToDouble(0x3fde093d9b7a466eL), Double.longBitsToDouble(0x3f5f322b12a9f800L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 13, 6, "\uda8f\udcd8\uf9c0\ud941\udda9\ud9c9\udfe8", "\u54b3\ua717", "\udab7\ude42\ud93e\udc76",
        22, 324, 1789306682, -4240563070718319542L, 18880L, true, true, (char) 36431, (char) 63605,
        Double.longBitsToDouble(0x3fcf6bb9e54e5eb8L), Double.longBitsToDouble(0x3feeb4e090e224aeL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 8, 15, "\ud902\ude64\udb94\udcae\udbd1\udc11\ue505\ud9cf\udf80\udb9d\udf9f", "\u2776", "\ud9a8\udc33\ud816\udda4\uda5d\uded1\uda12\udfab\ud870\udea3\ud8e2\udd1e\ud806\udedc\ud9f3\ude1f\udbe5\udea1\udb5c\uddd1\ud8f4\ude5b\ud89a\uded5\ud9b2\udf6f\ud986\uddff\udb39\udfc7\ud8a6\udcd6\ud8e4\udf07\ud931\udd55\udbe3\udc06",
        37, 81625, 1188349232, -1307006973386842376L, -85303L, false, true, (char) 25504, (char) 39666,
        Double.longBitsToDouble(0x3fd8286bafaf8968L), Double.longBitsToDouble(0x3fd30938b6f6f720L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\012",
        Z.run(T, 1, 13, 10, 14, "\udb13\udf32\uda9c\udd6f\udb91\ude1a\000\000\udb9d\udf52\ud92f\udfe0", "\u249c[\u7509", "\uda12\udfab\ud870\udea3",
        13, -1000, 0, 0L, 70235L, true, true, (char) 25576, (char) 54671,
        Double.longBitsToDouble(0x3fd3e750bfe9f200L), Double.longBitsToDouble(0x3fe8b9a1720069f1L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 10, 12, "\000", "\u0437\u6844\u397a\u93b3\ua717\u7c7f\u4e94\u1805\u1270\ud26b\ud030\u5fb3\u385b\u6427\ubf43\u1316", "\ud8fa\udedf\udae6\udc64\ud898\udecb\udb89\uddcf\udb39\udfc5\ud8a6\udcd6\ud962\udf06\ud89f\uddec\udbc2\udef8\ud9aa\udc41\ud9e5\udd82\udab5\udd6d",
        6, 71307, -799342251, -1128923513904361168L, -44298L, true, false, (char) 59022, (char) 33777,
        Double.longBitsToDouble(0x3fbceb3f060441d0L), Double.longBitsToDouble(0x3e2ddd9f10000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 10, 12, "\ud807\ude16", "\u0437\u6844\u397a\u93b3\ua717\u7c7f\u4e94\u1805\u1270\u2f00\ub4be\u5fb3\u385b\u6427\ubf43\u1316", "\udaeb\ude25\ud8bc\ude1b\udb99\udf21\udb89\ude09\udb39\udfc5\ud8a6\udcd6\ud962\udf06\ud89f\uddec\ud825\uddf9\ud9aa\udc41\ud9e5\udd82\udab5\udd6d",
        6, 71307, -799342251, -1128923513904361168L, -57826L, true, false, (char) 59022, (char) 33777,
        Double.longBitsToDouble(0x3fbceb3f0e0441d0L), Double.longBitsToDouble(0x3fecedede2c912f5L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28168.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,27936.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28619.5,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,27656.5,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28523.5,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,27935.0,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 15, 14, "\udad5\udc40\uda70\udfc7\ud841\udf07\uda6e\udf20\ud93e\udd60\udb9d\udf9f\ud832\udef8", "\u53cb\uaecf\u9fa4\ud26b\ub40b\u9044\u8648\uc7ba\ubf04\ua94c\u4668\u0bdb", "\ud99e\udd74\udaf5\udc3c\uda3d\udd74\ud8a6\udcd6\ud94b\ude07\ud9c1\udcc6\ud934\udee6\ud80a\ude94\udb40\udc07\ud928\udeee",
        34, 54971, -540252418, -5250786927240623263L, 41485L, true, true, (char) 44661, (char) 25063,
        Double.longBitsToDouble(0x3fe6947c18010c4aL), Double.longBitsToDouble(0x3fb8b50ca3abbd98L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optim.nonlinear.vector.Weight:@? |a0=[D:[[27986.5, 28168.0, 27936.0, 28619.5, 27656.5, 28523.5, 27935.0, 28536.0]]\0121=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[null, null, null]] |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 1, 12, 15, "\udad5\udc40\uda70\udfc7\ud841\udf07\uda6e\udf20\ud928\uddde\udb07\ude0d\ud988\udf73", "\uc8c7\uaecf\u9fa4\ud26b\ub40b\u9044\u8648\uc7ba\ubf04\ua94c\u46ac\u0bdb\u676c\u5810\ua0e8\u35e0\u7708\u8916\u2f9d\u2b93\u1d9b\ub34e\u9b73\ua905\u47f4\u3724\uc1e0\u93a7\u8f07\uac49\ub473", "\udbd5\udc88\ud97e\udf8b\uda6a\udfd9\ud959\udecc\ud9d7\udca1\udb91\udf53\ud9df\udf88\ud887\udd48\ud859\udeae",
        11, 32886, -1202094195, 4388179864784378720L, 1816L, true, false, (char) 36797, (char) 27834,
        Double.longBitsToDouble(0x3fe997cdf9f11e41L), Double.longBitsToDouble(0x3fed3d50aacdef85L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0},{0.0,28184.5,0.0,0.0,0.0,0.0},{0.0,0.0,28013.5,0.0,0.0,0.0},{0.0,0.0,0.0,28380.0,0.0,0.0},{0.0,0.0,0.0,0.0,27851.5,0.0},{0.0,0.0,0.0,0.0,0.0,28153.0}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 6, 3, "\udad5\udc61\udb0b\udde8\ud9c7\udc22", "\ub47a\ubb31\ua717", "\ud85d\ude99\ud89a\udfc2\udb8b\udd4f",
        0, 41754, -148472293, -3877066795738815505L, 6876L, true, true, (char) 34760, (char) 5140,
        Double.longBitsToDouble(0x3fe9b5b44e75d936L), Double.longBitsToDouble(0x3fe913b0a93e88e9L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27791.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28567.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,28034.5,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28187.5,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,27702.5,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28238.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,27966.5,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 6, 3, "\ud94f\udf5f\udb35\udc67\ud89d\udccc\udaad\udd4b\ud9cf\udf80\udb9d\udf9f", "\u7c7f\u3bf3\u1800\ud1a4\ud26b\ud030\u5fb3\u385b\ub484\ubf39\u1316\u48cd\u186d\u7f1d\u5ba8\u1ae4\u0350\u22fc\u8916\u97cc\u8651\u36d3\u8e52\u50b1\uc18e\u82c0\u2e41\ubfb3\u71ac\ubfcc\ubbe5\uc01f\u658c", "\uda53\udeb7\ud8c0\udd5d\ud9d6\udd53\ud84b\udfc4\ud999\udee2\ud87e\udca7",
        32, 59950, -1285348847, -2946948177404778L, -13836L, true, false, (char) 41195, (char) 39764,
        Double.longBitsToDouble(0x3f8519d6081f0480L), Double.longBitsToDouble(0x3fc67131643cf470L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27908.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28171.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,28013.5,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28400.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,27851.5,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28153.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,27966.5,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 6, 3, "\uda39\udc46\udb0b\ude10\ud9c7\udc22\udaad\uddbf\ud9cf\udf80\udb9d\udf9f", "\u7c7f\u3bf3\u1800\ud1a4\ud26b\ud030\u5fb3\u385b\ub484\ubf39\u1316\u48cd\u186d\u7f1d\u5ba8\u1ae4\u0350\u22fc\u8916\u97cc\u8651\u87b8\u8edf\u50b1\uc18e\u422b\ud00c\ubfb3\u71ac\ubfcc\ubbe5\uc01f\u658c", "\uda53\udeb7\ud8c0\udd5d\ud9d6\udd53\ud84b\udfc4\ud97d\udfd4\ud87e\udced",
        32, 59950, -1285348847, -58678993566114666L, -13836L, true, false, (char) 41195, (char) 39764,
        Double.longBitsToDouble(0x3f8519d6081f0480L), Double.longBitsToDouble(0x3fd2d94a89cf650eL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28184.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,-24.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,-24.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,-24.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28056.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,28624.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 6, 3, "\udad5\udc61\000\000\000\udb60\udfd0\udb9d\udf9f", "\u7c7f\u3bf3\u1800", "Z\uda12\udf71\ud870\udea3\ud8e2\udd1e\ud806\udedc\ud9f3\ude1f\ud91e\udefb\ud8b6\udd8b\uda75\ude8b\ud854\udd59\000\ud840\ude1f\udb39\udf28\000\000\udb6e\udcaf\ud92c\udd2a\udbba\ude4c\uda73\udf34\udae6\udc60\uda39\udc16\ud9ff\ude71\udbb4\udc1a\uda5d\ude93\udb70\uddc8\ud8bf\ude24\udbd8\udda4\udb7e\udf01\udb4c\udc56\udb98\udde1\uda53\udeb7\ud8c0\udd5d\ud9d6\udd53\ud84b\udfc4",
        14, 83458, 131240692, 9021827697317454353L, -25398L, false, false, (char) 43699, (char) 50043,
        Double.longBitsToDouble(0x3f44035ce9300000L), Double.longBitsToDouble(0x3f8519d6081f0480L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0},{0.0,28184.5}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 6, 0, "\udad5\udc61", "\u02c1\u6854\ub47a\ubb31\ua717\u7c7f\u3bf3\u1800\ud1a4\ud26b\ud030\u5fb3\u385b\ub484\ubf39\u1316\u48cd\u186d\u7f1d\u5ba8\u1ae4\u0350\u22fc\u8916", "\ud92c\udd2a",
        0, 16562, 1447617355, 3971859135433887324L, -54052L, true, false, (char) 22803, (char) 34744,
        Double.longBitsToDouble(0x3fea5866d8edfb27L), Double.longBitsToDouble(0x3ec97b0868f80000L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27636.0,0.0},{0.0,28402.0}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 6, 3, "\ud818\ude14", "\u02c1\u6854", "\ud94d\udc88\ud839\udec9\udbea\udeef\udab7\ude42\ud89b\udc44\udb8b\udd4f\uda5d\uded1\uda12\udfab\ud870\udea3\ud8e2\udd1e",
        23, 61656, -389976998, -2630652273197214076L, -28659L, false, true, (char) 54512, (char) 17993,
        Double.longBitsToDouble(0x3fdf4f91ee2e685cL), Double.longBitsToDouble(0x3fe0a49acae6f082L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28184.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,28013.5,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28380.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,27972.5,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28149.5,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,27966.5,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 3, "\udad5\udc61\udb0b\udde8\udab9\udc1b\udaad\uddbf\ud9cf\udf80\udb9d\udf9f", "\u0b12\u3bf3\u1800", "\uda5d\uded1\uda12\udfab\ud870\udea3\ud8e2\udd1e\ud806\udedc\ud9f3\ude1f\ud9d3\udf64\ud8b6\udd8b\uda75\ude8b\udbe8\ude5b\uda86\udd55\udb32\udfdc\udb23\udcb9\ud8a6\udcd6\ud8cf\udd07\udb6e\udcaf\ud92c\udd2a\udbba\ude4c\uda73\udf34\udae6\udc60\uda39\udc16\ud9ff\ude71\uda5c\uddee\ud936\udda0\udb5b\ude81\ud8bf\ude24\udbcb\ude52\udb9d\udeb7\udb4c\udc56\udba3\udfe1\uda53\udeb7\ud8c0\udd5d\ud9d6\udd53\ud84b\udfc4",
        31, 83458, 131240692, 9021827697317454353L, -25398L, false, false, (char) 43699, (char) 50043,
        Double.longBitsToDouble(0x3fca34035ce93068L), Double.longBitsToDouble(0x3f8519d6081f0480L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28184.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,28013.5,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28380.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,27851.5,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28153.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,27966.5,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\0121=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[]] |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 14, 12, 3, "\udad5\udc61\udb0b\udde8\ud9c7\udc22\udaad\uddbf\ud9cf\udf80\udb9d\udf9f", "\u7c7f\u3bf3\u1800\ud1a4\ud26b\ud030\u5fb3\u385b\ub484\ubf39\u306b\u48cd\u186d\u7f1d\u5ba8\u1ae4", "\udb5f\udc79\ud8d3\udc92",
        20, 20244, -170216730, -3999484015717850293L, -14404L, false, true, (char) 49492, (char) 41623,
        Double.longBitsToDouble(0x3fe749f150e336d5L), Double.longBitsToDouble(0x3fea5866d8edfb27L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{-24.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28011.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,28553.5,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,27851.5,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,28153.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,27966.5,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,28359.5,0.0},{0.0,0.0,0.0,0.0,0.0,... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 6, 12, "\000\udb06\udf43\ud9c7\udc22\udaad\uddbf\ud9cf\udf80\udb9d\udf9f", "\u7c7f\u3bf3\u1800\ud1a4\ud26b\ud030\u5fb3\u385b\ub484\ubf39\u1316\u48cd\u186d\u7f1d\u5ba8\u1ae4\u0350\u22fc\u8916\u97cc\u8651\024\u8edf\u50b1\uc18e\u422b\ud00c\ubfb3\u71ac\ubfcc\ubbe5\uc01f\u658c", "\uda53\udeb7\ud8c0\udd5d\ud9d6\udd53\ud84b\udfc4\ud97d\udfd4\ud87e\udced",
        32, 59950, -1285348847, -2946948177404778L, -13836L, true, false, (char) 41195, (char) 19540,
        Double.longBitsToDouble(0x3ecd6081f0000000L), Double.longBitsToDouble(0x3fda7898b21e7a38L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 6, 3, "\udad5\udc61\udb0b\udde8\ud9c7\udc22\udaad\uddbf\ud9cf\udf80\udb9d\udf9f", "\u7c7f\u3bf3\u1800\ud1a4\ud26bs\ud28a\u3929\ub484\ubf39\u1316\u48cd\u186d\u7f1d\u5ba8\u1ae4\u0350\u22fc\u8916\u97cc\u8651\u87b8\u8edf\u50b1\uc18e\u422b\ud00c\ubfb3\u71ac\ubfcc\ubbe5\uc01f\u658c", "\uda53\udeb7\ud8c0\udd5d\ud9d6\udd53\ud84b\udfc4\ud97d\udfd4\ud87e\udced",
        32, 59950, -1285348847, -2946948177404778L, -13836L, true, true, (char) 28614, (char) 4999,
        Double.longBitsToDouble(0x3f8519d6081f0480L), Double.longBitsToDouble(0x3fda7898b21e7a38L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{23901.5}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 6, 8, "\ubaeb", "\u5605\u6854\ub47a", "\ud839\udec9\udbea\udeef\udab7\ude42\ud89b\udc44\udb8b\udd4f\uda5d\uded1\uda12\udfab\ud870\udea3\ud8e2\udd1e\ud806\udedc\ud9f3\ude1f\ud9d6\udea5\ud8b6\uddb8\udb30\udda4\ud854\uddcb\ud9b2\udf6f\ud986\uddff\uda16\udce4\ufed3\ud8ca\udd27\udb6e\udcaf\ud92c\udd2a\udbba\ude4c\uda73\udf34\udae6\udc60\udaf1\udee0\ud9ff\ude71\udbb4\udc1a\uda5d\ude93\udb70\uddc8\ud8bf\ude24\ud966\udf4b\ud9c5\udc67",
        28, 91694, -11559311, -6336997282973486938L, 97284L, false, true, (char) 40843, (char) 41,
        Double.longBitsToDouble(0x3fe08be99fc4b363L), Double.longBitsToDouble(0x3fc2dffeb938a2d8L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28201.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,27958.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28319.5,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,27831.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28376.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,27979.5,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\0121=new org.apache.commons.math3.optim.nonlinear.vector.Weight:@? |a0=[D:[[27986.5, 28201.5, 27958.0, 28319.5, 27831.0, 28376.0, 27979.5, 28339.5]]\012",
        Z.run(T, 2, 14, 1, 7, "\udad5\udc83\uda9c\udd6f\ud99e\udde0\udac7\udd97\udae0\udee7\udbd9\udccd\udbf8\udd83\ud9f5\ude05\udad1\udc22\udac8\udddd\udab7\ude42\ud89a\udfbc\ud9a8\udc3e\ud85d\udd89\uda5d\udc58", "\u558d\u7c59\ub79e\u2c9f\u5403\u7d57\u088f\u4d1f\u239b\u8916\uc876\u791b\u7003\u4792\u6e7b", "\udb4a\udf38\udbff\udfbc\udb8a\ude87\udbfe\udd09\uda36\ude00\ud83d\ude7d\ud8c2\udfb6\ud87c\udc7e\uda8a\udf28\ud840\udf80\uda62\udc8e\ud97c\ude0d\uda4f\udd66\uda2f\udd40\udb2a\udf84\ub82e\u1dd2\udb7a\udda4\u5e24\ud8d0\udf67\uc225\udbae\ude2d\ud825\udc46\uda30\udc5f\udb9b\udd24\ud8eb\udc23\udaeb\udd74\udb61\udc18\ud8b2\udc1a\udacd\ude52\udbef\udcc0\udaa6\ude1c\uda42\udc44\udb62\udf15",
        7, 6883, -1810129663, -425611877438231034L, 16288L, false, true, (char) 47890, (char) 26299,
        Double.longBitsToDouble(0x3fe328d4ce04feccL), Double.longBitsToDouble(0x3feac6c2fa7e5adeL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28201.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,27951.5,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28220.5,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,27858.5,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28506.5,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,27979.5,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 1, 10, "\udad5\udc83\uda8f\udca9\ud9d5\udee5\udac7\udd97\udae0\udee7\udbd9\udccd\udbf8\udd83\ud9f5\ude05\udad1\udc22\udac8\udddd\udab7\ude42\ud87d\udfbc\ud9a8\udc3e\ud85d\udd89\uda5d\udc58", "\u558d\u7c59\ub79e\u2c9f\u5403\u7d57\u088f\u4d1f\u64a3\u8916\uc876\u791b\u7003\u4792\u6e7b", "\udb4a\udf38\udbff\udfbc\udb8a\ude87\udbfe\udd09\uda36\ude00\ud83d\ude7d\ud8c2\udfb6\ud87c\udc7e\uda8a\udf28\ud840\udf80\uda62\udc8e\ud97c\ude0d\uda4f\udd66\uda0e\ude40\udb2a\udf84\ub82e\u1dd2\udb7a\udda4\u5e24\ud8d0\udf67\uc225\udbae\ude2d\ud825\udc46\uda30\udc5f\udb9b\udd24\udbaa\udf62\udac6\udf60\udb05\udf1e\ud8b2\udc1a\udacd\ude52\udbef\udcc0\udaa6\ude1c\uda42\udc44\udb62\udf15",
        7, 6883, -1810129663, -425611877438231034L, 16288L, false, true, (char) 47890, (char) 26299,
        Double.longBitsToDouble(0x3fe328d4ce7376ccL), Double.longBitsToDouble(0x3fd58d8274fcb47aL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 3, 13, "\uda97\udc47\udb48\udfae\ud880\udf92\uda31\udcb8\ud920\udfac\udb9d\udf9f\ud92f\udfe0\ud989\udc73\ud922\udf86\udbea\udf45\udab7\ude42\ud97d\ude9b\ud886\udd21\udb53\ude10\udb1d\uddc1", "\u57cf\u2347\u65c8\u9ad5\ub668\u6901", "\udb39\udfc7\ud8a6\udd1b\ud9cc\udcea\udbf6\udc47",
        13, 94683, 1988884209, 8738211789774914516L, 14736L, true, false, (char) 12842, (char) 17028,
        Double.longBitsToDouble(0x3fd434736b16ed36L), Double.longBitsToDouble(0x3fe99c3f6478b955L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\0121=java.lang.Double:0.0 |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 8, 8, 9, "\udac3\ude38\udbbb\uddf8\udbc0\udc7e\udac7\udd3a\ud9cf\udf80\ud993\udf9a\ud968\udec0", "\u4462\u2172\u104a\uc375\ucff0\uc25e\u2d96\u05fc\ubf39", "\udb5c\uddd1\udbb1\udc49\ud89b\ude35\uda4f\udc73\ud8ff\udfbc\uda97\udd96",
        37, 33276, -633540567, -7174486651972859891L, 41622L, false, true, (char) 9430, (char) 44343,
        Double.longBitsToDouble(0x3fe0504514ba2b61L), Double.longBitsToDouble(0x3fe46d67837cb981L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 7, "\udad5\udc69\ud9c1\udf6e\udb74\ude2b\ud803\udc97\udb66\udfcb", "\u8117\ucfc2\u00e9\u1800", "\udb21\udfa9\udbd7\ude60\ud870\udf4a\ud8e2\udd1e\udb98\udf4a\ud902\udebb\udbe5\udea1\udb5c\uddd1\udb83\udca3\ud891\udc7d\ud9de\udc38\ud898\uded4\ud8bd\ude0e\uda30\udc0b\ud8df\udc24\ud83c\udf9d\udb7d\udc10\ud959\udebc\ud9a7\udc03\udb49\ude19\udb67\udc45\uda3b\ude2a\ud8dc\udf50\ud86b\udd79\ud885\udf06\udb17\udcee\uda6d\udd64\ud982\udc79\udb25\udd11\uda9e\udeab\udb54\uddfd\ud818\udc5c\ud913\udf49\ud8f1\udc8a",
        25, 25998, -2100695326, -5038776305210379907L, 49178L, false, false, (char) 57472, (char) 34323,
        Double.longBitsToDouble(0x3fbb19108f729c10L), Double.longBitsToDouble(0x3fdca1e90c1cd062L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[null]] |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 11, 10, "\ud99c\udf04\uda9c\udd6f\udb91\ude1a\udadd\udf3a\ud9cf\udf80\udb0f\udea6\udbb5\udc9f", "\u02a5\u1800\ud1a4", "\uda12\udfab\ud870\udea3",
        17, 35063, -641085344, -2101676505722344582L, 70235L, true, true, (char) 25576, (char) 54671,
        Double.longBitsToDouble(0x3faf3a85f7977250L), Double.longBitsToDouble(0x3fe823417177c2f8L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27745.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28216.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,27958.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28357.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,27993.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28489.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,28052.5,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 10, 14, "\ud8f2\udca0\uda9c\uddba\udae2\udec2\udb59\udcbc\uc311\udb9d\udf9f\ud92f\udfe0", "\u88c8\u1800\u8723", "\udaa5\ude9c\uda79\udea8",
        44, 87564, -1060528289, 3071022910080927472L, 41326L, false, true, (char) 27808, (char) 30440,
        Double.longBitsToDouble(0x3fd3e750bfe9fa3cL), Double.longBitsToDouble(0x3fe8b9a1717976f1L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[]] |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\0121=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[]] |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 12, 12, 16, "\udbec\ude14", "\u6a3c\u4800\u6aad\u21a8\u7df7\u8d1e\u3bf3\u1800\ud1a4\u4530\u4649\u191b\u24bb\u92f0\u5953\ub14e\u2d7e", "\ud808\udf2a\udb99\ude08\ud844\udf6b\u1a8f\ud88f\uddf3\uda74\ude95\udb10\ude2b\u7bef\ud88d\udd09\uda31\ude3b\ud8d0\udfbd\uda52\udd60\ud87a\udd2d\udbce\ude89\uda8a\udd87\ud802\udc4b\ud8ba\udc22\ud917\udeaf\ud9aa\udd35\udbe9\udf62",
        32, 54203, -985661945, 8578532714750596617L, 58538L, false, false, (char) 33897, (char) 19729,
        Double.longBitsToDouble(0x3fe2579124917325L), Double.longBitsToDouble(0x3fb8a404ebf637b8L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[null, null, null]] |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 11, 14, "\udad5\udc40\uda9c\udd6f\udb91\ude1a\udac7\udd3a\ud9cf\udf80\ud993\udda2\udaf6\udf7f\udac0\udc2f\ud839\ude68\udbea\udeef\udab7\ude42\ud89b\udc44\ud934\udf98\ud8d7\udc9d\udadc\uddd3\ud88b\udd89\udba3\udfa3\ud806\udedc\udbe2\udd7a\ud9bb\udf19\udbea\udf78\ud8f3\ude5b\ud808\udf2a\udb85\udf75\ud844\udf6b\uda44\ude9c\ud8a6\udcaf\uda4c\udc97\udb10\udd86\u7bef\ud88d\udd09\ud9fd\udee1\uda81\uddd7\udbce\udf53\ud87a\udd2d\ud838\udd3f\uda8a\ude26\ud802\udc4b\ud8ba\udc22\ud917\udeaf\ud9aa\udd35\udbe9\udf62\udac0\udcfc\ud828\uddfa\udb1e\udff5\ud8bf\udebb", "\u4630", "\udb42\uddcf\ud92e\uddaf",
        19, 16778, -1954318978, -6058840657629017179L, -40613L, false, true, (char) 22987, (char) 63230,
        Double.longBitsToDouble(0x3fde093d9b7a466eL), Double.longBitsToDouble(0x3f5f322b12a9f800L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |a0=[Lorg.apache.commons.math3.optim.OptimizationData;:[[null, null, null]] |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 9, 14, "\udad5\udc40\uda9c\udd6f\udb91\ude1a\udac7\udd3a\ud9cf\udf80\ud993\udda2\udaf6\udf7f\uda14\udef8\ud839\ude68\udbea\udeef\udab7\ude42\ud89b\udc44\ud934\udf98\ud8d7\udc9d\udadc\udead\ud88b\udd89\udba3\udfa3\ud806\udedc\udb34\udce0\ud9bb\udf19\udbea\udf78\ud8f3\ude5b\ud808\udf2a\udb99\ude08\ud844\udf6b\udb39\udfc7\ud8a6\udcd6\uda74\ude95\udb10\ude2b\u7bef\ud88d\udd09\ud9fd\udee1\uda81\uddd7\udbaa\ude53\ud87a\udd2d\ud838\udd3f\uda8a\ude26\ud802\udc4b\ud87a\udc71\udb2e\udf1a\ud9aa\udd35\udbe9\udf62\udb7e\udf7d\ud819\udf9c\udb1e\udff5\ud8bf\udebb", "\u4630", "\udb42\uddcf\ud92e\uddaf",
        19, 16778, -1954318978, -6058840657629017179L, -40613L, false, true, (char) 22987, (char) 63230,
        Double.longBitsToDouble(0x3fde093d9b7a466eL), Double.longBitsToDouble(0x3fe00f9915895422L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 0, 15, "", "\ua20e\000\u67af\ub47a\u999e\u2946\u2776\uc52e\u1800\000\u3723\ud030\u5fb3\u385b", "\ud9f3\ude1f\udbe5\udea1\udb5c\uddd1\ud8f4\ude5b\ud89a\uded5\ud9b2\udf6f\uc7d6\000",
        -5, 61888, 1777452823, 274963806289920L, -100000L, false, false, (char) 36052, (char) 32245,
        Double.longBitsToDouble(0x3e3ba24800000000L), Double.longBitsToDouble(0x3fbdd7ca40003d30L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\0121=java.lang.Double:0.11868053284126938 |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 13, 8, 1, "\ud902\ude64", "\uc931\u27ad\ua5d2\u81fe\u2946\u2776\uc52e\u1800\u9cdc\u3723\ua4ee\u8e55\u385b\ubf92\u9bf1\ud211\u8b02\u3959\u1d0a", "\ud986\uddff\udb39\udfc7\udb4b\udcd8\ud8e4\ude92\ud847\udff4\uda6a\udc06\ud8f4\udddb\udb6b\udcac\uda4c\udd5c\ud942\udf03\uda38\udcdf\uda7c\udd95\uda0e\udee4\uda7c\udd0f\ud969\udcea\ud999\udc27\ud8aa\uddfb\udb00\udd6b\ud88c\udc78\uda22\udef4\ud87f\udc05",
        -2, 3027, -1545105163, -4160437632716089203L, 3952L, false, false, (char) 61440, (char) 4770,
        Double.longBitsToDouble(0x3fd60c4b732638e4L), Double.longBitsToDouble(0x3fee471e8956a47aL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{61.5,0.0,0.0,0.0},{0.0,-24.0,0.0,0.0},{0.0,0.0,28025.0,0.0},{0.0,0.0,0.0,28141.0}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 6, 3, "\u00ab\000\udb22\udc0a", "\000\u192f\u516c", "",
        0, 56440, 1148641607, 1443664650362601274L, 38166L, true, true, (char) 53477, (char) 13134,
        Double.longBitsToDouble(0x3fdb9396a1664e2aL), Double.longBitsToDouble(0x3ec8400000000000L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{17884.5,0.0,0.0,0.0,0.0},{0.0,28013.5,0.0,0.0,0.0},{0.0,0.0,28380.0,0.0,0.0},{0.0,0.0,0.0,27864.5,0.0},{0.0,0.0,0.0,0.0,28351.0}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 6, 3, "\u8be9\udb0b\udde8\ud9e1\uddae", "\ub47a\ubb31\u4c6c", "\ud987\uddef\ud8fd\udcf7\ud8ee\udfd9",
        0, 41754, 485467419, -3877066798862558737L, -26582L, true, true, (char) 34760, (char) 5140,
        Double.longBitsToDouble(0x3fc9d45139d77ed0L), Double.longBitsToDouble(0x3fe113b0a9e6887bL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27908.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28171.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,28013.5,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28400.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,28100.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28310.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,27970.5,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 6, 3, "\uda39\udc46\udb0b\ude10\udbb8\udd5c\udab5\udfc1\ud9cf\udf80\udb9d\udf9f", "\u7c7f\u3bf3\u1800\ud1a4\ud26b\ud030\u7ca8\u3897\ub484\ubf39\u1316\u48cd\u186d\u7f1d\u5ba8\u1ae4\u0350\u0a83\uc2e0\u7c01\u8651\u87b8\u8edf\u50b1\uc18e\u422b\ud00c\ubfb3\u71ac\ubfcc\ubbe5\uc01f\u658c", "\uda53\udeb7\ud8c0\udd5d\ud9d6\udd53\ud84b\udfc4\ud97d\udfd4\ud87e\udced",
        32, 59950, -1285348847, -58678993566114666L, -13836L, true, false, (char) 41195, (char) 39764,
        Double.longBitsToDouble(0x3f8519d6081f0480L), Double.longBitsToDouble(0x3fd2d94a89cf650eL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28184.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,27899.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28337.5,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,2.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,-24.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,28056.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 6, 3, "\udad5\udc61\uda26\udd934\000\udb60\udfd0\udb9d\udf9f", "\u7c7f\u3bf3\u1800", "Z\uda12\udf71\ud870\udea3\ud8ce\udc1e\ud806\udedc\ud85f\ude15\ud91e\udefb\ud8b6\udd8b\uda8b\udef2\ud854\udd59\u00b4\ud840\ude1f\udb39\udf28\000\ud8c1\udd03\udb6e\udcaf\ud92c\udd2a\udbba\ude4c\uda73\udf34\udae6\udc60\uda39\udc16\ud9ff\ude71\udbb4\udc1a\uda5d\ude93\udab0\udf89\ud9d0\udd50\udaba\udcf5\udba1\udd60\u9464\u200b\uda53\udeb7\ud8c0\udd5d\ud9d6\udd53\ud84b\udfc4",
        37, 83458, 131240692, 9021827697317454353L, -25398L, false, false, (char) 43699, (char) 50043,
        Double.longBitsToDouble(0x3f44035ce9300000L), Double.longBitsToDouble(0x3f8519d6081f0480L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27837.5,0.0,0.0},{0.0,28238.5,0.0},{0.0,0.0,-24.0}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 6, 3, "\ud9ab\udccd\000", "\u7684", "\udb36\udf1b\ud839\udec9\udbea\udeef\udab7\ude42\ud89b\udc44\ud947\ude74Z\uda12\udf71\ud870\udea3\ud8e2\udd1e",
        23, 61656, -389976998, -2660812976662800764L, 75797L, false, false, (char) 4513, (char) 29963,
        Double.longBitsToDouble(0x3e4c5c0000000000L), Double.longBitsToDouble(0x3fe0a49acae6f082L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28184.5,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,-24.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,-24.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,-24.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,-24.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,9869.0}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 6, 3, "\udad5\udc61\000\000\000\000\u4d4a", "\u7c7f\u3bf3\u1800", "Z\uda12\udf71\ud870\udea3\ud8e2\udd1e\ud806\udedc\ud9f3\ude1f\ud91e\udefb\ud8b6\udd8b\uda75\ude8b\ud854\udd59\000\ud840\ude1f\udb39\udf28\000\000\027\000\udb8d\udf66\uda73\udf34\udae6\udc60\uda39\udc16\ud9ff\ude71\udbb4\udc1a\uda5d\ude93\udb70\uddc8\ud8bf\ude24\udbd8\udda4\udb7e\udf01\udb4c\udc56\udb98\udde1\uda53\udeb7\ud8c0\udd5d\ud9d6\udd53\ud84b\udfc4",
        14, 83458, 131240692, 9021827697317454353L, -25398L, false, false, (char) 43699, (char) 50043,
        Double.longBitsToDouble(0x3f44035ce9300000L), Double.longBitsToDouble(0x3f8519d6081f0480L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{4702.0}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 9, 2, "\u24ec", "\u92f2\u98c3\ub47a\u4aa6\u7b9a\u7c7f\u3bf3\u1800\u22eb\ud26b\ud030\u5fb3\u385b\ub484\ubf39", "\ud8b6\udd8b\uda75\ude8b\ud854\udd59\ud9b2\udf6f\ud986\uddff\udb39\udf28",
        19, 81419, -1822820585, -1116054791839436058L, 69346L, true, false, (char) 31301, (char) 64669,
        Double.longBitsToDouble(0x3fc3c52b89685f40L), Double.longBitsToDouble(0x3fdd86c95cde1c2eL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28184.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,28013.5,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28380.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,27972.5,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28149.5,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,27966.5,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\0121=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28184.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,28013.5,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28380.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,27972.5,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28149.5,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,27966.5,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 2, 14, 14, 3, "\udad5\udc61\udb0b\udde8\udab9\udc1b\udaad\uddbf\uda6a\udeed\ud9e0\udd12", "\u3132\u3bf3\u1800", "\ud92a\udcd6\uda12\udfeb\ud870\udea3\ud8e2\udd1e\u73f3\ud9f3\ude1f\ud965\udc6e\ud8b6\udd8b\uda75\ude8b\udbe8\ude5b\uda70\ude80\udb02\udc63\udbcb\udff9\udb68\udddc\uda20\udc59\udb6e\udd7c\ud92c\udd2a\udbba\ude4c\ud9f6\udf80\udab1\udee7\ud95a\udce0\ud9ff\ude71\uda5c\uddee\ud936\udda0\udb5b\ude81\ud4c0\ud843\udd81\udb9d\udeb7\udb4c\udc56\udba3\udfe1\uda53\udeb7\ud8c0\udd5d\ud9d6\udd53\ud84b\udfc4",
        31, 35714, 131240653, 9021827697317454353L, 87627L, false, false, (char) 17345, (char) 62286,
        Double.longBitsToDouble(0x3fca34107ce93068L), Double.longBitsToDouble(0x3f8519d7081f0480L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{-24.0}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 3, "\000", "\ua7c0\u6854M\000\000\u0b12\u3bf3\u1800\ucb91\ud26b\ua373\000\000\000\000\uc1c6\uce00\u186d\u0084\u3c70\ud4b5\u6f96\ua08c\u8916", "\ud92c\udd2a",
        0, -878, 4776704, 3971858212015918684L, -54176L, false, false, (char) 22803, (char) 58295,
        Double.longBitsToDouble(0x3fe808031800fb27L), Double.longBitsToDouble(0x3fe0000006c21a3eL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optim.nonlinear.vector.Weight:@? |a0=[D:[[27986.5, 28184.5, 28013.5, 28380.0, 27851.5, 28153.0, 27966.5, 28359.5]]\0121=new org.apache.commons.math3.optim.nonlinear.vector.Weight:@? |a0=[D:[[27986.5, 28184.5, 28013.5, 28380.0, 27851.5, 28153.0, 27966.5, 28359.5]]\012",
        Z.run(T, 2, 1, 1, 3, "\udad5\udc61\udb0b\udde8\ud9c7\udc22\udaad\uddbf\ud9cf\udf80\udb0a\udf48", "\u7c7f\u3bf3\u1800\ud1a4\ud26bs\ud28a\u3929\uaf64\u9c8e\u1316\u48cd\u186d\u4b3b\u5bcc\u1ae4\u0350\u84fd\uad98\u97cc\u8651\u87b8\u8edf\u50b1\uc7ee\u422b\ud00c\ubfb3\u71ac\ubfcc\ubbe5\uc01f\u658c", "\uda53\udeb7\ud8c0\udd5d\ud9d6\udd53\ud84b\udfc4\ud97d\udfd4\ud87e\udced",
        50, 59950, -1285348847, -2946948177404778L, -13836L, true, true, (char) 28614, (char) 4999,
        Double.longBitsToDouble(0x3f8519d6081f0480L), Double.longBitsToDouble(0x3fda1898b21e1fccL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\0121=void |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 13, 13, 13, "\uda97\udc47\udb48\udfae\ud8b7\udd8d\uda31\udcb8\ud83a\udf4b\uda82\udc31\ud92f\udfe0\udb48\udd53\ud922\udf86\udbea\udf45\ud9e6\udf80\ud803\udfad\ud886\udd21\udb53\ude10\udb1d\uddc1", "\u57cf\u2347\u0322\u9ad5\ub668\u5c88\u260f\ub799\u239b\u41b3\u0e63\u52c6\u97bb\u448c\u8371\ud50c\u2c52\u2efb\u221a\u3d41\ucceb\u2d44\u35d6\u2f9c", "\udaab\udc81\udb6e\udf89\ud8dd\udd41\ud981\udeaf",
        -1, 19130, -997873787, -844099060179233633L, 632L, true, true, (char) 59107, (char) 36374,
        Double.longBitsToDouble(0x3fc8122c3d41d788L), Double.longBitsToDouble(0x3fe1b9f9158ebcf0L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28184.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,28013.5,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28380.5,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,27972.5,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28149.5,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,27966.5,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\0121=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28184.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,28013.5,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28380.5,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,27972.5,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28149.5,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,27966.5,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 2, 14, 14, 3, "\udad5\udc61\udb0b\udde9\udab9\udc1b\udaad\uddbf\uda6a\udeed\ud9e0\udd12\udbc4\ude33\ud811\ude1e\ud826\udf7c\udbea\udeef\udab7\ude42\ud99d\udc45\udb8b\udd4f\ud92a\udcd6\uda12\udfeb\ud870\udea3\ud8e2\udd1e\udb70\ude5c", "\u186d\u7f1d\u2637\u2115\uc920\u129c\u6e0b", "\uda0c\udcac\udbba\udde7\ud9f6\udf80\udab1\udee7\ud95a\udce0",
        25, 77338, -528960644, 4479422294912473833L, 42934L, false, false, (char) 30172, (char) 1045,
        Double.longBitsToDouble(0x3fe2e7551a336de1L), Double.longBitsToDouble(0x3fc54745eb35aa50L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\0121=void |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 13, 13, 13, "\uda50\ude48\udb13\udcae\ud8b7\udd00\uda31\udcb8\ud83a\udf4b\uda82\udc31\u82f9\000\000\udbea\ude54\ud9e6\udf80\ud803\udfad\ud886\udd21\udb53\ude10\udb1d\uddc1", "\ud2f8\u2347\u0322\uab7a\u50e3\u5c88\u260f\ub799\u22b9\u41b3\ubb20\u52c6\u97bb\u0584\u9bda\u5d53\000\000\000\ua6ab\u0426\u2d04\u751e\u65ed", "\u0082",
        46, 54748, 0, 0L, -100000L, false, false, (char) 47412, (char) 59107,
        Double.longBitsToDouble(0x3ebe400000000000L), Double.longBitsToDouble(0x3fe803a806373f22L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 10, 8, "\uda2e\ude0e\uda9c\udd6f\udb91\ude1a\udac7\udd3a\ud9cf\udf80\udb9d\udf9f\ud8fc\udc86", "\u3bf3\u1800\ud1a4", "\uda12\udfab\ud870\udea3",
        17, 35063, -641085344, -2101676505722344582L, 70235L, true, true, (char) 25576, (char) 54671,
        Double.longBitsToDouble(0x3fd3e750bfe9f23cL), Double.longBitsToDouble(0x3fe8b9a1721469f1L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{-24.0}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\0121=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{-24.0}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 2, 14, 14, 8, "\000", "\ua7c0\u6854M\000\000\u0b12\u3bf3\u1800\ucb91\ud26b\ua373\000\000\000\000\uc1c6\uce00\u186d\u0084\u3c70\ud4b5\u6f96\ua08c\u8916", "\ud92c\udd2a",
        0, -878, 4776704, 3971858212015918684L, -54176L, false, false, (char) 22803, (char) 58295,
        Double.longBitsToDouble(0x3fe808031800fb27L), Double.longBitsToDouble(0x3fe0000006c21a3eL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{1.0}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 3, "2", "\ua7c0\u6854M\000\000\u0b12\u00f3\u1800\ucb91\ud26b\ud667\u03e0!\000\000\uc1c6\uce00\u186d\u0084\u3c70\ud4b5\u6f96\ua08c\u8916", "\ud92c\udd2a",
        0, -878, 4776704, 3971858212015918684L, -93111L, true, false, (char) 48936, (char) 64295,
        Double.longBitsToDouble(0x3fe13f4804962b27L), Double.longBitsToDouble(0x3fe4f5857b1776beL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{1064.5}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\0121=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{1064.5}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 2, 14, 14, 8, "\u0881", "\ua7c0\u6854M\000\000\u0b12\u3bf3\u1800\ucb91\ud26b\u1f73\uc96d\000\000\000\uc1c6\uce00\uaa9f\u4590\u3c70\ud4b5\u6f96\ua08c\u8916", "\ud92c\udd2a",
        0, -878, 4776704, 3971858212015918684L, -54176L, false, false, (char) 22803, (char) 58295,
        Double.longBitsToDouble(0x3fe808031800fb27L), Double.longBitsToDouble(0x3fe0000006c21a3eL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28184.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,27899.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28337.5,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,2.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,9.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,28056.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 1, 14, 6, 3, "\udad5\udc61\uda26\udd934B\udb60\udfd0\udb9d\udf9f", "\u7c7f\u3bf3\u1800", "Z\uda12\udf71\ud870\udea3\ud8ce\udc1e\udb4d\udf21\ud85f\ude7a\ud91e\udefb\ud8b6\udd8b\uda8b\udef2\ud854\udd59\u00b4\ud840\ude1f\udb39\udf28\000\ud8c1\udd03\udb6e\udcaf\ud92c\udd2a\udbba\ude4c\uda73\udf34\udae6\udc60\uda39\udc16\ud9ff\ude71\udbb4\udc1a\uda5d\ude93\udab0\udf89\ud9d0\udd50\udaba\udcf5\udba1\udd60\u9464\u200b\uda53\udeb7\ud8c0\udd5d\ud9d6\udd53\ud84b\udfc4",
        37, 4482, 131240692, 9021827697317454353L, -25398L, false, false, (char) 43699, (char) 50043,
        Double.longBitsToDouble(0x3f44035ce9300000L), Double.longBitsToDouble(0x3f8519d6081f0480L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28184.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,28020.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28479.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,27972.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28611.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,28091.0,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\0121=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{27986.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,28184.5,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,28020.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28479.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,27972.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,28611.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,28091.0,0.0},{0.0,0.0,0.0,0.0,0.... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 2, 14, 14, 3, "\udad5\udc61\udb18\udeae\udab8\udfb6\udba6\udfdc\udb77\udf3b\ud9e0\udd12", "\u3132\u3bf3\u1800", "\ud92a\udcd6\uda12\udfeb\ud870\udea3\ud8e2\udd1e\u73f3\ud9f3\ude1f\ud965\udc6e\ud8b6\udd8b\uda75\ude8b\udbe8\ude5b\uda70\ude80\udb02\udc63\udbcb\udff9\udb68\udddc\uda20\udc59\udb6e\udd7c\ud92c\udd2a\udbba\ude4c\ud9f6\udf80\udab1\ude9c\ud95a\udce0\ud9ff\ude71\uda5c\uddee\ud936\udda0\udb5b\ude81\ud4c0\ud843\udd81\udb9d\udeb7\udb4c\udc56\udba3\udfe1\uda53\udeb7\ud8c0\udd5d\ud9d6\udd53\ud84b\udfc4",
        31, 35714, 131240653, 9021827697317454353L, 87627L, false, false, (char) 17345, (char) 62286,
        Double.longBitsToDouble(0x3fca34107ce93068L), Double.longBitsToDouble(0x3f8519d7081f0480L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 6, 3, "\000", "\ud5a6\u20a9M\000\000\u0b12\u3bf3\u1800\ucb91\ud26b\ua373\000\u1509\u9a21\000\uc1c6\uce00\u186d\u0084\u3c70\ud4b5\u6f96\ua08c\u8916", "\ud92c\udd2a\udbba\ude4cz",
        44, 13304, 23940700, 78382624191232L, -27575L, true, false, (char) 48995, (char) 64295,
        Double.longBitsToDouble(0x3fe0000006c21a3eL), Double.longBitsToDouble(0x3fb6612258f00d20L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\0121=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 2, 14, 14, 8, "", "\u3065", "M",
        -5, -1000, 8801111, -1165778341L, 88743L, false, true, (char) 21, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e3036c800000000L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{-24.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,-24.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,-24.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,-24.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,-24.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,27864.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,28273.0}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\0121=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{-24.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,-24.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,-24.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,-24.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,-24.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,27864.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,28273.0}} |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 2, 14, 14, 3, "\000\000\000\000\000\ud9e0\udd12", "\u7177\u3bf3\u1800", "\ud92a\udcd6\uda12\udfeb\u7e1b\ud8a9\udcd4\u73f3\ud9f3\ude1f\ud965\udc6e\ud8b6\udd8b\uda75\ude8b\udbe8\ude5b\uda70\ude80\000\000\000\uda20\udc0b\ud909\udfe9\000\000\ud984\udf01\uda78\udf9c\ud95a\udce0\ud9ff\ude71\uda5c\uddee\ud936\udda0\udb55\udc81\ud4c0\ud843\udd81\udb9d\udeb7\udb4c\udc56\udba3\udfe1\udab1\udec6\000\ud99a\udcad\ud84b\udfc4",
        40, 35714, 117478093, 9021827697317454353L, 87627L, false, false, (char) 17345, (char) 62286,
        Double.longBitsToDouble(0x3fca34107ce93068L), Double.longBitsToDouble(0x3f8519d6081f0480L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{-24.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,27694.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,28363.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28091.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,28229.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,-24.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,-24.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\0121=org.apache.commons.math3.linear.DiagonalMatrix:DiagonalMatrix{{-24.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,27694.0,0.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,28363.0,0.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,28091.0,0.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,28229.0,0.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,-24.0,0.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,-24.0,0.0},{0.0,0.0,0.0,0.0,0.0,0.0,... |this=org.apache.commons.math3.optim.nonlinear.vector.Weight:@?\012",
        Z.run(T, 2, 14, 14, 3, "\000\ud88c\uddc6\udba6\udcba\000\000\ud9e0\udd12", "\u7177\u3bf3\u1800", "\ud92a\udcaf\uda91\ude0a\ud979\udd71\ud8a9\udcd4\u73f3\ud9f3\ude1f\ud965\udc6e\ud8b6\udd8b\ud8ea\udd0f\ud988\udf77\uda8a\udf44\ud9c4\udc77\ud9cb\udd36\ud849\udc1c\uda20\udc0b\ud909\udfe9\udaf9\udf3b\ud9fb\ude16\ud975\udf2e\uda78\udf9c\ud95a\udce0\ud9ff\ude71\uda5c\uddee\ud936\udda0\uda3d\udc9d\ud435\ud843\udd81\udb9d\udeb7\ud993\udd10\ud8ea\udc6d\udab1\ude49\000\ud99a\udcad\ud84b\udfc4",
        54, 35714, 117478093, 9021827697317454353L, -23531L, false, false, (char) 7873, (char) 26840,
        Double.longBitsToDouble(0x3fc1b6d4dce93068L), Double.longBitsToDouble(0x3f8519d6081f0480L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.AbstractLeastSquaresOptimizer|squareRoot|org.apache.commons.math3.linear.RealMatrix|new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "C|org.apache.commons.math3.optim.nonlinear.vector.Weight|<init>|[D",
    "C|org.apache.commons.math3.optim.nonlinear.vector.Weight|<init>|org.apache.commons.math3.linear.RealMatrix",
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.AbstractLeastSquaresOptimizer|computeCost|[D|new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.AbstractLeastSquaresOptimizer|computeCovariances|[D,double|new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.AbstractLeastSquaresOptimizer|computeResiduals|[D|new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.AbstractLeastSquaresOptimizer|computeSigma|[D,double|new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.AbstractLeastSquaresOptimizer|computeWeightedJacobian|[D|new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.AbstractLeastSquaresOptimizer|getChiSquare||new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.AbstractLeastSquaresOptimizer|getRMS||new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.AbstractLeastSquaresOptimizer|getWeightSquareRoot||new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.AbstractLeastSquaresOptimizer|optimize|[Lorg.apache.commons.math3.optim.OptimizationData;|new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.AbstractLeastSquaresOptimizer|parseOptimizationData|[Lorg.apache.commons.math3.optim.OptimizationData;|new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.AbstractLeastSquaresOptimizer|setCost|double|new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "M|org.apache.commons.math3.optim.nonlinear.vector.Weight|getWeight||new:org.apache.commons.math3.optim.nonlinear.vector.Weight:[D",
    "M|org.apache.commons.math3.optim.nonlinear.vector.jacobian.AbstractLeastSquaresOptimizer|squareRoot|org.apache.commons.math3.linear.RealMatrix|new:org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer:org.apache.commons.math3.optim.ConvergenceChecker",
    "C|org.apache.commons.math3.optim.nonlinear.vector.Weight|<init>|[D",
    "C|org.apache.commons.math3.optim.nonlinear.vector.Weight|<init>|org.apache.commons.math3.linear.RealMatrix",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
