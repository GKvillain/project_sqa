package org.apache.commons.math.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class MathUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Long:7770982488770528782\012",
        Z.run(T, 1, 3, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\u1114\u2449\u9e39\ube34\u9ce2\u7e40\ua268\u0aac\u6b97\u516a", "\ud963\udfac\udad2\udccd\uda05\udd61\ud9bc\udf0b\ud985\ude88\uda28\udc52",
        48, 12657, -402292012, 7770982488770445717L, 83065L, false, false, (char) 39442, (char) 62865,
        Double.longBitsToDouble(0x3fe465fac34933c8L), Double.longBitsToDouble(0x3fe25744156cd2bbL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Long:7770982491899718926\012",
        Z.run(T, 1, 3, 14, 1, "\ud84b\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\u2090\u824f\u9e39\ube34\u9ce2\u7e40\ua268\u0aac\u6b97\u516a", "\ud963\udfac\ud967\udd57\ud8e9\udf08\ud8b6\udd1b\ud9c2\udd58\uda28\udc52",
        48, 98857, -402292012, 7770982491899635861L, 83065L, false, false, (char) 39442, (char) 62865,
        Double.longBitsToDouble(0x3fe465fac34933c8L), Double.longBitsToDouble(0x3fe25744156cd2bbL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Long:7770982488770528782\012",
        Z.run(T, 1, 3, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\u1114\u2449\u6518\ube3f\u9ce2\u7e40\ua268\u0aac\u6b97\u516a", "\uda9e\udef5\udad2\udccd\uda05\udd61\ud9bc\udf0b\ud985\ude88\uda28\udc52",
        48, 20225, -402292205, 7770982488770445717L, 83065L, false, false, (char) 39442, (char) 62865,
        Double.longBitsToDouble(0x3fe465fac34933c8L), Double.longBitsToDouble(0x3fe25744156cd2bbL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Long:7770982488770424796\012",
        Z.run(T, 1, 3, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\u1114\u2449\u9e39\ube34\u9ce2\u7e40\ua268\u0aac\u6b97\u516a", "\ud963\udfac\udad2\udccd\uda05\udd61\ud9bc\udf0b\ud985\ude88\uda28\udc52",
        48, 12657, -402292012, 7770982488770445717L, -20921L, false, false, (char) 39442, (char) 62865,
        Double.longBitsToDouble(0x3fe465fac34933c8L), Double.longBitsToDouble(0x3fe25744156cd2bbL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Double:1.2767436306911084\012",
        Z.run(T, 1, 9, 14, 16, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\ud91b\udf7c", "\u2c0f\u61a0\u08e1\u4a8d\u9e39\ube34\u9ce2\u7e40\ua268\ua2bb\u6688\u516a", "\udbb4\udff5\ud8e8\ude4d\uda05\udd61\ud913\udcb7\uda63\ude2f\ud9b2\udfb1",
        48, 12657, -939162924, 7767463437381239189L, 83065L, false, false, (char) 39442, (char) 62865,
        Double.longBitsToDouble(0x3fe74a1e8b4933c8L), Double.longBitsToDouble(0x3fe25744156cd2bbL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda25\udf60", "\u8163\u9f4f\u5a61\ubc25\u9e39\ube34\u9ce2\u7e40\ua268\u0aac\u6b97\u516a\u85e5\ud0b6\u6adb\u7e83\u0742", "\uda28\udc52\udaed\udf18",
        37, 90988, 1809322855, -5840744763509012611L, -67710L, false, true, (char) 62865, (char) 29924,
        Double.longBitsToDouble(0x3fea499b3a4ae882L), Double.longBitsToDouble(0x3fe48695dde0c6b5L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Byte:1\012",
        Z.run(T, 1, 15, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\u1114\u2449\u9e39\ube34\u9ce2\u7e40\ua268\u0aac\u6b97\u516a", "\ud963\udfac\udad2\udccd\uda05\udd61\ud9bc\udf0b\ud985\ude88\uda28\udc52",
        48, 12657, -402292012, 7770982488770445717L, 50553L, false, false, (char) 39442, (char) 62865,
        Double.longBitsToDouble(0x3fe465fac2ee8fc8L), Double.longBitsToDouble(0x3fce1fdd6ea031e8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27803.0, 28252.5, 28022.5, 28631.5, 28037.0, 28219.5, 27795.5, 28216.0]] |a1=[D:[[4401.5, 20367.5, 18773.0, 4620.5, 24514.0, 15530.0]]\012",
        Z.run(T, 1, 11, 14, 7, "\ud966\udce9\udb1d\udfdf\udb3a\udca7\ud957\udca0", "\u2293\u9f4f\u92da\u2449\ubfb4\u7984", "\ud939\uddb7\ud8cf\ude23\ud8ad\udd6e\udae6\udf59\ud8a6\udf7f\u9863\ud964\udc10\udad2\udccd\uda05\udd61\ud9bc\udf0b\ud985\ude91\ud9e8\udf23\udaed\udf18\ud9af\udfe2",
        54, 25683, -1359912150, -6058599902880286949L, 60146L, true, true, (char) 7892, (char) 63225,
        Double.longBitsToDouble(0x3fdbc0e95ad9a514L), Double.longBitsToDouble(0x3fdbd79428d8bda4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Byte:-1\012",
        Z.run(T, 1, 15, 16, 14, "\ud84e\udf14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u7c9e\u11a8\u2449\u9e39\ube34\ua60d\u17a3\ub7b9\u0aac\u2795\u516a", "\ud963\udfac\udad2\udccd\uda05\uddc8",
        -4, 46909, -201766648, -2723682360568106575L, -3613L, false, true, (char) 31669, (char) 8293,
        Double.longBitsToDouble(0x3fcaf6842a32fd60L), Double.longBitsToDouble(0x3fea499e424ae882L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Long:-2723682360568110188\012",
        Z.run(T, 1, 3, 16, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\u1114\u2449\u9e39\ube34\u9ce2\u7e40\ua268\u0aac\u6b97\u370b", "\ud963\udfac\udad2\udccd\uda05\udd61",
        39, 90040, -201766648, -2723682360568106575L, -3613L, true, true, (char) 50092, (char) 39442,
        Double.longBitsToDouble(0x3fcaf6974a32fd60L), Double.longBitsToDouble(0x3fea499e424ae882L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:1670563873 |a0=[D:[[27669.0, 28402.0, 27791.5, 28167.5, 28039.5, 28316.0, 27914.0, 28453.0]]\012",
        Z.run(T, 1, 14, 14, 7, "\ud85a\ude14\ud94f\udc3f\udb3f\udd68\uda44\ude7a", "\u8163\uceb7\u334d\u2449\u9e39\ube34\u9ce2\u7e40\ua268\u0aac\u7357\u42c1", "\ud963\udfac\udad2\udccd\uda05\udd61\udb32\udc26\ud985\ude88\uda28\udc52",
        48, 12657, -402292012, 7770982488770445717L, 83065L, false, false, (char) 39442, (char) 62865,
        Double.longBitsToDouble(0x3fe465fac34933c8L), Double.longBitsToDouble(0x3fe25744156cd2bbL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Double:1.0888869450418425E28\012",
        Z.run(T, 1, 1, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8\udad6\udf0f\uda21\udc46", "\ubd2e\u2449\u9e39\ube34\u9ce2\u7e40\ua268\u0aac", "\ua63c\ud95e\udc3e\ud987\udcac",
        27, 85288, 279646736, -1407014591833487096L, -47185L, false, false, (char) 64364, (char) 60780,
        Double.longBitsToDouble(0x3fe3ed7788194b6bL), Double.longBitsToDouble(0x3fd2f9b4db1d6022L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Long:-3261958212371068297\0121=java.lang.Integer:-776919583 |a0=[D:[[27933.5, 28559.0, 27685.0, 28426.0, 27970.5, 28317.0, 27937.5, 28348.0]]\012",
        Z.run(T, 2, 3, 14, 17, "\uda6b\udf4e\ud87a\ude44\udab5\udd6a\uda73\udda8", "\u63cb\uaadc\u0f1e\u2449\u9e39\ube34\ua2c1\u853a\u4ab4\u0ae2\ubd33\u3ad5", "\ud915\uddad\ud913\udf75\ud96c\udf49\ud9bc\udf59\ud985\ude88\u7aae\udadb\udc42\ud9af\udfe2\ud8ce\udd6a\udbfc\uddc1\ud853\udcce\ud944\udfed\uda48\udc4a\u98bd\ud978\udd22",
        -3, 99292, -1162906030, -3261958212371016340L, -51957L, true, false, (char) 34548, (char) 55071,
        Double.longBitsToDouble(0x3fecfbf2465eb296L), Double.longBitsToDouble(0x3fe95bd63d46cd18L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 17, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8\ud82c\udcf9\uda0f\uddf8\udaba\udc05\ud9f1\udd30\udb4c\udc3f\ud8c7\uded8\uda7e\udd3d\udbb4\udc10\udb7d\udca6\udabc\uddf9\ud939\uddb7\uda32\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud95e\udc3e\ud963\udfc0\udad2\udccd\uda05\udd61\ud9bc\udf0b\ud985\ude88\uda28\udc52\udaed\udf18\ud9af\udfe2\u3d2c\udbfc\uddc1\ud853\udcce\ud8b4\udfee\uda2b\udfd4\u9885\ud97d\udd22\uda31\udd07\ud8bd\udd99\uda5c\udde6\ud79f\ud960\uddd9", "\u3b33\ub80e\ua902\u1eef\u7c6e\u0925\u7aab\u568e\u0706\u44e5\u0dd5\u5903\u06af\u0bf9\ub2d4\u3aad\u1865\u6fb7\u8768\uc38b\u52d0\u0400\u32bd\u50aa", "\ud9a7\udd93",
        -5, 37854, 1003839453, 726025069735064705L, -8978L, false, false, (char) 60599, (char) 9548,
        Double.longBitsToDouble(0x3fe52e66b02e42ebL), Double.longBitsToDouble(0x3fd178d0ecc2a9deL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Long:-3261958212594596566\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 3, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\ubff2\u2449\u9e39\ucf0e\u9ce2\u7e40\ua268\u0aac\u6b97\u516a", "\ud963\udfac\udad2\udccd\uda05\udd61\ud9bc\udf0b\ud985\ude88\uda28\udc52\udaed\udf18\ud9af\udfe2\ud8ce\udd6a\udbfc\uddc1\ud853\udcce\ud944\udfed\uda2b\udfd4\u9885\ud97d\udd22",
        -3, 76636, -394099895, -3261958212594690708L, 94142L, false, false, (char) 6768, (char) 57639,
        Double.longBitsToDouble(0x3fe2d38e69bc14e2L), Double.longBitsToDouble(0x3fe8cc523c90ffa1L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Double:1.2413915592536315E61\012",
        Z.run(T, 1, 17, 14, 7, "\ud91e\udff3\ud946\udfe1\udabc\udfe8\uda60\udfa8", "\u8163\u9f4f\u1114\u2449\u9e39\ube34\u9ce2\u7e40\ua268\u0aac\u6b97\u516a", "\ud963\udfac\udad2\udccd\uda05\udd61\ud9bc\udf0b\ud985\ude88\uda28\udc52",
        48, 12657, -1974172972, 5383188939439010913L, 68981L, false, false, (char) 39433, (char) 62865,
        Double.longBitsToDouble(0x3fe465fac34933c8L), Double.longBitsToDouble(0x3fe25744156cd2bbL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Long:5786785772757678795\012",
        Z.run(T, 1, 5, 0, 0, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8", "\u9086\u8163\u9f4f\u1114\u2449\u9e39", "\udabc\uddf9\ud939\uddb7\uda32\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud95e\udc3e\ud963\udfac\udad2\udccd\uda05\udd61\020\ud985\uddd9\uda28\udc52\udaed\udf18\ud858\uddb6\000",
        -5, 89288, 1263699837, 5786785772757614114L, 64681L, false, false, (char) 5376, (char) 33943,
        Double.longBitsToDouble(0x3fe941acd50c7735L), Double.longBitsToDouble(0x3fe4bcf3c141ae6aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Double:1.0888869450418425E28\0121=java.lang.Double:64.55753862700634\012",
        Z.run(T, 2, 17, 2, 7, "\ud85a\ude14\ud94f\udc3f\uda50\udd88\ud8ea\udf92", "\u7b83", "\ud8c7\uded8\uda7e\udd3d\ud9ca\udd85\udb6e\ude21\udabc\uddf9\ud939\uddb7\uda32\ude61\ud96c\udf03\uda32\uddca\uda27\udcf4\uda54\udff8\udb62\udd78\udb80\udea3\udba4\udc10\udb51\udc07\ud985\ude88\uda28\udc52",
        27, 12657, -402292012, 7770982492075557269L, 83065L, false, false, (char) 39442, (char) 62865,
        Double.longBitsToDouble(0x3fe465fac34933c8L), Double.longBitsToDouble(0x3fd14e882ad9a576L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:1\012",
        Z.run(T, 1, 12, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\u1114\u2449\u9e39\ube34\u9ce2\u7e40\ua2684\u6b97\u516a", "\ud953\udfac\udad2\udccd\uda05\udd61\020\000\uda28\udc52",
        22, 12657, -402292012, 7770982488770445717L, 83065L, false, false, (char) 39442, (char) 62865,
        Double.longBitsToDouble(0x3eb6180000000000L), Double.longBitsToDouble(0x3fe25744156cd2bbL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 10, 4, 10, "\u5a08\ud94f\udc3f\udabc\udfe8\uda73\udda8\uda0b\udfe9\uda30\uddb5\udaba\udc05\ud9f1\udd30\udb62\udddf\ud8be\udc33\ud9a0\udcd1\udbb4\udc10\udb7d\udca6\udabc\uddf9\ud939\uddb7", "\u516a\u8da5\u2a91\u7873\ubead\ua33c\u3e78", "\udaed\udf18\ud9af\udfe2",
        3, 7855, -1359904363, 5427549473222871833L, 60146L, true, false, (char) 16868, (char) 46864,
        Double.longBitsToDouble(0x3fe25744156cd2bbL), Double.longBitsToDouble(0x3fe1c216be3dcafdL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.ArithmeticException\012",
        Z.run(T, 1, 16, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\u1114\u2449\u9e39\ube34\u9ce2\u7e40\ua268\u0aac\u881a\ucccc", "\ud963\udfac\uda38\ude5b\ud9de\ude1d\ud9bc\udf0b\ud985\ude88",
        42, 21283, -514379343, -1727831033172716697L, 99710L, true, true, (char) 52848, (char) 9182,
        Double.longBitsToDouble(0x3fcaf6974aa86160L), Double.longBitsToDouble(0x3fea499e424ae882L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:23539\012",
        Z.run(T, 1, 4, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8\uda0b\udfe9\uda30\uddb5", "\u1114\ua489\u9e39\ube34\u7cc4\u7e40\u7520\u71c8", "\uda2c\udf09\ud95e\udc3e\ud963\udfac\udad2\udccd\uda05\udd61\ud9bc\udf0b\ud985\ude88\ud84c\udfa4",
        26, 23513, -402322732, -9018436922066763297L, 83065L, false, false, (char) 39442, (char) 50321,
        Double.longBitsToDouble(0x3fe465fac34933c8L), Double.longBitsToDouble(0x3fe25744156cd2bbL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27669.0, 28402.0, 27791.5, 28167.5, 27974.0, 28636.0, 27937.5, 28348.0]] |a1=[D:[[16537.5, 20367.5, 2162.0, 14178.0, 20200.5, 24322.0, 20057.0, 16182.5]]\012",
        Z.run(T, 1, 11, 17, 8, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\u1114\u6ef4\u9e01\ube34\u9ce2\u7e9d\ua268\u0aac\u6b97\u516a", "\ud963\udfac\udbab\udebb\ud953\ude17\ud9bc\udf0b\ud985\ude88\uda28\udc52",
        48, 12657, 67470036, 7770990226266489237L, 78286L, false, false, (char) 56838, (char) 49222,
        Double.longBitsToDouble(0x3fe465fac7ab33c8L), Double.longBitsToDouble(0x3fd06f3234e5e932L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 14, 0, "\ud85a\ude14", "\u6e7f\ub9bf\u911a\u8163\u9f4f\u1114\u2449\u9e39\u80df\000\000\u9e30\u0a78", "\uda2c\udf09\ud95e\udc3ed",
        -5, -1000, 279642112, 34137288925071624L, -47185L, false, false, (char) 64261, (char) 60780,
        Double.longBitsToDouble(0x3febed778b194b52L), Double.longBitsToDouble(0x3fe1128271922880L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27892.5, 28514.0, 27791.5, 28205.0, 27974.0, 28636.0, 27937.5, 28348.0]]\012",
        Z.run(T, 1, 11, 14, 7, "\uda19\udef4\ud94f\udc8a\udabc\udfe8\uda73\udda8", "\u07f3\u7edf\u1114", "\udbb4\udc10\udb7d\udca6",
        -5, 84631, 1169054516, 2084332438635609760L, 1058L, false, false, (char) 14512, (char) 32871,
        Double.longBitsToDouble(0x3fe085d517af10abL), Double.longBitsToDouble(0x3fd08ec792a7e7f2L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:1\012",
        Z.run(T, 1, 12, 12, 7, "\ud85a\ude14\ud94f\udc3f\000\000", "\u8163\u9f4f\u1114\u2449\u9e39\ube34\u9ce2", "\uda32\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud95e\udc3e\ud963\udfac\udad2\udccd\uda05\udd61\ud9bc\udf0b",
        47, 30352, -634156717, 54635876646912L, -1291L, true, true, (char) 5739, (char) 52848,
        Double.longBitsToDouble(0x3fd9228801af6974L), Double.longBitsToDouble(0x3fe465fac34933c8L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Long:-4918918009764210907\0121=java.lang.Long:20922789888000\012",
        Z.run(T, 2, 3, 0, 1, "\udab1\uddb6\udafc\udff2\uda90\udc94\ud80e\udd55\uda0b\udfa2\uda30\uddb5\udaba\udc05\ud9f1\udd30\udb62\udddf\ud893\udf5e\uda7e\udd2e\udbb4\udc10", "\u5fa4\u0aac\u6b97", "\ud95e\udc3e\ud99c\ude91\udad2\udccd\uda05\udd61\ud9bc\udf0b\ud985\ude88\uda28\udc52\udaed\udf18\ud9af\udfe2\ud8ce\udd6a\udbfc\udca2",
        16, 87837, 1347341081, -4918918009764286062L, 75155L, false, true, (char) 21420, (char) 51780,
        Double.longBitsToDouble(0x3fe43be23cd98ff0L), Double.longBitsToDouble(0x3fe5c5bb3e81dac0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Long:7770982488770528782\0121=java.lang.Long:7770982488770528782\012",
        Z.run(T, 2, 3, 5, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\u1114\u2449\u9e39\ube67\u9ce2\u7e40\ua268\u0aac\u6b97\u516a", "\ud963\udfac\udad2\udccd\uda05\udd61\ud9bc\udf0b\ud985\ude88\uda28\udc52",
        48, 12657, -402292012, 7770982488770445717L, 83065L, false, false, (char) 39442, (char) 62865,
        Double.longBitsToDouble(0x3fe465fac34933c8L), Double.longBitsToDouble(0x3fe25744156cd2bbL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 14, 7, "\udaa3\udf4d\ud9c9\udf0f\udabc\udf22\udbf8\udeaa", "\u8163\uac4f\u1114\u2449\u9e39\u24ba\u9ce2\u8468\ua268\u0aac\u6b97", "\ud95e\udc3e\ud963\udfac\udad2\udccd\uda05\udd61\ud9bc\udf0b\ud985\ude88\uda28\udc52\udaed\udf18\ud9af\udfe2\ud8ce\udd6a\udbfc\uddc1",
        51, 92853, -1603351783, 2914920880057315730L, -47338L, false, true, (char) 48316, (char) 32376,
        Double.longBitsToDouble(0x3fb3d4be8146c690L), Double.longBitsToDouble(0x3fea1f8f2b376053L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Double:362880.0\012",
        Z.run(T, 1, 17, 2, 11, "\ud84c\udf56\ud94f\udc3f", "\u48dc", "\udaaf\udc90\ud894\udd45\udb9a\uddbd\ud902\udf72\udbaa\udcd9",
        9, 5349, -1786176636, 1759788080610019794L, 60581L, false, true, (char) 55075, (char) 31551,
        Double.longBitsToDouble(0x3fa75a60d6e7da30L), Double.longBitsToDouble(0x3fee9957e108ec79L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Integer:1\012",
        Z.run(T, 1, 12, 14, 11, "\ud8c6\ude21\ud94f\udc3f", "\ub26c\ub9c6\u3ecb\u033c\u2cc2\u9e5e\u6518\u8265\ucf79\u7e40\u1bd1\u363a\ud332\u0d44\u85f0", "\ud899\udcd2\ud997\udcef\ud81b\udc9d\uda51\ude8e\udacb\udd44\udaed\udf18\ud978\udfc7\ud8ce\udca9",
        10, 59573, 1274972029, 5786785880492441122L, 64681L, false, false, (char) 59431, (char) 16506,
        Double.longBitsToDouble(0x3fc780759d9c4284L), Double.longBitsToDouble(0x3fe74b912399ea6aL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Integer:2034965025\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 13, 12, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\u1114\u2449\u8132\u085d\u9cac\u7e40\ua268\u0aac\u6b97\u516a", "\udb5c\udf09\udad2\udccd\ud96d\udd74\ud9bc\udf0b\ud985\ude88\uda28\udc52",
        39, 56066, -402292205, 7770982488770445717L, 83065L, false, false, (char) 39442, (char) 62865,
        Double.longBitsToDouble(0x3fd8613d46937b1cL), Double.longBitsToDouble(0x3fe257441015d2bbL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27669.0, 28402.0, 27791.5, 28167.5]] |a1=[D:[[22476.0]]\0121=java.lang.Integer:-470187839 |a0=[D:[[27669.0, 28402.0, 27791.5, 28167.5]]\012",
        Z.run(T, 2, 11, 14, 17, "\ud85a\ude14\ud94f\udc3f", "\uafc8", "\ud871\ude05\udb29\udfb9\ud8c7\uded8\uda4a\udc63",
        48, 91712, 1851253702, -6203584650047007044L, -62384L, true, true, (char) 3403, (char) 20790,
        Double.longBitsToDouble(0x3fc777856772dbbcL), Double.longBitsToDouble(0x3fe085d517af10caL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Double:3.1780538303479458\012",
        Z.run(T, 1, 2, 0, 17, "\ud9e5\ude65\ud91e\udf2a", "\ub9bf", "\ud879\udd34\udb28\udddf\udb0f\udc39\udb2a\udd33",
        4, 26519, 1175315321, -5079509184254317341L, 79295L, true, false, (char) 65287, (char) 53138,
        Double.longBitsToDouble(0x3fcc4f7282fd55b4L), Double.longBitsToDouble(0x3fe263802da11aabL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Double:6.204484017332436E23\0121=java.lang.Integer:102106559 |a0=[D:[[27471.0, 27965.0, 28283.0, 28101.0, 28351.0, 27843.5, 28336.0]]\012",
        Z.run(T, 2, 17, 14, 7, "\ud6ce\udaaa\udd26\udbba\uddae\ud9b7\udd90", "\u99a0\u9f4f", "\ud87d\udec4\udbed\udc23\ud81c\udc92\udabc\ude22\ud939\uddb7\uda32\ude61\ud812\udc0e",
        24, 47694, -1423018690, 8904813161357491484L, 26274L, false, true, (char) 13698, (char) 32076,
        Double.longBitsToDouble(0x3fdb1da335a9c2aeL), Double.longBitsToDouble(0x3feb3f402d956bd8L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:3\012",
        Z.run(T, 1, 12, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\u0cee\u2fe0\u9e39\ube34\u9ce2\u7e40\ua268\u0aac\u6b97\u516a", "\ud963\udfac\udad2\udccd\uda05\udde4\ud9bc\udf0b\ud985\ude88\uda28\udc52",
        48, 12657, -402292012, 7770982488770445717L, -20921L, false, false, (char) 39442, (char) 62865,
        Double.longBitsToDouble(0x3fe465fac34933c8L), Double.longBitsToDouble(0x3fe25744156cd2bbL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Integer:10\012",
        Z.run(T, 1, 12, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8", "\000\u8140\u9f4f\u1114\u2449\u9e39", "\udabc\uddf9\ud939\uddb7\uda32\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud95e\udc3e\ud963\udfac\udad2\udccd\uda05\udd61\ud9bc\udf0b\ud985\ude88\uda28\udc52\udaed\udf18\ud9af\udfe2\ud8ce\udd6a",
        10, -1000, -1301610496, 5786785880131796514L, 64681L, false, false, (char) 59431, (char) 24875,
        Double.longBitsToDouble(0x3fa0f21fba343990L), Double.longBitsToDouble(0x3fb5651a1c331188L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Double:1.2101439713833804\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 8, 9, "\ud85a\ude14\ud925\udc3f\ud9b0\udd84\uda37\udee6", "\uceb1\u9f4f\u6076\u2449\u4d3a\ube34\u9ce2\u7e1f\ua268\u3f6a\u6b97\u516a", "\uda5e\udcfe\udae0\udeb7\uda05\udd98\ud9bc\udf0b\ud985\ude88\udba0\udc8e",
        47, 65852, -402292145, -7419659054350237291L, -20921L, false, true, (char) 61332, (char) 62843,
        Double.longBitsToDouble(0x3fe465fac34933c8L), Double.longBitsToDouble(0x3fe25744152319bbL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Long:8121518231653304163\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 6, 14, "\ud811\udca5\ud8e2\udc3b\udabc\udfe8\uda25\udf60\udb0d\udccd\u4160\ud9a9\udffc\uda7e\ude77\udba1\udedf", "\ube34\uaa8e\u1664\u257e\u0aac\u638a\ua645\u295a\u2919\uc058", "\ud9bc\udf0b\ud985\ude88\uda28\udc52\udb45\udde9\ud9e8\udf93\ud8ce\udd6a\udbfc\uddc1\ud853\udcce\udad4\udc6f\udb69\udd51\u2594\ud97d\udd22\ud969\udda3\ud8c3\udd60\ud87d\uddc8\ud79f\udab4\udf2f\udb58\udc0f",
        23, 24339, 1648369749, 8121518231653330453L, -26290L, true, true, (char) 46588, (char) 43134,
        Double.longBitsToDouble(0x3fd9ef7780f7f34aL), Double.longBitsToDouble(0x3fc8e501ef369324L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Integer:1\012",
        Z.run(T, 1, 12, 11, 7, "\ud85a\ude14\udb73\udce4\uda8e\udda5\ud801\udf27", "\u03c3\u9f25\u5a61", "\udbb4\udc07\udb7d\udca6",
        -5, 84631, -2101191884, -5881138432789287520L, 1058L, true, false, (char) 46807, (char) 62658,
        Double.longBitsToDouble(0x3fe07ab057f18fe3L), Double.longBitsToDouble(0x3fd08ec79801e7f2L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 14, 11, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda25\udf60", "\u6427\u4537\u75f5\ubc25\ua987\ubcae\u0ca0\u027b\ua268\u0aac\u6b97\u516a\u85e5\u9330\u6adb\u7e83\u0742", "\uda28\udc52\udaed\udf18",
        -5, -28, 1809322855, -5840744766647993731L, -80510L, false, true, (char) 2738, (char) 27344,
        Double.longBitsToDouble(0x3fe7189f0f146031L), Double.longBitsToDouble(0x3fef12b95d43711cL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 7, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda25\udf60", "\u8163\u9f4f\u5a61\ubc25\u9e39\ube34\u9ce2\u7e40\ua268\u0aac\u6b97\u516a\u85e5\ud0b6\u6adb\u7e83\u0742", "\uda28\udc52\udaed\udf18",
        37, -859, 1809322855, -5840744763509012611L, -67710L, false, true, (char) 62865, (char) 29924,
        Double.longBitsToDouble(0x3fea499b39d9d282L), Double.longBitsToDouble(0x3fe4804385e0c6b5L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 7, 14, 7, "\ud85a\ude14\ud94f\udc3f\udbe4\udcdb\000", "\u8163", "\ud8ed\udeb4\uda7e\udd3d\udbb4\udc10\udb7d\udca6\udabc\uddf9\ud939\uddb7\uda32\ude61\ud96c\udf03",
        25, -1000, -1426063360, 8904813160233418012L, -39088L, true, true, (char) 13698, (char) 32076,
        Double.longBitsToDouble(0x3ea9800000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[31080.0]]\012",
        Z.run(T, 1, 11, 8, 7, "\uf300", "\u054c", "\ud848\uddac\ud9f1\udd30\udb2b\udc64\u383c\uda56\udc0a\udaf3\udf79",
        58, -1000, 0, 0L, -94313L, true, false, (char) 6607, (char) 14512,
        Double.longBitsToDouble(0x3fd78b6ef4217544L), Double.longBitsToDouble(0x3ec5600000000000L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Long:-6058599904172198899\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 5, 0, 11, "\ud8d4\udd80\udb1d\udfdf\udb3a\udca7\ud957\udca0", "\u2293\u48dc\u9457\u05d2\ubfaa\u7984", "\udbb1\udc5c\udb7c\udc18\ud928\udd82\udb95\udc71\ud8a6\udf0b\ud95b\udef7\ud960\ude10\udad2\udccd\ud87f\udd5e\ud9bc\udf0b\ud985\ude91\ud9e8\udf23\ud8fb\udd9e\ud9be\udfa4",
        29, 74427, -1359912150, -6058599904172193509L, -5390L, true, true, (char) 26729, (char) 23431,
        Double.longBitsToDouble(0x3fe26da4cdfdd2f5L), Double.longBitsToDouble(0x3fdbd79428d8bda4L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Double:2.308436973392454E71\0121=java.lang.Double:2.308436973392454E71\012",
        Z.run(T, 2, 17, 1, 7, "\ud966\udce9\udb1d\udc42\ud981\udc4b\udae7\udeb1", "\u62c2\u9eeb\u92da\u2449\uc804\uc8f5\ub24d\u2533", "\ud8ad\udd6e\udae6\udf59\ud8a6\udf7f\u9863\ud964\udc10\udad2\udccd\uda05\udd61\ud9bc\udf0b\ud984\udd91\ud9e8\udf23\udaed\udf3f\ud9af\udfe2",
        54, 25683, -1359912150, -6058599902880286949L, 60146L, false, false, (char) 25368, (char) 24301,
        Double.longBitsToDouble(0x3fd551983ad9a514L), Double.longBitsToDouble(0x3fdbd79428d8bda4L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Byte:-1\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 16, 14, "\ud84e\udf14\ud87a\ude33\ud870\uddbd\uda73\udd7a", "\u8163\u7c9e\u5f41\ub8db\u482d\u020f\u3fe0\u954a\ubae4\u0aac\u2795\u516a", "\ud963\udfac\udad2\udccd\ud99a\uddaa",
        -4, 46909, -201766648, -2723682360568106575L, 85475L, false, true, (char) 31669, (char) 8293,
        Double.longBitsToDouble(0x3fcaf6842a32fd60L), Double.longBitsToDouble(0x3fea499e464ae882L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 7, 16, 14, "\ud84e\udf14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u7c9e\u11a8\u2449\u9e39\ube34\ua60d\u17a3\ub7b9\u0aac\u2795\u7c65", "\ud963\udfac\udad2\udccd\uda05\uddc8\udb72\udd46\ud985\ude9e\uda28\udc52\udaed\udf18\ud9af\udfe2\ud8ce\udd6a\udbfc\uddc1\ud853\udcce\ud944\udfed\uda15\udc21\udba0\udc70\ud981\ude6c\uda31\udd07\ud8bd\udd99\uda5c\udde6\u34ab\udada\udd11\uda15\ude46\ud90f\udc91",
        8, -274, -644188295, 2689906702475446464L, -3364L, false, true, (char) 53803, (char) 55953,
        Double.longBitsToDouble(0x3fe92d7357831ca1L), Double.longBitsToDouble(0x3fe6c9f03e7e8a6eL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Double:3628800.0\0121=java.lang.Double:15.104412573075516\012",
        Z.run(T, 2, 17, 2, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8\udad6\udf0f", "\u250b\ubd2e\u2449\u9e39", "\ud9c0\udf13\ud939\uddb7\uda32\ude61\ud96c\udf03\uda32\uddca\u833c\ud95e\udc3e\ue5a8\udaa2\uded8\uda05\udd61\ud9bc\udf0b\ud985\ude88\uda28\udc52\udaed\udf18\ud9af\udfe2\ud8ce\udd6a",
        10, 59637, 810544429, -6813692920381445652L, 13609L, false, false, (char) 54540, (char) 33614,
        Double.longBitsToDouble(0x3fdcc4921e73c10eL), Double.longBitsToDouble(0x3fcba7f4735d1954L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8\u3200\uda21\udc46", "\ubd2e\u13ca\u9e39\ube34\u9ce2\u7e40\ua268\u0aac", "_\ud95e\udc3e\000",
        -1, 85288, 279646736, -1441073063813709824L, -47185L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3ece20652c000000L), Double.longBitsToDouble(0x3fd2f9b4db1d6000L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27669.0, 28402.0, 27791.5, 28167.5, 27974.0, 28636.0, 27937.5, 28348.0]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 16, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\ubff2\u2449\u9e39\ucf0e\u9ce2\u7e40\ua268\u82ac\u6b97\u516a", "\ud963\udfac\udad2\udccd\uda05\udd61\ud9bc\udf0b\ud985\ude88\uda28\udc52\udaed\udf18\ud9af\udfe2\ud8ce\udd6a\udbfc\uddc1\ud853\udcce\ud944\udfed\uda2b\udfd4\u9885\ud97d\udd22",
        -3, 76636, -394099895, -3261958212594690708L, 94142L, false, false, (char) 6768, (char) 2088,
        Double.longBitsToDouble(0x3fe2d38b49bc14e2L), Double.longBitsToDouble(0x3fe8cc523c90ffa1L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 8, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\ub059\u2449\u9e39\ucf0e\u9ce2\u7e40\ua268\u0aac\u6b97\u516a", "\udbb8\udea2\ud808\udf13\ud9f1\udf9b\ud818\udfc4\ud985\ude88\uda28\udc52\udadb\ude81\ud9af\udfe2\ud84f\udfe8\udbfc\udd66",
        22, 87837, 1347341081, 2918471241767219602L, -47338L, false, true, (char) 22370, (char) 26103,
        Double.longBitsToDouble(0x3fe303177704d36bL), Double.longBitsToDouble(0x3fec566cea5a71cdL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27795.0, 28606.0, 27791.5, 28216.0, 27969.0, 28636.0, 27937.5, 28348.0]] |a1=[D:[[16498.0, 20367.5, 2162.0]]\0121=java.lang.Boolean:false |a0=[D:[[27795.0, 28606.0, 27791.5, 28216.0, 27969.0, 28636.0, 27937.5, 28348.0]] |a1=[D:[[16498.0, 20367.5, 2162.0]]\012",
        Z.run(T, 2, 11, 11, 6, "\ud956\udfac\ud94f\udca0\udab2\udfe8\uda73\udda8", "\u8114\u9f4f\u1114", "\udbb4\udc10\udb7d\udca6",
        -5, 84631, -234005708, -9127378833523708624L, 55056L, false, true, (char) 55837, (char) 32756,
        Double.longBitsToDouble(0x3f90baa234a52760L), Double.longBitsToDouble(0x3f88380c74f2bd00L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 2, 4, "\ud85a\ude14\ud94f\udc3f\uda50\udd88\ud8ea\udf92", "\u7b83", "\000\uda7e\udd3d\ud9ca\udd85\udb6e\ude21\ud884\udf7e\ud874\udd79\uda32\ude61\ud96c\udf03\uda32\uddca\uda27\udcf4>\000\udb80\udea3\udba4\udc10\udb51\udc07\ud985\ude88\u4908",
        -5, -1000, -402292224, 7770982492075557269L, 83065L, false, false, (char) 39442, (char) 62865,
        Double.longBitsToDouble(0x3fe465fac34933c8L), Double.longBitsToDouble(0x3fd14e882ad9a576L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Integer:77792\012",
        Z.run(T, 1, 12, 14, 7, "\udbde\uded6\ud94f\udca5\udabc\udfe8\uda73\udda8", "\u8163\u11f2\ua29b\u2449\u9e39\ube34\u9ce2\u7e40\ua2684\u6b97\u5ed4", "\udb7a\udf40\udad2\udd3a\uda05\udd61\020\ud964\udf30",
        0, 77792, -514379343, -1727831033172716697L, -3613L, true, true, (char) 52848, (char) 39442,
        Double.longBitsToDouble(0x3fcaf69740000160L), Double.longBitsToDouble(0x3fe80000024ae882L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Integer:1\012",
        Z.run(T, 1, 12, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8\uda0b\udfe9\uda30\uddb5\udaba\udc05\ud9f1\udd30\udb62\udddf\ud8c7\uded8\uda7e\udd3d\udbb4\udc10\udb7d\udca6\udabc\uddf9\udabb\uddb8\ud823\ude64\ud96c\udf03\uda32\uddca", "\u2adb\u7e83\u0742\020\000\u12c7", "\ud8ce\udd6a\udbfc\uddc1\ud853\udcce\ud944\udfed\uda2b\udfd4\u9885\ud97d\udd22",
        -3, -1000, -394099968, -3261958210111597204L, -84975L, false, false, (char) 5961, (char) 48330,
        Double.longBitsToDouble(0x3fd730843aa6ecaeL), Double.longBitsToDouble(0x3feba531d6512b62L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Integer:2\012",
        Z.run(T, 1, 12, 14, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\u1114\u5a6e\u9dbb\ube34\u9ce2\u7e40\ua2684\u6b97\u7135", "\ud953\udfac\udad2\udccd\uda05\udd61\020\000\uda28\udc52\udad1\udd3d\ud9af\udfe2\ud8ce\udd6a\udbfc\uddc1\ud853\udcce\ud944\udfed",
        16, 81538, -1262849646, 24841090112684032L, -47338L, false, true, (char) 30495, (char) 33412,
        Double.longBitsToDouble(0x3fe15f6a38b75507L), Double.longBitsToDouble(0x3fea2aa5fd05b468L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Integer:4\012",
        Z.run(T, 1, 12, 14, 7, "\udb22\udc67\ud94f\udc3f\udb01\ude29\ud96b\udf03", "\u5c34\u9f4f\u1114\u2449\u60e4", "\ud8cc\udefa\ud939\uddb7\ud976\udeae\udaad\udc89\uda32\uddca\uda2c\udf09\ud95e\udc3e\ud857\ude39\ud824\ude4f",
        28, -984, 0, -6270900708050141059L, 63116L, false, true, (char) 9062, (char) 60799,
        Double.longBitsToDouble(0x3fe8ccf5ce22504eL), Double.longBitsToDouble(0x3fe6f14407dd2d39L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Integer:1\012",
        Z.run(T, 1, 12, 0, 7, "\ud85a\ude14\ud89c\udec6\udad3\udf96\uda73\udda8", "\u3faf\ua315\u1114\uab08\u8b4c\u9047\u9ca8\u7e40\ua2684\u19ff\u8ad1", "\ud953\udfac\udbc9\udc87\uda05\udd38\uda8a\udf34=\uda28\udc52\udac5\uddc2\ud9af\udfe2\ue9c4\uc25c\ud853\udc92\ud944\udfed\uda19\uded4",
        53, 53354, 745341544, -1558305315576643057L, -51297L, false, true, (char) 46012, (char) 3286,
        Double.longBitsToDouble(0x3feaa17e14debbf7L), Double.longBitsToDouble(0x3fd850ed77f5d9a4L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Long:0\012",
        Z.run(T, 1, 6, 4, 14, "\ud95a\uddd5\ud9d5\udcc1\ud822\uddf7\uda73\udd1d", "\uc543\u3130e\u60aa", "\udb7d\udca6\udabc\uddf9\ud939\uddb74\ud96c\udf03\uda32\uddca\uda2c\udf09\ud95e\udc3e\ud953\udfac\udad2\udd74\uda05\udd61",
        11, -1000, -201766648, -2738188572715523663L, -3613L, true, true, (char) 52848, (char) 39442,
        Double.longBitsToDouble(0x3fcaf69740000160L), Double.longBitsToDouble(0x3e4fcd4c48000000L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Integer:4\012",
        Z.run(T, 1, 12, 0, 0, "\u5a08\ud94f\udc3f\udabc\udfe8\uda73\udda8\uda0b\udfe9\uda30\uddb5\udafb\udc25\ud9dd\udd8d\udb58\udf3a\000\ud816\udd6a\udbb4\udc10\udb7d\udca6\udabc\uddf9\ue437", "\u516a\u8da5\u2a91\u7873\ubead\ua762\u3e78", "\udaed\udf18\ud9af\udfe2",
        12, -1000, -1359937536, 5427549473222819840L, -100000L, true, false, (char) 16868, (char) 46864,
        Double.longBitsToDouble(0x3fe25744106cd2bbL), Double.longBitsToDouble(0x3e48000000000000L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Integer:45\012",
        Z.run(T, 1, 12, 4, 8, "\ud877\uddc2", "\u8dd8\u9cb5\u911a\u8163\ub9f9\u439e\u7b5f\u9e18\u80df\000\000\u9e30\u7f81", "\uda2c\udf09",
        45, -900, 0, 7915629657430139648L, -15768L, true, true, (char) 15588, (char) 25643,
        Double.longBitsToDouble(0x3fe807402e956bd8L), Double.longBitsToDouble(0x3febed75293bd952L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[]] |a1=[D:[[6836.5]]\012",
        Z.run(T, 1, 11, 14, 0, "", "\u3599", "\ud815\udd6c\ud95c\udf08\000\000\000\000",
        27, -1000, 121, 1835740216857353012L, -100000L, false, false, (char) 0, (char) 43922,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e4ebc4000000000L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[D:[[]] |a1=[D:[[]]\012",
        Z.run(T, 1, 11, 14, 7, "", "", "",
        -5, -1000, -1289224192, 6789509808958204716L, -84256L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Integer:8\012",
        Z.run(T, 1, 12, 12, 7, "\ud85a\ude14\ud94f\udc3f\000\000", "\u8163\u9f4f\u1114\u2449\u9e39\ube34\u9ce2", "\uda32\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud95e\udc3e\ud963\udfac\udad2\udccd\uda05\udd61\ud9bc\udf0b",
        16, -1000, -634156800, 54635876646912L, -1291L, true, true, (char) 5739, (char) 52848,
        Double.longBitsToDouble(0x3fd9228801af6974L), Double.longBitsToDouble(0x3fe465fac34933c8L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 12, 12, 6, "\udbc9\udfb6\ud949\udf39\uda4a\udd2f\000\ud9a5\udd11\udbe9\udfb3\udaba\udc05\ud973\udffa\udb62\uddd4\ud8c7\uded8\uda7e\udd3d\udbb4\udc10\udb7d\udca6\udbd1\udf85\ud939\uddb7\uda32\ude61\ud96c\udf00\uda32\uddca\uda2c\udf09\ud95e\udc3e\ud964\udc01\ud952\udead\uda05\udd61\ud9bc\udf0b\ud985\ude88\uda28\udc62\udaed\udf18\u31b1\ud8ad\ude96\udbfc\uddc1\ud853\udcce\ud944\udfed\uda2b\udfd4\u9885\ud97d\udd22\uda31\udd07\ud8bd\udd99\udac4\ude9a\udb1f\uded6\ud973\uddcb", "\u7501\uaab4\u0b4c\u8fd0\u819c\u04b0\uca03", "\uda2b\uddff",
        21, 78158, -1465002923, -4042269895257306650L, 72851L, false, true, (char) 304, (char) 46440,
        Double.longBitsToDouble(0x3feb279722f9aa95L), Double.longBitsToDouble(0x3fe4f2505d9e4a6cL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Long:-690065053044394606\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 5, 10, 10, "\udbf1\ude9e\ud853\udd73\000\udbd9\udd6b\ud9f4\udcb7\uda30\uddb5\uda8c\udc0e\ud9f1\udd30\udb62\udddf\ud8c7\uded8\uda7e\udd3d\ud867\udc29\udb5f\udca6", "\ua474\u5f38\u6047\u85e5\ube1e\u6adb\u7e83", "\ud985\ude88\uda28\udc52\udaed\udf50\udabc\uddbb\ud8ad\ude96\ud843\udc65\ud853\udcce\ud871\udd9e\ud8be\udf0f\uda0c\udf2d\uda62\udf69",
        34, 14198, 2021186552, -690065053044416318L, 21712L, false, true, (char) 11598, (char) 14824,
        Double.longBitsToDouble(0x3fe60bab6621334eL), Double.longBitsToDouble(0x3fe88205bdf5e011L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 12, 12, 3, "\ud85a\ude14\ud94f\udc3f\000\000", "\u7080\u9ed3\u1114\u2449\u7dde\u248a\u9ce2", "\uda32\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud95e\udc3e\ud963\udfac\udad2\udccd\uda05\udd61\ud9f1\udce6",
        47, 30352, -634156717, 54635876646912L, -1291L, true, true, (char) 5739, (char) 52848,
        Double.longBitsToDouble(0x3fe7694400d78badL), Double.longBitsToDouble(0x3fe465fac34933c8L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Long:-4918918009764210907\0121=java.lang.Long:-4918918009764210907\012",
        Z.run(T, 2, 3, 3, 1, "\udab1\uddb6\udb6e\udd4b\uda91\ude5c\ud80e\udd55\uda0b\udfa2\uda30\uddb5\udaba\udc05\ud9f1\udd30\udb62\udddf\ud893\udf5e\uda7e\udd2e\udbb4\udc10", "\u5fa4\u0aac\u6b97", "\ud95e\udc3e\ud99c\ude91\udad2\udccd\uda05\udd61\uda0e\udfb4\ud985\ude88\uda28\udc52\udaed\udf18\ud9af\udfe2\ud8ce\udd6a\udbfc\udca2",
        16, 87837, 1347341081, -4918918009764286062L, 75155L, false, true, (char) 21420, (char) 51780,
        Double.longBitsToDouble(0x3fe43be23cd98ff0L), Double.longBitsToDouble(0x3fe5c5bb3e81dac0L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Long:-2209242456325259831\0121=java.lang.Long:-2209242456325259831\012",
        Z.run(T, 2, 3, 5, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8\uda0b\udfe9\uda30\uddb5\udaba\udc05\ud9f1\udd30\udb62\udddf", "\u46b3\u99c9", "\uda32\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud95e\udc3e\ud963\udfac\udad2\udccd\uda05\udd61\ud9bc\udf0b",
        47, 41936, -634156717, -2209242456325258540L, -1291L, true, true, (char) 5739, (char) 52848,
        Double.longBitsToDouble(0x3fd9272805af6974L), Double.longBitsToDouble(0x3fbb018f5a499d10L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Long:4681853585711941241\0121=java.lang.Long:4681853585711941241\012",
        Z.run(T, 2, 5, 5, 7, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\ud86f\udda6", "\u8163\u9f4f\u1114\u2449\u9e39\ube67\u9ce2\u7e40\ua268\u0aac\u6d12\u604f", "\udbea\ude6a\udad2\udd9c",
        13, 77736, -327596113, 4681853585711878125L, 63116L, true, true, (char) 60780, (char) 13934,
        Double.longBitsToDouble(0x3fe8ca5a9622504eL), Double.longBitsToDouble(0x3fd9228801af6974L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 12, 12, 11, "\ud9f7\uddb9\ud939\udec3\udbd1\ude32\uda51\udeb6\udbf7\udecb\ud8de\udcc3\uda84\udf86\uf8d6\ud923\ude6a\uda17\udf1c", "\ucf79", "\ud8b9\udee1\udad8\uded0\ud993\udd9b\uda2c\udf14\ud9a8\udf03\udb3e\udee4\ud899\udcd2\ud997\udcef\ud81b\udc9d",
        37, 81624, -634156717, -6006622466640346605L, -1355L, true, true, (char) 5911, (char) 52848,
        Double.longBitsToDouble(0x3fe531eff8d7b4baL), Double.longBitsToDouble(0x3fe465fac34933c8L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Byte:1\0121=java.lang.Byte:1\012",
        Z.run(T, 2, 15, 15, 9, "\udbb5\udf61\udaa4\udc9f\ud8f7\udc95\uda45\ude7b", "\u362e\u1982\u608e\u2449\u4d3a\ube34\ud050\u7e1f\ua268\u3f6a\u6b97\u516a", "\uda5e\udcfe\udae0\udeb7\uda05\udd98\ud85b\ude3a",
        47, 75216, 1935994437, 8382444085872788047L, 63435L, false, false, (char) 32132, (char) 61787,
        Double.longBitsToDouble(0x3fe60896b419a9ecL), Double.longBitsToDouble(0x3fe465fac34933c8L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Long:-5423897930246614985\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 6, 6, "\ud811\udca5", "\000\ubb80\u44ac\ubd55\u1adf\u8cbf\030\u017b\ube34\uaa8e?\u257e\u0aac", "\uda7a\udefd\000\udb85\udc01\ud801\udc63\udbf8\udf37\ud9bc\udf0b\ud985\uddd9\uda28\udc52\udb45\udde9\ud9e8\udf93\ud8ce\udd6a\000\000",
        -5, -1000, 679480064, -5423897930246635305L, 20320L, false, true, (char) 21717, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e18ca4000000000L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Integer:16\012",
        Z.run(T, 1, 12, 11, 7, "\uda42\udf75", "\u63bd\ub865\uad01\u03c3\u9f25\u5a61\ubc25\u5aaa\ube2b\u9ce2", "\uda12\udfd2\udaa0\udef1\uda32\uddca\uda2c\udf09\ud92a\udce4\udb97\uddd0\ud931\uddf8\uc588\uda6d\udf73",
        48, 30352, 1186696192, -1479115374061967391L, 95142L, true, true, (char) 39312, (char) 26363,
        Double.longBitsToDouble(0x3feafe25b20317d8L), Double.longBitsToDouble(0x3fe7eff45eee9f88L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 7, 14, 11, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda25\udf60", "\u6427\u4537\u2633\ubc25\ua987\u2e98\u0ca0\u027b\ua268\u0aac\u6b97\u516a\u85e5\u9330\u6adb\u1cca\u2d1a", "\uda28\udc52\udaed\udf18",
        37, -28, 1809322855, -5840744766865920414L, -75986L, true, true, (char) 2738, (char) 27344,
        Double.longBitsToDouble(0x3fe7189f0f146031L), Double.longBitsToDouble(0x3fef12b95d43711cL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 7, 14, 11, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda25\udf60", "\u6427\u4537\u75f5\ubc25\ua987\ubcae\u0ca0\u027b\ua268\u0aacO\000\u13e4\u9330\u6adb\u7e83\u0742", "\uda28\udc52\udaed\udf18",
        29, -28, 1809322855, -5840744766647993731L, -80510L, false, true, (char) 2738, (char) 27344,
        Double.longBitsToDouble(0x3fcc627c3c5180c4L), Double.longBitsToDouble(0x3fcc4ae5750dc400L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Double:3.6576848168E10\012",
        Z.run(T, 1, 7, 14, 11, "\udacc\udc6d\ud94f\udcca\udabc\udfe8\uda25\udf60", "\u6427\u4537\u75f5\ubc25\ua987\ubcae\u5ba0\u027b\ua268\u0aac\u6b97\u2275\ua3dc\u4d48\u6adb\u7e83\u0742", "\ud97b\udf1b\udb96\udefb",
        43, 13, 1809322855, -5840744766647993731L, -80510L, false, true, (char) 2738, (char) 27344,
        Double.longBitsToDouble(0x3fe7189f0f146031L), Double.longBitsToDouble(0x3fef12b95d43711cL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 7, 14, 11, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda25\udf60", "\u6427\u4537\u6ccc\ubc25\ua987\ubcae\u0ca0\u027b\ua268\u0aac\u6b97\u516a\u85e5\u9330\u6adb\u7e83\u0742", "\uda28\udc52\udaed\udf18",
        38, -192, -103279769, 2947657999448387204L, -80510L, false, false, (char) 2800, (char) 27344,
        Double.longBitsToDouble(0x3fe7189f0f146031L), Double.longBitsToDouble(0x3fe2cf615d437bb6L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Double:6.2270208E9\0121=java.lang.Double:6.2270208E9\012",
        Z.run(T, 2, 17, 1, 7, "\ud966\udce9\udb1d\udc42\ud981\udc4b\udae7\udeb1", "\u62c2\u9eeb\u92da\u2449\u8767\uc8f5\ub24d\u2533", "\ud8ad\udd6e\udae6\udf59\ud8a6\udf7f\u9863\ud964\udc10\udad2\udccd",
        13, 77736, 87808291, -871652364838008454L, 63116L, true, true, (char) 15163, (char) 13934,
        Double.longBitsToDouble(0x3fe8dd5f5e98f89aL), Double.longBitsToDouble(0x3fd9228aa9c85f64L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Integer:368577508\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 2, 14, "\ud84e\udf14\ud87a\ude33\ud870\uddbd\uda73\udd7a", "\u8163\u7c9e\u5f41\ub8db\u482d\u98e7\u9237\u954a\ubae4\u0aac\u2795\u516a", "\ud963\udfac\udad2\udccd\ud99a\uddaa",
        -4, 46909, -201766648, -2723682360568106575L, -15901L, false, true, (char) 31669, (char) 8293,
        Double.longBitsToDouble(0x3fcaf6842a32fd60L), Double.longBitsToDouble(0x3fea499e464ae882L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27669.0, 28402.0, 27791.5, 28167.5, 27974.0, 28636.0, 27937.5, 28348.0]] |a1=[D:[[3952.0, 21068.0, 18039.0, 4620.5, 20228.5, 26479.0, 14131.5, 15226.0]]\0121=java.lang.Boolean:false |a0=[D:[[27669.0, 28402.0, 27791.5, 28167.5, 27974.0, 28636.0, 27937.5, 28348.0]] |a1=[D:[[3952.0, 21068.0, 18039.0, 4620.5, 20228.5, 26479.0, 14131.5, 15226.0]]\012",
        Z.run(T, 2, 11, 11, 16, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8\uda73\udda8", "\u1f10\ua4c8\u8d1e\u2449\u9e39\ucf0e\u6e97\u7724\u02b0\u5214\u6bc5\u7d7e", "\uda90\uddaf\udb70\udfa2\uda05\udd61\ud9bc\udf0b",
        47, 30352, -633396397, -2209242456325258540L, -1291L, true, true, (char) 5739, (char) 52848,
        Double.longBitsToDouble(0x3fd922880d10b1f2L), Double.longBitsToDouble(0x3fe05e0c03493357L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27669.0, 28402.0, 27933.0, 28293.0, 27967.5, 28400.0, 27750.5, 28581.5]]\0121=java.lang.Boolean:false |a0=[D:[[27669.0, 28402.0, 27933.0, 28293.0, 27967.5, 28400.0, 27750.5, 28581.5]]\012",
        Z.run(T, 2, 11, 11, 16, "\ud85a\ude14\uda6a\udd3a\udaaf\ude10\ud8fd\udf7b", "\u398d\u81fe\ubff2\u2449\u9e39\ucf0e\u196d\u5af4\ua268\uc8f8\u0229\u5092", "\ud926\udd70\udae0\udd47\uda05\udd61\ud9bc\udf0b\udb31\udf3f\udb79\uddfa\uda9e\udc43\ud9c9\udfd6\ud8ce\udd6a\udbfc\uddc1\ud853\udcce\ud944\udfed\uda2b\udfd4\ud84f\uddd7\udb91\udecc",
        41, 54688, 546065541, -1610064770751400338L, 90455L, false, false, (char) 6692, (char) 2139,
        Double.longBitsToDouble(0x3fe2d38b49bc14e2L), Double.longBitsToDouble(0x3fe8cc523c90ffa1L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Integer:5\0121=java.lang.Integer:5\012",
        Z.run(T, 2, 12, 12, 4, "\ud85a\ude14\ud94f\udc3f\uda50\udd88\ud8ea\udf92", "\u7b83", "\000\uda7e\udd3d\ud96a\udf1d\udb6e\ude21\ud884\udf7e\ud874\udd79\uda32\ude61\ud96c\udf03\uda32\uddca\uda27\udcf4>\000\udb80\udea3\udba4\udc10\udb51\udc07\ud985\ude88\u4908",
        -5, -1000, -402292224, 7770982492075557269L, 83065L, false, false, (char) 39442, (char) 62865,
        Double.longBitsToDouble(0x3fe465fac34933c8L), Double.longBitsToDouble(0x3fd14e882ad9a576L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Integer:77792\0121=java.lang.Integer:77792\012",
        Z.run(T, 2, 12, 12, 5, "\udbde\uded6\ud94f\udca5\udabc\udfe8\uda73\udda8", "\u84f8\u11f2\ua29b\u2449\u9e39\ube34\u9ce2\u0807\ua2684\u6b97\u5ed4", "\ud9de\udc84\udad2\udcf3\uda05\udd61\020\ud964\udf30",
        0, 77792, -514379343, -1727831033172716697L, -3613L, true, true, (char) 47731, (char) 39442,
        Double.longBitsToDouble(0x3fcaf69740000160L), Double.longBitsToDouble(0x3fe80000024ae882L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Integer:1\012",
        Z.run(T, 1, 12, 0, 7, "\ud85a\ude14\ud89c\udec6\udad3\udf96\uda73\udda8", "\u3faf\ua315\u1114\uab08\u8b4c\u9047\u9ca8\u6f3d\u45b1", "\udb2c\udca9",
        46, -151, 2073296996, 9074679700967835983L, 73541L, false, true, (char) 62452, (char) 2994,
        Double.longBitsToDouble(0x3fe90f0ab867e8deL), Double.longBitsToDouble(0x3fe2cccbb7129e63L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[D:[[-24.0]] |a1=[D:[[-24.0]]\012",
        Z.run(T, 1, 11, 14, 7, "\000", "\000", "",
        46, 38187, 121985334, -6923527489601339224L, -84256L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe8e7406dd19e1fL), Double.longBitsToDouble(0x3eb4c00000000000L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[-24.0, -24.0, -24.0, -24.0, -24.0, -24.0, 27968.0, 28580.0]] |a1=[D:[[-24.0, -24.0, -24.0, -24.0, -24.0, -24.0, 17383.0, 4617.5]]\012",
        Z.run(T, 1, 11, 15, 4, "\000\000\000\000\000\000\udab0\udf78\udbdc\udcfa\ud976\ude77\udbcb\udcc1\u3275", "\000\000\000\000\000\000\u87fe\u2443\u928b\uc51f\u23b2\u24d9\uc8ca\u87d0", "\ud9e8\udde9\uda70\uddd0\u738e\uda2f\ude9c\ua20e\ud9f3\ude23\ud8cd\udf81\ud8f8\ude3f\ud9fa\udef8\uda72\udd29\ua83f\udad6\udc89\ud820\udf08\ud896\uddad\ud8c3\uddca\udbd6\udf44\udb68\udf39\ud9a0\ude70",
        2, 94881, 1874082565, -7168164177013331784L, -20155L, false, false, (char) 4993, (char) 29634,
        Double.longBitsToDouble(0x3fea3db7c81f4d7eL), Double.longBitsToDouble(0x3feebaef8934d88cL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.Integer:8\0121=java.lang.Integer:8\012",
        Z.run(T, 2, 12, 12, 7, "\ud85a\ude14\ud94f\udc3f\000\000", "\u8163\u9f4f\u1114\u2449\u9e39\ube34\u9ce2", "\uda32\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud95e\udc3e\ud963\udfac\udad2\udccd\uda05\udd61\ud9bc\udf0b",
        16, -1000, -634156800, 54635876646912L, -1291L, true, true, (char) 5739, (char) 52848,
        Double.longBitsToDouble(0x3fd9228801af6974L), Double.longBitsToDouble(0x3fe465fac34933c8L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Long:-5423897930246614985\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 7, 6, "\ud811\udca5", "\000\ubb80\u44ac\ubd55\u1adf\uaec9\u7e50\u017b\ube34\uaa8e?\u257e\u0aac", "\uda7a\udefd\000\udbb1\udd01\ud801\udc63\udbc3\udd8e\ud9bc\udf0b\ud985\uddd9\uda28\udc52\udb45\udde9\ud9e8\udf93\ud8ce\udd6a\000\000",
        -5, -1000, 679480064, -5423897930246635305L, 20320L, false, true, (char) 23892, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e18ca4000000000L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Byte:-1\0121=java.lang.Byte:-1\012",
        Z.run(T, 2, 15, 15, 6, "\ud811\udca5", "\000\ubb80\u44ac\ubd55\u1adf\u436f\030\u017b\uce16\u35f9?\u257e\u0aac", "\uda7a\udefd\000\udb85\udc01\ud801\udc63\udbf8\udf37\ud9bc\udf0b\ud985\uddd9\uda28\udc52\udb45\udde9\ud9e8\udf93\ud8ce\udd6a\u00e6\000",
        -5, -1000, 679480064, -5423897930246635305L, 20320L, false, true, (char) 21717, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e18ca4000000000L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.Integer:5517\0121=java.lang.Integer:5517\012",
        Z.run(T, 2, 4, 4, 10, "\ud84e\udf14\ud87a\ude33\ud870\uddbd\uda73\udd7a\uda0b\udfe9\ud874\uddd1\ud9a6\udcd9\udbc4\udec2\udbf2\udd7c\ud951\udc59", "\u9237\u954a\ubae4\u0aac\u2795\u516a\u9369\u52e7", "\ud99a\uddaa\udb72\udd46\ud985\ude9e\uda4c\udd1a\udaed\udf18\ud9af\udfe2\ud8ce\udd6a\udbfc\uddc1\ud853\udcce\uda22\ude17\uda15\udc21\udbc8\udc24\uda93\udf3c\uda31\udd07\ud8bd\udd99\uda5c\udde6\u4ae3\uda2b\uded8\udac7\udef7\ud9b8\udc6b\udba8\uded3\ud886\udf9d",
        42, 5475, 351441693, -6584690730762478470L, -96554L, false, true, (char) 4562, (char) 9333,
        Double.longBitsToDouble(0x3fe69187e0d0b5a0L), Double.longBitsToDouble(0x3fdc11a61be1166cL)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 10, 5, "\udbde\uded6\udb10\udf9a\udabc\udfe8\uda9e\udfbb", "\u84f8\u11f2", "\uda7e\udd3d\udbb4\udc10\udb7d\udca6\ud916\udee7\ud939\uddb74\ud96c\udf03",
        5, 67003, -500271810, -5122566723040461502L, 65811L, true, true, (char) 47731, (char) 39442,
        Double.longBitsToDouble(0x3fe1f0bdd6b6e5ddL), Double.longBitsToDouble(0x3fe80000024ae882L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[D:[[-24.0, -24.0]] |a1=[D:[[-24.0, -24.0]]\012",
        Z.run(T, 1, 11, 14, 13, "\000\000", "\000\000", "\udab2\udda3\ud998\udec4\ud8c7\udc4a\ud8af\udcc7\uda08\ude8b\000\ud8c4\udfde\udaad\ude96\ud956\udd57\udb91\uddd5\000\ud93e\ude1e\ud9b8\udd81\ud9f1\udf55\ud8e4\udcd1\udad6\udec1\udbc4\udec4\udbfd\ude28\udb9d\ude4d\udbce\udc73\udabc\udde0\ud89e\udd94\ud831\udedc\udaa3\udec9\ud885\udc14\ud8e3\udeec\udbf2\udd8b\uda6b\ude0d\uda7c\udca5\uda9e\udfb5\ud803\udf93",
        20, 19738, -2096130989, -4885002737695096999L, 60538L, false, true, (char) 7760, (char) 16745,
        Double.longBitsToDouble(0x3fd11d5c528e00e6L), Double.longBitsToDouble(0x3fd07872a715e67aL)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.Integer:16\0121=java.lang.Integer:16\012",
        Z.run(T, 2, 12, 12, 7, "\ud85a\ude14\ud94f\udc3f\000\000", "\u8163\u9f4f\u1114\u2449\ub96c\ua874\u9ce2", "\uda69\udfdc\udaed\ude02\ud8e6\udf4b\uda3d\udee2\udb30\udef2\ud963\udfac\udae2\udcdd\ud8b1\udf8a\ud9bc\udfdd",
        16, 77568, -634129368, 522753667642313663L, -1291L, true, true, (char) 5739, (char) 52848,
        Double.longBitsToDouble(0x3fd9228801af6974L), Double.longBitsToDouble(0x3fe465fac3f327c8L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=java.lang.Double:NaN\012",
        Z.run(T, 2, 6, 7, 10, "\ud8d8\udd75\ud819\udda0\u91b5\000\udb72\udc21\uda2d\ude77", "\uaec9", "\udb5b\udd00",
        6, -937, 429596453, -1005046862847029580L, -100000L, false, false, (char) 45311, (char) 16483,
        Double.longBitsToDouble(0x3fd5e0000420067cL), Double.longBitsToDouble(0x3fe800855908ec79L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.Long:8581140330773487907\012",
        Z.run(T, 1, 3, 14, 7, "\ud85a\ude14\ud811\udff3\udabc\udfe8\uda73\udda8", "\u8163\u9f4f\u1114\u7d7b\u9e39\ube34\u9ce2\u7e40\ua268\u0aac\u6b97\u516a", "\ud90b\udc0f\udad2\udcb1\uda05\udd61\uda11\udc75\ud99b\udd16\uda28\udc52\udaed\udf18\ud8d8\ude56\ud8ce\udd6a\ud8c9\udc49\ud918\udc9c\ud9fe\udf9a\uda2b\udfd4\u9885\ud97d\udd22\udb07\udeb1\ud8bd\udd99\uda5c\udde6",
        20, 5132, 2045657816, 8581140330773484843L, 3064L, true, false, (char) 54304, (char) 49915,
        Double.longBitsToDouble(0x3fdc323173385bcaL), Double.longBitsToDouble(0x3fd20ba4d398ff94L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=java.lang.Double:NaN\012",
        Z.run(T, 2, 6, 7, 9, "\udaf9\udd24\ud867\udf40\ud95a\udd8c\ud8ea\udf9c", "\u7b83", "\udbe3\udcc6\uda7e\udd3d\ud9ca\udd85\udad1\udd52\ud874\udf96\u1924\u8d06\ud96c\udf03\uda32\uddca\uda13\uddf4>\udb51\udca7\ud9b4\udf04\udba8\udf10\udb51\udc07\ud985\ude88\u4908",
        32, -1000, -402292224, 7770982492075360661L, -26239L, false, false, (char) 39442, (char) 62865,
        Double.longBitsToDouble(0x3fe465fac34933c8L), Double.longBitsToDouble(0x3fdbd1f82ad9a48aL)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=java.lang.Long:0\012",
        Z.run(T, 2, 6, 6, 2, "\uda40\udc39\ud8d3\udc64\uda50\uddba\ud8ea\udf92", "\u7b83", "\000\uda7e\udd3d\ud9ca\udd85\udb6e\ude21\ud884\udf7e\ud874\udd79\ud861\ude38\udaf4\udce6\ud963\ude74\uda27\udcf4>\000\udb80\udea3\udba4\udc10\udb51\udc07\ud985\ude88\udbac\udeb4",
        25, -1000, -402292224, 7770982492075557269L, -20921L, false, false, (char) 39442, (char) 62865,
        Double.longBitsToDouble(0x3fe465fac34933c8L), Double.longBitsToDouble(0x3fd14e882ad9a576L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[D:[[]] |a1=[D:[[]]\0121=java.lang.Boolean:true |a0=[D:[[]] |a1=[D:[[]]\012",
        Z.run(T, 2, 11, 11, 0, "", "", "\ud828\uded8",
        48, 60764, 1577058304, -1586415869902505924L, -99851L, false, false, (char) 32828, (char) 28247,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e48000000000000L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.Double:39.339884187199495\0121=java.lang.Double:39.339884187199495\012",
        Z.run(T, 2, 2, 2, 4, "\ud85a\ude14\ud862\udc47\ud861\udf67\ud8ea\udf92\ud83f\ude2c\ud9d8\ude24", "]\000\ube39\u3852\uacbc\uace0\u5401\u0ad5\u817d\u9ba4\u6dff>\u97b4", "\ud86d\udc2f\ud8ab\udf36\udba9\udd2a\000\000\ud8ce\udc96\ud973\udffd\uda87\udff5",
        19, 81, 679509538, -5423897930419912489L, 91124L, false, false, (char) 20476, (char) 7244,
        Double.longBitsToDouble(0x3feb5053c220efd8L), Double.longBitsToDouble(0x3fc9ed520080bb28L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Integer:41\012",
        Z.run(T, 1, 12, 2, 9, "\000", "\ub844", "\ud8d2\udcec\ud950\udea1\udaa2\uddae\udb41\ude5e\uda10\uddce",
        41, 1312, 1319084544, 5482922580159240989L, -82623L, false, true, (char) 19128, (char) 39150,
        Double.longBitsToDouble(0x3fdc416a0facd332L), Double.longBitsToDouble(0x3fe397e4fe853a88L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.Double:77520.0\012",
        Z.run(T, 1, 7, 14, 11, "\udacc\udc6d\ud94f\udcca\udabc\udfe8\uda25\udf60", "\u6427\u4537\u75f5\ubc25\ua987\ubcae\u5ba0\u027b\ua268\u0aac\u6b97\u2275\ua3dc\u4d48\u6adb\u7e83\u0742", "\ud97b\udf1b\ud94c\udc9d",
        20, 13, 1809322855, -5840744766647993731L, -80510L, false, true, (char) 2738, (char) 27344,
        Double.longBitsToDouble(0x3fe7189f0d2d5231L), Double.longBitsToDouble(0x3fef12b95afad4a8L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27669.0, 28402.0, 27791.5, 28167.5, 27974.0, 28636.0]] |a1=[D:[[16804.0, 16574.5, 21258.0, 3059.5, 21034.5, 20228.5]]\0121=java.lang.Double:4.04305126783455\012",
        Z.run(T, 2, 11, 8, 3, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8", "\u8378\u81ad\ua644\u1817\ua485\u9e39", "\udabc\uddf9\ud939\uddb7\uda32\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud855\udefa\ud963\udfdb\udad2\udccd\uda05\udd61\020\ud985\uddd9\uda28\udc52\udaed\udf18\ud858\uddb6\000\000\udb94\udf2a",
        57, 56, 679509538, -5423897930419882844L, 64681L, false, false, (char) 5376, (char) 34026,
        Double.longBitsToDouble(0x3fe941acd50c7735L), Double.longBitsToDouble(0x3fe4bcf3c141ae6aL)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.Long:43758\012",
        Z.run(T, 1, 6, 14, 7, "\udaa3\udf4d\ud9c9\udf0f\udabc\udf3b\ud816\udfa9\udadb\udc51", "\uac4f\u1114\u2449\u9e39\u24ba\u9ce2\u8468\ua268\u7480\u6bd7\u516a\u85e5\ud0b6\u6adb\u07b4\u2595", "\uda28\udc52\udb68\udf16",
        18, 10, 1809322855, 1502737848235362173L, -92089L, false, true, (char) 39795, (char) 16837,
        Double.longBitsToDouble(0x3fea499e424ae882L), Double.longBitsToDouble(0x3fd6cd2bbe9d2adcL)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.Double:57.0\0121=java.lang.Double:4.04305126783455\012",
        Z.run(T, 2, 7, 8, 3, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8", "\u8378\u7d68\u8313\u9feb\ua485\u9e39", "\udabc\uddf9\ud939\uddb7\uda32\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud855\udefa\ud963\udfdb\udad2\udccd\uda05\udd61\020\ud985\uddd9\uda28\udc52\udaed\udf18\ud858\uddb6\000\000\udb94\udf2a",
        57, 56, 679509538, -5423897930419882844L, 64681L, false, false, (char) 5376, (char) 34026,
        Double.longBitsToDouble(0x3fe941acd50c7735L), Double.longBitsToDouble(0x3fe4bcf3c141ae6aL)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27669.0, 28402.0, 27791.5, 28167.5, 27974.0, 28636.0]] |a1=[D:[[-24.0, 2668.5, 21258.0, 3059.5, 21034.5, 20228.5]]\0121=java.lang.Long:57\012",
        Z.run(T, 2, 11, 6, 3, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8", "\000\u1509\ua644\u1817\ua485\u9e39", "\udabc\uddf9\ud887\udc3e\000\000\000\uda10\udd08\ud855\udefa\ud963\udfdb\udad2\udccd\uda05\udd61\020\ud985\uddd9\uda28\udc52S\ud858\udd05\000\000\udb94\udf2a",
        57, 56, 679509538, -5423897930419882844L, 64681L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe941acd50c7735L), Double.longBitsToDouble(0x3fe4bcf3c141ae6aL)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27669.0, 28402.0, 27773.5, 28263.5, 27945.5, 28141.0]] |a1=[D:[[5330.0, 16574.5, 21258.0, 3059.5, 21034.5, 58.5]]\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 11, 8, 3, "\ud85a\ude14\ud92b\udcff\uda83\udc0a", "\u29d4\u81ad\ua644\u1817\ua485\u00a5", "\udabc\uddf9\ud939\uddb7\uda32\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud855\udefa\ud963\udfdb\udad2\udccd\uda05\udd61\020\ud985\uddd9\uda28\udc52\udaed\udf18\ud858\uddb6\000\000\ud9a6\udd73",
        56, 56, 681803298, -5423897930419882844L, -2537L, false, false, (char) 5376, (char) 34026,
        Double.longBitsToDouble(0x3fe941acd50c7735L), Double.longBitsToDouble(0x3fe4bcf3c141ae6aL)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.lang.Long:57\0121=java.lang.Long:57\012",
        Z.run(T, 2, 6, 6, 3, "\ud85a\ude14\ud94f\udc3f\udabc\udfe8", "\000\u1509\ua644\u1817\ua485\u9e39", "\udabc\uddf9\ud887\udc3e\000\000\000\uda10\udd08\ud855\udefa\ud963\udfdb\udad2\udccd\uda05\udd61\020\ud985\uddd9\uda28\udc52S\ud858\udd05\000\000\udb94\udf2a",
        57, 56, 679509538, -5423897930419882844L, -99927L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe941acd50c7735L), Double.longBitsToDouble(0x3fe4bcf3c141ae6aL)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 7, 8, 3, "\ud85a\ude14\ud92b\udcff\uda83\udc0a", "\u29d4\u81ad\ua644\u1817\ua485\u2aaa", "\udabc\uddf9\ud939\uddb7\uda32\ude61\ud96c\udf03\uda32\uddca\udb86\udf95\ud855\udefa\ud963\udfdb\udad2\udccd\ud9f2\udd61\020\ud985\uddd9\uda48\udc06\udae8\uded8\ud858\uddd2\000\000\ud81a\udfed",
        56, 56, 681803298, -5446128956021885788L, -2537L, false, false, (char) 5376, (char) 34026,
        Double.longBitsToDouble(0x3fe941acd50cee35L), Double.longBitsToDouble(0x3fe4bcf3c141ae6aL)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=java.lang.Long:1\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 6, 8, 3, "\ud85a\ude14\ud92b\udcff\uda83\udc0a", "\ua137\u81ad\ua644\u1817\ua485\u00a5", "\udabc\uddf9\uda05\uddbd\uda32\ude61\ud96c\udf03\uda32\uddca\udb60\ude29\ud855\udefa\ud905\udfcc\udad2\udcb4\uda05\udd61\020\ud985\uddd9\uda28\udc52\udaed\udf18\ud9c3\udf6d\ud936\ude1b\u00c2\ud9a6\udd73",
        56, 56, 681803298, -5423898175233018716L, -30651L, false, false, (char) 25088, (char) 34026,
        Double.longBitsToDouble(0x3fe941acd50c7735L), Double.longBitsToDouble(0x3fe4bcf3c141ae6aL)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27669.0, 28402.0, 27773.5, 28263.5, 27945.5, 28141.0]] |a1=[D:[[5330.0, 16574.5, 21258.0, 3059.5, 21034.5, 58.5]]\0121=java.lang.Double:7.410347097821024\012",
        Z.run(T, 2, 11, 8, 3, "\ud85a\ude14\ud92b\udcff\uda83\udc0a", "\u29d4\u81ad\ua644\u1817\ua485\u00a5", "\udabc\uddf9\ud939\uddb7\uda32\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud855\udefa\ud963\udfdb\udad2\udccd\uda05\udd61\020\ud985\uddd9\uda28\udc52\udaed\udf18\ud858\uddb6\000\000\ud9a6\udd73",
        58, 56, 681803298, -5423897930419882844L, -2537L, false, false, (char) 5376, (char) 34026,
        Double.longBitsToDouble(0x3fe941acd50c7735L), Double.longBitsToDouble(0x3fe4bcf3c141ae6aL)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=java.lang.Long:1\0121=java.lang.Long:1\012",
        Z.run(T, 2, 6, 6, 3, "\ud85a\ude14\ud92b\udcff\uda83\udc0a", "\ua137\u6ca4\u56a1\u1817\ua485\u00a5", "\udabc\uddf9\ud874\uddb0\uda32\ude61\ud96c\udf03\uda32\uddca\ud86a\udd2d\000\000\000\000\000\ud985\uddd9\uda28\udc52\udaed\udf18\ud9c3\udf6d\ud936\ude1b\u00c2\ud9a6\udd73",
        56, 56, 681803298, -5423898175233018716L, -30651L, false, false, (char) 25088, (char) 81,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 12, 12, 11, "\ud9f7\uddb9\ud939\udec3\udbd1\ude32\uda51\udeb6\udbf7\udecb\ud8de\udcc3\uda84\udf86\ud8ee\udc4e\ud923\ude6a\uda17\udf1c", "\ucf79", "\ud8b9\udee1\udad8\uded0\ud993\udd9b\uda2c\udf14\ud9a8\udf03\udb3e\udee4\ud86f\uded2\ud997\udcef\ud81b\udc9d",
        37, 79144, 711952723, -6006407529296985581L, 83065L, false, false, (char) 55460, (char) 62865,
        Double.longBitsToDouble(0x3fe88dfac074dc42L), Double.longBitsToDouble(0x3fbc8ab082212a28L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.Long:1653\0121=java.lang.Double:7.410347097821024\012",
        Z.run(T, 2, 6, 8, 3, "\ud85a\ude14\ud92b\udcff\uda83\udc0a", "\ua137\u81ad\ua644\u1817\ua485\u00a5", "\udabc\uddf9\uda05\uddbd\uda32\ude61\ud96c\udf03\uda32\uddca\udb60\ude29\ud855\udefa\ud905\udfcc\udad2\udcb4\uda05\udd61\020\uda99\udf43\uda59\udcdd\udaed\udf18\ud9c3\udf6d\ud936\ude1b\u00c2\ud9bc\ude1b",
        58, 56, 681803298, -5423898175233018716L, -30651L, false, true, (char) 2996, (char) 34026,
        Double.longBitsToDouble(0x3fe941acd50c7735L), Double.longBitsToDouble(0x3fe4bcf3c141ae6aL)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=java.lang.Double:6188.0\012",
        Z.run(T, 1, 7, 14, 9, "\ud85a\ude14\ud911\udc40\udabc\udfe8\uda25\udf60", "\u6427\u4537\u75f5\ubc25\ua987\ub1b7\u15ff\u014b\ua7f9\u0efc\u6c24\u516a\u6ee5\u9330\u6adb\u7e83\u0742", "\uda28\udc52\udaed\udf18",
        17, 5, 1809322855, -5840744766647993731L, -80510L, false, true, (char) 679, (char) 64587,
        Double.longBitsToDouble(0x3fe7189f0f146031L), Double.longBitsToDouble(0x3fef12b95bb0711cL)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27669.0, 28402.0, 27773.5, 28263.5, 27945.5, 28141.0]] |a1=[D:[[5330.0, 16574.5, 298.0, 16944.0, 21034.5, 58.5]]\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 11, 8, 3, "\ud85a\ude14\ud92b\udcff\uda83\udc0a", "\u29d4\u81ad\u0284\u8490\ua485\u00a5", "\udabc\uddf9\ud939\uddb7\ud8f2\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud855\udefa\ud963\udfdb\udad2\udccd\uda05\udd61\020\ud985\uddd9\uda28\udc52\udaed\udf18\ud858\uddb6\000\000\ud9a6\udd73",
        56, 0, 681803298, -5423897930419882844L, -2537L, false, false, (char) 5376, (char) 34026,
        Double.longBitsToDouble(0x3fe941acd50c7735L), Double.longBitsToDouble(0x3fe4bcf3c141ae6aL)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 8, 8, 3, "\ud85a\ude14\ud92b\udcff\uda83\udc0a", "\u29d4\u81ad\u0284\u8490\ua485\u00a5", "\udabc\uddf9\ud939\uddb7\ud8f2\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud855\udefa\ud963\udfdb\udad2\udccd\uda05\udd61\020\ud985\uddd9\uda28\udc52\udaed\udf18\ud858\uddb6\000\000\ud9a6\udd73",
        56, 0, 681803298, -5423897930419882844L, -2537L, false, false, (char) 5376, (char) 10685,
        Double.longBitsToDouble(0x3fe941acd50c7735L), Double.longBitsToDouble(0x3fe4bcf3c141ae6aL)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27669.0, 28402.0, 27773.5, 28263.5, 5067.0]] |a1=[D:[[1304.0, 16543.0, 298.0, 16944.0, 21034.5, 58.5]]\0121=java.lang.Integer:56\012",
        Z.run(T, 2, 11, 12, 3, "\ud85a\ude14\ud92b\udcff\u27c6", "\u0a60\u816e\u0284\u8490\ua485\u00a5", "\udabc\uddf9\ud939\uddb7\ud8f2\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud855\udefa\uda1c\uddd8\udaca\udf6f\uda05\uddb0\udabf\udd4e\ud9c2\uddc2\uda16\udfc8\udaed\udf18\ud858\uddb6\000\000\ud9a6\udd73",
        56, 0, 681803298, -5423897930410989378L, -2537L, false, false, (char) 5376, (char) 34026,
        Double.longBitsToDouble(0x3fe941acd50c7735L), Double.longBitsToDouble(0x3fe4bcf3c141ae6aL)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=java.lang.Long:1\012",
        Z.run(T, 1, 6, 8, 3, "\ud85a\ude14\ud92b\udcff\uda83\udc0a", "\u29d4\u81ad\u0284\u8490\ua485\u00a5", "\udabc\uddf9\ud939\uddb7\ud8f2\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud855\udefa\ud963\udfdb\udad2\udccd\uda05\udd61\020\ud930\udfd7\udb37\ude46\udaed\udf96\ud858\uddb6\000\000\ud9a6\udd73",
        56, 0, 681803298, -5423897927728924764L, -2537L, false, false, (char) 5376, (char) 34026,
        Double.longBitsToDouble(0x3fe941acd50c7735L), Double.longBitsToDouble(0x3fe4bcf3c141ae6aL)));
  }
  @Test(timeout = 4000)
  public void test120() throws Throwable {
    assertEquals("0=java.lang.Long:1\0121=java.lang.Long:1\012",
        Z.run(T, 2, 6, 6, 0, "\ud85a\ude14\ud92b\udcff\uda83\udc0a", "\u29d4\u81ad\u0284\u8490\ua485\u00a5", "\udabc\uddf9\ud939\uddb7\ud8f2\ude61\ud96c\udf03\uda32\uddca\uda2c\udf09\ud855\udefa\ud963\udfdb\udad2\udccd\uda05\udd61\020\ud985\uddd9\uda28\udc52\udaed\udf18\ud858\uddb6\000\000\ud9a6\udd73",
        56, 0, 681803298, -5423897930419882844L, -2537L, false, false, (char) 5376, (char) 34026,
        Double.longBitsToDouble(0x3fe941acd50c7735L), Double.longBitsToDouble(0x3fe4bcf3c141ae6aL)));
  }
  @Test(timeout = 4000)
  public void test121() throws Throwable {
    assertEquals("0=java.lang.Integer:56\0121=java.lang.Integer:56\012",
        Z.run(T, 2, 12, 12, 3, "\ud85a\ude14\ud92b\udcff\u27c6", "\u0a60\u816e\u0284\u8490\ua485\u00a5", "\udabc\uddf9\ud939\uddb7\udbfe\ude56\ud96c\udec0\uda7f\udef2\ud928\udc1b\u50ec\uda13\uddb0\udaca\udf6f\uda05\uddb0\udabf\udd4e\ud9c2\uddc2\ud8b5\udef7\udaed\udf18\ud97d\udf29\udbbe\udf03\000\udb40\udd42",
        56, 0, 681803298, 884158607814322366L, -2537L, false, false, (char) 55339, (char) 34026,
        Double.longBitsToDouble(0x3fe941acd50c7735L), Double.longBitsToDouble(0x3fd979e782835d14L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.util.MathUtils|factorial|int|static",
    "M|org.apache.commons.math.util.MathUtils|factorialDouble|int|static",
    "M|org.apache.commons.math.util.MathUtils|factorialLog|int|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|long,long,java.lang.String|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|long,long|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficient|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficientDouble|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficientLog|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|cosh|double|static",
    "M|org.apache.commons.math.util.MathUtils|equals|double,double|static",
    "M|org.apache.commons.math.util.MathUtils|equals|[D,[D|static",
    "M|org.apache.commons.math.util.MathUtils|gcd|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|hash|double|static",
    "M|org.apache.commons.math.util.MathUtils|hash|[D|static",
    "M|org.apache.commons.math.util.MathUtils|indicator|byte|static",
    "M|org.apache.commons.math.util.MathUtils|factorial|int|static",
    "M|org.apache.commons.math.util.MathUtils|factorialDouble|int|static",
    "M|org.apache.commons.math.util.MathUtils|factorialLog|int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
