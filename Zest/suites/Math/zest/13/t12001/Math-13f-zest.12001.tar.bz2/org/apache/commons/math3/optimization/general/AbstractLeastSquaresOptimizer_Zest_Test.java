package org.apache.commons.math3.optimization.general;
import org.junit.Test;
import static org.junit.Assert.*;
public class AbstractLeastSquaresOptimizer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 9, "\ud9e4\ude1d\ud94e\udea2\ud830\ude3b", "\u05bc\ucbf4\u939e\u1ea3\u4757\uabd8\ucb13\u7fa8\ubf1b\u8acf\u0695\u4cb5\uc606", "\ud875\ude2f",
        55, 17818, 476904471, 4964147226961699101L, 61965L, false, true, (char) 5478, (char) 53496,
        Double.longBitsToDouble(0x3feb62160aa2b0f5L), Double.longBitsToDouble(0x3fe0ef4b12be5a31L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!org.apache.commons.math3.exception.NumberIsTooSmallException\012",
        Z.run(T, 2, 10, 12, 3, "\ud9e4\ude53\ud94e\udea2\udaea\ude38\ud9bf\udd89\ud898\ude67\ud928\udf02\uda3a\udf0a\ud984\udf19\udb13\udf94", "\u257d\u7fa8\uaece\u8acf\u0695\u4cb5\uc606\u83c2\u2ad0", "\ud8a3\udfbe",
        51, 61594, 197845277, -7693706102802465927L, 2138L, false, true, (char) 5478, (char) 53496,
        Double.longBitsToDouble(0x3feb62160aa2b0f5L), Double.longBitsToDouble(0x3fe0ef4b12be5a31L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 2, 10, "\ud9e4\ude1d\ud94e\udea2\udb7f\udcfe\ud8d9\udc95\udae3\uddcb", "\ub2a3\u1ea3\u4757\u2e8f\u5777\u57af\ua2c3\ua6f4\u2f9e\ucabf\u1ac4\u7fb5\u3d82\u9351\u8ca2\u871e\u0ca3\u739d\ud716\u3b32\u4ab3\u645a\u9702\ub4c0\ub697\u55f4\u7879\u6151\u5ee9\u87d4\u3d02\u4221", "\u26f0\udb2e\udebf\uda33\udc36\ud8c2\udf76\uda63\udd8a\ud8a2\udfd8\udb2d\udc78\udae1\udfd8\ud80b\udc05\uda68\udda1",
        30, 50382, -1819480824, 8320763708807024969L, 89396L, false, false, (char) 26320, (char) 27124,
        Double.longBitsToDouble(0x3fe3af8656d42c38L), Double.longBitsToDouble(0x3fe55af57f7dff99L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 5, 9, "\ud9e4\ude1d\ud94e\udea2\ud830\ude3b", "\u05bc\u00ea\000\u1684\u4757\uabd8\ucb13\u7fa8\ubf1b\u8acf\u0695\u4cb5\uc606", "\ud875\ude2f",
        55, 17818, 476904471, 4964147226961699101L, 61965L, false, false, (char) 5425, (char) 53496,
        Double.longBitsToDouble(0x3feb621608a2b0f5L), Double.longBitsToDouble(0x3e35f00000000000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 9, "\ud864\udebd", "\u1764\u39aa\uc71c\ucbf4\u939e\u1ea3\u3267\u3fd3\u14ed\u71cf\u66db\u8acf\u0695\u4b3a\u1786\u2e4f\u2ad0\ub57e", "\udb59\uddc3\ud92d\udda9\udb9c\uddce\ud8d8\udc53\ud827\udedd\ud96c\udc46\ud99f\udfb3\ud9ab\ude4b\ud875\udc98\ud848\ude4c\ud86c\ude81\ud839\ude22\uda05\udec3\udb4a\udd4c\udaa5\udf6d\uda8e\ude02\ud9c3\udcc2\ud998\uddb1\ud9b1\ude41\udbf0\udda9\ud84a\udf2a\udb49\udfe6\ud9e3\udff2\uda9a\udf77\ud87c\udfd7\udbcb\udcc3\ud95f\uddba\udbbd\ude04\ud841\udc05\uda16\udcda\udbc3\ude28\ud979\uddb9\uf30c\ud999\udd19\udb49\ude74\u4f43",
        23, 89113, 1523353463, 4566741924766446413L, 41621L, true, false, (char) 58660, (char) 62819,
        Double.longBitsToDouble(0x3fd07b58bfc14510L), Double.longBitsToDouble(0x3fc32f3cbbf69868L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.DimensionMismatchException\012",
        Z.run(T, 2, 14, 5, 9, "\ud9e4\ude1d\ud956\udda2\ud830\ude3b", "\u05bc\ucbf4\u6481\u7ef7\u0a99\u8baa\ucb56\u7fa8\ubf1b\u8acf\u0695\uab6a\uc606", "\ud875\ude2f",
        55, 17818, 476904471, 4964147226961699101L, 61965L, false, true, (char) 23654, (char) 22445,
        Double.longBitsToDouble(0x3feb67dd62a2b0f5L), Double.longBitsToDouble(0x3fe0ef4b12be5a31L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!org.apache.commons.math3.exception.DimensionMismatchException\012",
        Z.run(T, 2, 6, 13, 9, "\ud9e4\ude1d\ud94e\udea2\ud8c4\udd36", "\u75c5\u4ff0\u593f\u6b18\ud5e3\u14d3\ucb13\u584f\ubf1b\u8acf\u0695\u4cb5\uc606", "\ud897\udeb1\uda47\udfaf\ud8a3\udfbe",
        7, 52167, 197844617, -8383130744168105436L, 61965L, false, true, (char) 5478, (char) 53496,
        Double.longBitsToDouble(0x3feb62160aa2b0f5L), Double.longBitsToDouble(0x3fe0ef4b12be5a31L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 5, 9, "\ud9e4\ude1d\ud94e\udea2\ud830\ude3b", "\u05bc\u4310\u0168\u1f3b\u8101\uc806\ucb13\u7fa8\ubf1b\u8acf\u0695\u4cb5\uc606\u83c2\u2ad0\ub57e\u32e6\u7475\u9dc7\u7340\ud716\u211e\uc261\u445a\u8908\u92c2\u9c96\u1ef4\u6b5a\u6151\ua62e\u87d4\u3d02\u16d7\u0cca\u6ef4", "\ud932\udf31",
        33, 88677, -1609594067, -4266424484380279799L, 76003L, true, true, (char) 24973, (char) 46432,
        Double.longBitsToDouble(0x3fe9ceaba11be094L), Double.longBitsToDouble(0x3fd1c47db15df81aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 9, "\ud9e4\ude1d\ud958\udf20\ud830\ude3b", "\u05bc\ucbf4\ud004\u1ea3\u4757\u95ea\u140e\uc98b\ube7e\u8acf\u0695\u4cb5\uc606", "\ud944\udf97",
        3, 17818, 476904471, 4964147226952982813L, 61965L, false, true, (char) 5478, (char) 23301,
        Double.longBitsToDouble(0x3feb6216eaa2b0f5L), Double.longBitsToDouble(0x3fe0ef4b10928879L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=java.lang.Integer:0 |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 10, 9, 9, "\uda84\udef8\udafb\udd24\ud990\udea2", "\u05bc\ucbf4\u939e\u7361\u48a2\uabd8\ucb13\u7fa8\ubf1b\u8acf\u75a2\u0088\uc606", "\ud875\ude2f",
        55, 17818, 476904471, -3329231486841069283L, 61965L, false, true, (char) 51813, (char) 53320,
        Double.longBitsToDouble(0x3feb62160aa2b0f5L), Double.longBitsToDouble(0x3fe0ef4b13be5a31L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 10, "\udba4\udf47\udb3d\udd03\udbf0\udf6d", "\u0583\ucbf4\u939e\u1ea3\u4757\uabd8\ucb13\u7fa8\u411e\u8acf\u0695\u6852\uc606\u83c2\uaad0\u3543\uce23\ud3fc\u030f", "\udb51\udc25\ud8bd\udc3a\uda10\uddcd\ud873\ude79\ud8d1\udec0\ud875\udc98\udadd\ude93\ud8f0\uddb9\ud839\ude22\uda05\udec3\ud846\udd83\udaa5\udf6d\ud91c\udfaa\udab9\udfab\udb3b\udc43\ud9e4\udf1b\uda9b\udf3c\ud840\udd82\udb07\udfe8",
        16, 80178, 1293172010, 7524774022327127311L, -99906L, true, true, (char) 55095, (char) 30549,
        Double.longBitsToDouble(0x3feada685274b050L), Double.longBitsToDouble(0x3fe2608cb0bb464cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!org.apache.commons.math3.exception.DimensionMismatchException\012",
        Z.run(T, 2, 9, 14, 11, "\ud9d1\uded6\ud94e\udea2\ud830\ude3b\ud8d9\udc95\udae3\uddcb\ud930\ude8b\udacc\udc39\ud824\udd48\udbd4\udd48\ud81d\udd9b\ud845\udfcd\udabc\udda9\ud387", "\u0695\u4cb5\uc606\u83c2\u2ad0", "\ud8a3\udfbe",
        51, 61594, 1453177629, -8383130598139217372L, 61965L, false, true, (char) 5478, (char) 53496,
        Double.longBitsToDouble(0x3feb62160aa2b0f5L), Double.longBitsToDouble(0x3fe0ef4b12be5a31L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 9, "\ud9e4\ude1d\ud94e\udea2\ud830\ude3b", "\ub2c4\ucbf4\u939e\u1ea3\u4757\uabd8\ucb13\u7fa8\ubf1b\u8acf\u2895\u4cb5\uc606", "\ud875\ude2f",
        55, 57586, 476904542, 4964147226961699101L, 61965L, false, true, (char) 5478, (char) 53496,
        Double.longBitsToDouble(0x3feb62160aa2b0f5L), Double.longBitsToDouble(0x3fe0ef4b12be5a31L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 9, "\ud9e4\ude1d\ud94e\udea2\ud830\ude3b", "\u05bc\u5310\u939e\u1ea3\u4757\uabd8\ucb13\u7fa8\ubf1b\u8acf\u3812\u912f\uc606", "\ud875\ude2f",
        55, 17818, -1055589353, 4964339091740746013L, 61965L, false, true, (char) 5478, (char) 53496,
        Double.longBitsToDouble(0x3feb62160d77b0f5L), Double.longBitsToDouble(0x3fe3d74a02be5a31L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 5, "\ud9e4\ude1d\ud94e\udea2\ud830\ude3b\ud860\uddf9\uda99\ude5f\ud8f7\uddff\udacc\udc39\ud824\udd48\udae7\udff1\ud9a4\udf5d\ud845\udf9a\uda66\udd22\ud853\ude63", "\u5e86\ua04a\u7c25\u4560\ub3cd", "\ud8a3\udfbe",
        51, 24946, 197836888, 3362257082352522959L, -94963L, true, false, (char) 39213, (char) 61566,
        Double.longBitsToDouble(0x3fb3811fccb268d8L), Double.longBitsToDouble(0x3fe0ef4b12be5a31L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 12, 3, "\ud9e4\ude53\ud92c\udc62\udaea\ude38\ud9bf\udd89\ud898\ude67\ud928\udf02\uda3a\udf0a\ud984\udf19\udb13\udf94", "\u257d\u7fa8\uaece\u8acf\u0695\u4cb5\uc606\u83c2\u2ad0", "\ud8a3\udfbe",
        51, 61594, 197845277, -7693706102802465927L, 2138L, false, true, (char) 5478, (char) 41593,
        Double.longBitsToDouble(0x3fda30e6586ad8d0L), Double.longBitsToDouble(0x3febb3dd52be5ac7L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=java.lang.Double:NaN |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 10, 10, 3, "\ud9e4\ude53\ud94e\udea2\ud968\ude9e\ud9bf\udd89\ud898\ude67\ud928\udf02\uda3a\udf0a\ud984\udf19\udb13\udf94", "\u590b\u7f6c\uaece\u1779\u88ab\u4cae\uc606\u83c2\u2ad0", "\ud8a3\udfbe",
        49, 2201, 197845277, -7662506360852694151L, -87991L, true, false, (char) 7327, (char) 51093,
        Double.longBitsToDouble(0x3fccddd584cdb850L), Double.longBitsToDouble(0x3fb9113b429d8e78L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 15, 3, "\ud9a3\uddf2\ud94e\udea2\udaea\ude38\ud954\udc76\ud898\udeaf\ud928\udf02\uda3a\udf0a\udad2\udea0", "\uabd8\ubeac\uca26", "\udac7\udd3d\udb1e\udcc5\udacf\udca4\udabf\udebd\ud88d\udf31",
        25, 81138, -74327294, 2048289107416986010L, -27435L, true, true, (char) 20728, (char) 8095,
        Double.longBitsToDouble(0x3fed15d5f330aa35L), Double.longBitsToDouble(0x3fcb0dd8b89ee15cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 13, 2, 3, "\ud9e4\ude53\ud94e\udea2\udaea\ude38\ud9bf\udd89\ud898\ude67\ud91f\udc74\ud92d\udfa3\uda38\udd5f\udb13\udf87", "\u72e9\u7fa8\uaece\u8acf\u106d\u4c8d\uaf0e\u8442\u2ad0", "\udb0e\udf58\uda68\udfee\ud92e\udc40\udb9c\uddce\ud888\udcc5",
        -3, 28973, -603116120, -5865813509489397498L, 45577L, true, true, (char) 52433, (char) 33687,
        Double.longBitsToDouble(0x3f9eec6257cb4620L), Double.longBitsToDouble(0x3fe6b69d53097226L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 3, "\ud8cb\udef3\ud94e\udea2\udaea\ude38\ud9bf\udd89\ud898\ude67\ud928\udf02\uda3a\udf0a\ud984\udf19\udaa4\uddbf", "\u25af", "\uda7b\udf1c",
        45, 89012, 899479164, -1431921139057119146L, -677L, false, true, (char) 19958, (char) 23016,
        Double.longBitsToDouble(0x3fd1d4473c201794L), Double.longBitsToDouble(0x3f94843afc163d00L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 5, 10, "\ud9e4\ude53\uda72\udd74\udb0a\udded\ud9bf\udd89\uda8f\udcc2\ud928\udf02\uda3a\udf0a\ud833\udd71\ud8c7\udd83\udacf\udf53\ud845\udf7d\ud8a1\udca2", "\u8acf\u0695\u9a52\u5fd3\ua57c\u90d1\ub73a\u32e6\uc2e9\u5548\u7340\ud716", "\ud96c\udc46\udb7f\udea3\udad7\udf04\ud905\udea3",
        37, 56015, 395203089, -5695611880278951262L, -97250L, true, true, (char) 44944, (char) 49586,
        Double.longBitsToDouble(0x3fd93ef3cd4c1d34L), Double.longBitsToDouble(0x3fd637fb1f7de8f6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 8, 3, "\ud9e4\ude53\ud94e\udea2\udaea\ude38\ud9bf\udd89\ud898\ude67\ud928\udf02\uda3a\udf0a\ud984\udf19\udb13\udf94\ud851\ude83\ud845\udfcd\ud8a1\udca2\ud387\ud9e0\ude2c", "\u4cb5\uc606\u1e03\u834b\ub57e", "\udb59\uddc3\ud92d\udda9\udb9c\uddce\ud888\udcc5\ud816\udf7c\ud96c\udc46\udb7f\udea3\ud9da\udea8\uda73\uddde\udadd\ude93\ud86c\uddb7\uda5c\udd6d\udb19\udc9c\udb4a\udd4c\udaa5\udf6d\ud8d1\udd64\ud85f\udfb8\udbdd\udc18\udb5d\ude0a\ud9c0\udf99\udb28\udee7\udbf0\udf8e\ud87f\udd50\ud968\udf46\ud881\udccc\udadb\ude77\ud822\udd27\uda95\udf41\udabc\udd07\uda89\udc38\ud819\udc71\udb62\udd88\ud824\udcdd\ud9e2\udcae\udabb\udeea\ud830\udf3f",
        43, 2173, -1558961232, -6747405688200437002L, -90618L, true, true, (char) 49386, (char) 39068,
        Double.longBitsToDouble(0x3fe181450f894d30L), Double.longBitsToDouble(0x3fd368c14cd48cbcL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 7, 0, "\ud9e4\ude53\udb1e\udeaa\udaea\ude38\uda0d\udd08\uda67\udd20\ud928\udf70\uda3a\udf0a\ud984\udf19\udb17\udc94", "\u2609\u7fa8\uaece\u8acf\u0695\u4cb5\u060e\u83c2\u2ad0", "\ud8a3\udfbe",
        51, 52194, 197845277, -7693706104546694791L, -92352L, true, true, (char) 46281, (char) 38852,
        Double.longBitsToDouble(0x3fe3234a028e1616L), Double.longBitsToDouble(0x3feb62160aa2b0f5L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 12, 3, "\ud9e4\ude53\ud94e\udea2\udaea\ude38\ud9bf\udd89\ud898\ude67\ud928\udf02\udb86\udd0d\ud98b\udf61\udb13\udf94", "\u1d20\u7fa8\uaece\u9a82\ucaa9\u8d70\u199d\ud17c\u2ad0", "\ud8a3\udfc7",
        51, 16730, -213265016, 7438471411961059079L, 2138L, false, true, (char) 5478, (char) 53496,
        Double.longBitsToDouble(0x3feb62160aa2b0f5L), Double.longBitsToDouble(0x3fe0ef4b12be5a31L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 14, 3, "\ud9e4\ude53\ud94e\udea2\udaea\ude38\ud9bf\udd89\ud898\ude67\ud928\udf02\ud9fe\udf4c\ud984\udf19\udb13\udf94", "\u257d\u7fa8\uaece\u8acf\u0695\u4cb5\uc606\u83c2\u2ad0\ub57e\u32e6\u7475\u9dc7\u7340\ud716\u1884\uc3b6\u445a\u1d7b\u346f\uaef0", "\ud839\ude4f\uda05\udec3\udb4a\udd4c\ud905\udd1e\ud8ef\ude74\ud916\udf7a\ud99c\udf94\ud88c\udf5a\uce70\udb21\uddff\udbb7\udeb1\udb89\udcf8\uda38\ude2a\ud845\ude56\uda8c\udc48\udbf1\udf11\ud8c3\udffe\ud900\udfc9\udadd\udd09\udb91\udf7d\u972a\ud96d\ude72\udac7\udef5\uda84\udc17\udb6a\udf79\ud88e\udfff\uda3d\udc65\udb59\ude47\udb2d\udcab\ud808\udf9b\uda44\udd46\udb41\udc70",
        45, 44846, 1037306101, -1068883931746831969L, 96410L, false, true, (char) 48664, (char) 29563,
        Double.longBitsToDouble(0x3fe825f00c3274e7L), Double.longBitsToDouble(0x3fee4e3e8b560d94L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 15, 3, "\ud9e4\ude53\ud94e\udea2\udaea\ude38\ud9bf\udd89\ud898\ude67\ud928\udf02\uda3a\udf0a\ud984\udf19\udb64\udedd", "\u257d\u7fa8\uaece\u8acf\u0695\u4cb5\uc606\u83c2\u2ad0\ub57e\u32e6\u7475\u9dc7", "\ud850\udde9\ud816\udf2a\ud96c\udc46",
        -3, 3069, -1161924346, -6181775830620476624L, -11060L, false, false, (char) 25244, (char) 25839,
        Double.longBitsToDouble(0x3fe2129d25c8174aL), Double.longBitsToDouble(0x3fe2b16df7a9b87dL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 15, 10, "\ud9e4\ude1d\ud94e\udea2\udb7f\udcfe\ud8d9\udc95\udae3\uddcb", "\ub2a3\u1ea3\u4757\u2e8f\u85af\u577a\ua2c3\ua6f4\u2f9e\ucabf\u1ac4\u7fb5\u3d82\u9351\u8ca2\u871e\u0ca3\u739d\u9c6c\u3b87\u4ab3\u645a\u9702\ub4c0\ub697\u55f4\u7879\u6151\u5ee9\u87d4\u3d02\u4221", "\u26f0\udb2e\udebf\uda33\udc36\ud8c2\udf76\ud9b1\udcc5\ud8a4\ude0d\udb2d\udc78\u81fe\uda11\udd20\udacc\uddcf",
        16, 54574, -1819480824, 8320763708807024969L, 89396L, false, false, (char) 26320, (char) 27124,
        Double.longBitsToDouble(0x3fe3af8656d42c38L), Double.longBitsToDouble(0x3fe55af57f7dff99L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 2, 10, "\ud9e4\ude1d\ud94e\udea2\udb7f\udcfe\ud887\ude6f\udaf8\udd79", "\ub2a3\u1ea3\u4757\u2e8f\u5777\u57af\ua2c3\ua6f4\u2f9e\ucabf\u1ac4\u7fb5\u3d82\u9351\u8ca2", "\ud92d\ude06\udb9c\uddce\ud834\udc95\ud82e\ude78\udada\udddd\ud925\udc54\ud839\udc07\ud875\udc98\udadd\ude93\ud874\udfb7\ud839\ude22\uda33\udfd7\udb4c\udc00\udaa5\udf6d\udb6c\udd7c\ud901\udeae\uda5b\ude3d",
        37, 83307, 674550232, -7559712379340519590L, -47139L, true, false, (char) 23478, (char) 31839,
        Double.longBitsToDouble(0x3fca2d212df95300L), Double.longBitsToDouble(0x3fd0874695052718L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 9, "\ud864\udebd", "\u1764\u39aa\uc71c\ucbf4\u891b\uc164\u3267\u3fd3\ub95d\ubdb0\u66db\u4acf\u28fa\u2132\u1786\u2e4f\u2ad0\ub57e", "\ud9dd\ude45\udb89\uddad\udb9c\uddce\ud8d8\udc53\ud827\udedd\ud96c\udc46\ud99f\udfb3\ud9ab\ude4b\ud875\udc98\ub9ff\ud86c\ude81\ud839\ude22\uda05\udec3\udb4a\udd4c\uda52\udd89\udbbf\uddfb\ud9c3\udcc2\ud998\uddb1\ud9b1\ude41\udbf0\udda9\ud84a\udf2a\udb9f\ude11\ud9e3\udff2\uda9a\udf77\ud87c\udfd7\udbcb\udcc3\ud95f\uddba\udbbd\ude04\ud8d1\udc0d\uda16\udcda\udbc3\ude28\ud979\uddb9\uf30c\ud999\udd19\udb39\udf34\u4f43",
        51, 47467, 1523335058, 4566741924766446413L, 41621L, true, false, (char) 58660, (char) 62819,
        Double.longBitsToDouble(0x3fd07b58bfc14510L), Double.longBitsToDouble(0x3fc32f3cbbf69868L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 9, "\ud864\udebd", "\u1764\u39aa\uc71c\ua7f4\u939e\u1ea3\u3267\u3fd3\u502d\u3f93\u66db\u1d1e\ua50d\u4b3a\u1786\u3869\u300d\ub57e", "\udb59\uddc3\ud92d\udda9\udb9c\ude0e\ud8d8\udc53\udb6d\udcdc\ud972\udcca\ud99f\udf59\ud9ab\ude4b\ud872\udc23\ud848\ude4c\ud86c\ude81\ud839\ude22\uda05\udec3\udb4a\udd4c\ud85b\uddc9\udb65\udf4e\udb05\udc33\ud86f\ude4b\ud846\udf30\udbf0\udda9\ud84a\udf2a\udb49\udfe6\ud9e3\udff2\uda9a\udf77\ud87c\udfd7\ud97a\udc7a\ud945\uddba\udbbd\ude04\ud841\udc05\uda16\udcda\ud9e6\udf39\udae1\udf5a\uf30c\ud999\udd19\udb49\ude74\u4f43",
        23, 89113, 1523353463, 4566741924766446413L, 41621L, true, false, (char) 58660, (char) 62819,
        Double.longBitsToDouble(0x3fdb1b58bc4ebd7eL), Double.longBitsToDouble(0x3f7c64237ed30d00L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 5, 9, "\ud9e4\ude1d\ud99e\udfa3\ud830\ude3b", "\u05bc\ucbf4\u6481\u7ef7\u0a99\u8baa", "\udb2b\udf50\uda7b\udf1c\ud9aa\udf5d\ud9ec\udcf2\udb1e\udea4\ud89c\ude24",
        15, 43752, -1746479545, -2769245369812583401L, 88701L, true, false, (char) 49516, (char) 55253,
        Double.longBitsToDouble(0x3fde951c15f92d46L), Double.longBitsToDouble(0x3fc5a7058e8aeaf8L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 5, 9, "\udafa\uddb2", "\u5f10\u9ea0", "\udb82\udcf8\ud884\udee1\ud9d0\udfd9\ud8d8\udcee\udabc\uddec\ud387\udb2b\udf50\uda7b\udf1c\ud9aa\udf5d\ud9ec\udcf2\udb50\udda4\ud89c\ude24\udbd1\ude46\ud9f9\udca1\ud8a1\udea1\ud8a4\udc16\udb59\uddc3",
        29, 64293, -507149, 14797516621028213L, -29250L, false, true, (char) 28946, (char) 9690,
        Double.longBitsToDouble(0x3fe51587ad915b62L), Double.longBitsToDouble(0x3fe5f2d07b5cb4f4L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 9, "\udbea\udfa1\u03dd\ud8c4\udd36\ud8d9\udc95\udae3\uddcb\ud916\udd5c", "\u6b18\ud5e3\u25b6\ucb13\u584f\ubf1b\u8acf\u0695\u4cb5", "\udbb8\uddde\ud897\udeb1\uda47\udfaf\ud8a3\udfbe\ud8fe\uded5",
        37, 85617, -1951849727, 14700626453797749L, 36286L, false, true, (char) 53496, (char) 24365,
        Double.longBitsToDouble(0x3fe51587aa1de962L), Double.longBitsToDouble(0x3fe5f2d1887975ffL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!org.apache.commons.math3.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 6, 13, 9, "\ud9e4\ude1d\uda20\uddac\ud8c4\udd19\ud8d9\udc95\udae3\uddcb\udb91\ude5a", "\u6b18\ud5e3\u14d3\ucb13\u584f\ubf1b\u8acf\u0695\ua3e4\uc606\u761e\ua8d2\u8376\u129b\u7475\u33b5\u0c05\u426f\u6556", "\udb15\udeec\ud9ab\ude4b\ud875\udc98\udadd\ude93\ud86c\uddb7",
        -3, 31444, -379399518, 6498986855820888766L, 64001L, false, true, (char) 2841, (char) 1325,
        Double.longBitsToDouble(0x3fd33a6c7ad990a4L), Double.longBitsToDouble(0x3fe48d2a44f6bb8eL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 1, 13, "\ud9e4\ude1d\ud94e\udea2", "\u7973\u75c5\u04a7\u593f\u6b18\ud5e3\u14d3\ua413\u584f\u6c07\u8acf\u0695\u49d4\u3765\u761e\ua8d2", "\ud8a3\udfbe\ud8fe\uded5\udb1e\udea7",
        17, 75273, 3422756, -251045491668472365L, 33641L, true, false, (char) 1070, (char) 33687,
        Double.longBitsToDouble(0x3fe418db172c96eaL), Double.longBitsToDouble(0x3fededafbf76d132L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 9, "\ud9e4\ude1d\ud94e\udea2\ud830\ude3b", "\u05bc\u4310\u0168\u475c\u8101\uc806\u8875\u7fa8\ubf1b\u21dd\u3e46\u4cb5\uc606\u83c2\u2ad0\ub57e\u32e6\u7475\u9dc7\u7223\ud716\u211e\uc261\u445a\u8908\u92c2\ua729\u868f\u6bd9\u6151\u78b3\u876d\u3d02\u16d7\u0cca\u86a8", "\ud932\udf31\ud8ff\udf8c\uda77\udf36\uda53\udd85\udaec\ude0b",
        40, 19331, 1762742397, -1456523124630063677L, -31108L, false, false, (char) 40104, (char) 54193,
        Double.longBitsToDouble(0x3f96af5270450660L), Double.longBitsToDouble(0x3fed914e36e7c02fL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 9, "\000", "\u1764", "\udacc\udc39",
        22, 13023, -93319697, -7578385470871261128L, -100000L, false, false, (char) 24543, (char) 10372,
        Double.longBitsToDouble(0x3fe3e4865300009cL), Double.longBitsToDouble(0x3fa17610268e0830L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 15, "\uf5a5", "\u1764", "\udb8a\ude64\udb77\udc9e\udbd4\ude25\ud81d\udd9b\ud845\udfcd\udabc\udda9\ud387\ud87c\uddc4\uda7b\udf1c\ud9aa\udf5d\ud8ae\uddf6\udb50\udda4\ud89c\ude24\udbd1\ude46\ud875\ude2f\ud9f0\udc24\ud8a3\udfbe\udb59\uddc3\ud92d\udda9\udae6\udc37",
        37, 88756, -2000610443, -3725678150286759185L, 36286L, false, true, (char) 53496, (char) 17197,
        Double.longBitsToDouble(0x3fca20b70dcde648L), Double.longBitsToDouble(0x3fecfca292c42187L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 3, "o", "\u41af", "\uda3a\udf0a\ud984\udf19\udaa4\uddbf>",
        -5, -1000, 604307456, 6924408384133267578L, 25308L, false, false, (char) 236, (char) 40054,
        Double.longBitsToDouble(0x3fe0b44103fb005bL), Double.longBitsToDouble(0x3fd0a98f129f594eL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NotStrictlyPositiveException\012",
        Z.run(T, 2, 13, 12, 3, "", "", "\ud898\ude67",
        18, 44227, -407658288, 0L, 66259L, true, false, (char) 62328, (char) 25585,
        Double.longBitsToDouble(0x3fb666e7e417d9a0L), Double.longBitsToDouble(0x3fd7f51c8043f2b2L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!org.apache.commons.math3.exception.NotStrictlyPositiveException\012",
        Z.run(T, 2, 10, 14, 0, "", "", "\ud898\ude67\ud928\udf02\ud9fe\udf4c\ud984\udf19\udb13\udf94\ud9ff\uddde\ud845\udf6a\ud8a1\udca2\ud387\ud9e0\ude2c\uda7b\udf1c\ud9aa\udf5d\ud8ae\uddf6\udb50\udda4\ud89c\uddd4\udbd1\ude46\ud875\ude2f\000",
        1, 82471, 1155805594, 124554082064L, -100000L, false, false, (char) 59113, (char) 8095,
        Double.longBitsToDouble(0x3fed15d5f7a5f3d9L), Double.longBitsToDouble(0x3fe306df036c42c1L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 9, "\udbea\udfa1\u03dd\ud8c4\udd36", "\u9cac\u13fc\u7cc5\u2050\ud5e3", "\udbdd\ude99\udb2b\udf50\ud8cf\udd4f\udb5e\ude4d\ud8ae\uddf2\udb50\udda4",
        3, 89378, 1024428824, 1722299507302050306L, 93495L, true, false, (char) 11979, (char) 50637,
        Double.longBitsToDouble(0x3febac8425e951c1L), Double.longBitsToDouble(0x3fe7e4b518ad382cL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 9, "\ud9e4\ude1d\ud94e\udea2\ud830\ude3b", "\u3ae6\ucbf4\u939e\u1ea3\ud702\u9160\ucb13\u7fa8\ubf1b\u8acf\u0695\u4cb5\uc606", "\ud875\ude2f",
        55, 17818, -2078286804, 4964146617076343069L, 61965L, false, true, (char) 52837, (char) 60964,
        Double.longBitsToDouble(0x3fefa322baa2b0f5L), Double.longBitsToDouble(0x3fe0ef4b12be5a31L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|squareRoot|org.apache.commons.math3.linear.RealMatrix|new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|computeCost|[D|new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|computeCovariances|[D,double|new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|computeResiduals|[D|new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|computeSigma|[D,double|new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|computeWeightedJacobian|[D|new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|getChiSquare||new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|getCovariances||new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|getCovariances|double|new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|getJacobianEvaluations||new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|getRMS||new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|getWeightSquareRoot||new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|guessParametersErrors||new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|optimize|int,org.apache.commons.math3.analysis.DifferentiableMultivariateVectorFunction,[D,[D,[D|new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|optimize|int,org.apache.commons.math3.analysis.differentiation.MultivariateDifferentiableVectorFunction,[D,[D,[D|new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|optimizeInternal|int,org.apache.commons.math3.analysis.differentiation.MultivariateDifferentiableVectorFunction,[Lorg.apache.commons.math3.optimization.OptimizationData;|new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
    "M|org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer|squareRoot|org.apache.commons.math3.linear.RealMatrix|new:org.apache.commons.math3.optimization.general.GaussNewtonOptimizer:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
