package org.apache.commons.math3.optimization.univariate;
import org.junit.Test;
import static org.junit.Assert.*;
public class BrentOptimizer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 0, 1, 1, "\ud8e1\udf84\udb09\ude20\uda88\udfc7\udb9b\udc9d\ud85f\udeaf\ud96a\udce8\ud937\udf31\ud9de\udc21\u6a8f\udac4\udde7\udb7e\ude6d\ud902\udf05\ud935\ude96\ud86f\udf79\udb33\udf31\ud877\udf7b\udb9f\udf27\udbb1\udee4\ud889\udfaf", "\u7926\ubf23\ubdda\u0227\u8dcf\u54f0\ud632\u8b12\u5258", "\ud803\udcbd",
        28, 29347, -1584031308, -4779604253087421591L, 79853L, true, true, (char) 24349, (char) 37406,
        Double.longBitsToDouble(0x3fe4b0d6f9180ed8L), Double.longBitsToDouble(0x3fcd52fb07e56d60L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 0, 1, 1, "\ud8e1\udf84\udb09\ude20\uda88\udfc7\udb9b\udc9d\ud85f\udeaf\ud96a\udce8\ud937\udf31\ud9de\udc21\u6a8f\uda8b\udce2", "\u2f2b\u1f05\u1265\u1bc4\u23df\ua80d\uc45f\u9c9a\u9edb\u7926\ubf23\u9cd9\u0227\u8dcf\u54f0\ud632\u8b12\u5258\u12d9\u9ef0\u2fe2\u3d25\ube11\ud23a\u7116\ud371\u1188\u47c4\u041d\u905b\u6946\uc82d\u95a5\uc52c\u565e\u7e33", "\ud939\udc3f",
        57, 10118, 1522086337, -2217395708659224577L, 39469L, true, false, (char) 23928, (char) 53485,
        Double.longBitsToDouble(0x3fd3b37a47d83ac6L), Double.longBitsToDouble(0x3fd89d83571d7f20L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 0, 1, 1, "\uda2d\udd54\ud847\ude1f", "\u2ab8\u0555\u17a5", "\udac4\udde7\udb7e\ude6d\ud902\udf05\udbee\udd93\ud86f\udf79\udb33\udf31\ud877\udf7b\udb9f\udf27\udae8\udf61\ud976\udf7b\udbcc\ude26\ud9f4\udd2b\udac3\ude5c",
        56, 68527, 34361425, 8475944263114391847L, -84644L, true, false, (char) 64371, (char) 45568,
        Double.longBitsToDouble(0x3fec6d7f2df95807L), Double.longBitsToDouble(0x3fd7b934d369d1beL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NotStrictlyPositiveException\012",
        Z.run(T, 2, 0, 1, 1, "\ud8e1\udf84\udb09\ude20\udad8\udfb8\udb9b\udc9d\udbaa\udd15\000\000\000\000\udabf\udd3e\udb7e\ude6d\ud902\udf05\ud935\ude96\ud86f\udf79\udb33\udf31\ud877\udf7b\udb9f\udf27\udbb1\udee4\ud889\udfaf", "\u7926\ubf23\ubdda\u0227\u8dcf\u54f0\ud632\u8b12\u6657", "\ud803\udcbd",
        28, 29347, -1584031308, -4779604253087421591L, 79853L, true, true, (char) 24349, (char) 37406,
        Double.longBitsToDouble(0x3fc2c35be0000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 2, 3, 2, 0, "\udb37\ude0f\udb09\ude20", "\u2ab8", "\ud9de\udc00\uf37e\udacb\udd8a\u91f3\uda98\udfbf\ud935\ude96\ud86f\udf79\udb33\udf31\ud888\udf7b",
        52, 52498, -406810339, -9056042245278287863L, 38538L, true, false, (char) 13349, (char) 45266,
        Double.longBitsToDouble(0x3fdbf251829cb5e2L), Double.longBitsToDouble(0x3f72541a39bfb980L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 1, 2, 1, 1, "\udae9\udf88\udb09\ude20\uda92\ude6c\udb09\ude69\uda3f\udd5d\ud96a\udce8\uda0a\udeba\ud8c2\udeb4\udb1d\ude28\udac4\udde7\udb7e\ude6d\ud902\udf05\ud935\ude96\ud86f\udf79\udb59\uddf1\uc10f\udb43\udc7d\udbcf\udd76\udb2a\udc2b", "\u7926\u6603\ucb95\u9f25\u5709\u54f0\u1925\u8b12\u4746\u12d9\u9ef0\u2fe2\u3f92\u240f\u11cd\u70a3\ud371\u1a1f\u47a3\u041d\u905b", "\udadc\udc14\ud933\udd14\ud9fc\uddfd\udb89\udd74\udae4\ude86\uda9c\udca7\udb93\udf44\ud9b5\udd8b\udb16\udd7b\uda77\udea1\udaa7\udd51\ud8cc\udda2\udae8\udc82",
        40, 92224, -1886501092, 8565636519880739159L, -40641L, false, false, (char) 13869, (char) 11150,
        Double.longBitsToDouble(0x3fe96b9c124008d2L), Double.longBitsToDouble(0x3fe0e4378050793bL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=!org.apache.commons.math3.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 2, 0, 1, "\ud8e1\udf84\uda06\udd5e\uda88\udf53\udbb8\udc8c\ud904\udc18\ud895\ude4e\u0440\ud9de\udc21\u6a8f\udac4\udde7\ud89c\udefb\udb50\udf6a\ud92b\ude0e\ud86f\udf79\udb33\udf31\ud877\udf7b\udb9f\udf27\udbb1\udee4\udb03\udfde", "\u7917\u3bb2\ubd8f\u0227\u8dcf\u54f0\ud632\u8b12\u5258\u12d9\u9ef0\u27e1\u3d25", "\ud90a\udf58\ud8e6\udc95\udad3\udf01",
        4, 31893, 816965285, 1936373485820976790L, -37530L, false, true, (char) 1722, (char) 55416,
        Double.longBitsToDouble(0x3fa7067c64390060L), Double.longBitsToDouble(0x3fd8d51b3f56756eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 2, 2, 1, 1, "\ud8e1\udf84\udb09\ude20\uda88\udfc7\udb9b\udc9d\ud85f\udeaf\ud96a\udce8\ud937\udf31\ud9de\udc21\u6a8f\udac4\udde7\ud96c\ude64\ud902\udf05\ud935\ude96\ud86f\udf79\udb33\udf31\ud877\udf7b\udb9f\udf27\udbb1\udee4\ud889\udfaf", "\u7926\ubf23\ubdda\u0227\u8dcf\u54f0\ud632\u8b12\u5258", "\ud803\udcbd",
        28, 29347, -1584031308, -4779604253087421591L, 79853L, true, true, (char) 24349, (char) 37406,
        Double.longBitsToDouble(0x3fe4b0d6f9180ed8L), Double.longBitsToDouble(0x3fcd52fb07e56d60L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=!org.apache.commons.math3.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 3, 0, 0, "\ud8e1\udf84\ud9e9\udd6f\uda82\ude51\ud845\udda9\ud9ad\udc63\uda75\udeb4\ud990\udd34\ud8db\udf83\u6a8f\ud9d5\udd13\udbe0\udea9\u4bb3\uda27\udddc\ud86f\udf79\ud987\udf9b\ud877\udedc\udb9f\udf27\udbb1\udee4\ud835\ude45", "\u5222\u4bd8", "\udb4c\udfc8\u1d45\uda4f\udf5a",
        12, 50955, 203435130, -5772024960142295095L, -61441L, false, true, (char) 4311, (char) 59668,
        Double.longBitsToDouble(0x3fe482be3e8d022aL), Double.longBitsToDouble(0x3fd55152ad4af0f0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud8e1\udf84\udadd\udf92\ud995\udcd3\udb9b\udc9d\ud85f\udeaf\ud96a\udce8\ud937\udf31\udbc9\udde3\u6a8f\udac4\udde7\udb7e\ude6d\udb77\udd7e\uda3f\uddbe\ud870\udc3b\udb33\udf31\ud877\udf7b\udb9f\udf27\udbb1\udee4\ud889\udfaf", "\u7926\ubf23\ubdda\u0227\u8dcf\u54f0\ud632\u8b12", "\uda0f\uddf4\udaf2\ude1c\udbbb\udc06\ud931\udf75\ud8d6\udffb\ud8f6\udf8f\ud8e6\udc95\udad3\udf01\ud92f\udfcc\ud85a\udd4f\ud965\udd59\ud800\udd77\uda9b\udcbc",
        7, 62129, -1200852487, 7638817860257259697L, -51473L, false, true, (char) 11312, (char) 43861,
        Double.longBitsToDouble(0x3fdb6ed6a589656aL), Double.longBitsToDouble(0x3fb9d2fa9c7d38b8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=!org.apache.commons.math3.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 1, 0, 1, "\ud8e1\udf84\udb1b\udc80\uda88\udfc7\udb9b\udc9d\ud93e\udf40\udb16\udef3\ud937\udf31\ud9c2\udc13\udb01\udf14\udac4\udde7\udb7e\ude6d\ud902\udf05\ud9f9\ude98\ud9d0\udc32\udb33\udf31\ud877\udf7b\udb9f\udf27\udbb1\udee4\ud889\udfaf", "\u7926\ubf23\ubdda\u0227\u4b24\ud4c3\ud632\u31fb\u6722", "\ud803\udcbd\ud867\udf91\udb87\udc10\ud834\udffa\ud92b\ude18\ud8e6\udc95\udad3\udf01\ud92f\udfcc\ud9c3\udc6e\uda78\udd83\ud984\udf02\ud8c4\uddb3\udaf8\udcb7",
        22, 15401, -1607267553, -6503689881207338196L, 73065L, true, true, (char) 7222, (char) 5640,
        Double.longBitsToDouble(0x3fe4f107e0559391L), Double.longBitsToDouble(0x3fe31dbba0662eceL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 2, 3, 3, 1, "\ud8e1\udf84\udad8\udd7d\udb95\udca1\ud975\udf15\uda5f\udd7d\ud971\udddf\ud937\udf31\ud9de\udc21\u6a8f\ud8f4\ude20\uda0b\udde1\ud902\udf7c\udaac\udf51\ud86f\udf79\udb33\udf31\ud877\udf7b\udb9f\udf27\udbb1\udee4\ud889\udfaf", "\u7902\ubf23\ubdda\u0227\u8dcf\u54f0\ud632\u8b12\u5258", "\ud803\udcbd",
        -5, 12581, -1718931116, -2991460558144983532L, 79853L, false, true, (char) 24349, (char) 37406,
        Double.longBitsToDouble(0x3fe4b0d6f9180ed8L), Double.longBitsToDouble(0x3fcd52fb06b9ee50L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 2, 2, 3, 1, "\ud8e1\udfc6\udb09\ude20\uda88\udfc7\udb9b\udc9d\ud85f\udeaf", "\u144d", "\udb7e\udef8\ud902\udf05\u6249\uda02\udfa8\udb33\udf31\ud877\udf7b\udb9f\udf27\uda1d\udeda\ud889\udfaf\udbcc\ude26\ud9f4\udd2b\udac3\ude5c\udb20\udca9",
        37, 17661, 1973459558, -796713655381478752L, 15827L, false, false, (char) 45568, (char) 26556,
        Double.longBitsToDouble(0x3fdf958072f7269aL), Double.longBitsToDouble(0x3fdb4e8df853432aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud8e1\udf84\ud905\ude1e\uda88\udfc7\udb54\udcf7\ud85f\udeaf\ud96a\udce8\ud841\udcf6\ud9de\udc21\u6a8f\udac4\udde7\udb7e\ude6d\ud902\udf05\ud918\udd5e\ud86f\udf79\udbc3\udf39\ud877\udf7b\udb9f\udf27\udbb1\udee4\udba5\udd3c", "\u7926\ubf23\ubdda\u0227\u8dcf\u85f7\u025a\u8b12\u5258\u12d9\u9ef0\u2fe2\u3d25\ube11\u11cd\u70a3\ud371\u1a1f\ub70b\u03ca\u905b\u6946\uc82d\u95a5", "\ud8bd\udcf3\udb73\uddc9\ud89f\uddb6\ud80a\udc2c\udba5\udc60\udb36\udfe6\uda79\udd0b\ud97c\uded4\uda22\ude66\udbff\udf0a\uda29\udc6d\ud982\udf1d\ud963\udda2\ud254\u32cb\ud816\udd3c\ud86d\udcaa\udbb1\uddef",
        31, 57082, -1928923724, -2327427876795125295L, -747L, true, true, (char) 6666, (char) 8521,
        Double.longBitsToDouble(0x3f86407cb0c1cec0L), Double.longBitsToDouble(0x3fcc27d14545d604L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NumberIsTooSmallException\012",
        Z.run(T, 2, 0, 0, 1, "\000\000", "", "\ud937\udf31",
        43, 12448, 1493172224, -7136322754561691894L, 31054L, true, false, (char) 58965, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd8fe70901304a4L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 1, 3, 1, 1, "\uda2d\udd54\ud847\ude1f", "\u2ab8\u0555\u17a5", "\udafd\uddfd\ud99a\udc51\ud902\udf05\udbee\udd93\ud877\ude79\ud9c5\udf3a\udb16\udf00",
        38, 80347, -1267643556, 3163898688397468598L, 38538L, true, true, (char) 60713, (char) 40049,
        Double.longBitsToDouble(0x3fe93bad04705ac7L), Double.longBitsToDouble(0x3f72a6f239bfb980L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 0, 1, 1, "\ud8e1\udf84\udb09\ude20\uda88\udfc7\udb9b\udc9d\uda60\udf5f\ud88f\udee8\ud937\udf31\ud9de\udc21\u6a8f\udac4\udde7\udb7e\ude6d\ud902\udf05\ud935\ude6f\ud86f\udf79\udb33\udf31\ud877\udf7b\udb9f\udf27\udbb1\udee4\ud889\udfaf", "\u7926\ubf23\ubdda\u0227\u8dcf\u54f0\ud632\u8b12\u5258", "\ud803\udcbd",
        28, 29347, -1584031308, -4779604253087421591L, 79853L, true, true, (char) 24349, (char) 37406,
        Double.longBitsToDouble(0x3fe4b0d6f9180ed8L), Double.longBitsToDouble(0x3fcd52fb07e56d60L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 2, 3, 2, 0, "\uda1d\udde2\udb09\ude20", "\u2ab8", "\ud9de\udc00\uf37e\udacb\udd8a\u91f3\uda98\udfbf\ud935\ude96\ud86f\udf79\udb33\udf31\ud888\udf7b",
        7, 86407, -406810339, -9056042245278287863L, -11164L, true, true, (char) 50944, (char) 24019,
        Double.longBitsToDouble(0x3fdbf145429cb5e2L), Double.longBitsToDouble(0x3f72541a39bfb980L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.optimization.univariate.BrentOptimizer|doOptimize||new:org.apache.commons.math3.optimization.univariate.BrentOptimizer:double,double",
    "M|org.apache.commons.math3.optimization.univariate.BrentOptimizer|best|org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair,org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair,boolean|new:org.apache.commons.math3.optimization.univariate.BrentOptimizer:double,double",
    "C|org.apache.commons.math3.optimization.univariate.BrentOptimizer|<init>|double,double,org.apache.commons.math3.optimization.ConvergenceChecker",
    "C|org.apache.commons.math3.optimization.univariate.BrentOptimizer|<init>|double,double",
    "M|org.apache.commons.math3.optimization.univariate.BrentOptimizer|doOptimize||new:org.apache.commons.math3.optimization.univariate.BrentOptimizer:double,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
