package org.apache.commons.math.analysis.solvers;
import org.junit.Test;
import static org.junit.Assert.*;
public class BisectionSolver_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 0, 0, "\udbeb\udff0\udad0\udcd7", "\u87a2\ua7f0", "\ud947\udc12\uda44\udeda\udaa9\udf1a",
        42, 87339, -228479769, -6042137616642695920L, 55935L, false, false, (char) 42559, (char) 32740,
        Double.longBitsToDouble(0x3fddd01590bea2c2L), Double.longBitsToDouble(0x3febb17992bc6d64L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 1, 6, 4, "\udaa7\udf0e\uda41\udfdd\ud9bf\uddc8\u72cf\ud91a\ude31", "\u1951\u2d6f\ub472\u8e83\ubfea\u3232\ud4c2\u5078\u6516\uc4f2\u5847\u3a63\u80aa\u28d3\u477f\u48cd\u6c38\uc963\ua25b\u60d6\u267a\ube16\u7be0\ub26f\u433c\u8acc\ua49f", "\ud8b8\udce1\uda27\udfbb\uda06\udd0c\udbdf\udc3b",
        30, 2715, -655889003, 4749056547385437587L, -62401L, false, true, (char) 3050, (char) 61953,
        Double.longBitsToDouble(0x3fefb11787e5ac23L), Double.longBitsToDouble(0x3fc3517cd57bae18L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 3, 6, 5, "\udbeb\udff0\udbb4\udd32", "\ucf08\ua825\u2d41\u1951\u6967\u0f3d\u0b2c\u8c5c\ua18a\ud4c2\u8b5c\u4d89\u3c79\u1a14\u3a63\u10d6\u28d3\uce50\u484f\uc51c\uc6a4\u9b27\u6ffb\u2e40\uc7eb\u6221\u54c3\u1375\u125d\u49ae\ua6c3\u6b15\u3058\u6839\u1a98", "\ud86e\udd48\uda78\udd72\ud9da\udf26\ud869\udd70\udad1\udc05\uda65\udecc",
        58, 1515, 89299116, -1343570516670421038L, 21095L, false, true, (char) 63580, (char) 47490,
        Double.longBitsToDouble(0x3fef2d0a1f0e4735L), Double.longBitsToDouble(0x3fd62c3b9c171fc2L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BisectionSolver:@?\012",
        Z.run(T, 1, 5, 3, 0, "\uda97\udd77\udbbf\ude62\ud9cf\udd7d\u72cf\uda40\ude7a\udbb9\udc90\ud8d2\ude24\uda34\udcad\ud947\udc12\uda44\udeda\udaa9\udf1a\ud8ea\udf22\ud828\udd78\udbb9\udfbf\udaae\udddd\uda00\udc1c\uda72\udcdc\udb55\udebc\ud968\udf2f\ud8f6\udc8c\udbc5\udcf4\udaf6\udea8\ud327\ud93c\udde8\udb6d\ude9d", "\u629d\u4339\u746b\ub95c\u2814\u10f4\u6647\u9766\u357e\u5fbf\u6b4c\u627b\u1019\u5336\u2084\ub130\uaf95\u2ef5\uc293\u979f\ua460", "\udaca\udcfe\udabf\udcfd\udae3\uddb7\udba2\udc30\udb9e\ude47",
        24, 90308, 1729208860, 5506481654350607055L, 13835L, false, false, (char) 59692, (char) 25906,
        Double.longBitsToDouble(0x3fcea00df6d98ec0L), Double.longBitsToDouble(0x3fcbcbe8095b6128L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 6, "\udbeb\udff0\ud972\udd28", "\u87a2\u9756\u4625\u80ae\u0747\u3fa9\u671a\u8c8e\u2c22\u4796\ud5b1\u6d7d\u3c79\u1a14\u3a63\u10d6\ub609\uce30\u484f\u9b5b\u971d\u159a\uc4be\u97d7", "\udb9b\udc29\udaa0\udf55\uda82\ude58\ud8b1\udf15\ud91b\udfbb\udaf3\udf45\udacb\uddd3\ud96c\udcc7\ud8f8\udd8c\uf124\u6d94\ud8a6\ude15\udb84\ude11\udb29\uddd9\ud9ab\udd19\ud9df\udcb8\ud952\udd8c\udba9\ude5d\uda98\udc19\udba6\udda5\udbdc\udf29\udb40\udc3f\udb80\udc4c\ud958\udee2\uda46\udc0d\udbf6\udd89\ud808\udecb\ud813\ude34\udbc6\udf46\udbcf\udd3f\uda22\udd20\ud83a\udf30\udbe2\udf8b\ud8e4\udc65\ud84e\udddf\udb36\ude4c\uda10\udf8e\udae4\ude5a\ud808\udd94\udbcd\uddf1\udaf2\ude4f\udaa7\udf6b\udbd3\udd9d\ud9dd\udd27\ud8ff\udeba\ud881\udd81\udbea\udd2a\u403b\ud85d\udd25\ueb7c\ud8d8\udec7\ud976\ude74\udab4\udc1d\udba5\ude0d\udbe2\udcbc\ud843\ude03\ud954\uddc9\u06b9\ud90d\udd18",
        18, 80620, 55824269, 1909670750214159583L, -6140L, true, true, (char) 28647, (char) 62614,
        Double.longBitsToDouble(0x3fe9a901b6552d16L), Double.longBitsToDouble(0x3fefc4cfa5a08477L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 4, 4, 0, "\ud889\udf5f\ud8e8\uddbe\ud9cf\udd7d\u72cf\uda40\ude7a\uda8e\udd7c\ud8e7\udc13\uda89\udfd1\u3620\uda44\udeda\udaa9\udf1a\ud8ea\udf33\uc471\uda11\udc19\udbdd\udee8\uda00\udc1c\uda72\udcdc", "\u7984\uc2a6\u61ec\uc9ea\ucfab\u17ce\u3f69\u14ba\u3b6c\uc0bd\u94ff\u9056\u9f3d\u8401\u0c34\ua878\u9f18", "\ud97d\udf1a\ud920\udd97\ud8e9\udfd6\uda28\udc97\ud843\ude06\udac5\udc64\udad4\udfc0\ud95e\uddac\ud9db\udf6c\ud88b\udffd\udb11\udf40\udba1\udfc5\ud977\uddcb\udb56\udc42\u1eb2\udba5\udc85\ud985\uddef\ud8d4\udd65\ud944\udcaa\ud8c2\uddf2",
        52, 52196, -918655568, 9210032958420909728L, 72358L, false, false, (char) 28151, (char) 20865,
        Double.longBitsToDouble(0x3fe5847890270c8aL), Double.longBitsToDouble(0x3fcaaa87a66f7794L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BisectionSolver:@?\012",
        Z.run(T, 1, 5, 0, 7, "\udbeb\udff0\ud9d6\udeba", "\u0b78\ua7f0", "\ud947\udc12\uda44\udeda\udaa9\udf1a",
        42, 87339, -228479769, -6042137616642695920L, 55935L, false, false, (char) 42559, (char) 32740,
        Double.longBitsToDouble(0x3fddd01590bea2c2L), Double.longBitsToDouble(0x3fbd8bcc95e00000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 4, 0, 2, "", "\000", "\ud8f9\udd0b",
        -5, -1000, 0, -5548434742716783254L, -100000L, false, true, (char) 1741, (char) 51141,
        Double.longBitsToDouble(0x3fb0001380000070L), Double.longBitsToDouble(0x3fe9d00005dd0000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BisectionSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 0, "\udad5\udda6\ud953\udf8e\udaf8\udd9e\u72cf\uda40\ude7a\udaf6\udc30", "\u2d6f", "\ud8ea\udf33\uc478\uda11\udc19\udaa1\udc6a\udbb2\udc9d\ud90b\ude09\udadd\udd76\uda2d\udd56\ud854\ude2e\ud9b3\udc57\udaf6\udea8\ud8d8\udfc7\ud942\udd70\uda47\ude6a\ud9bb\udc87\uda9e\ude0d\uda95\udc26",
        11, 56043, -1146442520, 7757896443683582112L, 70199L, false, false, (char) 15528, (char) 18293,
        Double.longBitsToDouble(0x3fd98f15948f7a90L), Double.longBitsToDouble(0x3fe27732925d2ee6L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BisectionSolver:@?\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 5, 3, 0, "\uda9d\udc77\udbbf\ude62\ud9cf\udd7d\u72cf\uda40\ude7a\udbb9\udc90\ud8d2\ude24\uda34\udcad\ud947\udc12\uda44\udeda\udaa9\udf1a\ud8ea\udf22\ud9dc\udd32\udbb9\udf80\udaef\uddfd\ud8bf\udfea\udb6d\udcc8\ud9ad\ude79\ud95e\udfc0\ud8f6\udc8c\udbc5\udcf4\udaf6\udea8\ud327\ud93c\udde8\ud925\udead", "\u6219\u4339\u4443\ub420\u2814\u10f4\u965f\u31c1\u357e\u5fbf\u6b4c\u627b\u1019\u47dc\u5ecc\u63e8\ua5ac\u2ef5\uc293\u979f\ua460\ub3c5\u71aa\u28f4\u39c2\u67b8\u8e69\ub56d\u1abc", "\udb80\udc64\ud8fc\udc8e\ud840\udfeb\udaf5\udd6e\uf154\ud9f0\udc8d\uda33\uddcc\udbd3\uded4\ua353\udbc1\ude86\udae2\udd06\udb01\udf61\ud90f\ude7c\udbcd\udc56\udbff\ude82\udbb9\udd36\udaf6\udf37\udacf\uddab\uda0a\udc4e\udbe6\ude2c\udb37\udc44\uda88\ude66\ud95e\udffc\u9ba1",
        55, 30025, -2075577153, -8220871051925523194L, 58426L, false, false, (char) 59181, (char) 36603,
        Double.longBitsToDouble(0x3fe1ac840ed4e010L), Double.longBitsToDouble(0x3fde04a5921cdb92L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BisectionSolver:@?\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 5, 1, 6, "\udbeb\udff0\ud972\udd28", "\u87a2\u9756\u04d0\u59c5\u1523\u3fa9\u671a\u8c8e\u2c22\u4796\ud5b1\u6d7d\u3c79\u1a14\u3a63\u10d6\ub609\uce30\ub415\u9abc\u971d\u2f14\ub9e6\u2039", "\udb9b\udc29\udaa0\udf55\uda82\ude58\ud8b1\udf15\ud91b\udfbb\udaf3\udf45\udacb\uddd3\ud96c\udcc7",
        11, 83163, -235729304, -639015703250562687L, 76499L, true, true, (char) 10054, (char) 23996,
        Double.longBitsToDouble(0x3fed5a7015ff3b52L), Double.longBitsToDouble(0x3fe97131df95cf24L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BisectionSolver:@?\0121=new org.apache.commons.math.analysis.solvers.BisectionSolver:@?\012",
        Z.run(T, 2, 5, 5, 3, "\udbc3\udefb\ud903\udcb0", "\ua2db\u9fc6\u2d41\u1951\u2d6f\ub472\u8e83\u1e24\ua116\u0cbd\u5078", "\udb55\udebc\ud968\udf2f\uda60\udc00\ud939\udf4e\udaf6\udea8",
        36, -882, -365307204, 4497702768602104874L, -58824L, false, false, (char) 42481, (char) 22608,
        Double.longBitsToDouble(0x3f902d35d60cc7e0L), Double.longBitsToDouble(0x3fea659d091c2c66L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BisectionSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 6, "\udad5\udda6\ud953\udf8e\udaf8\udd9e\u72cf\uda40\ude7a\udaf6\udc30\ud819\udcfc\uda34\udd13\ud947\udc12\uda44\udf51\udaa9\udf1a", "\ud4c2", "\ud90b\ude09\udadd\udd76\uda2d\udd56\ud854\ude2e\ud9b3\udc57\udaf6\udea8",
        34, 1160, 1226154524, -7692356168145852492L, -13192L, false, true, (char) 7241, (char) 21495,
        Double.longBitsToDouble(0x3fe3beffa27f5610L), Double.longBitsToDouble(0x3fe94c292a040dedL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BisectionSolver:@?\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 5, 4, 0, "\udad5\udda6\ud953\udf8e\udaf8\udd9e\u72cf\uda40\ude7a\udaf6\udc30", "\u2d6f", "\ud8ea\udf33\uc478\uda11\udc19\udaa1\udc6a\udbb2\udc9d\ud90b\ude09\udadd\udd76\uda2d\udd56\ud854\ude2e\ud9b3\udc57\udaf6\udea8\ud8d8\udfc7\ud942\udd70\uda47\ude6a\ud9bb\udc87\uda9e\ude0d\uda95\udc26",
        11, 56043, -1146442520, 7757896443683582112L, -42657L, false, true, (char) 60494, (char) 16369,
        Double.longBitsToDouble(0x3fddc22cc1d24d18L), Double.longBitsToDouble(0x3fd98f15948f7a90L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BisectionSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 0, "\udad5\udda6\ud953\udf8e\udb59\udfce\u72cf\uda40\ude7a\udaf6\udc30", "\u2d6f", "\ud8ea\udf33\uc478\uda11\udc19\udaa1\udc6a\udbb2\udc9d\u2e0a\udadd\udd76\uda2d\udd56\ud854\ude2e\ud9b3\udc57\udaf6\udea8\ud8d8\udfc7\ud942\udd70\uda47\udea4\ud9bb\udc87\uda9e\ude0d\uda95\udc26",
        11, 57779, -1146442563, 7757896443683582112L, 70199L, false, false, (char) 15528, (char) 18293,
        Double.longBitsToDouble(0x3fd98f15948f7a90L), Double.longBitsToDouble(0x3fe27732925d2ee6L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 0, 0, "\udbeb\udff0\udad0\udcd7", "\u87a2\ub260", "\ud947\udc12\uda44\udeda\udaa9\udf1a",
        42, 87339, -228479769, -6042137616642695920L, 55935L, false, false, (char) 42559, (char) 32740,
        Double.longBitsToDouble(0x3fddd01590bea2c2L), Double.longBitsToDouble(0x3febb17992bc6d64L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BisectionSolver:@?\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 5, 1, 6, "\udbeb\udff0\ud972\udd28", "\ud3d9\u9756\u04d0\u59c5\u1523\u3fa9\u671a\u1eb0\000\u475e\ud5b1\u6d7d\u3c79\u611f\u3a23\u10d6\ub609\uce30\ub415\u9abc\000\000\ub9e6\u2039", "\udb9b\udc29",
        23, -949, 0, -1325853714L, -70784L, true, true, (char) 17055, (char) 856,
        Double.longBitsToDouble(0x3fe4df8f9881f721L), Double.longBitsToDouble(0x3f8600017736b340L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.analysis.solvers.BisectionSolver|solve|double,double|new:org.apache.commons.math.analysis.solvers.BisectionSolver:",
    "M|org.apache.commons.math.analysis.solvers.BisectionSolver|solve|double,double,double|new:org.apache.commons.math.analysis.solvers.BisectionSolver:",
    "M|org.apache.commons.math.analysis.solvers.BisectionSolver|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double|new:org.apache.commons.math.analysis.solvers.BisectionSolver:",
    "M|org.apache.commons.math.analysis.solvers.BisectionSolver|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double|new:org.apache.commons.math.analysis.solvers.BisectionSolver:",
    "C|org.apache.commons.math.analysis.solvers.BisectionSolver|<init>|org.apache.commons.math.analysis.UnivariateRealFunction",
    "C|org.apache.commons.math.analysis.solvers.BisectionSolver|<init>|",
    "M|org.apache.commons.math.analysis.solvers.BisectionSolver|solve|double,double|new:org.apache.commons.math.analysis.solvers.BisectionSolver:",
    "M|org.apache.commons.math.analysis.solvers.BisectionSolver|solve|double,double,double|new:org.apache.commons.math.analysis.solvers.BisectionSolver:",
    "M|org.apache.commons.math.analysis.solvers.BisectionSolver|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double|new:org.apache.commons.math.analysis.solvers.BisectionSolver:",
    "M|org.apache.commons.math.analysis.solvers.BisectionSolver|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double|new:org.apache.commons.math.analysis.solvers.BisectionSolver:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
