package org.apache.commons.math.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class MultidimensionalCounter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=[I:[[55797, 56923, 55573, 57121, 55597, 57023, 55888, 56733]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 4, 3, 5, "\uda25\ude8b\ud945\udf51\ud95d\udeef\uda80\uddcd", "\u0898\u969f\u20ec\ubccc\u3c9b\u8598\ucc72", "\ud9f8\ude18\udad2\udde6\ud99e\udd12",
        58, 92640, -360674255, -7700574132831257479L, -96796L, false, false, (char) 4961, (char) 27776,
        Double.longBitsToDouble(0x3fd15f665225848cL), Double.longBitsToDouble(0x3fe493b78c72b3b2L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NotStrictlyPositiveException\012",
        Z.run(T, 1, 4, 3, 5, "\uda25\ude8b\udada\udf7c\ud8a4\uddd8\ufbbb", "\u384b\u3ade\u20ec\ubccc\u3c9b\u8598\ucc72", "\ud9f8\ude18\udad2\udde6\ud99e\udd12",
        58, 92640, -360674255, -7700574132831257479L, -96796L, false, false, (char) 4961, (char) 27776,
        Double.longBitsToDouble(0x3fd15f665225848cL), Double.longBitsToDouble(0x3fe493b78c72b3b2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NotStrictlyPositiveException\012",
        Z.run(T, 1, 4, 3, 5, "\uda25\ude8b", "\u2e89\ubcdd\u77c8\u0898\u969f", "\ud807\udd2b\ud982\udeb5\ud99c\udceb\ud9bf\udd87",
        42, 67757, 543490046, -9211338315305926916L, -64111L, false, false, (char) 37275, (char) 42265,
        Double.longBitsToDouble(0x3fe1355eb07830b4L), Double.longBitsToDouble(0x3fc0811343a094b0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.OutOfRangeException\012",
        Z.run(T, 1, 0, 3, 0, "\000\000\000\000", "\u88e1\ua77a\000\000\000\000\ucc72", "\000\udad2\udde6\uc000",
        -5, 92640, -360674255, 18280018804736L, -100000L, false, false, (char) 12078, (char) 27776,
        Double.longBitsToDouble(0x3fd15f665000008cL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 0, "\uda25\ude05", "\u1389\ubcdd\u77c8\u60b6\ua77a", "",
        -5, 11512, 171743313, 59555576121263919L, -100000L, false, false, (char) 0, (char) 41431,
        Double.longBitsToDouble(0x3fa8a35b8a0ea800L), Double.longBitsToDouble(0x3fbe4008b8913038L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException |a0=[I:[[55797, 56923, 55573, 57121, 55597, 57023, 55888, 56733]]\012",
        Z.run(T, 1, 7, 3, 2, "\uda25\ude8b\ud945\udf51\ud95d\udeef\uda80\uddcd", "\uc39d\u07bc\u20ec\\\u26f2\u7a61\ucc72", "\ud9f8\ude18\udad2\udde6\ud99e\udd12",
        58, 59776, -360674255, -7700574132831257479L, -96796L, false, false, (char) 5110, (char) 27776,
        Double.longBitsToDouble(0x3fdcc224422e3b48L), Double.longBitsToDouble(0x3fe493b78c72b3b2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:8 |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 2, 6, 0, "\udab7\udff4\ud945\udeed\ud89e\udcb0\udbff\ude7f\ud8b6\udd87\ud9fe\ude00\ud8e3\udd3e\ud97e\ude17\ud8e1\ude46\uda1d\udd0b\ud92d\udff8\udb15\udeb2\ud99c\udca9\ud9bf\udd87\ud98c\ude52\udb8d\ude08\uda65\ude3f\u5bcb\udb4b\udd81\udb7f\ude02\uda9a\udeec\udaea\ude53\udafb\udeb6\ud8e4\udef3\udb34\udc24", "\022\u2153", "\ud9ba\udc62\uda35\udc8a\ud85f\udecb\uda85\udec6\uda77\udfc4\uda96\uddd1\uda73\ude88\ud84a\udce5\ud8d2\udf69\udbd3\udec4\udaa5\uded9",
        54, 77224, 499815949, 6337646471086323939L, -70706L, true, true, (char) 64172, (char) 55783,
        Double.longBitsToDouble(0x3fd4a8dbfc728674L), Double.longBitsToDouble(0x3fdd820c81b33f40L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException |a0=[I:[[55797, 56923, 55774, 56613, 56187, 56551]]\012",
        Z.run(T, 1, 7, 7, 5, "\uda25\ude8b\uda0e\udd55\udbab\udd17", "\u77c8\u4ab8\u408e\u20ec\u95f1\ubf4c\u8598\u6160\ua5fe\u6c2c\u2481\u60d5\ub12f\u5792\u75a8\u3ad9\u958e\ubc3b\ua454\u97df\uc2a9\u6892\u7466\u5855", "\udab2\udfc0",
        29, 22061, 2076543067, -5549672696318081237L, -66164L, true, true, (char) 64911, (char) 12253,
        Double.longBitsToDouble(0x3fe052f66751cfc9L), Double.longBitsToDouble(0x3fae618a07036c30L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NotStrictlyPositiveException\012",
        Z.run(T, 1, 4, 3, 5, "\000", "\u2e89\ubcdd\u77c8\u0898\u969f", "\ud807\udd2b\ud982\udeb5\ud99c\udceb\ud9bf\udd87",
        6, 67757, 543490046, -9211338315305926916L, -64111L, false, false, (char) 37275, (char) 42265,
        Double.longBitsToDouble(0x3fe1355eb07830b4L), Double.longBitsToDouble(0x3fc0811343a094b0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[I:[[0, 13, 0, 0, 1, 1, 30301, 51447]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 0, 0, 0, "\uda25\ude8b\ud945\udf51\ud95d\udeef\uda80\uddcd", "\u0898", "\u40f6\ud807\udd2b\ud982\udeb5",
        48, 28363, 521799424, -479912098854010882L, -17820L, false, true, (char) 53991, (char) 64288,
        Double.longBitsToDouble(0x3fbe6548b8913038L), Double.longBitsToDouble(0x3fe1355eb07830b4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.apache.commons.math.util.MultidimensionalCounter$Iterator:@? |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 5, 3, 5, "\uda25\ude8b\ud945\udf51\ud95d\udeef\uda80\uddcd", "\u6a4c\u969f\u20ec\u7393\u3c9b\u8598\ucc72", "\ud9f8\ude18\udad2\udde6\ud99e\udd12",
        58, 92640, -360674255, -7700574132831257479L, -96796L, false, false, (char) 4961, (char) 27776,
        Double.longBitsToDouble(0x3fd15f665225848cL), Double.longBitsToDouble(0x3fe493b78c72b3b2L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NotStrictlyPositiveException\012",
        Z.run(T, 1, 1, 3, 5, "\ud9ee\udc4f\ud987\udc95\ud984\udda9\uda80\uddcd", "\u0898\u969f\u20ec\ubccc\u3c9b\u8598\ucc72", "\ud9f8\ude18\udad2\udde6\ud99e\udd12",
        58, 92640, -360674255, -7700574134307652487L, -96796L, false, true, (char) 13479, (char) 27264,
        Double.longBitsToDouble(0x3fdf9f6652729288L), Double.longBitsToDouble(0x3fe493b01c72b3b2L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.OutOfRangeException\012",
        Z.run(T, 1, 1, 2, 5, "\uda2d\udff9\ud945\udf51\uda64\ude74\u0c1e\udb29\udde1\ud8bd\udff5\udba5\udf58\ud910\udd09\ud979\udcc1\u40f6\ud807\udd2b\ud982\udeb5\ud99c\udceb\udbca\udc8a\udb36\udcfc\ud9f8\ude08\udad2\udde6\ud99e\udd12\uda7a\udd00\udb7f\ude02", "\u35fa\u0578\u312b\uc2a9\u2528\u07f4\u934e\u94a2\ucfec\u3e0b", "\ud9ce\udd5c\u522a\ua269\udb7d\uddbe\udac3\udcaf\ud95f\udebe\udab0\ude8a\uda62\udf78\ud8ff\ude09\udb8f\udd4e\uda66\udd06\ud84e\udcdb\ud8e0\ude5b\udacd\udde5\ud859\udec2\u0e11\uda74\udf96\uda50\udce2\udb32\udcdb\ud949\udc82\udb52\udf70\ud9c3\udfaa\udb78\udda2\uda68\udd68\udb00\udccf",
        8, 27876, 1093710761, -4378407879319671336L, 39209L, true, false, (char) 56530, (char) 50487,
        Double.longBitsToDouble(0x3fd7ea8935d71b22L), Double.longBitsToDouble(0x3fc563357c2a49acL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\0121=java.lang.Integer:4 |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 2, 2, 2, 6, "\ud9d8\udd57\udbd2\udfcb", "\u838d", "\ud910\udd6c\ud80e\udccb\u05c1\ud807\udd2b\ud982\udeb5\ud99c\udceb\udb00\udc48\u3fb8",
        3, 8046, -2144681829, 2467619636573086168L, 26816L, true, false, (char) 42265, (char) 8701,
        Double.longBitsToDouble(0x3fbe0c2d24234808L), Double.longBitsToDouble(0x3fcd04a596b16cc8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Integer:8 |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\0121=new org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException |a0=[I:[[55797, 56923, 55573, 57121, 55597, 57023, 55888, 56733]]\012",
        Z.run(T, 2, 2, 7, 5, "\uda25\ude8b\ud945\udf51\ud95d\udeef\uda80\uddcd", "\u0898\u969f\u20ec\ubccc\u3c9b\u8598\ucc72", "\ud9f8\ude18\udad2\udde6\ud99e\udd12",
        58, 92640, -360674255, -7700574132831257479L, -96796L, false, false, (char) 4961, (char) 27776,
        Double.longBitsToDouble(0x3fd15f665225848cL), Double.longBitsToDouble(0x3fe493b78d72b3b2L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[I:[[42561]] |this=org.apache.commons.math.util.MultidimensionalCounter:[0]\012",
        Z.run(T, 1, 4, 1, 7, "\ua671", "\u2e89\uc9de\u1963\u0898\u97a9", "\ud807\udd2b\ud982\udeb5\ud99c\udceb\ud83b\udf56",
        15, 67757, 1694929890, 4974246233049579260L, -40408L, false, true, (char) 39615, (char) 63289,
        Double.longBitsToDouble(0x3fe028df1878303eL), Double.longBitsToDouble(0x3fc0811343a094b0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=[I:[[10, 0, 3464, 2, 0, 0, 30493, 44607]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 0, 3, 1, "\uda25\ude8b\udada\udf7c\ud8a4\uddd8\ufbbb\ud9f6\udee3\uda3e\udc55\uda4c\ude91\ud8f9\uddab\udb9b\udd24\ud9d9\udff5", "\u25ae\ua675", "\udad2\udde6\ud8ef\uddba\ud962\udef4\udb87\udc9b\ud849\udf8b\ud893\ude82\udafb\udeb6\ud8f4\ude1c\ud862\udf15\udb08\udcf9\udb25\udeb4\uda0b\udf44\uda03\udc28\ud825\udf74\ud83c\udf7d",
        45, 70429, 1455056076, -2236983762976288682L, 91381L, false, true, (char) 59631, (char) 22045,
        Double.longBitsToDouble(0x3fde107147ebfcfeL), Double.longBitsToDouble(0x3fb1857d6f151510L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:251415651 |a0=[I:[[15022, 8380, 6489, 51366, 8416, 39547, 42565, 35859]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 1, 0, 6, "\uda25\ude8b\udada\udf7c\ud8a4\uddd8\ufbbb\ud9c8\udde3", "\u3ade\u20ec\u1989\uc8d6\u2110\u9aab\ua675\u8c43", "\udb07\udcc1\uda7a\udd00\ud9e6\udfb6\uda9a\udeec",
        8, 39593, -1412006126, 3509559915353608312L, 49736L, false, true, (char) 27776, (char) 30586,
        Double.longBitsToDouble(0x3fd12c2464732592L), Double.longBitsToDouble(0x3fbcacec88a15850L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=[I:[[19418, 932064, 44739242, -2147483634]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 0, 3, 0, "\000\000\000\000", "\u88e1\ua77a\000\000\000\000\ucc72", "\000\udad2\udde6\uc000",
        46, 75629, -360424902, 18280018804736L, -100000L, false, false, (char) 12078, (char) 27776,
        Double.longBitsToDouble(0x3fd15f665000008cL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[I:[[0, 0, 0, 0, 5, 211, 166, 697]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 0, 3, 0, "\000\000\000\000\ud9b1\udea5\u00da\ud8a5\udcd1\ua77a", "\000\u1043\ucc72\ua675\u072f\000\uc662", "\udb7f\ude02",
        15, 3256, 637992960, -6124755776944209882L, -1973L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd0bd4b5768e2aaL), Double.longBitsToDouble(0x3fe475db08e40326L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NotStrictlyPositiveException\012",
        Z.run(T, 1, 0, 3, 0, "\000\000\000", "\u00da", "\000\000\000\000\ud99c\udceb\ud9bf\udd87",
        14, -1000, 543490046, 211106232532992L, -64111L, false, false, (char) 0, (char) 42265,
        Double.longBitsToDouble(0x3fa3558000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[I:[[0, 0, 1, 0, 0, 173, 6651, 31]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 0, 3, 0, "\ud9b9\udc9b\ua861\000\000\ud9b1\udea5\u00da", "\000\u2071\u42cd\000\ucc72\ua675", "\uda7b\udd4c",
        23, -1000, 1186439640, -2576186319751343902L, -67470L, false, false, (char) 0, (char) 48491,
        Double.longBitsToDouble(0x3fe007f38df7020cL), Double.longBitsToDouble(0x3f76c0088afb3280L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[I:[[2130440, 102261120, 14]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 0, 3, 0, "\000\000E", "\u00da", "\000\000\000\000\ud99c\udceb\ud9bf\udd87",
        14, 73088, 543490046, 211595858804736L, -64111L, false, true, (char) 57431, (char) 42332,
        Double.longBitsToDouble(0x3fe13558000000feL), Double.longBitsToDouble(0x3fe0000006e6712dL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.OutOfRangeException\012",
        Z.run(T, 2, 1, 0, 0, "\ud838\udf08\ud877\udc9b\ud81a\udf3d\u75ac", "\u88e1\u50f6\u00a6\u88bd\000\u43e3\ua60f", "\udb52\udf05\udac3\udd62\uc000\000\udb7f\ude02\uda9a\udeec\u10a0\udabc\ude3d\uda9a\ude0f\uda8b\udcca\u00d8\000\ud833\udffd\udb8f\udd76\ud927\udd2a\udbe8\ude78\000\000\udac3\udda1",
        46, 79712, 1105718799, 7226423560080512731L, -68850L, false, true, (char) 47073, (char) 10096,
        Double.longBitsToDouble(0x3fd6760ebed60268L), Double.longBitsToDouble(0x3fec85b5915b319dL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[I:[[0, 2, 1, 1, 4, 4427, 6361, -2147483613]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 0, 3, 0, "\000\uda77\ude73\000\uac9f\ud930\udf45(\ud8a5\udcd1\udbd4\udf39\udb2e\udfd1\ud86b\udc6a\udab9\udf60", "\u57ee", "\udbe0\udc4e\udb0f\udda9\u00fe\udb7f\ude02\uda7e\udd1b\u10a0",
        35, 93346, 273406736, -5980689155238108553L, 74733L, true, true, (char) 25910, (char) 6042,
        Double.longBitsToDouble(0x3fe7252c3ed52d7bL), Double.longBitsToDouble(0x3fe6e89ba11f1bdbL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[I:[[0, 0, 0, 0, 0, 48]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 0, 5, 0, "\ud97d\udcb1\u6f9e\uda97\udcab\u07ef", "\u908d\u22bd\u25e3\uaaeb", "\udbfc\udc92\ud9bc\udcfa\u072f\ud913\udda8\udac6\udd70\ub44f\ud9f1\udd15\udbfc\udf5a\ud9c5\udf0c\udb60\udd83\udae7\udc22\ud844\udf70\ud98f\udedf",
        48, 34198, 13, 6087511195782617093L, -100000L, false, false, (char) 63, (char) 8938,
        Double.longBitsToDouble(0x3fede565e1010394L), Double.longBitsToDouble(0x3fea38c8fd5c8e0aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[I:[[55269, 56367, 56166, 56794, 55660, 56657, 55911, 57245]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\0121=!org.apache.commons.math.exception.OutOfRangeException\012",
        Z.run(T, 2, 4, 1, 3, "\ud815\udc5f\udb96\ude0a\ud99c\udd81\uda97\udfcd\ud84f\uddb4\ud8f2\uddbd\udb6f\uddc1\ua7bc", "\u27d1\u9d99\u7873\ucb1a", "\uf19c\000\ud92e\udf6a\udb7f\ude02\udbe9\udd8a\ud812\udf2f\udaaa\udc22\ud968\udd14\udbd0\ude59",
        57, 29034, 1734850701, -5834558542096515864L, -47440L, true, false, (char) 8927, (char) 46730,
        Double.longBitsToDouble(0x3fc63f62e6da1580L), Double.longBitsToDouble(0x3fcdbd6b32158f3cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.OutOfRangeException\012",
        Z.run(T, 1, 1, 0, 0, "\uda25\ude05\ud945\udf51\ud967\udfec\uda79\udecd\ud9f1\udea5", "\ua77a\000\000\ua5c6\u8533\uc2a4\ua6a9\u8c0b", "\000\000\udb7f\ude02\uda9a\udeec",
        -4, 39593, -957177057, 8498702499972729635L, 90021L, true, false, (char) 41883, (char) 8134,
        Double.longBitsToDouble(0x3fb9c5e58ede5e38L), Double.longBitsToDouble(0x3fe1a5e94ad0605aL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=[I:[[0, 13, 0, 0, 1, 1, 30301, 51419]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\0121=[I:[[0, 13, 0, 0, 1, 1, 30301, 51419]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 2, 0, 0, 0, "\uda25\ude8b\ud945\udf51\ud95d\udeef\uda80\uddcd", "\u0898", "\u40f6\ud979\udd24\udb39\udcba\udb35\udc58\ud8f1\udca1\udad3\ude30\ud9b0\ude5f\udab9\udeb1\ud99e\udd12\uda7a\udc9e\udb7f\ude02\uda9a\udeec\udaea\ude53",
        20, 74004, 817133094, 8071031588360917972L, 24654L, false, false, (char) 51674, (char) 23460,
        Double.longBitsToDouble(0x3fd9b9b2c2965136L), Double.longBitsToDouble(0x3fec509fbd43c07fL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Integer:-1089863943 |a0=[I:[[41757, 14932, 34405, 6946, 25529, 49081, 15061, 3383]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\0121=new org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException |a0=[I:[[55797, 56923, 55525, 57121, 55597, 57023, 55834, 56754]]\012",
        Z.run(T, 2, 1, 7, 3, "\uda25\ude8b\ud915\udf51\ud95d\udeef\uda4a\udde2\ud97a\udc45\ud905\udc0a\ud8bb\udcb4\ud910\udd6c\ud979\udcc1\u41c3\ud807\udd2b\ud982\udeb5\ud99c\udceb\ud9bf\udd87\ud8ae\udcd5\ud9f8\ude18\udb52\udc06\ud99e\udd71", "\ua34d\u3a84\u8695\u1b52\u63e9\ubfe9\u3b05\u0d67", "\ud919\udf5b\u0815\ud855\udd8b\udb33\udc0b\uda42\udfc0\uda92\udf7c\udbaa\udeb3\uda92\udeac\udbf7\udcb7\udb43\uddc8\ud941\udd1a\ud9f0\udfa0\udb15\udc0d\udaa4\udd85\udab9\udf4a\udbb9\udd78\udb0c\udf32\u1863\ud8d3\udcfb",
        40, 20468, -670983972, -9018222794797780373L, 41020L, true, false, (char) 32344, (char) 15637,
        Double.longBitsToDouble(0x3fe521351ba36942L), Double.longBitsToDouble(0x3fadbdedb7bfb580L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=[I:[[0, 0, 0, 2, 26, 3180, 1002]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 0, 0, 0, "\uda25\ude8b\ud945\udf51\ud95d\udeef\u04c9", "\u4aa8", "\u40f6\uf96a\ud982\udeb5\uda26\udce7\udbc8\udd0b\ud808\ude1b\udb26\ude91\udaca\udef9\ud99e\udd12\uda7a\udd00\udb7f\ude02\ud939\uddc0\ud9a7\udc93",
        34, 72403, -1187709209, -4064512701198132833L, -5659L, true, false, (char) 49336, (char) 53809,
        Double.longBitsToDouble(0x3fd56eca5c0b1866L), Double.longBitsToDouble(0x3fed4cfddf82389cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=[I:[[0, 0, 38]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 0, 1, 3, "\uda25\ude8b\u7841", "\u4e5c", "\ud910\uddc7\ud979\udcc1\ud8b1\ude67\udacc\udc1b\ud989\udd1d\ud985\udfb4",
        38, 44415, -111738243, 1590725811209131648L, -4865L, false, false, (char) 62288, (char) 57890,
        Double.longBitsToDouble(0x3fde8252c69cccf4L), Double.longBitsToDouble(0x3fe10e2f631bd48dL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException |a0=[I:[[55691, 56818, 55895, 56295, 55499, 56968, 55461, 57143]]\0121=new org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException |a0=[I:[[55691, 56818, 55895, 56295, 55499, 56968, 55461, 57143]]\012",
        Z.run(T, 2, 7, 7, 0, "\ud9bb\ude22\uda87\udc17\ud8fb\udeb8\ud8d5\udf67\ud92d\udc36", "\u3323\u15d3", "\ud8e5\udfa7\ud99c\udceb\ud9bf\udd87\ud880\ude2e\ud83f\uddbc\udba5\ude9b\ud9c9\udf17\uda79\udd54\udbe3\uddb9\uda9a\udeec\uda66\udca1\udadd\udf7e",
        15, 42246, 144314488, 2678611320104962280L, -59150L, false, true, (char) 690, (char) 35203,
        Double.longBitsToDouble(0x3fba815eecb15ec8L), Double.longBitsToDouble(0x3fe82b713cd089dbL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.OutOfRangeException\012",
        Z.run(T, 1, 1, 2, 5, "\uda2d\udff9\ud945\udf51\uda64\ude74\u0c1e\udb29\udde1\ud8bd\udff5\udba5\udf58\ud910\udd09\ud979\udcc1\u40f6\ud807\udd2b\ud982\udeb5\ud99c\udceb\udbca\udc8a\udb36\udcfc\ud9f8\ude08\udad2\udde6\ud99e\udd12\uda7a\udd00\udb7f\ude02", "\u35fa\ua73e\000\uc2a9\u18a4\u07f4\u934e\u94a2\025\u3e0b", "\ud9ce\udd5c\u522a\ua269\udb7d\uddbe\udac3\udcaf\ud95f\udebe\udab0\ude8a\uda62\udf78\ud8ff\ude09\udb8f\udd4e\ud828\ude07\uda33\ude59\ud8e0\ude5b\udacd\udde5\ud859\udec2\u0e11\uda74\udf96\uda50\udce2\udb32\udcdb\ud949\udc82\udb52\udf70\ud9c3\udfaa\udb78\udda2\uda68\udd68\udb00\udccf",
        8, -1000, 1093710761, -4378407879319671336L, 39209L, true, false, (char) 56530, (char) 50487,
        Double.longBitsToDouble(0x3f45126bae364400L), Double.longBitsToDouble(0x3fc5633560000000L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=[I:[[1, 1, 1, 1, 8, 0, 2020, 29700]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 0, 2, 5, "\uda2d\udff9\ud945\udf51\uda64\ude74\u0c1e\udb29\udde1\ud8bd\udff5\udba5\udf58\ud910\udd09\ud960\udec1\u40f6\ud807\udd2b\ud982\udeb5\uda2e\udc54\udbca\udc75\udb36\udcfc\ud9f8\ude08\udad2\udde6\ud99e\udd12\uda7a\udd00\udb7f\ude02", "\u35fa\u0578\u00ca\uc231\u8d74\u070c.\u94a2\ucfec\u3e0b", "\ud9ce\udd5c\u522a\ua269\udb7d\uddbe\udac3\udcaf\ud95f\udebe\udab0\ude8a\uda62\udf78\ud8ff\ude09\udb8f\udd4e\uda66\udd06\ud84e\udc5c\ud8e0\ude5b\udacd\udde5\ud859\udec2\u0e11\uda74\udf96\uda50\udce2\udb32\udcdb\ud949\udc82\udb52\udf70\ud9c3\udfaa\udb78\udda2\uda68\udd68\udb00\udccf",
        8, 27484, 1093710761, 1191182336L, 39008L, true, false, (char) 56530, (char) 50487,
        Double.longBitsToDouble(0x3fd7ea8935d71b22L), Double.longBitsToDouble(0x3f19ab0000000000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=[I:[[55720, 56615, 56226, 57243]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\0121=[I:[[55720, 56615, 56226, 57243]] |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 2, 4, 4, 0, "\ud9d8\udd57\udbd2\udfcb", "\u838d", "\udbd0\udc65\uda28\udeee\ud819\udee3\ud93b\udfe1\ud982\udeb5\ud99c\udceb\udb00\udc48\ud89d\udeff",
        59, 7967, -2146746046, 5349923395585483224L, 85299L, true, true, (char) 34252, (char) 58437,
        Double.longBitsToDouble(0x3fed6fc66c846901L), Double.longBitsToDouble(0x3fcd04a596b16cc8L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.math.util.MultidimensionalCounter:!toString:org.apache.commons.math.exception.DimensionMismatchException\0121=!org.apache.commons.math.exception.OutOfRangeException\012",
        Z.run(T, 2, 2, 0, 5, "\ud9d8\udd57\ud81f\udee7", "\u838d", "\ud910\udd6c\ud9a4\udfc7\u05c1\ud807\udd2b\udbf7\udf2a\ud99c\udceb\udb00\udc48\u3fb8",
        -1, 8046, -2144681829, -4521966985105923624L, 26816L, true, false, (char) 42265, (char) 8701,
        Double.longBitsToDouble(0x3fbe0c2d24234808L), Double.longBitsToDouble(0x3fef412965ac5b32L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.math.util.MultidimensionalCounter:[0]\0121=[I:[[37]] |this=org.apache.commons.math.util.MultidimensionalCounter:[0]\012",
        Z.run(T, 2, 2, 0, 0, "\u978c", "", "\000",
        37, 62754, 25297, -1811939328L, -100000L, false, false, (char) 0, (char) 8599,
        Double.longBitsToDouble(0x3eb5c00000000000L), Double.longBitsToDouble(0x3fe7e40151d8003eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.util.MultidimensionalCounter|getCounts|int|new:org.apache.commons.math.util.MultidimensionalCounter:[I",
    "M|org.apache.commons.math.util.MultidimensionalCounter|getCount|[I|new:org.apache.commons.math.util.MultidimensionalCounter:[I",
    "M|org.apache.commons.math.util.MultidimensionalCounter|getDimension||new:org.apache.commons.math.util.MultidimensionalCounter:[I",
    "M|org.apache.commons.math.util.MultidimensionalCounter|getSize||new:org.apache.commons.math.util.MultidimensionalCounter:[I",
    "M|org.apache.commons.math.util.MultidimensionalCounter|getSizes||new:org.apache.commons.math.util.MultidimensionalCounter:[I",
    "M|org.apache.commons.math.util.MultidimensionalCounter|iterator||new:org.apache.commons.math.util.MultidimensionalCounter:[I",
    "M|org.apache.commons.math.util.MultidimensionalCounter|toString||new:org.apache.commons.math.util.MultidimensionalCounter:[I",
    "C|org.apache.commons.math.util.MultidimensionalCounter|<init>|[I",
    "M|org.apache.commons.math.util.MultidimensionalCounter|getCounts|int|new:org.apache.commons.math.util.MultidimensionalCounter:[I",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
