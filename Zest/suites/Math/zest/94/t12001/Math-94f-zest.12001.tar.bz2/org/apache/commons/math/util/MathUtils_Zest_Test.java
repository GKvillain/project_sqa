package org.apache.commons.math.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class MathUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Long:1307674368000\012",
        Z.run(T, 1, 10, 4, 1, "\udbce\ude8e", "\u05d0\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda26\udfb2\ud875\udc01\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        15, 4663, 380453177, -7949099142619824649L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe4e3cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Long:1307674368000\012",
        Z.run(T, 1, 10, 4, 1, "\ud842\udc08", "\u05d0\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda26\udfb2\ud875\udc01\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        15, 13937, 380453177, -7949099142619824649L, -30062L, true, false, (char) 48925, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe4e3cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ArithmeticException\012",
        Z.run(T, 1, 10, 4, 1, "\udbce\ude8e", "\u6d99\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\000", "\uda26\udee3\ud875\udc01\ud8bf\udec8\ud98f\udca0\ud99e\udd48\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\udb71\udf96\udb9e\uddcf\u15f1\ud850\uddb7\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        53, 4663, 380453177, -7949099142619824649L, 29229L, false, true, (char) 36939, (char) 52061,
        Double.longBitsToDouble(0x3fc87cb5237a2c0cL), Double.longBitsToDouble(0x3fed9be14014c837L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.ArithmeticException\012",
        Z.run(T, 1, 10, 4, 1, "\udbce\ude8e", "\u05d0\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\u0306", "\uda26\udf86\ud875\udc01\ud8bf\udec8\ud98f\udca0\udb14\udf4e\ud88b\udc16\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\udbfe\udc1b",
        28, 77136, -1508544152, -7949099142619824649L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe4e3cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Double:1.020190503780448\012",
        Z.run(T, 1, 7, 4, 1, "\udbce\ude8e", "\u05d0\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\uc301\u46b1\u1896\u338f\u4062\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda26\udfb2\ud875\udc01\ud872\udd01\ud917\udfb6\ud98b\udec9\uda57\uddb3\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        15, 4663, 380453177, -7949099142619824649L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe473cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Long:-7949099142618719799\012",
        Z.run(T, 1, 1, 4, 1, "\udbce\ude8e", "\u05d0\u432b\ua3d9\u0bae\ua405\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\u9845\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc2b0\u50ec\u8f59\uba57", "\uda26\udfb2\ud875\udc01\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud876\udf2f\ud983\udd99\udb1d\udf4c\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\udbdb\udffd\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        15, 4663, 380453177, -7949099142618755273L, 35474L, true, false, (char) 65459, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe4e3cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Long:1307674368000\012",
        Z.run(T, 1, 10, 4, 1, "\udbce\ude4b", "\u05d0\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u6db1\u1896\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda26\udfb2\ud875\udc01\ud8f9\uddb9\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\ud90d\udccd\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud897\udc7f\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        15, 4663, -894615239, -7949108424044151305L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe4e3cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Long:6\012",
        Z.run(T, 1, 10, 4, 3, "\udbce\ude8e\ud9b6\udfc4\udad6\udd86\ud86d\udf65\udabf\udcc4\u8344\ud8f4\udfaa\ud8fa\udda7\ud862\udeb4\udb30\ude1d\u1657\ud9c2\udda2\ud962\ude56\ud9f1\udca1\udb07\udeb3\ud985\udf91", "\u58bc\u7712\u3a86\u46b1", "\udad2\uddf4\udaf5\udf1c\ud982\udfb1\uda76\uddff\udbd4\udd67\uda29\udea5",
        3, 94044, 145130291, 270387020859273733L, -8442L, true, false, (char) 53093, (char) 13230,
        Double.longBitsToDouble(0x3feeb0eb6681b111L), Double.longBitsToDouble(0x3fd2a0780ab42290L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Long:120\012",
        Z.run(T, 1, 10, 4, 1, "\udbce\ude47\ud9b6\udfc4\udae4\udf4a", "\ua3d9\u0bde\u2c42\ub968\u7305\u7143\u953a\u9670", "\ud985\udf20\ud8d8\udfca\udac4\udeec\ud97e\udfa5\uda35\udd40\ud910\uddc7\udae6\udc04\ud8d7\ude01\udbf5\udf48\udad2\uddf4",
        5, 24663, -1557459091, -8220159892479157715L, 63377L, false, true, (char) 55777, (char) 5367,
        Double.longBitsToDouble(0x3fc152e95370af88L), Double.longBitsToDouble(0x3fe8e455d8717ccaL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 4, 1, "\udbce\ude8e", "\u05d0\u432b\ua3d9\u0bde\u2c42\ua311\u34f4\u7143\u953a\u9670\u7def\u9075\u2fad\u8da3\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda26\udfb2\ud813\uddd1\udae9\udca3\udb4e\udcad\udb14\udf4a\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud861\udf9a\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud886\udc1d",
        -4, 4663, 380453177, -7949099142619824649L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe4e3cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:459831137 |a0=[D:[[27895.0, 28645.5]]\012",
        Z.run(T, 1, 14, 9, 1, "\uda1e\udffb", "\u05d0\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u10d6\u4698\u35eb\u2e3a\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\udb0b\ude84\ud88f\udda9\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\udbfd\ude7b\udab0\udd3d\u15f1\ud864\udcc9\ud859\ude80\ud8f8\udca2\uda94\udd04\ud976\udf29\uda63\ude36\udbef\udd69\udb15\udd63\ud9c9\udcf7",
        15, 4663, 380453177, -2574158540469404361L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe4e3cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Long:2\012",
        Z.run(T, 1, 10, 4, 1, "\udbce\ude8e", "\u05d0\u432b\ua3d9\u0bde\ube55\u3db7\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u46fc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda26\udfb2\udb2e\udffe",
        2, 91718, -2039764359, -3961398583153104217L, 65210L, true, false, (char) 22053, (char) 28441,
        Double.longBitsToDouble(0x3fbf11311aa9cbc8L), Double.longBitsToDouble(0x3fe2d9be7e7c42c4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Long:-7949099142619789175\012",
        Z.run(T, 1, 3, 4, 1, "\udbe5\udea8", "\ubfba\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u93a3\u9670\u7def\u0714\u3022\u85f6\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\u5673\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda26\udfb2\ud875\udc01\udb83\udd2b\uda18\udc02\udb14\udf4e\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\ud9cb\ude4c\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud86c\ude07\uda8d\udfb9\ud83b\ude7c\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        15, 4663, 380453177, -7949099142619824649L, 35474L, true, false, (char) 33658, (char) 6350,
        Double.longBitsToDouble(0x3fc9adb587725164L), Double.longBitsToDouble(0x3fe4e3cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 4, 1, "\udbce\ude8e", "\u05d0\u97b2\u22f5\u0bde\u2c42\u34f7\u9e06\u7143\u953a\u9670\u7def\u3b76\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda26\udfb2\ud875\udc01\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb91\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\ud960\udf51\ud904\ude1a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud97b\uddab\uda94\udd04\udbe5\udd53\ud99c\udeeb\ud8e3\udffb\udafb\uddbe\ud9d6\udf86",
        15, 4663, 380453177, -7949099142619824649L, 35474L, true, false, (char) 33658, (char) 51661,
        Double.longBitsToDouble(0x3fe983b9510cec57L), Double.longBitsToDouble(0x3fe4e3cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 11, 2, "\udbce\ude8e", "\u05d0\u432b\u71a8\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u46b1\u720c\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda26\udfb2\ud875\udc01\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        15, 4663, 380453177, -7949099142619824649L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe4e3cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Long:5355420346019621728\012",
        Z.run(T, 1, 1, 4, 1, "\udbce\ude8e", "\u05d0\u218a\uce51\uc5eb\ub841\ub8e7\u9e47\u7143\u0ca3\u95d8\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u7c18\u4c88\u3346\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\u08c7", "\uda26\udfb2\ud875\udc01\ud8bf\udec8\ud98f\udca0\uda80\udd82\uda57\uddbc\u57cc\ud887\ude69\udaf8\ude28\udb23\udc22\udb56\udf14\ud8e0\udd0f\udb4f\ude57\ud9c6\udf1b\ud973\ude1c\udbed\ude9f\ud9ca\udd0d\udb7f\udc61\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\ud9da\udf49\uda23\udc43\ud822\udd16\uda98\udc37\ud829\udd89\ud8ee\udf92",
        15, 19903, 203690786, 5355420346019595058L, 26670L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fef321e31dc56d1L), Double.longBitsToDouble(0x3fe4e3cd79ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:1\012",
        Z.run(T, 1, 0, 0, 0, "\udbce\ude8e", "\000\000\000\000\000\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda26\udfb2\ud875\udc01\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\u00a7\ud876\udf2f\ud873\udef2\udacf\ude04\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        15, 4663, 380453177, -7949099143287243273L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3ec5e00000000000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 13, 1, "\udbce\ude8e\ud9b6\udfc4\udad6\udd86\ud86d\udf65\udabf\udcc4\ud864\udf84\udb4a\udd09\ud8fa\udda7\ud862\udeb4", "\u953a\u9670\u7def", "\ud8d8\udfca\ud883\ude35\ud97e\udfa5\uda35\udd40",
        52, 38757, 1105272189, 8974574485855330568L, -72065L, true, true, (char) 50185, (char) 26649,
        Double.longBitsToDouble(0x3fe2325eed1dfffcL), Double.longBitsToDouble(0x3f8d2fb073ece640L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:2\012",
        Z.run(T, 1, 0, 4, 1, "\udbce\ude8e", "\u05d0\u432b\ua3d9\u0bde\u2c42\u81b4\u9dde\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u462c\u1896\u338f\u0909\000\000\000\000\000\000", "\uda26\udee3",
        12, 25822, -290888282, -8760721214373738246L, -30410L, true, false, (char) 7338, (char) 72,
        Double.longBitsToDouble(0x3fe0fbb57650bfd5L), Double.longBitsToDouble(0x3fe87640587c44c4L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Long:1307674368000\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 4, 1, "\udbce\ude8e", "\u05d0\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u9842\ucd2c\ub4ac\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda14\udc68\ubbcf\ud8c9\udf00\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\udab7\udde3\ud8f6\udc3e\udbc3\udf88\udb4c\udf03\udae3\udc1f\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\ud987\uddd0\ud823\udc03\ud820\udfc5\ud8e0\udd6d\uda94\udd04\uda23\udc43\ud9c6\udc52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        15, 4663, 380453177, -7949099142619824649L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fee6b6d646a172aL), Double.longBitsToDouble(0x3fe78c79c0dd14b0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Long:-7949099142619789175\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 4, 1, "\udbce\ude8e", "\u1112\u4277\u2a6a\u0b8f\u2c42\ub968\u9e47\u7143\u37e5\u44b6\u7def\u0714\u8d5b\u5965\u5ffe\u58bc\u7712\u5cfd\u46b1\u1896\u338f\ub05c\u646b\ucbd3\uc246\u50ec\uc417\ua241", "\uda26\udfb2\ud875\udc01\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9a9\udedd\u20a5\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\ud8cc\uddae\ud904\ude4a\udaac\udd6f\ud9a9\ude4f\udbb1\udffa\udb4b\ude22\u93d6\ud872\udc31\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        15, 4663, 380453177, -7949099142619824649L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb59f715b44L), Double.longBitsToDouble(0x3fc9edd5e02d5cb0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Byte:1\012",
        Z.run(T, 1, 15, 4, 1, "\udbee\udc8e", "\u05d0\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u7cb3\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\u31eb", "\uda26\udfb2\ud875\udc01\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\uda7a\udf79\uda20\ude18\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86\udaf1\udef1",
        28, 86177, -1850793870, 2866679660526992530L, 52159L, false, true, (char) 26318, (char) 26233,
        Double.longBitsToDouble(0x3fddc56d1d38f35eL), Double.longBitsToDouble(0x3fc5d155ef702b58L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 14, 2, 12, "\uda90\udf4d\ud9b6\udfc4\udad6\udd86\ud9a7\udf62\udabf\udcc4\u8344\ud8f4\udfaa\ud8fa\udda7\ud862\udeb4\udb32\udd5a\u1657\ud9c2\udda2\ud962\ude56\ud9f9\udc84\udb07\udeb3\ud985\udf91\ud8d8\udfca", "\u7712\u3a86\u8406", "\udad2\uddf4\udaf5\udf1c\ud982\udfb1\uda76\uddff\udbd4\udd67\udb7e\udf56",
        28, 66873, 0, -7472174369298353546L, -8442L, true, false, (char) 52986, (char) 13230,
        Double.longBitsToDouble(0x3fe2c0eb63cfee88L), Double.longBitsToDouble(0x3fd2a0780ab42290L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:1\012",
        Z.run(T, 1, 0, 0, 1, "\udbce\ude8e", "\u6d99\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u00fc\u76d2\u3a86\u46b1\000\000\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\000", "\uda26\udee3\ud875\udc01\udaa7\udebc\ud98f\udca0\ud99e\udd48\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\udb71\udf96\udb9e\uddcf\u15f1\ud850\uddb7\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        53, 4663, 380453177, -7949099143274136073L, 29229L, false, true, (char) 31307, (char) 0,
        Double.longBitsToDouble(0x3fc87cb5237a2c0cL), Double.longBitsToDouble(0x3fed9be14014c837L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Integer:51875\012",
        Z.run(T, 1, 2, 2, 1, "\udbce\ude8e\ud9b6\udfc4\udad6\udd86\ud871\udf67\udabf\udcc4\u8344\ud8f4\udfaa\ud8fa\udda7\ud862\udeb4\udb30\ude1d\u1657\ud9c2\udda2\ud962\ude56\udbcf\udc8c\ud8dd\udcea\ubd90\udaa5\udf34\ud873\udf76\ub01c\uda35\udd40\ud8c1\udceb\uda28\ude9a\uda4b\ude83\udbf5\udf48\udad2\uddf4\ud9a8\ude85\ud98d\udc6c\uda76\uddff\udbd4\udd67\uda29\udea5\000\uda89\udef9\u3bc7\ud9f2\ude4c\ud87a\ude01\uda27\udc1d\ud9a8\udfe5\ud99e\udd48", "\u8248", "\ud9e1\udced\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud8c7\ude07\ud8df\udc75\ud9a2\udc10\udb9e\uddcf\ud805\udddf\ud9ec\udd93\udb17\udf21\ud8f8\udca2\uda94\udd04\ud877\udcad\uda9e\udd69\ud9b7\udcf1\ud920\udc99",
        15, 51860, 109349724, 3530886691813269618L, -68065L, false, false, (char) 45663, (char) 33658,
        Double.longBitsToDouble(0x3fe29083e0cd6dacL), Double.longBitsToDouble(0x3fddc56d1d38f35eL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:6\012",
        Z.run(T, 1, 0, 4, 1, "\u324e", "\uc127\000\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544", "\ufdff\ud85a\udc33\ud854\udea9",
        24, 66954, 263250184, 7913115522605280543L, -100000L, true, true, (char) 38872, (char) 33023,
        Double.longBitsToDouble(0x3e3c70d188000000L), Double.longBitsToDouble(0x3fda636c40000152L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Byte:1\0121=java.lang.Double:160.33112821663093\012",
        Z.run(T, 2, 15, 12, 6, "\udbce\ude8e", "\u6d99\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\u5913\ua9ad\uc246\u50ec\uc417\000", "\uda26\udee3\ud875\udc01\ud8bf\udec8\ud98f\udca0\ud99e\udd48\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\udb71\udf96\udb9e\uddcf\u15f1\ud850\uddb7\ud859\ude80\ud838\udda2\udbf8\udfc9\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        53, 4663, 380453177, -7949099142619824649L, -38866L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe4e3cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Long:-6635975519367423615\012",
        Z.run(T, 1, 1, 4, 1, "\u6915", "\u6d99\ub586\u355c\u0bde\u2c42\ub968\u9e47\u7143\u953a\u07f2\ubd60\u7232\u3022\ub544", "\uda35\udd40\ud85a\udc33\ud854\udea9\udb4b\ude9d\udbf5\udf48",
        49, 73780, 1870949663, -6635975519367323615L, -100000L, true, true, (char) 38872, (char) 33023,
        Double.longBitsToDouble(0x3fe3b4c26b8e1a31L), Double.longBitsToDouble(0x3fda636c40f3dd52L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Integer:8\012",
        Z.run(T, 1, 0, 0, 1, "\udbce\ude8e", "\000", "\ud8f4\udfaa",
        40, 82552, -652993431, -324762083484381028L, 10829L, true, true, (char) 43274, (char) 37208,
        Double.longBitsToDouble(0x3f304f7fe3283800L), Double.longBitsToDouble(0x3fea05b31014de19L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Integer:18\012",
        Z.run(T, 1, 0, 4, 1, "\udbce\ude8e", "\uc127\u423f\ua3d9\u0bde\u9609\000\000\000\u0426\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\000", "",
        18, 97182, 918823822, -1297036694729523079L, -100000L, true, false, (char) 22053, (char) 28441,
        Double.longBitsToDouble(0x3fbf11311aa9cbc8L), Double.longBitsToDouble(0x3fe2d9be7e7c42c4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Byte:-1\012",
        Z.run(T, 1, 15, 2, 1, "\ud945\ude03\ud9da\uddee\ud873\udc21\ud936\ude09\udac0\udd43\u8344\ud8f4\udfaa\ud8fa\udda7\ud8e4\udeb5\uda6a\udf5a\ud9b6\ude36\ud883\udc14\ud81a\udce4\ud9f1\udd39\ud97d\udcea", "\u5ffe\u58bc\u7712\u3a86\u46b1", "\udad2\uddf4\udaf5\udf1c\ud982\udfb1\uda76\uddff\udbd4\udd67\uda29\udea5",
        -5, 66789, 0, -7472174369298380170L, -8442L, true, false, (char) 52986, (char) 13230,
        Double.longBitsToDouble(0x3feeb0efe681b111L), Double.longBitsToDouble(0x3fec681c07a517c0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Integer:5\012",
        Z.run(T, 1, 0, 4, 1, "\udbce\ude8e", "\u1ca8\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022;\u5ffe\u58bc\u7712\uc301\u46b1\u32bf\u07a6\000\u0130\ua94a\uc246\u50ec\ud311\ua241", "\uda26\udfb2\ud875\udc01\ud872\udd01\ud917\udfb6\ud98b\udec9\uda57\uddb3\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbd4\udf49\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\udb0c\udf37\000\udac0\udd87\ud815\udda1\ud8dd\udd69",
        -5, -1000, 369098752, -7949099142619824649L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe473cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Double:2.6313083693369503E35\0121=java.lang.Long:7279893153721825581\012",
        Z.run(T, 2, 11, 1, 14, "\udbce\ude8e", "\u05d0\u432b\ua3d9", "\ud862\udeb4\udb30\ude1d\u1657\ud9c2\udda2\ud962\ude56\ud9f1\udca1",
        32, 52437, -875063310, 7279893153721790460L, 35121L, true, true, (char) 26636, (char) 22943,
        Double.longBitsToDouble(0x3fde57c8c1481f32L), Double.longBitsToDouble(0x3fd1f6dd1edadf08L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Double:1.063005325308314\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 4, 1, "\udbce\ude8e", "\u05d0\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\uc301\u46b1\u1896\u338f\u4062\ua2cb\ua94a\uc246\u50ec\uc417\u2c08", "\uda26\udfb2\ud875\udc01\ud91d\ude38\ud917\udfb6\ud98b\udec9\udb95\ude11\udb1b\udf25\udb82\udc87\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05",
        51, 90814, -1747394719, -907467977730586871L, -31597L, true, true, (char) 48016, (char) 2784,
        Double.longBitsToDouble(0x3fd699e095c5c008L), Double.longBitsToDouble(0x3fefba275939d0adL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Double:1.0073726902791569\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 7, 8, 1, "\ud90e\udf4f", "\u05d0\u432b\u7581\u301e\u2be8\ub968\uc93e\u273b\u953a\u968e\u7def\u0714\u3022\ub544\u97f9\u57ce\u7712\uc301\u46b1\u1896\u474b\u3fb3\u7a7f\u21d0\uc246\u96dc\u6d91\ua2c5", "\ud8f1\uddd7\udb6d\ude38\ud872\udd01\ud917\udfb6",
        23, 97009, 493644455, -5687747442468962687L, -15046L, false, true, (char) 58665, (char) 60952,
        Double.longBitsToDouble(0x3fbf11311aa9cbc8L), Double.longBitsToDouble(0x3fe2d9be7fa6c6fcL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Long:0\012",
        Z.run(T, 1, 4, 4, 6, "\udbce\ude61\ud9b6\udfc4", "\u432b\ua3d9\u0b47\ua405", "\udb84\udcd7\ud9a1\udfd9\ud962\ude56\uda6f\udec0\ud89a\uddfe\ud985\udeca",
        35, -791, -1235046404, -2442693449052297196L, -21473L, false, true, (char) 4153, (char) 37513,
        Double.longBitsToDouble(0x3fd1f6dd1faedf08L), Double.longBitsToDouble(0x3fa0d1f422d8dec0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Long:-7949099142618719799\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 6, 1, "\udbce\ude8e", "\u05d0\u432b\ua3d9\u312a\ua441\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\u9845\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\u946e\ua25a\ua94a\uc2b0\u50ec\u8f59\uba57", "\uda26\udfb2\ud875\udc01\ud993\udc93\udac6\udffe\udae7\ude73\uda6d\udc6c\udb93\udc62\udbfc\udd31\ud837\udfac\udb1d\udfb0\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\ud839\udee4\udb41\uded8\udbdb\udffd\ud8df\udc75\ud8ee\udfa9\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        -3, 4663, 380453177, -7949099142618755273L, 35474L, true, false, (char) 65459, (char) 46229,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe4e3cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[28111.0, 28463.0]] |a1=[D:[[720.0, 8573.5, 20948.5, 1471.0, 20970.5, 23708.0, 20235.5, 27415.0]]\012",
        Z.run(T, 1, 9, 1, 1, "\udbce\ude8e", "\u05d0\u432b\ua3d9\u0bae\ua405\ub968\u9e47\ud65e\u953a\u9670\u7def\u0714\u3022\u9845\u5ffe\u58bc\u7752\u3a86\u46b1\u1896\u338f\ub270\ub52b\ua94a\uc2b0\u50ec\u8f59\uba57", "\uda26\udfb2\ud875\udc01\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud876\udf2f\ud983\udd99\udb48\udc01\ud9e9\udee0\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\udbdb\udffd\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        54, 74252, 1968873388, -7949099142618755273L, 35474L, true, false, (char) 65459, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe4e3cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[28111.0, 28429.5]]\012",
        Z.run(T, 1, 9, 7, 1, "\udbce\ude4b", "\u05d0\u0a47\uaedc\u740f\u0ae7\ub968\u9e47\u7143\uc61d\u3e25\u7def\u0714\u3022\ub544\u5ffe\u9463\u7712\u3a86\u6db1\u1896\u810c\ub3a0\ua2cb\ua94a\uc246\u0ce6\ub646\ua241", "\ud913\udd0d\ud875\udc01\ud8f9\uddb9\ud98f\udca0\u5876\uda83\ude30\udb93\udc62\ud876\udec9\ud873\udef2\ud9fd\udee5\ud97b\ude4b\udb7a\udc3f\udb4c\udf61\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\udbe2\udd89\ud8de\udfec\uda20\uddee\ud91c\udd53\uda10\udf02\ud9c6\ude8d\ud897\udc7f\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\udb08\udec7\udaab\udfe3",
        27, 4663, -894615239, -7949108424044151305L, 26670L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe4e3cd78cb8dafL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[28125.5, 28511.0, 27843.0, 28618.0]] |a1=[D:[[20653.0, 20948.5]]\012",
        Z.run(T, 1, 9, 4, 1, "\udbeb\udeee\ud9b6\udfc4", "\ua18a\ua3d9", "\ud90d\ude5a\uda4f\udfca\u1657\ud9c2\udda2\ud9cc\ude4b\ud9f1\udca1\ud8b4\udc06\ud985\udf1c\udbe0\udfce\ud883\ude35\ud97e\udfa5\uda35\udd40\ud85a\udc33\ud85e\udeae\ud80c\udcfc\uda04\ude19\udad2\ude24\udaf5\udf1c\ud99c\udcb1\uda76\uddff",
        51, 27509, -492541370, -7445435321973928946L, 67306L, true, true, (char) 9168, (char) 140,
        Double.longBitsToDouble(0x3fcf50cd669d090cL), Double.longBitsToDouble(0x3fd9a8fc9aba0d98L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Integer:1076756511 |a0=[D:[[15.0]]\012",
        Z.run(T, 1, 14, 9, 1, "N", "", "",
        21, 17453, -1152889420, 1452694020598013033L, 43204L, false, false, (char) 37393, (char) 0,
        Double.longBitsToDouble(0x3e4fc80000000000L), Double.longBitsToDouble(0x3fb0504f7fe32838L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:459831137 |a0=[D:[[27895.0, 28645.5]]\0121=java.lang.Boolean:false |a0=[D:[[27895.0, 28645.5]] |a1=[D:[[720.0, 27304.0, 20948.5, 1495.0, 5641.0, 23708.0, 20235.5, 14473.5]]\012",
        Z.run(T, 2, 14, 9, 1, "\uda1e\udffb", "\u05d0\ud580\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u401b\u965d\u7def\u0714\u3022\ub544\u5ffe\u58bc\u8294\ua7ba\u4650\u35eb\u2e3a\ub3a0\ua2cb\ua94a\u5d8a\u136b\uc417\ua241", "\udb0b\ude84\ud88f\udda9\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud82c\udc6a\udbac\udd12\ud9c9\udcaf\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\uda7d\udd26\ud904\ude2b\ud91a\udf05\ud8df\udc75\udbfd\ude7b\udab0\udd3d\u15f1\ud864\udcc9\ud859\ude80\ud8f8\udca2\uda94\udd04\ud976\udf29\uda63\ude36\udbef\udd69\udb15\udd63\ud9c9\udcf7",
        15, 4663, 380453177, -2574158540469404361L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe4e3cd7e8e8aafL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false |a0=[D:[[27895.0, 28645.5]] |a1=[D:[[720.0, 8573.5, 20948.5, 6535.5, 5641.0, 23708.0, 20235.5, 14473.5]]\012",
        Z.run(T, 2, 8, 9, 1, "\uda1e\udffb", "\u05d0\u432b\ua3d9\u333f\u2c42\ub968\u9e47\u7143\u953a\u95a1\ubf48\u0714\u3022\ub464\u5ffe\u58bc\u7712\u10d6\u2907\u28ec\u2e3a\ub3a0\ua2cb\ua94a\ub991\u071d\u858f\u58b6", "\udb0b\ude84\ud88f\udda9\ud8bf\udec8\ud913\udd42\udb14\udf4e\uda57\uddbc\udbbd\udd17\ud89f\udcaa\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb89\ude3c\ud9c6\udf1b\ud838\udfdf\uda6f\udce1\ud904\ude4a\ud91a\udf05\udbed\udc7c\ud8da\udc82\udab0\udd3d\udba1\udcd4\ud880\ude12\ud859\ude80\ud8f8\udca2\uda94\udd04\ud893\udc77\uda63\udf1b\udbef\udd69\udb15\udd63\ud9c9\udcf7",
        15, 4663, 380453177, -2574158540469404361L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb59dfd1344L), Double.longBitsToDouble(0x3fe4e3cfb8ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Integer:-1305594207 |a0=[D:[[27895.0, 28645.5, 27843.0, 28618.0, 27987.0, 28331.0]]\0121=java.lang.Boolean:false |a0=[D:[[27895.0, 28645.5, 27843.0, 28618.0, 27987.0, 28331.0]] |a1=[D:[[20948.5, 6844.5, 23787.5, 23708.0, 20235.5, 14473.5, 19645.5, 7893.0]]\012",
        Z.run(T, 2, 14, 9, 1, "\uda1e\udffb\ud9b6\udfc4\udad6\udd86", "\ua3d9\u35a9\uba07\ub968\u9e47\u7143\u99ab\u3dda", "\ud985\udf91\udbd2\udee7\ud883\ude77\ud892\udcaf\uda35\uddf2\udb2f\udc7d\ud854\ude90\udacd\udc7e\ud7a5\udad2\uddf4\udae0\ude93\udab6\udfb6\uda76\uddff\udbd4\udd67\uda29\udea5\udb1a\ude45\uda89\udef9",
        57, 43639, -1754434188, 3946317767768630694L, 12390L, true, false, (char) 1919, (char) 1581,
        Double.longBitsToDouble(0x3fd2a0780b35520cL), Double.longBitsToDouble(0x3fe71deae650bfd5L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Long:0\012",
        Z.run(T, 1, 4, 11, 2, "\udbce\ude8e", "\u05d0\u432b\u71a8\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u46b1\u720c\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda26\udfb2\ud875\udc01\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\ud906\udd2b\ud929\udea6\udbcb\udebe\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        15, -113, 239738169, -7949099271468843529L, 35474L, true, false, (char) 33658, (char) 60110,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe4e3cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Integer:9497\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 6, 8, "\udbce\ude8e", "\u05d0\u218a\uce51\uc5eb\ub841\ub8e7\u9e47\u7143\u0ca3\u95d8\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u7c18\u4c88\u3346\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\u08c7", "\uda26\udfb2\ud875\udc01\ud8bf\udec8\ud98f\udca0\uda80\udd82\uda57\uddbc\u57cc\ud887\ude69\udaf8\ude28\udb23\udc22\udb56\udf14\ud8e0\udd0f\udb4f\ude57\ud9c6\udf1b\ud973\ude1c\udbed\ude9f\ud9ca\udd0d\udb7f\udc61\ud8df\udc75\uda20\uddee\uda92\udf3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\ud9da\udf49\uda23\udc43\ud822\udd16\uda98\udc37\ud829\udd89\ud8ee\udf92",
        50, 9447, 203690786, 5355420346019595058L, 26670L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fef321e31dc56d1L), Double.longBitsToDouble(0x3fe4e3cd79ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Integer:1\012",
        Z.run(T, 1, 0, 0, 0, "\ud8de\uded1\udaa7\udc21\udbdd\udff5", "\000", "",
        19, 15377, -962648479, 7616984960654966123L, 31183L, true, true, (char) 37208, (char) 41342,
        Double.longBitsToDouble(0x3fefe3283f40b662L), Double.longBitsToDouble(0x3f94de19f0a04200L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Integer:1\012",
        Z.run(T, 1, 0, 0, 0, "\udbce\ude8e\ud9b6\udfc4\udad6\udd86\000\000\000", "", "\ud935\udfee",
        31, 74873, -695578861, 8725160851224801269L, 43552L, false, false, (char) 10645, (char) 26636,
        Double.longBitsToDouble(0x3fef920d69087c8cL), Double.longBitsToDouble(0x3fc481f6147db744L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 0, 0, "\udbce\ude8e", "\000\000\000\000\0009\ub919\u70f4\u953a\u309a\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\uaf01", "\uda26\udfb2\ud875\udc01\ud8bf\udec8\udbfa\ude75\udb14\udf0d",
        -2, -833, -1324281898, 540500679354160384L, -97921L, false, false, (char) 28185, (char) 3554,
        Double.longBitsToDouble(0x3fd5d61791a50c6eL), Double.longBitsToDouble(0x3fef5216249f4cfaL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 0, 0, 0, "\udbce\ude8e", "\000\000\000\000\000\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda26\udfb2\ud875\udc01\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\u00a7\ud876\udf2f\ud873\udef2\uda3f\udc7c\udbc6\udfb0\udb8c\udd6b\udbca\udf32\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        15, 4663, 380453177, -7949099143287243273L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3ec5e00000000000L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Integer:29102\012",
        Z.run(T, 1, 0, 15, 1, "\udbce\ude8e", "\u05d0\u432b\ua3d9\u0bde\u2c42\u81b4\u9dde\u7143\u953a\u9670\u7def\u0714\u3022\u4658\u5ffe\u58bc\u7712\u3a86\u462c\u1896\u338f\u0909\u6929\000\000\000\000\000", "\uda26\udee3\ud875\udc01\ud8bf\udec8\ud98f\udca0\udb01\udf89\uda57\uddbc",
        0, 29102, 125845121, 20289470379982848L, 59445L, false, true, (char) 41409, (char) 64897,
        Double.longBitsToDouble(0x3fbfa495a8e81280L), Double.longBitsToDouble(0x3fd1cf90c74261daL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 15, 6, "\udbce\ude8e\ud9b6\udfc4\ud9fd\udd73\ud86d\udf65\udabf\udcc4\u8344\ud8f4\udfaa\ud8fa\udda7\ud986\udd86\udb38\udeb4\u1657\ud919\udece\uda1b\udc95\ud972\ude5c\udb07\udeb3\udb23\udc40\udb3d\ude9b", "\u16c7\u58ee\u3908\u17f6", "\000\000",
        -5, -1000, 3866624, 0L, -1440L, false, false, (char) 15807, (char) 40042,
        Double.longBitsToDouble(0x3fe3cf7548fa866bL), Double.longBitsToDouble(0x3fe107f33fd61d6cL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Integer:1\012",
        Z.run(T, 1, 0, 4, 1, "\u0501", "\u05d0\u432b\u07eb\u53b1\u2c42\u81b4\u375d\u70eb\ua078\u39b1\u055a\u069c\u3022\uadc2\u1072\u58bc\u7712\u3a86\u462c\u1896\u338f\u0909\000\000\ud622t\ud01d\u8d72", "\uda26\udee3",
        31, 3041, -290888282, 7375986978299388733L, 91039L, true, false, (char) 7338, (char) 72,
        Double.longBitsToDouble(0x3fe0fbb57450bfd5L), Double.longBitsToDouble(0x3fe87320a70ea8c4L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Long:1307674368000\0121=java.lang.Double:1.307674368E12\012",
        Z.run(T, 2, 10, 11, 10, "\udbce\ude8e", "\u05d0\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u79da\u9598\u9670\u7def\u9842\ucd2c\ub4ac\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda14\udc68\ubbcf\ud8c9\udf00\ud98f\udca0\udb14\udf4e\uda57\uddbc\ud807\udd61\uda0d\udfbd\ud9c9\udeeb\udab7\ude73\ud8f6\udc3e\udbc3\udf88\udb4c\udf03\udae3\udc1f\udb55\uddd0\ud971\ude76\ud835\udec9\ud91a\udee7\ud8df\udc75\ud984\udc76\udae2\ude49\ud988\udfff\ud822\udfd3\ud820\udfc5\ud8e0\udd6d\ud8cc\udd00\uda23\udc43\ud9c6\udc52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        15, 4663, 380453177, -7949099142619798281L, 35474L, true, false, (char) 33658, (char) 3278,
        Double.longBitsToDouble(0x3fec7c96ec01604fL), Double.longBitsToDouble(0x3fe78c79c0dd14b0L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27963.5, 28341.5, 27843.0, 28618.0, 27987.0, 28331.0, 27678.5, 28570.5]] |a1=[D:[[20235.5, 14473.5, 19077.0, 19232.0, 16095.5, 19465.0, 26238.0, 23102.0]]\0121=java.lang.Integer:-1855585215 |a0=[D:[[27963.5, 28341.5, 27843.0, 28618.0, 27987.0, 28331.0, 27678.5, 28570.5]]\012",
        Z.run(T, 2, 9, 14, 1, "\udaa7\udd9b\ud9b6\udfc4\udad6\udd86\ud86d\udf65\udabf\udcc4\u8344\ud8f4\udfaa", "\u9e47\u7143\u953a\u9670\u7def\u9842\ucd2c\ub4ac\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb", "\udbd4\udd67\uda29\udea5\udb1a\ude45\uda7d\uddf9\ud941\udf8d\uda14\udc68\ubbcf\ud8c9\udf00\ud98f\udca0\udb14\udf4e\ud8ca\udf12\udb93\udc62\ud876\udf2f\ud873\udef2\udab7\udde3\ud8f6\udc3e\udbc3\udf88\udb4c\udf03\udae3\udc1f\ud838\udfdf\udbed\ude9e",
        55, 71172, -46414689, -6913377728748527775L, -83141L, false, true, (char) 26501, (char) 13503,
        Double.longBitsToDouble(0x3fe99b558a098a51L), Double.longBitsToDouble(0x3fc45c5dcd9e1de4L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Integer:7235\0121=java.lang.Integer:7235\012",
        Z.run(T, 2, 2, 2, 1, "\udbce\ude8e\ud9b6\udfc4\udad6\udd86\ud871\udf67\udabf\udcc4\u8344\ud8f4\udfaa\ud8fa\udda7\ud862\udeb4\udb30\ude1d\u1657\ud9c2\udda2\ud962\ude56\udbcf\udc8c\ud8dd\udcea\ubd90\udb49\uddc6\ud873\udf76\ub01c\uda35\udd40\ud8c1\udceb\uda28\ude9a\uda4b\ude83\udbf5\udf48\udad2\uddf4\ud9a8\ude85\ud98d\udc6c\uda76\uddff\ud888\udf81\udbf1\udcb2\udb0f\udc9b\uda89\udef9\uda3d\udc34\ud9f2\ude9d\ud87a\ude01\uda27\udc1d\ud9a8\udfe5\ud99e\udd48", "\u8248", "\ud9e1\udced\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud8c7\ude07\ud8df\udc75\ud9a2\udc10\udb9e\uddcf\ud805\udddf\ud9ec\udd93\udb17\udf21\ud8f8\udca2\uda94\udd04\ud877\udcad\uda9e\udd69\ud9b7\udcf1\ud920\udc99",
        15, 7220, 109378548, 3530886690335105138L, -68065L, false, false, (char) 45663, (char) 33658,
        Double.longBitsToDouble(0x3fe29083e0ac0a73L), Double.longBitsToDouble(0x3fddc56d1d38f35eL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Long:-6635975519367227007\0121=java.lang.Long:-6635975519367227007\012",
        Z.run(T, 2, 1, 1, 1, "\u6915", "\u6d99\ub586\u355c\u0bde\u2c42\ub968\u9e47\u7143\u953a\u07f2\ubd60\u7232\u3022\ub544", "\uda35\udd40\ud85a\udc33\ud854\udea9\udb4b\ude9d\udbf5\udf48",
        49, 73780, 1870949663, -6635975519367323615L, 96608L, true, true, (char) 38872, (char) 33023,
        Double.longBitsToDouble(0x3fe3b4c26b8e1a31L), Double.longBitsToDouble(0x3fda636c40f35352L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Long:3950853764334349723\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 12, 11, "\u69b9", "\u6d99\ubdd2\u6606\u0bde\u2c42\ub968\u9e47", "\ud8ad\udc0b\udba7\udf92\ud83e\udd75\ud985\udf91\ud8d8\udfca\udb07\ude3c\u68b1\uda2a\udd0b\ud85a\udc33\ud854\udea9\udb4b\ude9d\udbf5\udf48\udad2\uddf4\udb13\udde4\ud882\uddf6\udbd6\uddcb\ud98e\ude52\udbf0\udc91\u4269\uda89\udef9",
        -5, 5360, 1160373673, 3950853764334314918L, 34805L, false, true, (char) 37563, (char) 32491,
        Double.longBitsToDouble(0x3fd6a27f363af11cL), Double.longBitsToDouble(0x3fe2b12f57a88d51L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Integer:66784\012",
        Z.run(T, 2, 8, 2, 1, "\ud945\ude03\ud9da\uddee\ud873\udc21\udb1f\udf7e\ud921\udcf1\uda7e\ude69\ud8f4\udfaa\ud8fa\udda7\ud8e4\udeb5\uda6a\udf5a\ud999\udef2\ud883\udc14\ud81a\udce4\ud9f1\udd39\ud97d\udcea", "\u5ffe\u58bc\u7712\u644d\u46b1", "\udad2\uddf4\udaf0\ude5b\ud982\udfb1\uda76\uddff\ud8b4\udf4a\uda29\udea5",
        -5, 66789, 0, -7472174369298380170L, -8442L, true, false, (char) 42234, (char) 19997,
        Double.longBitsToDouble(0x3fe109cedfd79ba3L), Double.longBitsToDouble(0x3fef1f9247a517c0L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Integer:8\012",
        Z.run(T, 1, 0, 4, 1, "\udbce\ude8e", "\u1ca8\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022;\u601d\u0416\u63b1\uaadc\u074f\u32bf\u07a6\000\u0130\ua94a\uc246\u1642\ud311\ua241", "\uda26\udfb2\ud875\udc01\ud872\udd01\ud917\udfb6\udafe\udce4\uda57\uddb3\udb93\udc62\ud876\udf2f\ud90d\udddf\udb03\udd61\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\ud85c\udf43\ud904\ude4a\ud91a\udf05\ud977\udfa1\ud807\ude2e\ud80a\udc3c\ud9b9\udd55\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\udb0c\udf37\000\udac0\udd87\ud815\udda1\ud8dd\udd69",
        48, -1000, 369098987, -7949099142619824649L, 99689L, true, true, (char) 33477, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb59f715b44L), Double.longBitsToDouble(0x3fe473cef0ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Integer:5\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 1, "\udbce\ude8e", "\u1ca8\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022;\u5ffe\u58bc\u7712\uc301\u46b1\u32bf\u07a6\000\u0130\ua94a\uc246\u50ec\ud311\ua241", "\uda26\udfb2\ud875\udc01\ud872\udd01\ud917\udfb6\ud98b\udec9\uda57\uddb3\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9eb\udc5f\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbd4\udf49\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\ud896\udf59\ud850\udde2\ud859\ude80\ud8f8\udca2\uda94\udd04\udb0c\udf37\000\udac0\udd87\ud815\udda1\ud8dd\udd69",
        -5, -1000, 369098752, -7949099142619824649L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe473cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Integer:50\0121=java.lang.Long:0\012",
        Z.run(T, 2, 0, 4, 1, "\udbce\ude8e", "\u1ca8\u1caa\u6577\u102a\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\ub208;\u5ffe\u58bc\u7712\uc301\u46b1\u32bf\u07a6\000\u0130\ua94a\uc246\u42df\ud34c\ua241", "\uda26\udfb2\ud875\udc01\ud872\udd01\ud917\udfb6\ud98b\udec9\uda57\uddb3\udb93\udc62\ud876\udf2f\ud809\uddfb\ud904\udc96\ud9f4\uddcd\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbd4\udf49\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\udb0c\udf37\000\udac0\udd87\ud88a\udc52\udb13\udf40",
        50, -1000, 369098752, -7949099145069298185L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe473cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 8, 9, "\ud90e\udf4f", "\u05d0\u432b\u7581\u301e\u2be8\u476f\uc976\u273b\u953a\u968e\u7def\u0714\u3022\ub544\u97f9\u57ce\u7712\uc301\u7d6e\u2cb3\ua8f3\u527b\u7830\u831c\u7b5b\u6513\u362a\u9f2b", "\ud8f1\uddd7\uda60\uded1\uda63\udf84\ud918\udc05",
        23, 97009, 493644455, -5687747442468962687L, -15046L, false, true, (char) 58665, (char) 60952,
        Double.longBitsToDouble(0x3fbf11311aa9cbc8L), Double.longBitsToDouble(0x3fe2d9be78b0c6fcL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Double:1.1495542338343085\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 10, 1, "\udb8f\udfee", "\u05d0\u432b\u7581\u301e\u2be8\ub968\uc93e\u273b\u953a\u968e\u7def", "\ud8d8\udfca\udbc1\ude34\ud97e\udeb7\uda35\udd40",
        -1, 37858, 1101869759, 8974592884848397878L, -51452L, true, true, (char) 50185, (char) 24180,
        Double.longBitsToDouble(0x3fe14a3bc5616735L), Double.longBitsToDouble(0x3f8cf2650222ccc0L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=java.lang.Long:0\012",
        Z.run(T, 2, 4, 4, 6, "\udbce\ude61\ud9b6\udfc4", "\u42c5\u1ded\u3bbe\ua405", "\udb84\udcd7\ud9a1\udfd9\ud855\udd8f\uda6f\udec0\ud89a\uddfe\ud985\udeca",
        35, -791, -1235046404, -2442693447848757484L, 9966L, false, false, (char) 56048, (char) 46939,
        Double.longBitsToDouble(0x3fd21a3e845b1bd8L), Double.longBitsToDouble(0x3feb4341bf5aff01L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 0, 0, 0, "\000", "\u05d0", "\ud859\udd74",
        -1, 82684, -652993431, -324762083484381028L, 10829L, true, true, (char) 43274, (char) 19545,
        Double.longBitsToDouble(0x3fb0504fbfe32838L), Double.longBitsToDouble(0x3fea05b31014de19L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Boolean:false |a0=[D:[[27895.0, 28645.5]]\012",
        Z.run(T, 2, 14, 9, 10, "\uda1e\udffb", "\u05ea\ud580\ua3d9\u0bde\u2c42\u9d69\u9e47\u7143\u401b\u965d\u7def\u0714\u3022\ub544\u5ffe\u58bc\u8294\ua7ba\u4650\u35eb\u2e3a\ub3a0\ua2cb\ua94a\u5d8a\u136b\uc417\ua241", "\udb0b\ude84\ud88f\udda9\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud82c\udc6a\udbac\udd12\ud9c9\udcaf\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\uda7d\udd26\ud904\ude2b\ud91a\udf05\ud8df\udc75\udbfd\ude7b\udab0\udd3d\u15f1\ud864\udcc9\ud859\ude80\ud8f8\udca2\uda94\udd04\ud976\udf29\uda63\ude36\udbef\udd69\udb15\udd63\ud9c9\udcf7",
        15, 15388, 380474290, -2574158540469404361L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe4e78dde8e8aafL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Long:0\012",
        Z.run(T, 1, 4, 11, 2, "\udbce\ude8e", "\u05d0\u432b\u71a8\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u46b1\u720c\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda26\udfb2\ud875\udc01\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud8ca\udf48\ud8b3\udcb7\ud929\udea6\ud8ad\udf70\uda01\udcd9\ud88b\uddc2\udab5\udcf0\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\udb53\udc00\ud94d\ude3b",
        39, -113, 239738169, -7949099271468843529L, 35474L, true, false, (char) 33658, (char) 60110,
        Double.longBitsToDouble(0x3fc9adb587719ce8L), Double.longBitsToDouble(0x3fe4e3cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 5, 0, 0, "\udbce\ude8e", "\u8589\u18f4\u00d3\000d9\u12bc\u6910\u4505\ub7b6\u0199\u0714\u3022\u7d29\u5ffe\u58bc\u7712\u1486\u46b1\u1896\u338f\ud7c6\ua23f\ub2d8\ua146\u3083\u32b5\u02c3", "\ud910\ude18\ud8be\udef5\ud8bf\udec8\udb1e\udc47\ud918\udc9c\uda8d\ude39\u00a7\ud876\udf2f\ud873\udef2\udbdd\ude0b\uda65\udefb\ud950\ude36\udb48\udc8c\ud898\udeff\uda2f\uddcc\udac9\ude2f\ud96a\udfeb\ud94f\udf1c\ud856\uded1\uda2f\udc39\ud859\udc87\ud928\udf49\ud95a\udf52",
        36, -269, -1078233376, -934445939965562922L, 56018L, false, false, (char) 3972, (char) 35052,
        Double.longBitsToDouble(0x3fe7dd2cae5d02c8L), Double.longBitsToDouble(0x3fdbdcdbf6a01280L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Integer:87722945 |a0=[D:[[27963.5, 28341.5, 27843.0, 28618.0]]\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 14, 10, 8, "\udaa7\udd9b\ud9b6\udfc4", "\u432b\uc51c\u635d\u6997", "\u1657",
        42, 75002, -695578861, -930556748711347193L, 43552L, false, false, (char) 10645, (char) 26636,
        Double.longBitsToDouble(0x3fef920d6908e18cL), Double.longBitsToDouble(0x3fc481f6147db744L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[28023.5, 28352.5, 27893.5, 28188.0, 27987.0, 28275.5, 27981.0, 28174.0]] |a1=[D:[[20235.5, 9809.0, 10956.5, 2892.0, 16164.5, 19465.0, 26238.0, 23102.0]]\0121=java.lang.Boolean:false |a0=[D:[[28023.5, 28352.5, 27893.5, 28188.0, 27987.0, 28275.5, 27981.0, 28174.0]] |a1=[D:[[20235.5, 9809.0, 10956.5, 2892.0, 16164.5, 19465.0, 26238.0, 23102.0]]\012",
        Z.run(T, 2, 9, 9, 3, "\udb1f\uddb1\uda1b\udc68\udad6\udd17\udaca\udc4c\udbf6\udd2d\ud9f9\udc29\ud8f4\udfaa", "\u9e47\u4cd2\u55c9\u16c8\u7e79\u9842\ucd2c\ub4ac\u5ffe", "\udaa7\ude5b",
        22, 59759, 2089555954, 1130650932788398244L, -81715L, false, true, (char) 190, (char) 42275,
        Double.longBitsToDouble(0x3fcd3bd6503a5f60L), Double.longBitsToDouble(0x3fdcfb39945fd07aL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Long:-6635975519367358079\0121=java.lang.Long:-6635975519367358079\012",
        Z.run(T, 2, 1, 1, 1, "\u6915", "\u6d99\ub586\u355c\u0bde\u2c42\ub968\u9e47\u7143\u953a\u8c6e\uc6ef\ua72e\u2f9d\ub544", "\uda35\udd40\ud85a\udc33\ud854\udea9\udb4b\ude9d\udbf5\udf48",
        35, 59763, 1867402624, -6635975519367323615L, -34464L, true, true, (char) 42807, (char) 1335,
        Double.longBitsToDouble(0x3fe3b4c26b8e1a31L), Double.longBitsToDouble(0x3fda636c40f35352L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Long:7316159445252358472\0121=java.lang.Long:7316159445252358472\012",
        Z.run(T, 2, 1, 1, 1, "\u6915", "\u8c45\ub586\u355c", "\ud862\udeb4\udb30\ude1d\u1657\ud9c2\udda2\udb77\udc00\ud8ce\ude85",
        44, 52437, 1094555634, 7316159445252354044L, 4428L, true, true, (char) 26636, (char) 22943,
        Double.longBitsToDouble(0x3fd087c8c1481f60L), Double.longBitsToDouble(0x3fee736e8f6d6f84L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Double:172.35279713916282\0121=java.lang.Double:172.35279713916282\012",
        Z.run(T, 2, 12, 12, 11, "\u69b9", "\u6d99\ubdd2\u6606\u0bde\u2c42\ub968\u9e47", "\ud9fa\udc51\udba7\udf92\ud83e\udd75\ud985\udf91\ud8d8\udfca\udb07\ude3c\u68b1\udb9f\udfa6\ud857\uded2\ud887\udfdd\udb4b\ude9d\udbf5\udf48\udad2\uddf4\udb13\udde4\ud882\uddf6\udbd6\uddcb\ud98e\ude52\uda81\udc5a\udac3\ude83\uda89\udf22",
        56, 88766, 1160373673, 3950853764334314918L, 34805L, false, true, (char) 37563, (char) 32491,
        Double.longBitsToDouble(0x3fd6a27f363af11cL), Double.longBitsToDouble(0x3fe2b12f57a88d51L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Integer:16\012",
        Z.run(T, 1, 0, 4, 1, "\udbce\ude8e", "\u1ccf\u432b\u21b2\ud40a\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\u200f\ub71d\u24b4\u63a7\uaadc\u074f\u32bf\u07a6\000\u0130\ua94a\uc246\ua054\u0241\ua241", "\uda26\udfb2\ud875\udc01\ud872\udd01\ud917\udfb6\udafe\udce4\uda57\uddb3\udb93\udc62\ud876\udf2f\ud90d\udddf\udb03\udd61\ud8cd\udcaf\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\ud98d\udedb\ud81f\udc3a\ud951\udf48\ud977\udfa1\ud807\ude2e\ud80a\udc3c\ud9b9\udd55\ud82f\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04\uda47\udf55\uda23\udce7\udac0\udd87\ud815\udda1\ud8dd\udd69",
        48, 51904, -868270788, -7948929929498297079L, 99689L, true, true, (char) 32171, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb59f715b44L), Double.longBitsToDouble(0x3fe473cef0ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Integer:5\0121=java.lang.Integer:5\012",
        Z.run(T, 2, 0, 0, 9, "\udbce\ude8e", "\u1ca8\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\u5809\ub8f0\u0a1a\u7712\uc301\u46b1\u32bf\u07a6\000\u0130\ua94a\uc246\u50ec\ud311\ua241", "\uda26\udfb2\ud875\udc01\ud872\udd01\ud917\udfb6\ud98b\udec9\uda57\uddb3\udb93\udc62\ud876\udf2f\ud873\udef2\udae1\udd6d\ud9eb\udc5f\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud8d8\ude8f\udbd4\udff9\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\ud896\udf59\ud850\udde2\ud859\ude80\ud8f8\udca2\uda94\udd04\udb0c\udf37\000\udac0\udd87\ud815\udda1\ud8dd\udd69",
        -5, -1000, 369098752, -7949099142619824649L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe473cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Integer:5\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 1, "\udbce\ude8e", "\u1ca8\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u2504\u9670\u7def\u0714\u3022;\u5ffe\u58bc\u4957\ub25a\u46b1\u32bf\u07a6\000\u0130\ua94a\uc246\u50ec\ud311\ua241", "\uda26\udfb2\ud875\udc01\ud872\udd01\ud917\udfb6\ud98b\udec9\uda57\uddb3\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9eb\udc5f\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbd4\udf49\ud904\ude4a\ud91a\udf05\ud8df\udc75\ud9bd\ude2f\udbe6\ude25\ud8d0\ude90\ud850\udde2\ud859\ude80\ud8f8\udca2\uda94\udd04\udb0c\udf37\000\udac0\udd87\ud815\udda1\ud8dd\udd69",
        -5, -1000, 369098752, -7949099142619824649L, 35474L, true, false, (char) 33658, (char) 26318,
        Double.longBitsToDouble(0x3fc9adb587715b44L), Double.longBitsToDouble(0x3fe473cd78ae8aafL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Byte:1\0121=java.lang.Byte:1\012",
        Z.run(T, 2, 15, 15, 1, "\udbce\ude8e", "\u38e4\u4aa0\ub5ec\u0bdb\u2c42\ub968", "\udb9d\udfa8\ud962\ude56\ud9f1\udca1",
        32, 52437, 4036594, 7279893153721790460L, 34999L, true, true, (char) 26636, (char) 5888,
        Double.longBitsToDouble(0x3ec1800000000000L), Double.longBitsToDouble(0x3fd1f6d00edadf08L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 0, 0, 8, "\udb00\ude83", "\u47ec\u986d\u9ed9\uc0cd\ua3aa\uc777\u96c2\u2e6f", "\ud8f1\udcc1\udb08\udecf\ud96b\udd21\ud907\udeca",
        31, 81596, -568730048, 7067106675081806528L, -23783L, false, true, (char) 11422, (char) 29129,
        Double.longBitsToDouble(0x3fd346c8b32921e8L), Double.longBitsToDouble(0x3f895be16fd42dc0L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 0, 0, 0, "\000", "\ua715\u062b\u9ed9\u312a\ua441\ub968\u9e47\u7143\u953a\u9670\u7def\u0714", "\ud883\ude35\ud97e\udfa5\uda35\udd40\ud84c\ude8d\udacf\uddf7",
        54, 26203, 328434564, 8631743212317048625L, -77891L, true, false, (char) 59223, (char) 12050,
        Double.longBitsToDouble(0x3fcf7755e98c1c64L), Double.longBitsToDouble(0x3fecb73baf2e1944L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[28023.5, 28352.5, 27893.5, 28188.0, 27987.0, 28275.5, 27981.0, 28174.0]]\0121=java.lang.Boolean:false |a0=[D:[[28023.5, 28352.5, 27893.5, 28188.0, 27987.0, 28275.5, 27981.0, 28174.0]]\012",
        Z.run(T, 2, 9, 9, 3, "\udb1f\uddb1\uda1b\udc68\udad6\udd17\udaca\udc4c\udbf6\udd2d\ud9f9\udc29\ud8f4\udfaa", "\u9e47\u4cd2\u0e62\ubfc1\u7e79\u9842\ucd2c\ub4ac\u5ffe", "\udaa7\ude5b",
        0, 22129, 2089555769, 1130650932788398244L, -81715L, false, true, (char) 190, (char) 42275,
        Double.longBitsToDouble(0x3fcd3bd6503a5f60L), Double.longBitsToDouble(0x3fdcfb39945fd07aL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[28023.5, 28258.0]] |a1=[D:[[12855.5, 4169.5, 13347.5, 1495.0, 27229.0]]\0121=java.lang.Boolean:false |a0=[D:[[28023.5, 28258.0]] |a1=[D:[[12855.5, 4169.5, 13347.5, 1495.0, 27229.0]]\012",
        Z.run(T, 2, 9, 9, 3, "\udb1f\udcf4", "\u649f\u20c3\u6877\u0bde\ud4ea", "\uda5d\udce1",
        21, 28564, 1431414697, -930713149945431033L, -97660L, true, false, (char) 14501, (char) 4641,
        Double.longBitsToDouble(0x3febcaa9e1087c8cL), Double.longBitsToDouble(0x3fc481f6147db744L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Integer:8\0121=java.lang.Integer:8\012",
        Z.run(T, 2, 0, 0, 1, "\udbce\ude8e", "\u1ca8\u432b\ua3d9\u0bde\u4db4\ub968\u9e47\u7143\u2504\u9670\u7def\u0714\u3022\u97f2\000\000\u4317\ud7fb\ubed0\u32bf\u07a6\000\u0130\ua94a\uc246\u50ec\ud311\ua241", "\uda26\udfb2\udba2\ude78\udbd9\udd6b",
        16, -1000, -922353664, 2120186788752461782L, -94582L, true, true, (char) 14541, (char) 22053,
        Double.longBitsToDouble(0x3fe87640587c44c4L), Double.longBitsToDouble(0x3f2cbce5b3700000L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Long:3628800\012",
        Z.run(T, 1, 10, 4, 1, "\udbce\ude8e", "\u05d0\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u0714\u3022\ub544\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc223\u8827\uc417\ua241", "\uda26\udfb2\ud875\udc01\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\uda5a\udef7\udaa0\ude9d\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud850\uddc0\ud859\ude80\ud8f8\udca2\uda94\udd04",
        10, 16009, -2022057822, -7048841060478063255L, 93224L, true, false, (char) 14111, (char) 4007,
        Double.longBitsToDouble(0x3fc244f91b3a0a30L), Double.longBitsToDouble(0x3fe2fb02899cb9deL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Long:1307674368000\0121=java.lang.Long:1307674368000\012",
        Z.run(T, 2, 10, 10, 1, "\udbce\ude8e", "\u05d0\u432b\ua3d9\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u9842\ub940\ub454\u5ffe\u58bc\u7712\u3a86\u46b1\u1896\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda14\udc68\ubbcf\ud8c9\udf00\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\udab7\udde3\ud8f6\udc3e\udbc3\udf88\udb4c\udf03\udae3\udc1f\ud838\udfdf\udbed\ude9e\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\ud987\uddd0\ud823\udc03\ud820\udfdc\ud8e0\udd6d\uda94\udd04\uda23\udc43\ud9c6\udc52\udac0\udd87\ud815\udda1\ud9d6\udf86",
        15, 4663, 380453177, -7949099142619824649L, 35474L, true, true, (char) 5634, (char) 26318,
        Double.longBitsToDouble(0x3fee6b6d646a172aL), Double.longBitsToDouble(0x3fe78c79c0dd14b0L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Integer:-1070071777 |a0=[D:[[-24.0]]\0121=java.lang.Boolean:true |a0=[D:[[-24.0]] |a1=[D:[[-24.0]]\012",
        Z.run(T, 2, 14, 9, 0, "\000", "\000", "\000",
        -3, 82552, -652993431, -324762081631743844L, 10829L, true, true, (char) 43274, (char) 37208,
        Double.longBitsToDouble(0x3fb0504f7fe32838L), Double.longBitsToDouble(0x3fea05b31000a44fL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Long:0\012",
        Z.run(T, 1, 4, 11, 2, "\udbce\ude8e", "\u05d0\u432b\u71a8\u0bde\u2c42\ub968\u9e47\u7143\u953a\u9670\u7def\u4176\u2fe5\ub544\u5ffe\u58bc\u7712\u3a86\u46b1\u720c\u338f\ub3a0\ua2cb\ua94a\uc246\u50ec\uc417\ua241", "\uda6f\udc16\ud861\udeee\ud8bf\udec8\ud98f\udca0\udb14\udf4e\uda57\uddbc\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\ud9e1\udc58\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\ud906\udd2b\ud929\udea6\udbcb\udebe\ud8df\udc75\uda20\uddee\udab0\udd3d\u15f1\ud818\uddc4\ud859\ude80\ud8f8\udca2\uda94\udd04\uda23\udc43\ud99a\udd52\udac0\udd87\udaf0\udc57\udb14\ude41",
        13, -113, 239738169, -7949099271468843529L, 35474L, true, false, (char) 33658, (char) 60110,
        Double.longBitsToDouble(0x3fc9ada023715b44L), Double.longBitsToDouble(0x3fecdbbca8ae1466L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Byte:-1\0121=java.lang.Byte:-1\012",
        Z.run(T, 2, 15, 15, 1, "\udbce\ude8e", "\u05d0\u29fc\u58f8\u4132\u6d40\u2007\u40c7\u5ba9\uc6cb\uc01c\u7def\ub11e\u9ab8\u4658\ub8c3\u58b1\u7712\u3a86\u462c\u1896\u338f\uc50f\uc104\u108f\000\000\000\000", "\uda26\udee3\ud875\udc01\ud8bf\udec8\ud98f\udca0\udb01\udf89\ud830\ude28",
        -4, 51297, -742876893, 20289470379982848L, -13227L, false, true, (char) 61114, (char) 58009,
        Double.longBitsToDouble(0x3f9c6da51b6054e0L), Double.longBitsToDouble(0x3fbfa6c928b01280L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.Integer:93834\0121=java.lang.Integer:93834\012",
        Z.run(T, 2, 0, 0, 8, "\udb00\ude83", "\u908b\u0636\u9ed9\uc0cd\ua3aa\uc777\u96c2\u2e6f", "\ud8f1\udcc1\udb08\udecf\ud96b\udd21\ud907\udeca",
        0, 93834, -1853053097, 7067107134643307200L, -60784L, true, true, (char) 27293, (char) 40131,
        Double.longBitsToDouble(0x3fb4c712c0850dc8L), Double.longBitsToDouble(0x3fe01e6d59949977L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[D:[[-24.0]] |a1=[D:[[-24.0]]\0121=java.lang.Boolean:true |a0=[D:[[-24.0]] |a1=[D:[[-24.0]]\012",
        Z.run(T, 2, 9, 9, 0, "\000", "\000", "\000",
        57, 82753, -652993431, -324762081631738990L, 43349L, false, true, (char) 41342, (char) 27139,
        Double.longBitsToDouble(0x3fea05b4c800a44fL), Double.longBitsToDouble(0x3fc565362054c308L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Long:-8163733491928195784\0121=java.lang.Long:-8163733491928195784\012",
        Z.run(T, 2, 3, 3, 0, "\uda4c\udc0c\udb93\udea1\uda98\udf87x\ud9e3\udc91\ud9f7\udeec\ud9ab\ude35", "\u293e\ua423\u952e\u9670\ub1e5\u4224\uab98\u4ba2\u5211\u58bc\u7712\ua743\u466d\u0694\u3376\ub3a0\uc9cb\ua94a\uc26f\u1c95\u9427\u466f\u78ff\u8180\uc6e7\u4981\u875e\ua93f\u061f\u9f6a\u6d82\u4a59\u9f64\ub8d4\u7a03\u9900\u83fe\u91a5\ub49a", "\ud9d1\udd9a\ud8df\udc75\ud8ac\udef3\uda90\udf73\ud938\udd47\ud926\udedb\ud969\udce2\ud8fc\uddfb\uda94\udd04\uda9d\udc70\ud9ad\udf3e\udac0\udd87\udab7\udc9a\ud9ef\udcc8\udaf1\udef1\ue92d\ud83e\ude8f\udad0\udc69\u7df7\ud955\udc9b\ud8a7\udd80\udbcf\ude3c\udae4\ude94\ud8c5\udcc8\udb3b\uddea\ud94a\udd5f\000\ud860\udde7\ud9ca\udebe",
        3, 14262, 127114409, -8163733491928241351L, 45567L, false, true, (char) 51809, (char) 19896,
        Double.longBitsToDouble(0x3fa9c9e3ff821920L), Double.longBitsToDouble(0x3fc3b3ddab8ade6cL)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.Integer:1\012",
        Z.run(T, 1, 0, 4, 1, "\udbce\udf38\ud9a6\uddc4\ud9ca\udf69\ud86e\udc1b\ud888\ude8a\ud94d\udf54\ud8f4\udfaa\ud917\udd8a\ud85e\udd92\udb30\uddb4\u1657\ud978\udd7e\ud962\udda9\ud9f1\udca1\udb07\udeb3\udae7\udc62\udb55\udcb4\ud8a6\udf9c\ud97e\udfa5\uda35\udd40\ud85a\udc33\ud854\ude24\ud8bf\udeb8\u8c91\ud832\udc22\uf4f2", "\000", "\005\udbfc\uddec",
        -2, 65537, -922197379, -1249355660019389831L, 31072L, true, false, (char) 11009, (char) 47532,
        Double.longBitsToDouble(0x3fee00868a7808caL), Double.longBitsToDouble(0x3fdde2394d14b206L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\0121=java.lang.Long:0\012",
        Z.run(T, 2, 6, 4, 1, "\udbce\ude8e", "\u1ca8\u432b\ua3d9\u0bde\u2ba9\u645f\u861d\u3a1d\uaad4\u9670\u7def\u0714\u3022;\ua749\u58bc\u7712\uc301\u46b1\u556a\u726a\u8c1f\u0144\u0706\u0e19\ud606\u85cd\ub23b", "\uda26\udfb2\ud875\udc01\ud872\udd01\ud917\udfb6\ud98b\udec9\uda57\uddb3\udb93\udc62\ud876\udf2f\ud873\udef2\udacf\ude2e\udb9c\udd43\udbdf\ude56\udb4c\udf03\ud9c6\udf1b\ud838\udfdf\udbe5\udff7\ud904\ude4a\ud91a\udf05\ud8df\udc75\uda20\uddee\udab0\udd3d\ud896\udf59\ud850\udde2\ud890\udffb\ud8a3\uddd8\ud81b\udcf0\udb0c\udf37\000\udb3c\udcfb\ud823\udd76\ud867\udc2d",
        40, -1000, -520293888, 6032304588924157431L, 47748L, true, false, (char) 28904, (char) 26318,
        Double.longBitsToDouble(0x3fc2e4bcc40a14f8L), Double.longBitsToDouble(0x3fe473cd7f7c74afL)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Long:0\012",
        Z.run(T, 2, 0, 4, 1, "\udbce\uded1\ud9b6\udfc4\ud981\udd5f\ud847\ude2e\udabf\udcc4\u8344\ud8f4\udfaa\ud8fa\udda7\ud862\udeb4\udb30\ude1d\u1657\ud9c2\udda2\ud962\ude56\uda07\udd1b\udb07\udeb3\uda26\ude41\udaa8\udf00\ud8c2\udda5\ud955\udcf7", "\u46b1\u32bf\u9a04\000\u6a0e\ua94a\ud592\u0d36", "\uda89\udef9\ud941\udf8d\uda26\udfb2\ud875\udc01\udb23\udc7a\ud917\udfc8\ud928\ude59\uda57\uddb3\ud817\udd05\ud806\ude6c\ud824\ude47\udacf\ude2e\ud9eb\udc5f\udbdf\ude56\udb31\udce0\ud9f6\udd98\ud9b3\udd75\ud92d\udf74\ud9c9\udd47",
        12, -49, -1609646186, -7505003170405546321L, -55875L, false, true, (char) 34880, (char) 30091,
        Double.longBitsToDouble(0x3fe488028d9e40fdL), Double.longBitsToDouble(0x3fb9e1de56d0d7b8L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Long:0\012",
        Z.run(T, 2, 2, 4, 8, "\udb7b\udea6\ud8d2\udd34\uea2d\ud86d\udf65\udb21\udd15\ud849\udc1a\udb5a\udebd\udb3f\udfaa\ud921\udffe", "\u0ca3\u95d8\u7def", "\ud8d8\udfca\uf8cd\ud97e\udfa5\ud974\uddb1",
        1, -1, 139823431, 8974574172322717960L, -72065L, true, true, (char) 50185, (char) 26649,
        Double.longBitsToDouble(0x3fe2325ee9db63fcL), Double.longBitsToDouble(0x3f8d2fb1f3d76640L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.Integer:49\0121=java.lang.Long:0\012",
        Z.run(T, 2, 0, 4, 1, "\udbce\uded1\ud9b6\udfc4\ud981\udd5f\ud847\ude2e\ud9d0\udf80\ud9ae\ude45\ud8c5\udeaa\ud903\udd0c\ud9c5\udd2d\udb52\ude0d\u15ed\ud9c2\udda2\udaaa\udd59\uda07\udc9c\udb07\udeb3\udb73\ude11\udaa8\udf00\ud8c2\udda5\ud955\udcf7", "\u46b1\u32bf\u9a04\000\u6a0e\ua94a\ud592\u0d36", "\uda89\udef9\udb7e\udd85\ud887\udeca\ud82b\udefd\udb23\udc7a\ud917\udfc8\ud928\ude59\uda57\uddb3\ud817\udd05\ud806\ude6c\ud824\ude47\udacf\ude2e\ud9eb\udc5f\udbdf\ude56\udbe9\udedd\ua9f3\uda17\ude08\ud91d\udf8e\ud9c9\udd47",
        49, -49, -1609646186, -654356130418129353L, -55875L, false, true, (char) 26834, (char) 30091,
        Double.longBitsToDouble(0x3fe488028d9e40fdL), Double.longBitsToDouble(0x3fb9e1de56d0d7b8L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.Integer:22\0121=java.lang.Long:0\012",
        Z.run(T, 2, 2, 4, 8, "\udb7b\udea6\ud9e3\udc3c\uea2d\ud86d\udf65\udb21\udd15\ud849\udc1a\udb5a\udebd\udb3f\udfaa\ud920\udc84", "\u0ca3\u95d8\u7def", "\udadb\udfe9\uf8db\udbd8\udfbb\udb63\uddf7",
        23, -1, 139823431, -2698756062952076024L, -72065L, true, false, (char) 41352, (char) 25017,
        Double.longBitsToDouble(0x3fe2315369db63fcL), Double.longBitsToDouble(0x3fe074bec237cc3fL)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Integer:12\0121=java.lang.Long:0\012",
        Z.run(T, 2, 2, 4, 8, "\udb7b\udea6\ud9e3\udc3c\uea2d\ud86d\udf65\udb21\udd15\ud849\udc1a\udb59\udede\udb3f\udfaa\udbef\udeec", "\u0ca3\ucafb\u7439\u7378\u3022\u1382", "\ud94c\udd8c",
        13, -1, 139823431, -7670730051569103528L, 96705L, true, false, (char) 4275, (char) 55831,
        Double.longBitsToDouble(0x3fe074bec137cc3fL), Double.longBitsToDouble(0x3fe3fe924fe57751L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Integer:16\0121=java.lang.Integer:16\012",
        Z.run(T, 2, 0, 0, 1, "\udbce\ude8e", "\u1ca8\u432b\ua3d9\u0bde\u4db4\ub968\u9e47\u62f5\u577a\u3188\u7def\u0714\u3022\u97f2\000\000\u4317\ud7fb\ubed0\u32bf\u07a6\000\u0130\ua94a\uc246\u50ec\ud311\ua241", "\uda26\udfb2\udba2\ude78\ud812\udf49",
        16, 43920, -922353413, 2120186788752461782L, -94582L, false, false, (char) 14396, (char) 22053,
        Double.longBitsToDouble(0x3fe877c8587c44c4L), Double.longBitsToDouble(0x3f2cbce5b3700000L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Long:18009460\012",
        Z.run(T, 1, 4, 4, 6, "\uabea\ud821\ude5c\ud8b1\udf1e\ud83d\udeaa\udabf\udcc4\u8344\udb8e\udf40\ud8f4\udda4\ud9b8\udd9f\ud90b\udca3\udb84\udcd7\ud9a1\udfd9\uda1e\udfb4\udb4a\ude86", "\u9f2d\u25fa\u58bc\u7712\u2acc\u46b1\u1896", "\ud9c9\udfcd\ud982\udfb1\uda76\ude69",
        51, 45, 1490923262, 5430365140069803984L, -57068L, true, true, (char) 49267, (char) 326,
        Double.longBitsToDouble(0x3fdc52d4210ad9a2L), Double.longBitsToDouble(0x3fcae89117eb4014L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.Double:-Infinity\0121=java.lang.Long:0\012",
        Z.run(T, 2, 6, 4, 8, "\udb7b\udea6\ud8d2\udd34\udbe8\udc21\ud84e\udd2a\udb21\udd15\ud8d1\udc71\udb5a\udeec\udb3f\udfaa\ud921\udffe", "\u0ca3\u95a1\u7def", "\ud8d8\udfca\uf8cd\ud97e\udfa5\ud974\uddb1",
        1, -1, 139823431, 8974574172322717960L, -72065L, true, true, (char) 50185, (char) 26649,
        Double.longBitsToDouble(0x3fe2325ee9db63d1L), Double.longBitsToDouble(0x3fe874bec7cfc143L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 0, 0, 1, "\udbce\ude8e", "\u0e70\u432b\ua3d9\u0bde\u4db4\ub968\u9e47\u7143\u2504\u9670\u53ef\u0714\u9c65\u97f2\000\000\u4317\ud7fb\ubed0\u32bf\u07a6\000\u0130\ua94a\uc246\u50ec\ud311\ua241", "\uda26\udfb2\udba2\ude78\udbd9\udd6b",
        25, 88128, -1878343574, -5060709633479343147L, -94582L, true, true, (char) 14541, (char) 22053,
        Double.longBitsToDouble(0x3fe87640587c44c4L), Double.longBitsToDouble(0x3f2cbce5b3700000L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.Long:46\012",
        Z.run(T, 1, 4, 4, 6, "\uabea\ud821\ude5c\ud8b1\udf1e\ud83d\udeaa\udabf\udcc4\u8344\udb8e\udf40\ud8f4\udda4\ud9b8\udd9f\ud90b\udca3\udb84\udcd7\ud9a1\udfd9\uda1e\udfb4\udb4a\ude86", "\u9f2d\u25fa\u58bc\u7712\u2acc\u46b1\u1896", "\ud9c9\udfcd\ud8cc\udd57\udba9\udc3e",
        46, 45, 1490923262, 5430365140069803984L, -57068L, true, true, (char) 49267, (char) 326,
        Double.longBitsToDouble(0x3fdc52d4210ad9a2L), Double.longBitsToDouble(0x3fcae89117eb4014L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.Integer:5\012",
        Z.run(T, 1, 0, 0, 0, "\uabea\ud821\ude5c\ud8b1\udf1e\ud83d\udeaa\udabf\udcc4\ud803\udd54\udb13\udea8\ud8f4\udda4\ud9b8\udd9f\000\udb84\udcd7\ud9a1\udfd9\uda1e\udfb4\udb4a\ude86", "\u9f2d\u25fa\u58bc\u7712\u2acc\u46b1\u1896", "\ud9a3\udecd\ud8cc\udd57\udba5\ude1d",
        -5, 0, 1490923262, 26045587225208576L, 22309L, true, false, (char) 47455, (char) 53253,
        Double.longBitsToDouble(0x3fece3cc6341d953L), Double.longBitsToDouble(0x3fe0d270c9b91971L)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.lang.Integer:5\0121=java.lang.Integer:5\012",
        Z.run(T, 2, 0, 0, 0, "\uabea\ud821\ude5c\ud8b1\udf1e\ud83d\udeaa\udabf\udcc4\ud803\udd54\udb13\udea8\ud8f4\udda4\ud9e2\ude54\ud81a\udfdb\udb84\udcd7\ud9a1\udfd9\uda1e\udfb4\udb4a\ude86", "\u9f2d\u25fa\u331b\u7712\u2acc\u46b1\u6849", "\ud9a3\udecd\ud8cc\udd57\udba5\ude1d",
        -5, 0, 1490923262, 26045587225208576L, 22309L, true, false, (char) 47455, (char) 53253,
        Double.longBitsToDouble(0x3fece3cc63418353L), Double.longBitsToDouble(0x3fe0d270c9b91971L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.Long:1\012",
        Z.run(T, 1, 4, 4, 6, "\uabea\ud821\ude5c\ud8b1\udf1e\ud83d\udeaa\udabf\udcc4\u8344\udb8e\udf40\u00b4\ud9b8\udd1b\ud90b\udca3\udb84\udcd7\ud9a1\udfd9\uda1e\udfb4\udb4a\ude86", "\u9f2d\u25fa\u58bc\u8011\u2acc\u1f2c\u1896", "\ud99b\ude6c\ud8cc\udd57\udba9\udc3e",
        46, 0, 1490923262, 355786450688L, -57068L, true, true, (char) 49267, (char) 326,
        Double.longBitsToDouble(0x3fdc52d4200001a2L), Double.longBitsToDouble(0x3f31220000000000L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.Long:46\0121=java.lang.Long:46\012",
        Z.run(T, 2, 4, 4, 6, "\ud8a1\udfc6\ud821\ude5c\ud8b1\udf1e\ud83d\udeaa\udabf\udcc4\u8344\udb9d\udf40\ud8a0\udc3a\ud95d\udd78\ud90b\udca3\udb84\udcd7\ud9a1\udfd9\uda1e\udfb4\udb8c\udf47", "\u9f2d\ud7f4\u57e7\u2fbd\u2acc\u46b1\u9723", "\ud9f9\udf4c\ud8e4\udf53\udba9\udc3e",
        46, 45, 870952702, 3917155420460181433L, -57068L, true, true, (char) 49267, (char) 326,
        Double.longBitsToDouble(0x3fef796a141a0a38L), Double.longBitsToDouble(0x3fedcde4258eed85L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.Double:3.828641396489095\012",
        Z.run(T, 1, 6, 4, 6, "\uabea\ud821\ude5c\ud8b1\udf1e\ud83d\udeaa\udabf\udcc4\u8344\udb8e\udf40\ud8f4\udda4\ud9b8\udd9f\ud90b\udca3\udb84\udcd7\ud9a1\udfd9\uda1e\udfb4\udb4a\ude86", "\u9f2d\u25fa\u58bc\u7712\u2acc\u53f2\u1896", "\ud9c9\udfcd\ud8cc\udd57\udba9\udc3e",
        46, 45, 1490923262, 5430365140069803984L, -57068L, true, true, (char) 49267, (char) 326,
        Double.longBitsToDouble(0x3fdc52d4210ad9a2L), Double.longBitsToDouble(0x3fcae89117eb4014L)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\012",
        Z.run(T, 1, 6, 4, 6, "\uabea\ud821\ude5c\ud8b1\udf1e\ud83d\udeaa\udabf\udcc4\u8344\udb8e\udf40\uda1d\ude81\ud9b8\udd1b\ud90b\udca3\udb84\udcd7\ud9a1\udfd9\ud846\udde7\ud84c\udd42", "\u85fe\u2618\u014d\001\u2acc\u1f2c\u51c5", "\udabc\udf90\udae7\udd4b\udb95\udfce",
        46, 0, 1490923262, -2648005174432984576L, -57068L, true, true, (char) 49267, (char) 326,
        Double.longBitsToDouble(0x3fdc52d4200001a2L), Double.longBitsToDouble(0x3f312200011e7000L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=java.lang.Long:1\0121=java.lang.Long:1\012",
        Z.run(T, 2, 4, 4, 6, "\uabea\ud821\ude5c\ud8b1\udf1e\ud83d\udeaa\udabf\udcc4\u8344\udb8e\udf40\u00b4\ud9b8\udd1b\ud90b\udca3\udb84\udcd7\ud9a1\udfd9\uda1e\udfb4\udb4a\ude86", "\u2c00\u25fa\u58bc\u8011\u5e5a\u9a2e\ud650", "\ud99b\ude6c\ud8cc\udd57\udba9\udc3e",
        46, 0, 1490923262, 355786450688L, -57068L, true, true, (char) 49267, (char) 37701,
        Double.longBitsToDouble(0x3fda42fa400001a2L), Double.longBitsToDouble(0x3f31220000000000L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\012",
        Z.run(T, 1, 6, 4, 6, "\uabea\ud821\ude5c\ud8b1\udf1e\ud83d\udeaa\udabf\udcc4\u8344\udb8e\udf40\ud8f4\udda4\ud9b8\udd9f\ud90b\udca3\udb84\udcd7\ud9a1\udfd9\uda1e\udfb4\udb4a\ude86", "\u9f2d\u25fa\u58bc\u7712\u2acc\u53f2\u1896", "\ud9c9\udfcd\ud8cc\udd57\udaeb\udc67",
        45, 45, 1490923262, 5430365140069803984L, -57068L, true, true, (char) 49267, (char) 326,
        Double.longBitsToDouble(0x3fdc52d4210ad9a2L), Double.longBitsToDouble(0x3fcae89117eb4014L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Long:1\012",
        Z.run(T, 2, 6, 4, 6, "\uabea\ud821\ude5c\ud8b1\udf1e\ud83d\udeaa\udabf\udcc4\u8344\udb8e\udf40\ud8f4\udda4\ud9b8\udd9f\ud90b\udca3\udb84\udcd7\ud9a1\udfd9\uda1e\udfb4\udb4a\ude86", "\u9f2d\u25fa\u58bc\u7712\u2acc\u53f2\u1896", "\ud9c9\udfcd\ud8cc\udd57\udaeb\udc67",
        45, 45, 1490923262, 5430365140069803984L, -57068L, true, true, (char) 49267, (char) 326,
        Double.longBitsToDouble(0x3fdc52d4210ad9a2L), Double.longBitsToDouble(0x3fcae89117eb4014L)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 6, 6, 6, "\uabea\ud821\ude5c\ud8b1\udf1e\ud83d\udeaa\udabf\udcc4\u8344\udb8e\udf40\ud8f4\udda4\ud9b8\udd9f\ud90b\udca3\udb36\ude12\ud9a1\udfad\uda1e\udfb4\udb4a\ude86", "\u0f02\ub343\u58bc\u7712\u2acc\u53f2\u1896", "\ud9c9\udfcd\ud8cc\udd57\udaeb\udc67",
        45, 45, 1490923262, 5430365140069803984L, -57068L, true, true, (char) 49267, (char) 326,
        Double.longBitsToDouble(0x3fdc52d4210ad9a2L), Double.longBitsToDouble(0x3fcae89117eb4014L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=java.lang.Long:1\0121=java.lang.Long:1\012",
        Z.run(T, 2, 4, 4, 6, "\uabea\udbd8\ude18\uda36\udd2e\ud9bd\ude2b\udabf\udcc4\u2217\ud954\udfd1\ud90a\udd4e\ud9b8\udd9f\ud811\ude86\udb44\uddc1\ud98d\udc74\uda1e\udfb4\udb4a\ude86", "\u9f2d\u25fa\u58bc\u7712\u2acc\u3f57\u1896", "\ud9c9\udfcd\ud8cc\udd57\udba9\udc3e",
        45, 45, 1490923262, 5430365140069782697L, -57068L, true, true, (char) 50073, (char) 326,
        Double.longBitsToDouble(0x3fdc52d4207201a2L), Double.longBitsToDouble(0x3fcae8911e3e4814L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.Double:3.8066624897703196\0121=java.lang.Long:45\012",
        Z.run(T, 2, 6, 4, 6, "\ud9c1\udf15\ud821\ude5c\ud801\udefd\udb88\udf4f\udb48\udc06\ud81d\udd0e\udb8e\udf40\ud8f4\udda4\ud8ff\udfa2\u27cd\udb84\udcd7\ud9a1\udfd9\uda1e\udfb4\udb4a\ude86", "\u9f2d\u25fa\u58bc\u7712\u3b64\u332d\ubb70", "\ud9c9\udfcd\ud8cc\udd57\udaeb\udc67",
        45, 1, 1490923262, 5430365140069803984L, -57068L, true, true, (char) 49267, (char) 326,
        Double.longBitsToDouble(0x3fdc52d4210ad9a2L), Double.longBitsToDouble(0x3fcae89117eb4014L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=java.lang.Double:3.8066624897703196\0121=java.lang.Double:45.0\012",
        Z.run(T, 2, 6, 5, 6, "\ud9c1\udf15\ud821\ude5c\ud801\udefd\udb88\udf4f\udb48\udc06\ud81d\udd0e\udb8e\udf40\ud8f4\udda4\ud98a\udec9\u27cd\ud923\udc9c\ud9a1\udfd9\uda1e\udfb4\udb4a\ude86", "\u9f2d\u25fa\u58bc\u7712\u3b64\u332d\ubb70", "\ud9c9\udfcd\ud8cc\udd57\udaeb\udc67",
        45, 1, 1490923262, 5430365140069803984L, -57068L, true, true, (char) 49267, (char) 5061,
        Double.longBitsToDouble(0x3fdc52df010ad9a2L), Double.longBitsToDouble(0x3fcae89117eb4014L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=java.lang.Long:45\0121=java.lang.Long:45\012",
        Z.run(T, 2, 4, 4, 6, "\ud9c1\udf4b\ud821\ude5c\ud801\udefd\udb88\udf4f\udb48\udc06\ud81d\udd0e\udb8e\udf40\ud8f4\udda4\ud8ff\udfa2\u27cd\udb84\udcd7\ud9a1\udfd9\uda1e\udfb4\udb4a\ude86", "\u9f2d\u25fa\u5814\u7712\u3b64\u332d\ubb70", "\ud9c9\udfcd\ud8cc\udd57\udaeb\udc67",
        45, 1, 834604977, 5430365140069803984L, 8468L, true, true, (char) 49267, (char) 326,
        Double.longBitsToDouble(0x3fdc52d4210ad9a2L), Double.longBitsToDouble(0x3fcae89117eb4014L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[-24.0, -24.0, -24.0, -24.0, -24.0, 16096.0, 27746.0, 28605.0]] |a1=[D:[[-24.0, -24.0, -24.0, 4640.5, 16095.5, 19465.0, 26238.0, 23102.0]]\0121=java.lang.Integer:-47987263 |a0=[D:[[-24.0, -24.0, -24.0, -24.0, -24.0, 16096.0, 27746.0, 28605.0]]\012",
        Z.run(T, 2, 9, 14, 1, "\000\000\000\000\000\u7df0\ud8f4\udfaa", "\000\000\000\u2471\u7def\u9842\ucd2c\ub4ac\u5ffe\u57c0\u7f5e\u3a86\u2785\000\u2af7\ub3a0\ua2cb", "\udbd4\udd67\uda29\udea5\udb1a\ude45\uda7d\uddf9\ud941\udf8d\uda14\udc68\ubbcf\ud8c9\udf00\000\udaea\udcd5\ud8ca\udf12\ud968\udead\ud876\ude59\ud873\udef2*\ud8f5\udfe4\udbc3\udf88\ud88c\udf03\udae3\udc1f\ud838\udfdf\udbed\ude49",
        55, 71172, -46414689, -6913377728748527775L, -83141L, false, true, (char) 26501, (char) 13503,
        Double.longBitsToDouble(0x3fe99b5588000000L), Double.longBitsToDouble(0x3fc45c400d9e1de4L)));
  }
  @Test(timeout = 4000)
  public void test118() throws Throwable {
    assertEquals("0=java.lang.Double:3.828641396489095\0121=java.lang.Double:46.0\012",
        Z.run(T, 2, 6, 5, 6, "\uabea\ud821\ude5c\ud8b1\udf1e\ud83d\udeaa\ud857\udd10\u8344\udb8e\udf40\ud8f4\udda4\ud9b8\udd9f\ud90b\udca3\udb84\udcd7\ud9a1\udfd9\uda73\udd1e\ud973\udcee", "\u9f2d\u25fa\u58bc\u7712\u2acc\u53f2\u1896", "\ud9c9\udfcd\ud8cc\udd57\udba9\udc3e",
        46, 45, 1490923262, 5430365140069803984L, -57068L, true, true, (char) 49267, (char) 326,
        Double.longBitsToDouble(0x3fdc52d4210ad9a2L), Double.longBitsToDouble(0x3fcae89117eb4014L)));
  }
  @Test(timeout = 4000)
  public void test119() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 5, 6, 11, "\ud815\ude75\udbb8\udcf8\ud8cb\udfe3\ud83d\udeaa\udabf\udcc4\ud94d\udeba\ud8a1\uddea\ud9ca\udc64\ud80d\uddf9\ud911\udd94\udbc9\uded0\ud809\uddbe\ud86c\udfb2\uda83\udf08", "\u2c00", "\uda1e\uddad\uda6b\udcf5\udac6\udf09\uda60\udc87\ud8f8\udcd0\uda86\ude8b\ud9b3\udf7b\ud8c0\udf4c\udba9\udc3e",
        46, 0, 1490923262, 358337852108L, -57068L, false, true, (char) 44940, (char) 2048,
        Double.longBitsToDouble(0x3fed98bc609c8050L), Double.longBitsToDouble(0x3f31220000058000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.util.MathUtils|gcd|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|long,long,java.lang.String|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|long,long|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficient|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficientDouble|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficientLog|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|cosh|double|static",
    "M|org.apache.commons.math.util.MathUtils|equals|double,double|static",
    "M|org.apache.commons.math.util.MathUtils|equals|[D,[D|static",
    "M|org.apache.commons.math.util.MathUtils|factorial|int|static",
    "M|org.apache.commons.math.util.MathUtils|factorialDouble|int|static",
    "M|org.apache.commons.math.util.MathUtils|factorialLog|int|static",
    "M|org.apache.commons.math.util.MathUtils|hash|double|static",
    "M|org.apache.commons.math.util.MathUtils|hash|[D|static",
    "M|org.apache.commons.math.util.MathUtils|indicator|byte|static",
    "M|org.apache.commons.math.util.MathUtils|gcd|int,int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
