package org.apache.commons.math3.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class FastMath_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Double:0.8468031964361951\0121=java.lang.Double:0.560850188552901\012",
        Z.run(T, 2, 3, 7, 5, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf\uda1f\udd6f", "\u5871\u8798\u95f4", "\ud984\udea4\udbfe\uddfb\ud9d8\udf47\ud9c6\udd2f\ud8ec\uddd5\uda24\udc5b\udb2e\udd5b\ud874\udcd9\ud90d\udf37",
        45, 443, -2092507115, -7619679839175618892L, -38651L, false, false, (char) 62530, (char) 23761,
        Double.longBitsToDouble(0x3feb1903045aef62L), Double.longBitsToDouble(0x3fe9150979c1b5deL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Double:0.7838179948864157\0121=java.lang.Double:0.670005911535549\012",
        Z.run(T, 2, 3, 7, 5, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf\uda1f\udd6f", "\u58c2\u8798\u95f4", "\ud984\udea4\udbfe\uddfb\ud9d8\udf47\ud9c6\udd2f\ud8ec\uddd5\uda24\udc5b\udb2e\udd5b\ud874\udcd9\ud90d\udf37\ud875\udf25\ud993\udf24",
        50, 70039, -1682223436, -2879428955471671205L, 81256L, false, false, (char) 56258, (char) 9149,
        Double.longBitsToDouble(0x3fe9150979c1b5deL), Double.longBitsToDouble(0x3fc75aed915e427cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Double:0.08969131875304404\0121=java.lang.Double:1.4809843164973233\012",
        Z.run(T, 2, 3, 7, 0, "\ud9c1\udd43", "\u6849", "\ud91d\udc3f\udbb7\udc53\ud959\udd2d\uda3d\udcd5\uda4a\ude17\ud806\udd37\udbfe\uddfb\udad1\udd0d\ud952\uddad\ud928\udd13",
        56, 7490, 1683871816, 2671241002644690422L, -51851L, false, false, (char) 20650, (char) 53722,
        Double.longBitsToDouble(0x3fb6f602a0c78918L), Double.longBitsToDouble(0x3feabdc2501084c1L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Double:0.5087090485369061\0121=java.lang.Double:1.254496410017243\012",
        Z.run(T, 2, 12, 13, 8, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf", "\u01b2\u5871\u8798\u95f4\u6e74\uc3a3\ua507\uac04\ub4a5\uaa27\u9ea4\ubd22\u54e8\u09e3\u60f8\u15c7\uc803", "\ud88a\udeee\ud859\udc44\udb03\udf7a\ud877\udfde\uda87\udcb4\u18f8\ud93a\uded9\uda1f\udec3\uda7b\udec3\udb4e\udc51\ud9ae\udd1d\udae6\udffb\uda30\udd06\uf915\ud935\udc35\uda63\udc21\uda40\ude26",
        24, 3609, -4979133, -3818208607652279675L, -3532L, true, true, (char) 24101, (char) 17464,
        Double.longBitsToDouble(0x3fe1d8646b01c80cL), Double.longBitsToDouble(0x3fc75cb8408c8bc0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Double:0.08824455689571009\0121=java.lang.Double:1.003896078189903\012",
        Z.run(T, 2, 3, 16, 5, "\uc82e\ud989\udda3\ud9fd\uddcf\ud83c\udf07\uc42b\udb9a\udf01\ud9bf\ude8f\udb50\ude4d\ud99b\uded3\udb87\udfca\udb19\udf61\ud984\udea4", "\uaa27\u9ea4\ubd22\u54e8\ucd67\u60f8\u15c7\uc803\u5442", "\ud859\udf52\udb03\udf7a\ud8bb\udcac\uda87\udcb4\ud9c8\uddf8\ud93a\ude68\uda1f\udec3\uda7b\udec3",
        16, 80078, 214839404, -375683842914416030L, -63641L, true, false, (char) 22627, (char) 60782,
        Double.longBitsToDouble(0x3fb69731fdeac628L), Double.longBitsToDouble(0x3fe8fb16a6a5eb8fL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Double:0.8671064290236049\0121=java.lang.Double:0.5214326599872127\012",
        Z.run(T, 2, 3, 7, 5, "\ud9c1\udd43\udaee\uddd5\ud992\udf03\ud8ee\udddd", "\u5871\u8798\u95f4", "\ud984\udea4\udbfe\uddfb\ud9d8\udecd\ud9d0\udd2f\ud8ec\uddd5\u915c\udb40\udceb\ud874\udcd9\ud90d\udf37\ud875\udf25\ud993\udf24\ud944\udcbb\udb0e\udca6",
        25, 71092, -249302256, -5167128405442741256L, 79043L, false, false, (char) 33873, (char) 24479,
        Double.longBitsToDouble(0x3febbf55fb59d8e9L), Double.longBitsToDouble(0x3fed9fc0064cfd90L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Double:1.1708434750788081\0121=java.lang.Double:0.6572380344344378\012",
        Z.run(T, 2, 16, 14, 11, "\udb65\udc41\ud809\udcd5\ud8ff\udcfa\ud935\udd95\ud8ea\udd3e\udb74\udc78\udb52\udf0d\udb2a\udf3a\ud99b\uded3\udb87\udfca\udb19\udf61\ud984\udea4\udbfe\uddfb\ud9d8\udf47", "\ubd22\uaac7\u09e3\u9ba2\ubca5\uc803\u14f9\u4175\u23a3\u6572\u389c\ua71a\u172a\ud66f\ud7e9", "\uda5b\udc39\udaa9\udd3a\ud854\udedc\uda1c\ude2f\udb15\udd0b\uda9f\udeb4\ud8cf\udf5b\ud8ea\udddf\udb81\udf1b\udb66\udcc3\ud8fd\udfe7\ud93f\udd45",
        50, 95318, 1911192761, 2001170137508504253L, -83838L, false, false, (char) 16551, (char) 12172,
        Double.longBitsToDouble(0x3fe272df1aee94b9L), Double.longBitsToDouble(0x3f7df425d7075000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Double:1.3803639164078387\0121=java.lang.Double:1.3803639164078387\012",
        Z.run(T, 2, 0, 0, 12, "{\000\ud9fd\uddcf\uda1f\udd6f", "\u5871\u8798\u95f4", "\ud984\udea4\udbfe\uddfb\u00ca\u9f00\ud8eb\udfd5\uda24\udc5b\udb2e\udd5b\ud874\udcd9\ud90d\udf37",
        45, 443, -2092507115, -7619679839175618892L, -38651L, false, false, (char) 47426, (char) 0,
        Double.longBitsToDouble(0x3feb1800045aef62L), Double.longBitsToDouble(0x3fe9150979c1b5deL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:0.3855396073886762\0121=java.lang.Double:0.7067766845519464\012",
        Z.run(T, 2, 3, 11, 5, "\ud9c1\udd43\ud806\udf79\ud9fd\uddcf\uda04\udfe3", "\u57ee\u8798\u95f4", "\u5318\ud8a2\udd57\ud872\udd21\ud9c6\udd2f\ud8ec\uddd5\ud80c\ude2f\udb26\udf52\ud874\udc6f\ud90d\udf37\ud875\udf25\ud993\udf24\ud944\udcbb\udaa5\udf53\ud902\udccb\ud859\udc44\udb03\udf7a\ud877\udfde",
        46, 38680, 545354339, -6832184549789736158L, -39749L, false, false, (char) 58314, (char) 63373,
        Double.longBitsToDouble(0x3fd8acae514302c6L), Double.longBitsToDouble(0x3fe1c720f885770aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Double:0.15622109485724398\0121=java.lang.Double:0.10911741080637212\012",
        Z.run(T, 2, 13, 9, 5, "\ud9c1\udd43\ud95e\udde2\ud9a5\ude44\ud89a\udfba", "\u5871\u8798\u7b95\u5fb5\u44d1\u77ba\u14fc\u3eac\u1f82\u9ea4\ubd22\u54e8", "\ud875\udea3",
        28, 9885, -1774095054, -7225094642855102817L, -12984L, false, true, (char) 23761, (char) 15111,
        Double.longBitsToDouble(0x3fbbe0efa79a96f0L), Double.longBitsToDouble(0x3fe62012e14a24d2L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Double:0.8468031964361951\0121=java.lang.Integer:50\012",
        Z.run(T, 2, 3, 5, 5, "\uda8d\udc8a\ud96b\udda2\ud9fd\uddcf\uda1f\udd6f", "\u5871\u8798\u95f4", "\ud984\udea4\udbfe\uddfb\ud9d8\udf47\ud9c6\udd2f\ud8ec\uddd5\uda24\udc5b\udb2e\udd5b\ud874\udcd9\uda03\udf33",
        50, 32725, -2092507115, -7619679839175618892L, -84987L, false, false, (char) 62530, (char) 10208,
        Double.longBitsToDouble(0x3feb1903045aef62L), Double.longBitsToDouble(0x3fe9150979c1b5deL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Long:138286001160463506\0121=java.lang.Long:138286001160463506\012",
        Z.run(T, 2, 6, 6, 15, "\ud9c1\udd43\ud989\udda3\udb82\udf93\udb7c\ude8d\udb0a\uddd8\udb9a\ude38\ud9bf\ude8f\udaec\uddba\ud99b\uded3\ud873\udf21\ud999\udde7\ud984\udea4\uda35\ude94\ud9d8\udeaa\ud9c6\udd2f\ud994\uddc6\ud8d6\uddb2\udb2e\udd5b\uda1e\udc8c\uda6c\udff1\ud867\udd39\ud993\udf24\ud944\udcbb\udaa5\udf53\ud902\udccb\ud859\udc44\ud96b\ude85\ud87d\udede\u5e73\ud937\udfb1\ud93a\udf77\uda1f\udec3\uda7b\udec3\uda8b\udf50\udaf5\udc5d\ud99c\udebb\udb80\ude08\udaff\uded2\uda18\ude72\udb1a\udfce\uda53\ude72\u77b5\ud9ae\udca0\uda06\udca9\ue807\ud9e0\udcdd\udadf\udde0\ud8b6\uddcf", "\u3125\u2175\u9e92\u71c8\u581d\u63da\ua5cd\u1732\u931d\u7463\u60f7\uc9d4\u1739\u8a36\u8794\u9505", "\udb11\udd6d\udbf0\udca1\udad9\udcda\udaf3\udff8\ud991\udf92\ud932\udef8\udad3\ude57\u2f1d",
        56, 37943, 1531827899, 138286001160463506L, 58658L, true, false, (char) 38215, (char) 33458,
        Double.longBitsToDouble(0x3fe9e73c383cfd23L), Double.longBitsToDouble(0x3fe8bb8d3d7409a8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Double:0.9838736387599165\012",
        Z.run(T, 1, 3, 12, 2, "\ud9bf\udca9\udadc\udf3d\ucc3c\ud840\udfc7\u42eb\udb9a\udf26\ud8b8\udd4d\uda19\udd99\ud99b\udeeb\udb87\udfca\ud90f\udddb\ud985\uddfe\ud875\udfae\uf190\ud8d8\uddb8\udb48\udf0f\ud8dd\udf25\uda7a\udd61\ud874\udcd9\ud90d\udf37\ud875\udf25\ud893\udcc5\ud944\udcbb\udaa5\udf53", "\u4ebd\ua71a\ub1e5\ud66f\ud7b1\u9bf9\u2b46\u815a\uc98d\u9280\u2145\u1b36\u8a8f\u578c\u6fe4\ub4c7\u10fc\u1c08\u1f1c\u2e6e\uc3f9\u3b37\u04e8\u4f4a\u5f7e\u1796", "\udac9\udcef\ud8d2\udcfe\ud83c\udf8f\ud8af\udceb\ud91b\udd4c",
        52, 55516, -988557300, 2805101582333342102L, 78366L, false, true, (char) 62437, (char) 44009,
        Double.longBitsToDouble(0x3fef7be491bbd9fcL), Double.longBitsToDouble(0x3fe56d3caad74689L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Double:0.49283159644646257\0121=java.lang.Float:0.4928316\012",
        Z.run(T, 2, 3, 4, 1, "\ud9c1\uddb1\ud989\udda3\ud9fd\uddcf\uda1f\udd6f\ud9a7\udf13", "\u2f9c", "\udb19\udf61\ud9d2\udf8a\u3981\udbbd\udc02\ud9c6\udd2f\ud8ec\uddd5\uda23\udfaf\udb2e\udd5b\ud874\udcd9\udaca\udd16\udb8f\udcba\udbd3\udf12\udab7\udf91\udaa5\udf53\ud902\udccb\ud9be\udf63\udb03\udf7a\ud877\udfde\udb9b\udc5d\ud8a9\uded3\ud977\udd71\ud979\udc44\ud97b\ude13\uda0f\udea3\ud801\udf90\ud952\udc70\uda80\udeeb\ud93f\udce3\udb87\udfb0\ud8f1\udd7a\ud8fd\udf94\udabb\udc56\uda26\udd3c",
        44, 98458, 1897839892, -6702554743663769862L, -20689L, false, true, (char) 26582, (char) 49427,
        Double.longBitsToDouble(0x3fdf8a8d894b12deL), Double.longBitsToDouble(0x3fcb07f8bd348c04L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:0.8910643938121969\0121=java.lang.Double:0.8910643938121969\012",
        Z.run(T, 2, 3, 3, 15, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf\uda1f\udd6f", "\u5871\u8798\u95f4", "\ud982\udd06\udaa0\udc27\ud9d8\udf47\ud9c6\udd2f\ud8ec\uddd5\uda24\udc5b\udb2e\udd5b\ud88a\uddd9\ud90d\udf37",
        27, 3133, -1371086827, -2190497450798919980L, 81256L, false, false, (char) 56258, (char) 9149,
        Double.longBitsToDouble(0x3fec839979c1b5deL), Double.longBitsToDouble(0x3fa067c29db74f20L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Double:0.781046478496299\0121=java.lang.Long:8555535345822729637\012",
        Z.run(T, 2, 3, 6, 15, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf", "\u01b2\u344b\u6780\u4de2\u6e74\u4e01\ua507\uac04\ub4a5\uaa27\u9ea4\ubd22\u54e8\u09e3\u60f8\u26aa\u50d9", "\ud9ae\uddc0\ud9ea\udf51\ud93e\udff3\ud877\udfde\uda87\udcb4\ud9c8\uddf8\ud93a\ude68\uda1f\udec3\uda7b\udec3\ud819\udc18\uda2d\ude17\ud9fc\udd4e\udbb2\udc88\ud9ca\udfef\u7862\ud813\udfd3\uda1e\udd7b",
        41, 81512, 347351298, -8555535345822729637L, -88007L, true, true, (char) 48458, (char) 18514,
        Double.longBitsToDouble(0x3fe8fe552f3985b5L), Double.longBitsToDouble(0x3fd68718f66b3430L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:1.5707963267948966\012",
        Z.run(T, 2, 3, 7, 5, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf\uda1f\udd6f", "\u5871\u8798\u95f4", "\ud984\udea4\udbfe\uddfb\ud9d8\udf47\ud9c6\udd2f\000\000\udb22\udd11\ud874\udcd9\ud90d\udf37",
        45, 443, -2092507115, -7619679837493395456L, -38651L, false, false, (char) 47178, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Double:0.8468031964361951\0121=java.lang.Double:NaN\012",
        Z.run(T, 2, 3, 8, 10, "\ud9c1\udd43\ud989\udda3\ud9e9\udf38\uda1f\udd6f", "\u5871\u062b\u9685", "\ud8d9\udd6d\udbfe\uddf1\ud9d8\udf47\ud9c6\udd2f\ud8ec\uddd5\uda24\udc5b\udb2e\udd5b\udb83\uddff\ud834\ude39",
        45, 443, -2092507115, -2553146751056333700L, 79307L, false, true, (char) 8307, (char) 23800,
        Double.longBitsToDouble(0x3feb1903045aef62L), Double.longBitsToDouble(0x3fe1150979e8ae32L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Long:4060650100466894391\0121=java.lang.Double:-2.370090412463405\012",
        Z.run(T, 2, 6, 11, 6, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf\uda1f\udd6f\ud9a2\udcc5\ud9ac\udda8\ud9bf\ude8f\udaec\uddba", "\uc3a3\ua507\uac04\u2f95\u2526\u0a1e\u754c\u2d51\u09e3\u60f8\u15c7\uc803\u5442\ub03a\u575d\u7f42\u4ebd\ua71a\ub1e5\ud66f\ud7b1\u9bf9", "\uda89\udeb5\ud995\uddf1\uda9c\udf8e\ud9b8\ude4c\udb00\udfb6\ud89d\udd4a",
        4, 58952, -665275361, -4060650100466894391L, 858L, true, false, (char) 46179, (char) 48902,
        Double.longBitsToDouble(0x3fe942db61219f89L), Double.longBitsToDouble(0x3fca9e3362674574L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Double:0.7103709042188145\0121=java.lang.Double:0.8922674599548234\012",
        Z.run(T, 2, 3, 15, 15, "\ud9c1\udd3e\ud989\udda3\ud9fd\uddcf\uda1f\udd6f\udbbf\uddb4", "\u8798", "\uda6e\ude2a\u8ff1\ud91d\udfd6\ud9d8\udf47\uda6d\udd81\ud8f7\udd65\uda23\udf9f\udb2e\udd5b\ud874\udcd9\ud90d\udf37\ud875\udf25\ud993\udf24\ud9fe\uddb0\udaa5\udf53\ud902\udccb\ud859\udc44\udb03\udf7a\ud877\udfde\uda87\udcb4\ud9c8\uddf8\ud93a\ude68\uda1f\udec3",
        42, 39913, 1657549182, -8543774971748906083L, -28496L, false, false, (char) 23009, (char) 47710,
        Double.longBitsToDouble(0x3fe6bb5bc334cacfL), Double.longBitsToDouble(0x3fcf706618bfa068L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Double:0.25819536663871845\0121=java.lang.Double:0.2610737032174047\012",
        Z.run(T, 2, 3, 1, 5, "\ud9c1\udcdd", "\u05bb", "\ud9bf\ude8f\ud98a\udebf\ud99b\uded3",
        21, 47413, -1871140553, -7035458534413077814L, 97120L, false, true, (char) 62785, (char) 64853,
        Double.longBitsToDouble(0x3fd08645dbec4a24L), Double.longBitsToDouble(0x3fefd8a0c0157986L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Double:0.5608501934363114\0121=java.lang.Double:0.5608501934363114\012",
        Z.run(T, 2, 7, 7, 5, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf\uda1f\udd6f", "\u5871\u8798\u95f4", "\ud984\udea4\udbfe\uddfb\ud9d8\udf47\ud9c6\udd2f\ud8ec\uddd5\udbb6\ude23\udb23\udde3\ud874\udcd9\ud90d\udf37",
        45, 443, -2092507115, -7619679838789742924L, -38651L, false, false, (char) 62530, (char) 23761,
        Double.longBitsToDouble(0x3feb190302f5ef62L), Double.longBitsToDouble(0x3fe9150979c1b5deL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Double:0.22381415838993146\0121=java.lang.Double:0.5926774999272085\012",
        Z.run(T, 2, 10, 11, 3, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf\ud992\udff1", "\u0460\u8798\ud219", "\u5b9c\udb1d\udd01\ud836\udd58\ud9c6\udd2f\ud8b7\udc7a\uda02\udc31\udb2e\udd5b\ud874\udcd9\ud90d\udf37\ud875\udf25\udaa8\ude5b\ud944\udd00",
        19, 31564, 1183397535, 7157761597070027979L, -47866L, false, true, (char) 56319, (char) 57515,
        Double.longBitsToDouble(0x3fcce353523afec8L), Double.longBitsToDouble(0x3fdfd91ec2727afaL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Double:0.016132121981557893\0121=java.lang.Double:1.5546642048133388\012",
        Z.run(T, 2, 9, 7, 5, "\ud883\udce5\ud989\ude1a\ud9fd\uddcf\uda1f\udd6f", "\u5871\u8798\u95f4", "\ud984\udea4\udbfe\uddfb\ud9eb\ude26\ud9c6\udd2f\ud8ec\uddd5\uda24\udc5b\udb2e\udd5b\ud874\udc5c",
        59, 190, -1803094021, -8987249627346406001L, 17089L, true, false, (char) 40251, (char) 62530,
        Double.longBitsToDouble(0x3f9084c16c640c00L), Double.longBitsToDouble(0x3fb6bbd899150978L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Long:1771253573746871838\0121=java.lang.Double:0.08993299457903954\012",
        Z.run(T, 2, 6, 14, 4, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf\uda1f\udd6f", "\u5871\u8798\u95f4", "\ud984\udea4\udbfe\uddfb\ud9d8\udf47\ud9c6\udd2f\ud8ec\uddd5",
        8, 7906, 1750118718, 1771253573746871838L, 88489L, true, true, (char) 58613, (char) 53850,
        Double.longBitsToDouble(0x3fb6f602a0c78918L), Double.longBitsToDouble(0x3fefc5c2501084c1L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Double:0.8468031964361951\012",
        Z.run(T, 1, 3, 7, 5, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf\uda1f\udd6f", "\u97b4\u8798\u1a1a", "\ud984\udea4\udbfe\uddfb\udb26\udece\000\ud8ec\uddd5\uda24\udc5b\udb16\udd0b\ud874\udcd9\ud90d\udf37",
        25, -1000, 0, -7619679839175618892L, -38651L, false, false, (char) 62530, (char) 23761,
        Double.longBitsToDouble(0x3feb1903045aef62L), Double.longBitsToDouble(0x3fe9150979c1b5deL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Double:1.0283377862992098\0121=java.lang.Double:0.9838620143134877\012",
        Z.run(T, 2, 7, 13, 5, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf\uda1f\udd6f", "\u5871\u8798\u3b95", "\ud984\udea4\udb1c\udf08\udb5a\udc0d\uda55\udc6d\ud902\udc19\uda24\udc5b\udb2e\udd5b\ud874\udcd9\udb29\udec6\uda06\ude0c\ud993\udf24\ud91b\udebb\udaa5\udf53",
        24, 17720, -249360293, -5167128405442741256L, 79043L, false, false, (char) 33873, (char) 24479,
        Double.longBitsToDouble(0x3fe0851059443c08L), Double.longBitsToDouble(0x3fd5f9b59ff6c83cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Double:0.05606799712304062\0121=java.lang.Double:1.5147576826884404\012",
        Z.run(T, 2, 14, 7, 7, "\ud967\udc46\ud922\ude57\ud8fc\udea0\ud817\udefb", "\ucb1a", "\udb87\udfca",
        33, 99127, 377030589, 8512720028905861205L, -41585L, false, false, (char) 64853, (char) 47570,
        Double.longBitsToDouble(0x3facad40e089e870L), Double.longBitsToDouble(0x3fc3b403363fb1ccL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Double:0.7307075259648849\0121=java.lang.Double:0.7307075259648849\012",
        Z.run(T, 2, 15, 15, 12, "\ud995\udf25\uda87\udd82\ud9fd\uddda\uda1f\udd6f", "\u9821\u600e\u40c7\u81db", "\u9ed6",
        59, 74729, -47513088, -4300739871457746918L, 77533L, false, true, (char) 64159, (char) 56681,
        Double.longBitsToDouble(0x3fd8f8346d692c82L), Double.longBitsToDouble(0x3fe4fcda205bd80aL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Double:-2.616060094111058\0121=java.lang.Double:-2.616060094111058\012",
        Z.run(T, 2, 11, 11, 0, "\ud920\udd50\ud9db\udd69\ud9fd\uddcf", "\u01b2\u5871\u8798\u95f4\u6e74\u1e43\ub31d\ubd5f\ub1b4\uaa27\u9ed6\ubd22\ua2d5\u09e3\u60f8\u15c7\uc803", "\ud902\udccb\ud859\udc44\udb03\udf7a\ud877\udfde\uda87\udcb4\ud9c8\uddf8\ud93a\ude68\uda1f\udec3\uda7b\udec3\udb87\udd2e\udab3\udfe3\udb28\uddbf\ud964\udf9f\uda0c\udd2c\ud80f\udca3\ud9c2\udfd7\ud9bd\udf5c",
        38, 30750, -206629537, 3462862971169904014L, -32798L, true, true, (char) 64759, (char) 48326,
        Double.longBitsToDouble(0x3fb0eea78397bf78L), Double.longBitsToDouble(0x3fe16b922f8a21c1L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Double:0.0701254005042537\0121=java.lang.Double:0.0701254005042537\012",
        Z.run(T, 2, 10, 10, 5, "\ud9c1\udd43\ud86d\udea4", "\ua27f\u01b2\u5871\u8798\u3e65\u6e74\uc3a3\ua507\uac04\ub4a5\u251e\u4059\u0360\u54e8\u09e3\u60f8", "\ud944\udcbb",
        19, 31564, -670419297, -1070994304609375208L, -47866L, false, true, (char) 45215, (char) 22267,
        Double.longBitsToDouble(0x3fb1f7817d5d41c0L), Double.longBitsToDouble(0x3fe662c2d95bcc05L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Long:3282425673333362604\0121=java.lang.Double:-2.2481772160482736\012",
        Z.run(T, 2, 6, 11, 5, "\ud9ee\udda9\udbb7\udddc\ud9fd\uddc1\uda1f\udd6f\udbbf\uddb4\udb9a\udf01\ud9bf\ude8f\udad8\udf01\ud99b\ude71\udb87\udfca\udb19\udf61\ud984\udea4\udbfe\uddfb\ud9d8\udf47\ud9c6\udd2f\ud8ec\uddd5\uda24\udc5b\udb2e\uddbe\ud96a\ude88\ud8e4\udf20\ud875\udf25\ud993\udf24\ud944\udcbb\udaa5\udf53\ud902\udccb\ud859\udc44\udb03\udf7a\ud877\udfde\uda87\udcb4\ud9c8\uddf8\ud93a\ude68\uda1f\udec3\uda7b\udec3\ud99a\udc38\udb21\udd9f\ud9de\udee4\uda8d\udc2f\uda27\udd72\uda35\uddfa\ud93f\ude9e\u5f3e\uda7d\udfdf\udb55\udc34\udac1\ude2e", "\ubb3f\u9c87\u4694\uba3f\u8210\ucfe4\uab3e\ub7b7\u9757", "\udbdf\udda9\udbcd\udc06\udb89\udfb1\ud80c\udd5b",
        38, 43125, -1909582304, -3282425673333362604L, -97902L, true, false, (char) 12777, (char) 20618,
        Double.longBitsToDouble(0x3fea3e20b8e3fb16L), Double.longBitsToDouble(0x3fe008aa91a981feL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:45\012",
        Z.run(T, 1, 5, 9, 8, "\u6928\ud85f\uddd0\ud9fd\uddb1\uda1f\udd6f", "\u57d9\u8798\u95f4", "\ud984\udea4\ud9dc\udf86\uda64\udf4d\ud9c6\udd2f\ud9c4\uddea\udbe6\udf21\ud9e0\uddd4\ud874\udcd9\ud90d\udf37",
        45, 443, -2092507115, -560569029980619647L, -69612L, false, true, (char) 53421, (char) 60651,
        Double.longBitsToDouble(0x3feb1903045aef62L), Double.longBitsToDouble(0x3fe9150979c1b5deL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:51\0121=java.lang.Double:0.08957149759630255\012",
        Z.run(T, 2, 5, 10, 0, "\ud9c0\udee2", "\u0a5b", "\ud91d\udc3f\udbb7\udd0b\ud959\udd2d\uda5b\udcd5\uda4a\ude17\ud806\udd37\udbfe\uddfb\ud99d\udf12\ud80c\udeca\ud897\udc20",
        51, 52602, -841767954, 2670436486550672886L, -51851L, false, false, (char) 45104, (char) 53722,
        Double.longBitsToDouble(0x3fb6f6029f8d8888L), Double.longBitsToDouble(0x3feca275ef452bc1L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Double:0.08981162125555373\0121=java.lang.Double:1.4809843164973233\012",
        Z.run(T, 2, 1, 7, 7, "\ud9c1\udd43", "\u6849", "\000\000\000\uda3d\udcd5\udb57\udd7e\000\ud9cc\udc05\udac6\ude43\ud91e\udd4e\uda5e\udd0e",
        56, 7490, 1683871816, 2671241002644690422L, -51872L, false, false, (char) 20650, (char) 39898,
        Double.longBitsToDouble(0x3fb6f602a0c78918L), Double.longBitsToDouble(0x3feabdc2500000c1L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Double:0.00568573920756973\012",
        Z.run(T, 1, 14, 1, 7, "\ud9c1\udd43\ud989\udda3\uda20\ude42\ud87b\ude34\udb21\udfa1\udb26\udebb\ud91d\udc3f\ud90f\udd9f\udba0\udd20\uda39\udf6e\uda4a\ude17\uda14\ude5e\ud875\uded2\ud99b\udfec\udb39\ude15\ud975\ude2a\ud807\udc3e\ud811\udf6b\u6b34\ud8ea\uddb9\ud999\uddf7\ud8da\udd69\ud8b3\udedb\ud9bb\udfbe\udafc\udec6\ud859\udc44\udb08\ude62\ud877\udfde", "\u61f9\u6520", "\uda5b\udc4b\uda9e\udef4\ud98d\uddaf",
        57, 6740, 796840543, -6450511005827937052L, -71L, true, false, (char) 63142, (char) 45344,
        Double.longBitsToDouble(0x3f7749dd8ce4f700L), Double.longBitsToDouble(0x3fe4bd2c8641e69dL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Double:0.1327797630420216\0121=java.lang.Double:0.40619698493215894\012",
        Z.run(T, 2, 10, 13, 8, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf", "\u01b2\ubb33\u8798\u95f4\u6e74\uc3a3\ua507\uac04\ub4a5\uaa27\u9ea4\ubd22\u54e8\u09e3\u39f7\u15c7\uc803", "\ud88a\udeee\ud859\udc44\udb03\udf7a",
        57, 60875, 258005008, -1197188033310411686L, 53151L, false, true, (char) 56649, (char) 51421,
        Double.longBitsToDouble(0x3fc10bb92e470290L), Double.longBitsToDouble(0x3fd3d0b6cc0552aeL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Double:0.020968324389495398\0121=java.lang.Double:0.030996590088749002\012",
        Z.run(T, 2, 12, 13, 8, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf", "\u01b2", "\ud99b\uded3\udb87\udfca\udb19\udf61\ud984\ude9b",
        51, 73530, 371957729, -204067160093314080L, 67185L, false, true, (char) 31496, (char) 3091,
        Double.longBitsToDouble(0x3f957986b1f068c0L), Double.longBitsToDouble(0x3fe5a4b20e9f47bbL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\0121=java.lang.Double:0.8151434035222476\012",
        Z.run(T, 2, 8, 14, 5, "\ud8ba\udce0\ud8f8\udc4d\ud9fd\uddcf", "\u01b2\u5871\u8798\u95f4\u6e74\uc3a3\ua507\uac04\ub4a5\u73e4\u22e7\ubd09\u1457\ubbbf\u616d\u15c7\u3fea", "\ud88a\udeee\ud859\udc44",
        47, 45168, -2067710984, 1108123071285476308L, -27074L, true, true, (char) 63627, (char) 59729,
        Double.longBitsToDouble(0x3fe5847270076c14L), Double.longBitsToDouble(0x3fec4c51313d0b6cL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Double:1.254496410017243\0121=java.lang.Double:1.254496410017243\012",
        Z.run(T, 2, 13, 13, 8, "\ud9c1\udd43\udb9b\udcaa\uda87\udf95", "\u01b2\u5871\u8798\u95f4\u6e74\uc3a3\ua507\ub5cb\ub4a5\u63c8\u9ea4\ubd22\u54e8\u09e3\u60f8\u15c7\uc803", "\ud88a\udeee\ud859\udc44\udb03\udf7a\ud877\udfde\uda87\udcb4\u18f8\ud93a\uded9\uda1f\udec3\uda7b\udec3\udb4e\udc51\ud9ae\udd1d\udae6\udffb\uda30\udd06\uf915\ud935\udc35\uda63\udc21\uda40\ude26",
        24, 3609, -4979133, -3818208607652279675L, -3530L, true, true, (char) 24101, (char) 17464,
        Double.longBitsToDouble(0x3fe1d8646b01c80cL), Double.longBitsToDouble(0x3fc75cb8408c8bc0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Double:0.020969861084466017\0121=java.lang.Double:0.030996590259365683\012",
        Z.run(T, 2, 10, 13, 8, "\ud9c1\udd43\ud989\udda3\udb4b\udd56", "\u01b2", "\ud99b\uded3\udb87\udfca\udb19\udf61\ud984\udea4",
        51, 73530, 1227595745, -204066370124767370L, 67185L, false, true, (char) 31496, (char) 3091,
        Double.longBitsToDouble(0x3f957986b1f068c0L), Double.longBitsToDouble(0x3fe5a4b20c9f47bbL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Double:0.586574179718011\0121=java.lang.Integer:4\012",
        Z.run(T, 2, 12, 5, 5, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf", "\u01b2\u5871\u8798\u95f4\u6e74\uc3a3\ua507\uac04\ub4a5\uaa27\u9ea4\ubd22\u54e8\u09e3\u60f8\u15c7\u5bee", "\ud88a\udeee\udb6f\udf50",
        -4, 33932, -2067711054, 1108123071285476308L, -78373L, true, true, (char) 34130, (char) 59729,
        Double.longBitsToDouble(0x3fe5447270076c14L), Double.longBitsToDouble(0x3fec4c51313d0b6cL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Double:0.5087090485369061\0121=java.lang.Double:0.5087090485369061\012",
        Z.run(T, 2, 12, 12, 8, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf", "\u01b2\u5871\u8798\u95f4\u6e74\uc3a3\ua507\uac04\ub4a5\uaa27\u9ea4\ubd22\u54e8\ua35d\u60f8\u15c7\uc803", "\ud88a\udeee\ud859\udc44\udb03\udf7a\ud877\udfde\uda87\udcb4\u18f8\000\udb0c\ude66\uda7b\udec3\udb4e\udc51\ud9ae\udd1d\udae6\udffb\000\uf90e\ud935\udc35\uda63\udc21\uda40\ude26",
        24, -815, 0, -3818208607652279675L, -3532L, true, true, (char) 24101, (char) 17464,
        Double.longBitsToDouble(0x3fe1d8646b01c80cL), Double.longBitsToDouble(0x3fc75cb840008bc0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Double:1.4902362021694817\0121=java.lang.Double:1.4902362021694817\012",
        Z.run(T, 2, 14, 14, 8, "\ud849\udd17\ud989\udda3\ud9fd\uddcf", "\u01b2\u91e6\u41d2\u95f4\u6e74\uc3a3\ua507\uac04\ub4a5\uaa27\u9ea4\ubd22\u54e8\u09e3\u60f8\u15c7\uc803", "\udbc4\udd9f\ud859\udc44\udb03\udf6d\ud877\udfde\uda87\udcb4\u18f8\ud93a\uded9\uda1f\udec3\uda7b\udec3\udb4e\udc51\ud822\udf97\ud9e0\ude8f\uda30\udd06\uf915\ud935\udc35\uda63\udc21\uda40\ude26",
        30, 3631, -4979133, -3818208607652279675L, -3532L, true, true, (char) 24101, (char) 17464,
        Double.longBitsToDouble(0x3fece8646b0158e3L), Double.longBitsToDouble(0x3fc74edb208c8bc0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:NaN\012",
        Z.run(T, 2, 9, 2, 8, "\udb76\udf7e\ud989\udda3\u00c3", "\u4987\u5871\u8798\u95f4\u0911\uc3a3\ua4d0\u7b96\ub4a5\uaa27\000\u30e3\u54e8\u09e3\u251e\u14d1\uc803", "\ud861\udc2f\ud859\udc44\udb03\udf7a\ud877\udfde\uda87\udcb4\u18f8\ud93a\uded9\uda1f\udec3\ueb22\000\000\udae6\udf4c\uda30\udd06\uf915\ud935\udc35\uda63\udc21\uda40\ude26",
        19, 3424, -4979133, -3818208607652279675L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Integer:41\0121=java.lang.Integer:41\012",
        Z.run(T, 2, 5, 5, 0, "\uc82e\ud989\udda3\u86c3\ud9ff\udeff\uc42b\udb9a\udf01\ud9bf\ude8f\udb50\ude4d\ud99b\uded3\uf5c5\000\ud95a\udd6d", "\ub113", "\udb2e\udd5b\udb08\udfdf\ud831\udd09\u55f6",
        41, 9885, 30095, 52721582551859200L, -34464L, false, false, (char) 23568, (char) 56258,
        Double.longBitsToDouble(0x3fb6bbd899100000L), Double.longBitsToDouble(0x3fdc1b5deb1ce810L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Float:0.43917033\0121=java.lang.Float:0.43917033\012",
        Z.run(T, 2, 4, 4, 5, "\uc82e\ud989\udda3\ud9fd\uddcf\ud83c\udf07\ud9f5\ude17\udaee\udf2a\ud9bf\ude8f\udb50\ude4d\ud99b\uded3\udb87\udfca\udb35\udf61\ud984\udea4", "\uaa27\u9ea4\ua53f\u54e8", "\ud85b\udcba\ud993\udf24\ud944\udcbb",
        19, 31564, -1655560229, 1613995501583188398L, 97722L, true, true, (char) 9289, (char) 33873,
        Double.longBitsToDouble(0x3fdc1b5deab32810L), Double.longBitsToDouble(0x3fbb35db2d686670L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Double:0.29045056435234196\0121=java.lang.Double:0.29045056435234196\012",
        Z.run(T, 2, 1, 1, 5, "\ud9c1\udd43\udaee\uddd5\ud992\udf03\ud8d0\udf08", "\u1969\u8798\u95f4", "\ud984\udea4\udbfe\uddfb\ud9d8\udecd\ud9d0\udd2f\ud8ec\uddd5\u915c\ud880\udecb\ud877\udf57\ud90d\udf37\uda23\udde2\ud968\ude27\ud944\udcbb\udb0e\udca6",
        25, 71092, -249302256, 6480587605820914637L, 79043L, false, true, (char) 62901, (char) 48719,
        Double.longBitsToDouble(0x3fd2564097d19a92L), Double.longBitsToDouble(0x3fed9fc0064cfd90L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Double:0.0012793899295231448\0121=java.lang.Double:0.0012793895804976\012",
        Z.run(T, 2, 3, 10, 2, "\ud8ca\udcfb\u0a56\ud992\udf03\udbf7\udc61", "\u5871\u8798\u42f5", "\ud984\udea4\u0c00\ud9d8\udecd\ud9d0\udd2f\ud8ec\uddd5\u915c\uda2f\udf77\ud874\udcc1\ud90d\udf37\ud875\udf25",
        28, 9885, 426699151, -4782067377588744140L, -5843L, false, true, (char) 23761, (char) 56258,
        Double.longBitsToDouble(0x3f54f62679fe1800L), Double.longBitsToDouble(0x3fe23809d0ec0ad5L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:5.461174623633269E-9\012",
        Z.run(T, 2, 16, 14, 11, "\udb65\udc41\ud809\udcd5\ud8ff\udcfa\ud935\udd95\ud8ea\udd3e\udb74\udc78\udb52\udf0d\udb2a\udf3a\ud99b\uded3\udb87\udfca\000\000\000\ud9d8\udf47", "\ubd22\uaac7\u09e3\u9ba2\ubca5\uc803\u14f9\u4175\u42d7\u6572\u389c\ua71a\u172a\ud65f\ud7e9", "\uda5b\udc39\000\000\000\udaf7\udf9b\uda9f\udeb4\ud8cf\udf5b\ud8ea\udddf\udb81\udf1b\udb66\udcc3\000\000",
        -5, 95318, 1911192761, 2001170137508504253L, -83838L, false, false, (char) 16551, (char) 12172,
        Double.longBitsToDouble(0x3e3774a000000000L), Double.longBitsToDouble(0x3f7df425d7075000L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:3.141592653589793\012",
        Z.run(T, 2, 3, 11, 5, "\ud9c1\udd43", "\u1dba\ua27f\u01b2\u57ee\u8798\u95f4\u99b6\u2f2a", "\ud872\udd21",
        34, 90560, -481446944, -8493170675333201787L, -77994L, true, true, (char) 22939, (char) 70,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fb6f60020c78918L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 3, 3, 9, "{\ud806\udf79\ud9fd\uddcf\uda04\udfe3", "\000\000\u7bda", "\000\000\ud872\udd21\uda2d\udfe3\000\ud9d5\ude4a\u3245\000\000\000\ud955\udf29\ud90c\udcbb\udaa5\udf53\ud8ee\ude17\ud859\udc44\u1000\ud877\udfc6",
        -5, -1000, 545325056, -6832184549789736158L, -39749L, false, false, (char) 58314, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe1c720f885770aL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Double:0.3844710397723045\0121=java.lang.Double:0.3844710397723045\012",
        Z.run(T, 2, 9, 9, 14, "\ud9c1\udd43\ud95e\udde2\ud9a5\ude44\ud89a\udfba", "\u5871\u8798\u7b95\u5fb5\u44d1\u7b1e\u14fc\u3eac\u1f82\u8c6a\u0610\u38c3", "\udb28\ude55\ud959\udd5e\ud944\udcbb\udaa5\udef6\ud902\udccb",
        9, 7707, 1794419736, -8890987363126159344L, -2831L, true, false, (char) 52511, (char) 9756,
        Double.longBitsToDouble(0x3fd80120c1748066L), Double.longBitsToDouble(0x3fdf73a2068aa682L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Integer:50\012",
        Z.run(T, 2, 1, 5, 7, "\ubb7b\000\ud9fd\uddcf\uda1f\udd6f", "\u5871\u8798\u95f4", "\ud984\udea4\udbfe\uddfb\ud9d8\udf47\ud9c6\udd2f\udae5\udfd2\uda24\udc5b\udb2e\udd5b\ud874\udcd9\uda03\udf33",
        50, 32725, -2092507115, -7619679839175619072L, -84987L, false, false, (char) 62530, (char) 33985,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe9100001c1b5deL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\0121=java.lang.Double:NaN\012",
        Z.run(T, 2, 8, 8, 5, "\uda8d\udc8a\ud96b\udda2\ud9fd\uddcf\uda1f\udd6f", "\u5d22\ud240\ua2e6", "\ud8a1\udc51\udbfe\uddfb\ud9d8\udf47\ud9c6\udd2f\ud8ec\uddd5\uda24\udc5b\udb2e\udd5b\ud874\udcd9\uda03\udf33\ud9fc\udf33\udade\udd0f\ud944\udcbb",
        19, 31564, -670419297, -1070795292954416104L, -47866L, false, true, (char) 24479, (char) 11511,
        Double.longBitsToDouble(0x3fdb19ed241046b2L), Double.longBitsToDouble(0x3fce228a30996af4L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Long:5810566517838866019\0121=java.lang.Long:5810566517838866019\012",
        Z.run(T, 2, 6, 6, 15, "\ud9c1\udd43\ud989\udda3\udb82\udf93\udb7c\ude8d\udb0a\uddd8\udb9a\ude38\ud9bf\ude8f\udaec\uddba\ud99b\uded3\ud873\udf21\ud999\udde7\ud984\udea4\uda35\ude94\ud9d8\udeaa\ud9c6\udd2f\ud994\uddc6\ud8d6\uddb2\udb2e\udd5b\uda1e\udc8c\uda6c\udff1\ud867\udd39\ud993\udf24\ud944\udcbb\udaa5\udf53\ud902\udccb\ud859\udc44\ud96b\ude85\ud87d\udede\u5e73\ud937\udfb1\ud93a\udf77\uda1f\udec3\uda7b\udec3\uda8b\udf50\udaf5\udc5d\ud99c\udebb\udb80\ude08\udaff\uded2\uda18\ude72\u93d4\uda53\ude72\u77b5\ud9ae\udca0\uda06\udca9\udbff\udd06\ud9e0\udcdd\udadf\udde0\ud851\ude3d", "\u3125\u2175", "\ud80f\uddd3\ud98c\udcdd\ud9cb\ude5b",
        7, 11292, -79318589, -5810566517838866019L, -53956L, false, false, (char) 7667, (char) 39451,
        Double.longBitsToDouble(0x3fe820d17cc8f00dL), Double.longBitsToDouble(0x3fcf215fb57ed96cL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Double:0.4747910355573926\0121=java.lang.Double:0.4747910355573926\012",
        Z.run(T, 2, 10, 10, 1, "\ud9c1\uddb1\ud989\udda3\ud9fd\uddcf\ud859\ude6d\udb01\udcd8", "\u2f9c", "\udb19\udf61\ud9d2\udf8a\u3981\udbbd\udc02\ud9c6\udd2f\ud8ec\uddd5\uda23\udfaf\udb2e\udd5b\ud874\udcd9\udaca\udd16\udb8f\udcba\udbd3\udf12\udab7\udf91\udaa5\udf53\ud902\udccb\ud9be\udfac\udb03\udf7a\ud877\udfde\udb9b\udc5d\ud8a9\uded3\ud977\udd71\ud979\udc44\ud97b\ude13\uda0f\udea3\ud801\udf90\ud952\udc70\uda80\udeeb\ud93f\udce3\udb87\udfb0\ud8f1\udd7a\ud8fd\udf94\udabb\udc56\uda26\udd3c",
        44, 98458, 1897839892, -6702554743663769862L, -20689L, false, true, (char) 26582, (char) 49427,
        Double.longBitsToDouble(0x3fdf8a8d894b12deL), Double.longBitsToDouble(0x3fcb07f8bd348c04L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Float:0.0\0121=java.lang.Double:1.5707963267948966\012",
        Z.run(T, 2, 4, 7, 5, "\ud9c1\udd43\ud81e\ude8d\ud82e\udffc\uda1f\udd6f", "\u5871\u8798\u95f4", "\ud82e\udfcf\udbfe\uddfb\ud9d8\udf47\ud9c6\udd2f\000\000\udb22\udd11\ud874\udcd9\ud90d\udf37",
        45, 443, -2092507115, -7619679837493395456L, -38651L, false, false, (char) 7243, (char) 12336,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Double:1.5707963267948966\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 7, 13, 5, "\ud9c1\udd43\ud989\udda3\udaf4\ude6c\ud847\udef0", "\u5871\u8798\u5f80", "\ud984\udea4\udbfe\uddfb\ud9d8\udf47\ud9c6\udd2f\000\000\udb22\udd11\ud95d\udcd6\uda50\uded9",
        25, 1483, -2092507115, -7566199589956837076L, -38651L, true, false, (char) 47178, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 3, 11, 5, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf\uda1f\udd6f", "\u98bc\uce38\u95f4", "7\000\ud9bc\udc7d\ud9c6\udd2f\000\000\udb22\udd11\ud857\uddea\ud90d\udf37",
        45, 443, -2092507115, -7619679837493395456L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc0f561720b88d4L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 13, 15, 5, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf\uda62\udf10", "\u5871\u8798\u95f4", "\ud97d\udee3\udbfe\uddfb\ud9d8\udf47\ud9c6\udd2f\000\000\udb22\udd11\ud874\udcd9\ud90d\udf37",
        45, 443, -2092507115, -7619679837493395456L, 40146L, true, true, (char) 9287, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3f4d000000000000L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 11, 12, 5, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf\uda1f\udd6f", "\u5871\u8798\u6f92", "\ud984\udea4\udbfe\uddfb\ud9d8\udf47\ud9c6\udd2f\000\000\udb22\udd11\ud874\udcd9\ud90d\udf37",
        45, 443, -2092507115, -7619679837493395456L, -38651L, false, false, (char) 47178, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fdccae001fab28eL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Double:0.12433653773999523\0121=java.lang.Double:0.12433653773999523\012",
        Z.run(T, 2, 10, 10, 2, "\ud9dd\uded3\ud989\udda3\ud9fd\uddcf\uda1f\udd6f\ud988\udc14\udb94\uddf8\ud9db\udd36\ud821\udd83\ud9bb\udc80\udb87\udfca\ud975\udda4\ud984\udea4\udbfe\uddfb\ud9d8\udf47\ud9c6\udd2f\ud8ec\uddd5\uda24\udc5b\udb2e\ude02\ud8f4\udcd9\ud90d\udf37\ud875\udf25\ud993\udf24\ud8d9\udee4\udbc5\udec2\ud85c\udf65\ud813\udf5f\udb3b\udd97\ud9b0\udda5\udb6f\udd7b\udbc1\ude5b\ud811\udf72\ud8d8\ude93\ud87d\udfb4\ud93e\udf80\udb22\udf74\uda6a\ude4c", "J\ucdad\u5ec7\ube37\uabd1", "\udb35\udf56\ud8b0\udc07\udba0\udf0e\ud995\udee5",
        48, 38185, 1991061800, -1738128867474326725L, -97524L, false, false, (char) 57372, (char) 16740,
        Double.longBitsToDouble(0x3fbfe987f0742fe8L), Double.longBitsToDouble(0x3feb58f84f5181ecL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Double:0.05606799712304062\0121=java.lang.Double:0.05606799712304062\012",
        Z.run(T, 2, 14, 14, 7, "\ud967\udc46\ud922\ude57\ud8fc\udea0\ud817\udefb", "\ucb1a", "\ud81e\uddae",
        31, 99127, 376015585, 8512720028905861205L, -41585L, false, false, (char) 64853, (char) 47570,
        Double.longBitsToDouble(0x3facad40e089e870L), Double.longBitsToDouble(0x3fc3b403363fb1ccL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Double:0.020969861084466017\0121=java.lang.Double:0.020969861084466017\012",
        Z.run(T, 2, 10, 10, 5, "\ud9c1\udd43\ud86d\udea4", "\ua27f\u01b2", "\u96d9\udb87\udfca\udb19\udf61\ud984\udea4",
        51, 73530, -39084063, 1813546045562679757L, 67185L, false, true, (char) 31496, (char) 3091,
        Double.longBitsToDouble(0x3f957986b1f068c0L), Double.longBitsToDouble(0x3fe5a4b20e9f9bbbL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Double:9.449996658398035E-4\0121=java.lang.Double:9.449996658398035E-4\012",
        Z.run(T, 2, 10, 10, 5, "\ud9c1\udd43\ud86d\udea4", "\ua27f\u01b2\ua914\u8825", "\udb19\udf61\ud984\udea4\udbfe\uddfb\ud9d8\udf47\udb61\udfbd\udaf4\ude00\uda08\udf12\udb2e\udd5b\ud874\udcd9\ud90d\udf37\ud875\udf25\ud993\udf24\udbcb\ude10\udba3\udfc8\udb7c\udd5f\uf828\udb1b\uddbf\udb9b\udfb0\uda87\udcb4\ud9c8\uddf8\uda2c\udcf1\uda1f\udec3\udaf4\udc5e\udac7\udd79\ud83f\udf18\udab4\udf1a\u4ce0\udb5a\udfbb\uda27\udf82\udb6e\ude8e\uda89\udce3\ud85b\ude66\ud943\udf8e\udba4\udc80\ud85f\udf85\ud9b4\udc82\udb2d\udc30\ud930\ude16\ud8d6\udd31\ud8b0\udd0e",
        -3, 94727, -103480835, -6875597885969907480L, -72666L, false, false, (char) 47938, (char) 30788,
        Double.longBitsToDouble(0x3f4ef73ba1bdd400L), Double.longBitsToDouble(0x3fe55b1fccce2796L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Double:0.2415732301935962\0121=java.lang.Double:0.2415732301935962\012",
        Z.run(T, 2, 1, 1, 7, "\udab2\udc99", "\u6849", "\000\000\000\uda3d\udcd5\udb57\udd7e\000\ud9cc\udc05\udac6\ude43\ud91e\udd4e\uda5e\udd0e",
        56, 7490, 1683871816, 2671241002644690422L, -51872L, false, false, (char) 20650, (char) 39898,
        Double.longBitsToDouble(0x3fcea0d5820e73b8L), Double.longBitsToDouble(0x3feabf08b80000c1L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Double:0.1327797630420216\0121=java.lang.Double:1.5707963267948966\012",
        Z.run(T, 2, 10, 13, 8, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf", "\u01b2\ubb33\001\000\000\uc3a3\ua507\uac04\ub4a5\uaa27\u9ea4\ubd22\u54e8\u09e3\010\000\uc803", "\ud88a\udeee\ud859\udc44\udb03\udf7a",
        57, 60875, 258005008, -1197188033310411686L, -100000L, false, true, (char) 56649, (char) 51421,
        Double.longBitsToDouble(0x3fc10bb92e470290L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 14, 14, 8, "\ud849\udd17\ud989\udda3\u00c3", "\u01b2", "\u396e\udb87\udf05\udb19\udf61",
        12, 47661, 139555530, 1597546281501917696L, 18710L, true, false, (char) 6501, (char) 9490,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e45a80000000000L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Float:0.0\0121=java.lang.Float:0.0\012",
        Z.run(T, 2, 4, 4, 15, "\ud9a9\ude69\ud989\udd2d\ud9fd\uddcf\ud83c\udf07\ud9f5\ude17\udaee\udf2a\ud9bf\ude8f\udb50\ude4d\ud99b\uded3\udb87\udfca\udb35\udf61\ud984\udea4", "\uaa27\u9ea4\ua53f\u54e8", "\ud85b\udcba",
        28, 9885, -1774094961, -7225094642179364901L, 15118L, true, false, (char) 61430, (char) 43,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fdc1b500ab32810L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Double:3.141592653589793\0121=java.lang.Double:3.141592653589793\012",
        Z.run(T, 2, 11, 11, 5, "\ud9c1\udd43", "\u1dba\ua27f\u01b2\u57ee\u8798\u95f4\u99b6\uaa21", "\ud872\udd21",
        0, 34406, 1239737589, 7781376126945545571L, 49830L, true, false, (char) 49935, (char) 70,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fb6f60020c78918L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Double:1.5707963267948966\0121=java.lang.Double:1.5707963267948966\012",
        Z.run(T, 2, 7, 7, 5, "\ud9c1\udd43\ud81e\ude8d\udb56\udff0\uda1f\udd6f", "\u5871\u8798\u95f4", "\ud982\ude25\ud92a\udcdd\udaa7\udd0d\ud840\udee4\000\ud874\udd79\ud9f5\udf9e\ud874\udcd9\udb6f\udd4a",
        21, 443, -2092507115, -7619679837493395456L, -38651L, false, false, (char) 7243, (char) 12336,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 13, 13, 5, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf\uda62\udf10", "\u5871\u8798\u95f4", "\ud97d\udee3\udbfe\uddfb\ud9d8\udf47\ud9c6\udd2f\000\000\udb22\udd11\ud874\udcd9\ud90d\udf37",
        45, 443, -2092507115, -7619679837489766656L, 21961L, true, true, (char) 9287, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3f3e002800000000L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 15, 15, 5, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf\uda62\udf10", "\u5871\u8798\u95f4", "\ud8f1\udd63\u4e03\udb9e\udf0a\ud9c6\udcad\000\000\udb22\udd11\ud874\udcd9\ud90d\udf37",
        45, 443, -2092507115, -7619679837493395456L, 40146L, true, true, (char) 9287, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3f4d000000000000L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Double:0.11829822777302854\0121=java.lang.Double:0.11829822777302854\012",
        Z.run(T, 2, 14, 14, 3, "\ud967\udc46\ud922\ude57\ud8fc\udea0\ud817\udefb\ud9cd\uddb0\udb9a\udf01\uda3d\udc5c\udaec\uddcd\ud9ec\ude1c\ud81e\udcdb\uda21\udfb0\ud936\udf0b", "\u077c\u6a05\uc3f4\u54e8\u8ba9\ubdba\u78b3\u1c5e\u8d71", "\udaed\udf3c\ud9d0\udd5f\udaf3\udd3a\udb4f\udcb0\ud991\ude79\udb73\udf8b\uda97\udff0\udb52\udd2f\udb93\uddbe\ud9d9\udcaa\ud830\udc7f\udbdf\udef6\ud84b\udcf4\ud943\udd58\ud8b9\udfd9\ud891\udcd4\ud897\udcc3\ud834\udec0\udb70\udcbf\uda37\uded2",
        37, 91491, -769811174, -6522738455415572391L, 47698L, true, false, (char) 12595, (char) 965,
        Double.longBitsToDouble(0x3fbe24d41bf35e88L), Double.longBitsToDouble(0x3fe26c4d58a33edeL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 1, 1, 7, "\000", "\u6849", "\000\000\000\udbab\ude6c\udb50\udc07\000\000\000\000\uda5d\udf0e",
        56, 7490, 1683871816, 2671241002644690422L, -51872L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3feabf08b80000c1L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Double:1.5707963267948966\0121=java.lang.Double:1.5707963267948966\012",
        Z.run(T, 2, 13, 13, 8, "\ud9c1\udd43\ud989\udda3\ud9fd\uddcf", "\u01b2\ubb33\001\000\000\uc3a3\ua507\u35da\ubd32\uaa27\u9ea4\ubd22\u54e8\u09e3\ucf70\u340a\uc803", "\ud88a\udeee\ud859\udc44\uda8e\udc1b",
        34, 60875, 258005008, -1197188033310375590L, 7008L, false, false, (char) 34891, (char) 51583,
        Double.longBitsToDouble(0x3fc10bb92e470290L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Double:1.2816323718267109\0121=java.lang.Double:0.7467116227595637\012",
        Z.run(T, 2, 0, 7, 5, "\uda1c\udf0e\uda08\udda1", "\u7c2d", "\ud9e5\uded7",
        52, 72171, 606871116, 33874293756366976L, 84452L, true, true, (char) 2307, (char) 18417,
        Double.longBitsToDouble(0x3fe77c53349718baL), Double.longBitsToDouble(0x3fdf6e5a07f62830L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Double:0.02142363032518976\0121=java.lang.Double:0.02142363032518976\012",
        Z.run(T, 2, 14, 14, 5, "\ud967\udc46\uda9a\ude93\udba3\udf82\ud817\udefb\ud9cd\uddb0\udb9a\udf01", "\u95f4\u6d44\uc955\u74b7\u725f\u6dc8\u077c\u3ec3", "\ud83c\udf5e",
        -5, 26569, -1608966648, -1408636448807553649L, -84551L, false, false, (char) 34659, (char) 926,
        Double.longBitsToDouble(0x3f95ef3793c57d80L), Double.longBitsToDouble(0x3feb36bafe92ab77L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Integer:4\0121=java.lang.Integer:4\012",
        Z.run(T, 2, 5, 5, 5, "\ud823\uddf2\ud989\udda3\ud9fd\uddcf", "\u01b2\u5871\u8798\u95f4\u6e74\uc3a3\ua507\uac04\ub4a5\uaa27\uac86\ubd22\u54e8\u09e3\u60f8\u15c7\u5bee", "\ud88a\udeee\udb6f\udf50",
        -4, 33932, -2067711054, 1108123071285476308L, -78373L, true, true, (char) 34130, (char) 59729,
        Double.longBitsToDouble(0x3fe5447270076c14L), Double.longBitsToDouble(0x3fec4c51313d0b6cL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 9, 9, 16, "\ud9c1\udd43\ud81e\ude8d\ud9f2\ude3f\udb43\udfa7", "\u5871\u8798\u95f4", "\ud82e\udfcf\udbfe\uddb5\ud9d8\udf47\ud9c6\udd2f\000\000\udb22\udd11\ud874\udcd9\ud8f5\ude37",
        50, 74241, 932598048, -7576367398710673408L, 78597L, true, true, (char) 7243, (char) 12336,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.util.FastMath|cosh|double|static",
    "M|org.apache.commons.math3.util.FastMath|sinh|double|static",
    "M|org.apache.commons.math3.util.FastMath|IEEEremainder|double,double|static",
    "M|org.apache.commons.math3.util.FastMath|abs|double|static",
    "M|org.apache.commons.math3.util.FastMath|abs|float|static",
    "M|org.apache.commons.math3.util.FastMath|abs|int|static",
    "M|org.apache.commons.math3.util.FastMath|abs|long|static",
    "M|org.apache.commons.math3.util.FastMath|acos|double|static",
    "M|org.apache.commons.math3.util.FastMath|acosh|double|static",
    "M|org.apache.commons.math3.util.FastMath|asin|double|static",
    "M|org.apache.commons.math3.util.FastMath|asinh|double|static",
    "M|org.apache.commons.math3.util.FastMath|atan|double,double,boolean|static",
    "M|org.apache.commons.math3.util.FastMath|atan|double|static",
    "M|org.apache.commons.math3.util.FastMath|atan2|double,double|static",
    "M|org.apache.commons.math3.util.FastMath|atanh|double|static",
    "M|org.apache.commons.math3.util.FastMath|cbrt|double|static",
    "M|org.apache.commons.math3.util.FastMath|cosh|double|static",
    "M|org.apache.commons.math3.util.FastMath|sinh|double|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
