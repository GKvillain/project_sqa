package org.apache.commons.math3.optimization.univariate;
import org.junit.Test;
import static org.junit.Assert.*;
public class BrentOptimizer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 2, 1, 3, 2, "\uf699\udb3d\udc8c\ud87b\udf3c\uda5a\udcb6\udb54\udd5c\ua1d1\ud853\udcbb", "\u18a2\u0fb5\u7b02\ub787\u6056\u0bf3\u6d13", "\ud8e2\udc69\ud9a8\udc72\ud8b6\udda9",
        -5, 14772, -1342651178, -3570133140268931294L, -94110L, false, false, (char) 15578, (char) 54556,
        Double.longBitsToDouble(0x3fda1db70d9a5d0eL), Double.longBitsToDouble(0x3fe3883057b00fa0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 2, 1, 3, 2, "\uda29\udf0a\u198f\ud87b\udf3c\uda5a\udcb6\udb54\udd5c\ua1d1\ud853\udcbb", "\u8df6\ub12a\u7b02\ub787\u6056\u0bf3\u6d13", "\ud8e2\udc69\ud9a8\udc72\ud8b6\udda9",
        -5, 14772, -1342651178, -3570133140268931294L, -94110L, false, false, (char) 15578, (char) 54556,
        Double.longBitsToDouble(0x3fda1db70d9a5d0eL), Double.longBitsToDouble(0x3fe3883057b00fa0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 2, 1, 3, 2, "\ud94f\udc41\udb3d\udc73\ud8fc\udff0\uda5a\udcb6", "\u8a64\ub0c1\u2bf4\u18a2\u0fb5\u7b02\u39bb\u5ffb\u0bf3\u6d13\u1a85\u504f\u6acd\u3517\u346e\u3cb4\uba71\u55fc\u5e1a\u8d8e\u35c9\u5051\uaac4\u708b\u3a01\u923f\u45f6\ud0f5\u132ey\ubf64", "\udaea\udd6a\ud8fa\uddcd\uda3b\udfc8\uda3e\udc43\u257f\udb57\udc34\ud9b9\udc62\udb72\udccd\udb52\udd88\ud9a3\uddf6\ud933\udd8a\uda8b\udf06\ud931\uddc6\udb2a\udfd0\ud9d0\udebe",
        32, 15912, -1388777054, 3392490079860876146L, 26575L, true, false, (char) 3032, (char) 480,
        Double.longBitsToDouble(0x3fe3415856de032dL), Double.longBitsToDouble(0x3fef9fdfa1d3cd92L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 2, 1, 1, 0, "\uf699\udb3d\udc8c\ud87b\udf3c\uda5a\udcb6\udb54\udd5c\ua1d1\ud853\udcbb", "\u18a2\u0fb5\u7b02\ub787\u6056\u0bf3\u6d13", "\ud8e2\udc69\ud88f\udd65\ud8b6\udd2d",
        -5, 14772, -1342651178, -3570133140268931294L, 59599L, true, true, (char) 12562, (char) 1364,
        Double.longBitsToDouble(0x3fe3883057b00fa0L), Double.longBitsToDouble(0x3fec798813ca8850L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 1, 1, 3, 2, "\uf699\udb3d\udc8c\ud87b\udf3c\uda5a\udcb6\udb54\udd5c\ua1d1\ud853\udcbb", "\u18a2\u0fb5\u7b02\ub787\u6056\u0bf3\u6d13", "\ud8e2\udc69\ud9a8\udc72\ud8b6\udda9",
        -5, 14772, -1342651178, -3570133140268931294L, -94110L, false, false, (char) 15578, (char) 22556,
        Double.longBitsToDouble(0x3e4b34ba1c000000L), Double.longBitsToDouble(0x3fe3883057b00fa0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 2, 3, 3, 2, "\uf699\udb3d\udc8c\ud87b\udf3c\uda5a\udcb6\udb54\udd5c\ua1d1\ud853\udcbb", "\u18a2\u0fb5\u7b02\ub787\u6056\u0bf3\u6d13", "\ud8e2\udc69\ud9a8\udc72\ud8b6\udda9",
        -5, 14772, -1342651178, -3570133140268931294L, -94110L, false, false, (char) 15578, (char) 54556,
        Double.longBitsToDouble(0x3fda1db70d9a5d0eL), Double.longBitsToDouble(0x3fe3883057b00fa0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 0, 3, 2, "\uf699\udb3d\udc8c\ud93d\udfde\uda5a\udcb6\udb54\udd5c\ua1d1\ud853\udcbb", "\u18a2\u0e45\000\ub787\u6056\u0bf3\u6d13", "\ud8ca\udf85\ud9a8\udc72\ud8b6\udda9",
        9, 14772, 50390, -3570134046507030750L, -94110L, false, false, (char) 15578, (char) 32284,
        Double.longBitsToDouble(0x3f4b6e1b34b80000L), Double.longBitsToDouble(0x3fe3883057b00fa0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 2, 2, 3, 3, "\ud90f\ude86", "\u3ab8\u0d86", "\uda87\udcc6\ud8a4\udfae\ud8fd\ude93\udbeb\udff9\udb12\uddbe\ud824\uddd1\udbdd\udc58",
        39, 913, 1733725036, -7560404776073208702L, 45046L, true, false, (char) 36250, (char) 24640,
        Double.longBitsToDouble(0x3fdd3aff8e459c42L), Double.longBitsToDouble(0x3fd4f056b1fd28ceL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=!org.apache.commons.math3.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 1, 0, 2, "\udaad\udfe4\ud92a\udda4\uda8f\uddea\uda4a\udfe6\udacf\udd00\ua1b0\ud853\udcbb", "\u18a2\u0fb5\u7b02\ub787\u6056\u2c12\u6d13", "\ud8e2\udc69\ud9a8\udc72\ud8b6\udda9\ud89e\udd5f",
        54, 72463, -831236397, 7884579339099386451L, 75364L, true, false, (char) 54524, (char) 12562,
        Double.longBitsToDouble(0x3fe7d1743e71060aL), Double.longBitsToDouble(0x3fed807d022f8eceL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NumberIsTooSmallException\012",
        Z.run(T, 2, 1, 3, 0, "\uf699\000\000\u997e\ud884\udca2\ua1d1\udb8e\udeb2", "\000\000\u60e9\ub787\u7d62\u1f23\u671c", "\ud8e2\udc69\000\ud8b6\udd13",
        55, -1000, -1358954496, -3570133140268931294L, -94110L, false, false, (char) 15578, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe3883050b00fa0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 0, 1, 2, "\udb0d\udf51\ud9be\ude37\ud87b\udf3c\uda5a\udcb6\udb54\udd5c\ua1d1\ud853\udcbb", "\u18a2\u2ba3\u7b02\ub787\u6056\u0bf3\u6d13", "\ud8e2\udc69\ud976\udc79\ud898\udef9",
        -5, 14772, -1443314474, -6980040202074216670L, -92830L, false, false, (char) 5595, (char) 58324,
        Double.longBitsToDouble(0x3fda1db70d9a5d0eL), Double.longBitsToDouble(0x3fe3883057b00f0eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 1, 3, 2, 3, "\ub839\ud8e0\uddbf\ud8fe\udfce", "\u8f14", "\ud8f6\uddcf\udac0\udfee\u0a04\u4dd5\ud824\uddd1\udbcc\ude58\ud853\udc8b\uda09\udd32\ud94a\udc83\ud801\uddb8\ud942\ude0f\ud956\udfd2\ud852\udd31\udb8d\udec5\udac4\udf89\uda82\udc1e\ud856\udcc7\ud8c7\udde9",
        55, 25158, 93803810, 6316635189334018675L, 86061L, true, false, (char) 1872, (char) 64125,
        Double.longBitsToDouble(0x3fe5cf9d37ef7c16L), Double.longBitsToDouble(0x3fd35143d38a8274L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 1, 1, 3, 2, "\uf6ae", "\u3ab8\u750f\ucb41\u3807", "\ud8f9\uddeb\u97f7\udb08\uddd6\uda90\udc65\udbd4\ude03\ud922\udc35",
        49, 6884, -1862923286, -5477119437023904049L, -72609L, true, true, (char) 27734, (char) 20292,
        Double.longBitsToDouble(0x3fe913c3254f056bL), Double.longBitsToDouble(0x3feff4a33eb3bd53L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 2, 1, 1, 2, "\uf699\ud88d\udc94\ud87b\udf3c\uda5a\udcb6\udaa7\uddc5\udb2b\udd92\udba6\uddef", "\u709b\u9089\u8284\ub787\u6056\u0bf3\u9a84", "\ud8e2\udc69",
        17, 65772, -825319425, -7247737985346845482L, -77250L, true, true, (char) 32101, (char) 64423,
        Double.longBitsToDouble(0x3fc2326e616c1ea4L), Double.longBitsToDouble(0x3fef41066ea80dd2L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NotStrictlyPositiveException\012",
        Z.run(T, 2, 1, 3, 2, "\uf699", "\u3ab8\u0d86\ucb41\u3807", "\uda03\udd20",
        57, 64065, -987411127, -3711391181506087134L, -100000L, false, false, (char) 60890, (char) 13005,
        Double.longBitsToDouble(0x3fe4b00002ff342eL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NumberIsTooSmallException\012",
        Z.run(T, 2, 1, 3, 2, "\ud94f\udc41\udb3d\udc73\ud8fc\udff0\uda5a\udcb6", "\u8a64\ub0c1\u2bf4\u18a2\u0fb5\u7b02\u39bb\u5ffb\u0bf3\u6d13\u1a85\u504f\u6acd\u3517\u346e\u3cb4\uba71\u55fc\u5e1a\ua722\u57ff\u5051\uaac4\u708b\u3a01\u923f\u45f6\u1e71\u132ey\ubf64", "\udaea\udd6a\000\uda3b\udecf\uda3e\udc43\u257f\udb57\udc34\ud9b9\udc62\udb72\udccd\udb52\udd88\ud92e\ude7c\ud927\uddd3\uda8b\udf06\ud931\uddc6\udb2a\udfd0\ud9d0\udebe",
        35, -1000, -1388777054, 3392490079860876146L, 26575L, true, false, (char) 3032, (char) 25111,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fef9fdfa1d3cd92L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\012",
        Z.run(T, 1, 2, 2, 3, "\ud94f\udc41\udb3d\udc73\ud8fc\udff0\uda5a\udcb6", "\u8a64\ub0c1\ub011\u18a2\u0fb5\u6b03\u6c7b\u5ffb\uc901\u6c4c\u1a85\u504f\u6acd\u3517\u346e\u3cb4\uba71\u55fc\u5e1a\u8d8e\u35c9\u9f2a\u1a80\u27b1\u3971\u923f\u45f6\ud0f5\u132ey\ubf64", "\udae1\udcd0\ud912\udc9d\uda3b\udfc8\ud9df\ude33\u7573\udb57\udc34\ud9b9\udc62\udb72\udccd\udb52\udd88",
        1, 88159, -1932034608, 2141386881974833966L, -4728L, false, true, (char) 5342, (char) 14585,
        Double.longBitsToDouble(0x3feb9178a1ece224L), Double.longBitsToDouble(0x3fd91acdd8326a34L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 0, 0, 2, "\uda43\udf14\udbc6\udd55\u0d59\uda5a\udcb6\udb54\udd5c\ua1d1\ud853\udcbb\uda87\udcc6\ud8b5\udc19\ud8f9\uddeb\udbeb\udff9\udb12\uddbe\ud824\uddd1\uda97\uddc3\ud852\ude08\uda09\udd32\ud94b\udf00\udb2b\udd5e\ud8e2\udc69\ud9a8\udc72\ud8b6\udda9\udb8e\uddd7\uda1e\udf8e\uda82\udc1e\udaa4\udc9a\ud8f1\uddd3\udb0b\udd60\ud951\udcc8\ud60d\udab7\udc0c\ud9aa\ude0c\udbd2\udc5e\ud863\ude28\ud9ff\udc00\udbde\udccf\uda84\udee7\udab0\udc44\uda25\ude91\udaa0\udcc6\uab4f\ud8b2\uddda\uda7f\udd3b\uda89\udf06\ud9b5\udda5\ud94d\udee9", "\u0c39\u4aa6\u6d80\u4ace\u75c2\u77b7\u1bfa\u76c3\u9735\u1e96\u1610\u633d\u7780\ubaec\ub6a3\u0418\u9be4\u501e\u3947\u9b4f\uac68\u96d4\ud378\ud56a\u9541\u3f64\u51a9\ud391\u9865\uafcc\u855d\u6561\u0b9f", "\udabf\udc34\ud9eb\udd3d\u56a7\ud8d2\uded6\udab2\uded9\ud9a7\udfef\ud8be\udc61\udab8\udc49\ud888\udd9c",
        57, 91774, 1014017177, 2382803664148513063L, 61561L, false, true, (char) 45106, (char) 13867,
        Double.longBitsToDouble(0x3fe5812f85817a72L), Double.longBitsToDouble(0x3feb7be358499f66L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.math3.optimization.univariate.BrentOptimizer:@?\0121=!org.apache.commons.math3.exception.TooManyEvaluationsException\012",
        Z.run(T, 2, 1, 0, 2, "\udab2\udfa1\ud8b6\uddc9\ud9c4\udce4\uda63\udf5b\udacf\udd00\ua1b0\ud853\udcbb", "\u18a2\u1029\u7b02\u2409\u709b\u0342\u6d13", "\ud8e2\udc69\ud9a8\udc72\ud8b6\udda9\ud89e\udd5f",
        54, 72463, -831236397, 7884579339099386451L, 75364L, true, false, (char) 54524, (char) 12562,
        Double.longBitsToDouble(0x3fe7d1743e71060aL), Double.longBitsToDouble(0x3fed807d022f8eceL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.optimization.univariate.BrentOptimizer|doOptimize||new:org.apache.commons.math3.optimization.univariate.BrentOptimizer:double,double",
    "M|org.apache.commons.math3.optimization.univariate.BrentOptimizer|best|org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair,org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair,boolean|new:org.apache.commons.math3.optimization.univariate.BrentOptimizer:double,double",
    "C|org.apache.commons.math3.optimization.univariate.BrentOptimizer|<init>|double,double,org.apache.commons.math3.optimization.ConvergenceChecker",
    "C|org.apache.commons.math3.optimization.univariate.BrentOptimizer|<init>|double,double",
    "M|org.apache.commons.math3.optimization.univariate.BrentOptimizer|doOptimize||new:org.apache.commons.math3.optimization.univariate.BrentOptimizer:double,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
