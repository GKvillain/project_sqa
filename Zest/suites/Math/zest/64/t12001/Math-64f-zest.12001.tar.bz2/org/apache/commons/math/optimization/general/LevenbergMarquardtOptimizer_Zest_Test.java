package org.apache.commons.math.optimization.general;
import org.junit.Test;
import static org.junit.Assert.*;
public class LevenbergMarquardtOptimizer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |a0=[D:[[27651.0, 28180.0, 27833.5, 28241.5, 28110.5, 28533.0, 27755.0, 28262.5]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 1, 3, 6, 7, "\ud836\udc58\ud9a3\udcd3\udbcd\udf1a\ud906\udcfd\udb3a\udd3d\ud8e3\udf42\u9087\ud8f3\udfd5\uda4d\udca7", "\u5fe6\u0c99\u30a7\u179a\u2982\ua84a\u5941\u21d0\u0bb5\u5c6b\uc363", "\ud911\udd62\ud8f1\udf61\udb6d\udf63\u00d8\ud840\udd0b\udb45\ude47\ud91c\udf9c\uda37\udd48\ud9cb\udef5",
        50, 89977, 489785738, -1026268787568302443L, -99484L, true, true, (char) 10894, (char) 60347,
        Double.longBitsToDouble(0x3fe3a59df3291146L), Double.longBitsToDouble(0x3f7a4a5ae86ed580L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |a0=[D:[[27651.0, 28180.0, 27833.5, 28241.5, 28110.5, 28533.0, 27755.0, 28262.5]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 1, 3, 6, 7, "\ud836\udc58\ud9a3\udcd3\udbcd\udf1a\ud906\udcfd\udb3a\udd3d\ud8e3\udf42\ud8ad\udd0c\uda63\udcf4\ud85c\udf2b", "\u5fe6\u0c99\u30a7\ucbdc\u29df\ua84a\u5941\u21d0\u0bb5\u5c6b\uc363\u88ed\u42f6\ud4b0\u5b10\u6a9b\u78c3\ub85b\u8544\u2214", "\u566d",
        52, 35738, -238946822, -6851199250581589369L, 89196L, false, false, (char) 53870, (char) 58012,
        Double.longBitsToDouble(0x3fdd0ddabf1bc1deL), Double.longBitsToDouble(0x3fe9addeae3e0bb4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 2, "\ud836\udc58\ud9a3\udcd3\uda38\udeef\ud906\udcfd\udb3a\udd3d\ud8e3\udf42\ud80c\udf1b\ud898\udd48\uda56\udee9", "\u5fe6\u70dd\u0345\u179a\u2982\ua84a\u5941\u217e", "\uda0c\udcd1\ud8f7\ude4b",
        21, 37571, 1484915242, 5835964305827249418L, 28900L, false, true, (char) 15143, (char) 3888,
        Double.longBitsToDouble(0x3fd8a7ccbbf43a62L), Double.longBitsToDouble(0x3f840110a1e83ac0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 1, 6, 1, 3, "\ud836\udc58\ud9c3\udee3\ud8ac\udec9\ud906\udcfd\udb3a\udd3d\ud8dc\udd34\ud8af\udcad\udb13\udcaf\ue596\ud914\udf0e\ud8ff\udce9\ud87c\udff7", "\u2803\u807e\u2398", "\ud83c\udf2f",
        14, 76918, 39239208, -5605882941074388045L, -1026L, true, true, (char) 26278, (char) 60182,
        Double.longBitsToDouble(0x3fea480278b440ffL), Double.longBitsToDouble(0x3fef798e53395c59L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 1, 10, 6, 7, "\ud836\udc58\ud9a3\udcd3\udbcd\udf1a\ud906\udcfd\udb3a\udd3d\ud8e3\udf42\u9087\ud8f3\udfd5\uda4d\udca7", "\u5fe6\u0c99\u30a7\u179a\u2982\ua84a\u5941\u21d0\u0bb5\u5c6b\ucbaf", "\ud911\udd62\ud8f1\udf61\udb6d\udf63\u00d8\ud840\udd0b\udb45\ude47\ud82d\udc24\uda37\udd48\ud9cb\udef5",
        50, 56497, 489785600, -1026268787568302443L, -99484L, true, true, (char) 10894, (char) 60347,
        Double.longBitsToDouble(0x3fe3a59803291146L), Double.longBitsToDouble(0x3f7a4a5ae86ed580L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 1, 3, 6, 7, "\ud836\udc58\031\udbb3\udef9\ud906\udcfd\udb3a\udd3d\ud8e3\udf42\u9087\ud950\udfc6\uda4d\udca7", "\u82f6\u1022\uaa67\u179a\u2982\ua84a\u5941\000\u0b04\u5c6b\u00c9", "",
        -5, -1000, 0, 68028930159872L, 68932L, false, false, (char) 1416, (char) 3922,
        Double.longBitsToDouble(0x3fd19365a3143dbcL), Double.longBitsToDouble(0x3fdfa1d31d2be382L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 1, 4, 6, 7, "\ud836\udc58\ud9a3\udcd3\udb48\udc0a\uda0b\udec3\ud9c0\udfc0\udb9c\udc0e\ud967\ude1b\ud923\ude8f\udb4e\udd0b", "\u78ca", "\uda49\ude08\udaf8\udd2e\ud811\ude16\udbb0\udcab",
        41, 657, -2004033026, -2395111496401306072L, 12714L, false, false, (char) 56095, (char) 36430,
        Double.longBitsToDouble(0x3fdbbaab150a706eL), Double.longBitsToDouble(0x3f9cb812199ef120L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |a0=[D:[[27651.0, 28180.0, 27985.0, 28490.5]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 1, 3, 2, 7, "\ud836\udc58\udad2\udec5", "\ua5f2\u2eb0\ubf3a\u76c6\u3998\u89bc\u187e\u5fe6\u0c99\u30a7\u179a\u2982\ua84a\u83d4\u21d0\u0bb5\u5c6b", "\ud86d\udc03\ud911\udd62\ud8f1\udf61\udb6d\udf63\u00d8\uda55\udd56\ud8ef\udd4f\udb96\udf99\uda37\udd48",
        13, 94257, 517917977, 2103613726518277626L, 67289L, false, true, (char) 8844, (char) 10894,
        Double.longBitsToDouble(0x3fe0604585e711a6L), Double.longBitsToDouble(0x3feb681a10069296L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |a0=[D:[[27958.5, 28374.5, 27833.5, 28241.5, 28110.5, 28533.0]] |a2=[D:[[5952.0, 24453.0, 15179.0, 22066.0, 14772.0, 3111.0, 12251.0, 1588.5]] |a3=[D:[[27744.5, 28568.5, 28062.5, 28569.5, 84.0, 27656.0, 28269.5, 28042.5]] |a4=[D:[[27958.5, 28374.5, 27833.5, 28241.5, 28110.5, 28533.0]] |a5=[D:[[5952.0, 24453.0, 15179.0, 22066.0, 14772.0, 3111.0, 12251.0, 1588.5]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 1, 2, 1, 4, "\uda9d\udddd\ud9a3\udcd3\udbcd\udf1a", "\u2eb0\ubf3a\u76c6\uac94\u7398\u187e\u5fe6\u0c99\u30a7\u179a\u2982\ua84a\u5941\u21d0\u0bb5\u5c6b\u202b\u73b4", "\ud8f1\udf61\udb6d\udf63\u00d8\ud840\udd0b\udb45\ude47\ud91c\udf9c\uda37\udd48\ud8e3\uddfb",
        50, 89977, 489785738, -1026268787568302443L, -99484L, true, true, (char) 10894, (char) 60347,
        Double.longBitsToDouble(0x3fe3a59df3291146L), Double.longBitsToDouble(0x3fc39252cbb3daacL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |a0=[D:[[27651.0, 28180.0, 27833.5, 28241.5, 28110.5, 28533.0, 27755.0, 28262.5]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 3, 6, 7, "\ud836\udc58\ud9a3\udcd3\udbcd\udf1a\ud906\udcfd\udb3a\udd3d\ud8e3\udf42\u9087\ud8f3\udfd5\ud89b\udc8d", "\ua3ed\u303a\u30a7\u179a\u2982\ua84a\u5941\u146f\u0bb5\u5c6b\uc363", "\ud911\udd62\ud8f1\udf61\udb6d\udf63\u00d8\ud840\udd0b\udb45\ude47\ud87b\ude0b\uda37\udd48\ud9cb\udef5",
        50, 89977, 489785738, 126652717038544533L, -99484L, true, true, (char) 10894, (char) 60347,
        Double.longBitsToDouble(0x3fe3a59df3291146L), Double.longBitsToDouble(0x3f7a4a5ae86ed580L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 0, "", "\ub0be\ua355\ua5f2\u00bbQ", "\ud87f\udf56\u00b0\ud895\udcf7\uf021\udbc8\ude84\uda49\ude08`",
        11, 97229, -535799894, -2004033026L, -17608L, true, true, (char) 45798, (char) 0,
        Double.longBitsToDouble(0x3fe4f00005df50fdL), Double.longBitsToDouble(0x3fdbbaab150a706eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |a0=[D:[[27651.0, 28180.0]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 1, 3, 3, 0, "\ud836\udc58", "\ua3d3\ua5f2\u2eb0\ubf3a", "\ud880\udc31\uda86\udde4\ud895\udd72\udb79\udd1f\udbf0\udccb\uda49\ude08\uda69\udfe6\uda33\udc3e\udbb0\udcab\ud893\uddc8\ud83c\udf2f\udba2\udef3\u00c9\000",
        18, 37523, 1484915242, 5835964305827249631L, 31717L, false, false, (char) 59477, (char) 1449,
        Double.longBitsToDouble(0x3fe9cae0cd19365aL), Double.longBitsToDouble(0x3fd8a1edebf43a62L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 1, 5, 4, 7, "\ud836\udc58\ud9b6\udddc\udb16\ude5f\uda6c\uddce\ud838\uddc1", "\ub0a4\u3998\u89bc\u187e\u2a05\u0d65\u48f0\u1e61\u2cd1\ubecd\u5941\u21d0\u0bb5\u5c6b\ub6dc", "\ud911\udd62\ud8f1\udf61\udb6d\udf63\uda57\udf62\uda66\udcd9\ud8f6\udf79\ud92e\udf16\uda37\udd48\ud9ce\udf5e",
        20, 94736, -1651874049, -1026526550030584576L, 65283L, true, true, (char) 58012, (char) 53979,
        Double.longBitsToDouble(0x3fd58da80dd0b976L), Double.longBitsToDouble(0x3fd97339b9d5b6f4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |a0=[D:[[27651.0, 28180.0, 27673.0, 28489.5, 27887.0, 28583.0, 27755.0, 28262.5]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |a0=[D:[[27651.0, 28180.0, 27673.0, 28489.5, 27887.0, 28583.0, 27755.0, 28262.5]] |a2=[D:[[12251.0, 1588.5, 11480.0, 4846.0, 5289.0, 21517.0, 11400.5, 4304.0]] |a3=[D:[[27831.5, 28405.0, 27744.5, 28568.5, 28062.5, 28569.5, 84.0, 27682.0]] |a4=[D:[[27651.0, 28180.0, 27673.0, 28489.5, 27887.0, 28583.0, 27755.0, 28262.5]] |a5=[D:[[12251.0, 1588.5, 11480.0, 4846.0, 5289.0, 21517.0, 11400.5, 4304.0]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 3, 2, 9, "\ud836\udc58\ud862\udec3\uda0e\udf7e\ud906\udcfd\udb3a\udd3d\ud8e3\udf42\u9087\ud8f3\udfd5\uda4d\udca7", "\u5fe6\u0c99\u59e0\u260c\u2982\ua84a\u5941\u21d0\u0bb5\u5c6b\u522d", "\ud99f\ude1a\ud8f1\udf61\udb6d\udf63\u00d8\ud874\udc65\uda12\ude8a\ud91c\udf9c\uda37\udd48\ud9cb\udef5",
        16, 89977, 489785738, -1026268787568302443L, -99484L, true, true, (char) 10894, (char) 60347,
        Double.longBitsToDouble(0x3fe3a59df3291146L), Double.longBitsToDouble(0x3f7a4a5ae86ed580L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 1, 10, 7, 9, "\ufe58\ud9a3\udcd3\ud851\udf1c\ud906\udcfd\udb3a\udd3d\ud8e3\udf42\ud851\udd58\ud8f3\udfd5\uda4d\udca7\ud880\udc31\uda86\udde4", "\u30a7", "\uda33\udc3e\udbb0\udcab\ud893\uddc8\ud83c\udf2f\udba2\udef3\uda0c\udcd3\ud8f7\ude4b\ud90e\ude95\ud911\udd62",
        52, 37326, -1431224865, 4050835834655605381L, 36756L, false, true, (char) 21927, (char) 12070,
        Double.longBitsToDouble(0x3fe450f6f5fa1d6aL), Double.longBitsToDouble(0x3fe4af8e0a87a0ebL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 7, 10, 5, "\uda62\ude2d\ud9e1\uded5\ud93c\ude47\udbf8\udcfe\udbed\udd9e\udbcb\udc1b\udb24\udc47\ud91e\udd61\u8952", "\u5fbf\u0c99\u30a7\u8ca5\u760b\ua84a\u5941\u21d0\u0bb5\u5c6b\uc363\uc64b\u42f6", "\udb6d\udee3\u00d8\ud840\udd0b",
        11, 16164, 1277292748, 6636539518136267577L, 61336L, false, true, (char) 52531, (char) 4977,
        Double.longBitsToDouble(0x3fdfcafa96b95790L), Double.longBitsToDouble(0x3fe4af7fc7fdd0e5L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |a0=[D:[[27651.0, 28180.0, 27833.5, 28241.5, 27767.0, 28489.0, 27777.0, 28165.0]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |a0=[D:[[27651.0, 28180.0, 27833.5, 28241.5, 27767.0, 28489.0, 27777.0, 28165.0]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 3, 3, 2, "\ud836\udc58\ud9a3\udcd3\ud91e\udec2\ud932\udc3a\udb6f\ude3d\ud8e3\udf42\u9087\ud8f3\udfd5\uda4d\udca7\ud880\udc31\ud880\udde1\ud895\udd72", "\u09ad\u294f\ua84a", "\udb7a\udfcd\udacf\ude85",
        54, 50208, -1305253191, -7721760539935636950L, 49582L, false, true, (char) 34267, (char) 52002,
        Double.longBitsToDouble(0x3fc99ef6a6213084L), Double.longBitsToDouble(0x3fe9cae0cd19365aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 7, "\ud81b\ude05\ud8fe\udc43\ud9e9\udcda\udaa6\udeae\udb3a\udd9f\ud9ad\udc13\udaa8\uded2\ud8f3\udfd5\uda4d\udca7", "\u945c\u0c99\u30a7\u179a\u2982\u0f1b\u5941\u21d0\u0bb5\u5c6b\uc363", "\ud911\udd62\ud8f1\udf61\udb6d\udf63\u00d8\udb0d\ude7b\udb45\ude47\ud91c\udf9c\ud847\uded0\ud99e\udd85",
        26, 89977, 489785738, -1026268787568302443L, 9419L, false, false, (char) 62843, (char) 42094,
        Double.longBitsToDouble(0x3f7a4a5ae86ed580L), Double.longBitsToDouble(0x3fc5f41062ab19d8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 7, 6, 2, "\ud836\udc58\ud9a3\udcd3\udaea\udfdf\ud906\udcfd\udb3a\udd3d\ud8e3\udf42\u9087\ud8f3\udfd5\uda4d\udca7", "\u5fe6\u0c99\u30a7\u7b34\u2982\ua84a\u5941\u21d0\u1896\u518f\u024f", "\ud911\udd62\ud8f1\udf61\ud89b\udddb\u00d9\ud840\udd0b\udb45\ude47\ud84a\udc13\ud9df\uddbd\ud9bd\udfd9",
        50, 89977, 1546750346, -1015089129430735211L, -99484L, true, true, (char) 39821, (char) 54258,
        Double.longBitsToDouble(0x3fe3a67c9b291146L), Double.longBitsToDouble(0x3f7a4a5ae86ed580L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 4, 4, 2, "\ud836\udc58\ud9a3\udcd3\uda38\udeef\ud906\udcfd\udb3a\udd3d\ud8e3\udf42\ud80c\udf1b\ud898\udd48\uda56\udee9", "\u5fe6\u70dd\u0345\u179a\u2982\ua84a\u5941\u217e", "\uda0c\udcd1\ud8f7\ude4b",
        21, 37571, 1484915242, 5835964305827249418L, 28900L, false, true, (char) 15143, (char) 3888,
        Double.longBitsToDouble(0x3fd8a7ccbbf43a62L), Double.longBitsToDouble(0x3f840110a1e83ac0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |a0=[D:[[27987.5, 28284.0, 27833.5, 28241.5, 27908.0, 28511.5, 27767.0, 28557.0]] |a2=[D:[[12251.0, 14422.5, 394.5, 2997.0, 5289.0, 21517.0, 11400.5, 4263.0]] |a3=[D:[[27886.0, 28240.5, 27747.5, 28429.5]] |a4=[D:[[27987.5, 28284.0, 27833.5, 28241.5, 27908.0, 28511.5, 27767.0, 28557.0]] |a5=[D:[[12251.0, 14422.5, 394.5, 2997.0, 5289.0, 21517.0, 11400.5, 4263.0]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |a0=[D:[[27987.5, 28284.0, 27833.5, 28241.5, 27908.0, 28511.5, 27767.0, 28557.0]] |a2=[D:[[12251.0, 14422.5, 394.5, 2997.0, 5289.0, 21517.0, 11400.5, 4263.0]] |a3=[D:[[27886.0, 28240.5, 27747.5, 28429.5]] |a4=[D:[[27987.5, 28284.0, 27833.5, 28241.5, 27908.0, 28511.5, 27767.0, 28557.0]] |a5=[D:[[12251.0, 14422.5, 394.5, 2997.0, 5289.0, 21517.0, 11400.5, 4263.0]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 2, 2, 2, "\udad7\udd28\ud9a3\udcd3\uda38\udeef\ud91e\udf4a\udb4e\udeab\uda62\ude26\uda84\udd21\ud898\udd48\uda56\udee9", "\u5fe6\u70dd\u0345\u179a\u2982\ua84a\u5941\u217e", "\uda0c\udcd1\ud8f7\ude4b",
        44, 37571, 1484915242, 5835964306244844810L, 28900L, true, false, (char) 32966, (char) 3888,
        Double.longBitsToDouble(0x3fd8a7ccbbf43a62L), Double.longBitsToDouble(0x3f840110a1e83ac0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |a0=[D:[[27651.0, 28180.0, 27833.5, 28241.5, 28037.0, 28176.0, 27755.0, 28239.0]] |a2=[D:[[12251.0, 14422.5, 394.5, 3046.5, 5289.0, 19713.5, 25222.5, 4263.0]] |a3=[D:[[27886.0, 28240.5, 27747.5, 28429.5]] |a4=[D:[[27651.0, 28180.0, 27833.5, 28241.5, 28037.0, 28176.0, 27755.0, 28239.0]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 6, 2, 2, "\ud836\udc58\ud9a3\udcd3\udb3a\udc50\ud906\udcce\ud86d\udd3f\ud84b\udf55\ud8eb\udfc4\ud950\udd08\ud9aa\udfe8", "\u5fe6\u70dd\u0345\u17fd\u2982\u9a33\uc53d\u217e", "\uda0c\udcd1\ud8f7\ude4b",
        21, 37571, 1484940548, 5835964305827249418L, -32292L, true, true, (char) 25634, (char) 3888,
        Double.longBitsToDouble(0x3fd8a7ccbbf43a62L), Double.longBitsToDouble(0x3f840110a1e83ac0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |a0=[D:[[7002.5]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 1, 3, 1, 2, "\u36e5", "\u5d91\u2395\u4a52\uc2c4\ud686\u5fda\u7768\uaec3\u5e93\uc4b6\u3135\u5713\ub11f\ua84a\u5941\u217e\u0bb5\u5c6b\uc361\u88ed", "\ud8f1\udf61\udb6d\udf63\uda12\udc8b\udba7\udcb0\udbc0\udd93\ud91c\udde9\ud8be\ude8d\uda53\udd16\ud98c\udcea\ud958\udf65\ud9a2\udcbb\ud80f\ude02\ud845\udf45\udb31\ude1f\uda3c\udd2a",
        16, 34351, -1371944747, 5836097478511812337L, 73550L, true, true, (char) 6763, (char) 60183,
        Double.longBitsToDouble(0x3fa2705e35da79d0L), Double.longBitsToDouble(0x3fe639dcf4e73a57L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 10, 10, 3, "\ud836\udc58\ud9c3\udee3\ud8ac\udec9\ud80e\udd01\udb3a\udd3d\ud8dc\udd34\ud8af\udcad\udb13\udcaf\ue596\ud914\udf0e\ud8ff\udce9\ud87c\udff7", "\u2803\u807e\u2398", "\ud83c\udf2f",
        14, 76918, 39239208, -5605882941074388045L, -1026L, true, true, (char) 26278, (char) 60182,
        Double.longBitsToDouble(0x3fea480278b440ffL), Double.longBitsToDouble(0x3fef798e51395c59L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 5, 6, 10, "\ud836\udc58\ud9ba\udd59\udbed\udee0\ud895\udffb\udb3a\udd3d\ud8e3\udf42\u9087\uda8e\udc2c\uda4d\udca7", "\u82f6\u1022\uaa67\u6962\uc2fb\ua84a\u5941\000\u0b04\u5c6b\ua542", "",
        -5, -1000, -1609402368, 68028930159872L, 68932L, false, false, (char) 61951, (char) 3922,
        Double.longBitsToDouble(0x3fd19365a3143dbcL), Double.longBitsToDouble(0x3fdfa1d31b54a2a8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 7, "\ud836\udc58\031\udbb3\udef9\ud906\udcfd\ud809\udca5\udbfa\udd7d\u0d52\ud950\udfc6\uda4d\udca7", "\u82f6\u1022\uaa67\u179a\u2982\ua84a\u5941\000\u0b04\u5c6b\u00c9", "",
        -5, -1000, 0, 68028930159872L, 68932L, false, false, (char) 1416, (char) 3922,
        Double.longBitsToDouble(0x3fd19365a3143dbcL), Double.longBitsToDouble(0x3fdfa1d31d2be382L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |a0=[D:[[27958.5, 28374.5, 27833.5, 28241.5, 28110.5, 28533.0]] |a2=[D:[[18240.0, 3846.5, 11939.5, 22066.0, 14772.0, 3111.0, 12251.0, 1588.5]] |a3=[D:[[27950.5, 28571.5, 27694.0, 28523.5, 27635.0, 28532.0]] |a4=[D:[[27958.5, 28374.5, 27833.5, 28241.5, 28110.5, 28533.0]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 6, "\uda9d\udddd\ud9a3\udcd3\udbcd\udf1a", "\u8eb0\u1e3d\u5d77\uac94\u7398\u187e\u5fe6\u0c99\u30a7\u179a\u2982\ua84a\u5941\u21d0\u0bb5\u5c6b\u202b\u0f69\u42f6\u21a3\u5b10\u6a9b\u78c3\ub85b\u8544\u2214\u8307\u8ba9\uaba4\u61af\u9423\u9518", "\uda8d\udf67\ud88c\udf07\ud816\udf18",
        47, 31844, -1835625687, -672179165369726228L, -60436L, true, false, (char) 46207, (char) 30865,
        Double.longBitsToDouble(0x3fe390a604feaa5dL), Double.longBitsToDouble(0x3fda6739e552ec94L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\0121=void |a0=[D:[[27651.0, 28180.0, 27673.0, 28489.5, 27887.0, 28583.0, 27755.0, 28262.5]] |a2=[D:[[12251.0, 1588.5, 11480.0, 4846.0, 5289.0, 21517.0, 11400.5, 4304.0]] |a3=[D:[[27831.5, 28405.0]] |a4=[D:[[27651.0, 28180.0, 27673.0, 28489.5, 27887.0, 28583.0, 27755.0, 28262.5]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 2, 3, 2, 9, "\ud836\udc58\ud862\udec3\uda0e\udf7e\ud906\udcfd\udb3a\udd3d\ud8e3\udf42\u9087\ud8f3\udfd5\uda4d\udca7", "\u5fe6\u0c99\u59e0\u260c\u2982\ua84a\u5941\u21d0\u0bb5\u5c6b\u522d", "\ud99f\ude1a",
        52, 37326, -1431224865, 3258202300240307910L, 34964L, false, true, (char) 18002, (char) 984,
        Double.longBitsToDouble(0x3fd8a1edebf43a62L), Double.longBitsToDouble(0x3fe4af8e0a87a0ebL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |a0=[D:[[-24.0, 27811.0, 28357.0, 28110.5, 28533.0, 27755.0, 28262.5, 28037.0]] |this=org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:@?\012",
        Z.run(T, 1, 3, 6, 7, "\000\ud976\uddba\udbcd\udf1a\ud906\udcfd\udb3a\udd3d\ud8e3\udf42\u9087\ud8f3\udfd5\uda4d\udca7", "\u5fe6\u0c99\u30a7\u179a\u2982\ua84a\u5941\u21d0\u0bb5\u5c6b\u00c9", "\ud911\udd62",
        29, -1000, -1442840576, 15610569738420224L, 34964L, false, true, (char) 3922, (char) 883,
        Double.longBitsToDouble(0x3fd8a1edebf43a62L), Double.longBitsToDouble(0x3fe4af8e0a87a0ebL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|doOptimize||new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|determineLMDirection|[D,[D,[D,[D|new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|determineLMParameter|[D,double,[D,[D,[D,[D|new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|qTy|[D|new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|qrDecomposition||new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|setCostRelativeTolerance|double|new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|setInitialStepBoundFactor|double|new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|setOrthoTolerance|double|new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|setParRelativeTolerance|double|new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|setQRRankingThreshold|double|new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
    "C|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|<init>|",
    "M|org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer|doOptimize||new:org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
