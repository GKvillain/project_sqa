package org.apache.commons.math3.distribution;
import org.junit.Test;
import static org.junit.Assert.*;
public class HypergeometricDistribution_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NumberIsTooLargeException\012",
        Z.run(T, 2, 13, 1, 13, "\uda21\udd37", "\u54f5\u2b54\u1a21\ub605\u0e2a\u0f3f\u2663\u0329\u1353\u2ecd\u3565\u6bc9\u096c\u3c81\u90c8\u7982\u991e\u5460\ua115", "\udaa6\udf63\uda48\udce3\ud8d0\udd70\udb3c\udfb1\ud816\udc98\ud9cb\udd7b\uda24\udd6e\uda65\udfac\udb83\udcdc\ud9cb\udef2\udb89\udd7c\udb37\udd74\ud8be\udd15\uda99\udd39",
        24, 46054, 1093189627, -475267139991166651L, 25791L, false, true, (char) 52806, (char) 22558,
        Double.longBitsToDouble(0x3fbb3b450b5ec6b8L), Double.longBitsToDouble(0x3fd8b4d7e64ebf8cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NumberIsTooLargeException\012",
        Z.run(T, 2, 13, 1, 13, "\uda21\udd37", "\u54f5\u1a58\u1a21\ub605\u0e2a\u0f3f\u2663\u0329\u1353\u2ecd\u3565\u6bc9\u096c\u3c81\u90c8\u7982\u991e\u5460\ua115", "\udaa6\udf63\uda48\udce3\ud8d0\udd70\udb3c\udfb1\ud816\udc98\ud9cb\udd7b\uda24\udd6e\uda65\udfac\udb83\udcdc\ud9cb\udef2\udb89\udd7c\udb37\udd74\ud8be\udd15\uda99\udd39",
        24, 46054, 1093189627, -475267139991166651L, 25791L, false, true, (char) 52806, (char) 22558,
        Double.longBitsToDouble(0x3fbb3b450b5ec6b8L), Double.longBitsToDouble(0x3fd8b4d7e64ebf8cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NotPositiveException\012",
        Z.run(T, 2, 13, 1, 13, "\uda21\udd37\ud9b0\uddeb\ud886\udda8\udba0\udeb4\udab4\udeae\udb49\uddf9\uda10\udc74\ud91b\udda0\uda42\udc82\uda0b\udf3f\ud9e7\uddf0\ud93a\ude55\ud9e0\udc14\ud94f\udc5d\uda99\udd6b\ud851\udc87\ud80c\udd8c", "\u991e\u5460\ua115\u018b", "\uda48\udce3\ud8d0\udd70\udb3c\udfb1\ud816\udc98\ud85a\ude60\uda24\udd6e\uda65\udfac\udb83\udcdc\ud9cb\udef2\udb89\udd7c\udb37\udd74\ud8be\udd15\uda99\udd39\uda95\uddf0\ud86f\udea9",
        35, 38246, -479649467, 1470736600133870688L, -62220L, true, true, (char) 13065, (char) 19181,
        Double.longBitsToDouble(0x3fe031790561cab1L), Double.longBitsToDouble(0x3fee5179710abe65L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NotPositiveException\012",
        Z.run(T, 2, 15, 1, 13, "\uda21\udd37\ud9b0\uddeb\udbdf\udf60\ud94e\udcd7\udab4\udf25", "\u0e2a", "\ud9e7\uddf0\ud93a\ude55\ud8b8\ude98\udb88\udebf\udaba\udeee",
        22, 31424, -2061692306, 12008109716210464L, 21332L, true, false, (char) 30285, (char) 45907,
        Double.longBitsToDouble(0x3fea5b38b58cc2f0L), Double.longBitsToDouble(0x3fc8557e804140acL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NotStrictlyPositiveException\012",
        Z.run(T, 2, 13, 1, 13, "\uda21\udd37", "\u54f5\u2b54\u1a21\ub605\u0e2a\u0f3f\u2663\u0329\u1353\u923d\u349b\u6bc9\u096c\u3c81\u90c8\u7982\u991e\u5460\u3ca4", "\udaa6\udf63\udb24\udf11\ud8d0\udd41",
        -1, 50338, -869574462, -925187972419290833L, 51830L, true, false, (char) 59566, (char) 53136,
        Double.longBitsToDouble(0x3fe33702e7fb0473L), Double.longBitsToDouble(0x3fe8720941f81d6bL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NumberIsTooLargeException\012",
        Z.run(T, 2, 13, 1, 13, "\uda21\udcb1\ud9b0\uddeb\ud97c\udda3\udba0\udeb4", "\u0e3f\u0e0c\u0f3f\u2663\u0329\u511d\ud061\u6f87\u34ed\u096c\u5e47\u5cd0\u159e\u991e\u5460\uaa5d\u00ef\u99c1\u96f4\u0d5d\uacee\u4572\u61ac\u77cf\u3123\u1d4e\u1414\u089d\uc0a1\u71a3", "\udaef\udc1c\udbfc\udc5f\ud9d3\udde4\udbfb\udcef\u6f4e\uda3e\ude25\udb1b\ude0a\uda9b\uded9\uda37\udd37\uda14\ude10\ud8d1\udc1d\ud841\uddfc\udbc4\udf2f\ub033\udbb5\ude7d\uda17\udf0d",
        43, 4909, 875446852, -5100958414010161364L, -72212L, true, false, (char) 56141, (char) 11900,
        Double.longBitsToDouble(0x3fe13c4fd7a1a7c7L), Double.longBitsToDouble(0x3fe06abac8885712L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NotPositiveException\012",
        Z.run(T, 1, 0, 0, 13, "\uda21\udd37", "\ub4f4\u2b54\u1a21\ub605\u0e2a\u0f3f\u2663\u92d3N\000\u3639\u2d44\000\u3be1\u90c8\u7982\u991e\u5460\ua115", "\udaa6\udf63",
        56, -1000, 15777611, 68679895662418114L, 88815L, false, false, (char) 35980, (char) 21794,
        Double.longBitsToDouble(0x3fe269bc7fce7500L), Double.longBitsToDouble(0x3fe33702e7fb0473L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Double:1.1131725417439704 |this=org.apache.commons.math3.distribution.HypergeometricDistribution:@?\012",
        Z.run(T, 1, 6, 0, 13, "\udada\udc8a", "\ub4f4\u2b54\u1a21\u22da\u0e2a\u0f3f\u2663\u92d3N\u6829\u3639\u2d44\u2ccc\u6066\u90c8\u7982\u991e\u5460\u2f90", "\udaa6\udf63\uda51\udf88\ud923\udcd1\ud80f\uddd5",
        56, 50, 16, -2198889696157376233L, -36328L, false, true, (char) 21794, (char) 11740,
        Double.longBitsToDouble(0x3fee73a80666e05cL), Double.longBitsToDouble(0x3fefd8239d486c4bL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NumberIsTooLargeException\012",
        Z.run(T, 1, 6, 14, 13, "\udada\udc23", "\ub4f4\u2b54\u1a21\u22da\u0e2a\u0f3f\u2663\u87b9\u2e2f\u8fa4\u3d6c\u130b\u2ccc\ub028\u90c8\u19a6\u991e\u5460\u2f90", "\udaa6\udf63\uda51\udf88\ud923\udcd1\ud80f\uddd5",
        56, 50, 14926352, 6773125187189723071L, -83666L, false, false, (char) 50285, (char) 21026,
        Double.longBitsToDouble(0x3fe0fc8cf2941f17L), Double.longBitsToDouble(0x3fe9bf166eb117a0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Double:14.285714285714286 |this=org.apache.commons.math3.distribution.HypergeometricDistribution:@?\012",
        Z.run(T, 1, 0, 12, 13, "\udb24\udf4f", "\ub4f4\u2b54\u1a21\u22da\u0e2a\u0f3f\u2663\u92d3N\u6829\u3639\u2d44\u2ccc\u6066\u90c8\u7982\u991e\u5460\u2f90", "\udaa6\udf63\uda51\udf88\ud917\udc2c\uda06\udc30",
        56, 50, 16, -2198889696157376233L, -36328L, false, true, (char) 21794, (char) 11740,
        Double.longBitsToDouble(0x3fee73a80666e05cL), Double.longBitsToDouble(0x3fefd8239d486c4bL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[I:[[10, 16]] |this=org.apache.commons.math3.distribution.HypergeometricDistribution:@?\012",
        Z.run(T, 1, 3, 0, 13, "\udada\udc8a", "\ub4f4\u2b54\u1a21\u22da\u0e2a\u0f3f\u2663\u92d3N\u6829\u3639\u2d44\u2ccc\ubb10\u3ee0\u7982\u991e\u5460\ub401", "\udaa6\udf63\uda51\udf88\ud923\udcd1\ud80f\uddd5",
        56, 50, 16, -2198889696157376233L, -36328L, false, true, (char) 21794, (char) 11740,
        Double.longBitsToDouble(0x3fee73a80666215cL), Double.longBitsToDouble(0x3fefd8239d48964bL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Double:1.2784090909090908 |this=org.apache.commons.math3.distribution.HypergeometricDistribution:@?\012",
        Z.run(T, 1, 6, 0, 13, "\udada\udc8a", "\ub4f4\u2b54\u1a21\u22da\u0e2a\u0f3f\u2663\u92d3N\u6829\u3639\u2d44\u580e\ua0d4\u230e\u7982\u991e\u5460\u2f90", "\ud808\udd73\ud978\udd39\ud982\ude09\ud80f\uddd5",
        56, 50, 21, -2198889696157376233L, -36328L, false, true, (char) 21794, (char) 11740,
        Double.longBitsToDouble(0x3fee73a80666e05cL), Double.longBitsToDouble(0x3fefd8239d486c4bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|getNumericalMean||new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|calculateNumericalVariance||new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|cumulativeProbability|int|new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|getDomain|int,int,int|new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|getLowerDomain|int,int,int|new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|getNumberOfSuccesses||new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|getNumericalVariance||new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|getPopulationSize||new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|getSampleSize||new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|getSupportLowerBound||new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|getSupportUpperBound||new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|getUpperDomain|int,int|new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|innerCumulativeProbability|int,int,int|new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|isSupportConnected||new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|probability|int|new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|upperCumulativeProbability|int|new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
    "M|org.apache.commons.math3.distribution.HypergeometricDistribution|getNumericalMean||new:org.apache.commons.math3.distribution.HypergeometricDistribution:int,int,int",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
