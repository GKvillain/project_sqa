package org.apache.commons.math.stat.descriptive.moment;
import org.junit.Test;
import static org.junit.Assert.*;
public class Variance_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 8, 5, 21, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud97d\udce7", "\u5ddf\ucc76\u167e\u8529\u5ca5\u40d2", "\udbcf\udf79\ud8e2\udc10\ud98f\ude57\ud8a8\udd00\ud8e2\udfdd\ud8a2\udeed\ud9bb\udc5c\ud82b\udddb",
        17, 55823, 1166651040, 4931034463166012474L, 16813L, false, false, (char) 6821, (char) 42350,
        Double.longBitsToDouble(0x3fd31717546e27ccL), Double.longBitsToDouble(0x3fe7b6a9791899e6L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 8, 5, 21, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud97d\udce7", "\u5ddf\ucc76\u167e\u8529\ubba4\u40d2", "\udbcf\udf79\ud8e2\udc10\udb0d\udf17\ud9a6\udfbc\ud8e2\udfdd\ud8a2\udeed\ud9bb\udc5c\ud82b\udddb",
        17, 55823, 1166651040, 4931034463166012474L, 16813L, false, false, (char) 6821, (char) 42350,
        Double.longBitsToDouble(0x3fd31717546e27ccL), Double.longBitsToDouble(0x3fe7b6a9791899e6L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 22, 6, 21, "\udabf\udd07\uda2f\ude45\udab1\udcfd\ud999\udf66\ud96c\ude5f\ud97d\udce7", "\u5ddf\ucc76\u167e\u8529\ud5fd\u40d2\u8b11\u3832\ub961\u106e\u57b9\ud4f3\ua7b2\u23b8\ua854\uacae\u8e22\u4a93\u55b8\u73b0\uc185\ud1f4\u8b29\u6a4c\u5b6a", "\uda2f\ude2c\uda7e\udcf1\ud8d3\udccb\uda3c\udfcb\udb56\udd74",
        53, 1079, -2059466539, -8500809987864775256L, -8158L, true, true, (char) 31323, (char) 13054,
        Double.longBitsToDouble(0x3fc24f0672502450L), Double.longBitsToDouble(0x3fc88501fa5912c0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 22, 5, 21, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud97d\udce7\ud996\udd2c\uda43\udd4a\ud800\udcf4\udbbc\udf43", "\u2eec", "\ud9c6\udd3e\udbe8\udd77\ud8e2\udc10\ud98f\ude57\ud8a8\udd00\ud8e2\udfdd\ud8a2\udeed\uda22\udf10\udb7a\ude3f\ud840\udfde\udb8a\udd48\ud820\udeb9\ud976\uddc0\udbaa\udf4b",
        33, 85485, 282474072, 1557089675799531476L, 99223L, false, false, (char) 19198, (char) 25043,
        Double.longBitsToDouble(0x3feef90a685f5a62L), Double.longBitsToDouble(0x3fe88273f89bd5beL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 21, 13, 21, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud8a5\udf73", "\u4db2\ucc76\uc042", "\ud8f5\udf96\udac6\udf91\udb05\udc98\udbcf\udf79\ud8e2\udc10\ud98f\ude57\ud8a8\udd00\ud8e2\udfdd\ud8a2\udeed\ud9c7\udef8",
        42, 28914, 1558991761, 5010728062136323512L, 707L, false, false, (char) 35265, (char) 6821,
        Double.longBitsToDouble(0x3fe6a0acdd317175L), Double.longBitsToDouble(0x3fe1b89f36f6d52fL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 20, 5, 21, "\udabb\uddbe\uda2f\ude45\uda66\ude38\udb0c\uded6\uda44\udd21\ud97d\udce7", "\u8545\u9fe5\u167e\u8529\u5ca5\u5590", "\udaa7\udf85\ud8e2\udc10\ud98f\ude57\ud943\ude03\uda98\udefb\ud8a2\udeed\ud9bb\udc5c\ud82b\udddb\ud840\udfde\udb99\udf48\ud820\udeb9\ud976\uddc0\udbaa\udf4b\ud8d6\udf2f\uda93\udf64",
        41, 93127, -132214828, 1433883219122391607L, 2888L, false, false, (char) 2887, (char) 21454,
        Double.longBitsToDouble(0x3f90081e92b12f00L), Double.longBitsToDouble(0x3fd8173454332b7eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 8, 5, 5, "\udac8\udfe3\uda2f\ude45\000\udacd\udca5\uda71\udd7e\ud97d\udce7", "\u5ddf\ucc76\u167e\u8529\u5ca5\u40d2", "\udbcf\udf79",
        51, 41911, -2072707000, 115964116992L, 60809L, true, false, (char) 28770, (char) 236,
        Double.longBitsToDouble(0x3fdb8000087488dcL), Double.longBitsToDouble(0x3fc3be0700000000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 15, 19, 21, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\udb55\ude30\ud834\udde4", "\u9e58\ucc76\u6495\u5cea\u5ca5\u40d2", "\udbcf\udf79\ud9ca\udc04\ud8f0\ude28\ud97d\udc49\ud8e3\udc5f\ud8a2\udeed\ud89d\ude0e\udb8f\ude7d",
        31, 74320, 696888992, 7949393535148191159L, 94125L, false, true, (char) 44815, (char) 31087,
        Double.longBitsToDouble(0x3fa8b89b613997f0L), Double.longBitsToDouble(0x3fe5b43d5df443d0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NumberIsTooLargeException\012",
        Z.run(T, 1, 2, 5, 21, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud97d\udce7", "\u5ddf\u1c76\u167e\u4103\u9922\u40d2", "\udb7e\udd8a\ud8e2\udc10\ud98f\ude57\udbd1\udeb3\ud8e3\udc36\ud8a2\udeed\ud9bb\udc5c\ud82b\udddb",
        17, 79222, 1166651040, 670066265720101946L, 16813L, false, false, (char) 6821, (char) 42350,
        Double.longBitsToDouble(0x3fd31717546e27ccL), Double.longBitsToDouble(0x3fe7b6a9791899e6L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NotPositiveException\012",
        Z.run(T, 1, 2, 0, 21, "\udabf\udd07\uda2f\ude45\uda66\ude38\ud801\ude31\000\000", "\u5ddf", "\udb8d\ude2a\ud8d7\udf5f\ud8f5\udf96\udac6\udf91\udafd\udc94\ud90c\udd79\ud8e2\udc10\ud98f\ude57\000\ud8e2\udfc2\ud8a2\udeed\ud9bb\udc5c\000\ud820\uddaf\udb8a\udd48\ud820\udeb9\ud9f1\uddbe\000",
        33, -923, 282460160, 1556848882753048532L, 99223L, false, false, (char) 19198, (char) 34380,
        Double.longBitsToDouble(0x3fd04020dd0c645eL), Double.longBitsToDouble(0x3fcafdd41b833278L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 11, 5, 21, "\u822e\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud97d\udce7", "\u5ddf\ucc76\u167e\u4bf7\ua8f4\u40d2", "\udbcf\udf79\ud89a\udf6c\ud98f\uded7\ud8a8\udd00\ud8e2\udfdd\ud8a2\udeed\ud9bb\udc5c\ud82b\udddb",
        17, 55823, 1166651040, 4931034463166012474L, 16813L, false, false, (char) 6821, (char) 42350,
        Double.longBitsToDouble(0x3fd31717546e27ccL), Double.longBitsToDouble(0x3fe7b6a9791899e6L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Double:62229.696428843905 |a0=[D:[[27975.5, 28267.5, 27903.5, 28426.5, 27931.0, 28420.0, 28014.0, 28499.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 1, 5, 21, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud97d\udce7", "\u5ddf\ucc76\u167e\u8529\u5ca5\u40d2", "\udaa4\udc6a\ud98e\udd88\ud98f\ude07\ud8a8\udd00\ud8e2\udfdd\ud8a2\udeed\ud9bb\udc5c\ud82b\udddb",
        44, 55764, -1709658464, 6531998958862474298L, 16813L, false, false, (char) 6821, (char) 42350,
        Double.longBitsToDouble(0x3fd31717546e27ccL), Double.longBitsToDouble(0x3fe7b6a9791899e6L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 1, 10, 5, 21, "\udb4f\udfd1\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud97d\udce7", "\u5ddf\ucc76\u167e\u8529\u5ca5\u455d", "\udbcf\udf79\ud8e2\udc10\ud98f\ude57\ud8a8\udd00\ud8e2\udfdd\ud828\udef0\udaeb\udff4\ud82b\udddb",
        17, 55823, 1166651040, 4931034463166012474L, -7564L, false, false, (char) 6821, (char) 42350,
        Double.longBitsToDouble(0x3fd31717546e27ccL), Double.longBitsToDouble(0x3fe7b6a9791899e6L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 12, 11, 21, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud97d\udce7", "\u5ddf\ucc76\u167e\u8529\u5ca5\u40d2", "\udbcf\udf79\ud8e2\udc10\ud98f\ude57\ud8a8\udd00\ud8e2\udfdd\ud8a2\udeed\ud9bb\udc5c\ud82b\udddb",
        17, 51079, 1166651099, 4931034463166012474L, 31840L, false, false, (char) 6821, (char) 42350,
        Double.longBitsToDouble(0x3fd31717546e27ccL), Double.longBitsToDouble(0x3fe7b6a9791899e6L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:62229.69642857143 |a0=[D:[[27975.5, 28267.5, 27903.5, 28426.5, 27931.0, 28420.0, 28014.0, 28499.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 2, 0, 4, 6, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud97d\udce7", "\u5ddf\u10bd\ub5d0\u8529\u272c\u6d92", "\uda21\udd80\ud8c3\udcde\uda83\udcd3\udbc8\uddd3\udba5\uddde\ud8a2\udeed\ud9bb\udc01\ud82b\udddb",
        17, 55823, 1166651040, 7525107848531459366L, 82349L, false, false, (char) 6821, (char) 42350,
        Double.longBitsToDouble(0x3fd31717546e27ccL), Double.longBitsToDouble(0x3fe7b493c11899e6L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Double:62229.69642857143 |a0=[D:[[27975.5, 28267.5, 27903.5, 28426.5, 27931.0, 28420.0, 28014.0, 28499.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 16, 12, 4, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\ua9db\u25bb", "\u5ddf\ucc76\u167e\u08aa\u84d5\ub307", "\udbcf\udf79\ud8e2\udc10",
        21, 71344, -1575978725, -7626721545383743282L, -15018L, false, true, (char) 2727, (char) 27146,
        Double.longBitsToDouble(0x3fe0f71de570ae49L), Double.longBitsToDouble(0x3fb89338a0a3b248L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 1, 19, 5, 21, "\udabf\udd18\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud815\udec8", "\u5ddf\ucc76\u167e\u8529\u5c86\u9460", "\udbcf\udf79\ud8e2\udc10\ud98f\ude57\ud8a8\udd00\ud8e2\udfdd\ud8a2\udeed\ud9bb\udc5c\ud82b\udddb",
        8, 55740, 1166652638, 4931034463166012474L, -73790L, true, true, (char) 6821, (char) 42350,
        Double.longBitsToDouble(0x3fd31717546e27ccL), Double.longBitsToDouble(0x3fe7b6a9791899e6L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.math.stat.descriptive.moment.Variance:@? |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 9, 5, 21, "\udaac\ude9e\uda2b\uddce\uda66\ude38\udb0c\uded6\uda71\udd7e\ud97d\udce7", "\u5ddf\ucc76\u9d9a\u2497\u5ca5\u40d2", "\udbcf\udf79\ud8e2\udc10\udba0\udd5f\ud8a8\udd00\uda81\ude97\udaa4\ude52\ud9bb\udc5c\ud82b\udddb",
        17, 55823, 1166651040, 4931034463166012474L, 16813L, false, false, (char) 6821, (char) 42350,
        Double.longBitsToDouble(0x3fd31717546e27ccL), Double.longBitsToDouble(0x3fe7b6a9791899e6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 1, 7, 5, 21, "\udabf\udd07\uda2f\ude45\uda66\ude38\ud931\udd49\uda3a\udd79\ud972\udce1", "\u5ddf\ucc76\u167e\u8529\u5ca5\u40d2", "\udbcf\udf79",
        51, 31591, -2072649516, -6408489114652872406L, 1335L, true, false, (char) 28770, (char) 2956,
        Double.longBitsToDouble(0x3fc708b131444b90L), Double.longBitsToDouble(0x3fe4ef81c04d64b1L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Double:9384.5 |a0=[D:[[28131.0, 28268.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 0, 0, 0, "\udbf6\udd08", "\u1b78", "\u0702",
        0, 44631, -816323038, -1755265461199435803L, -100000L, false, false, (char) 0, (char) 58345,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd2aa71019d2c50L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 8, 5, 21, "\udabf\udd20\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud97d\udce7", "\u5ddf\ucc76\u167e\u8529\u6632\u40d2", "\ud9a6\udf27",
        51, 41911, -2072649656, -6408489114652872406L, 1335L, true, false, (char) 28770, (char) 2956,
        Double.longBitsToDouble(0x3fdb8458987488dcL), Double.longBitsToDouble(0x3fe4ef81c04d64b1L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 13, 12, 2, "\udabf\udd07\uda2f\ude45\uda66\ude38\ud929\udc64\uda71\udd7e\ud97d\udce8", "\u5ddf\ucc76\u167e\u8529\u5ca5\u40d2", "\udbcf\udf79\ud8e2\udc10\ud98f\ude57\ud8a8\udd00\ud8e2\udfdd\udae3\udf6d\uda08\udd4e\uda47\udc1c",
        46, 55823, 1166651040, 4931034463166012474L, 16813L, false, false, (char) 6821, (char) 42350,
        Double.longBitsToDouble(0x3fd317175c6e27ccL), Double.longBitsToDouble(0x3fe7b16b311899e6L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[D:[[]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 0, 0, 0, "", "\u00be\000\000\u12bd\u1fc1\000\000\000\u925e\u7e29", "\000\000\000\ud9d5\ude4a\ud98f\ude57\ue848\ud8c4\udedd\ud8a2\udec3\ud894\udf89\ud82b\udddb\ud840\udfde\udbb0\udfdc\u00a0\000\udba3\udf11\uc29d\000\000\ud856\udd09\0001\u0a37\000\ud9cb\udde5\udbf1\udc44\udb49\udd52",
        47, 98874, 1835215, -2277630888228131959L, 58621L, true, true, (char) 36431, (char) 30156,
        Double.longBitsToDouble(0x3fe133e36d695c95L), Double.longBitsToDouble(0x3fd4daf80a1fed00L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 14, 12, "\ud866\udfa2\uda01\udc90\uda66\ude38\udb0c\uded6\udb9d\uddef\ud97d\udce7", "\u5ddf\ucc76\u167e\u8529\uaa9c\u2dad", "\ud9d9\udf7e\ud8e2\udc10\ud98f\ude57\ud8a8\udd00\ud8e2\udfdd\ud8a2\udeed\ud9bb\udc5c\ud82b\udddb",
        17, 55823, 1644286525, 6723281529594289500L, 16813L, false, false, (char) 6821, (char) 42350,
        Double.longBitsToDouble(0x3fd317175c6e27ccL), Double.longBitsToDouble(0x3fe7b6ab991899e6L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud97d\udce7", "\u5ddf\ucc54\u167e\u00e5\u5ca5\u500c", "\udbcf\udf79\ud8e2\udc10\177\ud8a8\udd00\ud8e2\udfdd\ud8a2\udeed\ud9bb\udc5c\ud82b\udddb",
        17, 55823, 1166606336, 4931034463166012474L, 16813L, false, false, (char) 6821, (char) 5743,
        Double.longBitsToDouble(0x3fd31710000001ccL), Double.longBitsToDouble(0x3fe7b6a9791899e6L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Double:56929.44200821431 |a0=[D:[[27975.5, 28267.5, 27903.5, 28426.5, 27968.5, 28262.5, 27828.5, 28571.0]] |a1=[D:[[11991.5, 26147.0, 2855.0, 17020.5, 7803.0, 8273.0, 17776.5, 7169.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 20, 6, 21, "\udabf\udd07\uda2f\ude45\udab1\udcfd\ud999\udf66\ud96c\ude5f\ud97d\udce7", "\u5ddf\ucc76\u167e\u8529\u3d26\u40d2\u8b11\u3832\ub961\u106e\u57b9\ud4f3\ua7b2\u23b8\ua7ea\uacae\u8e22\u4a93\ub733\u1098\uc185\ud1f4\u8b29\ubf55\u5b6a", "\uda2f\ude2c\000\ud8d3\udcb3\uda3c\udfcb\udb56\udd74",
        53, 1079, -2059466539, -8500809987864775256L, -73694L, true, true, (char) 31579, (char) 48675,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc885001a5912c0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 22, 6, 5, "\udabf\udd07", "\ub67e\u833e", "\000\000",
        -3, 66413, -491649051, 5455623048864464896L, -100000L, true, false, (char) 20931, (char) 53352,
        Double.longBitsToDouble(0x3feb0267c11b8475L), Double.longBitsToDouble(0x3fa553880ce00000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 22, 6, 7, "\udaad\udc25\udb11\udcb8\udab1\udcfd\ud999\udf66\uda3d\udca2\ud987\udec7\udb86\ude03\udb68\udda4\u9fe7\udbbc\udf43\ud9e4\udded\udb5b\ude10\ud9cc\ude4f\ud815\ude16\ud95f\udeff\u1dd4\ud83e\udc70", "\ud4f3\u9807\u23b8\u02b3\u5ca6\u0fe2\u4a9b\uc9ba\ud7ce\uc185\ud1f4\u8b29\u6a4c\u5b6a\ud64c\ud143", "\ud8dd\udccb\uda30\ude62\udab5\udd26\ud8a7\udc7e\udba6\udeb6\ud80a\udd99\udb56\udcd4\ud924\udd08\ud92a\udc95\udba9\udd51\udb9d\udcb4\udbc7\ude17\ud97d\udc29\udbf5\udcbe\ud93b\udef0\ud90f\udcd0\udb68\udd33\ud865\ude47\udb3a\ude52\ud924\udf05\ud99d\udfa5\ud97d\udde6\ud88d\ude95\ud86e\ude84\ud902\udcb3\udb97\udc15\udb54\ude82\ud96f\udc93\ud9b0\udee2\udb52\udf03",
        7, 79584, 1765373329, -2020314512227297403L, -86999L, false, true, (char) 41456, (char) 51276,
        Double.longBitsToDouble(0x3fd327934f52e3e4L), Double.longBitsToDouble(0x3fef671ca3c8b5dcL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Double:35284.82519968861 |a0=[D:[[27975.5, 28267.5, 27903.5, 28426.5, 28119.5, 28437.0, 28060.0, 28613.0]] |a1=[D:[[20332.5, 26147.0, 2855.0, 17020.5, 27366.5, 8273.0, 17776.5, 7163.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 19, 6, 21, "\udabf\udd07\uda2f\ude45\udbdf\ude5a\udb68\udfba\ud99d\udf6b\ud97d\udce7", "\u9f09\ucc76\u167e\u8529\ud5fd\u40d2\u8b11\u3826\ub961\u106e\u694e\u58c0\ua7b2\ua663\ucec9\uac06\u9ed6\u1174\u55b8\u73b0\uc185\ud1f4\u2588\u412b\u5b6a", "\uda2f\ude2c\ud840\uddf1\ud817\ude27\ud99f\ude66\udbba\uded3",
        -2, 1079, -2059466539, 2956347464172867792L, 96405L, false, false, (char) 1221, (char) 3496,
        Double.longBitsToDouble(0x3fe419407e9c88d0L), Double.longBitsToDouble(0x3fd035a48f4ab3feL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Double:72570.02176141797 |a0=[D:[[27975.5, 28267.5, 27903.5, 28426.5, 27945.5, 28526.5, 27828.5, 28571.0]] |a1=[D:[[11991.5, 17576.0, 2855.0, 21837.0, 3489.0, 8273.0, 17776.5, 7169.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 6, 21, "\udabf\udd07\uda2f\ude45\uda83\udf0d\ud999\udf66\ud96d\udf91\ud97d\udce7", "\u5ddf\u8980\u167e\uaaca\u1b72\u40d2\u8b11\u3832\ub961\u106e\u57b9\u25d6\ua85d\u23b8\ua854\uacae\uc698\u4a93\u55b8\u73b0\uc185\ud1f4\u8b29\u6a4c\u5b6a", "\uda2f\ude2c\u3eb4\ud8d3\udccb\uda3c\udfcb\ufa48",
        48, 1079, -2074146603, -8456055372078500440L, -8158L, true, true, (char) 31323, (char) 13054,
        Double.longBitsToDouble(0x3fc24f0672502450L), Double.longBitsToDouble(0x3fc167eb6b470764L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 1, 10, 6, 5, "\udabf\udd07\ud9f8\udcca\udab1\udcfd\ud999\udf66\ud96c\ude5f\ud97d\udce7", "\u5ddf\ucc76\u167e\u8529\ud5fd\u40d2\u8b11\u3832\ub961\u106e\u3cc4\u4b4f\u799a\u0c80\ua854\uacae\u3082\u8e0b\u6436\u73b0\uc185\ud1f4\u8b29\u6a4c\u5b6a", "\uda2f\ude2c\udb02\uddfa",
        31, 89728, -161422842, 5642168906150042207L, -38139L, false, true, (char) 57897, (char) 32267,
        Double.longBitsToDouble(0x3fd738edd7ae384cL), Double.longBitsToDouble(0x3fe35a5e34927833L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 22, 6, 21, "\udabf\udd07\uda2f\ude45\udab1\udcfd\ud999\udf66\ud96c\ude5f\ud97d\udce7", "\u5ddf\ucc76\u167e\u8529\ud5fd\u40d2\u8b11\u3832\ub961\u106e\u57b9\ud4f3\ua7b2\u23b8\ua854\uabd7\u8e22\u4a93\u55b8\u73b0\uc185\ud1f4\u8b29\u6a4c\u5b6a", "\uda2f\ude2c\uda23\udf03\000\u5300\000",
        5, 1079, -2059466539, -8500809987864775256L, -8158L, true, true, (char) 31323, (char) 13054,
        Double.longBitsToDouble(0x3fc24f0672502450L), Double.longBitsToDouble(0x3fc88501fa5912c0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.MathIllegalArgumentException\012",
        Z.run(T, 1, 22, 6, 21, "\ud9b7\udfe2\ud832\uddf1\uda9c\udc68\ud864\udc98\ud96c\ude23\ud97d\udce7", "\ub3fd\u27f2\ub699\u388f\u4046\u1f1e\u8b11\u3832\ub961\u8477\u9382\ud574\ua7b2\u23b8\ua854\uacae\u47a7\u4b0e\u55b8\u73b0\uc185\ud1f4\u8b29\u124d\u5b6a", "\uda26\udfc5\uda7e\udcf1\ud8d3\udccb\uda3c\udfcb\udb56\udd74\ud839\udc5b\udb1d\udc4d\ud80a\udccf\ud8c5\udc67\ud8af\udcd8\ud93c\udc6d\udb8d\ude55\udba1\uddbe\udbc7\ude17\ud99d\udd39\udbf5\udd1a\ud93b\udef0\ud90f\udc4a\ud86f\udf5d",
        33, -147, -1899082370, 1665243110228858834L, 8053L, false, false, (char) 33535, (char) 63223,
        Double.longBitsToDouble(0x3fa829615815c7a0L), Double.longBitsToDouble(0x3fe4dfec86fdf538L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 22, 6, 21, "\udabf\udd07\uda2f\ude45\udb09\udf16\ud859\udea9\uda5c\udf9e\ud901\ude77", "\u5ddf\ucc76\u167e\u8529\ud5fd\u40d2\u8b11\u3832\ub961\u106e\u57b9\u7fff\ua7b2\u23b8\ua854\uacae\u8e22\u4a93\u55b8\u73b0\uc185\ud1f4\u2f4f\u6a4c\u591d", "\uda2f\ude2c\ud8de\udcdb\ud8d3\udccb\uda3c\udfcb\udb56\udd74",
        4, 60351, -2059466539, -8500809987864775256L, -8158L, true, true, (char) 31323, (char) 30462,
        Double.longBitsToDouble(0x3fe6089b673ff215L), Double.longBitsToDouble(0x3fbc9e23b4b22580L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NotPositiveException\012",
        Z.run(T, 1, 18, 5, 17, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud97d\udce7\ud996\udd2c\udb65\udf49\udb99\uddeb\udbbc\udf43\ud83c\udca2\udbb0\udc42\uda8c\udee5", "\ua3f7\u4360\u106e\u3e0e\u6ddc\ua7b2\u23b8", "\ud88b\udd8d\ud97b\udd5c\uf105\ud8a7\udce7\ud9fc\uded0\udb90\udf3d\ud989\udd37\u2756\u1615",
        -5, 45953, -718337481, -7357158900983025384L, 40255L, true, false, (char) 59790, (char) 44633,
        Double.longBitsToDouble(0x3fe74b235805c993L), Double.longBitsToDouble(0x3fcdf7d90fcbe7e8L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 2, 13, 5, 6, "\ud80b\udc84\udb5f\ude18\uda6c\udefe\udb0c\uded6\uda71\udd7e", "\u8437\u5ddf", "\uda7a\udd0a\uda8c\udee5\ud888\udc87\ued07\udab9\ude79\udbe8\udd77\ud8e2\udc10\udadd\udf0a\ud87b\udd49\ud8e2\udfdd\ud8a2\udeed\uda9a\udf0c\udb7a\ude3f\ud841\udc2a\udb8a\udd48\ud820\udeb9\ud976\uddc0\uea59",
        26, 85485, 282474072, 1557089672505914068L, 51272L, false, true, (char) 17708, (char) 8897,
        Double.longBitsToDouble(0x3fe88273f89bd5beL), Double.longBitsToDouble(0x3fe318df6f81a819L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Double:61371.0 |a0=[D:[[27975.5, 28278.5, 27903.5, 28426.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 0, 20, 2, "\udabf\udd1d\uda2f\ude45", "\u7db2\u4126\u3a6b\u80dd\u5ddf\u0676\u2cc6", "\ud8a1\ude5a\ud821\udcfd\ud9c6\udd8e\u1278\udba7\udf52\udaf5\udfad\ud815\udf67\ud838\udfc2\ud978\ude8b\uda22\udf10\ud9d0\udd87",
        59, 23042, 1166651043, -5509658573846024152L, 45306L, true, false, (char) 60600, (char) 42350,
        Double.longBitsToDouble(0x3fdbf2575e9443ccL), Double.longBitsToDouble(0x3fe7b3b4711899e6L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Double:54750.50989051689 |a0=[D:[[28035.0, 28506.0]] |a1=[D:[[3516.5, 4418.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 19, 13, 2, "\udb36\udee4", "\u1ba9\u22b5", "\uda47\udf0e\uda00\udd1d\udbbc\udf43",
        3, 16931, 1264887643, -7086636794659599023L, -38067L, false, false, (char) 21598, (char) 17272,
        Double.longBitsToDouble(0x3fd1b84752554e20L), Double.longBitsToDouble(0x3fc9d2c509b49300L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 1, 21, 13, 0, "", "\u2999", "\ud8a5\udf73\udb73\udd42\udb61\uddf6\uda00\udd1d\udbbc\udf43\udb5c\ude69\udbe1\udf53\ud98e\udfcc\ud8f5\udf96\udac6\udf91\udb05\udc98\uda85\ude13",
        51, 41911, -2072649656, -6408489114652872406L, 76749L, false, false, (char) 63733, (char) 2956,
        Double.longBitsToDouble(0x3fdb84589001c36eL), Double.longBitsToDouble(0x3fe4ef8000fa17c2L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:62229.69642857143 |a0=[D:[[27975.5, 28267.5, 27903.5, 28426.5, 27931.0, 28420.0, 28014.0, 28499.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 12, 0, 21, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud8a5\udf73", "\u4db2\ucc76\uc042", "\ud8f5\udf96\ud9a1\udf9f\ud927\udc54\udaf1\udc6d\ud95f\udde2\uda4f\ude27\ud8a8\udd00\ud8e2\udfdd\ud8a2\udeed\ud9c7\udef8",
        42, 28914, 1558991761, 5010728062136323512L, 707L, false, false, (char) 35265, (char) 6821,
        Double.longBitsToDouble(0x3fe6a0acdd317175L), Double.longBitsToDouble(0x3fe1b89f36f6d52fL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Double:30054.13717502626 |a0=[D:[[27973.5, 28359.0]] |a1=[D:[[3516.5, 8979.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 20, 5, 2, "\udabb\uddbe", "\u1ba9\u4657", "\uda43\udd4a\ud8c2\udfb5\ud8e6\udf1e\ud9e4\udded\udb8d\ude2a",
        32, 94154, -349413525, -5670017789397430765L, -68770L, true, true, (char) 34598, (char) 62443,
        Double.longBitsToDouble(0x3fdb9a38b0912b36L), Double.longBitsToDouble(0x3fe9d6b7a5b8c775L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 15, 10, 11, "\udabf\udd07\udaee\udcc6\uda66\ude38\udb0c\uded6\udb55\ude30\ud834\udde4", "\ub632\ucc76\u6495\u5cea\u5ca5\u40e2", "\udbcf\udf79\ud9ca\udc04\udba8\udfb0\udb3b\ude19\udad6\ude02\ud88b\udf7c\ud805\ude00\ud97a\udf6a",
        19, 18016, -802389089, 2833304357558670547L, 94125L, false, true, (char) 44815, (char) 31087,
        Double.longBitsToDouble(0x3fa8b89b613997f0L), Double.longBitsToDouble(0x3fe5b43d5df443d0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 8, 13, 11, "\udabf\udd07\uda2f\ude45\uda66\udd98\udb2f\udcba\udb96\udc92\uc8ee", "\u0234\ucc76\u8654\u8c56", "\udac6\udf91\uda27\udd94\ud92a\udf79\ud8e2\udc10\ud9eb\uddee\ud8a9\ude81\ud8e2\udfc2\uda73\ude33\ud89f\udd86\000\udbd9\udf2b\ud9da\uddfb\udbfb\udda9\udaae\uded2\000\uda95\udcef\ud9f0\udc26\ud9ae\udcf6",
        -1, 98241, 1846469394, -3095179384858238986L, 47029L, false, true, (char) 32949, (char) 37749,
        Double.longBitsToDouble(0x3fe63e3d0aefe503L), Double.longBitsToDouble(0x3fca3fba18e23340L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Double:99585.12500027248 |a0=[D:[[27768.0, 28516.0, 27908.5, 28565.5, 27931.0, 28420.0, 27986.5, 28367.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 5, 21, "\ud920\udef8\uda39\udf5b\uda66\ude38\udad5\uddcf\uda71\udd7e\ud97d\udce7\udac3\ude0f\uda2d\uded2\ud9b0\udfcc\udbbc\udf43\uda13\udeed\udb8d\ude2a", "\u8b11\u2857\ub718\u9448\u7781\u12e2\u29a2\u94c0\uc845\u7858\u4b5f\u5757\u55e4\u976c\u61b1\ud1f4\u2b23\u7aba\u40e4\u0a82\u6e54\ud777\u0ddf\uc080\u7861\u715b", "\uda85\udc11\uda5f\udc12\udb6f\udef8\ud948\udc15\ud920\udd85\ud9fa\uddea\uda06\udd3b\ud936\ude28\ud960\udea5\udafa\ude72\udaab\udd61\ub6b0\udacc\uddc9\ud96c\udcc9\udb8a\udc61\ud894\udca1\ud85e\ude63\ud9a4\ude24",
        0, 90056, 629749944, 387250622904473268L, -65462L, false, false, (char) 26111, (char) 46896,
        Double.longBitsToDouble(0x3fbf3a11b85928d0L), Double.longBitsToDouble(0x3fefc9c5787f357bL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Double:87057.06696428571 |a0=[D:[[27790.5, 28538.0, 28029.0, 28432.0, 27931.0, 28420.0, 28014.0, 28499.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!org.apache.commons.math.exception.NumberIsTooLargeException\012",
        Z.run(T, 2, 1, 7, 2, "\ud94d\udf24\udb2a\ude50\uda66\ude38\udb0c\uded6", "\u3a6b", "\udbbc\udf43\ud9e4\udded\udb8d\ude2a\uda55\udf5e\ud8f5\udf96\udac6\udf91\ud81f\udd48\udaa4\udc6a\ud98e\udd88\ud98f\ude07\ud8a8\udd00\ud8e2\udfdd\ud8a2\udeed\ud9bb\udc5c\ud82b\udddb\ud9df\udfed\udb8a\udd0d\ud87b\udfcf\uda9a\ude9f\udbaa\udf4b\ud852\udc8c\ud989\udd37\u2756\udad6\udcd7\ud94e\udd44\ud8a5\ude5a\ud7b1\uda7e\udcf1\uda2a\ude96\ud941\udc45\ud832\udc85",
        35, 56556, 222695457, 2185319994859225654L, 20618L, false, false, (char) 51134, (char) 9417,
        Double.longBitsToDouble(0x3fca6cd8801287d8L), Double.longBitsToDouble(0x3fddf129bcf3c0f4L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 11, 18, 1, "\udabf\udd07\uda2f\ude45\udb60\udc55\udb0c\udf12\uda71\udd7e\ud8db\udfbc", "\u5ddf\ucc76\u167e\u8529\u1c3d\u71d6", "\ud938\udd16\ud98e\udd88\u2085\uda8e\ude07\ud823\udd8d",
        54, 69542, -1703572521, 8870465089779650907L, 9966L, false, false, (char) 45781, (char) 3462,
        Double.longBitsToDouble(0x3fe3124b89cf10d6L), Double.longBitsToDouble(0x3feea0acdd317175L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Double:1.1213921950000013E8 |a0=[D:[[27975.5, 28267.5, 28.5, 27907.0, 28453.0, 13063.0, 27936.5, 28327.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:1.121392195E8 |a0=[D:[[27975.5, 28267.5, 28.5, 27907.0, 28453.0, 13063.0, 27936.5, 28327.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 17, 0, 7, "\udabf\udd07i\uda36\ude7a\u663e\uda71\udd7e\ud97d\udce7", "\u5ddf\u10bd\ub5d0\u8529\u1b2c\u6d92", "\uda21\udd80\udb9c\uddeb\000\000\000\udb40\uddc0\ud9bb\udc01\ud82b\udddb",
        17, 55823, 1166651040, 30963037712154624L, -100000L, false, false, (char) 6821, (char) 42350,
        Double.longBitsToDouble(0x3fd31717546e27ccL), Double.longBitsToDouble(0x3fe7b493c11899e6L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Double:62229.69642857143 |a0=[D:[[27975.5, 28267.5, 27903.5, 28426.5, 27931.0, 28420.0, 28014.0, 28499.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:47312.10056665593 |a0=[D:[[27975.5, 28267.5, 27903.5, 28426.5, 27931.0, 28420.0, 28014.0, 28499.0]] |a1=[D:[[15993.5, 24842.0, 12112.5, 1006.5, 4548.0, 21476.5, 5543.0, 10734.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 0, 4, 6, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud97d\udce7\ud996\udd2c\uda43\udd4a\ud800\udcf4\ud9e5\udd77\uda0c\udd3f\udb8d\ude2a\ud996\ude4d\udaed\udd0c\udac6\udf91", "\u7d23\uc244\u5ed1\u080d\u23b8\ua7f9\u2b7e\u540d\u11f1\u910a\ud17d\u8a72\u136f\u6ab5\u6a4c\u5b6a\ud64c", "\uda7e\udcf1\udada\ude0e\u6e46\ud980\uddd1\ud90d\udc7b\ud95f\udfdf\ud90e\udfd5\udab7\udc69\udb5b\udfcf\udb22\udcfa\uda34\udc5c\uda58\udfd2\ud997\udd1d\ud82c\udedd\ud8b8\udc9b\udb9a\udc5e\udb43\udec7\ud8fd\udd08\udb21\udf81\ud96b\udc20\udbd2\udf4b\uda94\uddd9\ud88b\udf54\ud861\uddc4\udb18\udf27\ud8cd\udda1\ud938\udc6a\ud9b1\udffe\uda34\uddee\ud9e5\udcaa\uda06\udeb5\uda56\udfde\ud9d5\udc58\udb31\udf77\ud985\udeac",
        22, 80689, 2049277646, -3202116560111510406L, 96063L, true, false, (char) 53859, (char) 24372,
        Double.longBitsToDouble(0x3feb5260cbd8f152L), Double.longBitsToDouble(0x3fd099b11c8a6d6cL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Double:60352.78125 |a0=[D:[[27975.5, 28267.5, 27903.5, 28426.5, 27931.0, 28420.0, 27831.0, 28295.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 0, 8, 9, "\udabf\udd07\uda2f\ude45\uda66\ude38\ud99e\udd3f\ud809\udf34\ud8d8\ude90", "\u5ddf\u10bd\ub5d0\u8529\u272c\u6d92", "\uda2e\udc55\ud809\udce1\uda83\udd4f\udbc8\uddd3\udba5\uddde\ud8a2\udeed\ud9bb\udc01\ud82b\udddb",
        17, 55823, 1166651040, -2418840128702595781L, 82349L, false, false, (char) 6821, (char) 42350,
        Double.longBitsToDouble(0x3fd31717546e27ccL), Double.longBitsToDouble(0x3fe7b493c11899e6L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Double:100478.03125 |a0=[D:[[27988.0, 28554.0, 27676.5, 28297.0, 28097.5, 28360.0, 27735.5, 28376.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:100478.03125 |a0=[D:[[27988.0, 28554.0, 27676.5, 28297.0, 28097.5, 28360.0, 27735.5, 28376.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 16, 16, 6, "\udad8\udf44\ud869\udd42\udbb3\uddc0\ud8df\udde0\ud863\udc5d\ud959\udd00\ud996\udd2c\uda43\udd80\udb8c\ude4e\ud9e5\udd75\uda0c\udd3f\udb8d\ude2a\ud996\ude4d", "\u1361\u0bce\u7db2", "\udba5\uddde\ud8a2\udeed\ud9bb\udc01\ud8cb\udc58\ud829\udd7a",
        31, 99894, 1752075704, -1136950933315272035L, 17099L, false, false, (char) 17319, (char) 28132,
        Double.longBitsToDouble(0x3fe0a1b598049278L), Double.longBitsToDouble(0x3fb45e9f428c7bd0L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Double:11325.125 |a0=[D:[[28131.0, 28281.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!org.apache.commons.math.exception.MathIllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 2, "\udbf6\udd23", "\000\u6f68", "\uda43\udcd6",
        56, 74730, -408638801, 8679605600256L, 27663L, true, true, (char) 49988, (char) 0,
        Double.longBitsToDouble(0x3fe3399000000000L), Double.longBitsToDouble(0x3e20000000000000L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Double:97162.42410714286 |a0=[D:[[27975.5, 28267.5, 27903.5, 28426.5, 27671.0, 28623.0, 28013.0, 28313.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!org.apache.commons.math.exception.NotPositiveException\012",
        Z.run(T, 2, 0, 18, 15, "\udabf\udd07\uda2f\ude45\ud85e\udfce\udb0a\udd63\uda71\udd7e", "\u74c6\u5092\u9c76\u9620\u249c\u6dd3\u6d92\u8b11\u6732", "\uda83\udcd3\udbc8\uddd3\udba5\uddde\ud8a2\udeed\ud9bb\udc01\ud82b\udddb\ud840\udfde",
        33, -960, 1752075704, -1136950933315272035L, 44984L, true, true, (char) 42350, (char) 40614,
        Double.longBitsToDouble(0x3fe1b89f36f69278L), Double.longBitsToDouble(0x3fedfccf30b3b638L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Double:62229.69642857143 |a0=[D:[[27975.5, 28267.5, 27903.5, 28426.5, 27931.0, 28420.0, 28014.0, 28499.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=org.apache.commons.math.stat.descriptive.moment.Variance:@? |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 0, 9, 6, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud97d\udce7", "\u5e72\u10bd\ub5d0\u8529\u272c\u75ec", "\uda21\uddbe\ud8c3\udcde\uda83\udcd3\udbc8\uddd3\udba5\uddde\ud8a2\udeed\ud9bb\udc01\udbc4\udd27",
        17, 53567, 1166650928, 7525107848531459366L, 82349L, false, false, (char) 62628, (char) 42276,
        Double.longBitsToDouble(0x3fd317175343fdccL), Double.longBitsToDouble(0x3fd7794cc2ec034cL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[D:[[]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!org.apache.commons.math.exception.MathIllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 13, "", "", "\uda71\udd7e\ud97d\udce7\ud996\udd2c\000\ud800\udcad\ud9e5\udd77\uda0c\udd3f",
        24, 79148, -1660591390, 7645437957939455789L, -19643L, true, false, (char) 64125, (char) 64942,
        Double.longBitsToDouble(0x3fd2ac91c0e72c50L), Double.longBitsToDouble(0x3feeb9e2ca2f9a75L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Double:42632.00000023842 |a0=[D:[[27975.5, 28267.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:21043.21327132929 |a0=[D:[[27975.5, 28267.5]] |a1=[D:[[3516.5, 4418.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 17, 4, 6, "\udabf\udd07", "\u1ba9\u22b5", "\uda43\udd4a\ud800\udcf4",
        7, 63504, -491649051, -2247564341936823582L, -100000L, false, false, (char) 47088, (char) 56539,
        Double.longBitsToDouble(0x3fd1aa1632370926L), Double.longBitsToDouble(0x3fd2ac91c0e72c50L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[D:[[77.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!org.apache.commons.math.exception.DimensionMismatchException\012",
        Z.run(T, 2, 0, 4, 6, "\u00cb", "\u1ba9\u2b21", "\uda43\udd4a\ud800\udcf4\ud9e5\udd77\uda0c\udd3f\udb8d\ude2a\ud996\ude4d\udaed\udd0c\udac7\udc30\udb10\udf98\uda21\udd80\ud8c3\udcde\uda47\udc34\uda39\udf80\uda78\udc67\udae8\uddae\ud8d0\udff5\udad5\udd78\udbdc\udccc\ud949\ude79\ud818\uddcc\udaaa\udfda\udbd3\udc37\ud852\udc8c\ud8c1\udd33\u2756\ud8bc\udd6b\udadf\udcfb\ud8d8\udc5d\ud957\udeb5\udbb8\ude68\uda0d\udebc\ud9cf\udc37\udb86\ude96\uda07\udc92\udbb2\udfa6\ud839\udecb\ud87d\udc10\uda02\udc5e\ud83b\udef1",
        11, 85115, 1464293919, -8755852335190305681L, -22565L, true, false, (char) 40904, (char) 27641,
        Double.longBitsToDouble(0x3fc0a9e163b23468L), Double.longBitsToDouble(0x3fca660304e0cf88L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:54450.984375 |a0=[D:[[27975.5, 28267.5, 27903.5, 28426.5, 27931.0, 28420.0, 28014.0, 28499.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 15, 0, 17, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud992\udc59", "\u5ddf\u10bd\ub5d0\u8529\u272c\u6250", "\uda21\udd80\ud84b\udf71\udb3e\ude74\ud8a3\udea7\udba5\uddc3\ud8a2\udeed\ud9bb\udc01\ud82b\udddb",
        17, 55823, 1166651040, 7525107848531459366L, -20205L, false, false, (char) 6821, (char) 15122,
        Double.longBitsToDouble(0x3fd31717546e27ccL), Double.longBitsToDouble(0x3fe7b493c11899e6L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 13, 5, 21, "\udabf\udd07\uda2f\ude45\udb6e\udde7\udba0\udf7c\uda31\udc33\ud972\udce1", "\u5ddf\ucd40\u167e\u8529\u5ca5\u40d2", "\udbcf\udf79",
        51, 31591, -2072649516, -6408489114652872406L, 1335L, true, false, (char) 28770, (char) 2956,
        Double.longBitsToDouble(0x3fc708b131451344L), Double.longBitsToDouble(0x3fe4ef81c04d64b1L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:47512.316964558195 |a0=[D:[[27975.5, 28280.0, 27903.5, 28426.5, 27931.0, 28420.0, 28114.0, 28322.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 13, 1, 18, "\udabf\udd20\uda2f\ude45\uda66\ude38\udbd4\udd74\udb47\uddea\ud97d\udce7", "\u51df\ucc76\u167e\u8529\u6632\u40d2", "\udb76\udeee\udbe0\udcee\ud98f\ude57\ud8a8\udd00\u13af",
        -4, 59446, 1774653917, 2059132719126565839L, 67352L, false, false, (char) 62165, (char) 11518,
        Double.longBitsToDouble(0x3fed58c51cb2e9c3L), Double.longBitsToDouble(0x3fe1e75a161d179aL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Double:70435.33928571429 |a0=[D:[[27944.5, 28536.5, 27848.0, 28197.0, 27945.5, 28217.5, 27712.5, 28243.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:70435.33928571429 |a0=[D:[[27944.5, 28536.5, 27848.0, 28197.0, 27945.5, 28217.5, 27712.5, 28243.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 1, 1, 12, "\uda81\udf21\ud9c0\udc7a\uda83\udca3\ud8b1\udcd7\ud8ec\ude38\ud97d\udce7\ud984\udc2c\uda43\udd4a\ud9b2\udff4\udb9c\ude43\ud9e4\udded\udb8d\ude2a\udb40\udf7c\ud8f5\udf96\ud861\ude40\udab1\udffd\udb40\uddd4\uda42\ude2e", "\u8f87\ubbcc\ua854\uaedd\u5486\u2785\u90be", "\ud852\udc8c\udb2d\udf6a",
        24, 46000, 337323358, 9078891186667931809L, 73225L, true, false, (char) 34410, (char) 25868,
        Double.longBitsToDouble(0x3fd7c5cbca90d678L), Double.longBitsToDouble(0x3fdc704ae45cb204L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Double:22883.420849695536 |a0=[D:[[27975.5, 28280.0]] |a1=[D:[[3516.5, 4418.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 5, 10, "\udabf\udd20", "\u1ba9\u22b5", "\uda43\udd4a\ud800\udcf4",
        -3, 90528, -1950994476, 5549979833084425570L, -54316L, false, false, (char) 34344, (char) 21609,
        Double.longBitsToDouble(0x3fb43f8c08dc23a8L), Double.longBitsToDouble(0x3fd2aa71064a04d4L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!org.apache.commons.math.exception.NullArgumentException\012",
        Z.run(T, 2, 8, 16, 17, "\udabf\udd20\uda2f\ude45\ud952\ude3f\uda86\udeaf\uda2f\uddb6\ud97d\udce7", "\u5ddf\ucc76\u167e\u8529\u6632\u40d2", "\ud9a6\udf27",
        32, 2225, -2072649656, -6408489114652872406L, 1335L, true, false, (char) 28770, (char) 2956,
        Double.longBitsToDouble(0x3feaf22c4c3a5ee2L), Double.longBitsToDouble(0x3fe4ef81c04d64b1L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[D:[[]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 17, 13, 0, "", "\u0783\000\000\u12bd\u1fc1\000\u0897\u0257\ucf6b\ua20a", "\000\000\000\udb5b\udf02\u4cd6\ud8c6\udf3a\ud8ea\udf6e\ud8a2\udec3\ud894\udf89\ud82b\udddb\ud840\udfde\udbb0\udfdc\ud8c2\udf88\u00f7\ud910\udc4f\udb2d\uddda\ud917\uddc1\u0083\ud856\udd09\ud87e\udc1e\010\u0a37\ube00\ud9cb\udde5\udbf1\udc44\udb49\udd52",
        47, 98874, 1835215, -2277630890979595383L, 58621L, true, true, (char) 36431, (char) 30156,
        Double.longBitsToDouble(0x3fe133e36d695c95L), Double.longBitsToDouble(0x3fd4daf80a1fed00L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[D:[[]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:NaN |a0=[D:[[]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 0, 16, 0, "", "\u7f8e\u0096\000\u12bd\u1fc1\000\000\000\u925e\u7e29", "\u0845\ud8e3\ude59\000\ud9d5\ude4a\ud98f\ude57\ue848\ud8c4\udedd\ud8a2\udec3\ud894\udf89\ud811\udfdb\ud840\udfde\uda39\udd4c\ud8b8\ude406\udba3\udf11\uc29d\udac5\ude83\000\ud856\udd09\000\ud8bf\udc6f\ud864\udfff\ud8e0\udebe\ud9ea\udd3e\udbf1\udc44\udb49\udd52",
        47, 98874, 1835215, 6228445051433035486L, 58621L, true, true, (char) 36431, (char) 30156,
        Double.longBitsToDouble(0x3fe133e36d695c95L), Double.longBitsToDouble(0x3fd4daf80a1fed00L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[D:[[-10.5]] |a1=[D:[[3465.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 19, 6, 21, "\033", "\u1b43", "\ub6f8\uda5e\udca0\ud870\uddf6\udbbc\udf43\ud9e4\udded\udb8d\ude2a\ud8c0\udcb8\ud8f5\udf96\u0d51\ud988\udc03\udbcf\udf66\ud8e2\udc10\uda25\ude53\ud8a2\udfe4\ud8e2\udfdd\u2d01\uf38b\udb80\uddfc\ud9dc\ude89\udaa8\udc0d\udac9\udc7c\ud98d\ude9d\udbaa\udf4b\ud852\udc8c\uc84d\udb39\udf1d\udbce\udf14\udac5\ude831\udb08\ude02\000\ud000\ud99f\ude66\ud8df\ude4e\udb4d\udffe\udba6\udeb6\udaca\udcd8\udbd6\ude6a\uda52\udc06\ud93c\udc6d\udb77\ude1e\u00bf\udbc7\udde2",
        22, -1000, 671088640, -8588128629751761252L, 63749L, false, false, (char) 51304, (char) 49225,
        Double.longBitsToDouble(0x3fcf3e9cd3c5561cL), Double.longBitsToDouble(0x3feaca42c968dbefL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Double:1.9677709595059752E8 |a0=[D:[[-10.5, -24.0, 27905.5, 28436.5]] |a1=[D:[[12452.5, 21584.5, 5148.5, 20332.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 19, 0, 0, "\033\000\uda33\ude59", "\u6179\ua8d1\u2869\u9f09", "\ud9d7\udfef\000\ud8f5\udf34\000\ud960\uded0\uda85\ude13\000\000\000\000\uda6a\udfd4\ud915\ude17/\u4d4a\ud8c4\udefc\000\000\udba3\udf11",
        33, 56976, 268916268, 10784662880256L, 99223L, false, false, (char) 332, (char) 24452,
        Double.longBitsToDouble(0x3fbe9d349ae35e30L), Double.longBitsToDouble(0x3f33aac6a8000000L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Double:80646.82894886257 |a0=[D:[[27975.5, 28267.5, 27903.5, 28426.5, 27945.5, 28526.5, 27828.5, 28571.0]] |a1=[D:[[11991.5, 14099.0, 12344.0, 24362.5, 5978.0, 25444.5, 20056.5, 6563.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 6, 21, "\udabf\udd07\uda2f\ude45\uda83\udf0d\ud999\udf66\ud96d\udf91\uda0f\uddc6", "\u5ddf\u6e56\u60a0\ube85\u2ee4\uc6f9\u9ce1\u3377\ub961\u106e\u57b9", "\ud83b\udc39\udb05\udfe1\udb80\udde4\udb43\udd98\udae5\udd8a\udac9\udc7c\ud9eb\udeac\udbab\udc0d\ud852\udc8c\ud9cd\udf01\u2756",
        2, 49236, 328809498, 4841099355284527223L, 9576L, false, false, (char) 63444, (char) 10412,
        Double.longBitsToDouble(0x3fcaa0ba79c6117cL), Double.longBitsToDouble(0x3fd9f8aa6e1de5e4L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[D:[[-24.0]] |a1=[D:[[3516.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 20, 5, 2, "\000", "\u1ba9", "\ud996\udd2c",
        24, 84407, 44290, -1755265860631394331L, 47016L, true, false, (char) 59255, (char) 45993,
        Double.longBitsToDouble(0x3fe84c48878217a4L), Double.longBitsToDouble(0x3fd603a8cb734716L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:NaN |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 12, 12, 11, "\udabf\udd07\udaee\udcc6\uda66\ude38\udb0c\uded6\udb55\ude30\ud834\udde4", "\ub632\ucc76\u6495\u5cea\u5ca5\u40e2", "\udbcf\udf79\ud9ca\udc04\udbf2\udfb5\udb3b\ude19\udad6\ude02\ud88b\udf7c\ud805\ude00\ud97a\udf6a",
        19, 18016, -802389089, 2833304357558670547L, 94125L, false, false, (char) 44978, (char) 2392,
        Double.longBitsToDouble(0x3fa8b89b61399fd0L), Double.longBitsToDouble(0x3fe5b43d5df443d0L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 15, 15, 11, "\udabf\udd07\udaee\udcc6\uda66\ude38\udb0c\uded6\udb55\ude30\ud834\udde4", "\ub632\ucc76\u6495\u5cea\u5ca5\u40e2", "\udbcf\udf79\ud9ca\udc04\uda11\ude39\udb0e\udd12\udad6\ude02\udb7f\ude7e\ud805\ude00\ud97a\udf6a",
        19, 18016, -802389089, 2833304354589103315L, 46211L, false, true, (char) 61643, (char) 65449,
        Double.longBitsToDouble(0x3fa8b89b613997f0L), Double.longBitsToDouble(0x3fe5b43d5df443d0L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Double:31689.266002483277 |a0=[D:[[27975.5, 28267.5, 27997.5, 28441.5, 27934.0, 28363.0, 27939.5, 28302.0]] |a1=[D:[[23297.0, 21487.0, 19565.0, 8585.5, 14820.0, 8281.0, 17776.5, 1182.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:31689.266002483277 |a0=[D:[[27975.5, 28267.5, 27997.5, 28441.5, 27934.0, 28363.0, 27939.5, 28302.0]] |a1=[D:[[23297.0, 21487.0, 19565.0, 8585.5, 14820.0, 8281.0, 17776.5, 1182.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 3, 19, 14, "\udabf\udd07\udaeb\ude63\uda6c\uddc6\uda77\udd4c\udb55\udeeb\ud834\udde4", "\ub632\ua80e\u990a\u4343\u73f8\u40e2\u8b11\u096d\u9fe7\u9c72\u1845\u0911\u8072\ubfea\u2334\u24bd\u72eb\ud13a\ucaef\ud529\uccb7\u8443\ua1c2\u62ad\u0114\u6cc6\u6448\u734c\u1674\ub965\u4db1\u9386\uaff6", "\u8b62\uda13\ude39\uda47\udc7d\udbf6\udc40\ud833\uddc8\udbdf\udf21",
        -1, 79855, -545823322, -1810918020048635578L, 47879L, false, true, (char) 57657, (char) 8952,
        Double.longBitsToDouble(0x3febf2eb6c77210dL), Double.longBitsToDouble(0x3fe0090ff4cb8888L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Double:99227.14285741534 |a0=[D:[[27790.5, 28538.0, 28029.0, 28432.0, 27790.0, 28397.5, 28014.0, 28499.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!org.apache.commons.math.exception.NotPositiveException\012",
        Z.run(T, 2, 1, 7, 0, "\ud94d\udf24\udb2a\ude50\ud94c\ude0b\udb0c\uded6", "\u263b\u214f\u622c\ucc76\u167e", "\udaf6\udd10\u309f\uda01\uded9\ud8b7\udf4d\udbc6\udf77\uda14\udfab\ud9d3\udcbc\uda13\udf75\ud8a2\udf53\ud9bb\udc5c\ud95f\udf94",
        -1, 55764, -993838445, -1024446644668064710L, 16813L, false, false, (char) 6821, (char) 34829,
        Double.longBitsToDouble(0x3fd2ed4d554e27ccL), Double.longBitsToDouble(0x3fe7b6a9791899e6L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=org.apache.commons.math.stat.descriptive.moment.Variance:@? |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 11, 9, 19, "\ud864\udd67\uda04\udf61\ud8c2\udf24\udb0c\udf20\uda71\udd7e\ud8db\udfbc\ud996\udd2c\uda35\udf5b\ud800\udcf4\ud827\ude72\ud9b3\uded5\ud8d7\udd8a\ud80d\udf5a\ud8a3\udecc\udb88\udd38\udbf9\udc1c\ud938\udd16\udb75\uddfd\u2085\udb5b\udd0c\u51ca\ud8a2\udeed", "\ubae6", "\uda45\udfc9\udbaa\udf4b\ud852\udc8c",
        5, 77124, 362507351, 3691726094795868025L, 72812L, false, false, (char) 51021, (char) 58873,
        Double.longBitsToDouble(0x3fe6837a8a64c136L), Double.longBitsToDouble(0x3fe4b12ef0cbd38bL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Double:61317.896634468205 |a0=[D:[[28119.5, 28445.5, 28074.0, 28421.5, 27711.5, 28281.5, 27966.5, 28444.5]] |a1=[D:[[23248.0, 986.5, 25110.0, 22780.5, 21317.5, 13185.0, 6233.5, 17801.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:61317.896634468205 |a0=[D:[[28119.5, 28445.5, 28074.0, 28421.5, 27711.5, 28281.5, 27966.5, 28444.5]] |a1=[D:[[23248.0, 986.5, 25110.0, 22780.5, 21317.5, 13185.0, 6233.5, 17801.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 4, 4, 8, "\udbdf\ude6b\udb84\ude3b\ud8af\udd23\udaad\ude69\ud9b8\ude5b\u0e21\ud968\ude34\uda43\udcd6", "\ub5d0\u07e5\uc45c\ub229\ua6bb\u6732\u30e3\u8b42\uaa67\u0403\u818a\u5665\u4fab\u53e9\u2fea\u813b\ub613\u43b2\u4c2b\ud0f7", "\uf01b\ud941\udcb7\uda55\udf90\udb56\udf79\udb45\udf8a\ud980\udd6d\uda47\udc53\ud965\udcd1\uda99\udff7\u4a8d\ud861\udeb0\uda2a\udffc\udbbf\udf50\ud8c8\uddba\udb04\udf1d",
        48, 75538, -261023375, -402465078556729982L, 60830L, true, false, (char) 12774, (char) 49449,
        Double.longBitsToDouble(0x3fd72003b09b4838L), Double.longBitsToDouble(0x3fe80b94b670d342L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=org.apache.commons.math.stat.descriptive.moment.Variance:@? |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=org.apache.commons.math.stat.descriptive.moment.Variance:@? |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 9, 9, 2, "\udbf6\udd23", "\u805f\u6f68", "\uda43\udcd6",
        56, 11730, -408638808, 7933959012352L, 27703L, false, false, (char) 29047, (char) 0,
        Double.longBitsToDouble(0x3fe33997e10bb300L), Double.longBitsToDouble(0x3f8b798840286f80L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[D:[[32460.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=!org.apache.commons.math.exception.NumberIsTooLargeException\012",
        Z.run(T, 2, 1, 7, 2, "\ufdc8", "\u09c7\u6f68", "\uda43\udcd6",
        56, 63570, -408663555, 8680375355942L, 27663L, true, true, (char) 43588, (char) 55039,
        Double.longBitsToDouble(0x3fce09200114ddd0L), Double.longBitsToDouble(0x3e20000000000000L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 13, 13, 13, "]\ua100\ud878\ude03\ud906\udf05\ud92f\udc88\uda51\udf9e\ud9f7\udea6\u028c\uda26\udd20\udb3b\udcc2\udbd6\udeb5", "\u84e1\u0bd4", "\ud9b0\udd43\ud963\udce6\ud8a0\udc31\ud9d5\udfe4\udb86\udc89\ud944\ude93\udac2\uddc5\udb31\udda8\u328d\ud959\udeab\udb85\uded9",
        25, 64586, 940839333, -851429825056745663L, 20305L, false, true, (char) 45819, (char) 38157,
        Double.longBitsToDouble(0x3fc10d5aef4240d4L), Double.longBitsToDouble(0x3fc121ac48dab3c8L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[D:[[77.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:0.0 |a0=[D:[[77.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 0, 16, 6, "\u00cb", "\u1ba9\u0b22", "\uda43\udd4a\ud800\udcf4\ud9e5\udd77\uda0c\udd3f\udb8d\ude2a\ud996\ude4d\udaed\udd0c\udac7\udc30\udb10\udf98\uda21\udd80\ud8c3\udcde\uda47\udc34\uda39\udf80\uda78\udc67\udae8\uddae\ud8d0\udff5\udad5\udd78\udbdc\udccc\ud949\ude79\ud818\uddcc\udaaa\udfda\udbd3\udc37\ud852\udc8c\ud8c1\udd33\u2756\ud8bc\udd6b\ud997\uddf8\ud89e\udc23\ud957\udeb5\udbb8\ude68\ud917\udfa9\ud9db\udd2c\udb86\udf08\uda07\udc92\udbe0\ude9f\udab2\udea4\ud87d\udc10\uda7a\udcda\ud835\udd44",
        11, 85115, 1464293919, -8755852335190305681L, 66523L, true, false, (char) 40904, (char) 3173,
        Double.longBitsToDouble(0x3f96a1c957f4e480L), Double.longBitsToDouble(0x3fca6618a4e0cf88L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:97073.64375089914 |a0=[D:[[27678.0, 28504.0, 27655.0, 28426.5, 27920.0, 28357.0, 28015.5, 28613.0]] |a1=[D:[[3725.5, 24556.0, 12817.0, 15961.0, 1601.5, 18121.5, 16482.0, 576.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 15, 20, 13, "\ud86c\udee0\ud83e\ude45\uda50\uddba\udb0f\udfba\udb3a\udcb6\ud913\uddd3\uda30\udec4\udacc\udf6a", "\u1d4b\uc008\u6452\u7ce2\u0cb3\u8dc3\u80f4\u04b0\u1f40\uc155\u9347\ubda3\u5127\u038d\u27f9\ud7ee\u4090", "\uda91\uddac\ud8be\udc51\udb3e\uddd9\ud836\uddf9\udb03\udece\ud892\udddf\uda89\uddce\ud943\udc62\udba6\udfe3\ud91e\ude31\ud93d\udd76\uda90\udea2\uda9e\udc24\uda26\udff3\udad5\udcc2\ud994\udc31\ud848\udd7a",
        32, 39420, 1528684606, 8267854807138704139L, 30970L, false, true, (char) 61743, (char) 30881,
        Double.longBitsToDouble(0x3fb45eae7c1907c8L), Double.longBitsToDouble(0x3fefcf48ad2fc4d6L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[D:[[32460.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:0.0 |a0=[D:[[32460.0]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 17, 1, 2, "\ufdc8", "\u09c7\u6f68", "\uda43\udcd6",
        56, 63570, -408663555, 8680375355942L, 27663L, true, true, (char) 10821, (char) 22873,
        Double.longBitsToDouble(0x3fd0755eccd5f4e8L), Double.longBitsToDouble(0x3e20000000000000L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 1, 8, 5, 21, "\udabf\udd07\uda2f\ude45\uda66\ude38\udb0c\uded6\uda71\udd7e\ud97d\udce7", "\u5ddf\ucc76\u167e\u8529\ud0e3\u40d2", "\udbcf\udf79\ud8e2\udc10\ud98f\ude57\ud8a8\udd00\udbe0\udd1b\000\ud894\udf89\ud82b\udddb",
        17, 55823, 1166651040, 4930879432026496058L, 16813L, false, false, (char) 6821, (char) 42350,
        Double.longBitsToDouble(0x3fd31717546e27ccL), Double.longBitsToDouble(0x3fe7b6a9791899e6L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[D:[[77.5]] |a1=[D:[[3516.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:0.0 |a0=[D:[[77.5]] |a1=[D:[[3516.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 20, 4, 6, "\u00cb", "\u1ba9", "\ud996\udd2c\uda43\udd4a\ud800\udcf4\"\000\000\ud996\ude4d\udaed\udd0c\udac7\udc30",
        13, 15715, 14821, -2075574581L, -12624L, true, false, (char) 64191, (char) 33202,
        Double.longBitsToDouble(0x3fa061805b3a01c0L), Double.longBitsToDouble(0x3fc708b13499a000L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[D:[[]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:NaN |a0=[D:[[]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 1, 1, 0, "", "\000\u09c7\u6f68\ucb42\000\000\u5ddf\ucce2\u551e\u07e5\u038f\u3b6e\u8b11\uafb3\u0f01\u1d86\u42a9E\000\u8212\u7638\u26b7", "\ud943\udebe\ud8c3\udd64\ud9c9\udf33",
        32, 89369, 99552153, 821192419090443972L, 47193L, true, true, (char) 62199, (char) 52431,
        Double.longBitsToDouble(0x3fd5bc4da0b884aeL), Double.longBitsToDouble(0x3fe89fb67946681dL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[D:[[-10.5]] |a1=[D:[[3465.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\0121=java.lang.Double:0.0 |a0=[D:[[-10.5]] |a1=[D:[[3465.5]] |this=org.apache.commons.math.stat.descriptive.moment.Variance:@?\012",
        Z.run(T, 2, 19, 3, 6, "\033", "\u1b43", "\ub6f8\uda5e\udca0\ud870\uddf6\udbbc\udf43\ud9e4\udded\udb8d\ude2a\ud8c0\udcb8\ud8f5\udf96\u0d51\ud988\udc03\udbcf\udf66\ud8e2\udc10\uda25\ude53\ud8a2\udfe4\ud8e2\udfdd\u2d01\ud9cf\uddb5\udb80\ude37\ud9dc\ude89\udaa8\udc0d\udac9\udc7c\ud98d\ude9d\udbaa\udf4b\ud852\udc8c\uc84d\udb39\udf04\udbce\udf14\udac5\ude831\udac1\udd5e\000\ud000\ud99f\ude66\ud8df\ude4e\udb4d\udffe\udba6\udeb6\udaca\udcd8\udbd6\ude6a\uda52\udc06\ud93c\udc6d\udb77\ude1e\u00bf\udbc7\udde2",
        22, -1000, 671088640, -8588128629751761252L, 63749L, false, false, (char) 51304, (char) 13642,
        Double.longBitsToDouble(0x3fcf3e84b3c5561cL), Double.longBitsToDouble(0x3fd5948592d1fe1eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|evaluate|[D|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|evaluate|[D,double|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|evaluate|[D,double,int,int|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|evaluate|[D,[D|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|evaluate|[D,[D,double|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|evaluate|[D,[D,double,int,int|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|evaluate|[D,[D,int,int|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|evaluate|[D,int,int|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|clear||new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|copy||new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|copy|org.apache.commons.math.stat.descriptive.moment.Variance,org.apache.commons.math.stat.descriptive.moment.Variance|static",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|getN||new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|getResult||new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|increment|double|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|isBiasCorrected||new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|setBiasCorrected|boolean|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|evaluate|[D|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|evaluate|[D,double|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|evaluate|[D,double,int,int|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|evaluate|[D,[D|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|evaluate|[D,[D,double|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|evaluate|[D,[D,double,int,int|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|evaluate|[D,[D,int,int|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
    "M|org.apache.commons.math.stat.descriptive.moment.Variance|evaluate|[D,int,int|new:org.apache.commons.math.stat.descriptive.moment.Variance:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
