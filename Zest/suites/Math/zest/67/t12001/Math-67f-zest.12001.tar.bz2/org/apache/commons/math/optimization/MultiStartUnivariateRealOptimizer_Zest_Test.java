package org.apache.commons.math.optimization;
import org.junit.Test;
import static org.junit.Assert.*;
public class MultiStartUnivariateRealOptimizer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 14, "\ud8c2\udd25\u031c\ud911\udca5", "\u7575\u53ad\u4c55\u3e8b\u58a1\u9fce\u9793\uc786\u5897\u843a\u26b0\u5d13\uab03\u5b95", "\ud9d8\udd82\uda7e\udcac\uda9a\udfe3\ud9b8\udd92\ud9ea\udf61\udb4c\udc8b\udb62\udf42\udb6b\udc0f\ua937\ud89d\udc36\udabf\udea4\uda8e\udc75\ud8d6\udea2\ud9a8\udcba",
        16, 13870, 2139733451, 8676370588326273491L, -42699L, true, false, (char) 5926, (char) 63443,
        Double.longBitsToDouble(0x3fe0bc832f34deeaL), Double.longBitsToDouble(0x3fcb262f003461f0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 14, "\ud8c2\udce2\u031c\ud911\udca5", "\u7575\u53ad\u4c55\u3e8b\u58a1\u9fce\u9793\uc786\u5897\u843a\u26b0\u5d13\uab03\u5b95", "\ud955\udd0c\ud8d5\udfbc\uda9b\udc3d\ud9b8\udd92\ud9ea\udf61\udb4c\udc8b\udac7\ude1c\udb6a\udf96\ua937\ud89d\udc36\udabf\udea4\uda8e\udc75\ud8d6\udea2\ud9a8\udd1d",
        16, 13870, 2139733451, 8676370588326273491L, -42699L, true, false, (char) 5926, (char) 63443,
        Double.longBitsToDouble(0x3fb1fd9979a51fa8L), Double.longBitsToDouble(0x3fcb262f003461f0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 11, 14, "\ud8c2\udd25\u031c\ud911\udca5", "\u7575\u53ad\u4c55", "\ud903\ude25\udb32\ude88\ud8ca\udc1e\ud931\udce2\ud8e4\udd97\udbe9\uddcc\ud975\udf55\ud818\udfd0\udbb3\uddd8\udb62\udd88\udaa6\udf97\ud9f3\uddf9\uda7e\udd2a",
        27, 37199, -150796752, 8142756493313416294L, -4243L, false, false, (char) 39563, (char) 29398,
        Double.longBitsToDouble(0x3fadf5c7ec1a1080L), Double.longBitsToDouble(0x3fe3b2d62c8e3d0dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 10, "\ud8c2\udd25\u031c\ud911\udca5\uda00\udf39", "\u53ad\u4c55", "\ud903\ude25\udb32\ude88\ud8ca\udc1e\ud931\udce2\ud8e4\udd97\udbe9\uddcc\ud975\udf55\ud818\udfd0\udbb3\uddd8\udb62\udd88\udaa6\udfc3\ud880\udf56\uda10\udf69",
        13, 49599, -137329699, 8142756493313416294L, -4243L, false, false, (char) 53719, (char) 29398,
        Double.longBitsToDouble(0x3fadf5c7b61a1080L), Double.longBitsToDouble(0x3fe3b2d62c8e0f0dL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:@?\0121=java.lang.Integer:0 |this=org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:@?\012",
        Z.run(T, 2, 3, 4, 14, "\ud8c2\udd25\u031c\ud911\udca5", "\u7575\u53ad\u4c55\u3e8b\u58a1\u9fce\u9793\uc786\u5897\u843a\u26b0\ud4b6\uab03\u5b95", "\ud9d8\udd82\uda7e\udcac\uda9a\udfe3\ud9b8\udd92\ud9ea\udf61\udb4c\udc8b\udb62\udf42\udb6b\udc0f\ua937\ud89d\udc36\udabf\udea4\uda8e\udc75\ud8d6\udea2\ud9a8\udcba",
        -2, 13837, 2139733451, 8676370588326273491L, -42699L, true, false, (char) 5939, (char) 63443,
        Double.longBitsToDouble(0x3fe0bc832f34deeaL), Double.longBitsToDouble(0x3fcb262f003461f0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 10, 8, "\ud8c2\udd25\u031c\ud911\udca5", "\u7575\u53ad\u4c55\u3e8b\u58a1\u9fce\u9793\uc786\u5897\u843a\u26b0\u5d13\uab03\u5b95", "\ud9d8\udd82\uda7e\udcac\uda9a\udfe3\ud9b8\udd92\ud9ea\udf61\udb4c\udc8b\udb62\udf42\udb6b\udc0f\ua937\ud89d\udc36\udabf\udea4\uda8e\udc75\ud8d6\udea2\ud9a8\udcba",
        16, 13870, 2139733451, 8676370588326273491L, -42699L, true, false, (char) 5926, (char) 63443,
        Double.longBitsToDouble(0x3fe0bc832f34deeaL), Double.longBitsToDouble(0x3fcb262f003461f0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 2, 11, 11, 14, "\ud8cf\udff1\udb6b\udd91\ud911\udca5", "\u063f\u53ad\u9fe3\u3cc5\u58a1\u9fce\u9793\u2490\ucfc6\u17e4\u4b83\u3c33\uab03\uba5e", "\ud9d8\udd82\uda7e\udcac\uda9a\udfe3\ud9b8\udd92\ud9ea\udf61\udb4c\udc8b\udb62\udf42\ud87c\ude58\udad0\ude04\udb14\udd2f\ud95e\udc9f\udaa2\udf81\udb7c\ude94\udbc5\ude43",
        -4, 30590, 1447589326, 8676328828359254483L, -42699L, true, false, (char) 5972, (char) 63443,
        Double.longBitsToDouble(0x3fe0bc832f34deeaL), Double.longBitsToDouble(0x3fcb262f003461f0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$5\012",
        Z.run(T, 2, 7, 1, 14, "\ud8c2\udd25\u031c\ud911\udca5", "\u1da6\u53ad\u4c55\u3e8b\u58a1\u9fce\ud272\uaec4\u58e7\u843a\u26b0\u5d13\uab03\u5b95", "\ud9d8\udd82\uda7f\udc9b\uda9a\udfe3\ud9b8\udd92\udbd8\udc98\uda07\ude97\ud82b\udd26\udb6b\udc0f\ua937\ud89d\udc36\udabf\udea4\uda8e\udc75\ud8d6\udea2\ud9a8\udcba",
        16, 13870, 881442251, -2143095081079008126L, 64612L, false, true, (char) 10768, (char) 13987,
        Double.longBitsToDouble(0x3fe857e5de0a723dL), Double.longBitsToDouble(0x3fe54621f67762b1L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$5\012",
        Z.run(T, 2, 7, 11, 12, "\ud8c2\udd25\u031c\ud911\udca5", "\u7575\u53ad\u4c55\u3e8b\u58a1\u9fce\u9793\uc786\u5897\u843a\uc8c1\u5c92\uab03\u5b95", "\ud9d8\udd82\uda7e\udcac\ud902\udd97\ud9b8\udd92\udac7\udd8f\udb4c\udc8b\udb62\udf42\udb6b\udc0f\ua937\ud89d\udc36\udabf\udea4\uda8e\udc75\ud8d6\udea2\ud9a8\udcba",
        16, 91290, 2141110286, 8676370588326273491L, -42699L, true, false, (char) 5926, (char) 63443,
        Double.longBitsToDouble(0x3fd6f90652d72336L), Double.longBitsToDouble(0x3fcb262f003461f0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$5\012",
        Z.run(T, 2, 8, 6, 14, "\udb1c\ude8f\ud97d\udea0\ud911\udca5", "\u7575\u53ad\u4c55\u3e8b\u58a1\u9fce\u9793\uc786\u5897\u843a\u26b0\u5d13\uab03\u5b95", "\ud9d8\udd82\uda7e\udcac\uda9a\udfe3\ud9b8\udd92\ud9ea\udf61\udb4c\udc8b\udb62\udf42\u3815\ud987\udcbe\ud89d\udc36\udabf\udea4\uda8e\udc75\ud8d6\udea2\ud9a8\udcba",
        16, 13870, 2139733451, 8676370588326273491L, -42699L, false, true, (char) 49772, (char) 63443,
        Double.longBitsToDouble(0x3fe0bc832f34deeaL), Double.longBitsToDouble(0x3fcb262f003461f0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:@?\0121=!org.apache.commons.math.MathRuntimeException$5\012",
        Z.run(T, 2, 3, 8, 1, "\ud8c2\udd25\u031c\ud911\udca5", "\u7575\u53ad\u4c55\u3e8b\u58a1\u9fce\u9793\uc786\u5897\u951d\u5639\u5d13\ud7c0\000", "\uda71\udc73\uda7e\udcac\uda9a\udfe3\ud9b8\udd92\ud9ea\udf61\udb4c\udc8b\udb62\udf42\udb6b\udc0f\udb9a\udd2e\ud89d\udc36\udabf\udea4\uda8e\udc75\ud8d6\udea2\ud9a8\udcba",
        16, 13870, 2139733451, 8676370588326273491L, -42699L, true, false, (char) 5926, (char) 63443,
        Double.longBitsToDouble(0x3fe0bc832f34deeaL), Double.longBitsToDouble(0x3fcb262f003461f0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:@?\0121=!org.apache.commons.math.MathRuntimeException$5\012",
        Z.run(T, 2, 3, 7, 15, "\ud8c2\udd25\u031c\ud929\udcbb", "\u7575\u53ad\u209b\u3e96\u58a1\u9fce\u9793\uc786\u5897\u843a\u26b0\u7e8e\u70b5\u5112", "\ud9d8\udd82\uda7e\udcac\uda9a\udfe3\ud9b8\udd92\ud9ea\udf61\uda77\udde5\uda3b\udc0c\udb6b\udc0f\udbd3\udd85\ud89d\udcad\udabf\udea4\uda8e\udc75\udad3\udde0\udb2a\ude52",
        16, 13870, 2139733451, 8676370588326273491L, -42699L, true, false, (char) 5926, (char) 37772,
        Double.longBitsToDouble(0x3fe13458f734deeaL), Double.longBitsToDouble(0x3fcb262f003461f0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 14, "\ud8c2\udcc5\u031c\ud911\udca5", "\u7575\u53ad\u4c55\u3e8b\u58a1\u9fce\u9793\uc786\u2b00\u843a\u26b0\u5d13\uab03\u5b95", "\u46cc\ud818\udfe2\udae1\udd5a\ud9ac\udd92\ud9ea\udf61\udb4c\udc8b\udb62\udf42",
        46, 44811, -1039671108, -7409410174738245206L, 44543L, false, false, (char) 47515, (char) 45281,
        Double.longBitsToDouble(0x3fd157f893a6f0d0L), Double.longBitsToDouble(0x3fe03546acfcacb1L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 11, 3, "\ud8a6\udf25\u031c\udb69\udd30", "\u02a6\u0657\u4355\u3e8b\u5e42\u9f71\u9793\uc786\u5897\u843a\ub666\u8fdd\uab03\u5b95", "\uda77\udd2a\uda7e\udcac\ud9e5\udf70\ud9b8\udd37\ud8d4\udc4a\ud84b\udca6\udbf9\udc45\udb6b\udc0f\ua937\ud89d\udc36\udabf\udea4\uda8e\udc75\ud851\udfff\ud9a8\udcf3",
        16, 13870, 2146221515, 8676370588326273491L, -42699L, true, false, (char) 5926, (char) 63443,
        Double.longBitsToDouble(0x3fa6c821c19ab070L), Double.longBitsToDouble(0x3fb8ec1631ab74c0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 14, "\udb05\udeb6\ud846\udf1e\uda17\udf88", "\u0a33", "\udacf\udd84",
        34, 49994, -1950796204, 7174508787772286343L, -52816L, true, true, (char) 54041, (char) 9679,
        Double.longBitsToDouble(0x3febb30b7333670fL), Double.longBitsToDouble(0x3fa184844e453580L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 11, 14, "\ud8c2\udd25\u031c\ud911\udca5\ud9ed\uddef\ud888\ude5e\udb34\udef6\ud9d7\udfce", "\u58a1\u9fce\u9793\uc786\u5897\u843a", "\ud818\udfd0\udbb3\uddd8\udb62\udd88\udaa6\udf97",
        23, 72743, -1351522088, 7483504626457839152L, -19999L, false, true, (char) 19226, (char) 19967,
        Double.longBitsToDouble(0x3fc683bae6aa64b0L), Double.longBitsToDouble(0x3fadf5c79c1a1080L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 2, 14, "\ud808\udf27\ud93f\udf91\ud91b\udd4b\ud8eb\udf21\ud888\ude5e\udb34\udef6\ud986\udd52\ud8fb\udd9c\ud92b\udc7a\udb57\udee0\ud903\ude25", "\u5897\u843a\ua393\u5c95\uab03\u5b95\u559c\u4212\u5cea\ucd85\ud15d\uaae5\u986a\u8500\uc66a\u7d47\u9163\u8ca2\u5b43\u66cb\u5817\ub597\u94d2\ucf0d\uaa52\u8d90", "\udadc\udf11\u7922",
        9, 25455, -828305667, -9194034744165304396L, 50734L, false, true, (char) 7362, (char) 2258,
        Double.longBitsToDouble(0x3fdb1ab7928dee80L), Double.longBitsToDouble(0x3fc098b248f354d0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 11, 14, "\ud8c2\udd25\u031c\ud911\udca5\ud9ed\uddef\ud987\udeb4", "\u4c55\u3e8b\u58a1\u9fce\u9793\uc786\u5897\u843a\u26b0\u5d13\uab03\u5b95\u559c\ua664\u536e\ucd85", "\ud973\udda8\udb4c\udc8b\uda62\udef7\udb5a\udeac",
        0, 95660, -1725137740, -1472719230552498117L, 30678L, false, false, (char) 20137, (char) 14748,
        Double.longBitsToDouble(0x3fe24f865c17e9efL), Double.longBitsToDouble(0x3fa38dadf1876ce0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 10, 8, "\ud8c2\udd25\u031c\ud911\udca5", "\u7575\u53ad\u4c55\u3e8b\u58a1\u9fce\u9793\uc786\u5897\u843a\u26b0\u5d13\uab03\u5b95", "\ud9d8\ude14\uda7e\udcac\uda9a\udfe3\ud9b8\udd92\ud9ea\udf61\udb4c\udc8b\udb62\udf42\udb6b\udc0f",
        0, 95660, -1725137740, -1472719230552498117L, 30678L, false, false, (char) 45281, (char) 10398,
        Double.longBitsToDouble(0x3fdd3786840d51aaL), Double.longBitsToDouble(0x3fcf95962f4feaf0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 0, 0, "\udbcb\udd4b\u7c2b\udaae\udcb3", "\u7575\u53ad\u41e7\u1e80\u409d\u9fce\u9793\uc786\ua548\u7932\u4df1\uca7d\u7b64\u5b95", "\ud85b\udc42\uda7e\udcac\uda9a\udfe3\ud9b8\udd92\ud9d0\udf21\u2411\ud9c0\uddf5\udb6a\udf97\ua937\udb49\udf29\ud951\udead\uda8e\udc75\ud8d6\udea2\ud896\udcb6",
        16, 91286, 2139733446, 8676370589182501331L, -68159L, true, true, (char) 18269, (char) 15476,
        Double.longBitsToDouble(0x3fe34dca9275a23aL), Double.longBitsToDouble(0x3fe0bc832f34deeaL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|getFunctionValue||new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|getResult||new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|getAbsoluteAccuracy||new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|getEvaluations||new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|getIterationCount||new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|getMaxEvaluations||new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|getMaximalIterationCount||new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|getOptima||new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|getOptimaValues||new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|getRelativeAccuracy||new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|optimize|org.apache.commons.math.analysis.UnivariateRealFunction,org.apache.commons.math.optimization.GoalType,double,double|new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|optimize|org.apache.commons.math.analysis.UnivariateRealFunction,org.apache.commons.math.optimization.GoalType,double,double,double|new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|resetAbsoluteAccuracy||new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|resetMaximalIterationCount||new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|resetRelativeAccuracy||new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|setAbsoluteAccuracy|double|new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|getFunctionValue||new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer|getResult||new:org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.UnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
