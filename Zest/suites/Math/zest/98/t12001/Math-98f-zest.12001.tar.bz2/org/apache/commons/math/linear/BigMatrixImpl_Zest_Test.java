package org.apache.commons.math.linear;
import org.junit.Test;
import static org.junit.Assert.*;
public class BigMatrixImpl_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\ud940\ude97\u2940\uda66\udfbe", "\uc7c7\u6d8c\u37fb\u82b4\u239d\u93f7\ub8c8\u2b84\u1e7c\u2e64\u5e78\u08ca\u5d77\ub5d8\u9e2a\uc549\u78b8\u08da\u4617\u80f2\u1940\u4c45\u5c87\u2899\u294e\u281b\ud243\u5df4\u2a49", "\ud98a\uddb8",
        57, 1577, 40126172, 6228187179345273953L, -82579L, false, true, (char) 41051, (char) 40614,
        Double.longBitsToDouble(0x3fe337ead73d5885L), Double.longBitsToDouble(0x3fca3d677a4dd0b8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 17, "\ud833\udd98\udb35\uded7\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\ud940\ude97\u2940\uda66\udfbe", "\uc7c7\u6d8c\u13d5\u6e2d\u516c\u93c1\ub8c8\u2b84\u237c\u2e64\u5e78\u08ca\u5d77\ub5d8\u9e2a\uc549\ud06c\u2e80\u4372\u5f85\u1940\u4c45\u5c87\ua04d\ub385\ud57c\ud1e3\ucea3\u7b45", "\ud98a\uddb8",
        57, 1577, 40126172, 6228187179345273953L, -82579L, false, true, (char) 41051, (char) 40614,
        Double.longBitsToDouble(0x3fe337ead73d5885L), Double.longBitsToDouble(0x3fca3d67664dd0b8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\udb88\ude9b\u2940\uda66\udfbe", "\uc7c7\u6d8c\u2b38\u82b4\u239d\u93f7\ub8c8\u2b84\u1e7c\u2e64\u5e78\u08ca\u5d77\ub5d8\u9e2a\uc549\u78b8\u08da\u4617\u80f2\u1940\u4c45\u5c87\u2899\u294e\u281b\ud243\u5df4\u8a49", "\ud98a\uddb8\udb08\uddb1\ud87b\uddb3",
        42, 54830, -1014733727, -3532333218720924685L, 64269L, false, true, (char) 64164, (char) 52387,
        Double.longBitsToDouble(0x3fca3d677a4dd0b8L), Double.longBitsToDouble(0x3fd9bbd6c2650ca6L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 3, 5, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\ud822\uddff\u2940\uda66\udfbe", "\uc7c7\u6d8c\u37fb\u82b4\u239d\u93f7\ub8c8\u2b84\u1e7c\u2e64\u5e78\u08ca\u5d77\ub5d8\u9e2a\uc549\u78b8\u08da\u4617\u80f2\uc4e7\u4403\u5c87\u2899\u294e\u281b\ud243\u5df4\u2a49", "\ud988\ude57",
        57, 1577, 40126172, 6228187179345273953L, -82579L, false, true, (char) 41051, (char) 63141,
        Double.longBitsToDouble(0x3fe337ead73d5885L), Double.longBitsToDouble(0x3fca3d677a4dd0b8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 2, 17, "\ud99f\ude12\udb35\udf63\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb22\udfb0\ud940\ude97\ud891\udf83\uda66\udfe6", "\u99c4\u535c\u17e9\u0462\u239d\u22c2\u2ff2\u2c60\u1e7c\u2e64\u3ff3\u5fe5\u5d77\ub5d8\u9e2a\uc549\u78b8\u08da\u4617\u80f2\u1940\u4c45\u5275\u80dd\u42bf\u2849\ud243\u5df4\u2a49", "\ud98e\udc3a\ud88d\udcb3\ud983\udf53\ud83d\uddbc\ud8fb\uddbc\ud9f8\udd03\ud917\udc9e\ud99d\udc51",
        18, 37591, 1733988037, 6378634627350492989L, -22173L, false, true, (char) 23317, (char) 63054,
        Double.longBitsToDouble(0x3fee985c68549a8fL), Double.longBitsToDouble(0x3fe8829e362c19e3L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 9, "\udbea\uddd7\udb35\udf08\ud80b\udd74\ud857\udf45\udade\udfc8\ud82f\udf93\udb24\udd31\ud940\ude97\udb65\udc2b\uda67\udc1d", "\u978a\u6d32\u37fb\u8362\u6ef8\u8809\u2aa3\u18d7\u4509\u2e64\u5e78\u08ca\u5d77\u8a96\ucb12\ud470\u78b8\u08da\u4617\u80f2\ucd19\uceec\u5c87\u2899\u294e\u281b\u4c55\ubdcf\u99e5", "\ud98a\uddb8",
        57, 1577, 40126172, 6229640733717193825L, 64269L, false, true, (char) 29633, (char) 53186,
        Double.longBitsToDouble(0x3fca3d677a4f9724L), Double.longBitsToDouble(0x3fd8f171c7ec1fe0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 11, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\ud940\ude97\u2940\uda66\udfbe", "\uc7c7\u6d8c\u37fb\u82b4\u239d\u93f7\u2997\uc1b5\u1e7c\u2e64\u5e78\u08ca\u5d77\uad09\u9e0c\uc549\u78b8\u08da\u4617\u80f2\u1940\u4c45\u5c87\u2899\u294e\u281b\ud243\u5df4\u878f", "\udb2a\ude4f\u3923\ud87b\uddb3",
        42, 54830, -1014733727, -3532333218720924685L, 64269L, false, true, (char) 29633, (char) 53186,
        Double.longBitsToDouble(0x3fca3d677a29d0b8L), Double.longBitsToDouble(0x3fee27244377e34aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null}}\0121=void |a0=[[Ljava.math.BigDecimal;:[[[null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null}}\012",
        Z.run(T, 2, 8, 8, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udae1\udcaa\ud8fb\udf99\udb24\udd31\ud940\ude97\u2940\uda66\udfbe", "\uc7c7\u0540\u295b\u6492\u0c2e\u93f7\ub8c8\u2b84\u1e7c\u2e64\u5e78\u08ca\u5d77\u44d8\u9e2a\uc549\uac51\u8ef1\u4617\u80f2\u1940\u2ddb\ucbc9\u27c8\u294e\u281b\ud243\u5df4\u2a49", "\ud98a\uddb8",
        57, 1577, 40126172, -3975105007996327648L, -82579L, false, true, (char) 41104, (char) 40614,
        Double.longBitsToDouble(0x3fe337ead73d5885L), Double.longBitsToDouble(0x3fca3d677a69d0b8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 17, 17, "\ud99f\ude12\udb35\udf08\udb08\udeb2\ud914\udd76\udade\udfce\ud82f\udf93\u8931\ud977\udd34\u2940\ud9de\udefa", "\uc7c7\u6d8c\u37fb\u82b4\uad53\u060a\u5d04\u2b84\u1e7c\u2e64\u1040\u9792\u5d77\ub5d8\u9e2a\uc549\u78b8\u08da\u4617\u80f2\u3695\u0f29\u5c87\u3a99\u294e\u281b\u34a3\u5c09\u0bb5", "\ud98a\uddb8\ud850\ude76\ud871\udfa8\ud9d8\udf5e",
        5, 12273, -822435417, 1572807347748694224L, -11756L, false, false, (char) 451, (char) 24589,
        Double.longBitsToDouble(0x3fe057717651acb3L), Double.longBitsToDouble(0x3fd37a601cadbe1cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 17, "\ud985\udc20\udb35\udf08", "\u637b\uac4e", "\ud8ed\udce7\uda66\udfbe\ud919\udd09\ud95e\udf22\ud936\udd7d\ud8dc\ude2d\ud8e0\udccd\udb21\udd0d\ud970\uddef\udb28\udedc\ud839\uddec\ued64",
        39, 38436, -589586401, -1571700590534771838L, -27392L, true, false, (char) 9165, (char) 58590,
        Double.longBitsToDouble(0x3fd17993f028ac02L), Double.longBitsToDouble(0x3fb5bd93e4ffeb28L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce", "\u9b91\u100d\u8fab\ub42e\u67ac\uc7c7\u6d8c\u37fb\u82b4\u64b6\u93f7\ub96f\u2b84\u1e7c\u403c\ud67b\u08ca\u7604\ub55b\ubb2c\u1fad\u5b0d", "\ud809\udf1b\udad5\udc2e\udaba\udcfa\ud8ea\udd80\udb88\udcb5\udbb7\uddfa\udbb0\udd1e\ud9d3\ude8e\ud9c8\udcac\udaef\ude17\ud8ec\udcb4\uda00\udcfe\ud98a\ude40\udb08\uddb1\ud87b\uddb3\ud81b\udf00",
        54, 12342, -822435417, 1572807347748688336L, -11756L, false, false, (char) 53186, (char) 24589,
        Double.longBitsToDouble(0x3fe49ba17455413fL), Double.longBitsToDouble(0x3fef3c21dabccf49L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 2, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\ud940\ude97\u2e0b\uda66\udfbe", "\uc7c7\u8f07\u37be\u82b4\u239d\u93f7\ub8c8\u2b84\u1e7c\u2e64\u5e78\u08ca\u5d77\ub5d8\u9e2a\uc549\u78b8\u08da\u4617\u80f2\u1940\u4c45\u5c87\u2899\u294e\u281b\ud243\u5df4\u2a49", "\ud98a\uddb8",
        57, 1577, 40126172, 6228187179345273953L, -82579L, false, true, (char) 41051, (char) 40614,
        Double.longBitsToDouble(0x3fe337ead73d5885L), Double.longBitsToDouble(0x3fca3d677a4dd0b8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 7, 6, 4, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\ud940\ude97\u2940\ud92c\udd81", "\uc7c7\u5d72\u37fb\u82b4\u239d\u93f7\ub8c8\u2b84\u1e7c\u2e64\u5e78\u08ca\u5d77\ub5d8\u9e2a\uc549\u78b8\u08da\u4617\u80f2\u1940\u4c45\u5c87\u2899\u186b\u02a5\ud243\u5df4\u2a49", "\ud98a\uddb8",
        57, 1577, 40126172, 6228187179345273953L, -82579L, false, true, (char) 41051, (char) 40614,
        Double.longBitsToDouble(0x3fe337ead73d5885L), Double.longBitsToDouble(0x3fca3d677a4dd0b8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 17, 9, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\ud940\ude97\u2940\uda66\udfbe", "\uc7c7\u6d8c\u6055\ua9e5\u239d\u93f7\ub8c8\u21bd\u34d9\u2e64\u5e78\u08ca\u5318\ub5d8\u3a3b\uc549\u78b8\u08da\u4617\u80f2\u1940\ua14e\u5c87\u2899\u294e\u281b\ud243\u5df4\u2a49", "\ud98a\uddb8",
        1, 1637, 40126172, 6228187179345273953L, 43262L, false, true, (char) 41051, (char) 40614,
        Double.longBitsToDouble(0x3fe18894573d5885L), Double.longBitsToDouble(0x3fee8f59de937402L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 6, 11, "\ud99f\ude12\udb35\udf08\ud937\udd6a\ud914\udd76\udade\udfce\ud82f\udfc8\udb24\udd31\ud905\udefb\ud8f8\uddd2\uda5a\udeb6", "\uaa72\u0db1\uc5dd\u82b4\u55b0\u2db9\ub8b3\u2b84\u1e7c\u2e64\u5e78\u08ca\u5d77\ub5d8\u64fb\uc4be\u78b8\u08da\u4617\ua2a7\u19be\u7c8c\u5c87\u7569\u3c6f\uc3c6\u6ca3\u5dda\u2a49", "\ud98a\uddb8",
        57, 1577, 1499743964, 4621603061260423110L, 66298L, true, true, (char) 24589, (char) 8897,
        Double.longBitsToDouble(0x3feb8f81969963aaL), Double.longBitsToDouble(0x3fd600d23d820cfcL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27831.5, 28401.0, 28034.5, 28524.0, 27629.5, 28322.0, 27762.0, 28323.0]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,27629.5,28322,27762,28323}}\0121=[Ljava.math.BigDecimal;:[[6319206886.75]] |a0=[D:[[27831.5, 28401.0, 28034.5, 28524.0, 27629.5, 28322.0, 27762.0, 28323.0]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,27629.5,28322,27762,28323}}\012",
        Z.run(T, 2, 6, 16, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udff7", "\u9b91\u100d\u3386\u3e2b\u67ac\uc7c7\u6d8c\u37fb\u7e8e\u2424\u93f7\ub8c8\u2b84\u1e7c\u2e64\u5e78\u08ca\u5d77\u1619\u9e2a\uc549\u78b8", "\udab4\udf32\udad5\udc2e\udaba\udcfa\ud8ea\udd80\udb88\udcb5\udbb7\uddfa\udbb0\udd1e\uda23\udd2f\udb19\udc38\ud9d3\ude7d\ud80f\udf49\uda02\udf21\ud98a\ude0f\uda4b\udc72\ud867\udf32\ud82e\udc80",
        5, 12273, 1886751911, 1572806818540526032L, 68454L, false, true, (char) 53186, (char) 24589,
        Double.longBitsToDouble(0x3fe49ba1743fb23dL), Double.longBitsToDouble(0x3fd3778f04aca3eeL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null}}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 2, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udb19\udfec\ud830\udc6e\udb24\udd31\ud940\ude97\u2940\uda66\udfbe", "\uc7c7\u6d8c\u37fb\u82b4\u239d\u93f7\ub8c8\u2b84\u1e7c\u2e64\u5e78\u08ca\u5d77\ub5d8\u9e2a\uc549\u78b8\u08da\u4617\u80f2\u1940\u4c45\u5c87\u2899\u294e\ud0b2\ud243\u5df4\u2a49", "\ud98a\uddb8",
        57, 1577, 40126172, 6228187179345273953L, -82579L, false, true, (char) 41051, (char) 56486,
        Double.longBitsToDouble(0x3fea2dcf673d5861L), Double.longBitsToDouble(0x3fca3d677a4dd0b8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\ud940\ude97\u2940\uda66\udfbe", "\uc7c7\u6d8c\u37fb\u82b4\u239d\u93f7\u30f5\u2b84\u1e7c\u2e64\u5e78\u08ca\u5d77\ub5d8\u9e2a\uc549\u78b8\u08da\u4617\u80f2\u1940\u4c45\u5c87\u2899\u294e\u281b\ud243\u5df4\u2a49", "\ud98a\uddb8",
        57, 1577, 40126172, 6228187179345273953L, -82579L, false, true, (char) 41051, (char) 40614,
        Double.longBitsToDouble(0x3fe337ead73d5885L), Double.longBitsToDouble(0x3fca3d677a4dd0b8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 2, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\ud940\ude97\u2940\uda66\udfbe", "\uc7c7\u6d8c\u37fb\u82b4\u239d\u93f7\ub8c8\u2b84\u1e7c\u2e64\u5e78\u08ca\u5d77\ub5d8\u9e2a\u380e\u78b8\u08da\u4617\u80f2\ua529\u4c45\u5c87\u2899\u294e\u281b\ud243\u5df4\u2a49", "\ud98a\uddb8\udb08\uddb1\ud87b\ude0c\ud81b\udf00\udbef\udc55",
        53, 50551, -1865772001, 7227017752301175213L, 82307L, true, true, (char) 24589, (char) 8897,
        Double.longBitsToDouble(0x3fe5ce7ca3958820L), Double.longBitsToDouble(0x3fdd9ad78c849f7cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 6, 9, "\ud973\udcbd\udb35\udf08\ud80b\udd74", "\u5bcf\u3e7f\u9b91\u100d", "\ud95e\udf22\ud923\udc33\ud805\udfcb",
        57, 7438, 1395038026, 70697340588190763L, -80714L, false, false, (char) 31008, (char) 23965,
        Double.longBitsToDouble(0x3fec117faafbc976L), Double.longBitsToDouble(0x3fe76bb90d680942L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 2, 17, "\ud99f\ude12", "\u2bd4\u637b\u14b0\u2aba\uc790\u100d\u8fab\ub42e\u67ac\uc7c7\u6d8c\u37fb\u82b4\u5c6f", "\ued64\uda30\udf36\udaae\ude4f",
        59, 11964, 0, -3767542562680544160L, 74186L, false, false, (char) 60151, (char) 45662,
        Double.longBitsToDouble(0x3fb5bdb9a4ffeb28L), Double.longBitsToDouble(0x3f327d0000000000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null, null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null,null}}\0121=!org.apache.commons.math.linear.MatrixIndexException\012",
        Z.run(T, 2, 8, 11, 3, "\ud99f\ude12\udb35\udf08\udbc5\ude1c\ud914\udd76", "\uc015", "\uda66\udfbe\ud919\udd09\ud95e\udf22\ud936\udd7d\ud8dc\ude2d\ud8e0\udc34\udb21\udd0d\ud970\uddef\udb28\udedc\ud916\udc1a\udb47\udf8b\ud924\udf51\udaae\ude4f\udb43\ude0c\udbba\udd5a\udb06\udd9d\ud8c4\udcbb\udbe1\ude73\udab9\udf9d\ud9ad\udd41",
        26, 94088, -152691780, -187589507230202721L, -13191L, false, true, (char) 63065, (char) 24568,
        Double.longBitsToDouble(0x3fd6fef3393cfe60L), Double.longBitsToDouble(0x3fe2a0f95079103eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 2, 17, "\uda81\udc73\udbca\udf23\udae0\udc0f\ud914\ude06\udade\udfce\ud82f\udf93\udb78\ude9b\udb88\ude9b\u2940\uda66\udfbe", "\uc7c7\u3f9e\u2b38\u82b4\u239d\u93f7\ucece\u6861\ubaeb\u2e64\u308b\u7e23\u1847\u8c7f\u56a9\uc569\u78b8\u08da\ub1a3\u80f2\u1940\u4c45\u5c87\u2899\u294e\u281b\ud243\u5df4\u8a49", "\ud98a\uddb8\udb08\uddb1\ud87b\uddb3",
        26, 54895, -779852703, -7216548722059866221L, 64269L, false, true, (char) 64164, (char) 52387,
        Double.longBitsToDouble(0x3fca3d677389e658L), Double.longBitsToDouble(0x3f727958989e8880L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27831.5, 28401.0, 28034.5, 28524.0, 27629.5, 28322.0, 28039.0, 28541.5]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,27629.5,28322,28039,28541.5}}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\udb3e\udf2b\udade\udfce\ud82f\udf93\udb24\udd31\udb88\ude9b\u2940\ud9aa\udd3e", "\uc7c7\u6d8c", "\ud81c\ude93",
        42, 17973, 91247890, 2703365833586755344L, 55969L, true, false, (char) 15047, (char) 48896,
        Double.longBitsToDouble(0x3fe5591a1796cc36L), Double.longBitsToDouble(0x3fba761757c239f8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null, null, null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null,null,null}}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 2, 16, "\uae19\udb35\udf08\ud80b\udd74\ud914\udd76\udb35\udf9b\ud82f\udfc2\udb24\udd31\udb88\ude9b", "\u1fab\u4c41\uc7c7\u6d8c\u2b38\u82b4\u239d\u46a8\ub3c7\u2b84\u1e7c\u2e64\u5e78\u08ca\u5d77\ub5d8\u0800\u3045\u78b8\u08da\u8792\u0b24", "\ud8ea\udd13\udb88\udcb5\udbb7\uddfa\udbb0\udd1e\uda23\udd2f",
        27, 50942, 284631819, -6531406412654073335L, -46447L, false, false, (char) 63905, (char) 9935,
        Double.longBitsToDouble(0x3fda1c3847e79df4L), Double.longBitsToDouble(0x3fdd015d335a3d5eL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27845.0, 28296.0, 28077.5, 28458.5, 27987.5, 28584.0, 27753.0, 28451.0]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27845,28296,28077.5,28458.5,27987.5,28584,27753,28451}}\0121=void |a0=[[D:[[[27845.0, 28296.0, 28077.5, 28458.5, 27987.5, 28584.0, 27753.0, 28451.0]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27845,28296,28077.5,28458.5,27987.5,28584,27753,28451}}\012",
        Z.run(T, 2, 6, 6, 2, "\ud9ba\udd40\udb8b\ude85\udad7\udf80\ud902\ude76\udade\udfce\ud82f\udf93\udb24\udd31\udb88\ude9b", "\ub42e\u67ac\u7018\u6d8c\u2b38\u82b4", "\ud839\uddec\ued64\uda30\udf36\udaae\ude4f",
        59, 82940, -1640154238, -3767344749371792288L, -11062L, false, false, (char) 12855, (char) 45670,
        Double.longBitsToDouble(0x3fbf3db9a4fc2c48L), Double.longBitsToDouble(0x3fc6293e939f2774L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{}\0121=java.lang.Boolean:false |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{}\012",
        Z.run(T, 2, 10, 10, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\udb88\ude9b\u2940\uda66\udfbe\ud919\udd09\ud95e\udf22\ud936\udd7d\ud8dc\ude2d\uda24\udd57\udb21\udd0d\ud970\uddef\udb28\udedc\ud839\uddec\ued64\uda30\udf36", "\u08ca\u5d77\ub5d8", "\ud9ad\udd41\udb6a\udc9b\ud98f\udcc2\udab4\udf32\udad5\udc2e\udaba\udcfa\ud8ea\udd80\udb88\udcb5\udbb7\uddfa\udbb0\udd1e\uda23\udd2f\udb19\udc38\ud9e0\udf43\udbc9\udc67\uda02\udf21\ud98a\uddb8\udb08\uddb1",
        32, 28172, 1450112830, -4358248172435627609L, -11756L, false, true, (char) 52387, (char) 24589,
        Double.longBitsToDouble(0x3fe49ba1719bbd6cL), Double.longBitsToDouble(0x3fd3286537541144L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 3, 5, "\udb57\udf9a\ud8ad\udcde\ub609\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\ud822\uddff\u2940\uda66\udfbe", "\uc7c7\u7741\u7395\u82b4\u239d\u93f7\ub8c8\u2b84\u1e7c\uab64\u57f3\u6816\u2a06\ub5d8\ub440\u3f62\u1632\u6de7\u108a\ubac6\uc4e7\u4403\u5aa8\u51b7\u289b\u281b\u2f02\u5df4\u2a49", "\ud988\ude57",
        57, 84055, 40152298, -6693203099398761750L, -82579L, false, true, (char) 41051, (char) 63141,
        Double.longBitsToDouble(0x3fe337ead73d5885L), Double.longBitsToDouble(0x3fca3d677d6dd2b8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 15, 5, "\ud99f\ude19\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\udba2\udd2c\udb18\udcd0\uda11\udca9\u2940\udaef\udd19", "\uc875\u6d8c\u37fb\u82b4\u239d\u93f7\ub8c8", "\udaae\ude4f\ud98d\udfd1\uda78\udcea\uda9f\udff2\udab7\udc79",
        4, 27087, -663398506, 5133835743569046264L, -25287L, true, false, (char) 30278, (char) 33476,
        Double.longBitsToDouble(0x3fdfeb8de6dc6d2eL), Double.longBitsToDouble(0x3fe7e4256922141cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27831.5, 28401.0, 28034.5, 28524.0, 27629.5, 28322.0, 27700.0, 28149.5]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,27629.5,28322,27700,28149.5}}\0121=[[Ljava.math.BigDecimal;:[[[27831.5, 28401, 28034.5, 28524, 27629.5, 28322, 27700, 28149.5]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,27629.5,28322,27700,28149.5}}\012",
        Z.run(T, 2, 6, 9, 5, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud898\udc1b\udae1\udc28\ud82f\udf93\udb24\udd31\ud822\uddff\u2940\uda66\udfbe", "\uc7c7\u6d8c\u37fb\u82b4\u239d\u93f7\ub8c8\uca84\u1e7c\u2e64\u5e78\u08ca\u5d77\ub5d8\u1bba\uc549\u78b8\u08da\u4617\u80f2\uc4e7\u4403\u5c87\u2899\u294e\u281b\ud243\u5df4\u2a49", "\ud988\ude57",
        57, 1577, 192884302, 6228012909569358558L, 39479L, false, false, (char) 50109, (char) 11430,
        Double.longBitsToDouble(0x3fe337ead73d5885L), Double.longBitsToDouble(0x3fca3d677a4dd0b8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 3, 5, "\ud99f\ude12", "\u2bd4\u637b\u14b0\u2aba\u2b7a\u100d\u8fab\ub42e\u67ac\uc7c7\u6d8c\u37fb\u82b4\u239d\u93f7\ub8c8\u2b84\u1e7c\u2e64\u5e78\u08ca", "\udbe1\ude73\udab9\udf9d\ud9ad\udd41\udb67\udc32\ud98f\udcc2\udab4\udf32\uda1a\udd18\ud84e\udd23\ud8ea\udd80\udb88\udcb5\udbb7\uddfa\udbb0\udd1e\uda23\udd2f\udb19\udc38\ud9d3\ude7d\ud80f\udf49\udb02\ude40\ud988\ude57\udb08\uddb1\ud87b\uddb3\u46dc\udbef\udc17\ud9f8\udcd0\ud9a1\udec3\ud903\udd3c\udbb2\udf9e\ud87d\ude5a\ud81b\udf24\ud9ce\udf9d\udaab\ude03\udb10\udfa9\ud95f\ude8c\ud979\ude3e\ud903\udc72\uda65\udc4b\uda1a\ude2c",
        -4, 72432, 1672693796, -9073919510283647231L, 8867L, false, true, (char) 53014, (char) 61242,
        Double.longBitsToDouble(0x3fdb3a36546bc8feL), Double.longBitsToDouble(0x3fcd54409a6b9b88L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null, null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null,null}}\0121=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null,null}} |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null,null}}\012",
        Z.run(T, 2, 8, 5, 5, "\ud99f\udd94", "\u2bd4\u637b\u14b0\u2aba\u2b7a\u0c36\u988f\ub42e\u67ac\uc7c7\u6d8c\u9fc4\ubb1e\u869c\u93f7\ub8c8", "\udaae\ude4f\udb43\ude0c\udbba\udd5a\udb06\udd9d\ud8c4\udcbb",
        10, 46875, -663398506, 5133835743569046264L, -23023L, true, false, (char) 45788, (char) 63065,
        Double.longBitsToDouble(0x3fe16f4e556fef33L), Double.longBitsToDouble(0x3fc3ce6614107f20L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null}}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 17, 3, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\ud82b\udee4\uff04\uda7e\udf10", "\uc7c7\u6d8c\u37fb\u82b4\u6d9f\u08fe\u5e0d\u2b84\u1e7c\u2e64\u5e78\u08ca\ub69c\u12aa\uca9b\uc549\u78b8\u08da\u4617\u80f2\uc4e7\u4403\u5c87\u2899\u294e\u281b\ud243\u5df4\u2a49", "\ud988\ude57",
        57, 1577, 40126172, 5915187006978771198L, -82441L, false, true, (char) 41051, (char) 63141,
        Double.longBitsToDouble(0x3fe337ead73d5885L), Double.longBitsToDouble(0x3fca3d677a4dd0b8L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null}}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 5, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\uda7e\udc5d\udbd9\udf07\ud932\udd97\uda66\udfb6", "\uc7c7\u6d8c\u37fb\u82b4\u239d\ud27c\u916d\ubdad\ubd4e\uadf1\u5e78\u08ca\u5d77\ub5d8\u9e2a\uc549\u78b8\u7a55\ucc17\u80f2\u9b4d\u4403\u5c87\u2899\u294e\u281b\ud243\u5df4\u2a49", "\ud988\ude57",
        57, 1577, 996427484, 6228187179345273953L, -82579L, false, true, (char) 41051, (char) 63141,
        Double.longBitsToDouble(0x3fe337ead73d5885L), Double.longBitsToDouble(0x3fca3d676922ecb8L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27831.5, 28401.0, 28034.5, 28524.0, 27629.5, 28322.0, 27753.5, 28468.5]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,27629.5,28322,27753.5,28468.5}}\0121=!org.apache.commons.math.linear.MatrixIndexException\012",
        Z.run(T, 2, 6, 14, 16, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud903\ude99\udade\udfce\ud82f\udf93\udb24\udd31\ud822\uddff\ud970\udfc0\uda85\udcb5", "\uc7c7\uba95\u1018\u82b4\u239d\u93f7\ub8c8\u2b84\u1e7c\u2e64\u5e78\u08ca\u5d77\u88dc\u8914\uc946\u78b8\u08da\u1ecd\u80f2\uc4e7\u4403\u5c87\u2899\u294e\u281b\ud243\u5df4\u2a49", "\ud988\ude57",
        57, 1577, 40126172, 6228187179345273953L, -82579L, false, true, (char) 41051, (char) 63141,
        Double.longBitsToDouble(0x3fe337ead03d5885L), Double.longBitsToDouble(0x3fca3d677a4dd0b8L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null}}\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 7, 3, "\udbea\uddd7\udb35\udf08\ud80b\udd74", "\uc09d", "\udbfc\udd35\uda67\udc8c",
        21, 86515, -334606546, 6869524579262589692L, -17909L, true, false, (char) 42811, (char) 21117,
        Double.longBitsToDouble(0x3fe1bf9291005d03L), Double.longBitsToDouble(0x3f9fd901549b9b60L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 12, 9, "\udbea\uddd7\udb35\udf08\ud80b\udd74\uda4d\udfba\udade\udfc8\ud82f\udf93\udb24\udd2a\udb32\udf64\udb45\udc3d\uda67\udc1d", "\u7743\u398d\ucbaf\uae2a\uc311\u9c38\u2b78\u18d7\u4509\u2e64\u5e78\u08ca\u5d77\u8a96\ucb12\ud470\u78b8\u08da\u4617\u80f2\ucd19\uceec\u5c87\u2899\u294e\u281b\u4c55\ubdcf\u99e5", "\ud8fc\udc70",
        57, 1538, 40126172, 6229640733717193825L, 64096L, false, true, (char) 29633, (char) 53186,
        Double.longBitsToDouble(0x3fb448cef49f2e48L), Double.longBitsToDouble(0x3f842e390a0ba800L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null}}\0121=!org.apache.commons.math.linear.MatrixIndexException\012",
        Z.run(T, 2, 8, 12, 9, "\udbea\uddd7\udb35\udf08\ud80b\udd74\ud857\udf45\uda9e\udd6e\ud8f8\udf0e\udb24\uddc2\ud940\ude97\uda27\udc2c\uda67\udc1d", "\u978a\u6d32\u37fb\u8362\u6ef8\u8809\u2aa3\u18d7\u4509\u38a7\u5e78\u345a\u1027\ud717\u5454\u64c1\u784e\u08da\u4617\u97fe\u88b4\uceec\u6e56\u8fd9\ud4e4\u7467\u012f\u14af\u99e5", "\ud98a\uddb8",
        57, 1577, -1100724516, 8987031241039303315L, 64269L, false, true, (char) 29633, (char) 53186,
        Double.longBitsToDouble(0x3fca3d677a4f9724L), Double.longBitsToDouble(0x3fd8f171c7ec1fe0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null, null, null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null,null,null}}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\ud940\ude97\u2940\uda66\udfbe", "\ucb8c\u6d8c\u346b\u00a3\u1bb7\u93f7\u2997\uc1b5\u1e7c\u2e4f\u5e78\u08ca\u2251\uad09\u9e0c\uc549\u78b8\u8384\u39e8\u80f2\u1940\u4c45\u5c87\u0e3a\ub146\u8054\ud243\u5df4\u878f", "\ud9e2\udf8a\ud822\udcc3\udaaf\ude5e\ud81b\udefb\ud96a\udcd4\ud9e6\udd66",
        23, 71747, 917459408, -4899756850844132136L, -55831L, true, true, (char) 29745, (char) 15578,
        Double.longBitsToDouble(0x3fed6182ab9c23cbL), Double.longBitsToDouble(0x3fe7667f071579e0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null, null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null,null}}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 12, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\ud940\ude97\ud94f\udee1\ud820\ude33", "\u7f02\u3447\u42c2\u1913\u239d\u93f7\u2997\uc1b5\u1e7c\u2e64\u5e78\u08ca\u5d77", "\udab9\udf9d\ud9ad\udd41\udb6a\udc9b",
        38, 19220, -43676586, 5328889341628984497L, -64717L, true, true, (char) 49102, (char) 9106,
        Double.longBitsToDouble(0x3fc004a010d215c0L), Double.longBitsToDouble(0x3fe786ff39319d91L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null, null, null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null,null,null}}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 12, "\ud978\udc5f\udb35\udf08\udab2\udf89\ud914\ude4c\udaa3\udf68\ud9c6\udf0f\udbb5\udff3\ud940\uddf0\ud964\udeeb\uda24\udc0d\ud8b6\udd94\udb33\ude30", "\u6193", "\udb3a\udca4\udb6f\udf27\ud9c1\udc6a",
        39, 38436, -13590497, 2310737772449053559L, 89506L, true, false, (char) 24553, (char) 21862,
        Double.longBitsToDouble(0x3fe7c239fb7f96a2L), Double.longBitsToDouble(0x3fefe7e5c49ffd5eL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 15, 7, "\ud99f\ude12\udb35\udf08\uca04\ud914\ude16\ud978\udfdb\ud82f\udf93\udb24\udd31\u5f68\udb23\udcee\ud99e\udd66", "\u0485\u127d\u45e7\u908e\u5040\u93d7\u2997\uc264\u3198\u2e5d\ub143\u7f73\u4f48", "\ud89b\udcd3\ud9ad\udd92\udbf2\udfa3\ud98f\udcc2\ud8fe\udd15\udaea\uddf9\ud95e\udcec\ud8ff\udd69\udb88\udcb5\ud894\udf23",
        27, 49917, -368189530, 6386430234491693717L, -86740L, false, false, (char) 28098, (char) 64091,
        Double.longBitsToDouble(0x3fe9f012e8134aa4L), Double.longBitsToDouble(0x3fe7795393f3ceaeL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27819.5, 28292.0, 28034.5, 28526.0, 27731.5, 28229.5, 27705.0, 28390.0]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27819.5,28292,28034.5,28526,27731.5,28229.5,27705,28390}}\0121=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27819.5,28292,28034.5,28526,27731.5,28229.5,27705,28390}} |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27819.5,28292,28034.5,28526,27731.5,28229.5,27705,28390}}\012",
        Z.run(T, 2, 6, 5, 12, "\ud987\udd38\udb35\udf0c\ud8d7\udcbb\ud8a2\uddfc\ud9bd\udd39\ud82f\udc93\ud99e\udd8e\ud940\ude56\u2940\uda30\udc22\ud919\udc2f\ud95e\udf22\ud936\udd7d\ud8dc\ude2d\ud8e0\udccd\ud945\udd3f\ud970\ude0c\udb5e\uded7\udb6f\udf27\ud820\udf95\uda30\udf36\udaae\ude4f\udb43\ude0c\udbba\udd5a\udb06\udd9d\ud990\udd0b\uda9c\udd5f\udab9\udf41", "\u3a46\u7fdd", "\ud8ea\udd80\ud8b9\ude2a\ua55f\ud90f\udf71\ud8dd\udcaf\ud84c\udcb6\ud94d\udc8e\ud8be\uddb4",
        49, 73964, -882327568, 2846505230401816105L, 6137L, false, true, (char) 41051, (char) 8802,
        Double.longBitsToDouble(0x3feb2f953ed61011L), Double.longBitsToDouble(0x3fc1a156baa4d0b8L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{}\0121=java.lang.Boolean:false |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{}\012",
        Z.run(T, 2, 10, 10, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\ud940\ude97\ud9be\udf35\015", "\uc7c7\u6d8c\u37fb\u82b4\u239d\u93f7\u2997\uae71\u1e7c\u2e64\u5e78\u08ca\u5d77\uad09", "\ud997\ude41\udb6a\udc9b\ud98f\udcc2\udab4\udf32\udad5\udc2e\udaba\udcfa\ud8ea\udd80\u00e7\u73ef\udbb0\udd1e-\000\udb26\ude93\ud8be\uddc3\udbfc\udd46\udb2a\ude4f\uda3b\udef8",
        -5, -1000, 0, -822476800L, -100000L, false, false, (char) 53186, (char) 24589,
        Double.longBitsToDouble(0x3fe453a173c4e488L), Double.longBitsToDouble(0x3febbf1a50928063L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 11, 17, "\ud99f\ude12\udb35\udf08\ud8a8\udf03\ud914\uddaf\udade\udfce\ud82f\udf93\udb24\udd31\ud940\ude97\u2940\uda66\udfbe", "\uc7c7\u6d8c\u37fb\u82b4\u239d\u93f7\u2997\uc1b5\ud1c4\ub4a4\u5e78\u08ca\u5d77\uad09\u9e0c\uc549\u78b8\u08da\u4617\u80f2\u3ae1\u2dc0\u812e\u2899\u294e\u281b\ud243\u5df4\u878f", "\ud86e\udebf\uda78\uddfb\ub6be",
        42, 54830, -1014733727, -3532333218720924685L, 64269L, false, false, (char) 63278, (char) 53186,
        Double.longBitsToDouble(0x3fca3d677a29d0b8L), Double.longBitsToDouble(0x3fee272440fd0b9cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null, null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null,null}}\0121=void |a0=[[D:[[[27831.5, 28401.0, 27631.0, 28274.5]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,27631,28274.5}}\012",
        Z.run(T, 2, 8, 6, 16, "\ud99f\ude12\ud80e\udd15", "\u6c57\u2536", "\u2940\ud919\udc37",
        14, 96085, -1327266595, -1417098351533754639L, -90970L, false, false, (char) 53797, (char) 42430,
        Double.longBitsToDouble(0x3fcce0ae12727dd8L), Double.longBitsToDouble(0x3f9fd901549b9b60L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null}}\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 16, 17, "\ud99b\udcd0\ud8a2\udec3\uda08\udf7c\ud95b\udc1d\udb51\udcc7\ud8fc\udc53\udb24\udd31\ud940\ude97\u2940\uda66\udfbe", "\uc7c7\u0540\u295b\u6492\u0c2e\u93f7\ub8c8\u2b84\u1e7c\u2e64\u5e78\u08ca\u5768\u5114\u72b8\u30ae\uac51\u8ef1\u82d3", "\ud84f\udebc\udaae\udf05\udb87\udfe4\udbb7\uddfa\udbb0\udd1e\uda23\udd2f\udb19\udc38",
        25, 36124, -1520711559, -384870812486762082L, -81860L, false, true, (char) 29173, (char) 1831,
        Double.longBitsToDouble(0x3fef9e77d1cc36d3L), Double.longBitsToDouble(0x3fde21e2be99eeb4L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null], [null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null},{null}}\0121=void |a0=[[Ljava.math.BigDecimal;:[[[null], [null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null},{null}}\012",
        Z.run(T, 2, 8, 8, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udae1\udcaa\ud8fb\udf99;\ud915\udde9\u2940\uda66\udfbe", "\uc7c7\u3cf4\u0a69\u6492\u5c70\u93f7\ud7fc\u2b84\u1e7c\u449d\000\000\u50e3\u44d8\u9229\u7349\uac51\u8ef1\u4617\u1bbc\u1940\u2d3c\ucbc9\026\u9315\u6cbd\000\u5085\u2a49", "\ud98a\uddb8",
        57, 1577, 40126172, -3975105007996327648L, -82579L, false, true, (char) 175, (char) 42827,
        Double.longBitsToDouble(0x3fe337ead73d5885L), Double.longBitsToDouble(0x3fca3d677a69d0b8L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 17, "\ua9d4", "\u2bd4\u637b\uabee\u3e4c\uaa12\ucb5e\u0e0d\000\u42ab\uc7c7\u3098\u37fb\u82b4\u239d", "\ued64",
        39, 38436, -589586401, -1571700590534771838L, -27392L, true, false, (char) 9111, (char) 58590,
        Double.longBitsToDouble(0x3fd17993f028ac02L), Double.longBitsToDouble(0x3f4ec9e000000000L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 7, 6, 16, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93;\000\ud9d6\udc0a\000", "", "\ud8e0\udccd",
        50, 93442, 16460494, 5813251201733514514L, 89284L, true, false, (char) 3968, (char) 9651,
        Double.longBitsToDouble(0x3fca1bfce0000000L), Double.longBitsToDouble(0x3e4c000000000000L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27831.5, 28401.0, 28034.5, 28524.0, 27629.5, 28322.0, 27762.0, 28323.0]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,27629.5,28322,27762,28323}}\0121=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{28401}} |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,27629.5,28322,27762,28323}}\012",
        Z.run(T, 2, 6, 14, 15, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\ud82f\udc7f\ud940\ude8d\u2940\uda66\udfbe", "\uc7c7\ua8dd\u9d16\ua9e5\u239d\u93f7\ub8c8\u21bd\u34d9\u2e64\u5e78\u08ca\u5318\ub5d8\u3a3b\uc549\u78b8\u08da\u4617\u80f2\u1940\ua14e\u92c0\u9e12\u4806\u281b\ud243\u5df4\u2a49", "\ud98a\uddb8",
        1, 1637, 40126172, 6228187179345273953L, 43262L, false, true, (char) 41051, (char) 40614,
        Double.longBitsToDouble(0x3fe18894573d5885L), Double.longBitsToDouble(0x3fee8f59de937402L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27831.5, 28401.0, 28034.5, 28524.0, -24.0, -24.0, 27991.0, 28643.5]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,-24,-24,27991,28643.5}}\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 8, 16, "\ud99f\ude12\udb35\udf08\000\000\udade\udff7", "\u9b91\u100d\u1a7f\u3e2b\u67ac\u6198\u6d8c\u37fb\000\u5c25\u2ace\ub89d\u2b84\u1e7c\u2e64\u5e78\uaec9\u0082\u1619\u9229\uc549\u78b8", "\udab4\udf32\udad5\udc2e\udaba\udcfa\ud8ea\udd80\udb88\udcb5\udbb7\uddfa\udbb0\udd1e\uda23\udd2f\udb18\udfc9\ud9d3\ude7d\ud80f\udf49\uda02\udf21\ud9f6\ude05\u819e\ud83b\udc3c\ud82e\udc80",
        8, 21824, 36007, 1572806818952944080L, 68454L, false, true, (char) 53186, (char) 24589,
        Double.longBitsToDouble(0x3fe49ba1743fb23dL), Double.longBitsToDouble(0x3fd3778f04aca3eeL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27831.5, 28401.0]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401}}\0121=[Ljava.math.BigDecimal;:[[1581209193.25]] |a0=[D:[[27831.5, 28401.0]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401}}\012",
        Z.run(T, 2, 6, 16, 17, "\ud99f\ude12", "\ub312\u5485\u14b0\u2aba\u9b91\u100d\u3386\u3e2b\u674c\u3802\u6d8c\u37fb\u7e8e\u2424\u93f7\u8700\ubb9e\u7728\u2e64\u5e78\u08ca\u5d77\u3618\u9e2a\uc549\u78b8\u08da\u4617\u80f2\ud7ce\u4d84\u5c87\u2899\u294e\u281b\ud243\u5df4\u2a49\ua194\u6506\u5c0b\u9a8a\uc021\u0332\u05d8\u9cb1\u7955\u8556\u2cae\ube65\u6dcf\ubece\uae9f\uce83\uc269\u8b95", "\uda7a\udc5c\ud855\udedd\ud8da\ude1b\uda01\udcda\ud82c\uddf8\ud949\udde7\ud986\udc54",
        16, 77020, -170566120, 1687047205896415757L, -18807L, false, false, (char) 55796, (char) 26844,
        Double.longBitsToDouble(0x3fec8792a731a8e7L), Double.longBitsToDouble(0x3fdce817f3f3ece0L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[-24.0, -24.0, -24.0, 27736.5, 28175.5, 27991.0, 28643.5]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{-24,-24,-24,27736.5,28175.5,27991,28643.5}}\0121=[Ljava.math.BigDecimal;:[[3167120133.75]] |a0=[D:[[-24.0, -24.0, -24.0, 27736.5, 28175.5, 27991.0, 28643.5]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{-24,-24,-24,27736.5,28175.5,27991,28643.5}}\012",
        Z.run(T, 2, 6, 16, 1, "\000\000\000\ud8e1\udc4f\udade\udff7", "\u9b91\u0fb7\000\u3e2b\u67ac\uc7c7\u6d8c\u37fb\u7e8e\u2424\u93f7\ub8c8\u2b84\u1e7c\u2e64\u5e78\u08ca\u3b82\000\000\uc549\u21b8", "\udab4\udf32\udad5\udc2e\udaba\udcfa\ud8ea\udd80\udb88\udcb5\udbb7\uddfa\udbb0\udd1e\uda23\udd2f\udb19\udc38\ud9d3\udddf\ud80f\udf49\ud97e\udc7e\000\uda4a\udfd4\ud867\udf32\ud82e\udc80",
        5, 12273, 7703719, 0L, -100000L, false, true, (char) 53186, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd3778f04aca3eeL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27831.5, 28401.0, 28034.5, 28524.0, 27629.5, 28322.0, 27762.0, 28323.0]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,27629.5,28322,27762,28323}}\0121=[D:[[28322.0]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,27629.5,28322,27762,28323}}\012",
        Z.run(T, 2, 6, 12, 5, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udff7", "\u9b91\u100d\u5c65\ubce7\u2405\uc7c7\u6d8c\u37fb\u7e8e\u2424\u93f7\ub8c8\u2b84\u1e7c\u2e64\u5e78\u08ca\u5e7c\u160f\u9e2a\uc549\u78b8", "\udab4\udf32\udad5\udc2e\udaba\udcfa\ud8ea\udd80\udb88\udcb5\udbb7\uddfa\udbb0\udd1e\uda23\udd2f\udb19\udc38\ud9d3\ude7d\ud80f\udf49\ud8b8\uddbb\ud981\udc96\uda3f\udf6a\ud867\udf32\ud82e\udc80",
        5, 12273, 1886751911, 1534165616253704656L, 68454L, false, true, (char) 53186, (char) 24589,
        Double.longBitsToDouble(0x3fe2f3a1743fb23dL), Double.longBitsToDouble(0x3fd3778f04aca3eeL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null], [null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null},{null}}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 5, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76b\ud82f\udf74;\000\ud932\udd97\uda66\udfb6", "\uc7c7\u6d8c\u37fb\u9751\000\000\u06d1\ubdad\ubd4e\uadf1\u5e78\u08ca\u5d77\ub5d8\u9e2a\u52ab\000\u7a55\ucc17\u80f2\u9b4d\u4403\u5c87\u2899\u294e\u281b\ud243\u5df4\u2a49", "\ud988\ude57",
        57, 1577, 996427484, 6228187179345273953L, -82579L, false, true, (char) 8028, (char) 0,
        Double.longBitsToDouble(0x3e4c000000000000L), Double.longBitsToDouble(0x3fca3d676002ecb8L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[-24.0]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{-24}}\0121=!org.apache.commons.math.linear.MatrixIndexException\012",
        Z.run(T, 2, 6, 14, 16, "\000", "", "\ud82f\udf93\udb24\udd31\u85ff\ud970\udfc0\uda85\udcb5\ud919\udd0e",
        -5, 11583, 143, 1633392384L, -78222L, true, false, (char) 118, (char) 31008,
        Double.longBitsToDouble(0x3fe526e6db82ea30L), Double.longBitsToDouble(0x3fdd0dfe71711fa6L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 8, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udae1\udcaa\ud8fb\udf99;\ud915\udde9\u2940\uda66\udfbe\ud919\udd09\ud8d3\udc3d\ud936\udd7d\u9c94\udab0\udf58\uda44\udce8\ud846\udeee\udb28\udedc\udbe3\udde1\ued64\uda30\udf36", "\000", "\udb82\udd81\udabd\udf64\ud9c1\udcd6\udb8b\udeb2\ud98f\udcc2\u1bbc\udad5\udc2e\udb8e\udd46\udbca\ude90\026\udb9a\ude0b\ud95a\udecd=\udb15\udec9",
        25, 36124, -1520711559, -384870812486762082L, -81860L, false, true, (char) 29173, (char) 1831,
        Double.longBitsToDouble(0x3fef9e77d1d000d3L), Double.longBitsToDouble(0x3ec5fd3000000000L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null, null], [null, null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null,null},{null,null}}\0121=void |a0=[[Ljava.math.BigDecimal;:[[[null, null], [null, null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null,null},{null,null}}\012",
        Z.run(T, 2, 8, 8, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\ud867\udedd\ud8fb\udf8d;\uda32\udf39\u2913\uda66\udfbe\ud919\udd09", "\u2d7a\u0a69", "\udb28\udedc\udbe3\udde1\ud8f8\udda2\udb70\udc5c\ud8ad\udfa3\000\000",
        30, 1734, 591528032, -7653833973985461819L, 91224L, false, true, (char) 35925, (char) 358,
        Double.longBitsToDouble(0x3fee768e5f9872bcL), Double.longBitsToDouble(0x3feac192400000ebL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.math.BigDecimal;:[[[null], [null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null},{null}}\0121=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null},{null}} |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null},{null}}\012",
        Z.run(T, 2, 8, 5, 10, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udae1\udcaa\ud8fb\udf99;\ud915\udde9\u2940\uda66\udfbe", "\uc7c7\u9623\u603c\u6492\u5c70\u93f7\ud7fc\u2b84\u1e7c\u449d\000\u845d\u51aa\u44d8\u9229\u7349\uac51\u8ef1\u4b3f\u1bbc\u1940\u32c6\ucb8d\026\u9315\u6cbd\000\u5085\u2a49", "\ud98a\uddb8",
        57, 1577, 40126097, -3975105007996327648L, -82579L, false, true, (char) 175, (char) 42827,
        Double.longBitsToDouble(0x3fe337ead73d5885L), Double.longBitsToDouble(0x3fca3d677a69d0b8L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27831.5, 28401.0]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401}}\0121=!org.apache.commons.math.linear.MatrixIndexException\012",
        Z.run(T, 2, 6, 8, 14, "\ud99f\ude12", "\000\u63a4\u14b0\u2aba\u9b91\u161b\u55cb\u3e2b\u67ac\u5901\u6dd0\u37fb\u0d20\u9f5c\u2ace\ub89d\u2b84\ud4b5\u0fc1\u5ca7\uaec9", "\udba8\ude73\udaf5\udc1a\ud9ad\udd41\udb6a\udc9b\ud817\udfaf\udab4\udf32\udad5\udc2e\udaba\udcfa\ud8ea\udd80\udb88\udcb5\ud854\udc15\udb7e\udcad\uda17\udcec\udb19\udcbb\ud93e\ude44\ud8a0\udeb1\ud931\udff8\udbc0\udc8b",
        31, 63256, 40144988, 6228186913048625152L, 64096L, false, false, (char) 20374, (char) 53186,
        Double.longBitsToDouble(0x3fca3d677a4dd0b8L), Double.longBitsToDouble(0x3fafd91ed3778f00L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{}\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 8, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udae1\udcaa\ud8fb\udf99;\ud915\udde9\u2940\uda66\udfbe\ud919\udd09\ud8d3\udc3d\ud936\udd7d\u9c94\udab0\udf58\uda44\udce8\ud846\udeee\udb28\udedc\udbe3\udde1\ued64\uda30\udf36", "\000", "\udb82\udd81\udabd\udf64\ud9c1\udcd6\udb8b\udeb2\ud98f\udcc2\u1bbc\udad5\udc2e\udb8e\udd46\udbca\ude90\026\udb9a\ude0b\ud95a\udecd=\udb15\udec9",
        25, 36124, -1520711559, -384870812486762082L, -81860L, false, true, (char) 29173, (char) 1831,
        Double.longBitsToDouble(0x3fef9e77d1d000d3L), Double.longBitsToDouble(0x3ec5fd3000000000L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27831.5, 28401.0, 28034.5, 28524.0, 27629.5, 28322.0, 27762.0, 28323.0], [27762.5, 28380.5, 27762.0, 28169.5, 28124.0, 28471.5, 27769.5, 28251.5]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,27629.5,28322,27762,28323},{27762.5,28380.5,27762,28169.5,28124,28471.5,27769.5,28251.5}}\0121=void |a0=[[Ljava.math.BigDecimal;:[[[null, null, null], [null, null, null]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{null,null,null,28524,27629.5,28322,27762,28323},{null,null,null,28169.5,28124,28471.5,27769.5,28251.5}}\012",
        Z.run(T, 2, 6, 8, 15, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udae1\udcaa\ud8fb\udf99;\ud915\udde9\ud914\udc43\udbe8\ude9f\ud923\udce7\ud8d3\udc3d\ud936\udd7d\u9c94\udab0\udf58\ud85e\udc34\uee29\udb28\udedc\udbe3\udde1\ued64\uda30\udf36", "\026", "\udb82\udd81\udabd\udf64\ud9c1\udcd6\udb8b\udeb2\ud98f\udcc2\ud933\udf32\udae9\udd94\udb8e\udd46\udbca\ude90\026\udb9a\ude0b\ud95a\udecd=\udb15\udec9",
        31, 42035, -1520711559, -384870812486762082L, -81860L, false, true, (char) 29173, (char) 1831,
        Double.longBitsToDouble(0x3fef9e77d1d000d3L), Double.longBitsToDouble(0x3ec5fd3000000000L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27831.5, 28401.0, 27824.5, 28233.0, 27763.0, 28472.0, 27762.0, 28323.0], [27762.5, 28380.5, 5256.0, 23039.0, 27639.5, 28637.5, 27729.5, 28166.5]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,27824.5,28233,27763,28472,27762,28323},{27762.5,28380.5,5256,23039,27639.5,28637.5,27729.5,28166.5}}\0121=[Ljava.math.BigDecimal;:[[6306874208.50, 5525720755.25]] |a0=[D:[[27831.5, 28401.0, 27824.5, 28233.0, 27763.0, 28472.0, 27762.0, 28323.0]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,27824.5,28233,27763,28472,27762,28323},{27762.5,28380.5,5256,23039,27639.5,28637.5,27729.5,28166.5}}\012",
        Z.run(T, 2, 6, 0, 17, "\ud99f\ude12\ud991\udcc2\ud916\udea0\ud914\udd76\udae1\udcaa\ud8fb\udf99;\ud915\udde9\u2940\ub42e\ud81f\udfeb\ud8d3\udc3d\ud936\udd7d\u9c94\udab0\udf58\uda44\udce8\ud846\udeee\udb28\udedc\ubfc9\udbba\udd72\uda30\udf16", "\000", "\udb82\udd81\udabd\udf64\ud9c1\udcd6\udb8b\udeb2\ud98f\udcc2\u1bbc\udad5\udc2e\ud81f\udeaf\udbca\ude8c\026\udb9a\ude0b\ud95a\udecd=\udb15\udec9",
        25, 36124, 1603455097, -8296296147626000018L, -81860L, false, true, (char) 29173, (char) 1831,
        Double.longBitsToDouble(0x3fef9e77d1d000d3L), Double.longBitsToDouble(0x3ec5fd3000000000L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27831.5, 28401.0, 28034.5, 28524.0, 27629.5, 28322.0, 27762.0, 28323.0], [27762.5, 28380.5, 27762.0, 28169.5, 28124.0, 28471.5, 27769.5, 28251.5]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,27629.5,28322,27762,28323},{27762.5,28380.5,27762,28169.5,28124,28471.5,27769.5,28251.5}}\0121=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,27629.5,28322,27762,28323},{27762.5,28380.5,27762,28169.5,28124,28471.5,27769.5,28251.5}} |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,27629.5,28322,27762,28323},{27762.5,28380.5,27762,28169.5,28124,28471.5,27769.5,28251.5}}\012",
        Z.run(T, 2, 6, 5, 15, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udae1\udcaa\ud8fb\udf99;\ud915\udde9\ud914\udc43\udbe8\ude9f\ud923\udce7\ud8d3\udc3d\ud936\udd7d\u9c94\udab0\udf58\ud85e\udc34\uee29\udb28\udedc\udbe3\udde1\ued64\uda30\udf36", "\026", "\udb82\udd81\udabd\udf64\ud9c1\udcd6\udb8b\udeb2\ud98f\udcc2\ud933\udf32\udae9\udd94\udb8e\udd46\udbca\ude90\026\udb9a\ude0b\ud95a\udecd=\udb15\udec9",
        31, 42035, -1520711559, -384870812486762082L, -81860L, false, false, (char) 19266, (char) 1831,
        Double.longBitsToDouble(0x3fef9e77d1d000d3L), Double.longBitsToDouble(0x3ec5fd3000000000L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 17, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udade\udfce\ud82f\udf93\udb24\udd31\ud940\ude97\u2940\uda66\udfbe", "\uc7c7\u6d8c\u37fb\u82b4\u239d\u93f7\ub8c8\u2b84\u1e7c\u2e64\u5e78\u08ca\u5d77\ub5d8\u9e2a\uc549\u78b8\u08da\u723e\u80f2\u1940\u4c45\u5c87\u2899\u294e\u281b\ud243\u5df4\u2a49", "\ud98a\uddb8",
        57, 1577, 40126172, 6228187179345273953L, -82579L, false, true, (char) 41051, (char) 40614,
        Double.longBitsToDouble(0x3fe337ead73d5885L), Double.longBitsToDouble(0x3fca3d677a4dd0b8L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27831.5, 28401.0, 28034.5, 28524.0, 27629.5, 28322.0, 27762.0, 28323.0], [27762.5, 28380.5, 27762.0, 28169.5, 28124.0, 28471.5, 27769.5, 28251.5]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,27629.5,28322,27762,28323},{27762.5,28380.5,27762,28169.5,28124,28471.5,27769.5,28251.5}}\0121=void |a0=[[D:[[[27831.5, 28401.0, 28034.5, 28524.0, 27629.5, 28322.0, 27762.0, 28323.0], [27762.5, 28380.5, 27762.0, 28169.5, 28124.0, 28471.5, 27769.5, 28251.5]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,27629.5,28322,27762,28323},{27762.5,28380.5,27762,28169.5,28124,28471.5,27769.5,28251.5}}\012",
        Z.run(T, 2, 6, 6, 15, "\ud99f\ude12\udb35\udf08\ud80b\udd74\ud914\udd76\udae1\udcaa\ud8fb\udf99;\ud915\udde9\ud914\udc43\udbe8\ude9f\ud923\udce7\ud8d3\udc3d\ud936\udd7d\u9c94\udab0\udf58\ud85e\udc34\uee29\udb28\udedc\udbe3\udde1\ued64\uda30\udf36", "\026", "\udb82\udd81\udabd\udf64\ud9c1\udcd6\udb8b\udeb2\ud98f\udcc2\ud933\udf32\udae9\udd94\udb8e\udd46\udbca\ude90\026\udb9a\ude0b\ud95a\udf7d=\udb15\udec9",
        31, 42035, -1520711559, -384870812486762082L, -81860L, false, true, (char) 29173, (char) 1831,
        Double.longBitsToDouble(0x3fef9e77d1d000d3L), Double.longBitsToDouble(0x3ec5fd3000000000L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27831.5, 28401.0, 28034.5, 28524.0, 28012.0, 28481.0, 28029.0, 28303.5]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,28012,28481,28029,28303.5}}\0121=[Ljava.math.BigDecimal;:[[28481]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27831.5,28401,28034.5,28524,28012,28481,28029,28303.5}}\012",
        Z.run(T, 2, 6, 11, 5, "\ud99f\ude12\udb35\udf08\udb08\udeb2\udb2a\udd4f\udadf\udc46\ud82f\udf93\uda2b\udf3b\ud977\udd34\u2940\ud9de\udefa", "\uc7c7\u6d8c\u37fb\u055f\u47d0\u7e6c\u6665\u2b84\u2d99\uaa57\u1040\u9792\u5d77\u167e\u9e2a\uc549\u78b8\u08da\u4617\u8117\ubfd5\ub6b8\u5c87\u3a99\ub81b\u1296\u4021\u5c09\u74b5", "\ud98a\uddb8\ud850\ude76\ud975\udfaa\ud9d8\udf5e",
        5, 12273, -822425433, 1572807347748694224L, -11756L, false, false, (char) 451, (char) 24589,
        Double.longBitsToDouble(0x3fe057717651acb3L), Double.longBitsToDouble(0x3fee84c1de56df0eL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[21714.0]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{21714}}\0121=void |a0=[[Ljava.lang.String;:[[[\ua9d4]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{4}}\012",
        Z.run(T, 2, 6, 7, 17, "\ua9d4", "\u2bd4\u02a3\uce7f\uab2b\u0df4\u46df\u0e0d\000\u42ab\uc7c7\u3098\u75ca\u63bf\u239d", "\uedeb",
        39, 4620, -589586401, -1571700590534771838L, -27392L, true, false, (char) 35478, (char) 587,
        Double.longBitsToDouble(0x3fd1799f2028ac02L), Double.longBitsToDouble(0x3f4ec9e000000000L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=void |a0=[[Ljava.lang.String;:[[[\ua9d4]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{4}}\0121=void |a0=[[Ljava.lang.String;:[[[\ua9d4]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{4}}\012",
        Z.run(T, 2, 7, 7, 17, "\ua9d4", "\u2bd4\u02a3\uce7f\uab2b\u0df4\ua304\u86b4\u1344\u6d55\uc7c7\u3098\u75ca\u63bf\u239d", "\uedeb",
        39, 4620, -589586401, -1571700590534771838L, -27392L, true, false, (char) 35478, (char) 587,
        Double.longBitsToDouble(0x3fe454cf9014d24fL), Double.longBitsToDouble(0x3f4ec9e000000000L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27903.0, 28401.5, 28027.5, 28557.5, 27629.5, 28322.0, 27762.0, 28323.0], [27762.5, 28380.5, 5256.0, 27931.0, 28615.0, 27764.5, 28268.5, 27729.5]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27903,28401.5,28027.5,28557.5,27629.5,28322,27762,28323},{27762.5,28380.5,5256,27931,28615,27764.5,28268.5,27729.5}}\0121=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{28322},{27764.5}} |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27903,28401.5,28027.5,28557.5,27629.5,28322,27762,28323},{27762.5,28380.5,5256,27931,28615,27764.5,28268.5,27729.5}}\012",
        Z.run(T, 2, 6, 14, 17, "\uda2e\ude13\udb27\udf4b\ud80b\udd74\ud914\udd76\udae1\udcaa\ud8fb\udf99;\ud915\udde9\u2940\uda66\udfbe\ud919\udd09\ud8d3\udc3d\ud936\udd7d\u9c94\udab0\udf58\uda44\udce8\udadf\udf79\udb28\udedc\udbe3\udde1", "\u3c1d\u75b5\ucd2b\u9a0c\u3755", "\ud9c1\udcd6\udb8b\udeb2\ud98f\udcc2\u1bbc\udad5\udc2e\udb8e\udd46\udbca\ude90\026\udb9a\ude0b\ud95a\udecd\ud864\udd15\udb83\udd01\udba5\udf62\ud80f\udf49\uda02\udf21\ud98a\uddb8\udb08\uddb1\ud87b\uddb3\ud81b\udf00\udae4\udfcd",
        5, 6583, 13876211, 49348074719412224L, 4603L, true, false, (char) 951, (char) 25165,
        Double.longBitsToDouble(0x3fe439b304a4d828L), Double.longBitsToDouble(0x3fe7df3d38265ba5L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27826.5, 28520.5, 27824.5, 28233.0, 27763.0, 28472.0, 27925.5, 28197.0], [27762.5, 28380.5, 5256.0, 23039.0, 27639.5, 28637.5, 27729.5, 28166.5]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27826.5,28520.5,27824.5,28233,27763,28472,27925.5,28197},{27762.5,28380.5,5256,23039,27639.5,28637.5,27729.5,28166.5}}\0121=[D:[[28197.0, 28166.5]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27826.5,28520.5,27824.5,28233,27763,28472,27925.5,28197},{27762.5,28380.5,5256,23039,27639.5,28637.5,27729.5,28166.5}}\012",
        Z.run(T, 2, 6, 12, 17, "\ud995\udf01\ud991\udcc2\ud916\udea0\uda5b\udc7a\ud8ce\ude62\uda63\udce0;\ud915\udde9\u2940\ub42e\ud81f\udfeb\ud8d3\udc3d\ud936\udd7d\u9c94\udab0\udf58\uda44\udce8\ud846\udeee\udb93\udfb1\uda17\uded8\udbba\udd78\uda30\udf16", "\000", "\udb82\udd81\udabd\udf64\ud9c1\udcd6\udb8b\udeb2\ud98f\udcc2\u1bbc\udad5\udc2e\ud81f\udeaf\udbca\ude8c\026\udb9a\ude0b\ud95a\udecd=\udac6\udf33",
        7, 78067, 1603455097, -8296296147626000018L, -81860L, false, true, (char) 29173, (char) 1831,
        Double.longBitsToDouble(0x3fef9e77d1d000d3L), Double.longBitsToDouble(0x3ec5fd3000000000L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=void |a0=[[D:[[[27903.0, 28401.5, 28027.5, 28557.5, 27629.5, 28322.0, 27762.0, 28323.0], [27762.5, 28380.5, 5256.0, 27931.0, 28615.0, 28100.5, 28547.5, 27729.5]]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27903,28401.5,28027.5,28557.5,27629.5,28322,27762,28323},{27762.5,28380.5,5256,27931,28615,28100.5,28547.5,27729.5}}\0121=[Ljava.math.BigDecimal;:[[28322, 28100.5]] |this=org.apache.commons.math.linear.BigMatrixImpl:BigMatrixImpl{{27903,28401.5,28027.5,28557.5,27629.5,28322,27762,28323},{27762.5,28380.5,5256,27931,28615,28100.5,28547.5,27729.5}}\012",
        Z.run(T, 2, 6, 11, 14, "\uda2e\ude13\udb27\udf4b\ud80b\udd74\ud914\udd76\udae1\udcaa\udb40\udfce;\ud915\udde9\u2940\uda66\udfbe\udbb9\udf37\ud8d3\udc3d\ud936\udd7d\u9c94\udab0\udf58\uda44\udce8\udadf\udf79\udb28\udedc\udbe3\udde1", "\u3c1d\u75b5\ucd2b\u854e\u0291", "\ud9c1\udcd6\udb8b\udeb2\ud98f\udcc2\u1bbc\udad5\udc2e\udb8e\udd46\udbca\ude90\026\udb9a\ude0b\ud95a\udecd\ud864\udd15\udb83\udd01\udba5\udf62\ud80f\udf49\uda02\udf21\ud98a\uddb8\udb08\uddb1\ud870\uddab\ud81b\udf00\udae4\udfcd",
        5, 6583, 13876211, 49348074719412224L, 4603L, true, false, (char) 27574, (char) 5063,
        Double.longBitsToDouble(0x3fe439b304a4f980L), Double.longBitsToDouble(0x3fe7df3d3a4b5ba5L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.linear.BigMatrixImpl|operate|[D|new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.BigMatrixImpl|operate|[Ljava.math.BigDecimal;|new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.RealMatrixImpl|operate|[D|new:org.apache.commons.math.linear.RealMatrixImpl:",
    "M|org.apache.commons.math.linear.BigMatrixImpl|add|org.apache.commons.math.linear.BigMatrix|new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.BigMatrixImpl|add|org.apache.commons.math.linear.BigMatrixImpl|new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.BigMatrixImpl|copy||new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.BigMatrixImpl|copyIn|[[D|new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.BigMatrixImpl|copyIn|[[Ljava.lang.String;|new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.BigMatrixImpl|copyIn|[[Ljava.math.BigDecimal;|new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.BigMatrixImpl|copyOut||new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.BigMatrixImpl|equals|java.lang.Object|new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.BigMatrixImpl|getColumn|int|new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.BigMatrixImpl|getColumnAsDoubleArray|int|new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.BigMatrixImpl|getColumnDimension||new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.BigMatrixImpl|getColumnMatrix|int|new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.BigMatrixImpl|getData||new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.BigMatrixImpl|operate|[D|new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.BigMatrixImpl|operate|[Ljava.math.BigDecimal;|new:org.apache.commons.math.linear.BigMatrixImpl:",
    "M|org.apache.commons.math.linear.RealMatrixImpl|operate|[D|new:org.apache.commons.math.linear.RealMatrixImpl:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
