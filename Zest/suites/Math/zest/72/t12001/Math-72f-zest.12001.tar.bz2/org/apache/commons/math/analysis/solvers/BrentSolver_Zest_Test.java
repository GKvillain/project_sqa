package org.apache.commons.math.analysis.solvers;
import org.junit.Test;
import static org.junit.Assert.*;
public class BrentSolver_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 5, 3, 0, "\udb0d\uded0\ud9ba\udd3b\uda5f\uded6\udae4\udc58\udbcf\uddd1\ud900\ude1b\ud868\udef8\ud8ba\udf2f\ud881\udd7d\udb15\uddc2\ud809\udf09\ud8d3\uded1", "\u2ae1", "\ud923\udfbd\udbfb\udfd8\ud9b7\udfc9\ud89a\udf49\ud828\udc1e\ud970\udda6",
        18, 53428, 263137621, 975324745707817181L, 85677L, true, false, (char) 30144, (char) 16927,
        Double.longBitsToDouble(0x3fe37427acab47d0L), Double.longBitsToDouble(0x3fe8d0ff54c8988aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 5, 3, 7, "\udb0d\uded0\ud9ba\udd3b\uda5f\uded6\udae4\udc58\udbcf\uddd1\ud900\ude1b\ud868\udef8", "\u7d8b\000\ub688\ud543\u9ce4", "\ud83f\udecf\uabe1\udbfb\udfba\ud9b7\udfc9\ud89a\udf49",
        50, 57302, 1301729478, 3705248649931860309L, -97731L, false, true, (char) 33139, (char) 9517,
        Double.longBitsToDouble(0x3fe27a936c6e76d7L), Double.longBitsToDouble(0x3fd4d12094e7fd3cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 9, 3, 7, "\udb0d\uded0\udb93\udc33\udaad\udfbc\ud895\udd92\udbcf\uddd1\udafc\udc49\ud91a\ude99\ud80f\udee5\ud9a7\udce4\udbd1\udde0\ud96f\udcdd\u6cb4", "\u4c90", "\ud923\udfbd\udbfb\udfd8\ud9b7\udfc9\ud878\ude49\ud828\udc1e\ud9bc\udcc5\ud80d\udf92\udafc\udfba\uda64\ude41\ud87d\udf4d\udab3\udeb5\ud8c8\udfab\udb34\udd5f\ud9e9\udfef\udb8b\udf1f\ud8e1\ude11\uda13\udd6f\ud822\udc7c\uda5f\udcd9\udaf8\ude13\ud99f\udea9\ud9df\ude8c\ud872\udd01\udaf4\udfca\ud8c5\udcd3\ud9f1\udf0f",
        13, 33950, 1148355054, 2743907121146244353L, -16665L, false, false, (char) 37267, (char) 58778,
        Double.longBitsToDouble(0x3fee2a912a781b90L), Double.longBitsToDouble(0x3fe0a2fb8ccc33f8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 1, 8, 10, "\udb0d\uded0\ud94c\udd24\uda70\udf10\uc163\udb92\udcf4\udacb\udeed\uf34a\ud97c\udefe\ud881\udd7d", "\u0431\ud543\u1832\ua639\ubb69\u4bf9\u0676\u895c\u478d\ud4eb\u1c1f\u3a8e\u65cb\u29ca\u9c52\uacba\ua058\u333d\u4d79\u2a35\uccdf\ud6eb\u72b3\u9cb7\ud7b5\u488f\u54cf\u068a", "\udacd\udc28\ud8cd\ude00",
        41, 19593, 13078771, 5295050200744110352L, -35808L, false, true, (char) 63025, (char) 33340,
        Double.longBitsToDouble(0x3fdf0621427fdc84L), Double.longBitsToDouble(0x3fd0a8bc589d2ae8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Double:0.34375001008891204 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 1, 0, 7, 0, "\u62b7\ud9ba\udd3b\uda5f\uded6\000\udbcf\udda2\ud900\ude1b\u008c\ud8ba\ude33\ud881\udd7d\udba1\udca7\000\ud8d3\uded1", "\u3213", "\ud923\udedc",
        39, -1000, 977725184, 2956962469353881854L, -100000L, false, false, (char) 7263, (char) 3686,
        Double.longBitsToDouble(0x3fd600000ad53812L), Double.longBitsToDouble(0x3fe50690024f526dL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 0, "\udb0d\uded0\ud9ba\udd3b\uda5f\uded6\udae4\udc58\udbcf\uddd1\ud900\ude1b\ud868\udef8\ud8e4\ude28\ud881\uddfc\udb15\uddc2\ud809\udf09\ud8b4\udf6d", "\u2b1b", "\ud923\udfbd\udbfb\udfd8\ud9b7\udfc9\ud89a\udf49\ud828\udc1e\ud970\udda6",
        54, 14763, 259383587, 975324745707817181L, 85677L, true, false, (char) 47040, (char) 55708,
        Double.longBitsToDouble(0x3fe37427aa5cd9c4L), Double.longBitsToDouble(0x3fe9e3d314c8986cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 3, 7, 2, "\udb0d\uded5\udb62\udeb0\ud9df\udec9\ud9d5\udcce\udbf2\udc7b\ud900\ude1b\ud868\udef8\ud8ba\udf2f\ud881\udd7d\udb15\uddc2\ud809\udf09", "\u9ce4", "\ud83f\udecf\ud923\udfbd\udbfb\udfd8\ud8d1\udef6\udb29\udf89",
        -5, 57140, 1301729478, 3705248649931860309L, 15048L, false, true, (char) 33139, (char) 9517,
        Double.longBitsToDouble(0x3fe27a936c6e76d7L), Double.longBitsToDouble(0x3fd4d12094e7fd3cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 1, 6, 3, 0, "\udb0d\uded0\ud8a4\udd30\uda8d\udcd8\ud952\udd36\udbcf\uddd1\ud900\ude1b\udaf8\udcfe\ud8e4\udde2\ud881\udd7d\udb15\uddc2\ud809\udf09\ud955\udf11", "\u2ae1", "\udb1e\udcb8\udbfb\udfd8\ud9b7\udfc9\ud9ec\udf52\ud828\udc1e\ud970\udda6",
        2, 53605, 263137621, 975324745707817181L, 85677L, true, false, (char) 30144, (char) 16927,
        Double.longBitsToDouble(0x3fe37427acab47d0L), Double.longBitsToDouble(0x3fe8d0ff54c8988aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:0.6079290745203654 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 1, 0, 0, 0, "\u00b7\udb26\udff2\u00d0\udae4\udc58\udbcf\uddd1[\000\000\000\000\000\ud894\udd2a", "\000", "\ud923\udfbd\udbfb\udfd8\ud9b7\udfc9\ud89a\udf49\ud828\udc1e\ud970\udda6",
        18, 53428, 0, 1342177280L, -45395L, true, false, (char) 30144, (char) 16927,
        Double.longBitsToDouble(0x3fe37427acab47d0L), Double.longBitsToDouble(0x3fe8d0ff54c8988aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Double:0.643419916071987 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=java.lang.Double:0.643419916071987 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 2, 7, 7, 0, "\ud9df\udddb\ud9ba\udd3b\ud9b4\udd6c\udbc3\udfaf\u814f\ud900\uddcb\ud868\udef8\udab4\udfab\ud962\udff7\udb15\uddc2\udad1\udced\udba4\udfb8", "\u2ae1", "\uda14\udc61\udaab\uded1\ud9b7\udfc9\ud89a\udf49\ud828\udc1e\ud995\udfab",
        42, 9950, -211391052, 7187196053979942814L, 83677L, true, false, (char) 59221, (char) 30994,
        Double.longBitsToDouble(0x3fe496e55d23f9d9L), Double.longBitsToDouble(0x3fe373699cab47d0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Double:0.577462875156665 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=java.lang.Double:0.577462875156665 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 2, 7, 0, 5, "\uda7b\udfd8\ud8bd\uddc1\udb2e\udc67\ud986\uddd9\udb4c\udd17\ud900\ude1b\udb17\ude8e", "\u458c\u505a\ua93a\ud543\u9ce4", "\ud983\ude72\ua5e1\udbfb\udfba\udbe5\udf58\ud86d\udc20",
        39, 25982, 1301729478, 3705248649931860309L, -97731L, false, true, (char) 33139, (char) 26412,
        Double.longBitsToDouble(0x3fe27a936c6e76d7L), Double.longBitsToDouble(0x3fd4d12094e7fd3cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Double:0.7292207373325833 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=new org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 2, 0, 6, 3, "\ud8c0\ude6a\ud8e4\udf8f\ud80b\udc6c\ud92c\ude9b\ud8c1\udc34\udada\uddc8\ud871\ude1c", "\ubf06\ub1fb\u4bfc\ud7c9", "\udb48\udc63\ud83f\udecf\uabe1\udbfb\udfba\ud9b7\udfc9\ud89a\udf49\ud972\udd84",
        53, 27405, 1293735490, -5115102755959892856L, 46548L, true, true, (char) 17383, (char) 62651,
        Double.longBitsToDouble(0x3fe755c6ba4d1209L), Double.longBitsToDouble(0x3fdc7d1db5e91204L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Double:0.08320395648479462 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 1, 0, 7, 7, "\udb0d\uded0\ud9ba\udd3b\uda5f\uded6\udade\udc58\udbcf\uddd1[\000", "\000\000\000", "\ud830\udf2e",
        6, -1000, 0, 1188197277L, -18669L, false, false, (char) 21551, (char) 64921,
        Double.longBitsToDouble(0x3fb54cdac0000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 8, 0, "\uf063\ud9ab\uddd5\uda5f\udec9\000\ud8e5\uddae\ud900\ude1b\udbaf\udd89\udaf4\udf8c", "\000\u0431\ud543\u82b1\ub97a\ud06d\u9984\u9308\u895c\000\u10cb\u60cf\u00fe\000", "\ud89d\udd7c\u00dd\udb85\udf7b",
        49, 3288, -288120241, -5027320935743358387L, 86523L, false, false, (char) 6229, (char) 32089,
        Double.longBitsToDouble(0x3fa63c65c77d16e0L), Double.longBitsToDouble(0x3fec8b3a8a682d32L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:0.4485395597874483 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 0, 9, 9, "\udbee\udf4c\ud9ba\udd93\udacf\udd62\udb1d\uddfc\ud8b1\udda8\ud8c5\ude96\ufda2\ud9b6\uded7\ud881\ude2e\udb15\uddc2\ud933\ude5f\u2312\uda16\udf96\udb68\udcf7\ud848\udd68\ud83c\udd07\udb8b\udeb2\ud9bf\uddba\ud974\uddce\udbc3\udcbf\ud89a\udf49\ud828\udc1e\ud970\udda6\ud8bc\udf8b\uda49\udf77\udbae\udd83\udbb0\udc4e\ud942\udd8f\udb76\uddb7", "\u3ee6\u6823\u4196\u66f6\u8ce0\u618c\uc51d\ud368\u3c79\ua47d", "\ud980\uded4\udbaa\uded6",
        23, 41411, 700017696, 4000350217275140166L, 84758L, true, true, (char) 18167, (char) 30778,
        Double.longBitsToDouble(0x3fdcb4df450ff4faL), Double.longBitsToDouble(0x3fa08b5401f6e3f0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 6, 5, 6, "\udb0d\uded0\ud9ba\udd3b\uda5f\uded6\udaba\udf04\udbca\udd69\ud900\ude1b\ud868\udef8\ud8e4\ude28\ud881\uddfc\udb15\uddc2\ud809\udf09\ud9a8\udd06", "\u02b2\ubbcc\u8bf8\u58a1\u895c\u478d\ud4eb\ube55\u5d54\u969a\u40cc\uc375\uacba\ua058\u8ee5\ua18b", "\ud83b\udd7e\ud88d\udd38\ud822\udc74\ud9d7\ude8d\udadf\ude9d\ud8a6\udc2d\ud948\udd92\ud956\udd21\udb2c\ude85\ud8ac\ude4b\udb8a\udd9c\udade\udcf7\uda84\udc09",
        45, 3352, 53732571, -2174959406923323581L, -44428L, true, true, (char) 5494, (char) 60727,
        Double.longBitsToDouble(0x3fd208956db903a0L), Double.longBitsToDouble(0x3fed39e9aba2b883L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=new org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 2, 6, 6, 1, "\ud9a3\udcfb\uda8e\udd24\uda5f\uded6\udae4\udc58\udbcf\uddd1\udbc1\ude3b\uda0f\udca1\ud8e4\ude28\ud881\uddfc\u1dbc\ud809\udf09\ud8b4\udf6d\ud8e5\udec0", "\uc9b9\u2030", "\udae7\udcd8\udace\ude0c\uda1f\udd5e\ud88e\udf18\ud8aa\udd84\ud962\ude42",
        -4, 73258, 1351616733, -7203158647238774934L, 85677L, true, false, (char) 15095, (char) 55708,
        Double.longBitsToDouble(0x3fe37427ae82d9c4L), Double.longBitsToDouble(0x3fe32d38bd7a0915L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 6, 10, 4, "\udb0d\uded0\ud9ba\udd3b\u4d54\ud8f9\udeca\udbc0\udf8c\ud900\uddf2\ud868\udef8\ud8e4\ude28\ud881\uddfc\uda88\udcc5\ud81a\udf3b\ud9c7\ude65", "\u2b1b\ubbcc\u8bf8\u58a1\u895c", "\ud828\udc1e\ud879\ude8a\uda8c\udc9f\uda51\udc3c\ud8b8\ude0c\ud959\udd9a\ud82a\udd11\ud8bd\udcda\uda30\ude9a\ud915\udfca\udb22\udd92\ud83b\uddc1",
        56, 59227, 1405082014, -8866038601079285138L, -87908L, false, false, (char) 16338, (char) 14006,
        Double.longBitsToDouble(0x3fd7a27f0005cb38L), Double.longBitsToDouble(0x3fcfe2012a14a390L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Double:0.08320395648479462 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=java.lang.Double:0.08320395648479462 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 2, 0, 7, 7, "\ud81f\udd26\ud9ba\udd3b\uda5f\uded6\udade\udc58\udbcf\uddd1[\000", "\u7d55\u4db0\u68ef", "\ud830\udf2e",
        6, -1000, 0, 5643080703027593177L, -18669L, false, false, (char) 21551, (char) 64921,
        Double.longBitsToDouble(0x3fb54cdac0000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 8, 0, "\udb0d\uded0\ud9ba\udd3b\uda5f\uded6\ud9cc\udfed\udbd3\udef8\ud900\ude1b\ud868\udef8\ud8ba\udf2f\ud881\udd7d\udb15\uddc2\ud809\udf09\ud8d3\uded1", "\u2ae1", "\ud923\udfbd\udbfb\udfd8\ud9b7\udfc9\udb3f\udf9c\udb52\ude09\ud962\udeb0",
        18, 53428, 263137621, 975324745707817181L, 85677L, true, false, (char) 40429, (char) 16927,
        Double.longBitsToDouble(0x3fe37427acab47d0L), Double.longBitsToDouble(0x3fe8d0ff54c8c23bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double,double,double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|double,double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "C|org.apache.commons.math.analysis.solvers.BrentSolver|<init>|org.apache.commons.math.analysis.UnivariateRealFunction",
    "C|org.apache.commons.math.analysis.solvers.BrentSolver|<init>|",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double,double,double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|double,double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
