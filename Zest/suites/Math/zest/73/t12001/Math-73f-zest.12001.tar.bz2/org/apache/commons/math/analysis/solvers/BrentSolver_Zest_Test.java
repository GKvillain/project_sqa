package org.apache.commons.math.analysis.solvers;
import org.junit.Test;
import static org.junit.Assert.*;
public class BrentSolver_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 2, 7, 1, "\ud8cc\udf99\udbb9\udff3\uda97\uddf6\udb5b\udee6\uf8a2\ud98b\udfe4\uda26\udf2b", "\u28f7\u14a2\u370c", "\ud8d3\ude5b\ud9d1\ude84\udaf0\udd48\udbdc\udf73\uda2d\udfb0\ud9ea\uddfb\ud978\uddee\ud8cb\udebb\udb59\uddea\uda27\udcfc\udafb\udfcb\ud808\udebb",
        16, 67117, -2017561031, -6794417621243751677L, -67309L, true, false, (char) 52202, (char) 20032,
        Double.longBitsToDouble(0x3fe7fc0481501aabL), Double.longBitsToDouble(0x3fcae85f0fb866c8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 2, 8, 8, "\uda2d\uddc9\udbef\udf84\udb39\udff4\udac4\udd73\udafc\udff2\ud986\udd23\uda26\udf2b", "\ucbf9\uc162\u370c", "\udaa4\udc33\ud9d1\ude84\ud82f\uddc8\udbd8\ude9f\uda18\udee6\uda41\ude4e\ud978\uddee\udb5d\udf24\udb59\uddea\uda27\udcfc\uff84\ud8ec\ude8d",
        40, 224, -2017561031, -8346868666022194423L, 35454L, true, false, (char) 22212, (char) 5082,
        Double.longBitsToDouble(0x3f96938a4ca6c2e0L), Double.longBitsToDouble(0x3fdb0fe3a0118abaL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 2, 7, 1, "\ud919\ude98\udbb9\udff3\uda97\uddf6\u3120\000\000\uda26\udf2b", "\u28f7\u14a2\ud630", "\ud8d3\ude5b\ud9d1\ude84\udaf0\udd488\000\ud9ea\uddfb\ud978\uddee\ud839\udeb2\u56a9\000\000\u8e71",
        44, 51493, 0, -6845471433634835709L, -100000L, false, true, (char) 53609, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe7fc0001501aabL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 1, "\udabf\uddf1", "\uad4d\u17f9", "\ud9e2\udc66\udb32\udc6b\ud995\udf9c\ud89c\udcfa\udaa4\udeee\ud8b1\udfbd\uda94\udd10\ud893\uddda",
        49, 13818, 920767236, -1057606431502890584L, -90416L, true, false, (char) 61486, (char) 23583,
        Double.longBitsToDouble(0x3fb29d75b7a36a70L), Double.longBitsToDouble(0x3fd0dcc41c715340L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 4, 7, 1, "\ud8cc\udf99\udbb9\udff3\uda97\uddf6\udb5b\udee6\uf8a2\ud98b\udfe4\uda26\udf2b", "\u28f7\u14a2\u370c", "\udb45\udcb4\ud9d1\ude84\udaf0\udd48\udbdc\udf73\uda2d\udfb0\ud9ea\uddfb\ud978\uddee\ud8cb\udebb\udb59\uddea\udb29\udcfd\udafb\udfcb\ud808\udebb",
        16, 67117, -2017561031, -6794417621243751677L, -67309L, true, false, (char) 52202, (char) 20032,
        Double.longBitsToDouble(0x3fe7fc0481501aabL), Double.longBitsToDouble(0x3fcae85f0fb866c8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 1, 6, 5, 1, "\udbe1\udc42\uda6e\udcb7\udae4\udcdd\udaec\udd20\uf8a2\ud98b\udfe4\uda26\udf2b\ud9e2\udc66\udb32\udc6b\ud86b\udfa7", "\u0463\u469f\u6314\u195a", "\uda2d\udfb0\ud9ea\uddfb\ud978\uddee\ud8cb\udebb",
        58, 75177, -1546233638, -1793671948194939318L, 807L, false, true, (char) 13496, (char) 54508,
        Double.longBitsToDouble(0x3fc2849caa367bd0L), Double.longBitsToDouble(0x3fe5ec504f3c6cbcL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 10, 8, 7, "\ud8bf\uddec\ud9e2\udecc\uda97\uddf6\ud8ba\udcd6\u93fb\ud98b\udfe4\uda26\udf2b", "\u05db\uc8ae\u370c", "\udb17\udf5c\ud86b\udece\ud883\ude59\ud94a\ude6d\uda1f\udc19\udbd6\udfff\udaed\udcb1\udaa8\udeb8\udbc2\udff4\ud82e\ude4d\udace\udcf5\udace\udf1f\ud966\udfe7\ud9a0\ude63",
        4, 13372, -268742071, 4915266472916750622L, 73698L, false, true, (char) 20841, (char) 3452,
        Double.longBitsToDouble(0x3fdb09d99211ca6eL), Double.longBitsToDouble(0x3fcff01205435d38L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Double:3.923195102117916E-12 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 1, 0, 0, 10, "\000", "\uad4d", "\000\000\u1236\ud86b\udfa7\uda18\udcf8\udaa4\udeee\ud8b1\udec1\ufb86\u3899\000\000\000\ua08e\ud9ea\udd53\ud978\uddac\ud8cb\udebb\udb59\uddea",
        39, -1000, 1828716618, -3728418693318521587L, -34464L, false, true, (char) 28, (char) 0,
        Double.longBitsToDouble(0x3d91412000000000L), Double.longBitsToDouble(0x3fae000004dd11c0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 4, 2, 10, "\ud9dd\udd2f\ud8e6\udd5d\uda99\udce9\udb3c\uddef\ud9e1\udf5f\ud98b\udfe4\uda1b\udc9b", "\u28f7\u14a2\u1049", "\udb51\ude91\udb9e\udde2\uda9f\udfa0\udb5a\ude30\uda0d\udd18\uda57\ude2f\ud9b0\ude8b\ud8cb\udebb\udb59\uddea\ud878\ude28\udbef\udc3b\ud808\udebb",
        16, 58365, -154190162, -6810157705720982781L, -67309L, true, false, (char) 52202, (char) 20032,
        Double.longBitsToDouble(0x3fcff7eb227260e8L), Double.longBitsToDouble(0x3fe0c694a432d058L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=java.lang.Double:0.968190411258906 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 2, 6, 7, 1, "\ud936\udca6\udbb9\udff3\uda97\uddf6\udb5b\udee6\uf8a2\uda55\udcc8\ud85e\udd42", "\u70ea\u890b\uad16", "\ud8ca\udc58\ud80d\udeb0",
        -4, 47258, -242958899, 398860658780502850L, -12279L, true, false, (char) 23620, (char) 544,
        Double.longBitsToDouble(0x3feefb6a75150ca1L), Double.longBitsToDouble(0x3fd92bcd22590f7cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 5, 7, 6, "\ud8d5\udf02\udbb9\udff3\udb20\udc3b\udb5f\udd92\uf8a2\ud98b\udfe4\uda26\udf2b", "\u28f7\u14a2\u370c", "\ud8d3\ude5b\ud9d1\ude84\udaf0\udd48\ud9f9\ude62\uda04\udfb5\ud9ea\uddfb\ud978\uddee\ud8cb\udebb\udb59\uddea\uda27\udcfc\uda46\udc31\ud855\udc17",
        16, 67117, -2017561031, -6794417621238159357L, -87120L, false, true, (char) 5007, (char) 1019,
        Double.longBitsToDouble(0x3fcae85f0fb866c8L), Double.longBitsToDouble(0x3fe54fa01d85db5fL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 1, 6, 7, 1, "\ud8cc\udf99\udad2\udd80\udbd1\udeee\udb5b\udee6\ud8d5\udfae\ud98b\udf93\uda37\udd54", "\u28f7\u14a2\u370c\u0463\u5af9\u1386\uc49c\u3764\u70f4\u9f28\u6837\u3094\u8641", "\udafb\udfe9\ud808\udebb\ud966\udfe7\ua428\uda56\udeee\udab4\udfb6\ud998\udfdc\ud842\uded5\ud988\udf60\ud934\udf99\ud9b4\udd25\uda73\udc78\ud802\udf7d\ud8fc\ude4a\udbb0\uddf2\ud930\udd51\ud94b\udc91\ud961\udd42",
        17, 26878, -1521569882, 2365456094505884498L, -20148L, true, false, (char) 41454, (char) 41570,
        Double.longBitsToDouble(0x3fe37d8f3379d31cL), Double.longBitsToDouble(0x3fe1949b131a7e16L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Double:0.7495138669626916 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 1, 0, 4, 5, "\ud973\udcb1\ud8d2\udcb2\uda97\uddbc\udb5b\udee6\uf8a2", "\u0519\u56fd\u9069\u14a2\u370c\u0463\u5af9\u1386", "\udbdc\udf73\uda2d\udfb0\ua0fb\ud978\ude05\ud8cb\udebb\udb59\uddea\uda27\udcfc",
        40, 76689, 139729856, 2539586625059997934L, -67309L, true, false, (char) 52202, (char) 20032,
        Double.longBitsToDouble(0x3fe7fc0481501aabL), Double.longBitsToDouble(0x3fc5085f0fb86528L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 1, "\ud8cc\udf99\udbb9\udff3\uda97\uddf6\udb5b\udee6\uf8a2\ud98b\udfe4\uda26\udf2b", "\u28f7\u14a2\u370c", "\ud8d3\ude5b\udbf8\ude18\uda92\udd1e\udbdc\udf73\uda2d\udfb0\ud9ea\uddfb\ud978\uddee\ud8cb\udebb\udb59\uddea\uda27\udcfc\udafb\udf26\ud808\udebb",
        16, 67117, -2017561031, -6794417621243751677L, -67933L, false, true, (char) 20841, (char) 63611,
        Double.longBitsToDouble(0x3fdb0fe3a211ca6eL), Double.longBitsToDouble(0x3fe7fc0481501aabL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:0.05877153632039578 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 0, "\udb38\udd6e\udb30\udfd5\uda97\udd70\udb5b\udee6\uf8a2\ud98b\udfe4\uda26\udf2b", "\u28f7\u14a2\u58be", "\ud8c5\udfa2\ud9d1\ude84\udaab\udf21\ud9c3\uddad\uda02\udd40\ud9ea\uddfb\udb06\udf4b\udbf4\udf24\ud8a5\udd35\udb93\ude49\ud850\ude1e",
        38, 69497, -769735790, -8665358644307205844L, -23920L, false, true, (char) 52085, (char) 64096,
        Double.longBitsToDouble(0x3fae174d84dd11c0L), Double.longBitsToDouble(0x3fe329b0bdb0fe3aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 5, 10, 1, "\ud8cc\udf99\udbb9\udff3\uda97\uddf6\udb5b\udee6\uf8a2\ud98b\udfe4\uda1a\ude2b", "\u28f7\u14a2\u370c", "\ud8d3\ude25\ud9e0\ude52\ud950\udefb\ud992\udf0b\udb3c\udd93\uda31\ude86\ud992\ude17\ud9a4\udda8\udb59\uddea\uda27\udcfc\ud86e\udc8a\ud808\udebb",
        29, 90693, 1829179723, -9154449061844975311L, -14927L, true, false, (char) 3270, (char) 59383,
        Double.longBitsToDouble(0x3fb374471329b0b8L), Double.longBitsToDouble(0x3fee9afec908e53cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Double:8.314890146721154E-4 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 1, 0, 10, 1, "", "\000", "",
        -5, -805, 0, 27303074653536256L, -100000L, false, false, (char) 8582, (char) 38561,
        Double.longBitsToDouble(0x3f4b3f0910000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Double:0.7438446310674071 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 7, 8, 2, "\uda1a\ude8d\udbb9\udff3\uda97\uddf6\u3120\ud887\udec3", "\u69e9\u571b", "\udb0e\udee3\ud8b1\udfbd\uda94\udd10\ud8d3\ude5b\ud9d1\ude84\udaf0\udd48\udb5a\udf84\u05d5\ud9ea\uddae\udad3\ude3b\ud839\ude4a\u56a9\ud9ff\udeff\000\u8e71\u00f4\ucd0d\000\udb0c\ude66\ud9ec\udee6\udbe1\ude8b",
        29, 83965, 983654144, -3378571268176478131L, -100000L, false, false, (char) 4863, (char) 1019,
        Double.longBitsToDouble(0x3fe7cd934177ab9dL), Double.longBitsToDouble(0x3fd80f4069550c30L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 6, 4, 10, "\udabf\uddf1", "\ua0cd\u187d", "\ud9e2\udc66\uda67\ude07\ud995\udf9c\ud89c\udcfa\ud8fa\ude70\ud90f\uddf8\udb97\udee9\ud8d6\ude6a",
        35, 13947, 920767236, -1057606431502890584L, -90416L, true, true, (char) 61496, (char) 13344,
        Double.longBitsToDouble(0x3fb29d5bb7a36a70L), Double.longBitsToDouble(0x3fd0dcc41c715340L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Double:0.07271514638288479 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 7, 3, 1, "\udabf\uddf1", "\u7c4d\u17f9", "\uda8b\udde4\udb32\udc6b\ud995\udf9c\ud89c\udcfa\udaa4\udeee\ud8b1\udfbd\uda94\udd10\ud893\uddda",
        49, 59242, 920715264, -1057606431502890584L, -90416L, false, false, (char) 64813, (char) 23583,
        Double.longBitsToDouble(0x3fb29d75b7a36a70L), Double.longBitsToDouble(0x3f8b98838e2a6800L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Double:0.07271514638288479 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 7, 9, 1, "\udabf\uddf1", "\uad4d\u17f9", "\ud9e2\udc66\udb32\udc6b\ud995\udf9c\ud89c\udcfa\udaa4\udeee\ud8b1\udfbd\uda94\udd10\ud893\uddda",
        49, 13818, 920767236, -1057606431502890584L, -90416L, true, false, (char) 61486, (char) 23583,
        Double.longBitsToDouble(0x3fb29d75b7a36a70L), Double.longBitsToDouble(0x3fd0dcc41c715340L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=java.lang.Double:0.0 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud967\udfc5", "", "\ud98b\udfe4\u00c3\000\000\udb71\udeb7\ud89c\udcfa\000",
        -5, -1000, 0, 0L, -100000L, false, false, (char) 7626, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fcb40600001d758L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=new org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 2, 6, 6, 9, "\udabf\uddf1", "\uad4d\u17f9", "\udad9\udeef\udb32\udc6b\ud995\udf23\ud89c\udcfa\udaa4\udece\ud996\udcd0\udb2f\uded6\ud893\uddab",
        49, 18, 920767263, -1057606431502890584L, -90416L, true, false, (char) 18479, (char) 12717,
        Double.longBitsToDouble(0x3fb29d7277a36a70L), Double.longBitsToDouble(0x3fd0d5ca50715340L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Double:0.7124387973040097 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 0, 5, 7, "\ud9cf\udf2a\udbb9\udff3\ud938\udf88\ud83a\udde7\uc572\uda1d\uddcf\ud83c\udfa3\udae6\udc58\udbd9\udeab\ud86b\udf7e\ud89c\udcfa\udaa4\udef1\ud8b1\udfbd\uda94\udd10\udb45\udcb4\ud874\udf5b\uc7ec\ud933\uded9\uda2d\udfb0\ud9ea\uddfb\ud882\udcca\udb10\udcf5\udb28\udc1f\udb29\udce7", "\u841e\u2def\u3e45\u2688", "\ud845\udcd1\udbed\uddeb\uda58\udfd0\ud8ab\udea7\ud86e\uddcd\uda51\uddb7\udac2\ude1e\ud994\udde2",
        23, 83912, 431117527, -115079361686567604L, -80907L, false, true, (char) 17031, (char) 60729,
        Double.longBitsToDouble(0x3fe6cc4c72da503dL), Double.longBitsToDouble(0x3fd108867fdcfa9cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Double:0.8332326417862848 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\0121=java.lang.Double:0.8332326417862848 |this=org.apache.commons.math.analysis.solvers.BrentSolver:@?\012",
        Z.run(T, 2, 7, 0, 0, "\uda74\udd91\uda45\udc5c\uda97\uddf6\u3120\ud887\udec3\ud9f5\udf30\ud889\udff2\ud9e2\udc66\uf325\ud8a3\udc10\udb54\udda9\udb0e\udee3\ud8b1\udfbd", "\u195a\u376b\u4d04\u05d5\u5d0a\u4f19\u80fb", "\ud9b9\udc5b",
        41, -756, 1711328525, 4864909686520697052L, -23894L, false, true, (char) 292, (char) 24329,
        Double.longBitsToDouble(0x3feaa9d7804dd11cL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 2, 7, 1, "\uc0fc\ud984\udc85\uda97\ude42\udb5b\udee6\uf8a2\ud98b\udfe4\uda26\udf2b", "\u28f7\u9bb8\u370c", "\ud8d3\ude5b\ud9d1\ude84\udaf0\udd48\udbdc\udf73\uda2d\udfb0\ud9ea\uddfb\ud978\uddc0\uda23\udce7\udb59\uddea\uda27\udcfc\udafb\udfcb\ud808\udebb",
        16, 94348, -2017561031, -6794417621243751677L, 99198L, true, false, (char) 3270, (char) 21496,
        Double.longBitsToDouble(0x3fb374471329b5d0L), Double.longBitsToDouble(0x3fdb0fe3a211ca6eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double,double,double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|double,double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "C|org.apache.commons.math.analysis.solvers.BrentSolver|<init>|org.apache.commons.math.analysis.UnivariateRealFunction",
    "C|org.apache.commons.math.analysis.solvers.BrentSolver|<init>|",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double,double,double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|double,double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
    "M|org.apache.commons.math.analysis.solvers.BrentSolver|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double|new:org.apache.commons.math.analysis.solvers.BrentSolver:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
