package org.apache.commons.math.linear;
import org.junit.Test;
import static org.junit.Assert.*;
public class OpenMapRealMatrix_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 2, 3, "\ud962\uddb0\uda20\ude8f", "\u806f\u772b\ucf59\u87fe\u29b0\u70be", "\ud9a1\ude7b\udb50\udc53\udb96\udc5e\ud877\udf19\udb4a\udc4f\ud988\udd22\udb67\udcf9\ud8b9\udce8\uda1a\udd69\udbe1\udc8d\udb66\udc67\ud85d\ude64\udb67\udfa2\udba6\udcb3\ud952\udda0\ud952\udf6e\udace\udcac\ud997\udf37\udb01\udf29\ud9ad\udc43\udb47\udd85\uda1f\udc8e",
        14, 69468, -1565808269, -3446724788781353574L, 29571L, true, true, (char) 39855, (char) 34765,
        Double.longBitsToDouble(0x3feffa6fa3323968L), Double.longBitsToDouble(0x3fddd35720a95278L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.math.linear.OpenMapRealMatrix:OpenMapRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0...\012",
        Z.run(T, 1, 0, 0, 3, "\ud962\uddb0\ueffd", "\u7107\000\ucf59\u87fe\u29b0\u70be", "\ud9a1\ude7b\udb50\udc53\ud864\udfc6\ud877\udf19\udb4a\udc4f\ud988\udd22\udb67\udcf9\ud8b9\udce8\uda1a\udd69\u00dd\udb66\udc32\ud85d\ude64\udb67\udfa2\ud9a2\udd92\ud952\udcbe\ud952\udf6e\udace\udcac\ud997\udf37\udb01\udf29\ud9ad\udc43\udb47\udd85\uda1f\udc8e",
        14, 69468, -1565808269, -3446724788781353574L, -99859L, false, false, (char) 41712, (char) 21501,
        Double.longBitsToDouble(0x3fcce9590c4cf2e8L), Double.longBitsToDouble(0x3fcfe9be80000000L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 2, 3, "\ud962\uddb0\uda20\ude8f", "\u806f\u772b\ucf59\u87fe\u29b0\u70be", "\ud9a1\ude7b\udb50\udc53\udb96\udc5e\ud877\udf19\udb4a\udc4f\ud988\udd22\udb67\udcf9\ud8b9\udce8\uda1a\udd69\udbe1\udc8d\udb66\udc67\ud85d\ude64\udb67\udecc\udba6\udcb3\ud952\udda0\ud952\udf6e\udace\udcac\ud997\udf37\udb01\udf29\ud9ad\udc43\udb47\udd85\uda1f\udc8e",
        14, 69468, -1565808269, -3446724788781353574L, -100000L, false, false, (char) 39655, (char) 34765,
        Double.longBitsToDouble(0x3feffa6fa3323968L), Double.longBitsToDouble(0x3fddd35720a95278L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.math.linear.OpenMapRealMatrix:OpenMapRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0...\012",
        Z.run(T, 1, 0, 4, 16, "\ud962\uddb0\uda20\ude8f\udaed\udfe2\uda90\udd67\uc586\ud886\udfa7\ud8d6\udd25\udba7\udea9\ud85c\ude75\udbae\udf1b\udb18\udecb\ud9aa\udd1a\ud9a1\ude7b\udb50\udc53\udb96\udc5e\udb83\udf1f\ud8db\udc4a\ud8dd\udfee\ud9b4\udfdf\ud8aa\udc0b\uda24\ude69\udbe1\udc8d", "\u9122\ub293\u665e\u1973\u4588\u2699\u50dc", "\uda1f\udc8e\uf888\ud9c7\udc77\udbe8\udfa9\ud94e\udf3f",
        27, 15791, -2062535429, 1935759188004514383L, 32573L, true, true, (char) 39855, (char) 34796,
        Double.longBitsToDouble(0x3feec9c7a14481ebL), Double.longBitsToDouble(0x3fddd35100a95278L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 8, 15, "\ud9ca\udf5a\ud856\uddcf\udaed\udfe2\udb6f\uddf8\udaea\ude36\ud921\udce8\uda62\udf95\ud8f7\ude29\ud93a\udf5e\ud9ce\udf81\udb12\udf4c\ud83e\udd39\ud9a1\ude7b\udb50\udc53\udb96\udc5e\ud877\udf19\udb4a\udc4f\ud988\udd22\ud8b1\udc5f", "\u9820\u9c72\u1773\u3199\u8171", "\udace\udcac\ud997\udf37\udb01\udf29\ud9ad\udc43\ud9da\uddbf\uda0c\udf5e\ud9b8\udca6\udb90\udd1b\udbe8\udff2\ud94e\udf3f\udb03\udc8c\ud9aa\ude16\ud90f\udcf6\ud886\udc81\uda53\udc08\udb6c\udca8\udb67\udf70",
        30, 55367, 1307855635, 4136745370341497650L, -51978L, true, false, (char) 26049, (char) 15517,
        Double.longBitsToDouble(0x3fe3fe10e2c7d6ecL), Double.longBitsToDouble(0x3fe5c01f8df13ea3L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 2, 3, "\ud962\uddb0\uda20\ude8f\udaed\udfe2\uda90\udd67\udad3\uded5\uda0d\ude87\ud8d6\udcee\uda76\udf11\ud85c\ude75\udb18\udc87\udb18\udecb\ud90f\udfe0\udbd1\ude35\udb4f\udfd9\udb96\udc5e\ud877\udf19\udb4a\udc4f\ud96f\udeae\udb67\udcf9\ud8fd\ude33\uda1a\udd4b\udbe1\udc8d\udb32\udd0d\ud85d\ude64\udb67\udfa2\udba6\udcb3\ud952\udda0\uda69\udd7a\ud92f\udc13\ud997\udf37\udb01\udf29\ud9ad\udc43\udb47\udd85\uda1f\udc8e", "\u78bb\ubd5f\u6352\u14dd\u5b46\uc290\u86ce\ua198\u0847\u7415", "\ud831\udf61\ud925\ude58",
        8, 82498, -1844672298, 5974895558587141550L, -42405L, false, true, (char) 63623, (char) 13746,
        Double.longBitsToDouble(0x3fca4a2dd5852140L), Double.longBitsToDouble(0x3fe4b9019a365455L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.math.linear.OpenMapRealMatrix:OpenMapRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0...\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 3, "\ud962\uddb0\uda20\ude8f", "\u86cd\u8b9d\ucf59\u87fe\u29b0\u8579", "\ud9a1\ude7b\ud8b2\ude54\udb96\udc5e\udbac\udc40\udb4a\udcc4\ud95e\udecf\ud939\udea6\ud8b9\udce8",
        39, 42119, -1651571147, -251416809359247598L, 50242L, true, true, (char) 22312, (char) 57556,
        Double.longBitsToDouble(0x3fd05c6a0e72d07eL), Double.longBitsToDouble(0x3f7d2f27c4463c00L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NotStrictlyPositiveException\012",
        Z.run(T, 1, 0, 10, 3, "\ud962\uddb0\uda20\ude8f", "\u806f\u772b\u0714\u87fe\000\u70be", "\uda09\udd2f\udb50\udc53\ud864\udfc6\ud84d\udce5\ud87a\udc47\000\udb2a\uded4\ud8b9\udce8\uda1a\udd69\udbe1\udc8d\u0635\000\000\000\ud952\udda0\ud952\udf6e\udace\udcac\ud997\udf37\udb01\udf29\ud9ad\udc43\udb47\udd85\000",
        2, -1000, -1565808269, 72715040000L, -100000L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e3991c800000000L), Double.longBitsToDouble(0x3fddd35720a95278L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 2, 3, "\ud962\uddb0\uda20\ude8f\udaed\udfe2\uda90\udd67\udae8\udd0e", "\u87fe\u29b0\u07d7\u5d2d\ucbb8\u0bac\u3ca8", "\udb4a\udc4f\ud988\udd22\ud9c1\udde7\udbe3\udd18\uda1a\udd69\udaf9\uddaf\udb38\uddc5\ud85d\ude5c",
        33, 83930, 1919823750, -1884620111219035723L, -61919L, false, false, (char) 53517, (char) 38913,
        Double.longBitsToDouble(0x3fee79740634c864L), Double.longBitsToDouble(0x3fe7f18a7119abc4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.math.linear.OpenMapRealMatrix:OpenMapRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0...\012",
        Z.run(T, 1, 16, 15, 14, "\u7b79\udbd0\udc62\udba8\udd3c", "\u772b\u829c\u090b", "\udbce\udd62\udab2\udfa3\ud9a1\ude7b\ud982\udc6c\udb96\udc5e\ue4fa\udb24\uddd1",
        30, 7253, 765352504, -7128337028246069504L, -80415L, false, false, (char) 45367, (char) 34601,
        Double.longBitsToDouble(0x3fea8f8ca105c68fL), Double.longBitsToDouble(0x3fe9cb41fffacdc9L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.math.linear.OpenMapRealMatrix:OpenMapRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0...\012",
        Z.run(T, 1, 16, 16, 16, "\udb1a\udc96\udafa\ude41", "\u806f\u772b\ucf59\u87fe", "\udb18\udecb\uda94\udc23\ud8b3\uddec\ud96f\udf96\uda46\udfab\ud85b\uddc4\udb42\udc4b\ud988\udd22\udb67\udcf9\ud8b9\udce8\uda1a\udd69\udbe1\udc8d\udb66\udc67\ud85d\ude64\udb67\udfa2\udba6\udcb3",
        44, 85278, 1983607221, -4134187250814559995L, -88785L, false, false, (char) 56000, (char) 5821,
        Double.longBitsToDouble(0x3fcd72291d6240b4L), Double.longBitsToDouble(0x3fef8efc32ba858eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NotStrictlyPositiveException\012",
        Z.run(T, 1, 0, 0, 3, "\ud962\uddb0", "\u01a9", "\ud8d6\udd25\udba7\udea9\ud85c\ude75",
        -3, 29979, -253923064, 1587901700503357573L, -65022L, false, true, (char) 16300, (char) 27020,
        Double.longBitsToDouble(0x3f73fcdf9f16cf00L), Double.longBitsToDouble(0x3fcbb3a278000000L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.math.linear.OpenMapRealMatrix:OpenMapRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0...\012",
        Z.run(T, 1, 0, 0, 3, "\ud962\uddb0\ueffd", "\u7107\000\ucf59\u87fe\u29b0\000", "\ud9a1\ude7b",
        8, 66980, 1393601076, 8430933538905770521L, 54168L, false, true, (char) 40432, (char) 1536,
        Double.longBitsToDouble(0x3fee9cec78000000L), Double.longBitsToDouble(0x3e30000000000000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.math.linear.OpenMapRealMatrix:OpenMapRealMatrix{{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0...\012",
        Z.run(T, 1, 0, 0, 3, "\ud962\uddb0\ueffd", "\u7107\000\ucf59\u87fe\u29b0\u70be", "\ud9a1\ude7b\udb50\udc53\ud864\udfc6\ud877\udf19\udb4a\udc4f\ud988\udd22\udb67\udcf9\ud8b9\udce8\uda1a\udd69\u00dd\udb66\udc32\ud85d\ude64\udb67\udfa2\ud9a2\udd92\ud952\udcbe\ud952\udf6e\udace\udcac\ud997\udf37\udb01\udf29\ud9ad\udc43\udb47\udd85\uda1f\udc8e",
        14, 7660, -1565808269, -3446724788781353574L, -99859L, false, false, (char) 41712, (char) 21501,
        Double.longBitsToDouble(0x3fcce9590c4cf2e8L), Double.longBitsToDouble(0x3fcfe9be80000000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "C|org.apache.commons.math.linear.OpenMapRealMatrix|<init>|int,int",
    "C|org.apache.commons.math.linear.OpenMapRealMatrix|<init>|org.apache.commons.math.linear.OpenMapRealMatrix",
    "M|org.apache.commons.math.linear.OpenMapRealMatrix|add|org.apache.commons.math.linear.OpenMapRealMatrix|new:org.apache.commons.math.linear.OpenMapRealMatrix:org.apache.commons.math.linear.OpenMapRealMatrix",
    "M|org.apache.commons.math.linear.OpenMapRealMatrix|addToEntry|int,int,double|new:org.apache.commons.math.linear.OpenMapRealMatrix:org.apache.commons.math.linear.OpenMapRealMatrix",
    "M|org.apache.commons.math.linear.OpenMapRealMatrix|computeKey|int,int|new:org.apache.commons.math.linear.OpenMapRealMatrix:org.apache.commons.math.linear.OpenMapRealMatrix",
    "M|org.apache.commons.math.linear.OpenMapRealMatrix|copy||new:org.apache.commons.math.linear.OpenMapRealMatrix:org.apache.commons.math.linear.OpenMapRealMatrix",
    "M|org.apache.commons.math.linear.OpenMapRealMatrix|createMatrix|int,int|new:org.apache.commons.math.linear.OpenMapRealMatrix:org.apache.commons.math.linear.OpenMapRealMatrix",
    "M|org.apache.commons.math.linear.OpenMapRealMatrix|getColumnDimension||new:org.apache.commons.math.linear.OpenMapRealMatrix:org.apache.commons.math.linear.OpenMapRealMatrix",
    "M|org.apache.commons.math.linear.OpenMapRealMatrix|getEntry|int,int|new:org.apache.commons.math.linear.OpenMapRealMatrix:org.apache.commons.math.linear.OpenMapRealMatrix",
    "M|org.apache.commons.math.linear.OpenMapRealMatrix|getRowDimension||new:org.apache.commons.math.linear.OpenMapRealMatrix:org.apache.commons.math.linear.OpenMapRealMatrix",
    "M|org.apache.commons.math.linear.OpenMapRealMatrix|multiply|org.apache.commons.math.linear.OpenMapRealMatrix|new:org.apache.commons.math.linear.OpenMapRealMatrix:org.apache.commons.math.linear.OpenMapRealMatrix",
    "M|org.apache.commons.math.linear.OpenMapRealMatrix|multiply|org.apache.commons.math.linear.RealMatrix|new:org.apache.commons.math.linear.OpenMapRealMatrix:org.apache.commons.math.linear.OpenMapRealMatrix",
    "M|org.apache.commons.math.linear.OpenMapRealMatrix|multiplyEntry|int,int,double|new:org.apache.commons.math.linear.OpenMapRealMatrix:org.apache.commons.math.linear.OpenMapRealMatrix",
    "M|org.apache.commons.math.linear.OpenMapRealMatrix|setEntry|int,int,double|new:org.apache.commons.math.linear.OpenMapRealMatrix:org.apache.commons.math.linear.OpenMapRealMatrix",
    "M|org.apache.commons.math.linear.OpenMapRealMatrix|subtract|org.apache.commons.math.linear.OpenMapRealMatrix|new:org.apache.commons.math.linear.OpenMapRealMatrix:org.apache.commons.math.linear.OpenMapRealMatrix",
    "M|org.apache.commons.math.linear.OpenMapRealMatrix|subtract|org.apache.commons.math.linear.RealMatrix|new:org.apache.commons.math.linear.OpenMapRealMatrix:org.apache.commons.math.linear.OpenMapRealMatrix",
    "C|org.apache.commons.math.linear.OpenMapRealMatrix|<init>|int,int",
    "C|org.apache.commons.math.linear.OpenMapRealMatrix|<init>|org.apache.commons.math.linear.OpenMapRealMatrix",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
