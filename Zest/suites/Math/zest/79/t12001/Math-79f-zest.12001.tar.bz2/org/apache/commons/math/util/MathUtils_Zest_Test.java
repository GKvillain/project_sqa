package org.apache.commons.math.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class MathUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Long:-6056854775302157335\0121=java.lang.Double:26886.5 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 13575.5, 2701.5, 1442.5, 10278.5, 7105.5, 7658.5, 15874.5]]\012",
        Z.run(T, 2, 4, 13, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u6a3f\u154b\u0b75\u507d\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u6b88\u0f52\u32da\u677c", "\u9959",
        29, 17370, 1419750058, -6056854775302103949L, -53386L, true, false, (char) 15670, (char) 32145,
        Double.longBitsToDouble(0x3fce7b1cf6d84ad4L), Double.longBitsToDouble(0x3fb07f04b6872fb8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Long:-6056854775302157335\0121=java.lang.Double:26886.5 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 13575.5, 2701.5, 1442.5, 10278.5, 7105.5, 7658.5, 15874.5]]\012",
        Z.run(T, 2, 4, 13, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udc53\ud965\udc4b\udb41\ude7a\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\ud8ab\udfdc\udb02\udd2c\ud85e\ude42\ud9ad\udd30", "\u533a\u6a3f\u154b\u0b75\u507d\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u5cfd\u671b\u52b9\u677c", "\u9959",
        29, 17370, 1419750058, -6056854775302103949L, -53386L, true, false, (char) 15670, (char) 63987,
        Double.longBitsToDouble(0x3fce7b1ce861739cL), Double.longBitsToDouble(0x3fa97f6d6d0e5f70L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Double:56551.323843920756 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 13575.5, 2701.5, 1442.5, 10278.5, 7105.5, 7658.5, 15874.5]]\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 16, 5, 10, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u6a3f\u154b\u0b75\u507d\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u6b88\u0f52\u32da\u677c", "\u9959",
        29, 17370, 1419750058, -6056854775302103949L, 60449L, false, false, (char) 39273, (char) 59498,
        Double.longBitsToDouble(0x3fb07f04b6872fb8L), Double.longBitsToDouble(0x3fe65b84d1b25beeL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Long:2719274167728490602\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 13, 15, "\ud88e\udcb1\ud866\udf49\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud82d\udc4f\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb75\udfde\ud834\udecd\ud869\udf32", "\u5335\u6a3f\ucc1a", "\uda3a\udd4a\uda41\udd94\ud89d\udce5\udb9a\ude9f\ud9e8\udd90\udaa9\udc62\ud974\udd34\udac9\uded9\uda47\udf5d\ud80d\udca0\udbf6\udf83\ud817\ude74\udb09\udccf\u3a5e\u9959\ud968\udc27",
        40, 93058, -1410221396, 2719274167728560983L, -70381L, true, true, (char) 32145, (char) 61914,
        Double.longBitsToDouble(0x3fdb612b5083f824L), Double.longBitsToDouble(0x3fe6872fbbb590c2L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Double:25414.0 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 13575.5, 2701.5, 11121.0, 10357.0, 7105.5, 7658.5, 15874.5]]\012",
        Z.run(T, 2, 15, 13, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\ud9ac\ude50\uda1f\udd7d\u7485\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\u7d4f\ud840\udf4c\ud869\udf32", "\u533a\u6a3f\u154b\u5712\u511a\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u4b62\u13e3\u32da\u677c", "\u9959",
        29, 17370, 1419750058, -6056854775302103949L, -53386L, true, false, (char) 15670, (char) 32145,
        Double.longBitsToDouble(0x3fce7b1cf6d84ad4L), Double.longBitsToDouble(0x3fb07f049e4f2fb8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Long:-3250174284566392238\012",
        Z.run(T, 1, 4, 13, 15, "\ud88e\udc8e\udbd7\udd82\ud877\udfce\ud8ab\udd9f", "\u8616", "\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\ud932\udd43\udb61\udc6d\ud861\ude29\ud901\udfff",
        22, 50387, 156450861, -3250174284566487295L, 95057L, true, true, (char) 6873, (char) 26523,
        Double.longBitsToDouble(0x3fe97a1d3edb3b0aL), Double.longBitsToDouble(0x3fcdf4c6ebebdaccL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:17399\0121=java.lang.Double:26886.5 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 13575.5, 2701.5, 1442.5, 10278.5, 7105.5, 7658.5, 15874.5]]\012",
        Z.run(T, 2, 3, 13, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u6a3f\u154b\u0b75\u507d\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u6b88\u0f52\u32da\u677c", "\u9959",
        29, 17370, 1419750058, -6056854775302103949L, -53386L, true, false, (char) 15670, (char) 32145,
        Double.longBitsToDouble(0x3fce7b1cec3d9534L), Double.longBitsToDouble(0x3fb07f04b6872fb8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Double:55379.95908268622 |a0=[D:[[28066.0, 28458.0, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[15286.5, 19304.0, 2731.0, 1442.5, 10278.5, 4289.5, 7658.5, 15874.5]]\0121=java.lang.Double:110759.91816537244 |a0=[I:[[56132, 56916, 56231, 56658, 55367, 57246, 55419, 56687]] |a1=[I:[[30573, 38608, 5462, 2885, 20557, 8579, 15317, 31749]]\012",
        Z.run(T, 2, 0, 1, 1, "\udb74\ude84\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\udbf5\udc9d\ud8fb\udc96\udb41\uddbe\udac5\ude25\uda8a\udd21\uda52\udc4e\u594f\udaf0\udc0e\uc314\udb01\udfe4\ud82b\udc28\ud97c\udc73", "\u779d\u9700\u1586\u0b75\u507d\u21b3\u3c05\u7c35\u6d14\u1c3f\u0949\u4d0f\u6afa\u6b88\u0f52\u8ec4\u5bba", "\u9959\ud968\udc27\uda4e\udce6\udaa5\udfa6\udb85\uddb7\ud981\udc27\uda99\udf78\udb04\udca2\uda33\udf95\ud920\udffd\ud88a\udc96\ud8bc\ude0d\udaff\udd7a\ud8db\udeb8\udb5a\udd76\udb8a\uddf8\udbf2\udcc1\ue59c\ud987\udec5\udb83\udda8",
        8, 24194, -1025160470, -4572858289358779951L, -989L, false, false, (char) 6046, (char) 11646,
        Double.longBitsToDouble(0x3fe71ec11c2d5f2aL), Double.longBitsToDouble(0x3fdfa56d6d85acdaL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:52325.589203562726 |a0=[D:[[27954.5, 28382.0, 28115.5, 28331.0, 27693.0, 28495.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 11307.5, 17870.0, 1442.5, 10278.5, 7105.5, 7658.5, 15874.5]]\0121=java.lang.Double:26888.5 |a0=[D:[[27954.5, 28382.0, 28115.5, 28331.0, 27693.0, 28495.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 11307.5, 17870.0, 1442.5, 10278.5, 7105.5, 7658.5, 15874.5]]\012",
        Z.run(T, 2, 0, 13, 15, "\uda95\uddec\udbd7\udd86\ud88a\udece\ud8ab\udd9f\ud99b\udcac\uda45\ude3b\ud9ee\uddb0\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udb11\udf6c\uc314\udaf4\udce4\ud834\udecd\ud869\udf32", "\u533a\u5887\u8bcc\u0b75\u507d\u37b3\u3c05\u7c35\u6d14\u2472\u9deb\u5e8e\u6b1f\u1449\u0f52\u32da\u677c", "\u9959",
        29, 17370, 1419750058, -6056854775302103949L, -53386L, true, false, (char) 15670, (char) 31988,
        Double.longBitsToDouble(0x3fce7b1cf6d84ad4L), Double.longBitsToDouble(0x3fb07f04b6872fb8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 5, 1, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\uee41\ud965\udc4b\uda36\udf95\ud8b0\udd91\uda8a\udd21\uda52\udc4e\ud8c0\udf56\ud98b\udf10\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u6a3f\u154b\u0b75\u507d\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u6b88\ub763\u32da\u677c", "\u9959",
        29, 17370, 1419750058, -6056854775302103949L, -53386L, true, false, (char) 15670, (char) 32145,
        Double.longBitsToDouble(0x3fce7b1cf6d84ad4L), Double.longBitsToDouble(0x3fb07f04b6872fb8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Double:1.0284876919729073\0121=java.lang.Double:26886.5 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 13575.5, 2701.5, 1442.5, 10278.5, 7105.5, 7658.5, 15874.5]]\012",
        Z.run(T, 2, 10, 13, 6, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u6a3f\u154b\u0b75\u507d\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u6b88\u0f52\u32da\u677c", "\u9959",
        29, 82802, 1419750058, -6056854775302103949L, -53386L, true, false, (char) 15670, (char) 32145,
        Double.longBitsToDouble(0x3fce7b1cf6d84ad4L), Double.longBitsToDouble(0x3fb07f04b6872fb8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Long:2085653350158307438\0121=java.lang.Integer:284081 |a0=[I:[[55390, 56449, 56231, 56658, 55367, 57246, 55380, 56773]] |a1=[I:[[21258, 27151, 5403, 2885, 20557, 14211, 42034, 31914]]\012",
        Z.run(T, 2, 4, 12, 1, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud884\uddf5\ud99b\udcac\ud87a\udcc0\ud965\udc4b\uda61\udf2c\uda50\udc09\uda8a\udd21\uda52\udc4e\ud8c0\udfdb\udadf\ude10\uc314\udb01\udfe4\ud834\udecd\ud869\udf60", "\u533a\u6a3f\u154b\u0b75\u507d\u37b3\ua462\u7cda\u6d14\u2472\u09e9\u5f57\u6b1f\u6b88\u0f52\u434d\u97c3", "\u9959",
        44, 17370, 1419750058, 2085653350158259208L, 48230L, false, false, (char) 15670, (char) 32145,
        Double.longBitsToDouble(0x3fce7b1cf6d84ad4L), Double.longBitsToDouble(0x3fb07f04b6872fb8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 0, 5, "\ud88e\udcb1\udbdb\ude82\ud93b\udc0f\uda71\udff3\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb2b\udc7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u6a3f\u154b\u0b75\u507d\u37b3", "\udaf8\udc2e\ud9bd\udcd1\udb15\udc08\ud974\udcde\udac9\uded9\uda47\udf5d\ud80d\udca0\udbf6\udf83\ud9d8\udc50\udb09\udccf\udaca\udd7b\u9959\ud895\uddf1\uda4e\udce6\udaa5\udfa6\udaaa\ude55\ud853\udeb0\uda99\udf78\ud885\udec3\uda33\udf95\ud920\udffd\ud88a\udc96\ud8bc\ude0d\udaff\udd7a\ud8db\udeb8\uda0f\udfd1\udbb2\udcec\ud8f9\udcd4\udbe4\udfea\udb1b\udf74\ud8eb\udc0a\ud915\udce4\ud824\udd3c\udaaf\udd78\uda9e\udd10\udb0c\udcfc\ud9bc\udd74\ud9fd\udf8a",
        32, 5989, -312870152, -5180860815511575412L, -6485L, false, false, (char) 55973, (char) 15346,
        Double.longBitsToDouble(0x3fdf7f00975f4f66L), Double.longBitsToDouble(0x3fd87073fc96f45eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 7, 6, 3, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud904\udf84\ud964\udfd1\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uda7a\udc38\ud97c\udc5a\ud834\udecd\ud869\udf32", "\u533a\u6a3f\u154b\u0b75\u065b\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\uc681\u3599\ud41a\u9168\u32da\u677c", "\udb44\ude56",
        17, 45176, 1419750058, -6056854775352435597L, 40712L, false, true, (char) 15670, (char) 32145,
        Double.longBitsToDouble(0x3fb05af9ebd23ba8L), Double.longBitsToDouble(0x3fb07f04b6872fb8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 13, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\udb11\udd92\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udbbc\uddea\ud8f0\udcf2\udb08\udf9e\ud88f\udf8e\ud869\udf32", "\u8026\u7d1c\u4fbe\u9291\u0f2d\u36f7\u3c05\u02c8\u523a\u23ee\u09e9\u5f57\u6b1f\u0fae\u3607\u4d39\uc993", "\u9959\ud968\udc27",
        55, 93058, -1007568212, 2737487710986656599L, -70381L, true, true, (char) 32145, (char) 61914,
        Double.longBitsToDouble(0x3fd0eee66083f824L), Double.longBitsToDouble(0x3fe6872fbc9a8ea3L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Double:1.0284876919729073\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 10, 5, 16, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udaf9\ude1b\ud939\udc86\udaf5\udf03\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u6a3f\u4532\ucef1\u7427\u3786\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u6b88\u0f52\u32da\u677c", "\uda8b\udfd8",
        29, 42906, 1201646250, -6056860912810370029L, -53386L, true, false, (char) 15670, (char) 32078,
        Double.longBitsToDouble(0x3fce7b1cf6d84ad4L), Double.longBitsToDouble(0x3fb07f04b6872fb8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Long:-3250174284566392238\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 13, 15, "\udb8b\uddfb\ud82f\udfe8\ud877\udfce\ud8ab\udd9f", "\u8616", "\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uda75\uddb6\udab8\udd4b\udbf9\udef2\ud869\udf32",
        13, 50387, 156450861, -3250174284566487295L, 95057L, true, true, (char) 6851, (char) 60858,
        Double.longBitsToDouble(0x3fe93da4c6db3bd9L), Double.longBitsToDouble(0x3fcdf4c6ebebdaccL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Long:-5934023395946307312\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 13, 15, "\ud88e\udcb1", "\000", "\ud965\udc4b",
        45, 62994, -192769585, -5934023395946395816L, 88504L, false, true, (char) 5686, (char) 46016,
        Double.longBitsToDouble(0x3fb5e6b7265f9a98L), Double.longBitsToDouble(0x3fa6b2c4f0000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Long:-6056854775302157335\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 4, 7, 15, "\ud905\udf43\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\ud84b\udeca\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\uae9a\u1550\u0b75\u507d\u37b3\u3c05\u7c35\u6d14\u2472\u552b\u2763\u9af8\u6145\u0f52\u32da\u677c", "\u9959",
        29, 17370, 1419750058, -6056854775302103949L, -53386L, true, false, (char) 15670, (char) 32145,
        Double.longBitsToDouble(0x3fce7b1cf6d84ad4L), Double.longBitsToDouble(0x3fb07f04b6872fb8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Long:2891327836093407240\0121=java.lang.Integer:18145\012",
        Z.run(T, 2, 4, 3, 1, "\ud818\ude09\udbd7\udd82\ud864\ude84\udaef\udf3c\ud8f7\udc5b\ud8fc\udc0e\udade\ude3d\ud9c9\udc19\ud85a\uddd8\udac1\udc16\uda52\udc9d\ud8c0\udf56\udaf0\udc0e\ud953\udfe5\ud924\udd56\udb08\udc28\udbd6\udcdf", "\u533a\u6a3f\u1584\u0bbb\u507d\u2033\u3c05\u26cc\u7d1e\u2472\u9186\u5f57\u531e\u51c2\u82e0\u08f9\ub1ac\u56dc\u8766\ua8e2", "\uda1d\udda8\uda4f\udda1\ud977\udda7\ud805\udc92\udabc\udc57\uda36\uddfe\ud805\udea8\ud915\udfcc\ud8bc\ude0d\uda04\udcc5\ud933\uddf4\ud884\udf84\ud8b3\udff5\udab3\udf40\udb69\udfc1",
        26, 18119, 1273044734, 2891327836093346266L, 60974L, false, true, (char) 40173, (char) 26033,
        Double.longBitsToDouble(0x3fc1c11764f510c0L), Double.longBitsToDouble(0x3fe3a4962343ac34L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 0, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\000\ud965\udc4b\udb18\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4eX\000\udbec\udeb5", "\u0549\u0152\u9ccb", "",
        -5, -1000, 5047823, 9111063521481497704L, 14917L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd5fe1005163234L), Double.longBitsToDouble(0x3ecaa00000000000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Long:1808842928535409254\0121=java.lang.Double:30379.5 |a0=[D:[[27695.0, 28224.5]] |a1=[D:[[10145.0, 15395.0, 23691.5, 23120.5, 16876.5]]\012",
        Z.run(T, 2, 4, 11, 13, "\ud88e\udcb1", "\u4f72\u7876\ub947\ub4d1\u8409", "\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\udb17\udc0e\udb01\udfe4\ud834\udecd\ud84c\udc1a\ud88c\udd3d\ud90d\udd79\udaaa\udd48\ud9f3\udd0c\ud417\ud928\udc2d\ud9a3\udf5f\uda3a\udd4a\uda41\udd94\udaac\uddeb\udac6\ude95",
        20, 4047, -422989916, 1808842928535470731L, -61477L, true, false, (char) 63552, (char) 28776,
        Double.longBitsToDouble(0x3fe3397f62296fd2L), Double.longBitsToDouble(0x3fe7532da2aaddd6L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Long:784766576509112283\0121=java.lang.Integer:54813 |a0=[I:[[55390, 56449, 56231, 56658, 55367, 57246, 55419, 56687]] |a1=[I:[[30070, 33591, 1418, 2420, 20557, 14211, 15317, 31749]]\012",
        Z.run(T, 2, 2, 14, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\udac0\udcb6\udaef\udd80\ud9a1\udc88\udb02\udc2c\ud834\udecd\ud869\udf32", "\u75a6\u8367\u05ba\u09a4\u507d\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u4716\u6b88\u0f52\u0dda\ua7b6\u9fc7\u8766\u9f4a", "\ud8c0\udfae\udb85\uddb7\ud853\udeb0\uda99\udf78\udb04\udca2\uda33\udf95\ud920\udffd\ud88a\udc96\ud8bc\ude0d\udaff\udd7a\ud8db\udeb8\ud86b\udcbf\udae1\ude61\udb93\udddb\ud933\ude5e",
        46, 76669, 633592276, 784766576509020956L, 91327L, false, true, (char) 3172, (char) 51873,
        Double.longBitsToDouble(0x3fcd771de5698e00L), Double.longBitsToDouble(0x3fdf81341a54f788L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Double:155813.5 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27925.0, 28483.5]] |a1=[D:[[10629.0, 13575.5, 2701.5, 1442.5, 10278.5, 7105.5, 7658.5, 15874.5]]\012",
        Z.run(T, 2, 9, 11, 11, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\uda5a\udeb7\ud998\udd5f\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u6a3f\u154b\u0b75\u507d\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u6b88\u0f52\u32da\u677c", "\u9959",
        29, 17370, 1419750058, -6056854775302103949L, -53386L, true, false, (char) 15670, (char) 32145,
        Double.longBitsToDouble(0x3fce7b1cf6d84ad4L), Double.longBitsToDouble(0x3fb07f04b6872fb8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Long:7233694197772333692\0121=java.lang.Integer:90792\012",
        Z.run(T, 2, 4, 3, 15, "\ud8a8\ude82\udb91\udc75\udbde\udd25\udafd\ude48\uda3b\udc04\ud87c\ude5b\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud88e\uddbb\ud869\udff2", "\u1715\u6a50\u154b\u0b75\u507d\u1f98\u022e\u7c75\u6d14", "\ud89c\ude31\udbad\udc6a",
        55, 90737, -525298053, 7233694197772358622L, -24930L, true, false, (char) 47262, (char) 34944,
        Double.longBitsToDouble(0x3fe562a4fc73abf1L), Double.longBitsToDouble(0x3fec312fee85be5bL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Double:1.0373926364380632\012",
        Z.run(T, 1, 10, 13, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfd4\u231f", "\u5b52\u6361\ub0d3\uac30\u838e\u87a6\u8c5f\uafa2\ubdff\u2557\u6a9f\u02a6\uad22\u40fa\u6b9b\u154b\uc3a5\ua4e2\u37b3\u3c05\u7c35\u385f\uc1b6\u608f\ua830\u6f84\ua502\ua980\u2a36", "\udbe6\udf30",
        39, 19769, 490854124, 318611122262489613L, -70381L, false, false, (char) 24571, (char) 46643,
        Double.longBitsToDouble(0x3fd172ab8c83f824L), Double.longBitsToDouble(0x3fee65c4269e004dL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Long:-8363769155338850395\0121=java.lang.Long:-8363769155338850395\012",
        Z.run(T, 2, 2, 2, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u6a3f\u154b\u0b75\u507d\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u6b88\u0f52\u32da\u1112", "\u9959\ud968\udc27\uda4e\udce6\udaa5\udfa6\udb85\uddb7\ud853\udeb0\uda99\udf78\udb04\udca2\uda33\udf95\ud920\udffd\ud88a\udc96\ud8bc\ude0d\udaff\udd7a\ud8db\udeb8",
        23, 20876, -472986341, -8363769155338809657L, -40738L, true, false, (char) 42831, (char) 33551,
        Double.longBitsToDouble(0x3fc2e397b0f2db24L), Double.longBitsToDouble(0x3f9c03e98aec8da0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Double:21517.5 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 13575.5, 16620.0, 23665.0, 27557.5, 7105.5, 7658.5, 15874.5]]\0121=java.lang.Double:21517.5 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 13575.5, 16620.0, 23665.0, 27557.5, 7105.5, 7658.5, 15874.5]]\012",
        Z.run(T, 2, 13, 13, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud969\udc91", "\u533a\u6a3f\u8208\ub912\ud77b\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u3ead\u6167\ud3f7\u32da\u677c", "\u9959",
        29, 17370, 1419750058, -6056854775302103949L, -53386L, true, false, (char) 15670, (char) 32145,
        Double.longBitsToDouble(0x3fce7b1cf6d84ad4L), Double.longBitsToDouble(0x3fb07f04b6872fb8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 6, 16, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u6a3f\u154b\u0b75\u507d\u37b3\u3c05\u7c35\u6d14\uad73\u09c1\u5f57\u6b1f\u6b88\u0f52\u32da\u677c", "\u9959",
        29, 17370, 1419750058, -6056854775302103949L, -56562L, true, false, (char) 15670, (char) 32145,
        Double.longBitsToDouble(0x3fce7b1cf6d84ad4L), Double.longBitsToDouble(0x3fb07f04b6872fb8L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Long:-5162188270871137396\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 1, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfceC\ud99a\udff0\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a", "\ud928\udc2d",
        5, 47639, 334273640, -5162188270871101669L, -35727L, false, false, (char) 0, (char) 39844,
        Double.longBitsToDouble(0x3fdf951d5cf65a04L), Double.longBitsToDouble(0x3f49b60f79918c00L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 2, "\000\000\ud877\udfce\udbcb\udf50\000\000\ud957\ude6b\udb41\ude7b\udac5\ude25\u00cf\uda52\udc25\ud8c0\udf56\udaf0\udc0e\u930e\udb01\udfe4:\ud854\ude0a", "-\000\uce49\u0b75\u507d\u37b3\000\000\000\u0596\u09e9\u5f57\u6b1f\u6b88\u0f52\u32da\u677c", "\ud990\udece",
        38, -1000, 1409286144, -6056854775302103949L, -53386L, true, false, (char) 15670, (char) 31972,
        Double.longBitsToDouble(0x3fce7b1cf6d84ad4L), Double.longBitsToDouble(0x3fb07f0480000000L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Double:11977.54861188215 |a0=[D:[[23940.5, 27868.5, 28383.5, 27683.5, 28623.0]] |a1=[D:[[23192.0, 26490.0, 19037.5, 20471.0, 27345.0, 2015.5, 17339.0, 17872.0]]\0121=java.lang.Double:19963.5 |a0=[D:[[23940.5, 27868.5, 28383.5, 27683.5, 28623.0]] |a1=[D:[[23192.0, 26490.0, 19037.5, 20471.0, 27345.0, 2015.5, 17339.0, 17872.0]]\012",
        Z.run(T, 2, 16, 11, 10, "\ubb39\ud9e9\uddef\ud877\udfce", "\ub560\ucf24\u94eb\ua01e\ud5d2\u0fef\u87a6\u8bd0\u5fa5\u045e\u5827\ud684\u0152\u7556\u38ee\u43ca\u2cff\u05ea\ucacf\u37b3\u3c05\u6659\u25b0\ub84e\u09e9\u6404\u6b1f\u6b88\u0f52\u32da\u677c\uc397\ud5f5\u3cd7\u6c97\u5a9d\uc70c\ua3bf", "\udb04\udca2\udaa2\ude8b\ud8bd\uddea\ud882\udc2c\ud94e\udd05",
        -1, 98730, 1865727664, 8609383308483264714L, 74874L, true, false, (char) 6070, (char) 33041,
        Double.longBitsToDouble(0x3fe7ee1fe10e99e8L), Double.longBitsToDouble(0x3fea52fefdfdaf31L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Long:-8251623426779150064\0121=java.lang.Long:-8251623426779150064\012",
        Z.run(T, 2, 4, 4, 10, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud97d\udcac\ud8d2\udc60\ud965\udc4b\u0e7d\udac5\ude25\ud83f\udd5c\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u5ec1\u69e3\u154b\u0b75\u240b\u7970\u3c05\u3e95\uba8f\u2472\u09e9\uc5f3\u0439\u8977\u0f13\ub1aa\ub87a", "\u9959\ud968\udc27\uda4e\udce6\udaa5\udfa6",
        9, 6055, 1901873323, -8251623426779151440L, 1376L, true, false, (char) 59498, (char) 44115,
        Double.longBitsToDouble(0x3fe6872fbd0363a9L), Double.longBitsToDouble(0x3fd553c43258e630L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 13, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud87b\ude9f\ud99b\udcac\ue5bf\000\uda08\udc03\000\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\u2d3a\000", "\u533a", "\ud927\udffc\ud9a3\udf5f\uda3a\udd4a\u9c68\ud89d\udce5\udac6\ude95\ud9e8\udd90\udaa9\udc62\ud974\udd34\udac9\uded9\uda47\udf5d\ud80d\udca0\udbf6\udf83",
        32, 3526, -1712562078, 59350273574043648L, -78154L, false, false, (char) 2149, (char) 33108,
        Double.longBitsToDouble(0x3fdeabe5b89bd49eL), Double.longBitsToDouble(0x3fd3faff75c9d55aL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Double:35183.68562274282 |a0=[I:[[55755, 56754, 55356, 56417]] |a1=[I:[[42152, 47383, 34278, 33597]]\0121=java.lang.Integer:22820 |a0=[I:[[55755, 56754, 55356, 56417]] |a1=[I:[[42152, 47383, 34278, 33597]]\012",
        Z.run(T, 2, 1, 14, 15, "\ud9fb\udde2\ud86c\udc91", "\ua4d8\ub947\u8616\u836d", "\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314",
        33, 13530, -1696836312, -913148429548820533L, -61818L, true, true, (char) 4735, (char) 49648,
        Double.longBitsToDouble(0x3fe6b8b26c68fb22L), Double.longBitsToDouble(0x3fd1e13ece3770b8L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Long:60097704306520792\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 16, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ubf43\ud960\udcf0\ud87a\udcc0\ud965\udc4b\udb41\ude7b\uda2a\udc17\udbd5\udf4a\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\000", "\ud8f8\udffc\ud9a3\udf5f\uda3a\udd4a\uda41\udd94\ud89d\udce5\udac6\ude95\ud9e8\udd90",
        17, -1000, 421154048, 60097704306602489L, -81697L, false, true, (char) 28776, (char) 29870,
        Double.longBitsToDouble(0x3fe14b7e90000000L), Double.longBitsToDouble(0x3fe0000002ac549fL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 9, 9, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud871\ude65\ud9c0\udc7b\ud965\udc4b\udb86\udc7f\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\ucaee\u6a3f\u154b\u0b75\u507d\u82b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u6b88\u0f52\u32da\u677c", "\u9959",
        29, 17370, 1419750058, -6056854775302103949L, -53386L, true, false, (char) 60726, (char) 42519,
        Double.longBitsToDouble(0x3fce7b1cf6d84ad4L), Double.longBitsToDouble(0x3fb07f04b6872fb8L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 13, 9, "\ud8b8\udd72\udae8\udca9\ud9a4\udc35\udb1d\udee9\ud8f7\udda4\uda4a\udea6\udafc\udd36\udb3e\udfe0\udac5\ude25", "\u87a6\uc49c", "\udb17\udfef\ud981\udd75\udb32\ude03\udb60\udec6\udaaa\udcb9\ud9f3\udd0c\ud417\ud928\udc2d\ud9a3\udf5f",
        -1, 63640, -1953600581, -4668207823911506852L, -33178L, true, true, (char) 39844, (char) 17315,
        Double.longBitsToDouble(0x3fbecb40840e6ac8L), Double.longBitsToDouble(0x3feef32318621006L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 13, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u57ec\u248f\u154b\u0b75\u507d\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u6b88\u0f52\u32da\u677c\ud3d1\u8312\u9f4a\uaab3\u7a6c\uc6f5\u570c\u7979\u058a", "\ud920\udffd\ud88a\udc96\ud8bc\ude0d\udaff\udd7a\ud8db\udeb8\ud84d\udf21\uda04\uddaf\udb12\udcbc\ud894\ude23",
        13, 97056, -712458180, 2056059112206608828L, -81011L, true, true, (char) 61924, (char) 51587,
        Double.longBitsToDouble(0x3fe348c448668c1dL), Double.longBitsToDouble(0x3fe7e4c05c5ee899L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Integer:4043\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 3, 6, 16, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\udb9b\uddac\ud87a\udc8f\ud965\udc4b\ud8ab\udd60\udac5\ude25\uda8a\udd21\uda52\udc4e\uda5b\ude4c\uda2a\udd5b\udae8\udd83\udb01\udfe4\ud834\udecd\ud869\udf32", "\ua7bf\u98c2\u154b\u740b\u5d5b\ud0f1\u6a45\u7ee0\u6d14\u2472\u09e9\u5f57\u6b1f\u6b88\u0f52\u32da\u677c", "\u98d0",
        28, 4015, 1419750058, 2878286885400960115L, -53386L, true, false, (char) 15670, (char) 32145,
        Double.longBitsToDouble(0x3fce7b1cf6d84ad4L), Double.longBitsToDouble(0x3fe6d7943848e580L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Long:-4328035470603389816\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 4, 9, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u6a3f\u154b\u0b75\u507d\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u70c0\u0c2e\u9514\ub643\u6764", "\u9959",
        29, 17370, 1419750058, -4328035470603435657L, 45841L, true, false, (char) 15670, (char) 32145,
        Double.longBitsToDouble(0x3f8c1dcf6d84ad40L), Double.longBitsToDouble(0x3fb07f04b6872fb8L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Long:5896762821382014842\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 15, 15, "\udbcc\udc1a\ud880\uddb1\ud877\udff9\udb12\udf83", "\ub4b8\u68ca\u4779\uac30\ucf09\ub8dc\u3810\u5cfa\u9570\u9c56\u90e4\u738a\u1efc\ua476\u6a3f\u06c7\ud365\u7a28\ua9d8\u9c72", "\udac0\udc6b",
        42, 46145, 1310329741, 5896762821382064437L, -49595L, true, false, (char) 13943, (char) 46823,
        Double.longBitsToDouble(0x3fe14b80faead5b4L), Double.longBitsToDouble(0x3fe556eeb2ac549fL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Double:51398.705718140416 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 13575.5, 1102.0, 18530.0, 10662.5, 7105.5, 7658.5, 15874.5]]\0121=java.lang.Double:51398.705718140416 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 13575.5, 1102.0, 18530.0, 10662.5, 7105.5, 7658.5, 15874.5]]\012",
        Z.run(T, 2, 16, 0, 1, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud83a\ude51\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\ud93d\udcf7\udb79\ude37\ud834\udecd\ud869\udf32", "\u533a\u6a3f\u08cc\u90f4\u537d\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u6b88\u56da\u8697\ucb55", "\uda69\udedb",
        18, 17370, 1419750058, -4399530112878425607L, -89783L, true, false, (char) 15670, (char) 32145,
        Double.longBitsToDouble(0x3fe275d8d898c9b5L), Double.longBitsToDouble(0x3fe5f9f48ed0e59aL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Double:157197.0 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[340.0, 13575.5, 2701.5, 1442.5, 10278.5, -24.0, 23338.0, 15874.5]]\0121=java.lang.Long:1\012",
        Z.run(T, 2, 11, 5, 10, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud9ff\uddc2\ud965\udc4b\udb41\ude7b\udac5\ude25\uda90\udcd6\uda52\udc4e\ud8c0\udf56\udabf\ude0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u02d8\u6a3f\u154b\u0b75\u507d\000\ub684\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u6b88\u0f52\u32da\u677c", "\000",
        58, -1000, 1419706368, -6056854775302103949L, 60449L, false, false, (char) 56909, (char) 59498,
        Double.longBitsToDouble(0x3e48000000000000L), Double.longBitsToDouble(0x3fe65b84d1b25beeL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 12, 0, 2, "\udab9\ude45\ud80b\ude4c\ud877\udfce\ud891\udc13\ud975\udc3c\ud9f9\udcde\ud952\udf00\udb41\ude8a\udac5\ude25\uda8a\udd21\uda61\udf4e\ud8c0\udf56", "\u2436\uc14c\u2c6a", "\udaaa\udcb9\ud86e\udf8a\ud82b\udf0e\udb8b\ude89\ud9a3\udf5f\uda3a\udd4a\udb69\udcda\ud89d\udce5\udac6\ude95\ud9e8\udd90\udaa9\udc62\ud974\udd34\udac9\uded9\uda47\udf5d\ud80d\udca0\udb0a\ude2c\u7ce4",
        25, 512, 2017478189, -7936684343322848663L, 19276L, false, false, (char) 16941, (char) 6133,
        Double.longBitsToDouble(0x3fa2750debd44dd0L), Double.longBitsToDouble(0x3fe9c85df64ebbd3L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void\0121=java.lang.Long:1\012",
        Z.run(T, 2, 8, 5, 14, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf69\ud8d8\udfa3\uc314\udb01\udfe4\ud834\udecd\ud8c4\udd7f", "\u533a\u6a3f", "\ud9a4\udc18\uda3a\udd4a\uda41\udd94\ud89d\udce5\udac6\ude95\ud9e8\udd90\udaa9\udc62\ud974\udd34\udb27\udee8\ud8f3\udf01\ud80d\udc53\udbf6\udf83\uda05\ude6b\udb09\udccf\u169a\u9959\ud968\udc27\uda4e\udce6\ud823\ude66\udb6a\udfcf\udbe2\ude36",
        19, -193, 429539405, -1536416794865331484L, 85607L, false, false, (char) 5320, (char) 869,
        Double.longBitsToDouble(0x3fde6884db491dd6L), Double.longBitsToDouble(0x3fc701886e2563d4L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Double:103043.61917168865 |a0=[I:[[55390, 56449, 55424, 56381, 55367, 57246, 55419, 56687]] |a1=[I:[[49778, 52360, 5403, 8574, 14135, 14211, 15317, 31749]]\0121=java.lang.Double:103043.61917168865 |a0=[I:[[55390, 56449, 55424, 56381, 55367, 57246, 55419, 56687]] |a1=[I:[[49778, 52360, 5403, 8574, 14135, 14211, 15317, 31749]]\012",
        Z.run(T, 2, 1, 1, 10, "\ud88e\udcb1\ud8b0\udc6d\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\ud93d\udec0\uda8a\udd21\uda52\udc4e\udbb0\udfce\udb60\ude81\ud803\udcdc\ud92c\ude49\ud8b3\udc1e\ud869\udf32", "\uc2a2\uccb8\u154b\u21ae\u3767\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\ub140\u29f7\ubd04\u0f52\u81f7\u6dcc", "\udb2f\udd9e\ud968\udc27\uda4e\udce6",
        33, 40604, 637361267, -4090012457156871497L, 1695L, false, false, (char) 50537, (char) 19142,
        Double.longBitsToDouble(0x3fb05c3fa9872fb8L), Double.longBitsToDouble(0x3feb777930192ab2L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Double:56578.099506346094 |a0=[D:[[27695.0, 28305.5, 28115.5, 28329.0, 28016.5, 28347.0, 27697.0, 28393.5]] |a1=[D:[[10629.0, 13575.5, 2701.5, 1442.5, 10278.5, 7105.5, 7658.5, 15874.5]]\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 16, 5, 10, "\ud88e\udd53\udbd7\udd82\udb11\udda6\ud892\ude03\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udb98\ude1d\uda8a\udcb1\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc33c\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u6a3f\u154b\u0b75\u507d\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u6b88\u0f52\u32da\u677c", "\ud938\udf43",
        -5, -220, 1419750058, -6057055985929986957L, 60449L, false, false, (char) 39273, (char) 59498,
        Double.longBitsToDouble(0x3fb07f04b6872fb8L), Double.longBitsToDouble(0x3fe65b84d1b25beeL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Long:2719205998007568490\0121=java.lang.Long:2719205998007568490\012",
        Z.run(T, 2, 4, 4, 9, "\ud88e\udcb1\ud866\udf49\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud82d\udc4f\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb3e\udccb\ud834\udecd\ud869\udf32", "\u5335\u6a3f\ucc1a", "\uda3a\udd4a\uda41\udd94\ud89d\udce5\udb9a\ude9f\ud9e8\udd90\udaa9\udc62\ud974\udd34\udac9\uded9\uda47\udf5d\ud80d\udca0\udbf6\udf83\ud817\ude74\udb09\udccf\u3a5e\u9959\ud968\udc27",
        40, 93058, -1410221396, 2719205998007638871L, -70381L, true, true, (char) 45721, (char) 61563,
        Double.longBitsToDouble(0x3fdb612b5083f824L), Double.longBitsToDouble(0x3fe6872fbbb590c2L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[D:[[]]\0121=java.lang.Double:0.0 |a0=[D:[[]]\012",
        Z.run(T, 2, 0, 13, 11, "", "", "\u00bc\000\000\ud8d2\ude78\udac5\ude25\u91cf\000\000\uc200\000\udbab\ude95\000\000",
        -5, -1000, 0, -3314649326578426111L, 96608L, false, false, (char) 40039, (char) 19722,
        Double.longBitsToDouble(0x3fe8ddc2e6db00b7L), Double.longBitsToDouble(0x3fcdf4c6ebebdaccL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Integer:93015\0121=java.lang.Integer:93015\012",
        Z.run(T, 2, 3, 3, 16, "\ud947\ude6c\ud866\udf49\ud877\udfce\uda0c\ude70\ud986\udedf\uda2e\ude5a\ud855\udeb0\ud8dc\ude21\uda43\udee7\ud85e\udc27\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\udb27\udd75\udb6a\udc57\ud834\udecd\ud869\udf32", "\u5335\u6a3f\ucc1a", "\uda3a\udd4a\uda41\udd94\ud89d\udce5\udb9a\ude9f\ud9e8\udd90\udaa9\udc62\ud974\udd34\udac9\uded9\uda47\udf5d\udb6e\uddf9\uda9d\udc07\uf4f2\udb09\udccf\udbcb\udd3b\uda67\udce0\ud8e0\udc09",
        49, 92966, -317474070, 5805674984060808780L, -70381L, true, true, (char) 32145, (char) 61914,
        Double.longBitsToDouble(0x3fdb612b5083f824L), Double.longBitsToDouble(0x3fe6872fbbb590c2L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Long:8057743211784007903\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 14, 15, "\ud88e\udcb1\ud866\udf49\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud82d\udc4f\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb75\udfde\ud834\udecd\ud869\udf32", "\u5335", "\ud9e1\udf50\ud9ee\ude4a\uda3a\udc9a\uda41\udd94\ud89d\udce5\udb9a\ude9f\ud9e8\udd90\udaa9\udc62\ud974\udd34\udac9\uded9\uda47\udf5d\ud80d\udca0\udbf6\udf83",
        12, 3526, -1712562078, 8057743211784086057L, -78154L, false, false, (char) 31076, (char) 33043,
        Double.longBitsToDouble(0x3fdeabe5b89bd49eL), Double.longBitsToDouble(0x3fd3faff75c9d55aL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Long:-5766986535841894996\0121=java.lang.Double:0.0 |a0=[D:[[]] |a1=[D:[[16541.0]]\012",
        Z.run(T, 2, 4, 13, 11, "", "\u816a", "\ud87a\udcc0\ud82d\udc4f\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb75\udfde\ud834\udecd\ud869\udf32\udaa8\udc53\ud87b\udf8d\udaaa\udcb4\ud9f3\udd0c\ud8ed\udc13\ud9c4\udf61\000\000\uda41\udd94\ud89d\udce5\udb9a\ude9f\ud9e8\udd90\udaa9\udc62\ud974\udd34\udac9\uded9\uda47\udf5d\ud80d\udca0\udbf6\udf83\ud817\ude74\udb09\udccf\u3a5e\u9959\ud968\udc27\uda4e\udce6\udaa5\udfa6\udb85\uddb7",
        -5, 94903, -369098518, -5766986535841985217L, 90221L, false, true, (char) 44115, (char) 5320,
        Double.longBitsToDouble(0x3fedac86110162dbL), Double.longBitsToDouble(0x3fdb6dd3bd2557b6L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Double:1.2741930320675234\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 13, 15, "\ud971\udf4d\udbe8\udca5\udae3\udda3\udaf0\udddb\ud89b\udcee\ue9d3\ud965\udc4b\ud9b5\ude50\uda1f\udd7d\u7485\uda52\udc4e\ud950\udc9f\udaf0\udc0e\uda60\udf4c\ud94b\ude9f\ud840\udedb\udb30\udc75", "\u533a\uba6f\u154b\u5712\u511a\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u4b62\u13e3\u32da\u677c\u56dc\u0871", "\uda4e\udce6\udaa5\udfa6\udb85\uddb7\ud859\udcb0",
        3, -486, -1342731187, -1536416596796927260L, 45334L, true, false, (char) 32442, (char) 24353,
        Double.longBitsToDouble(0x3fe72fba59cc38bfL), Double.longBitsToDouble(0x3fe5c28af6481523L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 13, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\ud9ac\ude50\uda1f\udd7d\u7485\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\u7d4f\ud91c\udf4f\ud869\udf32", "\u533a\u6a3f\u154b\u5712\u511a\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u4b62\u13e3\u32da\u677c", "\udaba\udf40",
        14, 6602, 27863626, -6056854775302103949L, -53386L, true, false, (char) 15670, (char) 10642,
        Double.longBitsToDouble(0x3febf2177242ea38L), Double.longBitsToDouble(0x3fd964d02aa32770L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 13, 8, "\ud88e\udcb1", "\u664b", "\ud94b\udc71",
        45, 59403, 1691486134, -6196266733179418147L, 5302L, false, false, (char) 54569, (char) 46016,
        Double.longBitsToDouble(0x3fdf39adcf97e624L), Double.longBitsToDouble(0x3fa6b2c4fb509530L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Integer:267248 |a0=[I:[[55390, 56449, 56231, 56658, 55367, 57246, 55419, 56687]] |a1=[I:[[21258, 27151, 5403, 2885, 23439, 22571, 47743, 31749]]\0121=java.lang.Integer:267248 |a0=[I:[[55390, 56449, 56231, 56658, 55367, 57246, 55419, 56687]] |a1=[I:[[21258, 27151, 5403, 2885, 23439, 22571, 47743, 31749]]\012",
        Z.run(T, 2, 12, 12, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud86d\udd7f\udaf0\udc0e\uc314\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u6a3f\u154b\u0b75\u5bbf\u585b\ubaaf\u7c35\u6d14\u2472\u0cdf\u3ef2\u2162\u0bf2\u0f52\u32da\u677c", "\u9959",
        29, 17370, 1419750058, -6056854775302103949L, -53386L, false, true, (char) 6923, (char) 53422,
        Double.longBitsToDouble(0x3fce7b1cec3d9534L), Double.longBitsToDouble(0x3fde005a4da1cb3eL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Long:6353724594615169264\0121=java.lang.Long:6353724594615169264\012",
        Z.run(T, 2, 4, 4, 16, "\ud88e\udd3e\udbd7\uddc0\ud877\udfce\ud884\uddf5\ud99b\udcac\ud84d\uddc0\ud9ed\udc35\uda72\udfa9\uda50\udc09\uda6c\udc96", "\u49e6\uc756\u13fe\u6696\ua085\u0152", "\ud9f3\udd0c\ud417\ud928\udc2d\ud9bd\ude5f\udacc\udcb3",
        1, 51179, 990527259, 6353724594615157999L, 11265L, true, false, (char) 17358, (char) 53549,
        Double.longBitsToDouble(0x3fef33241e908b23L), Double.longBitsToDouble(0x3fde310ff9a0fdd8L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 3, 6, "\ud870\udc01\udbdb\ude82", "\u35bb", "\uda2c\udd7c\ud891\udccd\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udbef\udf0f\uc348\udb01\udfe4\ud834\udecd\udb46\ude60\ud8ef\ude53\udb60\udec6\udaaa\udcb9\ud9f3\udd0c\ud417\ud928\udc2d",
        19, 38329, 334273638, -5090130677517041893L, 1136L, false, false, (char) 12110, (char) 39844,
        Double.longBitsToDouble(0x3fdf951d5cf65a04L), Double.longBitsToDouble(0x3fe3366d83de6463L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a0=[I:[[]] |a1=[I:[[34023]]\0121=java.lang.Double:0.0 |a0=[D:[[]] |a1=[D:[[17011.5]]\012",
        Z.run(T, 2, 12, 0, 16, "", "\u8517", "\ud87a\udcc0\ud965\udc4b\udb2b\udc7b\udac5\ude25\uda8a\udd21\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uc314\udb01\udfe4\u2d3a\ud87a\uddfd\ud8ef\ude53\udb60\udec6\udaaa\udcb9\ud9f3\udd0c\ud417\ud928\udc2d\ud9a3\udf5f\uda3a\udd4a\uda41\udd94\ud8fb\udcf4\udae8\udd2e\ud9bd\udcd1\udb15\udc08\ud974\udcde\udac9\uded9\ub751\ud80d\udca0\udbf6\udf83\ud9d8\udc50\u93de\udaca\udd7b\u9959\ud895\uddf1",
        40, 93058, -2088803924, 2737445796400814935L, -70381L, true, true, (char) 32145, (char) 61914,
        Double.longBitsToDouble(0x3fdb612b5083f824L), Double.longBitsToDouble(0x3fe6872fbe951112L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Double:37234.5 |a0=[D:[[28089.0, 28416.0]] |a1=[D:[[8793.5, 10477.0]]\0121=java.lang.Double:37234.5 |a0=[D:[[28089.0, 28416.0]] |a1=[D:[[8793.5, 10477.0]]\012",
        Z.run(T, 2, 11, 11, 7, "\udba2\ude30", "\u44e3\u520a", "\udb41\ude7b\ud807\uddca\uda8a\udcd1\uda52\udc4e\ud8c0\udf56\udaf0\udc0e\uda75\uddb6\udab8\udd4b\ud87d\udf95\ud861\udce1\udb37\udf97\udb60\udec6\udaaa\udcb9\ud9f3\udd0c\ud417\ud985\ude9e",
        5, 47639, -5727150, -5472823511412568827L, -35727L, false, false, (char) 12622, (char) 38484,
        Double.longBitsToDouble(0x3fea3f5b89057186L), Double.longBitsToDouble(0x3fd7b454fa357916L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Long:2065427609959326174\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 4, 7, 15, "\ud905\udf43\udbd7\udd82\ud877\udfce\ud96d\ude41\ud900\udf4a\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude25\udbc2\udd1d\ud84b\udeca\ud8c0\udf56\udaf0\udc0e\uc314\ud87f\udd79\ud834\udecd\ud869\udf32", "\u533a\u627c\u9921\u0b75\u18be", "\ud89d\udce5\udac6\ude95\ud9e8\udd90\ud931\udc26\udaf0\ude0e\ud89f\udc8f\udb88\udc9a\ud80d\udca0\udbf6\udf83\uda05\ude6b\udb09\udccf\u3a5e\u9959\ud968\udc27\uda4e\udce6\udaa5\udfa6\udb85\uddb7\ud853\udeb0",
        3, -563, -666334131, 2065427609959240392L, 85782L, true, false, (char) 5095, (char) 52798,
        Double.longBitsToDouble(0x3fc9684f124b70a4L), Double.longBitsToDouble(0x3fe875b55cfa0992L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Integer:54812 |a0=[I:[[55401, 56495, 56058, 57232, 55676, 56475, 55419, 56738]] |a1=[I:[[30070, 33591, 1418, 2420, 20557, 14211, 21582, 31749]]\0121=java.lang.Integer:54812 |a0=[I:[[55401, 56495, 56058, 57232, 55676, 56475, 55419, 56738]] |a1=[I:[[30070, 33591, 1418, 2420, 20557, 14211, 21582, 31749]]\012",
        Z.run(T, 2, 14, 14, 15, "\ud899\udcdf\udb2a\udfc0\ud9ac\udccb\ud8ab\uddd2\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\ud803\udc83\u190f\uda52\udc4e\udac0\udcb6\udaef\udd80\ud8db\uddc5\ud92d\udfb3\ud80f\udd68\ud869\udf32", "\u75a6\u8367\u05ba\u09a4\u507d\u37b3\u547e\u7c35\u6d14\u2472\u09e9\u9e3f\u4716\u8dfa\u2e8a\u2fda\ua7b6\u9fc7\u8766\u9f4a", "\ud8b9\udd7b\udb85\uddb7\ud853\udeb0\udaae\uddb2\udb09\udc1e\uda33\udf95\ud920\udffd\ud88a\udc96\ud8bc\ude0d\udaff\udd7a\ud8db\udeb8\ud86b\udcbf\udae1\ude61\ud8ca\udc0c\ud8fc\udc96",
        46, 76669, 1892735444, 784946282235652892L, 91327L, false, true, (char) 3035, (char) 37027,
        Double.longBitsToDouble(0x3fbbb88f4ad7bac8L), Double.longBitsToDouble(0x3fe8709a0d2a7bcdL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Integer:-1\0121=java.lang.Integer:-1\012",
        Z.run(T, 2, 9, 9, 6, "\ud8bf\udcb1\ud9f8\udd92\ud80d\ude9e\uda5a\udeb7\ud998\udd5f\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udaff\udec8\uda8a\udd21\uda76\udc7f\ud86b\udffa\ud93d\udc36\udb33\ude9f\udb01\udfb5\ud834\udecd\udb8e\udc4a", "\u533a\u6a3f\u154b", "\udba1\ude9f\uda41\udd96\uda8b\udf16\udae8\udfb7\ud9e8\udd90\udaa9\udc62\ud974\udd34\udac9\uded9\uda47\udf5d\udafd\udc19\ud862\udd99\ud9a5\ude11",
        1, 93922, 1876089538, 7328660790042841834L, 13324L, true, false, (char) 33108, (char) 41552,
        Double.longBitsToDouble(0x3fd4d845da7f5f30L), Double.longBitsToDouble(0x3fe7275568f3d8e7L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 6, 6, 2, "\000\000\ud877\udfce\udbcb\udf50\000\000\ud957\ude6b\udb41\ude7b\udac5\ude25\u00cf\uda52\udc25\ud8c0\udf56\udaf0\udc0e\udab8\udf5a\udb01\udfe4:\ud854\ude0a", "-\000\uce49\u0b75\u507d\u37b3\000\000\000\u0596\u09e9\u511f\u6b1f\u6b88\u0f52\u32da\u677c", "\ud990\udece",
        38, -1000, 1409286144, -6056854775302103949L, -53386L, true, false, (char) 15670, (char) 31972,
        Double.longBitsToDouble(0x3fce7b1cf6d84ad4L), Double.longBitsToDouble(0x3fb07f0480000000L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:0.0 |a0=[D:[[]]\012",
        Z.run(T, 2, 6, 13, 2, "", "", "\000\000\udac6\udc02\000\ud85d\ude0e\u00cf\uda52\udc25\u0758\u00d0\000\000\000\ud854\ude0a",
        13, -797, 0, 0L, 95057L, true, true, (char) 32369, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fcdf4c6ebebdaccL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Double:155458.0 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 13575.5, 2701.5, 1442.5, 10278.5, 7105.5, 7658.5, 15874.5]]\0121=java.lang.Double:155458.0 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 13575.5, 2701.5, 1442.5, 10278.5, 7105.5, 7658.5, 15874.5]]\012",
        Z.run(T, 2, 11, 11, 15, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udb9c\udc82\uda8a\udd21\uda52\udc4e\ud8c0\udf56\ud8a4\udcc6\udb9d\udea9\ud96b\udca5\udbae\udfda\ud869\udf32", "\u533a\u6a3f\u154b\u0b75\u507d\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u70c0\u0c2e\u9514\ub643\u6764", "\u9959",
        29, 17370, 1419750058, -4328035470603435657L, 45841L, true, false, (char) 15670, (char) 32145,
        Double.longBitsToDouble(0x3f8c1dcf6d84ad40L), Double.longBitsToDouble(0x3fb07f04b6872fb8L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 7, 7, 14, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udaaa\udd10\uda47\uddc9\ud823\udc84\uda52\udc4e\ud8c0\udf69\ud8d8\udfa3\uc314\udb01\udfe4\ud834\udecd\ud8c4\udd7f", "\u533a\u6a3f", "\ud9a4\udc18\uda3a\udd4a\uda41\udd94\ud89d\udce5\udac6\ude95\ud8bb\udc19\udaa8\udf9b\ud974\udd34\udb27\udee8\ud8f3\udf01\ud80d\udc53\udbf6\udf83\uda05\ude6b\udb09\udccf\u169a\u9959\ud968\udc27\uda4e\udce6\ud823\ude66\udb6a\udfcf\udbe2\ude36",
        19, -193, 429539405, -1536416794865331484L, 85607L, false, false, (char) 5320, (char) 869,
        Double.longBitsToDouble(0x3fde6884db491dd6L), Double.longBitsToDouble(0x3fc701886e2563d4L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 8, 8, 14, "\ud88e\udcb1\udbd7\udd82\ud877\udffe\ud8ab\udd9f\ud99b\udcac\ud87a\udcc0\ud965\udc4b\udb41\ude7b\udac5\ude80\uda8a\udd21\u266c\ud8eb\udc58\ud8d8\udfa3\uc314\ud976\udfeb\ud853\udf56\ud8c4\udd7f", "\u533a\u6a3f", "\ud9a4\udc18\uda3a\udd4a\uda41\udd94\ud9ca\uded1\udac6\udf4c\ud9e8\udd90\udaa9\udc62\ud974\udd34\udb27\udee8\ud97f\udf07\ud919\udfba\udbf6\udf0b\uda05\ude6b\udb09\udccf\u169a\u9959\ud968\udc27\uda4e\udce6\ud823\ude66\udb6a\udfcf\udbe2\ude36",
        19, -193, 429539405, -1536416795084932821L, 85607L, true, true, (char) 30534, (char) 869,
        Double.longBitsToDouble(0x3fde6884db491dd6L), Double.longBitsToDouble(0x3fc701886e2563d4L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Double:21398.0 |a0=[D:[[-24.0]] |a1=[D:[[21374.0]]\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 13, 9, 13, "\000", "\ua72c", "\000",
        1, 62994, 37327, 0L, -71436L, false, false, (char) 63305, (char) 112,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 9, 9, 13, "\000", "\ua72c", "\udbf6\udd9a",
        10, 62994, 37327, 0L, -71436L, false, false, (char) 63305, (char) 112,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Long:-6103094784052917271\0121=java.lang.Double:26886.5 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 28077.5, 28628.0, 27709.5, 28387.0]] |a1=[D:[[20451.5, 13575.5, 2701.5, 1442.5, 10278.5, 7105.5, 7658.5, 15874.5]]\012",
        Z.run(T, 2, 4, 13, 15, "\ud88e\udcb1\udbd7\udd82\udb8b\udfd8\ud8ab\uddf6\ud99b\udcac\ud8cb\udd92\ud8ea\udd66\udb41\ude7b\udafe\udc6d\udba6\udc63\ud870\udfcb\ud8c0\udfa4\udaf0\udc0e\uc314\u5192\ud868\udd07\ud869\udf32", "\u9ff7\u6a3f\u154b\u0b75\u507d\u37b3\u3c05\u7c35\u6d14\u2472\u09e9\u5f57\u6b1f\u6b88\u0f52\u32da\u677c", "\u9959",
        29, 43698, -2117184523, -6103094784052863885L, -53386L, true, false, (char) 15670, (char) 11276,
        Double.longBitsToDouble(0x3fce6f591ad84ad4L), Double.longBitsToDouble(0x3fb07f04b6872fb8L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Double:58488.25092272806 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 5725.0, 2701.5, 25475.0, 8556.0, 1222.5, 7658.5, 7114.0]]\0121=java.lang.Long:3654\012",
        Z.run(T, 2, 16, 5, 10, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\udb41\ude7b\udacd\udc25\uda8a\udd21\uda52\udc4e\ud8eb\udd34\u0e56\ud9c9\udf34\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u2cea\u154b\uc736\u4308\u09bd\u3c05\u37c4\ub25c\u245d\u7d77\u5f57\u6b1f\u6b88\u0f52\u32da\u677c", "\u9959",
        29, 26, 1419750058, -6056854775302103949L, 12065L, false, false, (char) 39273, (char) 59498,
        Double.longBitsToDouble(0x3fb07f0491cffb20L), Double.longBitsToDouble(0x3fe65b84d1b25beeL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Double:55253.64653350944 |a0=[D:[[27695.0, 28224.5, 28115.0, 28173.0, 27683.5, 28623.0, 14995.0, 27896.0]] |a1=[D:[[10629.0, 5725.0, 2701.5, 25475.0, 8556.0, 1222.5, 7658.5, 7114.0]]\0121=java.lang.Double:1.2551759587422E13\012",
        Z.run(T, 2, 16, 6, 10, "\ud88e\udcb1\udbd6\udc4a\ud877\udfce\u7556\uda20\udceb\ud87a\udc3d\ud965\udc4b\udb41\ude7b\udacd\udc25\uda8a\udd21\uda52\udc4e\ud8eb\udd34\ud83d\ude52\ud9c9\udf34\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u2cea\u154b\uc736\u4308\u09bd\u3c05\u37c4\ub25c\u245d4\uaca7\uc08a\u6b88\u0f52\u329a\u034a", "\u9959",
        47, 26, 1419750058, -6056854775302103949L, 12065L, false, false, (char) 39273, (char) 59498,
        Double.longBitsToDouble(0x3fb07f0491cffb20L), Double.longBitsToDouble(0x3fe65b84d1b25beeL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Double:58488.25092272806 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 5725.0, 2701.5, 25475.0, 8556.0, 1222.5, 7658.5, 7114.0]]\0121=java.lang.Long:27405\012",
        Z.run(T, 2, 16, 5, 14, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\udb41\ude7b\udacd\udc25\uda8a\udd21\uda52\udc4e\ud8eb\udd34\u0e56\ud9c9\udf34\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u2cea\u154b\uc736\u4308\u09bd\u3c05\u37c4\ub25c\u245d\u7d77\u5f57\u6b1f\u6b88\u0f52\u17d5\u674d", "\ud851\udc8f",
        30, 26, 1419750058, -6056854775302103949L, 12065L, false, false, (char) 39273, (char) 59498,
        Double.longBitsToDouble(0x3fb07f0491cffb20L), Double.longBitsToDouble(0x3fe65b84d1b25beeL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Double:8.203577736937952\0121=java.lang.Long:3654\012",
        Z.run(T, 2, 7, 5, 10, "\ud895\uddd9\udbd7\udd82\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\udb41\ude7b\udacd\udc25\uda8a\udd21\uda52\udc4e\ud8eb\udd34\ud96b\ude38\ud9c9\udf34\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u2cea\u154b\uc736\u4308\u09bd\u3c05\u37c4\ub25c\u245d\u7d77\u5f57\u6b1f\u6b88\u0f52\u32da\u677c", "\u9959",
        29, 26, 1419750058, -6056854775302103949L, 59425L, true, false, (char) 49961, (char) 57139,
        Double.longBitsToDouble(0x3fb07f0491cffb20L), Double.longBitsToDouble(0x3fe65b84d1b25beeL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Double:58488.25092272806 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 5725.0, 2701.5, 25475.0, 8556.0, 1222.5, 7658.5, 7114.0]]\0121=java.lang.Long:63432274896\012",
        Z.run(T, 2, 16, 5, 10, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\udb41\ude7b\udacd\udc25\uda8a\udd21\uda52\udc4e\ud8eb\udd34\u0e56\ud9c9\udf34\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u2cea\u154b\uc736\u4308\u09bd\u3c05\u37c4\ub25c\u245d\u7d77\u5f57\u6b1f\u6b88\u0f52\u32da\u677c", "\ud839\udda1",
        41, 26, 1419750058, -6056854775313769357L, 12065L, false, false, (char) 39273, (char) 59498,
        Double.longBitsToDouble(0x3fb07f0491cffb20L), Double.longBitsToDouble(0x3fe65b84d1b25beeL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Double:55558.32110944318 |a0=[D:[[27695.0, 28224.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[10629.0, 5725.0, 2701.5, 13040.0, 9953.5, 2312.0, 7712.0, 26581.5]]\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 16, 6, 4, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\udb41\ude7b\udacd\udc25\uda8a\udd21\uda6c\udcfa\ud8e1\udd72\u0e56\ud9c9\udf34\udb01\udfe4\ud885\ude16\ud88a\udc09", "\u533a\u2cea\u154b\u6610\u4df3\u1240\u3c70\ucfdb\u7d52\u242d\u7d77\u5f57\u9d87\ub639\u0f03\u32da\uc7b8", "\u9959",
        26, 26, 1419750058, -6056854775302103949L, 12065L, false, false, (char) 65172, (char) 59498,
        Double.longBitsToDouble(0x3fc0a68c62a7fd90L), Double.longBitsToDouble(0x3fe65b84d7d15beeL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Double:1.2551759587422E13\0121=java.lang.Double:1.2551759587422E13\012",
        Z.run(T, 2, 6, 6, 10, "\ud88e\udcb1\udbd6\udc4a\ud877\udfce\u7556\uda20\udceb\ud87a\udc3d\ud965\udc4b\udb41\ude7b\udacd\udc25\uda8a\udd21\uda52\udc4e\ud8eb\udd34\ud83d\ude52\ud9c9\udf34\udb63\udcf1\ud8b3\udf0e\ud928\udfde", "\u533a\u2cea\u154b\uc736\u4308\u09bd\u3c05\u37c4\ub25c\u23a14\uaca7\uc08a\u6b88\u0f52\u329a\u034a", "\u9959",
        47, 26, 1419750058, -6056854775302103949L, 12065L, false, false, (char) 39273, (char) 59498,
        Double.longBitsToDouble(0x3fb07f0491cffb20L), Double.longBitsToDouble(0x3fe65b84d1b25beeL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Long:1\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 5, 6, 4, "\ud88e\udcb1\uda15\ude37\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\udb41\ude7b\udacd\udc25\uda8a\udd21\uda6c\udcfa\ud8e1\udd72\u0e56\ud9c9\udf34\udb01\udfe4\ud885\ude16\ud88a\udc09", "\u533a\u2cea\u154b\u6610\u4df3\u1240\u3c70\ucfdb\u7d52\u242d\u7d77\u5f57\u9d87\ub639\u0f03\u32da\uc7b8", "\u9959",
        26, 26, 1419750058, -6056854775302103949L, 12065L, false, false, (char) 65172, (char) 59498,
        Double.longBitsToDouble(0x3fc0a68c62a7fd90L), Double.longBitsToDouble(0x3fe65b84d7d15beeL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 7, 15, 4, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud8f5\ude01\ud965\udc4b\udb41\ude7b\udacd\udc25\uda8a\udd21\uda6c\udcfa\ud8e1\udd72\uda0a\udd97\ud9c9\udf34\udb01\udfe4\ud885\ude16\ud88a\udc09", "\u533a\u2cea\u154b\u6610\u4df3\u1240\u3c70\ucfdb\u9a83\u690e\u7d77\u5f57\u9d87\ub639\u0f03\u32da\uc7b8", "\udbc8\udd49",
        26, 26, 1419750058, -6056854775302103949L, -67357L, true, false, (char) 65172, (char) 59498,
        Double.longBitsToDouble(0x3fc0a68c62a7fd90L), Double.longBitsToDouble(0x3fe65b84d7d15beeL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 6, 6, 4, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\udb41\ude7b\udacd\udc25\uda8a\udd21\uda6c\udcfa\ud8e1\udd72\u0e56\ud9c9\udf34\udb01\udfe4\ud885\ude16\ud88a\udc09", "\u533a\u2cea\u154b\u6610\u4df3\u1240\u3c70\ucfdb\u7d52\uae75\ub5dc\u5f57\u9d87\ub639\u0f03\u4b65\uc7fe", "\u9959",
        26, 26, 1419750058, -6056854775302103949L, 12065L, false, false, (char) 65172, (char) 59498,
        Double.longBitsToDouble(0x3fda6da6f00638e2L), Double.longBitsToDouble(0x3fe65b84d7d15b2bL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Double:53969.5683927526 |a0=[D:[[27877.0, 28219.5, 28115.5, 28329.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[16992.5, 5747.5, 2701.5, 13040.0, 9953.5, 2312.0, 7712.0, 26581.5]]\0121=java.lang.Double:26.0\012",
        Z.run(T, 2, 16, 6, 10, "\ud9fa\udca7\udbd7\udd82\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\udb41\ude7b\udacd\udc25\ud9bd\udc5b\uda7d\udc56\ud8e1\udd72\u0e56\ud9c9\udf34\udb01\udfe4\ud88b\ude9a\ud889\udfd0", "\u84f1\u2d17\u154b\u6610\u4df3\u1240\u3c70\ucfdb\u7d52\u242d\u7d77\u5f57\u9d87\ub639\u0f03\ub454\ub562", "\u0cbe",
        26, 1, 1419750058, -6056854775302103949L, 12065L, false, false, (char) 65172, (char) 6499,
        Double.longBitsToDouble(0x3fc7fd0102a7fd90L), Double.longBitsToDouble(0x3fe65b84d7d15beeL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Long:-6056854775302091884\0121=java.lang.Long:26\012",
        Z.run(T, 2, 2, 5, 10, "\ud9fa\udca7\udbd7\udd82\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\udb41\ude7b\udacd\udc25\ud9bd\udc5b\uda7d\udc56\ud8e1\udd72\u0e56\ud9c9\udf34\udb01\udfe4\ud88b\ude9a\ud889\udfd0", "\u84f1\u2d17\u154b\u6610\u4df3\u1240\u3c70\ucfdb\u7d52\u242d\u7d77\u5f57\u9d87\ub639\u0f03\ub454\ub562", "\u0cbe",
        26, 1, 1419750058, -6056854775302103949L, 12065L, false, false, (char) 65172, (char) 6499,
        Double.longBitsToDouble(0x3fc7fd0102a7fd90L), Double.longBitsToDouble(0x3fe65b84d7d15beeL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Double:49275.207079727224 |a0=[D:[[27877.0, 28219.5, 27786.5, 28276.5, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[16992.5, 22011.5, 2701.5, 13040.0, 9953.5, 2312.0, 7712.0, 26581.5]]\0121=java.lang.Double:3.4965075614664802\012",
        Z.run(T, 2, 16, 7, 13, "\ud9fa\udca7\ud945\udd19\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\udb41\ude7b\ud8a6\udd6b\udacd\udf2a\udbef\udf10\ud8e1\uddb9\u0e56\ud9c9\udf34\udb01\udfe4\ud88b\ude9a\ud889\udfd0", "\u84f1\uac27\u154b\u6610\u4df3\u1240\u3c70\ucfdb\u7d52\u242d\u981e\u5e9e\ub2be\u142a\u3df5\u31a2\ub5b1", "\ud84f\ude56",
        33, 1, -1231774540, -6056854775302103949L, 88098L, false, true, (char) 39111, (char) 53261,
        Double.longBitsToDouble(0x3fe65b84d7d15beeL), Double.longBitsToDouble(0x3fd14976574a2130L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Double:26.0\0121=java.lang.Double:26.0\012",
        Z.run(T, 2, 6, 6, 10, "\uda07\uddcc\udbcd\udcd1\ud877\udfce\ud8ab\udd9f\uda1d\udf59\ud87a\udc02\ud965\udc4b\udb41\ude7b\udacd\udc25\ud9bd\udc5b\ud8da\udcc7\ud8e1\udd94\u0e56\ud9c9\udf34\ud93f\udce3\udbc0\uddf6\ud889\udfe8", "\u84f1\u2d17\u8b52\u3fcc\ub45f\u1240\u3c70\ucfdb\u7d52\u242d\u7cb8\u5f57\u9d87\ub639\u161f\u5161\ub633", "\u0cc7",
        26, 1, 1419750058, -6056854775302103949L, 12065L, false, false, (char) 64971, (char) 6499,
        Double.longBitsToDouble(0x3fc7fd0102a7fd90L), Double.longBitsToDouble(0x3fe65b84d7d15beeL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Long:26\0121=java.lang.Long:26\012",
        Z.run(T, 2, 5, 5, 10, "\ud9fa\udca7\udbd7\udd82\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\udb41\ude7b\udacd\udc25\ud9bd\udc5b\uda7d\udc56\ud8e1\udd72\u0e56\ud9c9\udf34\udb01\udfe4\ud88b\ude9a\ud889\udfd0", "\u84f1\u2d17\u154b\u6610\u4df3\u1240\u3c70\ucfdb\u7d52\u242d\u7d77\u5f57\u9d87\ub639\u0f03\ub454\ub562", "\u0cbe",
        26, 1, 1419750058, -6056854667927921549L, 12065L, false, false, (char) 65172, (char) 25302,
        Double.longBitsToDouble(0x3fc7fd0102a7fd90L), Double.longBitsToDouble(0x3fe65b84d7d15beeL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Double:3.258096538021482\0121=java.lang.Double:3.258096538021482\012",
        Z.run(T, 2, 7, 7, 9, "\ud9e6\udf5d\ud943\udd95\ud9e3\udfc4\ud8ab\udd9f\udb97\udc44\u32cb\ud8d4\udc95\ud96e\udc02\udacd\udc25\ud9bd\udc5b\uda7d\udc56\ud8e1\udd72\u0e56\ud9c9\udf34\udb01\udfe4\ud88b\ude9a\ud889\udfd0", "\u84f1\u2d17\u154b\u7687\u9550\uba59\u3bb0\ucfdb\u7d52\u242d\u7d77\u5f57\ucc87\ub639\u0f03\ub454\ub562", "\u0cbe",
        26, 1, 1419750058, -6056854775302103949L, 12065L, false, false, (char) 65172, (char) 6499,
        Double.longBitsToDouble(0x3fc7fd0102a7fd90L), Double.longBitsToDouble(0x3fe65b84d7d15beeL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.Integer:84402\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 3, 5, 12, "\ud88e\udcb1\udbd7\udd82\ud886\udfce\ud971\udc62\ud85b\ude6e\udb42\udf08\udb96\ude3e\ud95f\udcac\udac5\ude4a\uda8a\udd21", "\u8c4c\uc756\u85f8\u2557\u0549\u0152", "\ud9f3\udd0c\ud417\ud928\udc2d\udab6\udce9\udb63\ude4b",
        20, 84382, 990527259, 736328484389455087L, 11265L, true, false, (char) 17358, (char) 50044,
        Double.longBitsToDouble(0x3fc039b60f79918cL), Double.longBitsToDouble(0x3fb884019614cf60L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=void\0121=java.lang.Long:27\012",
        Z.run(T, 2, 8, 5, 10, "\udba8\udc74\udbd7\udd82\ud877\udfce\ud8ab\udd9f\u11bc\ud87a\udc02\udad3\udde2\udb41\ude7b\udacd\udc25\uda8a\udd21\uda52\udc4e\ud8eb\udd34\u0e56\ud9c9\udf34\udb01\udfe4\udbdd\udd42\ud869\udf32", "\u533a\u2cea\u154b\uc736\u4308\u09bd\u3c05\u37c4\ub25c\u245d\u7d77\u00fa\u6b1f\u6b88\u0f52\u32da\u677c", "\u9959",
        27, 26, 1419750058, -6056854775302103949L, 12065L, false, false, (char) 39273, (char) 59498,
        Double.longBitsToDouble(0x3e31cffb20000000L), Double.longBitsToDouble(0x3fe65b84d1b25beeL)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Double:53023.597789097636 |a0=[D:[[27960.5, 28164.5, 27639.0, 28637.0, 28102.0, 28558.0, 28112.0, 28301.0]] |a1=[D:[[10629.0, 5725.0, 26443.5, 25530.5, 8556.0, 1222.5, 7658.5, 7114.0]]\0121=java.lang.Double:27.0\012",
        Z.run(T, 2, 16, 6, 10, "\udaa1\udc39\ud81e\udfea\udbbc\udf4c\udbd0\udd4a\udb53\uddc9\ud87a\udc3d\ud965\udc4b\udb41\ude7b\udacd\udc25\uda8a\udd21\uda52\udc4e\ud8eb\udd34\u4943\ud9c9\udf34\udb01\udfe4\ud834\udecd\ud869\udf32", "\u533a\u2cea\ucec7\uc7a5\u4308\u09bd\u3c05\u37c4\u705b\u245d4\uaca7\uc08a\u6b88\u0f52\u329a\u034a", "\ud856\udc91",
        27, 26, 1419750058, -6056854738794881933L, -31063L, true, false, (char) 39273, (char) 59498,
        Double.longBitsToDouble(0x3fb07f0491cffb20L), Double.longBitsToDouble(0x3fe65b84d1b25beeL)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.Double:3.258096538021482\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 7, 15, 4, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud8f5\ude01\ud965\udc4b\udb41\ude7b\udacd\udc25\uda8a\udd21\uda6c\udcfa\ud8e1\udd72\uda0a\udd97\ud9c9\udf34\udb01\udfe4\ud885\ude16\ud88a\udc09", "\u533a\u2cea\u154b\u6610\u4df3\u1240\u3c70\ucfdb\u9a83\u690e\u7d77\u5f57\u9d87\ub639\u0f03\u32da\uc7b8", "\udbc8\udd49",
        26, 25, 1419750058, -6056854775302103949L, -67357L, true, false, (char) 65172, (char) 59498,
        Double.longBitsToDouble(0x3fc0a68c62a7fd90L), Double.longBitsToDouble(0x3fe65b84d7d15beeL)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 7, 7, 14, "\udb7c\ude35\udbc5\udea4\ud972\udc3b\ud8ab\udd9f\ud96b\udc6b\ud8c1\uded5\ud96b\udc08\udab2\udcc4\ud898\udd53\uda8a\udd21\uda6c\udcfa\ud8e1\udd72\uda0a\udd97\ud9c9\udf34\udb05\udde4\ud90d\udeda\ud889\udfb5", "\u18b3\u2cea\u154b\u6610\ube89\u1240\u3c70\ucfdb\u9a83\u690e\u73fb\u7bcb\ua04e\uc06b\uca9c\u32da\u3850", "\udbc8\udd49",
        26, 26, 1423893871, -6056854775302103949L, -67357L, true, false, (char) 65172, (char) 59498,
        Double.longBitsToDouble(0x3fc0a68c62a7fd90L), Double.longBitsToDouble(0x3fe65b84d7d15beeL)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.Double:46089.95394606074 |a0=[D:[[27784.0, 28365.0, 28107.0, 28257.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[16992.5, 5266.5, 20016.5, 13040.0, 9953.5, 2312.0, 14765.5, 26581.5]]\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 16, 6, 10, "\ud940\uddca\udbc6\udcf2\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\udb41\ude7b\udacd\udc25\ud9bd\udc5b\uda7d\udc56\ud8e1\udd72\udb71\udeec\ud9c9\udeab\udb01\udfe4\uda51\ude83\ud889\udfd0", "\u84f1\u2955\u9c91\u6610\u4df3\u1240\u738b\ucfdb\u7d52\u242d\u7d77\u3f0c\uc7bd\u209b\u0f16\ub454\ub562", "\u0cbe",
        13, 0, 1419750058, 7273800119722954562L, 12065L, false, false, (char) 65172, (char) 6499,
        Double.longBitsToDouble(0x3fc7fd0102a7fd90L), Double.longBitsToDouble(0x3fe65b84d7d15beeL)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.Long:27\0121=java.lang.Long:27\012",
        Z.run(T, 2, 5, 5, 10, "\ud855\uddef\udb7a\udc9b\ud81b\udfbb\ud8ab\udd9f\udbe3\udebc\ud87b\udcc4\ud93a\ude22\udb41\ude7b\uda24\udd51\ud8d2\ude32\udac6\udeab\ud8d3\ude19\u0e56\ud9da\udc8a\udb01\udfe4\udbdd\udd42\ud869\udf32", "\u0559\u8228\u93f6\ua4b6\u0a20\u09bd\ua617\u7cd0\u90dd\u5b18\u7d2f\u00fa\u5de3\u6b88\u0f52\u32da\u677c", "\u9959",
        27, 26, -1180718422, -6107442682525819789L, -79337L, true, false, (char) 33104, (char) 18349,
        Double.longBitsToDouble(0x3fc7a0d5fc779654L), Double.longBitsToDouble(0x3f1b0826ffec8000L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.Double:27.0\0121=java.lang.Double:27.0\012",
        Z.run(T, 2, 6, 6, 10, "\udaa1\udc39\ud81e\udfea\udbbc\udf4c\udbd0\udd4a\udb53\uddc9\ud87a\udc3d\ud965\udc4b\udb41\ude7b\udacd\udc25\uda8a\udce3\uda52\udc75\ud8eb\udd34\u4943\ud9c9\udf34\udb01\udfe4\ud867\udd48\ud869\udf32", "\u533a\u2cea\ucec7\u89ad\u926a\u09bd\u3c05\u37c4\u705b\u245d4\uaca7\uc08a\u6b88\u0f52\u329a\u034a", "\ud856\udc91",
        27, 26, 1419750058, -6056854738794881933L, -31063L, true, false, (char) 39273, (char) 59498,
        Double.longBitsToDouble(0x3fb07f0491cffb20L), Double.longBitsToDouble(0x3fe65b86a1b25beeL)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.Double:3.258096538021482\0121=java.lang.Double:3.258096538021482\012",
        Z.run(T, 2, 7, 7, 4, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\udbfc\udc17\ud99b\ude60\ud965\udc4b\udb41\ude7b\udacd\udc25\uda8a\udd21\udbe4\udcd5\ud8e1\udd72\uda0a\udd97\ud9c9\udf34\udac0\udfc4\ud95a\udcde\ud88a\udc09", "\u533a\u2cea\u154b\u1a72\u4df3\u1240\u3c70\ucfdb\uca2a\u1f81\u7d08\u5f57\u9d87\ub639\u0f03\u32da\uc7b8", "\udbc8\udd49",
        26, 25, -962614614, -6057055590792995725L, -80777L, true, false, (char) 65172, (char) 59498,
        Double.longBitsToDouble(0x3fc0a68c62a7fd90L), Double.longBitsToDouble(0x3fe65b84d7d15beeL)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Double:1.0\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 6, 6, 10, "\ud940\uddca\udbc6\udcf2\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\udb41\ude7b\udacd\udc25\ud9bd\udc5b\uda7d\udc56\ud8e1\udd72\udb71\udeec\ud9c9\udeab\udb01\udfe4\uda51\ude83\u00c6", "\u84f1\u2955\u9c91\u6610\u4df3\u1240\u738b\ucfdb\u7d52\u242d\u7d77\u3f0c\uc7bd\u209b\u0f16\ub454\ub562", "\u0cbe",
        13, 0, 1419750058, 7273800119722954562L, 12065L, false, false, (char) 8147, (char) 6481,
        Double.longBitsToDouble(0x3fc7fd0102a7fd90L), Double.longBitsToDouble(0x3fe65b84d7d15beeL)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.Double:47697.75837500123 |a0=[D:[[27784.0, 28365.0, 28107.0, 28257.0, 27683.5, 28623.0, 27709.5, 28343.5]] |a1=[D:[[14277.5, 5230.5, 20016.5, 13040.0, 9953.5, 776.5, 14765.5, 26581.5]]\0121=java.lang.Long:1\012",
        Z.run(T, 2, 16, 5, 6, "\ud940\uddca\udbc6\udcf2\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\ud9cb\udc08\udacd\udc2d\ud9bd\udc5b\uda7d\udc56\ud8e1\udd72\ud9f9\udeb0\uda08\udeb1\udb01\udfe4\uda51\ude83\ud889\udfd0", "\u6fbb\u290d\u9c91\u6610\u4df3\u0641\u738b\ucfdb\u7d52\u242d\u7d77\u3f0c\uc7bd\u209b\u0f16\ub454\ub562", "\u0cbe",
        13, 0, 1419750058, 7273800119722954562L, 12065L, false, false, (char) 65172, (char) 6499,
        Double.longBitsToDouble(0x3fc7fd0102a7fd90L), Double.longBitsToDouble(0x3fe65b84d7d15beeL)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:1.0\012",
        Z.run(T, 2, 7, 6, 10, "\ud96a\ude7f\uda94\udcf9\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\udb41\ude7b\udacd\udc25\ud9bd\udc5b\uda7d\udc56\ud8e1\udd72\ud818\udeba\udb2c\udf89\uda6a\udf50\ud894\udc91\udb0a\udd4c", "\u84f1\u2955\u9c91\u6610\u4df3\uc749\ub58e\ucfdb\u7d52\u0c2d\u7d77\u3f0c\uc7bd\u6d0d\u0f16\ua241\ub562", "\u0cbe",
        13, 0, 1419750058, 7273800118940470055L, 12065L, false, false, (char) 65172, (char) 6499,
        Double.longBitsToDouble(0x3fc7fd0102a7fd90L), Double.longBitsToDouble(0x3fc50e1349994ef0L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.Long:1\0121=java.lang.Long:1\012",
        Z.run(T, 2, 5, 5, 6, "\ud940\uddca\udbc6\udcf2\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\ud9cb\udc08\udacd\udc2d\ud9bd\udc5b\uda7d\udc56\ud8e1\udd72\ud9f9\udeb0\uda08\udeb1\udb01\udfe4\uda51\ude83\ud889\udfd0", "\u6fbb\u290d\u9c91\u6610\u4df3\u7cc5\u07bc\u0349\u8684\u242d\u7d77\u3f0c\uc7bd\u209b\u0f16\ub454\ub562", "\u0cbe",
        13, 0, 1419750058, 7273800119722954562L, 12065L, false, false, (char) 65172, (char) 6499,
        Double.longBitsToDouble(0x3fc7fd0102a7fd90L), Double.longBitsToDouble(0x3fe65b84d7d15beeL)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 7, 7, 11, "\ud940\uddca\udbc6\udcf2\ud877\udfce\ud8ab\udd9f\udb97\udc44\udada\udc42\ud95f\ude87\ud9cb\udc08\udacd\udc2d\ud9bd\udc28\uda7d\udc56\ud8e1\udd72\ud9f9\udeb0\uda08\udeb1\udb01\udfe4\uda51\ude83\ud889\udfd0", "\u6fbb\u290d\u9c91\u6610\u4df3\u0641\u738b\uc278\ucf42\u2e84\u7cd3\u3f0c\uc7bd\u209b\u0f16\ub454\ub562", "\u0cbe",
        13, 0, 1419750058, -4081343543970902206L, 12065L, false, false, (char) 65172, (char) 6499,
        Double.longBitsToDouble(0x3fc7fd0102a7fd90L), Double.longBitsToDouble(0x3fe65b84d7d15beeL)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.Long:1\0121=java.lang.Long:1\012",
        Z.run(T, 2, 5, 5, 4, "\ud88e\udcb1\udbd7\udd82\ud877\udfce\ud8ab\udd9f\udb97\udc44\ud87a\udc02\ud965\udc4b\udb41\ude7b\udacd\udc25\uda8a\udd21\uda6c\udcfa\ud8e1\udd72\u0e56\udaef\udcb9\uda1b\udd59\ud885\ude16\ud88a\udc09", "\u533a\u2cea\u154b\u6610\u4df3\u1240\u3c70\ucfdb\u7d52\u8cb0\u7d77\u5f57\u9d87\ub639\u0f03\u32da\u7007", "\u9959",
        26, 26, 1419750058, -6056854775302103949L, 12065L, false, false, (char) 65172, (char) 59498,
        Double.longBitsToDouble(0x3fc0a68c62a7fd90L), Double.longBitsToDouble(0x3fe65b84d2d15bbeL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.util.MathUtils|distance|[D,[D|static",
    "M|org.apache.commons.math.util.MathUtils|distance|[I,[I|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|long,long,java.lang.String|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|addAndCheck|long,long|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficient|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficientDouble|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|binomialCoefficientLog|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|checkBinomial|int,int|static",
    "M|org.apache.commons.math.util.MathUtils|compareTo|double,double,double|static",
    "M|org.apache.commons.math.util.MathUtils|cosh|double|static",
    "M|org.apache.commons.math.util.MathUtils|distance1|[D,[D|static",
    "M|org.apache.commons.math.util.MathUtils|distance1|[I,[I|static",
    "M|org.apache.commons.math.util.MathUtils|distanceInf|[D,[D|static",
    "M|org.apache.commons.math.util.MathUtils|distanceInf|[I,[I|static",
    "M|org.apache.commons.math.util.MathUtils|equals|double,double|static",
    "M|org.apache.commons.math.util.MathUtils|distance|[D,[D|static",
    "M|org.apache.commons.math.util.MathUtils|distance|[I,[I|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
