package org.apache.commons.math.linear;
import org.junit.Test;
import static org.junit.Assert.*;
public class EigenDecompositionImpl_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 12, 0, "\udaf1\udcd3\ud97e\udd18\u05a3\udb03\udc4c\ud84b\udc69\udbe0\udf61\ud881\udd4a\ud9e3\udf84\ud9b3\udd89\uda94\ude48\ud9fe\ude77", "\u8b21\u1d5f\ud24e\ubda6\u7518", "\ud8d2\udf7f\uee4b\uda28\uddaa\udb55\udf1a\udb12\uded9\udb2d\udea4\ud897\udc85\ud9b6\udc43\ud939\udc1b\ud94b\udd49\udae4\udd74\ud807\udcd6\ud837\udc4a\ud9e1\udf33\ud96c\udca0\udade\udcdc\udbd0\udf48\ud9d2\udc70\ud912\udffb\ud828\udd1e",
        14, 49038, -1687109462, 5766621141567744568L, 67573L, true, true, (char) 23339, (char) 25135,
        Double.longBitsToDouble(0x3fed276c4ef2ddecL), Double.longBitsToDouble(0x3fe7be361d880a71L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 12, 0, "\udaf1\udcd3\ud97e\udd18\u05a3\udb03\udc4c\ud84b\udc69\udbe0\udf61\ud881\udd4a\ud9e3\udf84\ud9b3\udd89\uda94\ude48\ud9fe\ude77", "\u8b21\u1d5f\ud24e\ubda6\u7518", "\ud8d2\udf7f\uee4b\uda28\uddaa\udb55\udf1a\udb12\uded9\udb2d\udea4\ud897\udc85\ud9b6\udc43\ud949\udc1b\ud94b\udd49\udae4\udd74\ud807\udcd6\ud837\udc4a\ud9e1\udf33\ud96c\udca0\udade\udcdc\udbd0\udf48\ud9d2\udc70\ud912\udffb\ud828\udd1e",
        14, 49038, -1687109462, 5766621141567744568L, 67573L, true, true, (char) 23339, (char) 25135,
        Double.longBitsToDouble(0x3fed276c4ef2dd91L), Double.longBitsToDouble(0x3fe7be361d880a71L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 12, 0, "\udb10\ude84", "\ud040\ud74c\u821f\u16ea\u610a\u091a", "\uda21\udf59\udb94\udc76\udba6\ude15\udb4b\udc02\ud8cd\udd05\ud886\udf24\uda4f\uddc1\ud8b8\udf06\udacd\ude7d\udbdb\ude69\uee4b\uda28\uddaa\udb55\udf1a\udb12\uded9\udb2d\udea4\ud9e9\udd53\udacd\udd80\udb66\udd00\ud94b\udd49\udae4\udd74\ud807\udcd6\ud837\udc4a\ud9e1\udf33\uf709\udbee\uddaa\udbd0\udf48\ud9d2\udc70\ud912\udffb\ud828\udd1e\ud9af\udc4e\ud919\udf8c\udb94\udebc\ud93b\udc17\ud8ca\udfb7\ud8e5\udcfe\udafb\udff9\ud963\udd16\udaf6\udff1\ud9ae\udd43\udb84\udda1\ud9de\udf92\uda38\udf94\ud8d4\udfe1\udb4d\udfbc\udb88\udec9\ud870\udf2c",
        37, 8916, 1860921216, -3051703916066650100L, -76058L, false, true, (char) 39215, (char) 54093,
        Double.longBitsToDouble(0x3fb703ccd556b678L), Double.longBitsToDouble(0x3feef3cc911829c3L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 12, 0, "\udaf1\udcd3\ud97e\udd18\u05a3\udb03\udc4c\ud84b\udc69\udbe0\udf61\ud881\udd4a\udb14\udf1c\ud9cd\udc6a\uda94\ude48\ud9fe\ude77", "\u8b21\u1d5f\u4472\ubda6\u7518", "\ud8d2\udeda\uee4b\uda28\uddaa\udb55\udf1a\udb12\uded9\ud867\udc4c\ud897\udc85\ud9ae\ude43\ud939\udc1b\ud94b\udd49\udae4\udd74\ud807\udcd6\ud837\udc4a\ud9e1\udf33\ud96c\udca0\udade\udcdc\udbd0\udf48\ud9d2\udc70\ud912\udffb\ud828\udd1e",
        14, 49038, -1687109462, 5766621141668407864L, 67573L, true, true, (char) 23339, (char) 25135,
        Double.longBitsToDouble(0x3fed276c4ef2ddecL), Double.longBitsToDouble(0x3fe7be361fb1b83dL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 6, 0, "\udaf1\udcd3\ud97e\udd18\udba5\udde1\ud8fd\ude0c\udba9\udcf2\udbe0\udf61\ud881\udd4a\ud9e3\udf84\ud9b3\udd89\uda94\ude48\ud9fe\ude77", "\u8b21\u1d5f\ud24e\ubda6\u7518", "\ud87d\udcdb\uee4b\uda28\uddaa\ud9ec\udfe0\uda97\udcca\ud8c6\udfe9\ud89f\udcfe\ud9b6\udc43\ud939\udc1b\ud94b\udd49\udae4\udd74\ud807\udcd6\ud837\udc4a\ud9e1\udf33\ud96c\udca0\udade\udcdc\udbd0\udf48\ud9d2\udc70\ud912\udffb\ud828\udd1e",
        14, 49038, -1687109462, 5766621141567744568L, -63499L, true, true, (char) 23339, (char) 25135,
        Double.longBitsToDouble(0x3fd54ed89de5bbd8L), Double.longBitsToDouble(0x3fe7be361d880a71L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 12, 0, "\udaf1\udcd3\ud97e\udd18\u05a3\ud84b\udc50\ud84b\udc69\udbe0\udf61\ud881\udd4a\ud9e3\udf84\ud9b3\udd89\uda94\ude48\ud9fe\ude77", "\u461e\u1d5f\uc03b\ucad7\u7518\u87cc\uab5d", "\uda28\uddaa\udb55\udf1a\udb12\uded9\udb2d\udea4\ud897\udc85\ud9b6\udc43\ud939\udc1b\ud94b\udd49\udae4\udd74\ud807\udcd6\ud837\udc4a\ud9e1\udf33\ud96c\udca0\udade\udcdc",
        1, 71110, -763642198, 110304136846051737L, -50678L, false, true, (char) 31295, (char) 45221,
        Double.longBitsToDouble(0x3fd6bd9c530b756aL), Double.longBitsToDouble(0x3fe36805f25af7d4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 12, 14, "\udaf1\udcd3\ud97e\udd18\u05a3\udb03\udc4c\ud84b\udc69\udbe0\udf61\ud881\udd4a\ud9e3\udf84\ud9b3\uddc5\udac7\udd89\uda00\uddad", "\u8b21\u1d5f\ud24e\ubda6\u67e9", "\ud93a\ude33\ud93f\uddaf\uda28\uddaa\ud870\udd66\ud909\udf0e\ud8eb\udc93\udbff\udfa6\u03b5\ud939\udc1b\ud94b\udd49\udae4\udd74\ud807\udcd6",
        8, 23453, -1979333917, -2623448790230416984L, 99065L, false, true, (char) 1540, (char) 49872,
        Double.longBitsToDouble(0x3fe1c3683f3f1967L), Double.longBitsToDouble(0x3fd6bd9c530b756aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|flipIfWarranted|int,int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|computeGershgorinCircles||new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|computeShiftIncrement|int,int,int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|computeSplits||new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|countEigenValues|double,int,int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|decompose||new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|dqd|int,int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|dqds|int,int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|eigenvaluesRange|int,int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|findEigenVectors||new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|findEigenvalues||new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|findEigenvector|double,[D,[D|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|getD||new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|getDeterminant||new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|getEigenvector|int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|getImagEigenvalue|int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
    "M|org.apache.commons.math.linear.EigenDecompositionImpl|flipIfWarranted|int,int|new:org.apache.commons.math.linear.EigenDecompositionImpl:org.apache.commons.math.linear.RealMatrix,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
