package org.apache.commons.math3.geometry.euclidean.twod;
import org.junit.Test;
import static org.junit.Assert.*;
public class PolygonsSet_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 6, 7, 4, "\ud8e7\ude61\udacf\udd4c", "\u1118\u6e58\ub952\u4c2b\ud1bd\u3f03\u4f11\u2bad\uab02\u951e\u809d\u1589\u61ea\u0f23\u7661\u2df3\u330d\u8c98\u883a\u386d\u058f\uc8cb\uac6f\u3952\ube59\u6f6e\u863d\u6d6c\u7e62\u3d17\u8660\u46d6", "\udb0b\udc6b\ud928\udedc\u4e31\ud8fb\udc74\udbaf\udf93\ud9aa\udd2f\udaf4\udf44\ud92f\ude44\ud9cd\udc00",
        52, 9535, -47565648, 7453259969345685375L, -89528L, true, true, (char) 37807, (char) 11519,
        Double.longBitsToDouble(0x3fe7276fc2e234f5L), Double.longBitsToDouble(0x3fe50fcd355b29efL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 6, 2, 4, "\ud8e7\ude61\udacf\udd4c", "\u5e1f\u24ae\u5ffa\u4c2b\ud1bd\u3f03\u4f11\u2bad\uab02\u951e\u809d\u1589\u61ea\u0f23\u7661\u2df3\u5534\u6385\u652b\u386d\ud68e\uc8cb\uac6f\u3952\uc62d\u6f6e\u863d\u6d6c\u7e62\u3d17\u8660\u46d6", "\udb0b\udc6b\ud928\udedc\u4e31\ud8fb\udc74\udbaf\udf93\ud93c\uddf7\udae8\udc27\ud931\ude25\udac5\udf5d",
        57, 9025, -1752993951, 7043930164194795896L, -89528L, true, true, (char) 37807, (char) 11519,
        Double.longBitsToDouble(0x3fe7276fc2e234f5L), Double.longBitsToDouble(0x3fe50fcd355b29efL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 7, 4, "\udb4a\ude39\udacf\udd4c", "\u1118\u6e58\ub952\u4c2b\ud1bd\u3f03\u4f11\u2bad\uab02\u951e\u809d\u4d3d\u61ea\u0f23\u7661\u2df3\u330d\u8c98\u883a\u386d\u058f\uc8cb\uac6f\u3952\ube59\u6f6e\u863d\u6d6c\u7e62\u3d17\u8660\u46d6", "\udb0b\udc6b\ud928\udedc\u4e31\ud8fb\udc74\udbaf\udf93\ud9aa\udd2f\udaf4\udf44\ud92f\ude44\ud9cd\udc00",
        52, 25495, 1513938258, 7453259969345685375L, -89528L, true, true, (char) 37807, (char) 61182,
        Double.longBitsToDouble(0x3fe7276fc2e234f5L), Double.longBitsToDouble(0x3fe50fcd355b29efL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 4, "\ud8e7\ude61\udacf\udd4c", "\005\u0713\ub952\u4c2b\ud1bd\ube0a\u4e4c\u2bad\uab02\u951e\u809d\u1589\u61ea\u0f23\u7661\u2df3\u330d\u8c98\u883a\u386d\u058f\uc8cb\uac6f\u9171\000\u6f6e\u863d\u6d6c\u7e62\u3d17\u3004\u1bdf", "\udb0b\udc6b",
        41, 98517, -432271879, 8573059909157778745L, -29931L, true, false, (char) 20472, (char) 11158,
        Double.longBitsToDouble(0x3fc6098fb1d3f4a8L), Double.longBitsToDouble(0x3fbfd9dbd0000000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=[[Lorg.apache.commons.math3.geometry.euclidean.twod.Vector2D;:[[]] |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 1, 4, 7, 4, "\ud8e7\ude61", "\u9530\u4106\u6e58\ub952\uaca7\u824d\u3f03\u4f11\u2bad\uab02\u951e\u809d", "\u832f\udb4b\udf08",
        33, 17914, -861736583, 3473444199655768819L, -128L, true, true, (char) 12853, (char) 27768,
        Double.longBitsToDouble(0x3fc57ab4166f8254L), Double.longBitsToDouble(0x3fea722043f401c9L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 5, "\ud8e7\ude61\udacf\udd4c", "\u1118\u6e58\ub952\u4c2b\ud1bd\u3f03\u4f11\u2bad\uab02\u951e\ubf9d\u1523\u61ea\u0f23\u7661\u2df3\u330d\u8c98\u883a\u386d\u058f\uc8cb\uac6f\u3952\ube59\u6f6e\u863d\u6d6c\u7e62\u3d17\u8660\u46d6", "\udb0b\udc6b\ud928\udedc\u4e31\ud8fb\udc74\udbaf\udf93\ud9aa\udd2f\udaf4\udf44\ud92f\ude44\ud9cd\udc00",
        32, 9535, 679801520, 7453259969345685375L, -89528L, true, true, (char) 37807, (char) 11519,
        Double.longBitsToDouble(0x3fe7276fc2e23470L), Double.longBitsToDouble(0x3fe50fcd355b29efL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=void |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 2, 7, 0, 5, "\ud8e7\ude61\udacf\udd4c", "\u120f\u6e58\ub952\u4c2b\ud1bd\u3f03\u4f11\u2bad\uab02\u951e\u809d\u1589\u6dcc\u7d6e\u242f\u2df3\u330d\u8c98\u883a\u386d\u058f\uc8cb\uac6f\u3952\ube59\u6f6e\u863d\u6d6c\u7e62\u3d17\u8660\u46d6", "\udb0b\udc6b\ud928\udedc\u4e31\u55a2\udbaf\udf1a\ud9aa\udd2f\udaf4\udf44\ud893\udc56\ud9f9\ude78",
        52, 9535, -47565648, 7453259969345685375L, -89528L, true, true, (char) 37807, (char) 11519,
        Double.longBitsToDouble(0x3fe7276fc2e234f5L), Double.longBitsToDouble(0x3fe50fcd355b29efL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.math3.geometry.euclidean.twod.Line;:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 1, 6, 4, "\ud8e7\ude61\udacf\udd4c", "\u1118\u6e58\ub952\u4c2b\ud1bd\u3f03\u4f11\u2bad\uab02\u951e\u809d\u1589\u61ea\u0f23\u7661\u2df3\u330d\u7a62\u8701\ucc01\u8ab3\uc8cb\uac6f\u3952\ube59\u6f6e\u863d\u6d6c\u7e62\u3d17\u8660\u46d6", "\udb0b\udc6b\ud928\udedc\u4e31\ud8fb\udc74\udbaf\udf93\ud9aa\udd2f\udaf4\udf44\ud92f\ude44\ud9cd\udc00",
        49, 25004, -1018554349, 7453260300058167167L, 3230L, true, true, (char) 37807, (char) 11519,
        Double.longBitsToDouble(0x3fe7276fc2e234f5L), Double.longBitsToDouble(0x3fe50fcd34ac0aefL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 2, 7, 7, 4, "\udad5\udf83\ud8db\udf7d", "\u1118\u6e58\ub952\u4c2b", "\ud9bd\udd31\ud874\ude10\ud806\udf9c\ud939\udda5",
        5, 55553, 301659291, 4452483222623728985L, 51782L, true, true, (char) 20194, (char) 45862,
        Double.longBitsToDouble(0x3fe55d9cf9e0c910L), Double.longBitsToDouble(0x3fd4e7f562e34188L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 4, "\ud8e7\ude61\udacf\udd4c", "\u1118\u6e58\ub952\u4c2b\ud1bd\u3f03\u4f11\u2bad\uab02\u951e\u809d\u1589\u61ea\u0f23\u7661\u2df3\u330d\u8c98\u883a\u386d\u058f\uc8cb\uac6f\u3952\ube59\u6f6e\u863d\u6d6c\u7e62\u3d17\u8660\u46d6", "\000",
        57, 25709, -432271879, 8573059909157778745L, -29931L, true, false, (char) 20472, (char) 11158,
        Double.longBitsToDouble(0x3fc6098fb1d3f4a8L), Double.longBitsToDouble(0x3febfb3b7acbfb7dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@? |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 2, 7, 2, 4, "\ud8e7\ude61\udbe3\udcf5", "\u0cc0\u6e58", "\u4aed\uda30\udcea\ud9bd\udd31\ud874\ude10\uda0e\udd08\ud939\udda5\uda4f\udf8b\ud81b\ude59\ud8dd\uddaa\ud8a4\udd8b\ud8c2\udd12\ud9da\udda8\udb20\udd54\ud82f\ude72\ud8ba\uddf0\uda99\udf33\ud825\udda7\udbf1\udc95\ud8df\udcea\udb0f\udfcc",
        11, 75308, 1141433755, 128840009545212916L, -56572L, false, false, (char) 58144, (char) 45882,
        Double.longBitsToDouble(0x3fe6476266d9d7f3L), Double.longBitsToDouble(0x3fb56f162fcb1b68L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@? |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 2, 8, 2, 4, "\ud70a\udba1\udc76", "\u69ae\uc67a\ub952\u4c2b\ud1bd\u3f03\ucee0\u2b05\uab02\u951e\u809d\u1589", "\udb2f\ude08\ud947\udf0c\udbcf\udc88\uc7b4\ud8ba\uddf0\udadf\ude72\ud8b0\udf6e",
        3, 13118, -399237007, -3091300987446640213L, 13439L, false, true, (char) 61968, (char) 24158,
        Double.longBitsToDouble(0x3fe5b3cc19267cfaL), Double.longBitsToDouble(0x3fef6c736ec8ec4cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 1, 5, 7, 4, "\udbe0\udd5a\udacf\udd4c", "\ubbda\u6e58\u61e2\uc086\ud1ce\u6685\ua1b5\ud0c1\uab02\u2b0c\ud172\u5e75\u61ea\uc1c8\u7661\u2df3\u330d\ua6f7\u88bb\u707a\u6abb\uc80f\u16e4\ud7c3\ubeac\u8ad6\u863d\u72d7\u1f90\u3c71\u7e5f\u09cc", "\udb0b\udc6b\udad4\ude72\ud974\udd02\udba5\udd42\ud93f\ude4b\udb35\udeb5\udaf4\udf48\ud92f\ude97\ud9cd\udc00\uda5f\udfe5\ud881\ude2a\ud8b9\udc85",
        -4, 56319, 841774463, 867607203409433273L, -20166L, false, false, (char) 28631, (char) 9889,
        Double.longBitsToDouble(0x3fd5b29ef6bd52eeL), Double.longBitsToDouble(0x3fee5bfbe1b23a3bL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@? |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=void |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 2, 2, 0, 1, "\ud8e7\ude61\udacf\udd4c", "\u48e1\u6e58\ub952\u4c2b\ud1bd\u3f03\u4f11\u2bad\uab02\u951e\u809d\u3d55\u61ea\u0f23\ud791\u4042\u2345\u8c98\u883a\u386d\uac41\u03c7\uac6f\u3952\u67a8\ub2c8\u8af8\ud123\u7e62\u3d17\u8660\u46d6", "\udb31\udf13\ud92b\udfdc\u4e31\ud8fb\udc74\udbaf\udf93\ud9aa\udd2f\udaf4\udf44\udb8e\udfb4\udac3\udd8d",
        52, 34519, -45082432, 7453259969345685375L, 39321L, false, true, (char) 11485, (char) 28631,
        Double.longBitsToDouble(0x3fe50fcd35ed10efL), Double.longBitsToDouble(0x3fd10d72e2627bd4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=[[Lorg.apache.commons.math3.geometry.euclidean.twod.Vector2D;:[[]] |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 2, 5, 4, 5, "\udb4a\ude39\udacf\udd4c", "\u1118\u6e58\u2319z\ud1bd\u3f03\u4f11\u2bad\uab02\u951e\u809d\u4d3d\u61ea\ud413\u59a8\u2df3\u330d\u8c98\u883a\u386d\u058f\uc8cb\uac6f\u3952\ube59\u6f6e\u863d\u6d6c\u7e62\u3d17\u8660\u46d6", "\udb0b\udc6b\ud928\udedc\u4e31\ud8fb\udc74\udbaf\udf93\ud9aa\udd2f\udaf4\udf44\ud92f\ude44\ud9cd\udc00",
        52, 25495, 1513938258, 7453259969345685375L, 39459L, false, true, (char) 11485, (char) 28631,
        Double.longBitsToDouble(0x3fe50fcd355b29efL), Double.longBitsToDouble(0x3fba108f5f9612a0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@? |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=[[Lorg.apache.commons.math3.geometry.euclidean.twod.Vector2D;:[[]] |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 2, 2, 4, 4, "\udb4a\ude39\udacf\udd4c", "\u1118\u6e58\ub952\u4c2b\ud1bd\u3f03\u4f11\u2bad\uab02\u951e\u809d\u4d3d\u61ea\u0f23\u7661\u7b95\u330d\uaa95\u883a\u386d\u058f\uc8cb\uac6f\u3952\ube59\u6f6e\u863d\u6d6c\u7e62\u3d17\ubc50\u46d6", "\udb0b\udc6b\ud928\udedc\u4e31\ud8fb\udc74\udbaf\udf93\ud9aa\udd2f\udaf4\udf44\ud92f\ude44\ud9cd\udc00",
        47, 1431, 1513938258, 7453259969345685375L, -89528L, true, true, (char) 37807, (char) 61182,
        Double.longBitsToDouble(0x3fe7276fc2e234f5L), Double.longBitsToDouble(0x3fe50fcd355b29efL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=[[Lorg.apache.commons.math3.geometry.euclidean.twod.Vector2D;:[[]] |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=[Lorg.apache.commons.math3.geometry.euclidean.twod.Line;:@?\012",
        Z.run(T, 2, 4, 1, 4, "\udb4a\ude39\udacf\udd4c", "\u1118\uce94\ub952\u53f8\ud1bd\u3f03\u4f11\u2bad\uab02\u951e\u809d\u4d3d\u61ea\u0f23", "\udb20\udd54\ud82f\ude72\ud8ba\uddf0",
        40, 69363, 2136373728, -5481455454882416725L, 78284L, true, true, (char) 65365, (char) 58812,
        Double.longBitsToDouble(0x3fe5face665c929aL), Double.longBitsToDouble(0x3fe5b3cc19267cfaL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 2, 5, 5, 4, "\ud8e7\ude61\udacf\udd4c", "\005\u0713\ub952\u4c2b\ud1bd\ube0a\u4e4c\u2bad\uab02\u951e\u809d\u3459\u41a8\u0f23\u6829\u6a34\u330d\u8c98\u883a\u386d\u058f\uc8cb\uac6f\u9171\u883d\u6f6e\u863d\u6d6c\u7e62\u3d17\u3004\u1bdf", "\udb3e\udc28\ud82b\udfbe\u4e51\ud8fb\udc74\udbaf\udf93\ud9aa\udd2f",
        -1, 62899, 1038090331, 5791367541393578807L, -54036L, true, false, (char) 59903, (char) 39620,
        Double.longBitsToDouble(0x3fc3afb4790efc20L), Double.longBitsToDouble(0x3feffb70f99576a9L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=[[Lorg.apache.commons.math3.geometry.euclidean.twod.Vector2D;:[[]] |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 2, 0, 4, 4, "\ud8e7\ude61\udacf\udd4c", "\005\u0713\ub952\u4c2b\ud1bd\ube0a\u4e4c\u45bf\u2437\u951e\u809d\u1589\u61ea\u0f23\u7661\u2df3\u330d\u8c98\u883a\u386d\u058f\uc8cb\uac6f\u9171\000\u6f6e\u863d\u6d6c\u7e62\ua460\u3004\u1bdf", "\udb0b\udc6b",
        41, 98517, -432271879, 8573059909157778745L, -29931L, true, false, (char) 20472, (char) 11158,
        Double.longBitsToDouble(0x3fc6098fb1d3f4a8L), Double.longBitsToDouble(0x3fbfd9dbd0000000L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=[Lorg.apache.commons.math3.geometry.euclidean.twod.Line;:@?\012",
        Z.run(T, 2, 5, 1, 4, "\ud8e7\ude61\udacf\udd4c", "\005\u0713\u36f7\uba1e\ub15a\ube0a\u4e4c\u2bad\uab02\u951e\u809d\u1589\u61ea\u0f23\u7661\u2df3\u330d\u8c98\u5bc8\u386d\u056d\uc8cb\uac6f\u9171\000\u6f6e\u863d\u6d6c\u7e62\u3d17\u3004\u1bdf", "\udb0b\udc6b",
        41, 75134, -432271879, 8573059909157778745L, -29931L, true, false, (char) 20472, (char) 11158,
        Double.longBitsToDouble(0x3fc6098fb1d3f4a8L), Double.longBitsToDouble(0x3fbfd9dbc1580000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=void |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 2, 0, 0, 4, "\uda78\udf9a\udb2f\udd71\uda4d\udcb6\ud97b\udc76\ud9c8\ude29\udb80\udcbf\ud88b\udec4\ud936\udc63\u4aed\ube0a\ud9bd\udc6c", "\u951e\u809d\u1589\u61ea\u0f23", "\udb20\udd54\ud82f\ude72\ud8ba\uddf0",
        40, 69363, 2136373728, -6862090216849501839L, -17653L, false, true, (char) 65365, (char) 58812,
        Double.longBitsToDouble(0x3fe5face6000929aL), Double.longBitsToDouble(0x3fe5b3cc180000faL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 2, 5, 5, 2, "\ud8e7\ude61\udacf\udd4c", "\005\u0713\ub952\u1883\u220d\ube0a\u4e4c\u2bad\uab02\u951e\u809d\u1589\u61ea\u6ed5\u7678\u2df3\u330d\u8c98\u883a\u386d\u058f\uc8cb\u1ee0\u7db7\000\u6f6e\u70d6\u143b\u7e62\u3d17\u7882\u1bdf", "\udb0b\udc6b",
        41, 98517, -432271879, 8573059909157717305L, -29931L, true, false, (char) 16376, (char) 1278,
        Double.longBitsToDouble(0x3fe8c93944daaa30L), Double.longBitsToDouble(0x3f94c92fb26e0b40L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@? |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@? |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 2, 2, 2, 1, "\ud8e7\ude61\udacf\udd4c", "\ubba5\u2be9\ub952\u4c2b\u4e7c\u1cc4\u4eef\u2bad\uab02\u951e\u809d\u1589\uc0e9\u8823\u8829\u2eab\u8147\u9a29\u46c7\ud126\u0532\uc8cb\uac6f\u9171\u00a3\u6f6e\u863d\u9d6b\u7e62\u3d17\u3004\u1bdf", "\udb0b\udc74",
        41, 98517, -163836423, 1235759744581768775L, -29931L, true, false, (char) 20472, (char) 11158,
        Double.longBitsToDouble(0x3fc6098fb1d3f4a8L), Double.longBitsToDouble(0x3fbfd9dbd0000000L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 2, 5, 5, 1, "\u1ead\uda3a\udc26\udba8\udef2\uda95\udd02\udae5\ude57\udbad\udc4c\ud88b\udec4\ud9b0\udeec\u4aed\ube0a\ud9bd\udc6c\ud874\ude10\ud89e\udd09", "\u1589\u61ea", "\ud947\udf0c\udb20\udd54\ud82f\ude72\ud8ba\uddf0\udadf\ude72\ud8b0\udf6e",
        3, 13118, 37233, 48940361536838827L, 13458L, false, true, (char) 22667, (char) 37530,
        Double.longBitsToDouble(0x3fe5b3cc180000faL), Double.longBitsToDouble(0x3e4b23b130000000L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.math3.geometry.euclidean.twod.Line;:@?\0121=[Lorg.apache.commons.math3.geometry.euclidean.twod.Line;:@?\012",
        Z.run(T, 2, 1, 1, 6, "\ud8e7\ude61\udacf\udd4c", "\005\u0713\ub952\u4c2b\ud1bd\ube0a\u0860\ua630\uaa90\ucc5c\u80cc\u1589\u61ea\u0f23\u7661\u2df3\u330d\u7412\u883a\u386d\u0b4e\uc8d3\uac6f\u9171\000\u6f6e\u863d\u6d6c\u7e62\u3d17\u3004\u1bdf", "\udb0b\udc6b",
        41, 98517, -432271879, 8573059909157778745L, -29931L, true, false, (char) 20472, (char) 11158,
        Double.longBitsToDouble(0x3fc6098fb1d3f4a8L), Double.longBitsToDouble(0x3fbfd9dbd0000000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 1, 8, 7, 4, "\ud8e7\ude61", "\u9530\u4147\u6e58\ub952\u6ff6\u1f62\u3f03\u4f11\u2bad\u9bfb\u951e\ua515", "\udba3\udc9c\u51f4\ud942\udc1e\ud891\udf0c",
        2, 16249, -1281391885, -8246739288126713066L, 59375L, true, true, (char) 56883, (char) 6297,
        Double.longBitsToDouble(0x3fc1049f4fd00724L), Double.longBitsToDouble(0x3f7743a195eaf600L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[[Lorg.apache.commons.math3.geometry.euclidean.twod.Vector2D;:[[]] |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=[[Lorg.apache.commons.math3.geometry.euclidean.twod.Vector2D;:[[]] |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 2, 4, 4, 7, "\ud8e7\ude61\udacf\udd4c", "\u120f\u6e58\ub952\u4c2b\ud1bd\u3f03\u4f11\u2bad\uab02\u855d\u9441\u151d\u6dcc\u7d6e\u242f\u2df3\u330d\u8c98\u883a\u386d\u91fe\uac14\uac4c\u3952\ube59\u6f6e\u863d\u6d6c\u7e62\u3d17\u8660\u46d6", "\udb0b\udc6b\ud928\udedc\u4e31\u55a2\udbaf\udf1a\ud9aa\udd2f\udaf4\udf44\ud893\udc56\ud9f9\ude78",
        52, 9535, -46556240, 7453259969345685375L, -89528L, true, true, (char) 12011, (char) 11519,
        Double.longBitsToDouble(0x3fe7276fc2e234f5L), Double.longBitsToDouble(0x3fe50fcd355b29efL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 6, 7, 4, "\ud8e7\ude61\udacf\udd4c", "\u1118\u6e58\ub952\u4c2b\ud1bd\u3f03\u4f11\u2bad\uab02\u99dc\u809d\uc978\u61ea\u0f23\u7661\u2df3\u330d\u8c98\u883a\u386d\u058f\uc8cb\uac6f\u3952\ube59\u6f6e\u863d\u6d6c\u7e62\u3d17\u8660\u6c1f", "\udb0b\udc6b\ud928\udedc\u4e31\ud8fb\udc74\udbaf\udf93\ud9aa\udd2f\udaf4\udf44\ud92f\ude44\ud9cd\udc00",
        52, 9535, -47565648, 7453259969345685375L, -89528L, true, true, (char) 37807, (char) 11519,
        Double.longBitsToDouble(0x3fe7276fc2e234f5L), Double.longBitsToDouble(0x3fe50fcd355b29efL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 4, "\ud8e7\ude61\udacf\udd4c", "\005\u0713\ub952\u4c2b\ud1bd\ube0a\u4e4c\u2bad\uab02\u951e\u809d\u1589\u61ea\u0f23\u7661\u2df3\u330d\u8c98\u883a\u386d\u058f\uc8cb\u5e37\u9171\000\u6f6e\u863d\u6d6c\u7e62\u3d17\u3004\u1bdf", "\udb0b\udc6b",
        41, 98517, -432271879, 8573059909157778745L, -29931L, true, false, (char) 20472, (char) 95,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.math3.geometry.euclidean.twod.Line;:@?\0121=new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\012",
        Z.run(T, 2, 1, 7, 8, "\ud8e7\ude61\udacf\udd4c", "\005\u0713\ub952\u4c2b\ud1bd\u4656\u4e4c\u2bad\u2824\u8b31\u809d\u617a\u61ea\u0f23\u7661\u2df3\u330d\u8c98\u883a\u386d\u058f\uc8cb\u5e37\u9171\u0b42\uc35f\u863d\u6d6c\u7e62\u3d17\u3004\u1bdf", "\udb0b\udc6b",
        41, 98517, -432271879, 8573059909157778745L, -29931L, true, false, (char) 64504, (char) 95,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=[[Lorg.apache.commons.math3.geometry.euclidean.twod.Vector2D;:[[]] |this=org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 4, "\ud8e7\ude61\udacf\udd4c", "\005\u0713\u152c\u4c2b\u943c\ube0a\u4e4c\u2bad\uab02\u951e\u809d\u1589\u7e95\u2fc5\uac43\u4a26\u2bab\u8c98\u883a\u386d\u058f\u0b14\u4c60\ud49e\000\u514a\u2d97\ub9f8\u7e62\u344b\u64fd\u4178", "\udb0b\udc6b",
        -1, 925, -432271938, 8573036828003530041L, -29931L, true, false, (char) 62029, (char) 198,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 8, "\ud8e7\ude61\udacf\udd4c", "\005\u0713\ub952\u4c2b\u9b39\ub1d2\u9d67\u2bad\uab02\u951e\u809d\u1589\u61ea\u0f23\u7661\u2df3\u330d\u8c98\u883a\u386d\u058f\uc8cb\u5e37\u0ff6\u73f4\u6f6e\u863d\u6d6c\u7e62\u3d17\u569d\u792d", "\udb0b\udc6b",
        41, 77373, -170177060, 8573059909157778745L, -29931L, true, false, (char) 20472, (char) 95,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3d9c68a000000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.math3.geometry.euclidean.twod.Line;:@?\0121=[Lorg.apache.commons.math3.geometry.euclidean.twod.Line;:@?\012",
        Z.run(T, 2, 1, 1, 4, "\ud8e7\ude61\udacf\udd4c", "\005\ud7f6\u8b96\u4c2b\ud1bd\ube0a\u4e4c\u2bad\uab02\u951e\u809d\u1589\u61ea\u0f23\u7661\u2df3\u330d\u8c98\u883a\u386d\u058f\uc8cb\u5e37\u9171\000\u6f6e\u863d\u6d6c\u7e62\u3d17\u3004\u1bdf", "\udb0b\udc6b",
        41, 98517, -432271879, 8573059909157778745L, -29931L, true, false, (char) 20472, (char) 95,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 4, "\ud8e7\ude61\udacf\udd4c", "\005\u0713\ub952\u4c2b\ud1bd\ube0a\u4e4c\u2b6a\uab02\u951e\u809d\u1589\u61ea\u0f23\u7661\ud524\u330d\u8c98\u4483\u0634\u052d\uc8cb\u5e37\u9171\000\u6f6e\u863d\u6d6c\u7e62\u3d17\u3004\u1bdf", "\udb0b\udc6b",
        41, 65429, -432272121, 8573059909157778745L, -29931L, true, false, (char) 20472, (char) 95,
        Double.longBitsToDouble(0x3d1a600000000000L), Double.longBitsToDouble(0x0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet|computeGeometricalProperties||new:org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:",
    "M|org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet|boxBoundary|double,double,double,double|static",
    "M|org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet|buildNew|org.apache.commons.math3.geometry.partitioning.BSPTree|new:org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:",
    "M|org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet|followLoop|org.apache.commons.math3.geometry.partitioning.utilities.AVLTree$Node,org.apache.commons.math3.geometry.partitioning.utilities.AVLTree|new:org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:",
    "M|org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet|getVertices||new:org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:",
    "C|org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet|<init>|double,double,double,double",
    "C|org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet|<init>|java.util.Collection",
    "C|org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet|<init>|org.apache.commons.math3.geometry.partitioning.BSPTree",
    "C|org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet|<init>|",
    "M|org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet|computeGeometricalProperties||new:org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
