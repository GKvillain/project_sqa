package org.apache.commons.math.ode.nonstiff;
import org.junit.Test;
import static org.junit.Assert.*;
public class EmbeddedRungeKuttaIntegrator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 8, 4, 2, "\udb54\udc8b", "\uc7c6\u8a0d\ud679\u9e97\u8130\uaf9f", "\ud938\udd6c\ud9a7\udc61\ud926\udc7a\uda19\udf7d\udb56\udc28\ud870\udc71\udb41\udf4f\ud969\udead\ud8ed\udc6e\uda4b\udc21\ud858\udfc6\uda9d\udce1\ud8e2\udd1a\udae6\ude20\ud897\udf10\uda1f\udef6\u34fc\ud9dd\udf96\udb36\udc3f\udbf7\udce3\udb92\udcb8\ud9df\ude47\udb4c\udf80\udbae\udcef\udb0e\udc89\ud92e\udf30\ud923\uddd2",
        -4, 95253, 1813493865, 7662246447488976253L, -58386L, false, false, (char) 3813, (char) 57911,
        Double.longBitsToDouble(0x3fbd41c13c492708L), Double.longBitsToDouble(0x3fd9c64d0282a3f0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 8, 4, 2, "\udb54\udc8b", "\uc7c6\u8a0d\ud679\u9e97\u8130\uaf9f", "\ud938\udd6c\ud9a7\udc61\ud926\udc7a\uda19\udf7d\udb56\udc28\ud870\udc71\udb41\udf4f\ud969\udead\ud8ed\udc6e\uda4b\udc21\ud858\udfc6\uda9d\udce1\ud8e2\udd1a\udae6\ude20\ud897\udf10\uda1f\udef6\u34fc\ud9dd\udf96\udb36\udc3f\udbf7\udce3\udb92\udcb8\ud9df\ude47\udb4c\udf80\udbae\udcef\udb0e\udc89\ud92e\udf30\ud923\uddd2",
        -4, 95253, 1813493865, 7662246447488976253L, -58386L, false, false, (char) 3873, (char) 57911,
        Double.longBitsToDouble(0x3fbd41c105592708L), Double.longBitsToDouble(0x3fd9c648e282a3f0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 8, 4, 2, "\udb54\udc8b\ud9a4\ude03\ud9d4\udf06\ud97e\udd40\udbbf\udeab\ud8c3\udd61\ud96a\ude82\uda0f\ude95\ud96e\ude12\ud9d8\ude74\ud962\uddd6\ud954\uddcf\ud9a7\udc61\u97fb\uda22\udf87\udb56\udc28\ud870\udc71\udb41\udf4f\ud969\udead\ud8ed\udc6e\uda4b\udc21\ud858\udfc6\uda9d\udce1\ud8e2\udd1a\udae6\ude20\ud82f\ude4e\udb0a\udfc6\udbfe\uddc6\ud9e8\ude7a\udb36\udc3f\udbf7\udce3\ud8ac\udf5e\ud9f4\udf1b\ud8a3\ude88\udbae\udcef\udb0e\udca9\ud92e\udf30\udac3\udf82\ud928\udc2b\uda16\uddf5\u7225\ud8a4\udea1", "\u0f38", "\udb74\udfba\ud97c\udea1\udba7\udd79\uda83\ude70\udb55\udc8e\udb84\udcf5\uda08\udcf4\udbf1\udc72\udad1\udc2e",
        -1, 48854, -1402048578, 8156068592575008935L, 28657L, true, true, (char) 28195, (char) 60346,
        Double.longBitsToDouble(0x3fe495776ec6ebf0L), Double.longBitsToDouble(0x3fd4c1c491c3f94aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Double:0.2 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 3, 4, 2, "\udb54\udc8b", "\uc7c6\ua110\u62eb\u90e1\u8130\uaf9f", "\ud938\udd6c\ud9a7\udc61",
        49, 39324, 1734346424, 6186994154408681066L, -3576L, true, false, (char) 44328, (char) 49929,
        Double.longBitsToDouble(0x3fe58a2c157828eaL), Double.longBitsToDouble(0x3fe344981b60c746L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 2, "\udb54\udcd1", "\u4889\uc8dd\ud679\u777b\ud190\u205b", "\ud938\udd6c\ud9a7\udc61\ud926\udc7a\uda19\udf7d\ud8dc\udc2b\ud870\udc71\udb41\udf4f\ud91e\udcc8\udafd\udf07",
        35, 69514, 1166190793, 2948229038730313869L, -20992L, true, false, (char) 3468, (char) 31142,
        Double.longBitsToDouble(0x3fdaa8abb2646d80L), Double.longBitsToDouble(0x3fea0fbfcaa6ef76L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 8, 4, 6, "", "\u2122", "\u00e5\000\udb25\udf92\ud8f8\ude2a\ud9fa\udcab\ud964\uddc5",
        17, 4631, 18129, -4899916396446427464L, 56416L, false, true, (char) 11935, (char) 10085,
        Double.longBitsToDouble(0x3ebac00000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[27960.0, 28611.0, 27834.0, 28393.5, 28004.0, 28164.0, 27815.0, 28296.0]]] |a1=[D:[[8504.5, 25472.0, 22455.5, 5695.0, 4726.0, 19469.5, 13534.0, 19147.0]] |a2=[D:[[6758.0, 28084.5, 28434.5, 28035.0, 28167.5, 27938.0, 28362.5, 27633.5]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 1, 4, 2, "\udaa0\udfb6\ud9a4\ude03\udaf8\udc38\ud97e\udd40", "\u42a1\uc730\uaf9f\u2cae\u251c\u984b\u69ec\u95c6\ud3c1\u9acd\ua017\u9875\u2b30\u2946\u6fba\u076a\uc07f\uc12a\u9fef", "\u34fc\udb99\ude55\udb36\udc3f\uda74\uddc5\ud813\udf16\udb8d\udd5e\udb4c\udef7\udbae\udcef\u454c\udaea\udf37\ud95e\udd53\uda96\udc6a",
        1, 62503, 1784005772, 3752700790679389813L, -51255L, true, false, (char) 14480, (char) 31802,
        Double.longBitsToDouble(0x3fec49270ff9560bL), Double.longBitsToDouble(0x3fe4273522b6e029L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=java.lang.Integer:5 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 6, 4, 1, "\udb54\udc8b", "\u1a43\u8a0d\ud679\u9e97\u8130\uaf9f", "\ud938\udd6c\ud9a7\udc61\ud926\udc7a\uda19\udf7d",
        44, 58233, 1089627004, 3359584090713782440L, 32550L, true, false, (char) 31795, (char) 10615,
        Double.longBitsToDouble(0x3fe344981b60c746L), Double.longBitsToDouble(0x3fb96d4895d41210L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[28050.0, 28205.5, 27834.0, 28393.5]]] |a1=[D:[[17646.5, 27428.5]] |a2=[D:[[27748.0, 28413.0]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=java.lang.Integer:5 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 1, 4, 2, "\udb54\udc8b\ud9a4\ude03", "\u8a0d\ud679", "\ud8f8\ude2a",
        17, 42620, 1055731127, -7680882365074159916L, -23896L, true, false, (char) 39749, (char) 35329,
        Double.longBitsToDouble(0x3fc505d3fd650030L), Double.longBitsToDouble(0x3fe1d64b58c91a41L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Double:0.2 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 2, "\udb54\udc8b", "\uc7c6\u8a0d\ud679\u9e97\u8130\uaf9f", "\ud938\udd6c\ud9a7\udc61\ud926\udc7a\uda19\udf7d\udb56\udc28\ud870\udc71\udb41\udf4f\ud969\udead\ud8ed\udc6e\uda4b\udc21\ud858\udfc6\uda9d\udce1\ud8e2\udd1a\udae6\ude20\ud897\udf10\uda1f\udef6\u34fc\ud9dd\udf96\udb36\udc3f\udbf7\udce3\udb92\udcb8\ud9df\ude47\udb4c\udf80\udbae\udcef\udb0e\udc89\ud92e\udf30\ud923\uddd2",
        -4, 95253, 1813493865, 7662246447488976253L, 99803L, true, true, (char) 36728, (char) 13418,
        Double.longBitsToDouble(0x3fd9c64d0282a3f0L), Double.longBitsToDouble(0x3fe410148b7542e5L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=java.lang.Double:NaN |a0=[[D:[[[28050.0, 28205.5]]] |a1=[D:[[25547.0, 16045.5, 10892.5, 22689.5, 16512.0, 20410.5]] |a2=[D:[[27780.0, 28318.0, 27835.5, 28184.5, 27771.0, 28197.0, 27892.5, 28582.5]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 7, 1, 2, "\udb54\udc8b", "\uc7c6\u7d8b\u5549\ub173\u8130\u9fa5", "\ud938\udd6c\ud9a7\udc61\ud926\udc7a\uda19\udf7d\udb58\udf6e\ud870\udc71\ud823\udd79\ud969\ude65\ud8ed\udc6e\uda69\udd7d\ud9e3\udee6\udbe5\udfd8\ud8e2\udd1a\udae6\ude20\ud897\udf10\uda1f\udef6\ud852\udefd\ud9dd\udf96\udbef\uddfa\ud810\udfb4\ud90c\udd30\ud9df\ude47\udb4c\udf80\ud901\udefa\ud86d\udc5e\udada\uddc8\ud827\udf48",
        43, 95253, 1819981929, 7662246447488138877L, -58386L, false, false, (char) 3813, (char) 57911,
        Double.longBitsToDouble(0x3fbd41c13c492708L), Double.longBitsToDouble(0x3fd9c64d0282a3f0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[28050.0, 28205.5, 27834.0, 28393.5, 27858.0, 28523.0, 27815.0, 28296.0]]] |a1=[D:[[1924.0]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 1, 4, 3, "\udb54\udc8b\ud9a4\ude03\ud9d4\udf06\ud97e\udd40\udbbf\udeab\ud8c3\udd61\ud96a\ude82\uda0f\ude95\ud96e\ude12\ud9d8\ude74\ud962\uddd6\ud948\uddcf\ud9a7\udc61\u97fb\uda22\udf87\udb56\udc28\ud870\udc71\udb41\udf4f\ud969\udead\ud8ed\udc6e\uda4b\udc21\ud858\udfc6\uda9d\udce1\ud9c6\udf11\udae6\ude20\ud82f\ude4e\udb0a\udfc6\udbfe\uddc6\ud9e8\ude7a\udb36\udc3f\udbf7\udce3\ud8ac\udf5e\ud9f4\udf1b\ud8a3\ude88\udbae\udcef\udb0e\udca9\ud92e\udf30\udac3\udf82\ud928\udc2b\udb26\uddfd\u7225\ud8a4\udea1", "\u0f38", "\udb74\udfba\ud97c\udea1\udba7\udd79\uda7c\ude2e\udb88\udd3b\ud8af\udc77\uda08\udcf4\udbf1\udc72\udad1\udc2e",
        -1, 14374, -1402048578, 8156068592575008935L, 28657L, true, true, (char) 28195, (char) 60346,
        Double.longBitsToDouble(0x3fe495776ec6ebf0L), Double.longBitsToDouble(0x3fd4c1c491c3f94aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=java.lang.Integer:5 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 4, 4, 2, "\ud94e\udc07", "\u3d43\u1aca\u0f40\u9758\uc595\uaf9f", "\ud9c7\udcf3\ud9a7\udc56\ud9a1\udd84\uda19\udf7d\uda17\udc51\ud946\udc15\udb50\ude3d\ud969\udead",
        -2, 3179, 440531514, 136419469274970707L, -44808L, false, true, (char) 24513, (char) 6965,
        Double.longBitsToDouble(0x3fdf0c34bcb0c6c0L), Double.longBitsToDouble(0x3fbd1db678990918L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[28126.5, 28601.0]]] |a1=[D:[[9493.5, 3465.0, 20219.0]] |a2=[D:[[27625.5, 28618.0]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 1, 4, 2, "\udbed\udfa2", "\u4a5b\u1b42\u9e26", "\ud803\udfc4",
        4, 56725, 1055731127, -2204505218180389935L, 71626L, false, true, (char) 42823, (char) 40636,
        Double.longBitsToDouble(0x3fe1d59770c91a41L), Double.longBitsToDouble(0x3fab037d5dc26660L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:0.2 |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 3, 4, 2, "\udb54\udc8b", "\uc7c6\ua110\u62eb\u90e1\u8130\uaf9f", "\ud938\udd6c\ud9a7\udc61",
        49, 95012, 1728053248, 6186994154408681066L, -3576L, true, false, (char) 45864, (char) 49929,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[27910.0, 28188.0, 27834.0, 28393.5, 27858.0, 28523.0, 28106.0, 28154.5]]] |a1=[D:[[4726.0, 19469.5, 9349.0, 24794.0, 18161.0, 1836.0, 26446.5]] |a2=[D:[[28135.0, 28315.0, 27962.0, 28345.5, 27762.0, 28197.0, 27703.0, 28137.5]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=java.lang.Double:NaN |a0=[[D:[[[27910.0, 28188.0, 27834.0, 28393.5, 27858.0, 28523.0, 28106.0, 28154.5]]] |a1=[D:[[4726.0, 19469.5, 9349.0, 24794.0, 18161.0, 1836.0, 26446.5]] |a2=[D:[[28135.0, 28315.0, 27962.0, 28345.5, 27762.0, 28197.0, 27703.0, 28137.5]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 1, 1, 3, "\uda3c\udc68\ud9a4\ude03\ud9d4\udf06\udbc4\udc25\uda18\ude2d\udaee\udde3\uda26\udcdc\udb2e\uddb7", "\u251c\u984b\u493a\uc1e4\u8e12\u0e88\ucecd", "\udbfe\udd66\udaa4\udda3\ud914\udc7a\ud89e\udc03\ud8cb\udcb5\ud824\udd65\ud9dd\udf00\udbff\udde6\u3bb4\ud95b\udfaa\udb36\udc3f\udbf7\udd34\ud8cc\udcf5\ud9df\udee4\udb76\udd6d\ud931\ude73\ud9d7\udcf6\udb5f\udd90\udb19\ude8c\ud9fe\udee7\udb2c\udf17\udb44\uddc8\uda90\udfb2\udb43\udd52",
        56, 84557, -31547055, 2219574159155667894L, 12907L, true, false, (char) 38339, (char) 3054,
        Double.longBitsToDouble(0x3fcfd8a995b7f28cL), Double.longBitsToDouble(0x3fe899fd0014af07L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 8, 8, 1, "\udb3e\ude90\ud9a4\ude03\ud997\uddab\ud97e\udd40\udbbf\udeab\u00e5\ud83f\udd90\udb4b\uddf1\ud960\udcde\ud9fa\udcab\ud964\uddc5\ud9ec\udc5f\ud9b7\udc69\u467c\ud82d\udcd5\ud82b\udf04\ud891\udcbf\ud8ac\udc49\ud969\udead\ud8ce\udfc6.\uda91\ude68\uda14\udd34", "\u47bf\ubc09\u3e97", "\uda07\udf2c\udae6\udf32\ud9f1\udd6d\udba8\udd1b\u765f\udb11\udd95\udab3\udeaa\ud8d5\udc61\ue800\udb8c\udfee\udb65\ude25\ud9c7\ude95\udb39\uddfb\ud89e\udf21\uda0b\udc6b\udb32\uddcb\ud949\ude63\ud95a\ude30\ud907\ude8a\udaf2\udce6\udbbb\udca4\ud84c\udcdd\ud9e7\udce5\uda29\udc0d\udb40\ude58\udba4\udd44\ud9ec\udf93\ud9a4\ude6c",
        37, 16102, 239735998, -6587043699543464961L, -63411L, true, false, (char) 15870, (char) 26347,
        Double.longBitsToDouble(0x3fdf0871eee649b6L), Double.longBitsToDouble(0x3fe307edec9baa7fL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[28050.0, 28205.5]]] |a1=[D:[[-24.0, -24.0, 8509.5, 20275.5, 16512.0, 22455.5]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 2, "\udb54\udc8b", "\000\000\u42ab\u9e97\u8130\uaf9f", "\udbe7\uddc4\000\ud926\udc7a\uda19\udf7d\udb56\udc28\ud870\udc71\udb41\udf4f\ud969\udead\ud8ed\udc6e\000\000\uda73\udc18\ud8e2\udd1a\udae6\ude20\ud897\udf10\uda1f\udef6\u34fc\ud9dd\udf96\udb36\udc3f\udbf7\udce3\udb92\udcb8\ud9df\ude47\udb4c\udf80\udbae\udcef\udb0e\udc89\ud92e\udf30\"",
        -4, 72765, 0, 873743741L, -100000L, true, false, (char) 3813, (char) 57911,
        Double.longBitsToDouble(0x3fbd41c13c492708L), Double.longBitsToDouble(0x3fd9c64d0282a3f0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[]]] |a1=[D:[[7975.0]] |a2=[D:[[27721.5, 28312.5]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 1, 4, 7, "", "\u3e7e", "\ud8c3\udd61",
        12, 42460, 854503186, -6636669905324190095L, -100000L, false, false, (char) 0, (char) 54967,
        Double.longBitsToDouble(0x3fcc32164df3e258L), Double.longBitsToDouble(0x3ece400000000000L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[12308.0]]] |a1=[D:[[]] |a2=[D:[[]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 1, 4, 2, "\u6058", "", "",
        -5, 2616, 1444143532, -8921790223634848896L, 84905L, true, false, (char) 50489, (char) 14416,
        Double.longBitsToDouble(0x3fe0bda78e676760L), Double.longBitsToDouble(0x3fe352aee3ee40f2L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[27910.0, 28188.0, 27834.0, 28393.5, 27858.0, 28523.0, 28106.0, 28154.5]]] |a1=[D:[[4726.0, 10976.0, 9349.0, 24794.0, 18161.0, 1836.0, 26446.5]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=java.lang.Double:NaN |a0=[[D:[[[27910.0, 28188.0, 27834.0, 28393.5, 27858.0, 28523.0, 28106.0, 28154.5]]] |a1=[D:[[4726.0, 10976.0, 9349.0, 24794.0, 18161.0, 1836.0, 26446.5]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 1, 1, 6, "\uda3c\udc68\ud9a4\ude03\ud9d4\udf06\udbc4\udc25\uda18\ude2d\udaee\udde3\uda26\udcdc\udb2e\uddb7", "\u251c\u55f0\u493a\uc1e4\u8e12\u0e88\ucecd", "\udbfe\udd66\udaa4\udda3\ud914\udc7a\ud89e\udc03\ud8cb\udcb5\ud824\udd65\ud9dd\udf00\udbff\udde6\u3bb4\ud928\udfb3\udb36\udc3f\udbf7\udd34\ud8cc\udcf5\ud9df\udee4\udb76\udd6d\ud931\ude73\ud9d7\udcf6\uda88\udfe6\udb19\udf4e",
        49, 90226, 867217085, -3708003205198025633L, -58877L, true, true, (char) 33038, (char) 17027,
        Double.longBitsToDouble(0x3fd131d1ce58866aL), Double.longBitsToDouble(0x3fd903663debb2f4L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 1, 8, 4, 2, "\udb54\udc8b", "\uc7c6\u8a0d\ud679\u9e97\u8130\uaf9f", "\ud938\udd6c\ud9a7\udc61\ud926\udc7a\uda19\udf7d\udb56\udc28\ud870\udc71\udb41\udf4f\ud969\udead\ud8ed\udc6e\uda4b\udc21\ud858\udfc6\uda9d\udcff\ud8e2\udd1a\udae6\ude20\ud897\udf10\uda1f\udef6\u34fc\ud9dd\udf96\udb36\udc3f\udbf7\udce3\udb92\udcb8\ud9df\ude47\udb4c\udf80\udbae\udcef\udb0e\udc89\ud92e\udf30\ud923\uddd2",
        -4, 95253, 1813493865, 7662246447488976253L, -58386L, false, false, (char) 3813, (char) 57911,
        Double.longBitsToDouble(0x3fbd41c13c492708L), Double.longBitsToDouble(0x3fd9c64d0282a3f0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |a0=[[D:[[[27871.5, 28637.0, 27745.0, 28596.0], [-24.0]]] |a1=[D:[[]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\0121=java.lang.Double:NaN |a0=[[D:[[[27871.5, 28637.0, 27745.0, 28596.0], [-24.0]]] |a1=[D:[[]] |this=org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud9ef\udfea\ud8f2\udf98;\000", "", "\udafb\udc0b",
        3, 69914, 138554773, -2204399072364141615L, 71626L, false, true, (char) 19525, (char) 39341,
        Double.longBitsToDouble(0x3fcbcd620da518c4L), Double.longBitsToDouble(0x3fe03e21abd6fb37L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|integrate|org.apache.commons.math.ode.ExpandableStatefulODE,double|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|estimateError|[[D,[D,[D,double|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|getMaxGrowth||new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|getMinReduction||new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|getOrder||new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|getSafety||new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|setMaxGrowth|double|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|setMinReduction|double|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|setSafety|double|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
    "M|org.apache.commons.math.ode.nonstiff.EmbeddedRungeKuttaIntegrator|integrate|org.apache.commons.math.ode.ExpandableStatefulODE,double|new:org.apache.commons.math.ode.nonstiff.DormandPrince54Integrator:double,double,double,double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
