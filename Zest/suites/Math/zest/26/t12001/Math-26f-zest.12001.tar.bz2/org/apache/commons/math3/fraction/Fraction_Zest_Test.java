package org.apache.commons.math3.fraction;
import org.junit.Test;
import static org.junit.Assert.*;
public class Fraction_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:23 / 20385\0121=org.apache.commons.math3.fraction.Fraction:14789 / 321 |this=org.apache.commons.math3.fraction.Fraction:23 / 321\012",
        Z.run(T, 2, 20, 7, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\ub368\u0825\u4fb6\u6444\ubd3a\u3a07\u3908\u9a32", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\ud86e\ude5d",
        46, 40770, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe8e8c4db2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.fraction.Fraction:23 / 321\0121=new org.apache.commons.math3.fraction.Fraction:23 / 20385\012",
        Z.run(T, 2, 14, 20, 14, "\ud9a0\udfa0\udbf9\udc01\udb1c\udf43\udb07\udd7a\udb3b\udd55\udb7c\udffe\ud8c7\udc35\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\ub368\u0825\u4fb6\u1a32\ubd3a\u3a07\u3908\u9a32", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\uc65f",
        46, 40770, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe8e8c4db2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:46\0121=org.apache.commons.math3.fraction.Fraction:11 / 18 |this=org.apache.commons.math3.fraction.Fraction:11 / 18\012",
        Z.run(T, 2, 17, 6, 2, "\ud9a0\udfa0\udb33\udddf\udb1c\udf71\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\udb64\ude30", "\ub8ac\ud638\ub0f4\u64cd\u8b76\uc871\u954f\ub368\u0825\u4fb6\u6444\u0f64\u2c53\u3908\u9a32", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udb9c\ude54\uda72\udc5e\ud86e\ude5d",
        46, 50050, -1842938460, 4182139139505341959L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fe38e26e0e3947dL), Double.longBitsToDouble(0x3fd2bde706757a40L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:0\0121=org.apache.commons.math3.fraction.Fraction:5207 / 255 |this=org.apache.commons.math3.fraction.Fraction:107 / 255\012",
        Z.run(T, 2, 19, 7, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\ud889\udf5c\udb71\ude61\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd", "\udb5d\uddd0\udb8c\udcca\udaf2\udf77\uda7e\udfad\u5af9\uda2b\udc6f\uda3f\udf90\u988d\udbe9\udc76\udb6d\udd56\udb17\uddc3\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b",
        20, 44601, -336490230, 2286645575821160853L, 41816L, false, false, (char) 23340, (char) 23329,
        Double.longBitsToDouble(0x3fdadaf2a892ba44L), Double.longBitsToDouble(0x3fe6f4faff1d189bL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:46\0121=org.apache.commons.math3.fraction.Fraction:14789 / 321 |this=org.apache.commons.math3.fraction.Fraction:23 / 321\012",
        Z.run(T, 2, 17, 7, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\ud9fd\udd75\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\u4986\ud46f\ub053\u64cd\uc620\u3c12\u954f\u457b\u081b\u4fb6\u6444\ubd3a\u3a07\u3908\u9a32", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\ud86e\ude5d",
        46, 40770, -1653352183, -645719448834754946L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe8e8c4db2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:53 / 29676\0121=org.apache.commons.math3.fraction.Fraction:17036 / 321 |this=org.apache.commons.math3.fraction.Fraction:23 / 321\012",
        Z.run(T, 2, 20, 7, 14, "\udb7b\udc5c\ud92a\udd62\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\uc783\u2e43\u55e7\u64cd\u8b76\uc871\u954f\u8e29\u0825\u4fb6\u384e\u51d2\u8394\u3908\u9a32", "\uda8b\udc74\udb6f\udf17\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\uda1d\udd95",
        53, 29676, -307465849, 9162273888099752777L, -17660L, false, false, (char) 23329, (char) 52206,
        Double.longBitsToDouble(0x3fb25773d6f4faf8L), Double.longBitsToDouble(0x3fe8e8c4db2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:2 / 5225\0121=org.apache.commons.math3.fraction.Fraction:12719 / 442 |this=org.apache.commons.math3.fraction.Fraction:343 / 442\012",
        Z.run(T, 2, 20, 7, 8, "\ud9a0\udfa0\ud875\ude21\udb39\udf32\u64a9\ud953\ude87\ud826\udebd\udb47\udc07\ud819\udc57\ud836\udd74\ud9b3\ude61\ud895\udd88\ud8ca\ude9b\ud86f\udcd1\ud94a\udfad", "\u954f\ub368\u0825\u4fb6\u5cc8\u537d\u0356\u0778\u3ebe\u7405\u28a9\u7aee\u4c32\ubee2\u5f78\u97d3\u4198", "\ud987\udfdb\udb9f\udcfe\uda01\udf6a\ud953\ude4d\ud8f2\ude37\ud9ee\udeee\udb10\uddcc\ud8ae\udde6\ud81c\udca9",
        28, 73150, -755394787, -7152020583675319820L, -18059L, false, true, (char) 25634, (char) 38041,
        Double.longBitsToDouble(0x3fe8d51c3b8d0b82L), Double.longBitsToDouble(0x3fe804eedc513d07L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:93261 / 1999 |this=org.apache.commons.math3.fraction.Fraction:1307 / 1999\0121=org.apache.commons.math3.fraction.Fraction:93261 / 1999 |this=org.apache.commons.math3.fraction.Fraction:1307 / 1999\012",
        Z.run(T, 2, 7, 7, 14, "\ud9a0\udfa0\ud875\ude21\udb0f\udc43\ud9cc\udf3d\000\000\000\ud9be\udf1f", "\ub91c\ud638\u97ff\u64cd\u8b76\uc871\u954f\ub368\u0825\u4fb6\u6444\ubd3a\u3a07\u3908\u4a97", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\ud86e\ude5d",
        46, 40770, 0, -1283915776L, 4221L, false, true, (char) 61775, (char) 5362,
        Double.longBitsToDouble(0x3fe4ec26bea83543L), Double.longBitsToDouble(0x3fee7eb602b12603L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 8, 5, 14, "\ud9a0\udfa0\ud85c\uddbc\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\u464e\ub0f4\u64cd\u8b76\u857b\u7737\ub368\u0825\u5043\u6444\ubd3a\u3a07\u3908\u9a32", "\udb9c\udcb1\udbbc\udcdb\udb93\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\ud86e\ude5d",
        46, 40770, 412473609, 4182139349958739463L, 47876L, false, true, (char) 23259, (char) 50129,
        Double.longBitsToDouble(0x3fe6a79dac85aeffL), Double.longBitsToDouble(0x3fe8e8c4db2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 9, 7, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\udb2b\ude30\ud9c5\udca3", "\ub91c\ud638", "\ud92a\udf9b\ud952\udd01\udb57\udfd0\udb8c\udcca\udaf2\udf77\uda7e\udfad\u5af9\uda2b\udc6f\uda3f\udf90\u988d\udbc2\udce3\udb6d\udd56",
        51, 77698, -1261116385, -3769073054375791390L, -58488L, false, false, (char) 58533, (char) 516,
        Double.longBitsToDouble(0x3fccd57a58b74888L), Double.longBitsToDouble(0x3fe0a51acd063379L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:8 / 9\0121=new org.apache.commons.math3.fraction.Fraction:17 / 19\012",
        Z.run(T, 2, 19, 2, 7, "\ud986\ude24\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d", "\u7389\ub91c\uab41\u2a58\u4d19\u8b3a\u9909\ua9be\u3970\u0825\u4fb6\u6444\ubd3a\u3a07", "\ud919\ude29\udad0\udc87\udb88\udc1d\udbbc\udcdb\udb8a\uddcb\udb76\uddbe\uda63\ude95",
        34, 57489, -1739174399, 8210503066161636326L, -16537L, false, false, (char) 47425, (char) 23340,
        Double.longBitsToDouble(0x3feca1fc6fbe6b43L), Double.longBitsToDouble(0x3fb257755ef4faf8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:20 / 44601\012",
        Z.run(T, 1, 20, 15, 20, "\ud9a0\udfa0\ud809\udd81\udb1c\udef4\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd", "\udb5d\uddd0\udb8c\udcca\udaf2\udf77\uda7e\udfad\u5af9\uda2b\udc6f\uda3f\udf90\u988d\udbc2\udce3\udb6d\udd56\udb17\uddc3\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b",
        20, 44601, -336490230, -7101093553781476971L, 41816L, false, false, (char) 23340, (char) 23329,
        Double.longBitsToDouble(0x3fedf35a1c495dd5L), Double.longBitsToDouble(0x3fe5bb02ff1d189bL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:575 / 582\0121=new org.apache.commons.math3.fraction.Fraction:16\012",
        Z.run(T, 2, 0, 1, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\ud638\ub0f4\ua495\u8b76\uc871\u954f\ub368\u0825\u78b3\u325e\ubd89\uc707\u3908\u99e7", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\ud86e\ude5d",
        16, 55848, -1653352183, 4182139349958739463L, 4221L, false, true, (char) 46287, (char) 272,
        Double.longBitsToDouble(0x3fef9d76eebecc7cL), Double.longBitsToDouble(0x3fc9685051551db8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:59 / 20062\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 20, 10, 12, "\ud9a0\udfa0\ud875\ude21\udad6\udf40\udb50\udfb1\ud842\udd6e\uda07\udc7c\udb6b\udc09\ud9af\udd08\ud836\udd74\ud9b3\ude61\ud895\udd88\ud8ca\ude9b\ud86f\udcd1\udb51\udd31\uda8e\udc8d\ud952\udd01\udb5d\uddd0\udb8c\udcca\udbd2\udfc6\udbe3\ude21\uc911\uda2b\udc6f\uda36\udceb\ud851\udd8c\udbc2\udcec\udb6d\udd56\ud999\udd03\udb08\udefe\udbbc\udc9f", "\u97d3\u5449\u2463\u4b24\u8944\u2f9e\u61ce\u7dec\uaad1\u1764\u6160\u9ab4\ucef3\u21c3\u7008\u38f4\u6d0e\ucf9e\u3051\u2e29\u8e04\u813d\u2b19\u30a1\u0ad0", "\ud9db\udf6d\ud83e\udc9e\udacb\udc5f\u8f8b\ud987\ude4e\ud8ec\udfc7\ud9b0\udd93\ud92b\udeed\ud99e\udd5d\udb1c\udc73\ud9bf\uded2\udabc\uddd4\ud8d3\udd1e\udb55\udd9e\udaa3\udf97\ud83e\udc83\ud979\ude0e\udaa7\udf30",
        59, 20062, -174053474, -6467336372401686692L, 7246L, true, false, (char) 58959, (char) 37124,
        Double.longBitsToDouble(0x3fd0036a809a80d4L), Double.longBitsToDouble(0x3fd58993749f63b6L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:22 / 20385\0121=org.apache.commons.math3.fraction.Fraction:23 / 14124 |this=org.apache.commons.math3.fraction.Fraction:23 / 321\012",
        Z.run(T, 2, 20, 11, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\ub368\u9f68\u26c3\u6444\ubd3a\u3a07\u3908\u9a32", "\ud891\uddaa\ud859\udc8d\udbcf\udc52\udaab\udf04\udafa\udf62\uda6f\udc4b\udb68\udc5a",
        44, 40770, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3f9d189ba8f81c20L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:7\012",
        Z.run(T, 1, 17, 7, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a", "\u61aa\u7697\u4f09\ubad6\ub91c\ud638\ub0f4", "\ud952\udd01\udb5d\uddd0\udb8c\udcca\udaf2\udf77\uda7e\udfad\u5af9",
        7, 88975, -1780373810, -8105609042896476090L, -15322L, false, true, (char) 35253, (char) 148,
        Double.longBitsToDouble(0x3feb8e2b7b941e93L), Double.longBitsToDouble(0x3fd6e0365c033eeeL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:-4 / 88975\0121=org.apache.commons.math3.fraction.Fraction:-113 / 36 |this=org.apache.commons.math3.fraction.Fraction:31 / 36\012",
        Z.run(T, 2, 20, 7, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a", "\u61aa\u7697\u4f09\ubad6\ub91c\ud638\ub0f4", "\ud952\udd01\udb5d\uddd0\udb8c\udcca\udaf2\udf77\uda7e\udfad\u5af9",
        -4, 88975, -1778857499, -8105609042896476090L, -15322L, false, true, (char) 35253, (char) 148,
        Double.longBitsToDouble(0x3feb8e2b7a282f93L), Double.longBitsToDouble(0x3fe574e46601faa4L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:0\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 5, 8, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udadb\ude7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\ud638\ub0f4\u73e6\u374a\uc871\u954f\ub368\u0825\u4fb6\uc440\ubd3a\u3a07\u3908\u9a32", "\udb9c\udcb1\udbbc\udcdb\ud952\udeae\ud983\ude03\udb13\udd66\uda6f\udc4b\ud86e\ude5d",
        46, 40770, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe8e8c4db2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:23 / 20385\0121=org.apache.commons.math3.fraction.Fraction:645 / 14 |this=org.apache.commons.math3.fraction.Fraction:1 / 14\012",
        Z.run(T, 2, 20, 7, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\ub6c9\u085f\u4fb6\u6444\ubd3a\u3a07\u3908\u9a32", "\udb2c\uddb9\udbd0\uddd0\udb8a\uddcb\ud9a6\udd6e\udb68\udf02\ud80c\uddc8\ud86e\uddc7",
        46, 40770, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23433, (char) 33537,
        Double.longBitsToDouble(0x3fb249b556f4faf8L), Double.longBitsToDouble(0x3fe685f4db2c7f21L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:23 / 20385\0121=java.lang.Float:0.07165109 |this=org.apache.commons.math3.fraction.Fraction:23 / 321\012",
        Z.run(T, 2, 20, 15, 3, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\u4986\ub0d1\u64cd\u8b76\uc871\u954f\ub368\u0825\u4fb6\u6444\ubd3a\u3a07\u3908\u9a32", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\ud86e\ude5d",
        46, 40770, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe8e8c4db2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:40 / 63897\0121=org.apache.commons.math3.fraction.Fraction:16764 / 413 |this=org.apache.commons.math3.fraction.Fraction:244 / 413\012",
        Z.run(T, 2, 20, 7, 14, "\ud9a0\udfa0\ud88b\udf4b\udb3e\udc4f\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud863\uded2\ud836\udd74\ud99f\ude2e\ud895\udd88\ud8ca\ude9b\uda2b\udf4e\ud94a\udff7\ud92a\udf9b", "\ub3de\u0825\u6fb6\u5458\u96cd\u31e0", "\ud870\udda9\ud9e3\udc38\udbbf\ude3d\udbbc\udcdb\udba2\udff6",
        40, 63897, -1081302488, -6384098318879535615L, 21097L, true, true, (char) 32784, (char) 35201,
        Double.longBitsToDouble(0x3fe2e7d72e0e151eL), Double.longBitsToDouble(0x3fe4a1fc6fbe6ba6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Double:0.07165109034267912 |this=org.apache.commons.math3.fraction.Fraction:23 / 321\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 13, 9, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\ub368\u0825\u4fb6\u6444\ubd3a\u3a07\u3908\u9a32", "\udb9a\udd37\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\ud86e\ude5d",
        46, 40770, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe8e8c4d96674ebL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:-4 / 41937\0121=java.lang.Boolean:false |this=org.apache.commons.math3.fraction.Fraction:77 / 118\012",
        Z.run(T, 2, 20, 14, 2, "\udbe5\ude0a", "\u38e9", "\ud8c7\udc9d\ud9be\udf1f\udbc2\ude5b\ud9b3\ude61\ud895\udd88\ud98c\udf3d\ud810\uddde",
        -4, 41937, -1435849225, 5099978960443830547L, 45592L, false, true, (char) 56207, (char) 47246,
        Double.longBitsToDouble(0x3fe4e1b2cf8595ffL), Double.longBitsToDouble(0x3fb1a3e0eac2afb0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:23 / 20385\0121=new org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 2, 20, 19, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc820\u954f\ub368\u0825\u4fb6\u6444\ubd3a\u3a07\u3908\u9a32", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\ud86e\ude5d",
        46, 40770, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe8e8c4db2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:46\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 17, 12, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\u5342\u6f1b\u1e92\u8b76\uc871\u954f\ub368\u0825\u4fb6\u6444\ubd3a\u11a6\u3908\u9a32", "\ud997\udc64\udbbc\udcdb\udb46\udd40\ud9a6\udd6e\ud94b\udfdf\uda62\ude2f\ud86e\ude5d",
        46, 23474, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577546f4faf8L), Double.longBitsToDouble(0x3fe8e8c2132cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 9, 7, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\ud959\ude34\udb5a\udc6e\uda82\udc7a\ud8c7\udc9d\udab0\uddb7", "\u6ac3\u46a0", "\ud92a\udf9b\ud952\udd01\udb7a\udc64\udb92\udccd\udb12\udd77\udbae\udf26\uda05\udd35\u9e3b\uda3f\udf71\uda60\udf28\udbd5\udcfe\udb6d\udd56",
        40, 77698, -1261148854, -3768997351282232094L, -58488L, false, false, (char) 18598, (char) 10592,
        Double.longBitsToDouble(0x3fd09ebf132b3ae6L), Double.longBitsToDouble(0x3fe63aa049731372L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:44 / 19161\0121=new org.apache.commons.math3.fraction.Fraction:1\012",
        Z.run(T, 2, 20, 5, 14, "\ud9a0\udfa0\ud875\ude21\udb4c\udc43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9ff\ude29", "\ub91c\ud654\ub0f4\u64cd\ub3f1\uc880\u3de0\u333a\ubb82\u4fb9\u6444\ubd3a\u3a07\u3692\u0fad\u9b54\u7ddc\uba16\ub058\u2772\u4549\u8c37\u5449\u2454\u4b24\u8944\u5c3c\u9e5e\ucb53\uc7fb\u533e\u2a0b\ub375\u79e3\ua1a0\u6fe1\ub1bf", "\udb63\udcc3\udb69\ude1b\udb65\ude29\ud89c\udd9e\uda9b\udfc2",
        44, 19161, -1397694488, 7950659739454096683L, -66028L, false, true, (char) 55128, (char) 47016,
        Double.longBitsToDouble(0x3fe6a10c5c12bf72L), Double.longBitsToDouble(0x3fdb2458beae7884L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 12, 7, 14, "\ud986\udcd1\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\ub368\u0825\u4fb6\u6444\ubd3a\u3a07\u3908\u9a32", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\ud86e\ude5d",
        46, 40770, -1653352183, 4182139349958739463L, -17788L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe8e8c4db2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:-1 / 95152\0121=org.apache.commons.math3.fraction.Fraction:-52 / 197 |this=org.apache.commons.math3.fraction.Fraction:145 / 197\012",
        Z.run(T, 2, 20, 7, 14, "\ud8a5\udce6\uda8c\udf75\ud95c\udef7\udb07\uddf0\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\uda97\udf2c", "\ub91c\ud638\u098d\u64cd\u8b76\uc871\u954f\ub368\u0825\u4fb6\u6444\ubd3a\u3a07\u3908\u9a32\u7869", "\udbbc\udcdb",
        -1, 95152, 798166897, -7156437517242123602L, -12124L, true, true, (char) 36616, (char) 32784,
        Double.longBitsToDouble(0x3fe78d9bce5cfae5L), Double.longBitsToDouble(0x3fe070a8f3943f8dL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:-1 / 8152\0121=org.apache.commons.math3.fraction.Fraction:-5 |this=org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 2, 20, 7, 17, "\000\ud85c\udd2e\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud8fc\udf1e", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\ub368\u0825\u4fb6\u6444\ubd3a\u3a07\u3908\u9a32", "\udb9c\udcb1\udba2\udfdb\udb8a\uddcb\ud9a6\udd6e\uda95\udf79\uda6f\udc23\udaa2\udeb7",
        -5, 40760, -1653352183, 4182139349958739463L, -17568L, false, false, (char) 23329, (char) 27459,
        Double.longBitsToDouble(0x3e30000000000000L), Double.longBitsToDouble(0x3fe8e8c4db2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:1\0121=org.apache.commons.math3.fraction.Fraction:10746 / 203 |this=org.apache.commons.math3.fraction.Fraction:190 / 203\012",
        Z.run(T, 2, 19, 7, 14, "\ud9ae\ude4d\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\u9ca9\ua38b\u64cd\u607f\u30e5\u6c61\u1d81\u0825\u4fb6\u6444\ubd3a\u3a07\u3908\u573c", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud82d\ude04\udae0\uddfb\uda6f\udc4b",
        52, 12883, -336492174, -289025286352242904L, -89256L, false, true, (char) 8136, (char) 23398,
        Double.longBitsToDouble(0x3fedf35a1c495dd5L), Double.longBitsToDouble(0x3fdf98224e3a3136L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:23 / 20385\0121=org.apache.commons.math3.fraction.Fraction:1 / 642 |this=org.apache.commons.math3.fraction.Fraction:23 / 321\012",
        Z.run(T, 2, 20, 11, 14, "\uf00a\ud875\ude21\udb1c\udf43\udb07\udd7a\u205b\udb63\ude7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\ub368\u0825\u4fb6\u6444\ubd3a\ua395\ud12b\uaec4", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udb68\udf9d\uda32\ude39\ud87d\udf37",
        46, 40770, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe8e8c4dfe6d2f9L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:14789 / 321 |this=org.apache.commons.math3.fraction.Fraction:23 / 321\0121=new org.apache.commons.math3.fraction.Fraction:23 / 321\012",
        Z.run(T, 2, 7, 0, 14, "\ud914\udf34\ud875\ude21\udb1c\udf43\udb07\udd7a\ud9f3\udc11\uda8a\udc86\ud8c7\udc9d\udb57\udd6b", "\u98e8\ud638\ub0f4\u64cd\u8b76\uc871\u0b88\ud7b9\u6023\u4fb6\u6444\ubd3a\u6424\u2f9a\u9a81", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\ud984\uddf1\uda6f\udc4b\ud86e\ude5d",
        46, 40770, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe8e8c4df2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:11 / 40770\012",
        Z.run(T, 1, 20, 7, 14, "\ud9a0\udfa0\ud875\ude21\udb18\udf25\uda1d\ude86\udad7\udd12\uda82\udc65\ud9d6\udf25\uda19\udec4", "\u5a41\u17de\u0a10\u0e57\u75c8\u5f7e\u9516\ub368\u0825\u4fb6\u946e\ubda5\u3a07\ub08b\u9a32", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\ud86e\ude5d",
        11, 40770, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb257754e7022f8L), Double.longBitsToDouble(0x3fe8ec4cdb2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:0\0121=org.apache.commons.math3.fraction.Fraction:23 / 321 |this=org.apache.commons.math3.fraction.Fraction:23 / 321\012",
        Z.run(T, 2, 20, 7, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\udbb7\udd53\uda3a\ude53\udafa\uddd9\ud9fb\udfe7", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\ub368\u0825\u4fb6\u6444\uaf3b\u3a07\u3908\u9a32", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\ud85b\ude01\udad8\udff1",
        0, 40770, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe9342fdb2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:204 / 257\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 10, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\uda0d\udfde\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f\ud836\udd74\ud9b3\ude61\ud895\udd88\ud8ca\ude9b\ud86f\udcd1\ud94a\udfad\ud92a\udf9b\ud952\udd01\udb5d\uddd0\udb8c\udcca\udaf2\udf77\uda7e\udfad\u5af9", "\u3908\u9a32\u7a49\u1c7a\uba16\u4c32\ubee2", "\uda6f\udc4b\ud86e\ude5d\ud81b\udfe5\ud987\udfdb\ud8d8\udf3a",
        32, 34463, -1218137051, 6051823070865689454L, 90530L, true, false, (char) 25149, (char) 44983,
        Double.longBitsToDouble(0x3fe96697cb9afdd9L), Double.longBitsToDouble(0x3fba209840d7a310L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:23 / 20385\0121=new org.apache.commons.math3.fraction.Fraction:23 / 20385\012",
        Z.run(T, 2, 20, 20, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\ub368\u0825\ub427\u9d34\ubd3a\u3a07\u3908\u9a32", "\ud937\udf1e\uda1c\udd98\ud9ed\udedb\ud9a6\udcba\udae0\ude3e\uda6f\udc4b\ud86e\ude5d",
        46, 40770, -1653352183, 4181937469315958279L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe8e8c4db2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:1 / 200\0121=org.apache.commons.math3.fraction.Fraction:-5 |this=org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 2, 20, 7, 0, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\000", "\000\ud92a\udf9b\udb15\udc02\udb53\udc28\udb8c\udcca\u22c2\uda4d\udc65\ud8be\udfcc\000\000\ud905\udedb",
        -5, -1000, 0, -5540917381182495414L, -48002L, false, false, (char) 0, (char) 39936,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd09000032b3ae6L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:27\012",
        Z.run(T, 1, 17, 10, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\ud8e5\udc0d\uda8c\udfb1\ud8c7\udc9d\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u99f8\u312f\ub930\ub368\u0825\u4fb6\u6444\ubd3a\u3a07\u3908\u9a32", "\udb9c\udcb1\udaa6\udcd0\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\ud900\uddc6",
        27, 34633, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23329, (char) 20737,
        Double.longBitsToDouble(0x3fb2577540204cf0L), Double.longBitsToDouble(0x3fe8ea9a5b2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:23 / 321 |this=org.apache.commons.math3.fraction.Fraction:23 / 321\0121=java.lang.Double:0.07165109034267912 |this=org.apache.commons.math3.fraction.Fraction:23 / 321\012",
        Z.run(T, 2, 6, 13, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\ub368\u0825\u4fb6\u6444\ubd3a\u3a07\u3908\u9a32", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\ud86e\ude5d",
        46, 40770, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fd3973ea659a4c0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:23 / 321 |this=org.apache.commons.math3.fraction.Fraction:23 / 321\0121=org.apache.commons.math3.fraction.Fraction:23 / 321 |this=org.apache.commons.math3.fraction.Fraction:23 / 321\012",
        Z.run(T, 2, 6, 6, 6, "\udb3b\ude26\udae3\udc41\udbae\udccd\udaf4\udded\udb3b\udd55\uda82\udc7a\ud950\udc0a\ud964\udc64", "\ub91c\ua283\ub1a7\u64fe\u9ade\uc84a\u1222\ub373\u5ac2\u5049\u7255\u026f\ucc62\u454f\u9a32", "\udb9c\udcec\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\ud805\udd30",
        29, 40770, -1653352183, 4182139349958739463L, -56799L, false, false, (char) 60544, (char) 14593,
        Double.longBitsToDouble(0x3fb2574456f4faf8L), Double.longBitsToDouble(0x3fe8e8c4dd2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:0\0121=new org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 2, 18, 18, 6, "\ud9a0\udf57\ud91e\udcf5\uda7f\udeb0\udaff\udc83", "\u39a9\u20e9\u4f53\ubad6\u7cf7\uc053\ub08b", "\ud952\udd01\udaaf\udd1e\udb8f\udeca\udaf2\uded2\uda7e\udfad\u5af9",
        -4, 88975, -1778421042, -8105609042896476090L, -15322L, false, true, (char) 43957, (char) 62870,
        Double.longBitsToDouble(0x3fe95ef8f46ae262L), Double.longBitsToDouble(0x3fe574e463cfd3a4L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:21\0121=new org.apache.commons.math3.fraction.Fraction:21\012",
        Z.run(T, 2, 1, 17, 14, "\udb11\udc59\ud868\uddfb\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud894\udf8c", "\u0cbd\u0638\u2736\u71f1\u8b76\uc871\u954f\ub368\ubd56\u9dbb\uc816\ua030\ucf56\u6c4b\u3d24", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\uda17\udec7\udb4e\udd50\uda6f\udc4b\ud86e\ude5d",
        21, 41473, -1776756397, 4182202463407548423L, 36390L, false, false, (char) 38184, (char) 52601,
        Double.longBitsToDouble(0x3f9575085bd3ebe0L), Double.longBitsToDouble(0x3feb6c3e2315b2eeL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:6 / 10349\0121=org.apache.commons.math3.fraction.Fraction:13473 / 277 |this=org.apache.commons.math3.fraction.Fraction:177 / 277\012",
        Z.run(T, 2, 20, 7, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud88d\udc40\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\ub368\u0825\u4fb6\u6444\ubd3a\u3a07\u0dc6\u267e", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\ud86e\ude5d\ud81b\udfe5\ud987\udfdb\ud8d8\udf3a\uda55\udd00\ud9cc\udd84\u6dbb\uda6d\udf9a\udb10\uddcc\ud8ae\udde6\uda57\udd45\ud8bd\ude97\ud8d9\udc51\udad7\udc75\ud826\udd21\udb82\udcfe\ud9b3\ude0e\uda73\udd72\udbf0\udd1c\ud9e5\udf1c\uda4d\udcf7\ud8c7\udef0\uda48\udd97\uda53\udd37\ud840\ude42\ud8e6\ude8c\uda9b\udca3\udaf8\udd4a\ud8b7\udd4c\ud8e4\udf43\ud942\udff4\udaf6\udc9d\ud9ae\udf18\ud9d9\ude31\ud8cf\udc7d\udbd2\udce4\udb49\udf19\udbc8\udfe4\ud846\udc78",
        48, 82792, -1757427529, 2832554830654131381L, 19005L, true, true, (char) 34126, (char) 63426,
        Double.longBitsToDouble(0x3fe4729e265b2758L), Double.longBitsToDouble(0x3fe530ccacb7825cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:0\0121=new org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 2, 3, 3, 14, "\ud9a0\udfa0\ud875\ude21\ud8c2\udd8c\ud9c7\udf5c\udb33\udd3b\uda92\udf5d\ud8c7\udc9d\ud903\udeb4", "\ub91c\u6086\u6754\uc17c\u8b19\u7191\u4edb", "\uda7e\udfad",
        58, 89567, 2131971511, -7696137567283767418L, -34376L, false, true, (char) 6245, (char) 35253,
        Double.longBitsToDouble(0x3fcc59763dc6ca2cL), Double.longBitsToDouble(0x3fe1417c9aae9c8cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:3 / 30145\0121=new org.apache.commons.math3.fraction.Fraction:3 / 30145\012",
        Z.run(T, 2, 20, 20, 14, "\ud9a0\udfa0\udbf9\udc01\udadb\udef3\ud833\ude96\udb3b\udd55\udb7c\udffe\ud8e7\ude91\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64ed\u2b76\u09d2\u954f\ub368\u0825\u4fb6\u1a32\ubd3a\u3a07\u3908\ud530", "\udb9c\udcb1\udbbc\udcdb",
        6, 60290, 798166897, -7166174613319959890L, 59478L, true, true, (char) 36616, (char) 32784,
        Double.longBitsToDouble(0x3fe0459bce5cfae5L), Double.longBitsToDouble(0x3fe070a8f3943f8dL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.fraction.Fraction:23 / 321\0121=java.lang.Boolean:false |this=org.apache.commons.math3.fraction.Fraction:23 / 321\012",
        Z.run(T, 2, 14, 14, 13, "\ud9a0\udfa0\udbf9\udc01\udb1c\udf43\udb07\udd7a\udb3b\udd55\udb7c\udffe\ud8c7\udc35\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\u6a1c\u2000\uadd7\u3625\u3b3d\u3a07\u3908\u9a32", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\uc65f",
        46, 59458, -1434734430, 4182139629131613703L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe8e8c4dbe19935L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:0\0121=new org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 2, 20, 20, 14, "\ud9a0\udfa0\udbf9\udc01\udb1c\udf43\udb07\udd7a\udb3b\udd55\ud896\udd72\ud9e7\ude61\ud929\udd02", "\ub91c\ud638\ub0f4\u64cd\u59c3\u39cc\u953e\ub368\u0825\u4fb6\u1a32", "\u988d\ud9dd\udc0f\udaaf\udddc\ud871\udeae\ud8ab\udd8e\udbbc\udd73\uda25\udeb8",
        0, 63897, -1668505048, 4513797245803777537L, -90025L, true, false, (char) 9482, (char) 35201,
        Double.longBitsToDouble(0x3fe2e7d72f34d53aL), Double.longBitsToDouble(0x3feca1fc6fbe6b43L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.fraction.Fraction:23 / 321\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 14, 9, 14, "\ud9a0\udfa0\udb40\udda5\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda1e\udd90\ud8c7\udc35\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\ub368\u0825\u4fb6\u1a32\ubd3a\u3a07\u3908\u9a32", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\uc65f",
        46, 40770, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe8e8c4db2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:0\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 19, 9, 12, "\ud9a0\udfcc\udbf9\udc01\udb1c\udf43\ud941\udc58\ud924\udd7c\uda53\udc05\udaa6\udcb9\ud9be\udf1f", "\ub91c\ud638\u10f4\u64cd\u8b76\uc871\u6550\uca26\u0825\u6037\u19e2\ubd3a\u6dcd\u9151\u9a32", "\ud812\udf89\udbbc\udd6b\uda5d\udc54\ud9a6\udd24\udae0\ude3e\uda6f\udc4b\uc65f",
        46, 40770, 1121087497, 6352246978708588112L, -17660L, false, true, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe8e8c4db2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:0\0121=new org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 2, 3, 19, 14, "\ud9a0\udfa0\udbf9\udc01\udb1c\udf43\udb07\udd7a\udb3b\udd55\udb7c\udffe\ud8c7\udc35\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u1aeb\u5dd3\u0825\u4fb6\u1a32\ubd3a\u3a07\u3908\u220f", "\udb9c\udcb1\udbbc\udcdb\udb8a\udcec\ud8c5\udd5d\udae0\ude86\uda6f\udc4b\uc65f",
        46, 40770, -1653352183, 4182139349958739463L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3feba414db2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.MathArithmeticException\012",
        Z.run(T, 2, 11, 19, 2, "\ud9a0\udfa0\udbf9\udc01\udb1c\udf43\udb07\udd7a\udb3b\udd55\udb7c\udffe\ud8c7\udc35\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\ub368\u027e", "\uda2b\udc6f\uda3f\udf90\u988d\udbc2\udce3\udb6d\udd56\udb17\uddc3\udb9c\udcb1\udbbc\udcdb\uda3b\uddc5\ud9a6\udd6e\udae0\ude3e",
        0, 44318, -1739174399, 6173323061362191314L, -16537L, false, false, (char) 47425, (char) 23340,
        Double.longBitsToDouble(0x3feca1fc6fbe6b43L), Double.longBitsToDouble(0x3fb2577556f4faf8L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:40\0121=org.apache.commons.math3.fraction.Fraction:134 / 177 |this=org.apache.commons.math3.fraction.Fraction:134 / 177\012",
        Z.run(T, 2, 17, 6, 2, "\ud9ad\udf9f\udbb9\udecc\ud81d\udccb\ud9df\udd72\udadf\udfd7", "\u7fb0", "\ud895\udd18\udaa6\udf94\ud86f\udcd1\ud8c6\udfab\ud8a5\udd6a\ud952\udc0a\udb5d\uddd0\udb8c\udcca\udaf2\udf77\uda7e\udfad\u5af9\ud984\udd5c\ud851\udc60\ud8da\udc86\udbc2\udce3\udb83\udd56",
        40, 77698, -1261148854, -3768997351282232094L, 11103L, false, true, (char) 21866, (char) 33595,
        Double.longBitsToDouble(0x3fe839d04dac0696L), Double.longBitsToDouble(0x3fe2e7d72e0e151eL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 19, 5, 2, "\ud9a0\udfa0\udb33\udddf\udb1c\udf71\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\udb64\ude30", "\u8236\ud188\ub001\u1180\u8b76\uc871\u954f\ub368", "\u5af9",
        15, -338, -1780373810, -8105609042896453562L, -15322L, false, true, (char) 35253, (char) 148,
        Double.longBitsToDouble(0x3fec5e2b7e3b2f52L), Double.longBitsToDouble(0x3fe574e465abfaa4L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Float:0.60833335 |this=org.apache.commons.math3.fraction.Fraction:73 / 120\0121=java.lang.Float:0.60833335 |this=org.apache.commons.math3.fraction.Fraction:73 / 120\012",
        Z.run(T, 2, 15, 15, 2, "\ud9a0\udfa0\udb7d\udcc4\ud906\udec4\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\udb64\ude30", "\ub8ac\u4038\ub0f4\u64cd\u8b76\uc871\u14a5\ub368\u0825\uac8b\u638b", "\udb50\udea0\udbc2\udce3\udb83\udd56\udb17\uddc3\udb9c\udcb1\udbbc\udcdb",
        6, 16394, -344122893, -7166160793256052050L, -6058L, false, true, (char) 5742, (char) 40525,
        Double.longBitsToDouble(0x3fe3776a575cfae5L), Double.longBitsToDouble(0x3fe997d820f879c9L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:1\0121=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 5, 19, 12, "\ud9a0\udfa0\udb33\udddf\udb15\udd71\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\udb64\ude30", "\ub85b\ud638\ub9d0", "\udbe5\udeaa\udb0b\udee2\ud8f1\udc8c\uda3d\udf9b\ud869\udf80\udb82\udd69",
        15, -338, -1780373810, -8105609042896453562L, 24102L, false, true, (char) 35253, (char) 148,
        Double.longBitsToDouble(0x3fec5e2b7e3bcf52L), Double.longBitsToDouble(0x3fe574e46601faa4L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:0\0121=new org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 2, 19, 16, 14, "\ud971\ude57\ud875\ude21\udb1c\udf43\ud889\udf5c\udb71\ude61\uda82\udc7a\ud8c7\udc9d\ud8a4\udef2", "", "\ud86f\udcd1\ud94a\udfad\ud92a\udf9b",
        49, 44984, 28947, 1251737600L, 88577L, true, true, (char) 15986, (char) 38393,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd3ad43da956634L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:0\0121=!org.apache.commons.math3.exception.MathArithmeticException\012",
        Z.run(T, 2, 19, 11, 11, "\ud9a0\udfa0\ud875\ude21\ud96d\udd8c", "\u13e0", "\ud9eb\udfd3\ud9ac\uddc1\ud895\udd88\ud8ca\ude9b",
        0, 15285, 1666239937, -8734744708895135320L, -738L, true, true, (char) 54696, (char) 9803,
        Double.longBitsToDouble(0x3fe938e01be83bfaL), Double.longBitsToDouble(0x3fefa2a92c3ad491L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:39 |this=org.apache.commons.math3.fraction.Fraction:0\0121=org.apache.commons.math3.fraction.Fraction:39 |this=org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 2, 7, 7, 14, "\ud9a0\udfa0\ud875\ude21\udb0f\udc43\ud9c7\udd3d\000\000\000\ud9be\udf1f", "\ub91c\ud638\u97ff\u64cd\u4e7d\u79c5\ub6a0\ub368\u0825\u4fb6\uc5bf\ubd3a\u3a07\u3908\u4a97", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\udba9\udf5d\udaee\udf76\udb8a\udf38\udbf7\udd07",
        39, -394, -693878479, -3341250997250359296L, 75500L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3ecaab7a7d7c0000L), Double.longBitsToDouble(0x3fe8e8c4db2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:152825 / 3758 |this=org.apache.commons.math3.fraction.Fraction:2505 / 3758\0121=org.apache.commons.math3.fraction.Fraction:152825 / 3758 |this=org.apache.commons.math3.fraction.Fraction:2505 / 3758\012",
        Z.run(T, 2, 7, 7, 14, "\ud9a0\udfa0\ud875\ude21\udb0f\udc43\ud9cc\udf3d\000\000\000\ud9be\udf1f", "\u94ab", "\ud9a2\ude5a\ud92a\udf76\ud952\udd01\udb5d\uddd0\udb8c\udcca",
        40, 94616, -219053122, 6192765453742650807L, -34376L, false, true, (char) 6245, (char) 13237,
        Double.longBitsToDouble(0x3fe5549b5ca41313L), Double.longBitsToDouble(0x3fcdbcf8cbbe7230L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:3 / 872\0121=new org.apache.commons.math3.fraction.Fraction:56 / 109\012",
        Z.run(T, 2, 20, 0, 10, "\udafe\udeb3\ud8f6\udfe1\udb0f\udc43\ud9cc\udf3d\000\000\000\ud9be\udf1f", "\ub91c\ud638\u97ff\u64cd\uc8fb\uc81c\u954f\ub368\u2fab\u5031\u6444\ubd3a\u3a07\u3908\u4a97", "\udb9c\udcb1\uda2f\ude91\udb89\udd4b\ud9a6\udd6e",
        48, 13952, -89900370, -7469697166081945334L, -100000L, false, false, (char) 35201, (char) 47425,
        Double.longBitsToDouble(0x3fe070a803943f8dL), Double.longBitsToDouble(0x3fedf35a1c0000d5L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:33623 / 720 |this=org.apache.commons.math3.fraction.Fraction:503 / 720\0121=org.apache.commons.math3.fraction.Fraction:33623 / 720 |this=org.apache.commons.math3.fraction.Fraction:503 / 720\012",
        Z.run(T, 2, 7, 7, 14, "\ud9a0\udfa0\uda1c\udc23\ua471\ud9a6\udef7\ud81c\uddee\ud974\udf1a\udae9\udc53\ud9be\udf1f", "\ub91c\ud638\u97ff\u64cd\u8b76\uc871\u954f\ub368\u0825\u97eb\u6444\ubd3a\u3a07\u3908\u575e", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udcd0\ud880\udfcb",
        46, 40770, 0, -1283915776L, 4221L, false, true, (char) 61775, (char) 5362,
        Double.longBitsToDouble(0x3fe65b06bfa8ce2fL), Double.longBitsToDouble(0x3fee7eb59ab12603L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:467 / 18420 |this=org.apache.commons.math3.fraction.Fraction:467 / 921\0121=org.apache.commons.math3.fraction.Fraction:467 / 18420 |this=org.apache.commons.math3.fraction.Fraction:467 / 921\012",
        Z.run(T, 2, 11, 11, 7, "\ud986\ude24\ud81e\ude54\udb4b\ude61\ud86e\udc79\udb3b\udd55\uda82\udc7a\ud8c7\udc9d", "\u2aae\u7e41\uab41\u2a58\u4d19\u8b3a\u9909\u43de\u3970\u0825\u4fb6\u6444\u2456\u3a07", "\ud919\ude29\udad0\udc87\uf8b8",
        20, 49824, 1379811752, 5102136140539662176L, -54433L, false, true, (char) 21975, (char) 29022,
        Double.longBitsToDouble(0x3fe039d04e08b379L), Double.longBitsToDouble(0x3fe2e7d72e0e151eL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 18, 0, 0, "\000", "\u38e9", "\ud8c7\udc9d\ud9be\udf1f\ud836\udd74\ud9b3\ude61\ud895\udd88\ud8ca\ude9b\ud86f\udcd1",
        13, 41937, -842533897, 5086017155716116755L, 88577L, true, false, (char) 15986, (char) 44165,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd3a0000a956634L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:49 / 44984\0121=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 20, 18, 0, "\udb27\ude77\ud80d\udfca\udb49\udcf3\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\000", "\udae8\udd2e\ud92a\udf92",
        49, 44984, -80187117, 38217868420864L, -100000L, false, false, (char) 4425, (char) 225,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd000000a956634L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math3.fraction.Fraction:23 / 321\0121=java.lang.Boolean:false |this=org.apache.commons.math3.fraction.Fraction:23 / 321\012",
        Z.run(T, 2, 14, 14, 13, "\ud9a0\udfa0\udbf9\udc01\udb1c\udf43\udb07\udd7a\udb3b\udd55\udb7c\udffe\ud8c7\udc35\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\u6a1c\u2000\uadd7\u3625\u3b3d\u3a07\u3908\u9a32", "\udb9c\udcb1\udbbc\udcdb\udb8a\uddcb\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\uc65f",
        46, 59458, -1434468224, 4182139629131613703L, 79804L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe8e8c4dbe19935L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=org.apache.commons.math3.fraction.Fraction:-31 / 916 |this=org.apache.commons.math3.fraction.Fraction:31 / 229\0121=org.apache.commons.math3.fraction.Fraction:-31 / 916 |this=org.apache.commons.math3.fraction.Fraction:31 / 229\012",
        Z.run(T, 2, 11, 11, 11, "\ud889\uddd6\ud8b8\udceb\ud97a\udc32", "\u356b\uc94f\u7a22\ub4be\ub76f\u905e\u18d0\u4aa1\u8805\ubd7b\u8395\ucf95\u7965\u98e3\u3d7d\uc69f\u0a7b\u90e3\u963e\u9c78", "\udaf9\uddb8\udb80\udc7e\udb24\udefc\ud892\uddd8\udbe4\uddde\ud82e\udeb6\udb34\udea7\udbe1\udc57\ud9d8\ude66\ud974\udfe9\uda98\udeb7\ud8df\udf9f",
        -4, 5247, 1569264140, -4547466761794429507L, -34291L, false, true, (char) 16731, (char) 54789,
        Double.longBitsToDouble(0x3fc154232bce9098L), Double.longBitsToDouble(0x3fe2a7aa501668b0L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 18, 0, 0, "\000", "\u38e9", "\ud8c7\udc9d\ud9be\udf1f\ud8fd\ude97\ud9b3\udea7\ud895\udd88\ud8ca\ude9b\ud86f\udcd1",
        13, 41937, -842533897, 5086017155716116755L, 88577L, true, false, (char) 63646, (char) 44165,
        Double.longBitsToDouble(0x3fe80000000082caL), Double.longBitsToDouble(0x3fd3a0000a956634L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:49 / 44984\0121=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 20, 18, 0, "\ud953\udc50\ud80b\udcfb\udb49\udcf3\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\u00ee", "\udae8\udd2e\ud92a\udf92",
        49, 44984, -80187117, 38217868420864L, -19808L, false, false, (char) 22221, (char) 225,
        Double.longBitsToDouble(0x3fd000000001892aL), Double.longBitsToDouble(0x3fd000000a956634L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:23 / 20385\0121=org.apache.commons.math3.fraction.Fraction:14789 / 321 |this=org.apache.commons.math3.fraction.Fraction:23 / 321\012",
        Z.run(T, 2, 20, 7, 14, "\ud9a0\udfa0\ud875\ude21\udb1c\udf43\udb07\udd7a\udb3b\udd55\uda82\udc7a\ud8c7\udc9d\ud9be\udf1f", "\ub91c\ud638\ub0f4\u64cd\u8b76\uc871\u954f\u4480\u0825\u4fb6\u6444\ubd3a\u1ce3\u3933\u9a32", "\udb9c\udcb1\udbbc\udcdb\ud826\uddc7\ud9a6\udd6e\udae0\ude3e\uda6f\udc4b\ud86e\ude5d",
        46, 40770, 639359241, -2386565456242063717L, -17660L, false, false, (char) 23329, (char) 33537,
        Double.longBitsToDouble(0x3fb2577556f4faf8L), Double.longBitsToDouble(0x3fe8e8c4db2cd2f9L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:2 / 99\0121=org.apache.commons.math3.fraction.Fraction:27 / 1340 |this=org.apache.commons.math3.fraction.Fraction:216 / 335\012",
        Z.run(T, 2, 20, 11, 6, "\udb54\udd29\udb94\udda9\udacc\udce0\ud9aa\udee2\ud879\udd8c\uda82\udc7a\ud8c7\udc9d\uda7e\udd5e", "\ub91c\ud638\ubabb\u80f2\u8b76\uc871\ub991\u861f\u9f68\u26c3\u6444\ubd3a\u5bd8\u3c8c\u3e59", "\udafd\ude34\ud859\udc8d\ud818\udd13\ud981\ude81\udafc\udca5",
        32, 1584, -1741738261, -1445214534926870263L, -16537L, false, false, (char) 47425, (char) 23340,
        Double.longBitsToDouble(0x3fe4a1fc6d9ebedfL), Double.longBitsToDouble(0x3fdf85d5c5bd3ebeL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:3 / 872\0121=new org.apache.commons.math3.fraction.Fraction:3 / 872\012",
        Z.run(T, 2, 20, 20, 20, "\udafe\udeb3\ud8f6\udfe1\udb0f\udc43\ud9cc\udf3d\000\000\000\ud9be\udf1f", "\ub91c\ud638\u97ff\u64cd\uc8fb\uc81c\uca7b\ub368\uc01e\u8189\u9d1e\ubd3a\u3a07\u3908\u4a97", "\udb9c\udcb1\uda2f\ude91\udb89\udd4b\ud9a6\udd6e",
        48, 13952, -89900370, -7469697166081945334L, -100000L, false, false, (char) 35232, (char) 47425,
        Double.longBitsToDouble(0x3fe070a803943f8dL), Double.longBitsToDouble(0x3fedf35a190000d5L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "C|org.apache.commons.math3.fraction.Fraction|<init>|double",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|double,int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|double,double,int,int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|int,int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|double,double,int",
    "M|org.apache.commons.math3.fraction.Fraction|abs||new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|add|int|new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|add|org.apache.commons.math3.fraction.Fraction|new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|addSub|org.apache.commons.math3.fraction.Fraction,boolean|new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|compareTo|org.apache.commons.math3.fraction.Fraction|new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|divide|int|new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|divide|org.apache.commons.math3.fraction.Fraction|new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|doubleValue||new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|equals|java.lang.Object|new:org.apache.commons.math3.fraction.Fraction:double",
    "M|org.apache.commons.math3.fraction.Fraction|floatValue||new:org.apache.commons.math3.fraction.Fraction:double",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|double",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|double,int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|double,double,int,int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|int,int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|double,double,int",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
