package org.apache.commons.math.distribution;
import org.junit.Test;
import static org.junit.Assert.*;
public class NormalDistributionImpl_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Double:1.0E-9 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 6, 9, 6, "\ud873\udfe1\ud9cf\udf9e\udbe1\udeba\ud838\udeaa\ud842\udefe\ud913\udd1a\ud9c9\uded8\ud851\udcf7\udac6\udd71\ud9e6\udf57", "\u9cbf\u77a6\u21fc", "\ud9be\ude22",
        32, 90804, -217414867, -3976481865689941892L, -21413L, false, false, (char) 17139, (char) 1369,
        Double.longBitsToDouble(0x3fcbe321f34aaed4L), Double.longBitsToDouble(0x3fafc3cd45ce3b80L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Double:1.0E-9 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 6, 9, 6, "\ud873\udfe1\ud9cf\udf9e\u15a5\ud838\udeaa\ud842\udefe\ud913\udd1a\ud9cc\uddd8\u7950\udac6\ude34\ud9e6\udf57", "\u0892\u2881\uc476", "\ud9be\ude22",
        32, 90804, -472539896, -2447769316784354838L, -21413L, false, false, (char) 17139, (char) 1369,
        Double.longBitsToDouble(0x3fcbe321f34aaed4L), Double.longBitsToDouble(0x3fafc3cd45ce3b80L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 10, 8, 11, "\uda48\ude85\ud9cf\udfa0\ud860\udcd2\ud804\uddeb\udb07\udc7e\ud9cb\udd77\ud842\udf36\ud851\udcf7\udac6\udd71\ud964\udcce", "\u6260\u77a6\u56f8", "\ud9be\ude22",
        32, 48372, 2056414884, 638215069109792124L, -32520L, true, false, (char) 19582, (char) 1369,
        Double.longBitsToDouble(0x3fcbe321f34aaed4L), Double.longBitsToDouble(0x3fafc3cd45c88b80L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Double:0.8234014345447318 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 0, 0, 0, "", "\u00c6", "\ud8d5\udcc9",
        49, 9840, 8, 335544320L, -100000L, false, false, (char) 44, (char) 0,
        Double.longBitsToDouble(0x3fedb580000000abL), Double.longBitsToDouble(0x3e48d32800000000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 12, 9, 6, "\ud873\udfe1\ud9cf\udf9e\udbe1\udeba\ud838\udeaa\000\000\ud9c9\uded8\ud851\udcf7\udbf6\udd62\ud9e6\udf57", "\u43fe\u77a6\u3dd6", "\000",
        -5, 90752, -217414867, -4035224373915502468L, -100000L, false, false, (char) 17139, (char) 1369,
        Double.longBitsToDouble(0x3fcbe321f34aaed4L), Double.longBitsToDouble(0x3f40f351738ee000L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:1.0E-9 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 11, 6, 6, "\uef4e\udb7a\udd94\ud935\udcf6\ud838\ude5b\ud842\udefe\ud8ac\udc24\udb12\udf2a\ud83d\udfba\ud8a9\udd77\ud9f8\udcee", "\u9cbf\u77a6\u21fc", "\ud9be\ude22",
        32, 90804, -217414867, -7426365323445225424L, -21413L, false, false, (char) 17139, (char) 1369,
        Double.longBitsToDouble(0x3fbb0643f5da6d20L), Double.longBitsToDouble(0x3fafc3cd45ce3b80L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:0.3895854741412402 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 10, 1, 6, "\uda95\udf2f\ud963\udce4\uda00\udc8d\ud8d0\ude97\udabe\ude9e\ud979\udd85\udafd\udea8\ud851\udcf8\ud88a\ude53\ud9a1\udd91", "\u47df\u5eb4\u4f3d", "\ud9be\ude22",
        17, 45768, 1965489511, 7916692853685008533L, -21413L, false, false, (char) 25075, (char) 1441,
        Double.longBitsToDouble(0x3fcbe321f34aaed4L), Double.longBitsToDouble(0x3fbbe1e6a2e71dc0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Double:1.0E-9 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 6, 9, 6, "\ud873\udfe1\ud9cf\udf9e\udbe1\udeba\ud838\udeaa\ud8a5\udc4e\uda6b\udd0a\ud9c9\uded8\ud851\udcf7\udac6\udd71\ud8c4\udca5", "\u2e50", "\ud86f\udcd8\ud905\uddbd\ud9be\ude22\uda94\udca2\ud80f\udff0",
        9, 19168, -1144735620, -8227715182088762107L, -77126L, true, false, (char) 31214, (char) 30855,
        Double.longBitsToDouble(0x3fafc3cd45ce3b80L), Double.longBitsToDouble(0x3fea8cef2d446753L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 3, 8, 8, "\uda1c\udd10\ud9a8\udc39\udbfb\udc88\ud82c\udf38\ud8c8\ude9d\ud913\udd18\uda55\ude3e\ud851\udd77\udac6\udd71\ud9e6\udf57", "\u9cbf\u77a6\u21fc", "\ud9be\uddfc",
        32, 90804, -217414665, -3976481865689941892L, 44123L, true, false, (char) 8531, (char) 1369,
        Double.longBitsToDouble(0x3fcbe321f34aaed4L), Double.longBitsToDouble(0x3fafc3cd45ce3b80L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Double:0.5002451066909279 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 0, 9, 6, "\ud873\udfe1\ud9cf\udf9e\udbe1\udeba\ud84b\udff4\000\000\ud9c9\ude23", "\u6d2a", "\udb39\udf5b\uda54\udcef\ud9a1\udc7a",
        32, 17870, -1730961353, -3846500934587818444L, 78014L, true, true, (char) 130, (char) 42495,
        Double.longBitsToDouble(0x3f4421e37c643c00L), Double.longBitsToDouble(0x3ec6a0021e680000L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Double:-0.764173179393278 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 4, 1, "\ud89b\uddd3\ud85b\udd9d\udbe1\udeba", "\u97c8\u46aa\u17f8\u7d33\u6d2a\u808f\u6f03", "\ud9d7\udf21\uda84\udd33\udae3\udee6",
        30, 65104, -1778984506, -931178404239068464L, -53058L, true, true, (char) 24213, (char) 61087,
        Double.longBitsToDouble(0x3fcc77039f7c643cL), Double.longBitsToDouble(0x3fca5576b0fcb668L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 4, 10, 6, "\ud873\udfe1\ud9cf\udf9e\uda3f\udd22\udb3f\ude8d\uda3c\ude2c\ud913\udd1a\u1f5b\ud90f\udf2f\udb4f\udf6e\ud97a\udf40\udab1\udd9f\udada\uddc8", "\u21fc\u6f01\u7b16", "\udb00\udc68\ud9d7\ude34\ud9ab\udf8f\uda63\udc76\uda66\udeeb\u4253\udb94\udc31\ud97c\udd0f\ud811\udec3",
        45, 10498, -407358374, -3932792829541045616L, -99416L, false, true, (char) 213, (char) 38025,
        Double.longBitsToDouble(0x3feeeb37cb27861aL), Double.longBitsToDouble(0x3fda422fe6426408L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Double:0.524734796287931 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 0, 9, 0, "\ud873\udfe1\ud9cf\udf9e\udbe1\udeba\ud838\udeaa\ud842\udefe\ud913\udd1a\uda92\udfbc\000\udac6\udd71\ud9e6\udf57", "\u9cbf\u77a6\u21fc", "\ud9be\ude22",
        32, 90804, -217414867, -3976481865689941892L, -77126L, true, false, (char) 31214, (char) 30855,
        Double.longBitsToDouble(0x3fafc3cd000e3b80L), Double.longBitsToDouble(0x3fab9d3fc9a3dcb0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 2, 7, 6, "\ud873\udfe1\ud9cf\udf9e", "\u3cb7\ua893\ub9e8\u7909\u1898\u231f\u60ac\u1927\uc8ad\u77a6\u21fc\u331f\u7b9d\ubdee\u7407", "\ud9ab\udf8f\uda63\udc76\ud95c\udde7\ud9e0\ude5a\udba5\udc90\ud8af\udde8",
        3, 22524, 2073742546, -2645467602315008932L, 79983L, false, true, (char) 47085, (char) 59514,
        Double.longBitsToDouble(0x3fea37fdefc598d1L), Double.longBitsToDouble(0x3fe8c3266bc8640eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:1.7976931348623157E308 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 3, 5, 5, "\u2d87\ud989\udf4e\ud99a\udeef\ud9e3\ude0d\ud85e\udfdf\uda26\udf1c\ud842\udf36\ud84a\udef7\ud94a\udfda\ud964\udcce\uda06\udd79\ud916\udcdb\uda86\udf38\uda56\udf21\udbf7\uddda\u129c\uda43\uddfd\ud9be\ude22\ud809\udd2a\uec67\ud883\uddce\uda65\uddbe\uda69\udf1d\uda64\udf6b\ud95f\udf78\udb9d\udd68\udab8\udd0d\ud9a0\uddc5\ud928\udfe7", "\ua48a\u52c8", "\ud953\udd6f\u4413\udb27\udfb9\ub3ee\ud9d4\udd37\ud8e2\udd1b",
        30, 3096, 403256114, 1993477656127906538L, -65020L, true, false, (char) 46776, (char) 19450,
        Double.longBitsToDouble(0x3fe4a983925af99dL), Double.longBitsToDouble(0x3fee22128e1d8f52L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 10, 8, 11, "\uda48\ude85\ud9cf\udfa0\ud860\udcd2\ud804\uddeb\udb07\udc7e\ud9cb\udd77\ud842\udf36\ud851\udcf7\udac6\udd71\ud964\udcce", "\u6260\u8715\u56f8", "\udad4\udc37",
        32, 48372, 2050713252, 638215068975574396L, -4047L, true, false, (char) 19582, (char) 1369,
        Double.longBitsToDouble(0x3fcbe321ef4aaed4L), Double.longBitsToDouble(0x3fcc00b5917222e0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Double:0.5522508883005657 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 3, 11, "\uda48\ude85\udaf3\ude72\ud860\udcd2\ua9df\udb07\udc7e\ud9cb\udd77\ud842\udf36\ud851\udcf7\udac6\udd71\ud964\udcce\uda06\udd79\ud916\udcdb\uda86\udf38\ud97f\udd44\udb98\ude56\u129c\uda43\uddfd\ud9be\ude22\uda94\udca2\udb17\udc91\ud88f\udddd\uda65\uddbe", "\u5794\u7f99", "\udb4f\udea7\udae5\ude56\ud9bd\udd37",
        20, 73005, 1826920915, 5919062171789988917L, -1908L, true, true, (char) 33766, (char) 34495,
        Double.longBitsToDouble(0x3fe6b523ba806960L), Double.longBitsToDouble(0x3fc6028631c40fdcL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Double:0.5247347995200716 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 0, 8, 11, "\uda48\ude85\ud9cf\udfa0\ud860\udcd2\ud804\uddeb\udb07\udc7e\ud9c5\udc02\uda76\udf90", "\u3d48\u8153\u12dc", "\udb98\ude56\u129c\uda43\uddfd\ud9c2\udc43\ud923\udcd14",
        38, 24025, 1409286144, 304942678016L, -77126L, false, false, (char) 31214, (char) 30855,
        Double.longBitsToDouble(0x3fafc3cd45c88b80L), Double.longBitsToDouble(0x3fe0e1b9da7bb040L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Double:0.7746094050845651 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:0.687490963581389 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 0, 8, 11, "\uda48\ude85\udabe\uded7\uda05\udfe4\udb02\ude05\udb07\udc7e\ud9cb\udd77\ud842\udf36\udbc1\udfaf\udac6\udd71\ud964\udcce", "\u6260\u77a6\u56f8", "\ud9b7\udc22\uda94\udca2\ud9f9\ude43\uda9f\ude4c\uda73\udd02\ud886\ude78\ud8d7\udfda\ud86b\udecc\udb9d\udd22\uda92\udcbb\ud80f\uddc3\uda2a\udee5\uda81\uddb9\ud9bd\udd37\ud8aa\ude23\ud9fb\udde2\ud92c\ude23",
        56, 74674, 610987840, -713230963575325762L, -11002L, false, true, (char) 23417, (char) 36840,
        Double.longBitsToDouble(0x3fe821b238ef9c33L), Double.longBitsToDouble(0x3fddabb0f192b1d8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Double:1.010442159061017 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 8, 11, "\uda48\ude85\ud9cf\udfa0\ud860\udcd2\ud804\uddeb\ud95d\udde8\ud9cb\udd77\ud842\udf36\ud851\udcf7\udac6\udd71\ud964\udcce", "\u6260\u77a6\u56f8", "\ud9be\ude22",
        32, 48372, 2056414884, 638215069109792124L, -32520L, true, false, (char) 19582, (char) 45087,
        Double.longBitsToDouble(0x3feb00e304d26812L), Double.longBitsToDouble(0x3fafc3cd45c88b80L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 11, 6, 12, "\000\ud9cf\udf9e\u00c6\u00e9", "\ub9ef\u7909\010", "\177",
        -5, 54584, 0, -5447211501081722778L, -494L, false, true, (char) 23721, (char) 24322,
        Double.longBitsToDouble(0x3fe85bd2b3b1686fL), Double.longBitsToDouble(0x3fe8d0db4df3fed5L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Double:0.8341934216226623 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 0, 0, 0, "", "\u00c6\u00e9\u867e\u3c26\u832c\u6db3\u9da8\u653b\ud45b\u7d3aG\uca15\000\ud12e\u1674\u1ff6\uaa04\u480d\ua976\u0c70\u449a\u8d3b\u0a4d\ua3e5\u6508\u0fc9\u90da\u8865\u8e2d\u33c8\u7d6b\u62a9\uab02\uc11d\u1847\u8293\ua631\u0518\u4561\u76fe\u9b26\u44c6\u2fbf\ud304\uc058\ua129", "\ud9cc\udd9c\ud90c\udfba\ud923\udf02\udb92\ude82\udb57\udcf6\udb7a\ude6a\uda56\udc19",
        -4, 49391, -1717594604, -7364661469581386205L, -25526L, true, true, (char) 10071, (char) 33584,
        Double.longBitsToDouble(0x3fef115d61d528b9L), Double.longBitsToDouble(0x3fbe5b9211e166e0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Double:0.5000010165442519 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 0, 0, 0, "", "\u00c6", "\ud8d5\udcc9\ud9ce\udc1a",
        38, -992, 0, 7488068911683246961L, -67577L, false, false, (char) 0, (char) 35766,
        Double.longBitsToDouble(0x3ec5600000000000L), Double.longBitsToDouble(0x3fe1a65003f43f71L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Double:0.5000000046977561 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 0, 1, 10, "\016\ud81e\udd65", "\u8614", "\uda1b\udcfc",
        3, -1000, 335544320, 4323456188328117309L, 50562L, false, false, (char) 28168, (char) 171,
        Double.longBitsToDouble(0x3e4949aa44000000L), Double.longBitsToDouble(0x3fce70a582357c10L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Double:-0.2585092452071178 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 0, 7, "", "\u00c6\u00e9\u867e\u8841\ubac2\u7969\010\000\u37b4\177\000\u2034\000\ud12e\u9481\000\u97ff", "\uda97\udd59\udb44\udce2\ud975\udc3e\ud88a\udc9e\ud832\udc33\udba3\udea0\ud8e5\udf91\u5e0a\uda6c\udd57\udb8d\udeff",
        54, 58955, 2025952622, 3227082415384577546L, 91922L, false, false, (char) 43765, (char) 11696,
        Double.longBitsToDouble(0x3fd978f22c72dfccL), Double.longBitsToDouble(0x3fc8b1fb27a3f9e0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Double:0.8234014345447318 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:0.8234014345447318 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "\u00c6", "\ud8d5\udcc9",
        49, 9840, 8, 920986124132841216L, -100000L, false, false, (char) 44, (char) 41431,
        Double.longBitsToDouble(0x3fedb580000000abL), Double.longBitsToDouble(0x3e48d32800000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Double:0.5 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 0, 0, 0, "", "\000", "\ud8d5\udcc9",
        49, 55760, 0, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Double:0.9045099218312205 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 6, 5, "\ufa14", "\u25eb\u867e\u8841\u91ce\u7909\010\u486b", "\ud923\ude05\udb6b\ude10\ud485\ud812\udf49\ud8be\ude18\ud891\udfde",
        19, 55402, 1543285178, 691077638692947700L, -63736L, true, true, (char) 9441, (char) 64679,
        Double.longBitsToDouble(0x3fea25fd768a2cb6L), Double.longBitsToDouble(0x3fe9b4cd46b254aaL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Double:1.3218918406286162 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 10, 0, "", "\u3ac0", "\ud8d5\udcc9\ud9c9\uded8\ud9a0\uddfc\010\000\udadc\udd2d\uda9b\udd8c\uda6d\udf3e\uda6f\ude80\udb17\udfb5\uda48\udce0\ud84c\udf3f\000\ud9cc\udf05\ud8a3\udf27\ud8ef\udccc\ud911\ude1a\udad9\udfdf\udb83\udd94\ud9d5\udcc8\uda34\udf3f\udadc\udff0\ud8cc\udebb\uda00\udfb4\ud850\udfe1\ud954\udebb\uda10\udd81\uda17\udeae\uda66\udfd6",
        4, 44568, -1348230644, -3228114921291732242L, -65140L, false, true, (char) 21428, (char) 34987,
        Double.longBitsToDouble(0x3fed054ec6c3ca62L), Double.longBitsToDouble(0x3fdba9bf1412904eL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Double:-1.8880473943164502 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 8, 0, "\ud237\uda28\udecc\ua204\ud85a\udeb9\uda91\udeec\ud8f3\udd0a\ud8c8\udc0f", "\000\u9bc6\177\000\u2034\000\u9a45\u9cac", "\u1eb8\ud85a\udeff\uda3e\udf69\ud9a8\ude46",
        52, 37200, -864879028, 5758418879850529121L, -25551L, false, false, (char) 50564, (char) 42669,
        Double.longBitsToDouble(0x3f9e37d0c198e0a0L), Double.longBitsToDouble(0x3fd5f927c55a5e8aL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Double:-1.0 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-1.078753755810012 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 4, 8, 7, "\udaa7\udce9\udaf2\udcb3\u44e0\udbe8\udec4\udb5f\udf6f\ud907\udee5\udbd4\udeb2\ud979\udf8e\010\ud87e\udcfe", "\000", "\ud9ad\udef6\ud81c\udedb\000",
        45, 75953, -560424657, 5455812369410743180L, -9848L, false, true, (char) 21159, (char) 10643,
        Double.longBitsToDouble(0x3fc1f6f2b5ad2f8cL), Double.longBitsToDouble(0x3fe486bf9680c053L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Double:-3.2809518416472647 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 9, 6, "\ud873\udfe1\ud9cf\udf9e\udbe1\udeba\ud838\udeaa\000\000\ud9c9\uded8\ud851\udcf7\udbf6\udd62\ud9e6\udf57", "\u43fe\u77a6\u3dd6", "\ud91f\udedd\udb7e\udc80\udaa3\udf3e",
        53, 78112, -1144735620, -8227715182097334272L, -77126L, true, false, (char) 31214, (char) 30855,
        Double.longBitsToDouble(0x3f40f351738ee000L), Double.longBitsToDouble(0x3fd53d548fcc4f14L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Double:0.7526692091071372 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=new org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 0, 11, 6, "\uef4e\udb7a\udd94\ud935\udcf6\ud838\ude5b\ud842\udefe\ud8ac\udc24\udb12\udf2a\ud83d\udfba\ud8a9\udd77\udbe9\udee7", "\u2a4c", "\ud86f\udcd8\ud905\uddbd\ud9be\ude22\uda94\udca2",
        45, 37133, -1729085418, -4916602378799462238L, -12430L, false, false, (char) 1369, (char) 48506,
        Double.longBitsToDouble(0x3fe5da6d2682879aL), Double.longBitsToDouble(0x3fb738ee38842130L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-1.2504678104999472 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 11, 8, 6, "\uef4e\udace\udc9f\udb24\udfc2\udaa8\udfeb\ud833\ude17\ud8ac\udc24\udb12\udf2a\ud83d\udfba\ud8b0\udd77\ud9f8\udcee", "\u9cbf\uae31\u21fc", "\udb8a\udfc8",
        59, 17875, -217414867, -7426365323445225424L, -21413L, false, false, (char) 50979, (char) 46169,
        Double.longBitsToDouble(0x3fbb0643f5da6d20L), Double.longBitsToDouble(0x3fafc3cd45ce3b80L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=new org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 10, 10, 10, "\uda95\udf2f\ud963\udce4\uda00\udc8d\udac1\udd3e\udb2c\udc76\ud979\udd85\udafd\udea8\ud851\udcf8\ud88a\ude53\ud9a1\udd91\uda06\ude25", "\u5eb4\u6457\u331f\u7b9d\ubdee\u9011\u664c", "\uda63\udc8f\ud95c\udde7\u4494\ud901\udd9a",
        15, 14623, -1414176545, -8675396530335107985L, 40352L, false, false, (char) 60367, (char) 20824,
        Double.longBitsToDouble(0x3fd0b184e1e3c51cL), Double.longBitsToDouble(0x3fe065aa893b197dL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Double:0.3895935860728479 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:0.3895935860728479 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 1, 1, 6, "\000\000\ud9c1\ude5f\ud8d0\ude97\udabe\ude9e\uda31\udf82\udafd\ude0e\ud851\udcf8\ud858\ude53\ud9a1\udd91", "\u47df\u0090\000", "\ud9be\ude22",
        17, 11392, 0, 7916483718842464405L, 83552L, false, false, (char) 25075, (char) 41303,
        Double.longBitsToDouble(0x3fcbe000134aaed4L), Double.longBitsToDouble(0x3fbbe1e6a2e71dc0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:0.0 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 11, 3, 6, "\ud97f\udef9\ud81a\udc80\uda00\udc8d\ud8d0\ude97\udabe\ude9e\ud979\udd85\udafd\udea8\ud851\udcf8", "\ub9b3\u4185\u47df\u7e69\u010e\u331f\u7b9d\ubdee\u04d0\u260f\u7040\ub06b\u8fb6", "\udb94\udc31\udbc8\udc11\ud894\udc90\udad7\udc95\uda81\uddb9\ud938\udec4",
        7, 10536, 422991968, 8274617887197136566L, -89550L, true, false, (char) 963, (char) 45548,
        Double.longBitsToDouble(0x3fdac6046706bfaeL), Double.longBitsToDouble(0x3fefb09ea132fed4L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-0.1615258575183761 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 3, 8, 1, "\udb52\uddbb\uda19\udd09\uda00\udc8d\ud993\udef7\ud8f8\udc19\ud9c5\ude43\udbd3\udc43\ud8c0\udc16\ud90b\udc20\ud995\udc0c", "\u3eca\u5eb4\u4f3d", "\ud996\ude4f\uda63\udf69\udb01\ude19\ud991\udc4e\ud9e5\udcae\udb53\udc07\ud99b\udc43\ud9e6\udcfc\udb94\udc31\udbc8\udc11\ud80f\uddc3\ud928\udfe7\uda81\udde2\ud938\udec4\u21cc\udbcd\udce9\udad6\udf4e\udad2\udefb",
        52, 82971, -1175134775, 6236660001745963263L, 72574L, false, false, (char) 50960, (char) 52672,
        Double.longBitsToDouble(0x3fdbe4cbe08563f2L), Double.longBitsToDouble(0x3fe251bc069439abL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-Infinity |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 10, 8, 6, "\000\uda57\ude8a\uda00\udc8d\ud84b\udff4\000\000\000\000\000\000", "\000\u5eb4\u4f3d", "\ua037",
        -5, 33376, 64871, 0L, -100000L, false, false, (char) 0, (char) 25600,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e41738ee0000000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Double:-0.03260739090524134 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 8, 10, "\ud86e\ude2e\ud9cf\udf9e\udbe1\udeba\ud839\udda6\uda0d\ude21\u82a7\ud9c9\uded8\udac3\uddb6\ud91b\udc3f\udb0d\udf0b", "\u2c9b\uc46f\u837e\u5b3d\u7f33\ub40b\uc35e\u547c\u294a\u3e54\u3c51\u78b3\u284b\u9da9\u0544\u7004\u0d13\u3980\u50b8\ub6a9\u3356\ubf62", "\ud93b\udcf7\ud937\ude30\udaf6\udc39\ud98e\udec8\udb95\udd22\ud873\ude20\ud98f\udd96\ud9f9\udcf1\uda9b\udcb4\ud884\ude6d\ud85f\udea1\ud9bd\udebc\ud9f4\udc20\ud8e3\udcb7\ud900\udfd6\uda8e\udcc1\ud90f\udf6f\ud9b5\udebb\uda6e\udfdc\ud8be\ude35\udbb8\udf7d\udb15\udc9c\udb80\uddb3\ud8ec\ude57\ud899\udc43\uda38\udcbf\udaa4\udeb1\ud839\udda8\udacf\udc69\udbed\ude42\udb55\uddfd\ud835\uddca\udacd\udcf2\ud944\udd96\ud9d4\udefa",
        23, 3005, 1400009546, 7275512689825803480L, 99840L, false, false, (char) 23183, (char) 63435,
        Double.longBitsToDouble(0x3fdf2ae833cc19a4L), Double.longBitsToDouble(0x3fe4dab3b7b7dd98L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Double:1.7976931348623157E308 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:0.050262165462481787 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 3, 8, 8, "\uda1c\udd10\udac0\udf66\udbfb\udc88\ud8de\uded6\ud83f\udcc1\ud9f9\udefa\ud8e9\udc26\u2bac\udbbb\udeb2\uda98\udcb2", "\ubeff\u6ab7\u0de6", "\ud9be\ude1b\uda94\udca2\udb15\ude37\ud8dc\udc45\ud9ab\udf8f\ud978\udf72\ud85b\uded1\udae5\udf3d\udaa6\udccc\udab1\udfe6\ud80f\uddc3\ud928\udfe7\uda81\uddb9",
        35, 51044, 1620839971, 4246078559218614512L, -99404L, false, true, (char) 3418, (char) 50784,
        Double.longBitsToDouble(0x3fe0a431c4ff2269L), Double.longBitsToDouble(0x3fec4cf49d3993a6L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Double:-0.9984441742836944 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 11, 8, "\uda94\udeab\ud9a7\udfe6\uda71\udce2\ud99c\udea4\ud8c8\ude9d\ud913\udd18\uda55\ude3e\udb82\ude59\udac6\udd71\ud9e6\udf57", "\u9cbf\u27e4\u21fc", "\ud9be\uddfc",
        56, 54356, -217414805, -3976481865689941892L, 43962L, true, false, (char) 8531, (char) 50008,
        Double.longBitsToDouble(0x3fc45b29334aaed4L), Double.longBitsToDouble(0x3fafc3cd45ce3b80L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Double:-1.6765750843247782 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 3, 10, "\ud873\udfd7\ud9cf\udf9e\udbe1\udeba\ud838\udeaa\ud842\udefeQ\udb36\udf1b\ud851\udcf7\udb7e\udf6e\ud97d\udd28\u06cf\udbb3\ude3c", "\u21fc\u331f\u7b9d\ua037\u00c8\000\u20c9", "\udaf7\uddb3\ud9e0\udef4\udb94\udc31",
        19, 86457, 13874370, -474480640L, -17861L, true, true, (char) 31162, (char) 32169,
        Double.longBitsToDouble(0x3fa7f7d8f4143ff0L), Double.longBitsToDouble(0x3fe9b20cf0bea00bL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Double:-1.4396594215544447 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 4, 1, "\ud89b\uddd3\ud85b\udd9d\udbe1\udeba", "\u97ea\u46aa\u17f8\u7d33\u6d2a\u808f\u6f03", "\ud9d7\udf21\uda84\udd33\udae3\udee6",
        30, 65104, -1778984506, -931178404239068464L, -53058L, true, true, (char) 24213, (char) 61855,
        Double.longBitsToDouble(0x3fb332035b799510L), Double.longBitsToDouble(0x3fb9834b61f96cd0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Double:-5.545436886284928 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 4, 1, "\ud89b\uddd3\ud85b\udd9d\udbe1\udeba", "\u97c8\u46aa\u17f8\u7d33\u6d2a\u808f\u6f03", "\ud9d7\udf21\uda84\udd33\udae3\udee6",
        30, 65104, -1778984506, -931178404239068464L, -53058L, true, true, (char) 24213, (char) 77,
        Double.longBitsToDouble(0x3e4f7c0000000000L), Double.longBitsToDouble(0x3fca5576b0fcb668L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Double:-2.3473274903575034 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 4, 1, "\ud89b\uddd3\ud85b\udd9d\udbf6\udfc5\ud8e6\ude22\udbbb\udd69\udb56\udd63\ud9a6\udf44\udabd\udc81\ud882\ude63\ud9e6\udf57\ud84a\udc93\ud8c3\ude6c\udaff\ude84\udade\ude74\ud9d7\udf21\uda84\udd33", "\u6d73\u5419\u12dc", "\udab2\udd53\udb8a\udf12\ud8e9\udf1a",
        -5, 89579, -1414139937, 3286164078726755391L, 85887L, true, true, (char) 61361, (char) 43311,
        Double.longBitsToDouble(0x3f835cc8794bbd80L), Double.longBitsToDouble(0x3fbf4fa5552bbc90L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Double:-4.54822449097892 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 4, 10, "\ud89b\uddd3\ud85b\udcd6\udbe1\udeba", "\u97c8\u4699\u1355\000\u64e5\u808f\u6f03", "\000\000\udae3\udee0",
        56, -800, -1778984704, -931178403313221424L, -100000L, false, false, (char) 0, (char) 2271,
        Double.longBitsToDouble(0x3ec6b0fcb6680000L), Double.longBitsToDouble(0x3fc32b1d1484bfb8L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Double:-1.2683389814549801 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 4, 1, "\ud89b\uddd3\ud85b\udd9d\udbe1\udeba\ud8e6\ude22\udbbb\udd69\udb56\udd63\ud9a6\udf44", "\u6d2a\u808f\u6f03\u9cbf", "\uda84\udd33\udae3\udee6\ud9c5\udf21\ud81d\udea6\ud8f6\udf86\ub16a\ud9ab\udf8f",
        45, 48506, -92091007, -7183975803319987630L, 26943L, false, false, (char) 25049, (char) 21132,
        Double.longBitsToDouble(0x3fba32da76fa6bd8L), Double.longBitsToDouble(0x3fdecf57baeae04aL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Double:-0.764173179393278 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-1.7976931348623157E308 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 2, 1, "\ud89b\uddd3\ud85b\udd9d\udbe1\udeba", "\u97c8\u46aa\u17f8\u7d33\u6d2a\u808f\u6f03", "\udb21\udc3a\uda84\udd33\ud8d6\uddba",
        31, 32016, -1778984506, -931178404249505328L, -53058L, true, true, (char) 61505, (char) 38649,
        Double.longBitsToDouble(0x3fcc77039f7c643cL), Double.longBitsToDouble(0x3fca5576bda6a668L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Double:-2.6425991641136637 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 4, 1, "\ud920\udfe1\ud85b\udd9d\udbe1\udeba", "\u4e8c\u46aa\u17f8\u7d33\u6d2a", "\udbb7\uded0\udade\ude74\ud9d7\udf21\uda84\udd33\udae3\udee6\ud9c5\udf21\udbb4\uddb2\ud8d4\ude9f\ub16a\ud9ab\udf8f\uda63\udc76\ud980\ude59\ud968\udefc\udb94\udd2b\ud99b\ude15",
        9, 18983, 765119497, -8026201517391981928L, -32229L, false, true, (char) 15377, (char) 15119,
        Double.longBitsToDouble(0x3f70d9710d81e480L), Double.longBitsToDouble(0x3fd26a0c1a3fe538L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Double:0.015044283865910632 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 4, 1, "\uda39\udf13\udbb6\udeba\u1d23", "\u92dd\uaf75\ub0eb\u7c73\ua06d", "\udb74\uddcd\udade\ude74\ud9d7\udf21\ud90e\udcd9",
        6, 79790, 816085450, 7347299286311488142L, -56860L, true, true, (char) 15640, (char) 13973,
        Double.longBitsToDouble(0x3fe0312a36c98697L), Double.longBitsToDouble(0x3fb523edd8112978L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Double:2.1329650266199462 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 4, 1, "\ud89b\uddd3\ud85b\udd9d\udbe1\udeba", "\u97e5\u46aa\u17f8\u7d33\u6d74\u808f\u6f03\u9cbf\u0508\ud511\u1d92\u201f\u02ee\u6d73", "\ud9ab\udf8f\uda63\udc76\ud9fb\udf35\ud88f\udd2e\udb97\ude31\ud99b\ude15\ud81c\ude5d",
        58, 43698, -1006029761, 2685072450678443601L, 18562L, true, false, (char) 13239, (char) 18082,
        Double.longBitsToDouble(0x3fef7920e9f2b80fL), Double.longBitsToDouble(0x3fc028f10161ac2cL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Double:-1.4145926620378235 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 4, 1, "\ud89b\uddd3\ud85b\udd9d\udbe1\udeba", "\u97c8\u46aa\u17f8\u7d33\u6d2a\u808f\u6f03", "\ud9d7\udf21\uda84\udd33\udae3\udee6\ud9c5\udf21\ud81d\udea6\ud8f6\udf86\ub16a",
        54, 98380, 1872185506, -395527864993356782L, -73603L, true, true, (char) 30855, (char) 25049,
        Double.longBitsToDouble(0x3fb41ebc31098158L), Double.longBitsToDouble(0x3fb5888f9fb21720L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Double:0.001494557363849354 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 5, 1, "\udba8\udc74", "\u7bbd\u787a\u97c8\u665e\u24f7\uc8fc\u6ce5\u808f\u9e6b", "",
        -5, 38147, -1173517562, -7434390520232673280L, -100000L, false, false, (char) 28696, (char) 24213,
        Double.longBitsToDouble(0x3fe004e268e3b81cL), Double.longBitsToDouble(0x3fcbe321f34aaed4L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Double:2.5912949898755215 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 0, 1, "\ud957\ude28\ud83d\udc98\uda58\udfbe\ud95b\uddd5\udbbb\uddef\ud9e7\udfcc\ud8a2\udeaf\udabd\udc7b\ud886\ude65\ud9e6\udf57\ud84a\udcfc\ud8c3\ude6c\ud8bc\ude2d\udadf\ude9a\ud9d7\udf21\uda84\udd33\udae3\udee6\ud9a2\udc21\udabc\udcb5\ud8f6\udf43\ub16a", "\u34b1\u58ee\u2c6c", "\ud94c\udee7",
        49, 35575, 627661964, -1709035514103929518L, -96395L, true, true, (char) 61143, (char) 6216,
        Double.longBitsToDouble(0x3fefd8d5fd2d81b2L), Double.longBitsToDouble(0x3fc229ddc5f9fca4L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Double:-0.7796305563945317 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-0.7796305563945317 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 6, "\ud873\udfe1\udb6d\udc16\udbe1\ude21\ud838\udeaa\uda05\udea3", "\u7909\u7472\u6d2a\u8dcb\u0b40\u9cbf\u77a6\u21fc", "\ud9be\ude22",
        33, 23343, 436742337, 7434326902409132996L, 83557L, false, false, (char) 17139, (char) 1369,
        Double.longBitsToDouble(0x3fcbe101e816aed4L), Double.longBitsToDouble(0x3fe9443a6b854330L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Double:0.6195146246471377 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:0.6195146246471377 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 0, "\ud873\udfe1\udb63\udf14\udbe1\udeba\ud838\udeaa\udb3c\udf9f\udadb\udfa9\uda58\udc6e\ud89a\ude8f\ud9a7\udf00\uda16\udd0d\uda1a\udd11\ud916\udcdb\u4730\udbcd\udf7d\ud9a1\udc7a\ud86f\udcd8\uda34\udd33", "\u4d44\u9f5a\u2936\ub189", "\ud8f0\udf0a\udbcb\udca9\uda9a\udea8",
        28, 39093, 484994971, 2166975086256689524L, -97571L, true, true, (char) 36345, (char) 54533,
        Double.longBitsToDouble(0x3fe76e4666f010c7L), Double.longBitsToDouble(0x3fe854aa37413193L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=new org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 11, 11, 10, "\ud878\udc23\udb9a\uddb1\uda3f\udd22\udb3f\ude8d\uda3c\uddce\ud913\udd1a\udada\udd58\ud959\ude47\udb4c\udff6\ud97a\udf40\udab1\udd9f\udada\uddc8", "\u6622\u0b08\u16ba", "\uda25\ude89\udaca\udf0f",
        22, 79859, 651249826, 6486253308025875218L, -62441L, true, false, (char) 4451, (char) 13205,
        Double.longBitsToDouble(0x3fdc2e7b852192d6L), Double.longBitsToDouble(0x3fe1312003251fbbL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Double:1.1679904743049163E-8 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 3, 11, "\uda48\ude85\udaf3\ude47\ud860\udcd2\ua9df\udb07\udc7e\ud9cb\udd77\ud842\udf36\ucb08\udac6\udd71\ud964\udcce\uda06\udd79\ud916\udcdb\uda86\udf38\ud97f\udd44\u4d4a\u129c\uda43\uddfd\ud9be\ude22\uda94\udca2\udb17\udc91\ud88f\udddd\uda65\uddbe", "\u5794\u7f99", "\udb4f\udea7\u00e2\uda5a\udced",
        45, -1000, 1811939328, 5919062171789988917L, -1908L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe0000002806960L), Double.longBitsToDouble(0x3fc6028621c40fdcL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Double:1.010442159073006 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:1.010442159073006 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 11, "\uda48\ude85\ud9cf\udfa0\ud860\udcd2\ud804\uddeb\ud95d\udde8\ud9cb\udd77\ud842\udf36\ud851\udcf7\udac6\udd71\ud964\udcce", "\u6260\u77a6\u56f8", "\ud9be\ude22",
        32, 48372, 2056414884, 638215069109792124L, -32520L, true, false, (char) 19582, (char) 45087,
        Double.longBitsToDouble(0x3feb00e304d2cd12L), Double.longBitsToDouble(0x3fafc3cd45c88b80L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Double:1.3938469801217666 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:1.3938469801217666 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 10, "\udbbf\udc43\uda71\udf62\ud860\udcd2\ud804\uddeb\ud9de\ude6a\uda71\ude34", "\u8912\u3d48\u0184\u30ce\u39d6\u3b7a\ua66b\u6184\u5c44\u4448\u31b2\u9242\u734a\u47b8\ub6fc\u7294\u5794\u425e", "\uda9b\udda4\uda81\uddb9\ud9bd\udd37\uda75\udf29\udb72\udf43\ud91f\ude76",
        8, 37429, 104880135, -7223924641735229515L, -40963L, true, false, (char) 24746, (char) 53829,
        Double.longBitsToDouble(0x3fed62dc9f111a86L), Double.longBitsToDouble(0x3fd4f31d0e01552aL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NotStrictlyPositiveException\012",
        Z.run(T, 2, 11, 4, 0, "\000\ud9cf\udf9e\u00c6\u00e9j\000\ud9c6\udf23\ud851\udcf7\000\000\udadc\udd2d\udb7f\ude3e\u4957\000\000\ud829\udc03\ud84c\udfc0\000\ud923\udcd1\udad4\udede\uda87\udebe\uda7b\ude65\u02b5\ud879\udd92\udb16\udf82\ud9ff\ude8a\ud8e9\udf5c\ud8f2\ude47\ud9e1\uddb7\uda68\udcc2\ud83e\udc3d\ud868\udefe\udbd3\ude3e\000\000\ud8e1\udc4f\ud93f\ude58\udb2a\udd16\ud982\udd44\ud9cc\udebe\udb12\udfa4\ud95b\udc2b\ud911\udf66\ud8cb\ude69\uda15\ude7b\udb78\udf1e", "\u2bba\u2efd\u5e08\ucb0a\u99d1\u7b5a\u7a44\u7764\u48eb", "",
        56, 53419, 872481243, 49909757657481216L, -70062L, false, false, (char) 51027, (char) 14470,
        Double.longBitsToDouble(0x3fe0f08550a76b78L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Double:-6.8099921622652095 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 0, 6, "\u7257\000\udbe1\uddf4\ud838\udeaa\000\000\000\ud851\udcef\udbf6\udd62\udb0e\udc4a", "\u43fe", "\udb69\udd26",
        9, 93380, 1344351176, 5944930049702134573L, -100000L, false, false, (char) 40013, (char) 0,
        Double.longBitsToDouble(0x3d9576a000000000L), Double.longBitsToDouble(0x3f40f351738ee000L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Double:-1.2504678104999472 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-1.2504678104999472 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 0, "\uef4e?\udb24\udf66\udaa8\udfeb\ud833\ude17\ud8ac\udc24\udb12\udf2a\ud83d\udfba\ud8b0\udd6f\ud9f8\udcee", "\u58c1\000\u14f4", "\udb8a\udfc8",
        59, 66688, -217414867, -7426365323445225424L, -21413L, false, false, (char) 50979, (char) 46169,
        Double.longBitsToDouble(0x3fbb0643f5da6d20L), Double.longBitsToDouble(0x3fafc3cd45ce3b80L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:0.3989422804014327 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 11, 1, 6, "\uef4e\udace\udc9f\udb24\udfc2\udaa8\udfeb\ud833\ude17\ud8ac\udc24\000\ud83d\udfba\ud8b0\udd77\ud9f8\udcee", "\u9cbf\uae31\u21fc", "\000",
        -5, 17656, -217414867, 93344544816L, -21413L, false, false, (char) 50979, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3faf800045ce3b80L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Double:0.3989422804014327 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-7.541068080469814 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 1, 8, 6, "\000\ud80c\udec5\uda00\udc8d\ud84b\udff4\000\000\000\000\000\000", "\000\u5eb4\ua0fa", "\udb7f\udd62",
        14, 10599, 64871, 0L, -100000L, false, false, (char) 0, (char) 25600,
        Double.longBitsToDouble(0x3d1a400000000000L), Double.longBitsToDouble(0x3e41738ee0000000L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Double:-Infinity |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-Infinity |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 6, "\000\uda57\ude8a\uda00\udc8d\ud84b\udff4\000\000\000\000\000\000", "\000\u5eb4\u4f3d", "\ua037",
        -5, 33376, 64871, 0L, -100000L, false, false, (char) 0, (char) 25600,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e41738ee0000000L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:0.0 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 10, 8, 6, "\000\uda57\ude8a\uda00\udc8d\ud84b\udff4\000\000\000\000\000\000", "\000\u30d8\u4f3d", "\ua037",
        -5, 33376, 64871, -1694498816L, -100000L, false, false, (char) 0, (char) 25600,
        Double.longBitsToDouble(0x3fe000000000005cL), Double.longBitsToDouble(0x3e41738ee0000000L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Double:-3.5784760352212515 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 4, 10, "\ud89b\uddd3\ud85b\udcd6\udbe1\udeba", "\u97c8\u4699\u1355\000\u64e5\u808f\u6f03", "\000\000\udae3\udee0",
        56, -800, -1778984704, -931178403313221424L, -100000L, false, false, (char) 0, (char) 2271,
        Double.longBitsToDouble(0x3f26a643f2d9a000L), Double.longBitsToDouble(0x3fc32b1d1484bfb8L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Double:1.6554843454261203 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:1.6554843454261203 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 10, "\ud873\udfe1\udb6d\udc16\udbe1\ude21\ud838\udeaa\uda05\udea3\ud93a\udc43\ud9c9\uded8\ud851\udd51", "\ua728\ud6a0\u9cbf\u77a6\ua5d5\ubb05\uced7\u9370\u6701\u544a\u579b\ub026\u8fe6\uca93\u8ccb\u8ea9\u73be\ud206\025\u74a0\ua315\ucaa7\u1571\u1ff4\uc39c\u236d\uc9e2\u6ca3\u6840\u170a\u2b24\ub629\u7e6f\u5c36\ud6b8\ua484\u4e83\ucf5d\ua788\uc530\u087b\u14e1\u9c1b\u69be\u5320\u9db6\ud0e7\u7967\ud32e", "\u1a60\udb1d\udc60\ud91a\udf7f\ud9fb\udf8f\udb82\udfa9\udb39\udd0b\ud8b3\ude39\ud85e\udc73\ud96f\ude13",
        39, 48698, 1570712359, 2128245928593975722L, -1391L, false, true, (char) 14340, (char) 11824,
        Double.longBitsToDouble(0x3fee6f4db36b01d2L), Double.longBitsToDouble(0x3fcff1f5cd645d98L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Double:1.7621218126039067 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:1.7621218126039067 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 6, "\ud873\udfe1\udb6d\udc16\uda86\ude26\ud838\udeaa\uda05\udea3", "\u7909\u7472\u6d2a\u8dcb\u0b40\u9cbf\u77a6\u21fc", "\ud9be\ude22\uda35\udde4\u9a0b",
        57, 44153, -767951932, 4300828231365479685L, -9665L, true, false, (char) 43637, (char) 18101,
        Double.longBitsToDouble(0x3feec04ffc9ec734L), Double.longBitsToDouble(0x3fde01a2d52d3b4eL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Double:-2.313955886836155 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-2.313955886836155 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 0, "\ud873\udfe1\udb63\udf14\udbe1\udeba\ud838\udeaa\udb3c\udf9f\udadb\udfa9\uda58\udc6e\ud89a\ude8f\ud9a7\udf00\uda16\udd0d\u87d6\000\u466f\udbcd\udf7d\ud9a1\udc7a\ud86f\udcd8\uda34\udd33", "\u4d44\u9f5a\u2936\ub189", "\ud8f0\udf0a\udbcb\udca9\uda9a\udea8",
        -5, 39093, 484994971, 2161908536675897716L, -34464L, false, true, (char) 17338, (char) 10167,
        Double.longBitsToDouble(0x3f852a8dc0000000L), Double.longBitsToDouble(0x3fea33713194270aL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Double:2.1017247039606946 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:2.1017247039606946 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 7, "\ud873\udfe1\udb63\udf14\udbe1\udeba\ud838\udeaa\udb3c\udf9f\udadb\udfa9\uda58\udc6e\ud89a\ude8f\ud9a7\udf00\uda16\udd0d\ud97c\udca3\ud916\udd35\u4730\ud878\uddc4\ud9a1\udd69\ud86f\udcd8\uda34\udd33", "\u8644\u9f5a\u40e7\ub361", "\ud8f0\udf0a\udbcb\udca9\uda9a\udea8",
        28, 39093, 484994971, 5753529239497972791L, -97571L, true, true, (char) 36345, (char) 54533,
        Double.longBitsToDouble(0x3fef6e4664e03c30L), Double.longBitsToDouble(0x3fe82fab97413193L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 3, 11, "\uda48\ude85\u8a00\000\000\ud9cf\uddc6\ud9cb\udd77\ud842\udf36\010\udac6\udd71\ud964\udcce\uda06\udd79\177\uda86\udf38\ud971\udd44\u4d4a\u129c\uda43\uddfd\ud9be\ude22\uda94\udca2\udb17\udc91\ud88f\udddd\uda65\uddbe", "\u5794\u2374", "\udb4f\udea7\u00e2\uda5a\udced",
        45, -1000, 1811939328, 5919062171789988917L, -1908L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe0000000000000L), Double.longBitsToDouble(0x3f14310000000000L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Double:-1.2658275787656943 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-1.2658275787656943 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 11, "\udbf3\ude43\ud9cf\udff1\ud860\udcd2\ud804\uddeb\ud95d\udde8\ud9cb\udd77\ud842\udf36\ud851\udcf7\udac6\udd71\ud964\udcce", "\u6260\u2275\u7dbb\ua200\uc9fc\u91c0\u0573\uc159\ubfe9\u47b8", "\ud86b\udecc\udb9d\udd22",
        32, 43360, -854396064, -8675396531861834689L, -68428L, false, true, (char) 54252, (char) 641,
        Double.longBitsToDouble(0x3fba5046926018c0L), Double.longBitsToDouble(0x3fee7e9d9457201dL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Double:1.4563418044919383 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:1.4563418044919383 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 10, "\udbbf\udc43\uda71\udf62\ud860\udcd2\ud804\uddeb\ud9de\ude6a\uda71\ude34\ud903\udf9c\ud810\udd67\ud8f2\udcca\ud964\udcfe\ud9a1\uddb7\ud804\udfe6\udb5c\uddaa", "\u6184\u5c44\u4448\u31b2\u9242\u4474\u8ca6", "\ud817\udd62\uda8a\udcc9",
        -2, 28370, -777697184, -8675396530587356097L, 63521L, false, false, (char) 36745, (char) 17731,
        Double.longBitsToDouble(0x3fedacdbd7a4f52eL), Double.longBitsToDouble(0x3fd63a86bc9a58eeL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Double:-5.841428686877538 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-5.841428686877538 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 8, "\udbbf\udc43\uda71\udf62\ud860\udcd2\ud804\uddeb\ud9de\ude6a\uda71\ude34", "\u8912\u3d48\u0184\u30ce\u39d6\u3b7a\ua66b\u6184\u5c44\u4448\u31b2\u9242\u6da9\uba7e\u2abb\u7291\u5794\u425e", "\000",
        42, 19079, -1479447460, 639399813163797937L, -39309L, true, false, (char) 32016, (char) 56180,
        Double.longBitsToDouble(0x3e263a86b0000000L), Double.longBitsToDouble(0x3fe26963b9826f28L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Double:-1.4232043599872846 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-1.4232043599872846 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 10, "\udbbf\udc43\uda71\udf62\ud860\udcd2\ud804\uddeb\ud9de\ude6a\uda71\ude34", "\u8912\u3d48\u0184\u30ce\u39d6\u3b7a\ua66b\u6184\u5c44\u4448\u9b79\u92cb\u734a\u47b8\ub6fc\u7294\u5794\u1fcb", "\uda9b\udda4\uda81\uddb9\ud9bd\udd37\uda75\udf29\udb72\udf43\ud91f\ude76",
        8, 37429, 104880135, -7223924641735229515L, -38174L, true, false, (char) 55103, (char) 59798,
        Double.longBitsToDouble(0x3fb3cc7410dfd208L), Double.longBitsToDouble(0x3fedb19d5ef10816L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Double:-2.4561867755845244 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-2.4561867755845244 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 10, "\udbbf\udc43\uda71\udf62\ud860\udcd2\ud981\ude6a", "\u4f6c\u11f9\u8912\u3d48\u0184\u30ce\u39d6\u3b7a\ua66b\u6184\u5c44\u4448\u31b2\u9242\u734a", "\ud8d7\udf96\ud86b\udecc\uda8a\udcc9",
        -2, 28370, -777697184, -8675396531861834689L, -74078L, true, true, (char) 49148, (char) 55283,
        Double.longBitsToDouble(0x3f7cc20f68032000L), Double.longBitsToDouble(0x3fedacddffa4f52eL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Double:1.7976931348623157E308 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=!org.apache.commons.math.exception.NotStrictlyPositiveException\012",
        Z.run(T, 2, 3, 12, 0, "\000\ud9cf\udf9e\u00c6\u00e9j\000\ud9c6\udf23\ud851\udcf7\udbe8\udd28\ud922\ude6c\ud9df\udf63\udb7f\ude3e\u4957\000\000\ud829\udc03\ud84c\udfc0\ud857\udd2a\ud923\udd89\udad4\udede\uda87\udebe\ud9eb\udc9c\ud8e5\udc1a\ud879\udd92\udb16\udf82\ud9ff\ude8a\ud8e9\udf5c\ud8f2\ude47\ud9e1\uddb7\uda68\udcc2\ud83e\udc3d\ud868\udefe\udbd3\ude3e\000\000\ud8e1\udc4f\ud93f\ude58\udb2a\udd16\ud982\udd44\ud9cc\udebe\udb12\udfa4\ud95b\udc2b\ud911\udf66\ub43b\uda15\ude22\udb78\udf1e", "\u2bba\u2efd\u5e08\ucb0a\u99d1\u7b5a\u7a44\u8551\u4801", "",
        56, 53419, 872481243, -7359941492699299595L, -70062L, false, false, (char) 51027, (char) 14470,
        Double.longBitsToDouble(0x3fe0f08550a76b78L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Double:-6.257144858371196 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 0, 3, "\u7257\000\udbe1\uddf4\ud838\udeaa\000\000\udb67\udd38\ud851\udcef\udbf6\udd62\ud81c\uddf1", "\u43fe", "\ud89a\udd92\uda83\uddba\ud91f\udedd",
        46, 56890, -217414867, -4035224371585574183L, -100000L, false, false, (char) 46925, (char) 12,
        Double.longBitsToDouble(0x3deaf1b500000000L), Double.longBitsToDouble(0x3fcb750ab18c074cL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Double:-5.572733340597673 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-5.572733340597673 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 0, "", "\u954b", "\ud8ac\udc24\udb12\udf2a\ud83d\udfba\ud8b0\udd6f\000\000\ud9de\udcdf\u58c1\000\ud967\udf73\ud86f\udcd8\ud905\uddbd\udb8a\udfc8",
        28, -1000, -217448448, -7426365323445225424L, -21413L, false, false, (char) 50979, (char) 46169,
        Double.longBitsToDouble(0x3e4aed3400000000L), Double.longBitsToDouble(0x3fafc3cd45ce3b80L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Double:3.0551595748828397E-9 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 3, 11, "\uda48\ude85\u8a00\000\000\ud9cf\uddc6\ud9cb\udd77\ud842\udf36\010\udac6\udd71\ud964\udcce\uda06\udd79\177\ud9fb\ude7c\ud971\udd44\u4d4a\u129c\uda43\uddfd\ud9be\ude22\uda94\udca2\udb17\udc91\ud88f\udddd\uda65\uddbe", "\u5794\u2374", "\udb4f\udea7\u00e2\uda5a\udced",
        45, -1000, 1811939328, 5919062171789988917L, -1908L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe0000000be3e78L), Double.longBitsToDouble(0x3f14310000000000L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Double:-5.6917708075692595 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-5.6917708075692595 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 8, "\udbc3\ude43", "\u52bb", "\ud842\udf36\ud851\udcf7\udac6\udd71\ud964\udcce\udb02\uddf2\ud916\udcdb\uda86\udf38\ufe89\ud921\ude11",
        58, 92792, 43026, 0L, 80039L, false, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e3b000000000000L), Double.longBitsToDouble(0x3fca59a250fe1e68L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Double:2.329318054210934 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:2.329318054210934 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 0, "", "\ua1bd", "\ud8a1\uded7\udb12\udf2a\ud83d\udfba\udbdc\udd85\ud8af\udfe9\000\ud9de\udcdf\u58c1\000\ud967\udf73\ud86f\udcd8\ud905\uddbd\udb8a\udfc8\udba7\udf9b\000\ud9b9\udf3c\ud86a\ude03\uda63\udc2a\ud95c\udde7\ud9e0\ude5a\uda12\udd50\udb77\udc8d",
        58, 54632, -1650796869, 3370438816303426693L, 84011L, true, false, (char) 26241, (char) 15562,
        Double.longBitsToDouble(0x3fefaeb9ebebd2a3L), Double.longBitsToDouble(0x3fb6f3cebb88d030L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Double:-3.5716111449287546 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-3.5716111449287546 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 0, "", "\u954b", "\ud8ac\udc24\udb12\udf2a\ud83d\udfba\ud867\ude21\000\000\ud9de\udcdf\u58c1\000\ud967\udf73\ud86f\udcd8\ud905\uddbd\udb8a\udfc8",
        32, 12766, -217448448, -7426365320691544196L, 83734L, false, false, (char) 50979, (char) 29192,
        Double.longBitsToDouble(0x3f27406bb4d00000L), Double.longBitsToDouble(0x3fafc3cd75ce3b80L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Double:1.7852179647780287E-9 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 0, 12, "\uda48\ude85\u8a00\000\000\ud9cf\uddc6\ud9cb\udd77\ud842\udf36\010\udac6\udd71\ud964\udcce\uda06\udd79\ud859\ude64\uda07\udd06\ud971\udd44\u4d4a\u129c\uda43\uddfd\ud9be\ude22\uda94\udca2\udb17\udc91\ud88f\udddd\uda65\uddbe", "\u5794\u2374", "\udb4f\udea7\u00e2\uda5a\udced",
        45, -1000, 1811939328, 5919062171789988917L, -1908L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe000000053c078L), Double.longBitsToDouble(0x3fe9ac31100000b1L)));
  }
  @Test
  public void test87() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test87() throws Throwable {
//     assertEquals("0=java.lang.Double:-1.6842234439501145 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:0.3981752440372065 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
//         Z.run(T, 2, 9, 1, 4, "\ud83a\udef5\udba4\udf3a\udbe1\udeba\ud882\udde2\ud842\udf67\ud913\udd1a\u16d7\uda73\udd0e\udbcb\udd81\ud9e6\udf57", "\u9cbf\u77a6\u21fc", "\ud997\udf94",
//         32, 90804, -217414867, -2782465667318368103L, 84922L, true, false, (char) 31214, (char) 30855,
//         Double.longBitsToDouble(0x3fafc3cd45ce3b80L), Double.longBitsToDouble(0x3fc2ca66649bff10L)));
//   }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.Double:-8.0 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 7, 3, "\ud89b\uddd3\uda2c\udc96\udbb4\udd2a\ud8e6\ude22\udba5\udd69\udb56\udd63", "\000", "\ud8c3\ude6c",
        2, -763, 10245, 5346413260693165564L, -86221L, false, false, (char) 47227, (char) 48230,
        Double.longBitsToDouble(0x3cd0000000000000L), Double.longBitsToDouble(0x3f4a800000000000L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Double:0.3989422804014327 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:0.3989422804014327 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 1, 1, 6, "\uef4e\udace\udc9f\udb24\udfc2\udaa8\udfeb\ud833\ude17\ud8ac\udc24\000\ud83d\udfba\ud8b0\udd77\ud9f8\udcee", "\u9cbf\uae31\u21fc", "\000",
        -5, 17656, -217414867, 93344544816L, -21413L, false, false, (char) 50979, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3faf800045ce3b80L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Double:-1.7535677900781015 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-1.7535677900781015 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 0, "", "\u9ec7", "\ud8ce\uddae\ud87f\uddda\ud95f\ude5d",
        47, 50256, 0, 1683624426957985985L, 31072L, false, true, (char) 35852, (char) 15074,
        Double.longBitsToDouble(0x3fa45a69c00f6b70L), Double.longBitsToDouble(0x3ec8405bcc280000L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.Double:-7.877350159179226 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 1, 8, 0, 0, "", "\u902a\000\000\000\000\000\000\000\ub9b3\u12dc", "\000\ud9f4\udf0b\uda83\uddba",
        10, 51896, 41570, -939524096L, 78014L, false, false, (char) 0, (char) 39936,
        Double.longBitsToDouble(0x3cde000000000000L), Double.longBitsToDouble(0x3fca556000021e68L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.Double:-1.415007467917872 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:-1.415007467917872 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 11, "\udbfa\udea3\udba6\udc3c\uda0b\udf51\ud804\uddeb\ud95d\udde8\ud9cb\udd77\ud842\udf36\uda92\udc54\udac6\udd8a\ud964\udcce\udb02\uddce\ud916\udcdb\ud838\udf31", "\ua21e\u126a\u91c0\u0573\uc159\ubfe9\u47b8\ub9bd", "\udb9d\udd22\udab8\udd0d\ud81e\udcbc\uda97\udf56\uda81\uddb9\ud9bd\udd37",
        -2, 25357, 1215476720, 1802644345553873277L, 84908L, true, true, (char) 29247, (char) 19633,
        Double.longBitsToDouble(0x3fb41abfacc6e2c8L), Double.longBitsToDouble(0x3fa5201c13f92d50L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.Double:2.428007763730193 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:2.428007763730193 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 3, "", "\u954b\u6fad\ud7cf\u8ac9\u438b\u2bcc\u85b9u\u0426\u202d", "\uda51\udc04",
        1, 17870, -1261199305, 4303169824181837750L, 56082L, true, false, (char) 44041, (char) 50979,
        Double.longBitsToDouble(0x3fefc1d080002e80L), Double.longBitsToDouble(0x3fe5da68043f879aL)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.Double:3.4542924137377016 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\0121=java.lang.Double:3.4542924137377016 |this=org.apache.commons.math.distribution.NormalDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 6, "\ud873\udfe1\uda0b\udf86\uda86\ude26\ud838\udeaa\uda05\udea3", "\u7909\u7472\u6d2a\u8dcb\u0b40\u9cbf\u77a6\u21fc", "\ud9be\ude22\uda35\udde4\u9a0b",
        57, 44153, -767951932, 4300828231365479685L, -93896L, false, false, (char) 48450, (char) 18331,
        Double.longBitsToDouble(0x3feffdbd75bf19e5L), Double.longBitsToDouble(0x3fdc0dee2450a50cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.distribution.NormalDistributionImpl|cumulativeProbability|double|new:org.apache.commons.math.distribution.NormalDistributionImpl:",
    "M|org.apache.commons.math.distribution.NormalDistributionImpl|density|double|new:org.apache.commons.math.distribution.NormalDistributionImpl:",
    "M|org.apache.commons.math.distribution.NormalDistributionImpl|getDomainLowerBound|double|new:org.apache.commons.math.distribution.NormalDistributionImpl:",
    "M|org.apache.commons.math.distribution.NormalDistributionImpl|getDomainUpperBound|double|new:org.apache.commons.math.distribution.NormalDistributionImpl:",
    "M|org.apache.commons.math.distribution.NormalDistributionImpl|getInitialDomain|double|new:org.apache.commons.math.distribution.NormalDistributionImpl:",
    "M|org.apache.commons.math.distribution.NormalDistributionImpl|getMean||new:org.apache.commons.math.distribution.NormalDistributionImpl:",
    "M|org.apache.commons.math.distribution.NormalDistributionImpl|getSolverAbsoluteAccuracy||new:org.apache.commons.math.distribution.NormalDistributionImpl:",
    "M|org.apache.commons.math.distribution.NormalDistributionImpl|getStandardDeviation||new:org.apache.commons.math.distribution.NormalDistributionImpl:",
    "M|org.apache.commons.math.distribution.NormalDistributionImpl|inverseCumulativeProbability|double|new:org.apache.commons.math.distribution.NormalDistributionImpl:",
    "M|org.apache.commons.math.distribution.NormalDistributionImpl|sample||new:org.apache.commons.math.distribution.NormalDistributionImpl:",
    "C|org.apache.commons.math.distribution.NormalDistributionImpl|<init>|",
    "C|org.apache.commons.math.distribution.NormalDistributionImpl|<init>|double,double,double",
    "C|org.apache.commons.math.distribution.NormalDistributionImpl|<init>|double,double",
    "M|org.apache.commons.math.distribution.NormalDistributionImpl|cumulativeProbability|double|new:org.apache.commons.math.distribution.NormalDistributionImpl:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
