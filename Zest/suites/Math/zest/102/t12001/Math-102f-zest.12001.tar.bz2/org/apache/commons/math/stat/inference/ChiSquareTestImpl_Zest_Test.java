package org.apache.commons.math.stat.inference;
import org.junit.Test;
import static org.junit.Assert.*;
public class ChiSquareTestImpl_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 5, "\udbda\udd93\udbf1\udde0\uda41\udc11\u4b28\ud8e3\udcde", "\ua54b\u01c4\u7472\u418f\u625e\u56d7\u40eb\u62e4\u83a2", "\udbc7\udfdf\udba6\udfd1\udab6\udf19\uda2f\udd5a\udbae\udf53\ue90e\u82b5",
        52, 52950, 43576218, 7501894170882027414L, -92338L, false, false, (char) 41092, (char) 57216,
        Double.longBitsToDouble(0x3fe2d0e1bc3f71f0L), Double.longBitsToDouble(0x3fe99603d907a263L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 1, "\udb9b\ude1f\udbf1\udde0\uda41\udc11\ud917\udf09\ud973\udcf8", "\ua54b\u01c4\u7472", "\ud955\udc0f",
        9, 41271, -1505206792, -6489929328668232160L, 1301L, false, false, (char) 34518, (char) 9746,
        Double.longBitsToDouble(0x3fe97955a65a1b32L), Double.longBitsToDouble(0x3fecd3bd85000298L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 10, 5, "\udbda\udd93\udbf1\udde0\uda41\udc11\u4b28\ud8e3\udcde", "\ua54b\u01c4\u7472\u418f\u625e\u56d7\u40eb\u62e4\u83a2", "\udbc8\udc02\udba6\udfd1\udab6\udf19\uda2f\udd5a\ud8cf\udf7e\ud830\udd9e\uda09\uddf8",
        32, 78465, 46789772, 7501894170882027414L, -92338L, false, false, (char) 41092, (char) 57216,
        Double.longBitsToDouble(0x3fe2d0e1bc3f71f0L), Double.longBitsToDouble(0x3fe71603d907a2e8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 8, 5, "\udbda\udd93\udbf1\udde0\uda41\udc11\u4b28\ud8e3\udcde", "\ua54b\u01c4\u7472\u418f\u625e\u56d7\u40eb\u62e4\u83a2", "\udbc7\udfdf\udba6\udfd1\udab6\udf19\uda2f\udd5a\udbae\udf53\ue90e\ud8c4\udd85",
        3, 52950, 43576218, 7501894170882027414L, -92338L, false, false, (char) 41092, (char) 57216,
        Double.longBitsToDouble(0x3fe2d0e1bc3f71f0L), Double.longBitsToDouble(0x3fe99603d907a263L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[D:[[27627.0, 28408.0, 28011.5, 28510.0, 28110.5, 28251.5, 28013.0, 28271.5]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 4, 5, "\ud806\ude20\udb07\udeec\udbcd\udce7\udb0a\udd0f\ud951\ude0c", "\uaf3d\ua449\u7472\u418f\u625e\u56d7\u40eb\u62e4\u6073\uc908\ud59f\u3da0\u49b1\ua6cb\u5cd3\u7bc7\u7a27\ubdf0\u6c9f\ucc60\u0eae\u3064\u61f4\u7b4c\uae04\u329b\u74ac\uc4d3\u2d64\uc1bd\u890e\ub03e\u1643\u37b3\u576f\u382d", "\udb67\udf05\ud9e4\udcc7\uda04\uddb9\ud847\udefc\udbe6\udd2a\ud80b\udd67\ud99b\udd31\ufa12\udb55\udf42\ud8e8\udda0\udaaf\udecd\udb47\ude67\uda03\udc6c\udad4\udfb3\udbc1\udf9c\udb28\udd45\udb97\udedb\ud848\ude68",
        51, 55213, 1817157917, 1852989269237229572L, 89221L, false, true, (char) 34919, (char) 14329,
        Double.longBitsToDouble(0x3fea68b3f80d3c9eL), Double.longBitsToDouble(0x3feda1d62bb58779L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.math.distribution.DistributionFactoryImpl:@? |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 7, 5, "\ud881\udda5\ud925\udc1e\uda41\udc11\u4b28\ud8e3\udcde", "\ua54b\u01c4\u7472\u443a\u8431\ua849\u40eb\u62e4\u83a2", "\udbc7\udfdf\uda38\ude3a\udab6\udf5e\uda2f\udd5a\udbae\udf53\ue90e\u82b5",
        52, 52950, 43576218, 7501894170882027414L, -92514L, false, false, (char) 41092, (char) 57216,
        Double.longBitsToDouble(0x3fe062d9bc3f71f0L), Double.longBitsToDouble(0x3fe99603d907a263L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 10, 5, "\udbda\udd93\udbf1\udde0", "\u1c11\u699a\ub221\ua54b\u01c4\u7472\u418f\u625e\u2fd6\u40eb\u62e4\u83a2\ub8e9\ub002\u3da0\u49b1", "\udbae\udf53\ue90e\u82b5\ud860\udc37\udaa9\udd93\ud88a\udfc1\uda8c\udf22\ud9c5\ude11\ud87d\udc1b\ud851\udfd3\ud968\udfa0\ud940\udd4e\udad3\udd0b\udbb5\udd10",
        9, 42042, 881938695, 5314166869445074454L, -33412L, true, false, (char) 51818, (char) 18234,
        Double.longBitsToDouble(0x3fc02c4af8a8221cL), Double.longBitsToDouble(0x3fe22ad51d02aa02L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 13, 5, "\udbda\udd93\udbf1\udde0\udb4d\ude86\u4b28\ue4e9", "\ua54b\u01c4\u7472\u418f\u625e\u368c\000\u62e4\u83a2", "\udbc7\udfdf\udba6\udfd1\udab6\udf19\uda2f\udd5a\udbae\udf53\ue90e\u82b5",
        -5, 41040, 43576218, 7501894170882027414L, -92338L, false, false, (char) 41092, (char) 57216,
        Double.longBitsToDouble(0x3fe2d0e1bc3f71f0L), Double.longBitsToDouble(0x3fe99603d907a263L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Double:71207.18060698769 |a0=[D:[[28102.0, 28398.5, 28128.5, 28376.0, 27912.5, 28144.5, 9596.0, 27876.5]] |a1=[J:[[404, 29762, 16735, 25134, 22183, 16571, 25268, 33650]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=org.apache.commons.math.distribution.DistributionFactoryImpl:@? |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 0, 10, 1, "\udbbc\ude0d\udbf1\udde0\uda41\udc11\u4b28\ud9f9\udd49\udb7e\udedc", "\u01c4\u7472\u418f\u625e\u56d7\u40eb\u62e4\u83a2\ub8e9\ub002\u3da0\u49b1\u2c06\u5cd3\u7bc7\u7a27\ubdf0\u6c9f\ucc60\u0eae\u3064", "\ud851\udfd3\ud968\udfa0\ud940\udd4e\udad3\udd0b\udbb5\udd10\udaf8\udc80\udaf4\uddad",
        5, 64044, -393672893, 449685044973446632L, 97413L, true, true, (char) 23098, (char) 41358,
        Double.longBitsToDouble(0x3fef8d4188ba3761L), Double.longBitsToDouble(0x3fc6461b56ac088cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[D:[[28117.0, 28337.5, 28128.5, 28376.0, 27912.5, 28144.5, 9596.0, 27737.5]] |a1=[J:[[42267, 404, 29762, 16735, 15643, 34602, 16571, 25268]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=org.apache.commons.math.distribution.DistributionFactoryImpl:@? |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 6, 10, 5, "\udbda\udd93\udbf1\udde0\uda41\udc11\u4b28\ud8e3\udcde", "\ua54b\u01c4\u7472\u418f\u3d4b\u875a\u40eb\u62e4\u83a2", "\udbc7\udfdf\udba6\udfd1\udab6\udf19\uda2f\udd5a\udbae\udf53\ue90e",
        14, 92037, 2008034950, 187158432940037376L, 70950L, true, false, (char) 57216, (char) 12945,
        Double.longBitsToDouble(0x3fafb8f8732c07b0L), Double.longBitsToDouble(0x3fb16898e8953850L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=org.apache.commons.math.distribution.DistributionFactoryImpl:@? |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 15, 10, 13, "\udbda\udd93\udbf1\udde0\uda41\udc11\u4b28\ud8e3\udcde", "\ua54b\u01c4\u7472\u418f\u625e\u1f60\u28fe\u49e2\u83a2", "\udbc7\udfdf\udba6\udfd1\udab6\udf19\uda2f\udd5a\udbae\udf53\ue90e\udb26\udeb7",
        52, 37532, 43576218, 7501894170882027414L, -92338L, false, false, (char) 41092, (char) 57216,
        Double.longBitsToDouble(0x3fe2d0e1bc3f71f0L), Double.longBitsToDouble(0x3fe99603d907a263L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Double:53984.79283347787 |a0=[J:[[56234, 56675, 56257, 56752, 55825, 56289, 19192, 55701]] |a1=[J:[[16735, 25134, 22183, 16571, 25268, 33650, 47289, 45010]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=void |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 3, 15, 5, "\udbda\udd93\udbf1\udde0\uda41\udc11\u4b28\ud9c5\udf90\udab0\udf10\uda34\ude62\ud9ef\udef7", "\u418f\u625e\u56d7\u40eb\u62e4\u83a2\ub8e9\ub002\u3da0\u7152", "\udbae\udf53\ue90e\u82b5\ud860\udc37\udaa9\udd93\ud88a\udfc1\uda8c\udf22\ud9c5\ude11\ud87d\udc1b\ud851\udfd3\ud968\udfa0\ud940\udd4e\udad3\udd0b\udbb5\udd10",
        9, 42042, -1597157113, -3149548986442332420L, 73523L, false, true, (char) 61125, (char) 44578,
        Double.longBitsToDouble(0x3fe60418674d7fedL), Double.longBitsToDouble(0x3fdb7a02f6af9c06L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 0, 0, "\ud93e\ude85\udbf1\udde0\uda41\udc11\uda73\udd38\ud84b\udc8a\udab3\udcc1\uda34\ude62\uda02\udcf7\udbe2\udc9d\ud8ff\udc64\ud95c\ude48\ud8dc\udffd\udb79\udeee\uda73\udeff\uda13\udf48\ud9c2\udf83\ud8d1\udd5a\ud87a\udc35\udbe9\udde6\ud95d\ude0d\ud99b\udec7\uda2f\udd5a\ud9da\udf49\udaeb\udcb5\u82b5\ud860\udc37\ud90d\udd26", "\ub534\u0eaf\u6326\uc90c\u364f\u3e9c\u59a3", "\ud898\udf09\u8af7",
        59, 65241, -1105304440, -8255592866886275094L, 76265L, false, true, (char) 38552, (char) 64448,
        Double.longBitsToDouble(0x3faad428e9f50ef0L), Double.longBitsToDouble(0x3fb82891eb9e8bd8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[J:[[55507, 56695, 56257, 56773, 55288, 57168, 55740, 56333]] |a1=[J:[[30488, 51993, 29762, 10453, 25134, 22183, 16571, 45521]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 1, 9, 10, 5, "\ud903\udda7\udbf1\uddf5\ud828\udf80\ud9ec\udc3d\uda7f\udd26", "\u7748\ucb49\u7472\u2905\u625e\u56d7\u40eb\ub201", "\ud91e\udc38",
        17, 71295, 1062650423, 1997891040059457084L, -25296L, false, true, (char) 63805, (char) 57368,
        Double.longBitsToDouble(0x3fd0b61125676f9cL), Double.longBitsToDouble(0x3fe40d04a032de0cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 5, "\udbda\udd93\ud935\ude82\uda41\udc11\u4b28\ud8e3\udcde", "\ua54b\u01c4\u7472\u74af\u625e\u56d7\u40eb\u62e4\u83a2", "\udbc7\udfdf\udba6\udfd1\udab6\udf19\uda2f\udd5a\udbae\udf53\ue90e\udbcf\udf6b",
        55, 52950, 43576218, 7501894170882027414L, -92338L, false, false, (char) 41092, (char) 57216,
        Double.longBitsToDouble(0x3fe2d0e1bc3f71f0L), Double.longBitsToDouble(0x3fe99603d907a263L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[J:[[56212, 56733, 56267, 56405, 55825, 56289, 55652, 57257]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 6, 7, "\udbc4\uddcd\udbfb\udc85\uda41\udc11\ud994\udfd9\uda45\ude3c\udbce\udfae\u46ab\ud9ef\udebd\udbe2\udc9d\uda65\udf16\udbea\udcd7\uda34\ude9b", "\u56b2", "\udbc4\uddd4",
        41, 89919, 1238191148, 6176029470352055764L, 70950L, true, false, (char) 57216, (char) 12945,
        Double.longBitsToDouble(0x3f9071f0f3e50f60L), Double.longBitsToDouble(0x3fd07a2632085d5cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Double:75320.50099052543 |a0=[D:[[28117.0, 28337.5, 28128.5, 28376.0, 27774.5, 28297.0, 27720.0, 28613.0]] |a1=[J:[[35847, 404, 31203, 16712, 53550, 22183, 16571, 45217]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 7, 12, "\udbda\udd93\udbf1\udde0\ud92d\udd42\ud8c0\udfba\ud92b\uddcd", "\u8c37\u01c4\u7a13\u4178\ud15e\u56d7\u40eb\ub0d1\u0a13", "\ud857\udc04\ud9c9\ude3f\udab6\udf19\uda2f\udd5a\udbae\udf53\udb5b\udcdf\ud984\udda7\udac1\udeff\udaa9\uddd3\ud88a\udfc1\uda0d\ude83\ud9c5\ude5e\ud87d\udc1b\ud851\udfd3\ud844\udcdd\ud940\udc92\udad3\udd0b\ud93f\ude76\ud84b\ude7a\udaf4\uddad\ud867\uddb0\udae7\udfe9\ud8d1\udda6\ud875\uddd1\udbaf\uded3\udbee\udf00\ud8d1\uded6\ud95d\udf63",
        24, 82935, 1629873701, -5088046491295467747L, -60799L, true, false, (char) 38496, (char) 41765,
        Double.longBitsToDouble(0x3fe9e63970369f48L), Double.longBitsToDouble(0x3feee87ed5977c2eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 10, 5, "\000\ud93d\ude5d", "\u04ea\u68b4\ub221\ua54b\u01c4\u7472\u418f\u625e\u56d7\u8c57\u62e4\u83a2\ub8e9\ub002\u3da0\u49b1", "\000\000\u81d2\ud860\udc37\udaa9\udd93\ud88a\udfc1\uda8c\udf22\ud9c5\ude11\ud860\ude1b\ud851\udfd3\ud968\udfa0\ud940\udd4e\udad3\udd0b\udbb5\udd10",
        9, 42042, 1267814663, -6456834643203531009L, 66142L, true, true, (char) 39481, (char) 63045,
        Double.longBitsToDouble(0x3fe3b85397204f8fL), Double.longBitsToDouble(0x3fe1e8874e1a6926L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[[J:[[[56206, 57187, 55361, 57171, 55335, 56677, 56083, 56929]]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=java.lang.Boolean:true |a0=[[J:[[[56206, 57187, 55361, 57171, 55335, 56677, 56083, 56929]]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 14, 12, 5, "\udbbe\udf93\ud871\udf83\ud857\udd95\udb43\ude91\ud994\udf0b\udab3\udc70\ud917\ude8b\ud9ef\udf17\udbe2\udc9d\udb4b\uddd0", "\u5bc3", "\uda66\ude49\ud8ab\ude5a\udb94\udc42\udbc8\udc94\udba6\udfd1\udb1a\udfac\uda2f\udda1\udb9a\udf31\ud9e3\udea3",
        9, 80473, 2008034964, 187158432621270272L, 34341L, true, false, (char) 30080, (char) 31416,
        Double.longBitsToDouble(0x3fe78197870cd275L), Double.longBitsToDouble(0x3fab14101541a590L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 13, 11, "\udbda\udd93\udbf1\udde0\uda41\udc11\u6728\ud8e3\udcde", "\u767e\ub642\u836b\u9f47\uc6cf\u5297\u40cc\u62e4\u83a2", "\udbc7\udfdf\uda2a\udfd3\uda6d\udc6a\udb21\udc76\ud968\udd4b\u8747\u82b5",
        52, 2296, 1116214460, 7523604951390433174L, -26802L, true, false, (char) 41092, (char) 57216,
        Double.longBitsToDouble(0x3fe2d0e1bc3f71f0L), Double.longBitsToDouble(0x3fe99603d907a263L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Double:49236.67538726461 |a0=[D:[[28117.0, 28337.5, 28128.5, 28376.0, 27912.5, 28144.5, 9596.0, 27737.5]] |a1=[J:[[42267, 404, 29762, 16735, 25134, 22183, 16571, 25268]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=java.lang.Boolean:true |a0=[J:[[56234, 56675, 56257, 56752, 55825, 56289, 19192, 55475]] |a1=[J:[[42267, 404, 29762, 16735, 25134, 22183, 16571, 25268]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 0, 8, 2, "\udbda\udd93\udbf1\udde0\uda41\udc11\u4b28\ud8e3\udcde", "\ua54b\u01c4\u7472\u418f\u625e\u56d7\u40eb\u62e4\u83a2\ub8e9\ub002\u3da0\ua934", "\udbae\udf53\ue90e\u82b5\ud860\udc37\udaa9\udd93\ud88a\udfc1\uda8c\udf22\ud9c5\ude11\ud87d\udc1b\ud851\udfd3\ud968\udfa0\ud940\udd4e\udad3\udd0b\udbb5\udd10",
        9, 42042, -18198265, 6952405593832945400L, 82317L, true, true, (char) 56303, (char) 46655,
        Double.longBitsToDouble(0x3fdaa847d92e7480L), Double.longBitsToDouble(0x3fc499b4ab7987b8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 12, 5, "\udbda\udd93\udbe6\udee0\uda41\udc11\u4b28\ud92e\udcf0\ud9a2\udf17\uda34\ude62\udacc\udcda\udbe2\udc9d\ud88c\udcaa\ud93c\udff2\ud8dc\udffd\udb79\udeee\uda73\udeff\ud81a\udf6d\ud9c4\udcae\ud944\udcc6\ud87a\udcea\udbd4\udedf\udba6\udfd1\udab6\udf19\uda2f\udd5a", "\ubdf0\ua2b9\u3d68\u4a3d\ua44c\ua38b\u5944\u577b\uc926\u32f5\u52ae", "\ud85d\udeba\udb0b\udfe4\uda40\udfb6\udadf\udf7b\ud819\udc6f\udb78\udc58\ud8fc\udf88",
        -4, 83827, 769097339, 5764120416060179579L, 84470L, true, true, (char) 40763, (char) 23637,
        Double.longBitsToDouble(0x3fe0cd84518639c4L), Double.longBitsToDouble(0x3fea5983edb54593L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[[J:[[[56227, 56850, 55584, 56577, 55825, 56297, 19192, 55475]]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 1, 5, "\udbd3\ude42\ud950\udd31\uda41\udc19\u4b28\ud8e3\udcde", "\ua54b\u01c4\u7472\u418f\u625e\u168c\u5b97\u283f\u83a2", "\udbc7\udfdf\udba6\udfd1\udab6\udf19",
        58, 34012, 254720041, -3887829261984272507L, -39686L, false, true, (char) 38834, (char) 57419,
        Double.longBitsToDouble(0x3fdee1eb387530d0L), Double.longBitsToDouble(0x3fe79bec8b62e41eL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.math.distribution.DistributionFactoryImpl:@? |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=org.apache.commons.math.distribution.DistributionFactoryImpl:@? |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 10, 10, 9, "\udbb4\ude68\udbf1\udde0\uda41\udc11\udaa7\udfc1\ud8e3\udcb3", "\ua54b\u01c4\u7472\u418f\u617c\uab9b\u4106\u62e4\u83a2", "\ud9cd\udfe2\udba6\udf2f\udab6\udf19\uda2f\udd5a\udbae\udf53\ue90e\u82b5",
        52, 50560, 43575053, 7501894170882048406L, -8661L, false, true, (char) 41092, (char) 57216,
        Double.longBitsToDouble(0x3fe2d0e1bc3f71f0L), Double.longBitsToDouble(0x3fe99603d907a263L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 11, 5, "\000", "\000\u1c11\u699a", "\udbe2\udc9d\ua1b9\ud93c\udfb6\ud8dc\udf6d\udb79\udeee\ud846\udefa\ud81a\udf6d\ud9c4\udcae\ud826\udfb7",
        -3, 57716, 1755856295, 213541479025589L, 31072L, true, true, (char) 47504, (char) 45716,
        Double.longBitsToDouble(0x3fecd3bd85000298L), Double.longBitsToDouble(0x3fecb340e24c6dffL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 5, "\udbda\udd93\ud8c9\udfed\uda41\udc01\u4b28\ud8e3\udcde", "\ua54b\u01c4\u7472\u418f\u625e\u924a\u4155\u62e4\u7f2f", "\ud89d\udcb6\udba6\udfd1\udab6\udf19\uda2f\udd5a\udbae\udf53\ue90e\u82b5",
        52, 52950, 43576218, 7501894170882027414L, -92338L, false, false, (char) 41092, (char) 57216,
        Double.longBitsToDouble(0x3fead0e1bc3f71d9L), Double.longBitsToDouble(0x3fe99603d907a263L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 8, 5, "\ud820\udd96\uda5d\udff7\udbe7\uddbb\udb8f\udcaf\ud8eb\ude84", "\ua54b\u01c4\u7472\u56ca\u61e7\u9dd4\u0513\u8b74\u7b74", "\udbc7\udfdf\udb69\udc93\ud9a6\udcb9\ud9cc\udfe8\ud956\uddbf\u9821\ud997\udccd",
        52, 52950, 43576218, 7529197243540388141L, 64849L, true, true, (char) 25340, (char) 57193,
        Double.longBitsToDouble(0x3fe2d139bc3f71f8L), Double.longBitsToDouble(0x3fe99603d907a263L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 3, 8, "\ud916\uddd0\ud835\udccd\uda0a\udf55\u4b8a\ud8e3\udcde\udab3\udcc1\uda34\ude62\ud9ef\udef7\ud8d1\udd6e\udb7d\udeb6\udae7\udf5b\ud922\ude40\udbb2\udd17\udbab\udfba\ud81a\udf6d\ud9c3\udff3\ud8ab\ude5a\uee16\udbc7\udfdf\udba6\udfd1\udab6\udf19\uda2f\udd5a\udbae\udf53\uda48\udd15\u82b5\ud860\udc37\udaa9\udd93\ud88a\udfc1\uda8c\udf22\uf60d\udb2b\ude53\ud936\udd6e\ud969\udc26\ud940\udd4e\udad3\udd0b\udbb5\udd10\udaf8\udc80\udaf4\uddad\uda55\ude67\u36fc", "\uc0ae", "\udbd4\ude9a\ud819\udc87\ud842\uddeb",
        19, 2271, -1393572009, 3918869794783574406L, -43379L, false, true, (char) 50716, (char) 13357,
        Double.longBitsToDouble(0x3fdf25764e72e082L), Double.longBitsToDouble(0x3fe8a855f4dbfe25L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[[J:[[[55831, 56368]]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 5, 8, "\uda47\udc60", "\u02ef\u1c11\u699a", "\udbe2\udc9d\ud88c\udcaa\ud93c\udff2\ud853\udf7c\udb79\udeee\uda73\udeff\ud81a\udf6d\ud9c4\udcae\ud8ab\ude5a",
        3, 78760, 1755856295, 1082766303890148277L, -16073L, true, true, (char) 47504, (char) 45716,
        Double.longBitsToDouble(0x3fecd3bd85000227L), Double.longBitsToDouble(0x3fecb340e24c6dffL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[D:[[28117.0, 28337.5, 28128.5, 28376.0, 27912.5, 28144.5, 9627.0, 27737.5]] |a1=[J:[[42267, 404, 29762, 16735, 25134, 819, 5933, 25268]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 2, 5, "\udbda\udd93\udbf1\udde0\uda41\udc11\u4b66\ud8e3\udcde", "\ua54b\u01c4\u7472\u418f\u625e\u0363\u175d\u62e4\u83a2", "\udb12\udc30\ud819\udc05\udab6\udf19\uda2f\udd5a\udbae\udf53\ue90e\u82b5\ud860\udc37\udaa9\udd93\ud88a\udfc1\uda8c\udf22\ud9c5\ude11",
        39, 43518, 2102011344, -2009129956214834334L, 75865L, false, true, (char) 44106, (char) 61142,
        Double.longBitsToDouble(0x3fc239a525f19020L), Double.longBitsToDouble(0x3fb7a267895cc088L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 1, "\udb81\ude1f\udbf1\udde0\uda41\udc11", "\u66e3\u64fd\ua54b\u01c4\u7472\u418f", "\uda73\udeff\ud81a\udf6d\ud9c4\udcae\ud8ab\ude5a",
        3, 57716, 1755856295, 1082766302376987573L, -16073L, true, true, (char) 26083, (char) 18828,
        Double.longBitsToDouble(0x3fecd3bd85000298L), Double.longBitsToDouble(0x3fe4cc8f4d1947eaL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 8, 0, "", "", "\u00e9\000\uda21\udd3e\000\udbe2\udc9d\ud88c\udcaa\ud93c\udff2\ud8dc\udffd\ud4a0\ud846\udea3\ud88e\udf67\ud9c4\udcae\ud8ab\ude5a\u3620",
        -5, -1000, 0, 2013390508422725180L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3ee4c7b1da830000L), Double.longBitsToDouble(0x3fe966dea601679bL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[[J:[[[56171, 56815, 56257, 56752, 55990, 56468, 55480, 57221]]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 3, 1, "\udb9b\ude1f\udbf1\udde0\udae6\udcc4\ud8e8\udfb5\ud97a\udd14", "\u145b\u019c\uc907", "\ud955\udc0f\uda73\udeff",
        11, 96208, -1511054423, 2546563623904625924L, 80791L, true, true, (char) 6701, (char) 34518,
        Double.longBitsToDouble(0x3fef1e71732f2abeL), Double.longBitsToDouble(0x3fe2d0d994ea8d7dL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 10, "\udb9b\ude1fw\000\uda6a\udfff\ud973\udcf8", "\ua54b\ua765\u300e", "\ud955\udc0f",
        35, -1000, 0, -6489968537424677344L, 1301L, false, false, (char) 0, (char) 52736,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe8000005000298L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 5, 1, "\udb9b\ude1f\udbf1\udde0\uda41\udc11\ud917\udf09\ud973\udcf8", "\ua54b\u01c4\u7472", "\ud955\udc0f\uda73\udeff\ud81a\udf6d\ud9c4\udcae\ud8ab\ude5a\ud87a\udc35\udbc7\udfdf\ud9de\ude6e\uda93\ude8f\uda2f\udd5a\udbae\udf53\ud98f\udd39\ud8e0\ude67\ud905\udcc9\udaa9\udd67\ud88a\udfc1\udb1f\udcec\udb94\udf7c\uda7b\udfeb\ud9b2\udc30\uda95\udcdf\udbb0\udd3e\ud84c\udd58\ud8fb\udf08\udbae\udeb1\udbdd\udc5e\ud9cd\udcff",
        48, 28530, -571875068, 993644904180711691L, 58088L, true, true, (char) 20740, (char) 6508,
        Double.longBitsToDouble(0x3fc3522e6bac7304L), Double.longBitsToDouble(0x3f80045fbd281c00L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 10, 13, "\udb09\ude07", "", "\u0c0a",
        -5, 71205, 214, 794568949760L, 19968L, true, false, (char) 7533, (char) 3933,
        Double.longBitsToDouble(0x3fc534c900000000L), Double.longBitsToDouble(0x3d95000000000000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[D:[[28085.5, 28407.5, 27692.0, 28622.5, 27768.5, 28364.5, 27763.5, 28524.5]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=java.lang.Boolean:true |a0=[D:[[28085.5, 28407.5, 27692.0, 28622.5, 27768.5, 28364.5, 27763.5, 28524.5]] |a1=[J:[[30546, 16135, 16806, 25134, 38089, 14663, 25414, 33650]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 13, 4, 7, "\udb9b\ude1f\ud888\udfcd\ud921\uddc9\ud917\udf09\ud973\udcf8\ud8f9\udd05", "\u7782\u3f37\u41d6\u625e\u94f9\u3977\u6376\u83a2\u2a66", "\udb15\udf92\udab6\udf32\uda2f\udd5a\uda84\udffd\ud9d9\udf6a\ud84b\uddd9\ud892\udcd5\udaff\udc77\ud88a\udfc1\ud94f\ude85\ud919\udd77",
        5, 21657, -54063122, -6721848711945902646L, -58727L, false, true, (char) 7037, (char) 56137,
        Double.longBitsToDouble(0x3fd47353b652cbe8L), Double.longBitsToDouble(0x3fb5865d025fcaa8L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[J:[[56171, 56815]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=org.apache.commons.math.distribution.DistributionFactoryImpl:@? |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 11, 10, 1, "\udb9b\ude1f", "", "\ud8f9\udd05",
        8, 71205, -1770434858, 177815942478592L, -100000L, false, false, (char) 7533, (char) 100,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd042300b4f5188L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Double:66907.80804263076 |a0=[D:[[28085.5, 28439.0, 28128.5, 28376.0, 27912.5, 28144.5, 27805.0, 28384.5]] |a1=[J:[[365, 29581, 47880, 33442, 9771, 21470, 29084, 44273]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=java.lang.Double:66907.80804263076 |a0=[D:[[28085.5, 28439.0, 28128.5, 28376.0, 27912.5, 28144.5, 27805.0, 28384.5]] |a1=[J:[[365, 29581, 47880, 33442, 9771, 21470, 29084, 44273]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 16, 0, 4, "\udb9b\ude5e\udbf1\udde0\uda41\udc11\ud96a\uddf1\uda0a\udf56\ud845\udc32", "\u019d\u73bd\ubb38\u82d2\u265b\u540e\u71cc\uad21\u7baf", "\udba6\udfd1\uab94\uda2f\udd5a\udbae\udf53\u93c4\udb64\uddba\udb6b\uddc7",
        33, 44218, -988998400, -5244340012565174557L, 20225L, true, false, (char) 52156, (char) 57439,
        Double.longBitsToDouble(0x3fe5e7000dada56eL), Double.longBitsToDouble(0x3f9ea60f80f038a0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[D:[[28085.5, 28407.5, 28128.5, 28376.0, 27912.5, 28144.5, 27763.5, 28524.5]] |a1=[J:[[36846, 404, 29762, 16735, 25134, 16659, 16571, 25268]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=java.lang.Double:0.0 |a0=[D:[[28085.5, 28407.5, 28128.5, 28376.0, 27912.5, 28144.5, 27763.5, 28524.5]] |a1=[J:[[36846, 404, 29762, 16735, 25134, 16659, 16571, 25268]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 6, 6, 1, "\udb9b\ude1f\udbf1\udde0\uda41\udc11\ud917\udf09\ud94b\udea6", "\u901e\u01c4\u7472\u418f\u625e\u4143\u40eb\u62e4\u83a2\ub8e9", "\udba6\udfd1\udab6\udf19\uda2f\udd5a\udbae\udf53\ud98f\udd39\ud8e0\ude67\ud905\udcc9\udaa9\udd67\ud88a\udfc1\ud9f2\udf15\udbaa\udf96\u0c2e\ud9ee\udf9e\udb3a\uddb4\ud8bb\ude60\uda61\udc6c\udb3a\ude2f\uda01\udeda",
        25, 90074, 560705515, 1956193915264950712L, -44541L, false, true, (char) 15434, (char) 6835,
        Double.longBitsToDouble(0x3fea568ced8c3d66L), Double.longBitsToDouble(0x3fdd3909cde3c5caL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[[J:[[[56171, 56815, 56257, 56752, 55825, 56289]]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=java.lang.Boolean:true |a0=[J:[[56171, 56815, 56257, 56752, 55825, 56289]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 14, 11, 1, "\udb9b\ude1f\udbf1\udde0\uda41\udc11", "\u66e3\u64fd\ua54b\u4ed6\u7472\u418f", "\uda73\udeff\ud81a\udf5e\ud9c4\udcae\u23a9",
        30, 57716, 1755856295, 1082766302376987573L, -16073L, true, true, (char) 26083, (char) 18828,
        Double.longBitsToDouble(0x3fecd3bd80000000L), Double.longBitsToDouble(0x3fd510ba63034864L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Double:42140.1601872489 |a0=[D:[[28085.5, 28407.5, 28128.5, 28376.0, 27912.5, 28144.5]] |a1=[J:[[26291, 25805, 42267, 404, 29762, 16735]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=java.lang.Boolean:true |a0=[J:[[56171, 56815, 56257, 56752, 55825, 56289]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 16, 11, 15, "\udb9b\ude1f\udbf1\udde0\uda41\udc11", "\u66e3\u64fd\ua54b\u01c4\u7472\u418f", "\uda73\udeff\ud81a\udf6d\ud9c4\udcae\ud8ab\ude5a",
        3, 57716, 916995495, 1082766663154240437L, 78217L, false, true, (char) 26083, (char) 18828,
        Double.longBitsToDouble(0x3fecd3bd8500ed9aL), Double.longBitsToDouble(0x3fd167eb32b5bf9aL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 4, 5, "\udbda\udd93\udbf1\udde0\uda41\udc11\u4b28\ud8e3\udcde", "\u1f85\000\uaab8\u418f\000\u185e\000\u62e4\u83a2", "\u4527\u0e21\udab6\udf19\ud8c0\udfc3\000\ufddf\uda09\uddf8",
        32, 78465, 46789632, 7904389108793344L, -92338L, false, false, (char) 8704, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e207a2000000000L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[[J:[[[56234, 56675, 56257, 56752, 55825, 56289, 19192, 55475]]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=java.lang.Boolean:true |a0=[[J:[[[56234, 56675, 56257, 56752, 55825, 56289, 19192, 55475]]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 12, 12, 2, "\udbda\udd93\udbf1\udde0\uda41\udc11\u4b28\ud8e3\udcde", "\ua54b\u01c4\u7472\u418f\u36b6\u4dc5\u411f\u62e4\u83a2\ub8e9\u8215\u5151\u647d\u2c06\u63ee\uafbf\u5e23\u6f1a\u7287\u6b05\u0d1e\ua9c7\u7ab0\u8267\u295b\uc9b5\ub5e6", "\uda9b\udc3d\uda37\udde9",
        2, 89382, 1244374262, -7421821140869204315L, 12612L, false, false, (char) 5945, (char) 61333,
        Double.longBitsToDouble(0x3fe051c1ba59c25eL), Double.longBitsToDouble(0x3fe50be6419eba44L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[J:[[15]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 0, 0, "?", "", "\udab3\udcc1",
        -4, 71205, -1770434858, -1293481176818369732L, -84007L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fed48000620a5efL), Double.longBitsToDouble(0x3ec3800000000000L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[J:[[56234, 56675, 56257, 56752, 55825, 56289, 19192, 55475]] |a1=[J:[[1580, 21472, 46030, 19987, 15274, 22183, 16571, 25268]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=java.lang.Double:39923.424838445506 |a0=[J:[[56234, 56675, 56257, 56752, 55825, 56289, 19192, 55475]] |a1=[J:[[1580, 21472, 46030, 19987, 15274, 22183, 16571, 25268]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 8, 3, 9, "\udbda\udd93\udbf1\udde0\uda41\udc11\u4b28\ud8e3\udcc5", "\u065c\u5410\ub3fe\u4e43\u3bda\u56d7\u40eb\u62e4\u83a2\ub8e9\ud007\u09a8\u838d\u2c06\u5cd3\u1381\u6045\ud03d\u5e1d", "\ud84f\udc23\udbd5\uddd6\ud85d\udd03\ud873\udcc3\ud968\udfa0\uda54\udde5\udad3\udd0b\udbb5\udd10\udaf8\udc80\udaf4\uddad\udbea\udef2\udb51\ude33\udb7f\udcbf\ua5b5\ud8ed\udc1e\uda3f\udcbc\udba5\ude75\uda93\ude95\ud8e7\udc6a\uda92\udc5e\ud955\udfe7",
        23, 26885, 1387271803, -8546433163551274197L, 63584L, true, false, (char) 36434, (char) 4123,
        Double.longBitsToDouble(0x3fcacfb4b971e84cL), Double.longBitsToDouble(0x3fc3d4efefbd3968L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[27627.0, 28408.0, -24.0, 28110.5, 28251.5, 28013.0, 28271.5, 27792.5]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 4, 5, "\ud806\ude20\000\udbcd\udce7\udb0a\udd0f\ud951\ude0c", "\uaf3d\ua449\ud1c7\u418f\u625e\u56d7\u40eb\u62e4\u6073\uc908\ud59f\u3da0\u49b1\ua6cb\u5cd3\u7bc7\u7a27\ubdf0\uc48e\ucc60\u0eae\u3064\u61f4\u7b4c\uae04\u329b\u74ac\uc4d3\u2d64\uc1bd\u890e\ub03e\u1643\u37b3\u576f\u382d", "\udb67\udf05\ud989\uded9\000\ud821\udfd0\udbe6\udd2a\ud80b\udd67\ud99b\udd31\ufa12\udb55\udf42\ud8e8\udda0\udaaf\udecd\udb47\ude67\uda03\udc6c\udad4\udfb3\udbc1\udf9c\udb28\udd45\udb97\udedb\ud848\ude68",
        51, 55213, 1817157917, 1852989269237229572L, 89221L, false, true, (char) 34919, (char) 14329,
        Double.longBitsToDouble(0x3fea68b3f80d3c9eL), Double.longBitsToDouble(0x3feda1d62bb58779L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[J:[[55254, 56816, 56023, 57020, 56221, 56503, 56026, 56543]] |a1=[J:[[44813, 42009, 29762, 16735, 25134, 22183, 16571, 25268]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=java.lang.Double:0.0 |a0=[J:[[55254, 56816, 56023, 57020, 56221, 56503, 56026, 56543]] |a1=[J:[[44813, 42009, 29762, 16735, 25134, 22183, 16571, 25268]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 9, 9, 13, "\ud806\ude20\udb07\udeec\udbcd\udce7\udb0a\udd0f\ud951\ude0c", "\uaf3d\ua449\u7472\u418f\u625e\u56d7\u40eb\u62e4\u6073\uc908\ud59f\u3da0\u49b1\ua6cb\u5cd3\u7bc7\u7a27\ubdf0\u6c9f\ucc60\u0eae\u3064\u61f4\u7b4c\uae04\u329b\u74ac\uc4d3\u2d64\uc1bd\u890e\ub03e\u1643\u37b3\u576f\u382d", "\udb67\udf05\ud9e4\udcc7\uda04\uddb9\ud847\udefc\udbe6\udd2a\ud80b\udd67\ud99b\udd31\ufa12\udb55\udf42\ud8e8\udda0\udaaf\udecd\udb47\ude67\udafa\udce6\udab8\ude9c\udbc1\udf9c\udb28\udd45\udb97\udedb\ud848\ude68",
        51, 55213, 1817157917, 1852989269237229572L, 89221L, false, true, (char) 34919, (char) 14329,
        Double.longBitsToDouble(0x3fea68b3f80d3c9eL), Double.longBitsToDouble(0x3feda1d62bb58779L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[D:[[-24.0, -24.0, -24.0, 28013.0, 28271.5, 27887.5, 28397.5]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 4, 5, "\000\000\000\udb0a\udd0f\uda0f\ude0b", "\uaf3d\ua449\u7472\u418f\u625e\u56d7\u40eb\u62e4\u6073\uc908\ud59f\u3da0\u49b1\ua6cb\u3cd3\u4cbd\u7a27\ubdf0\u6c9f\ucc60\u139b\000\u2f96\u7b00\uae04\u329b\u74ac\uc4d3\u8ded\uc1bd\u890e\ub03e\u49b7\u7c25\u576f\u382d", "\udb41\udedf\ud9e4\udcc7\u2cfd\ud847\udefc\udb26\udeeb\ud80b\udd67\ud99b\udd31\ufa12\udb55\udf42\ud8e8\udda0\udb82\ude56\ud93d\ude5d\uda03\udc6c\udad4\udfb3\udbc1\udf9c\udb28\udd45\udb97\udedb\ud848\ude68",
        51, 55213, 1817157917, 1852989268213819396L, -27040L, false, true, (char) 34919, (char) 26,
        Double.longBitsToDouble(0x3fb340000069e000L), Double.longBitsToDouble(0x3feda1d62bb58779L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[D:[[28087.0, 28245.5, 28026.5, 28454.0, 28110.5, 28251.5]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=java.lang.Boolean:true |a0=[[J:[[[56174, 56491, 56053, 56908, 56221, 56503]]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 13, 12, 8, "\udb9e\udcdb\udb25\ude7c\udbcd\udce7", "\u9395\ub221", "\ud88c\udcaa\ud93c\udff2\ud8dc\udffd\udb79\udeee\uda73\udeff\ud81a\udf6d\udb04\udf4e\ud922\udfb0\ud85e\udef0\udbc7\udfdf\udba6\udfd1\ud8fb\udd61\uda2f\udd5a\udbae\udf53\ue90e",
        -3, 92037, 2008034950, 187158432940037538L, -41812L, true, false, (char) 65101, (char) 45538,
        Double.longBitsToDouble(0x3feb1724a65a1c37L), Double.longBitsToDouble(0x3fc2ee3e074fdb60L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.apache.commons.math.distribution.DistributionFactoryImpl:@? |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=java.lang.Boolean:false |a0=[J:[[-48, 55541, 56302, 55825, 56289, 19192, 55475, 56494]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 10, 11, 0, "\000\ud925\udc1e\uda41\udc11\u4b28\ud8e3\udcde", "\ua54b\u01c4\u7472\u3b3c\000\000\000\u525e\u83a2", "\004\uda38\udd93\udab6\udf5e\uda2f\udd5a\udbae\udf53\ue90e\u81d2",
        52, 52950, 10021786, 0L, -92514L, false, false, (char) 41092, (char) 57216,
        Double.longBitsToDouble(0x3f88b66f0fdc4000L), Double.longBitsToDouble(0x3fe99603d907a263L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 10, 1, "\udbbc\ude0d\udbf1\udde0\000\000\000\ud92c\udf76", "\u01c4\u7472\u418f\u625e\u56d7\u40eb\u62e4\u83a2\ub8e9\ub002\u3da0\u49b1\u2c06\u5cd3\u7bc7\u7a27\ubdf0\u6c9f\ucc60\u0eae\u3064", "\ud851\udfd3\ud968\udfa0\ud940\udd4e\udad3\udd0b\udbb5\udd10\udaf8\udc80\udaf4\uddad",
        5, 64044, -393672893, 449685044973446632L, 97413L, true, true, (char) 23098, (char) 41358,
        Double.longBitsToDouble(0x3fef8d4188ba3761L), Double.longBitsToDouble(0x3fc6461b56ac088cL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 10, 1, "\udbbc\ude0d\uda75\udf83\000\000\ud9c2\udc60\udb7e\udedc", "\u00ee\u7472\u418f\u625e\u56d7\u40eb\u1086\000\000\000\u8fb3\u49b1\u2c06\u5cd3\u7bc7\u7a27\ubdf0\u6c9f\ucc60\u0eae\u0843", "\ud851\udfd3\udb56\udf97\ud940\udd4e\udad3\udd0b\udbb5\udd10\udaf8\udc80\udaf4\uddad",
        5, 21548, -393672893, 449685044973446632L, 97413L, true, true, (char) 23098, (char) 41358,
        Double.longBitsToDouble(0x3fef8d4188ba3761L), Double.longBitsToDouble(0x3fc6460016ac088cL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.apache.commons.math.distribution.DistributionFactoryImpl:@? |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 0, 3, "\000\ud93d\ude5d\udb4d\udf0d\u4b28\ud9f9\udd49\udb7e\udedc", "\u01c4\u7472\u418f\u625e\u56d7\u40eb\u62e4\u83a2\ub8e9\ub002\u3da0\u49b17\u3c1e\000\000\000\000\000\ud312\000", "\ud851\udfd3",
        18, 43979, 473430882, 8210086695433655359L, 75865L, false, false, (char) 25673, (char) 39602,
        Double.longBitsToDouble(0x3fde8063d00000e4L), Double.longBitsToDouble(0x3fd8500009b65300L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 15, "", "", "\ud8ab\udff5\uda79\uddc1\uda74\udf5c\ud9ef\udef7\udbe2\udc9d\udaea\uddb9\ud93c\udff2\ud854\uddc5\udac0\udff6\ud846\udea3\ud81a\udf6d\ud9c4\udcae\u2efe\ud87a\udc77\udbc7\udfdf\udba6\udfd1",
        35, 72773, 60, 0L, -100000L, false, false, (char) 57164, (char) 15521,
        Double.longBitsToDouble(0x3fad4c3420000000L), Double.longBitsToDouble(0x3feb1720f65a1c37L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |a0=[D:[[7.5, 28114.5, 28444.5, 27912.5, 28144.5, 9596.0, 27737.5, 28247.0]] |a1=[J:[[42267, 404, 29762, 16735, 15643, 34602, 16571, 25268]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=org.apache.commons.math.distribution.DistributionFactoryImpl:@? |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 6, 10, 5, "?\udbd5\ude69\uda41\udc11\u4b28\ud8e3\udcde", "\ua54b\u01c4\u7472\u418f\u3d4b\u875a\u40eb\u62e4\u83a2", "\udbc7\udfdf\u3da7\000\uda2f\udd5a\udbae\udf53\ue90e",
        14, 92037, 2008034950, 187158432940037376L, 70950L, true, false, (char) 57216, (char) 12945,
        Double.longBitsToDouble(0x3fafb8f8732c07b0L), Double.longBitsToDouble(0x3fb16898e8953850L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[J:[[56216, 57125, 55578, 56574, 55825, 56289, 55507, 56432]] |a1=[J:[[17458, 33296, 3546, 27759, 55023, 4191, 12340, 25028]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=java.lang.Boolean:true |a0=[D:[[28108.0, 28562.5, 27789.0, 28287.0, 27912.5, 28144.5, 27753.5, 28216.0]] |a1=[J:[[17458, 33296, 3546, 27759, 55023, 4191, 12340, 25028]] |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 8, 4, 5, "\udbc8\udf55\ud94a\udd2e\uda41\udc11\ud903\udca0\uf44b\uda8d\udcb8\ud88a\uddc2\ud9ef\udef7\udbe2\udc9d\ud873\udc72\ud93c\udff2\ud854\uddc5\udac9\udd4b\udb5d\udd07\uda5b\uddb0\ud9c4\udcae\u2efe\ud87a\udc77\udbc7\udfdf\udaff\udf9e", "\u4462\u8240\u0e0a\u6c9f\ud71f\u108f\u3064\u61f4\u6c4e\u6326\u4276\u21e7\uc4d3\u2a6a", "\udb88\udf49\ud8cb\ude9d",
        28, 19305, -261596308, 2125494808754385496L, -62416L, false, false, (char) 40313, (char) 19265,
        Double.longBitsToDouble(0x3fdef99682dbdf6eL), Double.longBitsToDouble(0x3fd5924b58855b94L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\0121=void |this=org.apache.commons.math.stat.inference.ChiSquareTestImpl:@?\012",
        Z.run(T, 2, 15, 15, 5, "\udbda\udd93\u1d2c\uda53\udc25\udbc4\ude72\ud963\udec6", "\ua54b\u1d2e\u4eb3\u8431\u4083\u1905\u40eb\u62e4\u0d8c", "\ud8ad\udf1c\ud8c4\ude36\ud80e\udeb0\uda22\udfb1\udbae\udf53\ud9d3\udffb",
        13, 92037, 2008034950, -9082333718653269910L, 70950L, true, false, (char) 57216, (char) 12945,
        Double.longBitsToDouble(0x3fafb8f8732c07b0L), Double.longBitsToDouble(0x3fb16898e8953850L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|chiSquare|[D,[J|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|chiSquare|[[J|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|checkArray|[[J|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|chiSquareDataSetsComparison|[J,[J|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|chiSquareTest|[D,[J,double|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|chiSquareTest|[[J,double|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|chiSquareTest|[D,[J|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|chiSquareTest|[[J|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|chiSquareTestDataSetsComparison|[J,[J,double|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|chiSquareTestDataSetsComparison|[J,[J|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|getDistributionFactory||new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|isNonNegative|[J|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|isNonNegative|[[J|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|isPositive|[D|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|isRectangular|[[J|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|setDistribution|org.apache.commons.math.distribution.ChiSquaredDistribution|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|chiSquare|[D,[J|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
    "M|org.apache.commons.math.stat.inference.ChiSquareTestImpl|chiSquare|[[J|new:org.apache.commons.math.stat.inference.ChiSquareTestImpl:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
