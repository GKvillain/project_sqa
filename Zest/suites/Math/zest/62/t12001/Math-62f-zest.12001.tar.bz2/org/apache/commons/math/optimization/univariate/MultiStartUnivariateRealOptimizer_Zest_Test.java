package org.apache.commons.math.optimization.univariate;
import org.junit.Test;
import static org.junit.Assert.*;
public class MultiStartUnivariateRealOptimizer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\0121=new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\012",
        Z.run(T, 2, 9, 9, 4, "\ud8e8\udeae", "\u266a\u4d42", "\udb13\udf67\ud9b8\udf69\uda3b\udea0\udbbf\udd71\ud890\udf37\ud984\udd27\udb64\uddef",
        25, 40887, -182234566, -7778212766092928939L, 5948L, false, false, (char) 47688, (char) 36253,
        Double.longBitsToDouble(0x3fe3959eb03f5277L), Double.longBitsToDouble(0x3fd164e5c15141aeL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\0121=new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\012",
        Z.run(T, 2, 9, 9, 4, "\ud8e8\udeae", "\ud00f\u4d55", "\udb13\udf67\ud9b8\udf69\uda3b\udea0\udbbf\udd71\ud890\udf37\ud984\udd27\udb64\uddef",
        25, 40887, -182234566, -7778212766092928939L, 5948L, false, false, (char) 47688, (char) 36253,
        Double.longBitsToDouble(0x3fe3959eb03f5277L), Double.longBitsToDouble(0x3fd164e5c15141aeL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 4, "\ud800\udf5b", "\u266a\u4d42", "\udb13\udf67",
        20, 40876, 1040824778, -4460130587131171093L, -100000L, true, false, (char) 4112, (char) 12759,
        Double.longBitsToDouble(0x3fb565039d818cf8L), Double.longBitsToDouble(0x3fdecf906704a4f0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 10, "\ud9c8\uddd5\uda1a\uddfb\udb73\udcd8\udb35\udd35\ud9b8\udfec\uda02\udf4d\uda46\udf7c\udb13\udf67\ud9b8\udf69\uda3b\udea0", "\ub2fe\u6abb\u3b97\ud03b\u455a\u3886\ua1e8", "\ud8df\ude97\uda06\ude0a\udbba\udc3f\udb4d\udfd6\udbcc\udc0b\ud84a\udf4e\ud89d\udcdd\ud97b\udf7a\udb8c\ude4b\u6e68\udb97\udcf0\ud9f8\ude17",
        12, 3892, 572103806, -2439242422640856324L, -9265L, true, true, (char) 12328, (char) 64407,
        Double.longBitsToDouble(0x3f4a2b0841bae400L), Double.longBitsToDouble(0x3fe6038126a07850L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 9, 4, "\ud8e8\udeae", "\u259c\u4d42", "\udb13\udf67\ud9b8\udf69\uda3b\udea0\udbbf\udd71",
        0, 2107, 9849319, 7188419395643113127L, 15533L, true, false, (char) 13647, (char) 4851,
        Double.longBitsToDouble(0x3fec1293c5dc3012L), Double.longBitsToDouble(0x3fe74a37ac52ddf6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\0121=new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\012",
        Z.run(T, 2, 9, 9, 4, "\ud8e8\udeae", "\u3564\u4d42", "\udb13\udf67\ud9b8\udf69\uda3b\udea0\udbbf\udd71\ud890\udf37\ud984\udd27\udb64\uddef",
        21, -1000, 0, 0L, 5948L, false, false, (char) 47688, (char) 36253,
        Double.longBitsToDouble(0x3fe3959eb03f5277L), Double.longBitsToDouble(0x3fd164e5c15141aeL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 4, "\ud8e8\udeae", "\uc2ae\u4d42", "\udb13\udf67\ud9b8\udf69\uda3b\udea0\udbbf\udd71\ud8fc\udc0c\ud984\udca9\udb64\uddef",
        25, 40887, -182234566, -7778212765275629483L, 5948L, false, false, (char) 55112, (char) 42897,
        Double.longBitsToDouble(0x3fe3959eb03f5277L), Double.longBitsToDouble(0x3fd164e5c15141aeL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 2, 4, "\ud8e8\udeae", "\u266a\u4d42", "\udb13\udf67\ud9b8\udf69\uda3b\udea0\udbbf\udd71\ud890\udf37\ud984\udd27\udb64\uddef",
        25, 40887, -182234566, -7778213260014167979L, 5948L, false, false, (char) 47688, (char) 39401,
        Double.longBitsToDouble(0x3fe3959eb03f5277L), Double.longBitsToDouble(0x3fd164e5c15141aeL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\0121=new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\012",
        Z.run(T, 2, 3, 9, 4, "\ud859\udfaa\ud890\udfc7\uda50\udc96\ud897\udf8b\ud9b9\udc39\uda02\udf4d\uda46\udf7c\udb13\udf67", "\u1b51\u9d80\ud106", "\udb32\udec0\ud84e\udd96",
        50, 83421, -117046352, -686770440964486352L, 76762L, false, false, (char) 36253, (char) 62024,
        Double.longBitsToDouble(0x3fafa93bd164e5c0L), Double.longBitsToDouble(0x3fda8a0d7e8618c2L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\0121=!org.apache.commons.math.exception.MathIllegalStateException\012",
        Z.run(T, 2, 3, 5, 4, "\ud8e8\udeae", "\u5cf9\uc7f8\ud15f\u36b8\u551c\u0d25\u4da2\u3de8\u2e18\u112b\uc44f\u3b97\ud03b\u455a\u3cc3\u1325\u336b\u2baa\u147c\u01f6\uca22\ud14e\ud243\u282f\u5987\u4bb2", "\udab1\udd20\ud85b\udc6c\uda48\udf52\ud849\uded7\uda86\udfbc\ud99d\udfb9\uda3a\udc8e",
        15, 92357, 497586109, 2125595176649586901L, 20140L, true, false, (char) 13156, (char) 40447,
        Double.longBitsToDouble(0x3fe3293b7f2f31b3L), Double.longBitsToDouble(0x3fd5d804c3b3b41cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\012",
        Z.run(T, 1, 9, 9, 8, "\udb6d\udf78", "\u6b59\ucfbd", "\udb68\udcd1\ud9b8\udf69\udaae\udf9d\u516e\ud890\udf1d\ud984\udd27\udb25\udfd0\ud94f\udfab\udb32\udec0",
        -2, 23715, 832526421, -7681014854456043028L, 5948L, false, false, (char) 40820, (char) 36292,
        Double.longBitsToDouble(0x3fe3959eb214d077L), Double.longBitsToDouble(0x3fd164e5c15141aeL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 3, "\ud8e8\udeae", "\000\000", "\udb13\udf67",
        20, 40876, 1040824778, -4460130587131171093L, -74053L, false, false, (char) 0, (char) 15360,
        Double.longBitsToDouble(0x3fb565039d818cf8L), Double.longBitsToDouble(0x3fdecf906704a4f0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\0121=java.lang.Integer:0 |this=org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udb38\udf3e", "\u2594\u4d42", "\uda1b\uddf5\ud9b8\udf5c\uda3b\udea0\udbbf\udd71\uda2d\udfc4\ud996\udc27\udb64\uddef\u733c\ud783\ud84e\ude48\ud9d5\ude56\uda70\udf41\udaee\udf46\ud881\udec8",
        39, 97273, -1290096006, 8148379525690301577L, -69217L, false, true, (char) 45439, (char) 6910,
        Double.longBitsToDouble(0x3fd6d3a044c1631eL), Double.longBitsToDouble(0x3feafec06616bc7cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 10, 3, "\ud8e8\udeae", "\u266a\u4d42", "\udb13\udf67\ud9b8\udf69\uda3b\udea0\ud98d\ude7d\ud909\udcf2\ud950\uddcd\ud918\udfe1",
        30, 67959, -120892870, 8383413332627656591L, -41100L, true, true, (char) 37628, (char) 35796,
        Double.longBitsToDouble(0x3fed6e58782bd48aL), Double.longBitsToDouble(0x3fe39466903f5277L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\0121=!org.apache.commons.math.exception.MathIllegalStateException\012",
        Z.run(T, 2, 3, 5, 7, "\ud8e7\udece", "\u9a50\u3bad", "\udb13\udf67",
        20, 22564, 1040824778, -4460130587131171093L, 57019L, true, false, (char) 4112, (char) 12759,
        Double.longBitsToDouble(0x3fb565039d818cf8L), Double.longBitsToDouble(0x3fdecf906704a4f0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 8, 2, "\udb8f\udfc6\udbb0\udd81\ud8a1\udcc7", "\ud15f\uc28f\u551c\u0d25\u9322\u1b51\u9d80\ub2fe\u1a99\u3b97\ud03b\u455a", "\udaee\udf46",
        44, 90246, -738026020, 1370789684008206113L, -50450L, true, false, (char) 7026, (char) 45439,
        Double.longBitsToDouble(0x3fe5878825369198L), Double.longBitsToDouble(0x3fd4d124c97bc496L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 9, 3, "\ud8e8\udeae", "\u3924\u4d29\u4d06\u36b8\u3020\ua8af\u9322\u1b70\u9d80\u39cf", "\udb32\udec0\ud84e\udd96",
        50, 83421, -105708624, 5942528210952506242L, 76762L, false, false, (char) 36253, (char) 62024,
        Double.longBitsToDouble(0x3fd9f5677a2c9c4eL), Double.longBitsToDouble(0x3fc5141affbe6748L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\012",
        Z.run(T, 1, 9, 5, 4, "\ud8e8\udeae", "\uc9d1\u4de0", "\udb13\udf67\ud9b8\udf69\ud938\udfff",
        59, 88805, -1631779842, 20628931459835227L, -57562L, false, true, (char) 57634, (char) 13647,
        Double.longBitsToDouble(0x3fdecf906704a4f0L), Double.longBitsToDouble(0x3fddc30125c68deaL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 9, 4, "\ud8e8\udeae", "\u266a\u4d42", "\udb13\udf67\ud9b8\udf69\uda3b\udea0\udbbf\udd71",
        0, 2107, 9849262, 7188419395643113127L, 15533L, true, false, (char) 13647, (char) 4851,
        Double.longBitsToDouble(0x3fe42293c521ffadL), Double.longBitsToDouble(0x3fe3d237ac52ddf6L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 0, 0, "\ud963\udeac", "\u2d9d\u4d42", "\udb13\udf67\ud9b8\udf69\uda3b\udea0\udbbf\udd71",
        0, 2107, 1721125351, 7188419941103959719L, -24702L, true, true, (char) 13647, (char) 27634,
        Double.longBitsToDouble(0x3fec1293c5dc3012L), Double.longBitsToDouble(0x3fe74a37ac52ddf6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 3, "\ud994\udf8b", "\u75eb\u2c6e\u2d1d\u210d\ub79b\u0d25\u9f55\ud096", "\udb75\ude1c\udaff\udced",
        40, 92736, -1811164512, 3575673752858744240L, 83170L, false, true, (char) 27529, (char) 21577,
        Double.longBitsToDouble(0x3fe61139b1944c21L), Double.longBitsToDouble(0x3fcca9b2f6710b54L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer|optimize|org.apache.commons.math.analysis.UnivariateRealFunction,org.apache.commons.math.optimization.GoalType,double,double|new:org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer|optimize|org.apache.commons.math.analysis.UnivariateRealFunction,org.apache.commons.math.optimization.GoalType,double,double,double|new:org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer|getConvergenceChecker||new:org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer|getEvaluations||new:org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer|getMaxEvaluations||new:org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer|getOptima||new:org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer|setConvergenceChecker|org.apache.commons.math.optimization.ConvergenceChecker|new:org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer|setMaxEvaluations|int|new:org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer|sortPairs|org.apache.commons.math.optimization.GoalType|new:org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "C|org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer|<init>|org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer|optimize|org.apache.commons.math.analysis.UnivariateRealFunction,org.apache.commons.math.optimization.GoalType,double,double|new:org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
    "M|org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer|optimize|org.apache.commons.math.analysis.UnivariateRealFunction,org.apache.commons.math.optimization.GoalType,double,double,double|new:org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer:org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer,int,org.apache.commons.math.random.RandomGenerator",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
