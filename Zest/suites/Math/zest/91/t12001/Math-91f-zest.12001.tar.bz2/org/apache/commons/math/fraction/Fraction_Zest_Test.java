package org.apache.commons.math.fraction;
import org.junit.Test;
import static org.junit.Assert.*;
public class Fraction_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 10, 14, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\ud8b1\udf4c", "\u0b57\u4d94\ucfa8\ucc5f\u9c6d\u7431\uc410\u26b6\uc0f1\uaa74", "\udb10\uddae\ud8a7\udfe2\ud90e\udfa2\udae0\udd95\udaca\uded5",
        16, 45221, -55370440, -6249208789316281341L, 1848L, false, true, (char) 49372, (char) 38323,
        Double.longBitsToDouble(0x3fd2a29dd46af614L), Double.longBitsToDouble(0x3fd540c382c8562eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 10, 1, 3, "\ud84f\udd35\ud803\uddd5\udb41\udcf4\u3c5d\ud8b1\udf4c", "\u0f03\u4d94\ucfa8\ucc5f\u9c6d\u7431\uc410\u26b6\u2af2\uaa74", "\udb10\uddae\ud8a7\udfe2\ud877\udf9b\udae0\udd95\udaca\uded5",
        16, 45221, -55370440, -6249208789316281341L, 60400L, false, true, (char) 49372, (char) 38323,
        Double.longBitsToDouble(0x3fd2a29dd46af614L), Double.longBitsToDouble(0x3fd540c382c8562eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 14, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\udaca\udd76", "\u67c7\u4d94\u5094\ucc5f\u9c6d\u7431\uc410\u0e8f", "\uda50\ude75\ud92c\udfb2\udb10\uddae\ud8a7\udfe2\ud90e\udfa2\udae0\udd95\udac1\udf2b",
        16, 45221, -2127815368, -6249208948228874236L, 1848L, true, true, (char) 49372, (char) 38323,
        Double.longBitsToDouble(0x3fd2a29dd46af614L), Double.longBitsToDouble(0x3fd540c382c8562eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 10, 14, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\ud8b1\udf4c\ud847\udc96\udade\udf54\udac7\udd34\ud80b\udfee\ud89c\udf3c\udbfb\udd6d\ud9c2\udf2c\udb71\udcca\ud84f\ude75\uda7c\udf3d\uf6cd\udb1d\udfbd\uda5d\udd75\ud92c\udfb2", "\u7441\u4678\u3ac9\u2bc9\u4e47\u2d4f\u62ed\u03b4\uc7bd", "\u6b4f\udb4c\uddad\ud8f7\udcaa\ud87f\udedc\ud9d7\uddaa\ud9c4\udeea\ud96e\ude63\udb83\udc3b\uda89\udd57\udaf1\ude1f\uda41\udcfe\u81f6\udb34\udff1\ud857\udcad",
        51, 27984, 127992100, -8948056894431605854L, -95303L, true, true, (char) 62819, (char) 16362,
        Double.longBitsToDouble(0x3fe62e44fc8ff113L), Double.longBitsToDouble(0x3fd1b2fcf0c488c0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 10, 14, 0, "\ud9b1\udf03\ud9fd\udc03\udb0e\uddc0\udb92\ude97\udbda\udfa0\ud80c\udfec\u2514\ucb45\ud970\udc40\ud9e2\udf24\ud8f4\udde0\udbaf\udc4b\ud9a4\udff3\ud9d5\uddeb\ud94a\udd62", "\u0bcb\u1d53\ub2c4\u56bc\u7eb1\u4618\u2d09\ubec9\u4b9c\u894e\u62ed\u05df\uc797\u78be\u51a6\u3d93\u965c\u7efe\ud1ee\u7908\u5281\u0d33", "\uda19\udcf0\udbd5\udd0d\udb2b\udf6f\ud966\ude69\udb09\udd9d\ud8d1\udc83\udaac\udcdc\ud9f0\udc5c\u4f66\udbab\udcff\ud97f\udc85\ud961\udcdf\uda72\udd02\udab6\udc9f\ud897\udf33\ud850\udc39\ud9d8\udc3e\uda3c\udd16\ud9b6\udde8\ud810\udd12",
        36, 31352, 1058506190, 2137666869890350812L, -86693L, false, false, (char) 21915, (char) 3662,
        Double.longBitsToDouble(0x3fe4586fb4cb8dc3L), Double.longBitsToDouble(0x3fdb1565adc433baL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 10, 0, 0, "", "", "",
        -5, 57742, -1948662178, 20671677595648L, -100000L, false, false, (char) 0, (char) 96,
        Double.longBitsToDouble(0x3fc6c00014a83cc0L), Double.longBitsToDouble(0x3fe26777800000c2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 10, 15, 3, "\ud9ca\ude5d\ud8c8\uddb8\udb32\udcd9\u3c5d\ud8b1\udf4c", "\u0b57\u4d94\u248f\u291e\u9c6d\u7431\ubb3d\u262e\u4bea\uaa74\u0bab", "\ud8a7\udfe2\ud918\udca7\udab8\udfc1\udaca\uded5\ud952\udf62\udae8\udca1\ud8a5\udd06\uda5d\udc9a\udbf1\udfdf\ud9db\udc3b\udb58\udda4\uda7d\ude75\uda9e\udc89\uda5d\udf35\ud8f7\udc6a",
        6, 4796, 112646500, -8624636240618115505L, 74218L, true, false, (char) 17111, (char) 3829,
        Double.longBitsToDouble(0x3fe36f76730893ffL), Double.longBitsToDouble(0x3fa6c94029ba3760L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 14, 3, "\ud84f\udde2\ud8c8\uddb8\udb32\udcd9\u3c5d", "\uacb4\u11dd\u2233\ucfa8", "\udb7c\ude2d\ud9d5\uddeb\ud9df\udf03",
        26, 3745, 1165013342, -2080859404380757798L, -84989L, true, false, (char) 10632, (char) 32741,
        Double.longBitsToDouble(0x3fccb2c954e3ee28L), Double.longBitsToDouble(0x3fdb7fcb3807528cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 10, 14, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\udb88\udf02", "\uacb4\u0b57\u4d94\ucfa8", "\ud9a5\udc80\ud9d5\uddeb\ud851\udd9b",
        48, 3796, 1165013342, -2080859404380757798L, -84989L, true, false, (char) 10632, (char) 32741,
        Double.longBitsToDouble(0x3fe922fa55a237b4L), Double.longBitsToDouble(0x3fede916f24b5461L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Double:0.2224025974025974 |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 5, 12, 3, "\udae2\udeff\u3320\ud815\udf3a\u2d7e\ud867\udc87", "\ua357\u4cf7\ucfa8\ucc5f\u9c6d\u7431\ub753\uaf35\u1641\uaa74\u0bab\u1b2c\u08ad\u5679\u7eb1\u67c5\u2d09\ubec9", "\uc180\ud947\udd70\udac4\ude7f\udb58\udda4\uda7d\ude75\uda9e\udc89\uda5d\udf35\ud8f7\udc6a\ud934\udeed\ud839\udfde\udbe0\ude79\ud934\udf24\ud9b0\udc12\ua49c\uda07\udd2e\ud891\udc97\ud907\udeca\udb3d\udc53\udb2d\uddc1\uda02\udcdb\udaff\udc50",
        6, 72178, 220236890, -6440711847799968298L, 22058L, false, true, (char) 40512, (char) 26771,
        Double.longBitsToDouble(0x3fcc77af227c23b4L), Double.longBitsToDouble(0x3fe755a9edd189f1L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.fraction.Fraction:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 14, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\ud8b1\udf4c", "\u2cce\u2736\ubea4\ucc5f\uc983", "\ud851\udd9b\uda6d\udc28\uda27\udfc1\uda5d\udd75",
        -4, 25066, 1528210052, -2611460361863667344L, -21171L, true, true, (char) 6339, (char) 22123,
        Double.longBitsToDouble(0x3f6d4a34a7418d00L), Double.longBitsToDouble(0x3fe147dedbbc7f0eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 10, 14, 3, "\ud9eb\ude49\uda07\udca9\udb32\udcd9\u3c5d\ud8b1\udf4c", "\u0b57\u4d94\ucfa8\ucc5f\u9c6d\ud431\uc410\u26b6\uc0f1\u508a\u1bdb\u1b67", "\udbd1\udd4f\ud947\udf57\udaca\uded5\ud8bd\uddd8",
        15, 9984, 489183520, 4723709017524493479L, 19876L, false, false, (char) 54587, (char) 52693,
        Double.longBitsToDouble(0x3fe1abd857540c38L), Double.longBitsToDouble(0x3fd1159dda053344L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 12, 14, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\udb77\udf0f", "\u0b57\u4d94\ucfa8\ucc5f\u7c76", "\ud851\udd9b\uda6d\udc28\udb1d\udfbd\uda5d\udd75",
        46, 25063, -1978228092, 1219414049577887875L, -21171L, true, false, (char) 43342, (char) 22123,
        Double.longBitsToDouble(0x3f6d4a37c5b48d00L), Double.longBitsToDouble(0x3fe147dedbbc7f0eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 15, 14, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\ud8b1\udf4c", "\u0b57\u4d94\ucfa8\ucc5f\u9c6d\u6aa5\u1202\u12ff\uc0f1\uaa74", "\udacf\ude24\udac2\udf52\ud901\udc89\udae0\udd95\udaca\uded5",
        16, 45221, -55370440, -6249208789316281341L, 60481L, true, true, (char) 49372, (char) 38323,
        Double.longBitsToDouble(0x3fd2a29dd46af614L), Double.longBitsToDouble(0x3fd540c382c8562eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 10, 14, 3, "\ud9e0\udede\udac9\udfd3\udb32\udcd9\uda93\uddff\udb67\udc3b\ud9fa\udec7\u6c54\ucb45\udbef\uddff\udb11\udc2d\ud903\udc73\ud9e0\udf75\ud9a5\udc80\ud9d5\uddeb\ud851\udd9b\uda61\uddb6", "\u1fbe\u4ea4\u31db", "\udaca\uded5\ud8bd\uddd8\udb87\udf9d",
        0, 20727, 1099815939, -298543078903722694L, -68656L, false, false, (char) 63238, (char) 32860,
        Double.longBitsToDouble(0x3fd540c382c8562eL), Double.longBitsToDouble(0x3fb3df5e26fd3f70L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 13, 14, 3, "\ud84f\udd35\ud88e\udfb3\udb32\udcd9\u3c5d\ud8b1\udf4c", "\ua551\u053f\ucfa8\ucc5f\u9c6d\u7431\uc410\u26b6\u97a0\u0e41", "\ud90f\udd64",
        -2, 4963, 305522819, 121102767066093746L, -99471L, false, true, (char) 12194, (char) 40498,
        Double.longBitsToDouble(0x3fe147dedbbc7f0eL), Double.longBitsToDouble(0x3fe2f533f4be5cf5L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 14, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\ud939\udda9", "\u5228\u335a\u2430\ucc5f\u9c6d\u7431\uc410\u26b6\uc0f1\uaa74", "\udb10\uddae\ud8a7\udfe2\ud90e\udfa2\udae0\udd95\udaca\uded5",
        16, 55901, 1272924530, -6249081309064340477L, 1848L, false, false, (char) 49372, (char) 38323,
        Double.longBitsToDouble(0x3fd2a29dd46af614L), Double.longBitsToDouble(0x3fd540c382c8562eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.fraction.Fraction:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 14, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\udb21\udeec", "\u363c\u0a18\u45b6\u7f3f", "\ud9d5\uddeb\udb75\udd6d\u7ab8\udb1d\udfbd\uda5d\udd75\ud832\udcf4\udafe\udca9\ud8a7\udfe2\ud8c4\udf1e\ud827\ude98\udaca\udf17",
        16, 45221, -55370440, -6249208789316281341L, 1848L, false, true, (char) 51827, (char) 38323,
        Double.longBitsToDouble(0x3fd2a29de46af614L), Double.longBitsToDouble(0x3fd540c38358562eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 14, 3, "\ud84f\udd35\ud8c8\uddb8", "\u6b4b\u9cc1\uacb4\u0b57\u77a8", "\uda2a\udde0\udb63\ude29\ud846\udc76\ud853\udd9f",
        58, 80155, 746500446, -2080684582031941414L, 70130L, true, false, (char) 10632, (char) 32741,
        Double.longBitsToDouble(0x3fccb2c954e3ee28L), Double.longBitsToDouble(0x3fdb7fcb3f55528cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 1, 4, 3, "\ud84f\udd35\ud843\udf15\udb32\udc3c\u3c5d\uda71\udd03", "\u1f89\ubc04\u8e44\ucc5f\u9c6d\u7431", "\udaf1\udecb\ud81d\ude10",
        7, 8166, -2040880934, 6563612195042376355L, 46379L, true, false, (char) 37724, (char) 4557,
        Double.longBitsToDouble(0x3fdb7fcb3807528cL), Double.longBitsToDouble(0x3fc4e831a8a3ef6cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 10, 14, 3, "\udbbe\udc41\ud8c8\uddb8\udb32\udcd9\u3c5d\ud8b1\udf4c", "\u0b57\u6839\u3264\uc5c9\u9c6d\ua798\uc410\u26b6\uc0f1\u3eea", "\udb10\uddae\ud8a7\udfe2\ud90e\udfa2\udae0\udd95\udaca\uded5",
        27, -253, -55370440, -6249208789853152253L, 1848L, false, true, (char) 49372, (char) 8728,
        Double.longBitsToDouble(0x3fd2a299846af614L), Double.longBitsToDouble(0x3fd540c382c8562eL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 14, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\ud8b1\udf4c\uda81\uddbe\udabf\udf85\ucb45\ud80b\udfee\ud89c\udf3c\udbfb\udd6d", "\uc410\u26b6\uc0f1\uaa74\u0bab\u1b2c\u08ad\u5679\u7eb1\u4618\u2d09\ubec9\u4b9c\u894e\u62ed\ud1b4", "\uda7d\ude75\uda9e\udc89\uda5d\udf35\ud8f7\udc6a\ud934\udeed\ud839\udfde\ud9e5\udf5b\uda3d\udfba\udb2f\ude66\udbfa\ude6e\udb4b\udc2a\ud811\udf93\ud966\udd7a\udacd\udd42\ud93d\udd4b\udae7\ude29\u10ff\ud8ea\ude9d\uda6c\udf18\u7b17\ud98d\udedc\ud925\udee1\uda10\udd9e\udb7f\udd6c\udbbc\udc16\udaca\udd64\ud83c\udc1d\ud8ad\uddf0\ud92b\ude3c\ud82f\ude12\udab4\udee7\ud9ce\udcaf",
        27, 28888, -1876905699, 5266308289354846594L, -73224L, false, true, (char) 12272, (char) 20392,
        Double.longBitsToDouble(0x3fe855abdf2dc47dL), Double.longBitsToDouble(0x3fe51c7dcc837a13L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 5, 7, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\ud8b1\udf4c", "\u0b57\u4d94\u4cda\ucc5f\u9c6d\u7431\uc410\u26b6\uc0f1\uaa74", "\ud9aa\ude40\ud882\udcd0\ud90e\udfa2\udae0\udd95\ud95f\udedf",
        16, 45221, -55370440, -6249208789316281341L, 1848L, false, true, (char) 26948, (char) 38323,
        Double.longBitsToDouble(0x3fd2a29dd46af614L), Double.longBitsToDouble(0x3fd540c382c8562eL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\0121=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 1, 10, 7, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\udb04\udef6\uda81\uddd6\udabf\udf85", "\ucf53", "\ud9a5\udc80\ud9d5\uddeb\ud851\udd9b",
        53, 3796, -1475622006, -2080859404380757798L, 17688L, true, true, (char) 14725, (char) 39915,
        Double.longBitsToDouble(0x3fccb2c954e3ee28L), Double.longBitsToDouble(0x3fdb7492381a088cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 14, 3, "\ud84f\udd35\ud864\udd25\ud882\udf07\u87af\ud8b1\udec4", "\u0b57\u4d94\ucfa8\ucc5f\u9c6d\u7431\uc410\u26b6\ud65b\u069f", "\ud8c1\ude6c",
        58, 23139, 305522819, -5489299352335000970L, 40285L, true, false, (char) 28164, (char) 63380,
        Double.longBitsToDouble(0x3feaf0e70cbee0c4L), Double.longBitsToDouble(0x3fd2a29dd46af744L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 14, 12, 3, "\ud811\udefb\ud8c8\uddb8\udb32\udcd9\u3c5d", "\u2c60\u796b\u779a\ua940\uc9d8", "\ud9d5\udea2",
        0, 75418, -1866277808, 5003694205040549045L, 7140L, true, false, (char) 63854, (char) 46728,
        Double.longBitsToDouble(0x3f93b3d204efa940L), Double.longBitsToDouble(0x3fd000f8a8604c2cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Float:0.29117647 |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 7, 10, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\ud8b1\udf4c", "\u0b57\u4d94\ucfa8\u9fed\u91f4\u7431\uc410\u26b6\uc0f1\uaa74", "\udb10\uddae\ud8a7\udfe2\ud90e\udfa2\udae0\udd95\udaca\uded5",
        16, 45221, -55370440, -6249208789316281341L, 1848L, false, true, (char) 49372, (char) 38323,
        Double.longBitsToDouble(0x3fd2a29dd46af614L), Double.longBitsToDouble(0x3fd540c382c8562eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 3, "\ud84f\udd35\ud8c8\uddb8\ud966\udca0\ud8c7\uddb9\udaca\udd76", "\u0fc7\u4d94\u5094\ucc5f\u9c6d\u7431\uc410\u0e8f", "\uda50\ude75\ud92c\udfb2\udb10\uddae\ud8a7\udfe2\ud90e\udfa2\udae0\udd95\uda05\udf0d",
        16, 45221, -2127815368, -6249208950047956988L, -79560L, true, true, (char) 49372, (char) 38323,
        Double.longBitsToDouble(0x3fd2a29dd46af614L), Double.longBitsToDouble(0x3fd540c382c8562eL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\0121=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 10, 10, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\udaca\udd76", "\u67c7\u4d94\u5094\ucc5f\u9c6d\u7431\uc410\u0e8f", "\ud984\udf4a\ud92c\udf97\udaa2\udeeb",
        52, 4963, 305522819, -5527548759115117549L, 80965L, true, false, (char) 60270, (char) 40519,
        Double.longBitsToDouble(0x3fe147dedb95911aL), Double.longBitsToDouble(0x3fe2f533f4bee0f5L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\0121=java.lang.Integer:133 |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 1, 9, 3, "\ud84f\udd35\udbba\udded\ue06e\ud8de\udc8a\udaca\udd76\uda8c\udfc6", "\u4d94\u5094\ucc5f\u9c6d\ub772\uc47f\u4de1\ud7c8\u3d55\ub0aa\u1b2c\u1a45\u5679\u7eb1\u4618\u20c6\u2fc5\u4b6e\ub6e6\u62c8\u85cb\uc7bd\uc621\u32bc\u3e0c\u965c\u7efe\u50b0\u56e3\ud7af\u5977\ub4e9", "\udaed\udc1b\ud99a\udf3e\ud907\udf91\uf978\udb33\udcb4\udb36\udf9f",
        34, 29902, -1739413427, -6546169135429344744L, 1056L, false, true, (char) 55261, (char) 8568,
        Double.longBitsToDouble(0x3fe04e73b3d59f8bL), Double.longBitsToDouble(0x3fc3fec653ac07e4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 14, 3, "\000\ud88f\udc67\udb32\udcd9\u3c5d\udb84\udd73", "\u67c7\u4d94\u5094\ucc5f\000\000\u5ee2\u0e8f", "\uda31\udc17\ud92c\udfb2\udb10\uddae\ud92c\ude85\ud90e\udeff\udae0\udd95\udac1\udf2b",
        14, 45221, -2127815368, -6249208948228874236L, 1848L, true, true, (char) 126, (char) 38078,
        Double.longBitsToDouble(0x3e31abd850000000L), Double.longBitsToDouble(0x3eac1642b0000000L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\0121=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 15, 15, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\udaca\udd76", "\u67c7\u6f0f\ud40c\ucc5f\u9c6d\u7431\uc410\ucec7", "\uda50\ude75\ud92c\udfb2\udb10\uddae\ud8a7\udfe2\ud90e\udfa2\udae0\udd95\udac1\udf2b",
        16, 45221, -2127815368, -6249208948228874236L, 67384L, true, true, (char) 49372, (char) 38323,
        Double.longBitsToDouble(0x3fd2a29dd46af614L), Double.longBitsToDouble(0x3fd540c382c8562eL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 3, 7, "\udbc1\ude8c\ud866\ude86\ud8e4\udeb1\udb74\udf6f\udaf3\udc55", "\u67c7\u4d94\u5094\ucc5f\u9c6d\u7186\uc410\u0e8f", "\uda50\ude75\ud92c\udfb2\udb10\uddae\ud8a7\udfe2\udaa7\uddee\uda5b\udef2\udb07\uddd7",
        34, 99477, -1854310989, -6249208948228874236L, 1848L, true, true, (char) 54479, (char) 55111,
        Double.longBitsToDouble(0x3fbbe2e0d1abd850L), Double.longBitsToDouble(0x3fd540c382c8562eL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Float:0.16333333 |this=org.apache.commons.math.fraction.Fraction:@?\0121=java.lang.Float:0.16333333 |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 7, 7, 14, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\udaca\udd76", "\uc64c\u4d94\u5094\ucc5f\u9c6d\ub1d1\u7cfb\u0e8f", "\uda0c\udfb3\uda90\udc64",
        46, 30124, 51594271, 807807355642393546L, -16261L, false, true, (char) 55998, (char) 51530,
        Double.longBitsToDouble(0x3fc4e83416f66c8cL), Double.longBitsToDouble(0x3fecac8f0c0fa165L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.fraction.Fraction:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 14, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\udbc7\udf45\ud9dd\udd36", "\u5cfd\u02ff\u5094\u2499\u3f1a\u7431\uc410\ua987", "\uda50\ude75\ud92c\udfb2\udb10\uddae\ud8a7\udfe2\ud90e\udfa2\udb31\udcde\udac1\udf74\ud8bd\uddd8\udacc\udda1",
        57, 98658, -2085675004, -298543079821250008L, 89858L, false, false, (char) 63238, (char) 34111,
        Double.longBitsToDouble(0x3fd540c382c8562eL), Double.longBitsToDouble(0x3fefb96028171198L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:269 |this=org.apache.commons.math.fraction.Fraction:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 14, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\udaca\udd76", "\u8b3b\u4ccc\u5094\ucc5f\u9c6d\u7431\uc410\u0e8f", "\uda50\ude75\ud92c\udfb2\uda16\udf91\ud8a7\udfe2\udafb\udf58\udae0\udd3c\udac1\udf2b",
        16, 45221, 1680612664, 4820920818846408708L, 1848L, true, true, (char) 49372, (char) 38323,
        Double.longBitsToDouble(0x3fe9514eece671d1L), Double.longBitsToDouble(0x3fd540c382c8562eL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 4, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\ud989\udeb5", "\u8bb8\u4d94", "\uda2a\udde0\uda39\ude6c\ud805\udd3e",
        50, 53602, -1190756051, -6964255811288360803L, -10532L, true, false, (char) 63854, (char) 17894,
        Double.longBitsToDouble(0x3f93b34a1cb2c940L), Double.longBitsToDouble(0x3fd38fb8a370d458L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\0121=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 10, 10, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\udaca\udd76", "\u67c7\u4d94\u5094\ucc5f\u9c6d\u7431\u0e11\u40d0", "\uda50\ude75\ud92c\udfb2\ud92a\udd22\ud8a7\udee2\ud90e\udfa2\udae0\udd95\udac1\udf2b",
        16, 45221, -1456726728, 8747256010368391097L, -67651L, true, true, (char) 49372, (char) 38323,
        Double.longBitsToDouble(0x3fd2a29dd46af614L), Double.longBitsToDouble(0x3fd540c382c8562eL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 14, 3, "\ud84f\udd35\ud8c8\uddb8", "\ua308\ucd75\uace9\u67c7\u4d94", "\uda2a\udde0\ud9a5\udc80\ud9d5\uddeb",
        27, 1130, -1866301139, 5003638127716158822L, -10532L, true, true, (char) 38203, (char) 24048,
        Double.longBitsToDouble(0x3f93b34a1cb2c940L), Double.longBitsToDouble(0x3fd38fb8a3250258L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 14, 3, "\ud8e7\udd22\ud89d\udf96\udaf5\udd99\udbf2\udd43\udaca\udd76", "\u3a70", "\ud98d\udcbf",
        37, 89450, 210724142, 6993831519279017697L, 20674L, false, true, (char) 33785, (char) 10462,
        Double.longBitsToDouble(0x3fd8d8016f6a0f58L), Double.longBitsToDouble(0x3fed88971c13b34aL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 15, 14, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\ud8b1\udf4c\ud847\udc96\udade\udf54\udac7\udd34\ud80b\udfee\ud89c\udf3c", "\u58fd\u2444\u4a66", "\udac7\udd20\ud92c\udfb2\udb10\uddae\ud9d7\uddfa\udba2\udc0c\uda63\udf4c\udace\udc95",
        59, 44726, -1236428488, -6249209369136919037L, 1848L, false, true, (char) 40707, (char) 51078,
        Double.longBitsToDouble(0x3fd6ad32eb04f614L), Double.longBitsToDouble(0x3fe0347997f83dcfL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\0121=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 10, 10, 1, "\udb58\udccf\ud820\udf97\udbca\udf3b\udb05\udeb5\udbce\udcc3\udab0\uddff\udabf\udf63\ud86b\udf34\udaa7\udf31\uda07\udcb5\ud989\ude3e\ud9be\udeca\udac3\udd99\u1f8a\ud851\udd9b", "\u61b3\u7637\ud048\ud712", "\ud8f3\udcf4\udbc2\udf69\ud9e5\udc56\uda7b\udfcb\ud9db\udd9c\ud95b\udd6b\ud8ca\udfd8\udb76\udd2b\udb11\udcce\ud9cf\udf7c",
        58, 1004, -1572399909, 6303955864354305693L, 57627L, false, true, (char) 12242, (char) 27942,
        Double.longBitsToDouble(0x3fe52f78fe55c0a6L), Double.longBitsToDouble(0x3f977bd76a189ea0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\0121=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 10, 10, 0, "", "", "\ud93e\ude67\uda81\uddbe\udabf\udf85\u12cd\000",
        26, -1000, 0, 27021597764222976L, -51574L, false, false, (char) 62401, (char) 28355,
        Double.longBitsToDouble(0x3fd50bd2d7ebc29cL), Double.longBitsToDouble(0x3fe021c3ac4163aeL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 10, 0, 7, "\udb33\ude19\u00af\ud821\udc87\ud96d\udfe1", "\u1556", "\ud9dd\uddfd",
        16, 54560, -552585971, 160404398412982L, -29932L, false, false, (char) 9672, (char) 36971,
        Double.longBitsToDouble(0x3fd7925ddd0ddd4eL), Double.longBitsToDouble(0x3fe08b608d742154L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.math.fraction.Fraction:@?\0121=java.lang.Long:0 |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 13, 13, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\udb70\udc2d\ud81b\udf60", "\u994e\u9db7\u947f\u5048", "\udadf\udf99\ud851\udd9b\ud9cc\udd3b\uda27\udfc1\udb60\udcdc\ub61b",
        3, 33114, -608028568, 1304462175311501139L, -10085L, false, true, (char) 21952, (char) 34121,
        Double.longBitsToDouble(0x3fc4e831a8a17f90L), Double.longBitsToDouble(0x3fede3fb93bc5fd5L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.fraction.Fraction:@?\0121=java.lang.Boolean:false |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 6, 6, 13, "\ud9cd\uddf5\uda89\uddc5\udb32\udc7b\u3c7c\ud868\udeb2\uda81\uddbe\ud975\udf52\uc6e3\ud969\ude9f\ud93e\udfff\udbfb\uddac\uda2a\udde0\udb28\udfa6\u74ed\ud920\ude11\uda6d\udc48\udb16\udeab", "\uc566", "\udadc\udd19\ud98a\udc14\ud8bd\udeac\udae8\udca1",
        0, 98695, 1099815939, 3528272192201454305L, 22786L, false, false, (char) 63238, (char) 34111,
        Double.longBitsToDouble(0x3fd540c38324562eL), Double.longBitsToDouble(0x3fca96f44cbc93f8L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 15, 14, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\ud8b1\udf4c", "\u204b\u4d94\u2e2d\ub9d0\u9c6d\u6aa5\u1202\u12ff\uc0f1\ub942", "\udacf\ude24\udac2\udf52\ud901\udc89\udae0\udd95\udaca\uded5",
        16, 45221, -55370440, 1099759616L, -100000L, false, false, (char) 6750, (char) 38323,
        Double.longBitsToDouble(0x3fd0000dd46af614L), Double.longBitsToDouble(0x3f0870590ac5c000L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 15, 14, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\ud8b1\udf4c", "\u0b57\u4d94\ucfa8\ucc5f\u9c6d\u6aa5\u8887\u24fe\u74f1\u7ac6", "\udb4b\udf70\udac2\udf52\ud901\udc89\udb62\udc10\u6c41",
        44, 7668, -55370440, -6249208789316281341L, 13571L, false, true, (char) 56335, (char) 21172,
        Double.longBitsToDouble(0x3fd262bc146af614L), Double.longBitsToDouble(0x3fd540c382c8562eL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 15, 14, 0, "", "\u1b81", "\000\000\000\ud89b\udc0d",
        50, 59046, -1157627904, -8765409149289523714L, -51574L, false, false, (char) 45405, (char) 112,
        Double.longBitsToDouble(0x3e37300000000000L), Double.longBitsToDouble(0x3fc2e0e6820c005cL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\0121=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 10, 10, 4, "\ud8c5\uddd5\ud8c8\uddb8\udb6f\udd79\ud9b1\udeaf\ud926\udf41\udb65\uddb9\udabf\udf71\ucb45\ud938\udedd\ud89c\udf3c\udad2\udc7d\udb1f\udf46\ud873\udd5a\uf488\ud98b\udea7\ud9a4\udca3\udb05\udf7c\ud8ec\udffd\ud954\udeb2\udb10\uddae\udb13\ude2d\uda40\ude1f\ud82d\ude84\ud817\udcbc\ud8bd\uddd8\udae8\udca1\ud87e\udd52\uda3b\udffc", "\u6f1b\u20bd\u66bf\u3c58\ua70a", "\ud9e6\udf6f\uda01\udfcb\ud9f3\udda8",
        -3, 54581, -245985582, 9007835048659300723L, -38407L, false, false, (char) 54467, (char) 60327,
        Double.longBitsToDouble(0x3fc9a2a501ee9adcL), Double.longBitsToDouble(0x3fbe95bb3061e7d8L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\0121=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 1, 1, 11, "\ud84f\udd35\udb6d\udf6b\udb32\udc10\u3c5d\ud975\udf4e", "\u0b57\ub5e0\ud6c0\u675e\u016d\uc4cf\uc410\u26b6\uc0f1\uaa74", "\ud8ad\udd75\ud9a4\udf18\ud90e\udfa2\udae0\udd95\udb5c\uddbe",
        -4, 99549, -1798031896, -6249209403496604669L, 1848L, true, true, (char) 11655, (char) 32725,
        Double.longBitsToDouble(0x3fe02fa1ff869d6cL), Double.longBitsToDouble(0x3fea34873964e042L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\0121=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 15, 15, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\udaca\udd76", "\u67c7\u6f0f\ud40c\ucc5f\u9c6d\u7431\u652e\000", "\uda50\ude75\ud92c\udfb2\udb10\uddae\ud8a7\udfe2\ud90e\udfa2\udae0\udd95\udac1\udf2b",
        16, 45221, -2127815368, -6249208948228874236L, 67384L, true, true, (char) 49372, (char) 57589,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd540c002c8562eL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.math.fraction.Fraction:@?\0121=java.lang.Boolean:false |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 6, 6, 10, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\ud852\udfca\udab2\udde3", "\u5cfd\u02ff\u5094\u2499\u3f1a\u7431\uc410\ua987", "\uda50\ude75\ud92c\udfb2\udb10\uddae\udb64\udf37\ud90e\udf54\udb31\udcde\udac1\udf74\ud8bd\uddd8\udba2\udcc4",
        16, 51507, -2085675004, 494090454597765842L, 89858L, false, false, (char) 63238, (char) 34111,
        Double.longBitsToDouble(0x3fd540c382c8562eL), Double.longBitsToDouble(0x3fefb96028171198L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\0121=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 10, 10, 3, "\ud84f\uddc8\ud8c8\uddb8\udb32\udcd9\u3c5d\ud989\udeb5", "\u9da4\u5303\u5094\ucc5f\u9aa8\uba57\ube52\u8840\ud70f\u97b9\uc7bf\uae6a\u0cb5\u565c\u7304\ud7b3\u20c6\ubec9\u6fc2\ua418\u68d0\uc526\u64f6\u8359\u4acc\u7e87\u733c\u5a7e\u1d69\u6095\u36c5\u336d\u99bc\ucc67\u02b3\u84c1\ucb51\u4c06", "\ud915\udca8",
        59, 11368, 1948139181, -249000287288288428L, 39789L, false, true, (char) 41431, (char) 30279,
        Double.longBitsToDouble(0x3fd90aff5f2a29f4L), Double.longBitsToDouble(0x3fe9f0068641f811L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@? |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 15, 14, 0, "\udabb\udd14", "\u4343\u6b4b\000\u65ec\u7903\u4897\ud0ee\u1f67\u6e38\u6aa5\u1202\u12ff\uc0f1\u68f4\u094c\u7884\u1a97\u3b70\u3390\u947f\u90d6\u703c\u903a", "\udb59\udda1",
        39, 73701, -216950969, -6055820528896201503L, 23712L, false, false, (char) 55591, (char) 3146,
        Double.longBitsToDouble(0x3fc0ffe895369af0L), Double.longBitsToDouble(0x3fd0004078218d96L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 10, 14, 3, "\u93a2\ud8c8\uddb8", "\u6b4b\ud7c0\uacb4\u0b57\u72ea", "\uda2a\udde0\ud9a5\udc80\ud9d5\uddeb\ud851\udd9b",
        48, 3796, 1165013342, -2080859404380757798L, -84989L, true, false, (char) 10632, (char) 55127,
        Double.longBitsToDouble(0x3fde5964aa71f7a8L), Double.longBitsToDouble(0x3fdb7fcb3807528cL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\0121=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 10, 10, 1, "\udb58\udccf\ud820\udf97\udbca\udf3b\udb05\udeb5\ud952\udfc5\udab0\ude6b\udabf\udf63\ud86b\udf34\udaa7\udf31\uda07\udcb5\ud989\ude3e\ud9be\udeca\udac3\udd99\u1f8a\ud851\udd9b", "\u7000\u7637\ud048\ud712", "\ud8f3\udcf4\udbc2\udf69\ud9e5\udc56\uda7b\udfcb\ud9db\udd9c\ud95b\udd6b\ud828\udd88\udb76\udd2b\ud9df\udf81\ud9c9\ude16",
        24, 1004, -1572399909, 6303955864354305693L, 57627L, false, true, (char) 12242, (char) 27942,
        Double.longBitsToDouble(0x3fe52f78fea407b9L), Double.longBitsToDouble(0x3f977bd76a189ea0L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\0121=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 10, 10, 1, "\udb58\udccf\ud820\udf97\udbca\udf3b\udb05\udeb5\udbce\udcc3\udab0\uddff\udabf\udf63\ud90d\udd7a\udaa7\udf31\ud9cf\udd5b\ud989\ude3e\udacb\udf10\ud857\uded3\u1f8a\ud851\udd9b", "\u61b3\u7637\ud048\ud712\u5cdd\u1c86\u8b6f\u28b9\uca53\u92c8q", "\udb76\udd2b\udb37\udda6\ud9cf\udf7c\ud9a5\udf00\udb41\udff4\udac3\udf4d\udb5a\udfde\udbc9\udd99\udaae\udc2c\udb23\udd1f\ud910\udd44\udaef\udee6\ud91f\uddb7\ud906\udef3\ud959\udda1\ud8e7\udc9c\ud878\udd26\ud86b\udedc\uda51\udcd6\ud8de\udecc\ud863\udff5\ud93e\udcc7\ud93b\udc31\ud969\udff0\ud822\uddf2\udaef\udf46",
        0, 29580, 61615255, 8686133690152858469L, -11410L, true, false, (char) 50320, (char) 28713,
        Double.longBitsToDouble(0x3fd4df149e429a76L), Double.longBitsToDouble(0x3fe53d3bf71dc03aL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.fraction.Fraction:@?\0121=java.lang.Integer:0 |this=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 12, 12, 3, "\uda97\udfda\uda1f\udd7b\udb5b\udebd\ud86e\udca5\udb91\udc6e", "\u1ee3\ua95c\u7739\ucc5f\ubd83", "\ud851\udda7\uda6d\udc28\uda27\udfc1\uda5d\udd75\ud92c\udfb2\ud818\udf9b\udb05\udf32\uc245\ud8fc\udc50",
        51, 78309, -74810978, 8367523420147177731L, -87590L, false, false, (char) 43722, (char) 8948,
        Double.longBitsToDouble(0x3fecd35e701cb9ceL), Double.longBitsToDouble(0x3feeb1cb373a36b5L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\0121=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 2, 10, 10, 1, "\udb27\udf7e\ud820\udfa0\udbca\udf3b\ud877\udc6d\ud952\udf37\uda5b\udd20\uda90\ude45\ud86b\udf34\udaa7\udf31\ud9f1\udcb5\ud989\ude3e\u9a7f\udaca\udd2a\u1f8a\ud851\udd9b\udb2f\udfe3\ud951\udda0\uda43\udd8c", "\ud712\u2789\u7ca5\u51b7\u05ab\u3e30\u07eb\uc4af\ua6fb\ua902\ua67a\u95de\u64c1\u049b\u6e09\u5dc6\u0e25\u5327\u7aa5\u7b50\uc398\u77c5\uac08\u3fcd\ua16b\u1a1d\uafb5\u3bf6\u3eee\ud670\uabd9\u06e1\ub2bd\u6b32\u58ce\u9dbe\u021d\uae8c", "\ud9db\ude07\udad1\udf4e\uda40\udc38\ud936\udd77\ud840\uddb3\ud85b\udd9a\ud825\udc41\ud973\udc12\udbee\udfc9",
        16, 88704, -548424373, -2999452688511260058L, 37330L, true, true, (char) 39069, (char) 48022,
        Double.longBitsToDouble(0x3fe7c4ab033f5ea0L), Double.longBitsToDouble(0x3fee2807faf7ee3dL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$1\012",
        Z.run(T, 1, 10, 14, 3, "\ud9e0\udede\udac9\udfd3\udb32\udcd9\uda93\uddff\udb67\udc3b\ud9fa\udec7\u6c54\ucb45\udbef\uddff\udb11\udc2d\ud903\udc73\uda7e\udce3\ud9a5\udc14\ud9d5\uddeb\ud851\udd9b\uda61\uddb6", "\u1fbe", "\ud9a0\udf0b\udb6a\udda4\ufa8e\ud896\udf46\udb87\udf9d\udbd6\udc81\ud81e\udec9\udbf1\udfdf\ud9db\udc68\ud85b\udd0c\ud898\udc98\ud8dd\udccf\uda5d\udf35\uda23\udc20\ud934\udeed\ud839\udfde\ud886\udc2b\ud952\udef8\uda41\ude4b\udbc9\udfb3\udab5\udf03\udad0\udcb1\ud960\udf9e\udacf\udfdb\u3744\uda29\udf9b\uda10\udcb8\udb4d\ude49\uda13\ude8e\ud915\udfde\ud937\ude69\udaff\udfce\ud98e\udd40\udadd\udf1c\udbe1\udc29\ud804\udd11\ud8f3\udd41\ud8d7\udc56\ud852\udd7d\uda35\udd5c\ud88e\ude8d\udacd\udced\udaca\udfc7\ud9c8\udeea",
        28, 0, -1724012082, 2024510436545119305L, -76119L, false, true, (char) 55369, (char) 41751,
        Double.longBitsToDouble(0x3fef648dd627b4e7L), Double.longBitsToDouble(0x3fc2d4dd1cde3e90L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$1\012",
        Z.run(T, 1, 10, 14, 3, "\ud9e0\udede\udac9\udfd3\udb32\udcd9\uda93\uddff\udb2c\ude3b\ud9fa\udec7\u6c54\ucb45\udbef\uddff\udb11\udc2d\ud903\udc73\uda7e\udce3\ud9a5\udc14\ud9d5\uddeb\ud851\udd9b\uda61\uddb6", "\u2ed8", "\ud9a0\udf0b\udb6a\udda4\ufa8e\ud896\udf46\udb87\udf9d\udbd6\udc81\ud81e\udec9\udbf1\udfdf\ud9db\udc68\ud85b\udd0c\ud898\udc98\u7a70\uda5d\udf35\uda23\udc20\u0a35\ud839\udf8a\ud886\udc2b\ud952\udef8\uda41\ude4b\udbc9\udfb3\udab5\udf03\udad0\udcb1\ud960\udf9e\udacf\udfdb\u3744\uda29\udf9b\uda10\udcb8\udb4d\ude49\uda13\ude8e\ud915\udfde\ud937\ude69\ud802\ude90\ud98e\udc9c\udadd\udf1c\udbe1\udc29\ud804\udd11\ud8f3\udd41\ud8d7\udc56\ud852\udd7d\uda35\udd5c\ud88e\ude8d\udacd\udced\udaca\udfc7\ud9c8\udeea",
        -4, 0, 4041166, 2024368032609453129L, -76119L, false, false, (char) 55369, (char) 41751,
        Double.longBitsToDouble(0x3fef648dd627b4e7L), Double.longBitsToDouble(0x3fc2d4dd1cde3e90L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$1\012",
        Z.run(T, 1, 10, 14, 3, "\ud9e0\udede\udac9\udfd3\udb32\udcd9\uda93\uddff\udb2c\ude3b\ud9fa\udec7\u6c54\ucb45\udbef\uddff\udb11\udc2d\ud903\udc73\uda7e\udce3\ud9a5\udc14\ud9d5\uddeb\ud851\udd9b\uda61\uddb6", "\u2ed8", "\ud9a0\udf0b\udb6a\udda4\ufa8e\ud896\udf46\udb87\udf9d\udbd6\udc81\ud81e\udec9\udbf1\udfdf\ud9db\udc68\ud85b\udd0c\ud898\udc98\u7a70\uda5d\udf35\uda23\udc20\u0a35\ud839\udf8a\ud886\udc2b\ud952\udef8\uda41\ude4b\udbc9\udfb3\udab5\udf03\udad0\udcb1\ud960\udf9e\udacf\udfdb\u3744\uda29\udf9b\uda10\udcb8\udb4d\ude49\uda13\ude8e\ud915\udfde\ud937\ude69\ud802\ude90\ud98e\udc9c\udadd\udf1c\udbe1\udc29\ud804\udd11\ud8f3\udd41\ud8d7\udc56\ud852\udd7d\uda35\udd5c\ud88e\ude8d\udacd\udced\udaca\udfc7\u59f2",
        30, 0, 4041166, 2024368032609453129L, -76119L, false, false, (char) 55369, (char) 41751,
        Double.longBitsToDouble(0x3fef648dd627b4e7L), Double.longBitsToDouble(0x3fc2d4dd1cde3e90L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$1\012",
        Z.run(T, 1, 10, 14, 3, "\ud9e0\udede\udac9\udfd3\udb32\udcd9\udb59\udcc2\ud817\udfd3\ud8b0\udd61\udbb5\ude44\ud82d\udecf\udbef\uddff\udb11\udc2d\ud903\udc73\uda7e\udce3\uda57\udd58\ud9d5\uddeb\ud851\udd9b\uda61\uddb6", "\u2ed8", "\ud9a0\udf0b\udb6a\udda4\ufa8e\ud896\udf46\udb87\udf32\udb2c\udf7f\udad2\udeb9\udbf2\udcaa\ud9db\udc68\ud85b\udd0c\uda68\ude89\ud9a3\ude3f\udac6\udeb4\uda23\udc20\u0a35\ud839\udf8a\ud886\udc2b\ud952\udef8\uda41\ude4b\udbc9\udfb3\udab5\udf03\udad0\udcb1\ud960\udf9e\udacf\udfdb\u3744\uda29\udf9b\uda10\udcb8\udb4d\ude49\uda13\ude8e\ud8b5\ude1e\ud91c\udfcb\ud802\ude90\ud98e\udc9c\udadd\udf1c\udbe1\udc29\ud804\udd11\ud8f3\udd41\ud9eb\udc53\ud852\udd7d\uda35\udd5c\ud91a\ude52\udacd\udced\udaca\udfc7\ud9c8\udeea",
        0, 0, 4041166, 2024368032609453129L, -76119L, false, false, (char) 55369, (char) 41751,
        Double.longBitsToDouble(0x3fef648dd627b4e7L), Double.longBitsToDouble(0x3fc2d4dd1cde3e90L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=org.apache.commons.math.fraction.Fraction:@?\012",
        Z.run(T, 1, 10, 14, 3, "\ud84f\udd35\ud8c8\uddb8\udb32\udcd9\u3c5d\ud8b1\udf4c", "\u0b57\u4d94\ucfa8\u858e\u896d\u7431\uad10\u26b6\u7b50\u507d", "\ud94e\udc7c\ud8a7\udfe2\ud90e\udfa2\udae0\udd95\udaca\uded5",
        16, 45221, -55370440, -6249208789316281341L, 1848L, false, false, (char) 56390, (char) 38127,
        Double.longBitsToDouble(0x3fd2a29dd46af614L), Double.longBitsToDouble(0x3fd540c382c8562eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.fraction.Fraction|compareTo|org.apache.commons.math.fraction.Fraction|new:org.apache.commons.math.fraction.Fraction:double",
    "M|org.apache.commons.math.fraction.Fraction|abs||new:org.apache.commons.math.fraction.Fraction:double",
    "M|org.apache.commons.math.fraction.Fraction|add|org.apache.commons.math.fraction.Fraction|new:org.apache.commons.math.fraction.Fraction:double",
    "M|org.apache.commons.math.fraction.Fraction|addSub|org.apache.commons.math.fraction.Fraction,boolean|new:org.apache.commons.math.fraction.Fraction:double",
    "M|org.apache.commons.math.fraction.Fraction|divide|org.apache.commons.math.fraction.Fraction|new:org.apache.commons.math.fraction.Fraction:double",
    "M|org.apache.commons.math.fraction.Fraction|doubleValue||new:org.apache.commons.math.fraction.Fraction:double",
    "M|org.apache.commons.math.fraction.Fraction|equals|java.lang.Object|new:org.apache.commons.math.fraction.Fraction:double",
    "M|org.apache.commons.math.fraction.Fraction|floatValue||new:org.apache.commons.math.fraction.Fraction:double",
    "M|org.apache.commons.math.fraction.Fraction|getDenominator||new:org.apache.commons.math.fraction.Fraction:double",
    "M|org.apache.commons.math.fraction.Fraction|getNumerator||new:org.apache.commons.math.fraction.Fraction:double",
    "M|org.apache.commons.math.fraction.Fraction|getReducedFraction|int,int|static",
    "M|org.apache.commons.math.fraction.Fraction|hashCode||new:org.apache.commons.math.fraction.Fraction:double",
    "M|org.apache.commons.math.fraction.Fraction|intValue||new:org.apache.commons.math.fraction.Fraction:double",
    "M|org.apache.commons.math.fraction.Fraction|longValue||new:org.apache.commons.math.fraction.Fraction:double",
    "M|org.apache.commons.math.fraction.Fraction|multiply|org.apache.commons.math.fraction.Fraction|new:org.apache.commons.math.fraction.Fraction:double",
    "M|org.apache.commons.math.fraction.Fraction|negate||new:org.apache.commons.math.fraction.Fraction:double",
    "M|org.apache.commons.math.fraction.Fraction|compareTo|org.apache.commons.math.fraction.Fraction|new:org.apache.commons.math.fraction.Fraction:double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
