package org.apache.commons.math.analysis.solvers;
import org.junit.Test;
import static org.junit.Assert.*;
public class UnivariateRealSolverUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 7, 1, 3, "\udbcc\udd12\ud898\ude84\ud8a9\udef2\ud99c\uddc8\ub2ec\udb34\udfe9\ud8c4\udcba\ud878\ude11\uda69\udcfa\udaa2\udc18\udab3\udd31\ud828\udf66\udac9\udc6e\ud8e8\uded3\uda22\udcf2\ud69e\uda72\udfb9\ud80f\udf25\udbcb\udc2a\udae3\udf85\udb3e\ude2d\udb49\udfcc\uda0d\udf8d\ub642\udbdf\ude42\udbde\udff1\ud8b0\ude00\udbfc\udf64\ud811\udc0c\udaa4\udfb5\uda25\udff4\udbac\udec8\ud815\udc88", "\ua4a6\u704c\ubda9\u7575\ua050\ub4b3\u6c46", "\ud851\udf0f\u8218\udb51\udee9\udbf7\udd41\udb87\udcc6",
        24, 34733, -1115928515, 5118801738241480478L, 80277L, false, false, (char) 11764, (char) 16397,
        Double.longBitsToDouble(0x3fe097c449250f98L), Double.longBitsToDouble(0x3fdd4292d132796cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 7, 1, 3, "\udbcc\udd12\ud898\ude84\ud8a9\udef2\ud99c\uddc8\ub2ec\udb34\udfe9\ud8c4\udcba\ud878\ude11\uda69\udcfa\udaa2\udc18\udab3\udd31\ud828\udf66\udac9\udc6e\ud8e8\uded3", "\u9064\u6414\u8442\ucf8b\u3e47", "\ub642\udbdf\ude42\udbde\udff1\ud8b0\ude00\udbfc\udf64\ud811\udc0c\udaa4\udfb5\uda25\udff4\udbac\udec8\ud815\udc88\uda7e\udc3f\u4c7e\ud8ec\udce5\udba1\udfdf\uda0b\udc1c\ud9ae\udd62\u2d17\u5248\ud8d9\udd09\ud956\udf77\udb3e\udfbc\ud851\udf0f\u8218\udb51\udee9\udbf7\udd41\udb87\udcc6\ud87d\uddef\ud86c\udeb8",
        -5, 12903, 1938364190, 2985487257754058805L, -58280L, false, true, (char) 15004, (char) 6333,
        Double.longBitsToDouble(0x3fdd4292d132796cL), Double.longBitsToDouble(0x3fe25410be1c6cc1L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 1, 1, 6, 0, "\udbcc\udd12\ud898\ude84\ud886\uddf2\udbf3\ude95\udb33\udc18\udb35\udc01\ud8c4\udcba\ud878\ude11\uda69\udcfa\udaa2\udc18\udab3\udd31\ud828\udf66\udac9\udc6e\ud8e8\uded3\u605d\ud5de\uda72\udfb9\ud80f\udf25\udbcb\udc2a\udae3\udf85\udb3e\ude2d", "\u7110\u51e3\u3bf9\ucccb\u1ac0\uc6ee\u95c4\uccea\u9c53\u3e19\ucf4d\u2edf\ua4a6\u704c\ubda9\u7575\ua050\ub4b3\u6419\u68d0\u9e75\ub742\u2d30\u1458\ua7c5\u30d5\u66c7\u69d9\ubab6\u4b27\ud00c", "\ud863\udddc\ud887\udf80\ud987\udd75\ud8e8\udefd\ud89e\udf92",
        51, 85841, 950807109, 3945378855879288342L, 4855L, false, false, (char) 17001, (char) 4915,
        Double.longBitsToDouble(0x3fd81d167d74ac08L), Double.longBitsToDouble(0x3fc32ff2dfdcdee4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 4, 0, 6, "\udbcc\udd12\ud898\ude84\ud8a9\udef2\ud99c\uddc8\ub2ec\udb34\udfe9\ud8c4\udcba\ud878\ude11\uda69\udcfa\udaa2\udc18\udab3\udd31\ud828\udf66\udac9\udc6e\ud8e8\uded3\uda22\udcf2\ud69e\uda72\udfb9\ud80f\udf25\udbcb\udc2a\udae3\udf85\udb3e\ude2d\udb49\udfcc\uda0d\udf8d\ub642\udbdf\ude42\udbde\udff1\ud8b0\ude00\udbfc\udf64\ud811\udc0c\udaa4\udfb5\uda25\udff4\udbac\udec8\ud815\udc88", "\ua412\ud12d\u5e81\u6435\ua050\ub4b3\u5d08", "\ud853\uddd2\u8218\udb51\udee9\udbf7\udd41\udb87\udcc6",
        24, 17341, 555802533, -9161536750805758802L, -37409L, true, true, (char) 15004, (char) 6333,
        Double.longBitsToDouble(0x3fdd4292d132796cL), Double.longBitsToDouble(0x3fb73d83da7f3980L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Double:0.49518825058040217\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 2, 1, 3, "\udbcc\udd12\ud898\ude84\ud8a9\udef2\udb1c\udedb\udb24\udda9\udb34\udfe9\ud8c4\udcba\ud878\ude11\uda69\udcfa", "\u4063\u424b", "\ud801\udd71\ud9d9\udd52\ud80f\udf25\udbcb\udc2a\udae3\udf63\udb3e\ude2d\udb49\udfcc\uda3d\ude8d\ub642\udbdf\ude42\udbde\udff1\ud8b0\ude00\udbfc\udf64\ud811\udc0c\udaa4\udfb5\uda25\udff4\udbb4\uddc8",
        24, 97892, -1461231200, 7704531068354704425L, 66886L, true, false, (char) 46822, (char) 8425,
        Double.longBitsToDouble(0x3f923f40a8afb000L), Double.longBitsToDouble(0x3fef1f300a214fccL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils:@?\0121=java.lang.Double:0.16030013705141116\012",
        Z.run(T, 2, 6, 2, 0, "\udbcc\udd12\ud898\ude84\ud8a9\udef2\ud83d\udf5a\ub33e\udb34\udfe9\ud8c4\udcba\ud878\ude11\ud85a\ude14\udaa2\udc3e\udab3\udd31\ud828\udf66\udac9\udc6e\ud8e8\uded3\uda96\udcec\ud69e\uda72\udfb9\ud8e2\udd1b\udbcb\udc2a\udae3\udf85\udb3e\ude2d\udb49\udfcc\uda88\udf8b\u3f29\ud8ac\uded9\ud9ac\udcb2\ud8bc\udf41\udbfc\udf64\ud811\udc0c\udaa4\udfb5\uda25\udff4\udbc7\udc54\uda34\uddbe", "\ua4a6\u5e1d\ubd38\u4e59\u3261\ub469\u6c46\u68d0\u9e75", "\udb51\udee9\udbf7\udd41\udb87\udcc6\ud87d\uddef\ud86c\udeb8\ud9fb\udc51\udac9\udf3e\u95ed\ud809\udf49\udb35\uddd7",
        44, 9416, -125198874, 1123720752796600613L, 47353L, true, false, (char) 463, (char) 36853,
        Double.longBitsToDouble(0x3fc6e11fc3f31388L), Double.longBitsToDouble(0x3fc2284e423b0964L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils:@?\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 6, 4, 5, "\uda95\udcf6\udba5\udf8e\ud8a9\udf94\ud99c\uddc8\ub2ec\ud8e4\udfe1\ud8c4\udcba\ud878\ude11\uda69\udcfa\udaa2\udc18", "\u4670\ubb16\u25bb\u517d", "\udbcb\udc2a",
        46, 95608, 197760795, 618724932417446488L, -16601L, false, true, (char) 7126, (char) 51050,
        Double.longBitsToDouble(0x3fefcde88a4181f9L), Double.longBitsToDouble(0x3fdd260be97bf654L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils:@?\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 6, 7, 3, "\uda6b\udea2\ud898\ude39\ud8a9\udef2\ud95b\udda8\ub3bc\udb05\udf52\udae2\udce9\ud878\ude11\uda69\udcfa\udaa2\udc18\udab3\udd31\ud828\udf66\udac9\udc6e\ud8e8\ude4d\uda22\udcf2\ud69e\uda72\udfb9\ud80f\udf25\udbcb\udc2a\udae3\udf85\udb3e\ude2d\udb49\udfcc\uda0d\udf8d\ub642\udbdf\ude42\udbde\udff1\udb33\udc6a\udbfc\udfb8\ud811\udc0c\udaa4\udfb5\uda25\udff4\udbdc\udec0\ud815\udc88", "\ua4a6\u704c\ubda9\u7575\ua050\ub4b3\u6c46", "\ud85d\udc0f\u8218\udb51\udee9\udbf7\udd41\udb87\udcc6",
        24, 34733, -1115928515, 5118801738241480478L, 80277L, false, false, (char) 11764, (char) 41884,
        Double.longBitsToDouble(0x3fe097c449250f98L), Double.longBitsToDouble(0x3fdd4292d132796cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 3, 1, 1, "\udbcc\udced\ud86e\udf0b\ud8a9\udef2\ud9bb\udcc8\ud981\udcd3", "\u2989\u261e\u8cc9\ubcb8\u4646\ua32c\u6dc5\u9207\u3bad\u9064\u6414\u8442\ucf8b\u3e47\u7e64\u82bf\u7110\u51e3\u3bf9\ucccb\u9a3b\u65be\u1cc5", "\ud8d7\udc89\uda7e\udc3f",
        -5, 31040, -1304546187, -7066312864247009546L, 54151L, true, true, (char) 8926, (char) 45765,
        Double.longBitsToDouble(0x3fc7fcc03ce23a54L), Double.longBitsToDouble(0x3fd5ff109ecd24d6L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 5, 1, 3, "\udbcc\udd12\ud898\ude84\ud8a9\udef2\ud99c\uddc8\ub2ec\udb34\udfe9\ud8c4\udcba\ud878\ude11\uda7c\uddfa\ud923\udd28\udab3\udd31\ud828\udf66\udac9\udc6e\ud8e8\uded3\uda22\udcf2\ud69e\uda72\udfb9\ud80f\udf25\udbcb\udc2a\udae3\udf85\udb3e\ude2d\udb49\udfcc\uda0d\udf8d\ub642\udbc2\udc42\udbde\udff1\ud8b0\ude00\udbfc\udf64\ud811\udc0c\udaa4\udfb5\uda25\udff4\udbac\udec8\ud815\udc88", "\ua4a6\u704c\ubda9\u7575\ua050\ub4b3\u6c46", "\ud851\udf0f\u8218\udb51\udee9\udb77\udd41\udb87\udcc6",
        24, 34733, -1115928515, 5118801738241480478L, 80277L, false, false, (char) 11764, (char) 16397,
        Double.longBitsToDouble(0x3fe097c449250f98L), Double.longBitsToDouble(0x3fdd4292d132796cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Double:0.48785726888417436\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 2, 1, 3, "\udbcc\udd12\ud898\ude84\ud8a9\udef2\ud99c\uddc8\ub2ec\udb34\udfe9\ud8c4\udcba\ud878\ude11\uda69\udcfa\udad5\udff0\udab3\udd31\ud828\udf66\udac9\udc6e\ud8e8\uded3\uda22\udcf2\ud69e\udaa2\udf30\ud80f\udf25\ud8cb\udc2a\udae3\udf85\uda4d\udd2b\udb49\udfcc\uda0d\udf8d\ub642\udbdf\ude42\udbde\udff1\ud8b0\ude00\udbfc\udf64\ud811\udc0c\udaa4\udfb5\uda25\udff4\udbac\udec8\ud815\udc88", "\ua4a6\u704c\ubda9\u7575\ua050\ub4b3\u6c46", "\ud851\udf0f\u8218\udb51\udee9\udbf7\udd41\udb87\udcc6",
        24, 34733, -1113569219, 5118801738241480478L, 80277L, false, false, (char) 11764, (char) 16397,
        Double.longBitsToDouble(0x3fe097c449250f98L), Double.longBitsToDouble(0x3fdd4292d132796cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 4, 1, 3, "\udbcc\udd12\udb4a\udd45\ud8a9\udef2\ud99c\uddc8\ub2ec\udb34\udfe9\ud8c4\udcba\ud878\ude11\uda69\udcfa\udaa2\udc18\udab3\udd31\ud828\udf66\udac9\udc6e\ud8e8\uded3", "\u9064\u6414\u8442\ucf8b\u3e47", "\ub642\udbdf\ude42\udbde\udff1\ud8b0\ude00\udbfc\udf64\ud811\udc0c\udaa4\udfb5\uda25\udff4\udbac\udec8\ud815\udc88\uda7e\udc3f\u4c7e\ud8ec\udce5\udba1\udfdf\uda0b\udc1c\ud9ae\udd62\u2d17\u5248\udbc4\udf22\ud956\udf77\udb3e\udfbc\ud851\udf0f\u8218\udb51\udee9\udbf7\udd41\udb87\udcc6\ud87d\uddef\ud86c\udf1a",
        -5, 12903, 1938364190, 2985487257754058805L, 89944L, false, true, (char) 15004, (char) 6333,
        Double.longBitsToDouble(0x3fdd4292d132796cL), Double.longBitsToDouble(0x3fe25410be1c6cc1L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils:@?\0121=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 6, 5, 3, "\udbcc\udd12\ud898\ude84\ud8a9\udef2\ud99c\uddc8\ub2ec\ud962\udc95\udbc6\udc87\ud8a1\udc22\uda69\udcfa\udaa2\udc18\udab3\udd31\ud828\udf66\udac9\udc6e\ud8e8\uded3", "\u9064\u7086\u8442\u1109\u2680", "\ub642\uda99\udf1e\udbde\udff1\ud8b0\ude00\udbfc\udf64\ud811\udc0c\udaa4\udfb5\uda25\udff4\udbac\udec8\ud815\udc88\uda7e\udc3f\u4c7e\ud8ec\udce5\ud9ab\udd84\udbd9\udf51\ud904\uddac\u2c87\u5248\ud8d9\udd09\ud956\udf77\udb3e\udfbc\ud851\udf0f\u8218\udb51\udee9\udbf7\udd41\udb87\udcc6\ud87d\uddef\ud86c\udeb8",
        -5, 12903, -593102818, 4817120990786142261L, -58280L, false, true, (char) 15004, (char) 6333,
        Double.longBitsToDouble(0x3fe6a14968990a0eL), Double.longBitsToDouble(0x3fe25410be1c6cc1L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils:@?\012",
        Z.run(T, 1, 6, 6, 0, "\udbcc\udd12\ud898\ude84\ud886\uddf2\udbf3\ude95\udb33\udc18\udb35\udc01\ud8c4\udcba\ud878\ude11\uda69\udcfa\udaa2\udc18\udab3\udd31\ud828\udf66\udac9\udc6e\ud8e8\uded3\u605d\ud5de\uda72\udfb9\ud80f\udf25\udbcb\udc2a\udae3\udf85\ud8cf\udcf6", "\u7110\u51e3\u3bf9\ucccb\u1ac0\uc6ee\u95c4\uccea\u9c53\u3e19\ucf4d\u2edf\ua4a6\u704c\ubda9\u7575\ua050\u2bf8\u2966\u69a3\u9e75\ub742\u2d30\u1458\ua7c5\u30d5\u66c7\u69d9\ubab6\u4b27\ud00c", "\ud863\udddc\ud887\udf80\ud987\udd75\ud8e8\udefd\ud89e\udf92",
        51, 85841, 950807109, 3945378855879288342L, 4855L, false, false, (char) 17001, (char) 4915,
        Double.longBitsToDouble(0x3fdeed167d74ac08L), Double.longBitsToDouble(0x3fc32ff2c86242e4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils:@?\0121=new org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils:@?\012",
        Z.run(T, 2, 6, 6, 5, "\udbcc\udd12\ud898\ude84\ud8a9\udef2\ud99c\uddc8\ub2ec\udb34\udfe9\ud8c4\udcba\ud878\ude11\uda69\udcfa\udaa2\udc18\udab3\udd31\ud828\udf66\udac9\udc6e\ud8e8\uded3\uda22\udcf2\ud69e\uda72\udfb9\ud80f\udf25\ud8eb\udd1e\udae3\udf85\udb3e\ude2d\udb49\udfcc\uda0d\udf8d\ub642\udbdf\ude42\udbde\udff1\ud8b0\ude00\udbfc\udf64\ud811\udc0c\udaa4\udfb5\uda25\udff4\udbac\udec8\ud815\udc88", "\ua412\ud12d\u5e81\u6435\ua050\ub4b3\u5d08", "\ud853\uddd2\u8218\udb51\udee9\udbf7\udd41\udb87\udcc6",
        24, 17341, 555802533, -9161536750805758802L, -37409L, true, true, (char) 15004, (char) 6333,
        Double.longBitsToDouble(0x3fdd4292d132796cL), Double.longBitsToDouble(0x3fb73d83da7f3980L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Double:0.5248661008077946\0121=java.lang.Double:0.5248661008077946\012",
        Z.run(T, 2, 2, 2, 6, "\udbcc\udd12\ud898\ude84\ud8a9\udef2\ud99c\uddc8\ub2ec\udb34\udfe9\ud8c4\udcba\udbed\udd2c\udb26\udd05\udaa2\udce9\udab3\udd31\ud828\udf66\udb77\udf22\ud8e8\uded3\uda22\udcf2\ud69e\uda72\udfb9\ud80f\udf25\udbcb\udc2a\udae3\udf85\udb3e\ude2d\udb49\udfcc\uda0d\udf8d\ub642\udbdf\ude42\udbde\udff1\ud8b0\ude00\udbfc\udf64\ud811\udc0c\udaa4\udfb5\uda25\udff4\udbac\udec8\ud967\udc10", "\u17dd\uc24c\u5e81\u6435\ua050", "\ud957\udc10\ud93c\udeda\ud853\uddd2\u8218\udb51\udee9\udbf7\udd41\udb8b\udf96\ud87d\uddef\uc0c4\udb20\udd98\ud9e1\ude70\udbac\uddda\ud9e2\udfb9\ud905\udc6f\ud892\ude59\ud82a\uddb4\ud971\udf10\ud8e8\udefd\ud89e\udf92\udbda\udd67\ud003\udaa7\udee5",
        27, 49342, 1579706190, -9194270336364424177L, -43312L, true, false, (char) 59677, (char) 24326,
        Double.longBitsToDouble(0x3fc5760040e61a84L), Double.longBitsToDouble(0x3fec39e7ec366114L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Double:0.5711757233728827\0121=java.lang.Double:0.5711757233728827\012",
        Z.run(T, 2, 2, 2, 2, "\udab4\udcb9", "\ube5b\u2da1\u31f2\u374f\u0193\u4a32", "\ud80c\udcc1\ud84e\udd71",
        43, 25270, 725100278, -5391004973049820257L, -15748L, false, false, (char) 30080, (char) 57402,
        Double.longBitsToDouble(0x3fe2c0411199a86bL), Double.longBitsToDouble(0x3fe1cde38d704e25L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!org.apache.commons.math.MathRuntimeException$4\012",
        Z.run(T, 2, 7, 1, 3, "\udbcc\udd12\ud898\ude84\ud8a9\udef2\ud99c\uddc8\ub2ec\udb34\udfe9\ud8c4\udcba\ud878\ude11\uda69\udcfa\udaa2\udc18\udab3\udd31\ud828\udf66\udac9\udc6e\ud8e8\uded3\uda22\udcf2\ud69e\ud845\udfa1\ud9c3\udcff\udbcb\udc2a\udb10\udd85\udb3e\ude2d\udb49\udfcc\uda0d\udf8d\ub642\udbdf\ude42\udbde\udff1\ud8b0\ude82\udbfc\udf64\ud811\udc0c\udaa4\udfb5\uda25\udff4\udbac\udec8\ud815\udc88", "\ua4a6\u704c\ubda9\u7575\ua050\ub4b3\u6c46", "\ud851\udf0f\u8218\udb51\udee9\udbf7\udd41\udb87\udcc6",
        24, 34733, -1115928515, 5118801738241480478L, 80277L, false, false, (char) 11764, (char) 16397,
        Double.longBitsToDouble(0x3fe097c449250f98L), Double.longBitsToDouble(0x3fdd4292d132796cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils|bracket|org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double|static",
    "M|org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils|bracket|org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double,int|static",
    "M|org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils|midpoint|double,double|static",
    "M|org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils|setup|org.apache.commons.math.analysis.UnivariateRealFunction|static",
    "M|org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double|static",
    "M|org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils|solve|org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double|static",
    "C|org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils|<init>|",
    "M|org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils|bracket|org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double|static",
    "M|org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils|bracket|org.apache.commons.math.analysis.UnivariateRealFunction,double,double,double,int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
