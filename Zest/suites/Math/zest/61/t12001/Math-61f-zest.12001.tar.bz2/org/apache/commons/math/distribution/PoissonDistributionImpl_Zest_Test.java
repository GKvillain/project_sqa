package org.apache.commons.math.distribution;
import org.junit.Test;
import static org.junit.Assert.*;
public class PoissonDistributionImpl_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:2147483647 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 6, 1, 9, "\uda7c\udc2a\uda17\udec6\uda9b\uddc5", "\u7dcf\u60bd", "\udb66\udd1b\u3a19\u5900\ud973\udf27\uda16\udc60\ud9fe\ude51",
        55, 42464, -1267364851, -4794450016633724955L, 52182L, false, false, (char) 11854, (char) 62919,
        Double.longBitsToDouble(0x3fb490e3b10eb560L), Double.longBitsToDouble(0x3fe9a180fbc2c4baL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:2147483647 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 6, 13, 5, "\uda7c\udc2a\uda17\udec6\u00f4", "\000", "",
        -5, 50, 2030043891, 597132134923506176L, -98835L, true, false, (char) 0, (char) 2908,
        Double.longBitsToDouble(0x3fd1db4751cb7a00L), Double.longBitsToDouble(0x3fed5549758aeb61L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 4, 1, 9, "\uda7c\udc2a\uda17\udec6\uda9b\uddc5", "\u7dcf\u60bd", "\udb66\udd1b\u3a19\u5900\ud973\udf27\uda16\udc60\ud9fe\ude51",
        55, 42464, -1267364851, -7710232915183165512L, 52182L, false, false, (char) 11854, (char) 62919,
        Double.longBitsToDouble(0x3fb490e3b10eb560L), Double.longBitsToDouble(0x3fe9a180fbc2c4baL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 2, 1, 9, "\uda66\uddb8\uda17\udec6\udb3f\udf77\udb76\udf34\u8daa\ud81d\uddc6\ud85e\uddb3\udb64\udc9f\udaad\udcff\udb66\udd1b", "\u039b\u1bcb\u752c\uab31\ub26d\u6e68\u9e66\u7b4c\u133a\ua97d\u4ec5", "\uda0f\udde2",
        4, 46588, 1236958146, 7405961939038540049L, -90362L, true, false, (char) 48903, (char) 27135,
        Double.longBitsToDouble(0x3fe074f37cb46624L), Double.longBitsToDouble(0x3fefe34648bee0efL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 12, 1, 9, "\uda7c\udc2a\uda17\udec6\udbcc\udd5d", "\u29f6\u358b", "\udb66\udd1b",
        23, 5883, 820694673, -9096151925315863693L, -14269L, true, true, (char) 21720, (char) 39147,
        Double.longBitsToDouble(0x3fe1601aab8d4ac1L), Double.longBitsToDouble(0x3fc63fa2c1490e38L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:2147483647 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 6, 1, 9, "\uda7c\udc2a\uda17\udec6\uda9b\uddc5", "\u7dcf\u60bd", "\udb66\udd1b\u3a19\u5900\ud973\udf27\uda16\udc60\ud9fe\ude51",
        55, 42464, -307524595, -4794449849130000411L, 52182L, true, false, (char) 11854, (char) 49863,
        Double.longBitsToDouble(0x3fb49415710eb560L), Double.longBitsToDouble(0x3fe9a180fbc2c4baL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 0, 2, 9, "\uda7c\udc2a\u0084\uda9b\uddc5", "\015\000", "\udb66\udd1b\u3a19\u7083",
        -5, -1000, 0, 2135890432L, -14269L, true, true, (char) 43310, (char) 39147,
        Double.longBitsToDouble(0x3fe1601aab8d4ac1L), Double.longBitsToDouble(0x3fc63fa2c0000000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:2147483647 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 6, 4, 4, "\uda1f\udc3c\ud8d3\udd3d\uda9b\uddc5", "\u7dcf\u60bd", "\udb66\udd1b\ud9d6\udf9d\udb66\udee1\ud87c\udf6d\uda18\udc18\ud9fe\ude51",
        55, 48704, -1264612339, 3961392083912176423L, 46593L, false, false, (char) 11854, (char) 62919,
        Double.longBitsToDouble(0x3fb490e386e15d60L), Double.longBitsToDouble(0x3fe9a180fb29c4baL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.9791203582283219 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 12, 8, 13, "\udaac\udc63\udb35\udff4\ud84d\udc22\udb76\udc3a\u8daa\ud81d\uddc6", "\u93e6\ua6c2\u32b7\u4a55\u039b\u9a33\u27f7\uab31\u2903\uca84\u9b9a\u0d01\u133a\ua97d\u4ec5", "\uda0f\udde2\u40f7\udb2e\udfb5\uda0d\udfd9",
        2, 98167, 1941900548, -2418227543681725863L, 8665L, false, true, (char) 5889, (char) 26113,
        Double.longBitsToDouble(0x3fe7ce8852904cddL), Double.longBitsToDouble(0x3fb178b205b14e90L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:2147483647 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 6, 3, 6, "\uda7c\udc2a\udba3\udc4c\uda9b\udd37", "\u7e9c\u60bd", "\ud9bd\udd47\udacb\ude18\u58de\uda42\udc0e\uda15\udfc9\ud9fe\ude51",
        55, 83352, -1183067993, 5297701479285813604L, 75380L, true, false, (char) 58713, (char) 42509,
        Double.longBitsToDouble(0x3fb490e3b10eb560L), Double.longBitsToDouble(0x3fe9a180ffc2c4baL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Double:0.08033583814422718 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 7, 1, 0, "\ud903\ude2e\uda10\ude16\uda9b\uddc5", "\u1fd3\ub451", "\ud980\udec4\u9848\u5900\ud82d\udf46\udbd3\ude1b\ud9fe\ude51",
        5, 73064, 266964191, -5290827710996850145L, 52182L, false, false, (char) 27839, (char) 62919,
        Double.longBitsToDouble(0x3fb490e3b586b560L), Double.longBitsToDouble(0x3fede900f9c2c4baL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:2147483647 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.08033583710376524 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 6, 7, 10, "\uda7c\udc2a\uda17\udec6\uda9b\uddc5", "\u62da\u3a62", "\udb66\udd1b\u3a19\u5900\ud973\udf27\uda16\udc60\ud9fe\ude51",
        55, 94349, -1271278609, -4759749567100067867L, 52182L, false, false, (char) 58100, (char) 13883,
        Double.longBitsToDouble(0x3fb490e3b10eb560L), Double.longBitsToDouble(0x3fe9a180fbc2c4baL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 0, 0, 9, "\uda7c\udc2a", "\u4907\000", "\udb64\udc9f\udaad\udcff",
        35, 40163, 139030659, 5914935297581506513L, -100000L, false, false, (char) 2908, (char) 46226,
        Double.longBitsToDouble(0x3e38000000000000L), Double.longBitsToDouble(0x3fd8aeb6100000aaL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:2147483647 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:4.2799891299258315E-134 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 6, 9, 9, "\uda7c\udc2a\uda17\udec6\uda9b\uddc5", "\u7dcf\u60bd", "\udb66\udd1b\u3a19\u5900\uda6e\udfd5\uda16\udc60\ud9fe\ude51",
        55, 42464, -1267364851, -4794450016633724955L, 52182L, false, false, (char) 11854, (char) 62919,
        Double.longBitsToDouble(0x3fb490e3b10eb560L), Double.longBitsToDouble(0x3fcc8603fb052cd8L)));
  }
  @Test
  public void test14() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test14() throws Throwable {
//     assertEquals("0=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Integer:1 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
//         Z.run(T, 2, 3, 10, 9, "\ud809\udc99\uda31\udc47\uda9b\uddc5\udb76\udf34\u8daa\ud81d\uddc6\ud85e\uddb3", "\u4da7\u9b36\u5504\u8947\u99ce\u7599", "\ud93b\udf99\ud895\udd31\ud89c\udec7\udbbc\ude72\ud911\uddbc\udb14\ude93\ud822\udf61\ud8b7\udcac\uda0f\udde2\u4159\udb04\uddb5\udb8b\udf97\uda6b\udd8f\udbeb\udcce\uda04\udde1\ud816\udfa3\ue27c\ud888\udfdb\ud8af\udd27",
//         47, 99397, -1676917621, 220947074534050444L, 59889L, false, true, (char) 30422, (char) 37437,
//         Double.longBitsToDouble(0x3fd0afb579a31a9eL), Double.longBitsToDouble(0x3fcf4aca60729e18L)));
//   }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Double:0.9608264907092189 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 7, 1, 9, "\uda7c\udc2a\uda17\udec6\uda9b\uddc5\udb76\udf34\u8daa\ud81d\uddc6\ud85e\uddb3\udb64\udc9f\udaad\udcff\udb66\udd1b\u3a19\udacc\udf36\ud99f\udfaf\udb02\uddd0", "\u2903\uca84", "\udbbc\ude72\ud911\uddbc\udb14\ude93\ud822\udf61\ud8b7\udcac",
        36, 80369, -994398412, -6588630182119500485L, 83235L, true, true, (char) 37049, (char) 34608,
        Double.longBitsToDouble(0x3feebf1732573fd7L), Double.longBitsToDouble(0x3febe39046cf8276L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 4, 1, 9, "\udae7\udf72\uda17\udf14\udaa7\udd85", "\u7dcf\u17e0\u2adc\ua2ac\ua1d2\u32b7\u4a55\u039b\u9246\u7599\uab31\uc999\ub989\u0241\u08ff\u133a\ua97d", "\ucb0a\udba8\udc2e\u40f7\uda78\udd3c\udb19\udd82\udb1d\udd3f\ud810\udeca\ud95b\udf20\uda92\udd91\uda2c\udc33\udb97\udfcd\uda1b\udf0d",
        17, 71212, -47037868, 7161447328274616940L, -56094L, false, true, (char) 52163, (char) 52054,
        Double.longBitsToDouble(0x3fef0db1a0a3d4dbL), Double.longBitsToDouble(0x3fdc6a067941e5e6L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 4, 9, 0, "\uda7c\udc2a\ud9ca\udd9e\udbe6\udd5f", "\ud5ce\u4f4e\u19f9\u3b4b\ub0c2\u32b7\u0ec7\u039b\u9a33\u854c\u5055\u2903\u3dc1\u0320\u61b5\u0573\ua97d\uc674\u7f57\u87d9\u4f57\u2f2a\ub0a9\u689f\u7597\u7d13\ub8ca\ucf46\ub3aa\uc0c9\uc23b\uaa04\u942c\u8556\u52fb\u4db8", "\ud878\udf46\udb31\udc4d",
        -1, 24858, -871739652, -1974833462976160765L, 60466L, true, false, (char) 49223, (char) 14396,
        Double.longBitsToDouble(0x3fe25d41e708d68bL), Double.longBitsToDouble(0x3fe1348e1a309588L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Double:7.062010350839087E-74 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 9, 4, 7, "\uda7c\udc2a\ud875\uddd5\uda9b\uddc5", "\u7dcf\u60bd\032\u509e\ub0c2\u32b7\u5214\u3774\u8e24\u7599", "\udbf3\ude95\ud913\udca8\uda9a\udc31\ud994\udceb\ud885\uded7\udb14\ude93\ud805\uddac\udb79\udd7e\uda12\udea0\u40f7\udb2e\udfb5\ud8ba\ude4f\uda22\udc86\uda2f\udf15\ud988\ude32\ud80c\udd0e\uda0a\udea5\ud83d\udf09\udad1\udc58",
        37, 40339, -959982424, -1101997174513475560L, -51497L, true, true, (char) 31962, (char) 18458,
        Double.longBitsToDouble(0x3fc3db134388e8b8L), Double.longBitsToDouble(0x3fe1b51facd85002L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Double:0.08033583710376524 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Integer:0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 7, 10, 13, "\uda7c\udc2a\uda17\udec6\uda9b\uddc5", "\u7dcf\u60bd", "\udb66\udd1b\u3a19\u5900\ud973\udf27\uda16\udc60\ud885\uddf6",
        40, 42549, -1267338629, -4794450016633724955L, 52182L, false, false, (char) 11854, (char) 62919,
        Double.longBitsToDouble(0x3fb490e3b10eb560L), Double.longBitsToDouble(0x3fe9a180fbc2c490L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 1, 1, 7, 2, "\uda7c\udc2a\uda17\udec6\uda26\udd2a", "\u89f6\u60bd\u2adc\u18f1\u4aec\u32b7\u134e\u1fcf", "\ud9fa\udf6b\udaa6\udd80\ud836\ude58\ud87e\udf24\ud89c\udec7\udbbc\ude72",
        48, 76672, -2104392, 4868100981259024466L, 31428L, true, true, (char) 8392, (char) 45175,
        Double.longBitsToDouble(0x3fea56dae1a30b0eL), Double.longBitsToDouble(0x3fec54b02eceefc9L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 8, 12, 9, "\uda7c\udc2a\uda17\udec6\uda9b\uddc5", "\u7dcf\u60bd", "\udb66\udd1b\u3a19\u5900\ud973\udf27\uda16\udc60\ud9fe\ude51",
        55, 42464, -1267364851, -4794450016633724955L, 52182L, false, false, (char) 11854, (char) 62919,
        Double.longBitsToDouble(0x3fb490e3b10eb560L), Double.longBitsToDouble(0x3fe9a180fbc2c4baL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 8, 13, 0, "\udbd4\udd98\uda17\udec6\ud855\udf81\udb57\udfc5\udbd9\udfd4\ud802\udcc2", "\u93e6\ub0c2\u916d\u913c\u039b\u9a33\u6c38\u3fee\u60ec\u3c4e\u695d\u6c3a\u1294\u869f\u9df4", "\uda0f\udde2\u40f7\udb2e\udfb5\ud826\uddd8\uda12\udc01\uda0b\udced\udb0b\udf3a\ud9e7\ude37",
        12, 28014, -625957002, 4345072160572215888L, -69849L, true, false, (char) 19958, (char) 25799,
        Double.longBitsToDouble(0x3fc896b15f9ae7a4L), Double.longBitsToDouble(0x3fb4c38cd1ebc8d0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NotStrictlyPositiveException\012",
        Z.run(T, 1, 0, 13, 0, "\000", "\000", "\udbd8\uddb0",
        10, -1000, 6408704, 8718968878728310915L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 8, 1, 9, "\uda7c\udc2a\uda17\udec6\uda9b\uddc5", "\u7dcf\ua26b\u94e2\u9e6c\ub143\u32b7\u4a55\u039b", "\uda7c\udc41\ud93f\udce7\ud93b\udf99\ud895\udd31\ud89c\udec7\udbbc\ude72",
        5, 48204, -48831603, 4868101685633661010L, -38917L, true, false, (char) 57048, (char) 6727,
        Double.longBitsToDouble(0x3fca30d6ac304344L), Double.longBitsToDouble(0x3fd9622bf5e849d6L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:1.2331071941318328E-8 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 12, 8, 7, "\uda7c\udc2a\udbeb\udfbd\uda94\udff5", "\ud6c1\u6a14", "\udb66\udd1b\ud907\ude35\u5900\ud973\udf27\uda16\udc60\ud9fe\ude51",
        -2, 42636, -1267364851, 313287901094764517L, 52182L, false, false, (char) 11854, (char) 62919,
        Double.longBitsToDouble(0x3fb490e3b10eb560L), Double.longBitsToDouble(0x3fe9a180fbc2c4baL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!org.apache.commons.math.exception.NotStrictlyPositiveException\012",
        Z.run(T, 2, 8, 3, 0, "", "", "\u8cf1\ud81d\uddc6\ue1c0",
        35, -1000, -362690048, 1043816054784L, -42703L, false, false, (char) 58367, (char) 110,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fef2de803aaa92eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 4, 4, 0, "\uda7b\udfc4\uda17\udec6\uda9b\uddc5", "\u7dcf\u60bd", "\udb66\uddaa\u3a19\ud96b\udd69\uda93\udfd8\ud946\udef8\ud9fe\ude16\uda7c\udc41\uda8a\udda0\udaca\udf40\uda2d\udcec\ud89d\udff4",
        37, 92634, -1944769492, -8808104539263955031L, -70848L, true, false, (char) 12328, (char) 5273,
        Double.longBitsToDouble(0x3fda3e4dc0011108L), Double.longBitsToDouble(0x3feb2ea6c537e824L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:4.2799891299258315E-134 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 8, 9, 9, "\uda7c\udc2a\uda17\udec6\uda9b\uddc5", "\u7dcf\u60bd", "\udb66\uddac\u3a19\u5900\ud99f\udf12\uda16\udc60\ud9fe\ude51",
        55, 42464, -1267364851, -4794450016633724955L, 99237L, false, true, (char) 11683, (char) 62919,
        Double.longBitsToDouble(0x3fb490e3b10eb560L), Double.longBitsToDouble(0x3fe89980fbc2c4baL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Double:0.9999999999999304 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:1.8420010749501897E-12 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 4, 9, 0, "\udae1\udd2c\uda75\udfd5\udbdb\udd3d", "\u12db\u4471\u2a6e\u93e6\ub0c2\u32b7\u4a55\u039b\u9a33\u7599\uab31\u2903\uca84\u0241\u08ff\u133a\ua97d\u4ec5\u7a2d\ud01c\u4f57\uc716\u6282\u5d41\u4329\ud60c", "\uda0d\udd1d\ud920\udd82\u9c59\ud816\udd94\udaf8\udf0d\udae2\udc41\ud85d\ude6c\ud9a4\uddac\ud80b\udf47\ud9c7\udcbe\ud87c\udd2e\udb39\udf4f\udb55\udd1d\uda5c\udce9\ud903\udc86\udb3f\udc5a\ud962\ude87\ud8ca\udffe\udb9b\udc72\ud974\udda2",
        11, 13812, 1395165083, 8316912516655259367L, 23099L, true, false, (char) 59767, (char) 51421,
        Double.longBitsToDouble(0x3fdc08e5eeedeb5cL), Double.longBitsToDouble(0x3fb430ecf48197b8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Double:0.003342951012975104 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 8, 2, 5, "\uda7b\udfcb\uda17\udec6\udb01\uddb6\uda87\udfe3\ud988\udc03\u1db9\uda05\udc17\ud84e\udf60", "\u0148\u7533\u39cd\u00fc\u86b0\u7264\u9836\uc684\uc618\u50bb\u7eac\u39f6", "\udaa8\uddf2\udaa0\ude68",
        -2, 34938, 421849682, 7101184978949505426L, 27735L, false, true, (char) 8141, (char) 34561,
        Double.longBitsToDouble(0x3fe32aae923e1dcfL), Double.longBitsToDouble(0x3fd34521ec7ee27cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Double:3.858025010572419E-14 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:3.858025010572419E-14 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 6, "\uda7c\udc2a\ud8bf\udcbf\u00f4", "\000", "",
        -5, 32412, -266817188, -8809064758291781717L, -59826L, true, false, (char) 25600, (char) 55899,
        Double.longBitsToDouble(0x3fdbe823b1fc8a56L), Double.longBitsToDouble(0x3fed5549758aeb61L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 4, 4, 5, "\uda98\udf1e\uda1a\udff6\uda93\udd43\ud9f0\udf5b\ud9c1\udd81\000\u1002\ud9d3\udfbd\ud105\ud825\udd5a\ud8fd\udd30\uda2a\udcbc\udab3\udf91\udb61\ude4f\udbe6\udcd6\ud834\udc34\ud94f\uddc7\ud918\udfc0\ud8c7\udd2a\ud884\udfc7\udbc9\udf98\ud883\udfd8\ud80f\ude5d\ud864\udde3\ud94a\udca8\ud923\ude0f\uda53\udd9c\ud9f8\udfe5\u4ddc\ud99e\udd94\udafa\udcfb\uda26\udcf4\u3887\uda78\udc67\udbb1\udd2d\uda00\udef2\udbe5\ude07\uda2a\uddbb\udaa3\udf87\udb17\udcf3\ud98b\udc40\udbd4\udd96\uda96\udc41\ud9b3\udc8a\udb63\udf15\udb75\ude95\uda18\udece\ud881\udc7c\ud9ae\udca3\uda0c\udfad\ud931\udc25\u7c27\ud98f\udd07\ud96c\udfdd\uf4f2\ud9f2\ude28", "\u50e7", "\udb67\ude7c\ud9b5\uddbc",
        22, 12293, -1476383314, 8258594919396750462L, -58845L, false, false, (char) 14574, (char) 2162,
        Double.longBitsToDouble(0x3fd76a45c90ad532L), Double.longBitsToDouble(0x3fe29b93d10bd83cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Double:0.07864511018897868 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 1, 8, 5, 4, "\uda7c\udc2a\uda17\udec6\u8ef4\000\ud9dd\udd93\uda56\udf99\011\udbc9\udc23\udaad\udcc1", "\u6d00\u034a\u9a33\u65ff\u05c1\u2bfd\uca84\u4b7c\u53ec", "\ud9f6\udec3\ud9b4\ude70\uda88\uddab\ud8e0\udf93\ucf50\udad1\udfd8\udb4a\udd01\ud976\udfad\ud8d7\udd96\ud9c3\udd3a\udbbc\udee7\udaa1\ude36\ud877\udff7\uda08\udfbc\ud966\uddfa\udb7e\udf8f\ud925\udce8\ud949\udd2e",
        -1, 73191, 738532093, -3952290505588242732L, 62696L, true, false, (char) 56561, (char) 2170,
        Double.longBitsToDouble(0x3fdf94e58506b43aL), Double.longBitsToDouble(0x3feb1cd97276fce0L)));
  }
  @Test
  public void test34() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test34() throws Throwable {
//     assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Integer:0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
//         Z.run(T, 2, 10, 10, 5, "\uda7c\udc2a\uda17\udec6\u00f4\000\ud9cf\udca7\udad2\udcd4\000", "\ub12a", "\ud973\uded6\uda16\udc60\ud9fe\ude51",
//         58, 91884, -1377513469, 5456998864944900976L, 75498L, false, false, (char) 31106, (char) 64361,
//         Double.longBitsToDouble(0x3fc6bdc17eec55d8L), Double.longBitsToDouble(0x3fb2870bae273610L)));
//   }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Double:0.9941023015950933 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.028859840105370318 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 4, 9, 0, "\uda7c\udc2a\uda17\udec6\uda9b\uddc5\udb76\udf34\u8daa\uda00\ude1c\ud810\ude99\udb1a\udee3\ud8c8\udd0a\udb48\ude32\u3a19\u5900\ud973\udf27\uda16\udc60\ud9fe\ude51\uda7c\udc41\uda8a\udda0\ud93b\udf99\udb9f\udefa\udab0\ude3c\udbbc\udeaa\ud911\uddbc\udb14\ude93\ud822\udf61\ud8b7\udcac\uda0f\udde2\u40f7", "\uce35\uacd2", "\udbe5\udfdd\uda03\uddfe\uda3f\udd82\ud9b0\udd31\udbc9\udf02\udbb8\udf17\ud8ba\udfce\ud8cb\udf97\udb18\udec5\udabf\udf52\ud908\ude5a\udb37\udd26\uda72\udddf\uc25f\udb0d\udde0\udb04\udc1f",
        3, 97327, -1606844535, -905085784226951394L, -26597L, false, false, (char) 20048, (char) 47103,
        Double.longBitsToDouble(0x3fe68fae62e4fcb3L), Double.longBitsToDouble(0x3fdf43559a322b92L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 4, 1, 9, "\uda7c\udc2a\uda17\udec6\udb99\uddc4", "\ua4a0\u60bd", "\udb66\udd1b\ud9c6\udc14\u5900\ud973\udf27\uda16\udc60\ud9fe\ude51",
        55, 42464, 0, -7782220157656784968L, 52182L, false, false, (char) 11854, (char) 62919,
        Double.longBitsToDouble(0x3ec1d80000000000L), Double.longBitsToDouble(0x3fe9a180fbc2c4baL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Double:1.0188066339396273E-12 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:1.0188066339396273E-12 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 9, 9, 1, "\ud909\udfb2\udbab\udc17\uda9b\uddc5\udb76\udf34\u8daa", "\ua376\u0804\ub0c2", "\ud973\udf27\uda16\udc60\ud9fe\ude51\uda7c\udc06",
        14, 83149, -1795178492, -6702588008133973022L, 84108L, true, true, (char) 64165, (char) 7929,
        Double.longBitsToDouble(0x3fecb2e43f34f362L), Double.longBitsToDouble(0x3fee1625d3c03d66L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Double:0.9997932007469282 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 4, 1, 2, "\ud8dc\udd36\ud9ab\udee7\uda9d\ude41\ud9a9\udf1b\ud8ad\ude20\udb25\uddea\ud9f4\uddfd\udb64\udc9f\udac0\udcff\udb66\udd1b\udb85\ude98\u592d\ud973\udf27\uda16\udc60\udaff\udfdc\udb63\uddaf\ud86f\udc12\udbbb\udf8a\udad2\uddb5\udab0\ude3c\ud99b\udf9a\ud911\uddbc\udbf7\udc16\ud821\udf5c\udbc5\ude12\uda0f\udde2\u40f7\udb2e\udfb5\udaa5\ude24\uda02\udfe6\uda2d\ude6f\udbae\udca8\ud965\ude93\ud907\udc7a\udb08\udc00\ud822\udc92\uda78\udf9a\ud922\udcb5\u12cc\u925d\ud89a\ude7f\udafc\udff5\uda19\ude33\udb39\udf46\udbeb\udea3\ud98b\ude42\uda88\udee8\ud9e3\ude66\ud936\udf12\ud802\udc35\uda83\udf82\ud909\udc51\ud83c\udc3b\udb6c\ude58\ud970\udfb8\u4d3a\udab5\uddac\ua51d\uda24\udf43\udacd\udf5e", "\u1d5a\u7235\u41a6\u679c\u3233", "\ud9bb\udd3c\ud86f\udf05\udb58\udd77\ud959\ude99\udb49\ude65\uda49\udfd9",
        4, 12486, -1754977565, 2123491154460957721L, 14240L, false, true, (char) 37576, (char) 27615,
        Double.longBitsToDouble(0x3fe0a781bffa74beL), Double.longBitsToDouble(0x3fecbbf9827ed21dL)));
  }
  @Test
  public void test39() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test39() throws Throwable {
//     assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Integer:0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
//         Z.run(T, 2, 10, 10, 11, "\uda7c\udc2a\uda17\udec6", "\u11fc\u778f\u60bd", "\udb66\udd1b\u3a19\u5900\ud973\udf27\uda15\udfa0\ud9fe\ude51",
//         55, 42464, -1267364851, -7710232915183165512L, -72168L, false, true, (char) 57823, (char) 51660,
//         Double.longBitsToDouble(0x3fe9a180fbc2c4baL), Double.longBitsToDouble(0x3fe8d953c424b34fL)));
//   }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 3, "\uda7c\udc2a\u0084\uda9b\uddc5", "\u3b1a\000", "\udb69\udd43\u3a19\uda42\udc02",
        29, -1000, 0, 2135890432L, -14269L, true, true, (char) 43310, (char) 39147,
        Double.longBitsToDouble(0x3fe1601aab8d4ac1L), Double.longBitsToDouble(0x3fe6efe8b000a91eL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Double:4.2799603971962063E-134 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:4.2799603971962063E-134 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 9, 9, 4, "\uda1f\udc3c\ud8d3\udd3d\uda9b\uddc5", "\u7dcf\u60bd", "\udb66\udd1b\ud9d6\udf9d\udb66\udee1\ud87c\udf6d\uda18\udc18\ud9fe\ude51",
        55, 48704, -1264612339, 3961392083912176423L, 46593L, true, false, (char) 51676, (char) 42163,
        Double.longBitsToDouble(0x3fb490e386e15d60L), Double.longBitsToDouble(0x3feac180fb2957baL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 12, 8, 13, "\udaac\udc63\udb35\udff4\ud84d\udc22\udacd\udd66\u8cf1\ud81d\uddc6", "\u93e6\ua6c2\u3b4e\000\u034a\u9a33\u27f7\uab31\u2903\uca84\u9b9a\u0d01\u133a\uad8a\000", "",
        36, 80369, -994398412, -4778464606984929883L, 99940L, true, false, (char) 59593, (char) 27466,
        Double.longBitsToDouble(0x3fec3f0d77bc1062L), Double.longBitsToDouble(0x3fe1936679fc3405L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Double:0.9791203582283219 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.9791203582283219 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 13, "\udaac\udc63\udb35\udff4\ud84d\udc22\udb76\udc3a\u8daa\ud81d\udddb", "\u93e6\ua6c2\u2167\u1ef1\u039b\u9a33\u27f7\uab31\u2903\uca84\u9b9a\u0d01\u17f5\u2404\u4f09", "\ud8af\udca1\u40f7\udb2e\udfb5\uda0d\udfd9",
        2, 98167, 1941900548, -2418227543681725863L, 8409L, false, true, (char) 5833, (char) 26113,
        Double.longBitsToDouble(0x3fe7ce8852904cddL), Double.longBitsToDouble(0x3fb178b205b48828L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 12, 8, 13, "\udaac\udc63\udb35\udff4\ud84d\udc22^\000\udae2\uddb1", "\ua93e", "\u5900\ud973\udf27\uda16\udc60\u05b5\uda7c\udc41\uda90\ude24\000\udb74\udd1a\udba9\ude5b",
        37, 92634, 1254166060, -209730136762812239L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4410de80000000L), Double.longBitsToDouble(0x3ec7e80000000000L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Double:0.5639970207020837 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.671447935193068 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 8, 9, 13, "\udaac\udc63\udb35\udff4\ud84d\udc22\udb3e\udc3a\u8daa\ud81d\uddc6", "\u93e6", "\u5900\ud973\udf27\uda16\udc60\u05b5\uda47\ude41\ud85c\uddca\ud956\ude46\uda5f\uddd5\ud995\ude10",
        0, 87885, 1254178838, -209730136762812239L, -70849L, true, false, (char) 43992, (char) 46203,
        Double.longBitsToDouble(0x3fd97e0e24086f40L), Double.longBitsToDouble(0x3fe6eb9bf259de70L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 1, 8, 1, 9, "\uda60\udf9e\uda17\udec6\uda9b\uddc5", "\u7dcf\u60bd\u2adc\u93e6\u9059\u32c3\u4a55\uc073\u9a33\u7599\u1a93\u7114\u07f3\u0241\u08ff\u9b56\ua97d\u52c6\ub718\u18c3\u4f57\u2f2a\u4e08\u5d27\u4bb7\u1cb8", "\udb35\udfdd\ud99c\ude9d\udaa8\udd2a",
        26, 30294, 87714947, 2092246658775550756L, -36230L, true, true, (char) 44626, (char) 42712,
        Double.longBitsToDouble(0x3fde726acbb99a5cL), Double.longBitsToDouble(0x3fe9088d9434c013L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udb94\uddda\ud9ca\ude03\udbe6\udd5f", "\ud5ce\u4f4e\u19f9\u3b4b\ub0c2\u32b7\u0ec7\u039b\u9a33\u854c\u5055\u2903\u3dc1\u0320\u61b5\u0573\ua97d\uc674\u7f57\u87d9\u07a2\u2f2a\ub0a9\u689f\u7597\u7d13\ub8ca\ucf46\ub3aa\uc0c9\uc23b\uaa04\u942c\u4774\u52fb\u4db8", "\ud878\udf46\udb31\udc4d",
        -1, 24858, -871739652, -1974833462976160765L, 60466L, true, false, (char) 49223, (char) 14396,
        Double.longBitsToDouble(0x3fe25d41e708d68bL), Double.longBitsToDouble(0x3fe1348e1a309588L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 9, 9, 2, "\uda7c\udc2a\udbeb\udfbd\uda94\udff5", "\ud6c1\u6a14", "\udb66\udd1b\ud907\ude35\ud825\udd66\u2e17\ud870\udead\ud9fe\ude51",
        -2, 42636, -1267364851, 313287901094764517L, 52182L, false, false, (char) 11854, (char) 50197,
        Double.longBitsToDouble(0x3fd332a9cdb583a2L), Double.longBitsToDouble(0x3fe9a180fbc2c4baL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Double:0.7436519011275408 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.3677935326683329 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 4, 9, 0, "\udae1\udd2c\uda75\udfd5\udbdb\udd3d", "\u12db\uc5a1\u2a05\u4cca\ucedc\u32b7\u4a55\u3601\u9a33\u2c95\u6079\u2903\uca84\uc35f\u979d\u7734\u29f6\u4f2c\u7a2d\ud01c\u4f57\uc716\u6282\u5d41\u4ab6\ud60c", "\udb16\udcee\udb33\udd9c",
        1, 1263, -437588358, 2579916818341533842L, 77549L, true, false, (char) 16593, (char) 26771,
        Double.longBitsToDouble(0x3fef50392bbc8ca7L), Double.longBitsToDouble(0x3fda8d01eb5ee918L)));
  }
  @Test
  public void test50() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test50() throws Throwable {
//     assertEquals("0=java.lang.Integer:4 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
//         Z.run(T, 2, 10, 13, 5, "\ud9a9\udca1\ud93a\udda3\u00f4", "\u33a2\ua376\ud331\ub553\u336d\u1712\u4a55\u034a\u9a33\ua676\ubef4\u65f1\u6b9e\u0c2a\u63a0\u4c69", "\ud950\udf85\udaca\udeab\ud8f0\uddb1\uda7c\udcf1\ud966\udc0b\uda47\udccb\udb3b\udf8a\ud8d8\udef8\udaf2\udc91\udb82\ude13",
//         54, 44958, 812647158, -5827528040854956374L, -30732L, true, true, (char) 18487, (char) 38508,
//         Double.longBitsToDouble(0x3fef7304ddeb5a8cL), Double.longBitsToDouble(0x3fc242ad90e2cae0L)));
//   }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 3, "\uda7c\udc2a\u0084\uda9b\uddc5", "\u3b1a\000", "\udb69\udd43\u3a19\uda3d\udff9",
        28, 26856, -1927938967, -4226238220734486425L, -4797L, true, true, (char) 43310, (char) 39147,
        Double.longBitsToDouble(0x3fe1601aaf8d4ac1L), Double.longBitsToDouble(0x3fd984b610a37694L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Double:0.07422866395291838 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.07422866395291838 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 3, "\uda7c\udc2a\u0084\uda9b\uddc5", "\u3ad7\u4118", "\udb69\udd43\ud84b\ude70\uda41\udfa6\ud8d7\udc4d\000\000",
        -1, 89737, -1268277199, -4794450016633724955L, -49925L, false, false, (char) 11854, (char) 15909,
        Double.longBitsToDouble(0x3fd518fa41497a82L), Double.longBitsToDouble(0x3fd79538ffaa466cL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Double:0.671447935193068 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.671447935193068 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 9, 9, 13, "\udaac\udc63\udb35\udff4\ud84d\udc22\udb3e\udc3a\u8daa\ud81d\uddc6", "\u93e6", "\u5900\ud973\udf27\uda16\udc60\udbd8\udc0f\uda47\ude41\ud85c\uddca\ud956\ude46\uda5f\uddd5\ud995\ude10",
        0, 87885, 1254178838, -209730136762812239L, -70849L, true, false, (char) 43992, (char) 46203,
        Double.longBitsToDouble(0x3fd97e0e24086f40L), Double.longBitsToDouble(0x3fe6eb9bf259de70L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 12, 3, 4, "\uda7c\udc2a\uda17\udec6\uda9b\uddc5", "\u7dcf\u60bd", "\udb66\udd1b\u3a19\u5900\ud973\udf27\uda0d\ude60\ud9fe\ude51",
        55, 42464, -1267364851, -4794450016633724955L, 52182L, false, false, (char) 11854, (char) 62919,
        Double.longBitsToDouble(0x3fd44e522c43ad58L), Double.longBitsToDouble(0x3fe9a180fbc2c4baL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Double:0.9982410315777722 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.9982410315777722 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 4, 4, 5, "\ud8ed\udce6\uda1a\udff6\uda93\udd43\ud9f0\udf5b", "\u4028", "\ud825\udd5a\ud8fd\udd30\uda2a\udcbc\udab3\udf91\uda0f\udd65\udb36\udfdf\ud834\udc34\ud94f\uddc7\ud918\udfc0\ud8c7\udd2a\ud884\udfc7\udbc9\udf98\ud883\udfd8\ud8f4\udd8d\ud864\uddf0",
        4, 11514, -1473922358, 3169163381426247357L, -27516L, false, true, (char) 23885, (char) 37400,
        Double.longBitsToDouble(0x3feaef7b3a5d9711L), Double.longBitsToDouble(0x3fa184f4f8c20250L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Double:0.7877445287878984 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.3638106335503034 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 4, 9, 0, "\udae1\udd2c\uda75\udfd5\udbdb\udd3d", "\u12db\uc5a1\u2a05\u4cca\ucedc\u32b7\u4a55\u3601\u9a33\u2c95\u6079\u412a\uca84\uc35f\u979d\u7734\u29f6\u4f2c\u3bca\u5bbc\u947a\uc716\u6282\u3670\uc3ac\ud60c", "\udbf5\udfd4\udb36\udf0b",
        1, 1263, -1813621382, -8138929201386514338L, 77549L, true, false, (char) 16593, (char) 26771,
        Double.longBitsToDouble(0x3feb76312bbcd82bL), Double.longBitsToDouble(0x3fda8d01eb5ee918L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Double:0.07820681441867328 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.07820681441867328 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 8, 8, 3, "\udaf0\udfa4\ud8dc\udcb1\uda33\udf11", "\u9420\ua34e", "\udb69\udd43\ud83a\ude72\uda41\udfa6\ud8d7\udc4d\000\ud91c\udc0d",
        -1, 89737, -633364431, -4794538913866817563L, -49933L, false, false, (char) 54850, (char) 39794,
        Double.longBitsToDouble(0x3fdc13e9f1497a82L), Double.longBitsToDouble(0x3fd79538fa6a7bfeL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Double:0.3677935326683215 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.3677935326683215 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 9, 9, 0, "\udae1\udd2c\uda75\udfd5\udbdb\udd3d", "\u6eda\u09c7\uc6ab\u3ae0\u204a\u2788\u75e9\u0cfa\u5a7e\u2c69\u6079\u0182\u758e\uc3e7\u979d\u7734\u29f6\u4f2c\u7a1d\u4a7b\u7623\uc716\u16c6\u04c7\u4ab6\ud60c", "\udb16\udcee\udb33\udd9c",
        1, 1263, -437588358, 2579916818341533842L, 77549L, true, false, (char) 16593, (char) 26771,
        Double.longBitsToDouble(0x3fef50392bbc5aa7L), Double.longBitsToDouble(0x3fda8d01e0fd3c18L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 4, 4, 5, "\uda98\udf1e\uda1a\udff6\uda93\udd43\ud9f0\udf5b\ud9c1\udd81\000\u1002\ud9d3\udfbd\ud105\ud825\udd5a\udab4\ude33\uda2a\udcbc\udab3\udf91\udb61\ude4f\udbe6\udcd6\ud834\udc34\ud94f\uddc7\ud918\udfc0\ud8c7\udd2a\ud884\udfc7\udbc9\udf98\ud883\udfd8\ud80f\ude5d\ud864\udde3\ud94a\udca8\ud923\ude0f\uda53\udd9c\ud9f8\udfe5\u4ddc\ud99e\udd94\udafa\udcfb\uda26\udcf4\u3887\uda78\udc67\udbb1\udd2d\uda00\udef2\udbe5\ude07\uda2a\uddbb\udaa3\udf87\udb17\udcf3\ud98b\udc40\udbd4\udd96\uda96\udc41\ud9b3\udc8a\udb63\udf15\udb75\ude95\uda18\udece\ud881\udc7c\ud9ae\udca3\uda0c\udfad\ud931\udc25\u7c27\ud98f\udd07\ud96c\udfdd\uf4f2\ud9f2\ude28", "\u50e7", "\udb67\ude7c\ud8be\uddbd",
        22, 12293, -1476383314, 8258594919396750462L, -58845L, false, false, (char) 55032, (char) 2162,
        Double.longBitsToDouble(0x3fd76a45c90ad532L), Double.longBitsToDouble(0x3fe29b93d10bd83cL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:1.0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 0, 4, 8, "\000\udb35\udff4\ud84d\udc22^\000\udae2\uddb1", "\ua93e", "\u0083\ud96f\udcd6\u00d1\u0542\uda7c\udc41\uda90\ude24\000\udb74\udd1a\ud9ac\udf7c",
        31, 92634, 3628, -216172780980340559L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3dc0de8000000000L), Double.longBitsToDouble(0x3ec7e80000000000L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Double:0.36219145550394555 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.36219145550394555 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 9, 9, 0, "\udae1\udd2c\uda75\udfd5\udbdb\udd3d", "\u4be0\u09c7\uc6ab\u3ae0\u204a\u6900\u709a\u0d17\u5a7e\u2c69\u6079\u0182\u758e\uc3e7\u979d\u7734\u29f6\u7ae9\u82ea\u4a7b\u7623\uc716\u16c6\u04c7\u4ab6\ud60c", "\udb16\udcee\udb33\udd9c",
        1, 1263, -437588358, 2579916818341533842L, 64918L, false, true, (char) 29393, (char) 17609,
        Double.longBitsToDouble(0x3feaada491f29abeL), Double.longBitsToDouble(0x3fef1eb5807e9e0cL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 10, 13, 5, "\u00e0", "\u954d\ua0d8\ucb39", "\uda9d\udecc\udbd7\ude74\udbd8\ude76",
        9, 42112, -2117869615, 8358773615268724929L, 41325L, false, true, (char) 0, (char) 21674,
        Double.longBitsToDouble(0x3f4a2c2000000000L), Double.longBitsToDouble(0x3fd670000fd1c026L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=new org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 12, 1, 9, "\uda7c\udc2a\uda17\udec6\uda9b\uddc5", "\u7dcf\u60bd", "\udb66\udd1b\u3a19\u5900\ud973\udf27\udb99\udf3d\ud8af\udf7d",
        55, 42464, -1267364851, -4794450016633724955L, 52182L, false, false, (char) 49204, (char) 62919,
        Double.longBitsToDouble(0x3fb490e3b10eb560L), Double.longBitsToDouble(0x3fe54c008bc2c4caL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Double:0.7361509018780574 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\0121=java.lang.Double:0.3678792321510726 |this=org.apache.commons.math.distribution.PoissonDistributionImpl:@?\012",
        Z.run(T, 2, 4, 9, 0, "\udae1\udd2c\uda75\udfd5\udbdb\udd3d", "\u12db\uc5a1\u2a05\u4cca\ucedc\u32b7\u4a55\u3601\u9a33\u2c95\u6079\u2903\uca84\uc35f\u979d\u7734\u29f6\u218a\u83b0\ud01c\u4f57\uc716\u6282\u5d41\u4ab6\ud60c", "\udb16\udcee\udb33\udd9c",
        1, 10983, -437627361, 2579916818341533842L, 77549L, true, false, (char) 16593, (char) 26771,
        Double.longBitsToDouble(0x3feff7453bbc8ca7L), Double.longBitsToDouble(0x3fda8d01eb5ee918L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "C|org.apache.commons.math.distribution.PoissonDistributionImpl|<init>|double,int",
    "C|org.apache.commons.math.distribution.PoissonDistributionImpl|<init>|double,double",
    "C|org.apache.commons.math.distribution.PoissonDistributionImpl|<init>|double,double,int",
    "C|org.apache.commons.math.distribution.PoissonDistributionImpl|<init>|double",
    "M|org.apache.commons.math.distribution.PoissonDistributionImpl|cumulativeProbability|int|new:org.apache.commons.math.distribution.PoissonDistributionImpl:double",
    "M|org.apache.commons.math.distribution.PoissonDistributionImpl|getDomainLowerBound|double|new:org.apache.commons.math.distribution.PoissonDistributionImpl:double",
    "M|org.apache.commons.math.distribution.PoissonDistributionImpl|getDomainUpperBound|double|new:org.apache.commons.math.distribution.PoissonDistributionImpl:double",
    "M|org.apache.commons.math.distribution.PoissonDistributionImpl|getMean||new:org.apache.commons.math.distribution.PoissonDistributionImpl:double",
    "M|org.apache.commons.math.distribution.PoissonDistributionImpl|normalApproximateProbability|int|new:org.apache.commons.math.distribution.PoissonDistributionImpl:double",
    "M|org.apache.commons.math.distribution.PoissonDistributionImpl|probability|int|new:org.apache.commons.math.distribution.PoissonDistributionImpl:double",
    "M|org.apache.commons.math.distribution.PoissonDistributionImpl|sample||new:org.apache.commons.math.distribution.PoissonDistributionImpl:double",
    "C|org.apache.commons.math.distribution.PoissonDistributionImpl|<init>|double,int",
    "C|org.apache.commons.math.distribution.PoissonDistributionImpl|<init>|double,double",
    "C|org.apache.commons.math.distribution.PoissonDistributionImpl|<init>|double,double,int",
    "C|org.apache.commons.math.distribution.PoissonDistributionImpl|<init>|double",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
