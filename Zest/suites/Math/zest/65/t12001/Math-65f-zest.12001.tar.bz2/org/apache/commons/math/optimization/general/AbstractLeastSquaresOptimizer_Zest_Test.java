package org.apache.commons.math.optimization.general;
import org.junit.Test;
import static org.junit.Assert.*;
public class AbstractLeastSquaresOptimizer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!org.apache.commons.math.optimization.OptimizationException\012",
        Z.run(T, 1, 12, 2, 14, "\ud8ed\udf86\uda5f\udc6b\udafe\udddf", "\u8343\u05b9\u2a28\u5cee\u1d98", "\udb11\udf6c\ud930\udf15\ud926\udf6e\ud8d8\ude92\uda85\udc91",
        9, 68250, 889831243, -1474653413632843975L, 95228L, true, false, (char) 38111, (char) 58791,
        Double.longBitsToDouble(0x3fe1bfba88d6f9d9L), Double.longBitsToDouble(0x3fcaf8af6bb38d48L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.apache.commons.math.optimization.OptimizationException\012",
        Z.run(T, 1, 12, 2, 14, "\ud8ed\udf86\udbaf\udc5c\uda1d\ude3d\ud9b5\udf96", "\ub5ae\u4851", "\ud9dc\udfc1\ud8f3\udf90\udb11\udf6c\ud930\udf15",
        44, 70787, 1851196945, -2613284655981181011L, -93872L, true, true, (char) 60539, (char) 4971,
        Double.longBitsToDouble(0x3f56c46fbc8a0200L), Double.longBitsToDouble(0x3fe8e0408637f751L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 2, 9, "\ud86b\udf46\udbea\udd2d\udafe\udddf\ud972\udd5d\uda2d\udd97\ud8c9\ude40\ud884\udd54", "\u1d98\u2fb1\u167e\u5f7d\u07ce\u5607\u0a6b\u3105\u0d62\u3cb4\u5e27\u9247\u126a\u4211\u19d9\ubdc9\u2bd7\u1098\u0781\u7bf8\u3c2e\u56c6\u8809\uce1d\ub935\u8a49\u09f9\u3437\ud3ac\u7a52\u5e55\u4fe1\u3e34\u4a84\u4f01\ub720\u9725\u1ce9\u1b21", "\uda44\udf6a\udb6d\ude7c\ud820\ude97\uba85\ud888\ude8e",
        22, 56267, -952990600, -714631050501378274L, -27413L, true, false, (char) 35489, (char) 39389,
        Double.longBitsToDouble(0x3fea4939ad7fa275L), Double.longBitsToDouble(0x3fd7219da42dce5eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\012",
        Z.run(T, 1, 0, 2, 14, "\ud8ed\udf86\uda5f\udc6b\udafe\udddf", "\u46a4\u05b9\u01a7\u5cee\u1d98", "\udb11\udf6c\ud930\udf15\ud8eb\udfd2\ud961\udd9c\uda85\udc91",
        9, 68250, -1465185973, 6217128286127852219L, 95228L, true, false, (char) 38111, (char) 58791,
        Double.longBitsToDouble(0x3fe1bfba89e71fd9L), Double.longBitsToDouble(0x3fb646ad85c5bcc8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\012",
        Z.run(T, 1, 13, 2, 14, "\ud8e4\udea2\uda4c\udd5d\ud9bd\udfbe\ud9da\udd61\uda2d\udd86\ud8c9\ude40\ud884\udd54", "\ucec6\u3ccb\ucc64\u1f01\u04dc\u7e87\u0ad9\u78d7\u0d5b\ubfff\u81d5\u748f\u8b9f\u23df\ua2a5\ubdc9\u896c\u434e\u8eec\ua37a\u1ada\u4ae4\u2af7\u1b04\u03fd\u04e5\ua2eb\ucf2e\uc732\ubbd3\ud696\uaa6d\u4405\u75f2\u75d2\u313c\ucfa3\u98b1\u09ce", "\ud82d\udccb\u27c0\ud8cb\udde5\ud9ad\udcbb\udabb\udd5e\udaef\udf20\udb26\ude01\udb3c\uded5\ud8f0\udc0b\ub6b4\udbff\udc9f\udab4\udf0d\udbac\ude92\udb1e\udd6f\udabb\udd97",
        27, 67876, 875729893, 6832228529484807869L, 57149L, true, false, (char) 61490, (char) 11429,
        Double.longBitsToDouble(0x3fe9b1cfffc0b163L), Double.longBitsToDouble(0x3fc32f32aa2b80f0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.apache.commons.math.optimization.OptimizationException\012",
        Z.run(T, 1, 10, 13, 8, "\ud8ed\udf86\uda5f\udc6b\udafe\udddf", "\u8343\u05b9\u2a28\uaf6f\u1d98", "\udb11\udf6c\ud930\udf15\ud926\udf6e\ud8d8\ude92\uda85\udc91",
        9, 68250, 889831243, -1474653413632843975L, -78003L, false, true, (char) 20701, (char) 17072,
        Double.longBitsToDouble(0x3fcaf8af6bb38d48L), Double.longBitsToDouble(0x3fce12d51ad2b1f8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\012",
        Z.run(T, 1, 1, 13, 14, "\ud8ed\udf86\uda5f\udc6b\udafe\udddf", "\u01c6\u05b9\u2a28\u5cee\u1d98", "\udb11\udf6c\ud930\udf15\ud926\udf6e\ud8d8\ude92\uda85\udc91",
        9, 68250, 889831243, -1474653413632843975L, 95228L, true, false, (char) 38111, (char) 58791,
        Double.longBitsToDouble(0x3fe1bfba88d6f9d9L), Double.longBitsToDouble(0x3fcaf8af6bb38d48L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\012",
        Z.run(T, 1, 11, 11, 14, "\ud8ed\udf86\uda5f\udc6b\udafe\udddf", "\u8343\u05b9\u2a28\u5cee\u1d98", "\udb11\udf6c\ud930\udf15\ud926\udf6e\ud8d8\ude92\uda85\udc91",
        9, 68250, 889831243, -1474653413632843975L, 95228L, true, false, (char) 38111, (char) 58791,
        Double.longBitsToDouble(0x3fe1bfba88d6f9d9L), Double.longBitsToDouble(0x3fcaf8af6bb38d48L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 2, 14, "\ud8ed\udf86\uda5f\udc6b\udafe\udddf", "\u8343\u05b9\u2a28\u5cee\u1d98", "\udb11\udf6c\ud930\udf15\ud926\udf6e\ud8d8\ude92\uda85\udc91",
        9, 68250, 889831243, -1474653413632843975L, 95228L, true, false, (char) 38111, (char) 58791,
        Double.longBitsToDouble(0x3fe1bfba88d6f9d9L), Double.longBitsToDouble(0x3fcaf8af6bb38d48L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:100 |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 9, 15, 14, "\ud8d0\udf97\uda5f\udc5f\udafe\udddf", "\u4d42\u05b9\u2a28\u5cee\ube97", "\udb11\udf6c\ud930\udf15\ud926\udf6e\ud8d8\ude92\uda85\udc91",
        9, 26362, 903730675, -1474653413632843975L, 95228L, true, false, (char) 38111, (char) 58791,
        Double.longBitsToDouble(0x3fe1bfba88d6f9d9L), Double.longBitsToDouble(0x3fcaf8af6bb38d48L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!org.apache.commons.math.optimization.OptimizationException\012",
        Z.run(T, 1, 12, 10, 5, "\udbc7\udf34", "\uce10\u2726\u8343\u0c88", "\ud814\ude90\ud829\udef4",
        56, 44223, 1296736252, 3964255319030528713L, 14507L, true, false, (char) 20590, (char) 60539,
        Double.longBitsToDouble(0x3fde329cf92a317eL), Double.longBitsToDouble(0x3feef2280db40810L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\012",
        Z.run(T, 1, 14, 5, 14, "\ud8ed\udf86\uda5f\udc6b\udafe\udddf", "\u5381\u05b9\u2a28\u5cee\u3443", "\udb11\udf6c\ud930\udf15\ud926\udf6e\ud8d8\ude92\uda85\udc91",
        3, 68250, 889831243, -1474653410812364999L, 95228L, true, false, (char) 38111, (char) 58791,
        Double.longBitsToDouble(0x3fe1bfba88d6f9d9L), Double.longBitsToDouble(0x3fcaf8af6bb38d48L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 2, 15, "\uda83\udf7f\udb20\udc16\ud854\udcb0\ud897\uddde\uda2d\udd41\udb33\udd01\ueca9\udaee\uddbe\uda3f\uddc5\ud949\udc05\ud9dc\udfdf\udb81\ude58\u2f6e\ud930\uded4\ud926\udf6e\ud90f\udf87\udab4\udc10\ud6ea\ud95d\udd5d\ud893\udc1b\ud8c9\ude86\udac2\udc3e\ud907\udc59\ud9ee\udefd\u6828\udb04\udeed\u0f7e\ud89b\uddda\ud86d\udd63\udb9b\udeeb\u1b35\ud822\udddc\ud870\udcaf", "\ucda3\u1773\u0a37\u0375", "\udb52\udced",
        34, 12525, -217966093, -7994742273626231254L, -70645L, false, false, (char) 6798, (char) 58006,
        Double.longBitsToDouble(0x3fb5dd3dcd786638L), Double.longBitsToDouble(0x3fe8d5d9c4011e46L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!org.apache.commons.math.optimization.OptimizationException\012",
        Z.run(T, 1, 12, 5, 0, "\ud8ed\udf86", "\u6abe", "\ud884\udd54",
        42, 77595, 1231924881, 7897552103125559453L, -60975L, true, true, (char) 45358, (char) 50786,
        Double.longBitsToDouble(0x3feb9b72b8000000L), Double.longBitsToDouble(0x3fb2c00000000000L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=java.lang.Double:0.0 |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 1, 16, 10, "\ud8ed\udf86\uda1c\udf42\uda2b\uded3\udb32\uddeb\udbdd\udd0d\uda24\udce3\ud884\udd54\udb28\udc4b\udbeb\udead\udb14\udee4\ud9dd\udc40\ud8f3\udf90\ud94e\udd39\ud8d1\udda3\ud91d\udcc9\u0086\uda85\udc91\u4824\uda88\udd38\ud872\ude6b\udb8e\udd50\udac2\udc3e\ud858\udd01\uda04\udcfd\ud95c\ude48\uda9f\udea5\uc515\ud89b\uddda\ud86d\udd63\udbf0\udc55\ud867\udf98\uda23\udeae\ud98f\ude6b", "\u7072\u95b8\u8695\u2ffa\u8891\u00a8\uaf76\u8dd8\uc3f4\u6131\ub1bf\ud771\u163d\u46fa\u4197\ub192\u5fe3\u3374\u15ec\u2be9\uc862", "\ud828\udd3b\ufbad\ud863\udfa0\uda07\udf1b\udbfd\udfde\uda94\udded\ud838\udf35\ud8ab\udc57\udb2d\ude8f\ud842\udff2\ud917\udfa5\udbf0\ude7c\uda2b\uddfc\udb44\udf07\ud96e\udc6a\ud9f3\udc32\ud998\udd82\udbdb\udc35",
        55, 81775, -270054024, 190643044263092910L, -83299L, true, false, (char) 46776, (char) 62145,
        Double.longBitsToDouble(0x3fe95d602e67aeedL), Double.longBitsToDouble(0x3fef1cb2fba9e2beL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 4, 7, "\ud8ed\udf86\uda5f\udc6b\udafe\udddf\ud830\ude1b\ud9fe\udeb3\ud8c9\ude40\uda32\ude54", "\u5a7b\u2fb1\ucc64\u4101\u462a", "\ud892\udd21\u4824\uda88\udd38\udb1a\ude56\ud8c7\udc0a\udac2\udc3e\ud907\udc59\ud9f3\ude16\ud8a7\udd4e\uda81\udc34\uda66\udc84\ud89b\ude98\uda96\udf93\ud8c6\ude63\udbd2\udd2b\ud97d\udf35\ud811\udc6b\ud89e\udf52\udb6a\ude78\u84d9\ud832\udc1d",
        7, 16290, -829131158, -3168541425083671506L, -59527L, true, false, (char) 24539, (char) 19165,
        Double.longBitsToDouble(0x3fb5c304f7cccfa0L), Double.longBitsToDouble(0x3fe18e6b06905cb6L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 14, "\ud8ed\udf86\ud89f\udc6b\ud8d2\udc15", "\u1da2\u44cc\u2a28\ud7ab\u8e7b", "\udb22\udeef\ud9f6\ude04",
        11, 70787, 1851196945, 845479855957444362L, 63557L, true, false, (char) 60539, (char) 32895,
        Double.longBitsToDouble(0x3fe80d8b47de4501L), Double.longBitsToDouble(0x3fd98aab3c6feea2L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 2, 14, "\u641d", "\000", "",
        -5, 61801, 1027349504, 5291077076862483915L, -87413L, true, false, (char) 29657, (char) 45358,
        Double.longBitsToDouble(0x3fe08e028f736e57L), Double.longBitsToDouble(0x3fd0a0bbbe96062eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Double:0.0 |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=!org.apache.commons.math.optimization.OptimizationException\012",
        Z.run(T, 2, 0, 12, 14, "\ud90a\udf6f\uda5f\udc6b\udafe\udddf", "\u46a4\u05b9\u01a7\u5cee\u1d98", "\udb11\udf6c\ud930\udf15\ud8eb\udfd2\ud961\udd9c\ud9dd\udf63",
        35, 40994, -1465185973, 6217128286127852219L, 95157L, true, false, (char) 254, (char) 28584,
        Double.longBitsToDouble(0x3fe7fa366ee71fd9L), Double.longBitsToDouble(0x3fdbd0e761716f32L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 15, 13, 8, "\ud8ed\udf86\uda5f\udc6b\udafe\udddf", "\u560c\u05b9\u2a28\u8393\u1d98", "\udb11\udf6c\ud82a\udf12\ud857\ude06\ud8d8\ude50\uda85\udc91",
        9, 68250, 889831243, -1474653413632843975L, -78003L, false, true, (char) 20701, (char) 44285,
        Double.longBitsToDouble(0x3fcc3ba1ebb38e04L), Double.longBitsToDouble(0x3fce12d51ad2b1f8L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Double:NaN |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=java.lang.Double:NaN |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 1, 1, 9, "\ud8ed\udf86\uda5f\udc6b\udafe\udddf", "\u6aa1\u0594\u2a28\u5cee\u1d98", "\uda2f\udfff\ud8c7\udca8\ud8fb\udd74\ud8d8\udede\uda85\udc91",
        29, 68250, 889831243, -1474653413632843975L, 95228L, true, false, (char) 38111, (char) 58791,
        Double.longBitsToDouble(0x3fe1bfba8f66f9d9L), Double.longBitsToDouble(0x3fcaf8bfc04c5db8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 11, 11, 14, "\ud8ed\udf86\uda5f\udc6b\udafe\udddf", "\u8343\u05b9\u2a28\u5cee\u1d98", "\udb11\udf6c\ud930\udf15\ud926\udf6e\ud8d8\ude92\uda85\udc91",
        9, 68250, 889831243, -1474653413632843975L, 95228L, true, false, (char) 38111, (char) 58791,
        Double.longBitsToDouble(0x3fe1bfba88d6f9d9L), Double.longBitsToDouble(0x3fcaf8af6bb38d48L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Integer:2147483647 |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 12, 3, "\uda8b\udd89\ud8e3\udfe2\ue00d", "\u8343\u05b9\u2a28\u5cee\u1d98", "\ud86a\udc68\ud96f\udfa1\udb92\udf4c\ud8d8\udf37\ud9fd\udf35",
        9, 11778, 889831243, 2002150632845795129L, 83343L, true, false, (char) 14076, (char) 3810,
        Double.longBitsToDouble(0x3fe0b7fcd0d625d0L), Double.longBitsToDouble(0x3fcaf8af7bc4fa10L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 14, 15, 14, "\ud8da\udc15\uda5f\udc5f\udafe\udddf\ud9fd\udfe4\uda2d\udd97\ud84e\udd0c", "\u5cee\u8d7e\ucbdc\ucc64\uaebc\u619a\u1d22\u7eec", "\ud908\uddf9\ud9c2\udd2a\ud8c8\udc59\ud8f2\udd1d\u3167\uda04\udd16\ub812\uda88\udc57\uc515",
        18, 43830, -481114921, -8913236176608263446L, -66209L, false, false, (char) 9316, (char) 40667,
        Double.longBitsToDouble(0x3f82891c4ed60a00L), Double.longBitsToDouble(0x3fed88566f8812f8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=!org.apache.commons.math.optimization.OptimizationException\012",
        Z.run(T, 2, 13, 12, 11, "\ud8ed\udf86\uda5f\udc6b\udafe\udddf\ud830\ude1b\ud9fe\udeb3\ud8c9\ude40\uda32\ude54", "\u5a7b\u2fb1\ucc64\u4101\u462a", "\ud892\udd21\u4824\uda88\udd38\udb1a\ude56\ud8c7\udc0a\udac2\udc3e\ud907\udc59\ud9f3\ude16\ud8a7\udd4e\uda81\udc34\uda66\udc84\ud89b\ude98\uda96\udf93\ud8c6\ude63\udbd2\udd2b\ud97d\udf35\ud9f4\udd7c\ud89e\udeea\udb6a\ude78\u84d9\ud832\udc1d",
        7, 16290, -667781526, -3168541425083671506L, -59527L, true, false, (char) 24539, (char) 19165,
        Double.longBitsToDouble(0x3fb5c304f7cccfa0L), Double.longBitsToDouble(0x3fe18e6b06905cb6L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 13, 13, 7, "\ud8ed\udff0\uda5f\udc6b\udae7\udd4b\ud830\ude1b\ud9bf\udf83\ud8c5\udcaa\udbbc\udd55", "\u5a7b\uc7c8\ucc64\u4101\u462a", "\ud8c1\udded\udb90\udf1d\uda9a\udcff\udb1a\ude56\ud8c7\udc0a\udac2\udc3e\udae2\udde6\ud993\udf06\ud8ce\ude48\uda81\udc34\ud98c\udd80\ud89b\ude98\uda96\udf93\ud9c8\ude0c\ud8f0\udf06\udbd9\udc14\ud972\udfd7\udb6b\udd3a\ud8dd\udf93\uda35\udf4b\ud832\udc21",
        26, 38392, -829131262, -3168541425083671506L, 35205L, false, false, (char) 14972, (char) 7851,
        Double.longBitsToDouble(0x3fd175ac4a04cfb6L), Double.longBitsToDouble(0x3fb5c304f7cccfa0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=!org.apache.commons.math.optimization.OptimizationException\012",
        Z.run(T, 2, 15, 2, 14, "\ud847\udecd\uda0d\udcdd\udae3\udca7", "\u1da2\u44cc\u5956\ud7ab", "\ud908\udf0d\udaf6\ude96\ud9f6\ude04\uda62\udfa7\ud822\udcdb\uda85\udc91\u4824\udaa9\udfed\ud945\udda6\ud9bc\ude38\ud86c\udcb0\ud8df\udd90\ud90d\udc0e\ud80a\udf12\ud846\uded7\uc515\uda74\udde7\udaa9\udeb4\udaa0\udee4",
        -5, 12728, -2031248604, -6285128961310586258L, 84265L, true, true, (char) 10889, (char) 54023,
        Double.longBitsToDouble(0x3fe6b1b7334cae2aL), Double.longBitsToDouble(0x3fe4f9b63d8e1f16L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!org.apache.commons.math.optimization.OptimizationException\012",
        Z.run(T, 1, 12, 2, 11, "\u641d", "", "",
        -5, -1000, 15616801, 30787557502609L, -89603L, true, false, (char) 0, (char) 18181,
        Double.longBitsToDouble(0x3fe00006de11c051L), Double.longBitsToDouble(0x3feb9b72b8000bbbL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=!org.apache.commons.math.optimization.OptimizationException\012",
        Z.run(T, 2, 13, 12, 3, "\000\ud8e3\udf56\ue00d", "\u8343\u05b9\ub727\u5cee\u1d98", "\udb09\udd97\ud96f\udfa1\udb92\udf4c\ud8d8\udf37\ud9fd\udf35",
        9, 11778, 889831243, 2002150632845795129L, 83343L, true, false, (char) 14076, (char) 3810,
        Double.longBitsToDouble(0x3fe0b7fcd0d625d0L), Double.longBitsToDouble(0x3fcaf8af7bc4fa10L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=!org.apache.commons.math.optimization.OptimizationException\012",
        Z.run(T, 2, 15, 2, 8, "\ud847\udecd\uda0d\udcdd\ud9b1\uddea\ud867\ude24\uda2d\udd97\udae6\udf2f\ud846\udc1c\ud954\udc41\ud9f6\udef3", "\u66ab\u63a2\u64db\ub703\u6620\u78d7\uc45a\u10ed\u4257\u9655\u468d\u8579\ucb89\u50ca\u02c5\u434e\u9f88\ubc07\u3c48", "\ud9a1\udc01\ud827\udf5e\ud912\uddd4\udb78\ude97\ud90e\udc15\ud808\udef2\uda4c\udc88\ud8ba\udf6e\ud970\ude03\ud98b\ude86\udbf1\udc73\udba0\udc3e\udb8c\udcec\uda24\udd3f",
        0, 96950, 1074123838, -689302698175847041L, -74550L, true, true, (char) 30400, (char) 36265,
        Double.longBitsToDouble(0x3fe24a1d89b757a8L), Double.longBitsToDouble(0x3fba74f8611b9cf8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.math.optimization.SimpleVectorialValueChecker:@? |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=org.apache.commons.math.optimization.SimpleVectorialValueChecker:@? |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 3, 3, 14, "\ud847\ude6a\uda0d\udcdd\udae3\udca7", "\u1da2\u44cc\u5956\u0955", "\udad8\udf0e\uda64\udf2d\ud9d3\uddc3\uda62\udfa7\ud822\udcdb\uda85\udc91\ud8eb\uddf0\ud867\udf91\uda11\uddd8\ud9bc\ude38\ud8e7\uddee\ud8df\udd90\ud90d\udc0e\ud80a\udf12\ud846\uded7\uc515\uda74\udde7\udaa9\udeb4\ud942\udebd",
        -5, 12728, -2031248604, -6285128961310586258L, 84265L, true, true, (char) 10889, (char) 54023,
        Double.longBitsToDouble(0x3fe6b1b7334cae2aL), Double.longBitsToDouble(0x3fe4f9b63d8e1f16L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 2, 14, "\uda5c\ude98\uda0d\udd59\udae3\udca7\ud867\udda2\ud90d\udd9c\udae6\udf2f\ud846\udc1c", "\u6340\ub09e\u66ab\u63a2\u64db\ub703\u6620\u78f3\u0d5b\u10ed\u4257\u9655\u468d\u8579\u4431\u27d5\u13df\u434e", "\udaa0\udee4\udb1f\udf6c",
        -2, 62396, 1685175426, 399705932676611200L, 36393L, false, true, (char) 54023, (char) 36284,
        Double.longBitsToDouble(0x3fea65715286c2c7L), Double.longBitsToDouble(0x3fd8e1f16132b8f2L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\0121=null |this=org.apache.commons.math.optimization.general.GaussNewtonOptimizer:@?\012",
        Z.run(T, 2, 13, 3, 14, "\uda5c\ude98\uda0d\udd59\udae3\udca7\ud867\udda2\ud90d\udd9c\udae6\udf2f\ud846\udc1c\uda40\ude43", "\ub09e", "\ud9f6\ude04",
        11, 9219, 1851196973, 845479855957444362L, 56754L, false, false, (char) 42505, (char) 15662,
        Double.longBitsToDouble(0x3fe90f5648f88718L), Double.longBitsToDouble(0x3fd98aab3c6feea2L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!org.apache.commons.math.optimization.OptimizationException\012",
        Z.run(T, 1, 12, 2, 14, "\ud8ed\udf86\uda5f\udc6b\udafe\udddf", "\u8343\u05b9\u2a28\u5cee\u1d98", "\udb11\udf6c\ud930\udf15\ud926\udf6e\ud8d8\ude92\uda85\udc91",
        9, 68250, 889831243, -1474653413632843975L, -55556L, true, false, (char) 49488, (char) 30458,
        Double.longBitsToDouble(0x3fe1bfba88d6f9d9L), Double.longBitsToDouble(0x3fcaf8af6bb38d48L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|getChiSquare||new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|getRMS||new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|doOptimize||new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|getConvergenceChecker||new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|getCovariances||new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|getEvaluations||new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|getIterations||new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|getJacobianEvaluations||new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|getMaxEvaluations||new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|getMaxIterations||new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|guessParametersErrors||new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|incrementIterationsCounter||new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|optimize|org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction,[D,[D,[D|new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|setConvergenceChecker|org.apache.commons.math.optimization.VectorialConvergenceChecker|new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|setMaxEvaluations|int|new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|setMaxIterations|int|new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|getChiSquare||new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
    "M|org.apache.commons.math.optimization.general.AbstractLeastSquaresOptimizer|getRMS||new:org.apache.commons.math.optimization.general.GaussNewtonOptimizer:boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
