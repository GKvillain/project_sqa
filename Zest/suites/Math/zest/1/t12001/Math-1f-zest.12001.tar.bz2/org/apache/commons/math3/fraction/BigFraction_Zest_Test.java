package org.apache.commons.math3.fraction;
import org.junit.Test;
import static org.junit.Assert.*;
public class BigFraction_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:1\0121=new org.apache.commons.math3.fraction.BigFraction:391914973673313533\012",
        Z.run(T, 2, 2, 1, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, -1605492967, 391914973673313533L, 46224L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:1\0121=new org.apache.commons.math3.fraction.BigFraction:391914973673313533\012",
        Z.run(T, 2, 2, 1, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\uc77e\ud631", "\udaf4\ude2a",
        10, 32891, -1605492967, 391914973673313533L, 46224L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 20, 7, 25, "\udaa5\udda6\udafa\udf8d\udaef\udc92\ud8b5\uded7\udbf7\udcaa\uda2e\ude54\ue891\uda69\udfe3", "\u1ea1\u997f\u6e39\ua156\u6797\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u6f14\u9586\u13ba\ud73d\u7903\uae8c\u3243\u9aab", "\ud9dd\uded1\ud8fc\udcc4\ud920\udfae\udad3\udfc1\uda37\udd56\udb10\udec3\ud94e\uddfa\udbc6\udc2f\ud8f0\udedc\ud81b\udf1f\udad2\ude90\uda2d\udfdf\udaec\udef2\udbaf\ude0f\udac3\udeaa\udaf4\ude2a\udaf6\udf6b\udab3\udcdb\ud912\udde4\ud804\udfd7\udbd7\ude9e\udabe\udfc6\ud9ac\ude0c\ud879\udffd\ud865\udf71\udab8\udcfa\u21f8\ud93d\udf83",
        -3, 261, 206752364, 3109389279894822361L, 31685L, false, true, (char) 54157, (char) 31392,
        Double.longBitsToDouble(0x3fe9eec8649d0de6L), Double.longBitsToDouble(0x3f835fc79025a780L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:0\0121=new org.apache.commons.math3.fraction.BigFraction:-5091113454418926524\012",
        Z.run(T, 2, 2, 1, 21, "\udaff\udfbc\ud888\udd2b\udb19\udd6e\ud83e\udf79\ud837\udc89\udbca\ude93\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u42e3\u4ae0\uc893\u2fe0\u1be9\u05f3\u0df2\u04b6\u794f\ud7f0\u1782\u988f\ud4d5\u8a9f", "\uda4b\ude34\udbdb\ude20\ud8ae\udf46\udad3\udff9\uda37\udd56\udb10\udec3",
        35, 41506, 486935869, -5091113454418926524L, 23224L, true, true, (char) 60901, (char) 49258,
        Double.longBitsToDouble(0x3fc4790c13eddef4L), Double.longBitsToDouble(0x3fe8cc026498a04eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:0\0121=new org.apache.commons.math3.fraction.BigFraction:3 / 28\012",
        Z.run(T, 2, 2, 8, 12, "\udaec\ude72\uda32\udf64\udb21\udddc\udb5f\udd11\u120a\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u4b83\uad1a\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\u6bdf\u1782\u988f\ud4d5\u742c\u5cc8\u50f7\ub556\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\ucfc5\ub6c0\u60b8", "\udaf4\ude2a",
        59, 32758, -1605492967, -9121347598141756594L, 65168L, false, true, (char) 6377, (char) 5315,
        Double.longBitsToDouble(0x3fbb6b908761f8a0L), Double.longBitsToDouble(0x3fdb8a2bc95b6f84L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:10\0121=new org.apache.commons.math3.fraction.BigFraction:391914973673313533 / 46224\012",
        Z.run(T, 2, 11, 0, 17, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8cf\udca5\ud872\udfa2\ud89c\ude81\ud83e\udf29\uda8b\udd97\ue1c1\ue440\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\ua371\uacdc\u3e07\u2fe9\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u1e61\u7583\u7de1\u0bb2\u4b9d\u138a\ucdfe\u52d6\u3cdf\u20ab\uc6ab\u52a0\u769f\uc3b5\ub78b\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, -531751143, 391914973673313533L, 46224L, false, true, (char) 35816, (char) 53771,
        Double.longBitsToDouble(0x3fb83d060763c188L), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:5 / 6\0121=new org.apache.commons.math3.fraction.BigFraction:391914973673313533\012",
        Z.run(T, 2, 24, 1, 26, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\u7419\u2fe0\u1be9\u05f3\u0df2\u0e32\u5781\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\ubc70\ua547\u793f\u1f7e\ub78b\ub6c6\ub6a0\u60b8", "\uda98\udd0b",
        11, 32854, -1605492967, 391914973673313533L, 46224L, false, true, (char) 45800, (char) 8560,
        Double.longBitsToDouble(0x3fea8e6340ec690fL), Double.longBitsToDouble(0x3fcc2603135a6ce8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:391914973673313533 / 46224\0121=new org.apache.commons.math3.fraction.BigFraction:391914973673313533\012",
        Z.run(T, 2, 16, 1, 29, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\ud8da\udd3c\uda1a\udc88\ud83b\udf72\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\uda85\udce6\udba1\udd53", "\u559f\uacdc\uc819\u2fe0\u519f\u05f3\u0df2\u0e32\u577b\u67f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ucca7\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, 724049689, 391914973673313533L, 46224L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:54\0121=new org.apache.commons.math3.fraction.Fraction:27 / 137\012",
        Z.run(T, 2, 11, 26, 13, "\udaff\udfbc\ud888\udcfc\udbcd\ude4f", "\u4b39\u7168\ua746\ub911\u07ae\u036d\ucccb\u7b09\u9440\uc9d5\u143d\u2fd6\uc124\uc792\u4a2d\ucd86\u1655\u16d1\u06a5\u0c67", "\uda80\udfec",
        54, 77994, 941372819, -5480567716277033802L, 51354L, true, false, (char) 3290, (char) 8720,
        Double.longBitsToDouble(0x3fc939f554f441e4L), Double.longBitsToDouble(0x3fea48e8319a133eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:531 / 562\0121=new org.apache.commons.math3.fraction.BigFraction:1\012",
        Z.run(T, 2, 26, 24, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda7f\udf97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u7e96\uacdc\uc819\u2fe0\u15e9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\u1dd6\u2f12\u0b2b\u888d\ub4c3\uadfe\u52d6\u98b9\ub9da\ucfe7\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\u4753", "\udaf4\ude2a",
        10, 32891, -1605492967, 391914974126298365L, 46224L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:-426323604364122021 / 1928\0121=new org.apache.commons.math3.fraction.BigFraction:0\012",
        Z.run(T, 2, 0, 2, 21, "\udaff\udfbc\ud86b\udd0d\000\000\000\uda1f\udfe2\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d", "\ud9dd\udefc\ud887\udd2c\u1852\udad3\udff9\uda37\udd56\udb10\udec3",
        35, 53058, 486935869, -5115883252369464252L, 23136L, true, true, (char) 60901, (char) 49258,
        Double.longBitsToDouble(0x3f1b4a9f6ef7a000L), Double.longBitsToDouble(0x3fe8cc026498a04eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:1 / 2\0121=new org.apache.commons.math3.fraction.BigFraction:-6169904749258362682\012",
        Z.run(T, 2, 2, 1, 12, "\udaff\udfbc", "\u79b3\u7cd9\u4b39\uc7d3\u2c14\ubd62\ub948\u7923\u7fed\uced1\u6183\u0f98\u559f\uacdc\uc819\u2fe0\u1be9\u4e8a\u27f6\u2d39\u62fb\u3c69\u300e\u988f", "\ud8b2\udce6",
        50, 87349, 131425462, -6169904749258362682L, -34190L, false, false, (char) 8513, (char) 7565,
        Double.longBitsToDouble(0x3fe248e8345d2e3eL), Double.longBitsToDouble(0x3fd3c7e252b0e14eL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:1\0121=new org.apache.commons.math3.fraction.BigFraction:1\012",
        Z.run(T, 2, 2, 24, 29, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\u9a1f\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, -1605492967, 391914973673313533L, 46224L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:2419136591847869 / 4503599627370496\0121=new org.apache.commons.math3.fraction.BigFraction:3225260919043816621\012",
        Z.run(T, 2, 3, 1, 21, "\udaff\udfb4\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\udb5c\udefc\udbab\udf1d\uda8b\udd4a\ue1c1\ud974\ude9d\uda5d\udc8d\ud9eb\udf0a\ud8d7\udf00", "\u559f\uacdc\u3ed7\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u685c\ud4d5\u6f4b\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d", "\uda0a\udda2\udb6f\udef2\ud81b\udf1f\ud85a\udfb3\uda2d\udfdf\uda01\udf1c\ud934\ude52\ud8fa\udcdc\udaf4\ude2a\ud9be\udfb1\ud889\udd74\ud892\ude3d\udbff\udd1a\udb7d\udcb0\ud862\udd0b\uda00\udc0d\ud8de\ude32\uda9e\udece",
        49, 76486, -401065748, 3225260919043816621L, -47099L, false, false, (char) 92, (char) 57188,
        Double.longBitsToDouble(0x3fe130624270c37aL), Double.longBitsToDouble(0x3f92588ca0d89520L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:17 / 18\0121=new org.apache.commons.math3.fraction.BigFraction:391914973673313533\012",
        Z.run(T, 2, 28, 1, 21, "\udaff\udfbc\ud888\udcfc\000\000\000\000\000\uda8b\udd97\udbfc\udc7d\ud974\ude9d\ud9fe\udded\ud9eb\udf0a\udba1\udce4", "\uad0e\uacdc\uc819\u2fe0\u1be9\u67f2\u00b3\u0e00\u577b\ud7f0\u3066\000\u819d\000\u4228\000\u3b85\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u2544\000\000\u34beX", "\udaf4\ude2a",
        21, -1000, -1605500928, 391914973673313533L, 46224L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e8188016f84L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:2091373605649169225\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 1, 4, 3, "\udb0c\udc67\ud8aa\udf0d\udbec\udf8a\udabb\ude22\udbe0\udd3f\uda20\udc30", "\u0b2a\uae04\uadff", "\ud9a6\ude5d\ud9b7\udc0e\uda21\udf72\udbcb\udf7b\ud97a\udc38\uda0a\udd5a\uda23\uddb8\ud82e\udf79\udbba\udd8f\ud842\udf75\uda73\uddec\udad1\udf5e\ud873\udc22\ud8c8\udfb3\udb4c\udf16\udbee\udfdf\ud8b9\udea4\ud9f8\udde9\ud9c2\uddd0\ud887\udd2c\ud8ae\udf46\udad3\udff9\uda37\udd56",
        44, 32875, -130169174, 2091373605649169225L, 84972L, true, true, (char) 49258, (char) 38845,
        Double.longBitsToDouble(0x3fcf6ef7b3508e90L), Double.longBitsToDouble(0x3fcec124f3f415c0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:1\0121=new org.apache.commons.math3.fraction.BigFraction:10\012",
        Z.run(T, 2, 2, 7, 14, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\uda0d\ude1a\ud9ba\udd08\udad0\udd72\udb7b\udfcd\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\u399b\u301c\u98bd\u3370\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d\ud4ef\u828c\u18fa\uae33\u52d6\u482b\u16cd\uc6ab\u0820\u6430\u6d47\ucf25\uc75a\ub6c0\u60b8", "\udaf4\ude2a",
        10, 9675, -1605492967, 1833066855769042335L, 46224L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:531 / 562\0121=new org.apache.commons.math3.fraction.Fraction:1\012",
        Z.run(T, 2, 26, 29, 21, "\udbab\ude06\uda4b\udef8\udb65\udc06\udb97\udff1\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ud98a\udcc1\ud8ce\udeff\udac0\ude8f\ud9eb\udf0a\udb4c\udf12", "\u559f\uacdc\uc819\ua69d\u1e44\u05f3\u91fc\u0e37\ubebe\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uab53\u5357\u9fa1\u5b9b\uc63c\u082d\u30d4\u1fa3\u92e8\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, -1605492967, 391914973673313533L, -84848L, true, true, (char) 43912, (char) 47607,
        Double.longBitsToDouble(0x3fee3c20c52352d0L), Double.longBitsToDouble(0x3fe7c2e46cad406eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:1\0121=new org.apache.commons.math3.fraction.BigFraction:391914973673313533\012",
        Z.run(T, 2, 13, 1, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u5827\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, -1605492967, 391914973673313533L, 46224L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:8510360674658575 / 9007199254740992\0121=new org.apache.commons.math3.fraction.BigFraction:391914973673313533\012",
        Z.run(T, 2, 3, 1, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\uda78\udfea\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u2881\u988f\ud4d5\u6f5d\u0b2b\u10d5\u8885\u355b\u531a\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        57, 82000, -1605492967, 391914973673313533L, 46224L, false, true, (char) 62784, (char) 38789,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fcd03e312b46ce8L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:1\0121=new org.apache.commons.math3.fraction.BigFraction:1\012",
        Z.run(T, 2, 2, 25, 23, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u7c81\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, -1605492967, 391914973673313533L, 46224L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:-219484278940411904 / 3125\0121=new org.apache.commons.math3.fraction.BigFraction:7023496926093180928\012",
        Z.run(T, 2, 16, 1, 21, "\udaff\udf69\ud888\udcfc\ud81a\udc60\u3e26\000\000\udb7e\udddb\uda8b\udd97\udab2\udc78\ud974\ude9d\ud9fe\udded\000\000", "\u559f", "\uda73\udd4c\ud9c8\udf01\ud82e\udf79\udbf2\udfa7\ud876\udc2f\uda61\udcaf\ud99e\udf85\udac0\ude0c\udb67\udd77\u819d",
        38, 66778, 941372819, 7023496926093180928L, -100000L, true, true, (char) 12427, (char) 121,
        Double.longBitsToDouble(0x3fe800000444b958L), Double.longBitsToDouble(0x3f3f894000000000L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:16 / 5305\0121=new org.apache.commons.math3.fraction.BigFraction:-6895539787131757416\012",
        Z.run(T, 2, 22, 17, 17, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\udb70\udfbe\ud85e\udf8f", "\u6e39\ua156\u0f98\u7f0c\u97b2\u42f2\u36ed\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\u9224\u4a48\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6", "\udb08\udc6e\udac3\udeaa",
        48, 15915, -2142479109, -6895539787131757416L, 5210L, false, false, (char) 5601, (char) 6377,
        Double.longBitsToDouble(0x3fb5a843de3c20c0L), Double.longBitsToDouble(0x3fcd8d21f6e3a060L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 2, 1, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\udb2d\udebf\ud87d\udf48", "\u559f\uacdc\uc819\u2fe0\u1be9", "\ud876\udc2f\uda73\uddec\ud99e\udf85\udac0\ude0c\udb67\udd77\u18ef\udbee\udfdf\ud9e0\udd1d\ud9ec\udce1\ud9dd\udefc\ud887\udd2c\ud8ae\udf46\udad3\udff9\uda37\udd56\udb10\udec3\udbfd\ude52\uda0a\udda2\udb6f\udef2\ud81b\udf1f",
        -1, 15884, -1820729000, 3199013485180338561L, -2557L, true, false, (char) 40805, (char) 64742,
        Double.longBitsToDouble(0x3fcfa0ae0bea4fd0L), Double.longBitsToDouble(0x3fca10ba2c21eb64L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:1\0121=new org.apache.commons.math3.fraction.BigFraction:10 / 32891\012",
        Z.run(T, 2, 9, 22, 9, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\ud89c\udc0c\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\uc819\u2fe0\uc2f9\u05f3\u0df2\u0e32\u577b\u18c0\u748d\u39a2\ud4a6\u6f5d\u2f9c\u5e15\u757f\u2c0d\u3c0f\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, -1605492967, 391914973673313533L, 46765L, true, true, (char) 6485, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:1\0121=new org.apache.commons.math3.fraction.Fraction:10\012",
        Z.run(T, 2, 29, 27, 21, "\udaff\udfbc\ud888\udcfc\ud8dc\udf82\uda11\udee7\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u059d\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\u2417\u6149\u58c3\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, -1605492967, 391914973673313533L, 46224L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:17 / 18\0121=new org.apache.commons.math3.fraction.Fraction:17 / 18\012",
        Z.run(T, 2, 12, 28, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\ud9a6\udea8",
        36, 32891, -1605492967, 391914973673313533L, 46224L, false, true, (char) 6377, (char) 49253,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:391914977308619773 / 46224\0121=new org.apache.commons.math3.fraction.BigFraction:17 / 18\012",
        Z.run(T, 2, 16, 24, 21, "\udab3\udeec\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\uda6c\udde5\ud8a9\uddb1\udb8d\udc1a\uda8b\udd97\ue1c1\ud974\ude9d\ud8c4\ude91\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\uc819\ua2ec\ud688\ub7c7\u299a\u220e\u11a8\ub1d5\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ucc05\u9ac1\uc5ea\u98b9\u4d1d\u2245\u087e\u6430\u024e\u61c2\u612b\ub6c8\u615d", "\ud8c3\udd5d",
        50, 32891, -1605492967, 391914977308619773L, 46224L, true, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 21, 13, 21, "\udbf6\udf76\uda44\udd0b\ud870\udf6d\ud9fa\uddbb\uda96\udc9c\uda20\udca9\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\u548b\uc819\u1aa9\u1bb5\u0625\u0df2\u0e32\u021a\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, -1605492967, 391914973673313533L, 46224L, false, true, (char) 25263, (char) 36401,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:1\0121=new org.apache.commons.math3.fraction.Fraction:10 / 32891\012",
        Z.run(T, 2, 2, 30, 21, "\udaff\udfbc\ud872\udff9\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\000\000\u1801\ub2a1\u1be9\u05f3\u0df2\u0e32\u493d\u600b\u1782\u988f\ud4d5\000\u4228\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\ub939\u1f66\ubb49\000\000\u60b8", "\udaf4\ude2a",
        10, 32891, -1605492967, 31627003483673853L, 46224L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895a0184L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:924813942626091 / 1125899906842624\0121=new org.apache.commons.math3.fraction.BigFraction:23 / 28\012",
        Z.run(T, 2, 3, 24, 21, "\udaff\udfbc", "\u79b3\u7cd9\u4b39\uc7d3\u2c14\u0b2a\uae04\u46b6\u997f\u6e39\ua156\u0f98\u559f\uacdc\uc819\u2fe0\u8bdf\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f", "\ud9e0\udd1d",
        29, 61295, 131427549, -6169904749258362682L, -4053L, true, true, (char) 12427, (char) 7606,
        Double.longBitsToDouble(0x3fea48e83444b958L), Double.longBitsToDouble(0x3fd3c7e252b0e14eL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:6 / 24305\012",
        Z.run(T, 1, 22, 8, 5, "\udbfe\udffa\u6eb3\uda60\udd45\ud8b2\udcb6\ud864\uddce\uda28\udc8c\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uad13\uc819\u2f50\ua1d4\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u67bc\ub9b5\u3364\u2c7e\uae3c\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\u75b8", "\ud830\udf68",
        18, 72915, -1605492967, 391914973673365757L, 46237L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:1\0121=new org.apache.commons.math3.fraction.Fraction:1\012",
        Z.run(T, 2, 25, 13, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda72\udd19\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub524\uadfe\u14d7\u98b9\u4d1d\u878a\u74b8\u63d3\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, -1605492967, 391914973673313533L, 46224L, true, true, (char) 6480, (char) 21861,
        Double.longBitsToDouble(0x3fee8feac1e25603L), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:1\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 2, 5, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\ud9b8\udc13\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, -1605492967, 391914973673313533L, 46224L, false, true, (char) 62440, (char) 38734,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:0\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 29, 21, 21, "\udaff\udfe5\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1", "\u997f\u6e39\ua156\u0f98\u559f\uacdc\ua523\ua82a\u1be9\u05f3", "\uda73\uddec",
        45, 61203, -1855042054, 8950765294473125964L, -86285L, false, true, (char) 50734, (char) 8231,
        Double.longBitsToDouble(0x3fc8d54c1a9fca70L), Double.longBitsToDouble(0x3fd967173d22eeaeL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:1\0121=new org.apache.commons.math3.fraction.Fraction:1\012",
        Z.run(T, 2, 2, 28, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\udae7\ude2a",
        10, 32891, -1605492967, 391914973673313533L, 46224L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:391914973673313533\0121=new org.apache.commons.math3.fraction.BigFraction:391914973673313533\012",
        Z.run(T, 2, 1, 1, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, -1605492967, 391914973673313533L, 46224L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:0\0121=new org.apache.commons.math3.fraction.BigFraction:0\012",
        Z.run(T, 2, 2, 25, 15, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, -1605492967, 391914973673313533L, 46224L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3f408303b1a43c00L), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:531 / 562\0121=new org.apache.commons.math3.fraction.Fraction:531 / 562\012",
        Z.run(T, 2, 26, 10, 21, "\udb13\udfc6\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\ud90a\udc19\ud94a\udfcd\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\ud80e\ude1c", "\u559f\u1cdc\uc819\u2fe0\u1cea\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadc9\u52d6\u98b9\u4d1d\u4d7c\u5e75\u6430\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, -1605492967, 391914973673313533L, 46323L, true, false, (char) 62940, (char) 43424,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895a090aL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 2, 1, 21, "\000", "\u79b3\u7cd9\u4b39\uc7d3\uc9b4\u0ae7\uae04\u46b6\u997f\u6e39\ua156\uaa8c\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f", "\ua102",
        -5, -1000, 0, -6169931489724747578L, -99797L, false, false, (char) 12427, (char) 7606,
        Double.longBitsToDouble(0x3fea48e83444b958L), Double.longBitsToDouble(0x3fd3c7e252b0e14eL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:1\0121=new org.apache.commons.math3.fraction.BigFraction:1\012",
        Z.run(T, 2, 2, 2, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14", "\uae04\u46b6\u997f\u6e39\ua156\u0f98\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\ua9b6\u0703\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u07fc\u6430\u1fa3\ub78b\u6b64\u515b\u60b8", "\udaf4\ude2a",
        10, 77419, -1605492790, 391914973673313533L, 46224L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c608690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:1634435 / 8388608\0121=new org.apache.commons.math3.fraction.BigFraction:391914973673313533\012",
        Z.run(T, 2, 19, 1, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\uda4d\udd3a\udba1\udce4", "\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, -1605492967, 391914973673313533L, 46432L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fc8f08300000000L), Double.longBitsToDouble(0x3fc71d0300000000L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:1\0121=new org.apache.commons.math3.fraction.BigFraction:0\012",
        Z.run(T, 2, 2, 1, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430=\ud441\u059a\ub6c0\u60b8", "\udaf4\ude2a",
        10, 32891, 25, 0L, 46224L, false, true, (char) 6377, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:45\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 11, 20, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\udadc\udca6\ud89e\udf93\uda8b\udd97\ue1c1", "\u997f\u6e39\u778f\ubf5e\u571a\u2229\u1110\ua445\u1be9\u4af5", "\uda73\uddec",
        45, 61203, -1860637695, 8950765295598510156L, -68033L, false, true, (char) 39214, (char) 30428,
        Double.longBitsToDouble(0x3fc8d54c1a9fc9d4L), Double.longBitsToDouble(0x3fe65b8ea1294365L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:-391914973673313533 / 100000\0121=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 16, 25, 15, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\ud951\udef7\ud884\udc01\000\uda8b\udcf1\ue1c1\000\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\uc819>\000\000\u0d3f\u0e32\u577b\ud7f0\u1782\u988f\ud4d5\u6f5d\u0b2b\u4313\ub4c3\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\uc9c6\ub6c0\000", "\udaf4\ude2a",
        21, -1000, 0, 391914973673313533L, -100000L, false, false, (char) 6248, (char) 43365,
        Double.longBitsToDouble(0x3fee3c20c0ec690fL), Double.longBitsToDouble(0x3fc71d0312b6df08L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:48 / 38627\0121=new org.apache.commons.math3.fraction.BigFraction:7881329242673483 / 9007199254740992\012",
        Z.run(T, 2, 14, 3, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\ud935\udf0f", "\u559f\uacdc", "\udb23\udf4e\ud82e\udf79\udbf2\udfa7\ud876\udc2f\uda73\uddec\ud99e\udf85\udac0\ude0c\udb67\udd77\u18ef\udaf9\ude43\ud870\udf66\ud9ec\udd39\ud9dd\udefc\ud887\udd2c\ud8ae\udf46\udad3\udff9\uda37\udd56\udb10\udec3\udbfd\ude52\uda0a\udda2\udb6f\udef2\ud81b\udf1f\ud85a\udfb3\uda2d\udfdf\udaec\udef2\udb08\udc6e\udac3\udeaa\udaf4\ude2a\ud9be\udfb1\ud989\udd74\ud900\udd75\uf4ea\udbd7\ude9e\udabe\udfc6\ud96f\udc0d",
        48, 38627, -2078799786, 6755843398539163722L, -845L, true, true, (char) 1962, (char) 16463,
        Double.longBitsToDouble(0x3fec0006f5de114bL), Double.longBitsToDouble(0x3fe02a198bce0c87L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:0\0121=new org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 2, 2, 28, 9, "\udaff\udfbc\ud888\udcfc\ud849\udf28\ud9ed\udf12\ud8b6\udf54\uda20\udc88\ud951\uddfc\ud978\udf48\ue1c1\ud974\ude9d", "\u6e39\u308b\u1021\u0795\uacdc\uaf92\u2fe0\u1be9\u05f3\u0df2\u4e32\u73a0\u17d7\u1782\ub025\u35a4\u6f5d\u0b2b\u1c56\u99a1\ub50b\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\u4f32", "\udb08\udc6e\udac3\udeaa",
        -1, 15915, -2142479109, 3841266024245654737L, 56934L, false, false, (char) 5601, (char) 6377,
        Double.longBitsToDouble(0x3fb5a843e86c20c0L), Double.longBitsToDouble(0x3fc33188d6e3a060L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:-3\0121=new org.apache.commons.math3.fraction.BigFraction:-3\012",
        Z.run(T, 2, 27, 7, 25, "\udaa5\udda6\udafa\udf42\udaef\udc92\ud8b5\uded7\udbf6\udfed\uda2e\ude54\ue891\uda69\udfe3", "\u1ea1\u997f\u6e39\ua156\u6797\u559f\uacdc\uc819\u2fe0\u1be9\u992e\u6f14\u9586\u13ba\ud73d\u7903\uae8c\u3243\u9aab", "\ud9dd\uded1\ud8fc\udcc4\ud920\udfae\udad3\udfc1\uda37\udd56\udb10\udec3\ud94e\uddfa\udbc6\udc2f\ud8f0\udedc\ud81b\udf1f\udad2\ude90\uda2d\udfdf\udaec\udef2\udae9\udf4c\udac3\udeaa\udaf4\ude2a\udaf6\udf6b\udab3\udcdb\ud912\udde4\ud804\udfd7\udbd7\ude9e\udabe\udfc6\ud9ac\ude0c\ud879\udffd\ud865\udf71\udab8\udd9f\u21f8\ud93d\udf83",
        -3, 261, 206752364, 3109389279894822361L, 31685L, false, true, (char) 54157, (char) 31392,
        Double.longBitsToDouble(0x3fe9eec8649d0de6L), Double.longBitsToDouble(0x3f835fc79025a780L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:-1 / 87\0121=new org.apache.commons.math3.fraction.Fraction:-1 / 87\012",
        Z.run(T, 2, 6, 30, 4, "\udaa5\udda6\udb2b\udf15\udaef\udc05\ud8b5\uded7\ud814\udcfa\uda28\uddd0\ue891\uda69\udfe3", "\u1dcf\u997f\u6e39\u96a8\uad9c\u1837\uacdc\uc918\u6fe8\u1be9\u85e4\u6ef2\u9586\uacba\ud73d\u7903\uae8c\u32ec\u9aab", "\ud9dd\uded1\ud840\udfb3\udbbb\udf2e\udad3\udf6f\uda37\udd56\udb10\udec3\ud94e\uddfa\udbc6\udc2f\ud8f0\udedc\ud81b\udf1f\udad2\ude90\uda2d\udfdf\udaec\udef2\udbaf\ude0f\udb8c\udf8e\udae9\udf00\udaf6\udf6b\udab3\udcdb\ud912\udde4\ud804\udfd7\ud9a2\udfbb\ud871\udcae\ud9ac\ude0c\ud879\udffd\ud865\udf71\udab8\udcfa\u21f8\ud93d\udf83",
        -3, 261, 944949868, 3109389906960047577L, 31685L, false, true, (char) 63765, (char) 19702,
        Double.longBitsToDouble(0x3fda636e2d5d467cL), Double.longBitsToDouble(0x3f82c88e1f3f9940L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:-7220044514124561922 / 19703\0121=new org.apache.commons.math3.fraction.BigFraction:-7220044514124561922 / 19703\012",
        Z.run(T, 2, 0, 0, 0, "\udaa5\udda6\udafa\udf8d\udaef\udc92\ud8b5\uded7\udbf7\udcaa\uda2e\ude54\ue891", "\u12b4\u1ea1\u997f\u6e39\ua156\u6797\u559f\uacdc\uc819\u2fe0", "\ud829\udc82",
        8, 79785, -1245022414, -7220044514124561922L, 19703L, false, false, (char) 57389, (char) 27499,
        Double.longBitsToDouble(0x3fd766178c2b60b0L), Double.longBitsToDouble(0x3fc1cbe03a9fc9d4L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:-1 / 87\0121=new org.apache.commons.math3.fraction.Fraction:-3\012",
        Z.run(T, 2, 30, 11, 6, "\udaa5\udd74\udafa\udf8d\ud806\udc5c\ud8b5\uded7\udbf7\udcaa\uda2e\ude54\ue891\uda69\udfe3", "\u1de1\u997f\u6e39\u2c98\u66dd\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u6f14\u9586\ub76e\u8c22\u7399\uae8c\u5614\u9aab", "\ue0e5\ud8fc\udcee\uf92d\uda9b\udcf5\uda4c\udd1a\udbfd\ude2c\uda0a\udcc0\ud962\udfbc\udae4\udd47\ud9b9\ude6d\ud865\udca3\ud8ee\udf89\ud981\udc22\udbca\udcb7\ud839\udd1c\udaf4\ude61\udb7e\udd18\udbe2\udca6\ud912\uddba\ud804\udfd7\udbd7\ude9e\udabe\udfc6\ud9ac\ude0c\ud879\udffd\udbee\ude65\udbc6\udd01\u21f8\ud93d\udf83",
        -3, 261, 206752364, 3109389279894822361L, 30459L, false, true, (char) 54157, (char) 31392,
        Double.longBitsToDouble(0x3fe9eec8679d0de6L), Double.longBitsToDouble(0x3f8333139025a780L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 15, 7, 25, "\udaa5\udda6\udafa\udf8d\udaef\udc92\ud8b5\uded7\udbf7\udcaa\uda2e\ude54\ue891\uda69\udfe3", "\u1ea1\u997f\u6e39\uc497\u6797\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u6f14\u9586\u13ba\ud73d\u7903\uae8c\u3243\u9aab", "\ud9dd\uded1\ud8fc\udcc4\ud920\udfae\udad3\udfc1\uda37\udd56\udb10\udec3\ud94e\uddfa\udbc6\udc2f\udb52\udf32\ud93b\ude8e\udad2\udebb\uda2d\udfdf\udaec\udef2\udbaf\ude0f\udac3\udeaa\udaf4\ude2a\udaf6\udf6b\udab3\udcdb\ud912\udde4\ud804\udfd7\udbd7\ude9e\udabe\udfc6\ud9ac\ude0c\ud879\udffd\ud865\udf71\udab8\udcfa\u21f8\ud93d\udf83",
        -3, 261, 206752364, 3109389279894822361L, 31685L, false, true, (char) 54157, (char) 31392,
        Double.longBitsToDouble(0x3fe9eec8649d0de6L), Double.longBitsToDouble(0x3f835fc79025a780L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:-1272778363604731631 / 5806\0121=new org.apache.commons.math3.fraction.BigFraction:-1272778363604731631 / 5806\012",
        Z.run(T, 2, 0, 0, 21, "\udaff\udfbc\ud888\udd2b\udb19\udd6e\ud83e\udf79\ud837\udc89\udbca\ude93\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u42e3\u4ae0\uc893\u2fe0\u1be9\u05f3\u0df2\u04b6\u794f\ud7f0\u1782\u988f\ud4d5\u8a9f", "\uda4b\ude34\udbdb\ude20\ud8ae\udf46\udad3\udff9\uda37\udd56\udb10\udec3",
        35, 41506, 486935869, -5091113454418926524L, 23224L, false, false, (char) 49407, (char) 49258,
        Double.longBitsToDouble(0x3fc4790c13eddef4L), Double.longBitsToDouble(0x3fe8cc026498a04eL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:519511349274799 / 2251799813685248\0121=new org.apache.commons.math3.fraction.Fraction:3 / 13\012",
        Z.run(T, 2, 19, 28, 12, "\udaec\ude72\uda32\udf64\udb21\udddc\udb5f\udd11\u120a\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\udbf7\uddeb\ud85a\udecd\ud9eb\udfd6\udba1\udce4", "\u4b83\uad1a\u8b23\u3093\u1be9\u1180\u0df2\u0e32\u577b\u1bcb\u1782\uaf8e\ud4d5\u621a\u747f\u511f\ub556\uadfe\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\ucfc5\ub6c0\u60b8", "\udaf4\ude2a\ud9b1\udeeb",
        53, 2207, -2123729232, -7736770839989646181L, 56920L, true, false, (char) 61376, (char) 54959,
        Double.longBitsToDouble(0x3fcd87e296e28af0L), Double.longBitsToDouble(0x3fc5b6f84837ac6cL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:11753327 / 67108864\0121=new org.apache.commons.math3.fraction.BigFraction:7 / 40\012",
        Z.run(T, 2, 2, 8, 12, "\udaec\ude72\uda32\udf64\000", "\u4b39", "\ue1c1\ud974\ude9d\udac0\ude8f",
        55, 88842, 88, 8926561070012927246L, -100000L, false, false, (char) 39074, (char) 23223,
        Double.longBitsToDouble(0x3fc66aede0000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:3 / 28\0121=new org.apache.commons.math3.fraction.BigFraction:3 / 28\012",
        Z.run(T, 2, 8, 8, 12, "\udaec\ude72\uda32\udf64\udb21\udddc\ud95a\udd6e\u120a\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud8df\udd13\udac0\udde8\ud9eb\udf0a\udba1\udce4", "\u4b83\uad1a\uc819\u2fe0\u1be9\u05f3\u818b\u9350\u55d2\u2e30\u9879\u988f\u3cfe\u644c\u5cc8\u50f7\ub15f\u05fc\u52d6\u98b9\u4d1d\uc6ab\u0820\u69d1\u736a\ub7d8\ucfc5\ub6c0\u60b8", "\udaf4\ude2a",
        59, 32758, -1605492967, -9121436658583606450L, 65168L, false, true, (char) 6377, (char) 5315,
        Double.longBitsToDouble(0x3fbb6b908761f8a0L), Double.longBitsToDouble(0x3fdb8a2bc95b6f84L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:614727 / 926129755\0121=new org.apache.commons.math3.fraction.BigFraction:0\012",
        Z.run(T, 2, 2, 8, 12, "\udaec\ude72\uda32\udf64\udb21\udddc\udb5f\udd11\u114a\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u4b83\uad1a\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\u230a\u1782\u988f\ud4d5\u742c\u5cc8\u50f7\ub556\000\u5284\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\ucfc5\ub6c0\u60b8", "\udaf4\ude2a",
        59, 32758, 0, 0L, -100000L, false, true, (char) 6377, (char) 41231,
        Double.longBitsToDouble(0x3f45c003b0fc5000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:0\0121=new org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 2, 15, 13, 3, "\udaec\ude72\uda32\udf64\udb21\udddc\udb5f\udd11\u120a\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u4b83\uad1a\uc819\u2fe0\u1be9\u05f3\u0df2\u0edc\u577b\u6bdf\u1782\u7b8f\ud4d5\u742c\u5cc8\u50f7\ub556\u4cff\u52d6\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\u09fd\ud00f\ub6c0\u60b8", "\udaf4\ude2a",
        59, 32758, -1605492967, -9121347598141756594L, 65168L, false, true, (char) 6377, (char) 5315,
        Double.longBitsToDouble(0x3fbb6ba88761f8a0L), Double.longBitsToDouble(0x3fdb8a2bc95b6f84L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 28, 15, 2, "\udaff\udfbc", "\000", "",
        -5, 20928, 140175683, -2083221248L, -7998L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3d5c000000000000L), Double.longBitsToDouble(0x3ecc800000000000L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:-7992824087328020394 / 52055\0121=new org.apache.commons.math3.fraction.BigFraction:-7992824087328020394 / 52055\012",
        Z.run(T, 2, 0, 0, 17, "\000\ud888\udcfc\ud81a\udc60\ud8cf\udca5\ud872\udfa2\ud89c\ude81\ud83e\udf29\uda8b\udd97\ue1c1\ue440\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\ua371\uacdc\u3e07\u2fe9\u1be9\u05f3\u0df2\u0e32\u577b\ud7f0\u1782\u1e61\u7583\u7de1", "\udab1\uddb8\ud88f\udd2c\ud8ae\udf46",
        48, 72383, 1124073675, 7992824087328020394L, -52055L, false, false, (char) 3937, (char) 20991,
        Double.longBitsToDouble(0x3fdd19379b0258caL), Double.longBitsToDouble(0x3fc1f9f4928c6d28L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:0\0121=new org.apache.commons.math3.fraction.BigFraction:-391914973673313533 / 84848\012",
        Z.run(T, 2, 11, 0, 17, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8cf\udca5\ud872\udfa2\ud8d6\ude7e\ud83e\udf29\uda8b\udd97\ue1c1\ue440\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\ua371\uacdc\u3e07\u2fe9\u3675\u6799\u0df2\u0e32\u577b\ud7f0\u3c3c\u00d4\u7583\u7de1\u0bb2\u4b9d\u138a\ucdfe\u4f15\ud244\u20ab\u71a2\uc664\u769f\uc3b5\ub78b\uc9c6\ub6c0\u60b8", "\u7f1c",
        0, 99221, 2120081517, 391914973673313533L, -84848L, false, false, (char) 48606, (char) 48241,
        Double.longBitsToDouble(0x3fccff3dc3b39b60L), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:4\0121=new org.apache.commons.math3.fraction.Fraction:4 / 60565\012",
        Z.run(T, 2, 11, 14, 30, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8cf\udca5\ud872\udfa2\ud89c\ude81\ud83e\udf29\uda8b\udd97\ue1c1\ue440\udac0\ude8f\ud9eb\udf0a", "\u501c\ua371\uacdc\u3e07\u2fe9", "\ud998\udf5c",
        4, 60565, -1245022235, -7328209769359367935L, 44593L, false, true, (char) 14181, (char) 37266,
        Double.longBitsToDouble(0x3fc6cc22a1481f54L), Double.longBitsToDouble(0x3fc8d54c1a9ec9d4L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:39\0121=new org.apache.commons.math3.fraction.BigFraction:39\012",
        Z.run(T, 2, 23, 7, 26, "\udadc\udf73\ud888\udcfc\udbcd\ude4f", "\u4ae7\uaf57\u0c6b\u0d04\u5056\u0d01\uab97\u7b09\u9440\ua7d6\u8a1a\u2fd6\uc124\uc792\u4a2d\ucd86\u1655\u83b8\ucc72\u7e7a", "\ud89c\udc7f\ud821\udfd1\udbd1\udc88\ud9ec\udcff\ud852\udf57\ud887\udd2c\ud8ae\udf46\ud886\ude8d\udaec\udd1e\u6185\ud84a\uddbd\uda0a\uddc1\udb6f\udef2\ud935\udc6b\ud8c5\udc12\ud996\udfbf",
        39, 90615, -374533035, -8363424967733898158L, 55827L, false, false, (char) 48663, (char) 33447,
        Double.longBitsToDouble(0x3fea30bbd4a5894bL), Double.longBitsToDouble(0x3feb6c2f073382e0L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:3 / 4333\0121=new org.apache.commons.math3.fraction.Fraction:3 / 4333\012",
        Z.run(T, 2, 30, 14, 13, "\udaff\udfbc\ud888\udcfc\udbe6\uddaa", "\u8846\u9e7b\ua746\ub911\u07ae\u036d\ucccb\u7b09\u9440\u3e6d\u18ad\u2fd6\uc124\uc792\u4a2d\ucd86\u1655\u16d1\u06a5\u1fa5", "\uda80\udfec",
        54, 77994, 941372819, -3743281102517646927L, 51354L, true, false, (char) 3290, (char) 17344,
        Double.longBitsToDouble(0x3fe430febd3d1079L), Double.longBitsToDouble(0x3fd401d0633426acL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:937728636773 / 9007199254740992\0121=new org.apache.commons.math3.fraction.BigFraction:0\012",
        Z.run(T, 2, 19, 2, 21, "\udaeb\uddbc\ud86b\udd0d\000\000\000\uda1f\udfe2\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udbad\udfa4\ud9b5\udd9a\udba1\udce4", "\u559f\uacdc\uc819\u1354\u1c29\u05f3\u0df2\u0e32\u577b\ud0f0\u1782\u7f60\uc45e\u6f5d", "\ud9dd\udefc\ud887\udd2c\u1852\udad3\udff9\uda37\udd56\udb10\udec3",
        35, 53058, 486935869, -5115883252360616892L, -77399L, true, true, (char) 60901, (char) 49258,
        Double.longBitsToDouble(0x3f1b4a9f6eeca000L), Double.longBitsToDouble(0x3fe8cc026498a04eL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:-426323604364122021 / 1928\0121=new org.apache.commons.math3.fraction.BigFraction:0\012",
        Z.run(T, 2, 0, 2, 21, "\udaff\udfbc\ud86b\udd0d\000\000\000\uda1f\udfe2\u1f39\u00a6\uf143\ud974\ude9d\udac0\ude8f\ued31\udba1\udce4", "\u559f\uacdc\uc819\u553e\ucf46\u05f3\u0df2\u0e32\u577b\u77e5\u3066\u2471\u819d\u6f11", "\u793e\uda54\udc69\u1852\udad3\udff9\uda37\udd56\udb10\udec3",
        35, 53058, 486935869, -5115883252369464252L, 23136L, true, true, (char) 11365, (char) 52992,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:3 / 3533\0121=new org.apache.commons.math3.fraction.BigFraction:3 / 3533\012",
        Z.run(T, 2, 6, 22, 27, "\udaff\udfbc\ud86b\udd0d\000\000\udbb0\ude38\uda1f\udfe2\ud87b\udd91\ud9df\ude3d\ue1c1\ud974\ude9d\udb22\udcbf\udaf9\udcde\udac9\udd21", "\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\ud626\ud7f0\u1782\u5ef8\u565c\u6f5d", "\ud9dd\udefc\ud887\udd2c\u1852\udad3\udff9\udb64\udecd\udae8\udc33",
        45, 52995, 486935869, -5115883252369464252L, 23136L, true, true, (char) 15271, (char) 4850,
        Double.longBitsToDouble(0x3fec9763dc38595bL), Double.longBitsToDouble(0x3fe44b8542499b6dL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:27 / 73238\0121=new org.apache.commons.math3.fraction.Fraction:27 / 73238\012",
        Z.run(T, 2, 30, 14, 12, "\udaff\udfbc", "\u79b3\u7cd9\u4b39\uc7d3\u2c14\ubd62\ub948\u7923\u7fed\uced1\u6183\u0f98\u559f\uacdc\uc819\u2fe0\u1be9\u4e8a\u27f6\u2d39\u62fb\u3c69\u300e\u988f", "\uda0d\udee4",
        27, 73238, 131425300, -6169904749258362682L, -34190L, false, false, (char) 8513, (char) 7565,
        Double.longBitsToDouble(0x3fe248e8345d2e3eL), Double.longBitsToDouble(0x3fd3c7e252b0e14eL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:2419136591847869 / 4503599627370496\0121=new org.apache.commons.math3.fraction.BigFraction:2419136591847869 / 4503599627370496\012",
        Z.run(T, 2, 3, 3, 19, "\udaff\udfb4\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\udb5c\udefc\udbab\udf1d\uda8b\udd4a\ue1c1\ud974\ude9d\uda5d\udc8d\ud9eb\udf0a\ud8d7\udf00", "\u559f\uacdc\u3ed7\u2fe0\u10f2\u6a12\u0df2\u0e32\u577b\ud7f0\u1782\u685c\ud4d5\u6f4b\u0b2b\u77d0\ub4c3\uadfe\u52d6\u98b9\u4d1d", "\ud996\udfa9\udb6f\udef2\ud81b\udf1f\ud85a\udfb3\uda2d\udfdf\uda01\udf1c\ud934\ude52\ud8fa\udcdc\u95c3\ud9be\udf63\ud889\udd74\ud892\ude3d\udbff\udd1a\udb7d\udcb0\ud85b\udc86\uda00\udc0d\ud8de\ude32\uda9e\udece",
        49, 76486, -401065748, 3225260919043816621L, -47099L, false, false, (char) 92, (char) 57188,
        Double.longBitsToDouble(0x3fe130624270c37aL), Double.longBitsToDouble(0x3f92588ca0d89520L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:0\0121=new org.apache.commons.math3.fraction.BigFraction:3225260919043816621\012",
        Z.run(T, 2, 3, 1, 21, "\000\ud872\udff9\ud895\udc5e\ud8b2\udc90\udbe0\udd3f\udb5c\udefc\udbab\udf1d\uda8b\udd4a\udab2\udcbb\ud974\ude9d\uda5d\udc8d\ud9eb\udf0a\ud987\udef8", "\016\000\u970e\000\ucf46\u05f3\u0df2\u0e32\u573e\ud7f0\u1782\u685c\ud4d5\u6f4b\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d", "\uda0a\udda2\ud945\udd3d\000\uec44\udab5\ude99\uda01\udf1c\ud934\ude52,\ud930\udd97\ud9be\udfb1\ud889\udd74\ud892\ude3d\uda29\udccf\000\000\uda00\udc0d\ud8de\ude32\uda9e\udece",
        49, -866, -401065984, 3225260919043816621L, -47099L, false, false, (char) 92, (char) 29284,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:-5\0121=new org.apache.commons.math3.fraction.Fraction:-5\012",
        Z.run(T, 2, 11, 27, 21, "\udaff\udfbc\ud888\udcfc\udbdc\udfe7\udb99\udef5\000\udbd2\ude6d\000\ud846\ude56\uadcc\ud974\ude9d\ud9fe\udded\ud9eb\udf0a\ud8ff\udc33", "\uad8b\uacdc\uc819\u2fe0\u1be9", "\ud8b5\udcfe\ud8fb\udf83\ud99e\udf85\uda08\udc0f\000\u819d\000\ud9ca\ude1b\000\ud9bf\uddbe\ud887\udd2c\ud8ae\udf46\udad3\udff9\uda37\udd56\udb27\udcc3\udbfd\ude52\uda0a\udda2\ud945\udd3d\000",
        -5, 43192, -1444937640, 16372187392L, -68093L, false, false, (char) 0, (char) 64742,
        Double.longBitsToDouble(0x3fcfa0ae08024fd0L), Double.longBitsToDouble(0x3fca10ba2c21eb64L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:3 / 4\0121=new org.apache.commons.math3.fraction.Fraction:-21 / 1000\012",
        Z.run(T, 2, 28, 30, 0, "\udaff\udfbc\ud888\udcfc\000\000\000\000\000\uda8b\udd97\udbfc\udc7d\ud974\ude9d\ud9fe\udded\ud9eb\udf0a\udba1\udce4", "\uad0e\uacdc\uc819\u2fe0\u1be9\u67f2\u00b3\u5ee3\u573e\ud7f0\013\000\u819d\000\000\000\000\uadfe\u52d6\u6951\u4c76\uc6ab\ua929\u0386\u2544\000\000\000X", "\udaf4\ude2a",
        21, -1000, -1605500928, 391914973657322749L, 46224L, false, false, (char) 0, (char) 41317,
        Double.longBitsToDouble(0x3fe8000000ec690fL), Double.longBitsToDouble(0x3fdb8e8188016f84L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:0\0121=!org.apache.commons.math3.exception.NullArgumentException\012",
        Z.run(T, 2, 28, 4, 2, "\ud874\udd74\ud888\udd60\000\000\udaf8\ude5c\000\000\uda8b\udd97", "\ucadc", "\ud9ba\ude67\udbbd\udc11\ud953\udea5\ud873\udc6d\ud97a\udc38",
        31, 86930, 1466892370, 769365370368L, 61765L, true, false, (char) 76, (char) 33180,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3edd200000000000L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:8 / 13\0121=new org.apache.commons.math3.fraction.Fraction:167 / 271\012",
        Z.run(T, 2, 28, 10, 19, "\ud8cc\udcf0\uda76\udcbd\ud964\uddee\udb96\udc44\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ud98a\udcc1\ud8fb\udc95\ud8db\udf1e\udb53\uddb4\ud971\udebb", "\u568a\uacdc\uc819\ua69d\u1e44\u05f3\ub871\u797a\ubebe\ud7f0\u1782\u988f\ub910\u5772\u0682\ud51a\ub49f\u55ae\u26eb\u542f\u4969\ub72a\u86a0\u6ed7\u1fa3\u92e8\uc9c6\ub6c0\uc04a", "\udaf4\ude59\ud9be\udfb1\ud9fa\udeec\ud900\uddd2\uf4ea\udbd7\ude9e\ud800\udc45",
        56, 8933, -432935911, 1151184026402184106L, 31832L, true, false, (char) 17862, (char) 3206,
        Double.longBitsToDouble(0x3fe3b82717cee7dbL), Double.longBitsToDouble(0x3fd25c5f731482b8L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:0\0121=new org.apache.commons.math3.fraction.BigFraction:0\012",
        Z.run(T, 2, 16, 1, 21, "\udaff\udf69\ud888\udcfc\ud81a\udc60\u3e26\000\000\udb7e\udddb\uda8b\udd97\udab2\udc78\ud974\ude9d\ud9fe\udded\000\000", "\u5591", "\uda73\udd4c\ud9c8\udf01\ud82e\udf79\udbf2\udfa7\ud876\udc2f\uda61\udcaf\ud99e\udf85\013\000\u819d",
        38, 66778, 1848723, 0L, -100000L, false, false, (char) 24746, (char) 0,
        Double.longBitsToDouble(0x3fe800000044b958L), Double.longBitsToDouble(0x3f3f894000000000L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:3 / 4\0121=new org.apache.commons.math3.fraction.BigFraction:0\012",
        Z.run(T, 2, 8, 0, 15, "\udad2\udd69\u73f2\000\u3e00\000\000\udb7e\udddb\uda8b\udd97\udab2\udc78\000\ud9da\udc0c\000\000", "\u559f", "\uda73\udd4c\ud9c8\udf01\ud82e\udf79\udbf2\udfa7\ud876\udc2f\000\000\udac0\ude0c\udb67\udd77\u819d",
        38, 66778, 147, 0L, -100000L, true, true, (char) 170, (char) 121,
        Double.longBitsToDouble(0x3fe800000000b958L), Double.longBitsToDouble(0x3f3f894000000000L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:0\0121=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 8, 15, 16, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\udb2d\udebf\ud856\ude48", "\u559f\uacdc\uc819\u2fe0\u1be9", "\ud876\udc2f\uda73\uddec\ud99e\udf85\udac0\ude0c\udb67\udd77\u18ef\udbee\udfdf\ud9e0\udd1d\ud9ec\udce1\ud9dd\udefc\ud887\udd2c\ud8ae\udf46\udad3\udff9\uda37\udd56\udb10\udec3\udbfd\ude52\uda0a\udda2\udb6f\udef2\ud81b\udf1f",
        -1, 15884, -1820729000, 3199013485180338561L, -2557L, false, true, (char) 56424, (char) 35343,
        Double.longBitsToDouble(0x3fcfa0ae0bea4fd0L), Double.longBitsToDouble(0x3fca10ba2c21eb64L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:1\0121=new org.apache.commons.math3.fraction.Fraction:1\012",
        Z.run(T, 2, 25, 13, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\ud9f2\udc91\udb7e\ude14\uda72\udd19\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u7d3f\ud7f0\u1782\u988f\ud4d5\u883c\ud458\u353a\ub524\uadfe\u14d7\u98b9\ua3d5\u880b\u74b8\u63d3\u1fa3\ub78b\uc9c6\ub6c0\u60b8", "\udaf4\ude2a",
        10, 95335, 1329793948, 7532483275006231264L, 46224L, true, true, (char) 6480, (char) 21861,
        Double.longBitsToDouble(0x3fee8feac1e25603L), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:22548398355795 / 281474976710656\0121=new org.apache.commons.math3.fraction.BigFraction:22548398355795 / 281474976710656\012",
        Z.run(T, 2, 19, 19, 27, "\ud8e2\udef6\udb6c\udf93\ud81a\udcc8\ud8dd\uddb6\udbe0\udd3f\uda20\udc88\udb7e\ude14\ud855\udf24\u652e", "\u997f\u6e39\u39b9\u15a6\ua525\uac81\ua523", "\ud91b\ude52\udbf2\udfa7\ud876\udc7e",
        5, 3765, -1706231797, -7967345240313462371L, -10146L, true, true, (char) 45402, (char) 50734,
        Double.longBitsToDouble(0x3fb481f546355300L), Double.longBitsToDouble(0x3fe53f94e5967173L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:124515685 / 507039462\0121=new org.apache.commons.math3.fraction.BigFraction:9079257139886133564\012",
        Z.run(T, 2, 2, 1, 21, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8b2\udcb6\udbe0\udd3f\uda16\udf88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9d7\udf8e\udba1\udce4", "\u559f\uacdc\uc819\u2fe0\u1be9\u05f3\u5a26\u0e32\u577b", "\udb67\udd77\u18ef\udbee\udfdf\ud9e0\udd1d\ud9ec\udce1\ud9dd\udefc\ud887\udd2c\ud8ae\udf46\udad3\udff9\uda37\udd56\udb10\udec3\udbfd\ude52",
        43, -939, -1185415168, 9079257139886133564L, 84879L, true, true, (char) 49258, (char) 38893,
        Double.longBitsToDouble(0x3fcf6ef7a0660130L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:1 / 200\0121=new org.apache.commons.math3.fraction.Fraction:1 / 200\012",
        Z.run(T, 2, 30, 30, 4, "\udaa5\udda6\udb2b\udf15\udaef\udc05\ud8b5\uded7\ud814\udcfa\uda28\uddd0\ue891\uda69\udfe3", "\u1dcf\u997f\u6e39\u16dc\uad9c\u1837\uacdc\uc918\u6fe8\u1be9\u85e4\u6ef2\u9586\uacba\ud73d\u7903\uae8c\u32ec\u9aab", "\ud9dd\uded1\ud840\udfb3\udbbb\udf2e\udad3\udf6f\uda37\udd56\udb10\udec3\ud94e\uddfa\udbc6\udc2f\ud8f0\udedc\ud81b\udf1f\udad2\ude90\uda2d\udfdf\udaec\udef2\udbaf\ude0f\udb8c\udf8e\udae9\udf00\udaf6\udf6b\udab3\udcdb\ud912\udde4\ud804\udfd7\ud9a2\udfbb\ud871\udcae\ud9ac\ude0c\ud879\udffd\ud865\udf71\udab8\udcfa\udba6\udfc7\000",
        -5, -1000, 0, 0L, 31685L, false, true, (char) 63765, (char) 19702,
        Double.longBitsToDouble(0x3fda636e2d5d467cL), Double.longBitsToDouble(0x3f82c88e1f3f9940L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:11737889 / 67108864\0121=new org.apache.commons.math3.fraction.BigFraction:55 / 88842\012",
        Z.run(T, 2, 15, 22, 7, "\udafc\udd3c\uda32\udf64\000", "\u660b", "\ue1c1\ub59b\ud96c\ude8f",
        55, 88842, 88, 8926561070012927246L, -100000L, false, false, (char) 39074, (char) 45063,
        Double.longBitsToDouble(0x3fc6636420000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:614727 / 926129755\0121=new org.apache.commons.math3.fraction.Fraction:614727 / 926129755\012",
        Z.run(T, 2, 2, 15, 29, "\udbf0\ude06\uda75\uddf9\udaec\ude48\udb5f\udd11\u114a\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u4b83\uad1a\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\u230a\u1782\u988f\ud4d5\u742c\u5cc8\u50f7\ub556\000\u5284\u98b9\u4d1d\u11ac\u16ac\u4a40\u93e6\ub74d\ucfc5\ub6c0\u60b8", "\udaf4\ude2a",
        59, 32758, 0, -2546893339657484493L, -100000L, false, true, (char) 6384, (char) 41231,
        Double.longBitsToDouble(0x3f45c003b0fc5000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:614727 / 926129755\0121=new org.apache.commons.math3.fraction.BigFraction:614727 / 926129755\012",
        Z.run(T, 2, 2, 2, 12, "\udaec\ude72\uda32\udf64\udb21\udddc\udb5f\udd11\u114a\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\u4b83\uad1a\uc819\u902b\u4f29\u05f3\u0df2\u0e32\u577b\u230a\u1782\u988f\ud4d5\u742c\u5cc8\u50f7\ub556\000\u5284\u98b9\u4d1d\uc6ab\u0820\u6430\u1fa3\ub78b\ucfc5\ub6c0\u9f73", "\udaf4\ude2a",
        59, 32758, 0, 0L, -100000L, false, true, (char) 6377, (char) 37348,
        Double.longBitsToDouble(0x3f45c003b0fc5000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:0\0121=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 2, 28, 18, "\ud916\udca4\ud85b\udd7b\udb21\uddf3\udb5f\udd11\u114a\uda20\udc88\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\udac0\ude8f\ud86a\udc29\ud87e\udea1", "\ubd96\uad1a\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\u230a\u1782\u988f\ud4d5\u742c\u5cc8\u50f7\ub556\000\u5284\u98b9\u4d1d\uc6ab\ub8a1\u48e8\u204a\ub78b\ucfc5\ub6c0\u60b8", "\udaa9\udcf5\udae5\udf2b\ud941\udfb6",
        -5, -1000, -1006632960, 7579981762945353943L, -50951L, false, false, (char) 44544, (char) 30720,
        Double.longBitsToDouble(0x3d91c00000000000L), Double.longBitsToDouble(0x3fe621a960dca6ffL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:0\0121=new org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 2, 11, 27, 17, "\udaff\udfbc\ud888\udcfc\ud81a\udc60\ud8cf\udca5\ud872\udfa2\ud8d6\ude7e\ud83e\udf29\uda8b\udd97\ue1c1\ue4cf\udac0\ude8f\ud9eb\udf0a\udba1\udce4", "\ua371\uacdc\u3e07\u2fe9\u3675\u6799\u0df2\u0e32\u577b\ud7f0\u3c3c\uad46\u7583\u7de1\u0bb2\ua05b\u70b2\ucdfe\u4f15\ud244\u20ab\u71a2\ud6d8\u5600\u710d\u87ba\uca22\ub6c0\u60b8", "\u7f1c",
        0, 99221, 1884496493, 819856600777403747L, -84848L, false, false, (char) 48606, (char) 48241,
        Double.longBitsToDouble(0x3fe73fcf70096382L), Double.longBitsToDouble(0x3fdb8e81895b6f84L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:0\0121=new org.apache.commons.math3.fraction.BigFraction:0\012",
        Z.run(T, 2, 25, 2, 21, "\udaff\udfbc\ud86b\udd0d\000\u0088\ud9a0\ude86\ud8cc\ude07\u1f0f\u00a6\uf143\ud974\ude9d\udac0\ude8f\ued31\udba1\udce4", "\uc083\uacdc\uc819\u8d5a\u910c\u05b9\u0df2\u0e32\u577b\u77e5\u3066\u2471\u819d\u6f11", "\u793e\uda54\udc69\u1852\udad3\udff9\ud9dd\udd56\udb10\udec3",
        35, 53058, 486935869, -1657118738548923271L, 23136L, true, true, (char) 11365, (char) 52992,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 8, 2, 20, "\udaff\udfbc\ud86b\udd0d\ud9fe\udd08\ud89b\udf4c\u00fe\ud87c\ude49\u1f60\u00a6\uf143\ud974\ude9d\udac0\ude8f\ued31\udba1\udce4", "\u559f\uacdc\uc819\u553e\ucf46\ucd5a\u8974\ubbf4\u577b\u0843\u30d8\u38b8\u4521\ube79", "\u793e\uda54\udc69\u1852\ud910\ude59\ud938\udf5f\udb10\ude94",
        -2, 40081, 486959387, -5115883255438224763L, 39007L, true, true, (char) 11365, (char) 52992,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:0\0121=new org.apache.commons.math3.fraction.Fraction:0\012",
        Z.run(T, 2, 13, 13, 21, "\udaff\udfbc\ud86b\udd0d\000\ud96e\udc97\uda67\udc40\udb2c\udf60\ue6cf\ud8eb\udf7f\u0bda\ud974\ude9d\udac0\ude8f\ued31\udba1\udce4", "\u559f\uacdc\uc819\u553e\ucf46\u05f3\u0df2\u0e32\ua5ac\u290f\uc432\u2471\u819d\u6f11", "\u793e\uda54\udc69\u1852\ud92c\udc53\uda37\udd67\udb10\udec3",
        35, 10307, 486935869, -5115883252369464252L, 23136L, true, true, (char) 11365, (char) 52992,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:221 / 67108864\0121=new org.apache.commons.math3.fraction.BigFraction:221 / 67108864\012",
        Z.run(T, 2, 3, 19, 21, "\000\ud872\udff9\ud895\udc5e\ud8b2\udc90\udbe0\udd3f\udb5c\udefc\udbab\udf1d\uda8b\udd4a\udab2\udcbb\ud974\ude9d\uda5d\udc8d\ud9eb\udf0a\ud987\udef8", "\016\000\u970e\u6ca6\ucf56\u05f3\u0df2\u0e32\u573e\ud7f0\u1782\u685c\ud4d5\u6f4b\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d", "\uda0a\udda2\ud945\udd3d\000\uec44\udab5\ude99\uda01\udf1c\ud934\ude52,\ud930\udd97\ud9be\udfb1\ud889\udd74\ud892\ude3d\uda29\udccf\000\000\uda00\udc0d\ud8de\ude32\uda9e\udece",
        49, -866, -401065984, 3225260919043816621L, -47099L, false, false, (char) 92, (char) 10596,
        Double.longBitsToDouble(0x3ecba00000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:3 / 4\0121=new org.apache.commons.math3.fraction.Fraction:3 / 4\012",
        Z.run(T, 2, 28, 10, 0, "\udaff\udfbc\u73ef\000\000\000\000\000\uda8b\udd97\udbfc\udc7d\ud974\ude9d\u00e1\ud9eb\udf0a\udb69\udf69", "\000\ua14a\uc819\u2fe0\u1be9\u67f2\u00b3\u5ee3\u85a1\ud0d4\000\000\000\000\000\000\000\uadfe\u52d6\u6951\000\000\ua929\u0386\u2544\000\000\000\000", "\udaf4\ude2a",
        21, -1000, -1605500928, 391914973657322749L, 46224L, false, false, (char) 0, (char) 41317,
        Double.longBitsToDouble(0x3fe800000000690fL), Double.longBitsToDouble(0x3fdb8e8180000000L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:614727 / 926129755\0121=new org.apache.commons.math3.fraction.Fraction:614727 / 926129755\012",
        Z.run(T, 2, 15, 15, 29, "\udbf0\ude06\uda75\uddf9\udaec\ude48\udb5f\udd11\u114a\uda20\udc88\udb95\udd7f\udb98\udeb7\uda75\udef6\udb94\udf46\udac0\ude8f\ud00e\udba1\udcb9", "\u4b83\ubf94\uc884\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\u876c\u1782\u0198\ud4d5\u742c\u5cc8\u50f7\ub556\000\u5284\u98b9\u4d1d\u11ac\u16ac\u4a40\u02dc\ub74d\ucfc5\ub6c0\u60b8", "\udaf4\ude2a",
        59, 32758, 0, -2546893339657484493L, -100000L, false, true, (char) 6384, (char) 41231,
        Double.longBitsToDouble(0x3f45c003b0fc5000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:35041217 / 62222074\0121=new org.apache.commons.math3.fraction.BigFraction:35041217 / 62222074\012",
        Z.run(T, 2, 2, 2, 12, "\ud8c1\udfdd\udbef\udc8a\udb21\udddc\udb5f\udd11\udb0a\udf2c\uda44\udcf3\udb7e\ude14\uda8b\udd97\ue1c1\ud974\ude9d\uda7d\udc0c\uda04\ude48\udbe1\udd90", "\u4b83\uad1a\uc819\u902b\u4f29\u05f3\u0df2\u0e32\u577b\u230a\u1782\u988f\ud4d5\u742c\u5cc8\u50f7\ub556\000\u5284\u98b9\u4d1d\u8c3c\u0820\u6430\u1fa3\ub78b\ucfc5\ub6c0\u9f73", "\udaf4\ude2a",
        59, 32758, 0, 0L, -100000L, false, false, (char) 6347, (char) 37348,
        Double.longBitsToDouble(0x3fe205700026fef2L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:1 / 200\0121=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 30, 24, 18, "\ud916\udca4\ud85b\udd7b\udb21\uddf3\udb5f\udd11\ud98a\ude20\ud8ed\udd15\udbdc\udc42\ud85f\udfb9\ue1de\ud974\ude9d\udac0\ude8f\ud86a\udc29\ud87e\udea1", "\ubd96\uad1a\uc819\u2fe0\u1be9\u05f3\u0df2\u0e32\u577b\u230a\u1782\u988f\ud4d5\u742c\u5cc8\u50f7\ub556\000\u5284\u98b9\u4d1d\uc6ab\ub8a1\u48e8\uaa72\uc936\ucfc5\ub6c0\u60b8", "\udbbb\udfd1\udae5\udf66\ud941\udfb6",
        -5, -1000, -1006632960, 7579981762945353943L, -50951L, false, false, (char) 44544, (char) 30720,
        Double.longBitsToDouble(0x3d91c00000000000L), Double.longBitsToDouble(0x3fe621a960dca6ffL)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:3 / 4\0121=new org.apache.commons.math3.fraction.Fraction:3 / 4\012",
        Z.run(T, 2, 28, 12, 0, "\udb8b\uddc0\uda2d\udd72\udaae\udf86\uda50\udd7a\udad0\udc47N\000\uda8b\udd97\udbfc\udc7d\ud974\ude9d\u00e1\udafd\udfc0\ud9b0\udf0d", "\000\ua14a\uc819\u141e\u1bb3\u67f2\u00b3\u5ee3\u85a1\ud0d4\000\000\000\000\000\000\000\uadfe\u52d6\u6951\000\000\u8412\ub6d7\u4d84\000\000\ub99b\ud10d", "\udaf4\ude2a",
        21, -1000, -1605500928, 391914973657322749L, 46224L, false, false, (char) 0, (char) 41317,
        Double.longBitsToDouble(0x3fe800000000690fL), Double.longBitsToDouble(0x3fdb8e8180000000L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.Fraction:72344129 / 73690543\0121=new org.apache.commons.math3.fraction.Fraction:72344129 / 73690543\012",
        Z.run(T, 2, 15, 15, 12, "\ud934\udf53\uda75\uddf9\udaec\ude48\udb5f\udd11\u114a\uda20\udc88\udb95\udd7f\udb98\udeb7\ud9fe\ude0a\udb94\udf46\udac0\ude8f\ud00e\udba1\udcb9", "\u4b83\ubf94\uc884\u236e\u5847\ud540\u0df2\u0e32\u577b\u87cb\u1782\u0198\u1ccf\u742c\ubf31\u2004\ub556\000\u8372\ua59b\u2be4\u11ac\u16ac\u1501\u02dc\ub74d\ucfc5\ub6c0\u60b8", "\udaf4\ude2a",
        50, 43267, 80, -2546048918484119015L, -100000L, false, true, (char) 17334, (char) 32875,
        Double.longBitsToDouble(0x3fef6a5288ec3fbbL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:1\0121=new org.apache.commons.math3.fraction.Fraction:25\012",
        Z.run(T, 2, 2, 27, 2, "\udb04\udebc\ud888\udcfc\ud81a\udc60\uda8a\udd30\udb0f\udf0f\ud800\ude06\ud851\udc33\uda67\udc92\ue1c1\ud974\ude9d\udac0\ude8f\ud9eb\udf0a\ud80e\ude1c\ud81c\udecd\udbdb\udd4e\uda21\udeac\ud912\udce3\ud97a\udc38\udaa1\udc22\ud9c8\udf01\ud82e\udf79\udb40\udc4d\ud876\udc2f\uda73\uddec\ud99e\udf85", "\ud4d5\u6f5d\u0b2b\u7813\ub4c3\uadfe\u52d6\ub77a\u1c85", "\uda0a\udda2\udb6f\udef2\ud81b\udf1f\uda67\uddbb\udae3\uddd9\udaec\udef2\udb08\udc6e\uda42\udc17\udaf4\ude2a\uda81\ude54\ud989\udd04\ud900\udd75",
        25, 42997, -2049860870, 8852322941891877640L, 94474L, true, false, (char) 51456, (char) 21969,
        Double.longBitsToDouble(0x3fed6dbe1018d54bL), Double.longBitsToDouble(0x3fe0d15f567a93beL)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:0\0121=new org.apache.commons.math3.fraction.BigFraction:0\012",
        Z.run(T, 2, 3, 3, 21, "\000\ud872\udff9\ud895\udc5e\ud8b2\udc90\udbe0\udd3f\udb5c\udefc\udbab\udf1d\uda8b\udd4a\udab2\udcbb\ud974\ude9d\uda5d\udc8d\ud9eb\udf0a\ud987\udef8", "\016\000\u970e\000\ucf46\u05f3\u0df2\u0e32\u573e\ud7f0\u1782\u685c\ud4d5\u6f4b\u0b2b\u7813\ub4c3\uadfe\u52d6\u98b9\u4d1d", "\uda0a\udda2\ud945\udd3d\000\uec44\udab5\ude99\uda01\udf1c\ud934\ude52,\ud930\udd97\ud9be\udfb1\ud889\udd74\ud892\ude3d\uda29\udccf\000\000\uda00\udc0d\ud8de\ude32\uda9e\udece",
        49, -866, -401065984, 3225260919043816621L, -47099L, false, false, (char) 92, (char) 29284,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:3 / 4\0121=new org.apache.commons.math3.fraction.BigFraction:3 / 4\012",
        Z.run(T, 2, 8, 8, 15, "\udad2\udd69\u73f2\000\u3e00\000\000\ud883\uddfc\uda73\udfec\udaf1\udecf\000\ud9da\udc0c\000\000", "\u559f", "\uda73\udd4c\ud9c8\udf01\ud82e\udf79\udbf2\udfa7\ud876\udc2f\000\000\udac0\ude0c\udb67\udd77\u819d",
        38, 66778, 147, 0L, -100000L, true, true, (char) 170, (char) 121,
        Double.longBitsToDouble(0x3fe800000000b958L), Double.longBitsToDouble(0x3f3f894000000000L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:-426323604632557477 / 1928\0121=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 0, 9, 15, "\uda13\ude65\ud86b\udd0d\uda77\udd7e\000\000\uda1f\udfe2\u1f39\u00a6\udbc7\udfe2\ud974\ude9d\udac0\ude8f\ued31\udba1\udce4", "\u6ca7\ub094\u288d\ua95b\u5683\u4663\u0df2\u0ed8\u577b\u75a2\ua93b\u2471\u819d\u020c", "\ud968\ude71\uda81\udc74\u1852\udad3\udff9\uda37\udd56\udb10\udec3",
        35, 53058, 486935869, -5115883255590689724L, 23136L, true, true, (char) 11365, (char) 23552,
        Double.longBitsToDouble(0x3fd000000000e2f8L), Double.longBitsToDouble(0x3d15c00000000000L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 15, 4, 20, "\ud870\udcf2\ud921\udf26\uda77\uddd3\000\000\ud9b4\udd85\ufd2c\u00a6\udbc7\udfe2\ud974\ude9d\udac0\ude8f\ued31\udba1\udce4", "\u6ca7\ub094\u288d\ua95b\u5683\ua732\u0df2\u0ed8\u6ea2\u812f\ua93b\u338e\ud5e6\u01d0", "\ud968\ude7e\uda81\udc74\u1852\ud98a\udfc8\uda37\udd91\udb10\udec3",
        35, 68437, 486935869, -5115883255590689724L, -904L, true, true, (char) 11365, (char) 23552,
        Double.longBitsToDouble(0x3fd000000000e2f8L), Double.longBitsToDouble(0x3d15c00000000000L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=new org.apache.commons.math3.fraction.BigFraction:-426323604632557477 / 1928\0121=!org.apache.commons.math3.fraction.FractionConversionException\012",
        Z.run(T, 2, 0, 13, 15, "\uda13\ude65\ud86b\udd0d\uda77\udd7e\ueb00\000\uda1f\udfe2\u1f39\u00a6\ud9b6\udce5\ud974\ude9d\udac0\ude8f\ued31\udba1\udce4", "\u6ca7\ub094\u288d\ua95b\u6cbc\u810c\u2f26\u0e28\u577b\u75a2\ua93b\u2471\u819d\u020c", "\ud968\ude71\uda81\udc74\udbb0\udd5e\udad3\udff9\uda37\udd56\udb10\udec3",
        42, 53058, 486935869, -5115883255590689724L, 23136L, true, true, (char) 11365, (char) 23552,
        Double.longBitsToDouble(0x3fd000000000e2f8L), Double.longBitsToDouble(0x3d15c00000000000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|long,long",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|long",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|double,double,int",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|double",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|java.math.BigInteger,java.math.BigInteger",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|java.math.BigInteger",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|int,int",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|int",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|double,int",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|double,double,int,int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|double",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|double,int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|double,double,int,int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|int,int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|double,double,int",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|long,long",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|long",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|double,double,int",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|double",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|java.math.BigInteger,java.math.BigInteger",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|java.math.BigInteger",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|int,int",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|int",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|double,int",
    "C|org.apache.commons.math3.fraction.BigFraction|<init>|double,double,int,int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|double",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|double,int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|double,double,int,int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|int,int",
    "C|org.apache.commons.math3.fraction.Fraction|<init>|double,double,int",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
