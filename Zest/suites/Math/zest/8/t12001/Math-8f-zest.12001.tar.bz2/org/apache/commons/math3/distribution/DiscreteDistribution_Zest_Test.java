package org.apache.commons.math3.distribution;
import org.junit.Test;
import static org.junit.Assert.*;
public class DiscreteDistribution_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 6, 4, 2, "\udb08\udd05\ud85c\udf09\ud85b\udd44", "\u63eb\ub850\u3739\u1745\u0b67\u92cb\u42ee\u55f9\u3476\ua51b\u89a1\ub8c0\u08dc\u8419\u3b19\u1b91", "\ud932\udc19\uda8a\udeaf\udbb7\ude83\udb02\udf54\ud971\udf48\ud8e5\udd09\ud82e\ude68\udaaf\ude46\udbd7\udc60\uc77e\udbb8\udf47\ud843\ude37\ud9c2\udf28",
        48, 94855, -703264467, 5743673431909873077L, 43036L, true, true, (char) 13610, (char) 1162,
        Double.longBitsToDouble(0x3fe621983d2f3dcdL), Double.longBitsToDouble(0x3fe3d172f85550a1L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 6, 4, 2, "\udb08\udd05\ud85c\udf09\ud85b\udd44", "\u63eb\ub850\u3739\u1745\u0b67\u92cb\u42ee\u55f9\u3476\ua51b\u89a1\ub8c0\u08dc\u8419\u3b19\u1b91", "\uda54\udd8a\uda8a\udea5\udbb7\ude83\udb02\udf54\ud971\udf48\ud8e5\udd09\ud82e\ude68\udaaf\ude46\udbd7\udc60\uc77e\udbb8\udf47\ud843\ude37\ud9c2\udf28",
        28, 94855, -703264467, 5743673431909873077L, -86764L, true, true, (char) 13610, (char) 1162,
        Double.longBitsToDouble(0x3fe621983d2f3dcdL), Double.longBitsToDouble(0x3fe3d172f8557ba1L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 2, "\udb08\udd05\ud92d\ude4e\ud85b\udd44", "\u63eb\ub850\u93c6\u9285\u312b\u92cb\ua7d7\u3685\u3476\ua51b\u517b\u4b1e\u0882\u6c46\u3b70\ucc81", "\ud932\udc19\uda8a\uddc0\udbb7\udde4\udae6\udcfd\ud971\udf48\uda73\udd90\uda27\udf1f\udaaf\ude7c\udbd7\udc60",
        6, 89709, -1257217213, 2761875072925528426L, -32115L, false, false, (char) 34154, (char) 32839,
        Double.longBitsToDouble(0x3fe10ac3dbf9c9beL), Double.longBitsToDouble(0x3fe24ee23e6ade19L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 5, 5, 1, "\udb08\udd05\ud9ae\udcb1\ud913\udd22", "\u5ef8\uaea3\u9b24\u9fdf\u5751\u5ead\u10c4\u23b3\ua1d6\ua51b\u89a1\ub8c0\u8e27\ud677\u6eb0\u03df", "\ud92f\ude85\udaa2\udf1c\ud8dc\uddbf\udacc\udda8\ud971\udf48\ud8e5\udd09\ud82e\ude68\udaaf\ude46\udab6\udfb0\ud827\udccb\ud94a\udf50\ud843\ude37\ud9c2\udf28",
        48, 94855, -703264467, -7008829517890964043L, 43036L, true, true, (char) 13610, (char) 1162,
        Double.longBitsToDouble(0x3fe2d8603bfdb11eL), Double.longBitsToDouble(0x3fe3d172f85550a1L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 0, 4, 2, "\udb08\udd05\ud860\udd2a\ud85b\udd08", "\u63eb\ub850\u3739\u1745\u1acf\ua85d\u087a\u0092\000\ua51b\u89a1\ub8c0\u08dc\uc70f\u3b19\u8be8", "\000\uda8a\udeaf\udae5\udfd2\udb02\udf54\ud971\udf48\ud8e5\udd09\ud82e\udd9d\udaaf\ude46\udbd7\udc60\uc77e\udbb8\udf47\ud843\ude37\ud9c2\udf28",
        48, 94855, -703264467, 5743673431909873077L, 43036L, true, false, (char) 13610, (char) 1162,
        Double.longBitsToDouble(0x3fe621983d2f3dcdL), Double.longBitsToDouble(0x3fe3d172f85550a1L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 3, 5, 2, "\udb08\udd05\ud85c\udf09\ud85b\udd44", "\u63eb\ub850\u679c\u1727\u231b\u9230\u42ee\u55f9\u3476\ua51b\u8894\ub8c0\u08dc\u8419\u3b19\u1b91", "\udbb4\udefd\udbef\udd95\ud92b\udd31\uda31\uddb9\uda2d\ude09\uda88\udf92\ud82e\ude68\udaaf\ude46\udbd7\udc60\uc77e\udbb8\udf47\ud843\ude37\ud9c2\udf28",
        55, 30358, -703264467, 5601647711063782661L, 43036L, true, true, (char) 13610, (char) 1162,
        Double.longBitsToDouble(0x3fe621983d2f3dcdL), Double.longBitsToDouble(0x3fe997d1d0c5c1bfL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 4, 4, 2, "\udb08\udd05\ud8f2\udc93\uda05\udfd8", "\u75fe\u5ad3\u3819\u1745\u0b67\u92cb\u85de\u2757\ubffc\ua51b\u89a1\ub8c0\u08dc\u9fd8\u3b19\u1b91\uc2cc\u755c\u6343\ubdef\ua339\u4c9d\u17ba\u8d5f\u2d14\u9d34\u82df\u9d2c\ud06a\u8ea9\u02a4\u3e9c\u424a\u7f7e\ubf06\ud0c5\u5c60\u6f14\u2ffd\uad9b\u97ed\uc7b8\u9cc3\ua20a\ubf50\u8002\ua4ef\u45b8\u44e6\u42ed\uc68d\u145a", "\uda2e\udd77\ud924\udfce\ud9a1\udea7\ud8e1\udef1",
        20, 54813, -485657453, 5538403022806107874L, -58051L, false, true, (char) 30302, (char) 20320,
        Double.longBitsToDouble(0x3fb7f9fb440aa9f8L), Double.longBitsToDouble(0x3fee8c40324cd361L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 1, 4, 2, "\udb08\udd05\ud85c\udf09\uda16\udd5a", "\ubaf9\u14eb\ua72e\u1745\ucd91\u92cb\u42ee\u55f9\ub0bd\ua51b\u89a1\ub8c0\u08dc\u8419\u3b19\u1b91", "\ud932\udc19\uda8a\udeaf\udbb7\ude83\udb02\udf54\ud971\udf48\ud8e5\udd09\ud82e\ude68\udaaf\ude46\udbd7\udc60\uc77e\ud881\ude2b\udbd0\udd1e\ud9c2\udf53",
        48, 76935, -703264467, 5743673431909873077L, 43036L, true, true, (char) 52393, (char) 1308,
        Double.longBitsToDouble(0x3fe621983d2f3dcdL), Double.longBitsToDouble(0x3fe3d172f85550a1L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 6, 4, 2, "\udb08\udd05\ud85c\udf09\ud85b\udd44", "\u63eb\ub850\ucebc\u1745\u0b67\u92cb\u42ee\u55f9\u5328\u499e\u89a1\ub8c0\u08dc\u8419\u3b19\u1b91", "\ud932\udc19\uda8a\udeaf\udbb7\ude83\udb02\udf54\ud971\udf48\ud8e5\udd09\ud82e\ude68\udaaf\ude46\udbd7\udc60\uc77e\udbb8\udf47\ud843\ude37\udb63\udd97",
        48, 94855, 2067877358, 5743716029395514805L, 43036L, true, true, (char) 13610, (char) 50509,
        Double.longBitsToDouble(0x3fe621983d2f3dcdL), Double.longBitsToDouble(0x3fe3d172f85550a1L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.distribution.DiscreteDistribution|sample||new:org.apache.commons.math3.distribution.DiscreteDistribution:java.util.List",
    "M|org.apache.commons.math3.distribution.DiscreteDistribution|sample|int|new:org.apache.commons.math3.distribution.DiscreteDistribution:java.util.List",
    "M|org.apache.commons.math3.distribution.DiscreteDistribution|getSamples||new:org.apache.commons.math3.distribution.DiscreteDistribution:java.util.List",
    "M|org.apache.commons.math3.distribution.DiscreteDistribution|probability|java.lang.Object|new:org.apache.commons.math3.distribution.DiscreteDistribution:java.util.List",
    "M|org.apache.commons.math3.distribution.DiscreteDistribution|reseedRandomGenerator|long|new:org.apache.commons.math3.distribution.DiscreteDistribution:java.util.List",
    "C|org.apache.commons.math3.distribution.DiscreteDistribution|<init>|java.util.List",
    "C|org.apache.commons.math3.distribution.DiscreteDistribution|<init>|org.apache.commons.math3.random.RandomGenerator,java.util.List",
    "M|org.apache.commons.math3.distribution.DiscreteDistribution|sample||new:org.apache.commons.math3.distribution.DiscreteDistribution:java.util.List",
    "M|org.apache.commons.math3.distribution.DiscreteDistribution|sample|int|new:org.apache.commons.math3.distribution.DiscreteDistribution:java.util.List",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
