package org.apache.commons.math3.optimization.direct;
import org.junit.Test;
import static org.junit.Assert.*;
public class CMAESOptimizer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0....\012",
        Z.run(T, 1, 5, 8, 4, "\ud9f5\udd53\ud955\udec2\ud936\udc43\ud8ea\udfaa\udb1a\ude12\uc29b\ud9be\udd64\udbc6\udea9\ud8bc\udd39\ud8c3\udea7\uda11\udc1a\uda15\uddeb\uda81\uddd6\ud8b8\udc2c\ud907\udc09\udbe0\udc59\udaad\udf12", "\u065f\u2533\022\u7f22\u7498\u2185\ub089\u06b5\u6df4\u8a05\u75eb\u1bf8\ub87a\ucf71\u2f81\u119e", "\ud934\ude03\udbe7\udc83\uda77\udcd6\uc70d\udb4b\ude65\uda7d\udc6c\ud923\udc9d\udb07\udd08",
        28, 1525, 792563365, -2409700860635600707L, 7507L, true, false, (char) 6702, (char) 4876,
        Double.longBitsToDouble(0x3fda2faeb821b790L), Double.longBitsToDouble(0x3fbe4f3211d8afd8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0....\012",
        Z.run(T, 1, 5, 8, 4, "\ud9f5\udd53\ud955\udec2\ud936\udc43\ud8ea\udfaa\udb1a\ude12\uc29b\ud9be\udd64\udbc6\udea9\ud8bc\udd39\ud8c3\ude7c\uda11\udc1a\uda15\uddeb\uda81\uddd6\ud8b8\udc2c\ud907\udc09\udbe0\udc59\udaad\udf12", "\u065f\u2533\022\u7f22\u7498\u2185\ub089\u06b5\u6df4\u8a05\u75eb\u1bf8\ub87a\ucf71\u2f81\u119e", "\ud934\ude03\udbe7\udc83\uda77\udcd6\uc70d\udb4b\ude65\uda7d\udc6c\ud923\udc9d\udb07\udd08",
        28, 1525, 792563365, 7821070118399131693L, 7507L, true, false, (char) 6702, (char) 4876,
        Double.longBitsToDouble(0x3fc45f5d70436e68L), Double.longBitsToDouble(0x3fbe4f3211d8afd8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0....\012",
        Z.run(T, 1, 5, 8, 4, "\ud9f5\udd53\ud955\udec2\ud936\udc43\ud8ea\udfaa\ud944\udf27\ud83d\udf84\udb86\ude98\udaa7\ude12\ud8bc\udd4c\ud8c3\udea7\uda11\udc1a\uda15\uddeb\uda81\uddd6\ud8b8\udc2c\ud907\udc09\udbe0\udc59\udaad\udf12\uda9c\udea9\uda49\udedd", "\022\u7f22\u7498\u2185\ub089\u06b5", "\u0749\uda7c\ude28\ud824\udd89\udab0\uddbc\ud81b\udce4\udadb\udddc",
        40, 739, -1212940218, 5105727753568487949L, 24874L, true, true, (char) 53809, (char) 19925,
        Double.longBitsToDouble(0x3fe5280785d62f3dL), Double.longBitsToDouble(0x3fc7bbd1f0526b70L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0....\012",
        Z.run(T, 1, 5, 8, 4, "\ud9f5\udd53\ud955\udec2\ud93f\udc49\ud8ea\udfaa\udb1a\ude12\uc29b\ud889\udfab\udbad\udedc\ud8bc\udd39\ud8e4\udda2\uda11\udc1a\uda15\uddeb\uda81\uddd6\uda96\udfdb\ubc5e\ud983\udf9d\udbe2\udf9e", "\u065f\u2533\022\u7f22\u7498\u2185\ub089\u06b5\u6df4\u8a05\uc646\uce74\ub87a\ucf71", "\uda73\udf62\udbf2\udcb9\ud8cc\ude16\ud95d\udeb1",
        20, 35189, -456938143, 2801862938152003530L, -4170L, false, true, (char) 34636, (char) 18160,
        Double.longBitsToDouble(0x3fb89726965a7878L), Double.longBitsToDouble(0x3fe414273923d41cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0....\012",
        Z.run(T, 1, 5, 8, 4, "\ud9f5\udd53\ud955\udec2\ud936\udc43\ud8ea\udfaa\udb1a\ude12\uc29b\ud9be\udd64\udbc6\udea9\ud8bc\udd39\ud8c3\udea7\uda11\udc1a\uda15\uddeb\uda81\uddd6\ud8b8\udc2c\uda11\udd40\udbe0\udc59\udaad\udf12\ud84f\udc81\uf61f\ud8c7\udcd9\udb81\udde6\uda7a\udf6b\ud86c\ude69\ud973\udef1\ud951\ude01\udb30\udf7e\udacb\udcec\ud9f4\udf52\uda49\ude1e", "\ub87a\ucf71\u2f81\u119e\u3351\u3a44\u3897\u9451\u421d\u20c4\u1e11\u3838\u28d6\u3fd9\u46d0\ud5d9\u4ea2\u6633\u58de\ub574\u1d83\u7910\uacb9", "\ud8a7\ude0d\udb2e\udf44\ud832\udff8\ud9ef\udcca\udbb7\ude21\uda34\udcf0\udadf\udf35\udbf9\uddb4\ud8d4\udfa6\uda27\udd62\udb97\ude19\udb23\udc38\uda79\udf1d",
        24, 22407, -143394612, -8813531228375773590L, 13725L, false, false, (char) 34333, (char) 50659,
        Double.longBitsToDouble(0x3fd4a727afc7a798L), Double.longBitsToDouble(0x3fe63bab7f0987ecL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0....\012",
        Z.run(T, 1, 5, 8, 4, "\ud9f5\udd53\ud8e5\ude4a\ud936\udc43\ud8ea\udfaa", "\u4886", "\ud8c3\udea7\uda11\udc1a\uda15\uddeb\uda81\uddd6\ud8b8\udc2c\ud907\udc09\udbe0\udc59\udaad\udf12\uda9c\udea9\uda49\udedd\ud91d\ude5d\ud845\uddc9\ud9ed\udcb1\udb39\uddec\ud973\udef1\ud951\ude01",
        13, 99592, 1707593043, 1273336806378359810L, 41774L, true, false, (char) 14518, (char) 59435,
        Double.longBitsToDouble(0x3fc574e07968b870L), Double.longBitsToDouble(0x3fd76d0d10ae4098L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.apache.commons.math3.exception.NoDataException\012",
        Z.run(T, 1, 5, 4, 10, "\uda11\udc3a\udb76\ude39\ud8f5\udd63\ud8eb\udc0f\udb8b\udf6b\udbd9\udd9d\ud9be\udc9f\uda8c\udeeb\udb9d\udc6a\ud81e\ude93\ud805\uddbd\ud99c\udc68\uda93\udc8c", "\u6802\ub0ed\u7f75\ub58e\u065f\u2533", "\ud9cb\udf4f\u71e1\udb21\ude35\udb77\udea1\ud86c\udc2c\ud8ca\udf89\u0749\uda7c\ude28\ud824\udd89\udab0\uddbc\ud81b\udce4",
        0, 12569, -912354865, -5209285679449952169L, 63207L, false, false, (char) 37032, (char) 33606,
        Double.longBitsToDouble(0x3fec46318d1b9ae5L), Double.longBitsToDouble(0x3fc7ac38ddfc07acL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0....\012",
        Z.run(T, 1, 5, 8, 4, "\ud9f5\udd53\ud955\udec2\ud936\udc43\ud8ea\udfaa\udb1a\ude12\uc29b\u44f0\udafa\udc95\ud852\udeb4\ud8c3\udea7\uda11\udc1a\uda15\uddeb\uda81\uddd6\ud8b8\udc2c\ud907\udc09\udbe0\udc59\udaad\udf12", "\u065f\u2533\022\u7f22\u7498\u2185\ub089\u06b5\u6df4\u8a05\u75eb\u1bf8\u25d1\ucfa9\u2f81\u119e", "\ud934\ude03\udbe7\udc83\uda77\udcd6\uc70d\udb4b\ude65\uda7d\udc6c\ud923\udc9d\udb07\udd08",
        28, 57605, 792563238, -2409700860635600707L, 7507L, true, false, (char) 6702, (char) 4876,
        Double.longBitsToDouble(0x3fda2faeb821b790L), Double.longBitsToDouble(0x3fbe4f3211d8afd8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0....\012",
        Z.run(T, 1, 5, 8, 4, "\ud9f5\udd53\ud955\udec2\ud936\udc43\ud8ea\udfaa\udb1a\ude12\uc29b\ud9be\udd64\udbc6\udea9\ud8bc\udd39\ud8c3\udea7", "\u5faf\u2316\u0e66\ud046\ub16a\u7021\u404f", "\uda8b\udde0\ud86c\ude69\ud973\udef1\ud951\ude01\udb21\ude35\udacb\udcec",
        8, 35828, 933022722, -5002463172503939534L, 63385L, false, true, (char) 45998, (char) 45292,
        Double.longBitsToDouble(0x3fe2364c4857b7b4L), Double.longBitsToDouble(0x3fe06a36dbfc2f4dL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 0, 1, "\udb03\udc3b\ud974\udfe2\ud936\udc43\ud8ea\udfaa\udb1a\ude12\u1f82\ud85d\udc08\udbfd\udf84\ud9e7\udf5f\ud8c3\ude4b\udb19\udc32\uda15\uddeb\u385d\udb42\udfcf\udaaf\udfbc\ud954\udfbf\ud897\ude58", "\u065f\u2533\022\u8006\u56e1\u3184\u7ea6\u289b\uaa14\u2ba8\021\u1bf8\u9961\u4902\ub6f4\ub9d4", "\ud843\udf57\udb4f\udee0\uda05\udebe\ud81f\udcd8\ud804\ude20\udae1\udedd\ud878\udc1d\udb07\udd08",
        28, 1525, 790204069, -2409700860635600707L, -45855L, true, true, (char) 60557, (char) 16821,
        Double.longBitsToDouble(0x3fc2202d5c97398cL), Double.longBitsToDouble(0x3fef0580b206d534L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0....\012",
        Z.run(T, 1, 5, 8, 4, "\ud9f5\udd53\ud955\udec2\udb0e\udc4f\ud8ea\udfaa\udb1a\ude12\uc29b\ud9be\udd64\udbc6\udea9\ud8bc\udd39\ud8c3\udea7\uda11\udc1a\uda15\uddeb\uda81\uddd6\ud8b8\udc2c\ud907\udc09\udbe0\udc59\udaad\udf12", "\u0089\u3ba8\021\u7f22\u7498\u2185\ub089\u06b5\u6df4\u8a05\u75eb\u1bf8\ub87a\ucf71\u2f81\u119e", "\ud934\ude03\udbe7\udc83\ud869\udf10\uc700\udb4b\ude65\uda7d\udc6c\ud923\udc9d\udb07\udd08",
        28, 2085, 2017486411, -2409701290132330307L, 7507L, true, false, (char) 6702, (char) 4876,
        Double.longBitsToDouble(0x3fd9724eb813f2c8L), Double.longBitsToDouble(0x3fbe4f3211d8afd8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.apache.commons.math3.linear.Array2DRowRealMatrix:Array2DRowRealMatrix{{1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0....\012",
        Z.run(T, 1, 5, 8, 4, "\ud8bb\udc1b\ud955\udf50\ud936\udc43\ud8ea\udfaa\udb1a\ude12\udb67\udd14\ud9be\udca7\udbc6\udea9\ud8bc\udd39\ud8c3\udea7\uda11\udc1a", "\u2316\u9887\u6446\ub16a\u4e5b\u4017\u065f\u2533\022\u7f22\u7498\u2185", "\ud9fc\udc52\uda49\ude1e\u0749\uda7c\ude28",
        41, 77747, -1391099449, -6412216477996544853L, 877L, false, true, (char) 61905, (char) 8470,
        Double.longBitsToDouble(0x3fee513711e951e1L), Double.longBitsToDouble(0x3fcdd5a872f7645cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|checkParameters||new:org.apache.commons.math3.optimization.direct.CMAESOptimizer:",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|copyColumn|org.apache.commons.math3.linear.RealMatrix,int,org.apache.commons.math3.linear.RealMatrix,int|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|diag|org.apache.commons.math3.linear.RealMatrix|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|divide|org.apache.commons.math3.linear.RealMatrix,org.apache.commons.math3.linear.RealMatrix|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|doOptimize||new:org.apache.commons.math3.optimization.direct.CMAESOptimizer:",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|eye|int,int|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|getStatisticsDHistory||new:org.apache.commons.math3.optimization.direct.CMAESOptimizer:",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|getStatisticsFitnessHistory||new:org.apache.commons.math3.optimization.direct.CMAESOptimizer:",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|getStatisticsMeanHistory||new:org.apache.commons.math3.optimization.direct.CMAESOptimizer:",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|getStatisticsSigmaHistory||new:org.apache.commons.math3.optimization.direct.CMAESOptimizer:",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|initializeCMA|[D|new:org.apache.commons.math3.optimization.direct.CMAESOptimizer:",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|inverse|[I|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|log|org.apache.commons.math3.linear.RealMatrix|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|max|[D|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|max|org.apache.commons.math3.linear.RealMatrix|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|min|[D|static",
    "M|org.apache.commons.math3.optimization.direct.CMAESOptimizer|checkParameters||new:org.apache.commons.math3.optimization.direct.CMAESOptimizer:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
