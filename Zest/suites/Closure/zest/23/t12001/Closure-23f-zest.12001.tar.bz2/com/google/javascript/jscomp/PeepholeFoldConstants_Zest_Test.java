package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class PeepholeFoldConstants_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 2, 5, "\udb19\udceb\ud963\udf86\ud89f\udfb7\udbc2\udc48\ud895\udd4e\ud957\udd14", "\u84ca\uc467\u8d4e\u9bf2\u17e2\ud418\ub67e\u77e5\uc9b6\u6677", "\ud874\udcf4",
        37, 52948, -7400678, 8066255575899217515L, -28329L, false, true, (char) 56750, (char) 2478,
        Double.longBitsToDouble(0x3feed7a9eb63db78L), Double.longBitsToDouble(0x3f7e783c9552f080L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 2, 5, "\udb19\udceb\ud963\udf86\ud89f\udfb7\ud9f1\udc3f\udaee\ude9f\ud800\udc4c", "\u0304\u94ff\u8d4e\u07e1\u17a2\ud418\ub67e\u77e5", "\uda9c\uddfc",
        11, 68566, 976043097, -8112974402258267366L, -59445L, false, true, (char) 27182, (char) 16265,
        Double.longBitsToDouble(0x3fe4f2cee58ccb30L), Double.longBitsToDouble(0x3fe4a694ef74b481L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 11, "\udb19\udceb\ud963\udf86\ud89f\udfb7\udbc2\udc48\ud895\udd4e\ud957\udd14\udaa0\udd7c\ud828\ude82\uda16\udeba\ud8e5\uddb4\uda38\udd3c\ud890\udeea\ud9ca\udfaa\uda5c\udee1\ud90b\udfe1\uda7a\udea5\ud88e\udfb1\udb6d\udc5f\udbd7\udc33\udaf2\ude74\ud874\udcf4\udba0\udee0", "\u7da5\u1ae5\u1382\u5978\u9056\u6802\u89b5\ua0b3\u421e\u9a5f\u3322\u0e66\u2c92\uaee7\uc747\u1753\u5ce3\ud29a\u7cd0", "\uda5f\ude62\uda21\udeb4\udb43\udf2b\udbdd\udc23\udae1\ude11\ud94f\ude51\udb98\udd61",
        53, 1608, -1205685642, -2284564139318220239L, 44900L, true, false, (char) 63189, (char) 7055,
        Double.longBitsToDouble(0x3fe745e74aeb4847L), Double.longBitsToDouble(0x3fe4388cf27909bfL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 1, 8, 0, 5, "\udb19\udceb\uda69\udec4\ud89f\udfb7\udaa8\udc1b\ud8ce\udffa\ud953\ude78", "\u84ca\uc467\u8cf4\u9bf2\u17e2\ud418\ub67e\u179a\uc925\u6677", "\ud9e1\udd9e",
        7, 52964, -7400678, 8066255575899217515L, -28329L, false, true, (char) 56750, (char) 2478,
        Double.longBitsToDouble(0x3feed3d1eb63db78L), Double.longBitsToDouble(0x3f7e783cf4d2f080L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 0, "\udb19\udceb\ud963\udf86\ud89f\udfb7\udbc2\udc48\ud895\udd4e\ud957\udd14", "\u84ca\uc467\u8c6b\u9bf2\u17e2\u9a1d\ub67e\u77e5\uc9b6\u6677", "\ud874\udcf4",
        19, 52948, -7400678, 27168285392896L, -79268L, false, false, (char) 53790, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3d19400000000000L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 1, "\udb19\udc24\ud963\udf86\ud89f\udfb7\udbc2\udc48\udb24\udd56\ud8bf\udd5e\udb97\udc97\ud99c\udd6a\udb8b\udcd5\uda76\udd70", "\u180a\ud418\ub67e\u77e5\uc9b6", "\ud8ab\udff6\ud867\ude66",
        6, 35565, -7400678, 8066255575899217515L, -73734L, true, false, (char) 32363, (char) 56273,
        Double.longBitsToDouble(0x3feac032bfe3a1caL), Double.longBitsToDouble(0x3feed7a9eb63db78L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 10, "\udba9\udf34\u9354\udaa9\udfd0\ud818\udfaf\udb74\udfaf\ud93f\udc20", "\u84ca\ub5fd\u3345\u9b54\u9eb3\ud418\ub67e\u77e5\uc9b6\u6677", "\ud874\udcf4",
        37, 6740, -7400541, 8066255578573487979L, -24685L, false, false, (char) 56750, (char) 17325,
        Double.longBitsToDouble(0x3feb39c44b6cdbfeL), Double.longBitsToDouble(0x3f7e783c9552f080L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 2, 5, "\udb19\udceb\ud963\udf86\ud89f\udfb7", "\uaaba\uaab5\u1f41\ubb4e", "\udbc7\udf8f\ud9f3\udd19\uda5c\udee1\udbb1\udd94\uda7a\udea5\ud883\udcb1\udb6d\udc4a\ud84b\uddad\u16bb\ud98a\udcb1\udaac\udc3d\ud928\udcf9",
        13, 90507, -1661165973, 1815727230491513084L, -28329L, false, true, (char) 56750, (char) 64429,
        Double.longBitsToDouble(0x3feed7a9eacbdb78L), Double.longBitsToDouble(0x3f7eaf909552f080L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$1:false |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 1, 1, 2, 5, "\u347a\udb09\ude1f\ud839\udd3b\udbc2\udc48\ud895\udd4e\ud957\udd14", "\u84ca\u6c38\u8d4e\u7074\u3668\ud418\u3585\u5791\uc9b6\u0802", "\uda9c\udeeb",
        5, 62798, 2048051954, 1628192129970642539L, -28329L, false, true, (char) 56750, (char) 2478,
        Double.longBitsToDouble(0x3feed7a9ed6015cbL), Double.longBitsToDouble(0x3f7e79a89552f080L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 2, 10, "\udb19\udceb\ud963\udf86\udaa1\udedd\ud99d\udde6\ud895\udd4e\ud957\udd14", "\u8508\uc467\u8d4e\u9bf2\uc7a0\ud418\u8619\u77e5\uc9b6\u18d1", "\ud874\udcf4",
        37, 52948, -7397600, 8066451288968961643L, -55196L, true, false, (char) 49848, (char) 5375,
        Double.longBitsToDouble(0x3fefbb362483025dL), Double.longBitsToDouble(0x3f93fb81b8ba3aa0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 2, 5, "\udb19\udceb\ud963\udf86\ud89f\udfb7\udbc2\udc48\ud895\udd4e\ud957\udd14", "\u6702\uc467\u8d4e", "\uda5c\udee1\uda53\udcc4\uda7a\uded0\ud88e\udfb1\udb6d\udc5f\udbd7\udc33",
        24, 68643, -661963687, -8113226379298925798L, -59445L, false, false, (char) 27182, (char) 46378,
        Double.longBitsToDouble(0x3fe4d690f08ccb30L), Double.longBitsToDouble(0x3fefbb362774b45dL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 1, 8, 12, 11, "\ud9de\udc94\udbcc\udee6\uda56\ude5f\udbc2\udc48\ud895\udd4e\ud884\udc53\ud806\uddf9\uda0a\udfa5\uda0d\udf57\ud8e5\uddb4\uda38\udd3c\ud890\udeea\uda35\udc3f\ud837\udc9d\ud92f\udc43\uda7a\ude3c\uda92\uded2\udb97\ude5f\udbd7\udc33\udaf2\ude74\ud874\udcf4\udba0\udee0", "\u7da5\u1ae5\u1382\u6f84\u9056\ub2fb\u29e0\u8bf5\u81fc\u9a5f\u3322\u0e66\u2c92\uaee7\uc747\u1753\u5497\ud29a\u7cd0", "\uda5f\ude62\u6fc7\udb43\udf2e\udbdd\udc23\udae1\ude11\ud838\udf89\uda2b\udf75",
        53, 44433, -1205685642, -2284564139315338720L, 44900L, true, true, (char) 63308, (char) 7055,
        Double.longBitsToDouble(0x3fe745e74aeb4847L), Double.longBitsToDouble(0x3fe4388cf27909bfL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=com.google.javascript.rhino.jstype.TernaryValue$1:false |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 2, 8, 1, 15, "\uda82\udc6e\ud91e\udd3e\uda3c\udc56", "\u3c8a", "\uda94\udf85\ud9f7\udf71\uda6e\udca8\ud80e\ude52\udb5d\ude0c\uda5c\udee1\ud8f1\ude55\ucf02",
        38, 52422, 2011523305, 8000868825912952604L, -70595L, false, false, (char) 7255, (char) 63280,
        Double.longBitsToDouble(0x3fd2f10921e55414L), Double.longBitsToDouble(0x3fc07101a206b5f4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 1, 8, 0, 5, "\ud805\ude71\uda69\udec4\ud89f\udfb7\udaa8\udc1b\ud8ce\udffa\ud953\ude78\udaa0\udd7c\ud828\ude82\udb8b\udcd5\uc2f4\uda97\ude36\ud905\udded\ud9f3\udd19\uda5c\udee1\ud8f1\ude55\ucf02\ud88e\udf20\udb6d\udc5f\udbd7\udc33\ud81c\udf88\ud9e1\udd9e\uda05\udd3a\ud975\ude31\ud938\udf13\udb39\udf4e\ud8bc\udc95", "\u9056\u6802\u7259\uce51", "\ud885\udf17\udb84\udd5f\ud9a3\udd9d\ud97a\udeb7\ud929\ude2b\ud9a4\udd40\udb3b\udde6\uda86\udcfd\ud87b\ude4c",
        46, 61581, 1817765064, 282740969486664079L, -54457L, false, true, (char) 65182, (char) 10641,
        Double.longBitsToDouble(0x3fcd5877de72df64L), Double.longBitsToDouble(0x3fddb98b998ebe8aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 1, 8, 0, 5, "\udb19\udceb\uda69\udec4\ud89f\udfb7\udbea\udc1c\ud8ce\udffa\ud953\ude78", "\u84ca\uae17\u3def\u9bf2\u17e2\ud418\ub67e\u179a\uc925\u6677", "\ud9e1\udd9e\uda05\udd3a\ud975\ude31\ud938\udf13\udb39\udf4e\ud8bc\udc95\ud8f9\udd10\udb0b\udd97\udb53\udc02\ud8e0\udf7d\udbd2\udd57\udbbe\udf03\udab3\udf3f\udada\uddca",
        12, 14199, -1643136157, -6493794806724654615L, -94641L, false, true, (char) 19918, (char) 30905,
        Double.longBitsToDouble(0x3fee01f01a76bce3L), Double.longBitsToDouble(0x3fe63029d7baa432L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 1, 8, 0, 5, "\udb19\udceb\uda69\udec4\uda78\udd43\udaa8\udc1b\ud8ce\udffa\ud953\ude78", "\u84ca\uc467\u8cf4\u9bf2\u17e2\ubbf1\ub67e\u179a\uc925\u6677", "\ud9e1\udd9e",
        13, 52964, -7400678, 8066255575899217515L, -28329L, false, true, (char) 56018, (char) 13050,
        Double.longBitsToDouble(0x3fe2dd1a3b635760L), Double.longBitsToDouble(0x3f7e783cf4d2f080L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 1, 8, 0, 5, "\udb19\udceb\uda69\udec4\ud89f\udfb7\udaa8\udc1b\ud8ce\udffa\ud953\ude78", "\u84ca\uc467\u9ab0\u9bf2\u179f\ud418\ub67e\u179a\uc925\u4978", "\ud966\udfa0",
        45, 52964, -7400678, 8066255579568840299L, -79268L, true, false, (char) 14521, (char) 48060,
        Double.longBitsToDouble(0x3fb4a478548f2d50L), Double.longBitsToDouble(0x3feac032bfe3a1caL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$1:false |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 2, "\ud87a\udee9\ud8d5\udd55\udbed\udf9d\ud801\ude9d\ud987\uddf7\uda1d\udd75\udaa0\udd7c", "\u33a1\u8cf4", "\uda5c\udee1\ud8f1\ude55\ucf02\ud88e\udf20\udb6d\udc5f\udb8c\udccd",
        55, 63723, 1910866985, -8112974333438127109L, -59445L, true, false, (char) 51101, (char) 46378,
        Double.longBitsToDouble(0x3fe4d690f2866130L), Double.longBitsToDouble(0x3febbe9037aa110bL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$1:false |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 0, "\udb19\udceb\ud963\udf86\ud89f\udfb7\udbc2\udc48\ud895\udd4e\ud957\udd14", "\u84ca\uc467\u8c6b\u9bf2\ubf7d\u8fd2\ub67e\u77e5\u9281\uced2", "\ud86d\udf71Y",
        18, 72322, 6326, -7205759403792743860L, 31072L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3ec9465aa2240000L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 10, "\ud9a1\udc7e\u9354\udaa9\udfd0\ud818\udfaf\udb74\udfaf\ud93f\udc20", "\u84ca\ub5fd\u48e1\u1a8f\u9eb3\ud418\ub67e\u77e5\uc9b6\u6677", "\ud874\udcf4",
        37, 66540, -9007019, 8066255578573487979L, -24685L, false, false, (char) 56750, (char) 17325,
        Double.longBitsToDouble(0x3feb39c44b6cdbfeL), Double.longBitsToDouble(0x3f7e783c9552f080L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 10, 14, "\udba9\udf34\u9354\udaa9\udfd0\uda44\udf5b\ud960\udd94\ud8e0\udd53", "\u9d3b\u5f60\u3345\u9b54\u9eb3\ud418\ub67e\u77e5\uc9b6\u6677", "\ud874\udcf4",
        37, 6740, -7400541, 8066255578573487979L, -24685L, false, false, (char) 56750, (char) 17325,
        Double.longBitsToDouble(0x3feb39c44b6cdbfeL), Double.longBitsToDouble(0x3f7e783c9552f080L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 10, "\udb1a\udd2c\ud8a4\udd82\udaa9\udfd0\ud818\udfaf\udb74\udfaf\ud93f\udc20", "\u84ca\ub5fd\u3345\u9b54\u9eb3\ud418\uc6cb\u57ea\uc9b6\u6677", "\ud874\udcf4",
        -5, 6740, -7400541, 8066255578573487979L, -49960L, false, false, (char) 30915, (char) 48060,
        Double.longBitsToDouble(0x3fe1987e2238fc5dL), Double.longBitsToDouble(0x3feac032b9e3a1caL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=java.lang.Boolean:false |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 2, 8, 8, 10, "\uda91\udf84\ud86e\ude8f\udaa9\udfd0\ud818\udfaf\uda47\ude38\ud91a\udd6b\udaa0\udd7c\ud956\uddef\ud822\ude5d\ud801\udfe1\ud97d\udc43\udbf5\uded1\ud830\udecc\uda2a\ude87\udb09\uddde\uda7b\udec2\uda72\udeb0\ud9be\udf30\ud9ac\udfdf\udb11\ude71\ud885\udcf3\udaab\udfc6\udaf4\ude9f\ud938\udf9c\udb39\udf4e\ud838\udfab\uda4d\udc59\ud95a\ude79\uda79\ude1d\ud8d9\ude7d\udb98\udd79\uda3c\udcf1\ud9dc\udfc7\uda10\udd00", "\u2726\uc01d\u135e\u461c\uc0ab\u22c8\ub68c\uab5e\u1e7c\u7b92", "\ud9da\udfca\ud982\udf97",
        15, 69633, 830045014, 3593503095292175660L, 76224L, false, true, (char) 27499, (char) 10219,
        Double.longBitsToDouble(0x3fe2242c16999aecL), Double.longBitsToDouble(0x3fc005d5c6384138L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$1:false |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=com.google.javascript.rhino.jstype.TernaryValue$1:false |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 2, 1, 1, 13, "\u347a\udb09\ude1f", "\u9f07\u3622\u67d4\u4f4e\u84ca\u6c38\u2525\u7074\u3668\ud418\u3585\u5791\ub9dc\u0802\ud568\u853d\u1e29\u56a1\u5d40\u8ada\ub2e5\ubd37\u6829\u9cc6\u9056\u0303\u6ea4\u9d6e\ua6f7\u892b", "\udb19\udf9f\ud97a\udeb7\uda94\udf7e\ud852\udffe",
        34, 37237, 2089857796, -6313796773326275592L, 18084L, false, false, (char) 8844, (char) 44655,
        Double.longBitsToDouble(0x3fee09c44c559460L), Double.longBitsToDouble(0x3fb59059155477f8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 2, 5, "\udb19\udceb\ud963\udf86\ud89f\udfb7\udbc2\udc48\ud895\udd4e\ud957\udd14", "\u6702\u32c0\u8bea", "\udb5b\udf5a\uda53\udcc4\uda7a\uded0\ud88e\udfb1",
        21, 78325, -1729533816, 5393197489556503641L, -39354L, false, false, (char) 63876, (char) 24392,
        Double.longBitsToDouble(0x3fcf83265ff319ccL), Double.longBitsToDouble(0x3fe3c14c908ccb30L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$2:true |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 0, "", "", "\ud895\udc88\ud801\udf2a\000\000\udb8b\udc40\uc2f4\uda97\uddad\ud905\udded\ud8d1\udd7d\ud939\ude96\ud8f1\ude55\uda7a\udea5\ud8b1\ude51\uda55\ude36\ud84d\udebc\ud94a\uddcc\ud86d\udf71",
        19, 52948, -7400678, 27168285392896L, -100000L, false, false, (char) 53790, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3d19400000000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 10, 14, "\udba9\udf34\ud86f\udc18", "\ucc96\u40ae\ucf3d\u1f41\uc457", "\ud8ad\uddc4\udb1d\udff2\uda5c\ude93\udbe8\ude54\uda7a\udea5\ud88e\udfb1",
        21, 50821, -1729533875, 3303527264094600281L, 42699L, true, false, (char) 9086, (char) 13573,
        Double.longBitsToDouble(0x3fe4b82a008ccb30L), Double.longBitsToDouble(0x3fe1987e2238fc5dL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 2, 8, 8, 10, "\uda91\udf84\ud86e\ude8f\udb2d\udfd2\ud89e\ude10\ud8b1\udee1\ud86e\uddc5\u883a\ud956\udd2b\ud822\ude5d\ud801\udfe1\ud97d\udc43\udbf5\uded1\ud830\udecc\uda2a\ude87\udb09\uddde\uda7b\udec2\uda72\udeb0\ud9be\udf30\ud9ac\udfdf\udb11\ude71\ud885\udcf3\udaab\udfc6\udaf4\ude9f\ud938\udf9c\udb39\udf4e\ud838\udfab\uda4d\udc59\ud95a\ude79\uda79\ude1d\ud8d9\ude7d\udb98\udd79\uda3c\udcf1\ud9dc\udfc7\uda10\udd00", "\u2726\uc01d\u135e\u7408\u58d4\u22c8\ub68c\uab5e\u1e7c\u7b92", "\ud9da\udfca\udbd1\udf3b\udac1\udcbf\udadf\ude40\ud975\ude40\ud94e\udef7\uda31\udfe0",
        46, 9798, 1762203899, -5932447082917797151L, 6873L, false, false, (char) 51589, (char) 22318,
        Double.longBitsToDouble(0x3fd8e104e61f89baL), Double.longBitsToDouble(0x3fc2ab9706b4ef58L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$2:true |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=com.google.javascript.rhino.jstype.TernaryValue$2:true |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 2, 1, 1, 0, "", "", "\ud895\udc88\ud801\udf2a\000\000\udb8b\udc40\uc2f4\uda97\uddad\ud905\udded\ud8d1\udd7d\ud939\ude96\ud8f1\ude55\uda7a\udea5\ud8b1\ude51\uda55\ude36\ud84d\udebc\ud94a\uddcc\ud86d\udf71",
        19, 52948, -7400678, 27168285392896L, -100000L, false, false, (char) 53790, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3d19400000000000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 2, 5, "\udb19\udceb\ud963\udf86\ud89f\udfb7\udba6\ude48\ud895\udd4e\ud957\udd14", "\u84ca\uc467\u8d4e\u9bf2\u17e2\ud418\ub67e\u77e5\uc9b6\u6677", "\ud874\udcf4",
        37, 52948, -7400678, 8066255575899217515L, -28329L, false, true, (char) 56750, (char) 2478,
        Double.longBitsToDouble(0x3feed7a9eb63db78L), Double.longBitsToDouble(0x3f7e783c9552f080L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 2, 8, 8, 4, "\ud9d3\udce9\udb0c\udd3c\uda10\udd0c\ud818\udfaf\udb74\udfaf\ud93f\udc20\uda15\ude55\ud81a\udcc6\udb8b\udcd5\ud87a\udd7c", "\u9eb3\ud418\ub67e\u77e5\uc9b6\u6677\u0140\u9659\ub409\u79ae\u5357\u17b2\u7d62\uaefc", "\ud91e\udd3e\ud98a\ude3b\ud923\udf61\ud85d\ude79\uda86\ude97\ud924\udf9c\ud95f\ude49\udb2e\udd47",
        12, 31449, 444604475, -5595812779180137073L, 41067L, false, true, (char) 30483, (char) 35675,
        Double.longBitsToDouble(0x3fe68d61bc03b98dL), Double.longBitsToDouble(0x3f85f30595cc3100L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 2, 8, 8, 14, "\udba9\udf34\u9354\ub7d3\uda44\udf5b\ud960\udd94\udb44\udee6", "\u9d3b\u5f60\u3345\u9b54\u9eb3", "\uda7a\ude41\ud88e\udfb1\ud84c\udeae\udbd6\udfdd\udaf2\ude74\uda5b\ude69\ud89b\udd0d\udaf4\ude9f\ud938\udf9c\udb39\udf4e\u3afa\udae3\udd1e\udb58\udd1b\uda41\ude00\ud80a\udf7b\udb98\udd79\ud85d\uddfc",
        45, 5880, 948543971, -2594439081998959764L, 20335L, false, true, (char) 29938, (char) 33703,
        Double.longBitsToDouble(0x3fdbb8ae39de91e0L), Double.longBitsToDouble(0x3fe86f6317394c5bL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 2, 8, 8, 14, "\udba9\udf34\u9354\ud930\ude94\uda37\udc52\ud960\udd94\udb44\udee6", "\u9d3b\u5f60\u3345\u9b54\u6e34", "\uda7a\ude41\ud88e\udfb1\ud84c\udeae\udbd6\udfdd\udaf2\ude74\uda5b\ude69\ud89b\udd0d\udaf4\ude9f\ud966\ude9c\udb39\udf4e\u3afa\udae3\udd1e\udb58\udd1b\uda45\udc00\ud80a\udf7b\udb98\udd79",
        13, 17640, -1580542120, 4073965333658907495L, 69760L, false, true, (char) 42407, (char) 1113,
        Double.longBitsToDouble(0x3fdb4633253e04a6L), Double.longBitsToDouble(0x3fd1732901bd15c6L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$3:unknown |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 0, "\000\udb0c\udc25\uda21\udc4d\ue484\uda26\udc41\ud8cc\udc02\000\ud956\udc0a\udb8b\udc40\uc2f4\uda2a\udcc3\ud828\udfbf\u631c\ud939\ude96\ud8f1\ude55\udbd7\uddbc\ud980\udcac\uda55\ude4b\ud84d\udebc\udb1d\udc7a\ud989\udd2f\uda86\udc50", "\u9753\u997a\uaad4\u9770\u79e9\000\000\u9589\u586f\u8ce1\u2888\u76e9\u6a31\u4b4a\u67ed\013\u0912\ua694\uc709", "\ud962\udfcb\udaf8\udf3b\ud896\udfda\ud942\udc29\uda7a\udf61\udbc4\udc8a\ud8ba\udc56\uda5f\udd91\ud802\udfdd\ud81e\udc84\ud99f\ude2b",
        14, 78065, -1601921260, -1510344310942256123L, 5536L, false, false, (char) 57257, (char) 62663,
        Double.longBitsToDouble(0x3fef3a5c943f5e42L), Double.longBitsToDouble(0x3fb9d70cb2135518L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$3:unknown |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=com.google.javascript.rhino.jstype.TernaryValue$3:unknown |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 2, 1, 1, 0, "\000\udb0c\udc25\uda21\udc4d\ue484\uda26\udc41\ud8cc\udc02\000\ud956\udc0a\udb8b\udc40\uc2f4\uda2a\udcc3\ud828\udfbf\u631c\ud939\ude96\ud8f1\ude55\udbd7\uddbc\ud980\udcac\uda55\ude4b\ud84d\udebc\udb1d\udc7a\ud989\udd2f\uda86\udc50", "\u9753\u997a\uaad4\u9770\u79e9\000\000\u9589\u60dc\u8ce1\u2888\u76e9\u6a31\u4b4a\u67ed\013\u0912\ua694\u4413", "\ud962\udfcb\udaf8\udf3b\ud896\udfda\ud942\udc29\uda7a\udf61",
        38, 27463, -746612393, -8563573947671428162L, -59276L, false, true, (char) 7952, (char) 48051,
        Double.longBitsToDouble(0x3fb00ae7ad07eaa8L), Double.longBitsToDouble(0x3fd04f2a5dc90236L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$3:unknown |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 0, "\udbed\udd0e\013\ud89f\udfb7\udae5\ude1a\ud895\udc88\ud801\udf2aa\000\udb8b\udc40\uc2f4\uda97\uddad\udbf7\udf9e\ud901\udff4\ud939\ude96\udace\udee2\uda7a\udea5\ud8b1\uddc2\uda55\ude36\uda11\udfc8\ud94a\ude08\ud86d\udf87Y\udbed\udf94\udb59\udd22\ud8f1\udee7", "\u5516", "\000\udb92\udde5\ud911\uddc2\udadd\udfe8\u5552\udbe6\udc95\uda6a\uddb0\ud967\udde2\uda45\udeab\udbcb\udc39\udb82\udc04\ud899\udd2e",
        46, 59470, -575240554, -7106915953025731290L, -79929L, true, true, (char) 29145, (char) 54676,
        Double.longBitsToDouble(0x3fe823e678057634L), Double.longBitsToDouble(0x3fd7f234823aef36L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$3:unknown |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\0121=com.google.javascript.rhino.jstype.TernaryValue$3:unknown |this=com.google.javascript.jscomp.PeepholeFoldConstants:@?\012",
        Z.run(T, 2, 1, 1, 0, "\udbed\uddc4\013\ud89f\udfb7\udae5\ude1a\ud895\udc88\ud801\udf2aa\000\udb8b\udc40\uc2f4\ud946\uddb1\ud9b7\udcc3\ud901\udff4\ud939\ude96\ud983\udd69\uda7a\udea5\ud801\udf20\udb20\udd59\uda11\udf81\ud945\udf08\ud86d\udf87Y\udbed\udf94\udb59\udd22\ud8f1\udee7\u87b1\udbfd\udfc6\uda9f\udf3e\udadc\udc67\ud9bc\udfc3\036\ud842\udd3b\ud8e6\ude0b\udadd\udfe8\u5552\udbe6\udc95\uda6a\uddb0\ud967\udde2\uda45\udeab\udbcb\udc39\udbe5\udcf5\udadb\ude42\ud875\udf5c\ud8f1\udd14\uda22\ude19\ua3c8\ud9ef\udd96", "\ucd56\u98bb\u97c5", "\ud9b1\udc8b\udb01\udf74\ud982\udef3\udb2d\udd4d\ud950\ude27\ud90d\ude67\udbdc\udc4d\udb50\udc93",
        45, 73873, -1893249085, -1119204235139307530L, 59603L, false, false, (char) 11326, (char) 5777,
        Double.longBitsToDouble(0x3fe09c4131959dcaL), Double.longBitsToDouble(0x3fe695ef8b9251d5L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldArrayAccess|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|areStringsEqual|java.lang.String,java.lang.String|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|compareAsNumbers|int,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|compareToNull|com.google.javascript.rhino.Node,int|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|compareToUndefined|com.google.javascript.rhino.Node,int|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|getNormalizedNodeType|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|inForcedStringContext|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|isAssignmentTarget|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|isEqualityOp|int|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|optimizeSubtree|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|performArithmeticOp|int,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryConvertOperandsToNumber|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryConvertToNumber|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldAdd|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldAddConstantString|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldAndOr|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldArrayAccess|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
