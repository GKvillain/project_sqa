package com.google.javascript.jscomp.parsing;
import org.junit.Test;
import static org.junit.Assert.*;
public class IRFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 8, "\uda26\udda9\ud877\udfbc\udba8\ude5e", "\uac5f\u377d\u2bc3\u18c0\u7194\u56c1\u392d\u4cd3\u340a\u174b\u3436\u698d", "\udb60\uddca\ud86e\udf96\ud8d2\udde8\ud9e3\ude8d\uda72\udc63\ud8a6\udff2\udb65\ude67\ud9da\udc9f\u73f3\ud99e\uddde\ua44d\ud91f\udd37\udad4\udfb2\udbee\uddab\ud82c\udc1d\ud878\ude5c\ud998\ude3c\u8180\udb93\ude2c\uda63\udeec\uda5e\udc85\ud8e6\udf0f\ud850\udd04\ud99e\udead\uda68\udfb4\uda96\udf26\ud9d9\ude78\udbf7\udfc7\uda25\ude9e",
        26, 27682, -685118291, -1617802208323081135L, -84542L, false, true, (char) 60574, (char) 45756,
        Double.longBitsToDouble(0x3fd3d98dce6a9c34L), Double.longBitsToDouble(0x3fec6740d2d4f5b8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 8, "\uda26\udda9\ud877\udfbc\uda32\udf22", "\uac5f\u377d\u2bc3\u18c0\u7194\u56c1\u392d\u8d02\u294f\u174b\u3436\u698d", "\udb60\uddca\ud8f5\udfb0\ud853\udd86\ud9e3\ude8d\uda72\udc63\ud8a6\udff2\udb65\ude67\ud9da\udc9f\u73f3\ud99e\uddde\ua44d\ud91f\udd37\udad4\udfb2\udbee\uddab\ud82c\udc1d\ud878\ude5c\ud998\ude3c\u290f\udb93\ude2c\uda63\udeec\uda5e\udc85\ud8e6\udf0f\ud850\udd04\ud99e\udead\ud81c\udf4e\udaa3\udd56\ud95b\udf54\u1e85\uda25\ude9e",
        26, 27682, -685118291, -1617802208323081135L, -71718L, false, true, (char) 60574, (char) 45756,
        Double.longBitsToDouble(0x3fd9998dce6a9c34L), Double.longBitsToDouble(0x3fec6740d2d4f5b8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 8, "\uda26\udda9\ud877\udfbc\udba8\ude5e\udb0c\udc66\ud853\uddb3\ud98f\udf26\uda77\ude33\udbee\udc6c\ud986\uded7\ud93d\udebb\ud92b\udc17\udb56\udf05\ud824\udd2f\udb36\udd33\uda03\udd1d\ud931\uddaf\uda86\udf90\udafd\udcf8\ud981\udc0b\udb60\uddca\ud86e\udf96", "\u4b55\u336f\ub546\u3f9b\u9b5f\u4a19\uccf2\005\u9092\uaa87\u3b78\u0336\u80d8\u1821\ub494\uaf16\u5f3c\u1890\ub6ee\uae58\u6d15\u6c39\u2543\ubbae\uacc4\uc699\u51b5\ua446\uc6da\uafe6\u21b2\u77d3", "\udbf6\ude6b\ud90e\uddd7\ud9db\uddcc\udba0\udef0\uda6b\uddf9\udb8c\udc31\udbf7\udcc1\udb42\ude64\udb6a\udecf\udbe5\udd37\ud950\uddc4",
        51, 32677, 322949130, -5397316876803296334L, 63315L, false, true, (char) 15399, (char) 60773,
        Double.longBitsToDouble(0x3fe695e0ef08cab5L), Double.longBitsToDouble(0x3fe7c37bad2c1bf0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 2, 8, "\uda26\udda9\ud877\udfbc\udba8\ude5e", "\uac5f\u377d\u2bc3\u18c0\u7194\u56c1\u392d\u4cd3\u340a\u8d4a\u3436\u698d", "\udab5\udefb\ud86e\udf96\ud8d2\udde8\ud9e3\ude8d",
        20, 81488, 1214214692, -4926756953159516963L, 96900L, false, false, (char) 54416, (char) 38002,
        Double.longBitsToDouble(0x3fd6f9392b85937aL), Double.longBitsToDouble(0x3fb9adf0051b1038L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:0.12567558570256032\012",
        Z.run(T, 1, 3, 2, 12, "\uda26\udda9\ud877\udfbc\udba8\ude5e\udb0c\udc66\uda02\udf6a\ud8a4\udc2c\udaf2\udd5b\udbb1\ude80\udbed\udd81\ud93d\ude25\ud92b\udc17\ud899\ude60\ud8ec\udca4\udb36\udd33\uda03\udd1d\uda39\uddb3\uda86\udf90\udafd\udcf8\ud981\udc0b\udb60\uddca\ud86e\udf96\ud8d2\udde8\ud9e3\ude8d\uda72\udc63\ud97a\udf64\udb56\udc01\ud9da\udc9f\u73f3\ud83d\udd0d\udbea\udfd5\ud91f\udd37\udad4\udfb2\udbee\uddab\ud82c\udc1d\udabc\ude5e\ud998\ude3c\u8122\udb93\ude2c", "\u1890\ub6ee\u11ee\u6d15\u6c39\u2543\u15c2\u9d19\uc699", "\ud8f6\udc24\ud9f7\udd3f",
        31, 92398, -1424975792, 3620320084886323328L, 75925L, false, true, (char) 30860, (char) 31910,
        Double.longBitsToDouble(0x3fc01623393fc31cL), Double.longBitsToDouble(0x3feb42c52b8ca53bL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 6, 2, "\uda26\udda9\ud877\udfbc\udba8\ude5e", "\uac5f\u377d\u2bc3\u18c0\u7194\u56c1\u392d\u4cd3\u340a\u174b\u3436\u698d", "\udbc1\udca4\ud86e\udf96\ud8d2\udde8\ud9e3\udef0\uda72\udc63\ud8a6\udff2\udb65\ude67\ud9da\udc9f\u73f3\ud99e\uddde\ua44d\ud9b7\udd24\uda4e\udc3a\udbee\uddab\ud82c\udc1d\ud878\ude5c\ud998\ude3c\u8180\udb93\ude2c\uda63\udeec\ud9a3\udd28\ud8e6\udebc\ud850\udd04\ud99e\udead\uda68\udfb4\uda96\udf26\ud9d9\ude78\udbf7\udfc7\uda25\ude9e",
        26, 27682, -348459859, 9204919412229885029L, -84542L, false, true, (char) 60574, (char) 45756,
        Double.longBitsToDouble(0x3fd3d98dce6a9c34L), Double.longBitsToDouble(0x3fec6740d2d4f5b8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 12, 7, "\uda26\udda9\ud877\udfbc\ud839\udfc7", "\uac5f\u377d\u2bc3\u18c0\u7194\u56c1\u392d\u4cd3\u340a\u174b\u3436\u4a4b", "\uda96\udfc5",
        36, 57032, -1847689973, -2370782004460583712L, -18984L, true, true, (char) 25916, (char) 63341,
        Double.longBitsToDouble(0x3fb7e4ab73f8b090L), Double.longBitsToDouble(0x3fc8127655be4e48L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 2, 8, "\uda26\udda9\ud877\udfbc\udba8\ude5e", "\u0633\u377d\u2bc3\u18c0\u7194\u56c1\u392d\u4cd3\u04ed\u0d3b\u3436\u698d", "\udb60\uddca\ud86e\udf96\ud8d2\udde8\ud9e3\ude8d\uda72\udc63\ud8a6\udff2\uda3a\udd9d\ud9da\udc9f\u73f3\ud99e\uddde\u628f\ud91f\udd7b\udad4\udfb2\udbee\uddab\ud82c\udc80\uda11\udca8\ud9ca\udf1a\u9559\udbc6\udc46\ud93a\udefe\ud84a\udddc\udb60\udf17\uda4f\udef5\udb54\udee0\uda68\udff6\uda96\udf26\udb9b\ude08\udb9b\udf15\udb49\udf68",
        -2, 27682, -685118291, 5227669225280072785L, 33664L, false, false, (char) 63001, (char) 64846,
        Double.longBitsToDouble(0x3fec6740d3c035f2L), Double.longBitsToDouble(0x3fc6ab80dd0f033cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:0.7057957333220971\012",
        Z.run(T, 1, 3, 2, 8, "\udb53\udd06\ud874\udc5d\udba8\ude5e\udb0c\udc66\ud853\uddb3\ud98f\udf26\uda77\ude33\udbee\udc6c\ud986\uded7\ud93d\udebb\ud92b\udc17\udb56\udf05\ud824\udd2f\udb36\udd33\uda03\udd1d\ud931\uddaf\uda86\udf90\udafd\udcf8\ud981\udc0b\udb60\uddca\ud86e\udf96", "\u4b55\u336f\ub546\u3f9b\u9b5f\u4a19\u5eba\uc732\u9092\uaa87\u3b78\u0336\u80d8\u1821\ub494\uaf16\u5f3c\u1890\ub6ee\uae58\u6d15\u6c39\u2543\ubbae\uacc4\uc699\u51b5\ua446\uc6da\uafe6\u21b2\u77d3", "\udbf6\ude6b\ud90e\uddd7\ud9db\uddcc\udba0\uded1\uda6b\uddf9\u26ee\udbf7\udcc1\udb42\ude64\udb6a\udecf\udbe5\udd37\ud950\uddc4",
        51, 32677, 322949130, -5397316876803296334L, 63315L, false, true, (char) 15399, (char) 60773,
        Double.longBitsToDouble(0x3fe695e0ef08cab5L), Double.longBitsToDouble(0x3fe7c37bad2c1bf0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:0.7057957333220971\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 9, "\uda26\udda9\ud877\udfbc\u1de2\ud872\udcad\ud91c\ude5e\ud814\udfb4\uda7b\udf7a\udbee\udc02\ud986\uded7\ud93d\udebb\ud92b\udc17\udb56\udf05\ud824\udd88\udb36\udd33\uda03\udd1d\ud931\uddaf\uda86\udf90\udafd\udcf8\ud981\udc0b\udb60\uddca\ud98b\ude26", "\u37c4\ub557\u2d99\ud154\u9b5f\u1e19\ucccd\005\u8c21\u5b4d\ud101\u65b7\u80d8\u1821\u455a\u3033\uacb3\u1890\ub6ee\uae58\u6d15\u6c39\u2543\ucf59\uacc4\uc699\u7162\u55e4\u326b\uc0a2\u3456\u77d3", "\udbf6\ude6b\ud90e\uddd7\ud9db\uddcc\udba0\udef0\uda6b\uddf9\udb8c\udc31\udbf7\udcc1\udb42\ude64\ud86c\uddaf\udb9c\ude94\ud802\ude3d",
        7, 32677, 322949130, -5397316872849971790L, -5489L, true, true, (char) 15399, (char) 60773,
        Double.longBitsToDouble(0x3fe695e0ef08cab5L), Double.longBitsToDouble(0x3fe7c37bad2c1bf0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:0.7385708187560881\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 4, "\udb1a\udde3\ud9be\udfb6\udba8\ude5e", "\uac5f\u4274\u2bc3\ua86a\ubf34\u11fd\u251e\u4cd3\u61f7\u07eb\u3436\u11d9", "\uda7a\udf98\ud86e\udf96\ud8d2\udde8\ud9e3\ude8d",
        20, 81488, -1290774748, -4923481691064256178L, 96900L, true, false, (char) 16315, (char) 51828,
        Double.longBitsToDouble(0x3fe7a25f450acb81L), Double.longBitsToDouble(0x3fb9adf0297c6838L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:0.7057957333220971\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 9, "\uda26\udda9\ud877\udfbc\u1de2\ud872\udcad\ud91c\ude5e\ud814\udfb4\uda7b\udf7a\uda85\udeef\ud986\udf0a\ud93d\udebb\ud92b\udc17\udb56\udf05\ud824\udd88\udb36\udd33\uda03\udd1d\ud931\uddaf\uda86\udf90\udafd\udcf8\ud981\udc0b\udb60\uddca\ud98b\ude26", "\u37c4\ub557\u2d99\ud154\u9b5f\u1e19\ucccd\005\u8c21\u5b4d\ud6ca\uccb6\u80d8\u1821\u455a\u3033\uacb3\u1890\u6360\uae58\u6d15\u6c39\u2543\ucf59\uacc4\uc699\u7162\u55e4\u326b\uc0a2\u3456\u77d3", "\udbf6\ude6b\ud90e\uddd7\ud9db\uddcc\udba0\udef0\uda6b\uddf9\udb8c\udc31\udbf7\udcc1\udb42\ude64\ud86c\uddaf\udb9c\ude94\ud802\ude3d",
        7, 32677, 322949130, -5397316872849971790L, -5489L, true, true, (char) 15399, (char) 60773,
        Double.longBitsToDouble(0x3fe695e0ef08cab5L), Double.longBitsToDouble(0x3fe7c37bad2c1bf0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 9, "\uda26\udda9\ud877\udfbc\u1de2\ud872\udcad\ud91c\ude5e\ud814\udfb4\uda7b\udf7a\udbee\udc02\ud986\uded7\ud91d\udebb\ud922\uddd0\udb56\udf05\ud824\udd88\ud9fb\udef6\ud9e1\ude70\ud931\uddaf\uda86\udf90\udafd\udcf8\ud981\udc0b\udb60\uddca\ud98b\ude26", "\u37c4\ub557}\ud0f6\u9b5f\u1e19\uc5cc\000\000\000\ud101\u65b7\u80d8\u1821\u455a\u3033\uacb3\u1890\ub6ee\uae58\u6d15\u17bf\u24e4\ucf59\uacc4\ua253\u7162\u47c6\u326b\uc0a2\u3456\u77d3", "\udbf6\ude6b\ud90e\uddd7\ud9db\uddcc\000\000\udb8b\udf42\udbf7\udcc1\udb42\ude64\ud86c\uddaf\udb9c\ude94\u00a7",
        58, 32677, 322949130, -5397316872849971790L, -5489L, true, true, (char) 15399, (char) 49,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e44b06c00000000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:0.21960106332654272\0121=java.lang.String:0.21960106332654272\012",
        Z.run(T, 2, 3, 3, 4, "\udb1a\udd47\ud880\udf58\ud9b0\ude9b", "\u059a", "\ud87e\uded3\ud9f6\udf3b\udbed\uddd3\ud894\ude51\ud8ec\udca4\uda3c\udf16",
        2, 97961, -1185346376, 6383034009938102870L, 19923L, false, true, (char) 10050, (char) 56219,
        Double.longBitsToDouble(0x3fcc1be33c93c0f4L), Double.longBitsToDouble(0x3febed99194ebbacL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:0.1418232573496373\0121=java.lang.String:0.1418232573496373\012",
        Z.run(T, 2, 3, 3, 9, "\uda26\udda9\ud877\udfbc\u1de2\ud872\udcad\ud91c\ude5e\ud814\udfb4\uda7b\udf7a\uda85\udeef\ud986\udf0a\ud93d\udebb\ud92b\udc17\udb56\udf05\ud824\udd88\uda33\udc71\uda23\udd1e\udaab\udefc\ud938\uddaf\udafd\udc05\ud981\udc0b\udb60\uddca\ud98b\ude26", "\u37c4\ub557\u2d99\ud154\u9b5f\u1e19\ucccd\005\ubc2f\u5b4d\ud6ca\uccb6\u80e7\u1821\u10e5\ube3a\u12f7\u1835\u6360\uae58\u6d15\u6c39\u2543\ucf59\uacc4\uc699\u7162\u55e4\u326b\uc0a2\u3456\u77d3", "\udbf6\ude6b\ud90e\uddd7\ud9db\uddcc\udba0\udef0\uda6b\uddf9\udb8c\udc31\udbf7\udcc1\udb42\uddc7\ud86c\uddaf\udb9c\ude94\ud802\ude3d",
        7, 32677, 322949130, -5397316872849971790L, -5489L, true, true, (char) 15399, (char) 60773,
        Double.longBitsToDouble(0x3fc22743b6107f44L), Double.longBitsToDouble(0x3fc6cfa915e9dae4L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 8, "\uda26\udda9\ud877\udfbc\udba8\ude5e", "\uac5f\u377d\u2bc3\u18c0\u7194\u56c1\u392d\u4cd3\u340a\u174b\u3436\u698d", "\udb60\uddca\ud86e\udf96\ud8d2\udde8\ud9ec\udd1d\uda72\udc63\udbec\udc6a\udb65\ude67\ud9da\udc9f\u73f3\ud99e\uddde\ua44d\ud91f\udd37\udad4\udfb2\ud8a6\udda8\ud8e0\udc96\uda7b\udc03\ud998\ude3c\u8180\udb93\ude2c\uda63\udeec\udb9f\ude7b\ud8e6\udf0f\ud850\udd04\ud99e\udead\uda68\udfb4\uda96\udf26\udbf6\udf67\ud9bc\udfef\uda25\ude9e",
        26, 27682, -685118291, -1617802208323081135L, -84542L, false, true, (char) 60574, (char) 45756,
        Double.longBitsToDouble(0x3fd3d98dce6a9c34L), Double.longBitsToDouble(0x3fec6740d2d4f5b8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:0\0121=java.lang.String:0\012",
        Z.run(T, 2, 3, 3, 9, "\uda26\udda9\ud877\udfbc\udbd4\udf7e\ud872\udcad\ud91c\ude5e\ud814\udfb4\uda7b\udf7a\udbee\udc02\ud986\uded7\ud91d\udebb\u64ac\ud8fd\ude95\ud824\udd88\ud9fb\udef6\ud9e1\ude70\ud931\uddaf\uda86\udf90\ud8b5\udf54\ud9a8\udca2\udb60\uddca\ud98b\ude26", "\u37c4\u0a58}\ud0f6\u9b5f\u1e19\uc5cc\ua301\u0adb\000\ud101\u65b7\u80d8\u1821\u455a\u3033\uacb3\u1890\ub6ee\uae58\u6d15\u17bf\u24e4\ucf59\uacc4\ua253\u7162\u47c6\u326b\uc0a2\u987c\u24a9", "\udbf6\ude6b\uda32\udca9\ud9db\uddcc\000\000\udb8b\udf42\udbf7\udcc1\udb42\ude64\udae0\ude0a\ud87f\udd38\u00a7",
        25, 1558, 322949130, -5397316872849971790L, -5489L, true, true, (char) 15399, (char) 49,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e44b06c00000000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.parsing.IRFactory|handleBlockComment|com.google.javascript.rhino.head.ast.Comment|new:com.google.javascript.jscomp.parsing.IRFactory:java.lang.String,com.google.javascript.rhino.jstype.StaticSourceFile,com.google.javascript.jscomp.parsing.Config,com.google.javascript.rhino.head.ErrorReporter",
    "M|com.google.javascript.jscomp.parsing.IRFactory|createJsDocInfoParser|com.google.javascript.rhino.head.ast.Comment,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.parsing.IRFactory:java.lang.String,com.google.javascript.rhino.jstype.StaticSourceFile,com.google.javascript.jscomp.parsing.Config,com.google.javascript.rhino.head.ErrorReporter",
    "M|com.google.javascript.jscomp.parsing.IRFactory|createTemplateNode||new:com.google.javascript.jscomp.parsing.IRFactory:java.lang.String,com.google.javascript.rhino.jstype.StaticSourceFile,com.google.javascript.jscomp.parsing.Config,com.google.javascript.rhino.head.ErrorReporter",
    "M|com.google.javascript.jscomp.parsing.IRFactory|getStringValue|double|static",
    "M|com.google.javascript.jscomp.parsing.IRFactory|handleJsDoc|com.google.javascript.rhino.head.ast.AstNode,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.parsing.IRFactory:java.lang.String,com.google.javascript.rhino.jstype.StaticSourceFile,com.google.javascript.jscomp.parsing.Config,com.google.javascript.rhino.head.ErrorReporter",
    "M|com.google.javascript.jscomp.parsing.IRFactory|handlePossibleFileOverviewJsDoc|com.google.javascript.jscomp.parsing.JsDocInfoParser|new:com.google.javascript.jscomp.parsing.IRFactory:java.lang.String,com.google.javascript.rhino.jstype.StaticSourceFile,com.google.javascript.jscomp.parsing.Config,com.google.javascript.rhino.head.ErrorReporter",
    "M|com.google.javascript.jscomp.parsing.IRFactory|handlePossibleFileOverviewJsDoc|com.google.javascript.rhino.head.ast.Comment,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.parsing.IRFactory:java.lang.String,com.google.javascript.rhino.jstype.StaticSourceFile,com.google.javascript.jscomp.parsing.Config,com.google.javascript.rhino.head.ErrorReporter",
    "M|com.google.javascript.jscomp.parsing.IRFactory|isExprStmt|com.google.javascript.rhino.head.ast.AstNode|new:com.google.javascript.jscomp.parsing.IRFactory:java.lang.String,com.google.javascript.rhino.jstype.StaticSourceFile,com.google.javascript.jscomp.parsing.Config,com.google.javascript.rhino.head.ErrorReporter",
    "M|com.google.javascript.jscomp.parsing.IRFactory|isPropAccess|com.google.javascript.rhino.head.ast.AstNode|new:com.google.javascript.jscomp.parsing.IRFactory:java.lang.String,com.google.javascript.rhino.jstype.StaticSourceFile,com.google.javascript.jscomp.parsing.Config,com.google.javascript.rhino.head.ErrorReporter",
    "M|com.google.javascript.jscomp.parsing.IRFactory|justTransform|com.google.javascript.rhino.head.ast.AstNode|new:com.google.javascript.jscomp.parsing.IRFactory:java.lang.String,com.google.javascript.rhino.jstype.StaticSourceFile,com.google.javascript.jscomp.parsing.Config,com.google.javascript.rhino.head.ErrorReporter",
    "M|com.google.javascript.jscomp.parsing.IRFactory|maybeInjectCastNode|com.google.javascript.rhino.head.ast.AstNode,com.google.javascript.rhino.JSDocInfo,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.parsing.IRFactory:java.lang.String,com.google.javascript.rhino.jstype.StaticSourceFile,com.google.javascript.jscomp.parsing.Config,com.google.javascript.rhino.head.ErrorReporter",
    "M|com.google.javascript.jscomp.parsing.IRFactory|maybeSetLengthFrom|com.google.javascript.rhino.Node,com.google.javascript.rhino.head.ast.AstNode|new:com.google.javascript.jscomp.parsing.IRFactory:java.lang.String,com.google.javascript.rhino.jstype.StaticSourceFile,com.google.javascript.jscomp.parsing.Config,com.google.javascript.rhino.head.ErrorReporter",
    "M|com.google.javascript.jscomp.parsing.IRFactory|newNode|int|new:com.google.javascript.jscomp.parsing.IRFactory:java.lang.String,com.google.javascript.rhino.jstype.StaticSourceFile,com.google.javascript.jscomp.parsing.Config,com.google.javascript.rhino.head.ErrorReporter",
    "M|com.google.javascript.jscomp.parsing.IRFactory|newNode|int,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.parsing.IRFactory:java.lang.String,com.google.javascript.rhino.jstype.StaticSourceFile,com.google.javascript.jscomp.parsing.Config,com.google.javascript.rhino.head.ErrorReporter",
    "M|com.google.javascript.jscomp.parsing.IRFactory|newNode|int,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.parsing.IRFactory:java.lang.String,com.google.javascript.rhino.jstype.StaticSourceFile,com.google.javascript.jscomp.parsing.Config,com.google.javascript.rhino.head.ErrorReporter",
    "M|com.google.javascript.jscomp.parsing.IRFactory|newNode|int,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.parsing.IRFactory:java.lang.String,com.google.javascript.rhino.jstype.StaticSourceFile,com.google.javascript.jscomp.parsing.Config,com.google.javascript.rhino.head.ErrorReporter",
    "M|com.google.javascript.jscomp.parsing.IRFactory|handleBlockComment|com.google.javascript.rhino.head.ast.Comment|new:com.google.javascript.jscomp.parsing.IRFactory:java.lang.String,com.google.javascript.rhino.jstype.StaticSourceFile,com.google.javascript.jscomp.parsing.Config,com.google.javascript.rhino.head.ErrorReporter",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
