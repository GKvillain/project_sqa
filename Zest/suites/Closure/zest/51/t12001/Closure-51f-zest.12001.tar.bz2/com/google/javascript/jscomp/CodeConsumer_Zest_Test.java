package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class CodeConsumer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 15, 0, 2, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1", "\u6949\u5619\u073a", "\ud915\udee8\ud91c\udcdb\ud808\udded\ud8c4\udfca",
        13, 46041, -211396461, 9026043281656089698L, 81971L, true, true, (char) 708, (char) 8956,
        Double.longBitsToDouble(0x3fea1d1d1ab4567aL), Double.longBitsToDouble(0x3fbfbe125ff24130L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 15, 15, 10, "\u2472\ud87c\udf7a\ud89a\udde1\udb15\udff1\ud8da\udd70\uda94\udd61\udad8\udda8\ud80f\udf03\udbdd\udfc8\ud8a0\udca3\ud915\udee8\ud91c\udcdb\ud808\udded\ud8c4\udfca\ud9d2\udc74\ud812\ude5b\ud8fd\udfef\udae5\ude57\ud9bb\udd90\uda4c\udc65\ud3a4\uda54\udc0e\ud8b7\udfac", "\uc139\u0dc2\u2190\u6e01\ub63d\u8485\u9042", "\ud88e\udd49\udb1a\udfba",
        35, 42779, -1483951256, -4484408606556217772L, 47569L, true, false, (char) 33480, (char) 12551,
        Double.longBitsToDouble(0x3fea0d330ada713fL), Double.longBitsToDouble(0x3fce71088da69980L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 15, 1, 2, "\000", "\000", "\000\ud80f\udf03\u00c6b\000\000\000\000\uda9c\udeee\udabf\ude7c\udb83\udf41\udb02\uddec\ud918\udf1c\ud8c9\ude1e\u009b\000\ud936\udf22\ud817\udf59\udbb2\udfee\uda58\udd3f\ucf43\uda8a\ude3f~\udac0\udc62",
        42, 24999, -515138202, 7884032101470861809L, -11386L, false, false, (char) 16808, (char) 10667,
        Double.longBitsToDouble(0x3fedaa714474b16aL), Double.longBitsToDouble(0x3fe8a541f22cb1f4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 15, 4, 13, "\udbee\udfd2\uda36\udfa7\ud89a\ude9a", "\u6949\u6451\u0805", "\ud866\udfee\ua4f2\udba8\uddc2\uda42\udce6",
        13, 46041, -211396461, 9026043281656089698L, 5939L, false, true, (char) 11128, (char) 8956,
        Double.longBitsToDouble(0x3fea1d1d1ab4567aL), Double.longBitsToDouble(0x3fbfbe125ff24130L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 14, 10, 2, "", "", "\ud8da\udd70\uda94\udd61\udad8\udda8",
        15, 23262, -1358954496, 7032169780447833308L, 73900L, false, true, (char) 43643, (char) 1172,
        Double.longBitsToDouble(0x3fe45f9b30000000L), Double.longBitsToDouble(0x3fe8df53489bab5fL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 9, 12, 2, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1\udb15\udff1\ud8da\udd70\uda94\udd61\udad8\udda8\ud80f\udf03\udbdd\udfc8", "\u33a4\u16b4\u7be6\ua566\u0aca\uc9a3\ucf00\u02cc\u76cd\u254f\u8b9b\u1530\ud575\u6ed4\u8568\u26d0\ub778\ud291\u8408\u764a", "\uda25\udd7e\ud9d1\udc1a\ud898\udd30\udbb9\udc1a\udbe9\udf48\ud979\udc0a\udb63\udc08",
        48, 87300, 1774373589, 361294368370126146L, 7796L, false, false, (char) 53292, (char) 51831,
        Double.longBitsToDouble(0x3fbc36f84a383728L), Double.longBitsToDouble(0x3fd2fc03ea81ad28L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 0, 2, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1", "\u6949\u5619\u073a", "\ud915\udee8\ud91c\udcdb\ud808\udded\ud8c4\udfca",
        13, 46041, -211396461, 9026043281656089698L, 81971L, true, true, (char) 708, (char) 8956,
        Double.longBitsToDouble(0x3fea1d1d1ab4567aL), Double.longBitsToDouble(0x3fbfbe125ff24130L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 0, 0, 2, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1", "\u6949\u5619\u073a", "\ud915\udee8\ud91c\udcdb\ud808\udded\ud8c4\udfca",
        13, 46041, -211396461, 9026043281656089698L, 81971L, true, true, (char) 708, (char) 8956,
        Double.longBitsToDouble(0x3fea1d1d1ab4567aL), Double.longBitsToDouble(0x3fbfbe125ff24130L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 15, 0, 2, "\udbee\udfd2\udaf0\udd94\000", "\u6949", "\udbdd\udfc8b\ud915\udec0\ud91c\udcdb\ud808\udded\ud8c4\udfca\u2b72\ud998\udd10\udb99\udf41\udb02\uddec\u8c62\000\udb78\udcd6\000\ud905\udd22\u891f\ud98a\udc04\000",
        -5, -1000, 1210491006, -4301522591411281795L, 35544L, true, false, (char) 48815, (char) 7726,
        Double.longBitsToDouble(0x3fa2416a9970afd0L), Double.longBitsToDouble(0x3fedc320601827a5L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 15, 2, 11, "\udbee\udfd2\ud96c\uddb7\ud8e1\uddaf\uda06\udd2d\udb87\udd60", "\u073a\u331e\u95f2\u6c86", "\udbe6\udfbc\udaa7\ude4b\ud998\uddcb\udb38\udda4\ub54a\ud918\udf53\ud94d\ude1f\udb64\udfcd\udbf1\udfde\ud936\udff5\ud817\udf59\ud84d\udefc\ud9f8\udfa5\udb54\udca6\uda92\ude97\ud97b\ude1d\udba0\uddcf\uda7a\udf15\udbe9\udd20\udaa8\uddac\uda36\udd24\ud834\udddd\ud8cd\udc8f\ud9a1\udf1f\udbb7\udc40\uda9c\udcab\ud88a\uddd8\udb10\udc02\ud937\uddf7\ud96e\udcb2",
        11, 17264, 1326934064, 699514921345154088L, -81395L, true, true, (char) 17409, (char) 45496,
        Double.longBitsToDouble(0x3fe9c7b95e305955L), Double.longBitsToDouble(0x3f6d7fc46caa7400L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 5, 3, 0, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1", "\u6949\u5619\u073a", "\ud882\udc21\ud8ef\udeea\ud904\udfda\ud84a\udd84",
        2, 46041, -211396461, 9026043281656089698L, 81971L, true, true, (char) 708, (char) 8956,
        Double.longBitsToDouble(0x3fea1d1d1ab4567aL), Double.longBitsToDouble(0x3fbfbe125ef385e0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 1, 11, 2, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1", "\u6949\u5619\u073a", "\ud915\udee8\uda08\ude32\ucc7c\ud8c4\udfca",
        13, 46041, -211396461, 9026043281656089698L, -42874L, true, false, (char) 29414, (char) 12846,
        Double.longBitsToDouble(0x3fd7eacde7fc904cL), Double.longBitsToDouble(0x3fe09d5b440322f3L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 4, 0, 2, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1", "\u6949\u5619\u073a", "\ud915\udee8\ud91c\udcdb\ud808\udded\ud8c4\udfca",
        13, 46041, -211397416, 9026043281656089698L, 81971L, true, true, (char) 708, (char) 8956,
        Double.longBitsToDouble(0x3fea1d1d1ab4567aL), Double.longBitsToDouble(0x3fbfbe125ff24130L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 9, 0, 2, "\udb8a\udf3f\udbb1\udc24\ud89a\udde1", "\u6949\u1a19\uab60", "\ud915\udee8\ud91c\udcdb\ud808\udd61\ud8c4\udfca",
        29, 46041, -211396461, 9026043281656089698L, 81971L, true, true, (char) 708, (char) 8956,
        Double.longBitsToDouble(0x3fea1d1d1ab4567aL), Double.longBitsToDouble(0x3fbfbe125ff24130L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 13, 7, 3, "\ud884\udd7d\ud89e\udd12\ud9c1\udf11", "\u6949\u5619\u073a\u331e\u95f2\u6c21", "\ud8c4\udfca\udaa7\ude60\ud998\udd89\udb99\udfd4\udb02\uddec\ud918\udf1c\ud8c9\ude1e\udb78\udcd6\udbf1\udfde\ud936\udff5\ud817\udf59\udbb2\udfee\uda58\udd3f\uda58\udde0\uda8a\ude3f\ud9eb\udcbe\ud855\udecb\uda24\udeca\ud936\udd0f\ud8e3\udfae\u7bd3\ud94d\udc42\ud973\udf2b\ud86e\udf87\ud960\uddce\ud954\udfd9\udaf6\udede\udb17\udeef\udaa5\udd50\ud8e4\udc36",
        53, 44280, -403496283, 1155575631509177380L, -66192L, true, true, (char) 37865, (char) 54154,
        Double.longBitsToDouble(0x3fed127e57d23916L), Double.longBitsToDouble(0x3fcd4512923f0760L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 15, 0, 2, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1\udb15\udff1\ud8e6\udcc1", "\u073a\u331e\u95f2\u4cd2", "\ud8c4\udfca\udaa7\ude60\ud998\udd89\udb99\udfd4\udb02\uddec\ud918\udf1c\ud810\udd6a\udb78\udcd6\ud973\udfdf\ud936\udff5\ud817\udf59\udbb2\udfee\uda58\udd3f\udaa7\udc5b\uda8a\ude3f\ud9eb\udcbe\ud96c\ude96\ud8ea\udeb3\ud80b\udcab\ud9da\udebb\ud85c\udebc\ud8e4\udd9a\udab1\udc49\ud83d\udec0\udacc\udf5e\uda37\ude24\ud83d\udccd\uda6b\ude46\udbc7\uddc7\ud9a2\udd38",
        46, 30160, -1606940860, -5872001453435014514L, -68495L, false, true, (char) 47799, (char) 13747,
        Double.longBitsToDouble(0x3fe247b5ac0ccf1fL), Double.longBitsToDouble(0x3fcd1e4f101492a4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 15, 14, 2, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1", "\u6949\u5619\u073a", "\ud915\udee8\ud91c\udcdb\ud808\udded\ud8c4\udfca",
        13, 46041, -211396461, 9026043281656089698L, 81971L, true, true, (char) 708, (char) 8956,
        Double.longBitsToDouble(0x3fea1d1d1ab4567aL), Double.longBitsToDouble(0x3fbfbe125ff24130L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 0, 0, "", "\u05b3\u66f4\000\000\u35a5\u073a\u00c6\u77ff\000\uc863\u4eb3", "\udabf\ude03",
        27, 31467, -362181534, 12210592022683L, -100000L, false, true, (char) 708, (char) 8956,
        Double.longBitsToDouble(0x3ec4600000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 13, 4, 2, "\udbee\udfd2\udaee\udfd4\ud89a\ude94", "\u6949\u5619\u073a", "\ud915\udee8\ud91c\udcdb\ud808\udded\ud8c4\udfca",
        13, 46041, -211396461, 9026043281656089698L, 81971L, true, true, (char) 59290, (char) 8953,
        Double.longBitsToDouble(0x3fea1d1d1ab4567aL), Double.longBitsToDouble(0x3fd7ef8494b01780L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 13, 6, 2, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1", "\u6949\u5619\u073a", "\uda27\ude94\ud9bb\udfb2\ud808\udd4f\ud8c4\udfca",
        46, 62217, -211396461, 9026043281656089698L, 81971L, true, true, (char) 708, (char) 36167,
        Double.longBitsToDouble(0x3fdc09f9f568acf4L), Double.longBitsToDouble(0x3fbfbe125ff78930L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 9, 9, 6, "\udbee\udfd2\ud802\udf7d\uda8a\udfb8\udb17\udc57\ud8da\udd70", "\u073a\u331e\u95f2\u4cd2", "\u76e1\udaa7\udea4\ud998\udd89\udba6\udeb1\udb02\uddec\ud918\udeff\ud88f\udf01\ud809\udc87\uda06\udc44\udac0\udfdf\ud892\udc42\udbb2\udfee\uda58\udd3f\udaa7\udc5b\uda8a\ude3f\ud9c8\udc8d\udb5e\udc2c\ud8f0\udcab\ud974\udf96\uda18\udcdd\udac8\udcb5\uda37\udd4d\ud8eb\uddad\ud969\udfc3\ud9a6\udd94\uda45\udf3c\ud9e5\udd66\ud978\udc28\ud92a\udfca\udad3\udef9",
        25, 47086, -1680509041, 7532941093199506860L, -70551L, false, true, (char) 49989, (char) 57285,
        Double.longBitsToDouble(0x3f7cb0ff0fc3c400L), Double.longBitsToDouble(0x3feb9cde2be607c1L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 14, 14, 3, "\u8cf7\uda02\udfb6\ud89a\udde1\udb15\udff1\ud8da\udd70\uda94\udd61\udad8\udda8", "\u8dc5\u4cd2", "\ud8c4\udfca\udbbf\uddcc\udb68\udeeb\udb67\udfa9\udaf8\udd7f\ud968\ude43\ud8d4\udfc7\udb78\udcd6\udbf1\udfde\udadc\uddf0\ue07c\ud8e9\ude0a\uda2e\uddda\uda7d\udfef\uda8a\ude3f\ud9eb\udcbe\udbe9\udcb5\udae9\udc68\uda7c\udfe0\ud8f9\udf2f\ud83d\uddf8",
        37, 2446, -1318046969, 5429878141493904101L, -15580L, true, false, (char) 8874, (char) 3536,
        Double.longBitsToDouble(0x3fdeb1282e46badcL), Double.longBitsToDouble(0x3fe3a73219e5ef2dL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 1, 1, 9, "\ud98b\ude93\ud9db\udd1e\ud89a\udde1\udb15\udff1\ud8da\udd70\uda94\udd61\udad8\udda8\ud80f\udef3\udbdd\udfc8\ud8a0\udca3\ud915\udee8\ud91c\udcdb\ud808\udded\ud8c4\udfca", "\u6c86\ucf00\u7ef1\uce2a\uc8eb\u8b9b\u1530", "\uda58\udd3f\udaa7\udc5b\uda8a\ude3f\ud9eb\udcbe\ud8a7\udff3\ud8cd\udf43\uda55\udd8b",
        52, 52389, -1062748323, 6979457803423110291L, -85578L, true, true, (char) 57111, (char) 19380,
        Double.longBitsToDouble(0x3fd306c6d2154af8L), Double.longBitsToDouble(0x3f943abb7ee086e0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 2, 3, 3, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1", "\u12ca\u5619\u073a", "\ud915\udee8\uda64\udfc5\ud808\udd92\ud951\udc87",
        52, 83159, -647929727, 9026043019023708389L, -18378L, false, false, (char) 6373, (char) 54653,
        Double.longBitsToDouble(0x3fcb50e9617b212cL), Double.longBitsToDouble(0x3fec02060ab4567aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 12, 12, 14, "\uda4a\udfda\ud8e4\udfe2\ud8ad\udd3c\udb60\udd56\ud9ad\udf2b\uda94\udd30", "\ub28f\u95f2\u4cd2\ua750\u3c8b\u2559\ud76a\u2fab\ubc8d\u6f64\ucab1\ucec1\u09a5\u91a3\ud517\u4649\ud3e0\u16b1", "\ud9eb\udcbe\ud8d3\udee9\udb50\udc8f\ud9a7\udf07\udb10\udfe1\ud861\uddf8\udb1d\udedd\udb2b\ude71\ud875\udc09\ud82e\udf06",
        19, 202, 1466065157, 8992764820113837048L, 78973L, true, false, (char) 28658, (char) 17439,
        Double.longBitsToDouble(0x3fea09946d3abdd7L), Double.longBitsToDouble(0x3feaa67f215adc37L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 4, 12, 2, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1", "\u8c52\u5619\u0821", "\ud915\udee8\udbd8\uddf9\ud9b9\udf12\ud88a\udeb0",
        3, 14576, -211396461, 9026043281656104802L, 81971L, true, true, (char) 33953, (char) 8956,
        Double.longBitsToDouble(0x3fea1d1d1ab4567aL), Double.longBitsToDouble(0x3fbfbe3b5ff24130L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 8, 0, 2, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1", "\u6949", "\udbc6\udd02",
        1, 93616, 1137994972, -5836297111389339468L, -25881L, true, false, (char) 58865, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e4b4d6238000000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 1, 15, 10, "\u2472\ud87c\udf7a\ud89a\udde1\udb15\udff1\ud8da\udd70\uda94\udd61\udad8\udda8\ud80f\udf03\udbdd\udfc8\ud8a0\udca3\ud915\udee8\ud91c\udcdb\ud808\udded\ud8c4\udfca\ud9d2\udc74\ud812\ude5b\ud8fd\udfef\udae5\ude57\ud9bb\udd90\uda4c\udc65\ud3a4\uda54\udc0e\ud8b7\udfac", "\uc139", "\ud9eb\udcbe\udbdc\udf4e\uda50\uddfe\uda8f\udc73\ud874\udcde\ud9aa\uddce\ud88e\udd49\udb1a\udfba\uda66\udd44\ud876\udefb",
        39, 10810, 0, 2097152000L, -77436L, false, true, (char) 34210, (char) 19481,
        Double.longBitsToDouble(0x3fce71088da69980L), Double.longBitsToDouble(0x3fea840408807502L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 10, 10, 10, "\u2472\udaf4\ude5d\ud89a\udde1\udb15\udff1\ud8da\udd70\ud9ad\udf19\ud93b\udcaf\ud80f\udf23\udbdd\udfc8\ud8a0\udce4\ud915\udee8\ud91c\udcdb\ud808\udded\ud8c4\udfca\ud9d2\udc74\ud812\ude5b\ud8fd\udfef\udae5\ude57\ud9bb\udd90\uda4c\udc65\ud3a4\uda54\udc0e\ud8b7\udfac", "\uc139\u0dc2\u2190\u6e01\ub63d\u8485\u9042", "\udbae\udce5\udb9f\ude62",
        -1, 42779, -1483951256, -4484408606556217772L, 47569L, true, false, (char) 33480, (char) 12551,
        Double.longBitsToDouble(0x3fe665330ada713fL), Double.longBitsToDouble(0x3fe7d2122369a671L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 4, 8, 4, "\udbee\udfd2", "\ud2dc\ub93d", "\udbae\udc8c\udbdd\udfdc\ud8a0\udca3\ud866\udfee",
        22, 34349, -1952452825, -6132221510540140935L, 93212L, false, true, (char) 62852, (char) 44026,
        Double.longBitsToDouble(0x3fe53b27c5d3588eL), Double.longBitsToDouble(0x3fda61e25082166eL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 15, 4, 13, "\uaa90\uda37\udc0c\ud89a\ude9a", "\u6949\u6451\u0805", "\ud866\udfee\ua4f2\udba8\uddc2\uda98\ude70",
        23, 46041, -211396461, 9026043281656089698L, 71349L, false, true, (char) 11128, (char) 8956,
        Double.longBitsToDouble(0x3fea1d1d1ab4567aL), Double.longBitsToDouble(0x3fbfbe125ff24130L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 1, 4, 13, "\ud9cb\ude97\ud965\udc5b\ud89a\ude9a", "\u4228\u3463\u0805", "\ud866\udfee\ua4f2\udba8\uddc2\uda44\udee6",
        13, 46041, -211396461, -6106051466308776868L, 96463L, true, false, (char) 63072, (char) 64458,
        Double.longBitsToDouble(0x3fb042cdf589a258L), Double.longBitsToDouble(0x3fea1d1d1ab4567aL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 4, 4, 13, "\udbee\udfd2\uda36\udfa7\ud89a\ude9a", "\u6949\u6451\u0805", "\ud866\udfee\ua4f2\udba8\uddc2\uda42\udce6",
        13, 46041, -211396461, 9026043281656089698L, 5939L, false, true, (char) 11128, (char) 8956,
        Double.longBitsToDouble(0x3fea1d1d1ab4567aL), Double.longBitsToDouble(0x3fc93f092ff92194L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 0, 4, 13, "\u73a2", "\ud2dc\ub93d", "\ud80f\udfce\udbdd\udfdc\ud8a0\udca3\ud866\udfee\ua4f2",
        7, 6310, -1442698382, -3273998227926352741L, 1474L, false, false, (char) 64044, (char) 26527,
        Double.longBitsToDouble(0x3fdd3588eb4c3c4aL), Double.longBitsToDouble(0x3fb042cdf589a258L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 13, 13, 11, "\udbee\udfd2\uda36\udfa7\ud89a\ude9a", "\u6949\u6451\u0805", "\ud9cd\udfec\ua4f2\udba8\uddc2\uda42\udce6",
        13, 46041, -211396461, 9026043281505032078L, 5939L, false, true, (char) 11128, (char) 8956,
        Double.longBitsToDouble(0x3fea1d0552b4567aL), Double.longBitsToDouble(0x3fbfbe125ff24130L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 0, 16, "\u6995\ud9f6\udf77\ud89a\udde1", "\u6949\u5619\ua457", "\udbf7\udc61",
        57, 85187, 878794932, -6196342370087281031L, -31019L, false, false, (char) 62852, (char) 44026,
        Double.longBitsToDouble(0x3fe5381fc6d3588eL), Double.longBitsToDouble(0x3fd1fcf5e1b5c3d2L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 3, 8, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1", "\u7207\ub818\u073a", "\udb33\udc3d\udbe5\udc19\udb9a\udc57\ud8e9\udf89",
        35, 78126, -204253037, 9071149427630640226L, -99859L, true, false, (char) 8071, (char) 22653,
        Double.longBitsToDouble(0x3fc95c3d3ac4d12cL), Double.longBitsToDouble(0x3fc3d4747555de64L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 1, 10, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1", "\u68ec\u5619\u073a", "\ud915\udee8\ud91c\udcdb\u4eb3\ud8c4\udf16",
        13, 46041, -211396461, 9026043281656089698L, 81971L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fbfbe1240000000L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 11, 11, 2, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1", "\u9c7c\u5589\u5371", "\ud915\udee8\uda08\ude32\ucc7c\ud967\udf5e",
        13, 46041, -211396461, 9056227073309285668L, -89745L, true, false, (char) 47790, (char) 22726,
        Double.longBitsToDouble(0x3fcb5c3d3ac4d12cL), Double.longBitsToDouble(0x3fe6fd918ba15634L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 4, 4, 2, "\udbee\udfd2\ud9f6\udf77\ud89a\udde1", "\u6949\u5619\u073a", "\ud915\udee8\udae6\ude81\ud808\uddea\ud8c4\udfca",
        13, 46041, -211397416, 9026043281656089698L, 81971L, true, true, (char) 708, (char) 8956,
        Double.longBitsToDouble(0x3fea1d1d1ab4567aL), Double.longBitsToDouble(0x3fbfbe125ff24130L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 3, 16, "", "\u406c\u66f4\000\000\u35a5\u073a\u3ceb\u2f03\000\uc863\u4eb3", "\udabf\ude03",
        27, 31467, -362181534, 2377912813843658623L, -100000L, false, true, (char) 708, (char) 8956,
        Double.longBitsToDouble(0x3ec4600000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 4, 4, 2, "\udb8a\udf3f\ud81a\ude15\ud89a\udde1", "\u8c52\u23f8\u0821", "\ud915\udee8\udbd8\uddf9\ud9b9\udf12\ud88a\udeb0",
        3, 14576, -211413311, 9026043281656104802L, 81971L, true, true, (char) 33953, (char) 8956,
        Double.longBitsToDouble(0x3fea1d1d1ab4567aL), Double.longBitsToDouble(0x3fbfbe3b5ff72930L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 0, 0, 2, "\ud8b9\udf16\ud9f6\udfd8\ud89a\udde1", "\u6949", "\udbc6\udd02",
        1, 93616, 1137994972, -9053556095192137654L, -25881L, true, false, (char) 58865, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fb48000369ac470L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 4, 4, 13, "\uaa90\uda37\udc0c\ud89a\ude5a", "\u6949\u6451\u0805", "\ud866\udfee\ua4f2\udba8\uddc2\uda98\ude70",
        23, 46041, -211396461, 9026043281656089698L, 27734L, false, true, (char) 22822, (char) 34734,
        Double.longBitsToDouble(0x3fb042cdf589a258L), Double.longBitsToDouble(0x3fea1d1d1ab4567aL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 15, 0, 2, "\udbee\udf83\ud9f6\udf77\ud89a\udde1", "\u6949\u9661\u5f33", "\ud915\udee8\ud91c\udcdb\ud808\udded\ud8c4\udfca",
        13, 46041, -211396461, 9026043281656089698L, 81971L, true, true, (char) 46045, (char) 8956,
        Double.longBitsToDouble(0x3fea1d1d1ab4567aL), Double.longBitsToDouble(0x3fbfbe125ff24130L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.CodeConsumer|addNumber|double|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|isNegativeZero|double|static",
    "M|com.google.javascript.jscomp.CodeConsumer|add|java.lang.String|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|addIdentifier|java.lang.String|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|addOp|java.lang.String,boolean|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|append|java.lang.String|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|appendBlockEnd||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|appendBlockStart||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|appendOp|java.lang.String,boolean|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|beginBlock||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|beginCaseBody||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|breakAfterBlockFor|com.google.javascript.rhino.Node,boolean|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|continueProcessing||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|endBlock||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|endBlock|boolean|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|endCaseBody||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|addNumber|double|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|isNegativeZero|double|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
