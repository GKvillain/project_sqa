package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class Compiler_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 15, 13, "\ud957\udd94\ud9af\uddab\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udbc2\udf55", "\u3aba\u74eb\ua145\uce74\u1c7e\u7a34", "\ud986\udff6\udb46\udeba\uda8c\udfff\ud83b\udeb6\ud8b5\udd76\ud8d0\udedf\uda4f\udd34\ud95b\ude4c\udb0a\ude08\ud943\ude33\udb01\udcca\ud853\udca2\ud814\udec5\ud847\udc3d\udb50\uddce\ud840\udc28\ud96f\udcdf\udae2\udc01\ud84e\udf90\ud81e\udcd9\uda67\udff7c\ud8a8\ude2b",
        31, 18078, -2035611008, -8162726340327176888L, 90146L, true, true, (char) 58468, (char) 43074,
        Double.longBitsToDouble(0x3fbc531855d220f8L), Double.longBitsToDouble(0x3fe65041ad9f63b1L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 15, 13, "\uda24\ude7d\ud957\udfae\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udbc2\udf55\ud8b8\uddcc\ud931\uddb6\udbce\udf35\uda60\udf91\udbe4\uddd6\udb0c\udefe\udbcf\udc57\ud8d0\ude99\ud95a\udfc8\ud90a\udea6\ud986\udff6\udb46\udeba\uda8c\udfff\ud83b\udeb6\ud8b5\udd76\ud8d0\udedf", "\ua6a9\u0629\u56c0\ub8cd\u2714\u2082\u5636\u7dcb\u39df", "\ud81e\udcd9\uda70\udf02\ud932\udc07\ud8a8\ude2b\ud8d7\udd6f\ud96a\udee9\ud9f4\udf73\udbef\udcf6\udb22\udc77",
        -5, 52622, 1208674733, -8267874049954945021L, -76033L, false, false, (char) 13451, (char) 21010,
        Double.longBitsToDouble(0x3fe51475039937e8L), Double.longBitsToDouble(0x3fd62328de1e5f46L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 15, 13, "\ud956\udc27\ud9af\uddab\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udbc2\udf55", "\u3aba\u74eb\ua0da\ucdf5\u1c7e\u7a34", "\ud986\udff6\udb46\udeba\uda8c\udfff\ud83b\udeb6\ud8b5\udd76\ud8d0\udedf\uda4f\udd34\ud95b\ude4c\udb0a\ude08\ud943\ude33\udb01\udcca\ud853\udca2\ud814\udec5\ud847\udc3d\udb50\uddce\ud840\udc28",
        35, 76197, 1391335085, -4264807321226532134L, 25365L, true, false, (char) 6908, (char) 18628,
        Double.longBitsToDouble(0x3fed24355d488eb8L), Double.longBitsToDouble(0x3fe299b0993eccabL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 15, "\ud957\udd94\ud9af\uddab\ud8ee\ude53\udb3c\uddea\udbf8\uddc5\udbc7\udf2b", "\u3aba\u74eb\u36df\ucec9\u2910\u7a34", "\ud986\udff6\u40c1\uda8c\udfff\ud83b\udeb6\ud8f6\udc16\ud94d\ude1e\udadd\udcc5\ud95b\udddf\udb0a\ude08\ud943\ude33\udb01\udcca\udb84\uddef\ud814\udec5\ud847\udc3d\ud927\udcfa\ud85c\udea9\ud99e\udc9e\uda59\udf20\ud84e\udf90\udb87\udccd\uda67\udff7c\ud8a8\ude2b",
        31, 18078, -2035611008, -8162502770099550904L, -92638L, false, false, (char) 13854, (char) 43560,
        Double.longBitsToDouble(0x3fb7dcaf15d220f8L), Double.longBitsToDouble(0x3fe65041adea63b1L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 15, 13, "\ud957\udd94\ud9af\uddab\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udbc2\udf55", "\u3aba\u74eb\ua145\uce74\u1c7e\u7a34", "\ud986\udff6\udb46\udeba\uda8c\udfff\ud83b\udeb6\ud8b5\udd76\ud8d0\udedf\uda4f\udd34\ud95b\ude4c\udb0a\ude08\ud943\ude33\udb01\udcca\ud853\udca2\ud814\udec5\ud847\udc3d\udb50\uddce\ud840\udc28\ud96f\udcdf\udae2\udc01\ud84e\udf90\ud81e\udcd9\uda67\udff7c\ud8a8\ude2b",
        31, 18078, -2035611008, -8162726340328423352L, 90146L, true, true, (char) 58468, (char) 43074,
        Double.longBitsToDouble(0x3fbc531855d220f8L), Double.longBitsToDouble(0x3fe65041ad9f63b1L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 15, 13, "\ud9fb\udf08\ud98d\udd63\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udba2\ude97", "\u3aba\u74eb\ua145\uce74\u1c7e\uca76", "\ud986\udff6\udb46\udeba\uda8c\udfff\ud83b\udeb6\ud8b5\udd76\ud8d0\udf15\uda4f\udd34\ud95b\ude4c\udb0a\ude08\ud943\ude33\udb01\udcca\ud853\udca2\ud814\udec5\ud847\udc3d\udb50\uddce\ud840\udc28\ud96f\udcdf\udae2\udc01\ud9cc\udf8f\ud81e\udcd9\uda67\udff7c\ud8a8\ude2b",
        31, 95446, -2035611008, -8162726341468680120L, 90146L, true, true, (char) 24556, (char) 25650,
        Double.longBitsToDouble(0x3fe8245296b2378aL), Double.longBitsToDouble(0x3fd15cd3ca90829aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 15, 2, "\ud957\udd94\ud9af\uddab\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udbc2\udf55", "\u3aba\u74eb\ua145\u8489\u1d35\u7a34", "\ud986\udff6\udb46\udeba\uda8c\udfff\ud83b\udeb6\ud8b5\udd76\ud8d0\udedf\uda4f\udd34\ud95b\ude4c\udb0a\ude08\ud943\ude33\udb01\udcca\ud853\udca2\ud814\udec5\ud847\udc3d\udb50\uddce\ud840\udc28\ud96f\udcdf\udae2\udc01\ud84e\udf90\ud81e\udcd9\uda67\udff7\udbfc\ude41\ud8a8\udd9e",
        31, 18078, -2035611008, -8162726340327176888L, 90146L, true, true, (char) 58468, (char) 43074,
        Double.longBitsToDouble(0x3fbc531855d220f8L), Double.longBitsToDouble(0x3fe65041ad9f63b1L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 4, 13, "\ud92f\udd37\ud9af\uddab\ud8ee\ude53\udb1a\udf92", "\u0829\ua572\u3aba\u9666\u987d\uce74\uadbc\u2559", "\ud986\udff6\uda5f\udf08\uda78\ude75\u0b92\ud8c6\udf41\ud8d0\udedf\uda4f\udd34\ud95b\ude4c\udb0a\ude08\ud9e8\udee6\udb01\udcb6\ud853\udca2\ud814\udec5\ud847\udc3d\udb50\uddce\ud840\udc28\ud96f\udcdf\ud93f\udf10\ud915\udeec\udaff\udd96\ud96d\udc30c",
        59, 77931, 1044662078, -8742771655027709020L, -28749L, true, false, (char) 43074, (char) 35405,
        Double.longBitsToDouble(0x3f89515ab2822540L), Double.longBitsToDouble(0x3fd9f63b159e856eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 15, 13, "\ud957\udd94\ud9af\uddab\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udbc2\udf55", "\u3aba\u74eb\ua145\uce74\u2edc\u8d11", "\ud986\udff6\udb46\udeba\uda8c\udfff\ud83b\udeb6\ud8b5\udd76\ud8d0\udedf\uda4f\udd34\ud95b\ude4c\udb0a\ude08\ud943\ude33\udb01\udcca\ud853\udca2\ud814\udec5\ud847\udc3d\udb50\uddce\ud840\udc28\ud96f\udcdf\udae2\udc01\ud84e\udf90\ud81e\udcd9\uda67\udff7c\ud8a8\ude2b",
        31, 18078, -2035611008, -8162726340327176888L, 90146L, true, true, (char) 37414, (char) 43074,
        Double.longBitsToDouble(0x3fbc531855d220f8L), Double.longBitsToDouble(0x3fe65041ad9f63b1L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 5, 13, "\ud957\udd94\ud9af\uddab\ud8ee\ude53\udb1a\udf92", "\u0829\ua572\u3aba\u74eb\ua145\uce74\u1c7e\u7a34", "\ud986\udff6\udb46\udeba\uda8c\udfff",
        23, 33360, -504599387, 3623225844101013628L, 47797L, false, true, (char) 26615, (char) 28441,
        Double.longBitsToDouble(0x3fe7f73b49ff5907L), Double.longBitsToDouble(0x3fe127e6734f9a75L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 15, 13, "\ud957\udd94\ud9af\uddab\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udbc2\udf55", "\u3aba\u74eb\ua145\uce74\u1c7e\u7a34", "\ud986\udff6\udb46\udeba\uda8c\udfff\ud83b\udeb6\ud8b5\udd76\ud8d0\udedf\uda4f\udd34\ud95b\ude4c\udb0a\ude08\ud943\ude33\udb01\udcca\ud853\udca2\ud814\udec5\ud847\udc3d\udb50\uddce\ud840\udc28\ud96f\udcdf\udae2\udc01\udbcf\uddf2\udb43\ude72\uda67\udff7c\udafd\uddf9",
        4, 21908, -2035611035, 93430606584462811L, 90146L, true, true, (char) 58468, (char) 43074,
        Double.longBitsToDouble(0x3fbc531855d220f8L), Double.longBitsToDouble(0x3fe65041ad9f63b1L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 15, 15, "\ud957\udd94\ud9af\uddab\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udbc2\udf55", "\u3aba\u74eb\ua145\uce74\u1c7e\u7a34\uba49\u72f8\u4803\u49e7\u1f1b\u893d\u9722\u58ff", "\udb0a\ude08\ud943\ude33\udb01\udcca\ud853\udca2\ud814\udec5\ud847\udc3d\udb50\uddce\ud8d8\ude94\udb0a\ude26",
        -3, 59085, 1560575133, 6255123905972758000L, -20117L, false, true, (char) 19652, (char) 51976,
        Double.longBitsToDouble(0x3fc260f09102f414L), Double.longBitsToDouble(0x3fd66a5eb35b132aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 11, 6, 6, "\ud957\udd94\ud9af\uddab\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udbc2\udeeb", "\ub19d\ud507\u86e6\uce99\u1c7e\u7a34", "\ud986\udff6\udb46\udeba\uda8c\udfff\ud83b\udeb6\ud8c2\ude3c\uda45\udf59\u0f39\ud900\udfeb\udb09\udd4c\ud94b\udf91\udb01\udcca\ud853\udca2\udaee\ude29\ud847\udc04\udb50\uddce\u1a4b\ud96f\udcdf\udae2\udc01\ud8bc\ude89\ud823\udcef\uda67\udff7\udba2\udc22\uda6e\udf9b",
        46, 40878, -2035555059, -8162726341628394168L, 1556L, true, true, (char) 58632, (char) 43074,
        Double.longBitsToDouble(0x3fbc531855d220f8L), Double.longBitsToDouble(0x3fc55a66b5bfbb20L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\012",
        Z.run(T, 1, 7, 14, 7, "\ud957\udd94\ud9af\uddab\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udbc2\udf55", "\u3aba\u74eb\ua145\uce74\u1c54\u7a34", "\ud986\udff6\udb46\udeba\uda8c\udfff\ud83b\udeb6\ud8b5\udd76\ud8d0\udedf\uda4f\udd34\ud95b\ude4c\udb0a\ude08\ud943\ude33\ud8b5\udd52\ud86e\udcc1\ud814\udec5\ud847\udc3d\udb50\uddce\udbf1\udc5d\ud96f\udcdf\udae2\udc01\ud84e\udf90\ud81e\udcd9\uda67\udff7c\ud8a8\ude2b",
        31, 18078, -2035611008, -8162726340327176888L, 90146L, true, true, (char) 58468, (char) 43074,
        Double.longBitsToDouble(0x3fbc531855d220f8L), Double.longBitsToDouble(0x3fe65041ad9f63b1L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 10, 14, "\uda24\ude7d\ud957\udfae\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udbc2\udf55\ud8b8\uddcc\uda9a\udcee\udbce\udee1\ud8ff\udec0\ud93f\udde7\udb0c\udefe\udbcf\udc57\ud8d0\ude99\ud95a\udfc8\ud90a\udea6\ud986\udff6\udb46\udeba\uda8c\udfff\ud83b\udeb6\ud8b5\udd76\ud8d0\udedf", "\ua6a9\u0629\u56c0\ub8cd\u2714\u2082\u5636\u7dcb\u39df", "\ud81e\udcd9\uda70\udf02\ud932\udc07\udade\ude26\ud8d7\udd6f\ud96a\udee9\ud9f4\udf73\udbef\udcf6\udb22\udc77",
        -5, 52622, 1208674733, -8267874049954945021L, -76033L, false, false, (char) 13451, (char) 21010,
        Double.longBitsToDouble(0x3fe51475039937e8L), Double.longBitsToDouble(0x3fd6232bee1e5f46L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\012",
        Z.run(T, 1, 3, 2, 13, "\uda91\udd1b\ud9af\uddab\udb8b\udfe3\udb1a\udf92\ud9d2\udc46\udb16\udf76", "\u250d\u74eb\ua0da\ucdf5\u1c7e\u7a34\u2bbc\ub899\u4803\u28ad\u2c68", "\ud8d0\udedf",
        24, 81148, -897686224, 9210352354269740530L, 38184L, true, true, (char) 7090, (char) 56050,
        Double.longBitsToDouble(0x3fea7cd3a9fd92caL), Double.longBitsToDouble(0x3fe56ef304c49ceeL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 15, "\ud8f9\udd7b\ud9af\uddc4\ud8ee\ude53\udb3c\uddea\udbf8\uddc5\udbc7\udf2b", "\u3aba\u74eb\u36df\u366c\u0d53\uab50\uba49", "\u40b1\uda8c\udfff",
        20, 94606, -2142540379, -6688062884017348593L, 47797L, true, true, (char) 8220, (char) 58049,
        Double.longBitsToDouble(0x3fa5d9208cfbeed0L), Double.longBitsToDouble(0x3fc2ae5612d87604L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 4, 13, "\ud92f\udd37", "\ua55a\u677d\ud1bc\u0829\ua572\u3aba\u9666\u987d\uce74\uadbc\u2559\u9b50\u72f8\u4803\u4ead\u9f69\u8fd1\u04ee\u58ff\u7dd6\u5d69", "\udb01\udcb6\ud853\udca2\ud814\udec5\ud847\udc3d\udb50\uddce\ud840\udc28\ud807\udf8a\ud93f\udf10\ud915\udeec\udaff\udd96",
        54, 59600, 131459509, -3189331340167985346L, -28749L, true, false, (char) 43074, (char) 35405,
        Double.longBitsToDouble(0x3f89515ab2822540L), Double.longBitsToDouble(0x3fd9f63b159e856eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 13, "\ud92f\udd37\ud9af\uddab\ud8ee\ude53\udb1a\udf92", "\u0829\ua572\u21ea\u7e13\ub2e6\uce74\uadbc\u2559", "\ud986\udff6\uda5f\udf08\uda78\ude75\u0b92\ud8c6\udf41\uda9a\udea2\uda61\uddd4\u6c5d\ud8a4\udfea\uda5c\udc91\udb21\udf8b\ud853\udca2\ud814\udec5\ud847\udc3d\udb50\uddce\ud840\udc28\ud96f\udcdf\ud93f\udf10\ud915\udeec\udaff\udd96\ud96d\udc30c",
        59, 77931, 1044662078, -8742771655291425884L, -68685L, true, false, (char) 43074, (char) 35405,
        Double.longBitsToDouble(0x3f89515ab2822540L), Double.longBitsToDouble(0x3fd9f63b159e856eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=void |this=com.google.javascript.jscomp.Compiler:@?\012",
        Z.run(T, 2, 7, 7, 8, "\udaa6\udcf2\ud910\ude4c\ud8ee\ude53\udb1a\udf92", "\u0829\ucf72\u8b0a\u9a4a\ube70\u9216\u9778\u24fe", "\uda5b\udf01\uda5f\udf08\uda78\ude75\u0b92\ud8c6\udf41\ud8d0\udedf\udb56\udc17\ud9c4\udc16\udb0a\ude08\ud9e8\udee6\udb10\uddb6\ud853\udca2\ud828\udc0f\udb4e\ude8e\ud981\udfc6\uda3a\udfce\udb4c\udeeb\udb80\ude9b\ud915\udeec\ud877\udce3\ud94f\udfd4c",
        59, 77931, 1044662078, -8742771655027709020L, 36787L, true, false, (char) 42604, (char) 62338,
        Double.longBitsToDouble(0x3f89515ab2822540L), Double.longBitsToDouble(0x3fd9f63b159e856eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=void |this=com.google.javascript.jscomp.Compiler:@?\012",
        Z.run(T, 2, 3, 7, 9, "\ud92f\udd37\ud9af\uddab\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udbc2\udf57\ud8b8\uddcc\ud931\uddb6\udbce\udf35\udbe2\ude72\ud8a6\udce4\ud923\udd69\udbb9\udd19\udbd7\udd5e\ud867\udd70\ud90a\udea6\ud986\udff6", "\u8f14\u04ee", "\ud95b\ude4c\udb0a\ude08\ud9e8\udee6\ud8ac\ude4c\ud853\udc5c\ud814\udec5\ud847\udc3d",
        40, 14548, -1832240305, -3575750366581998359L, 25365L, true, false, (char) 6908, (char) 44484,
        Double.longBitsToDouble(0x3fed24355d0d3db8L), Double.longBitsToDouble(0x3fd20361383c69f6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 14, 7, "\ud957\udd94\ud9af\uddab\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udbc2\udf55", "\u3aba\u74eb\ua145\uce74\u1c54\u7a34", "\ud986\udff6\udb46\udeba\uda8c\udfff\ud83b\udeb6\ud8b5\udd76\udb7f\udf37\ud8aa\udcf6\ud95b\udddb\udb0a\ude08\ud943\ude33\ud851\udcbf\uda75\udc11\udaeb\udd97\ud847\udc3d\udb50\uddce\udbf1\udc5d\ud96f\udcdf\udae2\udc01\ud84e\udf90\ud81e\udcd9\uda67\udff7c\ud8a8\ude2b",
        31, 18078, -2035611008, -8162726340327176888L, 90146L, true, true, (char) 58468, (char) 43074,
        Double.longBitsToDouble(0x3fbc531855d220f8L), Double.longBitsToDouble(0x3fe65041ad9f63b1L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 15, 14, "\uda24\ude7d\ud957\udfae\ud8ee\ude53\ud925\udf58\ud840\udc58\udb8e\udffb\udbd3\udf24\uda9f\ude49\udbce\udee1\ud8ff\udec0\ud93f\udde7\udb0c\udefe\udbcf\udc57\ud8d0\ude99\ud95a\udff1\ud90a\udea6\ud986\udff6\udb46\udeba\uda8c\udfff\udbb1\udc71\ud8a3\udd56\ud8d0\udedf", "\ua76b\u0629\u56c0\ub8cd\u2a0a\ud2c8\u5636\u7dcb\u39df", "\ud81e\udcd9\uda70\udf02\ud932\udc07\udade\ude26\ud8d7\udd6f\ud96a\udee9\ud9f4\udf73\udbef\udef5\udb22\udc77",
        -5, 52622, 1208674733, 8051895563994620146L, -82551L, true, false, (char) 8708, (char) 22714,
        Double.longBitsToDouble(0x3fe6261a76f16b21L), Double.longBitsToDouble(0x3fe51475039937e8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 12, 14, "\uda24\ude7d\udb4d\udd4b\ud8ee\ude53\udb1a\udf92\ud81b\udc38\uda84\udef7\udaf1\udea6\udafe\ude50\udab0\ude94\ud8ff\udec0\ud93f\udde7\udb0c\udefe\udbcf\udc57\ud8d0\ude99\ud95a\udfc8\ud90a\udea6\ud986\udff6\udb46\udeba\uda8c\udfff\ud83b\udeb6\ud8b5\udd76\ud8d0\udedf", "\ua6a9\u0629\u56c0\ub8cd\u2714\u2082\u5636\u7dcb\u39df", "\ud81e\udcd9\uda70\udf02\ud932\udc07\udade\ude26\ud8d7\udd6f\ud96a\udee9\ud9f4\udf73\udbef\udcf6\udb22\udc77",
        -5, 52622, 1208674733, -8267874049954945021L, -76033L, false, false, (char) 13451, (char) 21010,
        Double.longBitsToDouble(0x3fe51475039937e8L), Double.longBitsToDouble(0x3fd6232bee1e5f46L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 1, "\uda24\ude7d\udb0a\udd88\udaab\ude83\udb28\udc7b\ud81b\udc38\udbc2\udf55\ud8b8\uddcc\uda9a\udcee\udbce\udee1\ud8ff\udec0\ud93f\udde7\udb0c\udefe\udbcf\udc57\ud8d0\ude99\udb97\udfc6\ud90a\udec6\ud986\udff6\udb46\udeba\uda8c\udfff\ud83b\udeb6\ud8b5\udd76\ud8d0\udedf", "\ua6a9\u0629\u56c0\ub8cd\u2714\u2082\u5636\u7dcb\u39df", "\ud81e\udcd9\uda70\udf02\ud928\udd62\udae3\udc70\ud8d7\udd6f\ud96a\udee9\ud9f4\udf73\udbef\udcf6\udb22\udc77",
        -5, 52622, 1208674733, -8267874049954945021L, -10497L, false, true, (char) 463, (char) 21146,
        Double.longBitsToDouble(0x3fed147503706e07L), Double.longBitsToDouble(0x3fd6232bee1e5f46L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 11, 14, "\uda24\ude7d\ud957\udfae\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udbc2\udf55\ud8b8\uddcc\uda9a\udcee\udbce\udee1\ud8ff\udec0\ud93f\udde7\udb0f\udffe\udbcf\udc57\ud8d0\ude99\ud95a\udfc8\ud90a\udea6\ud986\udff6\udb46\udeba\uda8c\udfff\ud83b\udeb6\ud8b5\udd76\ud8d0\udedf", "\u6d1c\uaa98\u56c0\u5d9b\u2714\uab4b\u560e\u1534", "\udb31\udfdd\uda78\udc22\udaac\udea9\ud944\udf85\udade\ude26\ud8d7\udd6f",
        13, 43018, -1900532828, 3896463908540201555L, -28749L, true, false, (char) 57925, (char) 42759,
        Double.longBitsToDouble(0x3feeba22fa1b1437L), Double.longBitsToDouble(0x3fd9f63b181dad58L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 9, 10, "\uda24\ude7d\ud957\udfae\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udbc2\udf55\ud8b8\uddcc\uda9a\udcee\udbce\udee1\ud9f3\udfd8\ud950\udec4\udb0c\udefe\udbcf\udc57\ud8d0\ude99\udb96\udfc6\ud90a\ude23\udb83\uded5\udb56\udcf7\uda8c\udfff\ud83b\udeb6\ud8b5\udd76\ud8d0\udedf", "\ua6a9\u0629\u56c0\ub8cd\u27bc\u2082\u5636\u7dcb\u39df", "\ud81e\udcd9\uda8d\udf93\ud932\udc07\udade\ude26\ud8d7\udd6f\ud96a\udee9\ud9f4\udf73\udbef\udcf6\udb22\udc77",
        51, 60500, 1208674733, -8267874049954945021L, -76033L, false, false, (char) 15648, (char) 21010,
        Double.longBitsToDouble(0x3fe51475039937e8L), Double.longBitsToDouble(0x3fd6232bee1e5f46L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 14, "\uda24\ude7d\ud957\udfae\ud8ee\ude53\udb1a\udf92\ud81b\udc38\udbc2\udf55\ud8b8\uddcc\uda9a\udcee\u8c4c\ud8ff\ude90\ud93f\udde7\udb0c\udefe\udbcf\udc57\ud8d0\ude99\ud95a\udfc8\ud90a\udea6\ud986\udff6\udb46\udeba\uda8c\udfff\ud83b\udeb6\ud8b5\udd76\ud8d0\udedf", "\ua6a9\u0629\u56c0\ub8cd\u2714\u2082\u5636\u7dcb\u39df", "\ud81e\udcd9\uda70\udf02\ud932\udc07\udade\ude26\ud8d7\udd6f\ud8e4\udee6\ud9f4\udf73\udbef\udcf6\udb1f\udd45",
        -5, 52622, 1208674733, -8267874049954945021L, -76033L, false, false, (char) 13451, (char) 21010,
        Double.longBitsToDouble(0x3fe51475039937e8L), Double.longBitsToDouble(0x3fd6232bee1e5f46L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 14, 9, "\ud92f\udd37\ud841\uddad\ud8ee\ude53\udb25\ude99\ud81b\udc38\ud803\udd77\uda60\udd12\ud925\ude3b\udbce\udf35", "\uce74\uc492\ucf9a", "\ud986\udff6\uda5f\udf08\uda78\ude75\udbe8\udc08\ud823\udc70\udbe3\udf2e\uda36\udf1c\ud95b\ude4c\udb0a\ude08\ud8b5\udcf8\uda7f\udc68\udb34\ude28\uda8c\udfd9\ud846\udfa1\ud8e9\udd7d\uda46\ude86\uda04\udfa8\ud93f\ude43\ud915\udeec\udaff\udd96\ud975\udf56\udbff\udfa1",
        59, 66995, -565950580, -457762801691898541L, 6037L, false, false, (char) 59801, (char) 54416,
        Double.longBitsToDouble(0x3fcbecbb3414fd64L), Double.longBitsToDouble(0x3fb6732dbd52a948L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 15, 14, "\uda24\ude7d\ud957\udfae\ud8ee\ude53\ud925\udf58\ud840\udc58\udb8e\udffb\udbd3\udf24\uda9f\ude49\udbce\udee1\ud8ff\udec0\ud93f\udde7\udb0c\udefe\udbcf\udc57\ud8d0\ude99\ud95a\udff1\ud90a\udea6\ud986\udff6\udb46\udeba\uda8c\udfff\udbb1\udc71\ud8a3\udd56\ud8d0\udedf", "\ua76b\u0629\u596b\ub324\u2a0a\ud2c8\u5636\u7dcb\u39df", "\ud81e\udcd9\uda70\udf02\ud932\udc07\udade\ude26\ud934\uddb7\ud860\udf0a\ud9f4\udf73",
        5, 33200, -861193645, -8532886163696195155L, -9646L, true, true, (char) 20024, (char) 46161,
        Double.longBitsToDouble(0x3fd76c48d41dad58L), Double.longBitsToDouble(0x3fe317cd86f16b21L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 15, 13, "\ud957\udd94\ud9af\uddab\ud8ee\ude53\udb1a\udf92\ud81b\udc38\ud84a\udf59", "\u3aba\u74eb\ua145\uce74\u1c7e\u7a34", "\ud986\udff6\udb46\udeba",
        43, 17463, 620780360, -2167237863903034818L, 5187L, true, false, (char) 48579, (char) 39847,
        Double.longBitsToDouble(0x3fac4579efee7690L), Double.longBitsToDouble(0x3fdff5907907f99cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.Compiler|parseInputs||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|acceptConstKeyword||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|acceptEcmaScript5||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|addChangeHandler|com.google.javascript.jscomp.CodeChangeHandler|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|addIncrementalSourceAst|com.google.javascript.jscomp.JsAst|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|addNewScript|com.google.javascript.jscomp.JsAst|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|addNewSourceAst|com.google.javascript.jscomp.JsAst|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|addToDebugLog|java.lang.String|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|areNodesEqualForInlining|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|buildKnownSymbolTable||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|check||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|checkFirstModule|java.util.List|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile|com.google.javascript.jscomp.JSSourceFile,[Lcom.google.javascript.jscomp.JSModule;,com.google.javascript.jscomp.CompilerOptions|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile|[Lcom.google.javascript.jscomp.JSSourceFile;,[Lcom.google.javascript.jscomp.JSModule;,com.google.javascript.jscomp.CompilerOptions|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile|[Lcom.google.javascript.jscomp.JSSourceFile;,[Lcom.google.javascript.jscomp.JSSourceFile;,com.google.javascript.jscomp.CompilerOptions|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|parseInputs||new:com.google.javascript.jscomp.Compiler:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
