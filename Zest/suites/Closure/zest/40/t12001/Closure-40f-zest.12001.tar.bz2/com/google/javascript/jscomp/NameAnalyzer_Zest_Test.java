package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class NameAnalyzer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 1, 5, "\ud990\udf6a\uda8e\udc0e\uda73\udce3", "\u0b9d\u87dd\u0e90\ud182\u210c\u59ef\u8294\u7951\u54c3\u3751", "\udb10\udc9c\u7462\u0e88\uda3e\uddcd",
        10, 96881, 1847877316, 3386850853487445467L, -47301L, true, true, (char) 19996, (char) 28762,
        Double.longBitsToDouble(0x3fcdc99b49faf1d0L), Double.longBitsToDouble(0x3fbd2255aecdf948L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 7, 5, "\ud990\udf6a\udb36\udd54\uda45\udf8b", "\u0b9d\u87dd\u0e90\ud182\u210c\u59ef\u8294\u7951\u54c3\u3751", "\udb10\udc9c\u7462\u0e88\uda3e\uddcd",
        10, 96881, 1847877316, 3386850853487445467L, -47301L, true, true, (char) 19996, (char) 28762,
        Double.longBitsToDouble(0x3fcdc99b49faf1d0L), Double.longBitsToDouble(0x3fbd2255aecdf948L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 1, 7, "\udbe4\ude7e", "\ud579\u7b21\u68f2\ua2e9\u0f1c\u3cee\u5be3\u7d20\u0c58\u45c9\u54d6\u6bdf\u13b0\u0dd3\u7942\u1809\ub9ec\uc095\u2d41\u0510\ub5a4\u8eb5\ub10f\u999e\u7624\ub792\ub7b5\u0689\u6530\uadbf\u78d1\u97bf\ucd16\uae3f\u5791\u3b20\u2652\u1cfe", "\ud8a6\udff8\uda73\udda6\ud883\udefb\udba1\uddcf\uda43\udfa7\ud966\udd65\u947a\uda7a\udd2e\ud9aa\udfed\udbc9\uddbe\ud934\udfff\udaad\ude2e\ud847\udd50\udb22\udc5b\ud805\ude4b\ud9aa\ude39\ud837\uddd9\uda82\udc9c\udb09\ude84\ud87d\udd25\ud8f5\udd6a\ud88a\udebb\ued10\ud81b\uded2\ud875\udc76\ud8f2\udc24\ubfdc\udac5\udd70\ud858\udd77\ud962\udd66\u4313\ud9e1\udfac\ud94b\udc75\uda69\udcc1\udbcf\ude01",
        -3, 77219, -253201989, -1931259955033879038L, 7139L, false, false, (char) 50187, (char) 35568,
        Double.longBitsToDouble(0x3fc5e333a4254ca4L), Double.longBitsToDouble(0x3fd6e5db032f8356L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 12, 1, "\ud990\udf6a\uda8e\udc0e\uda73\udce3\ud889\udffb\ud922\udc78\udbea\udc83\udabc\ude5c\ud92d\udcaa\udb8f\udf8d\ud8e2\udf2c\ud96d\udf75\ud931\uddc7\ud989\uddf5\ud90a\udde4\udbea\udd56\udac4\udd70", "\u1a77\u6b93", "\ud88f\uddfe\ud97e\udfe2\ud82d\udcf9\ud85c\udc87\udb0e\udcbc\ud8c7\udce2\udb30\udd51\ud8c8\udf86\ud9c9\udfcd",
        3, 17328, 1997347838, -5398286245822773300L, -60614L, true, false, (char) 38539, (char) 37935,
        Double.longBitsToDouble(0x3fe1a37509d13b26L), Double.longBitsToDouble(0x3fdf89560330771cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud990\udf6a\ud8fc\ude04\uda73\udce3<li>null</li>\012 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 1, 0, 1, 5, "\ud990\udf6a\ud8fc\ude04\uda73\udce3", "\u0b9d\u87dd\u0e90\ud182\u210c\u59ef\uce87\u1d27\u3cf5\u3331\ua8f5k\u2601", "\uda3e\uddcd\ud9e8\udf8c\ud904\udf7a\uda95\udd41\ud82d\uddad",
        38, 57794, -1497681248, -301818618913205684L, -45525L, false, false, (char) 62922, (char) 54530,
        Double.longBitsToDouble(0x3fe928226b2370d7L), Double.longBitsToDouble(0x3fdeb9d1baee2516L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 3, 1, 5, "\ud990\udf6a\uda8e\udc0e\uda73\udce3", "\u0f0c\u8526", "\uda47\udd1b\uda68\udf83\udb13\udc43\udb3c\udf9a\ud937\ude73\udbea\udd56\udac4\udd70\uda68\udfe7\udb10\udc9c\u7462",
        39, 41401, 1089273785, -2859568260093550908L, -32965L, false, false, (char) 46620, (char) 24652,
        Double.longBitsToDouble(0x3fe267de7b468d14L), Double.longBitsToDouble(0x3fcdc99b49faf1d0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud990\udf6a\uda8e\udc0e\uda73\udce3<li>\u4f19\000\u7aaa\ud182\u98ce\000\000\000\000\u58d8</li>\012 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 1, 0, 4, 5, "\ud990\udf6a\uda8e\udc0e\uda73\udce3", "\u4f19\000\u7aaa\ud182\u98ce\000\000\000\000\u58d8", "\udb10\udc9c\u7462\u0e88\udb5a\udf4c",
        10, 96881, 1847877316, 3386850853487445467L, -47301L, true, true, (char) 21068, (char) 28762,
        Double.longBitsToDouble(0x3f33368000000000L), Double.longBitsToDouble(0x3fbd2255aecdf948L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:<a name=\"\udb77\udc8a\uda8e\udc0e\udbf9\udd28\ud800\udfd9\uf9c7\udbea\udcf1\u9fee\ud896\ude3a\udb8f\udf8d\udbb1\uded3\">\udb77\udc8a\uda8e\udc0e\udbf9\udd28\ud800\udfd9\uf9c7\udbea\udcf1\u9fee\ud896\ude3a\udb8f\udf8d\udbb1\uded3</a> |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 1, 14, 7, 1, "\udb77\udc8a\uda8e\udc0e\udbf9\udd28\ud800\udfd9\uf9c7\udbea\udcf1\u9fee\ud896\ude3a\udb8f\udf8d\udbb1\uded3", "\u13af\u01ba\u3751\u9c5d\u6c0b\u0fdc\u13c8\u6b93\ua173\u44ac\u47c8\u714e\u029d\u0a1e\u2c4a\u98dc\u8506\u3745\ud342\u54e0\ub3fa\ud0ac\u5ede\u1aa2\u6256\u1acb\u4c48\ub3be\u02c1\u1c97\u6292\u89a7\u9a03\u6e12\u18a7\ubcb3\u727d\u3258\uaecc\u8db7\u9dcc\u232b", "\ud9f3\udd51\ud91e\udeeb\uda7e\udc1d",
        31, 25245, -1309889645, -5775970361883464361L, 68582L, false, false, (char) 4374, (char) 64629,
        Double.longBitsToDouble(0x3febf324ddd1177eL), Double.longBitsToDouble(0x3fefcadbc413ef57L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 1, 1, 2, 3, "\ud990\udf6a\u9a5b\ud9f2\udde1\ud801\ude58\ud835\udd6e\ud9b3\udd43\ud845\udfbe\udb85\ude50\ud924\udcae\uda0b\udeb6\ud80d\udc0f\udae1\udcf2\ud989\ude56", "\ud47d\u8368\u7a07\u1a77\u89e2\u2e53\uad0f\u2ef1\u714e\u029d\u40dc\u3bc4\u9857\u890c\u8217\u2f10\u53f9\ubdda\u379b", "\udb93\udc90\ud98e\ude6a",
        56, 96637, -351983918, 1894049343187439738L, -54313L, false, true, (char) 52725, (char) 41513,
        Double.longBitsToDouble(0x3fc5185d581cd834L), Double.longBitsToDouble(0x3fe50a4daefd07caL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 1, 9, 3, 5, "\ud990\udf6a\uda8e\udc0e\uda73\udce3\ud889\udffb\ud922\udc78\udbea\udc83\u9fee\ud920\ude3f\udb8f\udf8d\udbb1\uded3\udb20\udde8\udb77\udce9\ud989\uddf5\ud853\udc88\ud9a5\udc29\udac4\udd67\uda68\udfe7\udb10\udc9c", "\ua173\u44ac\u2e4a\u714e\u03b6", "\ud8c7\udce2\udb30\udd51\ud8c8\udf86\ud9c9\udfcd\udbfe\udcf2",
        52, 41124, 448561625, 1889606842667122830L, -54625L, false, false, (char) 10477, (char) 31932,
        Double.longBitsToDouble(0x3feaad7a4bb4fed4L), Double.longBitsToDouble(0x3fe07be70edcfb1dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 12, "\ud990\udf6a\uda8e\udc0e\uda73\udce3", "\u0b9d\u6385\u35b1\ucc89\u210c\u59ef\u8294\u7951\u54c3\u3751", "\udb10\udc9c\u7462",
        39, 15341, 1089273785, 6127538519161462356L, -32965L, false, false, (char) 46620, (char) 24652,
        Double.longBitsToDouble(0x3fe267de7b468d14L), Double.longBitsToDouble(0x3fcdc99b59faf1d0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 2, 0, 5, "\ud990\udf6a\uda8e\udc0e\uda73\udce3", "\u0b9d\u87dd\u0e90\ud182\u210c\u59ef\u8294\u7951\u54c3\u3751", "\udb10\udc9c\u7462\u0e88\uda3e\uddcd",
        10, 96881, 1847877316, 3386850853487445467L, -47301L, true, true, (char) 19996, (char) 28762,
        Double.longBitsToDouble(0x3fcdc99b49faf1d0L), Double.longBitsToDouble(0x3fbd2255aecdf948L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.NameAnalyzer$JsName:\ud990\udf6a\uda8e\udc0e\uda73\udce3 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 1, 10, 12, 0, "\ud990\udf6a\uda8e\udc0e\uda73\udce3", "\u0c69\u87dd\u0e90\ud182\u210c\u59ef\u8294\u7951\u54c3\u3751", "\udb10\udc9c\udb67\udf9d\ud8c8\udce7\ud9a0\udcd8",
        39, 96881, 1847877316, 3386850853487445467L, -47301L, true, true, (char) 19996, (char) 28762,
        Double.longBitsToDouble(0x3fcdc99b49faf1d0L), Double.longBitsToDouble(0x3fbd2255aecdf948L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 5, "\ud990\udeaa\ud880\udc66\ubdcc", "\u9c80\u43c7\u0e90\uc3a0\u0aa3\u7b6d\u3906\u606f\u0453\u38d7\u9c5d\u6ee4", "\ud8da\udf31\ud888\uddd2\ud9e8\udf8c\uda91\udd2f",
        20, 32624, -435234240, -7689977376829989024L, 37966L, false, false, (char) 42300, (char) 21537,
        Double.longBitsToDouble(0x3fedccb5fd5d139eL), Double.longBitsToDouble(0x3fe4fa08493dc547L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 1, 1, 1, 5, "\ud9e5\udcd4\uda8e\udc0e\uda73\udce3", "\u0b9d\u87dd\u0e90\ud182\u210c\u59ef\u8294\u7951\u54c3\u3751", "\udbb8\udf5b\u7462\u0e88\uda3e\uddcd",
        5, -1000, 0, 3386849857055032795L, -100000L, false, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fbd00002ecdf948L), Double.longBitsToDouble(0x3fe5b78eedc658d7L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 1, 10, 10, 0, "\udbdd\udc27\udacd\udc0e\uda73\udce3\udb3b\udec8\ud86c\udc59\udb17\udcfa\u8107\udb7c\udcf7\ud8ee\uddd1\ud928\udece\ud9cb\udcce", "\u54c3\u3751\u923a\uc4ee\u74cf\ud7a5\u6b93\ua173\u9c4f\u6843\u714e\u5380\u5b83\ub486", "\udba5\udc2c\ud9a0\udf2d\udbfe\udcf2\udb3c\udf7f\udb36\udca1\uda21\udc06\ud894\udea5\uda25\udd20\ud808\udd19\ud91a\udf5c\ud9ab\udea9",
        46, 65332, 1341262165, -556848700339051897L, -33420L, true, false, (char) 23707, (char) 22233,
        Double.longBitsToDouble(0x3f8047515d183b00L), Double.longBitsToDouble(0x3fe937b743d79098L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 12, 1, "\ud990\udf6a\uda8e\udc0e\uda73\udce3\ud889\udffb\ud922\udc78\udbea\udc83\udabc\ude5c\ud92d\udcaa\udb8f\udf8d\ud8e2\udf2c\ud96d\udf75\ud931\uddc7\ud989\uddf5\ud90a\udde4\udbea\udd56\udac4\udd70", "\u1a77\u6b93", "\ud88f\uddfe\ud97e\udfe2\ud82d\udcf9\ud85c\udc87\udb0e\udcbc\ud8c7\udce2\udb30\udd51\ud8c8\udf86\ud9c9\udfcd",
        3, 17328, 1997347838, -5398286245822773300L, -60614L, true, false, (char) 38539, (char) 37935,
        Double.longBitsToDouble(0x3fe1a37509d13b26L), Double.longBitsToDouble(0x3fdf89560330771cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 2</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 1, 9, 1, "\ud990\udf6a\uda8e\udc0e\uda73\udce3\ud889\udffb\ud947\udf78\udbea\udc83\udabf\udcbf\ud8f7\udf30\uda91\udf8f\ud8e2\udf2c\ud96d\udf75\ud831\udf26\uda8b\udd61\ud90a\ude61\udab7\udef7\udabf\uddb2", "\ua6e9\u7a4e\u499c\u9902\u724b\ub56d\u0266\u139a\u5d84\u48e6\u1c9a\u8217\uae5c\u54e0\u033c\u9117\u5e78\ube24\u790a\u6833\u2310\u6178\u8075\u6741\u2ced\uad96\u5886\u288a\ub7db\u59fe", "\ud93b\udf59\u5628\ud96f\udc90\ud944\udf7f\ud9ce\udfb8\ud92d\ude66\udbfe\ude54\uda66\udeb5\udb0f\udda2\ud88f\udccf\udba5\udfc1",
        6, 71790, -63673200, -1712581400020935834L, -77095L, true, true, (char) 58807, (char) 17110,
        Double.longBitsToDouble(0x3fc692bd1f0a7f00L), Double.longBitsToDouble(0x3fec6970bf0d7fd1L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud990\udf6a\ud8fc\ude04\uf869<li>\u6113\uc919\u6ab8\ua770\u97a1\u5794\uc277\u0162\uc434\u32f1\u1abd\u3635\ucad1</li>\012 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 0, 1, 5, "\ud990\udf6a\ud8fc\ude04\uf869", "\u6113\uc919\u6ab8\ua770\u97a1\u5794\uc277\u0162\uc434\u32f1\u1abd\u3635\ucad1", "\uda3e\uddcd\ud9e8\udf8c\udbe0\udd07\ud834\udf1d\udbeb\udce8\ud816\udd8c\udafe\udc1c\ud8c7\udd31\udb30\udd51\ud947\udda5\udbdf\uddc7\udbfe\udcbb\udb3c\udf8e\udb36\udca1",
        1, 36196, -1973811334, 1336194611382655536L, -52269L, true, true, (char) 39288, (char) 18217,
        Double.longBitsToDouble(0x3fc46894ead8b328L), Double.longBitsToDouble(0x3fef702caa38b7e8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 1, 5, "\ud990\udf6a\ud8fc\ude04\uda73\udce3", "\u8a6d\u87dd\u0e90\ud182\u630b\u59ef\u228a\u5ba0\u3cf5\u3331\u2439k\uc29b\ubb38", "\ud9e8\udf8c\ud904\udf16\uda95\udd41\ud82d\uddad\ud9e3\udfec\uda31\udd38\ud8ac\udd28\ud95d\udf27\udbd0\udf8a\udb6f\ude6e\udbfe\udccf\udb3c\udf7f",
        10, 45729, 1893184293, -7125825857330143765L, -79497L, false, true, (char) 35376, (char) 17269,
        Double.longBitsToDouble(0x3fe8c21de0b12b14L), Double.longBitsToDouble(0x3f7c200a7e24df00L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 3, 9, 5, "\udb8b\udc27\ud99c\udfbf\udaa4\udd2d", "\u0f0c\u8526", "\uda8c\ude6e\uda68\udf83\ud91c\uddac\udb48\udf35\ud937\ude73\ud947\ude1c\udaa9\udcaa\ud8da\udf3d\udab5\udc8d\ud913\ude44",
        36, 41401, 1089273785, 6523712349864272514L, 95212L, false, false, (char) 46524, (char) 36628,
        Double.longBitsToDouble(0x3fe267de78468d14L), Double.longBitsToDouble(0x3fcdd6a209faf1d0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=void |a0=java.lang.StringBuilder:\ud990\udf6a\uda8e\udc0e\uda73\udce3<li>\u0f0c\u8526</li>\012 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 3, 0, 10, "\ud990\udf6a\uda8e\udc0e\uda73\udce3", "\u0f0c\u8526", "\uda47\udd1b\uda68\udf83\udb13\udc43\udb3c\udf9a\ud937\ude73\udbea\udd56\udac2\udf70\uda68\udfe7\udb10\udc9c\u7462",
        23, 41401, 1089273673, -2859568260093550908L, -32965L, false, false, (char) 46620, (char) 24652,
        Double.longBitsToDouble(0x3fe267de7b468d14L), Double.longBitsToDouble(0x3fcdc99b49faf1d0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 1, 3, 2, "\ud990\udf6a", "\uab93\u1b9d\ubb23\u8526\u6148\u12e0\ubf99\u464f\u4d99\u91fb\u7282\u3751\ua754\u7169\ub918\u1a77\u6b93\u1bd2\u44ac", "\ud82d\uddad",
        38, 48658, 1251990053, -301933973748821428L, -45490L, false, false, (char) 98, (char) 56101,
        Double.longBitsToDouble(0x3fea49197b99dc61L), Double.longBitsToDouble(0x3fd4155d1b3944b0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud9ff\udeec\ud9a3\udfac\ud8a2\uddfe<li>\u0f0c\u8526\u6148\u12e0\ubf99</li>\012 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 13, 5, "\ud9ff\udeec\ud9a3\udfac\ud8a2\uddfe", "\u0f0c\u8526\u6148\u12e0\ubf99", "\ud86b\udce3\udaa8\udf9c\udbf8\udc00\udac4\udd70\uda68\udfe7\ud87a\udcdd\udaab\ude53\uda5e\udeb3\ud9c5\udfd8\ud9e8\udf8a\ud904\udf7a\uda95\udd41\u74c7\udb29\udcb2",
        2, 51995, -70272623, -8280903327167093946L, -94494L, true, false, (char) 402, (char) 9691,
        Double.longBitsToDouble(0x3fe2c61a957da5d3L), Double.longBitsToDouble(0x3fd01bf2d40c72ceL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 3, 3, 5, "\ud995\udc46\ud908\udc0b\uda73\udce3", "\u0f0c\u8526", "\uda47\udd1b\uda68\udf83\udb13\udc43\ud924\udffb\uda94\udf43\udbea\udd26\udac4\udd70\uda68\udfe7\udb10\udc9c\u7462",
        39, 41401, 1089273785, -2859568260093550908L, -32965L, false, false, (char) 46620, (char) 24652,
        Double.longBitsToDouble(0x3fe267de7d428d14L), Double.longBitsToDouble(0x3fedcdae67f6e313L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 14, "\udb1d\ude6f\udae4\ude97\uda3e\udf78\ud9bd\uddf6\ud940\udcf3\uda01\udc4f\ud831\udd39\uda0c\udc5f\ud8c7\udf54\udbd1\udc14\uda68\udf83\udb13\udc43\udb3c\udf9a", "\u9beb\u6c0b\ub918\uaf80\u5514\u463f\u0a18\ua9c9\u714e\u029d\u139a\u4518\u5822\u151a\u166a\u9581\ua448\ub388\uc88f", "\udbf7\udceb\udabb\udd1d\udb79\udf92\uda0c\ude6c\ud867\uddb0\uda42\udf18\uda2d\uddc4",
        6, 33815, -773345244, -8287284115391800298L, 28407L, false, false, (char) 19823, (char) 11913,
        Double.longBitsToDouble(0x3fe31559e928aa07L), Double.longBitsToDouble(0x3fed83b47e32d04fL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 3, 2, 5, "\ud990\udf6a\uda8e\udc0e\uda73\udce3", "\u0f0c\u8526", "\uda47\udd1b\uda68\udf83\udb13\udc43\udb3c\udf9a\ud937\ude73\udbea\udd56\udac4\udd70\ud902\udc13\udb10\udc9c\u7462",
        39, 41401, 1089273785, -2859568260093550908L, -32965L, false, false, (char) 46620, (char) 24652,
        Double.longBitsToDouble(0x3fe267de7b468d14L), Double.longBitsToDouble(0x3fcdc99b49faf1d0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud990\udf6a<li>null</li>\012 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=void |a0=java.lang.StringBuilder:\ud990\udf6a<li>null</li>\012 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 0, 0, 2, "\ud990\udf6a", "\uabfd\u1b9d\u0f0c\u1b14\u6148\u9080\000\ub8a5\u4d99\u02a2\u3153\u3751\u9c5d\u6c0b\ub918\u1a77\u6b93\ua173\uc0d1", "\u00e8",
        38, -974, 0, -360287972117687732L, -99762L, false, false, (char) 25330, (char) 20919,
        Double.longBitsToDouble(0x3fe354487cf0034fL), Double.longBitsToDouble(0x3fdba8ea36cf9c4eL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 1, 1, 5, "\ud990\udee4\uda1c\udc15\uda73\udce3", "\u4341\u94f7", "\uda47\udd1b\udbaa\udfd9\udaa5\uddbf\ud865\ude82\ud869\udd80\udbea\udcef\udaa0\udc1d\uda4a\udca4\udb10\udcf5\u7462",
        7, 42489, 919382042, -2859568783768750908L, -40190L, true, true, (char) 22477, (char) 24652,
        Double.longBitsToDouble(0x3fe267de7b468d14L), Double.longBitsToDouble(0x3fcdc99b44a2f1d0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 4, 4, 5, "\000\uda8e\udc0e\uda73\udce3", "\u0f0c\u8526", "\uda47\udd1bG\000\ud90f\udf87\ud801\udeb8\udbea\udcde\udac4\udd70\u00c2\udb57\udd40\udb8b\udc85",
        39, 41401, 1089273785, -2859568260093550908L, -32965L, false, false, (char) 0, (char) 47359,
        Double.longBitsToDouble(0x3f4f79ed18000000L), Double.longBitsToDouble(0x3fcdc99b41faf1d0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:1 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 4, 3, 5, "\ud990\udf6a\uda8e\udc0e\uda73\udce3\ud889\udffb\udbcc\uddcd\u4dd3\u9fee\ud920\ude3f\ud913\udf8f\ud93c\ude59\udb20\udde8\uda0e\udfd6\ud990\udd3e\ud853\udc88\ud9a5\udc29\udac4\udd67\uda68\udfe7\udb10\udc9c", "\ua173\u44ac\u32b8\u6266\u5274", "\udb62\udfd7\udb30\udd40\ud8c8\udf86\ud9c9\udfcd\udbfe\udcf2\udb33\udcbe\udb1e\udca1\ud948\udf6c\uda67\udcf4\ud953\udf0e\udba1\udd5b\uda6b\udde4\uda07\udffa\ud8d1\udcfe\uda7d\udcce\ud833\udcd2\uda92\ude5f\udb11\udd1f\u5b10\ud8fa\uddc5",
        46, 21737, -1959354367, 4217470733505272950L, -83931L, true, true, (char) 12119, (char) 21667,
        Double.longBitsToDouble(0x3fdef095d81da190L), Double.longBitsToDouble(0x3fb89d37b2328658L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 1, 3, 14, "\u00d0\000\000", "\000\000\000\000\000\u5624\u8279\u0251\u54c3\u3751", "\000\udb8b\udc85",
        39, 15341, 1089273785, 6127538519161462356L, -32965L, false, false, (char) 0, (char) 24465,
        Double.longBitsToDouble(0x3fe267de78000014L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 9, 9, 2, "\uda55\udf01\udaba\udfe4\uda73\udce3", "\u0b9d\u6385\u398c\ucc89\u210c\u348d\uabe9\u0422\u54c3\u3751", "\ud81c\udd73\u8a8c",
        7, 43176, 1075239844, 6127538519161458516L, -32965L, false, false, (char) 46620, (char) 24652,
        Double.longBitsToDouble(0x3fe267de7b468d14L), Double.longBitsToDouble(0x3fcdc99b59faf1d0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:2 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 1, 3, 0, "\ud990\udf6a\uda8e\udc0e", "\uc661", "\udb3f\udc57\ud8b2\udeee\udbb1\uded3",
        -2, 98207, 1837594497, -328118280760347016L, -136L, true, true, (char) 18710, (char) 1905,
        Double.longBitsToDouble(0x3fa2fb6a7b9381e0L), Double.longBitsToDouble(0x3fee8a0766545509L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 4, 3, 12, "\ud990\udf6a\udb7e\uddc5\udb5e\udf07\udb9e\udc97\ud93c\ude42\udbea\udc83", "\ua25a", "\uda75\udce8\ud9ac\ude68\udb06\udc8f\ud8e9\udd9c\ud942\udd53\uda69\udc0d\u4cff\u7447",
        39, 15341, 1089273785, 6127538519161462356L, -32965L, false, true, (char) 21197, (char) 24652,
        Double.longBitsToDouble(0x3fe267de7cd09014L), Double.longBitsToDouble(0x3fc6ea45d9faf1d0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 1</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 4, 9, 4, "\ud990\udf6a\uda8e\udc0e\uda73\udce3", "\u0b9d\u6385\u35b1\ucc89\u210c\u59ef\u8294\u7951\u54c3\u3751", "\udb10\udc9c\u7462",
        39, 15341, 1089273785, 6127538519161462356L, -32965L, false, false, (char) 46620, (char) 24652,
        Double.longBitsToDouble(0x3fe267de7b468d14L), Double.longBitsToDouble(0x3fcdc99b59fa7e70L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.NameAnalyzer$JsName:\ud90a\udda6\udb7c\udc2a\ud8d4\udfb3\ud832\udfeb\udb64\uded7 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=com.google.javascript.jscomp.NameAnalyzer$JsName:\ud90a\udda6\udb7c\udc2a\ud8d4\udfb3\ud832\udfeb\udb64\uded7 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 10, 10, 2, "\ud90a\udda6\udb7c\udc2a\ud8d4\udfb3\ud832\udfeb\udb64\uded7", "\u0e8a\ud182\u210c\u05ad\uc343\u775f\u74fa\u83f8\u9c5d\u6c0b\ub918\u4ccb\u93f2\u4848\u3288\ubea2\uc4c3\u029d\u139a\u633f\u98fe\u1c9a\u8217\uae5c", "\udb36\udca1\udb09\ude2d",
        10, 59614, -164358590, 1358215479512782993L, 21211L, false, true, (char) 54080, (char) 2456,
        Double.longBitsToDouble(0x3fdd41c500a76c7cL), Double.longBitsToDouble(0x3fdc82c01847ffe6L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 1, 3, 1, "\ud990\udf6a\uda8e\udc0e\uda73\udce3\ud889\udffb\ud947\udf78\udbea\udc83\udabf\udcbf\ud8f7\udf30\uda91\udf8f\ud8e2\udf2c\ud96d\udf75\ud831\udf26\uda8b\udd61\ud90a\ude61\udab7\udef7\udabf\uddb2", "\ua6e9\u7a4e\u499c\u9902\u724b\ub56d\u0266\u139a\u5d84\u48e6\u1c9a\u8217\uae5c\u54e0\u033c\u9117\u5e78\ube24\u790a\u6833\u2310\u6178\u8075\u6741\u2ced\uad96\u5886\u288a\u053a\000", "\ud93b\udf59\u5628\ud96f\udc90\ud944\udf7f\ud9ce\udfb8\ud92d\ude66\udbfe\ude54\uda66\udeb5\udb0f\udda2\ud88f\udccf\udba5\udfc1",
        6, 71790, -63673200, -1712581400020935834L, -77095L, true, true, (char) 58807, (char) 17110,
        Double.longBitsToDouble(0x3fc692bd1f0a7f00L), Double.longBitsToDouble(0x3fec6970bf0d7fd1L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 4, 3, 8, "\ud990\udf6a", "\uab93\u1b9d\ubb23\u8526\u03f4\u4e14\ubf99\u464f\u4d99\u91fb\u7282\u9cfe\ua754\u7169\ub918\u1a77\u6b93\u1bd2\u73a4\u785c\uac7f\u33c1\ud69c\ud172\ucbdc\u3280\ucd2a\ub620", "\udb53\udd3d\udb37\udc4d\uda77\udd2f\udaba\udca7\ud804\udfbc\uda77\udf2c",
        49, 36693, 1086419223, -6844190032026204494L, -38996L, true, true, (char) 12235, (char) 58103,
        Double.longBitsToDouble(0x3fd2e784e379ab74L), Double.longBitsToDouble(0x3faedecc27cbeca0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 4, 3, 2, "\ud990\udf6a", "\u6fc6\u130f\u7079\u5b10\u4d19\u971f\u9cf6\u464f\u4d99\u9269\u7282\u27e9\ua754\u7169\ub918\ubbd0\ucba4\u1bd2\u9bb2", "\ud8e7\udcaf",
        38, 18738, 1251990053, -301826217627659700L, -45490L, false, false, (char) 98, (char) 56101,
        Double.longBitsToDouble(0x3fea49197e99dc61L), Double.longBitsToDouble(0x3fe1fb40559ca258L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 4, 3, 10, "\uda22\uded3\uda8e\udc0e", "\u1b9d\ubb23\u8526\u6148\u12e0", "\udb13\udc43\uda39\udf39\udabd\udf39\ud873\udebb\ud835\udf28\ud8d8\udd00\udb10\udc9c\u7462\u0e88\udaed\udd25\ud95d\udd2d",
        -3, 81316, 788562664, 3267649440709075994L, -27110L, true, false, (char) 33522, (char) 46119,
        Double.longBitsToDouble(0x3fe1d808df67232fL), Double.longBitsToDouble(0x3feccee30d4155d1L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=null |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 10, 10, 3, "\ud990\udf6a\ud93f\udd87\uda52\udd4d", "\u0b9d\u6385\u35b1\ucc89\u210c\u59ef\u980f\u4f74\u54c3\u3751", "\udb10\udc9c\u7462",
        39, 8294, 1089273785, 6127538519161462320L, -32965L, false, false, (char) 46620, (char) 24652,
        Double.longBitsToDouble(0x3fe267de7b468d14L), Double.longBitsToDouble(0x3fde04cdacfcecceL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 6, 7, "\ud990\udf6a\uda8e\udc0e\ud766\ud889\udf4b\ud922\udc78\udbea\udc83\u9fee\uc3c9\udb8e\udf55\udbb1\uded3\ud9b5\udc53\udb66\udc42\ud91e\udce0\ud854\udcaf\udbea\udda5\udac4\udd70", "\u1a77\u6b93", "\ud904\udf7a\uda95\udd41",
        44, 34709, -2080954342, -6432492507261716079L, -87393L, true, true, (char) 30004, (char) 63039,
        Double.longBitsToDouble(0x3fdd9bf29150b462L), Double.longBitsToDouble(0x3fa9c509762158a0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.NameAnalyzer|appendListItem|java.lang.StringBuilder,java.lang.String|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|calculateReferences||new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|collapseReplacements|java.util.List|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|countOf|com.google.javascript.jscomp.NameAnalyzer$TriState,com.google.javascript.jscomp.NameAnalyzer$TriState|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|createName|java.lang.String|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|createNameInformation|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|createNameInformation|java.lang.String,com.google.javascript.jscomp.Scope,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|getDependencyScope|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|getEnclosingFunctionDependencyScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|getHtmlReport||new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|getName|java.lang.String,boolean|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|getRhsSubexpressions|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|getSideEffectNodes|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|isExternallyReferenceable|com.google.javascript.jscomp.Scope,java.lang.String|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|nameAnchor|java.lang.String|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|nameLink|java.lang.String|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
