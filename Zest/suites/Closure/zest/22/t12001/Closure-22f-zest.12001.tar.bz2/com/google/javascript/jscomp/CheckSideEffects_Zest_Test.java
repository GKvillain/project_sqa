package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class CheckSideEffects_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 4, "\udb93\udd7e\ud9ca\udf67\udb40\udc26\udaf8\uddb2\ud9ae\udcc3", "\u0140\u6709\uc297\ubd58\ub888\uc247\u214f\u8ad8\u3bc7\u6c63\u4af9\u6165\u17d7\u4d1a\ub4e4", "\ud96c\udf14\udb28\udd42\udaac\udddd\udba0\udd8d\u0a9f\udb15\udc0b\udae6\uddbf\udaca\udd26",
        47, 62595, -1323625769, 1997481383223125867L, -38336L, false, true, (char) 19463, (char) 16813,
        Double.longBitsToDouble(0x3fe348c2faea02a7L), Double.longBitsToDouble(0x3fe0a1ef920b3b0cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 1, "\udbba\udeaa\ud9ca\udf67\udb40\udc26\udaf8\uddb2\ud9ae\udcc3\ud9ae\udc95\ud81c\udc21\ud8d1\udf2a\uda4d\uddc0\ud9a5\udc12\udad2\udf99\udb54\ude79\ud839\udf79\ua333\ud867\ude17\udb0f\ude50\u9885\ud939\udfbe\ud985\udd80", "\ub4e4\u0797\ucd9a\ube4a\u8f96", "\udb80\udd7f\ud906\udd10\u1614",
        59, 8327, -732409450, -5684929389532775748L, -13082L, false, false, (char) 37302, (char) 19490,
        Double.longBitsToDouble(0x3fbbb54f9348c2f8L), Double.longBitsToDouble(0x3fe750153a143df2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 4, "\udb93\udd7e", "\u7193\000", "\ud8d1\udf2a\uda4d\uddc0\ud9a5\udc12\udb36\udeb0\ud883\udef7\ud84a\udc89\ua333\ud867\ude17\uda0b\udfcd\000\000\uda2a\udcf5\ud89f\udc94\ud845\ude1c\ud9e1\udf20",
        8, 73626, -428819306, 7698405447463469109L, -58784L, true, true, (char) 34667, (char) 31509,
        Double.longBitsToDouble(0x3fe6bea2c2bcb11bL), Double.longBitsToDouble(0x3e3c312000000000L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 5, "\udb93\udd7e\ud9ca\udf67\udb40\udc26\udaf8\uddb2\ud9cb\udcb2", "\u7a52\u7296\u1626\ubd91\ub888\uc247\u214f\u8ad8\u3bc7\u6c63\u4af9", "\ud845\ude1c\ud92d\udd4d\ud948\ude0a\udbb0\udd88\ud96c\udf14\udb28\udd42\udaac\udde0\udba0\udd8d\u0a9f\udb15\udc0b\ud83b\ude89\udaca\udd26\ud87c\udc9d\ud984\udd38\udaf7\ude30\ud9f4\ude49\ud896\udc9a\udbd7\udc66\ud8eb\udeb7\ud9b8\udc02\udbbb\udfa1\udabb\udddd",
        37, 92922, 990693908, 7969447242341487991L, 32070L, true, true, (char) 28747, (char) 30823,
        Double.longBitsToDouble(0x3fe40201488c27e9L), Double.longBitsToDouble(0x3fdf4b67eedf752aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\0121=new com.google.javascript.jscomp.CheckSideEffects:@?\012",
        Z.run(T, 2, 4, 5, 4, "\udb93\udd7e\ud9ca\udf67\udb40\udc26\udaf8\uddb2\ud9ae\udcc3", "\u0140\u6709\uc297\u11c4\u9d06\u2375\u3ddd\u4119\u1cf8\u6c63\u4af9\u6165\u17d7\u4d1a\ub4e4", "\ud953\udd75\udb28\udd42\udaac\udddd\udba0\udd8d\u0a9f\udb15\udc0b\udae6\uddbf\udaca\udd26",
        -5, 72368, -1323625769, 1997481383223125867L, -38336L, false, true, (char) 19463, (char) 16813,
        Double.longBitsToDouble(0x3fe348c2faea02a7L), Double.longBitsToDouble(0x3fe0a1ef920b3b0cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 4, "\udb93\udd7e\ud9ca\udf67\udb40\udc26\udaf8\uddb2\ud9ae\udcc3", "\u0140\u6709\uc297\ubd58\ub888\uc79d\u212c\u8ad8\u3bc7\u6c63\u4af9\u6165\u17d7\u4d1a\ub4e4", "\ud96c\udf14\udb28\udd42\udaac\udddd\udba0\udd8d\u0a9f\udb15\udc0b\udae6\uddbf\udaca\udd26",
        47, 62595, -1323625769, 1997481383223125867L, -38336L, false, true, (char) 19463, (char) 16813,
        Double.longBitsToDouble(0x3fe348c2faea02a7L), Double.longBitsToDouble(0x3fe0a1ef920b3b0cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\udb93\udd7e\ud9ca\udf67\udb40\udc26\udaf8\uddb2\ud9ae\udcc3", "\u0140\u6709\uc297\ubd58\ub888\uc247\u214f\u8ad8\u3bc7\u6c63\u4af9\u6165\u17d7\u4d1a\ub4e4", "\ud96c\udf14\udb28\udd42\udaac\udddd\udba0\udd8d\u0a9f\udb15\udc0b\udae6\uddbf\udaca\udd26",
        47, 62595, -1317579305, 1997481383223125867L, -38336L, false, true, (char) 19463, (char) 16813,
        Double.longBitsToDouble(0x3fe348c2faea02a7L), Double.longBitsToDouble(0x3fe0a1ef920b3b0cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 0, "\udb93\udd7e\ud9ca\udf67\udb40\udc26\ud976\uded1\ud9ae\udcbe\ud9fc\udc9c\ud81c\udc21\ud9e4\ude0d\ud93b\udf37\udb6d\udf97\udb17\udc00\ud9dd\udda3\udae0\udc44\ua333\ud867\ude17", "\u7c6b", "\ud845\ude1c\ud9e1\udf20\ud8f2\udeb1\udbc6\udf59\ud96c\udeb7",
        26, 49733, 828748683, -4933782827866489050L, -79573L, true, false, (char) 20359, (char) 18313,
        Double.longBitsToDouble(0x3fe5e588df6b1bb8L), Double.longBitsToDouble(0x3fde189785ad1046L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckSideEffects:@?\012",
        Z.run(T, 1, 5, 5, 2, "\udb93\udd7e\ud9ca\udf67\udb40\udc26\udaf8\uddb2\ud9ae\udcc3", "\u0140\u6709\uc297\ubd58\u3db3\u8a72\u29d0\u8ad8\ucb1d\u6c63\u4af9\u6165\u17d7\u4d1a\ub4e4", "\uda08\udebd\ud913\udcd4\udaac\udddd\ud85b\udd0b\u0a9f\udb15\udc0b\udae6\uddbf\udaca\udd26",
        59, 58284, -1323625769, 1997481383223160454L, -38336L, false, true, (char) 65443, (char) 25366,
        Double.longBitsToDouble(0x3fe28a0e925c2f5aL), Double.longBitsToDouble(0x3fd513dcc416da6aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 1, 4, "\udb93\udd7e\ud9ed\udfda\udb4c\udf84\udaf8\uddb2\ud9ae\udcc3", "\u0140\u6709\u839f\u478b\ub888\uc247\u214f\u8ad8\u3bc7\u531b\u4af9\u0d66", "\ud883\udcb1\udb86\uddf1\udbc6\udf59\ud82f\udf11\ud9cd\ude09",
        59, 50603, -360229208, -1347942818116230911L, -39287L, false, false, (char) 33571, (char) 10863,
        Double.longBitsToDouble(0x3fabb9c2812db5c0L), Double.longBitsToDouble(0x3feae632dc5762ccL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 4, "\udb93\udd7e\ud9ca\udf67\udb40\udc26\udaf8\uddb2\ud9ae\udc66", "\u010b\u6709\uc297\u5a62\u69d0\uc247\u214f\u8ad8\u2298\u6be9\u4af9\u6165\ub7b8\u3487\ub4e4", "\ud96c\udf6e\udb28\udcc9\udaac\udddd\udba0\udd8d\u0a9f\udb15\udc0b\udbfc\ude19\ud905\udef9",
        8, 62595, -1323625769, 1997481383223127915L, 36705L, false, false, (char) 54703, (char) 16813,
        Double.longBitsToDouble(0x3fe348c2faea02a7L), Double.longBitsToDouble(0x3fe0a1ef920b3b0cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 3, "\ud8c8\udcee\ud9ca\udf67\udb40\udc26\uda99\udfe2\udbca\udcde", "\u1bd0", "\udb36\udebf\udbd8\udc02\ud84a\udc6d\ua333\ud867\ude17\ud810\udd1e\ud850\ude8f\ud92a\udf19\uda2a\udcf5",
        58, 47402, 1748050702, -710324890793945366L, 15977L, true, true, (char) 64648, (char) 32326,
        Double.longBitsToDouble(0x3fd26bb60203da96L), Double.longBitsToDouble(0x3fee58652632fb21L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\0121=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\012",
        Z.run(T, 2, 4, 4, 2, "\udb93\udd7e\ud9ca\udf67\udb40\udc26\udaf8\uddb2\udaad\ude83", "\u0140\u6709", "\ud883\udef7\ud84a\udc89\ua333\ud867\ude17\uda0b\udfcd\udbc9\udeef\udacc\ude4b\uda77\udeaa",
        48, 34786, 1754280183, -710324894694137366L, 15977L, true, true, (char) 54665, (char) 43953,
        Double.longBitsToDouble(0x3fd26bb87203da00L), Double.longBitsToDouble(0x3fef527e501fa523L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckSideEffects:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 4, "\udb93\udd7e\ud9ca\udf67\udb40\udc26\udaf8\uddb2\ud8fa\udd9c", "\u0140\u6709\uc297\ubd58\ub888\uc247\u214f\u8ad8\u3bc7\u6c63\u4af9\u6165\u17d7\u4d1a\ub4e4\u0797\u95ed\ube4a", "\udba0\udd8d\u0a9f\udb15\udc0b\udae6\uddbf\udaca\udd26\udb71\uddb8\ud984\udd38\udaf7\ude30\ud8a5\udc5e\ud8a8\udd91\udb34\ude54\udb93\ude8a",
        56, 51639, 408906862, 191141752406684394L, 11273L, true, false, (char) 4254, (char) 56785,
        Double.longBitsToDouble(0x3fd559b1fd54f2beL), Double.longBitsToDouble(0x3fe9adee8d9e04b6L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckSideEffects:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 4, "\udb93\udd7e\ud9ca\udf67\udb40\udc26\udaf8\uddb2\ud9ae\udcc3", "\u0140\u6709\uc297\ubd58\ub888\uc247\u214f\u8ad8\u3bc7\u6c63\u4af9\u3378\u1775\u4d1a\u4e4b", "\ud96c\udf14\udb28\udd42\udaac\udddd\udba0\udd38\u0a9f\udb15\udc0b\udae6\uddbf",
        10, 8327, -732388405, -5684929389532775748L, -13082L, false, true, (char) 59881, (char) 37660,
        Double.longBitsToDouble(0x3fbbb5421348c2f8L), Double.longBitsToDouble(0x3fe750153a143df2L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckSideEffects:@?\0121=new com.google.javascript.jscomp.CheckSideEffects:@?\012",
        Z.run(T, 2, 5, 5, 0, "\udb93\udd7e\ud9ca\udf67\udb40\udc26\udaf8\uddb2\ud9cb\udcb2", "\u7a52\u7296\u1626\ubd91\ub888\uc247\u214f\ud4ea\ud5a9\u6c63\u4af9", "\ud845\ude1c\ud92d\udd4d\uda9e\ude27\udbb0\ude55\ud96c\udf14\udb28\udd42\udaac\udde0\udba0\udd8d\u0a9f\udb15\udc0b\ud83b\udf32\udaca\udd26\ud87c\udc9d\ud984\udd38\udaf7\ude30\ud9f4\ude49\ud896\udc9a\udbd7\udc66\ud8eb\udeb7\ud9b8\udc02\udbbb\udfa1\udabb\udddd",
        37, 92922, 990693908, 7969447242341487991L, 32070L, true, true, (char) 28747, (char) 30823,
        Double.longBitsToDouble(0x3fec0201488ca1c9L), Double.longBitsToDouble(0x3fdf4b67eedf752aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckSideEffects:@?\012",
        Z.run(T, 1, 5, 5, 2, "\udb93\udd7e\ud9ca\udf67\udb40\udc26\udaf8\uddb2\ud9ae\udcc3\ud9ae\udc95\ud81c\udc21\ud8d1\udf2a\uda4d\uddc0\ud8c8\udde4\udaa5\udc0b\uda9c\udd7f\ud99b\udf8a\udbf4\udfb4", "\u6c31", "\ud89f\udc94\uae10\ud9fe\udc55\ud8f2\udeb1\udbd7\ude40\uda08\udebd\ud913\udcd4\udaac\udddd\ud85b\udd0b\udaa1\udf55\ud8a3\udd51\udae6\uddbf\ud9aa\udff0\uda14\udd46\ud980\udc61\udaf7\ude30\ud8a5\udc5e\ud8ca\udcac\ud809\ude40\udbbd\udfc2\udaa4\udd84",
        37, 7722, 559557201, -6178430729727915695L, 66196L, true, false, (char) 41876, (char) 21166,
        Double.longBitsToDouble(0x3fdfcd18a1867f68L), Double.longBitsToDouble(0x3fe170b06ac03a84L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckSideEffects:@?\0121=new com.google.javascript.jscomp.CheckSideEffects:@?\012",
        Z.run(T, 2, 5, 5, 1, "\udb93\udd7e\ud9ca\udf67\udb40\udc26\udaf8\uddb2\ud8fa\udd9c", "\u0140\u6709\uc297\ubd58\ub888\uc247\u214f\u8ad8\u3bc7\u6c63\u4af9\u6165\u17d7\u4d1a\ub4e4\u0797\u95ed\ube4a", "\udba0\udd8d\u0a9f\udb15\udc0b\udae6\uddbf\udaca\udd26\udb71\uddb8\ud984\udd38\udaf7\ude30\ud8a5\udc5e\ud8a8\udd91\udb34\ude54\udb93\ude8a",
        56, 51639, 408906862, 191141752406684394L, 11273L, true, false, (char) 4254, (char) 56785,
        Double.longBitsToDouble(0x3fd559b1fd54f2beL), Double.longBitsToDouble(0x3fe9adee8d9e04b6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 4, "\udb93\udd7e\udaeb\uddd4\udb40\udc65\udaf8\uddb2\ud9ae\udcc3", "\u0140\u6709\uc297\ubd58\ub888\u8b13\u6747\u8ad8\u3bc7\u6c63\u4af9\u6165\u17d7\u4d1a\ub4e4", "\ud96c\udf14\udb28\udd42\ud8c2\uddf7\udb9f\uddae\u0a9f\udb15\udc0b\udae6\uddbf\udb93\ude0a",
        -4, 91971, -1323628143, 1997481383223125867L, -38336L, false, true, (char) 19463, (char) 16813,
        Double.longBitsToDouble(0x3fe348c2faea02a7L), Double.longBitsToDouble(0x3fe0a1ef920b3b0cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\0121=new com.google.javascript.jscomp.CheckSideEffects:@?\012",
        Z.run(T, 2, 4, 5, 4, "\ud9d6\udfe1\ued66\udb40\udc35\udaf8\uddb2\ud9ae\udcc3", "\u0140\u6709\uc297\u11c4\u9d06\u2375\u3ddd", "\udadc\udc75\ufd7e\uda2a\udccc\ud89f\udc94\ud842\udc1c\ud9e1\udf20\ud8f2\udeb1\udae8\ude49",
        22, 77463, 1895719733, 6127539315028743848L, -97983L, false, true, (char) 29258, (char) 11224,
        Double.longBitsToDouble(0x3feb58ddc3862478L), Double.longBitsToDouble(0x3fcc0e70b44bc970L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 4, "\udb93\udd7e\ud9ca\udf67\udb40\udc26\udaf8\uddb2\ud9ae\udcc3", "\ua509\u4a65\u10ff\ubd58\ub888\uc247\u214f\u8ad8\u3bc7\u6c63\u4a6a\u6165\u1ea8\u489c\ub4e4\u0797\u95ed\ube4a\u9196\ua120\u3154\u2b5b\u2efa", "\udb71\uddb8\ud984\udd38",
        36, 69876, 611870571, 8324151320640286944L, 37767L, true, false, (char) 10952, (char) 13713,
        Double.longBitsToDouble(0x3fe0a1ef920b3b0cL), Double.longBitsToDouble(0x3fe4d7a2e2b4bb92L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.CheckSideEffects|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckSideEffects:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.CheckSideEffects|addExtern||new:com.google.javascript.jscomp.CheckSideEffects:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.CheckSideEffects|hotSwapScript|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckSideEffects:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.CheckSideEffects|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckSideEffects:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.CheckSideEffects|protectSideEffects||new:com.google.javascript.jscomp.CheckSideEffects:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "C|com.google.javascript.jscomp.CheckSideEffects|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.CheckSideEffects|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckSideEffects:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
