package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class Compiler_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 3, "\uda3b\udd25\ud92f\ude22\ud8bf\udcd2", "\u7180\u0b30\u1a4c\u9f8c\u9ef2\u217e\uc9a7\u7cfd\ub38f\u94ca\u20ba\u46d5\u0948\ud30a\u882d\ud22a\u04d2\u291e\u97fe\u0687\u10b7\u3519\u44bb\u0d96", "\ud973\udd9c\uda87\udf5b\ud9b1\udc5c\ud9f2\udf5c",
        -4, 84039, 290042831, -1799388368949485039L, -42770L, true, false, (char) 45848, (char) 49059,
        Double.longBitsToDouble(0x3fe9751d9dd35113L), Double.longBitsToDouble(0x3fdc05186ea9962cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 3, "\uda3b\udd25\ud92f\ude22\ud8bf\udcd2", "\u4187\u0b30\u1a4c\u9f8c\u9ef2\u217e\uc9a7\uc9fc\ub38f\u94ca\u20ba\u46d5\u0948\ud30a\u882d\ud22a\u04d2\u291e\u97fe\u0687\u10b7\u3519\u44bb\u0d96", "\ud973\udd9c\uda87\udf5b\ud9b1\udc5c\ud9f2\udf5c",
        8, 84039, 290042831, -1799388368949485039L, -42770L, true, false, (char) 45848, (char) 49059,
        Double.longBitsToDouble(0x3fe9751d9dd35113L), Double.longBitsToDouble(0x3fdc05186ea9962cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 3, "\uda3b\udd25\ud92f\ude22\ud8bf\udcd2", "\u7180\u0b30\u1a4c\u9f8c\u606d\u50bc\uc9a7\u7cfd\ub38f\u94ca\u20ba\u46d5\u0948\ud30a\u882d\ud22a\u04d2\u291e\u97fe\u0687\u10b7\u3519\u44bb\u0d96", "\ud973\udd9c\uda87\udf5b\ud9b1\udc5c\ud9f2\udf5c",
        -4, 84039, 290042831, -1799388368949485039L, -42770L, true, false, (char) 45848, (char) 49059,
        Double.longBitsToDouble(0x3fe9751d9dd35113L), Double.longBitsToDouble(0x3fdc05186ea9962cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=void |this=com.google.javascript.jscomp.Compiler:@?\012",
        Z.run(T, 2, 3, 5, 3, "\uda3b\udd2b\ud92f\ude22\ud8bf\udcd2", "\u7180\u0b30\u1a36\u9f8c\u9ef2\u217e\u3fc1\u58c1\u6c3f\u9579\u20ba\u46d5\u0948\u4510\u882d\ud22a\u04d2\u291e\u97fe\u0687\u10b7\ub0f3\u44bb\u0d96", "\ud973\udd9c\uda87\udf5b\udb5b\udddf\ud9f2\uded1",
        -4, 16743, -876988277, 1836497576911721927L, -42770L, true, false, (char) 45848, (char) 48922,
        Double.longBitsToDouble(0x3fe9751d9c4d5113L), Double.longBitsToDouble(0x3fdc0cb30ea9962cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 3, "\uda3b\udd25\ud92f\ude22\ud8bf\udcd2", "\u7180\u0b30\u1a4c\u9f8c\u9ef2\u217e\uc9a7\u7cfd\uaf20\u94ca\u20ba\u46d5\u0948\ud30a\u882d\ud22a\u9eb1\u5d19\u97fc\u2ac7\u10b4\u3519\u44bb\u0d96", "\ud973\udd9c\uda87\udf5b\ud9b1\udc5c\ud9f2\udf5c",
        -4, 84039, 290022607, -1799388368949485039L, -42770L, false, false, (char) 61471, (char) 48852,
        Double.longBitsToDouble(0x3fe9751d9d594913L), Double.longBitsToDouble(0x3fdc0b7f8ea9962cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 3, "\uda3b\udd25\ud92f\ude22\ud8bf\udcd2", "\u7180\u678f\"\u9f8c\u9ef2\u217e\uc9a7\u7cfd\ub38f\u94ca\u20ba\u46d5\u0948\ud30a\u882d\ud22a\u04d2\u291e\u97fe\u0687\u10b7\u3519\u44bb\u5a53", "\ud973\udcdd\uda87\udf5b\ud9c7\udfc7\udbe3\ude53",
        -4, 84039, 290042831, -1799388368949485039L, -42770L, true, false, (char) 45848, (char) 33699,
        Double.longBitsToDouble(0x3fe97519e5d35113L), Double.longBitsToDouble(0x3fdc05186ea9962cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 5, 3, "\uda3b\udd25\ud941\udf22\ud8bf\udcd2", "\u7180\u0b30\u1a4c\u9f8c\u9ef2\u217e\u27e1\u7cc4\ub38f\u94ca\u20ba\u8134\u7186\ud30a\u882d\ud22a\u04d2\u291e\u97fe\u0687\u10b7\u3519\u8ffd\u5c01", "\ud973\udd9c\uda87\udf5b\ud9b1\udc5c\ud9f2\udc5c\ud881\ude93\ud98a\udf8e\udb37\udcd3\ud8e2\udc57\ud86e\udc2b\udb3e\udef5\ud806\uded4\udaa9\udd09\u5bf7\ud9f9\ude59\ud865\udff5\udbc8\udea0",
        54, 74364, -610628603, -6412495254783775615L, -53226L, true, true, (char) 61905, (char) 43011,
        Double.longBitsToDouble(0x3fc2073714f46438L), Double.longBitsToDouble(0x3fe03ec2a24fba53L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 3, "\uda3b\udd25\udaf8\udda7\udac9\ude57", "\u7180\u0b30\u1a4c\u9f8c\u9ef2\u217e\uc9a7\u7cfd\u7bb4\u37c0\u2aee\u46d5\u64b2\ud08b\u7f17\u4493\u04d2\u291e\u97fe\u51c9\u10b7\u3519\u44bb\ud02b", "\ud973\udd9c\uda87\udf5b\ud9b1\udc5c\ud9f2\udf5c",
        41, 84039, 290042831, -1799388368949485039L, -42770L, true, false, (char) 45848, (char) 49059,
        Double.longBitsToDouble(0x3fe9751d9dd35113L), Double.longBitsToDouble(0x3fdc05186ea9962cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 3, "\ud921\udcf8\udb34\udc68\ud8a1\ude55", "\u7180\u0b30\u6281\u488c\u9ef2\u217e\uc9a7\u7cfd\ub38f\uafaa\u20ba\u46d5\u0948\ud30a\u58f8\uadda\u04d2\u291e\u97fe\u716b\u10b7\u388f\u44bb\u0d96", "\ud973\udd9c\uda87\udf5b\udb7d\ude02\ud9f2\udf5c",
        -4, 84039, 297919951, -1799388369450813167L, -42783L, true, false, (char) 23208, (char) 48950,
        Double.longBitsToDouble(0x3fe9751d9dd35113L), Double.longBitsToDouble(0x3fe5028c3754e560L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SymbolTable:@? |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 15, "\uda3b\udd25\ud92f\ude22\ud8bf\udcd2", "\u7180\u5c71\u1a8c\u9f8c\u9ef2\u217e\ua1a6\u7cfd\ub38f\u94ca\u20ba\u46d5\u0948\ud30a\u882d\ud22a\u04d2\u291e\u97fe\u69b7\u10b7\u3519\u44bb\u0d96", "\ud973\udd9c\uda87\udf5b\ud9b1\udc5c\ud9f2\udf5c",
        -4, 84039, 290042831, -1799388368949485039L, -42770L, true, false, (char) 45848, (char) 49059,
        Double.longBitsToDouble(0x3fe9751d9dd35113L), Double.longBitsToDouble(0x3fdc05186ea9962cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 3, "\uda3b\udc36\ud92f\ude22\ud8bf\udcd2", "\u7180\u4885\u77f9\u9ef0\u21b8\u2e4b\uc9a7\u7cfd\ub38f\u94ca\u20ba\u46d5\uc047\ud30a\u882d\ubb92\u04d2\u4b67\u7299\u0687\u10b7\u3519\u44bb\u0d96", "\ud973\udd9c",
        6, 99535, -744496154, -4555722744333424225L, 83983L, false, true, (char) 49059, (char) 63201,
        Double.longBitsToDouble(0x3fe96723e4ddbfe7L), Double.longBitsToDouble(0x3fd8475597902ad2L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 10, 15, "\uda0c\udde5\udaf6\ude45\ud83b\ude47", "\ub680\u101e\u3603\u9f8c\u9ef2\u217e\ua321\u3922\uc069\u94ca\u20ba\u46d5\u889a\uc9c1\u02b6\u7129\ua593\u7663\ud659\u0687\u10b7\u3519\uaa5c\ub7ce", "\udb3c\udc8d\uda87\udfbe\ua6f8\ud9f4\udfde",
        -4, 43143, 754493600, -1799388368949485039L, -42770L, true, false, (char) 45848, (char) 35415,
        Double.longBitsToDouble(0x3fe655afcdd35124L), Double.longBitsToDouble(0x3fdc051862a9963eL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 5, 14, "\uda3b\udd25\ud92f\ude22\ud8bf\udcd2", "\u7180\u0b30\u1a4c\u9f8c\u9ef2\u217e\uc9a7\u7cfd\ub38f\u94ca\u20ba\u46d5\u0948\ud30a\u882d\ud22a\u04d2\u291e\u97fe\u0687\u10b7\u3519\u44bb\u0d96", "\ud973\udd9c\uda87\udf5b\ud9b1\udc5c\ud9f2\udf5c",
        -4, 69375, 290036627, -1799388368949485039L, -42770L, true, false, (char) 45848, (char) 49059,
        Double.longBitsToDouble(0x3fe9751d9dd35113L), Double.longBitsToDouble(0x3fdc05186ea9962cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 9, 5, 3, "\uda3b\udd25\ud92f\ude22\ud8bf\udcd2", "\u1bd4\u0b30\u1a4c\u9f8c\u9ef2\u217e\uc9a7\uacb0\ub38f\u94ca\u20ba\u46d5\u0948\ud30a\u882d\ud22a\u04d2\u291e\u97fe\u0687\u10b7\u3519\u44bb\u0d96", "\ud973\udd9c\uda87\udf5b\ud9b1\udc5c\ud9f2\udf5c",
        -4, 84039, 290042831, -1799388368949485039L, -42770L, true, false, (char) 45848, (char) 49059,
        Double.longBitsToDouble(0x3fe9751d9dd35113L), Double.longBitsToDouble(0x3fdc05186ea9962cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 5, 5, "\uda51\udc59\ud92f\ude58\ud8bf\udcd2\ud928\udf64", "\u7af5\u30ef\u9ebf\u7606\u217e\uc9a7\u9951\u725f\u9555\u20ba\u46d5\uc886\ud3bb\u7c0a\u5c55\u047a\u51b3\u97fe", "\uda43\uddaa\ud8f7\udd4c\ud859\udc58\udbb2\ude02",
        3, 21473, 331009586, -9188511885497180186L, 72687L, true, false, (char) 54288, (char) 45000,
        Double.longBitsToDouble(0x3fead7947f8e3d3cL), Double.longBitsToDouble(0x3fb9066338336408L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=void |this=com.google.javascript.jscomp.Compiler:@?\012",
        Z.run(T, 2, 5, 5, 6, "\uda3b\udd25\ud92f\ude22\ud8bf\udcd2", "\u1c9d\u2776\u1a4c\ube0d\u4a14\u7b37\u3942\ubd31\ub38f\u94ca\u20ba\u46d5\u0948\ud30a\u882d\ud22a\u04d2\u7222\u9e20\u7440\ub20f\u81dd\u44bb\u0d96", "\udb61\udcd3\uda87\udf5b\ud900\udea4\ud9f2\udf5c",
        22, 91045, 290042831, -1799388368949485039L, 43610L, false, true, (char) 5253, (char) 41481,
        Double.longBitsToDouble(0x3fdc05186ca9962cL), Double.longBitsToDouble(0x3fd82752a8015368L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SymbolTable:@? |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 14, 3, "\udac4\ude9d\ud92f\udddd\ud8c4\udcc6", "\u7180\u0b30\u713a\u697a\ucb92\u258d\uc9a7\u7cfd\ub38f\u94ca\u4a11\u4788\u0948\ud30a\u882d\ud22a\u04d2\u291e\u97fe\u0687\u10b7\u3519\u44bb\u0d96", "\udbbc\udef9\uda91\udf5b\ud9b1\udc5c\ud9f2\udf5c",
        53, 54621, 290042831, -7708111078167731101L, -42770L, true, false, (char) 45848, (char) 7880,
        Double.longBitsToDouble(0x3fe974a305d35113L), Double.longBitsToDouble(0x3fe734197754cb16L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 3, "\ud8c1\ude01\ud9b7\udee6\ud8bf\udcd2", "\u59ff\ua929\ud699\u71db\u3c47\u298e\uc9a7\u6cf2\ub3d0\u94ca\u20ba\u46d5\u0948\ud30a\ub81a\ud22a\u04d2\u291e\u1c91\ud0a5\u111f\u3519\u44bb\u0d96", "\ud973\udd9c\uda87\udf5b\ud9b1\udc5c\ud9ff\udeb6",
        16, 84039, 290042831, 919129324203532817L, -71630L, true, false, (char) 24233, (char) 43211,
        Double.longBitsToDouble(0x3fe9751d99ae8a13L), Double.longBitsToDouble(0x3fdc074abea9962cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=void |this=com.google.javascript.jscomp.Compiler:@?\012",
        Z.run(T, 2, 3, 5, 3, "\uda3b\udd2b\ud92f\ude22\ud8bf\udcd2", "\u7180\u0b30\u1a36\u9f8c\u9ef2\u217e\u3fc1\u58c1\u6c3f\u9579\u93fe\ucac3\u4bf9\u4510\u882d\ud22a\u04d2\u291e\u97fe\u0687\u10b7\ub0f3\u44bb\u0d96", "\udb6b\udf18\uda87\udf5b\udb5b\udddf\ud9f2\uded1",
        21, 15596, -876988343, 1836497576911721927L, -42791L, true, false, (char) 45848, (char) 48922,
        Double.longBitsToDouble(0x3fedbb259c4d5113L), Double.longBitsToDouble(0x3fdc0cb30ea9962cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SymbolTable:@? |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 3, "\uda3b\udd2b\ud92f\ude22\ud8bf\udcd2", "\u71da\u0b30\u1a36\u9f8c\u9ef2\u087b\u3fc1", "\ud97e\ude01\ud95a\udfbc\uda15\udcba\ud877\udc73\udaab\udf85\uc2ec\uda26\udd50\ud912\ude7c",
        36, 77770, 1852018714, 198522796865423252L, -49602L, false, false, (char) 48500, (char) 8914,
        Double.longBitsToDouble(0x3fde014bb4e20670L), Double.longBitsToDouble(0x3fd9fc0c611635acL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 13, 3, "\uda3b\udd2b\ud92f\ude22\ud8bf\udcd2", "\u7180\u0b30\u1a36\u9f8c\u2de5\u217e\u3fc1\u58c1\u6c3f\u9579\u20ba\u46d5\u0948\u4510\u882d\ud22a\u9b4e\u316f\u97fe\u0687\u10b7\ub0f3\u44bb\u9a91", "\ud942\udd82\uda87\udf5b\udb5b\udddf\ud9f2\uded1",
        -4, 16743, -876988277, 1836497576911721927L, 83206L, true, false, (char) 45848, (char) 48922,
        Double.longBitsToDouble(0x3fe9751d9c4d5113L), Double.longBitsToDouble(0x3fdc0cb30ea9962cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 5, 9, 1, "\uda3b\udd2b\ud92f\uddc2\ud8bf\udcd2", "\u7180\ud54a\u6816\u8169\u268f\u217e\u3fc1\u58c1\u6c3f\u9579\u20ba\u46d5\u9c70\u3fce\u0811\ud22a\u04d2\u291e\u97fe\u0687\u10b7\ub0f3\u44bb\u0d96", "\ud973\udd9c\uda87\udf5b\udb5b\udddf\ud9f2\uded1",
        -4, 16743, -876988277, 1836497576911721927L, -42770L, true, false, (char) 45848, (char) 48922,
        Double.longBitsToDouble(0x3fe97533d44d5113L), Double.longBitsToDouble(0x3fdc0cb30e0b5e34L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 14, 3, "\uda3b\udd2b\ud92f\ude22\ud8bf\udcd2", "\u7180\u0b30\u1a36\u9f8c\u9ef2\u217e\u3fc1\u58c1\u2c36\u118c\ub1a7\u1584\u5677\u4510\u882d\ud22a\u04d2\u291e\u97fe\u0687\u10b7\ub0f3\u44bb\u0d96", "\ud973\udd9c",
        6, 97423, -744508049, 8649533950946346203L, 83983L, false, true, (char) 48922, (char) 47023,
        Double.longBitsToDouble(0x3fb3547d6e065980L), Double.longBitsToDouble(0x3feaa658b53e6783L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 12, 3, "\uda3b\udd2b\ud92f\ude22\ud8bf\udcd2", "\u41b2\u0b30\u1a36\u9f8c\u9ef2\u217e\u3fc1\u58c1\u1caa\ud0ae\u625b\ucac3\u0985\u4510\u882d\ud22a\u5c13\u4d84\u8424\u0687\u10b7\ub0f3\u44bb\u0d96", "\ud973\udd9c",
        8, 97635, -342575761, -5954494975563584935L, 83983L, false, true, (char) 48922, (char) 63201,
        Double.longBitsToDouble(0x3fb35444ca322150L), Double.longBitsToDouble(0x3fdda3f9bb4944a6L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 10, 3, "\ud975\udf29\ud92f\ude22\ud8bf\udcd2", "\u7180\u0b30\u1a36\u9f8c", "\ud91f\udfdd\u6cde\ud9a5\udd4a\ud97e\ude01\ud951\udeb3\uda15\udcba\udb4c\udd1c",
        44, 26825, 313302979, 4221839015938707829L, -35790L, false, false, (char) 2725, (char) 12271,
        Double.longBitsToDouble(0x3fb1b9dd3e1982d8L), Double.longBitsToDouble(0x3fe917095bcb6fafL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SymbolTable:@? |this=com.google.javascript.jscomp.Compiler:@?\0121=com.google.javascript.jscomp.SymbolTable:@? |this=com.google.javascript.jscomp.Compiler:@?\012",
        Z.run(T, 2, 7, 7, 12, "\uda3b\udd25\ud918\udc22\ud8bf\udcd2", "\u446c\u0b30\u5267\u9f8c\u9ef2\u217e\u27e1\u7cc4\ub38f\u94ca\u20ba\u8134\u7186\ud30a\u882d\ud22a\u04d2\u291e\u97fe\u0687\u10b7\u3519\u8ffd\u5c01", "\ud877\ude3e\ud8af\ude84\ud9b1\udc99\ud9f2\udc5c\ud881\ude93\ud98a\udf8e\udb37\udcd3\ud8e2\udc57\ud86e\udc2b\udb3e\udef5\ud806\uded4\udaa9\udd09\u5bf7\udb07\udd75\udbb0\udd1a\udbc4\udcd9",
        16, 74364, -610628603, -6412495254783775615L, -53226L, true, true, (char) 32466, (char) 18574,
        Double.longBitsToDouble(0x3fbd2cc369e8c870L), Double.longBitsToDouble(0x3f86a4a8afd1d600L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SymbolTable:@? |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 11, 14, "\uda3b\udd25\ud92f\ude22", "\u7041\uad8f\u8fe8\uacea\u5b08\u9ef2\u217e\ua1a6\u7cfd\u02f1\u94ca\u20e4\u46d5\u0948", "\uda26\udcf4\uda04\udd94\uda37\udc70\udb59\udfb3\udbbc\udec4",
        32, 17302, -411764303, 3484471395808417731L, -85377L, false, false, (char) 50088, (char) 27237,
        Double.longBitsToDouble(0x3fee7906b1d01149L), Double.longBitsToDouble(0x3fbab9c1c2e5a6d8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 8, 15, "\uda0c\udde5\udaf6\ude45\ud83b\ude47", "\ub680\u101e\u3603\u9f8c\u9ef2\u217e\ua321\u3922\uc069\u94ca\u20ba\u46d5", "\ud9ee\uddef\udae1\udcad\ud90c\udc94",
        42, 57968, -853476654, 8534466802459805642L, -24673L, true, true, (char) 7424, (char) 17018,
        Double.longBitsToDouble(0x3fe4ab0e091f13baL), Double.longBitsToDouble(0x3fe3e319d24dd39fL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 14, 3, "\uda3b\udd2b\ud92f\ude22\ud8bf\udcd2", "\u7180\u0b30\u1a36\u9f8c\u9ef2\u217e\u3fc1\u58c1\u2c36\u118c\ub1a7\uc4ec\u4e70\u963e\u87ce\ud22a\u04d2\u291e\u97fe\u0687\u10b7\u2365\u467e\u0d96", "\ud8b3\uddfc",
        23, 97423, -744508049, 8649533950946346203L, 83983L, false, true, (char) 48922, (char) 47023,
        Double.longBitsToDouble(0x3fb3547d6ffe5980L), Double.longBitsToDouble(0x3feaa658b53e0883L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 3, "\uda3b\udd25\ud92f\ude22\ud8bf\udcd2", "\u7180\u0b30\u1a4c\u9f8c\u9ef2\u217e\uc9a7\u7cfd\ub38f\u94ca\u20ba", "\ud85e\ude57\ud87f\udf31\uda26\udcf4\ud912\ude7c\uda35\ude05",
        0, 73346, 1987085399, -2595472196495935022L, -19157L, false, false, (char) 60632, (char) 25908,
        Double.longBitsToDouble(0x3fe26e9cf99fc0c6L), Double.longBitsToDouble(0x3fee7906b1d01149L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 5, 9, 1, "\000\000\ud884\udca2", "\u38e8\ud54a\u6816\u8169\u268f\u217e\u3fc1\u58c1\u6c3f\u9579\u20ba\u46d5\u9c70\u3fce\u0811\ud22a\u04d2\u291e\u97fe\u0687\u10b7\ub0f3\u44bbF", "\ud973\udd9c\uda87\udf5b\udb5b\udddf\ud9f2\uded1",
        -4, 16743, -876988277, 1836342748071876039L, -42770L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3ebea26a88000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SymbolTable:@? |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 3, "\uda3b\udd2b\ud92f\ude22\ud8bf\udcd2", "\u71da", "\ub0ad\ud845\udc69\000\ubda2\ud917\udf60\udbb5\udd73\000\ud95a\udfbc\uda15\udcba\ud877\udc73\udaab\udf85\uc2ec\uda26\udd50",
        50, 94992, 2021593770, 46222191L, -47218L, false, false, (char) 38655, (char) 7246,
        Double.longBitsToDouble(0x3fb81bebc9f021b8L), Double.longBitsToDouble(0x3fc7aac2b40052ecL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.Compiler|initOptions|com.google.javascript.jscomp.CompilerOptions|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|acceptConstKeyword||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|acceptEcmaScript5||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|addChangeHandler|com.google.javascript.jscomp.CodeChangeHandler|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|addIncrementalSourceAst|com.google.javascript.jscomp.JsAst|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|addToDebugLog|java.lang.String|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|areNodesEqualForInlining|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|buildKnownSymbolTable||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|check||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|checkFirstModule|java.util.List|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile|com.google.javascript.jscomp.JSSourceFile,[Lcom.google.javascript.jscomp.JSModule;,com.google.javascript.jscomp.CompilerOptions|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile|com.google.javascript.jscomp.JSSourceFile,com.google.javascript.jscomp.JSSourceFile,com.google.javascript.jscomp.CompilerOptions|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile|com.google.javascript.jscomp.JSSourceFile,[Lcom.google.javascript.jscomp.JSSourceFile;,com.google.javascript.jscomp.CompilerOptions|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile|[Lcom.google.javascript.jscomp.JSSourceFile;,[Lcom.google.javascript.jscomp.JSModule;,com.google.javascript.jscomp.CompilerOptions|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile|[Lcom.google.javascript.jscomp.JSSourceFile;,[Lcom.google.javascript.jscomp.JSSourceFile;,com.google.javascript.jscomp.CompilerOptions|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|initOptions|com.google.javascript.jscomp.CompilerOptions|new:com.google.javascript.jscomp.Compiler:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
