package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class CheckAccessControls_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 5, "\ud911\udfa2\u6f94\udaf2\udfbd\u092d\ud9e7\udc10\ud93a\udef6\uda90\udc2d\ud9c2\udeab\uda5d\udebd\ud92d\udd57\ud850\udef6\udbfd\udc27\uda85\udd98\ud9b3\udff5\udab4\ude74\ud9e9\udee8\udac9\udd02\ud9d5\udf8b\u19ab\ud9b2\udc2a\ud806\udc24\udbef\uddf6\ud942\udc86\udba3\ude6b", "\u75a2\u3d75\u6e91\u79ee\u29ae", "\ud867\udda3\ud81c\ude41\ud986\uddb4\udaf8\udd8f\ud9a8\ude63\ud890\udd06\ud890\udd53\ud9af\udebf\udbf4\udd26\ud931\udc5c",
        21, 49524, 2078127175, -4503879479507753285L, -56243L, false, true, (char) 44155, (char) 44326,
        Double.longBitsToDouble(0x3feeaae628e6e6f4L), Double.longBitsToDouble(0x3fe07e2a9103ceedL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 0, "\ud911\udfa2\u6f94\udaf2\udfbd\ud81c\udcb8\ud9e7\udeda\ud93a\udef6\uda90\udc2d\ud9c2\udeab\uda5d\udebd\ud92d\udd57\ud850\udef6\udbfd\udc27\uda85\udd98\ud9b3\udff5\udab4\ude74\ud9e9\udee8\udac9\udd02\ud9d5\udf8b\u19ab\ud9b2\udc2a\ud806\udc24\udbef\uddf6\ud942\udc86\udba3\ude6b", "\u75a2\u3d75\u6e91\u79ee\u29ae", "\ud867\udd57\ud81c\ude41\ud986\uddb4\udaf8\udd8f\ud9a8\ude63\ud890\udd06\ud890\udd53\ud9af\udebf\udbf4\udd26\ud931\udc5c",
        21, 49524, -485587741, -4503879400343804229L, 45995L, true, true, (char) 4151, (char) 36786,
        Double.longBitsToDouble(0x3fe489cf5491a895L), Double.longBitsToDouble(0x3feeaae628e6e6f4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 6, "\ud911\udfa2\u6f94\u2769\udb5b\udd14\ud9e7\udc10\ud93a\udef6\uda90\udc2d\ud9c2\udeab\uda5d\udebd\ud92d\udd57\ud850\udef6\udbfd\udc27\uda85\udd98\ud9b3\udff5\udab4\ude74\ud9e9\udee8\udac9\udd02\ud9d5\udf53\u19ab\ud9b2\udc2a\ud806\udc24\udbef\uddf6\ud942\udc86\udba3\ude6b", "\u75a2\u3d75\u6e91\u79ee\u29ae", "\ud867\udda3\ud81c\ude41\udba7\udcc4\udb01\ude0e\ud9a2\udf63\ud890\udd06\ud890\udd53\ud9af\udebf\udbf4\udd26\ud931\udc5c",
        21, 78260, 2078127744, -4503879479507753285L, -56243L, false, true, (char) 44155, (char) 44326,
        Double.longBitsToDouble(0x3feeaae628e6e6f4L), Double.longBitsToDouble(0x3fe07e2a9103ceedL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 1, 5, "\ud911\udfa2\u6f94\udaf2\udfbd\u092d\ud9e7\udc10\ud93a\udef6", "\u2696\u5b15", "\uda85\udd98\ud9b3\udff5\udab4\ude74\ud9e9\udee8\udac9\udd02\ud9d5\udf8b",
        -3, 63390, -1176959673, -1447283692926683875L, -42773L, false, true, (char) 48328, (char) 34415,
        Double.longBitsToDouble(0x3fe2ac6738722156L), Double.longBitsToDouble(0x3fd6fa2c189e4aaaL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 0, 5, "\ud911\udfa2\u6f94\udaf2\udfbd\u092d\ud9e7\udc10\ud93a\udef6\uda90\udc2d\ud9c2\udeab\uda5d\udebd\ud92d\udd57\ud850\udef6\udb65\udc3a\uda85\udd98\ud9b3\udff5\udab4\ude74\ud9e9\udee8\udac9\udd02\ud820\udd8e\u19ab\ud9b2\udc2a\ud806\udc24\udbef\uddf6\ud942\udcf7\udba3\ude6b", "\u75a2\u2f57\u2c4f\u79cc\u29ae", "\ud867\udda3\ud81c\ude41\ud986\uddb4\udb04\udd8f\ud9a8\ude63\ud890\udd06\ud890\udd53\ud9af\udebf\udbf4\udd26\ud931\udc5c",
        21, 49524, 1172485191, -4503879165975140677L, -56243L, false, true, (char) 44155, (char) 44326,
        Double.longBitsToDouble(0x3feeaae628e6e6f4L), Double.longBitsToDouble(0x3fe07e2a9103ceedL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 1, 5, "\ud911\udfa2\u6f94\udaf2\udfbd\u092d\ud9e7\udc10\ud93a\udef6\uda90\udc2d\ud9c2\udeab\udb70\udf26\ud962\udfb7\ud850\udef6\udbfd\udc27\uda85\udd98\ud9b3\udff5\udab4\ude74\ud9e9\udee8\udac9\udd02\ud9d5\udf8b\u19ab\ud9b2\udc2a\ud806\udc24\udbef\uddf6\ud942\udc86\udba3\ude6b", "\u75a2\ub574\u6ed0\u79ee\u29ae", "\ud867\udda3\ud81c\ude41\ud986\uddb4\udaf8\udd8f\ud9a8\ude63\ud890\udd06\ud890\udd53\ud9af\udebf\udbf4\udd26\ud931\udc5c",
        21, 49524, 2078127175, -4503879479507753285L, -56243L, false, true, (char) 44155, (char) 44326,
        Double.longBitsToDouble(0x3feeaae628e6e6f4L), Double.longBitsToDouble(0x3fe07e2a9103ceedL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 5, "\ud911\udfa2\u6f94\udaf2\udfbd\u092d\ud9e7\udc10\ud93a\udef6\uda90\udc2d\ud828\udd37\uda3b\udefb\ud92d\udd57\ud850\udef6\udbfd\udc27\udba9\udc80\ud9b3\udff5\udab4\ude74\ud9e9\udee8\udac9\udd02\ud9c4\udd98\uda91\udf8f\ud904\ude03\ud9ff\udfae\udb28\ude01\ud942\udc86\udba3\ude6b", "\u75a2\u3d75\u6e91\u79ee\u29ae", "\ud867\udda3\ud81c\ude41\ud986\uddb4\ud91c\udcc0\ud994\ude89\ud890\udd06\ud890\udd53\ud9af\udebf\udbf4\udd26\ud931\udc5c",
        -1, 36647, 2075379105, -4503879480001143729L, -37125L, true, true, (char) 33533, (char) 25516,
        Double.longBitsToDouble(0x3fd2db8c89235152L), Double.longBitsToDouble(0x3feeaae628e6e6f4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 5, "\ud911\udfa2\u6f94\udaf2\udfbd\u092d\ud9e7\udc10\ud96e\udef0\ud974\udd20\ud9c2\udeab\uda5d\udebd\ud92d\udd57\ud850\udef6\udbfd\udc32\uda85\udd98\ud9b3\udff5\udab4\ude74\ud9e9\udee8\udac9\udd02\ud9d5\udf8b\u19ab\ud9b2\udc2a\ud806\udc24\u6ded\ud942\udc86\udba3\ude6b", "\u75a2\u2cdd\u6e91\u79ee\ud1df", "\udbcb\udfa0\ud81c\ude41\ud986\uddb4\udaf8\udd8f\ud9a8\ude63\ud890\udd06\ud890\udd53\ud9af\udebf\udbf4\udd26\ud931\udc5c",
        21, 49524, 2078127175, -4503879479507753285L, 39843L, false, true, (char) 40424, (char) 36938,
        Double.longBitsToDouble(0x3fe489cf5491a895L), Double.longBitsToDouble(0x3feeaae628e6e6f4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 5, "\ud90f\udc16\ud8d7\uddb1\udb68\udc70\udbee\udc0b\ud922\udfda\ud93a\udef6\uda90\udc2d\ud9c2\udeab\uda5d\udebd\ud92d\udd57\ud82e\udc4e\udbfd\udc27\ud941\udf16\ud9b3\udff5\udab4\ude74\ud9e9\udee8\ud99b\udf8b\ud9d5\udf8b\u19ab\ud9b2\udc2a\ud806\udc24\udbef\uddf6\ud942\udc86\ud92e\uddf1", "\u75a2\u3d75\u6e91\u5300\u29ae", "\ud9f1\udc24\ud81c\ude41\ud922\udd21\udaf8\udd97\ud9a8\ude63\udaaf\udf36\uda33\udfd7\udbed\udfa6\udac3\udfec\ud934\ude5a",
        58, 24868, 2078127175, -4503879479507753285L, 33355L, false, false, (char) 44155, (char) 5892,
        Double.longBitsToDouble(0x3feeac2e28e680f4L), Double.longBitsToDouble(0x3fe07e2a922db8edL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 8, 6, "\ud911\udfa2\u6f94\u4337\udb5b\udd14\ud9e7\udc10\ud93a\udef6\uda90\udc2d\ud9c2\udeab\uda5d\udebd\ud92d\udd57\ud850\udef6\udbfd\udc27\uda85\udd98\ud9b3\udff5\udab4\ude74\ud9e9\udee8\udac9\udd02\ud9d5\udf53\u19ab\ud9b2\udc2a\uda8c\udf17\udbef\uddf6\ud942\udc86\udba3\ude6b", "\u75a2\u3d75\u6e91\u79ee\u29ae", "\udb9e\udebf\ud98f\udeb2\udba7\udc66\uda23\udec8\udb51\udcd3\uda90\udf63\udaa5\ude74\uda66\udcce\udbf4\udd24\ud931\udc5c",
        21, 78260, 2078127744, -4503879479507753285L, -56243L, false, true, (char) 44155, (char) 3600,
        Double.longBitsToDouble(0x3fe83fab90e650feL), Double.longBitsToDouble(0x3fe07e2a9103ceedL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 6, 6, "\ud911\udfa2\u6f94\u2769\udb5b\udd14\ud9e7\udc10\ud93a\udef6\uda90\udc2d\ud9c2\udeab\uda5d\udebd\ud92d\udd57\ud850\udef6\udbfd\udc27\uda85\udd98\ud9b3\udff5\udab4\ude74\uda3b\udf71\udac9\udcf7\ud9d5\udf53\u19ab\ud9b2\udc2a\ud806\udc24\udbef\uddf6\ud942\udc86\udba3\ude6b", "\u75a2\u3d75\u6e91\u79ee\u29ae", "\ud867\udda3\ud81c\ude41\udba7\udcc4\udb01\ude0e\ud9a2\udf63\ud890\udd06\ud890\udd53\ud9af\udebf\udbf4\udd26\ud931\udc5c",
        21, 78260, 2078127744, -4503879479507753285L, -56243L, false, true, (char) 44155, (char) 44326,
        Double.longBitsToDouble(0x3feeaae628e6e6f4L), Double.longBitsToDouble(0x3fe07e2a9103ceedL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 11, 5, "\ud911\udfa2\u6f94\udaf2\udfbd\u092d\ud9e7\udc10\ud93a\udef6", "\u2696\u5b15", "\uda85\udd98\ud9b3\udff5\udab4\ude74\ud9e9\udee8\udac9\udd02\ud9d5\udf8b\u19ab\ud9b2\udc2a\uda7c\udd24",
        26, 7349, -850822807, 110092404065123078L, 466L, true, true, (char) 39332, (char) 15174,
        Double.longBitsToDouble(0x3fedbc0a3c9c970bL), Double.longBitsToDouble(0x3fd7c750767d2f3aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 12, 12, 5, "\ud911\udfa2\u6f94\udaf2\udfbd\u092d\ud9e7\udc10\ud93a\udef6\uda90\udc2d\ud88e\udcf2\ud971\udcec\ud950\uddaa\ud850\udef6\udbfd\udc27\uda85\udd98\ud9b3\udff5\udab4\ude74\ud9e9\udee8\udac9\udd02\ud9d5\udf8b\udbf5\udd27\ud9b2\udc2a\ud806\udc24\udbef\uddf6\ud942\udc86\udba3\ude6b", "\u75a2\u14b0\u6ed0\u4615\u29ae", "\ud867\udda3\udb0c\udeb9\uda22\udd1d\uda55\udfbf\ud9a8\udea6\ud890\udd06\ud890\udd53\ub6bf\udbf4\udd26\ud931\udc5c",
        21, 49524, 2078127175, -4503879478704675141L, -43242L, true, true, (char) 4151, (char) 41498,
        Double.longBitsToDouble(0x3fe489cf5491a895L), Double.longBitsToDouble(0x3feeaae628e6e6f4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 5, "\ud911\udfa2\u6f94\udaf2\udfbd\u092d\ud9e7\udc10\ud93a\udef6\uda90\udc2d\ud9c2\udeab\uda5d\udebd\ud92d\udd57\ud850\udef6\udbfd\udc27\ud8dd\udc23\ud9b3\udf8b\udab4\ude74\ud9e9\udee8\udac9\udd02\ud9d5\udf8b\u19ab\ud9b2\udc2a\ud806\udc24\udbef\uddf6\ud942\udc86\udba3\ude6b", "\u75a2\u3d75\u6e91\u79ee\u29ae", "\ud867\udda3\ud81c\ude41\ud986\uddb4\udaf8\udd8f\ud9a8\ude63\ud890\udd06\ud890\udd53\ud9af\udebf\udbf4\udd26\ud931\udc5c",
        21, 49524, 2078127175, -4503879479507753285L, -56243L, false, true, (char) 44155, (char) 44326,
        Double.longBitsToDouble(0x3feeaae628e6e6f4L), Double.longBitsToDouble(0x3fe07e2a9103ceedL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.CheckAccessControls|checkPropertyVisibility|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckAccessControls:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.CheckAccessControls|canAccessDeprecatedTypes|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.CheckAccessControls:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.CheckAccessControls|checkConstantProperty|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckAccessControls:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.CheckAccessControls|checkConstructorDeprecation|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckAccessControls:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.CheckAccessControls|checkNameDeprecation|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckAccessControls:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.CheckAccessControls|checkNameVisibility|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckAccessControls:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.CheckAccessControls|checkPropertyDeprecation|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckAccessControls:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.CheckAccessControls|dereference|com.google.javascript.rhino.jstype.JSType|static",
    "M|com.google.javascript.jscomp.CheckAccessControls|enterScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.CheckAccessControls:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.CheckAccessControls|exitScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.CheckAccessControls:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.CheckAccessControls|getClassOfMethod|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckAccessControls:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.CheckAccessControls|getPropertyDeprecationInfo|com.google.javascript.rhino.jstype.ObjectType,java.lang.String|static",
    "M|com.google.javascript.jscomp.CheckAccessControls|getTypeDeprecationInfo|com.google.javascript.rhino.jstype.JSType|static",
    "M|com.google.javascript.jscomp.CheckAccessControls|hotSwapScript|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckAccessControls:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.CheckAccessControls|isDeprecatedFunction|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.CheckAccessControls|isValidPrivateConstructorAccess|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.CheckAccessControls|checkPropertyVisibility|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckAccessControls:com.google.javascript.jscomp.AbstractCompiler",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
