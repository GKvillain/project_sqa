package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class PeepholeOptimizationsPass_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 9, "\ud966\udf8a\uda34\udfdb\ud9f5\udece\udb72\udedb\ud9e2\udef3\uda74\udf5d\udacc\udd08", "\ub274\ud10d\u55cd\u9f77\u3e15\u4f5d\u2b1e\u4c08", "\udb2d\udf3d\uda8f\udde0\ud8ab\udc4a\ud94b\udfcb\ud8ce\udce0\udbfd\udce2\ud963\udd5f\uda0d\udca2\ud929\udc16",
        10, 82351, -331157904, 5914601813184347541L, -2846L, true, true, (char) 42486, (char) 43493,
        Double.longBitsToDouble(0x3fd73ce6979a2b84L), Double.longBitsToDouble(0x3fd137ab68e9ed6eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 9, "\ud966\udf8a\ud83a\udec7\ud9e8\udf79\udb85\udd72\udb3f\ude16\uda74\udf9a\udacc\udd08", "\ub4b4\ud10d\u55cd\u63f8\u3e15\u4f5d\u2b1e\u4c08\u92d1\u6603\u5dc4\u6115\u9c16\u2a0d\u46f2", "\ud83c\udc93",
        26, 99003, 1115527351, -1422312366114807037L, 88382L, false, false, (char) 28989, (char) 42486,
        Double.longBitsToDouble(0x3fd553490ae79cd2L), Double.longBitsToDouble(0x3fee68ae15137ab6L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 9, "\ud966\udf8a\uda34\udfdb\ud9f5\udece\udb72\udedb\ud9e2\udef3\uda74\udf5d\udacc\udd08", "\ub274\ud10d\u55cd\u9f77\u3e15\u4f5d\u2b1e\u4c08", "\udb2d\udf3d\uda8f\udde0\ud8ab\udc4a\ud94c\udc36\ud8ce\udce0\udbfd\udce2\ud963\udd5f\uda0d\udca2\ud929\udc16",
        10, 82351, -331157904, 5914601813184347541L, -2846L, true, true, (char) 42486, (char) 43493,
        Double.longBitsToDouble(0x3fd73ce6979a2b84L), Double.longBitsToDouble(0x3fd137ab68e9ed6eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 9, 9, "\ud966\udf8a\uda34\udfdb\ud9f5\udece\udb7f\udfa1\uda1c\ude6f\udbe7\udee7\udaca\udee8", "\ub274\ud10d\u55cd\u9f77\u3e15\u4f5d\u2b1e\u4c08", "\udb2d\udf3d\u021c\ud8ab\udc0f\ud94b\udfcb\ud8ea\udc91\ud833\udfa4\ud525\uda0d\udcb0\ud815\udc6d\ud96d\udfa5\udada\udf66\ud8a9\udd9a\ud82a\udee5",
        9, 98518, -2093054850, -4570610465946671771L, 7149L, true, true, (char) 12233, (char) 37675,
        Double.longBitsToDouble(0x3fc00ffd7e6b9b6cL), Double.longBitsToDouble(0x3fdad71fc7e396fcL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PeepholeOptimizationsPass:@? |a1=[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;:[[null]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 9, "\ud966\udf8a\uda34\udfdb\ud9f5\udece\udb72\udedb\ud9e2\udef3\ud870\udf5b\udacc\udd08", "\u5521\ud10d\u55cd\u9f77\u3e15\u4f5d\u2b1e\u4c08", "\udb2d\udf3d\uda8f\udde0\ud8ab\udc4a\ud94b\udfcb\ud8ce\udce0\udbfd\udce2\ud963\udd5f\uda0d\udca2\ud929\udc16",
        57, 82351, -883757456, -7725048230995869264L, -2846L, true, true, (char) 42486, (char) 43493,
        Double.longBitsToDouble(0x3fd73ce6979a2b84L), Double.longBitsToDouble(0x3fd137ab68e9ed6eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\0121=null |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\012",
        Z.run(T, 2, 9, 4, 9, "\udada\udf01\ua72f\ud9e7\udd44\udb72\udedb\ud9e2\udef3\uda74\udf5d\udacc\udd08", "\u938d\ud10d\u55cd\u9f77\u3e15\u4f5d\u2b1e\u4c08", "\udb2d\udf3d\udb17\udea4\udbfc\udef2\ud94b\udfcb\ud8ce\udce0\uda36\udce9\ud963\udd5f\uda0d\udca2\ud929\udc16",
        10, 82340, -331157904, 5914601813184347541L, -2846L, true, true, (char) 42486, (char) 43493,
        Double.longBitsToDouble(0x3fd73ce6979a2b84L), Double.longBitsToDouble(0x3fd137ab68e9ed6eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 1, "\udb5e\ude9d\udb24\udf53\ud9f5\udf85\ud85b\udcbe\ud84f\udc01\uda63\ude17\udacc\udd08", "\u21b0\u3e99\ub2b6\u9f77\u3e15\u5d95\u2ad6\ub9bf\u21e3\u5ee7\u5dc4\u6115\u9c16", "\ud93b\udc5a\ud963\udd88\uda0d\udca2",
        20, 12320, 1115527351, -1289311041560880777L, 88382L, false, false, (char) 28989, (char) 42486,
        Double.longBitsToDouble(0x3fd286affa1a578cL), Double.longBitsToDouble(0x3fe9075d4513561bL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 9, "\ud956\udf8a\uda34\udfdb\ud9f5\udece\udb7f\udcdb\udb02\udfa4\uda68\udd04\uda51\udd2a", "\ub274\ud10d\ubf57\u5a17\ub6ae\u845e\u8f4e\ucefe\u4475\u4bf7", "\ud813\uddc5\ud943\udd48\ud8ce\udce0\ud88e\ude4b\uda02\udc4a\udb43\udc9d\ud929\udc16\ud994\udf7d\ud8f9\udc87\ud816\udd35\ud927\udfd9\udbdb\udc22",
        -5, 4568, -1064178177, 4005359667176737010L, -9041L, false, true, (char) 29511, (char) 60732,
        Double.longBitsToDouble(0x3fee433cfa137951L), Double.longBitsToDouble(0x3fc5bacc25e7fb74L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 6, 1, "\ud966\udf8a\uda34\udfdb\ud9f5\udece\udb72\udedb\ud9e2\udef3\uda74\udf5d\udacc\udd08", "\u2e4e\u451e\u1303\u4e3b\u612f\u4f5d\u2b1e\u4c08", "\udb2d\udf3d\uda8f\udde0\ud8ab\udc4a\ud94b\udfcb\ud8ce\udce0\udbfd\udce2\ud963\udd5f\uda0d\udca2\ud929\udc16",
        10, 82351, -331157904, 5914601813184347541L, -2846L, true, true, (char) 42486, (char) 63490,
        Double.longBitsToDouble(0x3fd73ce6979a2bdcL), Double.longBitsToDouble(0x3fd137ab68e9ed6eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 9, "\ud966\udf8a\uda34\udfdb\ud9f5\udece\udb72\udedb\ud9e2\ude50\u008f\udacc\udc48", "\ub274\ud10d\u55cd\u9f77\u3e15\u4f5d\u2b1e\u4c08", "\udb2d\udf3d\uda8f\udde0\ud8ab\udc4a\ud94b\udfcb\ud8ce\udce0\udbfd\udce2\ud963\udd5f\udac3\udc9d\ud929\udc16",
        10, 82351, -331157904, 5914601813184347541L, -2846L, true, true, (char) 42486, (char) 43493,
        Double.longBitsToDouble(0x3fd73ce6979a2b84L), Double.longBitsToDouble(0x3fd137ab60e9ed6eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 9, "\ud97a\ude27\ud867\ude4a\ud9f5\udedc\u6a09\ud9e2\udf2e\ud9a7\ude77\ud962\udd52", "\ucc00\ud1be\u55cd\u2222\u8233\u1ddd\u4aff\u9d35", "\udb2d\udf3d\uda8f\udde0\ud873\udc4e\ud94b\udfcb\ud8ce\udce0\ud855\udcfe\ud972\udd7e\ud8e0\udcc0\ud929\udc16",
        37, 87911, -1270437782, -2775712550579463812L, -21267L, true, true, (char) 26924, (char) 20422,
        Double.longBitsToDouble(0x3fce95e64e536cfcL), Double.longBitsToDouble(0x3fe1e3e0b871f6afL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 9, "\ud9b1\udd14\udb63\udecf\ud8c9\udcaa\udbf6\udf44\udaec\ude18\ud80f\udee3\udafa\udeb6", "\u117b\u5152\u5652\u9a4e\u1d19\ua464\u6e86", "\udb05\udf51\ud9ff\udc9a\ud8f3\ude8f\udac2\udd91",
        0, 49581, -198329737, 6895911081013268706L, 57208L, true, true, (char) 12525, (char) 53061,
        Double.longBitsToDouble(0x3fd955214fbc3d76L), Double.longBitsToDouble(0x3fe23fd071a92cd1L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 9, 9, "\ud9a0\udca1\uda8c\ude60\ud9f5\udece\ud82d\udd18\ud9e2\udef3\uda74\udf5d\udacc\udd08", "\u0732\u8f92\u1e65\ub17d\u3e15\u4f5d\u728b", "\ud9c7\udef3\udb2d\udf3d\uda8f\udde0\ud8ab\udc4a\uda4b\udf2e",
        30, 14989, 807543090, -8205101604490526373L, 55209L, false, false, (char) 47685, (char) 42665,
        Double.longBitsToDouble(0x3feef0f5dc7efab8L), Double.longBitsToDouble(0x3fdff833eb0900f4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\0121=void |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\012",
        Z.run(T, 2, 4, 8, 5, "\ud966\udf8a\uda34\udfdb\ud9f5\udece\udb56\udd4d\udaa9\udf97\ud976\udc4a\uda10\udc7b", "\ub274\ud179\u8478\u2c4b\u48fc\u4cb2\uad2d\u4c08\u9b2e\u659e\ubf22\u3065\ud571", "\udbfd\udce2\ud963\udd5f\ud825\ude0e\ud928\udfbd\ud84b\uddba\ud83f\udca2\udbfa\udfb1\uda95\udf11",
        28, 29254, 102037791, -5327906763629992380L, 395L, false, true, (char) 48939, (char) 37675,
        Double.longBitsToDouble(0x3feaf98b872bac06L), Double.longBitsToDouble(0x3fde878c18a56032L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 9, "\ud966\udf8a\uda34\udfdb\ud9f5\udece\udb72\udedb\ud9e2\udef3\uda74\udf5d\ud99e\udf91", "\ub274\ud10d\u55cd\u673c\ucb2e\u4f5d\u2b1e\u4c08", "\udb2d\udf3d\uda8f\udde0\ud8ab\udc4a\ud94b\udfcb\ud8ce\udce0\udbfd\udce2\ud963\udd5f\uda0d\udca2\ud929\udc16\ud84b\uddba\ud93b\udcd7",
        29, 73843, 1468845046, -428158772070939522L, 7149L, true, true, (char) 12233, (char) 37758,
        Double.longBitsToDouble(0x3fca29941071df94L), Double.longBitsToDouble(0x3fad7f3b29260580L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PeepholeOptimizationsPass:@? |a1=[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;:[[null, null, null]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 9, "\uda50\udc9f\uda35\udc8d\ud9f5\udece\udb72\udedb\ud9e2\udef3\uda74\udf5d\udacc\udd08", "\u3484", "\udbe9\udc4f\udb26\ude02\ud9c7\uddcb\ud85f\udcbc\ud92f\udf26\udbff\udeca\ud9c7\udef3\udb2d\udf3d\uda8f\udde0\ud8ab\udc4a",
        31, 9777, 2132933989, -4674136965458518128L, 4936L, true, false, (char) 12525, (char) 53061,
        Double.longBitsToDouble(0x3fd955214fbc3d76L), Double.longBitsToDouble(0x3fbfbe83affc19f0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\0121=void |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\012",
        Z.run(T, 2, 1, 2, 0, "\ud966\udf8a\uda34\udfdb\ud9f5\udece", "\u9491\u2812\u8f07\u1a4f\uce2f\u2fe4\u5589\uce77\u588d\u3ec5\u2a99", "\ud88e\ude36\udb2d\udfdb\udaab\uddee\ud8ab\udc4a\ud94b\udfcb\ud8b3\udf12\udbfd\udce2\ud963\udd5f\uda0d\udca2\udba1\udc92",
        36, 6749, -331206473, 2527894893401713045L, -2846L, true, false, (char) 33596, (char) 34508,
        Double.longBitsToDouble(0x3fc85518d6d8d5f4L), Double.longBitsToDouble(0x3fd13a7148e9ed6eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PeepholeOptimizationsPass:@? |a1=[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;:[[null, null]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 2, 9, "\udb52\uddc2", "\u90d6\u0f2f\u9491\u7780\u94d3\u0614\ub274\ud10d\u55cd\u9f77\u3e15\u4f5d\ua662\u4c08\u92d1", "\ud8cc\udea4\ud859\udff5\udb62\udcd5",
        34, 89053, -1088282318, -3579623312201184165L, 57513L, false, false, (char) 53106, (char) 37545,
        Double.longBitsToDouble(0x3fc65892c96ec088L), Double.longBitsToDouble(0x3fe623f4b876324aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\0121=null |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\012",
        Z.run(T, 2, 4, 4, 9, "\ud8fc\udeab\ud881\ude02\ud9e8\udf79\udb85\udd72\udb3f\ude16\udb60\udf90\udacc\udd08\uda9e\udc09\udaf6\udd64\ud831\udd1b\ud994\udd40\ud843\udee9", "\ubb92\u2a9d\u4c08\u92d1", "\uda8f\udde0\ud8ab\udc4a",
        20, 37401, -2145542487, -6844632319936062742L, 93982L, true, false, (char) 12525, (char) 53061,
        Double.longBitsToDouble(0x3fd955214fbc3d76L), Double.longBitsToDouble(0x3fbfbe83affc19f0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PeepholeOptimizationsPass:@? |a1=[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;:[[null, null]]\0121=new com.google.javascript.jscomp.PeepholeOptimizationsPass:@? |a1=[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;:[[null, null]]\012",
        Z.run(T, 2, 9, 9, 0, "\ud966\udf8a\ud83a\udec7\ud9e8\udf79\udb85\udd72\udb3f\ude16\udbe0\udf90\udacc\udd08\uda9e\udc09", "\ud10d\uc523\u3953\ua82f\u4f5d\u051b\u920a\u4824\u6603\u5e1e\ub3c4\u8b9c\u2a0d\u46a9", "\ud83e\ude36",
        26, 89787, 1115527351, -1422312366114807037L, 88382L, false, false, (char) 32413, (char) 42486,
        Double.longBitsToDouble(0x3fd5534902e79cd2L), Double.longBitsToDouble(0x3fe6045dcd137aa6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 6, "\ud91b\udea9\udb5c\udc49\ud969\udfc8\udb85\udd08\udb3f\ude16\uda74\udf9a\udacc\udd08", "\ub4b4\ud10d\u55cd\u63f8\u3e15\u4f5d\ubef7\uabf9\ub7bb\u7aa2\u37a3\u9fcf\u9bfa\u2a0d\u46f2", "\ud83c\udc93",
        44, 99003, 1110087863, -1422312366111079151L, 88382L, false, false, (char) 28989, (char) 42486,
        Double.longBitsToDouble(0x3fd823490bcb9cd2L), Double.longBitsToDouble(0x3fee68aaad137ab6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PeepholeOptimizationsPass:@? |a1=[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;:[[null]]\012",
        Z.run(T, 1, 9, 1, 9, "\ud966\udf8a", "\u9d70\u0b37", "\ud82f\udcb2\ud948\ude19\ud8af\udea4\ud994\udd26\ud843\udee9\ud9fe\udf0e\uda1f\udf1f\ud9ca\udc84\ud89c\udebb\ud931\udeae\udbff\udeca\ud9c7\udef3\udb2d\udf3d\uda8f\udde0\ud8ab\udc4a\ud933\uddff\ud8ce\udce0\udaa0\udfdb\udbcb\udd91\ud83c\udc93\udbb4\udcff\ud9e6\ude41\ud83f\udca2\ud8a9\udd46\u04e7\udbcb\ude18\udb27\udecc",
        5, 57823, 881907122, -3573195821536290377L, 77427L, true, true, (char) 38741, (char) 65429,
        Double.longBitsToDouble(0x3fe29dd247dcef03L), Double.longBitsToDouble(0x3fa4fd4393820d90L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\0121=void |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\012",
        Z.run(T, 2, 1, 1, 9, "\ud966\udf8a\uda34\udfdb\ud9f5\udece\udb76\udc46\uda6f\uddf1\uda74\udf5d\udacc\udd08", "\ub273\u1ce9\ub86b\u8d32\u3bb4\u4f5d\u2b1e\u4c08", "\udb2d\udf86\udbde\uddc9\ud8b7\udea7\ud94c\udc36\ud8ce\udce0\udbfd\udce2\ud963\udd5f\ud927\udd2a\udae9\uddf3",
        48, 94113, -331174440, 5914601813184347541L, -2846L, true, true, (char) 42486, (char) 44429,
        Double.longBitsToDouble(0x3fd73ce6979a2b84L), Double.longBitsToDouble(0x3fd137ab6a42e4ecL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\0121=new com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\012",
        Z.run(T, 2, 9, 9, 3, "\ud966\udf8a\uda34\udfdb\ud9f5\udece\udb72\udedb\ud9e2\udef3\uda74\udf5d\udacc\udd08", "\ub274\ud10d\u55cd\u9f77\u3e15\u4f5d\u2b1e\u4c08", "\udb2d\udf3d\uda8f\udde0\ud8ab\udc4a\ud94c\udc36\ud8ce\udce0\udbfd\udce2\ud963\udd5f\ud9cc\ude86\ud818\udfde",
        10, 82351, -331157904, 5914601813174167242L, -2846L, true, true, (char) 42486, (char) 43493,
        Double.longBitsToDouble(0x3fd73ce6979a2b84L), Double.longBitsToDouble(0x3fd5005788e9ed6eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\012",
        Z.run(T, 1, 9, 1, 9, "\ud966\udf8a\uda34\udfdb\ud9f5\udece\ud89f\ude52\udbeb\udc99\udba7\udd6d\ud940\uddb2", "\u5521\ud10d", "\udb26\ude02\ud9c7\uddcb\ud85f\udcbc\ud92f\udf26\udbff\udeca",
        54, 50774, -905596657, -6666653743653875176L, 30405L, false, true, (char) 24242, (char) 47802,
        Double.longBitsToDouble(0x3fded6ac36992ab8L), Double.longBitsToDouble(0x3fc7bf55b6423ed0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PeepholeOptimizationsPass:@? |a1=[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;:[[null, null]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 8, 7, "\ud94a\udd8a\uda59\udfdb\ud9f5\udece\udb54\udddb\ud90c\udd49", "\u366d\u5198\u5521\ud10d\u55cd\u9f77\u3e15\u4f5d\u2b1e\u4c08\u92d1\u6603\u5dc4\u6115", "\ud8ce\udce0\udbfd\udce2\ud963\udd5f\uda0d\udca2\ud929\udc16\udb41\udf99\ud84c\udd9b\ud906\udf55\uda63\udec1\uda70\udf7f\ud945\udf84\udb6b\udd23\ud802\ude42\ub07e\udb84\ude68\udb34\ude80\ud9a7\ude24\udbd5\udc86\udb0a\udf65\udbf0\udd8d",
        2, 48178, 1488252365, 2030096476566082705L, 75121L, true, false, (char) 64008, (char) 40747,
        Double.longBitsToDouble(0x3fc2e04a4852a6f0L), Double.longBitsToDouble(0x3fe43394937ce455L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\0121=null |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\012",
        Z.run(T, 2, 4, 4, 9, "\udada\udf01\ua72f\ud9e7\udd44\udb72\udedb\ud9e2\udef3\uda74\udf5d\udacc\udd08", "\u1d09\u8f08\u55cd\u9f77\u3e15\u4f5d\u2b1e\u4c08", "\udac3\udde7\u61f6\udab2\udc89\udaa3\udf38\ud8ce\udce0\uda36\udce9\ud963\udd5f\uda0d\udca2\ud929\udc16",
        10, 82340, -331157904, 2383779705325878677L, -2846L, true, true, (char) 42486, (char) 43493,
        Double.longBitsToDouble(0x3fd73ce6979a2b84L), Double.longBitsToDouble(0x3fd137ab68e9ed6eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\0121=void |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\012",
        Z.run(T, 2, 8, 8, 6, "\udb24\ude9d\udb24\udf53\ud9f5\udf85\uda0f\udd10\udbd0\udeff\udb6f\udff2", "\uad7b\uc3cf\u00ab\ub2eb\ubf2c", "\ud85f\udc74\ud83b\udd0c\uda65\udd10\udbde\udf5e\uda28\udffa\uda8f\uddd2\ud8ab\udc4a\ud94f\udecb\ud894\udee4\uda4b\udde2\ud80e\udf3b\ud8c2\udfdb\ud910\ude0f\u6132",
        32, 38541, -2055209560, 4950773205310562270L, 6200L, true, true, (char) 58579, (char) 34676,
        Double.longBitsToDouble(0x3fdb2b6c022689feL), Double.longBitsToDouble(0x3fd807d6cc709462L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\0121=void |this=com.google.javascript.jscomp.PeepholeOptimizationsPass:@?\012",
        Z.run(T, 2, 2, 2, 0, "", "", "\udb02\udfa4\uda68\udd04\uda51\udd2a\udbe1\udd2b\ud96a\ude8d\ud954\udd5b\ud994\udd40\udbd0\ude85\udaa0\udc8e\udb6e\ude74",
        56, 24986, 1771207135, 4611660295136884642L, 51281L, false, true, (char) 29872, (char) 19589,
        Double.longBitsToDouble(0x3fd655aa09f0a642L), Double.longBitsToDouble(0x3fec8585015bce02L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 9, "\ud966\udf8a\ud882\ude8b\ud9f5\udf5b\udb72\udedb\ud9e2\udef3\uda74\udf5d\udacc\udd08", "\ub274\ud10d\u55cd\u9f77\u07dc\u776e\u2b1e\u4c08", "\udb2d\udf3d\uda8f\udde0\ud8ab\udc4a\ud94b\udfcb\udbe0\ude48\udbfd\udce2\ud963\udd5f\uda0d\udca2\ud929\udc16",
        10, 82351, -331212176, 5914601813184347541L, -2846L, true, true, (char) 42486, (char) 37244,
        Double.longBitsToDouble(0x3fd73cea879a2b84L), Double.longBitsToDouble(0x3fd137ab68e9ed6eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.PeepholeOptimizationsPass|traverse|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeOptimizationsPass:com.google.javascript.jscomp.AbstractCompiler,[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;",
    "M|com.google.javascript.jscomp.PeepholeOptimizationsPass|beginTraversal||new:com.google.javascript.jscomp.PeepholeOptimizationsPass:com.google.javascript.jscomp.AbstractCompiler,[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;",
    "M|com.google.javascript.jscomp.PeepholeOptimizationsPass|endTraversal||new:com.google.javascript.jscomp.PeepholeOptimizationsPass:com.google.javascript.jscomp.AbstractCompiler,[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;",
    "M|com.google.javascript.jscomp.PeepholeOptimizationsPass|exitNode|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeOptimizationsPass:com.google.javascript.jscomp.AbstractCompiler,[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;",
    "M|com.google.javascript.jscomp.PeepholeOptimizationsPass|getCompiler||new:com.google.javascript.jscomp.PeepholeOptimizationsPass:com.google.javascript.jscomp.AbstractCompiler,[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;",
    "M|com.google.javascript.jscomp.PeepholeOptimizationsPass|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeOptimizationsPass:com.google.javascript.jscomp.AbstractCompiler,[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;",
    "M|com.google.javascript.jscomp.PeepholeOptimizationsPass|shouldRetraverse|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeOptimizationsPass:com.google.javascript.jscomp.AbstractCompiler,[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;",
    "M|com.google.javascript.jscomp.PeepholeOptimizationsPass|shouldVisit|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeOptimizationsPass:com.google.javascript.jscomp.AbstractCompiler,[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;",
    "M|com.google.javascript.jscomp.PeepholeOptimizationsPass|visit|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeOptimizationsPass:com.google.javascript.jscomp.AbstractCompiler,[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;",
    "C|com.google.javascript.jscomp.PeepholeOptimizationsPass|<init>|com.google.javascript.jscomp.AbstractCompiler,[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;",
    "M|com.google.javascript.jscomp.PeepholeOptimizationsPass|traverse|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeOptimizationsPass:com.google.javascript.jscomp.AbstractCompiler,[Lcom.google.javascript.jscomp.AbstractPeepholeOptimization;",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
