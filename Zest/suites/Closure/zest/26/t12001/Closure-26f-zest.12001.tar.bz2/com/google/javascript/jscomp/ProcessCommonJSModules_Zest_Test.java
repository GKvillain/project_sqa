package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class ProcessCommonJSModules_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:module$\u1670\u1e3c\ubb1c\u2468\uc62f\u32d9\uc8ae\ub9ad\ub998\u6aac\u63a0 |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=java.lang.String:module$\u8ba3\udb68\udfad\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\ud927\udcc0\udb88\udcc0\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\udad9\udce0\uda8d\udc41\ud92c\udee2\udb10\udf8f\udbb5\udd7a\ud879\udcd5\012",
        Z.run(T, 2, 1, 5, 4, "\u8ba3\udb68\udfad\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\ud927\udcc0\udb88\udcc0\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\udad9\udce0\uda8d\udc41\ud92c\udee2\udb10\udf8f\udbb5\udd7a\ud879\udcd5", "\u1670\u1e3c\ubb1c\u2468\uc62f\u32d9\uc8ae\ub9ad\ub998\u6aac\u63a0", "\ud8b6\udf43\udb56\udf17\ud8be\udf6a\u1eb6\ud887\udecb\ud9b1\udfc6\udb50\udd03\udaf8\uddf2\ud930\udd80\u7035\ud9ec\udef5",
        28, 92297, -1681892104, -4940534793452845645L, -63335L, false, false, (char) 49503, (char) 63330,
        Double.longBitsToDouble(0x3fe564d846614f62L), Double.longBitsToDouble(0x3fd25d8de802fe02L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:module$\u1670\u1e3c\ubb1c\uadd0\uc62f\u32d9\uc8ae\ub9ad\ub998\u6aac\u63a0 |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=java.lang.String:module$\u8ba3\udb68\udfad\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\ud927\udcc0\udb88\udcc0\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\udad9\udce0\uda8d\udc41\ud92c\udee2\udb10\udf8f\udbb5\udd7a\ud879\udcd5\012",
        Z.run(T, 2, 1, 5, 4, "\u8ba3\udb68\udfad\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\ud927\udcc0\udb88\udcc0\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\udad9\udce0\uda8d\udc41\ud92c\udee2\udb10\udf8f\udbb5\udd7a\ud879\udcd5", "\u1670\u1e3c\ubb1c\uadd0\uc62f\u32d9\uc8ae\ub9ad\ub998\u6aac\u63a0", "\ud8b6\udf43\udb56\udf17\ud8be\udf6a\u1eb6\ud887\udecb\ud9b1\udfc6\udb50\udd03\udaf8\uddf2\ud930\udd80\u7035\ud9ec\udef5",
        28, 92297, -1681892104, -4940534793452845645L, -63335L, false, false, (char) 49503, (char) 63330,
        Double.longBitsToDouble(0x3fe564d846614f62L), Double.longBitsToDouble(0x3fd25d8de802fe02L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 4, "\u8ba3\udb43\udcad\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\uda50\ude48\ud8cb\udfa2\000\ud809\udca4\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\udad9\udce0\uda8d\udc41X\udb16\udd0b\udbb5\udd7a\ud879\udcd5", "\u1670\u1e3c\ubae7\u2468\uc62f\u32d9\uc8ae\u56b7\ub89e\uaf64\uaa8a", "\uda0e\udd6f\uda26\udd93\udb22\udf5c\u1eb6\ud887\udecb\ud9b1\udfc6\udb50\udd03\udaf8\uddf2\ud930\udd80\u7035\ud9ec\udef5",
        28, 92297, 23800, -4940534793452845645L, -63335L, false, false, (char) 49503, (char) 63330,
        Double.longBitsToDouble(0x3fe004d846000062L), Double.longBitsToDouble(0x3fd25d8de802fe02L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 4, "\u8ba3\udb68\udfad\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\ud927\udcc0\udb88\udcc0\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\udad9\udce0\ud8e4\udecc\ud92c\udf28\udb10\udf8f\udbb5\udd7a\ud879\udcd5", "\u1670\u1e3c\ubb1c\u2468\u0f3a\u2796\uc8ae\ub9ad\ub998\u6aac\u63a0", "\ud8b6\udf43\udb56\udf17\ud8be\udf6a\u1eb6\ud887\udecb\ud9b1\udfc6\udb50\udd03\udaf8\uddf2\ud930\udd80\u7035\ud9ec\udef5",
        28, 92297, -1681892104, -4940534793452845645L, -63335L, false, false, (char) 49503, (char) 63330,
        Double.longBitsToDouble(0x3fe564d846614f62L), Double.longBitsToDouble(0x3fd25d8de802fe02L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:module$\u1670\u1e3c\u911d\u2468\uc62f\u32d9\uc8ae\ub9ad\ub998\u6aac\u63a0 |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=null |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 2, 1, 0, 5, "\ud81c\udf5f\u091c\ud8ea\udfdc\udaff\udef2\ud9b8\udeb6\ud912\udd9d\uda21\udc19\ud9e0\udcc1\ud8fc\udcdb\ud9e0\udfb9\ud917\udfca\ud860\ude86\ud8c8\udc16\ud94a\udf07\ud900\udc96\uda57\udcdf\uda8d\udc41\ud92c\udee2\udb10\udf8f\udbb5\udd7a\ud879\udcd5", "\u1670\u1e3c\u911d\u2468\uc62f\u32d9\uc8ae\ub9ad\ub998\u6aac\u63a0", "\ud8b6\udf43\udb56\udf17\ud8be\udf6a\u1eb6\ud887\udecb\ud9b1\udfc6\udb50\udd03\udaf8\uddf2\ud969\udc5e\udae3\uddff\ufe52",
        -2, 6496, -1681858891, 3192330615849470414L, -63335L, false, false, (char) 49503, (char) 8136,
        Double.longBitsToDouble(0x3fec9de346614f62L), Double.longBitsToDouble(0x3fd25d8de802fe02L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=new com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 2, 0, 6, 2, "\u8ba3\udb68\udfad\udaa5\udfe7\ud93f\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\ud927\udcc0\udb88\udcc0\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud8c8\udc16\ud8bb\udf88\ud904\udcad\udacb\udf44\uda81\uddc4\ud92c\udee2\udb10\udf8f\udbb5\udd7a\ud879\udcd5", "\u1670\u1e3c\ubb1c\u2468\uc62f\ub0e2\uc8ae\ub995\ub998\u6aac\u63a0", "\ud8b6\udf43\uda9e\uddfb\udb13\ude54\ud84f\udfec\ud9ca\udd65\uda4d\ude70\ud9c8\udc36\udaf8\ude12\udaef\ude60\u7035\ud9ec\udf12",
        28, 92297, -1681892104, -4940534793452845645L, -63335L, false, false, (char) 49503, (char) 63330,
        Double.longBitsToDouble(0x3fe564d846614f62L), Double.longBitsToDouble(0x3fd25d8de802fe02L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=new com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 2, 6, 6, 3, "\u8ba3\udb68\udfad\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\ud927\udcc0\udb88\udcc0\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud85a\udccb\ud94a\udf07\ud900\udc96\udad9\udce0\uda8d\udc41\ud92c\udee2\udb10\udf8f\udbb5\udd7a\ud879\udcd5", "\u1670\u1e3c\ubb1c\ub3e1\uc62f\u32d9\uc8ae\ub9ad\ub998\u6aac", "\ud9e6\ude47\ud8b6\udf43\udb56\udf17\ud8be\udf6a\u1eb6\ud887\udecb\ud9b1\udfc6\udb50\udd03\udaf8\uddf2\ud930\udd80\u7035\ud820\udeef\udba6\udd50\udab4\udd70",
        51, 81104, 197723571, 6214902272184542293L, 88338L, false, false, (char) 4533, (char) 61204,
        Double.longBitsToDouble(0x3fec076914017f8eL), Double.longBitsToDouble(0x3fee20f30d8d3c25L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:module$\u8ba3\udb68\udfad\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\ud927\udcc0\udb88\udcc0\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\udad9\udce0\uda8d\udc41\ud92c\udee2\udb10\udf8f\udbb5\udd7a\ud879\udcd5\0121=java.lang.String:module$\u8ba3\udb68\udfad\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\ud927\udcc0\udb88\udcc0\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\udad9\udce0\uda8d\udc41\ud92c\udee2\udb10\udf8f\udbb5\udd7a\ud879\udcd5\012",
        Z.run(T, 2, 5, 5, 4, "\u8ba3\udb68\udfad\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\ud927\udcc0\udb88\udcc0\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\udad9\udce0\uda8d\udc41\ud92c\udee2\udb10\udf8f\udbb5\udd7a\ud879\udcd5", "\u1670\u1e3c\ubb1c\u2468\uc62f\u32d9\uc8ae\ub9ad\ub998\u6aac\u63a0", "\ud8b6\udf43\udb56\udf17\ud8be\udf6a\u1eb6\ud887\udecb\ud9b1\udfc6\udb50\udd03\udaf8\uddf2\ud930\udd80\u7035\ud9ec\udef5",
        28, 92297, -1681892104, -4940534793452845645L, -63335L, false, false, (char) 49503, (char) 63330,
        Double.longBitsToDouble(0x3fe564d846614f62L), Double.longBitsToDouble(0x3fd25d8de802fe02L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:module$\u1670\u1e3c\ubb1c\u2468\uc62f\u32d9\uc8ae\ub9ad\ub998\u6aac\u63a0 |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 0, "\u8ba3\udb68\udfad\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\ud927\udcc0\udb88\udcc0\ud924\udf9f\ud9ee\ude01\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\udad9\udce0\uda8d\udc41\ud92c\udee2\udb10\udf8f\udbb5\udd7a\ud879\udcd5", "\u1670\u1e3c\ubb1c\u2468\uc62f\u32d9\uc8ae\ub9ad\ub998\u6aac\u63a0", "\ud8b6\udf43\udb56\udf17\ud8be\udf6a\u1eb6\ud887\udecb\ud9b1\udffb\udb50\udd03\udaf8\uddf2\ud930\udd80\u7035\ud9ec\udef5",
        28, 92297, -1681892104, -4940534793452845797L, -63335L, false, false, (char) 49503, (char) 63330,
        Double.longBitsToDouble(0x3fe564d846614f62L), Double.longBitsToDouble(0x3fd25d8de402fe02L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 1, 0, 6, 4, "\u8ba3\udb68\udfad\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\uda91\udf12\ud914\udc20\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\ud912\udfbe\ud984\ude01\udbce\udcbf\udb10\udf8f\udbb5\udd7a\ud879\udcd5", "\u50f5\u1e3c\ubb1c\u2468\uc62f\ud46d", "\ud8f5\udda0\uda78\udcca\udad6\udd03\ud9e9\udc8f\ud9e6\ude47",
        54, 1392, 1910783156, 6954289024310254475L, -4206L, false, true, (char) 20038, (char) 59969,
        Double.longBitsToDouble(0x3feb2f43c44df89cL), Double.longBitsToDouble(0x3fe14d36bcf8afe8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 4, "\u8ba3\udb68\udfad\udaa5\udfe7\udaff\udf3b\ud934\udfad\ud916\uddda\uda20\udfb6\ud927\udcc0\udb88\udcc0\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\udad9\udce0\uda8d\udc41\ud92c\udee2\u0eab\ud824\ude68\ua56d", "\u1670\u1e3c\ubb1c\u2468\uc62f\u32d9\uc8ae\ub9ad\ub998\u5c74\u05ba", "\ud8b6\udf43\ud908\udeb9\uda11\udf04\ud899\udc1e\ud887\udecb\udb1b\udfbb\udb50\udd03\udaf8\uddf2\ud930\udd80\u7035\ud9ec\udef5",
        28, 1705, 574769790, -4940534570114546253L, 2201L, false, false, (char) 49503, (char) 63330,
        Double.longBitsToDouble(0x3fbd31b9330a7b10L), Double.longBitsToDouble(0x3fd25d8de802fe02L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:module$\u05a2\u4e7f\ud41a\ua1da\u4903\u83c0\ucfd5\u4f6e\u3ebc\u1814\u65bf\ud0f5\u198d\u1670\u1e3c\ubb1c |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=java.lang.String:module$\udada\uded5\udb51\udc70\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\ud927\udcc0 |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 2, 1, 1, 2, "\udada\uded5\udb51\udc70\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\ud927\udcc0", "\u05a2\u4e7f\ud41a\ua1da\u4903\u83c0\ucfd5\u4f6e\u3ebc\u1814\u65bf\ud0f5\u198d\u1670\u1e3c\ubb1c", "\udb22\udc67\ud95d\udd07\u052d\ud90e\udf6e\uda70\udf6e\udad6\udc45\ud9e9\udc8f\ud9e6\ude47",
        17, 1392, 1910783156, 6954289024310254475L, 61330L, false, true, (char) 20038, (char) 59969,
        Double.longBitsToDouble(0x3feb2f43c64df89cL), Double.longBitsToDouble(0x3fe14d36bcf8afe8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 3, 4, "\u8ba3\udb68\udfad\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\ub45e\000\udb88\udcc0\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\udad9\udce0\ud92b\udf70\000\000\udbb5\udd10\ud879\udcd5", "\u1670\ubc21\u2235\000\uc62f\u32d9\uc8ae", "\uda78\udcca",
        49, 95653, -404229197, 2279359508898161024L, 70246L, true, true, (char) 26766, (char) 29329,
        Double.longBitsToDouble(0x3feb93d2cbce2a78L), Double.longBitsToDouble(0x3fd9860aa00000f0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:module$\u8ba3\ud98d\udf30\udaa5\udfb2\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\udb57\udf05\udb88\udcc0\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\udad9\udce0\uda92\udc41\ud8ac\udd80\udb10\udf8f\udbb5\udd7a\ud8af\udcd5\012",
        Z.run(T, 1, 4, 5, 4, "\u8ba3\ud98d\udf30\udaa5\udfb2\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\udb57\udf05\udb88\udcc0\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\udad9\udce0\uda92\udc41\ud8ac\udd80\udb10\udf8f\udbb5\udd7a\ud8af\udcd5", "\u1670\u571a\uc236\u87ac\ud317\u32e9\u5780\ud0b5\u5690\u9351w", "\ud8b6\udf43\udb56\udf17\ud8be\udf6a",
        5, 19835, -389826267, 8816229264123287410L, -64766L, false, true, (char) 60137, (char) 55552,
        Double.longBitsToDouble(0x3fcb516967226c28L), Double.longBitsToDouble(0x3fdb3bb6fd601792L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=null |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 2, 0, 0, 5, "\u8ba3\udb68\udfad\udad1\udfe7\ud90f\udd02\ud9c6\uddb6\ud912\udd9d\uda20\udfb6\ud927\udcc0\udb88\udcc0\udb42\udd11\ud862\ude32\ud99d\udd33\udb83\udc55\ud94a\udec0\ud900\udc96\udad9\udce0\uda99\udd41\ud952\uddd5\ud9f1\ude95\udb65\udd3b\udaf1\udea4", "\u9753\u59c1\ubb1c\u2468\uc62f\u32d9\ud3f2\u08a8\uc11b\ub49c\ua770", "\ud965\udf45\uda11\udd9d\ud958\uddee\u1f06",
        49, 84456, -205086432, -6919984579076218609L, -61559L, false, false, (char) 30523, (char) 36251,
        Double.longBitsToDouble(0x3fe584992f392283L), Double.longBitsToDouble(0x3fdfb86a809d4222L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:module$\u1670\u1e3c\ubb1c\u2468\uc62f\u32d9\uc8ae\ub9ad\ub998\u6aac\u63a0 |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=java.lang.String:module$\u8ba3\udb68\udfad\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\ud927\udcc0\udb88\udcc0\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\udad9\udce0\uda8d\udc41\ud92c\udee2\udb10\udf8f\udbb5\udd7a\ud879\udcd5\012",
        Z.run(T, 2, 1, 5, 4, "\u8ba3\udb68\udfad\udaa5\udfe7\udaff\udf3b\ud9b8\udeb6\ud912\udd9d\uda20\udfb6\ud927\udcc0\udb88\udcc0\udb60\udce0\uda6d\udcf7\ud9c6\ude79\ud8c8\udc16\ud94a\udf07\ud900\udc96\udad9\udce0\uda8d\udc41\ud92c\udee2\udb10\udf8f\udbb5\udd7a\ud879\udcd5", "\u1670\u1e3c\ubb1c\u2468\uc62f\u32d9\uc8ae\ub9ad\ub998\u6aac\u63a0", "\ud8b6\udf43\udb56\udf17",
        56, 39590, -1352066165, -1674291065834075698L, 40238L, false, true, (char) 5086, (char) 40681,
        Double.longBitsToDouble(0x3fe14d36bcf8afe8L), Double.longBitsToDouble(0x3fdc89bc0b6776deL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=java.lang.String:module$\ud81c\udeed$\012",
        Z.run(T, 2, 0, 4, 1, "\ud81c\udeed/", "", "\uda21\udc19",
        41, -1000, -1040187392, -4086986830709413749L, -99834L, false, false, (char) 45229, (char) 41436,
        Double.longBitsToDouble(0x3fb6329680000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=new com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 2, 0, 6, 6, "\ud81c\udeed/", "", "\uda21\udc19",
        41, -1000, -1040187392, -4086986830709413749L, -99834L, false, false, (char) 45229, (char) 41436,
        Double.longBitsToDouble(0x3fb6329680000000L), Double.longBitsToDouble(0x3d9e800000000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=java.lang.String:module$ |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 2, 0, 1, 4, "\ud896\udc39/", "\u4220", "\ud9e0\udcc1\000\uda71\udc58\ud917\udfca\ud860\ude86\ud8c8\udc16\ud849\udf69\udb2d\udc41\uda57\udcdf\uda90\udf92\udaa0\udc32",
        7, -1000, 598016000, -5502666147503459341L, -23990L, true, true, (char) 8780, (char) 50115,
        Double.longBitsToDouble(0x3fe41d80a2310584L), Double.longBitsToDouble(0x3fef93b46ad94c33L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.ProcessCommonJSModules|getModule||new:com.google.javascript.jscomp.ProcessCommonJSModules:com.google.javascript.jscomp.AbstractCompiler,java.lang.String",
    "M|com.google.javascript.jscomp.ProcessCommonJSModules|guessCJSModuleName|java.lang.String|new:com.google.javascript.jscomp.ProcessCommonJSModules:com.google.javascript.jscomp.AbstractCompiler,java.lang.String",
    "M|com.google.javascript.jscomp.ProcessCommonJSModules|normalizeSourceName|java.lang.String|new:com.google.javascript.jscomp.ProcessCommonJSModules:com.google.javascript.jscomp.AbstractCompiler,java.lang.String",
    "M|com.google.javascript.jscomp.ProcessCommonJSModules|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ProcessCommonJSModules:com.google.javascript.jscomp.AbstractCompiler,java.lang.String",
    "M|com.google.javascript.jscomp.ProcessCommonJSModules|toModuleName|java.lang.String|static",
    "M|com.google.javascript.jscomp.ProcessCommonJSModules|toModuleName|java.lang.String,java.lang.String|static",
    "C|com.google.javascript.jscomp.ProcessCommonJSModules|<init>|com.google.javascript.jscomp.AbstractCompiler,java.lang.String",
    "C|com.google.javascript.jscomp.ProcessCommonJSModules|<init>|com.google.javascript.jscomp.AbstractCompiler,java.lang.String,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
