package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeCheck_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 14, 7, "\udada\udd97\ud95b\udf54\ud8fd\ude46\uda90\uded9\ud84c\udcaa\udab4\ude55\ud8f8\udeb4\u3f48\udb85\udfe8\udb63\udffa\ud87e\udf41\ud834\udfc0\udba9\udd5b\udb0d\udcab\ud835\udf86\ud84b\udc3d\ud96e\udc60\udb22\udd82\ud8d4\udc3b\ud954\ude7b\udaf9\ude9b\udb51\udcf0\udb7c\udd75\uda6b\udcd2\ud967\udfc8\uda11\udedf\ud849\udcd4\ud82d\udcfc\ud9ee\ude72\ud997\udf5c\ud9e5\udfed\udb43\udfc5\ud82d\udfdb\ud9ed\udc77", "\u9a36\u9db1\u0a94\uaa6d\u0a5f\uae78\u72f3\u2a63\ucddd\u7e02\ubd66\u0b66\ua2a7", "\ud8b6\udd2e\ud902\udf2a\ud800\udd16",
        5, 21006, -863000002, 8563238469766036877L, -4162L, true, false, (char) 53917, (char) 26175,
        Double.longBitsToDouble(0x3fe5205edd3b9f8bL), Double.longBitsToDouble(0x3fdb1d99695ec07eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 14, 15, "\udacd\udf64", "\u4fe8\u1757\u609e\u7873\ub00b\ucd22\u2d95\u3142\u3a2d\u06db\u4f89\ub1fc\u67ed\u35d4\u3733\u2895\u9087\ubfb5\u058d\u7138\u474a\u09b8\ub6f3", "\ud9d0\udca2\ud997\udf5c\ud9e5\udfed\udb43\udfc5",
        8, 89837, 182574902, -5975386154037639981L, -63047L, false, true, (char) 53945, (char) 7975,
        Double.longBitsToDouble(0x3fc55c8bb4264decL), Double.longBitsToDouble(0x3fde30b567a13682L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 14, 7, "\udada\udd97\ud95b\udf54\ud8fd\ude46\ud886\udd37\ud84c\udcaa\udab4\ude55\ud8f8\udeb4\u3f48\udb85\udfe8\udb63\udffa\ud87e\udf41\ud834\udfc0\udba9\udd5b\udb0d\udcab\ud835\udf86\ud84b\udc3d\ud96e\udc60\udb22\udd82\ud8d4\udc3b\ud954\ude7b\udaf9\ude9b\udb51\udcf0\udb7c\udd75\uda6b\udcd2\ud967\udfc8\uda11\udedf\ud849\udcd4\ud82d\udcfc\ud9ee\ude72\ud997\udf5c\ud9e5\udfed\udb43\udfc5\ud82d\udfdb\ud9ed\udc77", "\u9a36\u9db1\u0a94\uaa6d\u0a5f\uae78\u72f3\u2a63", "\ud8ef\udf04\uda84\udc47\ud91a\udce3\ud956\udec5\ud8bb\udefb\ud8b6\udd2e",
        -5, 69982, 309142415, -7743087275406284226L, -18707L, false, false, (char) 48963, (char) 23632,
        Double.longBitsToDouble(0x3fcecb34f35325acL), Double.longBitsToDouble(0x3fee1cfedbc32bafL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 14, 7, "\ud882\uddeb\ud95b\udf54\ud8fd\ude46\uda90\uded9\ud84c\udcaa\ud8d1\udd44\ud8f8\udeb4\u3f48\udb85\udfe8\udb63\udffa\udad3\uddab\ud866\udf3d\udba9\uddd3\udb0d\udcab\ud835\udf86\ud84b\udc3d\ud96e\udc60\udb22\udd82\ud8d4\udc3b\ud954\ude7b\udaf9\ude9b\udb51\udcf0\udb7c\udd75\uda6b\udcd2\ud967\udfc8\uda11\udedf\ud8d5\ude79\ud82d\udcfc\ud9ee\ude72\ud997\udf5c\ud9e5\udfed\ud94e\udcfd\ud82d\udfdb\ud9ed\udc77", "\u9a36\u651e\u0a63\uaa6d\u0a5f\u4de7\u72f3\u7238\u4058\u7e9f\u864b\u0b66\u133f", "\ud8b6\udd8e\ud902\udf2a\ud800\udd16\udaa5\uddbd\udb56\udd06\udbd9\udf35\udb0b\ude05\ud912\udcae\uda57\udc17\ud8a2\udfbf\udb14\udd66\udafc\uddf9\ud9ee\udeb6\udb35\udcf4\ud9f2\udef7\ud808\udf5d",
        36, 6767, 544419743, 884660890781046130L, 45895L, false, false, (char) 56935, (char) 24175,
        Double.longBitsToDouble(0x3fd1e84a60c841f8L), Double.longBitsToDouble(0x3fa2cb74c96ebe50L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 14, 7, "\ud8fa\udf82\ud95b\udf9d\ud8fd\ude46\uda90\uded9\ud84c\udcaa\udab4\ude55\ud8f8\udeb4\u3f48\udb85\udfe8\udb63\udffa\ud87e\udf41\ud834\udfc0\udba9\udd5b\udb0d\udcab\ud835\udf86\ud84b\udc3d\ud96e\udc60\udb22\udd1d\ud8d4\udc3b\ud954\ude7b\udaf9\ude9b\udb51\udcf0\udb7c\udd75\uda6b\udcd2\ud967\udfc8\uda11\udedf\ud849\udcd4\ud82d\udcfc\ud9ee\ude72\ud975\ude2e\ud9e5\udfed\udb43\udfc5\ud82d\udfdb\ud9ed\udc77", "\u9a36\u9db1\u0a94\u5509\u0a5f\uae78\u72f3\u2a63\ucddd\u570e\ubd66\u0b66\ua2a7", "\udb20\udf43\ud902\udf47\ud800\udcc9",
        5, 21006, -863000002, 8563238469766036877L, -4162L, true, false, (char) 53917, (char) 26175,
        Double.longBitsToDouble(0x3fe5205edd3b9f8bL), Double.longBitsToDouble(0x3fdb1d99695ec07eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 14, 4, "\udada\udd97\ud95b\udf54\ud8fd\ude46\uda90\uded9\ud84c\udcaa\udac4\udfd4\udad2\udd7f\u3f48\udb85\udfe8\ud803\udf4b\udb5f\udeb6\ud835\udc77\udba9\udd5b\udb0d\udcab\ud835\udf66\ud84b\udc3d\ud96e\udc60\udb22\udd82\ud8d4\udc3b\ud954\ude7b\udaf9\ude9b\udb51\udcf0\udb7c\udce1\uda6b\udcd2\udbb9\udc11\ud924\ude0f\udaf8\udc9c\udbc8\udf2f\ud9ef\udf09\ud997\udf5c\uda00\udda4\udb43\udfc5\ud82d\udfdb\ud9ed\udc77", "\u9a36\u9db1\u5fab\uaa6d\u0a5f\uae78\u72f3\u2a63\ucddd\u7e02\ubd66\u0b66\ua2a7", "\ud97b\udff1\ua76f\ud8b0\udd4e",
        5, 54542, -863000002, 8504962648395703822L, -4162L, true, false, (char) 53917, (char) 26313,
        Double.longBitsToDouble(0x3fe5205ed83b9f8bL), Double.longBitsToDouble(0x3fe187f0d3ff8dd2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 14, 7, "\uda46\udcf3\ud9ff\ude7b\ud81d\udca0\u7f40\udbd1\udf7b\udab4\udece\ud8f8\udeb4\u3f48\udb85\udfe8\udb63\udffa\udaeb\udfb3\ud834\udfc0\ud95a\udc0a\udb0e\udf50\ud835\udf86\ud84b\udc3d\ud96e\udc60\udb22\udd82\ud8d4\udc3b\ud954\ude7b\udaf9\ude9b\udb51\udcf0\udb7c\udd75\ud862\udd93\ud967\udfc8\ud987\ude3b\ud8e7\udd8b\udb6e\udd03\uda03\udf72\ud997\udf5c\ud9e5\udfd1\udb43\udfc5\ud817\udcce\ud9ed\udc77", "\u9a36\u9db1\u92d1\ucba4\u0dc9\u985d\uc442\u1831\ucddd\u3113\ubd66\u2035\u485a", "\ud8b6\udd4b\ud902\udf2a\ud974\udf31\ud86c\udc59\udb56\udcd0\udbd9\udf35\udb72\udf05\ud925\udcd6\uda20\ude5d\udaec\udca5\uda41\udfc5\uda2f\uddbe\udb78\udec4\udb35\udcf4\ud9f2\udef7\ud9b1\udcd2\ud865\udf71\ud926\uded2\ud8a3\udfca\ud92c\udfce\udac1\udf82",
        55, 86826, -1423362081, 1970155715713013557L, -59126L, true, true, (char) 43234, (char) 26508,
        Double.longBitsToDouble(0x3fe51d30a7ddd946L), Double.longBitsToDouble(0x3fd9d33d7cb5c8b2L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 14, 6, "\udb96\uddb5\ud95b\udf3b\ud8fd\ude46\uda90\uded9\ud84c\udcaa\udab4\ude55\ud9c1\udf98\udbe1\uddf3\udb91\udc3c\uda7e\udd70\u6d2d\uf32a\udba9\udd5b", "\u558f\u35d4\ud732\u80e4\uac78\ua069\u6711\u540b\ua7aa\u5e85\ud4d3\ubeb2\u3a5c\uc3ee\u653c\u0ee7\u2faf\ub7ba\ua85e\ub41b", "\ud8c9\uded1",
        56, 60853, -527732825, 7934025730904465445L, -60675L, false, true, (char) 44001, (char) 54597,
        Double.longBitsToDouble(0x3fe8fe8863e679fbL), Double.longBitsToDouble(0x3fdbcccfca8a2a50L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.TypeCheck|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|check|com.google.javascript.rhino.Node,boolean|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkDeclaredPropertyInheritance|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.FunctionType,java.lang.String,com.google.javascript.rhino.JSDocInfo,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkEnumInitializer|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkInterfaceConflictProperties|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,java.lang.String,java.util.HashMap,java.util.HashMap,com.google.javascript.rhino.jstype.ObjectType|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkNoTypeCheckSection|com.google.javascript.rhino.Node,boolean|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkPropertyAccess|com.google.javascript.rhino.jstype.JSType,java.lang.String,com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|doPercentTypedAccounting|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|ensureTyped|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|ensureTyped|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|ensureTyped|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|getFunctionType|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|getJSType|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|getNativeType|com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|getTypedPercent||new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|hasUnknownOrEmptySupertype|com.google.javascript.rhino.jstype.FunctionType|static",
    "M|com.google.javascript.jscomp.TypeCheck|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
