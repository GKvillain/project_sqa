package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class CollapseProperties_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 6, "\ud9fe\uddff\udb15\udd03\ud809\udca1\ud89c\udeed\udbd6\ude60\udb3e\udd65", "\u89ba\u5f7a\ub9f8\uccb6\ua7e9\ub0f6\u8ef6\ubcd1\u8fd3\uc5e6", "\ud9d4\udfcd\ud818\ude66\udb3c\udc0b\udb93\uddf0\udb12\udeeb\ud89d\udf0f\ud9e3\udff3",
        54, 14747, -404624430, -4145097661045139860L, -43195L, true, true, (char) 65519, (char) 37065,
        Double.longBitsToDouble(0x3fea7562bc759f18L), Double.longBitsToDouble(0x3fe5a6abd1be70d1L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 6, "\ud9fe\uddff\udb15\udd03\ud809\udca1\ud89c\udeed\udbd6\ude60\udb3e\udd65", "\u89ba\u5f7a\ub9f8\uccb6\ua7e9\ub0f6\u8ef6\ubcd1\ucaff\u0652", "\ud9d4\udfcd\uda3b\udfd9\udb3f\ude10\udb93\uddf0\udb12\udeeb\ud89d\udf0f",
        10, 57534, -315710253, -1737848694977747036L, -19715L, true, true, (char) 37065, (char) 13221,
        Double.longBitsToDouble(0x3fbd67c615a6abd0L), Double.longBitsToDouble(0x3fdbe70d1424845aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 8, 6, "\ud9fe\uddff\ud953\udd02\ud809\udca1\ud89c\udeed\udbd6\ude60\ud9bb\ude04", "\u89ba", "\udaae\udd67\uda94\udcc0\udb11\ude09",
        33, 37892, 74021529, -8987124674539898985L, 36263L, true, true, (char) 54068, (char) 25685,
        Double.longBitsToDouble(0x3fe67ced8cea01e8L), Double.longBitsToDouble(0x3fc4b394f8bac170L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 5, 6, "\ud9fe\uddff\udb15\udd03\ud809\udca1\ud89c\udeed\udbd6\ude60\udb3e\udd65", "\u89ba\u338c\ub9f6\uccb6\ua7e9\ub0f6\u8ef6\ubcd1\u0446\uc573", "\ud9d4\udfcd\ud818\ude66\udb3c\udc0b\udb2d\udf62\ud868\udd02\ud89d\udf0f\ud9e3\udff3",
        32, 14747, -404624430, -4145097661045139860L, -51725L, false, false, (char) 55, (char) 37065,
        Double.longBitsToDouble(0x3fea7562bd54a218L), Double.longBitsToDouble(0x3fccaf12c2cd6860L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 8, 6, "\ud9fe\uddff\udb15\udd03\ud809\udca1\ud89c\udeed\udbd6\ude60\udb3e\udd65\ud8a7\udc4f\u3703\uda14\udc84\udb6b\udc9b\u45d9\udaa2\udf67\uda94\udcc0\udb11\ude09\ud82a\udd4c\udb3a\udd29\uda24\udedb\ud967\udea1\u8da0\udae4\ude8f\udbff\udee9\udb56\ude13\ud926\udfe4\ud9fa\udc20\udb12\udeeb\ud89d\udf0f\ud9e3\udff3\udbc9\udf2c\ud832\udfb7\ud864\ude66\ud863\udc40\u3ff2\udbc3\udc5e\ud8ab\udfde\udbe1\udd85", "\u0474\u1a0fk\u8463\u49e6\u8d3a\ua22a\u4bb5", "\uda06\udf66\ud896\udfc2\ud9a3\udd96\ud933\udc34\ud9c6\udc6c\ud946\uddd0\uda9e\ude95\ud8d6\udd67\ud8f7\udc32\ud90f\udf60\ud897\udc3d\udbed\ude5d\ud8d9\udcb7\ud930\ude31\ud888\udec1\udb3e\udf53",
        49, -80, 2098858363, -7669975926194590389L, 44847L, false, true, (char) 65093, (char) 40205,
        Double.longBitsToDouble(0x3fd1eb2274c87604L), Double.longBitsToDouble(0x3fe01b5d8e07dcb7L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 8, 6, "\ud9fe\uddff\udb15\udd03\uda97\ude37\udb32\udd8b\udbd6\udeed\udb3e\udd65", "\u89ba\u5f7a\ub9f8\uccb6\ua7e9\ucdc4\u6013\u77a2\u0bee\uc5e6", "\ud9d4\udfcd\ud818\ude66\udb3c\udc0b\udb93\udd6e\udb12\udeeb\ud89d\udf0f\ud9e3\udff3",
        53, 14747, 177204178, -5380243119917099330L, -92458L, false, true, (char) 43817, (char) 41615,
        Double.longBitsToDouble(0x3fb1324c1fdcecb0L), Double.longBitsToDouble(0x3fe6b2048ccae5dbL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 6, "\ud9fe\uddff\udb15\udd03\ud809\udca1\ud89c\udf5a\udbd6\ude60\ud8e0\udc56", "\u89ba\u5f7a\ub9f8\uccb6\ua7e9\ub0f6\u8ef6\ubcd1\u8fd3\uc5e6", "\uda02\udc57\udb48\ude52\udb3c\udc0b\udb93\uddf0\udb12\udeeb\ud89d\udf0f\ud87c\ude9e",
        51, 18616, 1787930164, -4145097480656513428L, -43195L, true, true, (char) 34376, (char) 37065,
        Double.longBitsToDouble(0x3fea7562bc759f18L), Double.longBitsToDouble(0x3fe5a6abd1be70d1L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:\ud9fe\uddff\udb15\udd03\ud809\udca1\ud89c\udeed\udbd2\udd60\udb3e\udd65$\u89ba\u3dd4\ub9f8\uccb6\ua7e9\ub0f6\u8ef6\ub18f\u9a74\uc5e6\012",
        Z.run(T, 1, 2, 8, 6, "\ud9fe\uddff\udb15\udd03\ud809\udca1\ud89c\udeed\udbd2\udd60\udb3e\udd65", "\u89ba\u3dd4\ub9f8\uccb6\ua7e9\ub0f6\u8ef6\ub18f\u9a74\uc5e6", "\ud9d4\udfcd\ud818\ude66\udb3c\udc0b",
        22, 31847, -1666757398, -5738680332175621057L, 36238L, false, false, (char) 12466, (char) 62084,
        Double.longBitsToDouble(0x3fde5432433a42f8L), Double.longBitsToDouble(0x3fd974259b4cf446L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 6, "\ud9fe\uddff\udb15\udd03\ud809\udca1\ud89c\udeed\udbd6\ude60\udb3e\udd65", "\u89ba\u5f7a\ub9f8\uccb6\ua7e9\ub0f6\u8ef6\ubcd1\u8fd3\uc5e6", "\ud9d4\udfcd\ud818\ude66\udb3c\udc0b\udb93\uddf0\udb12\udeeb\ud89d\udf0f\ud9e3\udff3",
        54, 14760, -404624430, -5458400528749160852L, 38572L, false, true, (char) 31952, (char) 39076,
        Double.longBitsToDouble(0x3fd4482bc8d4bd14L), Double.longBitsToDouble(0x3f96fe30f3b77460L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 2, 6, "\ud9fe\uddff\udb15\udd03\ud809\udca1\ud89c\udeed\udbd6\ude60\udb3e\udd65", "\u89ba\u5f7a\ub9f8\uccb6\ua7e9\ub0f6\u8ef6\ubcd1\u8fd3\uc5e6", "\ud9d4\udfcd\ud818\ude66\udb3c\udc0b\udb93\uddf0\udb12\udeeb\ud89d\udf0f\ud9e3\udff3",
        54, 14747, -404624430, -4145097661045139860L, -43195L, true, true, (char) 65519, (char) 54985,
        Double.longBitsToDouble(0x3fea75621c759f18L), Double.longBitsToDouble(0x3fe5a6abd1be70d1L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 0, 6, "\ud9fe\uddff\udb2c\udc6e\uda56\udc6d", "\u6dfe\ua19b\u9e24\u0b9e\u025b\uba14\u03b2\ua7e9\ub0f6\ua837\u7713\u0a32\uc62a\u61d8\u0e30\u0ff3", "\udb93\uddf0\ud804\udcf6\udb57\udcc0\ud9e3\udff3\udbc9\udf2c\ud832\udfb7\udab8\udef6\ud9d5\ude17\u4030\udbc3\udc5e\ud884\udcde\udbe1\udd85\u20c4",
        38, 13550, -713409419, 8129340046623781310L, 43680L, false, false, (char) 8364, (char) 22037,
        Double.longBitsToDouble(0x3fd5663afaca5628L), Double.longBitsToDouble(0x3fe04f3df258b03dL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 8, 6, "\ud9fe\uddff\udb15\udd03\ud809\udca1\ud89c\udeed\udbd6\ude60\udb3e\udd65", "\u459c\u70be\ub9f8\uccb6\ua7e9\ub0ab\u8ef6\ubcdf\ucdc1", "\ud9bd\udf6a\uda69\udd2a\ud818\udf32\udb3c\udc0b\udb82\udfd1\udb12\udeeb\ud89d\udf0f\ud9e3\udff3\udbc9\udf2c\ud832\udfb7\ud93c\udc13\ud863\udc40\u3ff2\udbc3\udc5e\ud8ab\udfde\udbe1\udd85\uda97\udcc9",
        1, 13652, -713409419, 8129528064761278910L, 20989L, false, true, (char) 28848, (char) 52961,
        Double.longBitsToDouble(0x3fd780b0701450e6L), Double.longBitsToDouble(0x3fd6812d949f2080L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 8, 6, "\ud9fe\uddff\udb15\udd03\ud809\udca1\ud89c\udeed\udbd6\ude60\udb3e\udd65\ud8a7\udc4f\ud8c8\udd5f\uda14\udcb9\udb6b\udc9b\ud886\uded4\udaae\udd67\uda94\udcc0\udb11\ude09\ud82a\udd4c\udb3a\udd29\uda24\udedb\ud960\ude5f\u8e11\udadb\udf79\ud9d4\udfcd\ud818\ude66\udb3c\udc0b\udb93\uddf0\udb12\udeeb", "\u0cfa\ubced", "\u3ff2\udbc3\udc5e\ud8ab\udfde\udbe1\udd85\uda97\udcc9\udb68\uddb7\udae6\ude10\ud9cc\uddef\ud808\udd5a\udaac\udfc6\ud8b7\udf9a\ud864\udd83\ud811\ude75\ud90f\uddab\udaa1\udde3\udae6\udcef\uda3c\udead\udae0\udcde\u5225\udb65\udfca\udb29\udeda\ud8cf\udcc6\ud970\udee9\udb08\udd4b\ud967\udf0d\udaa3\udd7f\ud9c2\ude9f\ud9be\udfa6\ud8bd\udd56\uda18\udecd\uda80\udf3f\uda95\udced\ud8ad\udde1\udb3b\udff8",
        -3, 47199, 477839492, 7274786769618462716L, 60261L, true, false, (char) 46557, (char) 21445,
        Double.longBitsToDouble(0x3fe7b155eab944b3L), Double.longBitsToDouble(0x3fd2bf1bed6bd728L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 8, 6, "\ud9fe\uddff\udb15\udd03\ud908\udc9c\ud89c\udeed\udbd6\ude60\udb3e\udd65", "\u070f\u05f3\ub9f8\u3fb7\u77c0\ub0f6\u0d30\ubcc6\uae58\uc5e6\u61d8\u0e30\u6b9f\u7fe2\u03e4\u9738\ub511\ud72a\u1e41\u2151\u5e85\u5f3c", "\udbc3\udc5e\ud8ab\udfde\ud864\ude4c\ud8b5\udcec\ud8c3\udc0a\ud8ac\udec5\udaf1\udf93\ud808\udcce\ud86a\udf0d\ud841\udcd9",
        20, 28752, 871976413, 4440757803801065174L, 30379L, false, true, (char) 36510, (char) 11247,
        Double.longBitsToDouble(0x3fe6a59dfc2a1669L), Double.longBitsToDouble(0x3fbe60fc0feb65a8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\ud82a\udc00\ud946\udd02\ud9f2\ude36\u0c2d\ud967\ude72\ud9cd\ude92$\u6f25\uaa2c\u0098\ucc34\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 15, 0, "\ud82a\udc00\ud946\udd02\ud9f2\ude36\u0c2d\ud967\ude72\ud9cd\ude92", "\u6f25\uaa2c\u0098\ucc34", "\ud960\uddfa\udb4c\udd90\ud85e\udcf1\ud915\udd8d\u8e11",
        57, 47561, 703885239, -3794728985498325776L, 82738L, false, false, (char) 26922, (char) 8187,
        Double.longBitsToDouble(0x3fecd6ec5784e7d6L), Double.longBitsToDouble(0x3fe360156ebe1379L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:\ud9fe\uddff\ud953\udd02\ud809\udca1\ud89c\udeed\udbd6\ude60\ud9bb\ude04$\u89ba\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 6, "\ud9fe\uddff\ud953\udd02\ud809\udca1\ud89c\udeed\udbd6\ude60\ud9bb\ude04", "\u89ba", "\udaae\udc9a\uda94\udcc0\udb11\ude09",
        33, 60028, 74021529, -4663669035214698739L, 14042L, false, false, (char) 54068, (char) 45140,
        Double.longBitsToDouble(0x3fe67ced8cea01d9L), Double.longBitsToDouble(0x3fc4b394f9e52354L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:\ud82a\udc00\ud946\udd02\ud9f2\ude36\u0c2d\ud967\ude72\ud9cd\ude92$\u6f25\u5145\uc935\ucc97\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 0, "\ud82a\udc00\ud946\udd02\ud9f2\ude36\u0c2d\ud967\ude72\ud9cd\ude92", "\u6f25\u5145\uc935\ucc97", "\ud983\udcfa\udb4c\udd90\ud868\udcf1\ud915\udd8d\uda70\ude38",
        -1, 34393, 703885239, -3794728986588844816L, 82738L, false, false, (char) 26922, (char) 17659,
        Double.longBitsToDouble(0x3fd19893bc1f769aL), Double.longBitsToDouble(0x3fe36416e6be1379L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:\ud82a\udc00\ud946\udd02\ud9f2\ude36\ud84d\udcf1\ud9f9\udddb\ud9e0\udfa2$\u2a17\uaa2c\u05f7\u85a2\u1e62\ubc82\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 0, "\ud82a\udc00\ud946\udd02\ud9f2\ude36\ud84d\udcf1\ud9f9\udddb\ud9e0\udfa2", "\u2a17\uaa2c\u05f7\u85a2\u1e62\ubc82", "\udb66\udc5e",
        7, 8285, 1548653391, -3210939293926066374L, 3184L, false, true, (char) 21804, (char) 16673,
        Double.longBitsToDouble(0x3fe175839a762c5bL), Double.longBitsToDouble(0x3fc523102d6f927cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String:\ud82a\udc00\ud946\udd02\ud9f2\ude36\ud84c\uddb6\ud967\udf14\ud9cd\ude92$\u6f25\uaa2c\u0098\ucc34\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 4, "\ud82a\udc00\ud946\udd02\ud9f2\ude36\ud84c\uddb6\ud967\udf14\ud9cd\ude92", "\u6f25\uaa2c\u0098\ucc34", "\ud960\uddfa\ud832\udc63\udaaf\udd95\uf195\ud903\udd0f",
        57, 47561, -1460375625, 8649803421376333372L, 82738L, false, false, (char) 26922, (char) 36564,
        Double.longBitsToDouble(0x3fecd6ec8484e7d6L), Double.longBitsToDouble(0x3fe034af7ebe1379L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:\ud82a\udc00\ud946\udd02\ud9f2\ude36\udb74\udee4\ud967\uded4\ud9cd\ude92$\u6f25\uaa2c\u0098\ucc34\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 0, "\ud82a\udc00\ud946\udd02\ud9f2\ude36\udb74\udee4\ud967\uded4\ud9cd\ude92", "\u6f25\uaa2c\u0098\ucc34", "\ud960\uddfa\udb4c\udd90\ud85e\udcf1\ud915\udd8d\u8e11",
        57, 47561, 703885239, -3794728985498325776L, 82738L, false, false, (char) 26922, (char) 59732,
        Double.longBitsToDouble(0x3fecd6d04784e7d6L), Double.longBitsToDouble(0x3fe360156ebe1379L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:\ud82a\udc00\ud946\udd02\ud9f2\ude36\u0c2d\ud967\ude72\ud9cd\ude92$\u6f25\uaa2c\u0098\ucc34\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 0, "\ud82a\udc00\ud946\udd02\ud9f2\ude36\u0c2d\ud967\ude72\ud9cd\ude92", "\u6f25\uaa2c\u0098\ucc34", "\ud960\uddfa\udb4c\udd90\ud85e\udcf1\ud915\udd8d\u8e11",
        57, 47561, 703885239, -3794728985498325776L, -54154L, true, false, (char) 59018, (char) 22507,
        Double.longBitsToDouble(0x3fc523102d6f927cL), Double.longBitsToDouble(0x3fe94eec5784e7d6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:\ud9ab\udd1a\uda0b\udc59\ud9dc\udd36\ud914\udf49\ud958\udca5\udbd0\udea7$\u4386\ub9bb\uaf0f\u425a\ub6f0\u2cca\ua8ff\u1177\u5b12\u97f5\uc1b4\ubb14\uc566\u64c0\u9300\u9155\ud4aa\u00a6\u1c62\u0c9d\0121=java.lang.String:\ud9ab\udd1a\uda0b\udc59\ud9dc\udd36\ud914\udf49\ud958\udca5\udbd0\udea7$\u4386\ub9bb\uaf0f\u425a\ub6f0\u2cca\ua8ff\u1177\u5b12\u97f5\uc1b4\ubb14\uc566\u64c0\u9300\u9155\ud4aa\u00a6\u1c62\u0c9d\012",
        Z.run(T, 2, 2, 2, 0, "\ud9ab\udd1a\uda0b\udc59\ud9dc\udd36\ud914\udf49\ud958\udca5\udbd0\udea7", "\u4386\ub9bb\uaf0f\u425a\ub6f0\u2cca\ua8ff\u1177\u5b12\u97f5\uc1b4\ubb14\uc566\u64c0\u9300\u9155\ud4aa\u00a6\u1c62\u0c9d", "\udb92\udcb2",
        2, 90206, -158996884, -6943364220039496050L, -24621L, false, true, (char) 37564, (char) 35217,
        Double.longBitsToDouble(0x3fdbd8229fe110feL), Double.longBitsToDouble(0x3fad2d551521efa0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:\ud82a\udc80\ud946\udd02\ud9f2\ude36\u0c2d\ud967\ude72\ud8de\udd7a$\uc25d\u50c2\uc935\ucc97\u4da3\uc831\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 0, "\ud82a\udc80\ud946\udd02\ud9f2\ude36\u0c2d\ud967\ude72\ud8de\udd7a", "\uc25d\u50c2\uc935\ucc97\u4da3\uc831", "\uda0a\udde2\ud915\udd33\uda70\ude38\ud8da\ude44\ud9d2\ude7a\ud9a2\udf7a",
        25, 48016, -1626852988, 5295268120060000165L, 29654L, true, true, (char) 50112, (char) 47651,
        Double.longBitsToDouble(0x3fd0fbb4dc0915b2L), Double.longBitsToDouble(0x3febd92522e47d56L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 13, 9, "\ud9eb\udd4c\udb15\udc7b\ud809\udca1\ud884\udeed\udbd6\ude60\udb3e\udd65", "\u89ba\u7c84\u1cdd\u9b9b\ua7e9\ub0f6\u8ef6\ubcd1\u594f\u3b83", "\ud974\ude1f\ud818\ude66\ud9ec\udf8e\ud92f\udcc7\udb12\ude59\ud89d\udf0f",
        10, 57534, -315710253, -1737848694977747036L, 71926L, true, false, (char) 34113, (char) 65519,
        Double.longBitsToDouble(0x3fe533d11f4eac57L), Double.longBitsToDouble(0x3fbd6ebad5a6abd0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\ud819\udd5d\ud946\udd02\ud9f2\ude36\u0c2d\ud967\ude72\udb73\udda4$\u6f25\uaa2c\u816c$0\0121=java.lang.String:\ud819\udd5d\ud946\udd02\ud9f2\ude36\u0c2d\ud967\ude72\udb73\udda4$\u6f25\uaa2c\u816c$0\012",
        Z.run(T, 2, 2, 2, 15, "\ud819\udd5d\ud946\udd02\ud9f2\ude36\u0c2d\ud967\ude72\udb73\udda4", "\u6f25\uaa2c\u816c$", "\ud960\uddfa\udb4c\udd90\ud85e\udcf1\ud915\udd8d\u8e11",
        57, 47561, 703885239, -3794728985498325776L, -54154L, true, false, (char) 59018, (char) 22507,
        Double.longBitsToDouble(0x3fda918816b7c9f0L), Double.longBitsToDouble(0x3fe94eec51d8e7d6L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\ud819\udd5d\ud946\udd02\ud9f2\ude36\u0c2d\ud82b\ude74\udb73\udda4$\u10a0\u2386\u8187$0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 0, "\ud819\udd5d\ud946\udd02\ud9f2\ude36\u0c2d\ud82b\ude74\udb73\udda4", "\u10a0\u2386\u8187$", "\ud960\uddfa\udb4c\udd90\ud8ea\ude71\ud845\udf86\uda8e\uddae",
        51, 28781, 703106241, -3794728985498325776L, -54154L, true, false, (char) 34937, (char) 22555,
        Double.longBitsToDouble(0x3feed8c40b5be4f3L), Double.longBitsToDouble(0x3fe94eec51d8e7d6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.CollapseProperties|updateSimpleDeclaration|java.lang.String,com.google.javascript.jscomp.GlobalNamespace$Name,com.google.javascript.jscomp.GlobalNamespace$Ref|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|addStubsForUndeclaredProperties|com.google.javascript.jscomp.GlobalNamespace$Name,java.lang.String,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|appendPropForAlias|java.lang.String,java.lang.String|static",
    "M|com.google.javascript.jscomp.CollapseProperties|checkForHosedThisReferences|com.google.javascript.rhino.Node,com.google.javascript.rhino.JSDocInfo,com.google.javascript.jscomp.GlobalNamespace$Name|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|checkNamespaces||new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|collapseDeclarationOfNameAndDescendants|com.google.javascript.jscomp.GlobalNamespace$Name,java.lang.String|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|declareVarsForObjLitValues|com.google.javascript.jscomp.GlobalNamespace$Name,java.lang.String,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|flattenNameRef|java.lang.String,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,java.lang.String|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|flattenNameRefAtDepth|java.lang.String,com.google.javascript.rhino.Node,int,java.lang.String|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|flattenPrefixes|java.lang.String,com.google.javascript.jscomp.GlobalNamespace$Name,int|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|flattenReferencesTo|com.google.javascript.jscomp.GlobalNamespace$Name,java.lang.String|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|flattenReferencesToCollapsibleDescendantNames|com.google.javascript.jscomp.GlobalNamespace$Name,java.lang.String|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|inlineAliasIfPossible|com.google.javascript.jscomp.GlobalNamespace$Ref,com.google.javascript.jscomp.GlobalNamespace|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|inlineAliases|com.google.javascript.jscomp.GlobalNamespace|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|updateFunctionDeclarationAtFunctionNode|com.google.javascript.jscomp.GlobalNamespace$Name|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|updateSimpleDeclaration|java.lang.String,com.google.javascript.jscomp.GlobalNamespace$Name,com.google.javascript.jscomp.GlobalNamespace$Ref|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
