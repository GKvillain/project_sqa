package com.google.javascript.jscomp.type;
import org.junit.Test;
import static org.junit.Assert.*;
public class ChainableReverseAbstractInterpreter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 3, "\uda0e\ude42\ud90c\udde8\ud910\udd92\ud849\udcf6\ud9ba\udf6a\ud9ef\udf85\ud81e\udde5\uda06\udd73\uda3a\udf83\ud9b7\udfcc\ud835\udfac\ud991\udc9f\udab8\udd92\ud9d3\udd8b\udbc1\udd53\uda83\udf1e\ud806\udf2c\ud8d5\ude48\uda94\ude18\ud9cb\uddd6\u0ea2\udaf0\udf4d\udaf1\udd9a\uda7d\udc51\uda80\udf12\uda8e\udd23\ud9db\udd0d\udbc7\udfc3\ud8dc\ude5b\uda65\uddf5\uda96\uddd9\ud8fe\uddf6\uda03\udd44\ud820\uddfc\uda7b\udddd\uca32\udb11\udd56\ud879\udf1d\udbcd\udf74\ud92d\udecf\udb59\udeaf", "\u0bdd\ub57b\u9a65\u5146\u6f37\u47f3\u95e7\ud3fe\u8c1c\u371f\u7123\u39b9\u6c64\u9038\ua5f0\u7234\u2948\u80fd\ua409\uc2c4\u3bfc\ubd9f\u54f7\ua0d5\u5322\u6cb9\u0738", "\u1804\ud882\uddf3\ud897\udf08\ud91c\ude6b\ud859\ude37\uda8e\udd6a\ud999\udf71",
        32, 66857, -1545650189, -7535075801844645672L, -85204L, true, false, (char) 18582, (char) 6527,
        Double.longBitsToDouble(0x3fd2599c8f8b5548L), Double.longBitsToDouble(0x3fc31e583011ebd8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 3, "\uda0e\ude42\ud90c\udde8\ud910\udd92\ud849\udcf6\ud9ba\udf6a\ud9ef\udf85\ud81e\udde5\uda06\udd73\uda3a\udf83\ud9b7\udfcc\ud835\udfac\ud991\udc9f\ud882\ude93\ud9d3\udd8b\udbc1\udd53\uda83\udf1e\ud806\udf2c\ud8d5\ude48\uda94\ude18\ud9cb\uddd6\u0ea2\udaf0\udf4d\udaf1\udd9a\uda7d\udc51\uda80\udf12\uda8e\udd23\ud9db\udd0d\udbc7\udfc3\ud8dc\ude5b\uda65\uddf5\uda96\uddd9\ud8fe\uddf6\uda03\udd44\ud820\uddfc\uda7b\udddd\uca32\udb11\udd56\ud879\udf1d\udbcd\udf74\ud92d\udecf\udb59\udeaf", "\u0bdd\ub57b\u9a65\u5146\u6f37\u47f3\u95e7\ud3fe\u8c1c\u371f\u7123\u39b9\u6c64\u9038\ua5f0\u7234\u1194\u794a\u1016\u0546\uae2d\ub6de\u867f\u05e7\u5322\u6cb9\u0738", "\u1804\ud882\uddf3\ud897\udf08\ud91c\ude6b\ud859\ude37\uda8e\udd6a\udbf6\ude7f",
        32, 66857, -1545650189, -7535075801844645672L, -85204L, true, false, (char) 18582, (char) 6527,
        Double.longBitsToDouble(0x3fd2599c8f8b5548L), Double.longBitsToDouble(0x3fc31e583011ebd8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 3, "\uda0e\ude42\ud90c\udde8\ud910\udd92\ud849\udcf6\ud9ba\udf6a\ud9ef\udf85\ud81e\udde5\uda06\udd73\036\ud9b0\udf58\ud835\udef8\ud991\udc9f\udab8\udd92\ud9d3\udd8b\udbc1\udd53\uda83\udf1e\000\000\uda94\ude18\ud9cb\uddd6\udbc5\udfa1\udaf0\udf4d\udaf1\udd9a\uda7d\udc51\uda80\udec2\uda8e\udd23\ud9db\udd0d\u662c\000\000\uda96\udd5c\ud8fe\uddf6\uda03\udd44\ud820\uddfc\uda7b\udddd\uca32\000\ud879\udf1d\u3b95\ud92d\udecf\u00c3", "\u5188\000\ud0e3\u5146\000\000\000\ud39e\u8c1c\u33df\000\u24fb\u471c\u9038\ua5f0\u7234\u0bb7\uc17b\ua409\u6613\u06d1\ubd9f\u54f7\u79d4\u5322\u6c69\u0738", "\u1804\000\ud812\udf49\007\000\uda8e\udd6a\uda89\udee9",
        2, 59001, 16128, -7535076330125623080L, -85204L, true, false, (char) 18582, (char) 6527,
        Double.longBitsToDouble(0x3fd2599c8f8b5548L), Double.longBitsToDouble(0x3fc31e583011ebd8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 3, 10, "\uda0e\ude42\ud90c\udde8\ud910\udd92\ud849\udcf6\ud9ba\udf6a\ud9ef\udf85\ud81e\udde5\uda06\udd73\uda3a\udf83\ud9b7\udfcc\ud835\udfac\ud991\udc9f\udab8\udd92\ud9d3\udd8b\udbc1\udd53\udbdb\udf2a\ud806\udf2c\ud8bb\uddfb\ud822\udf3d\u4b29\udb9f\udf4d\udaf0\udf4d\uda7c\ude9f\ud879\udd3f\uda8f\udc12\uda8e\udd23\ud9db\udd0d\udbc7\udfc3\ud8dc\ude5b\uda65\ude2e\uda96\uddd9\ud8fe\uddf6\uda03\udd44\ud820\uddfc\ud8c3\udde1\uca32\udb11\udd56\ud879\udf1d\udbcd\udf74\ud92d\udecf\udb59\udeaf", "\u0bdd\ub57b\u9a65\u3fab\u6f37\u47f3\u95e7\ud3fe\u8c1c\u371f\u7123\u39b9\u6c64\u9038\ua5f0\u7234\u2948\u80fd\ua409\uc2c4\u3bfc\ubd9f\ua4d3\u835d\u5322\u6cb9\u8f25", "\u1804\ud882\uddf3\ud897\udf08\ud91c\ude6b\ud859\ude37\uda8e\udd6a\ud999\udf71",
        32, 66857, -1545650183, -7535075801844645672L, -85204L, true, false, (char) 25308, (char) 6527,
        Double.longBitsToDouble(0x3fd2599c8f8b5548L), Double.longBitsToDouble(0x3fc31e54f011ebd8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 3, "\uda0e\ude42\ud90c\udde8\ud910\udd92\ud849\udcf6\ud9ba\udf6a\ud9ef\udf85\ud81e\udde5\uda06\udd73\uda3a\udf83\ud9b7\udfcc\ud835\udfac\ud991\udc9f\udab8\udd92\ud9d3\udd8b\udbc1\udd53\uda83\udf1e\ud806\udf2c\ud8d5\ude48\uda94\ude18\ud9cb\uddd6\u0ea2\udaf0\udf4d\udaf1\udd9a\uda7d\udc51\uda80\udf12\uda8e\udd23\ud9db\udd0d\udbc7\udfc3\ud8dc\ude5b\uda65\uddf5\uda96\uddd9\ud8fe\uddf6\uda03\udd44\ud820\uddfc\uda7b\udddd\uca32\udb11\udd56\ud879\udf1d\udbcd\udf74\ud92d\udecf\udb59\udeaf", "\u0bdd\ub57b\u9a65\u5146\u6f37\u47f3\u95e7\ud3fe\u8c1c\u371f\u7123\u39b9\u6c64\u9038\ua5f0\u7234\u2948\u80fd\ua409\uc2c4\u3bfc\ubd9f\u54f7\ua0d5\u5322\u6cb9\u0738", "\u1804\ud882\uddf3\ud897\udf08\ud91c\ude6b\ud859\ude37\uda8e\udd6a\ud999\udf71",
        32, 66857, -1545650189, -7535075801844645672L, -85204L, true, false, (char) 18582, (char) 6527,
        Double.longBitsToDouble(0x3fd2599c8f8b5548L), Double.longBitsToDouble(0x3fc31e583011ebd8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 3, "\uda0e\ude42\ud90c\udde8\ud910\udd92\ud849\udcf6\ud9ba\udf6a\ud9ef\udf85\ud81e\udde5\uda06\udd73\uda3a\udf83\ud9b7\udfcc\ud835\udfac\ud991\udc9f\udab8\udd92\ud9d3\udd8b\udbc1\udd53\uda83\udf1e\uda30\ude6e\ud998\udf28\uda6e\udf72\ud9cb\ude6b\u0ea2\udaf0\udf4d\udaf1\udd9a\uda7d\udc51\uda80\udf12\uda8e\udd23\ud9db\udd0d\udbc7\udfc3\ud8dc\ude5b\uda65\uddf5\uda96\uddd9\ud8fe\uddf6\uda03\udd44\ud820\uddfc\uda7b\udddd\uca32\udb11\udd56\udb1c\udc8b\udbcd\udf74\ud92d\udecf\udb59\udeaf", "\u0bdd\ub57b\u9a65\u5146\u6f37\u47f3\u95e7\ud3fe\u8c1c\u371f\u7123\u39b9\u6c64\u9038\ua5f0\u7234\u2948\u80fd\ua409\uc2c4\u3bfc\ubd9f\u54f7\ua0d5\u5322\u6cb9\u0738", "\u1804\ud882\uddf3\ud897\udf08\ud91c\ude6b\ud859\ude37\uda8e\udd6a\ud999\udf71",
        32, 66857, -1545650189, -7535075801844645672L, -85204L, true, false, (char) 18582, (char) 6527,
        Double.longBitsToDouble(0x3fd2599c8f8b5548L), Double.longBitsToDouble(0x3feddf960c047a60L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|declareNameInScope|com.google.javascript.jscomp.type.FlowScope,com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|append|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|firstPreciserScopeKnowingConditionOutcome|com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope,boolean|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|getFirst||new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|getNativeType|com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|getNativeTypeForTypeOf|java.lang.String|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|getRestrictedByTypeOfResult|com.google.javascript.rhino.jstype.JSType,java.lang.String,boolean|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|getRestrictedWithoutNull|com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|getRestrictedWithoutUndefined|com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|getTypeIfRefinable|com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|nextPreciserScopeKnowingConditionOutcome|com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope,boolean|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|declareNameInScope|com.google.javascript.jscomp.type.FlowScope,com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
