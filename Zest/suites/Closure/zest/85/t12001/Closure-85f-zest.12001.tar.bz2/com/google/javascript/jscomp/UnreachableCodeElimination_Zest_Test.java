package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class UnreachableCodeElimination_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.UnreachableCodeElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 4, "\uda53\udc06\ud8ab\ude11\ud957\udf67\ud9c2\udea6\ud97d\ude28\uda65\udcbb\uda4d\ude1b\udb20\ude55\udb36\uddfc\udb5c\udff7\udb12\udf38\ud8d1\udf83\udaf6\ude90\ud958\udc25\udabd\ude6c", "\uae5a\u7ac4\u0d60\u3b16\u964c\u1044\ub1a9\u251d\ub49e\uaed4\uc252", "\ud974\udebe\uda0b\uddf5\udbfb\udde4\ud87d\udd4a\ud841\udc1b\ud855\uddb1",
        45, 96201, 144623548, 3620346621700977426L, 20432L, false, true, (char) 44859, (char) 37998,
        Double.longBitsToDouble(0x3fe13fc4ff10be48L), Double.longBitsToDouble(0x3fe5b353c6104f7dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.UnreachableCodeElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 4, "\uda53\udc06\ud8ab\ude11\ud957\udf67\ud9c2\udea6\ud97d\ude28\uda65\udcbb\uda4d\ude1b\udb20\ude55\udb36\uddfc\udb5c\udff7\udb12\udf38\ud8d1\udf83\udaf6\ude90\ud958\udc25\udabd\ude6c\uda08\uded6\ud863\udee7\udb07\udcc8", "\u3b16\u964c\u1044", "\uda59\ude1a",
        6, 78871, -643443206, -6491720456590580217L, 53203L, false, true, (char) 20448, (char) 22386,
        Double.longBitsToDouble(0x3fd39994420202f6L), Double.longBitsToDouble(0x3fede0f0f612089eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.UnreachableCodeElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 8, "\uda53\udc06\ud8ab\ude11\ud957\udf67\000\udb9e\uddcf\uda65\udcbb\uda4d\ude1b\udb20\ude55\ud949\ude46\udb1e\udd4f\udb12\udf38\000\udaf6\udd93\ud958\udc25\000", "\uae5a\u7ac4\u9314\u3b16\u964c\u1044\ub1a9", "\ud8ce\udede\ud999\uddad\ud970\udfb7\udb76\udfa2\ud954\udfbe",
        44, 443, 63916, -7803893731026484289L, 47713L, false, true, (char) 3760, (char) 58703,
        Double.longBitsToDouble(0x3fa41722990b5d60L), Double.longBitsToDouble(0x3feb77a6d712202aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 4, "\uda53\udc06\ud8ab\ude11\ud957\udf67\ud9c2\udea6\uda20\udf2e\uda65\udcbb\uda4d\ude1b\udb20\ude55\udb36\uddfc\udb5c\udff7\udb12\udf38\ud8d1\udf83\udaf6\ude90\ud958\udc25\udabd\ude6c", "\ub6e7\u7c46\u5d7d\u0d7f\u964c\u1044\ud71f\u7ee3\ub34b\uaed4\uc252", "\ud974\udebe\uda0b\uddf5\udbfb\udde4\ud87d\udd4a\udb96\udc44\ud85d\udfd3",
        45, 96201, 144623548, 3620346621700977426L, 20432L, false, true, (char) 44859, (char) 32603,
        Double.longBitsToDouble(0x3fe139d2c710be48L), Double.longBitsToDouble(0x3fe5b353c6104f7dL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.UnreachableCodeElimination:@?\012",
        Z.run(T, 1, 1, 0, 4, "\ud838\uddd9\ud896\ude7b\ud943\udffd\ud9c2\uddf8\ud97d\ude28\uda65\udcbb\uda4d\ude1b\udb20\ude55\udb36\uddfc\udb5c\udff7\udb12\udf38\ud8d1\udf83\udaf6\ude90\ud958\udc25\udabd\ude6c", "\u7c47\uc273\u160d\ucbfb\u964c\u1044\ub1a9\ucf2f\u142f\u0959\uc252", "\ud974\ude6d\uda0b\uddf5\udae7\ude3b\ud990\udd61\uda44\udd22\udbb4\udcfe",
        45, 96201, 144623548, 3620346621700977426L, 39487L, true, false, (char) 12930, (char) 37876,
        Double.longBitsToDouble(0x3fe13fc4fb3cbe48L), Double.longBitsToDouble(0x3fe5b35466104f7dL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.UnreachableCodeElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 4, "\uda53\udc06\ud8ab\ude11\ud957\udf67\000\ud97d\ude28\uda65\udcbb\uda4d\ude1b\u356d\ud9ae\udfb6\udb5c\udff7\udb12\udf38\ud8d1\udf83\udaf6\ude90\ud958\udc25\u4477", "\u30c4\u7ac4\u0d60\u3b16\u964c\u1044\u3d58\000\ub3b1\uaed4\uc252", "\ud974\udebe\uda0b\uddf5\udbfb\udde4\ud87d\udd4a\ud841\udc1b\ud855\uddb1",
        45, 96201, 144623548, 3620346621700977426L, 20432L, false, true, (char) 44859, (char) 37998,
        Double.longBitsToDouble(0x3fe13fc4f800be48L), Double.longBitsToDouble(0x3fe5b35006104f7dL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.UnreachableCodeElimination:@?\0121=null |this=com.google.javascript.jscomp.UnreachableCodeElimination:@?\012",
        Z.run(T, 2, 1, 1, 4, "\ud85c\uddab\ud81b\uddc3\ud957\udf67\ud9c2\udea6\ud97d\ude28\uda65\udcbb\uda4d\ude1b\uda4f\uddc0\udb28\ude8d\udb9f\udec6\ud938\udcc9\ud8c9\udf69\udb35\udd17\ud913\udc7c\udabd\ude11\uda08\uded6\ud863\udee7\udb07\udcc8\udb74\ude2f", "\u964c\u1044\ub1a9\u251d", "\uda4d\udea0\ud970\udfb7\uda82\udf6e\ud974\udebe\uda0b\uddf5\udbfb\udde4\ud87d\udd4a\ud841\udf37\ud855\uddb1\ud958\udd4f\ud95e\udec7\uc73a\udbf0\udd07\ud823\uddcc\ud878\udfc9\udb3a\udce7\ud8e0\udd53\udb91\udd88\udacd\ude0d\udb75\udfef\ud8e9\udc60\ud8ae\udda9\udb52\uddfd\udb95\udd03\ud85a\udffe\udb4b\ude25\udbd0\uddb2\udbea\udc25\ud84b\udc09\udb42\ude08\ud92a\ude16\udb20\udc20\ud854\udea8\uda82\udd1c\ud86b\udde6\uda9d\udeab\ud98b\udea6\udb0a\udf50\udbe2\ude03\ud9b6\udc5f\uda11\udf82\ud9a2\uddea\ud8e6\udecb\uda11\ude1f\udaf1\udcf3\udbbf\udede\udbb6\udd6d\udafc\udc9e\ud9f2\uded9\u36e5\udbb6\udeb4\ud8d5\udd19\ud833\udc55\ud966\udea7\ud8c2\udc26\ud8c0\udd27\uda19\udf8f\ud887\udff3\udaa7\udcb1\udbb0\uddbf",
        35, 45588, -2013009435, -1925410477779488763L, -15028L, true, true, (char) 25911, (char) 41182,
        Double.longBitsToDouble(0x3fcc669ae7afe57cL), Double.longBitsToDouble(0x3fcfab73573d9354L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.UnreachableCodeElimination:@?\0121=void |this=com.google.javascript.jscomp.UnreachableCodeElimination:@?\012",
        Z.run(T, 2, 7, 6, 3, "\uda4d\udfd1\ud8ab\ude11\ud957\udf67", "\u4f52\u1e28\ud028\u394c\u2e25\u2300\ub691\u3527\ub0af\u59e0\ud1fd\u1d9a\uae5a\u7ac4\u0d60\u3b16\u964c", "\ud80d\ude62\uda59\ude1a\ud8ce\udede\ud999\uddad\ud970\udfb7\udb76\udfa2\ud974\udebe",
        44, 75099, 1029962156, -7803873402946272321L, 47713L, false, true, (char) 5808, (char) 3152,
        Double.longBitsToDouble(0x3fe4af9d5190b5d6L), Double.longBitsToDouble(0x3feb77a6d712202aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 0, "\uda53\udc06\ud8ab\ude11\ud957\udf67\ud9c2\udea6\ud97d\ude28\uda65\udcbb\uda4d\ude1b\udb20\ude55\udb36\uddfc\udb5c\udff7\udb12\udf38\ud8d1\udf83\udaf6\ude90\ud958\udc25\udabd\ude6c\uda08\uded6\ud863\udee7\udb07\udcc8\udb74\ude2f\ud8e8\uded4\udb16\udde5\uda25\udd4a", "\u251d\ub49e\uaed4\uc252\u6085\u59c6\u6bf6", "\ud87d\udd4a",
        8, 17311, 24881465, 2170243543134554044L, 11378L, false, false, (char) 57190, (char) 17481,
        Double.longBitsToDouble(0x3fe89101567de5f1L), Double.longBitsToDouble(0x3fe13fc4ff10be48L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.UnreachableCodeElimination:@?\0121=new com.google.javascript.jscomp.UnreachableCodeElimination:@?\012",
        Z.run(T, 2, 7, 7, 4, "\uda53\udc06\ud8ab\ude11\ud957\udf67\ud9c2\udea6\udad2\uddf1\uda65\udc18\uda4d\udea4\udb19\ude13\udb36\uddfc\udb5c\udff7\udb12\ude7b\ud8d1\udf83\ud974\udfaf\ud958\udc13\udabd\ude6c", "\u36f9\u7ac4\u0d60\u3b16\ucb0a\u1044\u1ca2\u24aa\ub49e\u4262\uc252", "\ud974\udebe\uda0b\uddf5\ud919\ude99\udacf\udddc\ud877\ude16\ud855\uddb1",
        35, 8919, 144623578, 3620346618799383988L, 20432L, false, true, (char) 44859, (char) 37998,
        Double.longBitsToDouble(0x3fe13fc4fcd8be48L), Double.longBitsToDouble(0x3fb139f1542094d0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.UnreachableCodeElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 3, "\uda52\udfe8\ud8ab\ude11\ud916\uddff\udb17\udf9e\udbaf\uddcd\uda72\udee5\uda4d\ude72\udb20\ude55\udb36\uddfc\udb5c\udff7\udb12\udf38\ud9a4\udf36\udaf6\ude90\ud958\udc25\udabd\ude6c", "\uae5a\u7ac4\u4f60\u3b16\u964c\u1044\u5409\u251d\ub49e\uaed4\uc252", "\ud974\udebe\uda0b\uddf5\udbfb\udde4\udaff\ude86\ud840\udfc4\ud5a2",
        12, 81585, 144623465, 3620346621700977426L, 20432L, false, false, (char) 23348, (char) 37998,
        Double.longBitsToDouble(0x3fe697c4ff10be48L), Double.longBitsToDouble(0x3fe5b353c6104f7dL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.UnreachableCodeElimination:@?\0121=void |this=com.google.javascript.jscomp.UnreachableCodeElimination:@?\012",
        Z.run(T, 2, 6, 6, 1, "\uda52\udff3\u42de\ud8e6\udc67\u6d70\ud97d\ude7e", "\ud028\u350b\u0cf7\u4fec\u32fc\u3527\u0d13\ud3e0\ud1d8\u1d9a\uae5a\u7ac4\u0d60\u3b16\u964c\u1044\ub1a9\u251d\ub49e\uaed4\uc252\u2e72\u7e8b\u38f6\ubd0b", "\ud841\udc1b\ud855\uddb1\ud958\udd4f\ud95e\udec7\ud8d1\udd0b\udbf0\udd07\ud823\uddcc\ud878\udfc9\udb3a\udce7",
        38, 73970, -354057770, -4735378756923467504L, -45088L, false, true, (char) 52683, (char) 51370,
        Double.longBitsToDouble(0x3fe7fa681a8db97fL), Double.longBitsToDouble(0x3fe00d43e269371fL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.UnreachableCodeElimination:@?\012",
        Z.run(T, 1, 7, 1, 4, "\uda53\udc06\ud8ab\ude11\ud957\udf67\ud9c2\udea6\ud8fa\udd9e\uda64\udfd5\uda4d\ude1b\udb20\ude55\udb36\uddfc\udb5c\udff7\udb12\udf38\ud8d1\udf83\udbcf\udc04\udb7a\ude93\udabd\ude25", "\ub6e7\u7c46\u5d7d\u0d7f\u964c\u1044\ud71f\u7ee3\ub34b\uaed4\uc252", "\ud974\udebe\uda0b\uddf5\udbfb\udde4\ud87d\udd4a\udb96\udc44\uda3b\udc60",
        45, 96201, 144623548, 3620346621700977426L, 20432L, false, true, (char) 13372, (char) 32603,
        Double.longBitsToDouble(0x3fe139d2c710be48L), Double.longBitsToDouble(0x3fbbda9e0dd39c18L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.UnreachableCodeElimination:@?\012",
        Z.run(T, 1, 7, 6, 1, "\uda4d\udfd1", "\u05fd\ucd1d\u4f52\u1e28\ud028\u394c\u2e25\u2300\ub691\u3527", "\uda08\udefb\ud863\udee7\udb07\udcc8\udb74\ude2f\udb88\udc03\ud8af\udcc4\ud9ba\udfce\ucf67\ud86c\udec6\ud80d\ude62\uda59\ude1a\ud8ce\udede\ud98d\udead\ud93b\uddbd\udb76\udfa2\ud974\udebe\ud9ce\udff5\ud933\udde0\ud87d\udd4a\ud841\udc1b\ud855\uddb1\ud8fa\udd40\000\udab2\udc78\uda8b\ude15\ud80c\ude0a\ud85e\ude36\udb3a\udce7\u4f6e",
        -5, 23965, 1710855979, 5732356997102800158L, 10056L, false, false, (char) 12292, (char) 31954,
        Double.longBitsToDouble(0x3fdd921a16b0b7baL), Double.longBitsToDouble(0x3fc3e61f6f380e90L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.UnreachableCodeElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 4, "\uda53\udc06\ud8ab\ude11\ud957\udf67\ud9c2\udea6\ud97d\ude28\uda65\udcbb\uda4d\ude1b\udb20\ude55\udb36\uddfc\udb5c\udff7\udb12\udf38\ud8d1\udf83\udaf6\ude90\ud958\udc25\udabd\ude6c", "\uae5a\u7ac4\u0d60\u3b16\u964c\u1044\ub1a9\u251d\ub49e\uaed4\uc252", "\ud974\udebe\uda0b\uddf5\udbfb\udde4\ud87d\udd4a\ud841\udc1b\ud855\uddb1",
        45, 96201, 144623548, 3620346621700977426L, 38878L, false, true, (char) 44859, (char) 37998,
        Double.longBitsToDouble(0x3fe13fc4ff10be48L), Double.longBitsToDouble(0x3fe5b353c6104f7dL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.UnreachableCodeElimination:@?\012",
        Z.run(T, 1, 1, 4, 8, "\uda53\udc06\ud8ab\ude11\ud957\udf67\000\udb9e\uddcf\uda65\udcbb\uda4d\ude1b\udb20\ude55\ud949\ude46\udb1e\udd4f\udb12\udf38\000\udaf6\udd93\ud958\udc25\000", "\u543f\u7ac4\u8dbe\u3b16\u964c\u1044\ub1a9", "\ud8ce\udede\ud999\uddad\ud970\udfb7\udb76\udfa2\ud954\udfbe\uda0b\uddf5\udbfb\udde4\ud800\uddac\ud83c\udd9e\ud855\uddb1\ud958\udd4f\ud95e\udec7\ud945\udfc5\udbf0\udd07\ud823\uddcc\ud878\udfc9\udb3a\udcd6\ud8e0\udd53\ud858\udd4b\uda30\udd4c\ud88a\udeed\udbb6\udce4\ud91f\udd07\udadd\udca1\ud88d\uddda\udb2a\udfcd\udb2e\udf9e\ud907\udd0b\udaa3\udca7\ud94e\udc0d\u1f40\u37a3\ud901\udc4e\ud827\udf1b\udb18\udc50",
        28, 58326, -626332002, -4030499431854458893L, -10535L, true, false, (char) 62015, (char) 38229,
        Double.longBitsToDouble(0x3fa766e727eedeb0L), Double.longBitsToDouble(0x3fde02c0a3a1956eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.UnreachableCodeElimination|computeFollowing|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.UnreachableCodeElimination:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.UnreachableCodeElimination|tryRemoveUnconditionalBranching|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.UnreachableCodeElimination:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.UnreachableCodeElimination|enterScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.UnreachableCodeElimination:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.UnreachableCodeElimination|exitScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.UnreachableCodeElimination:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.UnreachableCodeElimination|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.UnreachableCodeElimination:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.UnreachableCodeElimination|removeDeadExprStatementSafely|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.UnreachableCodeElimination:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.UnreachableCodeElimination|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.UnreachableCodeElimination:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "C|com.google.javascript.jscomp.UnreachableCodeElimination|<init>|com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.UnreachableCodeElimination|computeFollowing|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.UnreachableCodeElimination:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.UnreachableCodeElimination|tryRemoveUnconditionalBranching|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.UnreachableCodeElimination:com.google.javascript.jscomp.AbstractCompiler,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
