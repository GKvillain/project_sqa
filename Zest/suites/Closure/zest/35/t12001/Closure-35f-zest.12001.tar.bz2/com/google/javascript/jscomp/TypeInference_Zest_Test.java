package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeInference_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 4, "\ud81b\udc48", "\u7fd1\u4867\u135e\ud38b\u1ee1\u36a7\u0b35\u2d0d\u4e94\u24fe\u4282\u6f10\u3aeb\ua100\u3812\u40dc", "\udbee\ude37",
        24, 64118, 1101498022, -6752157005301680312L, -34107L, true, false, (char) 22056, (char) 44134,
        Double.longBitsToDouble(0x3fc6fd44ecac7028L), Double.longBitsToDouble(0x3fce70c6586443a8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 4, "\ud8e8\udc19", "\uccf8\u4867\u135e\ud38b\u9946\u36a7\u0b35\u2d0d\u4e94\u24fe\u4282\u175c\u3aeb\ua100\u3812\u40dc", "\udbee\ude37",
        24, 86774, 1101498022, -8481539262212012200L, -34107L, true, false, (char) 47370, (char) 7800,
        Double.longBitsToDouble(0x3fc6fd44ecac7028L), Double.longBitsToDouble(0x3fce70c6586443a8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 4, "\udb08\udcd6", "\u7efb\u4867\u135e\ud38b\u61c8\025\u0b35\uac28", "\udac2\uddc5\ud848\ude92",
        38, 47826, 1208928939, -7089486633669163963L, 53058L, false, false, (char) 50848, (char) 39315,
        Double.longBitsToDouble(0x3fe1633a99655ec4L), Double.longBitsToDouble(0x3fbe71547f6ef1d0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 8, "\ud81b\udc48\uda00\udf97\ud92a\ude12\ud8fb\udc41\udb9d\ude26\ud979\udf36\ud8bd\udfe5\uda8f\udeea\udbdb\udcd0\uda79\uddd6\ud9ea\udca4\udb1b\udda7\udba9\udfd5\ud91c\udeb3\ud88f\udd0a", "\u6044\u31fb\u5d83\ud73b\u955c\u1430\u9ab6\u8f09\u95ea", "\udb41\udee4\ud8c9\udce2\udaff\udef6\uda93\udf82\udbcc\udc5d\uda14\udd41\udb38\uddff\ud9b8\udf28\uda6b\udcba\uda40\udc6e\ud9d7\uded3\uda3a\ude78\ubcee\udbcb\udd56\ud832\udc03\uda3e\udd77\ud993\udfb3",
        17, 64161, 1727869992, -7708036648531036923L, -21100L, true, false, (char) 61, (char) 13123,
        Double.longBitsToDouble(0x3fc7d1becfd8faacL), Double.longBitsToDouble(0x3fe24604df478a1dL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 4, "\ud81b\udc48", "\000", "",
        30, 76475, -822069332, 1261895680L, 96356L, false, false, (char) 0, (char) 32899,
        Double.longBitsToDouble(0x3f9ada60557ed440L), Double.longBitsToDouble(0x3fd78480e88b3b3aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 11, 4, "\uda2c\udc2f", "\u7fd1\u4867", "\ud909\udf18\udbba\udd71\ud8f9\udcab\udae2\udc56\udb1b\udd0f\udb1b\ude8d\ud832\udc20\udbce\udc72\ud8e8\udc2f\udab5\udd45\ud892\udfe5\udaab\udf9f\uda93\ude0d\uda3d\udd04\udbee\ude37\ud8d7\udf72\ud952\udc14\udb7d\udc53\ud836\udd37\udb6d\udd5e\udaad\udfc1",
        29, 27217, -1559445552, -1574110401186309961L, 63830L, false, true, (char) 16034, (char) 13986,
        Double.longBitsToDouble(0x3fe4c56dc74f4151L), Double.longBitsToDouble(0x3fa8875c3a9d0e00L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 4, 4, "\ud81b\udc48\ud9f9\ude6b\ud92a\ude12\ud8fb\udc41\udb9d\ude26", "\u1ee1", "\udae2\udc56\udaf1\udc27\udba9\udfd5\udac2\uddc5\ud848\ude92\ud95b\udd4b\udad4\udf8c\ud833\udeea\ud9db\udf06\udbf4\udede\uda3d\udc89\udbee\ude37\ud8d7\udf72\ud952\udc14\ud971\udf8e\ud856\udeff\u8682\ud874\udd1b\uda95\uddef\ud9fc\ude7b\u5bca\ud9aa\udd4e\ud806\ude5e\ud99e\udffd\ud88e\uddf2\ud930\uddad\ud9ee\udc86\udaa9\ude11\udb3c\ude42\ubae9\ud96c\udd15\ud89f\udd25\uda42\uddfc\ud99e\udf04\ud81a\udd9e",
        30, 52586, -275421242, 3252152025288607044L, -38831L, false, false, (char) 21930, (char) 44581,
        Double.longBitsToDouble(0x3febc338427c0168L), Double.longBitsToDouble(0x3fd7222b85811258L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:TRUE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 4, "\ud81b\udc48", "\u7fd1\u4867\u135e\ud38b\uc1a0\u27ef\ua3bc\u2d0d\u4e94\u24fe\u4282\u6f10\u3aeb\ua100\u3812\u40dc", "\udac3\uddc7\ud900\udd7a\ud952\udc14\ud9e0\ude84\ud915\udf74\udb6d\udd5e\udaad\udfc1\uda95\uddef",
        0, 97621, -353155331, 2020665661276220203L, -26759L, false, true, (char) 46320, (char) 21457,
        Double.longBitsToDouble(0x3fe8feb5a3d6060dL), Double.longBitsToDouble(0x3fc9a4c01e290040L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\012",
        Z.run(T, 1, 11, 0, 4, "\ud81b\udc48", "\u173b\u4867\u135e\ud38b\u1ee1\u36a7\u0b35\u2d0d\u4e94\ucf3b\u4282\u6f10\u8b7e\ua1b5\u3812\u141f", "\udbee\ude37\ud95d\ude94",
        0, 92022, -1572109062, 7445566499173171756L, -25369L, true, true, (char) 44134, (char) 49886,
        Double.longBitsToDouble(0x3fe158e050f38642L), Double.longBitsToDouble(0x3f9910eaa63527a0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:EMPTY\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 4, "\ud81b\udc48", "\u7fd1\u8955\ua34e\ud38b\u1ee1\u36a7\u0b35\u2d0d\u4e94\u550c\u4282\u6f10\u3aeb\ua100\u603f\u40dc", "\uda42\udcbd",
        44, 64324, 1101498022, -6752157005301680312L, 52828L, true, true, (char) 22236, (char) 62098,
        Double.longBitsToDouble(0x3fc6f0c02cac7028L), Double.longBitsToDouble(0x3fce70c6586443a8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 15, "\ud9a8\udd6a", "\u7fd1\u4867\u4672\u9719\u1ee1\u36a7\u92ae\u2d0d\u4e94\u24fe\uc2b4\u6f10\u9a2b\u31d8\u6810\ud762", "\uda23\udcf8",
        46, 64146, 1739032230, -6752157008378424136L, 96303L, true, false, (char) 22056, (char) 44134,
        Double.longBitsToDouble(0x3fc6fd44ee0ffe28L), Double.longBitsToDouble(0x3fce70c6586763ccL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:BOTH\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 4, "\ud81b\udc48", "\u7fd1", "\ud8bd\udfe5\udaf3\udc77\ud8bf\udc2f\ud905\ude14\udae2\udc56\udb1b\udd27\udba9\udfd5\udac2\uddc5\ud848\ude92\ud95b\udd4b",
        31, 58939, -1650643787, -6824803619302687231L, -19218L, false, true, (char) 38649, (char) 50848,
        Double.longBitsToDouble(0x3fea45125a2c6753L), Double.longBitsToDouble(0x3fd655ec4cfc44eaL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "\000", "\uafb3\u4867\u135e\ud38b\u1ee1\u36a7\u0b35\u3429\000\000\000\u0500\u42f6\ua100\u3812\u2632", "\udbee\ude37",
        7, -1000, 1101463552, -6752157005301680312L, -34107L, false, false, (char) 30759, (char) 44134,
        Double.longBitsToDouble(0x3fc6fd44e0ac7028L), Double.longBitsToDouble(0x3f40c65800000000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 4, "\ud81b\udc48", "\u7fd1\u6b76\u12ad\ud38b\u1ee1\u36a7\u0b35\u2d0d\u4e94\u24fe\u38bb\uc64f\u3aeb\ua100\u3812\u40dc", "\udbee\ude37",
        53, 9590, 1101497882, -6752157005301680312L, -34107L, true, false, (char) 22056, (char) 44134,
        Double.longBitsToDouble(0x3fc6fd44ecac7028L), Double.longBitsToDouble(0x3fce70c6586443a8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:TRUE\012",
        Z.run(T, 1, 11, 0, 0, "", "\u2cfd\u7fd1\u4867\u135e\ud38b\u1ee1\u36a7\000", "\000",
        53, 52672, -631242621, -674976881274074453L, 95515L, false, false, (char) 18214, (char) 22779,
        Double.longBitsToDouble(0x3eb2753000000000L), Double.longBitsToDouble(0x3fcf4834fd22892cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\0121=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\012",
        Z.run(T, 2, 11, 11, 15, "\ud81b\udc48", "\u8b93\u43d8\u8867\u5fe9\u1ee1\u57a2\ua1de\u2d0d\u4e94\u24fe\u4282\u6f10\u3aeb\ua100\u3812\u03e9", "\udbee\ude37",
        24, 19926, 762489279, 6895045090354825242L, -26110L, false, false, (char) 49886, (char) 1845,
        Double.longBitsToDouble(0x3fce70c6586443a8L), Double.longBitsToDouble(0x3fc7817f80ee0944L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\0121=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\012",
        Z.run(T, 2, 11, 11, 4, "\ud81b\udc48", "\u17dd\uce2a\u135e\ud38b\u1ee1\u36a7\u0b35\u2d0d\u4e94\u24fe\u4282\u6f10\u3aeb\ua100\u3812\u40dc", "\uda41\udc80",
        49, 64118, 1101498022, -6752157005305674680L, -34107L, true, false, (char) 22056, (char) 44134,
        Double.longBitsToDouble(0x3fda4c79b66f5044L), Double.longBitsToDouble(0x3fce70c6586443a8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:BOTH\0121=com.google.javascript.rhino.jstype.BooleanLiteralSet:BOTH\012",
        Z.run(T, 2, 11, 11, 3, "\udb08\udc3d", "\u7f16\u4867\u0eed\uc408\u273e\025", "\udb29\udc9d\udba9\udfd5\ud94a\uddc9\ud848\ude92\ud95b\udd4b\udb8a\udf87\ud833\udeea\udaab\udfab\ud8b3\udf1d\ud832\udcfe\udaea\ude35\ud8d7\udf72\u85d9\ud9e0\ude84\ud915\udf74\udb6d\udd5e\udaad\udfc1\uda95\uddef\ud9fc\ude7b\ud851\udde5\uda59\udcdd\uda52\udce0",
        35, 70245, 1962139528, -2287995631881760984L, -28348L, true, true, (char) 22525, (char) 29145,
        Double.longBitsToDouble(0x3fd23ac70b9662c8L), Double.longBitsToDouble(0x3fcdbaf6e61ba274L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\0121=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\012",
        Z.run(T, 2, 11, 11, 4, "\ud81b\udc48", "\ua438\u00f2\000\ud38b\u1ee1\u0599", "\udb1b\udd27",
        38, -1000, 1493172224, -2711123532239946726L, -28968L, true, false, (char) 61567, (char) 51562,
        Double.longBitsToDouble(0x3fbe702367f4ba28L), Double.longBitsToDouble(0x3fe5ceda9fd25946L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:EMPTY\0121=com.google.javascript.rhino.jstype.BooleanLiteralSet:EMPTY\012",
        Z.run(T, 2, 11, 11, 4, "\ud81b\udc48\u00ee\ud9c2\udc00\000\000\000\ud8bd\udfe5\uda91\udd3e\udac8\ude26\udad4\udefa\ud8a7\udce3\udb1b\udd27", "\ua17b\u9939", "\udaab\udfab\ud9a8\udcb7\ud96f\udeca\ud94a\udebe\ud8f6\udf18\ud916\udfc8\u4e28\ud9fe\uddbe\ud8c4\udcec\uda91\ude97\ud91d\udfbc\uda65\ude44",
        41, 77644, -182592957, 1918649536024510083L, -90916L, true, false, (char) 19857, (char) 56634,
        Double.longBitsToDouble(0x3fe649132c8a7722L), Double.longBitsToDouble(0x3f951d70b38ed300L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:TRUE\0121=com.google.javascript.rhino.jstype.BooleanLiteralSet:TRUE\012",
        Z.run(T, 2, 11, 11, 1, "\ud81b\udc48", "\000\000\000", "\udb07\udc45\000\udadf\udc6e\udb1b\udd27\ud850\udd03",
        41, 88224, -628702206, -674770174832883029L, 26949L, false, true, (char) 577, (char) 32929,
        Double.longBitsToDouble(0x3fe8df9516e64a34L), Double.longBitsToDouble(0x3fcc25d749459a64L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 9, 4, "\ud81b\udc48", "\u7fd1\u4867\u1a19\ucf1d\u1ee1\u36a7\u74d8\u2d0d\u4e94\u8e7a\u4282\u0d5b\u2ff2\ua194\u3812\u40dc", "\udbee\ude37",
        24, 64118, 1101498022, 7154958641289987943L, 96251L, true, false, (char) 22056, (char) 44134,
        Double.longBitsToDouble(0x3fc6fd44ecac7028L), Double.longBitsToDouble(0x3fce70c6586443a8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.TypeInference|inferPropertyTypesToMatchConstraint|com.google.javascript.rhino.jstype.JSType,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|backwardsInferenceFromCallSite|com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.FunctionType|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|branchedFlowThrough|com.google.javascript.rhino.Node,com.google.javascript.jscomp.FlowScope|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|createEntryLattice||new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|createInitialEstimateLattice||new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|dereferencePointer|com.google.javascript.rhino.Node,com.google.javascript.jscomp.FlowScope|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|ensurePropertyDeclared|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|ensurePropertyDeclaredHelper|com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.ObjectType|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|ensurePropertyDefined|com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|flowThrough|com.google.javascript.rhino.Node,com.google.javascript.jscomp.FlowScope|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|getBooleanOutcomePair|com.google.javascript.jscomp.TypeInference$BooleanOutcomePair,com.google.javascript.jscomp.TypeInference$BooleanOutcomePair,boolean|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|getBooleanOutcomes|com.google.javascript.rhino.jstype.BooleanLiteralSet,com.google.javascript.rhino.jstype.BooleanLiteralSet,boolean|static",
    "M|com.google.javascript.jscomp.TypeInference|getJSType|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|getNativeType|com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|getPropertyType|com.google.javascript.rhino.jstype.JSType,java.lang.String,com.google.javascript.rhino.Node,com.google.javascript.jscomp.FlowScope|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|isAddedAsNumber|com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|inferPropertyTypesToMatchConstraint|com.google.javascript.rhino.jstype.JSType,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
