package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class MakeDeclaredNamesUnique_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 10, 0, "\udac7\udf47\ud85c\udc30\uda52\ude24\udb93\udc43", "\u5e24\u6dc8\ub11b\u07e5\u109f\u15dd\u925d\u3b84\u6762\ubd7b\u0a68\u74dc\u143d\ud663\u6fce\u05b2", "\udba8\udd34\ud9ab\udf8d\ud91b\uddff\uda33\udcc8\ud9ee\ude4a",
        5, 721, 786507992, -7764709223508483967L, -17482L, true, false, (char) 13238, (char) 16985,
        Double.longBitsToDouble(0x3fee98b7cf8a26b3L), Double.longBitsToDouble(0x3fbe11e23c60e6a8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 10, 0, "\udac7\udf47\udb8e\udd6a\uda52\ude24\udbc9\udece", "\u4d24\ua10b\u5a6a\u07e5\u5a66\u1615\u3bd9\ub7a1\u566c\ubd7b\u0a68\u74dc\u9c82\u2cba\u44d0\u05b2", "\udba8\udd34\ud9ab\udf8d\ud91b\uddff\uda33\udcc8\ud8ba\udf10",
        50, 77940, 705927822, -7764708506248945535L, -17482L, true, false, (char) 13238, (char) 16985,
        Double.longBitsToDouble(0x3fee528002cc2bb3L), Double.longBitsToDouble(0x3fa15e1cf8c1cef0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 2, "\udac7\udf47\ud85c\udc30", "\u2e37\u1990\u1272\u6dc8\ub11b\u07e5\u109f\u15dd\u925d\u3b84\u6762\ubd7b\u0a68\u24b0", "\ud8ad\uddd0",
        47, 92662, -1070779159, -6029655454614047662L, -472L, true, false, (char) 5621, (char) 25851,
        Double.longBitsToDouble(0x3fc03287c95ad24cL), Double.longBitsToDouble(0x3fdaab787d1ba06cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.MakeDeclaredNamesUnique:@?\012",
        Z.run(T, 1, 8, 9, 0, "\udac7\udf47\ud85c\udc30\uda52\ude24\udb93\udc43", "\u5e24\u6dc8\u534b\u07e5\u109f\u15dd\u925d\u3b84\u6762\ubd7b\u4417\u97d4\u143d\ud663\u6fce\u05b2", "\udba8\udd34\ud9ab\udf8d\ud91b\uddff\uda33\udcc8\ud9ee\ude4a",
        5, 721, 786507992, -7764709223508483967L, 37814L, false, true, (char) 13238, (char) 16985,
        Double.longBitsToDouble(0x3fee98b7cf8a26b3L), Double.longBitsToDouble(0x3fbe11e23c60e6a8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 10, 0, "\udac7\udf47\ud85c\udc30\uda52\ude24\udb93\udc43", "\uc3ee\u4163\u582f\ucff7\u89aa\ua9e5\u925d\u3b84\u6762\ubd7b\u0a68\u198c\u143d\ud663\u6fce\u4500", "\udba8\udd34",
        43, 14967, 2046836120, -8676042421940251292L, 86152L, false, true, (char) 11398, (char) 41831,
        Double.longBitsToDouble(0x3fd313295d1ba06cL), Double.longBitsToDouble(0x3fe8f6c4bff53b43L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.MakeDeclaredNamesUnique$ContextualRenameInverter:@?\012",
        Z.run(T, 1, 5, 10, 0, "\udac7\udf47\ud85c\udc30\uda52\ude24\udb93\udc43", "\u5da4\u6dc8\ub11b\u07e5\u109f\u15dd\u925d\u3b84\u6762\ubd7b\u0a68\u74dc\u143d\ud663\u6fce\u05b2", "\udba8\udd34\ud9ab\udf8d\ud91b\uddff\u3d98\ud9fc\udcde",
        5, 721, 786507992, -7764709223508483967L, -17482L, true, false, (char) 13238, (char) 16985,
        Double.longBitsToDouble(0x3fee98b7cf8a26b3L), Double.longBitsToDouble(0x3fbe11e23c60e6a8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.MakeDeclaredNamesUnique:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 10, "\udac7\udfe2\ud85c\udc30\uda52\ude24\ud8df\ude47\ud8e2\udfa5", "\u6dc8\ub11b", "\ud8ad\udebb",
        44, 26215, 597046581, -2873423284780482649L, -6895L, false, true, (char) 58699, (char) 7247,
        Double.longBitsToDouble(0x3fedf25ce4e9997eL), Double.longBitsToDouble(0x3fd04c02d45e8e3cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.MakeDeclaredNamesUnique:@?\012",
        Z.run(T, 1, 6, 10, 0, "\udac7\udf47\ud85c\udc30\uda52\ude24\ud990\udce0\ud8b8\ude5a\ud960\udcec", "\ub11b\u07e5", "\uda1a\udfbf",
        26, 34581, -669020993, 2112961900715599800L, -90763L, true, true, (char) 22013, (char) 65079,
        Double.longBitsToDouble(0x3fe17a3a1e6fd35aL), Double.longBitsToDouble(0x3fd9892c82c6f400L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 9, 0, "\udac7\udf47\ud9ad\uddd8\uda4f\udf53\udb93\udc43", "\u5e24\u72c8\ub11b\u07e5\u109f\u15dd\u925d\u3b84\u4963\ubd7b\u0a68\u74dc\u143d\ud663\u6fce\u05b2", "\udba8\udd34\ud9ab\udf8d\ud91b\uddff\ud97c\ude4e\ud9ee\ude2e",
        5, 721, 774588041, -7764709222004271502L, -17482L, true, false, (char) 13238, (char) 44096,
        Double.longBitsToDouble(0x3fee9f824f8a26b3L), Double.longBitsToDouble(0x3fbe11e23c60e6a8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.MakeDeclaredNamesUnique:@?\012",
        Z.run(T, 1, 7, 7, 10, "\udac7\udf47\ud85c\udc30\uda52\ude24\ud858\udf81", "\ubcae\u9a44\ub11b\u082a\u109f\u498e\ua725\u40a3\u62c1\ua805\u0a68\u6877\u1442\u243a\u6fce\u05b2\uc640\u2144\ud14d\ucd44\u9afd\u48b5", "\udaf4\ude99\ud8d6\udf6a\ud919\udfc0\ud855\udc0f\uda87\ude10\ud998\udfe3\ud9d1\udc3a\ud815\ude9c\uda38\udc70\udb71\udffa\ud89c\udfc1\udbff\ude2a\ud83d\udd86\ud991\udebd\ud86a\uddd0\uda9d\udc91\uce05\ud83a\udf7a\ud9f4\udf1c\ud8c6\ude69\udaf3\udee3\u21c4",
        26, 66660, -276478245, 6290664023418313964L, 14359L, true, true, (char) 48662, (char) 64133,
        Double.longBitsToDouble(0x3fcf44f2d58ea4f4L), Double.longBitsToDouble(0x3fef80d8415efbfcL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.MakeDeclaredNamesUnique$ContextualRenameInverter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 10, 0, "\udacb\udf47\ud85c\udc30\uda52\ude24\udb93\udc43", "\u5e24\u9669\ub11b\u07e5\u109f\u15dd\u925d\u99c4\u3b17\u9f77\u0a68\u874e\u13eb\u7e26\u6fce\u05b2", "\ud9b7\udf7c\ud9ab\udf8d\ud91b\uddff\ud839\udccb\udb89\udf17",
        26, 12714, 786507992, -7764709223508483967L, -17482L, true, false, (char) 13238, (char) 54264,
        Double.longBitsToDouble(0x3fed81828f8a26b3L), Double.longBitsToDouble(0x3f9e4788effc2500L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.MakeDeclaredNamesUnique:@?\012",
        Z.run(T, 1, 6, 0, 3, "\u85a6\ud85c\udc30\uda52\ude24\udb93\udc43\ud8e2\udfa5\ud960\udcec\udb1e\udc01\uda20\uddaa\ud888\udf8a\ud93a\ude70\uda9e\udd45\ud8ad\udebb\uda1a\udfbf\udb93\ude27\udb7f\udf4d\ud970\ude65\ud966\udd61", "\u8730", "\uda26\uddb3\ud851\ude49\udba8\udd34",
        43, 14967, 2046836120, -8676042477774773634L, 86152L, false, false, (char) 29887, (char) 65257,
        Double.longBitsToDouble(0x3fdaab787d1ba06cL), Double.longBitsToDouble(0x3fe8f6c4bb123b43L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.MakeDeclaredNamesUnique:@?\012",
        Z.run(T, 1, 8, 10, 0, "\udac1\udde2\ud87a\ude56\udbd0\udee4\ud835\ude9e", "\ub6ac\u2e31\ub11b\u07e5\ucb5e\uc2ac\u5c2c\u5317", "\ud966\udd61\ud8f7\udd25\ud970\udd00\uc94a\ud8c4\udd3b\udab4\udc89\uda26\uddb3\ud848\udd26\udba8\udd34\ud9ab\udf8d\ud91b\ude25\ud870\uddbe\ud9e1\udea4\ud854\udf6c\udb63\udd2f",
        57, 36754, -1265377246, 974421189809558060L, 92723L, true, true, (char) 44032, (char) 63833,
        Double.longBitsToDouble(0x3fad5dae7c0ea870L), Double.longBitsToDouble(0x3fe3021a09a2157aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.MakeDeclaredNamesUnique:@?\0121=new com.google.javascript.jscomp.MakeDeclaredNamesUnique:@?\012",
        Z.run(T, 2, 8, 8, 0, "\udac7\udf47\ud85c\udc30\uda52\ude24\udb93\udc43", "\u5e24\u5650\ud38b\u07e5\u109f\u15dd\u925d\u3b84\u6762\ubd7b\u4417\u97d4\u143d\u4ce2\u995a\ua9d9", "\udba8\udd34\ud9ab\udf8d\ud91b\uddff\uda33\udcc8\ud9ee\ude4a\ud854\udf6c\ud9e1\ude4e\ud8d2\udf9b\ud919\udfc0\ud855\udc0f\uda87\ude10\uda56\udcd7",
        37, 24982, 385419030, 2788761518199058314L, 37100L, true, true, (char) 11789, (char) 755,
        Double.longBitsToDouble(0x3fecbbbe3076e67fL), Double.longBitsToDouble(0x3fe9859dcf2d810dL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.MakeDeclaredNamesUnique$ContextualRenameInverter:@?\0121=null |this=com.google.javascript.jscomp.MakeDeclaredNamesUnique:@?\012",
        Z.run(T, 2, 5, 6, 0, "\udac7\udf47\ud85c\udc30\ud8e7\udeae\ud916\udf40", "\uc3ee\u4163\u582f\ucff7\u89aa\ua9e5\u925d\u3b84\u6762\ubd7b\u0a68\u198c", "\ud8c4\udd3b\ud9fa\udd4c\udbb5\uded7\ud943\udd98\udba8\udd34\ud9ab\udf8d\udae7\ude2c\uda33\udcc8\ud9ee\ude4a\ud94c\udebb\ud8b7\udef8\ud8d2\udf9b\udb1f\udf8b\ud9e6\udda1\ud840\udcfa\udbe8\udef1\udae3\udf39\ud821\udf28\ud8b2\uddad\ud95c\uddb5\udb0d\ude4a\ud9c2\udc72\udb4b\udc3a\uda4b\udee5",
        3, 48515, -1106441819, 1890920768915536339L, -92463L, false, false, (char) 25006, (char) 56087,
        Double.longBitsToDouble(0x3fec87615aa4e694L), Double.longBitsToDouble(0x3fcfbbceefda5e3cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.MakeDeclaredNamesUnique:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 10, 0, "\udab4\udd1d\ud9c6\udce9\uda52\ude24\ud818\udca4", "\uc3ee\u4163", "\ud98a\ude8f\udb88\udee8\uda1a\udfbf\udb93\ude27\udb7f\udf4d\ud970\ude65\ud966\udd61\ud8dd\udef8\ud970\udd00\uc94a\ud8c4\udd3b\ud9fa\udd4c\udbb5\uded7\ud943\udd98\udba8\udd34\ud9ab\udf8d\udbff\udc90",
        26, 84499, -2012736164, -2037078416198391592L, -85445L, false, false, (char) 42100, (char) 64918,
        Double.longBitsToDouble(0x3fd8c7740feb6416L), Double.longBitsToDouble(0x3fd6c0313386d4eeL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.MakeDeclaredNamesUnique:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 10, "\udac7\udfe2\ud85c\udc30\uda52\ude24\ud8df\ude47\ud8e2\udfa5", "\u6dc8\ub11b", "\ud8ad\udebb",
        59, 86195, 789870942, -3026213202987663487L, -6895L, false, false, (char) 19568, (char) 7247,
        Double.longBitsToDouble(0x3fedf25ce4e9997eL), Double.longBitsToDouble(0x3fdabc02d45e8e3cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.MakeDeclaredNamesUnique:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 10, "\udac7\udfe2\ud85c\udc30\uda52\ude24\ud8df\ude47\ud8e2\udfa5\ud960\udcec\uda06\udd58\udbb8\udff6\ud888\udf78\udbdf\udc9a", "\u0175\u6473\u4a58\ua4fa\uc277\u1d88", "\uda9e\udd03\udab4\udc89\uda26\uddb3\ud848\udcaf\ud9b9\udd2d\ud950\udcad\ud9a9\ude45\udbbb\udcac",
        22, 99220, -1150350633, 7245269253957136967L, -16958L, true, false, (char) 9640, (char) 30832,
        Double.longBitsToDouble(0x3fea2c0cfdc61918L), Double.longBitsToDouble(0x3fe918eb21f872efL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.MakeDeclaredNamesUnique:@?\0121=null |this=com.google.javascript.jscomp.MakeDeclaredNamesUnique:@?\012",
        Z.run(T, 2, 6, 6, 2, "\uda93\udf4e\ud806\udc76\uda4e\udffc\ud8df\ude47\ud8e2\udfa5\ud960\udcec\udb1e\udc01\udbb8\udff6\ud888\udf8a\ud93a\ude70\uda9e\udd45\ud8ad\udebb\ud815\udcfe\udb1f\ude33\udb7f\udf4d\ud970\ude65\ud966\udd61\ud8e9\udde8\udb1f\udccc\ud8bc\udda9\uda9e\uddbc\udab4\udc89\uda26\uddb3\ud848\udd26\udba8\udd34\ud903\udeb8\ud848\udf31\uda87\udf41\ub118", "\u45c5\uc7b5\u2f84\u0d4e\u4f83", "\ud8ff\udf8a\udbc3\ude3e\udbbf\udce2\udaea\ude8a\ud9a8\uddcb\ud9be\udf38\udab3\udf9b\ud98b\udcc3\udb0c\uddfc\ud836\ude0c\ud8d1\udcc4\udaa6\udd19\uda07\udea1\uc0ec\udba4\uddf4\udaa2\udf12\ud8ff\udcca\ud8f0\udffd\udbdb\uddbd",
        35, 27307, 56506091, 8739600466914773077L, 79191L, false, true, (char) 15741, (char) 59233,
        Double.longBitsToDouble(0x3fcc21e1198bdd6cL), Double.longBitsToDouble(0x3fbb470b15c900f0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.MakeDeclaredNamesUnique$ContextualRenameInverter:@?\0121=com.google.javascript.jscomp.MakeDeclaredNamesUnique$ContextualRenameInverter:@?\012",
        Z.run(T, 2, 5, 5, 0, "\udac7\udf47\ud85c\udc30\uda52\ude24\ud990\udce0\ud8b8\ude5a\ud960\udcec", "\ub11b\u4342", "\uda1a\udfbf\udb93\ude27\udb7f\udf4d\ud84e\ude93\ud966\udd61\ud88f\udf7b\ud82b\udf45\uaa1d\ud82a\udc5c\udab4\udc89\udaa3\udfeb\ud9df\udec8\udb83\udeef\ud9b8\udea4\ud912\udd8d\udaa3\ude18\uda25\udfc3",
        57, 64662, 1327017071, -809500716647985242L, -51781L, true, true, (char) 63474, (char) 10825,
        Double.longBitsToDouble(0x3fb2246a1aac3f30L), Double.longBitsToDouble(0x3fda0aee1a8fc236L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.MakeDeclaredNamesUnique:@?\012",
        Z.run(T, 1, 6, 0, 1, "\uccbd\ud85f\udc62\ud82b\ude90\ud8f4\udf39\ud8b8\ude5a\udbed\udf60", "\ub11b\u07e5\u109f\u15dd\u925d\u3b84\u6762\u47c2\u0a68\u74dc\u143d\ud663\u6fce\u51aa\ud6cf\u8dd8\ub7ee\u3a67\u0560\u8e30", "\udbe2\udc3d\ud802\udfc3\udad7\udd8f\ud98a\uddf8\ud9dc\udcf1\uda9e\udc4f\ud86d\udf9a\udbaa\udd5d\udb34\udf3a\udb2c\udcff\ud9c3\udcfa\uda8f\uddc6\udb45\udfe8\ud91f\udcd6\ud9df\udc1b",
        24, 94878, -1736656921, 2506925239959894546L, -78702L, true, false, (char) 56547, (char) 65519,
        Double.longBitsToDouble(0x3fe6d205ef31d51dL), Double.longBitsToDouble(0x3feec2523c164bbaL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.MakeDeclaredNamesUnique|enterScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.MakeDeclaredNamesUnique:",
    "M|com.google.javascript.jscomp.MakeDeclaredNamesUnique|shouldTraverse|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.MakeDeclaredNamesUnique:",
    "M|com.google.javascript.jscomp.MakeDeclaredNamesUnique|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.MakeDeclaredNamesUnique:",
    "M|com.google.javascript.jscomp.MakeDeclaredNamesUnique|exitScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.MakeDeclaredNamesUnique:",
    "M|com.google.javascript.jscomp.MakeDeclaredNamesUnique|findDeclaredNames|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.jscomp.MakeDeclaredNamesUnique$Renamer|new:com.google.javascript.jscomp.MakeDeclaredNamesUnique:",
    "M|com.google.javascript.jscomp.MakeDeclaredNamesUnique|getContextualRenameInverter|com.google.javascript.jscomp.AbstractCompiler|static",
    "M|com.google.javascript.jscomp.MakeDeclaredNamesUnique|getReplacementName|java.lang.String|new:com.google.javascript.jscomp.MakeDeclaredNamesUnique:",
    "C|com.google.javascript.jscomp.MakeDeclaredNamesUnique|<init>|",
    "C|com.google.javascript.jscomp.MakeDeclaredNamesUnique|<init>|com.google.javascript.jscomp.MakeDeclaredNamesUnique$Renamer",
    "M|com.google.javascript.jscomp.MakeDeclaredNamesUnique|enterScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.MakeDeclaredNamesUnique:",
    "M|com.google.javascript.jscomp.MakeDeclaredNamesUnique|shouldTraverse|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.MakeDeclaredNamesUnique:",
    "M|com.google.javascript.jscomp.MakeDeclaredNamesUnique|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.MakeDeclaredNamesUnique:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
