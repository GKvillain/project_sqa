package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class PeepholeFoldConstants_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 12, 13, "\u3b5a\ud824\udf56\ud9b7\udfb6\ud8d1\udfcc\udb5a\udf7b\udbfd\udf10\udb62\udf46\udb60\uddd6\uda5e\udd04\udbe1\udf6f\uda6d\udd27", "\u1b38\uc98a\u533f\u7595\uc3ac\u9acf\u1bac\u6979\u10d2\u1ed0\u4659\ua82f\u6952\uc609\u3455\uad36\u1df8\u3b76\u9638\u9e0b\ucb3f\u0999\u1577\uce45\u2aac\ub388\ub189\u5385\u7f0a\u04e6\u1cf6\u0342\u2c3b\u833f\u8744\u5808\u1e9a\u10ad\u8577\u18be\u974a", "\ud830\udc60\udbeb\udc28\ud9da\udd0e\udb2f\ude19\ud844\udd35\udb4c\udccf\udaf4\ude1b\uda3f\udf7e\uda52\uded2\uda0f\udfbc\u0d87\u44fa\ud945\udda7\ud9d7\udcf0\udbaa\udeda\udb3d\udc38\ud965\uddbd\ud9fd\udfc1\ud8e5\udf47\ud850\udd6b\ud8d9\udfc5\ud985\udf7c\udbb5\udc38\uda8c\udddb\ud862\udc1f\ud97e\uddac\udb14\udd15\udaf8\udebf\ud966\udd02\udaeb\ude10\udad8\udde1\udb1d\udc6f\uda9d\ude6e\ud9ef\udcf2\ud9b6\udcca\udb1e\udd4a\ud990\udf18\ud83a\udda4\udb99\udd29\ud884\udfc0\udba0\ude6a",
        2, 13701, 1866715648, -4308681305566591976L, -54587L, false, true, (char) 288, (char) 58622,
        Double.longBitsToDouble(0x3fef84490f88e139L), Double.longBitsToDouble(0x3fefd704aa95c0d6L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 0, 13, "\u3b5a\ud824\udf56\ud9b7\udfb6\ud8d1\udfcc\udb5a\udf7b\udbfd\udf10\udb62\udf46\udb60\uddd6\uda5e\udd04\udbe1\udf6f\uda6d\udd27", "\u1213\u9f34\u533f\u7595\uc3ac\u9acf\u1bac\u6979\u10d2\u1ed0\u4659\ua82f\u6952\uc609\u3455\uad36\u1df8\u3b76\u9638\u9e0b\u32a8\u0999\u1577\uce45\u2aac\ub388\ub189\u5385\u7f0a\u04e6\u1cf6\u0342\u2c3b\u833f\u8744\u5808\u1e9a\u10ad\u8577\u18be\u974a", "\udb19\udf2c\udbeb\udc28\ud9da\udd0e\udb2f\ude19\ud844\udd35\udb4c\udccf\udaf4\ude1b\uda66\ude12\uda52\udea8\uda0f\udfbc\u0d87\u44fa\ud945\udda7\ud9d7\udcf0\udbaa\udeda\udb3d\udc38\ud965\uddbd\ud9fd\udfc1\ud8e5\udf47\ud850\udd6b\ud8d9\udfc5\ud985\udf7c\udbb5\udc38\uda8c\udddb\ud862\udc1f\ud97e\uddac\udb14\udd15\udaf8\udebf\ud966\udd02\udaeb\ude10\udad8\udde1\udb1d\udc6f\uda9d\ude6e\ud9ef\udcf2\ud9b6\udcca\udb1e\udd4a\ud990\udf18\ud83a\udda4\udb99\udd29\ud884\udfc0\udba0\ude6a",
        2, 13701, 1866715648, -4308681305566591976L, -58002L, false, true, (char) 64785, (char) 14530,
        Double.longBitsToDouble(0x3fefd704aa95c0d6L), Double.longBitsToDouble(0x3fdceef8a8f51f18L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 12, 13, "\u3b5a\ud824\udf56\ud9b7\udfb6\ud8d1\udfcc\udb5a\udf7b\udbfd\udf10\ud80b\udc1a\udb2c\udfed\uda5e\udd04\udbe1\udf6f\uda6d\udd27", "\u1b38\uc98a\u533f\u7595\uc3ac\u9acf\u1bac\u6979\u724d\u17ca\u4659\ua82f\u6952\uc609\u3455\uad36\u1df8\u3b76\u9638\u9e0b\ucb3f\u0999\u1577\uce45\u2aac\ub388\ub189\u5385\u7f0a\u04e6\u1cf6\u0342\u2c3b\u833f\u8744", "\u7edd\udad1\udee8\ud835\udf91\ud9bc\udfbc\uda66\udc3a\ud837\uddb4\ud830\udc60\udbeb\udc28\ud9da\udd0e\udb2f\ude19\ud844\udd35\udb4c\udccf\udaf4\ude1b\uda3f\udf7e\uda52\uded2\ud9db\ude8b\u0d87\u44fa\ud945\udda7\ud9d7\udcf0\udbaa\udeda\udb3d\udc38\ud965\uddbd\ud9fd\udfc1\ud8e5\udf47\ud850\udd6b",
        16, 20496, -310342320, 4411643347297154630L, -11977L, false, false, (char) 34793, (char) 64183,
        Double.longBitsToDouble(0x3fe9a8f230fc7142L), Double.longBitsToDouble(0x3fd3a3a4ce5d196aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 12, 13, "\u3b5a\udaec\udf5a\ud9b7\udfb6\ud8d1\udfcc\udb5a\udf7b\udbfd\udf10\udb62\udf46\udb60\uddd6\uda5e\udd04\udbe1\udf6f\uda6d\udd27", "\u1b38\uc98a\u533f\u7595\uc3ac\u9acf\u1bac\u6979\u10d2\u1ed0\u4659\u5020\u6952\uc609\u2841\ud29b\u1d51\u3b76\u9638\u9e0b\ucb3f\u0999\u1577\uce45\u2aac\ub388\ub189\u5385\u3702\u04e6\u1cf6\u0342\u2c3b\u833f\u87c2\u5808\u5d58\u0b97\u8577\u18be\u974a", "\ud830\udc60\udbeb\udc28\ud9da\udd0e\uda73\uddfb\uda6b\udcc9\udb2e\uddc6\udaf4\ude1b\uda3f\udf7e\uda52\uded2\uda57\udf1f\udbf3\udf87\u44fa\udbad\udd5b\ud954\udc32\udbaa\udf49\udb3d\udc38\udb1c\udfaf\ud9fd\udfc1\ud8e5\udf47\ud850\udd6b\ud8d9\udfc5\ud985\udf7c\udbb5\udc38\uda8c\udddb\ud862\udc1f\ud9b8\udf1e\udbd2\uddb6\udb99\udf17\ud966\udd02\udaeb\ude10\udad8\udde1\udb1d\udc6f\udaf9\udc1a\ud9bb\udd98\ud9b6\udcf7\udb1e\udd4a\ud990\udf18\udabf\udd47\ud9b3\udca6\ud884\udfc0\udba0\ude6a",
        2, 13701, 1866715648, -4308681305566591976L, -54587L, false, true, (char) 288, (char) 58622,
        Double.longBitsToDouble(0x3fa94490bd40edc0L), Double.longBitsToDouble(0x3fe27f665a956adfL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 12, 13, "\u3b5a\ud834\ude7f\udb59\ude01\ud8d1\udfcc\udb5a\udf7b\udbfd\udf10\uda00\ude75\udb54\udf9b\uda5e\udd04\udbe1\udf6f\uda6d\udd27", "\u1b38\uc98a\u533f\u7595\uc3ac\u9acf\u1bac\u6979S\u1ed0\u4659\ua82f\u6952\uc609\u3455\uad36\u1df8\u4323\u935f\u9e0b\u605b\uabaa\u7828\uce45\u2aac\ub388\ub189\u5385\u7f0a\ubfe5\u1cf6\u029a\u2c3b\u833f\u8744\u5808\u82c0\u4791\u99db\u18be\u974a", "\ud830\udc60\udbed\udec1\ud9da\udd0e\udb2f\ude19\uda86\ude15\udb29\udd1e\udaf4\ude1b\uda3f\udf7e\uda52\uded2\uda0f\udfbc\uda57\uddf0\udae8\udf2c\ud9a6\udd62\ud9d7\udcf0\udbaa\udeda\udb3d\udc38\ud965\uddbd\ud9fd\udfc1\ud8e5\udf47\ud850\udd6b\ud8d9\udfc5\ud985\udf7c\udbb5\udc38\uda8c\udddb\ud862\udc1f\ud97e\uddac\udb14\udd15\udaf8\udebf\ud966\udd02\udaeb\ude10\udad8\udde1\udb1d\udc6f\uda9d\ude6e\ud8a3\udfce\udbec\udc1c\ud8e6\udd4d\uda00\udf39\ud83a\udce5\udb99\udd29\ud884\udfc0\udba0\ude6a",
        2, 13701, 1866715648, -4587396327702903784L, -54587L, false, true, (char) 288, (char) 58622,
        Double.longBitsToDouble(0x3fef84490f88e139L), Double.longBitsToDouble(0x3fefd704aa95c0d6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 12, 13, "\u3b5a\ud824\udf56\ud9b7\udfb6\ud8d1\udfcc\udb5a\udf7b\udbfd\udf10\udb62\udf46\udb60\uddd6\uda5e\udd04\udbe1\udf6f\uda6d\udd27", "\u1b38\uc98a\u3910\u75a5\uc3ac\u9acf\u1bac\u6979\u10d2\u1ed0\u4659\ua82f\u6952\uc609\u3455\uad36\ud772\ubd34\u9638\u9e0b\ucb3f\u0999\u1577\uce45\u2aac\ub388\ub189\u5385\u7f0a\u04e6\u1cf6\u0342\u2c3b\u833f\u8744\u5808\u1e9a\u10ad\u8577\u18be\ucdaa", "\ud830\udc60\u7b29\ud9da\udd0e\udb2f\ude4f\udb10\udd3f\udb4c\udccf\udaf4\ude1b\uda3f\udf7e\uda52\uded2\uda0f\udfbc\u0d87\u44fa\ud945\udda7\ud9d7\udcf0\udbaa\udeda\udb3d\udc38\ud965\uddbd\ud9fd\udfc1\ud8e5\udf47\ud850\udd6b\ud8d9\udfc5\ud985\udf7c\udbb5\udc38\uda8c\udddb\ud862\udc1f\ud97e\uddac\udb14\udd15\udaf8\udebf\ud966\udd02\udaeb\ude10\udad8\udde1\udb1d\udc6f\ud8ce\udcfe\ud97f\ude5e\ud9b6\udd25\udb1e\udd4d\ud990\udf18\ud83a\udda4\u77cd\ud8d9\udd07\udba0\uddf3",
        2, 13701, 213111296, -4308579849849125864L, -54587L, true, true, (char) 288, (char) 58622,
        Double.longBitsToDouble(0x3fef84490f88e139L), Double.longBitsToDouble(0x3fefd704aa95c0d6L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 12, 13, "\u3b5a\ud824\udf56\ud9b7\udfb6\ud8d1\udfcc\udb5a\udf7b\udbfd\udf10\udb62\udf46\udb60\uddd6\uda5e\udd04\udbe1\udf6f\uda6d\udd27", "\u1b38\uc98a\u533f\u7595\uc3ac\u9acf\u1bac\u6979\u10d2\u1ed0\u4659\ua82f\u6952\uc609\u3455\uad36\u1df8\u2b63\000\u9e0b\ucb3f\u0999\u1577\uce45\u1fb5\u05d6\ub189\u5385\u7f0a\u04e6\u1cf6\u0342\u2c3b\u833f\u8744\u5808\u1e9a\u10ad\u8577\u18be\u974a", "\ud830\udc60\udbeb\udc28\ud9da\udd0e\udb2f\ude19\ud844\udd35\udb4c\udccf\udaf4\ude1b\uda3f\udf7e\uda52\uded2\uda0f\udfbc\u0d87\u44fa\ud945\udda7\ud9d7\udcf0\udbaa\udeda\udb3d\udc38\ud965\uddbd\ud9fd\uded6\ud8e5\udf47\ud850\udd6b\ud8d9\udfc5\ud985\udf7c\udbb5\udc38\uda8c\udddb\ud862\udc1f\ud97e\uddac\udb14\udd15\udaf8\udebf\ud966\udd02\udaeb\ude10\udad8\udde1\udb1d\udc6f\uda9d\ude6e\ud9ef\udcf2\ud9b6\udcca\udb1e\udd4a\ud990\udf18\ud83a\udda4\udb99\udd29\ud884\udfc0\udba0\ude6a",
        2, 13701, 1866715648, -4308681305566591976L, -54587L, false, true, (char) 288, (char) 58622,
        Double.longBitsToDouble(0x3fef84490f88e139L), Double.longBitsToDouble(0x3fefd704aa95c0d6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldShift|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|optimizeSubtree|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldAdd|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldAddConstant|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldAndOr|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldArithmetic|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldAssign|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldBinaryOperator|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldBitAndOr|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldComparison|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldGetElem|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldGetProp|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldInstanceof|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldKnownMethods|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldLeftChildAdd|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldStringIndexOf|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
    "M|com.google.javascript.jscomp.PeepholeFoldConstants|tryFoldShift|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeFoldConstants:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
