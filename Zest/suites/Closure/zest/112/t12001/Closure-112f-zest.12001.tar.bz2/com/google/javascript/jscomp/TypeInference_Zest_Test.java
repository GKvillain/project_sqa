package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeInference_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 10, 12, "\uda2a\udf27\uda0e\udd4f\udbcc\udc75\uda56\udd20\ud9d7\ude85\ud89f\udee9\ud984\udd4f\udae2\udf79\ud774\ud85a\udd31\ud8d4\udeaa\ud906\udff8\udbe8\udd5f\uda57\ude82\udb82\ude92\uda3c\udc8e\ud802\udd98\uda6c\udeeb\ud98c\udca9\ud972\udd8f\uda37\udd21\ud9ad\udc40", "\ucaf1\u9493\ub07f\ubdc3\ucf89\uaf30\uc12b\u3d8b\u3c3f\u3d24\u4b76\u6be6", "\udafa\uddf6",
        32, 96528, 1696609755, -1653432937457219438L, -67505L, false, true, (char) 50033, (char) 20558,
        Double.longBitsToDouble(0x3fd1e6061acdb9dcL), Double.longBitsToDouble(0x3fd3e34073401d3eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 10, 12, "\uda2a\udf27\uda0e\udd4f\udbcc\udc75\uda56\udd20\ud9d7\ude85\ud89f\udee9\ud984\udd4f\udae2\udf79\ud774\ud85a\udd31\ud8d4\udeaa\ud906\udff8\udbe8\udd5f\uda57\ude82\udb82\ude92\uda3c\udc8e\ud802\udd98\uda6c\udeeb\ud98c\udca9\ud972\udd8f\uda37\udd21\ud9ad\udc40", "\ucaf1\u9493\ub07f\ubdc3\ucf89\u2814\ub958\u3d8b\u3c3f\u3d24\u4b76\u6be6", "\udafa\uddf6",
        32, 96528, 1696639195, -1653432937457219438L, -67505L, false, true, (char) 50033, (char) 20558,
        Double.longBitsToDouble(0x3fd1e6061acdb9dcL), Double.longBitsToDouble(0x3fd3e34073401d3eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 4, 10, "\uda2a\udf27\uda0e\udd4f\udbcc\udc75\uda56\udd20\ud9d7\ude85\ud89f\udee9\ud984\udd4f\udae2\udf79\ud774\ud85a\udd31\ud8d4\udeaa", "\u7275\u274a\u94d6\u560e\u36c1\u58c9\u28aa\u2f1c\u4820\u5edf\ud06a\ucaf1", "\uda74\udf76\ud8e2\ude7c\udb42\udfe8\udb7c\udf6c\udb87\udfb5\ud916\uded6\ud969\uded4\ud882\ude24\ud8aa\udf05\udb31\udcb9\ud9a0\udd6e\udafa\uddf6\uda56\ude22\udb13\udc28\uda7a\udfd0\udb40\ude26\ud9df\udf90\ud84a\udc45\udb72\udf58\udbc3\udd3e\ud93e\udf45\udbfd\udf05\udbb4\udf0c\udbba\udc76\uda74\ude1a\ud912\uddcf\ud94e\udf6c\ud804\udf5a",
        3, 5064, 889041516, 6980861838645536341L, 62708L, true, false, (char) 61409, (char) 48472,
        Double.longBitsToDouble(0x3fd223e7a4a6de26L), Double.longBitsToDouble(0x3fdd1e9dde566b26L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 10, 12, "\uda2a\udf27\ud9e2\ude1a\udbcc\udc75\uda56\udd20\ud9d7\ude3b\ud89f\udee9\ud984\udd4f\udae2\udf79\ud774\ud8e1\udcf4\ud8d4\udea6\ud906\udff8\udbe8\udd5f\ud8cc\udcfc\udb82\ude92\uda3c\udc8e\ud802\udd98\ud8e6\udee8\ud98c\udca9\ud972\udd8f\ud8fa\udd61\ud9ad\udc1b", "\ucaf1\u9493\ub07f\ubdc3\ucf89\uaf30\uc12b\u3d8b\u3c3f\u3d24\u4b76\ud774", "\udafa\uddf6\uda0f\udd7e\udb13\udc28",
        30, 41145, -286357358, 2250223587332226799L, 54910L, false, true, (char) 7493, (char) 55358,
        Double.longBitsToDouble(0x3fd3c620870eef44L), Double.longBitsToDouble(0x3f9fd404984edaa0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 10, 12, "\udb27\udc8b\uda0e\udd4f\udbcc\udc75\uda56\udd20\ud9d7\ude85\ud89f\udee9\ud984\udd4f\udae2\udf79\ud9ca\udd9e\ud979\udea1\ud8d4\udeaa\ud906\udff8\udbe8\udd5f\uda57\ude82\udb82\ude92\uda3c\udc8e\ud802\udd98\udb3f\ude3c\udadd\udc4b\udb33\udd34\ud8b7\ude46\ud9d9\udcb0", "\u3f70\u6d2c\u8aa6\u484c\u17f9\uaf30\uc12b\u3d8b\ud05a\u3d24\u4b76\u6be6", "\udafa\uddf6",
        32, 96528, 1696609755, -1653432937457219438L, 63567L, false, true, (char) 50033, (char) 20558,
        Double.longBitsToDouble(0x3fd1e9e46acdb9dcL), Double.longBitsToDouble(0x3fd3e34073401d3eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 10, 12, "\uda2a\udf27\ud8ad\udc7e\udbcc\udcb2\uda56\udd20\ud9d7\ude85\u20fd\ud984\udd4f\udae2\udf79\ud774\ud85a\udd31\ud867\udfad\ud8ff\udd33\uda71\udf36\ud97e\ude7e\udb6f\udf4e\uda3c\udc8e\ud802\udd98\udb18\udee1\ud98c\udca9\ud852\udd0c\udac5\uddb4\ud9ad\udc40", "\ucaf1\u15c3\uc5c1\uc10d\u5bf8\uaf30\u5b2c\u3d8b\u3c3f\u5207\u4b76\u8b46", "\udafa\uddf6",
        32, 96528, 1696609755, -1653432937457219438L, -67505L, false, true, (char) 50033, (char) 20558,
        Double.longBitsToDouble(0x3fd1e606145f9e9eL), Double.longBitsToDouble(0x3fd3e347addc1d3eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:EMPTY\012",
        Z.run(T, 1, 11, 10, 12, "\uda2a\udf27\uda0e\udd4f\udbcc\udc75\uda56\udd20\ud9d7\ude85\ud89f\udee9\ud984\udd4f\udae2\udf79\ud774\ud85a\udd31\ud8d4\udeaa\ud906\udff8\udbe8\udd5f\uda57\ude82\udb82\ude92\ud867\udca3\udbec\ude07\ud85a\ude85\ud98c\udca9\ud972\udd8f\uda37\udd21\ud9ad\udc40", "\ucaf1\u9493\ub07f\ubdc3\u5e63\uaf30\uc12b\u68d0\ucf0a\u4e23\u4b6e\u6be6", "\udafa\uddb6",
        32, 96528, 1696609755, -1653432937457219438L, -67505L, false, true, (char) 50033, (char) 20558,
        Double.longBitsToDouble(0x3fd1e6061acdb9dcL), Double.longBitsToDouble(0x3fd3e34073401d3eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 2, 6, "\uda23\udf59\udb4e\ude71\ud84d\udeb5\ud814\uddb4\ud9d7\ude85\ud89f\udee9\ud984\udd4f\udae2\udf79\ud774\ud8e2\udfc9\ud8d4\udeb1\ud906\udff8", "\u26b0\u94d6\u560e\u36c1\u58b7\u28ac\u2f1c\u4820\u5edf\ud06a", "\ud915\udc77\uda74\udf76\ud8e2\ude7c\udb42\udfe8\udb7c\udf6c\udb87\udfb5\ud916\uded6\ud969\uded4\ud81c\ude2b\ud8aa\udf05\udb6b\uddcc\ud9a0\udd6e\udafa\uddf6\uda56\ude22\udb13\udc28",
        30, 41145, -286357358, 2250223585436401391L, 54910L, false, true, (char) 2517, (char) 55358,
        Double.longBitsToDouble(0x3fb7c0c88fd3bd50L), Double.longBitsToDouble(0x3fcf62eadfe17920L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 4, 10, "\uda2a\udf27\udb21\udef9\ud9ed\ude44", "\u6eef\uc3d7\u0e43\u947e\u2fc1\u24ea\u0bb9", "\udb82\ude92\uda3c\udc8e\ud802\udd98\uda6c\udeeb\uda18\udd3e\udab0\udf1b\uda3f\ude9d\ud9ad\udc40\ud822\udf3c\udb10\udca6",
        53, 73920, 1013436648, 2706409665723550598L, -40753L, false, true, (char) 64306, (char) 59013,
        Double.longBitsToDouble(0x3fca3fd006b059ecL), Double.longBitsToDouble(0x3f41e4304ea12c00L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\012",
        Z.run(T, 1, 11, 4, 10, "\udae4\udec4\uda80\udd8f\uda04\udc86\uda59\ude76\ud9d7\ude85\uee36\ud97b\udd06\udae2\udf79\ud9d5\udea7\udbfe\udcd7\ud8d4\udeaa", "\ua119\u308a\u56c3\u6b5a\u4c87\u5875\u28aa\u4c26\u47f8\u5edf\ud06a\ucaf1", "\uda74\udfef\ud8e2\ude7c\udb42\udfe8\udb7c\udee9\udb87\udfb5\ud916\uded6\ud969\uded4\ud882\ude24\ud8aa\udf05\udb31\udcb9\uda10\udca9\uda4c\ude52\uda56\ude26\udb13\udc28\uda7a\udfd0\udb40\ude26\ud9df\udf90\ud84a\udc45\udb72\udf58\udbc3\udd3e\ud93e\udf45\udab0\udd0a\ud95c\ude89\udba6\udc3e\uda74\ude1a\ud912\uddcf\ud951\uddc3\ud81b\udec5",
        3, 5064, 889041516, 6980861838640450389L, 62708L, true, false, (char) 61409, (char) 54728,
        Double.longBitsToDouble(0x3fd223e7a4a6de26L), Double.longBitsToDouble(0x3fdd1e9ddc246b26L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 4, 8, "\udac9\udc36\uda23\uddc2\udbd5\udce8\ud935\ude22\uda28\ude63\ud89f\udee9\ud984\udd4f\udae2\udf79\ud768\ud9c2\ude44\ud8d4\udeaa\ud906\udff8\ud87b\udda6\uda57\ude82\udb82\ude92\uda3c\udc8e\ud802\udd98\uda6c\udeeb\ud98c\udca9\ud972\udd8f\uda37\udd21\ud9ad\udc40\ud822\udf3c\udb10\udca6", "\u7bec", "\udb42\udfe8\ud928\udd63\ud8c3\udf5e\uda56\udfc9\ud9b0\udecf\ud884\udc7d\ud8aa\udf05\udb31\udcb9\ud9a0\udd6e\udafa\ude66\uda56\ude22\udb13\udc28\uda7a\udfd0\udb40\ude26\udaaf\udf57\ud84a\udc45\ud94e\uddac\udbc3\udddb\ud93e\udf45\udbfd\udf05\udba7\ude46",
        29, 42062, 1495452064, 2957709055328969260L, -34245L, true, false, (char) 36345, (char) 61684,
        Double.longBitsToDouble(0x3fe6cd8536ba9127L), Double.longBitsToDouble(0x3fb9713cc911f3d0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:BOTH\012",
        Z.run(T, 1, 11, 10, 12, "\uda2a\udf27\uda0e\udd4f\udbcc\udc75\uda56\udd20\ud9d7\ude85\ud89f\udee9\ud984\udd4f\udae2\udf79\ud774\ud85a\udd31\ud8d4\udeaa\ud906\udff8\udbe8\udd5f\uda57\ude82\udb82\ude92\ud867\udca3\udbe6\udcee\ud85a\ude85\ud98c\udca9\ud972\udd8f\uda37\udd21\udbac\udd22", "\ucaf1\u3538\ub07f\ubdc3\u5e63\uaf30\uc12b\u68d0", "\ud882\ude1c\ud8aa\udf05\udb31\udcb9\ud9a0\udd6e\udafa\uddb6\uda47\udf80",
        48, 10755, -384969855, -1229895487259187602L, 65926L, false, true, (char) 14933, (char) 7493,
        Double.longBitsToDouble(0x3fda00e9fcdb7288L), Double.longBitsToDouble(0x3fe773c310a09868L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:TRUE\012",
        Z.run(T, 1, 11, 10, 12, "\uda2a\udf27\uda0e\udd4f\udbcc\udc75\ud9b3\uded0\ud9ce\udece\ud89f\udee9\ud984\udd4f\udae2\udf79\ud774\ud85a\udd31\ud983\ude02\ud906\udff8\udbe8\udd5f\uda57\ude82\udb82\ude92\ud867\udca3\udb72\udd52\ud94f\ude58\ud985\udca8\ud972\udd8f\uda37\ude00\ud979\udf3b", "\ub6ee\u58b8\ub07f\ubdc3\u5e63\uaf30\uc12b\u68d0\ucf0a\u4e1f\u4b6e\u85e5", "\udafa\uddb6",
        5, 96684, 1696609755, -1653432937457219438L, -67505L, false, true, (char) 50033, (char) 20558,
        Double.longBitsToDouble(0x3fd1e6061acdb9dcL), Double.longBitsToDouble(0x3fd3e34073401d3eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:BOTH\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 12, "\uda2a\udf27\uda0e\udd4f\udbcc\udc75\uda56\udd20\ud9d7\ude85\ud89f\udee9\udbb8\udda9\ud96b\uddea\udb2e\udef8\ud85a\udd31\ud8d4\udeaa\udba6\udf1e\udbdb\ude98\uda57\ude82\udb82\ude92\ud900\udc8f\udaac\udc07\ud836\udef4\ud98c\udca9\ud972\udd8f\uda37\udd21\ud9ad\udc40", "\ucaf1\u9493\ub07f\ubdc3\u5e63\uaf30\uc12b\u68d0\ucf0a\u4e23\u4b6e\u6be6", "\udafa\uddb6",
        -1, 29750, 1696609755, -1653432937457219438L, -67505L, false, true, (char) 50033, (char) 20558,
        Double.longBitsToDouble(0x3fd1e6061acdb9dcL), Double.longBitsToDouble(0x3fd3e34073401d3eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:EMPTY\0121=com.google.javascript.rhino.jstype.BooleanLiteralSet:EMPTY\012",
        Z.run(T, 2, 11, 11, 8, "\udac9\udc36\uda23\uddc2\udbd5\udce8\ud935\ude22", "\u568a\u0e43\u9472\uae46\u4444\u0bb9\u9992\u7275\u274a\u94d6\u51d7\u888a\u58c9\u28aa\u2f1c\u4820\u5edf\ud06a\u6680\ucaea\u7bec\ubc48\ucf89\uaf30\ub66b\ube00\u95d0\u1e79\u40e6\u6bc7", "\udafa\ude66",
        40, 96528, 1696609755, -1653432935252471150L, -14769L, false, true, (char) 50033, (char) 57628,
        Double.longBitsToDouble(0x3fd1e6bfa75917dcL), Double.longBitsToDouble(0x3fd3e34a5340433eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:BOTH\0121=com.google.javascript.rhino.jstype.BooleanLiteralSet:BOTH\012",
        Z.run(T, 2, 11, 11, 6, "\ud885\udc1a\uda23\uddc2\udbd5\udce8\ud935\ude22\uda28\ude63\ud89f\udee9\ud984\udd4f\ud9cc\udc91\ud9b5\ude17\udbd3\udc67\ud8d4\udf0a\ud906\udff8\u0e0c\uda57\ude82\udb82\ude92\uda3c\udc8e\ud802\udd98", "\u28aa\u2f1c\u4820\u5edf\ud06a\u6680\u8375\u7bec\ubc48\ucf89\uaf30", "\uda56\udfc9",
        41, 53138, -1893604948, -6319920295211195373L, -3994L, false, true, (char) 17601, (char) 10144,
        Double.longBitsToDouble(0x3fc25d21b9b9cba8L), Double.longBitsToDouble(0x3fcde3e74e8722b4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\0121=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\012",
        Z.run(T, 2, 11, 11, 8, "\udab5\ude4f\uda23\uddc2\udbc2\udc61\ud935\ude22\uda28\ude63\ud89f\udee9\ud984\udd4f\udae2\udf79\ud768\ud9c2\ude44\ud8d4\udeaa\ud906\udff8\udad3\udf87\udb48\udd57\udaeb\uddac\ud884\ude7c\ud8f9\udf24\ud999\udfef\uda89\udc88\ud964\udee9\uda37\udd21\ud9ad\udc40\ud822\udf3c\udb10\udca6", "\u7bec\ubc45", "\uda28\udfc2\ua55e\ud942\udcf1\ud8b6\udc6b\ud884\udcc2\ud8aa\udf05\udb31\udcb9\ud9b2\ude6e",
        19, 51510, 619070280, 7286883412454790017L, 57294L, true, true, (char) 48461, (char) 50033,
        Double.longBitsToDouble(0x3fc53b0e7479afe8L), Double.longBitsToDouble(0x3fed645f713e6da5L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:TRUE\0121=com.google.javascript.rhino.jstype.BooleanLiteralSet:TRUE\012",
        Z.run(T, 2, 11, 11, 8, "\udac9\udc36\uda23\uddc2\udbd5\udce8\ud935\ude22", "\u568a\u0e43\u9472\uae46\u4444\u0bb9\u9992\u7275\u274a\u8f39\u51d7\u888a\ua11d\u56e8\u2f1c\u4820\u5edf\uac7b\ua4a8\ucaea\u7bec\ubc48\u2cde\uaf30\ub66b\ube00\u95d0\u1e79\u40e6\u6bc7", "\u056c",
        43, 96528, 1696609755, -1653432935252471150L, -14769L, false, true, (char) 50033, (char) 57628,
        Double.longBitsToDouble(0x3fd1e6bfa7580e6cL), Double.longBitsToDouble(0x3fd3e34a537c433eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 10, 12, "\uda2a\udf27\uda0e\udd4f\ud9a6\udcd3\udbb8\ude32\ud9f9\udeb3\ud89f\udee9\ud984\udd4f\udae2\udf79\ud774\ud85a\udd31\ud8d4\udeaa\ud906\udff8\udbe8\udd5f\uda57\ude82\udb82\ude92\uda3c\udc8e\ud802\udd98\uda6c\udeeb\ud98c\udca9\ud972\udd8f\uda37\udd21\ud9ad\udc40", "\ucaf1\u9493\ub07f\ubdc3\ucf89\uaf30\uc12b\u3d8b\u3c3f\u3d24\u4b76\u6be6", "\udafa\uddf6",
        32, 96528, 1696609755, -1653432937457219438L, -67505L, false, true, (char) 50033, (char) 20558,
        Double.longBitsToDouble(0x3fd1e6061acdb9dcL), Double.longBitsToDouble(0x3fd3e34073401d3eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.TypeInference|inferTemplatedTypesForCall|com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.FunctionType|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|backwardsInferenceFromCallSite|com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.FunctionType|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|branchedFlowThrough|com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|createEntryLattice||new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|createInitialEstimateLattice||new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|dereferencePointer|com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|ensurePropertyDeclared|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|ensurePropertyDeclaredHelper|com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.ObjectType|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|ensurePropertyDefined|com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|flowThrough|com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|getBooleanOutcomePair|com.google.javascript.jscomp.TypeInference$BooleanOutcomePair,com.google.javascript.jscomp.TypeInference$BooleanOutcomePair,boolean|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|getBooleanOutcomes|com.google.javascript.rhino.jstype.BooleanLiteralSet,com.google.javascript.rhino.jstype.BooleanLiteralSet,boolean|static",
    "M|com.google.javascript.jscomp.TypeInference|getJSType|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|getNativeType|com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|getPropertyType|com.google.javascript.rhino.jstype.JSType,java.lang.String,com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|inferArguments|com.google.javascript.jscomp.Scope|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|inferTemplatedTypesForCall|com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.FunctionType|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
