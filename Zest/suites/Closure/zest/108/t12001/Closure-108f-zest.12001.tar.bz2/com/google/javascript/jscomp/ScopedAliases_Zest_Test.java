package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class ScopedAliases_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "\udb01\udf1a\udbc7\udfdd\ud937\ude48\uda98\ude86\uda92\udca2\uda2c\ude67\udb3b\uddce\ud8cb\udef6\ud857\ude30\udad8\udd9b\uda0e\udff2\uda6f\udde6\uda93\ude06\udac7\udd62\udb5a\udd77\udbd4\udf0d\udbf1\uddea", "\u442f\u1c35\u81d1\u108f\u7fd0\u0af4\uabb0\u4206\u0ad8\u91ae\u2426\u1eef\u7fc5\u6e7f\u0785\u16ee\u2da2", "\udb5c\udc55\uda61\udf48\ud9c9\udd22\ud8af\udf96\udaba\uddba\udbd5\udfbd\udad7\udfc5\udac9\udce0\udabb\udf34",
        49, 10920, 1359721283, 4738538803837101718L, -93299L, false, true, (char) 60085, (char) 63824,
        Double.longBitsToDouble(0x3fd565868c263a72L), Double.longBitsToDouble(0x3fa03641bd1fe650L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "\udb01\udf1a\udbc7\udfdd\ud937\ude48\uda98\ude86\uda92\udca2\uda2c\ude67\udb3b\uddce\ud8cb\udef6\ud857\ude30\udad8\udd9b\uda0e\udff2\uda6f\udde6\uda93\ude06\udac7\udd62\udb5a\udd77\udbd4\udf0d\udbf1\uddea", "\u442f\u1c35\u81d1\u108f\u7fd0\u0af4\uabb0\u4206\u0ad8\u91ae\u2426\u1eef\u7fc5\u6e7f\u0785\u16ee\u2da2", "\udb5c\udc55\uda61\udf48\ud9c9\udd22\ud8af\udf96\udaba\udcde\udbd5\udfbd\udad7\udfc5\udac9\udce0\udabb\udf34",
        49, 10920, 1359721283, 4738538803837101718L, -93299L, false, true, (char) 60085, (char) 63824,
        Double.longBitsToDouble(0x3fd565868c263a72L), Double.longBitsToDouble(0x3fa03641bd1fe650L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\udb01\udf1a\udbc7\udfdd\ud937\ude48\uda98\ude86\uda92\udca2\uda2c\ude67\udb3b\uddce\ud8cb\udef6\ud857\ude30\udad8\udd9b\uda0e\udff2\uda6f\udde6\uda93\ude06\udac7\udd62\udb5a\udd77\udbd4\udf0d\udbf6\uddea", "\u442f\u1c35\u81d1\u018f\u4677\u4049\u025c\u4fb8\u0ad8\u91ae\u2426\u3a49\u95d8\ud73a\u071b\u98b4\ube39", "\udb5c\udc55\uda61\udf48\ud9c9\udd22\ud8af\udf96\udaba\udd23\udbd5\udfbd\udad7\udfc5\udac9\udce0\udabb\udf34",
        49, 88312, -1525959753, -5018243279702014617L, -27763L, false, false, (char) 16586, (char) 32386,
        Double.longBitsToDouble(0x3fe65a199649f2fcL), Double.longBitsToDouble(0x3fa03641b96eb570L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 1, "\ud478\ud998\udc96\ud85d\udd4b\ud990\udc6e\uda92\udca2\uda2c\ude67\udb3b\uddce\ud8cb\udef6\ud857\ude30\udad8\udd9b\uda0e\udff2\uda6f\udde6\uda93\ude06\udac7\udd62\ud9d9\uded2\udbd4\udf0d\udbf1\uddea\ud871\udd42\ud8c6\udead\ud98b\udcd9\ud927\udcfd\ud9e3\udd9b\ud8bc\udccd\uda7c\ude3b\ud923\udd16\ud96b\udf97\uda0f\udf04\uda45\ude06\ud84b\udce7\udac1\udd65", "\uc9af\u56c2\u16ee\u2e14\u132d\u77d3\u2557\u136a\u1bb1\ua9e7\u041e\u7e25\ubd24\ua649\u51a1\u8600\uc3a5\u4351\u79e0\u5c7c\u48d1\u0701\u08fb\u5815\u9b49\u4810\ubeae\u9e39\u9694\u7c5c\ub520\uc892\ud2fd\u5cfa\u5923\u7df0\ub035\u6590\u7d4d\uc32d\u4929\u28dc\u4fac\u6164", "\ud95a\uddc7\ud992\udc56\uda5e\udd3b\ud8fa\ude4d\ud86f\udd9c\ud8c6\udd17\ud970\udd4b\udb45\ude75\ud82b\ude18\udada\ude24\uda90\udfce\uda7a\udddc\ud803\udd19\ud99d\ude57\ud831\udd89",
        52, 80125, -1737587656, -551279431662932396L, 46581L, true, false, (char) 19115, (char) 56279,
        Double.longBitsToDouble(0x3fddde6293488a12L), Double.longBitsToDouble(0x3fc33c12d1bb741cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "\udb01\udf1a\udbc7\udfdd\ud937\ude48\uda98\ude86\uda92\udca2\ud9e7\udc05\ud8d4\udf56\ud8cb\udef6\ud857\ude30\udad8\udd9b\uda0e\udff2\uda6f\udde6\uda93\ude06\udac7\udd7e\udb5a\udd77\udbd4\udf0d\uda77\udded", "\u442f\u6c82\u81d1\ucf5f\u7fd0\u0af4\uabb0\u66d6\ua843\u90d8\u2426\u1eef\u7fc5\u6e7f\ud1b6\u1511\u2da2", "\udb5c\udc55\uda61\udf48\ud9c9\udd22\ud876\udf1d\udbf3\ude4d\ud996\uddc4\udad7\udfd1\udac9\udce0\udabb\udf34",
        37, 14118, 1359721283, 4738538803837101718L, -93299L, false, true, (char) 60085, (char) 63824,
        Double.longBitsToDouble(0x3fd565868d9e3a72L), Double.longBitsToDouble(0x3fa03641bd1fe650L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.ScopedAliases|hotSwapScript|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ScopedAliases:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.PreprocessorSymbolTable,com.google.javascript.jscomp.CompilerOptions$AliasTransformationHandler",
    "M|com.google.javascript.jscomp.ScopedAliases|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ScopedAliases:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.PreprocessorSymbolTable,com.google.javascript.jscomp.CompilerOptions$AliasTransformationHandler",
    "C|com.google.javascript.jscomp.ScopedAliases|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.PreprocessorSymbolTable,com.google.javascript.jscomp.CompilerOptions$AliasTransformationHandler",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
