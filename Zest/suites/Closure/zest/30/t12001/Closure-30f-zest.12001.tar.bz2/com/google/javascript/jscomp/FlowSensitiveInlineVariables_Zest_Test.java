package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class FlowSensitiveInlineVariables_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 9, 16, "\uda34\ude5e\udb5f\udff0\udaf4\udf75\udb97\udf91\ud814\ude8d\ud94a\udc33\udb11\udcc8\udbdd\udda7\ud86f\ude50\ud912\udd7a\ud9a0\uddd3", "\u3a81\ud026\u2d6e\u5e8c\u3473\u7542\ub8da\u15a2\u0139\ua595\u16ca", "\ud9ca\udc21\ud8de\udfaf\ud8ff\uddf7\ud968\ude4e\uda4d\udfb3",
        43, 36138, 2016819216, 8326144441204262492L, 67908L, true, true, (char) 24435, (char) 16089,
        Double.longBitsToDouble(0x3fe2d51003441aadL), Double.longBitsToDouble(0x3fc0a725dfdc0ca8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 9, 16, "\uda34\ude5e\udb5f\udff0\udaf4\udf75\udb97\udf91\ud814\ude8d\uda1c\udf24\ud894\ude01\ud9d1\udde5\ud86f\ude50\ud912\udd7a\ud9a0\uddd3", "\u3a81\ud026\u2d6e\u5e8c\u3473\u7542\u1245\u4870\u0139\ua595\u17ad", "\ud9ca\udc21\ud8de\udfaf\ud8ff\uddf7\ud968\ude4e\uda4d\udfb3",
        43, 36138, 2016819216, 8326144441204262492L, 67908L, true, true, (char) 11124, (char) 16089,
        Double.longBitsToDouble(0x3fe2d51003441aadL), Double.longBitsToDouble(0x3fc0a725dfdc0ca8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 9, 16, "\ud95d\udf2c\udb5f\udff0\udaf4\udf75\udb97\udf91\ud814\ude8d\ud8a1\udd5f\udb29\udc19\udbdd\udda7\ud8f7\ude54\ud912\udd7a\ud9a0\uddd3", "\u3a81\ud026\u2d6e\u5e8c\u3473\u7542\ub8da\u15a2\u0139\ua595\u16ca", "\ud8e1\ude8d\ud8df\udc45\ud8ff\uddf7",
        56, 40958, -2132388854, -3034213411275261936L, 81852L, false, false, (char) 25431, (char) 6680,
        Double.longBitsToDouble(0x3feab800e0450694L), Double.longBitsToDouble(0x3fe2d51003441aadL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 3, 11, "\uda34\ude5e\ud8c5\ude0b\ud831\udc14\ud9dc\udfc9\uec67", "\u533f\ua28d\u07b3\u5567\ucde8\u0e5c\u3a81\u6759\u5dfb", "\ud9bf\udced\udb13\udf9a\udbb7\udeb8\ud98c\uddf0\ud8a0\udc64\ud974\ude57\ud91e\udffa\udb90\ude67\udb7f\ude85\udbd3\udf84\ud937\udeab\ud873\uddd0\ud83c\udf7a\udb46\udfeb\ud909\udf18\uda3b\udf25\ud8bb\udf10\ud9cb\udc67\ud92e\udd69\ud8ee\udf35\udab1\udd6c\ud8df\udfba\udb78\udeba\udbe7\uded0\uda91\udea2\uda7b\udf2a",
        46, 57761, -926845441, 501010020338518448L, -63560L, false, false, (char) 44924, (char) 60067,
        Double.longBitsToDouble(0x3fe03b199fb9cfe9L), Double.longBitsToDouble(0x3fd60da1b542b354L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 8, 9, "\uda34\ude5e", "\ub06f\u44a6\u0de6\u8361\u533f", "\udadd\udd5a\udb1c\udf9b\udb4f\udfa7\ud9c2\udc25",
        9, 22117, 1736817777, -9061856527659112565L, -99620L, false, false, (char) 3774, (char) 46679,
        Double.longBitsToDouble(0x3fccb844d480f5f0L), Double.longBitsToDouble(0x3f93ddf8a1c89aa0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\012",
        Z.run(T, 1, 6, 3, 16, "\uda34\ude5e\udb5f\udff0\udaf4\udf75\udb97\udf91\ud814\ude8d\ud94a\udc33\udbe5\udc53\udbd5\udc67\ud86f\ude50\ud912\udd7a\ud9a0\uddd3", "\u3a81\ud026\u2d6e\u5e8c\u3473\u7542\ub8da\u15a2\u0139\u3e4c\ua2f1", "\ud9ca\udc21\ud8de\udfaf\ud8ff\uddf7\ud968\ude4e\uda4d\udfb3",
        43, 36138, 2016819216, 8326144441204262492L, -72759L, true, true, (char) 24514, (char) 16089,
        Double.longBitsToDouble(0x3fe2d51003441aadL), Double.longBitsToDouble(0x3fc0a725dfdc0ca8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 9, 16, "\udad2\udeec\udaa3\udd0d\udaf4\udf75\ud83c\udc63\ud814\ude8d\ud94a\udc33\udb11\udcc8\udbdd\udda7\ud86f\ude50\ud912\udd7a\ud9a0\uddd3\ud96c\ude72\ud9bc\udc2f\udaf8\udc60\uda44\udfd0\udb18\udd0f", "\u7542\ub8da\u15a2\u0144\ua595\u16ca\u09c5\u5ccb\u45a8\u5a64\u5b74\u3a68\u24ea\u030f\u9b3f\u504e\uc133\u0fee\u3307\u126f\u058d\u4723\u60dc\uc9f7\ubbcc\uc845", "\ud951\udca1\ueaf7\uc5e2\ud846\ude4d\ud9ce\udc1d\ud8f1\uddef\ud8d5\udd43\ud862\udc04\ud91d\udf03\ud9a8\udef5\ud8d0\udc83",
        24, 71151, -1624507150, 6132550562093436032L, 98008L, false, false, (char) 24772, (char) 24833,
        Double.longBitsToDouble(0x3fe7d4965a518670L), Double.longBitsToDouble(0x3fde2ad60e2c4266L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\012",
        Z.run(T, 1, 8, 9, 5, "\ud958\udc30\udb15\udd93\udaf4\udf75\udb97\udf91\ud814\ude8d\u6715\udb11\udcc9\udbdd\udda7\uda8b\udf3e\ud90d\udda1\ud97e\udf14", "\uc1a8\u4175\u9956\u5ec1\u7bb7\u9f09", "\ud960\udfc8\udbe2\udc88\ud809\udc8b\uda42\udf11\uda70\udf1e\ud837\ude59\ud8df\udc7b\ud8ff\uddf7\ud968\ude4e\uda4d\udfb3\ud90c\udd85\udae5\udd7e",
        15, 87569, 1720895068, -920218482603364324L, -75593L, true, false, (char) 42795, (char) 55861,
        Double.longBitsToDouble(0x3fc1c6147fdc0ca8L), Double.longBitsToDouble(0x3fdf7684bd0e94c8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\012",
        Z.run(T, 1, 6, 6, 0, "\ud80d\udc8e\ud94b\udf42\udb1d\udd79\udb97\udf91\ud814\ude8d\ud94a\udc33\udb11\udcc8\udb1c\udfc5\ud86f\ude50\ud912\udd7a\ud9a0\ude1a", "\u06cf\u4ec5\u2d6e\uc5f5\u3473\u7542\u0de2\u15a2\u0139\u4287\u6f0e", "\ud9ca\udc21\uda6c\ude56\uda0c\ude39\ud97b\uddbf\uda4d\udfb3",
        43, 48314, 1481014283, 8290170447967995484L, 67908L, true, true, (char) 24435, (char) 16089,
        Double.longBitsToDouble(0x3fe2d51003441a82L), Double.longBitsToDouble(0x3fc96c85d7dc0ca8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\012",
        Z.run(T, 1, 7, 15, 13, "\uda34\ude5e\udb5f\udff0\udbbf\udf9b\udb97\udf91\ud814\ude8d\ud94a\udc33\udb11\udcc8\udbdd\udda7\uef81\udbc7\ude56\ud9a0\udfb3", "\u3a81\uaf01\ud76d\u4082\u0ca1\uac08\ub909\u15a2\u2855\u95c1\u16ca\u09c5\ub49a", "\ud8ff\uddf7\ud968\ude4e\uda4d\udfb3\ud912\ude85\udadd\udc7e",
        56, 87569, 1720895068, -920218482603364324L, -75593L, true, false, (char) 50266, (char) 26097,
        Double.longBitsToDouble(0x3fc0a725dfdc0ca8L), Double.longBitsToDouble(0x3fd64290a4aec9daL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 0, 16, "\uda34\udda2\udb5f\udff0\udaf4\udf75\udb97\udf91\ud814\ude8d\ud94a\udc33\udb11\udcc8\udbdd\udda7\ud86f\ude50\ud862\udd62\ud988\ude66", "\u3a81\ud026\u2d6e\u5e8c\ud225\u75ad\ub8da\u15a2\u0139\ua595\u16ca", "\ud9ca\udc21\ud8de\udfaf\ud8ff\uddf7\ud968\ude4e\uda4d\udfb3",
        43, 36138, 2016819216, 8326144441204262492L, 67908L, true, true, (char) 24569, (char) 57304,
        Double.longBitsToDouble(0x3fe0f8e04b441aadL), Double.longBitsToDouble(0x3fc0a725dfdc0ca8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 6, 13, "\uda34\ude5e\udb5f\udff0\udaf4\udf75\udb97\udf91\ud814\ude8d\ud94a\udc33\udb11\udcc8\udbdd\udda7\ud86f\ude50\udad7\uddea\ud9a0\uddd3", "\u3a81\ud026\u2d6e\u5e8c\u3473\u7542\ub8da\u15a2\u0139\ua595\u16ca", "\ud9ca\udc21\ud8de\udfaf\ud8ff\uddf7\ud968\ude4e\uda4d\udfb3",
        43, 36138, 2016819216, 5985942312097859164L, 67908L, true, true, (char) 24435, (char) 16089,
        Double.longBitsToDouble(0x3fe2d51003441aadL), Double.longBitsToDouble(0x3fc0a725dfdc0ca8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 4, 9, 16, "\uda34\ude5e\udb5f\udff0\udaf4\udf75\udb97\udf91\ud814\ude8dj\udb11\udc9f\u5263\ud86f\ude50\ud912\udd7a\ud9a0\uddd3", "\u3a81\ud026\u2d6e\u5e8c\u3473\u7542\ub8da\u15a2\u5d5e\000\000", "\ud9ca\udc21\ud8de\udfaf\ud8ff\uddf7\ud968\ude4e\uda4d\udfb3",
        43, 36138, 2016819216, 8326144441204262492L, 67908L, true, true, (char) 24435, (char) 14553,
        Double.longBitsToDouble(0x3fe2d51003441aadL), Double.longBitsToDouble(0x3fc0a725c0000000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 16, "\udae3\udeaf\ud8e5\ude09\udaff\udf6b\udb97\udf91\uda2e\udf76\uda1a\udc2f\udb28\udfd5\udbdd\udda7\ud8f8\udd57\ud912\udd7a\ud9a0\uddd3", "\u3a81\ud026\u2d6e\u5e8c\u3473\u7542\ub8da\u257c\u0139\ua595\u16ca", "\udb94\udd06\ud8df\udc45\ud8ff\uddf7",
        1, 39349, -2132388854, -3034213411275261936L, 81852L, false, false, (char) 25431, (char) 6680,
        Double.longBitsToDouble(0x3feab800e0450694L), Double.longBitsToDouble(0x3fe2d51003441aadL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 14, "\uda34\ude5e\ud8c5\ude0b\ud831\udc14\ud9dc\udfc9\uec67\ud94a\udc92\udb11\udcc8\udbdd\udda7\ud89b\udc52\udbe0\udfad\ud891\udf08\udac0\ude7d\udb5f\udd4b\udaf8\udc60\udad2\ude45\udb24\udd9c\udabc\uddbc", "\u033c\u1cb9\ua990\u76b0\u515b\u3aca\u1bb5\uca42", "\ud873\uddd0\ud83c\udf7a\udb46\udfeb\ud909\udf18\uda3b\udf25\ud8bb\udf10\ud9cb\udc67\ud92e\udd69\ud8ee\udf35\udab1\udd6c\ud8df\udfba\udb78\udeba\udbe7\uded0\uda91\udea2\uda7b\udf2a\uda2c\udea6\ud9cf\ude11\uda1a\udebd\udb8e\ude5e\u6a55",
        -3, 35480, -317396980, -2132240669963253701L, -75353L, false, true, (char) 31819, (char) 18753,
        Double.longBitsToDouble(0x3fe21d1a679beddbL), Double.longBitsToDouble(0x3fdd5326cef6065aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\0121=new com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\012",
        Z.run(T, 2, 7, 8, 5, "\uda34\ude5e", "\ub06f\u44a6\u3587\u8361\u533f", "\udadd\udd5a\udb1c\udf9b\udb7a\udc5c\ud9c2\udc25",
        16, 22138, 1736817777, -9061856527659112565L, -99620L, false, false, (char) 3774, (char) 46679,
        Double.longBitsToDouble(0x3fccb844d480f5f0L), Double.longBitsToDouble(0x3fdd3ddf8a1d3f56L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\0121=new com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\012",
        Z.run(T, 2, 8, 8, 9, "\uda34\ude5e", "\ub06f\u44a6\u0de6\u8361\u533f", "\udadd\udd5a\udb1c\udf9b\udb4f\udfa7\ud9c2\udc25",
        9, 83733, 1736817777, 3908510399167870557L, -99620L, false, false, (char) 3774, (char) 46679,
        Double.longBitsToDouble(0x3fccb844d480f5f0L), Double.longBitsToDouble(0x3f93ddf8a1c89aa0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 16, "\uda34\ude5e\udb5f\udff0\udaf4\udf75\udb97\udf91\ud814\ude8d\ud94a\udc33\udbe5\udc53\udbd7\udd87\ud98a\udcde\uda38\udf13\ud9a0\uddd3", "\u3a81\ud026\u2d6e\u5e8c\u3473\u7542\ub3a5\u15a2\u0139\u3e4c\ua2f1", "\ud85f\ude86\ud8de\udfaf\ud8ff\uddf7\ud968\ude4e\uda4d\udfb3\ud912\ude85\udadd\udc7e\uda3b\udf25\ud8bb\udf10\ud9cb\udc67",
        34, 18393, 7058789, -6308941272413457788L, 50340L, true, false, (char) 13089, (char) 27512,
        Double.longBitsToDouble(0x3fe5fc3316d95e83L), Double.longBitsToDouble(0x3fe9cf9fa3a8b3e5L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\0121=void |this=com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\012",
        Z.run(T, 2, 6, 6, 0, "\ud80d\udc8e\ud988\udec8\ud806\udc4d\udb97\udf91\ud814\ude8d\ud943\udfb0\udb11\udcc8\udb1c\udfc5\ud86f\ude50\ud912\udd7a\ud9a0\udd9d", "\u06cf\u4ec5\u2d6e\u76d8\ua292\u74d7\u0de2\u15a2\u0139\u4287\u6f0e", "\ud9ca\udc21\uda6c\ude56\uda0c\ude39\ud97b\uddbf\uda4d\udfb3",
        43, 48314, 1482145410, 8290170447967995484L, 67908L, true, true, (char) 24435, (char) 51093,
        Double.longBitsToDouble(0x3fe2d51003441a82L), Double.longBitsToDouble(0x3fc96c85d7dc0ca8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 12, 16, "\udae3\udef1\ud8e5\ude09\udac8\uddf0\udb97\udf91\uda2e\udf76\udbc3\udc33\udb28\udfd5\ud806\udc28\ud8f8\udd3d\ud912\udd7a\ud9a0\udf84", "\u3b0c\ud026\u2e4e\u5e8c\u9d7c\u7542\u0d4e\u25ab\u0139\ua595\u16ca", "\ud99a\udc8a\ud8df\udc0e\ud8ff\uddf7",
        1, 39349, -1765255422, -7781146230168375567L, 81852L, false, false, (char) 25431, (char) 6680,
        Double.longBitsToDouble(0x3feab800e0450694L), Double.longBitsToDouble(0x3fe2d51003441aadL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 10, 16, "\udae3\udeaf\ud8e5\ude09\udaff\udf6b\udb97\udf91\uda2e\udf76\uda1a\udc2f\udb28\udfd5\udbdd\udda7\ud8f8\udd57\ud912\udd78\udbcb\ude05\ud8c2\ude19\udb5f\udd4b\udaf8\udc60\uda57\udfd0\udb18\udd0f\udabc\uddbc\udae0\ude16", "\u257c\u0139\u7a53\u16ca\u45ce\u5ccb\u057d\u043e\u66fa\ud208\u405b\u1d66\ub511\uae89\uc133\u0fee\u3307", "\ud8df\udfba\udb78\udeba",
        13, 35396, -1693369900, -5847141671506398309L, -2566L, true, false, (char) 52490, (char) 4359,
        Double.longBitsToDouble(0x3fed2052ba3a67b5L), Double.longBitsToDouble(0x3fed6faeef622c18L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 16, 16, "\ud872\udc56\ud8c4\udee6\udb2c\udcaf\u05e0\uda2e\udf76\uda1a\udc2f\udb28\udfd5\udbdd\udda7\udbbc\udda2\ud84c\udd77\ud9a0\uddd3", "\u1c61\uae95\ubd5f\u89ce\u33da\u7542\ub8da\u257c\u0139\ua595\u16ca", "\udb94\udd06\ud8df\udc45\ud8ff\uddf7",
        1, 93109, -2132388854, 4017126963163296024L, 81852L, false, false, (char) 25431, (char) 6680,
        Double.longBitsToDouble(0x3fb5c007022b2180L), Double.longBitsToDouble(0x3fe51d10075df8b2L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 9, 0, "\uda07\udc83", "\ub077", "\000\000",
        -5, 81704, 162, -6435046002562332416L, -35392L, false, true, (char) 27080, (char) 12300,
        Double.longBitsToDouble(0x3fd7c4a5c9903d00L), Double.longBitsToDouble(0x3fb016df80013200L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 4, 4, "\ud90d\udfe3\uda67\udf85\ud9a5\udd9b\uda13\udde8\ud99f\udeff\uda0b\udce7\ud8a9\uded9\ud8f4\udf68", "\u0a67\u8a85\u1e1e\u8243\uae95", "\ud9f6\ude2d\ud8e7\udef0",
        -5, 62316, -514200376, 2756256021692582373L, 9708L, true, false, (char) 26837, (char) 56513,
        Double.longBitsToDouble(0x3fe2c9e49a6db75aL), Double.longBitsToDouble(0x3f84fa5f6c203980L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.FlowSensitiveInlineVariables|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FlowSensitiveInlineVariables:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.MustBeReachingVariableDef|computeDependence|com.google.javascript.jscomp.MustBeReachingVariableDef$Definition,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.MustBeReachingVariableDef:com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.Scope,com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.MustBeReachingVariableDef|dependsOnOuterScopeVars|java.lang.String,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.MustBeReachingVariableDef:com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.Scope,com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FlowSensitiveInlineVariables|checkLeftOf|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.FlowSensitiveInlineVariables|checkRightOf|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.FlowSensitiveInlineVariables|enterScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.FlowSensitiveInlineVariables:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FlowSensitiveInlineVariables|exitScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.FlowSensitiveInlineVariables:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FlowSensitiveInlineVariables|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FlowSensitiveInlineVariables:com.google.javascript.jscomp.AbstractCompiler",
    "C|com.google.javascript.jscomp.FlowSensitiveInlineVariables|<init>|com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.MustBeReachingVariableDef|addToDefIfLocal|java.lang.String,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.jscomp.MustBeReachingVariableDef$MustDef|new:com.google.javascript.jscomp.MustBeReachingVariableDef:com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.Scope,com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.MustBeReachingVariableDef|computeMustDef|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.jscomp.MustBeReachingVariableDef$MustDef,boolean|new:com.google.javascript.jscomp.MustBeReachingVariableDef:com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.Scope,com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.MustBeReachingVariableDef|createEntryLattice||new:com.google.javascript.jscomp.MustBeReachingVariableDef:com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.Scope,com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.MustBeReachingVariableDef|createInitialEstimateLattice||new:com.google.javascript.jscomp.MustBeReachingVariableDef:com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.Scope,com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.MustBeReachingVariableDef|escapeParameters|com.google.javascript.jscomp.MustBeReachingVariableDef$MustDef|new:com.google.javascript.jscomp.MustBeReachingVariableDef:com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.Scope,com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.MustBeReachingVariableDef|flowThrough|com.google.javascript.rhino.Node,com.google.javascript.jscomp.MustBeReachingVariableDef$MustDef|new:com.google.javascript.jscomp.MustBeReachingVariableDef:com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.Scope,com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.MustBeReachingVariableDef|getDef|java.lang.String,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.MustBeReachingVariableDef:com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.Scope,com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FlowSensitiveInlineVariables|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FlowSensitiveInlineVariables:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.MustBeReachingVariableDef|computeDependence|com.google.javascript.jscomp.MustBeReachingVariableDef$Definition,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.MustBeReachingVariableDef:com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.Scope,com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.MustBeReachingVariableDef|dependsOnOuterScopeVars|java.lang.String,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.MustBeReachingVariableDef:com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.Scope,com.google.javascript.jscomp.AbstractCompiler",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
