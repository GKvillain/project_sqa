package com.google.javascript.rhino.jstype;
import org.junit.Test;
import static org.junit.Assert.*;
public class PrototypeObjectType_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 4, 14, "\uda4f\udebb\ud84b\udc05\ud856\uddac\udbc3\ude03\ud9d8\udf14\ud9bd\ude2c\ud8ad\udd70\uc873\ud961\udd4e", "\ucfb3\u6079\u0626\u0fd9\u4214\u60ce\u6f57\uc22d\u2ec0\uc719\u16ee\u78d2\ucf51\ud766\u2b0f\u5dff\u64ed\uaa60\u1ac1\ud399\u6fc3\ucc8b\u53db\uc8f2\u7756\ubdb2", "\udb41\udf96\ud8e1\udc84\udad3\udfab",
        47, 30660, -750478251, -1299760745561589130L, -66356L, true, false, (char) 4052, (char) 65289,
        Double.longBitsToDouble(0x3fdefa72595534a0L), Double.longBitsToDouble(0x3fec6f1af377807cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 4, 14, "\uda4f\udebb", "\u5dd3\u2e86\u5080\u649b\u129b\u6c04\u90a0\u763f\ua1ac", "\ud9ed\udd0d\udbd9\udd45\udae6\udf84\udba7\udce6\ud839\ude37\ud864\ude84",
        59, 82945, 1169686065, 8768366745060188565L, 3412L, true, true, (char) 33721, (char) 47006,
        Double.longBitsToDouble(0x3fe427c4d1559cfbL), Double.longBitsToDouble(0x3fb3169c69c81ca8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 4, 14, "\udb9d\ude42\ud84b\udc46\uda3f\udf41\udbc3\ude03\ud9d8\udf14\ud9bd\ude2c\ud8ad\udd70\uc873\ud961\udd4e", "\ucfb3\ubcae\u53b5\u4c2a\u4214\u60ce\u6f57\uc22d\u2ec0\uc719\u981e\ucc3f\ucf51\ud766\u2b0f\u5dff\u64ed\u3c94", "\ud9c2\udde6\ud82a\udc82\ud843\udee6",
        18, 68080, -1204829488, 4669054877541050480L, 69895L, true, true, (char) 63000, (char) 47312,
        Double.longBitsToDouble(0x3fb5781193ee9a20L), Double.longBitsToDouble(0x3fe3b76fb32203cdL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 4, 14, "\uda4f\udebb\ud84b\udc05\ud856\uddac\udbc3\ude03\ud9d8\udf14\ud9bd\ude2c\ud8ad\udd70\uc873\ud8b9\udf5b", "\ucfb3\u6079\u0626\u0fd9\u4214\u60ce\u6f57\uc22d\u2ec0\uc719\ubdd5\u794a\ucf51\u01ca\u2b0f\uc51b\ud205", "\udb33\udc6d\ud9c2\udde6",
        3, 57297, -100364278, -4955339650203925808L, 69895L, true, true, (char) 22809, (char) 13248,
        Double.longBitsToDouble(0x3fb5781193e93220L), Double.longBitsToDouble(0x3fe3b76fb32203cdL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 4, 12, "\uda4f\udebb\ud84b\udc05\ud856\uddac\udbc3\ude03\ud9d8\udf14\ud9bd\ude2c\ud9fb\udfd9\uc873\ud961\udcd9", "\ucfb3\u6079\u0626\u0fd9\u4214\u94cd\u6f57\uc22d\u2ec0\uc719\u16ee\u78d2\ucf51\ub492\u7b9b\u5d0d\u641e\uaa60\u1ac1\ud399\u6fc3\ucc8b\u53db\ud552\u8419\u5352", "\udb41\udf12\ud8e1\udc84\udad3\udfab",
        25, 30660, -750478251, -1299760745561589130L, -66356L, true, false, (char) 4052, (char) 65289,
        Double.longBitsToDouble(0x3fdefa72595534a0L), Double.longBitsToDouble(0x3fec6f1af377807cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 4, 14, "\udb59\udc2d\ud84b\udc05\ud856\uddac\ud934\udfbb\ud9f9\udfa3\uda7d\udd8c\uda21\udd1f\udafb\udc9d\udbb8\udddb", "\ucf6a\u8bf2\u8bc7\u2683\u4214\u7296\u477d\u9468\u2ec0\uc719\u16ee\u2083\ucf51\u6e28\u6ea9\u6e16\ub725\u9630\u102c\ud2ee", "\ud99c\udcf3\udaef\udfaf\ud9eb\udcca\uda39\ude94\uda19\udc7d\uda1b\udc62\udb41\udf96\ud8e1\udc84\udadd\udede",
        47, 30660, -750478251, -1299760745561589130L, 71343L, true, false, (char) 52711, (char) 23318,
        Double.longBitsToDouble(0x3fbbeacc2e177148L), Double.longBitsToDouble(0x3fdfce3573793f22L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|matchConstraint|com.google.javascript.rhino.jstype.ObjectType|new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|canBeCalled||new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|collectPropertyNames|java.util.Set|new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|defineProperty|java.lang.String,com.google.javascript.rhino.jstype.JSType,boolean,com.google.javascript.rhino.Node|new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|getConstructor||new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|getCtorExtendedInterfaces||new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|getCtorImplementedInterfaces||new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|getImplicitPrototype||new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|getOwnPropertyJSDocInfo|java.lang.String|new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|getOwnPropertyNames||new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|getOwnerFunction||new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|getPropertiesCount||new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|getPropertyNode|java.lang.String|new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|getPropertyType|java.lang.String|new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|getReferenceName||new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|getSlot|java.lang.String|new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
    "M|com.google.javascript.rhino.jstype.PrototypeObjectType|matchConstraint|com.google.javascript.rhino.jstype.ObjectType|new:com.google.javascript.rhino.jstype.PrototypeObjectType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.jstype.ObjectType",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
