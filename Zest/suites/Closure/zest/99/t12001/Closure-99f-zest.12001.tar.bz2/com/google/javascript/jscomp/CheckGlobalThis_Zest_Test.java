package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class CheckGlobalThis_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 4, "\udb1b\uded9\udbe5\ude07\ud887\udd86\ud885\udc75\ud8ea\uddd5\uda6e\udd93", "\u6d8e\u16db\u350b\u351c\ub1cb\ua42f\u865e\uca18\u056b\u0d6e", "\ud8f7\udee2\ud9ca\udc86",
        48, 55913, -1746079081, -3518501550115191100L, -31027L, false, true, (char) 60108, (char) 65512,
        Double.longBitsToDouble(0x3fdf396632dba0f2L), Double.longBitsToDouble(0x3fdef649392a8f74L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 4, "\000\uda8a\udd05\ud887\udd86\ud885\udc75\ud8ea\uddd5\uda6e\udd93", "\ub713\u8400\000\u7c11\ub1cb\ua42f\u865e\000\u056b\u7cdc", "'\000",
        50, 78569, 0, 1673070276L, -31027L, false, true, (char) 60108, (char) 65512,
        Double.longBitsToDouble(0x3fdf396632dba0f2L), Double.longBitsToDouble(0x3fdef64930000174L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 1, 4, 1, 2, "\udb1b\uded9\udae4\udfa8\ud887\uddd8\ud885\udc75\ud8ea\uddd5\udbff\udfbb", "\u6f13\u16db\u8225\u351c\ub1cb\ua42f\u560d\u0a55\u056b\u0d6e\u00af\u1e9f\u795e\u71d2\u9964\u97db\uccde\u2ca1\uc9bc\u513a\u8fd1", "\udac3\udec7\u2b26\ud8d1\udc04\ud82b\udf18\uda59\udee3\udab1\udeed\ud875\udeff\uda59\udd43\udb18\uded3\udb5d\udd09\ud9f4\udf2a\ud9fd\udf93\ud9d8\udf26\u1007\ud86f\uded3\ud903\udc0d\ud9d1\udca2\udb18\udfbe\ud930\uddf9\uda36\udf91\uda7c\udefe\udb14\udd5f\ud872\ude69\u9556\ud8ea\ude75\uda20\udd10\udb63\udc5f\ud9a1\udcb4\u2bef\udb5e\uddc2\udbfd\uded9\uda09\udd49\ud82c\udcaa\uda50\uddf4\udbba\udc4a\udaa7\uddb2\ud98b\ude38\udba7\ude9a\udb76\udf27\udb91\udfac\ud992\udcee\udb7c\uddb2\udb13\udd6f\ud918\udcb6\udacd\udea5\ud893\udd6c\ud8bc\ude7f\udb35\ude68\uda2d\udc4c\udaec\udc62\ud918\udc8a\ud8a0\udd64\udb5f\udc94\ud815\udc15\udac9\udd8b",
        6, 51962, -893131125, 3339812007335098559L, -71343L, false, false, (char) 53045, (char) 40310,
        Double.longBitsToDouble(0x3fe7c69e1f14e971L), Double.longBitsToDouble(0x3fd29454abcd5b6cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 1, 2, 2, 2, "\udb1b\uded9\udbe5\ude07\ud887\ude29\ud885\udc75\ud8ea\uddd5\uda6e\udd93", "\u6d8e\u16db\u350b\u351c\ub1cb\ub5f7\ub785\u5c39\u47ac\u0d6e", "\ud8f7\udee2\udb6f\udd1d",
        20, 19497, -1746131601, -3518501550115191100L, -31027L, false, true, (char) 60108, (char) 15156,
        Double.longBitsToDouble(0x3fdf396632dba0f2L), Double.longBitsToDouble(0x3fdef649392a8f74L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 1, 2, 1, 4, "\udaef\ude13\ud95e\udd9e\udb2c\udf60\ud880\udea3\ud965\uddcd\ud86f\udc40", "\u6d8e\u16db\u350b\u57c7\u50a2\ua42f\u865e\uca18\u056b\u0d6e", "\uda6c\udcfd\ud977\udd97",
        48, 55913, 1629811351, -3518501550115191100L, 2765L, true, true, (char) 59922, (char) 65512,
        Double.longBitsToDouble(0x3fdf396632dba0f2L), Double.longBitsToDouble(0x3fdef649392a8f74L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 1, 4, 0, 3, "\udb1b\uded9\udbe5\ude07\ud887\ude43\ud885\udc75", "\u197d\ucb81\u6d8e", "\ud8ac\ude60\ud95b\udd5c\udad3\udc8c\uda46\udc80\uda34\udc55\udafb\udc91\udab3\udcf8",
        19, 98105, -361052727, -9129948741485912033L, -85388L, true, true, (char) 54767, (char) 62913,
        Double.longBitsToDouble(0x3fd6d47a3a49ce0aL), Double.longBitsToDouble(0x3fe685ffe50122e8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\0121=java.lang.Boolean:false |this=com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 2, 4, 2, 4, "\udb1b\uded9\udbe5\ude07\ud9ff\udec6\ud885\udc75\ud8ea\uddd5\uda6e\udd93", "\u6d8e\u16db\u350b\u351c\ub1cb\ua42f\u6bff\ud0ab\ub8ce\u6425", "\ud8f7\udee2\ud9ca\udc86\ud946\udf5d\ud94e\udcd0\uf16e\ud930\ude9a\ud9b3\udd7b\ud942\uddd5\udb35\udf1d\ud8c9\udc86\ud9b0\udea2\udac3\udec7\u2b26\ud92d\udf5a\ud86d\ude29\ud9f0\udc5c",
        2, 8669, -1981154027, 8886088283151853726L, 7801L, true, true, (char) 7214, (char) 16698,
        Double.longBitsToDouble(0x3fc4fbcc9b0b6f34L), Double.longBitsToDouble(0x3fa7e99187f03ed0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\0121=java.lang.Boolean:false |this=com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 2, 4, 2, 4, "\000\uda8a\udd05\ud887\udd86\ud885\udc75\ud8ea\uddd5\uda6e\udd93", "\ub713\u8400\u45a1\ud24d\u6d63\ud3c6\u865e\u3bb9\u2755\uaa00", "'\ud9da\udf8c",
        54, 60441, 0, 1673070276L, -31027L, false, true, (char) 60078, (char) 65512,
        Double.longBitsToDouble(0x3fdf39663adba0f2L), Double.longBitsToDouble(0x3fdef64930000174L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.CheckGlobalThis:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 4, "\udac3\udca6\ud9f4\udfac\udb63\uddcf\uda77\uddef\udaf6\udc95\uda6e\udd93\udb19\udd84\ud8ae\udfb0\ub713\u1500\000\udbd0\ude52", "\ub8a1\u6ba4\u04d3\ud490\u2b6f\u5cd0\ubf7b\u7300\ud070\ubb9b", "\uda47\udcf9",
        12, 26333, -1177848535, 7007917007750552857L, -51213L, true, true, (char) 186, (char) 54380,
        Double.longBitsToDouble(0x3fea1581a258059cL), Double.longBitsToDouble(0x3f904a35ed4afec0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.CheckGlobalThis:@?\0121=java.lang.Boolean:false |this=com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 2, 2, 2, 2, "\udb1b\uded9\udbe5\ude07\ud887\ude29\ud885\udc75\ud8ea\uddd5\uda6e\udd93", "\u6d8e\u16db\u350b\u351c\ub1cb\ub5f7\ub785\u5c39\u47ac\u6b27", "\ud8f7\udee2\udb6f\udd1d\udb8f\udfff\ud952\udd3b\udb43\udf4c\ud930\ude9a\ud870\udcdb\ud87f\udea2\ud852\udff4\ud8e0\udd5e\udade\udc58\udac3\udf12\u2b26\ud92d\udf5a\ud86d\ude29\ud926\udd56\ud8fb\ude8d\ud9ac\ude03\ud82a\udc87\ud9e5\udf9e\ud582\ud909\udf94\ud9d1\udd4b\ud81d\ude77\uda6a\ude27\udbad\udfe5\udb29\udccb\ud831\udeab\udb30\udf69\udaf7\udf6a\udbe6\uded9\udb6c\udd5d\ud99d\udfc5\uda11\udefa\udad7\udf4c\udaef\udefd\udb2a\udc04\ud896\udf49\udb2f\udd40\udad0\udc1b",
        50, 42401, 167777049, -6461190371645038949L, 63725L, false, true, (char) 58612, (char) 1249,
        Double.longBitsToDouble(0x3febb49ccacba4b6L), Double.longBitsToDouble(0x3fe2a1327e4e28f8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\0121=new com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 2, 4, 4, 2, "\uda34\udd6e\ud911\udf46\udb2c\udfc6\ud880\ude75\ud965\uddcd\ud943\udcef\udb0e\ude7a\udb45\uddb4\u0d5d\ud8a4\uddc4\udb17\ude98\u1fae\ud979\udc32\udad3\udc8c\ud828\udd8c\udbf0\udffb\uda5e\udd95\udab3\udcf8\udb09\udc2d\ud9ef\uded4\uda92\udebc\ud977\udd97\ud946\udf5d\udaca\ude96\ud831\ude85\ud8ff\ude45\ud9c5\udca4\uda90\udf8f\udbc2\udd7b\ud8eb\udf4e\udaf7\udeb5\ud8bd\udf19\u2a84\ud92d\udf5a\ud86d\ude29\ud9c1\udfe4\u4d55\udb91\udd4b", "\ua6c3\u00bd\u4f80\u23cd\u60cc\u63ec\u53be\ucb60", "\ud882\ude3a",
        16, 42543, 1553358033, -5288488257611681870L, -70548L, false, false, (char) 51077, (char) 35144,
        Double.longBitsToDouble(0x3fc93a7ac1147f68L), Double.longBitsToDouble(0x3fe83c7648615e44L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 4, "\udb1b\uded9\udbe5\ude07\ud887\udd86\ud885\udc75\udafa\udddd\uda6e\udd93", "\u6d8e\u16db\u350b\u351c\u2a28\ua405\u865e\uca18\u056b\u316e", "\ud8f7\udee2\ud9ca\udc86",
        48, 55913, -1746079081, -3518501550867085628L, 58221L, true, true, (char) 16002, (char) 52302,
        Double.longBitsToDouble(0x3fdc9695acbb6c02L), Double.longBitsToDouble(0x3fe7c7f0100e6d94L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.CheckGlobalThis|shouldTraverse|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckGlobalThis:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
    "M|com.google.javascript.jscomp.CheckGlobalThis|getFunctionJsDocInfo|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckGlobalThis:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
    "M|com.google.javascript.jscomp.CheckGlobalThis|shouldReportThis|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckGlobalThis:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
    "M|com.google.javascript.jscomp.CheckGlobalThis|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckGlobalThis:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
    "C|com.google.javascript.jscomp.CheckGlobalThis|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
    "M|com.google.javascript.jscomp.CheckGlobalThis|shouldTraverse|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckGlobalThis:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
