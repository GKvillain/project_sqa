package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class Compiler_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 12, 3, 19, "\udac6\udf96\ud9a2\udd9d\udaf7\udcf6\uda25\udfde\uda63\udc75\ud8bd\udc6e\udb53\udcca\ud98d\ude57\udad3\udfc2\udac4\udfa2\udbe0\udccd\ud86f\udd34\udac6\udfd8", "\u632b\u250a\u69d1\uac9d", "\ud859\udc34\ud952\udd80\udbf5\udf33\uda28\udd07\uda35\udff5\ud858\ude1e",
        56, 21461, -1605600084, 5094617642979834176L, 46008L, true, false, (char) 32163, (char) 22342,
        Double.longBitsToDouble(0x3fd0849f7f7cdbc8L), Double.longBitsToDouble(0x3fed1cbd445eba41L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 12, 3, 19, "\udac6\udf96\ud9a2\udd9d\udaf7\udcf6\uda25\udfde\uda63\udc75\ud8bd\udc6e\udb53\udcca\ud98d\ude57", "\u85b8\u2203\u0cce\ub729\u6b6d\u632b\u250a\u69d1\uac9d\uc3e7\u4adb\ub2ec\u525b\u447c\u1683\uc303\u991a\u06dc\u5fb0\u033f\uc38c", "\udb08\udf55",
        47, 43826, 1240949056, 7918512351549642686L, -84734L, false, false, (char) 7749, (char) 30906,
        Double.longBitsToDouble(0x3feb91a41c312929L), Double.longBitsToDouble(0x3feadf4513e44ea7L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 12, 3, 19, "\udac6\udf96\ud9a2\udd9d\udaf7\udcf6\uda25\udfde\ud923\udf79\ud8bd\udc6e\udb53\udcca\ud98d\ude57\udad3\udfc2\udac4\udfa2\udbdf\udffe\ud86f\udd34\udac6\udfd8", "\u632b\u250a\u69d1\uac9d\uc3e7\u4adb\ub2ec", "\uda28\udd07\uda35\udff5",
        9, 78971, 1793075461, -6895999850048669759L, 49883L, false, false, (char) 22342, (char) 32511,
        Double.longBitsToDouble(0x3fedf36f23a397a8L), Double.longBitsToDouble(0x3fb7ae9065615f80L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 12, 3, 19, "\udad3\udd43\ud9a2\udd9d\uda16\ude46\uda7f\ude01\ud8a3\uddf8\ud8bd\udc6e\udb2d\udcdc\ud98d\ude57\udad3\udfc2\udac4\udfa2\udbe0\udccd\ud86f\udd34\udb48\udf58", "\u059d\u250a", "\ud85c\ude61\ud886\udc23\ud859\udc79\ud952\udd80\udbf5\udf33",
        18, 49040, 1259554424, -3520309714046939899L, 49567L, false, true, (char) 5360, (char) 38344,
        Double.longBitsToDouble(0x3fe42c4895830359L), Double.longBitsToDouble(0x3fdb2116ba1093dcL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 3, 7, "\ud95c\uddc8\ud9a2\udd8c\udaf7\udcf6\uda25\udfde\ud896\udecf\ud8bd\udc6e\udb53\udcca\ud98d\ude57\udad3\udfc2\udac4\udfa2", "\u0cce\ub729\u6b6d\u632b\u4822\u71ef\u799e\uc3e7\u4ff4\u9f17\u525b\u447c", "\udbee\udfa9\udbfa\udd7a\ud965\udf51\ud897\udf08\uda84\udfeb\ud99e\udd07\ud809\udf6f\udb08\udf55\uda13\udeb7\ud9b2\uddb3",
        56, 17328, -1750542402, -5025529399369240226L, -24149L, true, true, (char) 44454, (char) 35639,
        Double.longBitsToDouble(0x3fea6f889f7284c6L), Double.longBitsToDouble(0x3fe3284477a72c45L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 12, 3, 19, "\udac6\udf96\ud9a2\udd9d\udaf7\udcf6\uda25\udfde\uda63\udc75\ud8bd\udc6e\udb53\udcca\ud98d\ude57\udad3\udfc2\udac4\udfa2\udbe0\udccd\ud8cd\udd43\udac6\udfd8", "\u632b\u9f69\u69d1\uac9d", "\ud859\udc34\ud952\udd80\udbf5\udf33\uda28\udd07\uda35\udff5\ud858\ude1e",
        56, 21461, -1605600084, 5094617642979834176L, 46008L, true, false, (char) 32163, (char) 22342,
        Double.longBitsToDouble(0x3fd0849f7f7cdbc8L), Double.longBitsToDouble(0x3fed1cbd445eba41L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 18, 5, "\udac6\udf96\ud9a2\udd9d\ud87b\udff8\ud93a\udd0f\uda63\udc5e\uda0b\uddc1\udb53\udcca\ud98d\ude57\uda05\udcdb\udac4\udfd0\udbe0\udcdb\ud86f\udd34\udac6\udfd8", "\u632b\u250a\u6df7\uac9d", "\ud859\udc34\udacd\ude04\ud96e\ude6a\udabe\udf13\uda36\udc87\u395a\udbd3\udd8d\ud965\udf51\ud956\uddb5\uda84\udfeb\ud99e\udd07\ud9cf\ude12\udb08\udf55\uda13\udeb7\uda7e\uddb9\udb91\udd9b\udb82\udf81\udb68\udd97\udbb0\udeb5\udb39\udfa2\u8685\u6ab8\ud966\udfb9\udb9a\uddb2\ud96f\udf5a",
        21, 82360, -1631795436, -4341608510429853460L, -55770L, true, true, (char) 23291, (char) 45672,
        Double.longBitsToDouble(0x3fe7ccec7b740092L), Double.longBitsToDouble(0x3fa0c036e49d0c20L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 3, 19, "\udac6\udf96\ud9a2\udd9d\udaf7\udcf6\uda25\udfde\uda63\udc75\ud8bd\udc6e\ud961\ude96\ud8d1\udeb0\uda95\udf77\udb27\ude6c\udbfd\ude91\ud86f\udd34\udac6\udfd8", "\u632b\u250a\u69d1\uac9d", "\ud859\udc34\ud952\udd80\udbf5\udf33\uda28\udd07\udb0a\udf51\ud838\udddb",
        56, 21461, -1605600084, 5094617642979834176L, 46008L, true, false, (char) 32163, (char) 22342,
        Double.longBitsToDouble(0x3fd0849f7f7cdbc8L), Double.longBitsToDouble(0x3fd8f97a88bd7482L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 19, "\udac6\udf96\udb48\udd5a\ud88a\udc64\uda1f\udca8\uda63\udc75\ud988\ude1d\udbb5\udcf0\uda09\udc1e\udad0\udc7f\udac4\udfa2\uda0b\uddde\ud86f\udd34\uda7c\udd13", "\ua8af\u1944\u5708\u498c", "\ud859\udc05\ud952\udd80",
        17, 88848, 522200608, -4159472808186521405L, -68084L, true, true, (char) 31219, (char) 43781,
        Double.longBitsToDouble(0x3feac2db81b216a9L), Double.longBitsToDouble(0x3fe2501ac940f605L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 16, 3, 19, "\000", "", "\ud8bd\udc6e\ud853\udcca\ud98d\ude57\uc532\000\000\ud848\ude64\udac6\udfd8\uda39\udca0\udb69\udd12",
        27, 812, -377969531, 5821549981168041405L, -43837L, false, false, (char) 8180, (char) 37982,
        Double.longBitsToDouble(0x3fe101b4b5851f20L), Double.longBitsToDouble(0x3fc878c8c4173c94L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 16, 7, 0, "\udb6d\udfe0\ud94d\udf1d\udbbd\udd72\uda25\udfde\uda63\udc75", "\u1640\u90c9", "\ud9bf\udffb\udac6\udfd8\uda39\udca0\udb69\udd12\ud9f9\ude80\uda6d\udfe3\ud824\ude2f\udb5a\udd4f\ud9cd\udd83\ud8b0\udfc9\ud8fc\udca1\udb84\udd43\udb8e\udc9c\uda28\udd07\uda35\udff5",
        4, 76038, 1793100301, -6896019641257969727L, 49923L, false, false, (char) 63045, (char) 61632,
        Double.longBitsToDouble(0x3fef192753a383a8L), Double.longBitsToDouble(0x3fb7ae906c810b10L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\012",
        Z.run(T, 1, 9, 7, 19, "\udac6\udf96\ud992\udf9d\udaf7\udcf6\uda25\udfde\uda63\udc75\ud8bd\udc6e\udb53\udcca\udae3\udf83\udb07\ude14\udac4\udfa2\ud826\udf71\uda77\udf26\udac6\udfd8", "\u632b\u250a\u69d1\uac9d", "\ud859\udc34\ud952\udd80\udbf5\udf33\uda28\udd07\uda35\udff5\ud858\ude1e",
        56, 21461, -1605600084, 5094617642979834176L, -3044L, false, true, (char) 32511, (char) 17826,
        Double.longBitsToDouble(0x3fed1cbd445eba41L), Double.longBitsToDouble(0x3fe6dcc771e88730L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 3, 19, "\udac6\udf96\ud9a2\udd9d\udaf7\udcf6\uda26\udc22\uda63\udc75\ud8bd\udc6e\udb53\udcca\ud98d\ude57\udad3\udfc2\ud8ee\udf57\uda82\udf8d\ud9d9\udfc4\udac6\udfd8", "\uc368\u4a65\u69d1\ucd9d\uc3e7\u4adb\ub2ec", "\udb54\udfac\ud928\uddd4",
        9, 73475, 1495851524, 5514055096977373121L, -49946L, false, false, (char) 16279, (char) 32163,
        Double.longBitsToDouble(0x3fb03d8159162f68L), Double.longBitsToDouble(0x3fc0a9c6ef025728L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 4, 19, "\uda3e\udf92\ud9a2\udd9d\udaf7\udcf6\uda25\udfde\uda63\udc75\ud8bd\udc6e\udb53\udcca\ud98d\ude57\udad3\udfc2\uda37\udefb\udbe0\udccd\uda79\udf62\ud8f4\udd41", "\u632b\u250a\u0350\uac9d\uc3e7\u4adb", "\udbf5\udf33\uda28\udd07\uda35\udff5\ud813\udcf2\ud8ac\ude7c\ud965\udf51\ud897\udf08\uda84\udfeb",
        6, 84007, -1995294120, 241424737220524618L, -86424L, false, true, (char) 21323, (char) 32415,
        Double.longBitsToDouble(0x3fd5b44a25b2479aL), Double.longBitsToDouble(0x3fe38e139280eef1L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 3, 19, "\udac6\udf96\ud9a2\udd9d\udaf7\udcf6\udbb1\udd64\000\u00b2\000\ud98e\udda6\udad3\udfc2\udac4\udfa2\udbe0\udccd\ud86f\udd34\udac6\udfd8", "\u632b\u250a\u69d1\uac9d", "\ud859\udc34\ud952\udd80\udbf5\udf33\uda9e\udffe\uda35\udff5\ud858\ude1e",
        56, 21461, 5012652, 4208896L, 45920L, false, false, (char) 31232, (char) 22342,
        Double.longBitsToDouble(0x3fd0849f7f7cdbc8L), Double.longBitsToDouble(0x3fed1cbd445eba41L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 3, 15, "\udac6\udf44\ud9a2\udd9d\udaf7\udcf6\uda25\udfde\udb1f\udc93\ud8bd\udc30\udb53\udcca\ud98d\ude57\ud84e\udc00\ud828\ude12\udbe1\udf58\ud86f\udd34\udac6\udfd8", "\u632b", "\udb97\udebe\ud9e4\udc6e\ud88e\ude04\ud924\udcbd\udb30\udf7a\udbf5\udf33\uda70\udfc9\ud9c3\udcfc\uda29\udc32\udbd3\udd6e\ueb41\ud89a\udf7c",
        50, 22096, -1787815761, -8569722467258878331L, -59360L, false, true, (char) 51106, (char) 48336,
        Double.longBitsToDouble(0x3fede0380f304021L), Double.longBitsToDouble(0x3fe525b17ad5f175L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 11, 1, "\udac6\udf96\ud9a2\udd9d\udaf7\udcf6\uda25\udfde\uda63\udc75\ud8bd\udc6e\ud914\udfe3\udabd\udfca\udad3\udfc2\ud8c9\udd10\udbe0\udccd\ud86f\udd34\udac6\udfd8", "\u632b\u250a\u69d1\uac9d", "\ud9e8\uddfc\ud952\udd80\udbf5\udf33\ud9b9\udd90\ud978\uddd8\ud893\ude2c",
        52, 81532, -1598839122, 5094617642979834176L, 68792L, true, false, (char) 32124, (char) 11343,
        Double.longBitsToDouble(0x3fd9d151ef7cdbc8L), Double.longBitsToDouble(0x3fed1cbd445eba41L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\012",
        Z.run(T, 1, 7, 3, 19, "\udac6\udf96\ud9a2\udd9d\udaf7\udcf6\uda25\udfde\uda63\udc75\ud8bd\udc6e\udb53\udcca\udb39\ude0e\uda60\udd55\udac4\udfa2\udbe0\udccd\ud86f\udd34\udac6\udfd8", "\u632b\u250a\u69d1\u7678", "\udb31\udd15\ud9fc\udd6e\udb50\udf20\u30ed\u3b6e\ud867\udd55\udbc4\udcdc\ud965\udf51",
        54, 38105, -2109720256, 6588793392746084952L, -3158L, false, true, (char) 32511, (char) 17826,
        Double.longBitsToDouble(0x3fed1cbd445eba41L), Double.longBitsToDouble(0x3fd1093f3aec2852L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 3, 19, "\udac6\udf96\ud9a2\udd9d\udaf7\udcf6\uda25\udfde\uda5e\udf75\ud8bd\udc6e\udb53\udcca\ud98d\ude57\udad3\udfc2\udac4\udfa2\udbe0\udccd\udaed\uddaa\udb93\udc7f", "\u632b\u250a\u69d1\uac9d\uc3e7\u4adb\ub2ec", "\uda28\udd07\uda35\udff5",
        9, 78971, 1793075461, -6895999850048669759L, 49883L, false, false, (char) 22342, (char) 32511,
        Double.longBitsToDouble(0x3fedf36f23a397a8L), Double.longBitsToDouble(0x3fd773721d26b1e8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 16, 6, 16, "\ud87c\udea5\ud9a2\udd9d\ud8f5\udcf5\uda25\udfde\uda63\udc75\ud87d\udc6e\udb53\udc71\ud98d\ude57\udad3\udfc2\ud8aa\udc95\udbe0\udccd\ud86f\udd34\udac6\udfd8\uda39\udca0\udb69\udd12\ud914\udecf\ud9d5\udce4\ud842\udf31\udb5a\udd9f\ud9ac\udef3\uda50\udd5a\udaeb\ude4d\uda62\udd68\udbf5\udf33\udbe3\udfc6\ud8ff\udd18\uda84\udcae\ud8a5\udc74\udb95\udc37\ud897\udf08\udb69\udd12\ud99e\udda2\udb97\udc6f\udb02\udf0c\udbcb\udd25\uda2d\ude39\uda16\udfd1\udb82\udf81\udb68\udd97\udbd1\udd94\uda48\udf5d\ud849\udcb8\ud84f\udccc\ud853\udfb4\uda44\ude69\ud85b\udc35\ud87e\ude8f\ud84c\ude95\udb9c\udff2\ud86c\ude2f\uda4f\udc3d\ud9ce\uded7\ud85a\udd45\uda6a\ude48", "\u7ab4", "\ud9bc\udf90\ud96f\udd22\udaa5\udfe4",
        56, 71640, 10567070, -2723037010989014662L, -32427L, false, true, (char) 37876, (char) 16283,
        Double.longBitsToDouble(0x3fece75fc96e3ecdL), Double.longBitsToDouble(0x3fe0e057e0147412L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 4, 19, "\udad0\udf4c\ud9a2\udcf7\udaf7\udcf6\ud80c\udc40\uda63\udc75\ud8bd\udc6e\udb43\udeca\ud98d\ude57\udad3\udfc2\udac4\udfa2\udbe0\udccd\ud86f\udd34\ud89c\udd21", "\u632b\u250a\u69d1\uac9d\u51d4\u4a1f\ub2ec\u525b\u447c\u0e37\u4a77", "\ud965\udf51\ud897\udf08\uda84\udfeb\ud99e\udd07\ud9cf\ude12\ud8ae\udcc3\ud8f9\ude06\uda4a\uddfb",
        39, 70581, -1750542402, -5025529399731370914L, 71826L, false, false, (char) 22578, (char) 40916,
        Double.longBitsToDouble(0x3fe95465b169f7d2L), Double.longBitsToDouble(0x3fdaa659fff4fe3cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 14, 19, "\udac6\udf96\ud9a2\udd9d\udaf7\udcf6\uda25\udfde\uda2f\udd1b\ud8bd\udcb2\udb53\udcca\ud98d\ude57\udad3\udfc2\udac4\udfa2\udbe0\udccd\ud86f\udd34\udac6\udfd8", "\u632b\u250a\u69d1\uac9d", "\ud9d7\udc94\u7fd9\udbf5\udf33\uda28\udd07\uda35\udff5\ud858\ude1e",
        56, 21461, -1605600084, 5094617642979834176L, 46008L, true, false, (char) 32163, (char) 22342,
        Double.longBitsToDouble(0x3fd0849f7b1da5c8L), Double.longBitsToDouble(0x3fcaca16517ae9f4L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 3, 7, "\ud8d4\udd04\uda50\udeae\ud997\ude8c\udacd\udc77\ud8a2\udc1d\ud8bd\udc6e\udb53\udcca\ud828\udf65\udac2\udec9\udac4\udfa2", "\u07cf\ub729\u6b6d\u632b\u4822\u71ef\u556f\u5583\u4ff4\u9f17\u525b\u447c", "\udbee\udfa9\udbfa\udd7a\ud965\udf51\ud897\udf08\ud857\udcd5\udbdb\udf56\ud809\udf6f\udb08\udf55\uda13\udeb7\ud9b2\uddb3",
        56, 17328, -1750539210, -5025529401537892002L, 85172L, true, true, (char) 29779, (char) 26295,
        Double.longBitsToDouble(0x3fea6f889f7284c6L), Double.longBitsToDouble(0x3fe3284477a72c45L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 0, 14, 19, "\udac6\udf96\ud9a2\udd9d\ud87b\udff8\ud93a\udd0f\uda63\udc5e\uda0b\uddc1\udb53\udcca\ud84b\udd7c\uda05\udcdb\udac4\udfd0\udbe0\udcdb\ud86f\udd34\udac6\udfd8", "\u632b\u250a\u3984\u195f", "\ud859\udc34\udacd\ude04\ud96e\ude6a\udabe\udf13\uda36\udc87\u395a",
        37, 21461, 1718551468, 5094617642958903872L, 62378L, false, true, (char) 32511, (char) 17826,
        Double.longBitsToDouble(0x3fc472f511799c44L), Double.longBitsToDouble(0x3fc495f6e11d8f08L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 12, 3, "\udac6\udf96\ud8a2\udd47\ud94c\udebf\udb74\udf29\ud9c5\ude52\udaa9\udc4c\ud817\udfc4\uda19\uddc0\udaaa\udf8d\ud979\udfcf\uda0b\uddde\ud89a\udca9\ud9e6\uddcb\uda77\uddfb\ud9a6\ude0f\uda66\udc37\ud834\udef4\udaf3\udc1b\ud913\udd60\ud8bf\udcd3\ud88e\udd97\ud859\udc05", "\u1683\uc343", "\ud965\udf51\ud897\udf08\uda84\udfeb\udae4\uddcb\ud9fa\udc6d\udb99\udcad\uda14\udde4\ud9b2\ude30",
        37, 56061, 765951807, 2691249811856690869L, -17749L, false, true, (char) 3183, (char) 20911,
        Double.longBitsToDouble(0x3fe620a64d479dd8L), Double.longBitsToDouble(0x3fe1f400d62109bcL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 18, 19, "\udb2d\uddee\udb0b\ude1d\uda4f\udf6b\uda26\udc1e\uda63\udc75\ud8bd\udc6e\ud853\udcca\ud98d\ude57\uc532\udb1a\udcbf\000\ud848\ude64\ud85f\udfc1\ud9a7\udd04", "\u6026\u9e5f\u0084\uc3f0\u39ec\u76ec\u4c53\u447c", "\ud97d\udf51\ud8cc\udc99\udaa8\uded0\ud88c\udf05\ud80a\udf63\uda99\udc35\uda1d\ude8d\udba6\udfbc\udb1e\udfdc\udb87\udfcd",
        5, 9434, 280794688, -2042179475520053170L, -59169L, true, true, (char) 43337, (char) 42201,
        Double.longBitsToDouble(0x3fe23ab9254b0f9eL), Double.longBitsToDouble(0x3fc19e9e56c574c0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=void |this=com.google.javascript.jscomp.Compiler:@?\012",
        Z.run(T, 2, 9, 7, 19, "\udb68\udf9b\ud992\udf9d\udaf7\udcf6\uda25\udfde\uda63\udc75\udb53\udeed\ud967\udd34\udae3\udf83\udb07\ude14\udac4\udfa2\ud826\udf71\uda77\udf26\udac6\udfd8", "\u632b\u250a\u69d1\uac9d", "\ud859\udc34\ud86d\udd4c\udbf5\udf33\uda28\udd07\uda35\udff5\ud858\ude1e\udbd3\udde1\ud96c\ude51\ud897\udf08\uda84\udfeb\ud99e\udd07\ud860\ude93\ud919\udc1d\ud8d2\ude14\ud9b2\ude25\udb91\udd9b\udb82\udf81\udb68\udd97\udb35\udf86\ud80b\ude4b\ud978\udfbc\udaa8\udd0b\uda76\ude1d\uda00\udfdf\uda3e\udfe9",
        19, 74441, 443791783, 3944782548805532144L, 94815L, false, false, (char) 39221, (char) 9251,
        Double.longBitsToDouble(0x3fe0a343075dc1c6L), Double.longBitsToDouble(0x3fd1a41324b99eb2L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 19, 11, "\udac6\udf96\ud9a2\udd9d\udb6c\udc70\ud909\udea2\udb6d\udc02\ud8bd\udc6e\udb53\udcca\ud8d3\udcdf\udab1\udfd0\ud8ee\udf57\udb56\udce3\udbcb\udffc\udaaf\uddc4", "\u1eed\u5c1a\u3de8\ubbf4\u0ef0\uc7a7\ub325", "\udabf\ude22",
        50, 72844, 1025608588, 6424412002479102949L, 89479L, false, true, (char) 38344, (char) 16279,
        Double.longBitsToDouble(0x3fe2501ac9c2f605L), Double.longBitsToDouble(0x3feffeffb71264ddL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 19, "\udac6\udf96\ud9a2\udd9d\udaf7\udcf6\uda25\udfde\uda63\udc75\ud948\udf53\udb53\udcca\udb39\ude0e\uda60\udd55\udac4\udfa2\udbe0\udccd\ud86f\udd34\udac6\udfd8", "\u632b\ud68f\u513b\u4a45", "\udb31\udd15\ud9fc\udd6e\udb50\udf20\u30ed\u3b6e\ud867\udd55\udbc4\udcdc\ud965\udf51",
        19, 53858, -2109720256, 6588793392746084952L, -3158L, false, true, (char) 32511, (char) 4258,
        Double.longBitsToDouble(0x3feaee45545e1c66L), Double.longBitsToDouble(0x3fd1093f3aec2852L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=void |this=com.google.javascript.jscomp.Compiler:@?\012",
        Z.run(T, 2, 7, 7, 3, "\udac6\udf96\ud9a2\udd9d\udaf7\udcf6\uda25\udfde\uda63\udc75\ud82e\udfe6\u71af\udb2e\ude32\uda60\udd55\udac4\udfa2\udbe0\udccd\ud86f\udd34\u0cd7", "\u4912\u250a\u69d1\u7678\u8a6f\u783f\u5222\u12ac\u3b6d\u1664\u39d9\uacad", "\ud8b1\udd30\ud949\uddcf\ud9dd\uded1",
        20, 60913, 628215429, -653882553094676160L, -44770L, true, true, (char) 56205, (char) 55516,
        Double.longBitsToDouble(0x3fd76f571893d9aeL), Double.longBitsToDouble(0x3fc91740732fa844L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 4, 3, "\udac6\udef6", "\u2635", "\ud817\udfc4\uda19\uddc0\udaaa\udf8d\ud979\udfcf\uda0b\uddde\ud873\udea9\ud9e6\uddcb",
        28, -590, 385466077, -4431877849858283057L, -44602L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fec45235dd0b68eL), Double.longBitsToDouble(0x3fe101b4b5851f56L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 7, 0, 13, "\ud86e\udf49\ud8a2\udd77\ud843\udd6e\ud823\ude23\ud9c5\ude52\udaa9\udc4c\ud817\udfc4\uda19\uddc0\udaaa\udf8d\ud979\udfcf\uda0b\uddde\ud8e8\udd8f\ud9f0\udf54\uda77\uddfb\uda3e\uddfc\uda65\udfcf\ud834\udef4\udaf3\udc1b\ud954\udd80\ud8bf\udcd3\udbec\udd47\ud859\udc05", "\u1683\u6327", "\ud965\udf51\ud897\udf08\uda84\udfeb\udae4\uddcb\ud86b\ude86\udb74\udc1f\uda14\udde4\ud9b2\ude30",
        37, 56061, 765951964, 2691249811856690787L, -17749L, false, true, (char) 3183, (char) 20911,
        Double.longBitsToDouble(0x3fe7d0a64ddc9e01L), Double.longBitsToDouble(0x3fe1f400d6210924L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 11, 3, "\udac6\udf96\ud8a2\udd47\ud94c\udebf\ud937\udfa0\ud9c5\ude52\ud927\udc0a\ud817\udfc4\uda01\udc86\uda8a\udd65\ud979\udfcf\uda0b\uddde\ud89a\udca9\ud953\udecc\uda77\udda1\ud9a6\ude0f\uda66\udc37\ud834\udef4\udaf3\udc1b\ud913\udd60\ud8bf\udcd3\ud88e\udd97\ud859\udc05", "\u1683\uc343", "\ud965\udf51\ud897\udf08\uda84\udfeb\udae4\uddcb\ud9fa\udc6d\udb99\udc90\uda14\udde4\ud9b2\ude30",
        37, 56061, 765951807, 2691249811856690869L, 85641L, false, false, (char) 34828, (char) 22321,
        Double.longBitsToDouble(0x3fe5afd4bd0a6daeL), Double.longBitsToDouble(0x3fce946f421ac4a4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 14, 3, "\udac6\udf96\ud8a2\udd47\ud94c\udebf\udb74\udf29\ud9c5\ude52\udaa9\udc4c\ud817\udfc4\uda19\uddc0\udaaa\udf8d\ud979\udfcf\uda0b\uddde\ud89a\udca9\ud9e6\uddcb\uda77\uddfb\ud9a6\ude0f\uda66\udc37\ud834\udef4\udaf3\udc1b\ud913\udd60\ud8bf\udcd3\ud88e\udd97\ud859\udc05", "\u1683\uc343", "\ud965\udf51\ud897\udf08\uda84\udfeb\udae4\uddcb\ud9fa\udc6d\udb99\udcad\uda14\udde4\ud9b2\ude30",
        37, 56061, 765951807, 2691249811856690869L, -17749L, false, true, (char) 3183, (char) 20911,
        Double.longBitsToDouble(0x3fe620a64d479dd8L), Double.longBitsToDouble(0x3fe60400d60618dcL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 3, "\udac6\udf2e\ud8a2\udd47\ud94c\udebf\udb74\udf29\ud9c5\ude52\udaa9\udc4c\ud817\udfc4\uda19\uddc0\udaaa\udf8d\ud979\udfcf\uda0b\uddde\ud89a\udca9\ud9e6\uddcb\uda77\uddfb\ud9a6\ude0f\uda66\udc37\ud834\udef4\udaf2\udfc7\ud913\udd60\ud8bf\udcd3\ud88e\udd97\ud859\udc05", "\u1683\uc343", "\ud965\udf51\ud897\udf08\uda84\udfeb\udae4\ude59\ud9fa\udc6d\udb99\udcad\uda14\udde4\ud9b2\ude30",
        37, 75613, 335355612, -7413457816309068107L, -81649L, false, false, (char) 36191, (char) 49058,
        Double.longBitsToDouble(0x3fe7b528b711b020L), Double.longBitsToDouble(0x3fe5afd4bd0a6daeL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 15, 19, "\udb9f\udd90\udb0b\ude1d\uda4f\udf6b", "\uc581\u4dbf\u1640\uc532\u044e\000\u5f32\ub9fe\ud2d0\uc6db", "\udaa3\udd7f\uda91\udcff\ud9e4\udc77",
        58, 1459, -1536904986, -5292156687152128560L, -61723L, false, false, (char) 40049, (char) 34379,
        Double.longBitsToDouble(0x3fecc579b43a88caL), Double.longBitsToDouble(0x3fd25f87c27f204cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 17, 11, "\udac6\udf96\ud9a2\udd9d\udb6c\udc70\ud909\udea2\uda0f\udd52\ud8bd\udc6e\udb53\udcca\ud8d3\udcdf\udab1\udfd0\ud8ee\udf57\udb56\udce3\udbcb\udffc\udaaf\uddc4", "\u1eed\u5c1a\u5e2c\u1bd4\u0ef0\uc7a7\ub325", "\udabf\ude22",
        50, 14265, 1025608588, 6424412002479102949L, 89479L, false, true, (char) 38344, (char) 16279,
        Double.longBitsToDouble(0x3fe2501ac9c2f605L), Double.longBitsToDouble(0x3feffeffb3d84a7aL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 17, 4, "\udb9f\udd90\ud8c0\udf78", "\ucb2e\uc581\u4dbf\u9005\u93cd\u044e\000\u5f32\ub9fe\ud2d0\uc6db\u632b\u4509\uc9c8\u0084\uc3f0\u39ec\u0644", "\uda28\udd07",
        28, 78437, -639538648, -8409643260817553464L, -72106L, false, false, (char) 1609, (char) 7470,
        Double.longBitsToDouble(0x3fe0d110d7b3db0aL), Double.longBitsToDouble(0x3fe094ff579b62d5L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=void |this=com.google.javascript.jscomp.Compiler:@?\012",
        Z.run(T, 2, 9, 9, 9, "\udac6\udf96\udb44\udf93\udb6c\udc70", "\u4997\ua12d", "\ud8be\udc74\udaea\udf87\ud979\ude41\udbed\uddd5\udbc7\udd5f",
        16, 86732, -1833803458, -4020305596717294151L, -31951L, false, true, (char) 40007, (char) 50548,
        Double.longBitsToDouble(0x3fe308a1ebccce2eL), Double.longBitsToDouble(0x3fc5cf4ccf9564a0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 12, 12, 19, "\udac6\udf96", "\ua7c3\ucb2e\u4997\u7df9\u792f\u90c9\u9647", "\udac6\udfd8\uda39\udca0\udb69\udd12\uda06\udd48\ud9d5\udce4\ud842\udf31\udb5a\udd9f\ud9e4\udc6e\ud88e\ude04\ud859\udc34\ud952\udd80\udbf5\udf33",
        18, 85912, 38144, -3520309937385232123L, -81505L, false, true, (char) 5360, (char) 38344,
        Double.longBitsToDouble(0x3fe42c48924a0359L), Double.longBitsToDouble(0x3fd40f605a1093eeL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 3, 7, "\ud95c\uddc8\ud9a2\udd8c\udadc\ude21\ud80a\udd53\ud894\udce1\ud8bd\udc6e\udb53\udcca\ud98d\ude57\udad3\udfc2\udac4\udfa2", "\u0cce\ub729\u6b6d\u632b\u4822\u71ef\u799e\u76ca\u1ec2\u30ae\u9f23\u1783", "\udbee\udfa9\udbfa\udd7a\ud965\udf51\udac7\ude57\uda84\udfeb\ud99e\udd07\ud809\udf6f\udb08\udf55\uda13\udeb7\ud9b2\uddb3",
        56, 17328, -1750542402, -5025529398285209250L, -24020L, true, true, (char) 44454, (char) 35639,
        Double.longBitsToDouble(0x3fea6f889f7284c6L), Double.longBitsToDouble(0x3fe3284477a72c45L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.Compiler|toSource|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|toSource|com.google.javascript.rhino.Node,com.google.javascript.jscomp.SourceMap,boolean|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|toSource||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|toSource|com.google.javascript.jscomp.JSModule|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|toSource|com.google.javascript.jscomp.Compiler$CodeBuilder,int,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|acceptConstKeyword||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|acceptEcmaScript5||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|addChangeHandler|com.google.javascript.jscomp.CodeChangeHandler|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|addIncrementalSourceAst|com.google.javascript.jscomp.JsAst|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|addToDebugLog|java.lang.String|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|areNodesEqualForInlining|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|check||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|checkFirstModule|java.util.List|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile|com.google.javascript.jscomp.JSSourceFile,[Lcom.google.javascript.jscomp.JSModule;,com.google.javascript.jscomp.CompilerOptions|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile|com.google.javascript.jscomp.JSSourceFile,com.google.javascript.jscomp.JSSourceFile,com.google.javascript.jscomp.CompilerOptions|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|toSource|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|toSource|com.google.javascript.rhino.Node,com.google.javascript.jscomp.SourceMap,boolean|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|toSource||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|toSource|com.google.javascript.jscomp.JSModule|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|toSource|com.google.javascript.jscomp.Compiler$CodeBuilder,int,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Compiler:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
