package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class DeadAssignmentsElimination_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 3, "\ud974\udf4d\ud81d\udcb0\udb3b\udf9f", "\u2a10\u06ee", "\u5bb9\ud895\udcda\ud9fc\udd9b\ud84b\udde7\ud919\udc1f\ud962\udefa\ud8a5\udf45\ud954\ude19\ud9de\ude56\uda78\ude02\ud89a\uddd8\ud8e8\udfbf\ud858\udcb0\ud87f\udd6a\ud879\udc3b\uda39\udf70\udada\udc66\udacf\udf1f\ud8fd\udd4f\ud99d\udde1\ud986\udd8f\ud9ca\udd71",
        42, 88179, -1856965206, -7483133990154345885L, 43264L, false, false, (char) 59975, (char) 21016,
        Double.longBitsToDouble(0x3fd8ed5a1985a74eL), Double.longBitsToDouble(0x3fe3cfcbc980a33fL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 11, "\udbf8\udf43\ud801\udff6\ud958\ude2d\uda53\udffb\udaf0\udf64\u554b\udb34\udcc5\ud950\uddd1\uda05\udd0c\u5bb9\ud895\udcda\udb98\ude3a\udb2f\udd8a\ud94b\udd83\udbad\udd95", "\ucd11\u5fb3\ub6ec", "\ud87f\udd6a\udb71\udc5c",
        23, 4493, -793212439, -8190108954072238887L, 29202L, false, false, (char) 51392, (char) 44482,
        Double.longBitsToDouble(0x3fd4991508dfc252L), Double.longBitsToDouble(0x3fc30b88c28fda44L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 5, 5, "\ud974\udf4d\ud81d\udcb0\udb3b\udf9f", "\uad06\u6e0e", "\u5bb9\ud895\udcda\ud9fc\udd9b\ud84b\udde7\ud919\udc1f\ud962\udefa\ud8a5\udf45\ud954\ude19\ud9de\ude56\ud90a\udc6b\ud89a\ude76\uf268\u6fe5\ucfc0\udbbc\ude00\uda39\udf70\udada\udc66\udacf\udf1f\ud979\udec9\udbbe\udcf1\ud986\uddf5\ud9ca\udd71",
        42, 88179, -1856965206, -7483133986161368477L, -22272L, true, false, (char) 7910, (char) 21840,
        Double.longBitsToDouble(0x3fd8eff98985a74eL), Double.longBitsToDouble(0x3fe09fcbc980a33fL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 2, 3, "\ud974\udf4d\ud81d\udcb0\udb3b\udf9f", "\u2a10\u06ee", "\u5bb9\ud895\udcda\uda2f\ude7d\ud84b\udd93\ud919\udc1f\ud962\udefa\ud8a5\udf45\ud954\ude19\ud9de\ude56\uda78\ude02\ud89a\uddd8\ud8e8\udfbf\ud858\udcb0\ud87f\udd6a\ud879\udc3b\uda39\udf70\udada\udc66\udacf\udf1f\ud8fd\udd4f\ud99d\udde1\ud986\udd8f\ud9ca\udd71",
        42, 88179, -1856965206, -7483133990154345885L, 43264L, false, false, (char) 59975, (char) 21016,
        Double.longBitsToDouble(0x3fd8ed5a1985a74eL), Double.longBitsToDouble(0x3fe3cfcbc980a33fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 3, "\ud974\udf4d\ud81d\udcb9\udb3b\udf9f", "\u2a10\u06ee", "\u5bb9\ud895\udcda\ud874\udc14\ud83b\ude1d\ud907\udfe3\ud962\udefa\ud8a5\udf45\ud954\ude19\ud9de\ude56\uda78\ude02\ud89a\uddd8\ud8e8\udfbf\ud858\udcb0\ud87f\udd6a\ud879\udc3b\uda39\udf70\udada\udc66\udacf\udf1f\ud8fd\udd4f\ud99d\udde1\ud986\udd8f\udb0e\ude53",
        52, 25583, -1846712322, -4124293089799043272L, 26798L, false, false, (char) 23112, (char) 21016,
        Double.longBitsToDouble(0x3fd8ed5a1985a74eL), Double.longBitsToDouble(0x3fe3cfcbc980a33fL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 3, 8, "\ud97d\udc8f\ud87b\udd39\u3e96\uda54\udc18\uda70\udf39\u8827\udb59\uddae\ud950\udd26\uda05\udd0c\u5bb9\ud949\udde1\ud9fc\udd9b\udb3d\udf33\ud968\ude57\udbe9\udceb", "\u9712\u9dd8\uc0c7\u6a5f\u7dff\ub59a\u670c\u0402\ub4ca\u6fb8\u1222\ubfe0\u7f3b\ub16f\u5149\u5af2\u6583\u11fd\u7e69\ub037\u9eb3\u4c42\ucd86\ucf5e\u80fe\u2ddc\u55cd\u2a85\u37f0\u667e\u864a\ua3d4\u5148\u2e24\u5fd3", "\ud8bf\udd4b",
        18, 26080, -1282294425, -698392935270119941L, -50719L, false, true, (char) 51961, (char) 49696,
        Double.longBitsToDouble(0x3fcf3a3a13bdcc78L), Double.longBitsToDouble(0x3fcf7ac329008a50L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 1, 10, 10, 3, "\ud974\udf4d\ud81d\udcb0\udb3b\udf9f", "\u1a16\u06ee", "\u5bb9\ud895\udcda\ud885\udcf2\ud84b\udde7\ud919\udc1f\ud962\udefa\ud8a5\udf45\ud83c\udc83\ud9de\ude56\uda78\ude02\ud89a\uddd8\ud8e8\udfbf\ud858\udcb0\ud87f\udd6a\ud879\udc3b\udbef\uddab\udb60\udd88\udacf\ude52\ud8fd\udd4f\ud99d\udde1\udaa0\uddbc\ud9ff\uddeb",
        42, 88179, -1856965206, -7483014949030600093L, 43264L, false, false, (char) 59975, (char) 16810,
        Double.longBitsToDouble(0x3fd8ed5a1985a74eL), Double.longBitsToDouble(0x3fe3cfcbc980a33fL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 1, 9, 8, 2, "\ud974\udf4d\ud81d\udcb0\udb3b\udf9f", "\u2a10\u06ee", "\u5bb9\ud895\udcda\ud9fc\udd9b\ud84b\udde7\u0df2\u5f16\ud8c8\udc6f\u05e9\uc588\udb59\udc03\ud83f\udf7c\ud9cf\ude73\ud858\udcb0\ud87f\udd6a\ud879\udc3b\uda2e\udd70\ud9ee\ude32\ud8ec\udcd1\uda51\udeb9\ud99d\udd1c\ud986\udd8f\ud9ca\udd71",
        42, 65915, -1850270565, -7483133990154345885L, 79616L, false, false, (char) 59975, (char) 28652,
        Double.longBitsToDouble(0x3fd8ed5a1985a74eL), Double.longBitsToDouble(0x3fe3cfcbc980a33fL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 6, 9, "\ud974\udf4d\ud81d\udcb0\udb3b\udf9f", "\u2a10\u06ee", "\u5bb9\ud895\udcda\ud9fc\udd9b\ud84b\udde7\ud919\udc1f\ud962\udefa\ud8a5\udf45\ud954\ude19\ud9de\ude56\uda78\ude02\ud89a\uddd8\ud8e8\udfbf\ud858\udcb0\ud87f\udd6a\ud879\udc3b\uda39\udf70\udada\udc66\udad6\udc1f\ud8fd\udd4f\ud99d\udde1\ud815\udd95\ud9a3\udc6a",
        42, 88179, -1661340246, -7465483414029540765L, 43264L, false, false, (char) 59975, (char) 21016,
        Double.longBitsToDouble(0x3fd8ed5a1985a74eL), Double.longBitsToDouble(0x3fe3cfcbc993e63fL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 6, "\ud974\udf4d\ud81d\udcb0\ud87c\udc60", "\u32c0\u3770\u2e19\u9b4c\u4389\u6af2\u7b37\u356d\u72a9\u1a01\ua4dd\ub2c1", "\ud89a\uddd8\ud8e8\udfbf\ud858\udcb0\ud86f\udf6a\ud879\udc3b\uda39\udf70\udada\udc66\udacf\udf1f\ud8fd\udd4f\udb80\udcdd\ud986\udd8f\ud9ca\udd71\ud891\ude97",
        19, 19794, -1742302903, -8776703809730535806L, 11470L, true, false, (char) 54386, (char) 57330,
        Double.longBitsToDouble(0x3fd802b3f4e88cdcL), Double.longBitsToDouble(0x3fe8eeb117e7d074L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 1, 1, 6, 3, "\ud974\udf4d\ud81d\udcb0\udb3b\udf9f", "\u2a10\u06ee", "\u1fb9\ud895\udcda\ud9fc\udd9b\ud84b\udde7\ud919\udc1f\ud962\udefa\ud85f\udc8c\ud954\ude8e\ud9de\ude56\uda78\ude02\ud89a\uddd8\ud820\udfbb\ud858\udcb0\uda5b\udf51\ud879\udc3b\uda39\udf70\udada\udc66\udb59\udca3\ud8d1\udecf\ud8ba\udf2f\ud986\udd8f\ud9ca\udd71",
        3, 65689, -1856965206, -7483133990154345885L, 43264L, false, false, (char) 55521, (char) 21016,
        Double.longBitsToDouble(0x3fd8ed5a1985a74eL), Double.longBitsToDouble(0x3fe3cfcbcd80a33fL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 2, 1, "\udac4\udd9b\ud81d\udcb0\udb3b\udf9f\uda53\udffb\ud811\udeb5\udba3\udf3c", "\u9b8f\u4389\u6af2", "\ud919\udc1f",
        7, 88510, -1777776552, -5839005851048125453L, -55316L, true, true, (char) 46078, (char) 46449,
        Double.longBitsToDouble(0x3fe72486d166c571L), Double.longBitsToDouble(0x3fde976d469ba170L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 1, 10, 2, 11, "\ud998\ude28\ud21c\uda1f\udd3c", "\u4f78\u067a\u2dd5\u9b4c\u4389\u6af2\ub56b\u0c19\u72a9\u1a01\ua4dd\u1007\ua1bb\u9d38\u2668\u8254\u3fac\u25e5\u66e8\u257d", "\ud8fd\udd4f\ud99d\udde1\ud986\udd8f",
        30, 44026, -257598285, 6071773901373987648L, 56030L, false, false, (char) 44633, (char) 29033,
        Double.longBitsToDouble(0x3fd9690ba91dab42L), Double.longBitsToDouble(0x3fd3c1967cf3f290L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 8, "\uda27\udff8\uda0b\udeba\udb56\udeab\uda47\uddf7", "\u5a1e\u2e7e\u9b4c", "\udbda\udc46\ud8e1\udf98\uda7a\udd69\udb1e\udefe\ud8a7\udff8",
        24, 85965, 1725548879, 1363006139643214997L, 53823L, false, false, (char) 3903, (char) 51223,
        Double.longBitsToDouble(0x3fd0f94d469ba170L), Double.longBitsToDouble(0x3fc372cacbb28324L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 2, 3, "\ud974\udf4d\ud813\ude14\ud960\udd52", "\u325c\u06ee", "\u5bb9\ud895\udcda\ud874\udc14\ud83b\ude1d\ud907\udfe3\ud962\udefa\ud8a5\udf45\u9ea3\ud8dd\udcc4\uda78\uddf3",
        31, 80637, 215893998, 7685857997395479240L, -27117L, true, false, (char) 36916, (char) 46270,
        Double.longBitsToDouble(0x3fef019a52773f3dL), Double.longBitsToDouble(0x3feff3b2f14991edL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 2, 10, 9, 6, "\ud97d\udc8f\ud87b\udd39\u3e96\uda54\udc18\uda4a\ude05\udaca\uddbe\udb49\udcd1\ud950\udd26\uda05\udd0c\u5b41\ud949\udde1\ud9fc\udd9b\udb4c\udcaa\ud968\ude57\udbe9\udceb\uda43\ude80\ud954\ude19\ud9de\ude56\uda78\ude02\ud89a\uddd8\uda2d\udca1\udb15\uddae\ud888\udf97", "\ub4ca\u6fb8\u1222", "\ud9d6\udc90\ud9d4\ude36\ud9d8\udf90",
        10, 87250, -2043504954, -3300682771292827548L, 6656L, true, true, (char) 28437, (char) 34921,
        Double.longBitsToDouble(0x3fe1840576364a62L), Double.longBitsToDouble(0x3fab97fec64fc640L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 2, 1, 9, 3, "\ud97d\udc8f\ud87b\udd39\u3e96\uda54\udc18\uda70\udf39\u8827\udb59\uddae\ud950\udd26\ud9f0\udf6d\u5bb9\ud973\ude96\ud9fc\ude8e\udb3d\udf33\ud968\ude57\udbe9\udceb", "\u9712\u9dd8\uc0c7\u6a5f\u7dff\ub59a\u670c\ucb69\u4836\u1fa3\u393a\ubfe0\u7f3b\u516f\u48d3\ucd2a\u5f60\u11fd\u7e69\ub037\u9eb3\u4c42\u9b2f\ucf5e\u80fe\u2ddc\u55cd\u2a85\u37f0\u0929\ua68d\uc1ce\u5148\u2e24\u5fd3", "\ud8bf\udd4b",
        13, 56462, -1282294425, -698392938285922565L, 36432L, false, true, (char) 51961, (char) 8993,
        Double.longBitsToDouble(0x3fcf3a3a13bdcc78L), Double.longBitsToDouble(0x3fcf7ac329008a50L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=new com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 2, 10, 10, 3, "\ud974\udf4d\ud81d\udcb0\udb3b\udf9f", "\u4968\u06ee", "\u5bb9\ud895\udcda\ud885\udcf2\ud84b\udde7\ud919\udc1f\ud962\udefa\ud8a5\udf45\udac0\udc5a\udab1\ude71\uda78\udd30\ud89a\uddd8\uda21\udd5b\ud8cb\udd6e\udbf7\udc2f\ud89c\udd09\udbef\uddab\udb60\udd88\udacf\ude52\ud8fd\udd4f\ud99d\udde1\udaa0\uddbc\ud9ff\uddeb",
        42, 88179, -1856965206, -7483014950065522589L, 43264L, false, false, (char) 59975, (char) 16810,
        Double.longBitsToDouble(0x3fd8ed5a1985a74eL), Double.longBitsToDouble(0x3fe3cfcbc980a33fL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 6, 3, "\ud974\udf4d\ud81d\udcb0\udb3b\udf9f", "\u1a16\u06ee\u2e20\u9b4c\uacdb", "\ud84b\udde7\ud919\udc1f\ud962\udefa\ud8a5\udf45\ud83c\udc83",
        9, 92187, 837199317, -7171919609654786066L, 50216L, false, false, (char) 30480, (char) 31184,
        Double.longBitsToDouble(0x3febac2814d99a56L), Double.longBitsToDouble(0x3fe36c4e3bc8b070L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 2, 4, 9, 6, "\uc9ed\ud81d\udcb0\udb3b\udf9f\uda53\udffb\ud811\udeaa\ud9c7\ude6d\uda29\udf2a\ud92a\udf8c\ud845\udede\u9a46\uda95\uddda\ud9fc\uddd6\ud84b\udde7\ud919\udc1f\ud962\udefa\ud85f\udc8c\ud954\ude8e\udb24\udd18\uda78\ude02\ud935\udfe6\ud98b\ude84\ud858\udcb0\uda5b\udf51\ud9ea\udf19\uda39\udf70\udada\udc66\udadc\udc9f", "\u6c92\ud2ea\u863e\u8943\ua819\ua5f2\uca06\u8222\u1efd", "\ud8ce\udcd1\udb1f\udced\udbff\ude05\uda62\uddcd\udaf5\udfe8\uda8f\udc62\udaf6\udee1\ud81a\ude5e\uc0c5",
        26, 13453, -1759574145, -3820180124561248012L, -20951L, true, false, (char) 7791, (char) 9082,
        Double.longBitsToDouble(0x3fe491d127052790L), Double.longBitsToDouble(0x3fdf40832d42dae6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 1, "\ud84a\udce8\uda8d\udf64\udb0c\udec8\ud88c\udf18\ud811\udeb5\udb3c\udf42", "\u2f52\u5ff0\u6af2\u7b37\u0c6d\u72a9\u1a01\ua4dd\u32c1", "\udb93\udf96\ud962\udf27\ud857\udfd3\ud87f\udd6a\ud879\udc3b\uda39\udf70\udada\udc66\udacf\udf1f\udad4\uddfa\udadf\udc48\ud957\udefc\uda99\ude11\udb21\udd8f",
        19, 88961, -1601540428, -7062244328546083229L, 49999L, true, true, (char) 8038, (char) 18366,
        Double.longBitsToDouble(0x3fe7776f19f5181dL), Double.longBitsToDouble(0x3fc9e08e939213f8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 7, 1, "\udac4\udd9b\ud81d\udcb0\udb3b\udf9f\uda53\udffb\u45a7\ud93e\uddc9", "\u9b8f\u4389\u6af2", "\ud919\udc1f",
        7, 88510, -1795803322, 4750022446654829731L, 8321L, false, false, (char) 5054, (char) 7896,
        Double.longBitsToDouble(0x3fde976d469ba170L), Double.longBitsToDouble(0x3fe44253ca49c34cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=java.lang.Boolean:false |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 2, 1, 1, 1, "\udac4\udd9b\udbcc\udf67\udb3b\udf9f\udbd8\udd3d\u972f\udba3\udf3c", "\u9b8f\ubc6f", "\ud84b\udde7\ud919\udc1f\ud962\udefa\ud8a5\udf45\ud81d\uddfd",
        37, 35883, 984065058, -4148749240180521199L, 50216L, false, false, (char) 7896, (char) 23165,
        Double.longBitsToDouble(0x3fd51705d562aaa6L), Double.longBitsToDouble(0x3fea705c097113e5L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 3, "\ud974\udf4d\ud21c\udb3b\udf9f", "\u2a10\u06ee", "\udaf0\uddc4\ud895\udcda\ud9fc\udd9b\ud84b\udde7\ud919\udc1f\ud962\udefa\ud8c7\udec4\ud954\ude19\ud9de\ude56\uda78\ude02\ud89a\uddd8\ud8e8\udfbf\ud858\udcb0\ud87f\udd6a\ud879\udc3b\uda39\udf70\udada\udc66\udacf\udf1f\uda4a\ude3a\ud8b3\udd6c\ud986\uddc4\ud9ca\udd71",
        42, 88179, -1856965206, -7483133990146589597L, 43264L, false, false, (char) 59975, (char) 21016,
        Double.longBitsToDouble(0x3fd8ed5a1985a74eL), Double.longBitsToDouble(0x3fb467de4c035810L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|isVariableReadBeforeKill|com.google.javascript.rhino.Node,java.lang.String|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|isVariableStillLiveWithinExpression|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,java.lang.String|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|checkHookBranchReadBeforeKill|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,java.lang.String|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|enterScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|exitScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|tryRemoveAssignment|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.jscomp.DataFlowAnalysis$FlowState|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|tryRemoveAssignment|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.jscomp.DataFlowAnalysis$FlowState|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|tryRemoveDeadAssignments|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.jscomp.ControlFlowGraph|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "C|com.google.javascript.jscomp.DeadAssignmentsElimination|<init>|com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|isVariableReadBeforeKill|com.google.javascript.rhino.Node,java.lang.String|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|isVariableStillLiveWithinExpression|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,java.lang.String|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
