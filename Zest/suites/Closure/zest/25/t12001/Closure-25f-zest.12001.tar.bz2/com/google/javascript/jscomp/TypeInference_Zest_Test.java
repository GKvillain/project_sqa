package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeInference_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 15, 0, "\ud9a3\udd2c\ud83a\udfaa\udb74\udea0\ud9bc\udcbb\udb97\udc0b\ud9fa\udcbf\ud81e\udc77", "\ud2c1\u45ca\uc029\u78b0\ucc3b\u2ef1\u0ad8\u920a\u35cc\u69df\u30ef\uc9ec\u78e2\u1114", "\ud855\udf1f\udaf6\udd99\ud983\udca7",
        56, 39241, 1469154220, -8156808621532043537L, 80893L, false, false, (char) 26086, (char) 35959,
        Double.longBitsToDouble(0x3fe59171098145e4L), Double.longBitsToDouble(0x3fe962b569274952L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 15, 0, "\ud9c3\udcc1\uda1b\udff0\udb6e\uddc8\ud9bc\udcbb\udb6c\udf0b\ud9fa\udcbf\u45b2\uda9b\uddb0\ud8e0\udf5b\udb4f\udd3b\ud9e3\udf66\uda4b\udd1d\ud9f4\udf18\ud9d7\udddd\udbd1\ude9a\ud81b\udcb3\ud91f\udfd9\udbb9\udda5\uda68\udf91\u4e4d", "\u0372\u4177\u6f26\uac91\u6b2b\u3fe9\u4dd8\u145c\u0b32\u41df\u6200", "\ud9b2\udcf6\uda13\udd04\u9665\ud984\udf4b\udbd8\ude82\ud998\uded0\uda7d\ude49\ud8a0\udf7e\uda5a\udc4a\udb50\udfd7\udb3e\ude70\udb10\udcca\udbf8\udc2a\ud853\udfab\udaca\udfb9\ud94d\udd16",
        27, 62187, 1505255627, 8842604903366715911L, -61653L, true, false, (char) 35846, (char) 31734,
        Double.longBitsToDouble(0x3fc77a54a8bb5220L), Double.longBitsToDouble(0x3feaccfe36eb068bL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 15, 9, "\ud9f8\udfde\ud9e1\ude88\ud902\udf63\ud9bc\udc26\udb97\udc0b\ud9fa\udcbf\ud81e\udc77", "\ud2c1\u764e\uc029\u78b0\ucc3b\u2ef1\u0ad8\u920a\u35cc\u8246\u30ef\u68bc\u2ed0\u1114", "\ud841\udf50\udaf6\udd99\ud983\udca7",
        14, 254, -2087615572, -8156767364076198161L, -50532L, true, false, (char) 333, (char) 5609,
        Double.longBitsToDouble(0x3fdfdf3efdc06dcaL), Double.longBitsToDouble(0x3fe4c195e15745e4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:BOTH\012",
        Z.run(T, 1, 11, 3, 0, "\ud9a3\udd3b\udb1b\udcf9\udb74\ude12\ud9bc\udcbb", "\u858d\ua9f9\u4059\u5b26\u45ca\uc029\ubde8\u4ce3\u2f0e\u0ad8\u920a\u8fe7\u69b0\u30ef\u5238\u7812\u451f\ud323\uce22\uac91\u6b2b\u02f8\u64ba\u628a", "\ud8aa\uddfe\ud820\ude71\ud836\udc15\ud9a7\uddd4\ud8d9\udd36\ue065\ud98a\uddd3\udbd8\ude82\ud998\uded0\ud8db\udeed\ud8a2\udfb4\ud89c\udd8b\ud9e7\ude4b\ud88f\ude20Q\udac1\uddda\ud921\udefc\u26f1\udaea\udf64\ud80b\udcfe\udb66\udc7b\udbbe\uddc5",
        16, 29667, -1990699010, -1812170509677137771L, -60186L, false, true, (char) 19435, (char) 11795,
        Double.longBitsToDouble(0x3f8832c3f0f68f00L), Double.longBitsToDouble(0x3fca3275a6f161f8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 15, 0, "\ud958\udd71\ud96a\udc71\udb74\ude17\udbf3\udf36\udae1\udf91\udb67\udfcb\udb1e\uddd4\ud878\udda0\uda86\udfe2\ud916\ude70\uda6c\udcbf\udad4\udd18\ud8fb\udcc4\udb05\udc44\udb75\ude52", "\u35cc\u69df\u30ef\uc9ec\u78e2\ub9f6\ua478\u3af0\ud6f1\u61cb\u9178\u2840\u628a\u5375\u90a0\uc215\uc823", "\uda13\udd04\u9665\ud943\udd2f\udbfe\uddfb",
        40, 29433, 1017029024, -1330503822730354621L, -84505L, false, true, (char) 22186, (char) 52689,
        Double.longBitsToDouble(0x3fe41ff25f3db723L), Double.longBitsToDouble(0x3fee1b668dce65cfL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:TRUE\012",
        Z.run(T, 1, 11, 4, 0, "\ud9a3\udd2c\ud83a\udfaa\udb74\udea0\ud9d0\ude7e\ud9c2\udc60\ud94a\udf2d\ud81e\udc77\uda9b\uddb0\ud8e0\udf5b\ueb53", "\u78b0\ucc3b\u2ef1\u0ad8", "\ud898\udfca\ud96a\udf37\ud8b0\udc15\ud836\ude72\ud8ab\udc1e",
        47, 42125, 200322667, -7627626178535568025L, 7959L, false, false, (char) 31542, (char) 46524,
        Double.longBitsToDouble(0x3fef8be5e93cc734L), Double.longBitsToDouble(0x3fc5db2317dfbb3cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:TRUE\012",
        Z.run(T, 1, 11, 6, 7, "\ud9a3\udd2c\ud83a\udfaa\udb74\udea0\ud9bc\udcbb\udb97\udc0b\udbab\udebd\ud81e\udc77", "\ud2c1\u45ca\uc029\u78b0\u02fc\ubfad\u161e\u920a\u35cc\u69df\u30ef\uc9ec\u78e2\u1114", "\ud855\udf1f\udaf6\udd99\ud983\udca7",
        56, 39241, 1469154220, -8156808621532043537L, 80893L, false, false, (char) 26086, (char) 35959,
        Double.longBitsToDouble(0x3fe59171098145e4L), Double.longBitsToDouble(0x3fe962b569274952L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:BOTH\012",
        Z.run(T, 1, 11, 15, 0, "\ud9c3\udcc1\uda1b\udff0\ud9c6\udc53\ud9bc\udc40\udb6c\udf0b\ud9fa\udcbf\u45b2\uda9b\uddb0\ud8e0\udf5b\udb4f\udd3b\ud9e3\udf66\uda4b\udd1d\ud9f4\udf18\ud9d7\udddd\uda9e\udfc3\ud81b\udcb3\ud91f\udfd9\ud9c9\udec4\udabf\udd80\u157b", "\u01ac\u58b8\u6f26\uac91\u6b2b\u3fe9\u4dd8\u145c\u0b32\u41df\u5b2f", "\ud8fb\udd2e\uda13\udd04\u9665\ud9a5\udf4b\udbd8\ude82\ud998\uded0\uda7d\ude49\ud8a0\udf7e\uda5a\udc4a\udb50\udfd7\udb3e\ude70\udb10\udcca\udbf8\udc2a\ud853\udfab\ud949\udcd8\uda53\udc30",
        18, 62187, 1505255627, 8842604903366715911L, -61653L, true, false, (char) 35846, (char) 31734,
        Double.longBitsToDouble(0x3fc77a54a29b5220L), Double.longBitsToDouble(0x3feaccfe36eb068bL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:EMPTY\012",
        Z.run(T, 1, 11, 1, 13, "\ud9c3\udc6c\uda1b\udff0\udb6e\uddc8\ud9bc\udcbb\udb6c\udf0b\ud9fa\udcbf\udae0\ude19\ud992\udde5\ud8e4\ude39\udb4f\udd3b\ud9e3\udf66\uda4b\udd1d\ud9f4\udf18\uda09\udc96\udbd1\ude7f\ud81b\udcb3\ud91f\udfd9\udbb9\udda5\uda68\udf91\u4e4d", "\u036a\u4177\u6f26\uac91\u6b2b\u3fe9\u4dd8\u145c\u0b32\u41df\u6200", "\ud9b2\udcf6\uda13\udd04\u9665\ud984\udf4b\udac6\udf83\ud998\uded0",
        32, 89900, -245085913, -1056326431923672257L, -74530L, true, false, (char) 21465, (char) 24620,
        Double.longBitsToDouble(0x3fcaa834b76da034L), Double.longBitsToDouble(0x3fe64fa79e4f5998L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\012",
        Z.run(T, 1, 11, 15, 7, "\ud9c3\udcc1\uda1b\udff0\udb6e\uddc8\ud9bc\udcbb\udb6c\udf0b\ud9fa\udcbf\u45b2\uda9b\uddb0\ud8e0\udf5b\udb4f\udd3b\udb95\udffe\udbe4\ude2f\uda05\ude2c\ud9d7\udddd\udbd1\ude9a\ud81b\udcb3\ud91f\udfd9\udbb9\udda5\uda68\udf91\ud7c4", "\u0e4a\u4177\u6f26\uac91\u6b2b\u3fe9\u4dd8\u145c\u0b32\u41df\u6200\u51c9\u03b8\u6463\u67d8\u5dbd\uad86", "\uda7d\ude49\ud8a0\udf7e\ud9f5\udfb7\udb50\udf61\udb3e\ude70\udb10\udcca\udbf8\udc2a\ud853\udfab",
        58, 55652, 820425847, -6266717746335686453L, -61653L, true, false, (char) 35846, (char) 31734,
        Double.longBitsToDouble(0x3fc77a54a8bb5220L), Double.longBitsToDouble(0x3feaccfe36eb068bL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 3, 0, "\ud9a3\udd3b\udb1b\udcf9\udb74\ude12\uda57\udd55", "\u8579\ua9f9\u4059\u5b26\u45ca\uc029\ubde8\u4ce3\u8adb\ucf66\u920a\u8fe7\u69b0", "\ud949\ude6f\uda09\udd8e\ud908\udc71\uda0e\udc36\ud855\udf1f\udaf6\udd99\ud97b\udca3\ud8b5\ude3b\ud8fc\udcaf",
        35, 47863, 870983407, -6318594687499482812L, -82857L, true, true, (char) 12243, (char) 51033,
        Double.longBitsToDouble(0x3feb152019274952L), Double.longBitsToDouble(0x3fd2806a4e9aae64L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 3, 0, "\ud9a3\udd3b\udb1b\udcf9\udb74\ude12\ud9bc\udcbb\u3dff\ud9fa\udcbf\ud825\udc77\uda9b\uddb0\uda5e\udc35\ud875\udf33\uda73\udc4d\uda45\ude4f\ud899\udd86\udb31\udc07\udb75\ude6f", "\u8fe7\u69b0\u30ef\u5238\u7812\u451f\ud323\uce22\uac91\u6b2b\u02f8\u64ba\u628a\u5375\u09e6\u7c76\u3fae\u6d52\u0c16\u0670", "\udbd8\ude82\ud998\uded0\ud8db\udeed\ud8a2\udfb4\ud89c\udd8b\ud9e7\ude4b\ud88f\ude20Q\udac1\uddda\ud921\udefc\u26f1\udac0\udf6f\ud80b\udcfe",
        38, 14574, -867224649, 8541924015350503422L, 67787L, true, true, (char) 8852, (char) 65166,
        Double.longBitsToDouble(0x3fbebf3bcce4ebf8L), Double.longBitsToDouble(0x3fceb93ec536d314L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:BOTH\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 3, 0, "\ud9fc\udc37\ud8bd\udce5\udb73\udebd\ud9bc\udcbb", "\u8615\ua9f9\u386c\u5b26\u45ca\uc029\ubde8\u0a59\u2f0e\u0ad8\u920a\u8fe7\u69b0\u30ef\u5238\u7812\u39dd\ud323\u5e9f\uac79\u6b2b\u02f8\u64ba\u628a", "\u47b3\uccfa\ud836\udc15\ud9a7\uddd4\ud8d9\udd36\uda89\udc4b\ud98a\udd93\udbd8\ude82\ud998\uded0\ud8db\udeed\ud8a2\udfb4\udb65\udf6f\ud9e7\ude4b\udad2\udca1\ud83e\udfe6\udaf7\udf50\ud921\udefc\u26f1\udaea\udf64\ud80b\udcfe\udb66\udc7b\udbbe\uddc5",
        16, 29667, -1990699010, -1812170509677137771L, -60186L, false, true, (char) 19435, (char) 11795,
        Double.longBitsToDouble(0x3f8832c3f0f68f00L), Double.longBitsToDouble(0x3fca3275a6f161f8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:BOTH\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 0, "\ud99c\udfe4\udb1b\udcf9\udb74\ude12\ud9bc\udcbb\u3dff\ud9fa\udcbf\ud825\udc77", "\u5b26\ub864\u909c\ubde8\u4ce3\u2f0e\u98ba\u929f\u1ce8\ud6a0\u30ef\u5238\u7812\u451f", "\ud8a0\udc1d\ud88a\udd7a\ud97b\udca3\ud8b5\ude3b\ud8fc\udcaf",
        11, 16899, 870983181, -6318594687343769276L, -82857L, false, false, (char) 26450, (char) 4464,
        Double.longBitsToDouble(0x3fe217381fdb4982L), Double.longBitsToDouble(0x3fd2806a4e9aae64L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\0121=com.google.javascript.rhino.jstype.BooleanLiteralSet:FALSE\012",
        Z.run(T, 2, 11, 11, 0, "\ud9a3\udd3b\udb1b\udcf9\udb74\ude12\ud9bc\udcbb\ud8f5\ude1c\ud892\ude22\ud8a3\udea9\uda9b\uddb0\uda5e\udc35\ud875\udf33\uda73\udc4d\uda45\ude4f\ud899\udd86\udb31\udc07\udb75\ude6f", "\u8fe7\u69b0\u30ef\u5238\u7812\u451f\ud323\uce22\uac91\u6b2b\u02f8\u64ba\u628a\u5375\u09e6\u28e7\ub214\u6d52\u0c16\u0670", "\udbd8\ude82\ud998\uded0\ud8db\udeed\ud8a2\udfb4\ud89c\udd8b\ud9e7\ude4b\ud88f\ude20Q\udac1\uddda\ud921\udefc\u26f1\udac0\udf6f\ud80b\udcfe",
        38, 14574, -867224649, 8541924015350503422L, 67787L, true, true, (char) 8852, (char) 65166,
        Double.longBitsToDouble(0x3fbebf3bcce4ebf8L), Double.longBitsToDouble(0x3fceb93ec536d314L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:BOTH\0121=com.google.javascript.rhino.jstype.BooleanLiteralSet:BOTH\012",
        Z.run(T, 2, 11, 11, 0, "\ud9fc\udc37\ud8bd\udce5\udb73\udebd\ud9bc\udcbb\udb91\udd0b\ud8c0\udc01\ud81e\udd39\uda9b\uddb0\uda20\udc36\ud875\udf33\ud9e3\udf66\ud8c7\udc14\ud899\udd86\ud997\udfc8\udb75\ude6f", "\u8f86\u69b0\u6bd5\uae1c\u7812\u39dd\ub750\u5fcb\uac79\u6b2b\u02f8\u64ba\u628a\u5375\u65cb\uc6e3\ub823", "\ud8d9\udd36\uda89\udc4b\ud98a\udd93\udbc6\udf9c\ud998\uded0\ud8db\udeed\ud8a2\udfb4\udb65\udf6f\ud9e7\ude4b\ud81d\udd4c",
        37, 10514, -1588777839, 921863740169878431L, -79679L, false, false, (char) 37129, (char) 17683,
        Double.longBitsToDouble(0x3f91305710d12b00L), Double.longBitsToDouble(0x3fc2bcdb276f4904L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:EMPTY\0121=com.google.javascript.rhino.jstype.BooleanLiteralSet:EMPTY\012",
        Z.run(T, 2, 11, 11, 0, "\ud9b5\udedc\udb4b\udf6a\udb74\ude12\ud9bc\udcbb\ud8f5\ude1c\ud892\ude22\ud8a3\udea9\uda9b\uddb0", "\ub864\u909c", "\ud9fa\udfd0\uda71\udca9\ud825\udddf\ud98b\udf74\ud898\udf9b\u4f0c",
        13, 14348, -483150015, 684441460887419391L, -19513L, true, false, (char) 9378, (char) 41353,
        Double.longBitsToDouble(0x3fed647ff8105791L), Double.longBitsToDouble(0x3fc33ff9bbb2a280L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.BooleanLiteralSet:TRUE\0121=com.google.javascript.rhino.jstype.BooleanLiteralSet:TRUE\012",
        Z.run(T, 2, 11, 11, 0, "\ud9fc\udc37\ud8bd\udce5\udb73\udebd\ud9bc\udcbb\udb91\udd0b\ud8c0\udc01\ud81e\udd39\uda9b\uddb0\ud962\udfc2\ud869\udf8c\ud9e3\udf66\ud8c7\udc14\ud899\udd86\ud997\udfc8\udb75\ude6f", "\u8f86\u69b0\u6bd5\uae1c\u7812\u39dd\ub750\u5fcb\uac79\u6b2b\u02f8\u64ba\u1ee0\u15d0\u65cb\uc6e3\ub823\u67e4\u858f\u0670\u2da5\uc3ce\u6f91\u2988", "\udb65\udf6f\ud9e7\udef6\ud81d\udd4c\ud83e\udfb5\udaf7\udf50\ud921\udefc\u26f1",
        23, 41248, -39079777, 6724705776279368631L, -91791L, false, false, (char) 22383, (char) 46108,
        Double.longBitsToDouble(0x3fefcbeec9537ddbL), Double.longBitsToDouble(0x3fcca75206d77760L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 15, 0, "\ud800\udddc\ud85d\udcf0\udb74\udea0\ud9bc\udcbb\udb97\udc0b\ud9fa\udcbf\ud81e\udc77", "\ud2c1\u45ca\uc029\u78b0\ucc3b\u2ef1\u0ad8\u920a\u35cc\u69df\u30ef\uc9ec\u78e2\u1114", "\ud855\udf1f\udb67\udef2\ud983\udca7",
        56, 39241, 1469154220, -8190653788458244369L, 80893L, false, false, (char) 26086, (char) 35959,
        Double.longBitsToDouble(0x3fe59171098145e4L), Double.longBitsToDouble(0x3fe962b569274952L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.TypeInference|traverseNew|com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|backwardsInferenceFromCallSite|com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.FunctionType|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|branchedFlowThrough|com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|createEntryLattice||new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|createInitialEstimateLattice||new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|dereferencePointer|com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|ensurePropertyDeclared|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|ensurePropertyDeclaredHelper|com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.ObjectType|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|ensurePropertyDefined|com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|flowThrough|com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|getBooleanOutcomePair|com.google.javascript.jscomp.TypeInference$BooleanOutcomePair,com.google.javascript.jscomp.TypeInference$BooleanOutcomePair,boolean|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|getBooleanOutcomes|com.google.javascript.rhino.jstype.BooleanLiteralSet,com.google.javascript.rhino.jstype.BooleanLiteralSet,boolean|static",
    "M|com.google.javascript.jscomp.TypeInference|getJSType|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|getNativeType|com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|getPropertyType|com.google.javascript.rhino.jstype.JSType,java.lang.String,com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|inferPropertyTypesToMatchConstraint|com.google.javascript.rhino.jstype.JSType,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
    "M|com.google.javascript.jscomp.TypeInference|traverseNew|com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope|new:com.google.javascript.jscomp.TypeInference:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
