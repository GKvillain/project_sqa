package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class PeepholeSubstituteAlternateSyntax_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 5, 5, "\uda6f\udec4", "\u59ab\u9da2\u68ca\u30a0\u7802\u33da\u8f5e\u1048\u2bd7\u7b55\u491f", "\ud8a2\udc25\udabf\udc55\ud822\ude5a\uda33\udeb8",
        19, 33648, 1856828312, 154248746206781291L, 28003L, true, true, (char) 29227, (char) 55211,
        Double.longBitsToDouble(0x3fcc69493e9b6e54L), Double.longBitsToDouble(0x3feafb5e43f17a7cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 5, 5, "\uda6f\udec4\ud8a3\udc94\ud9b4\udee2\udb18\udc30\ud920\udc43\ud9c3\udd03\udb28\udf6e\udb4c\udc33\ud977\udf10\uda4f\udcd7\ud8d4\udfd8\ud94e\ude63\uda3f\udd57\udb69\udd0b", "\u434f\u0d61\u0d97\u29a8", "\udaca\ude1d\ud902\udca8\ud9fa\udf1b",
        57, 52267, -1502413313, -3172843845280267340L, 9553L, true, false, (char) 39163, (char) 54734,
        Double.longBitsToDouble(0x3fc38cb34c0e53b0L), Double.longBitsToDouble(0x3fd8eb94621340c4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\012",
        Z.run(T, 1, 3, 10, 5, "\uda6f\udec4", "\u6b95\ub224\u68ca\u30a0\u7802\u33da\uc4a6\u1048\u2bd7\u7b55\u491f", "\ud8a2\udc25\udabf\udc55\ud822\ude5a\ud8e5\ude30",
        19, 33648, 1856828312, 154248746206781291L, 28003L, true, true, (char) 57899, (char) 55663,
        Double.longBitsToDouble(0x3fe29fab07a6db95L), Double.longBitsToDouble(0x3feafb5e43f17a7cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 5, 5, "\uda6f\udec4", "\u59ab\u9da2\u68ca\u30a0\u7802\u33da\u8f5e\u1048\u2bd7\u7b55\u491f", "\ud8a2\udc25\udabf\udc55\ud822\ude5a\uda33\udeb8",
        19, 33644, 749532056, 154248638832598891L, 28003L, true, true, (char) 29227, (char) 55211,
        Double.longBitsToDouble(0x3fcc69493e9b6e54L), Double.longBitsToDouble(0x3feafb5e43f17a7cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 6, 15, 14, "\uda6f\udec4", "\u59ab\u9da2\u68ca\u7bcd\u7802\ubc71\ua6ff\u3653\u4934\u7bd3\u47a4", "\udb85\udf42\uda97\udfd9\ud9d8\udc95\uda36\udd8b",
        19, 33648, 1856828312, 154248748756918123L, 93283L, true, true, (char) 29227, (char) 55211,
        Double.longBitsToDouble(0x3fcc69493e9b6e54L), Double.longBitsToDouble(0x3feafb5fd15e8f4bL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 5, 5, "\uda6f\udec4", "\u75a9\ua4f2\u68ca\u30a0\u7f1e\u33da\u8f5e\u1048\u8db9\u7b55\u0dac", "\udaea\udf4b",
        5, 40624, -1864288955, -7038014220544460128L, -99893L, false, false, (char) 61012, (char) 25088,
        Double.longBitsToDouble(0x3fdcc76d9141dd7cL), Double.longBitsToDouble(0x3feda1b9f0e34a49L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 11, 4, "\uda6f\udec4", "\u3782\u9da2\u68ca\u30a0", "\uda67\udf79\udbe4\udfe3\ud94e\uddd4\uda3f\udd57\uda2c\udced\ud9b6\ude7d\u7669\u46dd\udabc\ude7e",
        4, 69045, -1638665381, -266633079702741352L, 86200L, false, false, (char) 24906, (char) 29912,
        Double.longBitsToDouble(0x3fedcd3393b4d3f7L), Double.longBitsToDouble(0x3fcc69493e9b6e54L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 5, "\uda6f\udec4", "\ub9d4\u9d41\u68ca\u30a0\u404e\u33da\u8f5e\u1048\u0356\u7b55\u491f", "\ud8a2\udc25\udabf\udc55\ud822\ude5a\uda33\udeb8",
        19, 66736, 1404824370, -7970402117215408292L, -5728L, true, true, (char) 29227, (char) 55211,
        Double.longBitsToDouble(0x3fcc69493e9b6e54L), Double.longBitsToDouble(0x3feafb5e43f17a7cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 5, 10, "\uda6f\udec4", "\u59ab\u9da2\u68ca\u30a0\ua13a\u4f96\u94c9\u1048\ua506\u6b0a\u16f9", "\ud84f\udd5c\ud80a\ude39\udbc8\udf6d\uda33\udeb8",
        10, 33661, 1856828312, 7504123338444552978L, 28003L, true, true, (char) 20160, (char) 55211,
        Double.longBitsToDouble(0x3fcc69493e9b6c00L), Double.longBitsToDouble(0x3feafb5e44f17a7cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 14, 5, "\ud8e4\udd3e", "\u59ab\u9da2\u156c\u30a0\u7802\u8ed9\u038b", "\uda3f\udd57\uda2c\udced\uf08d\ud815\udc4a",
        24, 9584, -905120376, 4558264342674753985L, 99784L, true, false, (char) 24975, (char) 5139,
        Double.longBitsToDouble(0x3f6b6fed9d89d900L), Double.longBitsToDouble(0x3fedcd3393b4d3f7L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 6, 6, "\ud895\udc61", "\u59ab", "\udbcc\ude39\udb4c\udc33\udbf3\udc0e\uda67\udf79\ud8cd\uded8\ud94e\ude63\uda3f\udd57\uda2c\udced\ud9db\udf7d\u7669\u8ce6\uafac\ud985\udcb9\uda33\udeb8\ud9b9\udd99\ud880\ude68\udaca\ude1d\ud921\ude8b\ud897\udf2a\ud93e\udc1e\ud8b2\udc8c\udbf0\udcb7\uce3a\u6cc2",
        47, 81606, 2054976351, -5580333835261833981L, 46041L, true, true, (char) 55557, (char) 19003,
        Double.longBitsToDouble(0x3fecc50982d24c22L), Double.longBitsToDouble(0x3fecf36384eb8c27L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 5, "\uda6f\udec4", "\u59ab\u9da2'\u8a51\u5011\u3308\u8f5e\u9d7c\u2bd7\ucd2a\u491f", "\ud847\ude37\uf1f4\ud822\ude7c\uda33\udeb8",
        19, 33648, 1856828312, 154415283563719673L, 28003L, true, true, (char) 29227, (char) 55122,
        Double.longBitsToDouble(0x3fd074a4958ab940L), Double.longBitsToDouble(0x3fec1129135ad552L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 11, 6, "\uda6f\udec4", "\u59ab\u0fb5\u6872\u30a0\u7802\u33da\u8f5e\u1048\u535f\u7b8a\u491f", "\ud8a2\udc25\udabf\udc55\ud822\ude5a\uda33\udeb8",
        19, 66960, -1697554332, 5402016285836245481L, 28003L, true, true, (char) 29227, (char) 55211,
        Double.longBitsToDouble(0x3fcc69493e9b6e54L), Double.longBitsToDouble(0x3feafb5e43f17a7cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 5, 6, "\uda81\udf89", "\u7960\u906f\u8108\u9350\u7802\u33da\u8f5e\u1048\u2bd7\u27c7\u2e55", "\ud905\udedd\uc469\uda38\udc08\uda94\ude2d",
        29, 721, 575683185, 154248746206781291L, 28003L, true, true, (char) 29227, (char) 13372,
        Double.longBitsToDouble(0x3fe71a524904dbc0L), Double.longBitsToDouble(0x3fef59384bf1e4a0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 9, 5, "\udb74\udcec", "\u59ab\u9da2\u68ca\u30a0\u7802", "\ud8cd\uded8\ud94e\ude63\ud9cb\udc1d\udb32\udde1",
        49, 29223, 141454495, 7427680089678177131L, 19011L, true, false, (char) 29717, (char) 9837,
        Double.longBitsToDouble(0x3fed13e3ed9f6f6eL), Double.longBitsToDouble(0x3feb18f84007c4fbL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 5, "\uda6f\udec4", "\u6b95\ub224\u68ca\u30a0\u7802\u33da\uc4a6\u1048\u2bd7\u7b55\u491f", "\uda28\udf65\udaf7\udda5\ud822\ude5a\ud8e5\ude30",
        19, 33648, 1856828312, 154248748622700395L, -41847L, true, true, (char) 57899, (char) 55663,
        Double.longBitsToDouble(0x3fe29fab00b827daL), Double.longBitsToDouble(0x3feafc33fbf17a7cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 6, 10, 12, "\ud35b", "\u877d\ub224\uc828\u87ce\u2cc0\u404c\uc4a6\u1048\u2bd7\u7b55\u491f\u9ded\u10f7\u41a4\u6a7b\u0d97\u7fc0\u0798\u2133\u429c\u6af4\uc595\ucbfe", "\udada\udefd\ud950\udf78\udb99\udd30\ud807\ude00\udb8e\ude96\udb09\udce0\udb66\udf73\uda23\uddc3\ud925\udf82\udb04\udc2f\udb52\udf74\ud80d\udd78",
        30, 11423, -1747216459, -7808093627834171698L, -7890L, true, false, (char) 14181, (char) 58872,
        Double.longBitsToDouble(0x3feb3e87682f676dL), Double.longBitsToDouble(0x3fec71512a092d2cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 7, 9, "\uda6f\udec4", "\ub88e\uae75", "\udba3\udc00\ud82d\uddce\ud8ad\udc7d\udace\udceb\uda10\udfa7\ud89a\ude97\uda48\udd62\ud9db\udf87\u7669\ud8a2\udc25\udabf\udc55\ud822\ude5a\ud8e5\ude30\ud81f\ude4b\ud85b\ude57\ud8f4\uddd2\uda22\uddfa\ud9ef\udd1f",
        27, 77563, -1502413313, 8887356581903776281L, 6453L, true, true, (char) 9837, (char) 22278,
        Double.longBitsToDouble(0x3fd798f16adb4698L), Double.longBitsToDouble(0x3fe04f7734d88343L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 6, 13, 5, "\ud89a\udcbf\udace\udf6f\ud863\udcf4\udaff\uddff\ud872\udc15", "\u73b4\u602c\u1952\uceac\u0947", "\ud9db\udf7d\u7669\ud9b6\udcdc\uda2e\udf70\ud822\udeb9\ud8e5\ude30\ud8f2\udf6e\udb63\udced\ud92a\uddb1\uda00\udeec\ud8e4\udf4a\ud958\udd12\udafb\uddc4\udbcb\udce6\udb3f\uddb1",
        50, 16826, -1515479082, 8810036396794555377L, -79098L, true, false, (char) 4912, (char) 9103,
        Double.longBitsToDouble(0x3fe06c97e468bfbeL), Double.longBitsToDouble(0x3fd0b24b85581b92L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 6, 14, 5, "\ud946\ude6f\udbff\udff0\udae1\udf34\udaff\udd67\ud872\udc15\u0403\udbcc\uddd6\udb4c\udc33\udbf3\udc0e\ud83c\udee1\udbb3\udd44\ud94e\ude63\uda3f\udd57\uda2c\udced\ud9db\udf7d\uc2f0\ud8a2\udc25\u9af9", "\u0798\u3e3d\u2a9d\u2552\u8389\u51bd\u08e0\u1bdc", "\uda59\udc2d\ud807\ude00\udb8e\ude96\uda0d\udd41\uda56\udc2f\uda5b\udc74\udaf6\udc91\udbf7\udc26\ud8a5\udeeb\ud9e8\udf9d\udafc\udf99\ud9b3\uddf8\ud956\udd27\ud9fd\udcb4\udb40\udf7b\udb66\ude81\ud956\udf8a\udba7\udc77",
        59, 36453, 1460586685, 6664303316595314940L, 27140L, true, true, (char) 1718, (char) 34630,
        Double.longBitsToDouble(0x3fe066cbff51c9e6L), Double.longBitsToDouble(0x3fed9835a5f685deL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\012",
        Z.run(T, 1, 1, 5, 5, "\uda6f\udea4", "\u59ab\u9da2\u68ca\u30a0\u7802\u33da\u8f5e\u1048\u2bd7\u7b55\u491f", "\ud8a2\udc25\udabf\udc55\ud822\ude5a\uda33\udeb8",
        19, 33644, 749532056, 154248638831157099L, 28058L, true, true, (char) 29227, (char) 55211,
        Double.longBitsToDouble(0x3fcc69493e9b6e54L), Double.longBitsToDouble(0x3feafb5e4449f4cfL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 6, 15, 14, "\ud9cb\udcbe\udbff\udff0\udae1\udf34\udbf6\udf24\u58e0\ud9c3\udd03\uda15\udfc2\ud8e3\udd04\ud92f\udec3\uda8b\udf51\ud947\udf96\udaf6\udc8e\uda3f\uddd5\uda18\udfa3\ud9aa\udfab\u7669\udb85\udf22\uda97\udfd9\ud9d8\udc95\uda36\udd8b\ud9b9\udd99\ud880\ude68\udaca\ude1d\ud902\udc8b\uda9b\ude4b\uda48\uddfb\ud80c\udc6e\ud8f9\udce9\ud9bd\udcdb\uda57\udff1\uda69\udebd\u2e03\uda93\udcba\udac5\udfa7\ud8d9\udea9\udbad\udd04\u5626\uda2b\uddb0\ud88f\ude34\ud9d0\udd98\udb2a\udcc1\ud927\udc88\ud18a\udb44\udfe1\ud810\udc9e\ud9fa\udce1\ud802\udd1d\ud910\ude73\uda05\udde2\udbce\udff6\ud81d\udcbf\ud857\udda2", "\u6259\u56a7\u6bc4\uc399\u337f\u5115\u1918\u56d7\u2fdf\u62df\u5973\ucd47\u25ec\u5fb6\u1c4c\ua27b\u8535", "\uda40\udca3\ud820\udf2e\udabd\udf9a\ud926\udd3c\ud91d\udce6\udab3\udc32\uda57\udfd1\udb24\udeb9\udbf8\ude2d\ud9b1\udecb\ud911\udffe\udae4\udd94",
        0, 25033, -939854465, -3394338574163940092L, -56428L, true, false, (char) 21930, (char) 60218,
        Double.longBitsToDouble(0x3fe71f32af9c5bbfL), Double.longBitsToDouble(0x3fe4cb827f5b000cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 15, 14, "\uda6f\udec4", "\u59ab\u9da2\u68ca\u7bcd\u7802\ubc71\ua6ff\u3653\u4934\u7bd3\u47a4", "\udb85\udf42\uda97\udfd9\ud9d8\udc95\uda36\udd8b",
        19, 33648, 1856828312, 154248748756918123L, 93283L, true, true, (char) 29227, (char) 55211,
        Double.longBitsToDouble(0x3fcc69493e9b6e54L), Double.longBitsToDouble(0x3feafb5fd15e8f4bL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 6, 1, 14, "\ud90e\uddec\ud9fc\udd73\udaf4\udf17\ud996\udd8b\u9129\ud9c3\udd03\uf695\udb4c\udc33\udb6a\udf4a", "\u4934\u7bd3\u47a4\ub21a\u81e0", "\uda81\udd54\ud84a\udef5\ucc68\ud9c5\udff4\udaf9\udf37\u7fe5\uda9b\ude4b\uda48\uddfb\ud970\uddfb\ud819\udf6c\udb53\udca9",
        40, 9347, 1811562406, -8121270650566033043L, 68508L, true, false, (char) 6361, (char) 1035,
        Double.longBitsToDouble(0x3feabad4b4c5b01eL), Double.longBitsToDouble(0x3fcd0b3c8899b5a8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 6, 15, 8, "\ud9de\udce2\udbff\udf32", "\u9da2\u68ca\u7bcd\u7802\u449e\uacb7\u3653\u4934\u7bd3\u47a4\ub21a\u10f7\ud214\u6619\ub456\u2661\u0798\u3e3d\u6134\u6af4\u91bc\u75a7\uaf31", "\udadd\udc14\uda69\udebd\ud99c\ude0c\uda93\udd02\udbf7\udf41\uda3d\ude90\u8df8\udb4c\udcb5\ud95a\udc6f",
        56, 34373, -1023221797, 1740235823016835349L, -74799L, false, true, (char) 6973, (char) 65484,
        Double.longBitsToDouble(0x3fd9b2d17e2b16fcL), Double.longBitsToDouble(0x3fb0daaf4c2672a8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 6, 0, 14, "", "\u7157\u59ab\u9da2\u68ca\u7bcd\u7613\ubc71", "\udaf6\udc8e\uda3f\uddd5\000\ud9a7\ude32\u7669",
        -5, 57928, 849288, -8007048295382518949L, 99784L, true, false, (char) 655, (char) 51255,
        Double.longBitsToDouble(0x3fe81b6e70ff7646L), Double.longBitsToDouble(0x3e3da69fb8000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 6, 15, 14, "\000", "\u59ab\u9da2\u68ca\u7bcd\u7802\ubc71\ua6ff", "\uda3f\uddd5\udbb7\ude73\ud9aa\udfab\u7669\udb85\udf42\uda97\udfd9\u0088\000",
        19, 33648, 1856828312, 144115649595334507L, 93283L, true, true, (char) 29227, (char) 55211,
        Double.longBitsToDouble(0x3fcc69493e9b6e54L), Double.longBitsToDouble(0x3fb7dafe80000000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\012",
        Z.run(T, 2, 3, 3, 14, "\ud993\udc96", "\u56aa\u88ef", "\udb4c\udc33\ud93b\udfd2\uda8b\udecd\ud947\udf96\udaf6\udc9d",
        54, 15640, 1764232569, 2722576807598896806L, -97270L, true, true, (char) 62815, (char) 12463,
        Double.longBitsToDouble(0x3fe962ad406b6eacL), Double.longBitsToDouble(0x3feb5811238374b4L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\udb0d\udd45\ud867\ude02\uda5f\udfcf\uda42\udc89\u6030\ud9c3\udd03\udbcc\ude39\uda93\udfa7\udbf3\ude12\uda67\udf79\ud8cd\uded8\ud967\udc45\uda3f\udd57\ud9ec\udf50\udb21\udea4\u38a9\udaea\udf4b\ud84b\ude53\ud822\ude5a\uda33\udeb8\ud810\udebf\udac5\udfac\ud93d\ude91\ud8d9\ude6d\ud81d\udc7f\u5154\udbaf\udd36\udab3\udcc7", "\u1cb0\uc211\ubfbd\u22a4\u9f2e\u186f\u24f2\u4a6b\uad22\ucd79\uac28\ub2c2\u704c\u9df5\u82df\u7a75", "\udb1b\ude0e\ud893\ude27\ud979\udf05\ud8a0\udd0e\udad7\udd2d\udb00\udf43\uda18\ude14\u7784\udb9c\udf61\ud843\udc2f",
        29, 98032, -647544332, 961850850251324146L, 38057L, true, true, (char) 10195, (char) 9415,
        Double.longBitsToDouble(0x3fa1096768cdfc70L), Double.longBitsToDouble(0x3fee3c0a16944f20L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 5, "\uda6f\udec4", "\u310b\u9d41\u68ca\u30a0\u404e\u33da\u33c8\u772b\u0356\u7b55\u44f9", "\ud8a2\udc25\ud83b\udc0d\ud9be\udf0d\ud990\udc6c\ud9b9\udd99\ud8b7\udfe3",
        35, 19145, -564482212, 7925664893181194304L, -86617L, false, true, (char) 6956, (char) 6972,
        Double.longBitsToDouble(0x3fee3b5e43f17a7cL), Double.longBitsToDouble(0x3fd648cfe33c8b64L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 8, 5, "\udb41\ude97", "\ub9d4\u9d41\u58ca\u657b\u6211\u7fdc\u560b\u65e6\u9391\u5d18\u491f", "\ud9fd\udd69\udadf\udf99\ud822\ude1a\uda33\udeb8\udb48\udd40\ud8c5\ude98\ud8dc\udc21\ud8d2\udefc\ud975\udd60\ud961\udcb5",
        16, 61687, -738756590, 5352813703124603107L, -40075L, false, false, (char) 56177, (char) 49276,
        Double.longBitsToDouble(0x3fef8ebb9b1bca1fL), Double.longBitsToDouble(0x3fedf63277e6095aL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=void |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\012",
        Z.run(T, 2, 1, 1, 5, "\uda6f\udec4", "\ub9eb\u9d41\u68ca\u30a0\u404e\u33da\u8f5e\u1048\ub1b3\u2f49\u491f", "\ud8a2\udc25\udabf\udc55\ud822\ude5a\ud9eb\udeb4",
        19, 66736, 1404824370, -7970402117215408292L, -5728L, true, true, (char) 29227, (char) 55211,
        Double.longBitsToDouble(0x3fcc69493e9b6e54L), Double.longBitsToDouble(0x3feafb5e43f17a7cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 13, 2, "\ud8e4\udd3e", "\u59ab\u9da2\u156c\u30a0\u41c9\u8ed9\u038b", "\uda3f\udd57\uda2c\udced\ud9a9\udc44\udb70\udf02\ud887\udda4",
        24, 40624, 1061303621, -2777232501988646964L, -99893L, false, true, (char) 8720, (char) 25088,
        Double.longBitsToDouble(0x3fd9d89d97734ce4L), Double.longBitsToDouble(0x3feda69fbaa50c37L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 6, 0, 14, "\ud9cb\udcbe\udbff\udff0\udae1\udf34\udbf6\udf24\u58e0\ud9c3\udd03\uda15\udfc2\ud8e3\udd04\ud92f\udec3\uda8b\udf51\ud947\udf96\udaf6\udc8e\uda3f\uddd5\uda18\udfa3\ud9aa\udfab\u7669\udb85\udf22\uda97\udfd9\ud9d8\udc95\uda36\udd8b\ud9b9\udd99\u00a0\udaca\udd85\ud902\udc8b\uda9b\ude4b\uda48\uddfb\ud80c\udc6e\ud8f9\udce9\uda24\udf8f\uda57\udff1\uda69\udebd\u2e03\uda93\udcba\udac5\udfa7\ud8d9\udea9\udbad\udd04\u5626\uda2b\uddb0\u00b7\ud8df\ude4e\udb2a\udcc1\udb3a\uded2\000\000\ud810\udc9e\ud9fa\udce1\ud802\udd1d\u00ae\000\udbce\udf5e\ud81d\udcbf\ud857\udda2", "\u6259\u56a7\u6bc4\u1e99\u337f\u5115\u1918\u0d10\u2fcb\u62df\u5973\u00e3\u253b\u5fb6\u1c4c\ua27b\uc4bb", "\000",
        47, 6965, -654311424, 6993992561292099553L, -46975L, true, false, (char) 21533, (char) 6025,
        Double.longBitsToDouble(0x3fb124f638000390L), Double.longBitsToDouble(0x3fe0ce464d7f68c7L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 6, 15, 8, "H", "\u59ab\u9da2\u68ca\u7bcd\ua930\u9d84\uc72b", "\uda3f\uddd5\udbb7\ude73\udb3f\udfd6\ud964\ude0c\udb85\udf42\uda97\udfd9\u0088\ud845\udc4d\ud9b9\ude1d\ud880\ude68",
        14, 21656, 489709419, -250658823273973854L, -86617L, false, true, (char) 6956, (char) 6972,
        Double.longBitsToDouble(0x3fb7dafe80000000L), Double.longBitsToDouble(0x3fe5d06aac2089e4L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 6, 15, 14, "\011\ud8c0\udc5d\uda96\ude0e\udbeb\udcfd\u58e0\udaf0\udc47", "\u385c\u615e\ucd90\u4934\ud3a2\ud53a\u6960\u4616\ud214\u55c4\u7794\u375b\u0777\ua9a2\u64ae", "\udb0a\ude9d\ud944\udf55\ud869\ude4e\ud83f\udeaa\udadf\ude94\ud833\udf6b\uda6f\udda3\ud8b8\ude3c\uda3d\udf7e\uda00\udd48\udbde\udff5\udb85\udd32",
        -2, 81191, -32970888, -603067979747919819L, -18388L, true, true, (char) 33731, (char) 61446,
        Double.longBitsToDouble(0x3fe9f3841e8ef53dL), Double.longBitsToDouble(0x3fe4684bf33705e6L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\udb57\udd2b\ud867\ude02\uda5f\udfcf\uda42\udc89\000\ud989\udd44\udbb5\udc39\udb32\udfd6\udbf3\udd20\uda67\udf79\ud8cd\uded8\ud940\uddb1\uda3f\udd26\ud9ec\udf50\udb21\udea4\u38a9\udaea\udf4b\ud84b\ude53\000\uda33\udeb8\ud810\udebf\udac5\udfac\ud93d\ude91\ud8d9\ude6d\ud81d\udc7f\u29cf\udb8b\udd85\udab3\udcc7", "\u1cb0\uc211\ubfbd\u22a4\u9f2e\u186f\u24f2\u099b\uad22\ucd79\u00ea\u0f0a\u704c\u9df5\u7a93\000", "\udb1b\ude0e",
        41, 67797, 25036, -134821120L, -50163L, false, false, (char) 0, (char) 11520,
        Double.longBitsToDouble(0x3fc5126780000000L), Double.longBitsToDouble(0x3fe2080002f20d59L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 6, 15, 8, "\007\ud8ab\udef4\ud98f\udf2b\udbf6\udf24\u58e0\ud9c3\udd03\uda15\udfc2\ud8ed\ude88\udac4\udcb0", "\u4934\u7bd3\ud757\ud510\u0532\u4b25\u38d8\ub8d7\u919d\u081c\u3e3d\u79c6\ub33e\u4203\u7701\u0ef7\u1bdc\u1789\u1384\u3dba\u3615", "\ud86d\udfc4\ud985\udd13\ud87a\udf6a\udad6\udcc1\ud9e2\udcc0\ud84f\udcff\udb30\udda9\ud9ea\udcdb\udaab\udfd2\udaaa\udd16\ud8f4\udffd\udb84\udfe8\udab1\uddcb\udb73\udff5\ud8c3\ude00\udbbd\udc12\udbdf\udeea\u84a0\ud852\udd45\udaa7\udd56\ud8ea\udf05\udb95\udfcf\ud8fc\ude72\ud83c\udcf9\uda78\udf6a\udb1f\uddd3\udb21\ude6a\uda6a\udc7f\uda22\udf6f\udba6\udde4\ud95e\udc72\udbcc\udfb7\uda74\ude42\ud836\udc26\u5ae9\uda56\udea9\ud9a2\ude72\uda43\udcf7\ud96c\udc97\uda43\ude7f\ud931\udd6b\udb57\udd66\udb34\uddb1",
        37, 55690, 305547447, 277680948407685560L, 33539L, false, false, (char) 59095, (char) 33990,
        Double.longBitsToDouble(0x3fa9067d303ccb60L), Double.longBitsToDouble(0x3fe2d80b52a208a8L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\000\000\uda5f\udfcf\uda42\udc89\000\ud989\udd44\udbb5\udc39\udb32\udfd6\udbf3\udd20\uda67\udf79\ud8cd\uded8\ud940\uddb1\uda3f\udd26\ud9ec\udf50\udb21\udea4\u38a9\udaea\udf4b\ud84b\ude53\000\uda33\udeb8\ud810\udebf\udac5\udfac\ud93d\ude91\ud8d9\ude6d\ud81d\udc7f\u29cf\udb8b\udd85\udab3\udcc7", "\u1cb0\uc211\ubfbd\u22a4\u9f2e\u186f\u24f2\000\uad22\ucd79\u00ea\u0f0a\u704c\u41a3\000\000", "\udb1b\ude0e",
        41, 67797, 25036, -134821120L, -50163L, false, false, (char) 0, (char) 11520,
        Double.longBitsToDouble(0x3fc5126780000000L), Double.longBitsToDouble(0x3fe2080002f20d59L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 6, 15, 8, "<\ud8ab\udef4\ud8ed\udcdb\udbf6\udf24\u58e0\ud9c3\udd03\uda15\udfc2\ud8ed\ude88\udac4\udcb0", "\u4934\u7bd3\ud757\ud510\u0532\u4b25\u38d8\ub8d7\u919d\u081c\u3e3d\u79c6\ub33e\u4203\u7701\u0ef7\u1bdc\u1789\u1384\u3dba\u3615", "\ud86d\udfc4\ud985\udd13\ud87a\udf6a\udad6\udcc1\ud9e2\udcc0\ud84f\udcff\udb30\udda9\udbe4\ude48\udb3f\udc79\udaed\udf99\ud8f4\udffd\udb84\udfe8\udab1\uddcb\udb73\udff5\ud8c3\ude00\udbbd\udc12\udbdf\udeea\u84a0\ud852\udd45\udaa7\udd56\ud8ea\udf05\ud9e5\udfd7\ud8fc\ude72\ud83c\udcf9\uda78\udf6a\udb1f\uddd3\udb21\ude6a\uda6a\udc7f\uda22\udf6f\udba6\udde4\ud95e\udc72\udbcc\udfb7\uda74\ude42\ud836\udc26\u5ae9\uda56\udea9\ud9a2\ude72\uda43\udcf7\ud96c\udc97\uda43\ude7f\ud931\udd6b\udb57\udd66\udb34\uddb1",
        8, 10006, 316195085, 277680948407685560L, 33539L, false, false, (char) 59095, (char) 33990,
        Double.longBitsToDouble(0x3fa9067d303ccb60L), Double.longBitsToDouble(0x3fe2d80b52a208a8L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 6, 5, "\000\000\000", "", "\u9bd1\udbf3\udd20\uda67\ude7b\ud8cd\uded8\ud940\uddb1",
        9, 48115, 1210777700, -2684203808811336753L, -100000L, false, false, (char) 58035, (char) 34484,
        Double.longBitsToDouble(0x3fc132a209b55594L), Double.longBitsToDouble(0x3f47848000000000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\000\000\uda5f\udfcf\uda42\udc895\ud989\udd44\udbb5\udc39\udb32\udfd6\udbf3\udd20\uda67\udf79\ud8cd\uded8\ud940\uddb1\uda3f\udd26\ud9ec\udf50\udb21\udea4\u38a9\udaea\udf4b\ud84b\ude53\000\uda33\udeb8\ud810\udebf\udac5\udfac\ud93d\ude91\ud8d9\ude6d\ud81d\udc7f\ud961\uddfa\udbbf\udd7a\udab3\udcc7", "\u1cb0\uc211\ubfbd\u779b\ua00c\u186f\u24f2\000\uad22\ucd79\u00ea\u0f0a\u704c\u41a3\000\000", "\udb1b\ude0e",
        41, 67797, 25036, -134821120L, -50149L, false, false, (char) 45952, (char) 55315,
        Double.longBitsToDouble(0x3fc5126780000000L), Double.longBitsToDouble(0x3fb44574471873e8L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 5, 5, "\uda6f\udec4\udbff\udff0\udae1\udf34\udbf6\udf24\u58e0\ud9c3\udd03\udbcc\ude39\udb4c\udc33\udbf3\udc0e", "\u29ce\u7fa6\u491f\u9ded", "\udabf\udc55\ud822\ude5a\uda33\udeb8\ud9b9\udd99\uda92\udf1b\ud8f9\udc21",
        16, 13339, 1845301667, 8564144458641374719L, 95660L, true, false, (char) 6972, (char) 57127,
        Double.longBitsToDouble(0x3fef8bd3e424f395L), Double.longBitsToDouble(0x3fe86ccc1799c05fL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 6, 6, "\\", "\u59ab", "\udbd6\udeb7\udb4c\udc33\udbf3\udc0e\uda67\udf79\uda53\udd1b\udbae\udc92\uda3f\udd57\uda2c\udced\ud9db\udf7d\u7669\u8ce6\uafac\ud985\udcb9\uda33\udeb8\ud9b9\udd99\ud880\ude68\udaca\ude1d\ud921\ude8b\ud897\udf2a\ud93e\udc1e\ud8b2\udc8c\udbf0\udcb7\uce3a\u6cc2",
        47, 81606, 2054976351, -5580333835261833981L, -85031L, true, true, (char) 55557, (char) 19003,
        Double.longBitsToDouble(0x3fecc5e982d24c22L), Double.longBitsToDouble(0x3fecf36384eb8c27L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 6, 15, 14, "'", "\u59ab\uc8a2\u68ca\u7bcd\u7802\ubc71\ua6ff", "\ud869\udd8a\ud9e4\ude13\ud9aa\udfa1\ud84f\udcd8\uda5c\udfa8\ud89b\udfe6\u0088\000",
        19, 33648, 1856828312, 144115649595334507L, 93283L, true, true, (char) 29227, (char) 55211,
        Double.longBitsToDouble(0x3fcc69493e9b6e54L), Double.longBitsToDouble(0x3fb7dafe80000000L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\udb0d\udd45\ud867\ude02\uda5f\udfcf\025\000\ud9c3\udc44\udbcc\ude39\uda93\udfa7\udbf3\ude12\uda67\udf79\ud8cd\uded8\ud967\udc45\uda3f\udd57\ud9ec\udf50\udb21\udea4\u38a9\udaea\udf4b\ud84b\ude53\ud822\ude5a\uda33\udeb8\ud810\udebf\udac5\udfac\ud93d\ude91\ud8d9\ude6d\ud81d\udc7f\u5154\udbaf\udd36\udab3\udcc7", "\ud0e3\000\u2964\u009f\u9f1d\u186f\u24f2\u4a6b\uad22\ucd79\uac28\ub2c2\u704c\u9df5\u82df\u7a75", "\ud9c8\udd84\ud893\ude27\ud979\udf05\ud8a0\udd0e\udad7\udd2d\udb00\udf43\uda18\ude14\u7784\udb9c\udf61\ud843\udc2f",
        29, 64552, -647544332, 961850850251324146L, 24087L, true, true, (char) 10195, (char) 9415,
        Double.longBitsToDouble(0x3fa1096768c00000L), Double.longBitsToDouble(0x3fee3c0a16944f20L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 0, "\011\ud8c0\udc5d\uda96\ude0e\udbeb\udcfd\u58e0\udaf0\udc47\ud800\udebd\udbdb\udff9\udaa9\udd08\ud9d9\udd54\ud937\uded4", "\ud53a\u6960\u4616", "\udb81\udc6a\ud88c\uddf0\ud9b9\udd78\ud933\udf9d\u5776\udbe3\udf86\uda9b\ude4b\udb0a\udec9\ud944\udf55\ud869\ude4e\ud83f\udeaa",
        59, 58155, 1795571541, -6480319735217258496L, 62345L, true, true, (char) 110, (char) 2991,
        Double.longBitsToDouble(0x3febc2cc28defe08L), Double.longBitsToDouble(0x3faafbd08fc1bb60L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\udb57\udd2b\ud867\ude02\udaa0\udfef\udb19\udc7c\ud9db\udd89\ud989\udd72\udbb5\udc39\udb32\udfd6\udbf3\udd20\uda67\udf79\ud8cd\uded8\ud940\uddb1\uda3f\udd26\ud9ec\udf50\uda24\udda5\udbf6\udd54\udaea\udf4b\ud8d9\udcf6'\uda33\udeb8\ud810\udebf\udac5\udfac\ud93d\ude91\ud8d9\ude6d\ud81d\udc7f\u29cf\udb8b\udd85\udab3\udcc7", "\u1cb0\uc211\ubfbd\u22a4\u9f2e\u186f\u24f2\u099b\uad22\ucd79\u00ea\u0f0a\u704c\u9df5\u7a93\000", "\u5c63",
        41, 67797, 25036, -134821120L, -50163L, false, false, (char) 0, (char) 11520,
        Double.longBitsToDouble(0x3fec687ee8000041L), Double.longBitsToDouble(0x3fe2080002f20d59L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\000\000\uda3d\udcfe\uda42\udc895\000\000\u9bd1\ud936\ude1b\uda67\udf79\ud8cd\uded8\u00a3\000\ud9ec\udf50\udb21\udea4\ucadb\000\ua7a3\000\000\000\udac5\udeb2\ud93d\ude91\ud8d9\ude6d\ud81d\udc7f\ud961\uddfa\udbbf\udd7a\uf5cc", "", "\ud8da\udc73\ud8d4\udc3d\u38ef\uda50\ude47",
        18, -1000, -679752448, -6310126626562637590L, 29889L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e47a24814000000L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\000\000\uda5f\udfcf\uda42\udc895\ud989\udd44\udbb5\udc39\udb32\udfd6\udbf3\udd20\uda67\udf79\ud8cd\uded8\ud940\uddb1\uda3f\udd26\ud9ec\udf50\udb21\udea4\u38a9\udaea\udf4b\ud921\udca7:\uda33\udeb8\ud810\udebf\udac5\udfac\ud93d\ude91\ud8d9\ude6d\ud81d\udc7f\ud961\uddfa\udbbf\udd7a\udab3\udcc7", "\u1cb0\uc211\ubfbd\u779b\ua00c\u186f\u24f2\000\uad22\ucd79\u00ea\u0f0a\u704c\u41a3\000\000", "\udb1b\ude0e",
        41, 67797, 25036, -134821120L, -50149L, false, false, (char) 45952, (char) 55315,
        Double.longBitsToDouble(0x3fc5126780000000L), Double.longBitsToDouble(0x3fb44574471873e8L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 6, 6, "\\\ud8db\udcf0\ud8e2\udf4e", "\u4c96\u591e\u7802\u33da\u8f5e\u9559\u9f54\u7b55\u491f\u9ded\u10f7\u613c\u24d2\u2dbe\u9191\u0798", "\ud921\ude8b",
        -3, 30667, 512906943, -6452816045974631495L, 19011L, false, true, (char) 57127, (char) 9837,
        Double.longBitsToDouble(0x3fd03b28e836aa40L), Double.longBitsToDouble(0x3fd879d9da3626c6L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\000\000\u0e21\ud8e0\udd285\udb1f\udee0<\u9bd1\ud936\ude1b\uda67\udf79\ud8cd\uded8\u00a3\000\ud9ec\udf50\udb21\udea4\ucadb\000\ua7a3\000\000\000\udac5\udeb2\ud93d\ude91\ud8d9\ude6d\ud81d\udc7f\ud961\uddfa\udbbf\udd7a\uf5cc", "\u1916", "\ud8d4\udc3d",
        10, 77008, 1758666933, 3558969604849782016L, 29889L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e1ba00000000000L), Double.longBitsToDouble(0x3e47a24814000000L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 6, "\\\ud8db\udcf0\ud8e2\udf4e", "\u4c96\u591e\u7802\u33da\u8f5e\u9559\u1566\u9a91\u260b\u9ded\u10f7\u613c\u24d2\u2dbe\u9191\u0798", "\ud921\ude8b",
        -3, 30667, -1919658305, 7016156399063744597L, 19011L, false, true, (char) 57127, (char) 9837,
        Double.longBitsToDouble(0x3fd03b28e836aa40L), Double.longBitsToDouble(0x3fd879d9da3626c6L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 6, 15, 14, "\"", "\u59b3\u9da2\u68ca\u7bcd\u7802\ubc71\ua6ff", "\uda3f\uddd5\ud867\ude62\ud9aa\udfab\u7669\udb85\udf42\uda97\udfd9\udad2\udf10\ud877\udd8c",
        19, 33648, 1856828312, 144115649595334507L, 93283L, true, true, (char) 29227, (char) 55211,
        Double.longBitsToDouble(0x3fcc69493e9b6e54L), Double.longBitsToDouble(0x3fb7dafe80000000L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 6, 15, 12, "<\u0370\ud905\udd0f\udbf6\udf24\u58e0\ud9c3\udd03\uda15\udfc2\ud8ed\ude88\udac4\udcb0\uda01\ude94\ud971\udfca\udaf6\udc8e\uda3f\uddd5\udbb7\ude73\udb3f\udfd6\ud964\ude0c\ud814\udda8\udb87\ude7b\udbbf\udde0\ud845\udc4d\ud9b9\ude1d\ud880\ude68\u3fe1\ud87e\udcfe\ud94a\udd23\ud9f6\udeec\ud8f4\udf43\udbf0\udcb7\udac2\udd20\ud9d0\udf00\uda69\ude87\u2951\udac7\ude56\ud854\udcc9\ud86d\udfc4\ud985\udd13\ud87a\udf6a\udad6\udcc1\ud9e2\udcc0\udae7\udd01\ud96d\ude4b\ud986\udd87\uda06\udc81\udaed\udf99\ud8f4\udffd\udb84\udfe8\udab1\uddcb\udb73\udff5\ud8c3\ude00\udbbd\udc12\udbdf\udeea\u84a0\ud852\udd45\udaa7\udd56\ud8ea\udf05\ud9e5\udfd7\ud8fc\ude72\ud83c\udcf9\uda78\udf6a\udb1f\uddd3\udb02\udfa2\ud920\udf80\uda22\udf6f\udba6\udde4\ud95e\udc72\udbcc\udfb7\uda74\ude42\ud836\udc26", "\u1c75\u3008\u73e9\u95c6", "\udb34\uddb1\udac9\udfbf\udb75\ude0c\ud92a\ude29\ud857\udd94\udb64\udcef\u58b9\udb55\udcab\uda43\uddf4\udaf6\udfb8\udb47\ude42\ud8db\udd73\ud94c\udf18\uda84\udedd\udbf5\udf38\ud9c5\udfaf\uda5c\udfc5\udbde\udf7b\udbda\udc09\ud82c\udf8a\ud997\udca2\ud59e\udb0a\udc17\ud8da\udf47\ud894\uddff\udbeb\udcdb",
        18, 67956, -626626556, -7194956879110423290L, 85596L, false, true, (char) 20420, (char) 24611,
        Double.longBitsToDouble(0x3f91260b60989180L), Double.longBitsToDouble(0x3fc000c6c40c9c3cL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\ud8e9\udcf3\014\000", "", "\u628d\udbf3\udd20\uda67\ude7b\ud8cd\uded8\ud940\uddb1",
        20, 1995, 1210777700, -2684203808811336753L, -100000L, false, false, (char) 58035, (char) 34484,
        Double.longBitsToDouble(0x3fc132a209b55594L), Double.longBitsToDouble(0x3f47848000000000L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 6, 15, 12, "\015", "\u035a\u4884\u68ca\ub4c4\u625f\ubc71\ua6ff\u3653\u4934\u7bd3\u7264\ub21a\u10f7\ud214\u3509\u6589\u40ca\u0798\u3e3d\u56c4\ub2c9", "\udac1\udcaa\udbbc\udd58",
        25, 91390, -610938653, 7780601288448991436L, 623L, false, true, (char) 224, (char) 2557,
        Double.longBitsToDouble(0x3fe1f95d610f8e46L), Double.longBitsToDouble(0x3fd20f0c27bccffaL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 5, "\ud8e9\udcf3\014\000", "", "\u628d\udbf3\udd20\uce82\ud8cd\uded8\ud940\uddb1",
        20, 1995, 1210777700, -2684203808811336753L, -100000L, false, false, (char) 58035, (char) 34484,
        Double.longBitsToDouble(0x3fc132a209b55594L), Double.longBitsToDouble(0x3f478486ff160c00L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 5, 5, "\ud8b9\udc09", "\u4e1e\ua82d\uc30d\u30b6\u7802\u33da\u8e9d\u659b\u9603\u59a6\u0d9a\u23b9", "\udaeb\udf58\udb12\ude72\uda33\udeb8",
        8, 3378, 1856828312, -8812876526632261453L, 28003L, true, true, (char) 29227, (char) 55211,
        Double.longBitsToDouble(0x3fe23a524f07fdc1L), Double.longBitsToDouble(0x3fd4a9d2a1649f68L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 6, 15, 14, "\010\ud8ab\udef4\udbed\udddb\udbf6\udf24\uda8f\ude77", "\u8b7e\u7601\ua6ff\u3653\u4934", "\ud9d7\udec2",
        30, 89934, 1594991757, 584115552256L, -99893L, true, true, (char) 11871, (char) 55009,
        Double.longBitsToDouble(0x3fe67fbf2a4e5fd2L), Double.longBitsToDouble(0x3feda477b0e34a49L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 6, 6, ">\ud8db\udcf0\udac9\ude7b", "\u4c96\u591e\u7802\u33da\u8f5e\u9559\u9f54\u7b55\u8e3c\ucadf\u21e0\u613c\u24d2\u2dbe", "\ud880\ude68\udaca\ude1d\ud921\ude8b",
        -3, 30667, 512906943, -6452816045974631495L, 19011L, false, true, (char) 57127, (char) 9837,
        Double.longBitsToDouble(0x3fd03b28e836aa40L), Double.longBitsToDouble(0x3fd87a95da3626c6L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 6, ">\udba8\ude90\udac9\uddb3", "\u4c96\u591e\u7802\u33da\u8f5e\u8678\u0860\u7b55\u6019\u64a5\u3e8b\u6191\u24d2\u2dbe", "\ud880\ude68\udb4b\ude9f\ud921\ude8b",
        -3, 30667, 512906943, 5714221297320140699L, 19011L, false, true, (char) 57127, (char) 9837,
        Double.longBitsToDouble(0x3fd03b28e836aa40L), Double.longBitsToDouble(0x3fd87a9a1a3626c6L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 6, 13, 8, "\013", "\u8e1d\u0c40\u68ca\u55f1\u0f1d\u7abc\u3d1f", "\uda3f\uddd5\udbb7\ude73\ud8f0\udcb3\ud8f7\uddd0\udb85\udf42\uda97\udfd9\u0088\ud845\udc4d\udb94\udf8f\udb7b\udf69",
        19, 21656, 489709419, -250658823273973854L, -86617L, false, true, (char) 6956, (char) 6972,
        Double.longBitsToDouble(0x3fdab6bfa81e4132L), Double.longBitsToDouble(0x3fe01b0bb32089e4L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 6, 11, 12, "=", "\u47a0\u720c\u686b", "\udb6a\udf4a\uda8b\udecd",
        1, 49466, 331245081, 4862975451347543393L, 45062L, false, false, (char) 59217, (char) 41088,
        Double.longBitsToDouble(0x3fead80674814953L), Double.longBitsToDouble(0x3fecc123606b6eacL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\udb6d\ude9b\ud9c1\udc55&", "\u36d2", "\udbf3\udd20\uda67\ude7b\ud8cd\uded8\udb43\udc53\ud93d\udf1d\ud805\udea8\udbb3\udfbd\ud995\ude1a\ud9f8\ude73\udb26\udf0e\000\000\udad2\udee7\udb81\udecf\ud80a\udf9f\uda00\uddc7\u9395\uda3b\ude3c\ud909\udf8a\udad7\udcab\ud800\ude3e\ud931\udc23\ud820\udfe0\ud9ec\ude63\ud842\ude20\udb35\ude7f\udbf5\udd23\ud862\uddf4\ud925\udf18\ud8dc\udff6\ud861\udfd7\ud8ef\udd62\ud83a\ude1d\ud990\ude21\ud90d\udd21\ud936\udf92\uda2a\udc8b",
        38, 19661, 1045644044, -6133517174880249627L, 30097L, false, true, (char) 61656, (char) 3102,
        Double.longBitsToDouble(0x3fec7ba5c977506eL), Double.longBitsToDouble(0x3feefd5df841d931L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 8, "\010\ud8ab\udef4\udbed\udddb\udbf6\udf24\uda8f\ude77", "\u6952\u4699\ua6ff\u3653\u4934\ud1e3\ucbcb\ucc19\u54c2\u2020\u1d3a\u0088\000\u0798\u3e3d\u56c4", "\ud970\udf6b\udafa\udcaf\ud8a6\udf76\udaa4\udfa4\udac4\udc14\ud84a\udd8e\udb67\udc02",
        46, 10530, 834322532, 2756207259036708391L, 21229L, true, false, (char) 6525, (char) 28116,
        Double.longBitsToDouble(0x3fcfa17c14caff18L), Double.longBitsToDouble(0x3fa1fe98e2d51d50L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 6, 13, 8, "\012", "\u8e1d", "\udb8e\udc4d\ud996\udd88\ud98a\udf6a\ud9a9\udc89\udb0f\udceb\ud89b\udff3\ud909\udd63\udb40\udf3d\ud8f0\udcb3\udba9\udf0a\ud9e7\udcb0\ud8b0\udeae\udbf6\udc84\ud9b7\ude87\u1dd5\udb4d\udf68\udadb\udd4c\ud9a0\udc8c\ud92c\uddc2\ud9ea\udcb3\ud9e7\udd36\udbf0\udcb7\udac2\udd20\udac4\udc14\uda69\udebd\u2e03\udb1a\udf96\ud978\uddcd\ud86d\udf0d",
        0, 61830, -263197512, -6249721546384709676L, -81619L, true, true, (char) 44392, (char) 51512,
        Double.longBitsToDouble(0x3fdc51b308864ab6L), Double.longBitsToDouble(0x3fd889dfe8af447cL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 5, "\udb6d\ude9b\ud9c1\udc55&", "\u36d2", "\udbf3\udd20\uda67\ude7b\ud8cd\uded8\udb43\udc53\ud93d\udf1d\ud805\udea8\udbb3\udfbd\ud995\ude1a\ud9f8\ude73\udb26\udf0e\000\000\udad2\udee7\udb81\udecf\ud80a\udf9f\uda00\uddc7\u9395\uda3b\ude3c\ud909\udf8a\udad7\udcab\ud800\ude3e\ud931\udc23\ud820\udfe0\ud9ec\ude63\ud97c\udd9d\udb2c\ude2f\udbf5\udd23\ud862\uddf4\ud925\udf18\ud8dc\udff6\ud861\udfd7\ud8ef\udd62\ud83a\ude1d\ud990\ude21\ud90d\udd21\ud936\udf92\uda2a\udc8b",
        38, 19661, 1045644044, -6133517174880249627L, 30097L, false, true, (char) 61656, (char) 3102,
        Double.longBitsToDouble(0x3fec7ba5c977506eL), Double.longBitsToDouble(0x3feefd5df841d931L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\udb6d\ude9b\uda2e\udf8d=", "\u36d2", "\udbf3\udd20\uda67\ude7b\ud8cd\uded8\udb43\udc53\ud93d\udf1d\ud805\udea8\udbb3\udfbd\ud995\ude1a\ud9f8\ude73\udb26\udf0e\udbff\udf7e\000\udad2\udee7\udb81\udecf\ud842\udc9b\ud9d0\ude17\ud97b\udf6e\uda3b\udeca\udbec\udf3c\udad7\udcab\ud800\ude3e\ud931\udc23\ud820\udfe0\ud9ec\ude63\ud842\ude20\udb35\udf37\udbf5\udd23\udb32\udc5c\udad1\udc8d\ud97c\udc05\ud95d\udd0c\ud83b\uddc4\ud9ec\ude37\ud990\ude17\ud90d\udd21\ud936\udf92\uda2a\udc8b",
        38, 53589, -745361227, -6133517759643690779L, 30097L, false, true, (char) 61656, (char) 3102,
        Double.longBitsToDouble(0x3fec7ba5c977506eL), Double.longBitsToDouble(0x3feefd5df841d931L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 6, 8, "\012", "\u02ee", "\udb8e\udc91\ud996\udd88\udb5d\udd94\ud998\ude5c\udb0f\udceb\ud89b\udff3\ud909\udd63\udb40\udf3d\ud8f0\udcb3\udba9\udf0a\ud9e7\udcb0\ud956\udd00\udbcb\uddb4\ud8b7\udcd0\u1dd5\ud923\uddb3\udadb\uddbc\ud9e7\udd30\ud92c\uddc2\udacc\udf65\udb01\udf33\udbe0\udf1a\udac2\udd20\ud914\udc9e\uda69\udebd\u2e03\ud8df\ude39\udbcf\udf56",
        57, 52360, -635429170, -1130555627076840725L, -63945L, true, false, (char) 6830, (char) 4505,
        Double.longBitsToDouble(0x3fd19dc54f9af41eL), Double.longBitsToDouble(0x3fd6d97448b8a218L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\ud9e3\udc51\ud979\udcc9\udb80\udc54\ud800\ude32\u00c7\ud989\udd44\ud83c\udefd\udb44\udc91\udbf3\udd20\uda67\udf79\ud814\udf24\uda5b\udfe0\ud9e5\udea8\u83ab\udb22\udffb\u38a9\udaea\udf4b\ud84b\ude53\ud821\udd90\udb30\udd91\udae9\ude23\udace\udff0\ud93d\ude90\ud8d9\ude6d\ud8e9\udec5\ud85c\udc04\udb84\ude01\ud87d\udc28\ud9bd\udfe1\udac4\udc14\ud997\udd33\udac2\udf92\ud8da\udc73\ud9fe\udf92\ud8ac\udcfc\uda86\udcf6\ud9a5\udee2\ud9a3\uddb1\udadf\ude5d\ud903\uddb8\u05ea\ud9ac\udd96\udb2c\udd93\ud888\udc9d\uda32\udddc>\000\ud810\ude71\udb1b\ude0e\udb0c\udf44\ud972\udd31\u61cc\000\udb00\ude86\ud8d5\udf20\uda06\udc97\ud8ff\udf91\ud975\udcf3", "\u55fc\ua9a3\ucfac\u6ca3", "\uda8c\uded6\uda75\udc63\ud834\udd29\udbb4\udec1\uda65\ude5f\udba0\udde6\udaf5\udf48\ud8b8\udd61\ud95a\udee8\udb1d\udc43\udb98\udf75",
        41, 1231, -936445463, 4523617276033032554L, 4833L, true, false, (char) 13646, (char) 28144,
        Double.longBitsToDouble(0x3fd6e5846ed7d804L), Double.longBitsToDouble(0x3fd29c8ec6fd50c6L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 6, 5, "\ud9e3\udc51\ud979\udcc9\udb80\udc54\ud91a\ude5f\u00c7\ud989\udd44\ud83c\udefd\udb44\udc91\udbf3\udd20\uda67\udf79\ud814\udf24\uda5b\udfe0\ud9e5\udea8\u83ab\udb22\udffb\u38a9\udaea\udf31\udadd\udebc\udbb2\uded9\udb30\udd36\udae9\ude23\udace\udff0\ud93d\ude90\udb45\udc42\udb61\udd24\ud85c\udc04\udb84\ude70\ud985\udfb4\ud89c\udcd6\uda2a\udee6\ud997\udc66\udac2\udf03\ud8da\udc73\udace\udcfa\udaf9\udce9\ud894\uddf6\ud9a5\udebb\ud9a3\uddb1\udadf\ude5d\ud8da\udfb8\ud83c\uded1\ud9ac\uddf5\udb2c\udd93\ud91a\udc06\uda32\uddd3>\udbce\udd3d\udbd6\udf0d\udb1b\ude0e\udb0c\udf44\ud972\udd31\u61cc\000\udb00\ude86\ud8d5\udf20\uda06\udc97\ud8ff\udf91\ud975\udcf3", "\u55fc\ua9a3\ucfac\u6ca3", "\uda8c\uded6\uda75\udc63\ud834\udd29\udbb4\udec1\uda4e\udef4\u5624\ud8f3\udee4\ud8a0\ude16\ud95a\udee8\uda7e\ude40\ud91c\ude25",
        41, 1231, -1289422359, 4170813884833522104L, 4833L, true, false, (char) 13646, (char) 28144,
        Double.longBitsToDouble(0x3fd6e5846e4835d2L), Double.longBitsToDouble(0x3fd29c8ecef70dfcL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\ud892\udc97\uda19\ude5a\000\ud97e\ude7e\ud99a\udf69\ud915\udf35\uda4c\udfe2\udb23\udf5a\ud8cb\udc2e\uda67\ude7b\ud8cd\uded8\ud93c\udcb1\udb84\udca9\uda16\udd33\udb0c\udc11\u38a9\udaea\udf4b\ud9b9\ude8b\013\000\ud810\udebf\udb4d\udfb0\ud913\udd91\ud8d9\ude6d\000\ud8eb\udea5\ud8a4\udff5\ud9ff\uddd7", "\u2ce2", "\ud8cb\udc50\ud8e3\ude74\ud8a8\udf22\udbb4\udde3\udae9\udd41\ud9d1\ude62",
        40, 62363, -1170624409, -728722978352850608L, -80920L, true, true, (char) 9849, (char) 19280,
        Double.longBitsToDouble(0x3fb3693a7183eba8L), Double.longBitsToDouble(0x3fe4e9f0c67cd4eeL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\udb6d\ude99\udb1b\udd43\015\ud923\udd70", "\ud11b", "\uda67\ude7b",
        -2, 77931, 66000610, 3348465817022446555L, 83714L, true, true, (char) 21513, (char) 4823,
        Double.longBitsToDouble(0x3fe6d805bbf5503bL), Double.longBitsToDouble(0x3fdc537decebb718L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 13, "\ud99e\ude66\ud8db\udcf0\ud8e2\udf4e\ud908\udf2d\u58e0\"", "\u6518\u8f5e\uad81\ud6f4\u7be2\u491f\u9ded", "\uafac\ud9c3\udf22\ud8df\udf51\udac0\udc7c\udbbe\uddb5\udb9c\uddc3",
        47, 54331, 1411268277, 7339100686409196667L, 63739L, true, false, (char) 6972, (char) 57127,
        Double.longBitsToDouble(0x3fc1dccf940ecba8L), Double.longBitsToDouble(0x3fe3caa902e1b9ecL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 10, "\udb0d\udd45\ud867\ude02\uda5f\udfcf\025\003\ud9c3\udc44\udbcc\ude39\uda93\udfa7\udbf3\ude12\uda67\udf79\ud8cd\uded8\ud967\udc45\uda3f\udd57\ud9ec\udf50\ud89f\udd64\uda63\ude5e\udaea\udf4b\ud8ab\udd03\uda85\ude11\uda33\udeb8\ud810\udebf\udac5\udfac\ud93d\ude91\ud8d9\ude6d\u8702\u7749\udbaf\udd36\udab3\udcc7", "\ud0e3\000\u2964\u009f\u9f1d\u186f\u24f2\u4a6b\uad22\ucd79\uac28\ub2c2\u704c\u9df5\u82df\u7a75", "\ud9c8\udd84\ud893\ude27\ud979\udf05\ud8a0\udd0e\udb93\udd4b\udb00\udf43\uda18\ude14\u7784\udb9c\udf61\ud843\udc2f",
        14, 64552, -647544332, 961850850251324146L, 24087L, true, true, (char) 10195, (char) 9415,
        Double.longBitsToDouble(0x3fa1096768c00000L), Double.longBitsToDouble(0x3fee3c0a16944f20L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\udb9b\udf48\ud979\udcc9\udb80\udc54\ud800\ude32\u00c7\ud989\udd44\ud83c\udefd\udb44\udc91\udbf3\udd20\uda67\udf79\ud814\udf24\uda5b\udfe0\udb3e\udc7d\u83ab\udb22\udffb\u38a9\udaea\udf4b\ud84b\ude53\ud821\udd90\udb30\udd91\udae9\ude23\udace\udff0\udabb\udf50\ud9d1\udebd\udbbf\uddb1\ud85c\udc04\udb84\ude01\ud87d\udc28\ud9bd\udfe1\udac4\udc14\ud997\udd33\udac2\udf92\ud8da\udc73\ud9fe\udf92\ud8ac\udcfc\uda86\udcf6\ud9a5\udee2\ud9a3\uddb1\udadf\ude5d\ud903\uddb8\u05ea\ud9ac\udd96\udb2c\udd93\ud888\udc9d\uda32\udddc>\000\ud810\ude71\udb1b\ude0e\udb0c\udf44\udb6c\uddad\u3f94>\udb00\ude86\ud8d5\udf20\uda06\udc97\ud8ff\udf91\ud975\udcf3", "\ub6d4\ucbb8\ucfe1\u6ca3", "\uda8c\uded6\uda75\udc63\ud834\udd29\udbb4\udec1\uda3b\ude6a\udba0\udde6\udaf5\udf48\ud8b3\udf3e\ud84c\udee1\udb1d\udc43\udb98\udf75",
        41, 1231, -936445463, 4523617276553126250L, 4833L, false, false, (char) 13646, (char) 28144,
        Double.longBitsToDouble(0x3fd6e5846ed7d804L), Double.longBitsToDouble(0x3fd29c8486fd50c6L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\ud9e3\udc51\ud979\udcc9\udb80\udc54\ud800\ude32\u00c7\ud989\udd44\ud83c\udefd\udb44\udc91\udbf3\udd20\uda67\udf79\ud814\udf24\uda5b\udfe0\ud9e5\udea8\u83ab\udb22\udffb\u38a9\udb58\udfa3\ud84b\ude53\ud821\udd90\udb30\udd91\udae9\ude23\udb2a\udd9c\ud9f2\ude48\ud8d9\udec4\ud8dd\uddc5\udaf5\udcaf\ud8aa\ude85\uda1e\udf70\ud9bd\udfe1\udac4\udc14\ud997\udd33\udac2\udf92\ud8da\udc73\ud9fe\udf92\ud8ac\udcfc\uda86\udcf6\ud9a5\udee2\ud9a3\uddb1\udadf\ude5d\ud903\uddb8\u05ea\ud9ac\udd96\udb2c\udd93\ud888\udc9d\uda32\udddc>\000\ud810\ude71\udb1b\ude0e\udb0c\udf44\ud972\udd31\u61cc\000\udb00\ude86\ud8d5\udf20\uda06\udc97\ud8ff\udf91\ud975\udcf3\ud9df\udee3\u49c2\uda01\udf80\ud849\ude2a\ud885\udcfa\uda5a\udc94\udbb2\udcbb\udab4\udebc\uda8c\uded6\uda75\udc63\ud834\udd29\udbb4\udec1\uda65\ude5f\udba0\udde6\udaf5\udf48\ud8b8\udd61", "\uc7f6\u4048", "\ud830\udda5\u99c1\uda73\udce2\udb84\udc30\udac6\uddd1\ud994\udfbc\uda06\udcc6\udad0\ude86\udb0c\uddfb\ud98e\udc40\ud809\udc2c\ud8b6\udfff\udaa5\udc61\udb24\udf89\uda4d\udc23\udaed\ude86\ud8ea\udfbb\udbfd\ude18\udb65\udc6c\ud935\udf60\ud9cf\ude17",
        20, 75519, 676831737, -4449310549548639152L, 7985L, true, true, (char) 56966, (char) 47324,
        Double.longBitsToDouble(0x3fd8784d81d63878L), Double.longBitsToDouble(0x3fd671922a7771f0L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\000\000\000\ud853\udf695\udb41\uded1<\u9bd1\ud936\ude1b\uda67\udf79\000\000\000\u7e2b\000\000\000\ua700\000\000\000\udac5\udeb2\u0089\000\000\u29cf\000\000", "\000", "\ud8ea\udfa8",
        10, 54800, 1758666752, 3558969604849782016L, -100000L, false, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|tryMinimizeIf|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|addParameterAfter|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|areMatchingExits|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|areSafeFlagsToFold|java.lang.String|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|areValidRegexpFlags|java.lang.String|static",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|consumesDanglingElse|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|containsUnicodeEscape|java.lang.String|static",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|getBlockExpression|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|getBlockReturnExpression|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|getBlockVar|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|getExceptionHandler|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isExceptionPossible|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isFoldableExpressBlock|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isHigherPrecedence|com.google.javascript.rhino.Node,int|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isLowerPrecedence|com.google.javascript.rhino.Node,int|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isLowerPrecedenceInExpression|com.google.javascript.rhino.Node,int|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|tryMinimizeIf|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
