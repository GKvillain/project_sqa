package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class CommandLineRunner_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.String;:[[\u25a0\ud445]] |this=com.google.javascript.jscomp.CommandLineRunner:@?\012",
        Z.run(T, 1, 4, 5, 8, "\ud845\udf0f\ud986\udffc\uda32\udfb6\ud939\ude94\ud89f\ude4c\uda8a\uded9\ud9e7\udc17\uadc5\ud864\udd9d\ud934\udf0d", "\u25a0\ud445", "\ud81d\udece\ud86b\udc06\udaf7\udd5f\udb58\uddea\uda10\udff8\udbd5\udeec\uda93\uddf0",
        39, 63755, -1082467716, 5117251170032153418L, -96925L, true, false, (char) 57445, (char) 21472,
        Double.longBitsToDouble(0x3fc61927a8808d14L), Double.longBitsToDouble(0x3fc4bb8b36c463b4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.String;:[[\u25a0\ud445]] |this=com.google.javascript.jscomp.CommandLineRunner:@?\012",
        Z.run(T, 1, 4, 5, 8, "\ud845\udf0f\ud986\udffc\uda32\udfb6\ud939\ude94\ud89f\ude4c\uda8a\uded9\ud9e7\udc17\uadc5\ud864\udd9d\ud934\udf0d", "\u25a0\ud445", "\ud81d\udece\ud86b\udc06\udaf7\udd5f\udb58\uddea\uda10\udff8\udbd5\udeec\uda22\udc97",
        39, 63755, -1082467716, 5117251170032153418L, -96925L, true, false, (char) 57445, (char) 21472,
        Double.longBitsToDouble(0x3fc61927a8808d14L), Double.longBitsToDouble(0x3fc4bb8b36c463b4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\u89b3\u6f41] |this=com.google.javascript.jscomp.CommandLineRunner:@?\012",
        Z.run(T, 1, 9, 5, 8, "\ud845\udf0f\ud986\udffc\uda32\udfb6\uda9f\ude1b\ud89f\ude4c\uda8a\uded9\ud9e7\udc17\uadc5\ud864\udd9d\ud934\udf0d", "\u89b3\u6f41", "\ud917\udecb\ud86b\udc06\ud8d1\ude28\ud84c\ude82\uda10\udff8\udb23\udf12\udbb1\udcde",
        3, 63755, -1082467716, 5117251170032153418L, -96925L, true, false, (char) 57445, (char) 21472,
        Double.longBitsToDouble(0x3fc61927a4808d14L), Double.longBitsToDouble(0x3fc4bb8b36c463b4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 0, 8, "\000", "\u264f", "\ud9e7\udc17\uadc5\ud864\udd9d\ud934\udf0d\udb14\udc26\ud9e1\udf96\ud843\udcfb\ud91d\udde2\udbf4\udf51\udad3\udceb\ud81d\udece\ud86b\udc06\udaf7\udd5f\udb58\uddea\uda10\udff8\udbd5\udeec\uda93\uddf0\udbcc\udca5\ud822\udd3d\uda5b\udeae",
        19, 52754, -1261996561, -3752447224740226712L, 51112L, false, false, (char) 34149, (char) 55550,
        Double.longBitsToDouble(0x3fdb118ed7c54fe8L), Double.longBitsToDouble(0x3fa617c56d73a100L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.CompilerOptions:@? |this=com.google.javascript.jscomp.CommandLineRunner:@?\012",
        Z.run(T, 1, 0, 10, 8, "\ud845\udf0f\ud986\udffc\uda32\udfb6\ud939\ude94\ud89f\ude4c\uda8a\uded9\ud9e7\udc17\uadc5\ud864\udd9d\ud934\udf0d", "\u25a0\ud445", "\ud81d\udece\ud86b\udc06\udaf7\udd5f\udb58\uddea\uda10\udff8\udbd5\udeec\uda93\uddf0",
        39, 63755, -1082467716, 5117251170032153418L, -96925L, true, false, (char) 57445, (char) 21472,
        Double.longBitsToDouble(0x3fc61927a8808d14L), Double.longBitsToDouble(0x3fc4bb8b36c463b4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\u25a0\ud445] |a0=[Ljava.lang.String;:[[\u25a0\ud445]] |this=com.google.javascript.jscomp.CommandLineRunner:@?\012",
        Z.run(T, 1, 6, 7, 8, "\ud845\udf0f\udb05\udcbc\uda32\udfb6\ud939\ude94\ud89f\ude4c\uda8a\uded9\uda21\uded4\uda2f\ude1f\ud864\udd9d\ud934\udf0d", "\u25a0\ud445", "\ud81d\udece\ud86b\udc06\udaf7\udd5f\udb58\uddea\uda10\udff8\udbd5\udeec\uda93\uddf0",
        -5, 71230, -1082467716, 5117251169507341130L, -96925L, true, false, (char) 57445, (char) 21472,
        Double.longBitsToDouble(0x3fc61927a8808d14L), Double.longBitsToDouble(0x3fc4bb8b36c463b4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.io.FileNotFoundException\012",
        Z.run(T, 1, 7, 1, 7, "\ud845\udf0f\ud986\udffc\uda19\udde8\udada\udd7f\ud8eb\udca4\uda41\udc75\ud96b\udd6e\uad3e\ud864\udd9d\ud9de\ude41\udb14\udc5a\ud9e1\udf96\uda17\uddb1\udbb1\udfde\udbb4\udf51\udad3\udceb\ud81d\udece\uda54\udd9b", "\u5b3f\u99f8", "\ud881\ude0c\ud96f\udd41\ud969\udd03\udaa3\ude1d\ud880\udd80\ud945\ude0f\udbc1\udf3c\ud841\udfa2\uda75\udcf7\ud8bb\udf3d\uda5a\udef8\ud83a\ude69\ud866\udc06\ud80a\udc1d\ud957\ude69\udba2\udea1\udae1\udcc8\ub29e\udb17\udf7d\udad2\udfd7\ud962\ude2c\udb5a\udf7d\udba7\udf61\ud995\udcbb\udad7\udc48\udafd\uddff\udaff\udfbd\ud907\udc31",
        18, 49865, 1909254000, 50706712265120221L, -38126L, true, false, (char) 24425, (char) 30427,
        Double.longBitsToDouble(0x3fda96482f57105cL), Double.longBitsToDouble(0x3f9e7853ce739da0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.CommandLineRunner:@?\0121=java.util.ArrayList:[\ud845\udf0f] |this=com.google.javascript.jscomp.CommandLineRunner:@?\012",
        Z.run(T, 2, 8, 9, 6, "\ud845\udf0f", "\u264f\u6faa\ucb06\u45d6\u2feb\u8e7c\u7636\u64db\u57f6\u25a0\ud445\u8505\u3eaa\u3c00\u0ff3\u7129\u2573\u9c4d", "\ud83f\udeca\uda22\udd3d\uda5b\udeae\ud969\udd03\udaa3\ude1d\ud880\udd80\ud8eb\udc21\ud878\ude2f\ud842\udc7f\uda75\udcf7\ud8ed\udf3d\udb77\ude7d\ud83a\udec4\ud866\udc06\ud831\ude1d\ud96e\udf95\ud8b4\udf97\ud878\udecc\ud81b\udfd7\ud8a7\ude53\ud8b9\uddfe\ud9c6\udfd1\ud8bc\udf8a\udb93\udd26\ud911\udfbb\uda4c\udcc0\ud963\ude79\ud8b3\udc60\ud805\uddb7\ud804\udd7e",
        19, 42367, 1323653280, -3535557760123848759L, 37531L, true, false, (char) 46538, (char) 39399,
        Double.longBitsToDouble(0x3fe59a719102af65L), Double.longBitsToDouble(0x3fdebd0a7b0f5f74L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 5, 8, "\ud845\udf0f\ud986\udffc\uda32\udfb6\ud939\ude94\ud89f\ude4c\uda8a\uded9\ud9e7\udc17\uadc5\ud864\udd9d\ud934\udf0d", "\u0a38\ucfe7", "\ud81d\udece\ud86b\udc06\udaf7\udd5f\udb58\uddea\uda10\udff8\udbd5\udeec\uda93\uddf0\ud83f\udeca\ud822\udd3d\uda5b\udeae\ud969\udd03\udaa3\ude1d\ud880\udd80\ud945\ude0f\udbc1\udf3c\ud841\udfa2\uda75\udcf7\ud8ed\udf3d\udb77\ude7d\ud83a\udec4\ud866\udc06\ud831\ude1d\udbce\uddc4\ud967\udc6c\ud90b\udfc5\ud805\ude75\udaa3\udd6f\udba0\ude71\u60c5\udad2\ude3a\ud811\udddd\ud862\udd9d\ud95f\ude3e\udb36\udee8\ud9d3\ude8d\udb17\udd94\udab3\udfaf\udb63\udfb9\ud937\udf8e",
        16, 94353, -1351433875, 7788650602271601380L, 96115L, false, false, (char) 21932, (char) 57145,
        Double.longBitsToDouble(0x3febb62d385510eeL), Double.longBitsToDouble(0x3fc99fe2f0142120L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CommandLineRunner:@? |a0=[Ljava.lang.String;:[[\ud845\udf0f\ud986\udffc\uda32\udfb6\ud939\ude94\udb71\uded4\uda8a\udefc\udb46\udd88\udb76\udd23\ud841\udce1\udab6\udd43]]\012",
        Z.run(T, 1, 10, 8, 8, "\ud845\udf0f\ud986\udffc\uda32\udfb6\ud939\ude94\udb71\uded4\uda8a\udefc\udb46\udd88\udb76\udd23\ud841\udce1\udab6\udd43", "\u4e9f\ud445", "\ud81d\udece\ud86b\udc06\udaf7\udd5f\ud9ae\udf70\udb27\udd02\udbeb\udca8\uda93\uddf0",
        39, 63755, 1384739708, -1834601701737987283L, -58751L, true, false, (char) 11569, (char) 9184,
        Double.longBitsToDouble(0x3fc8bd7406e288a0L), Double.longBitsToDouble(0x3fc61927a8808d14L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.CommandLineRunner|createOptions||new:com.google.javascript.jscomp.CommandLineRunner:[Ljava.lang.String;",
    "M|com.google.javascript.jscomp.CommandLineRunner|createCompiler||new:com.google.javascript.jscomp.CommandLineRunner:[Ljava.lang.String;",
    "M|com.google.javascript.jscomp.CommandLineRunner|createExterns||new:com.google.javascript.jscomp.CommandLineRunner:[Ljava.lang.String;",
    "M|com.google.javascript.jscomp.CommandLineRunner|getDefaultExterns||static",
    "M|com.google.javascript.jscomp.CommandLineRunner|initConfigFromFlags|[Ljava.lang.String;,java.io.PrintStream|new:com.google.javascript.jscomp.CommandLineRunner:[Ljava.lang.String;",
    "M|com.google.javascript.jscomp.CommandLineRunner|main|[Ljava.lang.String;|static",
    "M|com.google.javascript.jscomp.CommandLineRunner|processArgs|[Ljava.lang.String;|new:com.google.javascript.jscomp.CommandLineRunner:[Ljava.lang.String;",
    "M|com.google.javascript.jscomp.CommandLineRunner|processFlagFile|java.io.PrintStream|new:com.google.javascript.jscomp.CommandLineRunner:[Ljava.lang.String;",
    "M|com.google.javascript.jscomp.CommandLineRunner|shouldRunCompiler||new:com.google.javascript.jscomp.CommandLineRunner:[Ljava.lang.String;",
    "M|com.google.javascript.jscomp.CommandLineRunner|tokenizeKeepingQuotedStrings|java.util.List|new:com.google.javascript.jscomp.CommandLineRunner:[Ljava.lang.String;",
    "C|com.google.javascript.jscomp.CommandLineRunner|<init>|[Ljava.lang.String;",
    "C|com.google.javascript.jscomp.CommandLineRunner|<init>|[Ljava.lang.String;,java.io.PrintStream,java.io.PrintStream",
    "M|com.google.javascript.jscomp.CommandLineRunner|createOptions||new:com.google.javascript.jscomp.CommandLineRunner:[Ljava.lang.String;",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
