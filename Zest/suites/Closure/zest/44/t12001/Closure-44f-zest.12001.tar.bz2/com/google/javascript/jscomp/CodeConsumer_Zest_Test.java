package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class CodeConsumer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 1, 1, 2, "\ud88f\udeb1\ud80d\udc9e", "\ucd5b\u3733\u5ddf\u1ea2\u0466\u2a2b\u608a\u7aee\u86b1\ua130\u0802\u3e78\u6b2d\u91d4\u285e\ubf46\uc08b\uae7f\u9655\u7911\u1b15\u6c4c", "\ud94c\udc33\ud91c\udf98\ud870\udf9e\udba9\udf3d\u56d8\udb1a\udde5\ud815\udd7d\ud8b3\udd59",
        21, 41560, -410480970, 5293864473832192043L, 42400L, true, false, (char) 8048, (char) 26043,
        Double.longBitsToDouble(0x3fdcd5ef1047300eL), Double.longBitsToDouble(0x3fdf1ae23268318aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 1, 13, 2, "\udbba\udc1c\ud80d\udc9e", "\u7bc4\u7d05\u5ddf\u1ea2\u0466\u2a2b\u608a\u7aee\u86b1\ua130\u2009\u4d04\u9798\u91d4\u285e\u7046\uc08b\uae7f\u9655\u7911\u1b15\u6c4c", "\ud94c\udc33\ud91c\udf98\ud870\udf9e\udba9\udf3d\u56d8\udb1a\udde5\ud815\udd7d\ud8b3\udd59",
        21, 41560, -410480970, 5293864473832192043L, 42400L, true, false, (char) 8048, (char) 16070,
        Double.longBitsToDouble(0x3fb849d1b1173b68L), Double.longBitsToDouble(0x3fdf13d9d268318aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 1, 2, 2, "\ud88f\udeb1\ud80d\udc9e", "\ucd5b\u3733\ua240\u1ea2\u23b8", "\ud9db\udef9\ud96a\udebb\ud888\udc9b\ud93d\udca1\udbda\udc25",
        7, 81947, -16301691, -5578355855866365543L, 37773L, false, false, (char) 21028, (char) 42719,
        Double.longBitsToDouble(0x3fd232b1b1bd6810L), Double.longBitsToDouble(0x3fe409b4716fd2b0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 1, 1, 2, "\udb47\udd67\udb26\udcac", "\ucd5b\u3733\u5ddf\u1ea2\u0466\u2a2b\u608a\u142d\u8688\u1e33\u0802\u3e78\u6b2d\u91d4\u285e\ubf46\uc08b\u5d7f\u9655\u7911\u1b15\u6c4c\u37b7\u8a00\ubb2e\u062f\u3a91\ucb78\u720d\u0ffc\u9d05\uac23\u74d2\u532f\u71b6\ubcc3\ucd4b\u0ccf\u2872\u1d7f\uc488\u8c4e\u5293\u9f1c\u4b4d\u03df\u85e9\u0f15\uadbe\u62a7\ua537\ua737\ud59f\u7aff\u49d3\u63f7\u08e6\uba86\u8e12\ub8c2\u7f7b\ud245\u277a\ud465\u5dd0\u5927\u1f8a\u9425\u9755\u4a4b\u3660", "\udaf0\udf85\ud912\udffd\ud8d9\udd1f\udb47\ude30",
        51, 18761, -1457031201, 2548567254049140646L, 91195L, true, true, (char) 61053, (char) 26192,
        Double.longBitsToDouble(0x3fe96684cd4f8012L), Double.longBitsToDouble(0x3fda1da502209c68L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 14, 1, 12, "\ud8e1\udeba\ud80d\udc9e", "\ucd93\u3733\u5ddf\u1ea2\u0466\u2a2b\u608a\u7aee\u86b1\u8109\u0802\u3e78\u6b2d\u91d4\u285e\ubf46\uc08b\uae7f\u9655\u7911\u1b15\u6c4c", "\ud94c\udc33\ud91c\udf98\ud870\udf9e\udba9\udf3d\u56d8\udb1a\udde5\ud815\udd7d\ud8b3\udd59",
        11, 41560, -410480970, 5293864475912566827L, -45666L, false, false, (char) 8048, (char) 26043,
        Double.longBitsToDouble(0x3fdcd5ef1047300eL), Double.longBitsToDouble(0x3fdf1ae23232b98aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 11, 3, 2, "\ud86f\udf16\ud80d\udc9e\udafc\uddde", "\u3679\u5ddf\u1ea2\u47c0\u2053\uab05\u79e6\u53f5\ua130\u0802\u6831\u6b2d\u91d4\u285e\ubf46\uc08b\uae7f\u5755\u7911\u1b15\u6c4c\u37b7\u3c78\u9050\u05b4\u3a91\ucb78", "\ud815\udd7d",
        27, 1151, 1612810560, -1763002340547783247L, 8102L, false, true, (char) 5846, (char) 8048,
        Double.longBitsToDouble(0x3fee41cf9dcd5ef1L), Double.longBitsToDouble(0x3fa1cc03df1ae230L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 1, 1, 2, "\ud88f\udeb1\udb34\udd98", "\ucd5b\u3733\u5ddf\u1ea2\u0466\u2a2b\u608a\u7aee\u86b1\ua130\u0802\u3e78\u6b2d\u91d4\u285e\ubf46\uc08b\ub60e\u9655\u7911\u1b15\u6c4c", "\ud94c\udc33\ud91c\udf98\ud870\udf9e\udba9\udf3d\u56d8\udb1a\udde5\ud815\udd7d\udb17\udeec",
        -5, 41560, -410480970, 5293864473832192043L, 42400L, true, false, (char) 8048, (char) 50026,
        Double.longBitsToDouble(0x3fd0c1ed7046bbb4L), Double.longBitsToDouble(0x3fef8d711aa91306L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 3, 1, 2, "\udb8a\udf97", "\u1a76\ucd5b\u4275\u542a", "\ud83e\udc1d\udb64\udde5\ud9db\udefc\ud83a\udc58\ud8a5\ude5f",
        18, 52472, -712890998, -244690767975071355L, -3335L, false, true, (char) 49536, (char) 28716,
        Double.longBitsToDouble(0x3fef6cb1b9358e49L), Double.longBitsToDouble(0x3fdb32b1bc397c66L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 6, 10, 5, "\ud88f\udeb1\ud80d\udc9e\udafc\uddde\ud9e3\udcd4\ud8ac\ude00\uda2a\udf6e\uda2c\udf01\udab9\udce7\ud86b\udca9\ud84e\udfec\udb64\udde5\ud9db\udfc7\ud96a\udebb\ud888\udc9b\ud913\udea1\udb22\udc29\udbc6\udf08\ud92c\udc6b\ud934\udd76\ud834\udcee\ud9ab\udf94\udbe8\udec3\ud8f0\udebd\ud810\udc36\uda49\udd79\ud93e\udfbf\ud938\uddd2\u3a19\ud944\udc4a\ud84e\ude08\ud870\udf9e\udba9\udf3d\u56d8", "\uc7e9\u4014\u532f", "\ud8fb\ude09\ud986\ude8b\ud82a\ude59\uda35\udc06\ud8ea\udf44\udbd6\ude4d\ud8f1\udfe8\udb59\udf0e\udadf\udf66\u1a5d\udbf9\udc09\ud926\udc0a\uda22\udd30\ud9b4\udfb4\ud9c7\ude97\u2b49\udb3b\udf44\ud8a3\udd4c\udbd2\udd55\udae2\udf29\uda58\udd77",
        23, 62659, -937807737, -7758922905098557409L, -46524L, false, true, (char) 21635, (char) 20305,
        Double.longBitsToDouble(0x3fdc4a9201cd3e3eL), Double.longBitsToDouble(0x3fe91c2babd56011L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 8, 1, 2, "\ud88f\udeb1\ud80d\udc9e", "\ucd5b\u3733\u5ddf\u2b3c\u0466\u2a2b\u608a\u7aee\u86b1\ua130\u0802\u3e78\u6b2d\u91d4\u285e\ubf46\uc08b\uae7f\u9655\u7911\u1b15\u6c4c", "\ud94c\udc49\ud91c\udf98\ud870\udf9e\udba9\udf3d\u56d8\udb1a\udde5\ud815\udd7d\ud8b3\udd59",
        21, 41560, -410480970, 5293864473832192043L, 42400L, true, false, (char) 8048, (char) 26043,
        Double.longBitsToDouble(0x3fdcd5ef1bd9300eL), Double.longBitsToDouble(0x3fdf1aeeb268318aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 1, 1, 2, "\ua3b8\ud80d\udc9e", "\ucd5b\u3733\u5ddf\u1ea2\u0466\u2a2b\u608a\u7aee\u86b1\u0c23\u9660\u8d89\u6b2d\u91d4\u6b1a\u6645\u7456\uae7f\u9655\u7911\u1b15\u6c4c", "\udb4c\udfe6\ud91c\udf98\ud870\udf9e\udba9\udf3d\u56d8\udb1a\udde5\ud815\udd7d\ud8b3\udd59",
        21, 41560, -410480970, 5293864473832192043L, 42400L, true, false, (char) 8048, (char) 51642,
        Double.longBitsToDouble(0x3fd0552cb047300eL), Double.longBitsToDouble(0x3fdf1ae23268318aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 8, 1, 12, "\ud88f\ude7a\ud80d\udc9e\uda99\uddf5\ud9e3\udcd4\ud8ac\ude00\uda2a\udf6e\ud963\udfcb\ud965\udd88\ud853\udebf\ud83e\udc1d\udb64\udde5", "\ua130\u0802\u3e78\u6b2d\u19b1\ubdda\ubf46\uc08b\uae7f\u9655\u7911\u4bf8\u3e69\u1b99\u8a00\ubb2e\u062f\u3a91\ucb78\u7257\u0ffc\u9d05\uac23\u74d2\u532f\u71b6\ubcc3\u674b\u0ccf\u2872\u1d7f\uc488\u8c4e\u5293\u9f1c\u4b4d\u4623", "\udba3\ude6a\udac1\ude8a\udab4\udc48",
        5, 30903, 312861236, -3310004299419754421L, 4156L, true, true, (char) 36917, (char) 65385,
        Double.longBitsToDouble(0x3fdcc0f26d60564eL), Double.longBitsToDouble(0x3fdd6828ebc5ee08L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 5, 1, 2, "\uda10\uddb1\ud87d\udc11\udb0d\udf82\ud9e3\udcd4\udb9d\udfb8\uda0c\udcf0\ud963\udfcb", "\ucc69\ub14e\u7aee\u86b1\ua130", "\udbc6\udf08\ud993\ude07\ud901\udcf1\ud8b3\udd93\ud9bc\udec8\ubf68\ud9d4\ude9f\ud810\udc36\uda49\udd79\ud93e\udfbf\ud938\uddd2\udb94\udcbb\ud94c\udc33\udaa4\udfe6\ud87d\udee1\udba9\udf3d\u56d8\udbac\udd4e\ub171\udb98\udea7\ud8d0\udc02\udac6\uddd1\udb5f\ude3d\ud950\ude05\ud889\ude71\u2729\uda6f\udcae\uda35\udc06\ud8ea\udf44\ud93e\udd60\ud9b5\udfac\udbde\udf4f\uda48\ude3c\ud88e\ude04\udb18\ude01\ud9fb\udf7e\ud8f2\udd9d",
        4, 13674, 917269692, 3100590104741181054L, 76965L, false, false, (char) 57239, (char) 39213,
        Double.longBitsToDouble(0x3fd1cba3a8f2786eL), Double.longBitsToDouble(0x3fe682ba9c7f0c43L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 12, 2, 2, "\uda38\udc29\ud80d\udc4d\udafc\uddde\ud9df\uded4\ud8ac\ude00\uda2a\udf6e", "\u0466", "\ud9db\udfab\ud96a\udebb\ud888\udc9b\uda6d\udc99\udbda\udc25\udbc6\udf08\ud92c\udc6b\ud934\udd76\ud864\udf08\ud9bc\udec8\ubf68\ud9d4\ude9f\ud810\udc36\uda49\udd79\ud93e\udfbf\ud938\uddd2\udb94\udcbb",
        18, 38393, -1326512057, 7436279888563870000L, 83469L, false, true, (char) 63327, (char) 45269,
        Double.longBitsToDouble(0x3fe5b30108b1e788L), Double.longBitsToDouble(0x3fa5a6d89badbd30L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 13, 1, 2, "\ud88f\udeb1\uda34\udc32", "\ucd9b\u79ff\u10b7\u1ea2\u0466\u7451\u608a\u7aee\u9244\u8139\u0802\ud64f\u6b2d\u91d4\u285e\ubf46\uc08b\u8092\u9655\u2112\u1ab5\u6c4c", "\ud94c\udc33\ud91c\udf98\ud870\udf9e\udb0a\udf0e\udad9\uddfe\udbfe\ude27\uda77\udc75\ud8b3\udd59",
        21, 41560, -410480970, 5293864473832192043L, 42400L, true, false, (char) 8048, (char) 26043,
        Double.longBitsToDouble(0x3fdcd5ef1c93be0eL), Double.longBitsToDouble(0x3fdd830fd3120b32L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 2, 1, 2, "\ud88f\udeb1\ud80d\udc9e", "\ucd5b\u3733\u5ddf\u1ea2\u4ff0\u2d2d\u60bd\u31ef\u86b1\ua130\u0802\u3e78\u6b2d\u91d4\u285e\ubf46\uc08b\uae7f\u9655\u7911\u1b15\u6c4c", "\ud94c\udc33\ud91c\udf98\ud974\ude01\udb12\udf83\u56d8\udb1a\udde5\ud815\udd7d\uda5b\udece",
        21, 41560, -410480970, 5293864473832192043L, 42400L, true, false, (char) 18515, (char) 26043,
        Double.longBitsToDouble(0x3fdcd5ef1447300eL), Double.longBitsToDouble(0x3fdb90a36268315aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 1, 1, 2, "\ud88f\udeb1\ud80d\udc9e", "\ucd5b\u0253\u9e6a\u54ce\uc951\u2d51\u608a\u7aee\u86b1\ua130\u0802\u3e78\u381f\u91d4\ua540\ubf46\uc08b\uae7f\u9655\u7911\u1b15\u6c4c", "\ud94c\udc33\udbad\udde9\ud870\udfef\udba9\udf3d\ud852\uded6\udb1a\udde5\ud835\udf8d\udaf9\udd09",
        52, 13716, -410480970, 5293864473832192043L, 14496L, true, false, (char) 4256, (char) 26043,
        Double.longBitsToDouble(0x3fdcd5ef1047300eL), Double.longBitsToDouble(0x3fdf1ae23268bb8aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 9, 12, 2, "\ud88f\udeb1\ud80d\udc9e", "\ucd5b\u3733\u5ddf\u1ea2\u0466\u2a2b\u608a\u7aee\u86b1\ua130\u0802\u3e78\u6b2d\u91d4\u285e\ubf46\uc08b\uae7f\u9655\u7911\u1b15\u6c4c", "\ud94c\udc33\ud91c\udf98\ud870\udf9e\udba9\udf3d\u56d8\udb1a\udde5\ud815\udd7d\ud8b3\udd59",
        21, 41560, -410480970, 5293864473832192043L, 42400L, true, false, (char) 33354, (char) 26043,
        Double.longBitsToDouble(0x3fdcd5ef1047300eL), Double.longBitsToDouble(0x3fdf1ae23268318aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 1, 1, 0, "", "\u8dd7\u1a76\ucd5b\u3733\u5ddf\u1ea2\u0466\u29e2\u608a\u7aee\u86b1\u4240\u4eda\u3e78", "\ud934\udd76v\ud9bc\ude2f\ubf68\ud9d4\ude9f",
        48, 72853, 53, 0L, 27232L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe8000004ad68d8L), Double.longBitsToDouble(0x3fe9106805e76979L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 10, 1, 2, "\ud88f\udeb1\ud80d\udc9e", "\u9b4f\u1cc9\ua16b\u6f25\u0466\u2a2b\u5852\u7af7\u86b1\ua99d\u0802\u3e78\u6b2d\u4b05\u7166\u6c8f\uc799\uae7f\u06ed\u7911\u1b15\u6c4c", "\ud965\ude01\ud8f7\udd2b\ud870\udf9e\udba9\udf3d\u56d8\udb1a\udde5\ud849\udd77\ud8b3\udd59",
        21, 41560, -410480970, 5293864473832192043L, 42400L, true, false, (char) 8048, (char) 26043,
        Double.longBitsToDouble(0x3fdcd5ef1047300eL), Double.longBitsToDouble(0x3fdf1ae23268318aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 7, 10, 1, "\ud88f\udeb1\ud80d\udc9e\udb0d\udd0a\ud9e3\udcd4\ud8ac\ude00\uda2a\udf6e\ud940\udfb0\ud965\udd88\ud853\udebf\udb9a\udd0a\udb64\udd9a\ud9fb\udce3\udbe0\udd76\udb12\udcb3\ud91b\udf52\udbda\udc25", "\u4514\ua6e7\u9d95\uaeec\u9655", "\udba3\udd81\ud938\uddd2\udb94\udcbb\ud94c\udc33\ud91c\udf98\ud836\udfaa\uda76\ude5f\u56d8",
        37, 79789, 658311380, -7705980129882568339L, -72785L, true, false, (char) 13710, (char) 22042,
        Double.longBitsToDouble(0x3fe0ad1c87dacf95L), Double.longBitsToDouble(0x3fee41cf9b2186f1L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 1, 2, 2, "\ud88f\udeb1\ud80d\udc9e\udbb8\uddfc\ud9e3\udd17\ud8ac\ude00\uda5d\udf28\udbeb\udc18\ud965\udd88\ud8af\uddc3\udb51\uddf2\ud92f\udc71", "\ua130\u0802\u3e78\u6b2d\u6a49\u0819\u2f27\uc08b\uae7f\u9655\u7911\u23d0\u6cae\u1f19\u9187\u64cd\u7217\ud2fb\u7462\uba9b\u8e6a\uc2e3\u20bb\u5713\u9a0b\u6e96\uc739\u5d62\ucd75\uc15b\uc98f\ub962\u91db\ub1c7\u115c\u6131\u47c1", "\ud9d2\udc75\u766e\udb77\ude3b",
        22, 81480, 17950039, -868681751179108822L, -87345L, false, false, (char) 65434, (char) 3827,
        Double.longBitsToDouble(0x3fee35632d2fed73L), Double.longBitsToDouble(0x3fe56994ef6a99f7L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 1, 2, 2, "\u447c\ud816\udf05", "\ua736\u8204\ua240\u1ea2\u23b8", "\ud9db\udef9\ud96a\udebb\ud888\udc9b\ud93d\udca1\udbda\udc25",
        11, 64451, -8159132, -5578300880284976743L, 37773L, false, false, (char) 21028, (char) 42719,
        Double.longBitsToDouble(0x3fd232b1b1bd6810L), Double.longBitsToDouble(0x3fe409b4716fd2b0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 1, 1, 9, "\u00f3\ud90b\udd8d", "\u7ebd\uc302\ud0fe\u89b2\u41d0", "\udad5\udeeb\uda68\ude3a\ud84b\ude43\udad5\udeed\uda23\udd8b",
        4, 33445, -223770490, 3375632965139203401L, 7541L, false, false, (char) 21028, (char) 42719,
        Double.longBitsToDouble(0x3fd23c41b1bd6810L), Double.longBitsToDouble(0x3fe409b4716fd2b0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 15, 8, 9, "\ud88f\udeb1\ud80d\udc9e\uda87\ude64\udac4\udec3\ud8aa\udf3e\udb74\udef1\udbef\udfd8\ud9b6\udcd1\udbad\udd2e", "\u358e\u86b1\u0c27", "\udbc6\udf08\udacb\udd70\ud862\udf76\ud80d\ude58\udbf1\udcb2\ud803\uddc4",
        12, 31852, 1924960252, -2135087845377275347L, -97886L, true, true, (char) 36048, (char) 58269,
        Double.longBitsToDouble(0x3fe3174931b2a337L), Double.longBitsToDouble(0x3fe841a2ea0d9f1fL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 1, 2, 2, "\ud88f\udeb1\uafef", "\ucd5b\u3733", "\000",
        -5, 24014, 535452952, 1277132989131342400L, -97048L, false, false, (char) 0, (char) 16773,
        Double.longBitsToDouble(0x3fe747f83999b295L), Double.longBitsToDouble(0x3fd8c8c00ba6015aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 11, 3, 6, "\ud8cb\udd34\udb32\udd01\udba9\udd4b\ud887\udf54\ud8b4\udd2a\ud88d\udf0b\ud843\ude3d\udbc4\udd52\ud9b2\udea2\udb91\udc52", "\u6815", "\ud98b\ude3f\ud86a\udd95\ud92c\udc6b\udbf4\udcb5\ud856\udda0\ud9bc\udec8\udbb4\uddf0\ud9d4\ude9f\ud93a\udf4a\udb80\udf09\ud8f2\uddcb\ud57c\ud91c\udeec\ud997\udfd5\udae0\udc59\u5734\udaa6\udc75\ud85e\udeea\ud846\udf25\ud977\udd56\uda3f\udf4a\ud9a0\udc50",
        40, 44090, -760319481, -3618765529212091694L, 31960L, true, false, (char) 36973, (char) 7516,
        Double.longBitsToDouble(0x3fb5c1307ffd6cb8L), Double.longBitsToDouble(0x3feedc59f21dcbb7L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 2, 2, 9, "\ud852\udcb2\udb3b\udef1\ud97d\udf07\udaf8\udc8d\ud8fc\udd86\ub6d2\udbea\udfe7\ud9b1\udedb\ud9d7\udf39\ud9bd\udff7\ud9d2\udff8\ud852\udca4\ud96a\udebb\udb16\udee3\ud961\udc9f\udbb5\udf54\uda72\udeb0\ud96a\ude89\ud9d8\udeb6\ud80d\ude58\udb82\udfea\ucd89\ud9d4\ude9f\ud810\udc36\uda00\udc37", "\u9187\ua439\u781f\u5988\u87b3\u7b3c\ubf50\u0576\u484c\u5f50\uc6ba\ub368\ua75b\u2853\u3828", "\ud9f3\udfba\udb26\udf62\uda23\udfd1\ud906\uddac\udbe7\ude87\u1852\ud88b\udd5d\udb40\udd4f",
        46, 63717, -804902090, 8354899051761874966L, -77921L, true, false, (char) 11219, (char) 4924,
        Double.longBitsToDouble(0x3fcb887864c1d130L), Double.longBitsToDouble(0x3fe63cda9576fe85L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 0, 2, 2, "\ud8f1\udce1", "\u1ab9", "\udbea\udfe7\ud965\udd88\ud8af\uddc3",
        20, 24014, 535452952, 1277132989129556032L, -100000L, false, false, (char) 0, (char) 133,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd8c8c5dba7b75aL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=java.lang.Boolean:false |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 11, 10, 2, "\ud88f\udeb1", "\u307e\u4e25\u3733\ua240\u1ea2\u6e32\u8b2e\u6abc\u37fe\u86b1\u6f49\u4ef7\u3b45\uca53\u97f3\u2874\u11d2\uc0db\u33d5\u9655", "\ud93f\udc21\udb8d\udca8\ud82b\udc15\ud997\udfd5\udaef\udfa2\uda0d\udf69\ud8a4\udcd9\uda79\udfa1",
        47, 46526, 2143605962, 4735937848397577555L, -82435L, false, true, (char) 61741, (char) 56145,
        Double.longBitsToDouble(0x3fdf298aac2cf2e2L), Double.longBitsToDouble(0x3feda15b93f493e4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 3, 1, 12, "\ud8e1\udeba\ud81a\udda5", "\ucd93", "\udab9\udff3\ud853\udebf\ud83e\udc1d\udb64\udde5\ud9db\udefc\ud96a\udebb\ud880\udc74\ud93d\udca1\udbda\udc25\udbc6\udf08\ud92c\udc6b\ud934\udd76\ud864\udf08\ud9bc\udec8\udb90\udca1\ud9d0\udc29\ud810\udc36\uda49\udd79\ud93e\udfbf\ud938\uddd2\ud8fa\ude52\ud94c\udc33\ud91c\udf98\ud870\udf9e\udba9\udf3d",
        2, 31632, 231394477, 7600113689438892263L, -63466L, true, true, (char) 16802, (char) 19998,
        Double.longBitsToDouble(0x3faf2cad68423d00L), Double.longBitsToDouble(0x3feed67cabc839f3L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 3, 1, 2, "\u8687\udb2c\uded0", "\u9213\u413d\u542a\u1ea2\u0466", "\ud9db\udefc\ud83a\udc58\ud8a5\ude5f\ud8dd\ude8a\udbda\udc25\udbc6\udf08\ud90a\udf37\ud99a\udcde\ud864\udf08\ud9bc\udec8\ubf68\ud808\udcf9\ud810\udc83\ud9c7\udd39\udbf1\udec1\ud938\uddd2\udbf8\ude0c",
        22, 9887, 1024854042, 4368107109889934893L, -83364L, true, true, (char) 60416, (char) 61882,
        Double.longBitsToDouble(0x3fc15df6f4ecaeacL), Double.longBitsToDouble(0x3fef2694a54b44ecL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 8, 6, 12, "\ud88f\ude7a\udbed\udd80\uda99\uddf5\ud9e3\udcd4\ud8ac\ude00\uda2a\udf6e\ud963\udfcb\ud965\udd88\ud853\udebf\ud83e\udc1d\udb64\udde5", "\uc4f7\u0802\u3e78\u6b2d\u19b1\ubdda\ubf46\uc08b\uae7f\u9655\u7911\u4bf8\u3e69\u1b99\u8a00\ubb2e\u062f\u3a91\u8423\u4244\u1420\u9d05\uac23\u5d2b\u532f\u71b6\ubcc3\u674b\u51a5\u6e07\u1d7f\uc488\u8c4e\u5293\u9f1c\u4b4d\u4623", "\udba3\ude6a\u5a54\udab4\udc48",
        5, 30903, 312861236, -3310004299419754421L, 4156L, true, true, (char) 36917, (char) 65385,
        Double.longBitsToDouble(0x3fdcc0f26d60564eL), Double.longBitsToDouble(0x3fdd6828ebc5ee08L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 13, 5, 2, "\ud88f\udeb1\uda34\udc32", "\ucd9b\u79ff\u10b7\u1ea2\u0466\u7451\u8a72\u7aee\u9244\u8139\u0802\ud64f\u6b2d\u91d4\u285e\ubf46\uc08b\u8092\u9655\u4599\u1ab5\u6c4c", "\ud94c\udc33\ud91c\udf98\ud870\udf9e\udb0a\udf0e\udaca\udefe\ud942\ude71\uda98\uddb3\ud8b3\udd59",
        30, 41560, -410480970, -3140251727059187066L, 42400L, true, false, (char) 55356, (char) 26043,
        Double.longBitsToDouble(0x3fdcd5ef1c93be0eL), Double.longBitsToDouble(0x3fdd830fd24e0b32L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 9, 9, 1, "\ud88f\udeb1\ud80d\udc9e", "\ucd5b\u3733", "\ud90d\udc7a",
        39, 46124, 535452955, 6619809521650722227L, -97814L, true, true, (char) 28137, (char) 49536,
        Double.longBitsToDouble(0x3fd02516d7db2da2L), Double.longBitsToDouble(0x3feeb0d248a5e371L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 1, 1, 0, "", "\u8dd7\u1a76\ucd5b\u3733\u5ddf\u1ea2\u0466\u29e2\u608a\u7aee\u86b1\u4240\u47a3\u3e78", "\ud934\uddd2v\ud9bc\ude2f\ubf68\ud9d4\ude9f",
        48, 72853, 53, 0L, -96160L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe8000004ad68d8L), Double.longBitsToDouble(0x3fe9106805e76979L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 7, 3, 13, "\udab9\ude05\ud80d\udc9e\udb0d\udd0a\udbed\udc79\ud8ac\ude00\uda2a\udf6e\ud93b\udde1\udac5\udd09\ud9de\udf10\uda84\udedb\udafc\udfce\udb30\ude97\udbe0\udd0b\udb12\udcb3\ud91b\udf52\udbda\udc25", "\uc27b\uc613", "\ud91c\udd05\udb7d\udecf\udbcd\udee3\udb78\udc57",
        8, 7532, 1831971268, 2212940639616218183L, -9608L, false, false, (char) 34267, (char) 31964,
        Double.longBitsToDouble(0x3fa5a4bb9badbd30L), Double.longBitsToDouble(0x3fee0412d615a36fL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 12, 13, 2, "\ud88f\udeb1\udae5\udc69", "\u3d18\uc44e", "\ud9ed\udef6\u2dc2\ud92f\udc71\ud9db\udef9\ud8cf\udcad\ud888\udcd8\ud93d\udca1\ud97b\udf16y",
        13, 47261, -1298812325, -8358547210442801268L, -45772L, true, false, (char) 63793, (char) 3609,
        Double.longBitsToDouble(0x3fe2798e58b2c308L), Double.longBitsToDouble(0x3fec9fa2d5e2fed6L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 8, 8, 2, "\ud88f\udeb1\uafef", "\u0b20\u2fbe", "\u622a",
        -5, 24014, 535911704, 5528531037369130811L, -97048L, false, false, (char) 0, (char) 16773,
        Double.longBitsToDouble(0x3fe747f83999b295L), Double.longBitsToDouble(0x3fd8c8c00ba6015aL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 3, 6, "\u30f6\udb42\udf56\udba9\udd07\udaec\udce5\udbe2\udf09\ud88d\udf0b\ud843\ude3d\uda7e\udddb\ud95e\udd53\udb91\udc52", "\u6815", "\ud98b\ude3f\ud86a\udd95\ud92c\udc6b\ud97c\udca3\ud856\udd34\ud9bc\udec8\udbb4\uddf0\ud9d4\ude9f\ud93a\udf4a\udb80\udf09\ud8f2\uddcb\ud57c\ud893\udfe5\ud992\udec2\udade\udc78\ud884\udd91\uda17\udea5\ud9da\udfb9\ud846\udf25\ud977\udd56\uda3f\udf4a\ud8c0\udf01",
        5, 44035, -760319481, 7155712595136250578L, 63994L, false, false, (char) 47667, (char) 7516,
        Double.longBitsToDouble(0x3fb5c1307ffd6cb8L), Double.longBitsToDouble(0x3feedc59f21dcbb7L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 3, 6, "\ud9fe\udf2f\udb10\udde4\udba9\udd4b\ud887\udf54\uda8a\udcd5\ud88d\udf0b\ud837\udf3d\udbc4\udd52\ud9b2\udea2\udb91\udc52", "\u0d87", "\ud98b\ude3f\ud86a\udd95\ud92c\udc6b\uda21\uddcd\udae4\udcce\ud9d2\udd16\ud839\ude51\ud9d4\ude9f\ud93a\udf4a\udb80\udf09\ud88d\udcfd\ud57c\ud91c\udeec\ud997\udfd5\udae0\udc59\ud8cb\udccd\udaa0\udc41\ud85e\udeea\uda74\udc9b\ud977\uddc7\uda27\udf4a\ud80e\ude46",
        13, 21994, -1667439878, 8856301877799846458L, 48344L, true, false, (char) 36973, (char) 7516,
        Double.longBitsToDouble(0x3fb5c1307ffd6cb8L), Double.longBitsToDouble(0x3feedc59ffa1cbb7L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 3, 6, "", "\u00c6", "\ud88d\udf0b",
        48, 78500, 1290501658, -8177469284629334451L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3f92966fe17ab920L), Double.longBitsToDouble(0x3fd858f9a95af40eL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 12, 13, 2, "\ud9e4\udd5f\ud9e3\uddcd", "\u3d18", "\uf355\ud958\udcff\u0e9b",
        26, 85354, 62474672, -2009939589965097987L, -31652L, false, true, (char) 56341, (char) 11606,
        Double.longBitsToDouble(0x3feecf648b59fbfaL), Double.longBitsToDouble(0x3fe30374a458eb13L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 3, 12, "\u30f6\udb42\udf56\udbbc\udf07\udbe9\udc12\udb22\udcce\udb9d\uddaa\ud843\ude3d\udaf3\udfb4\ud95e\udd53\udb91\udc52", "\u03d3\u4193\u3295\uc75a", "\ud97c\udca3\ud856\udd34\ud9bc\udec8\ud9bc\udcb2\udbf5\udc9c\uda6d\ude4f",
        45, 29031, 1237780778, -5821354796372679314L, 31536L, true, true, (char) 62068, (char) 47529,
        Double.longBitsToDouble(0x3fe5d4edc754e808L), Double.longBitsToDouble(0x3fe81ca16e71ffe2L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 0, 3, 6, "\uc078", "\u591d\u91e8\u45c5\ucea1\ucb2e\u5c53\u8cd8\u1886\000\u06d1\u6c0d\000\u9f69\u1a6c\u91d4\ud225", "\udb39\uddd3\ud9ab\udd88\udab6\ude27\udb90\ude6c\udb67\ude80\uda1d\udd9d\ud96a\udc19\udb45\udf28\udbdf\udc26\ud98d\udfd2\udbfe\udc81\ud866\udd63\uda3c\ude4b\ud92f\udc49",
        34, 2457, -1646794609, -8548882671760346864L, 18892L, true, false, (char) 12611, (char) 32126,
        Double.longBitsToDouble(0x3fec5f10b8793995L), Double.longBitsToDouble(0x3fb0637eb8436d68L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 10, 10, 3, "\uc078\udb32\udc6e", "\u5f35\u627c\u7d42\u5be9\u5d1a\u2515\u29df\u4108\u4e37\u8917\u25fb\u9e6e\u1a6c\u972a\uc0fd\u09d0\u7c2f", "\ud8cd\udc92\uda42\udc2b\udb84\udf2c\ud871\udda4",
        6, 55606, 8699759, -5906227933007893592L, 36136L, true, false, (char) 46759, (char) 25490,
        Double.longBitsToDouble(0x3fc1e9b67206775cL), Double.longBitsToDouble(0x3fd00895cb82f47aL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 1, 1, 2, "\ud88f\udeb1\ud80d\udc9e", "\ucd5b\u3733\u5ddf\u1ea2\u0466\u2a2b\u608a\u7aee\u86b1\ua130\u0802\u3e78\u6b2d\u91d4\u285e\ubf46\uc08b\uae7f\u9655\u7911\u1b15\u6c4c", "\ud94c\udc33\ud91c\udf98\ud870\udf9e\udba9\udf3d\u56d8\udb1a\udde5\ud815\udd7d\ud8b3\udd59",
        21, 41560, -410478154, 5293864473832192043L, 42400L, true, false, (char) 8048, (char) 26043,
        Double.longBitsToDouble(0x3fdcd5ef1047300eL), Double.longBitsToDouble(0x3fdf1ae23268318aL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 12, 12, 12, "\ud8a0\ude70\ud95f\udd28\ud818\udc00\uda87\udf7d\ud91b\udd2f\ud933\uded3\ud8df\udfef", "\u2237\u99b4\u2513\u3f8f\u53c7\u5305\u083f\u2633\u3b00\u69c1\u7cb7\u8604\u460c\u9c18\u7965\uaac8\u46f6\u37b7\u8a00\u446f\u062f", "\ud91e\ude29\ud9d4\udfdc",
        3, 43197, -2080379496, 6958302917793423545L, 1202L, true, false, (char) 33646, (char) 56904,
        Double.longBitsToDouble(0x3feed6ee33c839d2L), Double.longBitsToDouble(0x3fd9916e91c8cd38L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 13, 13, 2, "\ud88f\udeb1\udae5\udc69", "\u1b99\uc44e", "\ud9ed\udef6\u2dc2\ud92f\udc71\ud9db\udef9\udb8b\udcab\ud888\udcd8\ud93d\udca1\ud97b\udf16y",
        13, 47261, 423423067, -8305865184539738228L, -73676L, true, false, (char) 63793, (char) 3609,
        Double.longBitsToDouble(0x3fe2798e58b2c308L), Double.longBitsToDouble(0x3fec9fa2d5e2fed6L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 2, 2, 2, "\udae5\udf3b", "\u1ab9", "\udb12\udc3a\udbb3\ude40\ud93d\udfcc",
        3, 24014, 535452952, 1264862439078749760L, 41066L, false, false, (char) 0, (char) 16,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe99c62eb636145L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 11, 3, 6, "+", "\u71a7\u6278\ua647\u6cfa\u5c6c\u6944\ub4d5\u364d\000\000\ud25e\ubda0\uaba2\u454c\uc0f2\ud225", "\ud951\ude24\udbb9\udf6f\udb15\udfc8\ud98b\udea8\ud8e3\udd16\ud98b\uddb8\ud913\udcb1\udb1e\ude0d\ud885\ude16\uda2f\udd89\ud8ff\uddc1\uda03\udff1\udad9\udc7a\uda9a\ude23",
        29, 32508, -1519936923, -3259341295532317814L, 59625L, false, false, (char) 58775, (char) 39880,
        Double.longBitsToDouble(0x3fd81ae2d38b5eeaL), Double.longBitsToDouble(0x3fe02a1b95401068L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 0, 3, 6, "+", "\u71a7\u6278\ua647\u6cfa\u5c6c\u6944\ub4d5\u364d\000\000\ud25e\ubda0\uaba2\u454c\uc0f2\ud225", "\ud951\ude24\udbb9\udf6f\udb15\udfc8\ud98b\udea8\ud8e3\udd16\ud98b\uddb8\ud913\udcb1\udb1e\ude0d\ud885\ude16\uda2f\udd89\ud8ff\uddc1\uda03\udff1\udad9\udc7a\uda9a\ude23",
        29, 32508, -1519936923, -3259341295532317814L, 59625L, false, false, (char) 145, (char) 768,
        Double.longBitsToDouble(0x3fd81ae2d38b5eeaL), Double.longBitsToDouble(0x3fe02a1b95401068L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 11, 0, 6, "$", "\u71a7\u6278\ua647\u6cfa\u5c6c\u50d7\u4a89\u201eY\000\ud25e\ubda0\uaba2\u454c\uc0f2\ud225", "\ud951\ude24\udbb9\udf6f\udb15\udfc8\ud98b\udea8\udbfd\ude43\ud806\udd21\ud913\udcb1\udb1e\ude0d\ud885\ude16\uda2f\udd89\ucdbc\uda03\udff1\udad9\udc7a\uda9a\ude23",
        37, 32508, -1519936923, -3259341295532317814L, 59625L, false, false, (char) 58775, (char) 39880,
        Double.longBitsToDouble(0x3fd81ae2d38b5eeaL), Double.longBitsToDouble(0x3fe02a1b95401068L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 4, 0, 6, "$", "\u71a7\u6278\ua647\u6cfa\u5c6c\u50d7\u4a89\u1bf0m\u2e38\u1790\ubdcc\uaba2\u454c\uc0f2\ud225", "\ud97e\udf02\udbb9\udf6f\udb15\udfc8\ud98b\udea8\udbfd\ude43\ud806\udd21\ud913\udcb1\udb1e\ude0d\ud885\ude16\uda2f\udd89\ud897\udc4e\uda03\udfac\udad9\udc7a\uda9a\ude23",
        37, 32508, -1519936923, -3259341295532317814L, 59625L, false, false, (char) 58775, (char) 39880,
        Double.longBitsToDouble(0x3fd81ae2d38b5eeaL), Double.longBitsToDouble(0x3fe02a1b95401068L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 0, 3, 6, "/", "\u8ae2\u6278\ua647\u6cfa\u5c6c\u6944\u0169\u364d\000\000\ud25e\ubda0\uaba2\u454c\ub00f\ud225", "\ud949\udd24\udbb9\udf6f\udb15\udfc8\ud98b\udea8\ud8e3\udd16\ud98b\uddb8\ud913\udcb1\udb1e\ude0d\ud885\ude16\uda2f\udd89\ud8ff\uddc1\uda03\udff1\udad9\udc7a\uda9a\ude23",
        29, -916, -1519936923, -3259341295532317814L, -100000L, false, true, (char) 26542, (char) 18469,
        Double.longBitsToDouble(0x3fe02a1b95f1ed41L), Double.longBitsToDouble(0x3fe977fb56bc7b03L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 0, 1, 6, "/", "\u8ae2\u6278\ua647\u6cfa\u5c6c\u6944\u0169\u364d\u2e98\u979f\ud25e\ubda0\uaba2\u454c\ub00f\ud225", "\ud949\udd24\udbb9\udf6f\udb15\udfc8\ud98b\udea8\ud8e3\udd16\ud98b\uddb8\ud913\udcb1\udb1e\ude0d\ud885\ude16\uda2f\udd89\ud8ff\uddc1\uda03\udff1\udad9\udc7a\uda9a\ude23",
        29, -916, -1519936923, -3259341295532317814L, -100000L, false, true, (char) 26542, (char) 18469,
        Double.longBitsToDouble(0x3fe02a1b95f1ed41L), Double.longBitsToDouble(0x3fe977fb56bc7b03L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 0, 1, 6, "/\udb34\uddbf\ud96a\ude3b", "\ua647", "\ud9a5\udd73\ud906\udd46\u364d\udb01\udd7f\u75cd\ud9ec\uddb5\ud867\udcb3\ud94e\ude88\ud9c1\udfc1\udb79\udca9\udbf4\udcb5\udaf4\udde8\uda30\udd6d",
        42, 52820, -1947461984, -1024886129287749783L, 46480L, false, false, (char) 53889, (char) 63486,
        Double.longBitsToDouble(0x3fefa64a48fe6273L), Double.longBitsToDouble(0x3fe923afa3938ef7L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 0, 1, 6, "\\", "\u8ae2\u6278\ua647\u6cfa\u5c6c\u6944\u0169\u364d\u2e98\u979f\ud25e\ubda0\uaba2\u454c\ub00f\ud225", "\ud949\udd24\udbb9\udf6f\udb15\udfc8\ud98b\udea8\ud8e3\udd16\ud98b\uddb8\ud913\udcb1\udb1e\ude0d\ud885\ude16\uda2f\udd89\ud8ff\uddc1\uda03\udff1\udad9\udc7a\uda9a\ude23",
        29, -916, -1519936923, -3259341295532317814L, -100000L, false, true, (char) 26542, (char) 18469,
        Double.longBitsToDouble(0x3fe02a1b95f1ed41L), Double.longBitsToDouble(0x3fe977fb56bc7b03L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 0, 4, 6, "\\", "\u8ae2\u6278\ua647\u6cfa\u0718\u5193\u71a8\u4287\u4f78\u0435\u110a\ubdfd\uaba2\u454c\ub00f\ud225", "\ud949\udd24\udbb9\udf6f\udb15\udfc8\ud98b\udea8\ud97b\ude21\ud98b\uddba\u8119\udb9b\udc94\uda54\ude1f\uda2f\uddad\ud8ff\uddc1\uda03\udff1\udad9\udc7a\uda9a\ude23",
        29, -916, -1519936923, -3259372704628153462L, -100000L, false, true, (char) 26542, (char) 18469,
        Double.longBitsToDouble(0x3fe02a1b95f1ed41L), Double.longBitsToDouble(0x3fe977fb56bc7b03L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 3, 6, "+", "\u89ee\u6278\ud286\ua671\u1915\u6975\ub4d5\u364d\u40a8\000\ud25e\ubda0\uaba2\u9196\uc0f2\ud225", "\ud9f9\udf12\udbb9\udf6f\udb15\udfc8",
        30, 16392, 2108939856, 617622276748781204L, -21422L, false, false, (char) 42226, (char) 2748,
        Double.longBitsToDouble(0x3fec9c77bfe2e7a6L), Double.longBitsToDouble(0x3fd9cd6434cad83aL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 3, 9, "+\udb34\uddbf\u00c6\udacf\udc2b\ud8b4\udd2a\ud88d\udf0b\ud843\ude3d\udb36\udc0a", "\u364d\u3581\u9986", "\ud94e\ude8a\ud9c1\udfc1",
        42, 70968, -1353021612, 7701337294517824751L, -94366L, true, true, (char) 8559, (char) 46820,
        Double.longBitsToDouble(0x3fa83ed9e9408920L), Double.longBitsToDouble(0x3fdd03afa186de78L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 11, 0, 15, "_\udb00\udf1a\ud9f0\ude7a\ud83e\udd5b\ud8b4\udd2a\udb94\udc14\u4134\ud91b\udd7c\ud925\udeb9\udaaa\uddff\udac7\udde8Y\000\ud9ec\uddb5", "\u454c", "\udaf4\udde8\ud985\udc36\ud951\ude24\udbb9\udf6f\udb15\udfc8\ud98b\udea8\udbfd\ude43\ud806\udd21\ud913\udcb1\udb1e\ude0d\ud885\ude16\uda2f\udd92\ucdbc\uda03\udff1\udad9\udc7a\uda9a\ude23\udbcb\udd75\ud834\udffb\ud8b9\udd0e\uda4a\udfb1\uda3b\udfaa\ud815\udce9",
        -1, 9118, -1745004794, -5896052168096106111L, -47341L, true, true, (char) 46215, (char) 1694,
        Double.longBitsToDouble(0x3fc18541d1b8c5c0L), Double.longBitsToDouble(0x3fefa40c473162caL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 0, 0, 0, "_\udb00\udf1a\ud9f0\ude7a\ud86c\udc31\000\u1900\000\u00dc\000\000\ud984\udf01Y\000\000", "\u454c", "\000\ud95b\ude4c\ud951\ude24\udbb9\udf6f\udba1\udead\000\udbfd\ude43\ud8c8\uddc3\ud913\udc81\udb1e\ude0d\ud885\ude16\000\000\uda03\udef3\udad9\udc7a\uda9a\ude23\udbcb\udd75\ucd9c\ud8b9\udd0e\uda4a\udfb1\ud83b\udfaa\ud815\udce9",
        -1, 9118, -1745004794, -5896052168096106111L, -47341L, true, true, (char) 46215, (char) 1694,
        Double.longBitsToDouble(0x3fc18541d1b8c5c0L), Double.longBitsToDouble(0x3fce90201c000000L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 11, 3, 6, "-\udb32\udc6e\u00c6\ud887\ude87\ud8b4\udd2a\ud88d\udf0b\ud843\ude3d", "\u1c82\u364d\000\000", "",
        40, -694, -1885688053, 8793068838511426733L, -30219L, false, false, (char) 8844, (char) 63596,
        Double.longBitsToDouble(0x3fe953b2d1775e02L), Double.longBitsToDouble(0x3fd5ea69a7a852caL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 3, 6, "-\udb32\udc6e\u00c6\ud887\ude87\ud8b4\udd2a\ud88d\udf0b\ud843\ude3d", "\u1c82\u364d\000\000", "",
        40, -694, -1885688053, 8793068838511426733L, -30219L, false, false, (char) 8844, (char) 63596,
        Double.longBitsToDouble(0x3fe953b2d1775e02L), Double.longBitsToDouble(0x3fd5ea69a7a852caL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.CodeConsumer|add|java.lang.String|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|addIdentifier|java.lang.String|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|addNumber|double|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|addOp|java.lang.String,boolean|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|append|java.lang.String|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|appendBlockEnd||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|appendBlockStart||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|appendOp|java.lang.String,boolean|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|beginBlock||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|beginCaseBody||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|breakAfterBlockFor|com.google.javascript.rhino.Node,boolean|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|continueProcessing||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|endBlock||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|endBlock|boolean|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|endCaseBody||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|endFile||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|add|java.lang.String|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
