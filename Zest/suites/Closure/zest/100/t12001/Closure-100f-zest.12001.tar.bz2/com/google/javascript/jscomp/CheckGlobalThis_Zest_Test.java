package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class CheckGlobalThis_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 1, 4, 3, 5, "\udbbc\udfe2\ud995\ude24\uda93\uddc6\ud9c3\uddaf\ud9ff\udc5a\ud8ea\ude0b\ud9a5\udd1d\udb84\udcdf\ud960\udd20\ud8b2\udcf6\ud987\udf50\udbe6\udff7\udabd\udd6c\uda5d\udd69\ud851\udcef\udbe0\udea3\udb1f\udfcb\ud972\udc81", "\ua364\uc74c\u0507", "\udb5e\udce3\ud84d\ude65\udaae\udf60\uda9b\udc21\udb0c\uddb6\udb3a\udebe\udbe1\uddfd\ud86c\udf74\uda84\udcbe\ud9e4\udfb4\udbab\udebc\udaa4\udc21\udab9\udfb1",
        51, 65585, -714399564, 110055415065680262L, -44422L, true, true, (char) 43955, (char) 25712,
        Double.longBitsToDouble(0x3fb0cd18fc221888L), Double.longBitsToDouble(0x3fce828a71e728f0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 3, 5, "\udbbc\udfe2\ud995\ude24\uda93\uddc6\ud9c3\uddaf\ud9ff\udc5a\ud8ea\ude0b\ud9a5\udd1d\udb84\udcdf\ud960\udd20\ud8b2\udcf6\ud987\udf50\udbe6\udff7\udabd\udd6c\uda5d\udd69\ud851\udcef\udbe0\udea3\udb1f\udfcb\ud893\udc57", "\ua364\ua519\u8def\ua280\ub653\u0504", "\uda9b\udc21\udb0c\uddb6\uda67\udf95\udbed\udd4d\ud86c\udf74\uda84\udcbe\ud9e4\udfb4\udbab\udebc\udaa4\udc21\udab9\udfb1\ud85d\uddf8\udbb4\ude88\uda43\ude31\ub6e8\udb1e\udf71\u95a7\ud9a3\udf54\ud886\ude4c\udaec\udf37\uda36\uddb4",
        12, 15962, 1125221443, 1464680896115012852L, -75881L, true, false, (char) 31810, (char) 31936,
        Double.longBitsToDouble(0x3fbb02073000b7a0L), Double.longBitsToDouble(0x3fc4d3beb520864cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 1, 0, 0, 0, "\udbbc\udfe2\ud995\ude24\uda93\uddc6\ud9c3\uddaf\ud9ff\udc5a\ud8ea\ude0b\ud9a5\udd1d\udb84\udcdf\ud960\udd20\ud8b2\udcf6\ud987\udf50\udbe6\udff7\udabd\udd6c\uda5d\udd69\ud851\udcef\udbe0\udea3\udb1f\udfcb\ud972\udc81", "\ua364\uc74c\u0507", "\udb5e\udce3\ud84d\ude65\udaae\udf60\uda9b\udc21\udb0c\uddb6\udb3a\udebe\udbe1\uddfd\ud86c\udf74\uda84\udcbe\ud9e4\udfb4\udbab\udebc\udaa4\udc21\udab9\udfb1",
        51, 65585, -714399564, 110055415065680262L, -44422L, true, true, (char) 43955, (char) 25712,
        Double.longBitsToDouble(0x3fb0cd18fc221888L), Double.longBitsToDouble(0x3fce828a71e728f0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 1, 4, 3, 5, "\udbbc\udfe2\ud995\ude24\uda93\uddc6\ud9c3\uddaf\ud9ff\udc5a\ud8ea\ude0b\ud9a5\udd1d\udb84\udcdf\ud960\udd20\ud8b2\udcf6\ud987\udf50\udbe6\udff7\udabd\udd6c\uda5d\udd69\ud851\udcef\udbe0\udea3\udb1f\udfcb\ud972\udc81", "\ua364\uc74c\u0507", "\udb5e\udce3\ud84d\ude65\udaae\udf60\uda9b\udc21\udb0c\uddb6\udb3a\udebe\udbe1\uddfd\ud86c\udf74\uda84\udcbe\ud9a6\udcc0\udbab\udebc\udaa4\udc21\udab9\udfb1",
        51, 32087, 210537131, -6235303932032640634L, -44422L, true, true, (char) 50963, (char) 25712,
        Double.longBitsToDouble(0x3fb0cd18fc221888L), Double.longBitsToDouble(0x3fce828a71e728f0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 3, 0, "\uda54\udc70\ud8d8\udf65\ud883\udd9d\ud96d\udda9\uda0d\udc21\udb5c\udce4\udb07\uddbd\udb84\udcdf\ud960\udd20\ud8b2\udcf6\ud987\udf50\udbe6\udff7\ud98f\udff5\uda5d\uddb7\ud937\uddc2\ud849\udebd\udbeb\udf6c\ud972\udcdc", "\u33b1\u53df\u0881", "\udb27\udd0c\udb3d\udedd\uda3f\udc1e\udabe\udfdd\udb0c\uddb6\udb3a\udebe\udbda\ude78\ud86c\udf74\ud8fb\udc14\ud9e4\udfb9\ud857\uddb1\ucc1f\udab9\udfb1\ud898\udd94\udbb4\udeb0\uda43\ude31\ud9c4\udeec\ubc90\udbdf\ude5b\ud940\ude65\ud886\ude36\udb4d\udce7\udb3d\udd4e\udbc9\ude83\ud9b3\udd7b\udaca\udcba\udbc0\ude7d\udb7d\udec8\ud83a\udd13\uda68\udd74\ud8e6\udc85\ud936\udcb6\ud887\uddb4\uda0d\udcca\ud91f\udfc9",
        -1, 37398, 730132221, -4337873593576482641L, 84078L, true, true, (char) 18560, (char) 62673,
        Double.longBitsToDouble(0x3f9ffa80f433e940L), Double.longBitsToDouble(0x3fe841c9b5a3a0edL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.CheckGlobalThis:@?\0121=java.lang.Boolean:false |this=com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 2, 0, 0, 5, "\udbb9\udde2\uda54\udeb4\uda93\ude4b\ud9c3\uddaf\ud9ff\udc5a\ud8ea\ude0b\ud9a5\udd1d\udb84\udcdf\ud960\udd20\ud96f\udcac\uda41\uded1\udbe6\udff7\uda14\uded7\uda5d\udd69\ud851\udcef\udbe0\udea3\ud841\udf54\ud82b\udcfc", "\ua364\uc74c\u0507\uce43\ub59f\u0504\u4936", "\udb0c\uddb6",
        21, 3347, -175122503, -1768891897636891411L, 36722L, false, false, (char) 43037, (char) 46632,
        Double.longBitsToDouble(0x3fc693bcbb4755acL), Double.longBitsToDouble(0x3fd8601865b84132L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 5, "\ud9fe\udfe3\ud84d\udf21\uda38\udfdf\ud9f6\udc15\udb03\udc39\udb6d\udc30\ud835\ude03\udb84\udc4c\ud960\udd20\ud89a\uddf6\ud987\udf50\ud8c4\udc05\uda5a\udc23\uda4a\udd69\ud851\udcef\ud81d\udea2\uda62\udeaf\udb06\udf9e", "\ua364\uc74c\u0507\uce43\ub59f\u0504\u4936\u2820\uc314\u5fb9\u0fba\uadd2\u49de\ub8f2", "\uda41\ude2f\udac1\udce6\ud929\udcff\u0d59\ud80c\udf0d\ub684\udb1e\udf71\uda66\udc47\ud955\udc96\uda16\udcc3\udbc8\udfe8\uda97\udec0\udaee\udf20\ud93e\udc48\udb4a\udc36\udac0\udc10\udb86\uddc8\ud9b2\udfcf\udb00\udff8\udb1a\udfef\udbce\uddf3\u616e\udb96\udd74\ud8b2\udeca\ub9cf\udbf8\udd63\udbf2\udc86\ud9f2\udd83\ud847\ude86\udaef\udced\ud9c1\udf92\udaed\udee9\ud876\udef7",
        45, 32856, -1024044822, 8856071734228468118L, 23470L, false, false, (char) 43002, (char) 19414,
        Double.longBitsToDouble(0x3fe08af401bf8e11L), Double.longBitsToDouble(0x3fd58e210a2e9366L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\0121=new com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udbbc\udfe2\ud995\ude24\uda76\uddd7\udbde\udf26\ud9ff\udc5a\ud8ea\ude0b\ud9a5\udd1d\udb84\udcdf\ud960\udd20\ud904\udcff\ud987\udf50\udbe6\udff7\udabd\udd6c\uda5d\udd69\ud851\udcef\ud80a\ude98\udb1f\udfcb\ud972\udc81", "\u8251\u45a5\u0507\uce43\ub59f\u04d0\u4936\u0626\uc312\u5fb9\u0fba\uadd2\u49de\u8126\u6d2b\u3145\u1ea2", "\udbb4\ude88",
        26, 70273, 546904454, -3154143871513587869L, -44422L, true, true, (char) 43955, (char) 25712,
        Double.longBitsToDouble(0x3fb0cd18fc221888L), Double.longBitsToDouble(0x3fce828a71e728f0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 1, 4, 3, 1, "\udbbc\udfe2\ud995\ude24\uda93\uddc6\ud9c3\uddaf\ud9ff\udc5a\ud8ea\ude0b", "\u8e92\u5c9b\u97d8\u3bfb\uc774\ub395", "\udb1f\udfcb\ud972\udc81\uda1b\udfc0\ud963\udd53\ud8af\udfb0\ud9e0\udc74\ud987\udc0b\udad8\ude76\ud8d9\udd9a\udb5e\udce3\ud84d\ude65\udaae\udf60\uda9b\udc21\udb0c\uddb6\udb3a\udebe\udbe1\uddfd\ud86c\udf74\uda84\udcbe\ud9e4\udfb4\udbab\udebc\udaa4\udc21\udab9\udfb1\ud85d\uddf8\udbb4\ude88\uda43\ude31\ub6e8\udb1e\udf71\uda66\udc47\ud940\ude76\ud886\ude36\udaec\udf37\uda36\uddb4",
        12, 15962, 1125221443, 1464680896115012852L, -68215L, false, false, (char) 16885, (char) 4162,
        Double.longBitsToDouble(0x3fddf7d24984f936L), Double.longBitsToDouble(0x3fdabe27e97572e2L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.CheckGlobalThis|shouldReportThis|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckGlobalThis:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
    "M|com.google.javascript.jscomp.CheckGlobalThis|shouldTraverse|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckGlobalThis:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
    "M|com.google.javascript.jscomp.CheckGlobalThis|getFunctionJsDocInfo|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckGlobalThis:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
    "M|com.google.javascript.jscomp.CheckGlobalThis|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckGlobalThis:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
    "C|com.google.javascript.jscomp.CheckGlobalThis|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
    "M|com.google.javascript.jscomp.CheckGlobalThis|shouldReportThis|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckGlobalThis:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
    "M|com.google.javascript.jscomp.CheckGlobalThis|shouldTraverse|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckGlobalThis:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
