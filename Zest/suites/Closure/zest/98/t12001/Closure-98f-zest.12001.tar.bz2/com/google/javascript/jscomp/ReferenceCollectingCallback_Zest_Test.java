package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class ReferenceCollectingCallback_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 8, "\ud9ea\udf66\ud950\ude84\udb43\uddaf\uda10\udf9c\uda9c\udf82\ud844\ude57\u0e93\udabf\udec6\udb2b\udeb2\udac5\udc62\ud984\ude7f\ud8a3\uded9\ud825\udd8d\udbfd\udc46\u79b9\udbcc\udfd9", "\u370b\u3f0f\u64e5\u7528\u3c1d\u8462\u5cc1", "\udbd5\udd01",
        44, 1209, 519809149, -4638399325833396361L, -42065L, true, false, (char) 56752, (char) 1692,
        Double.longBitsToDouble(0x3fe96c54ebfc622eL), Double.longBitsToDouble(0x3fc54aa9e6955214L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 8, "\ud9ea\udf66\ud950\ude84\udb43\uddaf\uda10\udf9c\uda9c\udf82\ud844\ude57\u0e93\udabf\udec6\udb2b\udeb2\udac5\udc62\ud984\ude7f\ud8a3\uded9\ud825\udd8d\udbfd\udc46\u79b9\udbcc\udfd9", "\u370b\u3f0f\u64e5\u7528\u3c1d\u8462\u5cc1", "\udbd5\udd01",
        44, 1209, 519809149, -4638399325833396361L, -42065L, true, false, (char) 28760, (char) 12275,
        Double.longBitsToDouble(0x3fe96c54ebfc622eL), Double.longBitsToDouble(0x3fc54aa9e6955214L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 4, "\ud9ea\udf66\ud950\ude84\udb43\uddaf\uda10\udf9c\ud899\udda1\ud8be\udcfc\ud986\udcbb\udabf\udec6\udb2b\udeb2\udac5\udc62\ud984\ude7f\ud8a3\uded9\ud825\udd8d\udbfd\udc46\u79b9\uda8c\udd18", "\u370b\u3f0f\u79a3\u7558\u3c1d\u8462\u5cc1", "\ud8ff\udff9",
        15, 1209, -1998955907, -7815078178869471827L, -23329L, false, false, (char) 56752, (char) 1692,
        Double.longBitsToDouble(0x3fef933523fc622eL), Double.longBitsToDouble(0x3fc54aa9e6955214L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 8, "\ud9ea\udf66\ud950\ude84\udb43\uddaf\uda10\udf9c\uda9c\udf82\ud844\ude57\u0e93\udabf\udec6\udb2b\udeb2\udac5\udc62\ud984\ude7f\ud8a3\uded9\ud825\udd8d\udbfd\udc46\u79b9\udbcc\udfd9", "\u370b\u3f0f\u64e5\u7528\u3c1d\u8462\u5cc1", "\udbd5\udd01",
        44, 1209, 519809149, -4638399325833396361L, 21935L, true, false, (char) 56752, (char) 1692,
        Double.longBitsToDouble(0x3fe96c54ebfc622eL), Double.longBitsToDouble(0x3fc54aa9e6955214L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 7, 4, "\ud9ea\udf66\ud950\ude84\udb43\uddaf\uda10\udf9c\uda9c\udf82\ud844\ude57\uda51\ude99\udabf\udec6\udb2b\udeb2\udac5\udc62\ud984\ude7f\ud8a3\uded9\udabf\udeba\udbfd\udc46\u79b9\udbcc\udfd9", "\u370b\u3f0f\u64e5\u7528\u0c43\u8462\u5cc1", "\udbd5\udd01",
        25, 69820, 519809149, -4638399325833396361L, -42065L, true, false, (char) 21137, (char) 60720,
        Double.longBitsToDouble(0x3fe96c54ebfc622eL), Double.longBitsToDouble(0x3fc54aa9e6955214L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=void |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\012",
        Z.run(T, 2, 3, 0, 3, "\ud87d\udc56\ud950\ude84\udb43\uddaf\uda10\udf9c\uda9c\udf82\ud844\ude57\u0e93\udabf\udec6\udb2b\udeb2\udac5\udc62\ud926\udd10\u66e0\ud9a5\udc4d\ud8ff\uddeb\ud8de\udc31\uda84\uddc1", "\u370b\u3d10\u64e5\u0cdc\u8d39\ud205\u3412", "\udbd5\udd01",
        44, 1209, 519809149, -1020319978921786052L, -42065L, true, false, (char) 56752, (char) 1692,
        Double.longBitsToDouble(0x3fe96c54ebfc622eL), Double.longBitsToDouble(0x3fc54aa9e6955214L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 6, "\ud9db\uddb8\ud950\ude84\udb43\uddaf", "\u9d6c\u0cc7\u9b82", "\ud984\ude7f\ud8a3\uded9\ud825\udd8d\udbfd\udc46\u79b9\udb65\udd25",
        4, 50819, 908455646, -6323582666136624993L, -44225L, false, false, (char) 30499, (char) 33062,
        Double.longBitsToDouble(0x3fe0ec201733e9c9L), Double.longBitsToDouble(0x3fe103147b2918f6L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 1, "\ud9ea\udf66\ud950\ude84\udb78\udc93\ud9ee\ude9c\uda9c\udf82\ud844\ude57\u0e93\udabf\udec6\udb3e\udfaa\udac5\udc62\ud984\ude7f\uda12\uddb0\ud830\ude8d\udbfd\udc46\u79b9\udbbf\udf13", "\u370b\u3f0f\u64e5\ud6d9\u9227", "\ud9bf\uddba\udb7e\udccd\udbd5\udd01\uda69\udf98\udb41\udfcc\ud86e\udf7e\ud85b\udf5d\ud85d\ude24\ud933\uddb0\udbfd\udeab\ud992\ude7d\uda46\udc03\ud81c\udd37\ud8c0\udcf6",
        36, 68746, 202002853, 4475249883092786546L, -15726L, true, false, (char) 62617, (char) 12299,
        Double.longBitsToDouble(0x3fe37a9c697c3632L), Double.longBitsToDouble(0x3fe0168290dafcf1L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=void |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\012",
        Z.run(T, 2, 0, 0, 8, "\ud9ea\udf66\ud950\ude84\udb43\uddaf\uda10\udf9c\uda9c\udf82\ud844\ude57\u0e93\udabf\udec6\udaa5\udd47\uda3d\udd23\ud9a9\udc37\ud89c\udc31\ud895\udc06\udbfd\udc46\u79b9\udbcc\udfd9", "\u3693\u3f0f\u64e5\u7528\u3c1d\u8462\u5cc1", "\udbd5\udd01",
        44, 1209, 519809149, -4638399325833396361L, -42065L, true, false, (char) 56752, (char) 1692,
        Double.longBitsToDouble(0x3fe96c54ebfc622eL), Double.longBitsToDouble(0x3fc54aa9e6955214L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=void |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\012",
        Z.run(T, 2, 8, 0, 8, "\ud9ea\udf66\ud950\ude84\udb02\udd8f\udb7e\udf4a\uda9d\ude6d\ud844\ude57\u0e93\ud82c\uddd5\udbbb\udefa\udb6e\udd00\udbda\udd01\udb2f\udf80\udb18\udca8\ud948\udf22\ud9a0\uded6\udbc7\uddf1", "\u370b\u3f0f\u64e5\u7528\u3c1d\u8462\u5cc1", "\ud806\udc49",
        44, 1209, 704358525, -4638392417395277961L, 15631L, false, false, (char) 30665, (char) 9770,
        Double.longBitsToDouble(0x3fc54aa9e6955214L), Double.longBitsToDouble(0x3fa7326fa711b650L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=void |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\012",
        Z.run(T, 2, 3, 0, 8, "\ud9ea\udef9\ud950\ude84\udb43\uddafq\uda9c\udf82\ud844\ude57\u03b1\ud8f2\udf98\udb2b\udeb2\u00ba\uda4d\udf0c\ud8a3\uded9\ud825\udd8d\udbfd\udc46\u79b9\000", "\u370b\u3f0f\u64e5\u7528\u3c1d\u8462\u00e7", "\udbd5\udd01",
        44, 59201, 0, 26813480828928L, -100000L, true, false, (char) 56657, (char) 1692,
        Double.longBitsToDouble(0x3ec3aff000000000L), Double.longBitsToDouble(0x3f35400d2aa42800L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 0, "\ud9b2\uddf9\ud950\uddcc\000\ud840\ude1f\uda9c\ude85\ud844\ude57\u0e93\udabf\udec6\ua131\000\udb36\udf1b\ud8a3\uded9\u08dd\000\000\000", "\u370b\u875b\u64e5\u7528\u3c1d\u8380\037", "",
        12, 84904, -956568791, 2232563294036629603L, 16770L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e40761408000000L), Double.longBitsToDouble(0x3fc58cd5ae7496b4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 8, "\ud9ea\udf66\ud950\ude84\udb43\uddaf\ue971\uda8b\udf85\ud844\ude57\u00b1\000\udb03\udd81\udac5\udc62\udb6a\ude72\ud8a3\uded9\u00dd\udbfd\udc1b\u79b9\uc9cd", "\u362d\u3f0f\u64e5\u7528\u3c1d\u8462\u5cc1", "\udbd5\udd01",
        -5, -1000, 0, -4638399751040008192L, -42065L, true, false, (char) 56752, (char) 1692,
        Double.longBitsToDouble(0x3fe80454ebfc622eL), Double.longBitsToDouble(0x3fc54aa9e6955214L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=null |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\012",
        Z.run(T, 2, 3, 3, 8, "\ud9ea\udf66\ud950\ude84\u6dbc\uda10\udf9c\uda0e\ude3a\uda86\udd99\u0e93\udabf\udec6\udb2b\udeb2\ud805\udf22\ud87d\uddf1\ud881\udc96\ud825\udd8d\udbfd\udc46\u79b9\udbcc\udfd9", "\u370b\u3f0f\u64e5\u8786\u127b\u1b81\u5cc1", "\udbd5\udd01",
        44, 1209, 519809149, -4638399325833396361L, -42065L, true, false, (char) 56752, (char) 1692,
        Double.longBitsToDouble(0x3fe96c54ebfc622eL), Double.longBitsToDouble(0x3fc54aa9e6955214L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 8, "\ud9c8\udc17", "\u8983\uba54", "\udabf\udec6\udb2b\udeb2\udace\udd59\udb9c\udeb1\ud8a3\uded9\ud825\udd0b\udbfd\udc46\u79b9\uda8c\udd18\ud803\udd9e\ud915\udc11\udb7b\udc31\udaa9\udecd\ud848\udc46\udaa9\udd8c\ud8bb\ude01\udbdb\ude94\ud962\udcf8\udab6\udc77\ud98c\udde1\ud8ff\udff9\udbd5\udef0\ud841\udc6c\ud9ca\udf77\udb07\udd68",
        33, 95781, 815868799, -6818476223069799343L, 75090L, false, true, (char) 24538, (char) 46237,
        Double.longBitsToDouble(0x3faaca511a082480L), Double.longBitsToDouble(0x3fd3d0be3d08a466L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=new com.google.javascript.jscomp.ReferenceCollectingCallback:@?\012",
        Z.run(T, 2, 8, 8, 1, "\ud9ea\udf57\ud950\ude84\udb5e\udeaf\uda10\udf9c\uda9c\udf82\ud844\udedb\uda51\ude99\ud969\udf3c\u9380\ud899\udf83\udb69\udeee\ud8a3\uded9\udabf\udeba\udbfd\udc46\u79b9\udbcc\udfd9\ud93a\ude14\ud915\udc11\udb9e\ude0e\ub9e6\udb00\udf43\udb84\udecf\uda7b\udfc1\udbdb\ude6b\ud9d0\udfee\ud964\ude2f\udb7e\udccd\udba3\udf01\udb5d\udf7c\ud870\ude07\ud992\ude50", "\u2c96\uc968\ud39a\u246a\u3dd3\u6a3b\u5ad3\u5051\uc4c1\u660e\u1905\ubd50\u180b\u27e9\u780f\u7826\u6a84\u1dfc\u93bd\ud04f\u83ae\u5152\u6fcb", "\ud919\udd9b\udb48\udc0d\udb97\udcdb\uda8c\udd51\ud91e\udf4f\ud80a\udc4d\ud87c\udd52\udac6\udd05\ud88a\udf9a\ud8ca\udc61",
        57, 7996, 734241801, -3276346175920839194L, -96730L, false, true, (char) 46725, (char) 65285,
        Double.longBitsToDouble(0x3fe2c62b2752da6bL), Double.longBitsToDouble(0x3fe80e48ef240822L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 5, "\ud9ea\udf66\ud950\ude84\udb43\uddaf\u6c42\uda9f\ude1c\ud90a\udc68\u0e93\udabf\udec6\udb2b\udeb2\udac5\udc62\ud984\ude7f\ud8a3\uded9\uda3e\uddfe\udaea\uddbe\u79b9\udbcc\udfd9", "\u4f0a\u96fe\u64e5\u959c\u3c1d\u8462\u5cc1", "\udbbb\udf7a",
        44, 1209, 1563863165, 7621381896278769566L, -42065L, true, false, (char) 59971, (char) 54495,
        Double.longBitsToDouble(0x3fe96c54eb66fc15L), Double.longBitsToDouble(0x3fc54aa9e6955214L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=void |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\012",
        Z.run(T, 2, 3, 0, 5, "\udba0\uddc2\ud93a\udca0\udb43\uddafq\uda9c\udf82\ud844\ude57\ud9bf\ude90\ud9a6\ude8b\udb2b\udeb2\u00ba\uda4d\udf0c\ud8a3\uded9\ud825\udd8d\udbfd\udc46\u79b9\udbb8\udf5b", "\u370b\u3f0f\u64e5\u7528\u3c1d\u8462\u00e7\u906e\ua50f\ucc03\u6bb6\u132a\000\u1863\000\000\u82f6\ub779\u665d\u00dd\000\u00bb\u5cc7\u6903\ubf6c\u553b\u0c36", "\udb6f\udd51\uda0d\ude38\ud8e8\udd19\ud8f7\ude04",
        51, 47181, 669488085, -7393344738331160944L, -29199L, false, false, (char) 15663, (char) 62083,
        Double.longBitsToDouble(0x3fe536a9f3193d84L), Double.longBitsToDouble(0x3fdf366c344e00c6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|addReference|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.jscomp.Scope$Var,com.google.javascript.jscomp.ReferenceCollectingCallback$Reference|new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|enterScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|exitScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|getReferenceCollection|com.google.javascript.jscomp.Scope$Var|new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|isBlockBoundary|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|shouldTraverse|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "C|com.google.javascript.jscomp.ReferenceCollectingCallback|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "C|com.google.javascript.jscomp.ReferenceCollectingCallback|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior,com.google.common.base.Predicate",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
