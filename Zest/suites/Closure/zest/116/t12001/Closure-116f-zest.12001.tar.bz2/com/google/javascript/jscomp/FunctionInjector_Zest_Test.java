package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class FunctionInjector_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 6, "\uaed4\ud884\ude0c\uda61\ude14", "\u4acd\u7e7d\ua815\u575d\u0d09\u7725\u9abe\u7dab\u21ba\uaa02\u90ba\u31e0\u178a", "\uda80\udf43\udae9\udd1a\udb51\udc3b\udb6e\uddd7\udba9\udebe",
        3, 84094, -286843759, 80366621458596333L, 55789L, false, false, (char) 3847, (char) 7505,
        Double.longBitsToDouble(0x3fd994553b8aa65cL), Double.longBitsToDouble(0x3fbbe0ab1e28e4e8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 6, "\uaed4\ud884\ude0c\uda61\ude14", "\u4acd\u7e7d\ua815\u575d\u0d09\u2a0c\u9abe\u7dab\u21ba\uaa02\u90ba\u31e0\u178a", "\uda80\udf43\udae9\udd1a\udb51\udc3b\udb6e\uddd7\udba9\udebe",
        3, 84094, -286843759, 80366621458596333L, 55789L, false, false, (char) 3847, (char) 7505,
        Double.longBitsToDouble(0x3fd994553b8aa65cL), Double.longBitsToDouble(0x3fbbe0ab1e28e4e8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 3, 6, "\uaed4\ud884\ude0c\uda61\ude14", "\u4acd\u7e7d\ua815\u575d\u0d09\u7725\u9abe\u7dab\u21ba\uaa02\u90ba\u31e0\u178a", "\uda80\udf43\udae9\udd1a\udb51\udc3b\udb6e\uddd7\udba9\udebe",
        45, 40448, -286843759, 80366621458596333L, 55789L, false, false, (char) 3847, (char) 7505,
        Double.longBitsToDouble(0x3fd994553b8aa65cL), Double.longBitsToDouble(0x3fbbe0ab1e28e4e8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 2, 6, "\ud95a\udf0c\ud884\ude0c\uda61\ude14", "\u4acd\u7e7d\ua815\u2fc1\u0cff\u7725\u9abe\u7dab\u21ba\uaa02\u90ba\u31e0\u178a", "\uda80\udf43\udae9\udd1a\udb51\udc3b\udb6e\uddd7\udba9\udebe",
        3, 84094, -286843759, 80366621458596333L, 55789L, false, false, (char) 3847, (char) 7505,
        Double.longBitsToDouble(0x3fd994553b8aa65cL), Double.longBitsToDouble(0x3fd78d8f2938393aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 2, 13, "\uaed4\ud884\ude0c\udb9a\udcf1", "\u771d\u7e21\u356c\u40dc\u0d09\u7725\u9abe\u7dab\u2145\uaa02\u90ba\u31e0\u178a", "\uda80\udf43\uda1e\udf00\ud8a4\ude26\udb67\udd2c\udba9\udebe",
        3, 5022, -775668684, 6042345276282260738L, -32383L, false, false, (char) 50923, (char) 35059,
        Double.longBitsToDouble(0x3fbbe0ab1830e4e8L), Double.longBitsToDouble(0x3fec7d5ff13e20d8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 2, 4, "\uaecf\ud884\ude0c\uda61\ude14\ud8bd\udcb3\uda58\uded3\ud92d\udf50\ud82b\uddc4\udaaa\uddf1\ud9c4\udf6d", "\u9abe\u326d\u5a96\uaa02\u90ba", "\ud80b\udee2\udb46\uddd1\uda80\udfde\udae9\udd1a\udb51\udc3b\udb6e\uddd7\udba9\udebe\ud86b\udc96",
        19, 31824, 18711812, 3735315795758245539L, -65230L, true, true, (char) 35059, (char) 13083,
        Double.longBitsToDouble(0x3f981c9d6f66e880L), Double.longBitsToDouble(0x3fef06e42b3c7b81L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 2, 6, "\uaed4\ud884\ude0c\uda61\ude14", "\u4acd\u7e7d\ua815\u575d\u0d09\u7725\u9abe\u7dab\u21ba\uaa02\u90ba\u31e0\u178a", "\uda80\udf43\udae9\udd1a\udb51\udc3b\udb6e\uddd7\udba9\udebe",
        3, 84094, -286843759, 80366621458596333L, 55789L, false, false, (char) 3847, (char) 7505,
        Double.longBitsToDouble(0x3fd994553b8aa65cL), Double.longBitsToDouble(0x3fbbe0ab1e28e4e8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 5, 2, "\udb58\udc2a\ud9c8\udeb3\uda61\ude66\ud85b\ude83\ud946\udc58\ud92d\udf50\ud82b\uddc4\udaaa\uddf1\ud9c4\udf6d\ud825\ude54\ud825\udc48", "\u21ba\u68c4\u6b99\u31e0\u178a\u2a15\u2efa\u0e4a\u1b3b", "\ud946\ude2e\udb9e\udf7e\ud92c\udda2\ud804\udf8f\udb43\udd14\ud850\udc44\udac4\udfeb\ud81f\udc5c\ud8e8\udc3c\uda7e\uddc4",
        19, 47015, -2102643259, -3503887994784941178L, -30320L, true, true, (char) 48444, (char) 55981,
        Double.longBitsToDouble(0x3fdc969ada7c852eL), Double.longBitsToDouble(0x3fef4f6d0143e622L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 9, 13, "\uaed4\ud884\ude0c\udb9a\udcf1", "\u771d\u7e21\u356c\u40dc\u0d09\u7725\u9abe\u7e21\u2145\uaa02\u90ba\u31e0\u5772", "\uda80\udf43\uda1e\udf00\ud8a4\ude26\udb67\udd2c\uda7e\udfaa",
        0, 5022, -775668684, 6042345276282260738L, -32383L, false, false, (char) 50923, (char) 35059,
        Double.longBitsToDouble(0x3fbbe0ab3470e4e8L), Double.longBitsToDouble(0x3fec7d5b913e20d8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 2, 13, "\uaed4\ud884\ude0c\udb9a\udcf1", "\u771d\u7e21\u356c\u40dc\u0d09\ud5aa\u6906\u7dab\u2145\uaa02\u90ba\u31e0\u178a", "\uda80\udf43\uda1e\udf00\ud8a4\ude26\udb67\udd2c\udba9\udebe",
        3, 5022, -775668684, 6042345276282260738L, -32383L, false, false, (char) 50923, (char) 35059,
        Double.longBitsToDouble(0x3fbbe0ab2391ece8L), Double.longBitsToDouble(0x3fec7d5d913e20d8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 6, "\uaed4\ud884\ude0c\uda61\ude14", "\u4acd\u7e7d\ua815\u575d\u0d09\u7725\u9abe\u7dab\u21ba\uaa02\u90ba\u31e0\u178a", "\uda80\udf43\udae9\udd1a\udb51\udc3b\udb6e\uddd7\udba9\udebe",
        3, 84094, -286843759, 80366621458596333L, -8301L, false, false, (char) 3847, (char) 7505,
        Double.longBitsToDouble(0x3fd994553b8aa65cL), Double.longBitsToDouble(0x3fbbe0ab1e28e4e8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.FunctionInjector|canInlineReferenceDirectly|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FunctionInjector:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier,boolean,boolean,boolean",
    "M|com.google.javascript.jscomp.FunctionInjector|callMeetsBlockInliningRequirements|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,java.util.Set|new:com.google.javascript.jscomp.FunctionInjector:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier,boolean,boolean,boolean",
    "M|com.google.javascript.jscomp.FunctionInjector|canInlineReferenceAsStatementBlock|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,java.util.Set|new:com.google.javascript.jscomp.FunctionInjector:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier,boolean,boolean,boolean",
    "M|com.google.javascript.jscomp.FunctionInjector|canInlineReferenceToFunction|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,java.util.Set,com.google.javascript.jscomp.FunctionInjector$InliningMode,boolean,boolean|new:com.google.javascript.jscomp.FunctionInjector:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier,boolean,boolean,boolean",
    "M|com.google.javascript.jscomp.FunctionInjector|classifyCallSite|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FunctionInjector:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier,boolean,boolean,boolean",
    "M|com.google.javascript.jscomp.FunctionInjector|doesFunctionMeetMinimumRequirements|java.lang.String,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FunctionInjector:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier,boolean,boolean,boolean",
    "M|com.google.javascript.jscomp.FunctionInjector|doesLowerCost|com.google.javascript.rhino.Node,int,int,int,int,int,boolean|new:com.google.javascript.jscomp.FunctionInjector:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier,boolean,boolean,boolean",
    "M|com.google.javascript.jscomp.FunctionInjector|estimateCallCost|com.google.javascript.rhino.Node,boolean|static",
    "M|com.google.javascript.jscomp.FunctionInjector|getDecomposer||new:com.google.javascript.jscomp.FunctionInjector:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier,boolean,boolean,boolean",
    "M|com.google.javascript.jscomp.FunctionInjector|inline|com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.rhino.Node,com.google.javascript.jscomp.FunctionInjector$InliningMode|new:com.google.javascript.jscomp.FunctionInjector:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier,boolean,boolean,boolean",
    "M|com.google.javascript.jscomp.FunctionInjector|inlineCostDelta|com.google.javascript.rhino.Node,java.util.Set,com.google.javascript.jscomp.FunctionInjector$InliningMode|static",
    "M|com.google.javascript.jscomp.FunctionInjector|inlineFunction|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,java.lang.String|new:com.google.javascript.jscomp.FunctionInjector:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier,boolean,boolean,boolean",
    "M|com.google.javascript.jscomp.FunctionInjector|inlineReturnValue|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FunctionInjector:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier,boolean,boolean,boolean",
    "M|com.google.javascript.jscomp.FunctionInjector|inliningLowersCost|com.google.javascript.jscomp.JSModule,com.google.javascript.rhino.Node,java.util.Collection,java.util.Set,boolean,boolean|new:com.google.javascript.jscomp.FunctionInjector:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier,boolean,boolean,boolean",
    "M|com.google.javascript.jscomp.FunctionInjector|isDirectCallNodeReplacementPossible|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FunctionInjector:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier,boolean,boolean,boolean",
    "M|com.google.javascript.jscomp.FunctionInjector|isSupportedCallType|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FunctionInjector:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier,boolean,boolean,boolean",
    "M|com.google.javascript.jscomp.FunctionInjector|canInlineReferenceDirectly|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FunctionInjector:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier,boolean,boolean,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
