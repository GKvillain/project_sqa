package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class LightweightMessageFormatter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 5, 6, "\uda75\udf73\ud822\udc3d\udbb2\ude2f\uda44\udf59", "\ua264\u2e67\u02f5\ucd50\u920eW\u0494\u7dd0", "\udb31\udc15\u5873\ud85c\udf4b\uda0c\udcd4\ud97c\udd47\ud8a5\ude72\u2b32\ua4cd\uda13\ude0a\udb3b\udf4d\ud873\udf9f\ud863\ude59",
        29, 82386, 1059816002, 5642256966577690934L, -62743L, false, false, (char) 33103, (char) 8602,
        Double.longBitsToDouble(0x3fd277939fb0a89eL), Double.longBitsToDouble(0x3fee41b0eaad4c72L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 5, 6, "\uda75\udf73\ud822\udc3d\udbb2\ude2f\uda44\udf59", "\ua1ca\u2e67\u02f5\ucd50\u920eW\u0494\u7dd0", "\udb31\udc15\u5873\ud85c\udf4b\uda0c\udcd4\ud971\udc47\ud8a5\ude72\u2b32\ua4cd\uda13\ude0a\udb3b\udf4d\ud873\udf9f\ud863\ude59",
        29, 82386, 1059816002, 5642256966577690934L, -62743L, false, false, (char) 33103, (char) 48243,
        Double.longBitsToDouble(0x3fd1b80c81b0a89eL), Double.longBitsToDouble(0x3fc3ccdb89f44aa8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 5, 6, "\uda75\udf73\ud822\udc3d\udbb2\ude2f\uda44\udf59", "\ua264\u2e67\u02f5\ucd50\u920e\ucf15\u0494\u9eb7", "\udb31\udc15\u5873\ud85c\udf4b\uda0c\udcd4\ud97c\udd47\ud8a5\ude72\u2b32\ua4cd\uda13\ude0a\ud86d\udc67\ud8a4\udc21\ud863\ude59",
        29, 45266, 1129424612, 5642429920615733558L, -62743L, false, false, (char) 33103, (char) 8602,
        Double.longBitsToDouble(0x3fd657939fb0a89eL), Double.longBitsToDouble(0x3fc326c3aab531c8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 6, "\uda75\udf73\000\000\uda44\uded0", "\ua264\u2e67\u02f5\ucd50\u920eW\u0494\u7dd0", "\udb31\udc15\u5873\ud85c\udf4b\uda0c\udcd4\ud97c\udd47\ud8a5\ude72\u2b32\ua4cd\uda13\ude0a\udb3b\udf4d\ud873\udf9f\ud863\ude59",
        29, 30482, 1059816002, 5642256966577690934L, -62743L, false, false, (char) 33103, (char) 8602,
        Double.longBitsToDouble(0x3fd277939fb0a89eL), Double.longBitsToDouble(0x3fee41b0eaad4c72L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.LightweightMessageFormatter:@?\012",
        Z.run(T, 1, 6, 6, 4, "\uda75\udf73\ud822\udc3d\udbb2\ude2f\uda44\udf59", "\ua264\u2e67\u02f5\ucd50\u920eW\u0494\u0bad", "\udb31\udc15\u5873\ud85c\udf4b\uda0c\udcd4\udb21\udea6\ud929\ude4f\u2ae0\ua4cd\uda1b\udfe6\udb3b\udf4d\ud873\udf9f\ud863\ude59",
        29, 82386, 1059816002, 5642256966577690934L, -62743L, false, false, (char) 33103, (char) 8602,
        Double.longBitsToDouble(0x3fd277939fb0a89eL), Double.longBitsToDouble(0x3fee41b0eaad4c72L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 5, 6, "\uda2e\udecf\ud904\udec9\ud94a\udd94\uda44\udf59", "\ua264\u2e67\u02f5\u901e\u6803\026\u0494\u7dd0\ubb6a", "\u5873\ud85c\udf4b\uda0c\udcd4\ud8a4\udfbd\ud806\udd6e\u2b32\ua4cd\uda13\ude0a",
        -5, 55921, 1690501225, -1211878972008465670L, -13263L, false, true, (char) 59114, (char) 57138,
        Double.longBitsToDouble(0x3fa8343618974310L), Double.longBitsToDouble(0x3fc9dc8f8d2ef810L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 6, "\udac2\udc71\udba7\udc81\udb60\udc27\udb2b\udc2c", "\ua264", "\ud996\udd2b\uda6a\udf57\ud86b\udca9",
        57, 82423, -1092857697, 5891855801171563466L, 339L, false, true, (char) 18128, (char) 47719,
        Double.longBitsToDouble(0x3fdea19ff9142b7aL), Double.longBitsToDouble(0x3fd850471a321034L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.LightweightMessageFormatter:@?\012",
        Z.run(T, 1, 3, 6, 6, "\uda75\udf73\ud822\udc3d\udbb2\ude2f\uda44\udf59", "\u3afd\u8bb1\u7980\ucd50\u920eW\u0494\u7dd0", "\ud886\udd61\u1abd\ud85c\udf4b\uda0c\udcd4\udb52\udf6b\ud8d0\udea4\u2b32\u21cd\uda13\ude0a\udb3b\udf4d\ud873\udf9f\ud815\udd54",
        29, 82386, 1059816002, -3792391727112382110L, -84459L, true, true, (char) 23136, (char) 24871,
        Double.longBitsToDouble(0x3fee17ded2ad69ecL), Double.longBitsToDouble(0x3fb2589cc6b31558L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 6, "\uda75\udf73\udb79\udf69\udbb2\ude2f\udb88\udfba", "\ua264\u2e67\u1fff\uccff\u920eW\u0494\u7dd0", "\udb31\udc15\u5873\ud85c\udf4b\uda0c\udcd4\ud97c\udd47\ub6d8\ud835\udd0e\uda6f\udfc8\ud80a\ude91\udb67\udd8d\uda68\udd98\ud863\ude59",
        29, 82386, 1059816002, 5642256966577690934L, 31519L, false, true, (char) 33103, (char) 8602,
        Double.longBitsToDouble(0x3fd277939fb0a89eL), Double.longBitsToDouble(0x3fee41b0eaad4c72L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.LightweightMessageFormatter:@?\012",
        Z.run(T, 1, 3, 6, 5, "\uda75\udf73\ud822\udc3d\udbb2\ude2f\uda44\udf59\ud9be\udc03\ud870\udec1\udaa7\udd4e\ud8a3\ude50\udbd2\udd14\ud9ab\udf44\uda6a\udf57\ud86b\udca9\ud8de\udc2c\ud970\uddc3\ud8e7\udcc8", "\u14b4\u5144\ua122\u2c90\uc3b9\ua3ae\u31ce\u771e", "\ud863\ude59\ud8e8\udd81\ud89c\uddb8\u4dfb\ud911\udf6e\ud8bb\udc0f\ud94f\ude85\ud989\ude63\udbd0\udf08\udba5\udfe9",
        22, 26675, 2033820071, 6075321980873934808L, -24746L, false, false, (char) 30965, (char) 7187,
        Double.longBitsToDouble(0x3fe8d15be973a125L), Double.longBitsToDouble(0x3fe7787822ae9928L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.LightweightMessageFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 1, "\ud996\udd84\000\000\uda44\uded0\ud8b0\ude08\ud941\udd82", "\u29e3\ucd9c", "\udbd5\ude89\ud9a6\uddc8\ud8e7\udcc8\ud932\udeff\udb31\udc15\u5873\ud85c\udf4b\uda0c\udcd4\ud875\udf42\ud91b\udff2\uda7a\udc28\udb25\uddef\udbb1\udfd2\udb58\ude40\ud873\udf9f\ud863\ude59\ud8e8\udd81\ud96a\udf29\u966a\ud880\udc05\ud8bb\udc0a\ud99a\udd4a\udb79\ude07\uda2a\ude33\ud87c\uddd7\ud8b5\udff6\ud945\udd46",
        31, 15127, 907872216, -5413318691785041166L, -43341L, false, true, (char) 4497, (char) 56646,
        Double.longBitsToDouble(0x3fe0f69244ac95deL), Double.longBitsToDouble(0x3fed0767f127bda8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.LightweightMessageFormatter:@?\0121=new com.google.javascript.jscomp.LightweightMessageFormatter:@?\012",
        Z.run(T, 2, 6, 6, 4, "\udbb2\ude8b\ud845\udebb\udbb2\ude2f\uda44\udf59", "\ua264\u2e67\u02f5\ucd50\u920eW\u0494\u0bad", "\udb31\udc15\u5873\ud85c\udf4b\uda0c\udcd4\udb21\udea6\ud929\ude4f\udbc1\udf7a\ua46f\uda1b\udfe6\udb3b\udf4d\ud873\udf9f\ud863\ude59",
        29, 82386, 1059816002, 5641412541647558966L, -62743L, false, false, (char) 33103, (char) 8602,
        Double.longBitsToDouble(0x3fd277939fb0a89eL), Double.longBitsToDouble(0x3fee41b0eaad4c72L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.LightweightMessageFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 5, "\uda75\udf73\ud822\udc3d", "\u8445\u9b03\ua264\u2e67\u02f5\ucd50\u8717W\u0494\u8ead\ub7c6\u11e4\u0ca9\u14b4\u5144", "\ud929\ude4f",
        50, 11410, -2128984223, 8543891789568810121L, 66527L, false, false, (char) 27885, (char) 37372,
        Double.longBitsToDouble(0x3fd364e4dd2a60acL), Double.longBitsToDouble(0x3fae7f7b430686c0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.LightweightMessageFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 4, "\uda3d\udf13\uda37\udc2f\udbb2\ude2f", "\u513c\ua1f6\u9b91\ud73e\ucd97\u920eW", "\ud8e6\udd24\ud932\udeff\udb31\udc15\u5873\ud853\udf46\uda0c\udcd4\udb21\udea6\ud929\ude4f\u2ae0\udbb7\udf73\udba3\udf2d\udb4f\udc35\ud8a3\uded1\uda61\ude58\ud8e8\udd81\ud89c\uddb8\u4dfb\uda8a\uddce",
        8, 86165, 1751908668, 8372600931304116600L, -84459L, true, true, (char) 23136, (char) 23591,
        Double.longBitsToDouble(0x3fee41b0eaad4c72L), Double.longBitsToDouble(0x3f9d43321af691c0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.LightweightMessageFormatter:@?\0121=com.google.javascript.jscomp.LightweightMessageFormatter:@?\012",
        Z.run(T, 2, 3, 3, 5, "\uda4b\udebe\ud9be\udf99\udbb2\uddc7\uda44\udf59\udbaf\udf2e\ud85f\udca4\udaa7\udd44\ud9d3\udf07\ud845\udf8b\ud9ab\udf44\uda6a\udf57\ud86b\udca9\ud8de\udc2c\udb85\udfd8\ud966\udc19\udb6c\ude57", "\u685c\ua122", "\uda0a\udd8f\ua4cd\uda1b\udfe6\udb3b\udfdd\ud873\udf9f\ud94a\udf6d\ud8e8\udd81\ud89c\uddb8\u4dfb\ud911\udf6e\ud8bb\udc0f\udb81\udd78",
        32, 41460, -461598327, -8815934897090477237L, -61719L, true, true, (char) 23514, (char) 33163,
        Double.longBitsToDouble(0x3fefef3cf3cc1e24L), Double.longBitsToDouble(0x3fe53151dac9d85eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.LightweightMessageFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 6, "\uda4c\ude5e\ud813\udf78\udada\udead\uda32\udd09", "\ua264\u1686\u02f5\u901e\u6803\026\u0494\u7dd0\ubb6a", "\udbeb\udfc9\uda7c\udcd0\uda49\ude43\ud8ca\uddbd\ud806\udd6e\ud963\udc2a\ud803\udf64\uda13\ude0a",
        -5, 55921, 1690501225, -1211878972008465670L, -13263L, false, true, (char) 59114, (char) 51986,
        Double.longBitsToDouble(0x3fceb1b66a25d0c4L), Double.longBitsToDouble(0x3fb789e21a5df020L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.LightweightMessageFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 3, "\udbef\udeeb\udb0d\udf5f\ud95c\ude1f\udaec\udd52\ud9fb\ude07\udb7d\udc24\ud99b\udd41\udafe\udcd0\ud913\ude30", "\u4dd0\u8fc3\u05fe\ubb6a\ucbe3\u0ca9\u9da8\u80f7\uc438", "\udbfe\udf11\ua4cd\uda13\ude0a\udb6e\ude4d\ud8f9\udec2\ud989\udfd3\udac0\udead\uda51\udd71\udb94\udc1d\udb70\ude30\uda66\udf14\u03d9\uda09\udd23\udb11\udeb2\udb88\uddf3\uda1a\udd4f\ud949\udd89",
        -1, 50164, -1521245500, -4678566843984610478L, 58583L, false, false, (char) 15634, (char) 25961,
        Double.longBitsToDouble(0x3fec95810b7c3181L), Double.longBitsToDouble(0x3fc530d54c63ddd4L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.LightweightMessageFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 6, "\udac2\udc71\udba7\udc81\udb60\udc27\ud903\udc30\udb9b\udf88\uda97\ude6d\udb06\udcb0\uda9f\uddf9\udb36\udf06\ud996\udd2b\uda6a\udf57\ud851\udedb\uda9f\udf38\ud970\uddc3\ud969\udf88\uda4d\udf70\udb31\udc48\u5873\ud85c\udf4b\uda0c\udcd4\udb2b\udd11\ud8a5\ude72\u2b32\ud8d2\udd6c\ud949\udf81\uda81\ude4d\ud8ca\ude16\ud8c1\ude58", "\ub38f\u9445\uc31d", "\ud8d4\udc2f\ud994\udf20\uda28\ude45\ud861\udef4\udb28\ude20\u9844\ud9ab\udef2\udaa3\udca3\udb0b\ude04\ud8d3\udf33\udaf7\udd1d\ud92f\udc68\udb77\udcba\ud8a1\ude9c",
        3, 43012, 790377733, -2245625918363885304L, -61825L, false, false, (char) 43190, (char) 37710,
        Double.longBitsToDouble(0x3fdc85891d5e4662L), Double.longBitsToDouble(0x3f9f93bb3684e3a0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.LightweightMessageFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 6, "\uda28\udd74\udb90\ude18\udb60\udc27\udb2b\udc2c\ud8f1\udf88\ud969\udfe1\ud9bf\udee2\ud98d\udff5\udb36\udf06", "\u00a2\uaad4\u7dd0\ua941\u63c1\u0cdc", "\ud980\udcca\udb2b\udd11\udb91\udec5\ud92e\udcd9",
        15, 30977, 1982910643, 1262639228098806623L, 65848L, true, true, (char) 65161, (char) 47675,
        Double.longBitsToDouble(0x3fd668defd6c85fcL), Double.longBitsToDouble(0x3fee3a66567a2465L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 5, 6, "\uda75\udf73\ud822\udc3d\udbb2\ude2f\uda44\udf59", "\ua264", "\ud9ab\udf44\uda6a\udf57\ud86b\udca9",
        2, 36104, 898715801, -1134865721928984621L, 339L, false, true, (char) 35590, (char) 47712,
        Double.longBitsToDouble(0x3fdea19ff9142b7aL), Double.longBitsToDouble(0x3fd8504710a30234L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.LightweightMessageFormatter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 5, "\uda75\udf73\ud822\udc3d", "\u8445\u9b03\ua264\u2e67\u02f5\ucd50\u8717W\u0494\u8ead\ub7c6\u11e4\u0ca9\u14b4\u5144", "\ud929\ude4f",
        50, 11410, -2128984223, 8543891789568810121L, 66527L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4a54c000000000L), Double.longBitsToDouble(0x3fae7f7b430686c0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.LightweightMessageFormatter|format|com.google.javascript.jscomp.JSError,boolean|new:com.google.javascript.jscomp.LightweightMessageFormatter:",
    "M|com.google.javascript.jscomp.LightweightMessageFormatter|formatError|com.google.javascript.jscomp.JSError|new:com.google.javascript.jscomp.LightweightMessageFormatter:",
    "M|com.google.javascript.jscomp.LightweightMessageFormatter|formatWarning|com.google.javascript.jscomp.JSError|new:com.google.javascript.jscomp.LightweightMessageFormatter:",
    "M|com.google.javascript.jscomp.LightweightMessageFormatter|withoutSource||static",
    "C|com.google.javascript.jscomp.LightweightMessageFormatter|<init>|com.google.javascript.jscomp.SourceExcerptProvider,com.google.javascript.jscomp.SourceExcerptProvider$SourceExcerpt",
    "C|com.google.javascript.jscomp.LightweightMessageFormatter|<init>|com.google.javascript.jscomp.SourceExcerptProvider",
    "C|com.google.javascript.jscomp.LightweightMessageFormatter|<init>|",
    "M|com.google.javascript.jscomp.LightweightMessageFormatter|format|com.google.javascript.jscomp.JSError,boolean|new:com.google.javascript.jscomp.LightweightMessageFormatter:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
