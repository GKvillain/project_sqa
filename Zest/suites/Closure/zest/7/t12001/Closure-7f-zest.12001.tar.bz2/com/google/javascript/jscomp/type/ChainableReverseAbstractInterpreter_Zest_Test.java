package com.google.javascript.jscomp.type;
import org.junit.Test;
import static org.junit.Assert.*;
public class ChainableReverseAbstractInterpreter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 5, "\udb7f\ude28\uda8f\udda7\udbe0\udfab\uda5e\udce3\udb93\udc10\uda2b\udc26\ud99f\udfd4", "\u6088\u4bce\u445f\u9840\u9ab7\u6756\uaf0a\u7e9c\u0520", "\ud871\udff3\udb82\udcb2\ud9c9\udd0a\ud9d1\udc12\ud952\udd4e\ud85d\udce2\ud8f3\udeb0\ud8ab\udd8e\udba4\udf54\uda73\udf57\udbff\udf32\udae2\ude11\udb99\udd84\ud98a\udfb7\ud995\udeaa\ud8eb\udf73\udba0\uddcc\ud891\udcb5\uda8c\udcc8\udacb\ude1d\udb5f\ude12\u4711\udbca\ude05\ud96a\udfd5\udb2f\udfa3\ud88d\ude82\ud90b\udfc2\udbf6\udd30\udb94\udd54\uda79\udfc1\uda85\udd31\ud93c\ude56\udb55\udf9a",
        1, 96160, 1028011283, 3265285271917246773L, -17025L, true, false, (char) 37702, (char) 59697,
        Double.longBitsToDouble(0x3fe08e2c948df7b4L), Double.longBitsToDouble(0x3fdc0c6330284e4eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 0, "\udb7f\ude28", "\u5954", "\ud99f\udfd4\ud860\udce7\udb57\ude93\udbe6\ude72\udac7\udf29",
        53, 96561, -1014513053, -3666022855889565786L, -1035L, true, true, (char) 62405, (char) 58451,
        Double.longBitsToDouble(0x3fa02881554c5dc0L), Double.longBitsToDouble(0x3fe82fd902d611dcL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 4, 0, "\udaab\udd4a\uda8f\udda7\udbe0\udfab\uda5e\udce3\uc840", "\u5e34\u08b8\u68d9\u8071\u445f\u9840\ua766\u6756\uaf0a", "\ud802\udf91",
        17, 53365, -975408096, -351160563088482811L, -2637L, true, false, (char) 27575, (char) 53009,
        Double.longBitsToDouble(0x3fd971fbef60c338L), Double.longBitsToDouble(0x3fefafbdb19367b7L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 5, "\udb4b\udece\uda8f\udda7\udbe0\udfab\uda5e\udce3\udb93\udc10\ud9f4\ude7a\ud99f\udfd4", "\u9ed0\u4bce\u5439\u9840\u9ab7\u6756\uaf0a\u7e9c\u0095", "\ud871\udff3\udb82\udcb2\ud9c9\udd0a\u3b0d\000\udba8\udc74\ud8f3\udeb0\ud8ab\udd8e\udba4\udf54\uda73\udf57\udbff\udf32\udae2\ude11\udb99\udd84\ud98a\udfb7\ud995\udeaa\ud8d0\udc73\udba0\uddcc\ud891\udcb5\uda8c\udcc8\udacb\ude1d\udb5f\ude12\u4711\udbca\ude05\ud96a\udfd5\udb2f\udfa3\ud88d\ude82\ud90b\udfc2\udbf6\udd30\udb94\udd54\uda79\udfc1\uda85\udd31\ud915\udc49\ufacf",
        24, 96944, 1028011264, 3265285271917246773L, -17025L, true, false, (char) 37702, (char) 59697,
        Double.longBitsToDouble(0x3fe08800048df7b4L), Double.longBitsToDouble(0x3fdc0c6330284e4eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 7, "\udb7f\ude28\uda8f\udda7\udbe0\udfab", "\ub2a1\u03a8\u3874\u08b8\u6088\u4bce\u445f\ua848\ucdd5\u5596\ud19f\u9c83\u0520\u908a", "\udb82\udcb2\ud9c9\udd0a\ud9d1\udc12\ud952\udd4e",
        49, 74779, -489618748, -5684878291134256846L, -74389L, false, true, (char) 39282, (char) 31224,
        Double.longBitsToDouble(0x3fef6c209b837faeL), Double.longBitsToDouble(0x3fc832cb7344b82cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 5, "\udb7f\ude28\uda8f\udda7\udbe0\udfab\udab6\udc6e\udb93\udc53\uda2b\udc26\ud99f\udfd4", "\u6088\u4bce\u445f\u9840\u9ab7\u6756\uaf0a\u7e9c\u0520", "\ud871\udff3\udb82\udcb2\ud9c9\udd0a\ud9d1\udc12\ud952\udd4e\ud85d\udce2\ud8f3\udeb0\ud8ab\udd8e\udba4\udf54\uda73\udf57\udbff\udf32\udae2\ude11\udb99\udd84\ud98a\udfb7\ud995\udeaa\ud8eb\udf73\udba0\uddcc\ud891\udcb5\uda8c\udcc8\udacb\ude1d\udb5f\ude12\u4711\udbca\ude05\ud96a\udfd5\udb2f\udfa3\ud88d\ude82\ud90b\udfc2\udbf6\udd30\udb94\udd54\uda79\udfc1\uda85\udd31\ud93c\ude56\udb55\udf9a",
        1, 96160, 1028011283, 3265285271917246773L, -17025L, true, false, (char) 37702, (char) 966,
        Double.longBitsToDouble(0x3fe08e2c948df7b4L), Double.longBitsToDouble(0x3fe18e3198142727L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|append|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|declareNameInScope|com.google.javascript.jscomp.type.FlowScope,com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|firstPreciserScopeKnowingConditionOutcome|com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope,boolean|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|getFirst||new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|getNativeType|com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|getNativeTypeForTypeOf|java.lang.String|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|getRestrictedByTypeOfResult|com.google.javascript.rhino.jstype.JSType,java.lang.String,boolean|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|getRestrictedWithoutNull|com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|getRestrictedWithoutUndefined|com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|getTypeIfRefinable|com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter|nextPreciserScopeKnowingConditionOutcome|com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope,boolean|new:com.google.javascript.jscomp.type.ClosureReverseAbstractInterpreter:com.google.javascript.jscomp.CodingConvention,com.google.javascript.rhino.jstype.JSTypeRegistry",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
