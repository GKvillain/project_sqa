package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class DeadAssignmentsElimination_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 1, 8, 9, 6, "\udbc5\udd01\ud8be\udff5", "\u2176\u6ef6\ub4a7\u91ec\u4c39\u6673\ua6c0\u9959\u262c\u7af9\u07a5\ud1e4\ubae2\u5180\u44a5\u6db1\ud381\u18b0\ubaa8\u6183\u7680\u746b", "\ud900\udd73\ud87d\udfd1\uda3e\udfe7\uda6c\udd74\uda32\ude82\ud9c2\udf90\ud81f\udf85\ud9b8\udf47",
        -5, 65014, -705291336, 2270469322399953726L, 61182L, false, false, (char) 54949, (char) 10719,
        Double.longBitsToDouble(0x3fd1d38b37bc6f90L), Double.longBitsToDouble(0x3fecb57bfc5f3e41L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 1, 8, 9, 6, "\udbc5\udd01\ud8be\udff5", "\u2176\u8b70\ub4a7\u91ec\u9e6d\u664e\ua6c0\u9959\u7ce4\uc7bb\u07a5\ud1e4\ubae2\u5180\u44a5\u6db1\ud381\u18b0\u33a9\u6183\u7680\u746b", "\ud900\udd73\ud87d\udfd1\uda3e\udfe7\uda6c\udd74\uda32\ude82\ud9c2\udf90\ud81f\udf85\ud9b8\udf47",
        -5, 65014, -705291336, 2270469323404310168L, -42322L, true, false, (char) 31442, (char) 10533,
        Double.longBitsToDouble(0x3fe6c8be6f0eead0L), Double.longBitsToDouble(0x3fdeb38b37bc6fb2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 9, 6, "\udbc5\udd01\ud8be\udff5", "\u2176\uc7f5\ub4a7\u91ec\u4c39\u6673\ua6c0\u9959\u262c\u7af9\u07a5\ud1e4\ubae2\u6780\u44a5\u6db1\ud381\u18b0\ubaa8\u3ab2\ud032\u7b5f", "\ud89e\ude34\udaf5\ude28\ud86e\udeea",
        41, 98779, -343102267, -4520558812627782766L, 9614L, false, true, (char) 23385, (char) 37893,
        Double.longBitsToDouble(0x3f507b44c5e0e000L), Double.longBitsToDouble(0x3fb90a3076c8be68L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=new com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 2, 8, 9, 6, "\udbc5\udd01\uda6e\uddac", "\u2176\u6ef6\ub4a7\u91ec\u4c39\u6673\ua6c0\u9959\u262c\u7af9\ua175\ud1e4\ubae2\u5180\u44a5\u6db1\ud381\u18b0", "\ud8ce\udedb\u617e\ud868\ude14\udbdc\udd53\ud900\udd73\ud87d\udfd1\uda3e\udfe7\uda6c\udd74\uda32\ude82\ud9c2\udf90\ud81f\udf85\ud9b8\udf47\udae3\udcdf\udad0\udc5e\udb12\udd3d",
        34, 13862, -1295867833, 555316331691429889L, -34364L, true, false, (char) 10719, (char) 64975,
        Double.longBitsToDouble(0x3feef1be4796af7fL), Double.longBitsToDouble(0x3fb7cf905a1ec0b0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 8, 6, "\udbc5\udd01\ud8be\udff5", "\u2176\u6ef6\ub4a7\u917a\u4c39\u6673\ud087\u0263\u262c\u7af9\u07a5\ud1e4\ubae2\u5180\ua390\u6db1\ud381\u18b0\u94c5\ud451\u7680\u746b", "\ud900\udd73\ud87d\udfd1\uda3e\udfe7\uda6c\udd74\uda32\ude82\ud9c2\udf90\ud81f\udf85\ud9b8\udf47",
        -5, 65014, -705291336, 3018502136967185565L, 94985L, false, false, (char) 54776, (char) 10719,
        Double.longBitsToDouble(0x3fd1d38b37bc6f90L), Double.longBitsToDouble(0x3fecb57bfc5f3e41L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 1, 8, 9, 6, "\udbc5\udd01\ud8be\udff5\udaad\udd76\ud94d\ude83\ud9d3\udcb9\ud84b\udd3a\uda1c\udeef\ud9c1\udcdf\ud8c6\ude6e\ud996\udf3e", "\u5e95\u7a83\u07a5", "\uda25\udc0b\ud81a\udd9c\udbaf\udcb1\udaae\udc79\udb59\udf7d\ud9c4\udca7\ud9a8\udd99",
        41, 29183, -1170831823, 5010154785299155821L, 81024L, true, true, (char) 24845, (char) 63881,
        Double.longBitsToDouble(0x3fe1b759cb92c15eL), Double.longBitsToDouble(0x3fdd1fb0f68cef3eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 1, 2, 9, 6, "\udbc5\udd01\ud8be\udff5", "\u49be\u8bad\uc1ab\u91ec\u4c39\u6673\ua6c0\u9959\u262c\u7af9\u07a5\ud1e4\ubae2\u5180\u44a5\u6db1\ud381\u18b0\ubaa8\ub272\ud5a1\u746b", "\ud900\udd73\ud87d\udfd1\uda9c\udff6\udaa0\ude96\ua73b\u0e4a\ud828\ude8f\ud9b8\udf47",
        -5, 65014, -705291336, 2270469322399953726L, 61182L, false, false, (char) 54949, (char) 10719,
        Double.longBitsToDouble(0x3fd1d38b37bc6f90L), Double.longBitsToDouble(0x3fecb57bfcad34c0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 1, 9, 0, 6, "\udbc5\udd01\ud912\ude29", "\ud155\u6f71\u9601\u91ec\u4c39\u6673\ua6c0\u67bb\u262c", "\ud90f\ude8e\ud824\udc21\ud879\udcf6",
        53, 16321, -1384864425, 6544307553899746689L, -72253L, true, true, (char) 44109, (char) 3036,
        Double.longBitsToDouble(0x3fd862a873d9bcf4L), Double.longBitsToDouble(0x3fe9032043d3857aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 1, 3, 4, 4, "\ud871\udfef\uebf3\ud9d6\udc4a\uda40\udcdb\udb81\udc60", "\u91ec\u8045\uac14\ua6c0\u9959\u262c\u7af9\ub70d\ud1e4\ubae2\u5180\u44a5\u6db1\ud381\uaa3c\ud4a0\uad42\u5786\u7491\ub2aa", "\ud87d\udfd1\ud862\udfc2\ud978\udd78\uda30\uddb8\ud9c2\udf90",
        48, 30162, 2009206225, 6231701253176826808L, -26595L, true, false, (char) 31442, (char) 10533,
        Double.longBitsToDouble(0x3fe6c8be6f0eead0L), Double.longBitsToDouble(0x3fd1d38b35d66f90L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 6, "\u4b20", "\u00c9\u2176\u6ef6\ub4a7\u91ec\u4c39\u6673\u3402\ud783", "\udbf5\udf56\ud90f\ude8e\ud8e3\ude60\ud879\udd05\udbb9\udd6c\udb93\udd29\ud93d\udc7f\ud894\ude00\udbea\ude50\udbe3\ude35\ud8ce\udedb\u617e\ud868\ude14\udbdc\udd53\udab3\udf9a\ud87d\udf25\uda3e\udfe7\uda6c\udd74",
        54, 94733, -1040973002, -8443629647198810671L, 14743L, true, false, (char) 7347, (char) 23385,
        Double.longBitsToDouble(0x3fc5da7840041ed0L), Double.longBitsToDouble(0x3fe3178386a128c1L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 6, "\udbc5\udd01\ud8be\udff5", "\u2176\u6ef6\ub4a7\u91ec\u75e7\u1175\ua6c0\u9959\u262c\u7af9\u07a5\ud1e4\ubae2\u5180\u44a5\u6db1\ub061\u18b0\ubaa8\uccb1\u7680\u746b", "\ud900\udd73\ud87d\udfd1\uda3e\udfe7\uda6c\udd74\uda32\ude82\ud9c2\udf90\ud81f\udf85\ud9b8\udf47",
        -5, 65014, -705291336, 2270469322399953726L, 38941L, true, true, (char) 31542, (char) 10533,
        Double.longBitsToDouble(0x3fe6c8be6f0eead0L), Double.longBitsToDouble(0x3fd1d38b37bc6f90L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 9, 6, "\udbc5\udd01\udb69\udcb3", "\u2176\u9ce3\u1b67\u91ec\u4c39\u6673\ua6c0\u9959\u872e\u642d\u0623\u19f4\ubae2\u5180\u44a5\u6db1\ud381\u18b0\ubaa8\ua14b\u7680\u746b", "\ud900\udd73\ud87d\udfd1\uda3e\udfe7\ud8a8\udf38\udb06\udcbd\ud9ca\udc34\ud81f\udf85\ud9b8\udf47",
        -5, 65014, -705291336, 2270469322399953726L, 21577L, false, false, (char) 54949, (char) 10719,
        Double.longBitsToDouble(0x3fd1d38b37bc6f90L), Double.longBitsToDouble(0x3fecb57bfc5f3ec3L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 1, 9, 5, 4, "\udbc5\udd01\ud8be\udff5\udaad\udd76", "\u6ef6\u1182\u51a6\u94c6\u1288\ua76d\u9959\u262c\u7af9\u07a5\ud1e4\ubae2\u1005\u294a\u6db1\ud381", "\udb23\udd2b\ud8ce\udedb\ud9ba\udc6e\ud868\ude14\ud994\udfaf\ud900\uddf7\ud87d\udfd1\uda3e\udfe7\uda6c\udd74\uda32\ude82\ud9c2\udf90\ud86f\udf4d",
        -2, 12225, 1450931014, -3029203221743512622L, -9959L, true, true, (char) 55220, (char) 18185,
        Double.longBitsToDouble(0x3fe1aaba7b05dfacL), Double.longBitsToDouble(0x3fe87754621d38b3L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 9, "\udbc5\udd01\uda6e\uddac\ud86f\udec5\udb1e\ude6c\ud9d3\udcb9\ud84b\udd3a\uda1c\udeef\ud9c1\udcdf\ud9a1\udf36\udba3\udc86\ud987\uddfd\u27b0\ud812\ude5c\ud969\udc63\uda8c\ude54\ud90f\ude8e\ud824\udc21\ud879\udcf6\ud81a\udd9c\udbaf\udcb1\udab8\ude79\ud87a\ude66\ud9b5\ude28\udbe3\ude35\ud8ce\udedb\u617e\ud868\ude14\udbdc\udd53\ud900\udd73\ud87d\udfd1\uda3e\udfe7\ud9bc\udddd", "\u82cc\ucdb6\u1bc1", "\ud94d\uddad\ud82d\udf2e\udacc\udfb9\ud8e2\uddb7\uda89\ude4f\udb71\udcc8\ud810\uddcb\ud971\udd99\ud980\ude65\uda46\udc66",
        25, 37894, -669588385, -4892022714041417319L, 76561L, true, false, (char) 41652, (char) 4187,
        Double.longBitsToDouble(0x3fc28015e94d14fcL), Double.longBitsToDouble(0x3fe71df72be2d544L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=java.lang.Boolean:false |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 2, 8, 3, 1, "\udbc5\udd01\uda6e\uddac", "\u1be6", "\ud9c1\udcdf\u44f7\udb52\udd4b\ud8b2\udfe9\u27b0\ud812\ude5c\ud866\udca1\uda8c\ude54\ud90f\ude8e\ud824\udc21\udb8d\uddb2\udad5\udc37\udbaf\udcb1\udbb6\udc7d\ud87a\ude66\udb16\udef9\udbe3\udd70\udb94\ude9e\udbc0\udfb0\ud868\udebd\udbdc\udd53\ud900\udd73\ud87d\udfd1\uda3e\udfe7\uda6c\udd74\uda32\ude82\ud9c2\udf90\ud81f\udf85\ud9b8\udf47\ud9ec\udd25",
        25, 68542, 522408574, -4966851098951114681L, -96966L, false, false, (char) 12895, (char) 54856,
        Double.longBitsToDouble(0x3fe87756851d38b3L), Double.longBitsToDouble(0x3feef1be4796af7fL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=new com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 2, 9, 9, 6, "\udbc5\udd01\uda6e\uddac", "\u2176\u6ef6\ub4a7\u91ec\u4c39\u6673\ua6c0\u9959\u262c\u7af9\ua175\ud1e4\uaea1\uccc9\u44a5\u6db1\ud381\u18b0", "\ud8ce\udedb\u617e\ud868\ude14\udbdc\udd53\ud900\udd73\ud87d\udfd1\uda3e\udfe7\uda6c\udd74\ud859\udfd4\uda5c\udc33\ud85e\udd88\ud9b8\udf47\udae3\udcdf\udad0\udc5e\udb12\udd3d",
        34, 13862, -1295867109, 509130246255071233L, -34364L, true, false, (char) 10719, (char) 64975,
        Double.longBitsToDouble(0x3feef1be4796af7fL), Double.longBitsToDouble(0x3fb7cf905a1ec0b0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 6, "\udaa5\udc50\udbdc\udf63", "\u5d06\ub237\u28cb\u101d\ud2bf\u5e83\u3faa\u8669\u22b2", "\ud98e\ude65\ud875\udde7\ud879\udcf6",
        53, 16321, -1556522665, -4970551770547792504L, 48323L, true, true, (char) 44109, (char) 24433,
        Double.longBitsToDouble(0x3feb6a2c39ec9f01L), Double.longBitsToDouble(0x3fe9032043d3857aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 2, 8, 8, 6, "\udbc5\udd01\uda6e\uddac", "\u2176\u6ef6\ub4a7\u91ec\u4c39\u6673\ua6c0\u9959\u262c\u7af9\ua175\ua153\ubae2\u5180\u44a5\u6db1\u9e2d\u79b2", "\ud8ce\udedb\u617e\ud868\ude14\udbdc\udd53\ud902\ude73\ud863\ude45\ud8f3\udf4e\udaaa\udc27\uda32\udeca\ud89c\udffd\ud840\udf29\ud9b8\udf47\udae3\udcdf\udad0\udc5e\udaf0\udf0c",
        24, 90847, -1295867833, 555316331691429889L, -34364L, true, false, (char) 10719, (char) 64975,
        Double.longBitsToDouble(0x3feef1be4796af7fL), Double.longBitsToDouble(0x3fb7cf905a1ec0b0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 0, "\udbc5\udd01", "\uacdf\uce4c\u681f\ub524\u91ec\u4c39", "\u27b0\ud9ab\udde0\udbef\udc37\uda8c\ude54\ud997\udf29\ud824\udc0f\ud9d3\udee0\udba0\udfe5\udbb5\udd58\ud9db\udfaf\ud87a\ude6a\uda03\udd6f\ud827\ude5c\uda66\udee7\u617e\ud868\ude14\udbcd\udddd\ud900\udd73\ud878\udcd1\uda3e\udfe7\uda6c\udd74\uda32\ude82\ud9c2\udf90\ud81f\udf85\ud9b8\udf47\udae3\udcdf\udbe1\udc83\ud9be\ude2f\ud839\ude04\uda42\udc37\ud90e\uddd8\ud8e2\uddb7\ud8df\udf16\udb71\udcc8\ud810\uddcb\ud913\udd8a\uda85\udf3e\uee36\ud81f\uddb4\ud894\ude56\udbd6\udea9\ud82a\ude50\udbf0\udf81\ud811\ude81\ud948\udfbb\udaa3\udeed\uda11\udc97\uda9b\uded8\udac2\udc35\ud894\udcc0\ud9b8\ude8e\udbb8\udc41",
        51, 1066, 522131093, -4818864941859279772L, -11871L, true, false, (char) 21531, (char) 21003,
        Double.longBitsToDouble(0x3fc2af3cb75c4fd4L), Double.longBitsToDouble(0x3fa4d99550886800L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=java.lang.Boolean:false |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 2, 3, 3, 6, "\udb03\udc5f\ud993\udcfc", "\ub54f\u58fc\u5e7f\u91ec\u4c39\u6673\u0c16\uca22\u7d22\u8a25\ua175\ud1e4\ubae2\u5180\uc66b\u6db1\ud381\ud669\ua327\u3397\u7680\u746b\u9b7a\u37a3\u6bb2\u907b\u99e9\u3514\u669d\u0c88\u58fa\ucdb6\u1bc1\ub1c5\ud066\u392a\u118c\u64bb", "\udbb1\udc46\ud9fa\udccc\ud8ea\uddba\ud9a0\udeb7\uda46\udc66\ud9fb\udf1f\ud8b8\udf41\udb84\ude04\ud955\ude6b\ud8db\udf15\ud8e9\udd9c\udba6\udfb0\ud874\udd0b\udb57\udf09\udbf8\uddfc\ud950\udea8\ud932\udeb1\udb5b\udc9f\udbf1\udf95\uda25\udeed\udaed\udda0\ud9e1\udc6d\uda6b\udd9d\udbb9\udd7a\ud855\udd2a",
        15, 52219, -32795497, -7554985449683190010L, -59648L, true, true, (char) 59495, (char) 7305,
        Double.longBitsToDouble(0x3fec95dc8df2f288L), Double.longBitsToDouble(0x3fe4a6b1775f7376L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 6, "\udbc5\udcc1\ud881\uddf6\ud8fc\udcb6\udb1e\ude6c\ud9d3\udcb9\udaaa\udc11\udae8\udd9c\ud9d7\udd3d\ud802\uddd5\udba3\udc94", "\u262c\u7c20\u19cf\ud143", "\udb6e\udf07\udbaf\udcb1\udaae\udc79\ud87a\ude66\ud9b5\ude28",
        13, 14491, 639461183, -5028684387734543045L, -8819L, true, false, (char) 17886, (char) 61122,
        Double.longBitsToDouble(0x3fec960af5d1fb0fL), Double.longBitsToDouble(0x3fea33be13b8567bL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\0121=java.lang.Boolean:false |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 2, 3, 3, 6, "\udb03\udc5f\ud8e9\udef6\u713c\udb1e\udec1", "\u5e7f\u91ec\u4c39\u6673\u0c16\uca22\u7d22\u3ab8\ua15d\ud1e4", "\u8421\udb6d\udcb0\udaae\udc79\ud806\udc4c\udb22\udea2",
        2, 14491, 639461183, -5028684390435674821L, -8819L, true, false, (char) 17886, (char) 61122,
        Double.longBitsToDouble(0x3fec960af5d1fb0fL), Double.longBitsToDouble(0x3fea33be1287567bL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DeadAssignmentsElimination:@?\012",
        Z.run(T, 1, 8, 9, 2, "\udbc5\udd01\ud8be\udff5", "\u2176\u6ef6\ub4a7\u91ec\u4c39\ua9ec\ub802\ub835\u262c\u51ca\u07a5\ud1e4\ubae2\u5180\u44a5\u6db1\ud381\u18b0\ubaa8\u6183\u7680\u746b", "\ud900\udd73\ud86f\uddd1\uda3e\udfe7\uda6c\udd74\uda32\ude82\ud9c2\udf90\ud81f\udf85\ud9b8\udf47",
        -5, 65014, -705291336, 2270469322399953726L, 61182L, false, false, (char) 35687, (char) 15164,
        Double.longBitsToDouble(0x3fd1d38b37bc6f90L), Double.longBitsToDouble(0x3fecb57bf9e6517fL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|isVariableReadBeforeKill|com.google.javascript.rhino.Node,java.lang.String|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|enterScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|exitScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|isVariableStillLiveWithinExpression|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,java.lang.String|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|tryRemoveAssignment|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.jscomp.DataFlowAnalysis$FlowState|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|tryRemoveAssignment|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.jscomp.DataFlowAnalysis$FlowState|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|tryRemoveDeadAssignments|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.jscomp.ControlFlowGraph|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
    "C|com.google.javascript.jscomp.DeadAssignmentsElimination|<init>|com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.DeadAssignmentsElimination|isVariableReadBeforeKill|com.google.javascript.rhino.Node,java.lang.String|new:com.google.javascript.jscomp.DeadAssignmentsElimination:com.google.javascript.jscomp.AbstractCompiler",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
