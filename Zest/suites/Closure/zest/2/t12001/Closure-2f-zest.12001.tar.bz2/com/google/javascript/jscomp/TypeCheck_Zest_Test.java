package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeCheck_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 10, 15, "\udb23\udfdc\ud848\udf2f\ud9c0\udf4e\ud9c9\ude11\ud876\uddfa\ud9d5\udd08\udb18\udd15\ud997\udc9f\ud9a0\ude71\uda0c\udf11\ud807\uddf1\ud940\udf83", "\u9e0c\u82da\u6480\u2daa\u53ce\ua6f2\u5fa0\u518b\u6fd6", "\uda8d\udc08\udac1\udcdf\uda90\ude7c\ud85b\udf59\u5071\udb8e\ude87\ud9b1\uddbe\u9e10\ud8a7\udff7\ud9ae\udce1",
        1, 95652, -714476259, 8777563225194243165L, -72250L, false, false, (char) 50688, (char) 40298,
        Double.longBitsToDouble(0x3fd7934d4329a3c8L), Double.longBitsToDouble(0x3fe22ed9ce2f0609L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 10, 15, "\udb23\udfdc\ud848\udf2f\ud9c0\udf4e\ud9c9\ude11\ud876\uddfa\ud9d5\udd08\udb18\udd15\uda2e\udd91\ud867\udcce\ud9f7\udf64\ud807\uddf1\ud940\udf83", "\u9e0c\u82da\u6480\u2daa\u53ce\u7bfb\u5fa0\u518b\u6fd6", "\uda8d\udc08\udac1\udcdf\uda90\ude7c\ud85b\udf59\u5071\udb8e\ude87\ud9b1\uddbe\u9e10\ud8a7\udff7\ud9ae\udce1",
        1, 95652, -714476259, 8777563225194243165L, -72250L, false, false, (char) 50688, (char) 40298,
        Double.longBitsToDouble(0x3fd7934d4329a3c8L), Double.longBitsToDouble(0x3fe22ed9ce2f0609L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 4, 15, "\udb23\udfdc\udafe\udf81\ud818\udcc8\ud9c9\ude11\udb8b\udf44\ud8c4\udfa0\ud946\udcf7\udba9\ude5b\ud9a0\ude71\uda0c\udf11\ud807\uddf1\ud940\udf83", "\u9e0c\u82da\u6480\u45aa\u53ce\u36a4\u1dec\u6898", "\udbae\udcb5\ud98f\udfca\udac1\udcdf\ud952\udcfc\ud85b\udead\ud956\udca9\ud8a6\udec3\ud901\uddcc\u9e10\ud8a7\udff7\ud84a\udc8f\udb17\udfc9\udbfb\udfb7\ud9f8\ude9a\ud85c\ude87\udbe3\udcba\ud861\udce4\ud8ec\udf7b\uda86\udd98\ud8e2\uddf8\ud853\udd51\udb61\udf0b\ud1cf\ud8fb\udce4\u0550\uda49\udc49\ud858\udfa7\ud891\udfd9\ud9d5\uddd7\uda6f\udc36\ud97b\ude4a\ud83d\udd17\udb22\udc4c\udb3a\udebf\u41f4\ud93a\ude6f\uda27\udf2a\udbf5\udd7c\udbe4\ude76\ud963\ude6b\ud91e\udc08\ud9a0\udc32\ud8c9\udcf2\ud98b\udec2\uda22\udfa1\ud8ce\udc2e\udba7\udd48\uda67\udf43",
        30, 68832, 20119552, 8487622304386870608L, 11848L, false, false, (char) 60802, (char) 45883,
        Double.longBitsToDouble(0x3fea5f3b458d06f4L), Double.longBitsToDouble(0x3fb0d8e53051d790L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 15, "\udb23\udfdc\ud848\udf2f\ud9c0\udf4e\ud9c9\ude11\ud876\uddfa\ud9d5\udd08\udb18\udd15\ud997\udc9f\ud9a0\ude71\uda0c\udf11\ud807\uddf1\ud940\udf83", "\u9ded\u82da\u6480\u2daa\u53ce\ua6f2\u5fa0\u518b\u00aa", "\uda8d\udc08\udac1\udcdf\uda90\ude7c\ud85b\udf59\ud906\udce2\udb8e\ude87\ud9b1\uddbe",
        37, 31718, -51773424, 3496770929798695748L, 13539L, false, false, (char) 20779, (char) 37071,
        Double.longBitsToDouble(0x3fe427227f1b76e5L), Double.longBitsToDouble(0x3fe595b5c57934d4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 10, 15, "\udb23\udfdc\ud848\udf2f\ud9c0\udf4e\udba0\udf5d\ud8bd\udc0b\udb3c\ude9e\ud85f\udd38\ud997\udc9f\ud9a0\ude71\uda0c\udf11\ud807\uddf1\ud940\udf83", "\u9e0c\u8658\u29e4\u2daa\u53ce\ua6f2\u5fa0\ucf2b\u1ff0", "\uda8d\udc08\udac1\udcdf\uda90\ude7c\ud85b\udf59\u5071\udb8e\ude87\ud9b1\uddbe\u9e10\ud8a7\udff7\ud9ae\udce1\ud83c\udd7e\udbfb\udfb7\udb50\udcc6\udae8\ude6c\ud868\udeeb\ud8f3\udfa5\ud8ec\udf7b\udb96\udc48\ud8e2\uddf8\udacf\udd85\ud9b0\udec9",
        32, 5225, -617012844, 435101235020807727L, 60652L, true, true, (char) 3500, (char) 17035,
        Double.longBitsToDouble(0x3fe530e8cfd1cd02L), Double.longBitsToDouble(0x3fe83f421db96f4dL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.TypeCheck|checkInterfaceConflictProperties|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,java.lang.String,java.util.HashMap,java.util.HashMap,com.google.javascript.rhino.jstype.ObjectType|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|check|com.google.javascript.rhino.Node,boolean|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkDeclaredPropertyInheritance|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.FunctionType,java.lang.String,com.google.javascript.rhino.JSDocInfo,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkEnumAlias|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.JSDocInfo,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkNoTypeCheckSection|com.google.javascript.rhino.Node,boolean|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkPropCreation|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkPropertyAccess|com.google.javascript.rhino.jstype.JSType,java.lang.String,com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkPropertyAccessHelper|com.google.javascript.rhino.jstype.JSType,java.lang.String,com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkPropertyInheritanceOnGetpropAssign|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.rhino.JSDocInfo,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkTypeofString|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,java.lang.String|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|doPercentTypedAccounting|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|ensureTyped|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|ensureTyped|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|ensureTyped|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|getJSType|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|getNativeType|com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkInterfaceConflictProperties|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,java.lang.String,java.util.HashMap,java.util.HashMap,com.google.javascript.rhino.jstype.ObjectType|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
