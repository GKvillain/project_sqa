package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class ControlFlowAnalysis_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 8, "\udb62\udebf\ud956\ude5c\udaa8\ude98\udb6a\udf8d\uda23\udc3b\udb11\udf66\ud88a\udc5d\udb6f\udfe8\uda2c\ude6f\ud8fc\udd0c\uee0a\ud834\udf22\udb31\ude70\udbc0\udeff\ud8f1\udd85\udbce\udfa5\udb09\udfd0\udac6\udf39\udb3a\uded8\ud8bd\ude28\ud8f0\udf7f\ud8fe\udcb6\udb01\udc3a\udbff\udeb9\ud8cc\udead\ud93b\udc80\ud80e\udc52\udb69\udc7f", "\u1294", "\udad2\udfb2\ud81b\udcae\uda5a\udd7b\uda51\uddba",
        31, 69593, 1694672254, -8680387551046559544L, 31919L, false, false, (char) 60746, (char) 14377,
        Double.longBitsToDouble(0x3fe06ec16e81f33dL), Double.longBitsToDouble(0x3fc10b2602f665a0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 4, "\udb62\ude95\ud956\ude5c", "\u32f9\uc67b\uae37\ud536\u898a\u8ccf\u9b8d\u5a7d\u3184\ub336\u620d\u29ee", "\udbb3\udd8f\ud8bd\ude28\udad6\udf51\ud964\udd19\udb01\udc3a\udbff\udeb9\udaf2\udd18\udbb9\udc84",
        12, 42312, 1745867289, -8329648715265846876L, 31522L, false, true, (char) 38755, (char) 58101,
        Double.longBitsToDouble(0x3fb84a2f6413f9a8L), Double.longBitsToDouble(0x3fdca9c71f910f12L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 8, "\u5439\ud831\udf73\uda70\udf46\udb6a\udf8d\uda23\udc3b\udb11\udf66\ud88a\udc5d\udb6f\udfe8\uda2c\ude6f\ud8fc\udd0c\udab2\udefd\ud8c9\udee9\udb2d\uddaf\udbc0\udeff\ud8f1\udd85\udbce\udfa5\udb09\udfd0\udac6\udf39\udb3a\uded8\ud8bd\ude28\udb4f\ude0e\ud8fe\udcb6\udb01\udc3a\udbff\udeb9\ud917\udd72\ud93b\udc80\ud80e\udc52\udb69\udc7f", "\u1294", "\udad2\udfb2\ud81b\udcae\uda5a\udd7b\uda51\uddba",
        31, 69593, 1694672254, -8680387551046559544L, 31919L, false, false, (char) 60746, (char) 14377,
        Double.longBitsToDouble(0x3fe06ec16e81f33dL), Double.longBitsToDouble(0x3fc10b26038a79a0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 8, "\udb62\udebf\ud956\ude5c\udaa8\ude98\udaa5\udcca\uda22\udf3c\udb11\udf66\ud88b\udd58\u008a\ud861\udc2f\000\000\000\000\000\ud8f1\udd85\ue13a\udb10\udc87\udac6\udf39\udb3a\uded8\ud8bd\ude28\ud8f0\udf7f\ud8fe\udcb6\udb01\udc3a\udbff\udeb9\ud8cc\udead\ud93b\udc80\ud800\ude52\udb69\udc7f", "\u4000", "\udaa6\uddf2\ud8c8\udfa5\uda5a\udd7b\uda51\uddba",
        31, -903, 131072, 1394933760L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fdea4b61d5d92f4L), Double.longBitsToDouble(0x3fe06ec16e81003dL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 9, "\ud846\ude00", "\u93fa", "\ud857\udf17\udb6f\udfe8\ud88a\udcb0\ud894\udc37",
        53, 67359, 1237486390, 4180342124153460164L, 59546L, false, true, (char) 26978, (char) 5934,
        Double.longBitsToDouble(0x3fd856814c0dbb5cL), Double.longBitsToDouble(0x3fe2296cf803766bL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 0, "\udb62\udebf\ud956\ude5c\udaa8\ude98\udb6a\udf8d\uda23\udc3b\udb11\udf66\ud88a\udc5d\udb6f\udfe8\uda2c\ude6f\ud8fc\udd0c\u1c7b\ud982\udfe9\udb31\ude70\udbc0\udeff\ud8f1\udd85\udbce\udfa5\udb09\udfd0\udac6\udf39\udb3a\uded8\ud8bd\ude28\ud8f0\udf7f\ud8fe\udcb6\udb01\udc3a\udbff\udeb9\ud8cc\udead\ud93b\udc80\ud879\udff4\udb1a\udc44", "\u1294\u0cf1\ub235\u08ee\u0487\u917b\u0375\u7fe0\u0e5e\ub535\u6abc\ub353\ud5dd\u23af\u54cf\u1835\u39a7\u894b\u477b\u5eed\u1836\u9ef0\u8a85\ud1eb\u914a\u92e6\u25fa\uc49f", "\ud84d\udcb1",
        1, 6411, -24131345, -2113051645617307313L, -8800L, true, true, (char) 18079, (char) 15306,
        Double.longBitsToDouble(0x3fe61133bcb11b8cL), Double.longBitsToDouble(0x3feb6c6123fec723L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |a1=[I:[[56114, 56975]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 12, 8, "\udb62\udebf", "\u9466", "\udab8\ude52\ud82c\ude3d\uda2c\ude6f\ud8fc\udd0c",
        53, 79415, -574460741, 3995853967261897581L, 59546L, false, true, (char) 24490, (char) 5934,
        Double.longBitsToDouble(0x3fd3dd94bc0dbb5cL), Double.longBitsToDouble(0x3fd452d9f006ec34L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 15, "\udb62\udebf\ud956\ude5c\ud9b2\ude9c\udb6a\udf97\ud9ac\ude79\udad4\udf10\uda44\udf16\ud969\udf5a\uda52\ude1c\ud8fc\udd0c\u2f34\ud80a\udcde\udb31\ude70\udbc0\udeff\udb65\udda0", "\u7e45\u8ceb\u8b61\u948c\ud5f8\uc13e\u7f0e\ud763", "\udb69\udc7f\udbb7\udc3a\ud8fe\udd1a\udb8e\udc81",
        53, 59096, 554575552, 3573045288292050252L, 35415L, false, false, (char) 50562, (char) 30341,
        Double.longBitsToDouble(0x3fc910f125794c94L), Double.longBitsToDouble(0x3fdfc690b2162b5eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 8, "\udb62\udebf\ud956\ude5c\udaa8\ude57\udb6a\udf8d\uda19\ude71\ud929\udcb5\ud88a\udc3c\udb6f\udfe8\uda2c\ude6f\ud8fc\udd0c\uee0a\ud90a\ude2e\udb2a\udd1d\udbc0\udeff\ud8f1\udd85\udbce\udfa5\udb09\udfd0\udac6\udf39\uda26\udf2f\udb03\ude97\ud8f0\udfd4\udaf7\udfbb\ud876\udcd5\udbff\udeb9\ud8cc\udead\ud932\ude83\ud80e\udc52\udb69\udc7f", "\uc6a8", "\udad2\udfcd\ud84b\udde7",
        8, 54700, 683478936, 911265759802598782L, 57496L, false, true, (char) 31495, (char) 28346,
        Double.longBitsToDouble(0x3fec9cc90050434eL), Double.longBitsToDouble(0x3fdea4b61d5d92f4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |a1=[I:[[55278, 56339, 55590, 56876, 55928, 56936, 56122, 57181]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 4, 8, "\ud81e\udc43\ud956\ude5c\udaa8\ude98\udb6a\udf8d\uda23\udc3b\udb11\udf66\ud88a\udc5d\udb6f\udfe8\uda2c\ude6f\ud8fc\udd0c\uee0a\ud834\udf22\udbcd\udc7e\udbc0\udeff\ud8f1\udd85\udb6d\udd75\udae0\uddbd\udaaf\ude23\udb3a\uded8\ud94a\uddef\ud8f0\udf7f\ud8fe\udcb6\udb01\udc3a\ud8b1\ude32\ud8cc\udeb8\ud93b\udc80\ud80e\udc52\udb69\udc7f", "\u1294", "\udad2\udfb2\udaf0\udf7a\uda5a\udd7b\uda51\uddba",
        31, 69593, 1694672254, -8680387554284562235L, 31919L, false, false, (char) 60746, (char) 14377,
        Double.longBitsToDouble(0x3fe06ec16e81f33dL), Double.longBitsToDouble(0x3fc10b2602f665a0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 4, 8, "\udb62\udebf\ud956\ude5c\udaa8\ude98\udbb9\udc8a\uda23\udc3b\udb11\udf66\ud88a\udc5d\uda60\udc81\ud8ab\udeda\ud8fc\udd0c\udaef\ude04\ud834\udf22\udb31\ude70\udbc0\udeff\ud8f1\udd85\udbbb\udda5\udb09\udfd0\udac6\udf39\udb3a\uded8\ud8bd\ude28\ud8f0\udf7f\ud8fe\udcb6\udb01\udc3a\udbff\udeb9\ud8cc\udead\ud93b\udc80\udab5\uddec\ud854\udeff", "\u1294", "\udad2\udfb2\ud81b\udcae\uda5a\udd7b\uda51\uddba",
        24, 69593, 1694672254, -8680387551046559544L, -46740L, true, true, (char) 30459, (char) 14377,
        Double.longBitsToDouble(0x3fe06ec16e81f33dL), Double.longBitsToDouble(0x3fc10b2602f665a0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ControlFlowAnalysis:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 10, 2, "\udb62\udebf\ud956\ude5c\udaa8\ude98\udb6a\udf8d\uda23\udc3b", "\u930d\u82f4\u9e96\ub822\u8914\u3b77\ub41d", "\ud82f\ude58\udac2\udc79\udb3a\uded8\ud8bd\ude28\ud8f0\udf7f\ud94c\udceb",
        -3, 7971, -1356443791, 4405383441024169619L, 27041L, false, false, (char) 56843, (char) 40027,
        Double.longBitsToDouble(0x3fbc2d4e4e0278f0L), Double.longBitsToDouble(0x3fdc2210ea98632cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |a1=[I:[[55420, 56599, 55590, 56876, 55928, 56936]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 4, 5, "\ud8ac\udd47\ud956\ude5c\udaa8\ude98", "\uc67b\uae37\ud536\u82f4\u9e96\ub822\uba8a\u3184\ub336\u620d\u29ee\u3b12\ua3ea\u79fa\u8b61\ubcd8\u7418\u13cb\u7f27", "\ud80e\udc52\udb69\udc7f\udbba\udc3a\u9dd0\uda4b\udcde\udbe6\udd37\uda84\ude85\udad2\udfb2\uda99\udfcd\udae6\udf4a\uda4a\udc44\uda52\uddfe\udac5\udfb4\udb92\udefa\ud8d9\udc21",
        13, 11694, 363794940, -5065325775976266929L, 72522L, false, false, (char) 37954, (char) 22975,
        Double.longBitsToDouble(0x3fc10b2602f665a0L), Double.longBitsToDouble(0x3fedb88f0814fd9fL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ControlFlowAnalysis:@?\012",
        Z.run(T, 1, 6, 4, 8, "\udb62\udebf\ud956\ude5c\udaa8\ude98\udaa5\udcca\uda22\udf3c\udb11\udf66\ud88b\udd58\u008a\ud861\udc2f\ubd1d\000\000\000\ud8b1\udf2c\ud8f1\udd85\udbad\udeb9\udb10\udc87\udb4b\udddc", "\ubcd8\u7418\uc13e\u7f0e\ucf9d\ua15b\ud3b1\u57d2\000\u24a0\u5684\u013bp\u30a8\u32d5", "\uda52\uddfea\ud842\udc00\000\uda9f\udc2f\ufd41\ud82a\udde3\ud89c\udcf9\000\ud8a5\udc71\ud9bb\udeb3\ud8ab\udc55\uda63\ude10\ud867\ude67",
        14, 95625, -569174766, 2227135577199893530L, -77881L, false, true, (char) 48532, (char) 5570,
        Double.longBitsToDouble(0x3fe6d4e1ed142434L), Double.longBitsToDouble(0x3fd23bf279d5aaa2L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 14, "\ud846\ude00", "\u570a\u3284\uc67b", "\udbb2\uddac\ud893\udff6\uee0a\ud202\ud81b\ude87\ud8bc\uded8\ud9e1\udc9c\udbb7\udd92\udaa9\udd39\ud951\udcba\ud925\udcf3\uda85\ude0c\ud858\ude1c\ud9e3\udc3a\uda0c\udd3f\uda71\udd40\ud825\ude94\uda47\ude9b\uda03\udc7d\ud821\udd78\ud96d\udf11\ud939\udefe\udb2f\uddc8\udba5\udee8\udbba\udf88\udae1\ude36\udba4\uddcb\udbeb\udebb\udbc8\ude26",
        26, 4848, -487134921, 7702197017255053367L, -15822L, false, true, (char) 27750, (char) 45066,
        Double.longBitsToDouble(0x3fda78e0894184deL), Double.longBitsToDouble(0x3fe4f8773623a956L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ControlFlowAnalysis:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 9, "\ud846\ude00", "\u93fa", "\ud857\udf17\udb6f\udfe8\ud88a\udcb0\ud894\udc37",
        53, 67359, 1237486390, 4180342124153409732L, 59546L, false, true, (char) 26978, (char) 10047,
        Double.longBitsToDouble(0x3fd856814c0dbb5cL), Double.longBitsToDouble(0x3fe2296cf803766bL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ControlFlowAnalysis:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 14, 5, "\ud846\ude00", "\u93fa\ub429\u824c\ubcf0", "\ud86c\uddd6",
        51, 81995, 1237474628, 4180342124153467144L, 59546L, false, true, (char) 12655, (char) 6095,
        Double.longBitsToDouble(0x3fc0b3c9e9cdf734L), Double.longBitsToDouble(0x3fe9ae2bfefc1a9fL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |a1=[I:[[55318, 56784]]\0121=null |this=com.google.javascript.jscomp.ControlFlowAnalysis:@?\012",
        Z.run(T, 2, 7, 6, 12, "\ud846\ude00", "\u93fa", "\ud857\udef7\udb6f\udfe8\ud85a\udffc\ud86a\udee7",
        53, 67359, 1190134534, 4180464462001919428L, 59546L, false, true, (char) 26978, (char) 5934,
        Double.longBitsToDouble(0x3fde8ae14c0dbb5cL), Double.longBitsToDouble(0x3fe2296cf8037662L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 12, 8, "o", "\000", "\udab8\ude52\ud9b8\ude5b\uda2c\ude6f\ud8fc\udd0c",
        53, 61087, 0, 3963167672706470765L, 59546L, false, true, (char) 24490, (char) 16168,
        Double.longBitsToDouble(0x3fd3d0000c0dbb5cL), Double.longBitsToDouble(0x3fb14b67c0000000L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |a1=[I:[[56222, 57158, 56163, 56329, 56049, 56621, 56122, 57181]]\0121=null |a1=[I:[[56222, 57158, 56163, 56329, 56049, 56621, 56122, 57181]]\012",
        Z.run(T, 2, 7, 7, 5, "\udbce\udf76\udb93\udc39\udb21\udd5d\udb6a\udf8d\uda23\udc3b\ud9a1\uddd1\udab8\ude52\uda5d\uddd5\ud946\udd97\udb86\udc59\ud932\udf75\udbae\ude01\ud992\udea5\uda52\udf47\udba1\udd9a\udbce\udfa5\udb70\udcc3\ud87f\udd95\udb3e\udf89\ud827\uddbe", "\u7d29\u62c1\u85dc\u7d41\ucb29\uc28e", "\ud911\udd30\ud87a\udcdf\uda9e\udf6e\uda29\udc00\udb93\udf4c\udbcc\udccd\ud93e\udc1f\ud804\udfdd\udaa8\udc20\ud9a9\ude3a",
        17, 93425, -443314875, -3673604608225295695L, 20980L, false, true, (char) 10674, (char) 44413,
        Double.longBitsToDouble(0x3fe02d3a66550c2aL), Double.longBitsToDouble(0x3f932683bb704720L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ControlFlowAnalysis:@?\0121=null |this=com.google.javascript.jscomp.ControlFlowAnalysis:@?\012",
        Z.run(T, 2, 6, 6, 2, "\udb3a\udddb\udb98\ude6c\uda8a\udcb9\udb6a\udf8d\uda23\udc3b", "\u930d\u82f4\u9e96\ub822\u8914\u3b77\ub41d", "\udb03\ude38\udac2\udc8b\udb3a\uded8\ud8bd\ude28\ud8f0\udf7f\ud94c\udceb",
        -3, 7971, -1356400000, 4405383441024169619L, 27041L, false, false, (char) 56843, (char) 40027,
        Double.longBitsToDouble(0x3fbc2d4e4e0278f0L), Double.longBitsToDouble(0x3fdc25c0ea98632cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ControlFlowAnalysis:@?\0121=null |this=com.google.javascript.jscomp.ControlFlowAnalysis:@?\012",
        Z.run(T, 2, 6, 6, 9, "\ud846\ude00", "\u738a", "\ud822\udef2\udb6a\udce2\ud88a\udcb0\ud894\udc37",
        53, 67359, 1237486390, 8215567388085485252L, 5401L, false, true, (char) 6269, (char) 59383,
        Double.longBitsToDouble(0x3fd856814cc5bb5cL), Double.longBitsToDouble(0x3fe2296cf803766bL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 5, "\udbce\udf76\udb93\udc39\udb21\udd5d\udb6a\udf8d\uda23\udc3b\ud9a1\uddd1\udab8\ude52\uda5d\uddd5\ud946\udd97\udb86\udc59\ud932\udf75\udbae\ude01\ud992\udea5\uda52\udf47\udba1\udd9a\udbce\udfa5\udb70\udcc3\ud87f\udd95\udb3e\udf89\ud827\uddbe", "\u7d29\u62c1\u85dc\u7d41\ucb29\u39f7", "\ud911\udd30\ud87a\udcdf",
        57, 8254, 0, 3715713526464160918L, -6629L, false, false, (char) 55746, (char) 596,
        Double.longBitsToDouble(0x3f458c904f964c00L), Double.longBitsToDouble(0x3fe58e682253897eL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 8, "\udbb5\ude08\ud8db\udd6f\uda54\uddc8\udbb0\udefb\ud81e\udfcd\udb11\udf66\ud88a\udc5d\udb6f\udfe8\uda2c\ude6f\ud8db\udc0c\ud9ba\udeea\ud8b3\udedf\udb31\ude70\udbc0\udeff\ud8f1\udd85\udbce\udfa5\uda96\udcba\ud9a5\udf95\udb3a\udec5\ud8bd\ude28\ud8f0\udf7f\udbf8\udcd4\udb01\udc07\udbff\udeb9\ud8cc\udead\ud93b\udc80\ud80e\udc52\udb69\udc7f", "\u12c9", "\ud8d2\udeb2\ud85a\uddc8\uda5a\udd7b\uda51\uddba\ud9f0\udfce\uda7e\udccf\udb92\udf71",
        49, 50048, 100345737, 1562487371049294091L, -15952L, false, true, (char) 10764, (char) 17639,
        Double.longBitsToDouble(0x3fe40f9f18885930L), Double.longBitsToDouble(0x3fe63f7344d37fdaL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|mayThrowException|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|computeFallThrough|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|computeFollowNode|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ControlFlowAnalysis:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|computeFollowNode|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ControlFlowAnalysis:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|connectToPossibleExceptionHandler|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ControlFlowAnalysis:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|createEdge|com.google.javascript.rhino.Node,com.google.javascript.jscomp.ControlFlowGraph$Branch,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ControlFlowAnalysis:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|getCfg||new:com.google.javascript.jscomp.ControlFlowAnalysis:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|getNextSiblingOfType|com.google.javascript.rhino.Node,[I|static",
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|handleBreak|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ControlFlowAnalysis:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|handleCase|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ControlFlowAnalysis:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|handleCatch|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ControlFlowAnalysis:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|handleContinue|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ControlFlowAnalysis:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|handleDefault|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ControlFlowAnalysis:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|handleDo|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ControlFlowAnalysis:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|handleExpr|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ControlFlowAnalysis:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|handleFor|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ControlFlowAnalysis:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.ControlFlowAnalysis|mayThrowException|com.google.javascript.rhino.Node|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
