package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class CollapseProperties_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 2, 1, "\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9bf\ude8e\uc3d8\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9b7\udc2f\ud891\udc27", "\ucb88\u618e\u8f21\u4548", "\ud9d5\udec8\ud90a\udcf6\ud99d\uddf0\ud80b\ude89",
        32, 18151, -455998978, 4761731335067287946L, -90396L, true, true, (char) 14477, (char) 1954,
        Double.longBitsToDouble(0x3fd4ce73c4ea1816L), Double.longBitsToDouble(0x3fd0a8e2c53f8a84L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 2, 1, "\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\udaf6\udcdd\udace\ude65\udaeb\udd04\ubd5a\ud893\udda0\ud888\udd76\uc3d8\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9b7\udc2f\ud891\udc27", "\ucb88\u618e\u8f21\u4548", "\ud9d5\udec8\ud90a\udcf6\ud99d\uddf0\ud80b\ude89\ud8ee\udfea\ud9f6\udfff\udbcc\udc63\udbcf\udd50\ud8c5\udc44\ud832\udc90\uda32\uddd9",
        28, 85580, -415459088, 867964699078824565L, 38593L, false, false, (char) 53949, (char) 50677,
        Double.longBitsToDouble(0x3fe18dc446320761L), Double.longBitsToDouble(0x3fdbba6060df7eeeL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 2, 1, "\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9c7\udf11\uc3d8\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9b7\udc2f\ud891\udc27", "\ucb66", "\udbed\udff7\ud843\udc6c\u2a1b",
        19, 40637, -1032055115, -821195321928619648L, 31582L, false, true, (char) 33695, (char) 56210,
        Double.longBitsToDouble(0x3fe3e6afdf79f53bL), Double.longBitsToDouble(0x3fb300106f837590L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 2, 1, "\ud9e7\uddb0\uda99\udd8a\udb58\uddd6\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9bf\ude8e\ud8a2\ude6b\udb7b\udc15\uda25\udedb\uda66\udd82\udbc5\udc2e\udb9e\udce4\ud9af\udd53\ud9b6\udffd\ud891\udc27", "\ucb88\u618e\u8f21\u4548", "\ud9d5\udec8\ud90a\udcf6\udac8\udce5\ud972\udcc2",
        21, 18151, -455998978, 4761731335067287946L, -90396L, true, true, (char) 16261, (char) 1954,
        Double.longBitsToDouble(0x3fd4ce73c4ea1816L), Double.longBitsToDouble(0x3fd0a8e2c53f8a84L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 2, 1, "\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\ud95e\udf12\udbfd\udfac\uc8ae\udaea\udf77\udaf3\udc0b\ud9bf\ude8e\uc3d8\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9b7\udc2f\ud891\udc27\udb1d\udc89\ud831\udd22\udbf6\udf20\ud949\udea4\udb8b\udca6\udbed\udff7\ud843\udc6c\u2a1b", "\ua622\u2a1f\u292e\u5c6d\u49c7\u2fbe\u4780\ud33c\u55b9\u5fc6\u8b7e\u6b96\u9f92\u238c\ub76b\u475e\ud091\u388b\u8502\u1830\u481b\u300c\uc6d9\u64da\u634e\u7877\u1a05\u6b49\u7969\u7098\u6acc\u314a\u1501\ub722\u9197\u7194\u0e36\u4946\u5cc1\u570a\u5a01\ub73c\u7b3e\u6fc4\u40e4\u5c26\u950a\u7cbe", "\ud8ca\uddae\ud948\udf7c\ud92e\udff2\udbd4\udc15\udb54\udfe0\udb50\udc1c",
        10, 68620, -1033538086, -8929704442137415449L, 96430L, false, true, (char) 13467, (char) 41345,
        Double.longBitsToDouble(0x3fe5be9505f01498L), Double.longBitsToDouble(0x3fdd47ffe74f010eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 2, 1, "\ud9da\udeb7\udaad\udc8a\udb58\uddd6\ud95e\udf12\udbfd\udfac", "\ua91e\u0808\u25f6\u4cae", "\ud97a\udc69\udb9e\udd3e\udba5\udf7f\ud871\ude73\ud890\udff3\udb1d\udc89\ud831\udd22\udbf6\udf20",
        29, 90956, 675003801, 86661808086493386L, -44307L, false, true, (char) 24374, (char) 24091,
        Double.longBitsToDouble(0x3feafd09d9fe4e83L), Double.longBitsToDouble(0x3fd6ce4d2314842aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 2, 1, "\ud9ad\udf6f\udaad\udc8a\uda35\udc7b\ud989\udd17\udae6\udd1d\ud89d\udec5\udaa5\udc72\ud8ab\udc07\udb29\ude39\udb4c\udcf1\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud93b\ude19\ud891\udc27", "\ucb88\u618e\u8f21\u4548", "\uda7a\udf7b\ud90a\udd81\ud99d\uddf0\ud80b\ude89",
        32, 10751, -461676525, 4761731337568665994L, -90396L, true, true, (char) 9455, (char) 42112,
        Double.longBitsToDouble(0x3fe26739e2750cd2L), Double.longBitsToDouble(0x3fd0a8e2c53f8a84L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 7, 12, "\ud9e7\uddb0\udb1b\udddc\uda08\ude16\udb55\uddd2\u250d\udba8\udc39\udb62\udc7d\ud88d\udc39\udbe5\udd12\ud9f3\udc28\udab8\udf6d\ud951\udfc1\udabc\udc68\ud926\udc5f\udb9e\udd3e\udab6\udc07\ud9b7\udc2f", "\u9973\ucb88\ub942\u23e5\u73fd\u874c", "\ud90a\udcf6\uda34\udefb\ucd20\ud8ee\udfea\ud9f6\udfff\udbcc\udc63\udbcf\udd50\ud9bb\ude5b\ud908\ude97\u9470",
        5, 83956, 153986948, 867924536839639669L, -92479L, false, true, (char) 2736, (char) 56182,
        Double.longBitsToDouble(0x3fe5887899b073f1L), Double.longBitsToDouble(0x3fecdd7d97241934L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 2, 1, "\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\ud95e\udf12\ud979\udc09\udab7\ude0e\uda65\udef4\ud8ab\udc07\ud9bf\ude8e\uc3d8\udb4a\udea3\udba8\udf7c\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9b7\udc2f\ud891\udc27\udb1d\udc89\ud831\udd22\udbf6\udf20\ud949\udea4\udb8b\udca6\udbed\udff7\ud92a\udd3c\u2960\uda19\udfbf\ud90a\udcf6\ud99d\uddf0\ud80b\ude89\ud8e0\ude43\uda2a\uddcf\ud894\udf47\ud816\udcab\ud8c5\udc67", "\u5fc6\u8b7e\u6b96\u36ff\u238c\u4e11\ube31", "\ud938\udce0\udab3\udf6e\ud966\udc0d\ud918\ude5f\udb39\ude8c\ud95a\udde3",
        44, 76220, -1455211936, -8532023645563397426L, 869L, false, false, (char) 12849, (char) 18133,
        Double.longBitsToDouble(0x3fd9ddcfb565805aL), Double.longBitsToDouble(0x3fc8ac5fefc3fd54L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 1, "\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9bf\ude8e\uc3d8\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9b7\udc2f\ud891\udc27", "\ucb9b\u618e\u8f21\u4548\u55c6\u6a5f\u2e35\u527d\u4427\u29b3\u292e\u9f5b\u49c7\u2fbe\u4780\ud33c\uc0c6\u5fc6\u8b7e\u6b96\u9f92\u238c\u1a5f\ud069\u4661\u3bba\u215f", "\ud931\udc88\udb15\udcd7\ud954\udd66\ud9d2\udc76\ud9df\ude32",
        36, 21388, -269082906, 3188406435516431474L, -11463L, true, true, (char) 18850, (char) 54634,
        Double.longBitsToDouble(0x3fdc00454b463e54L), Double.longBitsToDouble(0x3fdce10cf15b9c94L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 2, 7, "\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\ud95e\udf12\udbfd\udfac\udb2e\udfeb\uda3c\udf83\udbd0\udca9\ud93a\udfc2\ud95a\ude62\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud9be\udfc6\udaf9\udc1f\ud998\ude38\ud9b6\udfd5\ud88e\udc27", "\ucb88\u618e\ud0ad\u561d", "\ud8fc\udc31\ud90a\udcf6\ud99d\uddf0\ud80b\ude89",
        32, 18151, -455998978, 4761731335067287946L, -90396L, true, false, (char) 49913, (char) 1954,
        Double.longBitsToDouble(0x3fd4ce73c4ea1816L), Double.longBitsToDouble(0x3fd0a8e2c53f8a84L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CollapseProperties:@?\012",
        Z.run(T, 1, 15, 9, 6, "\ud9e7\uddb0\udaad\udc8a\udb58\uddd6", "\uc9f5\u0a92\u62d4\ucf99\u590a\u4f0a\u6ea7", "\udb9e\udd3e",
        24, 25082, 202607473, 8739584053327890188L, -83001L, false, false, (char) 15776, (char) 57289,
        Double.longBitsToDouble(0x3fd4ddbf983fb0faL), Double.longBitsToDouble(0x3fec16538980f49aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\udacd\ude83\u5504\udb58\uddd6\ud95e\udf12\udbfd\udfac\udb39\udfcd\ud803\ude8e\udaf5\udc53\ud999\udd29\ud83b\udd4f\udaaa\udeb8\udbbf\udcb8\ud815\ude85\udaf4\udd00\udab7\udde7\udab8\udd04\ud8a7\udc7a\uda04\udde1$\u22e3\u618e\u815e\u052c\0121=java.lang.String:\udacd\ude83\u5504\udb58\uddd6\ud95e\udf12\udbfd\udfac\udb39\udfcd\ud803\ude8e\udaf5\udc53\ud999\udd29\ud83b\udd4f\udaaa\udeb8\udbbf\udcb8\ud815\ude85\udaf4\udd00\udab7\udde7\udab8\udd04\ud8a7\udc7a\uda04\udde1$\u22e3\u618e\u815e\u052c\012",
        Z.run(T, 2, 2, 2, 1, "\udacd\ude83\u5504\udb58\uddd6\ud95e\udf12\udbfd\udfac\udb39\udfcd\ud803\ude8e\udaf5\udc53\ud999\udd29\ud83b\udd4f\udaaa\udeb8\udbbf\udcb8\ud815\ude85\udaf4\udd00\udab7\udde7\udab8\udd04\ud8a7\udc7a\uda04\udde1", "\u22e3\u618e\u815e\u052c", "\ud9d5\udec8\u44da\ud99d\udddb\ud80b\ude89\uda43\udfb3\udb8b\udc33\udbcc\udc63\udbcf\udd50",
        9, 87866, -1374036499, 7330252770417610539L, -75756L, false, true, (char) 31150, (char) 35,
        Double.longBitsToDouble(0x3feb90a3c2df8f95L), Double.longBitsToDouble(0x3fd130bc7d2892deL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\ud9e7\uddb0\ud9e2\udc6c\udb58\uddd6\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9bf\ude8e\uc3d8\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9b7\udc2f\ud891\udc27$\ubc9d\u618e\u8f21\u4548\012",
        Z.run(T, 1, 2, 2, 1, "\ud9e7\uddb0\ud9e2\udc6c\udb58\uddd6\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9bf\ude8e\uc3d8\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9b7\udc2f\ud891\udc27", "\ubc9d\u618e\u8f21\u4548", "\udb2b\udf35\ud90a\udcf6\ud84f\ude69\udb60\ude58",
        32, 18151, -455998978, 4761731335067287946L, -90396L, true, true, (char) 14539, (char) 1954,
        Double.longBitsToDouble(0x3fe2af39e275e05eL), Double.longBitsToDouble(0x3fd0a8e2c53f8a84L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 7, 5, "\uda71\udd67\udaad\udc71\ud810\udf32\ud966\udd27\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\uda04\udfe5\ud85f\udfbd\uda65\udfd4\ud8f8\udc97\ud84c\udeab\ud94a\udce3\udb9e\udd3e\udab6\udc07\ud9b7\udc2f\ud891\udc27", "\ucb88\u618e\u8f21\u4548", "\ud9d5\udec8\ud90a\udcf6\ud99d\uddf0\ud80b\ude89\ud89d\udd41\uda56\ude69\u13ae\udbcf\udd50\ud8c5\udc44\ud81a\ude90\ubeb9\u60ab\udb90\udfd2\ud97b\udf7a\udad4\ude01\udad8\udfbf\udb48\udd93\ud8a0\uddcb\ud820\udfa5\udb06\udcc1\udaae\udcd1\udbc8\uddbc\ud86c\ude7e",
        43, 75722, -129353469, -6905989593602103410L, 89424L, true, false, (char) 31098, (char) 27171,
        Double.longBitsToDouble(0x3fb6ef0eefdb9b58L), Double.longBitsToDouble(0x3fe7d5927527fd7bL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CollapseProperties:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 6, 13, "\u0d3e\udaad\udcb5\udbaf\udc38\udb74\udf3c\uda37\udd06\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud941\udf0e\uc3d8\udab8\udf3a\ud996\udf85\ud865\udce2\udb35\ude5c", "\u71db\uccc0", "\ud94c\udf49",
        39, 90956, 675003801, 79395019774404810L, 61995L, false, true, (char) 28826, (char) 20609,
        Double.longBitsToDouble(0x3fd6ce4d2c2e4f5cL), Double.longBitsToDouble(0x3fda83c4696d61caL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 2, 1, "\udbdb\udfe4\udaa8\udc33\udb58\uddd6\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9c7\udf11\uc3d8\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9b7\udc2f\ud891\udc27", "\ucb66", "\udbed\udff7\ud843\udc6c\u2a1b",
        19, 40637, -1032055115, -821195321928619648L, 31582L, false, true, (char) 33695, (char) 56210,
        Double.longBitsToDouble(0x3fe3e6afdf79f53bL), Double.longBitsToDouble(0x3fb300105ab67958L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 0, 1, "\ud9e7\uddb0\uda99\udd8a\uda0a\ude4f\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9e5\udd8e\ud8a2\ude6b\udb7b\udc15\uda25\udedb\uda66\udd82\udb29\ude20\udb9e\udce4\ud9af\udd53\ud9b6\udffd\ud891\udc27", "\u6b10\u618e\u8f21\u4548", "\ud9d5\uddf2\udac3\udd52\udac8\udce5\udb8f\uddb1",
        15, 14071, -455999171, -1016668461825775989L, 87268L, true, true, (char) 16261, (char) 1954,
        Double.longBitsToDouble(0x3fd4ce73c4ea1816L), Double.longBitsToDouble(0x3fd0a8e2c53f8a84L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CollapseProperties:@?\012",
        Z.run(T, 1, 15, 2, 1, "\ud9ad\udf6f\udaad\udc8a\uda35\udc7b\ud989\udd17\udae6\udd1d\ud89d\udec5\udaa5\udc72\ud8ab\udc07\udb29\ude39\udb4c\udcf1\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud93b\ude19\ud891\udc27", "\ucb88\u618e\u8f21\ubd99", "\uda7a\udf7b",
        36, 4357, -191199435, -6828748410989928097L, 92148L, false, true, (char) 28842, (char) 45175,
        Double.longBitsToDouble(0x3febcfa9d8000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CollapseProperties:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 4, 5, "\ud838\ude23\uda8e\udfaa\ud8d9\udc8d\uda24\udf61\udae6\udd1d\udbb4\uddd1\ud932\ude79\uda0a\udf57\udb01\udc7d\udb4c\udcf1\ud965\ude39\udbbf\udcb8\uda66\udd82\ud97a\udcbd\udb9e\udd3e\udab6\udc07\ud93b\ude19\ud891\udc27", "\ucb7a", "\udbcc\udd50\ud843\udc6c\u2a1b",
        28, 83736, -503277626, -821195321928619648L, -83222L, false, true, (char) 45175, (char) 19637,
        Double.longBitsToDouble(0x3feaa9aa08f00b91L), Double.longBitsToDouble(0x3fe26739e2750cd2L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9bf\ude8e\uc3d8\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9b7\udc2f\ud891\udc27$\ucb9b\u618e\u8f21\u4548\u55c6\u6a5f\u2e35\u527d\u4427\u29b3\u292e\u9f5b\u49c7\u2fbe\u4780\ud33c\uc0c6\u5fc6\u8b7e\u4770\u9f92\u238c\u1a5f\ud069\u4661\u3bba\u215f\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 1, "\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9bf\ude8e\uc3d8\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9b7\udc2f\ud891\udc27", "\ucb9b\u618e\u8f21\u4548\u55c6\u6a5f\u2e35\u527d\u4427\u29b3\u292e\u9f5b\u49c7\u2fbe\u4780\ud33c\uc0c6\u5fc6\u8b7e\u4770\u9f92\u238c\u1a5f\ud069\u4661\u3bba\u215f", "\ud931\udc88\udb15\udcd7\ud954\udd66\ud9d2\udc76\ud9df\ude32",
        36, 21388, -269082906, 3188406435516431474L, -11463L, true, true, (char) 18850, (char) 54634,
        Double.longBitsToDouble(0x3fdc00454b463e54L), Double.longBitsToDouble(0x3fdce10cf15b9c94L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CollapseProperties:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 9, 6, "\ud9e7\uddb0\udae7\udc68\udb9a\uddf3\ud928\udd90\u064a\udab7\ude0e\ud94a\udd3c\ud8ab\udc07\ud8b7\udf10\udbae\ude16\uda0d\udfa2\udbbf\udc7e\ud942\udd2d\udaf5\ude82\ud850\udeba\udab6\udc07\ud9b7\udc2f", "\u9973", "\uda23\udc7d\ud86f\uddaf\ud93e\udcf1\udbdc\udc4f\ud84f\udeb7\udbcd\udebe\u60f7\ud80b\uded6\uf510\ud8c4\udf91\udae5\udeda\ud8d6\udfe7\uda66\udd41\ud8ff\udec2\ud9d2\ude32\ud8fb\udd8d\ud91d\udcb0\ud8c0\udc4b",
        31, 18927, -1951189760, -2760770419036842876L, -98822L, false, false, (char) 31213, (char) 60057,
        Double.longBitsToDouble(0x3fdf6b4c0843a6b6L), Double.longBitsToDouble(0x3f99cf193c824560L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:\udacd\ude83\u5504\uda72\udd03\ud95e\udf12\uda86\udd79\ud83c\udeed\udad0\udd16\uda28\uddcb\ud820\udf6c\ud83b\uddd9\udaaa\udeb8\udbbf\udcb8\ud815\ude85\udaf4\udd00\udab7\udde7\udab8\udd04\ud8a7\udc7a\uda04\udde1$\u22e3\u618e\u815e\u052c\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 1, "\udacd\ude83\u5504\uda72\udd03\ud95e\udf12\uda86\udd79\ud83c\udeed\udad0\udd16\uda28\uddcb\ud820\udf6c\ud83b\uddd9\udaaa\udeb8\udbbf\udcb8\ud815\ude85\udaf4\udd00\udab7\udde7\udab8\udd04\ud8a7\udc7a\uda04\udde1", "\u22e3\u618e\u815e\u052c", "\uda30\udff5\uda37\udec9\ud99d\udddb\ud80b\ude89\ud927\udfe5\udab0\ude7b\ud8af\udd36",
        42, 41234, 1184773386, 3983955844869052045L, -99716L, false, true, (char) 34289, (char) 31150,
        Double.longBitsToDouble(0x3fe9a942fc852201L), Double.longBitsToDouble(0x3fefcd65b5130bc7L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:\udacd\ude83\u5504\udb58\uddd6\ud95e\udf12\udbfd\udfac\udb39\udfcd\ud803\ude8e\udaf5\udc53\ud999\udd29\ud83b\udd4f\udaaa\udeb8\udbbf\udcb8\ud815\ude85\udaf4\udd00\udab7\udde7\udab8\udd04\ud8a7\udc7a\uda04\udde1$\u22e3\u618e\u815e\u052c\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 1, "\udacd\ude83\u5504\udb58\uddd6\ud95e\udf12\udbfd\udfac\udb39\udfcd\ud803\ude8e\udaf5\udc53\ud999\udd29\ud83b\udd4f\udaaa\udeb8\udbbf\udcb8\ud815\ude85\udaf4\udd00\udab7\udde7\udab8\udd04\ud8a7\udc7a\uda04\udde1", "\u22e3\u618e\u815e\u052c", "\ud9d5\udec8\u44da\ud99d\udddb\ud80b\ude89\uda43\udfb3\udb8b\udc33\udbcc\udc63\udbcf\udd50",
        9, 87866, -1374036499, 7330252770417610539L, -75756L, false, true, (char) 31150, (char) 35,
        Double.longBitsToDouble(0x3fbbff1e0ad11c50L), Double.longBitsToDouble(0x3fe0b7f4da1e2c51L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\udacd\ude83\u5504\udb58\uddd6\udb13\udeeb\udbf7\ude4c\udb39\udfcd\ud803\ude8e\udaf5\udc53\ud999\udd29\ud83b\udd4f\udaaa\udeb8\ud832\udde4\ud815\ude85\ud935\udc20\udab7\udde7\udab8\udd04\ud8a7\udc62\uda04\udde1$\u22e3\u9271\u7b8a\u052c\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 15, 12, "\udacd\ude83\u5504\udb58\uddd6\udb13\udeeb\udbf7\ude4c\udb39\udfcd\ud803\ude8e\udaf5\udc53\ud999\udd29\ud83b\udd4f\udaaa\udeb8\ud832\udde4\ud815\ude85\ud935\udc20\udab7\udde7\udab8\udd04\ud8a7\udc62\uda04\udde1", "\u22e3\u9271\u7b8a\u052c", "\ud9d5\udec8\u44da\ud99d\udddb\ud80b\ude89\uda43\udfb3\udb8b\udc33\udbcc\udc63\udbcf\udd50",
        9, 87866, -1374036499, 7330252770417610539L, -75756L, true, true, (char) 28440, (char) 35,
        Double.longBitsToDouble(0x3feb90a3c2df8f95L), Double.longBitsToDouble(0x3fdce3a81d289290L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CollapseProperties:@?\0121=void |this=com.google.javascript.jscomp.CollapseProperties:@?\012",
        Z.run(T, 2, 15, 15, 13, "\u0d3e\udaad\udcb5\udb60\udf52\udb88\udcdd\uda37\udd06\ud86a\udd11\ud9bd\udda9\ud8ab\udc07\ud93f\udd0e\uffd8\udab8\udf3a\ud996\udf85\udb92\udeeb\udac4\ude6b", "\u71db\uc5b3", "\ud94c\udf49",
        39, 90905, 675003801, 79395019774371018L, 149L, false, true, (char) 28826, (char) 20609,
        Double.longBitsToDouble(0x3fd6ce4d2c2e4f5cL), Double.longBitsToDouble(0x3fda83c4696d61caL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CollapseProperties:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 4, 5, "\ud838\ude23\uda8e\udfaa\ud8d9\udc8d\uda24\udf61\udae6\udd1d\udbb4\uddd1\ud916\udca7\uda0a\udf57\udb01\udc7d\ud9c5\udde4\ud965\ude39\udbbf\udcb8\uda66\udd82\ud97a\udcbd\udb9e\udd3e\udab6\udc07\ud93b\ude19\ud891\udc27", "\ucb7a", "\udbcc\udd50\ud843\udc6c\u2a1b",
        28, 83736, 378836934, -821194845187246976L, -83222L, false, true, (char) 45175, (char) 19637,
        Double.longBitsToDouble(0x3feaa9aa08f00b91L), Double.longBitsToDouble(0x3fe26739e2750cd2L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CollapseProperties:@?\0121=void |this=com.google.javascript.jscomp.CollapseProperties:@?\012",
        Z.run(T, 2, 15, 15, 5, "\ud838\ude23\uda8e\udfaa\ud8d9\udc8d\uda24\udf61\udae6\udd1d\udbb4\uddd1\ud932\ude79\uda0a\udf57\udb01\udc7d\udb4c\udcf1\ud965\ude39\udbbf\udcb8\uda68\udd5b\ud97a\udcbd\udb9e\udd3e\ud882\udeed\ud9a8\udf45\udb90\udd71", "\u9027\u1e8f", "\ud843\udc6c\u2a1b\uda7a\udf7b\ud805\udd3e\ud99d\ude01\ud80b\ude89\ud8ee\udfea\ud840\udf2a",
        55, -959, 1000358282, -3027768007591208324L, 29877L, false, false, (char) 51093, (char) 7964,
        Double.longBitsToDouble(0x3fe9b13af2e9c2e6L), Double.longBitsToDouble(0x3fd1ccd1971738f2L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9bf\ude8e\uc3d8\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud97a\udc69\ud900\uddcb\udab5\udff1\ud9b7\udc2f\ud805\udd5e$\ucb9b\u7942\u8f21\u4548\u55c6\ubb5e\u2e35\u527d\u4427\u29b3\u292e\u9f5b\u49c7\u2fbe\u4780\ud33c\uc0c6\u5fc6\u8b7e\u4770\u9f92\u238c\u1a5f\ud069\u31e5\u3bba\uaeb7\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 1, "\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9bf\ude8e\uc3d8\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud97a\udc69\ud900\uddcb\udab5\udff1\ud9b7\udc2f\ud805\udd5e", "\ucb9b\u7942\u8f21\u4548\u55c6\ubb5e\u2e35\u527d\u4427\u29b3\u292e\u9f5b\u49c7\u2fbe\u4780\ud33c\uc0c6\u5fc6\u8b7e\u4770\u9f92\u238c\u1a5f\ud069\u31e5\u3bba\uaeb7", "\ud931\udc88\udb15\udcd7\ud954\udd66\ud91c\udf65\ud9de\udedf\udb08\udd90\udbad\udcb5\u8df4\uda18\udd5e",
        36, 99506, 1722112473, 7803156734652636504L, 85639L, true, false, (char) 37493, (char) 18597,
        Double.longBitsToDouble(0x3fe27b6bb20a4a6eL), Double.longBitsToDouble(0x3fec8821aeab7ad7L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 2, 1, "\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\ud95e\udf12\ud9ea\udcab\ud809\udf5a\udabe\ude41\ud8ab\udc07\ud9bf\ude8e\uc3d8\udab8\udf3a\ud980\udcf8\ud807\udd47\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9b7\udc2f\ud871\udf97", "\u6788\u4c85\u4f8e\u176e\u5777\u6b6b\u1b3e\ud0c5", "\udbf1\udfb8\udb07\udd4e\uda27\udf84\ud8e8\udf7d\ud927\udd8f\ud81a\ude90\uda32\uddd9",
        28, 85580, -415459088, 867964699078824565L, -92479L, true, true, (char) 6798, (char) 1085,
        Double.longBitsToDouble(0x3fe96f9b09fdc908L), Double.longBitsToDouble(0x3fe6988c23a4e7eaL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String:\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9bf\ude8e\uc3d8\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9d4\udc1e\ud891\udca7$\ucb9b\u618e\u8f21\u4548\u55c6\u6a5f\u2e35\u527d\u4427\u29b3\u292e\u9f5b\u49c7\u2fbe\u4780\ud33c\uc0c6$0\u8bca\u4770\u9f92\u238c\u1a5f\ud069\u4661\u3bba\u215f\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 1, "\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9bf\ude8e\uc3d8\udab8\udf3a\udbbf\udcb8\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9d4\udc1e\ud891\udca7", "\ucb9b\u618e\u8f21\u4548\u55c6\u6a5f\u2e35\u527d\u4427\u29b3\u292e\u9f5b\u49c7\u2fbe\u4780\ud33c\uc0c6$\u8bca\u4770\u9f92\u238c\u1a5f\ud069\u4661\u3bba\u215f", "\ud931\udc88\udb15\udcd7\ud954\udd66\ud9d2\udc76\ud9df\ude32",
        36, 21388, -269082906, 3188406435516431474L, -11463L, true, true, (char) 18850, (char) 54634,
        Double.longBitsToDouble(0x3fdc00454b463e54L), Double.longBitsToDouble(0x3fdce10cf15b9c94L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String:\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9bf\ude8e\uc3d8\uda4d\ude65\udbbf\udc9a\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9d4\udc1e\ud891\udca7$\ucb9b\u618e\u8f21\u4548\u55c6\u6a5f\u2e35\u527d\u4427\u29b3\u292e\u9f5b\u49c7\u2fbe\u4780\ud33c\uc0c6$0\u8bca\u4770\u9f92\u238c\u1a5f\ud069\u4661\u3bba\u215f\0121=java.lang.String:\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9bf\ude8e\uc3d8\uda4d\ude65\udbbf\udc9a\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9d4\udc1e\ud891\udca7$\ucb9b\u618e\u8f21\u4548\u55c6\u6a5f\u2e35\u527d\u4427\u29b3\u292e\u9f5b\u49c7\u2fbe\u4780\ud33c\uc0c6$0\u8bca\u4770\u9f92\u238c\u1a5f\ud069\u4661\u3bba\u215f\012",
        Z.run(T, 2, 2, 2, 12, "\ud9e7\uddb0\udaad\udc8a\udb58\uddd6\ud95e\udf12\udbfd\udfac\udab7\ude0e\udabe\ude41\ud8ab\udc07\ud9bf\ude8e\uc3d8\uda4d\ude65\udbbf\udc9a\uda66\udd82\ud97a\udc69\udb9e\udd3e\udab6\udc07\ud9d4\udc1e\ud891\udca7", "\ucb9b\u618e\u8f21\u4548\u55c6\u6a5f\u2e35\u527d\u4427\u29b3\u292e\u9f5b\u49c7\u2fbe\u4780\ud33c\uc0c6$\u8bca\u4770\u9f92\u238c\u1a5f\ud069\u4661\u3bba\u215f", "\ud931\udc88\udb15\udcd7\ud954\udd66\ud9d2\udc76\ud9df\ude32",
        36, 21388, -269082906, 8664783582387776771L, -11463L, true, true, (char) 18850, (char) 54634,
        Double.longBitsToDouble(0x3fdc00454b463e54L), Double.longBitsToDouble(0x3fdce10cf15b9c94L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.CollapseProperties|inlineAliases|com.google.javascript.jscomp.GlobalNamespace|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|addStubsForUndeclaredProperties|com.google.javascript.jscomp.GlobalNamespace$Name,java.lang.String,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|appendPropForAlias|java.lang.String,java.lang.String|static",
    "M|com.google.javascript.jscomp.CollapseProperties|checkForHosedThisReferences|com.google.javascript.rhino.Node,com.google.javascript.rhino.JSDocInfo,com.google.javascript.jscomp.GlobalNamespace$Name|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|checkNamespaces||new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|collapseDeclarationOfNameAndDescendants|com.google.javascript.jscomp.GlobalNamespace$Name,java.lang.String|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|declareVarsForObjLitValues|com.google.javascript.jscomp.GlobalNamespace$Name,java.lang.String,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|flattenNameRef|java.lang.String,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,java.lang.String|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|flattenNameRefAtDepth|java.lang.String,com.google.javascript.rhino.Node,int,java.lang.String|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|flattenPrefixes|java.lang.String,com.google.javascript.jscomp.GlobalNamespace$Name,int|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|flattenReferencesTo|com.google.javascript.jscomp.GlobalNamespace$Name,java.lang.String|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|flattenReferencesToCollapsibleDescendantNames|com.google.javascript.jscomp.GlobalNamespace$Name,java.lang.String|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|flattenSimpleStubDeclaration|com.google.javascript.jscomp.GlobalNamespace$Name,java.lang.String|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|inlineAliasIfPossible|com.google.javascript.jscomp.GlobalNamespace$Ref,com.google.javascript.jscomp.GlobalNamespace|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|updateFunctionDeclarationAtFunctionNode|com.google.javascript.jscomp.GlobalNamespace$Name,boolean|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
    "M|com.google.javascript.jscomp.CollapseProperties|inlineAliases|com.google.javascript.jscomp.GlobalNamespace|new:com.google.javascript.jscomp.CollapseProperties:com.google.javascript.jscomp.AbstractCompiler,boolean,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
