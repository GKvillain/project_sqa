package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class FlowSensitiveInlineVariables_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 3, "\udbc8\udd33\udad9\udc7e\udb96\udf53\udad5\uddb9\u8c7c\ud829\ude4d\ud8eb\ude3f\udb5a\udfa1\udb6d\ude6d\ud9d3\udd02\ud917\udca3\udb27\udc55\udb82\udd72\u321b\udaf9\udc59\ud9d5\udd36\ud926\udec1\uda94\udc2c\ud88c\udc0a\udb35\udf58\ud85e\udc17\ud80c\udc93\ud85b\udd1e\udaf7\udccb\ud8d5\udf73\ud89a\udf3f\udb56\udca9\ud911\udf45\ud89c\udd80\ud9ce\udc59", "\u1022\u7b12\u0a4d", "\ud904\udd86\ud8fe\udd20",
        7, 18019, -998756000, 5496186185130922100L, 81650L, true, true, (char) 2409, (char) 60935,
        Double.longBitsToDouble(0x3fe9f0bab4fd4de6L), Double.longBitsToDouble(0x3fe13e811e807011L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 4, "\udbc8\udd33\udad9\udc7e\udb96\udf53\udad5\uddb9\u8c7c\ud829\ude4d\ud8eb\ude3f\udb5a\udfa1\udb6d\ude6d\ud9d3\udd02\ud917\udca3\udb27\udc55\udb82\udd72\u321b\udaf9\udc59\ud9d5\udd36\ud926\udec1\udaf1\ude6a\uda81\udf2b\udb35\udfb3\ud85e\udc17\ud80c\udc93\ud85b\udd1e\udaf7\udccb\ud8d5\udf73\ud89a\udf3f\udb56\udca9\ud928\udc45\ud921\ude63\udb43\ude3c", "\u1022\u7b12\u0a4d\u46de\ucecb\u11f6", "\ud84d\udc33",
        0, 9567, 539185268, -7246351211161372050L, 38046L, true, false, (char) 61002, (char) 46737,
        Double.longBitsToDouble(0x3fe3565293934f0bL), Double.longBitsToDouble(0x3fdb2d18bd3a51f6L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 3, "\udbc8\udd33\udad9\udc7e\udb96\udf53\udad5\uddb9\u8c7c\ud829\ude4d\ud8eb\ude3f\udb5a\udfa1\udb6d\ude6d\ud9d3\udd02\ud917\udca3\udb27\udc55\udb82\udd72\u321b\udaf9\udc59\ud9d5\udd36\ud926\udec1\uda7d\udf2c\ud88c\udc0a\udb35\udf58\ud85e\udc17\ud80c\udc93\ud85b\udd1e\udaf7\udccb\ud8d5\udf73\ud89a\udf3f\udb56\udca9\ud911\udf45\ud89c\udd80\ud9ce\udc59", "\u1022\u7b12\u0a4d", "\ud904\udd86\ud8fe\udd20",
        33, -1000, 7876960, 5496186185130922100L, -100000L, false, true, (char) 12948, (char) 6883,
        Double.longBitsToDouble(0x3fe13e811e807011L), Double.longBitsToDouble(0x3fc8841a17389558L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 3, "\udbc8\udd33\udad9\udc7e\udb96\udf53\udad5\uddb9\ud843\udc8b\ud829\ude03\ud8eb\ude3f\udb5a\udfa1\udb6d\ude6d\ud9d3\udd02\ud917\udca3\udb27\udc55\udb82\udd72\u321b\udaf9\udc59\ud9d5\udd36\ud926\udec1\uda94\udc2c\ud88c\udc0a\udb35\udf58\ud96a\udd3c\ud811\udfb3\ud85b\udd1e\udaf7\udccb\ud8d5\udf73\ud8c1\udcca\udb56\udca9\ud911\udf45\ud89c\udd80\ud9ce\udc59", "\u1022\u7b12\u0a4d", "\ud904\udd86\ud8fe\udd20",
        7, 98074, -998756038, 5496186185130922100L, 81650L, true, true, (char) 2409, (char) 60935,
        Double.longBitsToDouble(0x3fe9f0bc5cfd4de6L), Double.longBitsToDouble(0x3fe13e811e807011L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\0121=void |this=com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\012",
        Z.run(T, 2, 3, 3, 3, "\udbc8\udd33\udad9\udc7e\udb96\udf53\udad5\uddb9\u8c7c\ud829\ude4d\ud8eb\ude3f\udb5a\udfa1\udb6d\ude6d\ud9d3\udd02\ud917\udca3\udb27\udc55\udb82\udd72\u321b\ud86a\udccc\udae8\udd1c\ud926\udec1\uda94\udc2c\ud88c\udc0a\udb35\udf58\ud85e\udc17\ud80c\udc93\ud85b\udd67\udaf7\udccb\ud8d5\udf73\ud89a\udf3f\udb56\udca9\ud911\udf45\ud89c\udd80\ud9ce\udc59", "\u1022\u7b12\u0a4d", "\ud904\udd86\ud8fe\udd20",
        7, 85819, 1471310050, 6590367978541907576L, -28904L, true, true, (char) 2409, (char) 60935,
        Double.longBitsToDouble(0x3fe9f0bab3fd4de6L), Double.longBitsToDouble(0x3fa38b87680708b0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 1, "\udbc8\udd33\udb1b\ude7f\ud936\udd6e\udab7\udf35\ud983\udd6d\udbd1\udec2\ud8eb\ude0e\udb5a\udfa1\udb6d\ude6d\ud9d3\udd02\udbdd\udca6\udb27\udc55\udba9\udf65\u471d\udaf9\udc59\ud9d5\udd36\ud926\udec1\uda94\udc2c\ud88c\udc0a\udb35\udf58\ud85e\udc17\ud80c\udc93\udbb4\udeec\udb23\ude6d\ud8d5\udf73\ud89a\udf3f\udb56\udca9\ud911\udf45\ud89c\udd80\ud9ce\udc59", "\u1022", "\udb7b\udf95\udb45\uddf8",
        3, 56314, -977193218, 1261547939557814624L, 9458L, true, true, (char) 39465, (char) 28450,
        Double.longBitsToDouble(0x3fe9f0bab4fd28ccL), Double.longBitsToDouble(0x3fd27d0237b4c782L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 3, "\udbc8\udd33\udad9\udc7e\udb96\udf53\udad5\ude82\u8c7c\udb85\udd1b\ud9fb\udfa1\udb5a\udfa1\udb6d\ude6d\ud9d3\udd02\ud917\udca3\udb27\udc55\udba3\udc21\ud846\udcd1\udb2d\udc59\udbf2\ude25\ud83f\ude29\uda17\udc28\ud88c\udc0a\udb35\udf58\ud85e\udc17\ud80c\udc93\ud85b\udd1e\udaf7\udccb\ud8d5\udf73\ud89a\udf3f\udb56\udca9\ud911\udf45\ud89c\udd09\ud9ce\udc59", "\u1022\u7b12\u0a4d", "\ud904\udd86\ud8fe\udd20",
        7, 18019, -998756000, 5792196357668425844L, 81650L, true, true, (char) 28844, (char) 60935,
        Double.longBitsToDouble(0x3fe9f0bab4fd4de6L), Double.longBitsToDouble(0x3fe13e811945f211L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=void |this=com.google.javascript.jscomp.FlowSensitiveInlineVariables:@?\012",
        Z.run(T, 2, 1, 3, 5, "\ud82c\ude73\udad9\udc86\udb96\udf53\udad5\uddb9\udbd9\ude3f\ud829\udea4\ud8eb\ude3f\udb5a\udfa1\udb6d\ude6d\ud9d3\udd02\ud917\udca3\udb27\udc55\udb82\udd72\u321b\ud8de\udd48\ud97a\udf48\ud926\ude3f\uda94\udc2c\ud88c\udc0a\udb35\udf58\ud85e\udc17\ud80c\udc93\ud85b\udd1e\udaf7\udccb\ud8d5\udf73\ud89a\udf3f\udb56\udca9\ud911\udf45\ud89c\udd80\ud958\ude32", "\u510d\u0191\u4b4d", "\ud904\udd86\ud8fe\udd20\ud8f0\udf8f\ud84d\udc33\udb87\udddd\udad7\udcb5\udb5e\ude58\uda9f\udc5c\ud847\udfe9\udb83\udde5\ud889\udfed\ud806\udc78",
        -5, 89869, 1880170023, -1994454168960617483L, 2217L, false, true, (char) 27557, (char) 58163,
        Double.longBitsToDouble(0x3f447659d437c800L), Double.longBitsToDouble(0x3fdbb1d476fe4aacL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 3, "\udbc8\udd33\udad9\udc7e\udb96\udf53\udad5\uddb9\udaa4\udfbb\ud88e\udd6c\ud8eb\ude74\udb5a\udfa1\udb6d\ude6d\ud9d3\udd02\ud917\udca3\udb27\udc55\udb82\udd72\u321b\udaf9\udc59\ud9d5\udd36\ud926\udec1\uda94\udc2c\ud88c\udc0a\ud8fb\udf5b\ud85e\udc17\ud80c\udc93\ud85b\udd1e\udaf7\udccb\ud9b4\udd83\ud89a\udf3f\udb56\udca9\ud911\udf45\ud89c\udd80\ud9ce\udc59", "\u1022\u7b12\u0a4d", "\ud904\udd86\ud8fe\udd20",
        7, 18019, 1126107937, 5496093778909548660L, 81650L, true, true, (char) 2409, (char) 60935,
        Double.longBitsToDouble(0x3fe9f0bab4fd4de6L), Double.longBitsToDouble(0x3fe13e81196a7011L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 5, "\udac7\ude92\udad9\udc7e\udb96\udf53\uda54\udc39\u8cc3\ud829\ude4d\ud8eb\ude3f\udb5a\udfa1\udb6d\ude6d\ud9d3\udd02\ud917\udca3\udb27\udc55\udb82\udd72\udb50\uddfc\uda3e\udc22\uda37\ude1f\ud926\udec1\udaf5\ude43\u34fc\udb35\udf58\ud882\udc48\ud804\udc3d\ud85b\udd1e\udaf7\udccb\ud8d5\udf73\ud8b1\udd3f\udb56\udca9\ud911\udf45\ud89c\udd80\ud9ce\udc59", "\u1022\u7b12\u0a4d", "\ud904\udd86\ud8fe\udd20",
        7, 18019, -998756000, 5496186185130922100L, -19487L, true, true, (char) 2409, (char) 60935,
        Double.longBitsToDouble(0x3fe9f0bab4a84de6L), Double.longBitsToDouble(0x3fe13e811e807011L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 1, 1, 5, "\udbc8\udd33\udad9\udc7e\udb96\udf53\udad5\uddb9\u8c7c\ud829\ude4d\udb65\ude5c\udb5a\udfa1\udb6d\ude6d\ud9d3\udd02\udb8b\ude29\uda60\udde7\ud994\udd90\u321b\udaf9\udc59\ud9d5\udd36\ud926\udec1\uda7d\udf2c\ud88c\udc0a\udb35\udf58\ud85e\udc17\ud80c\udc93\uda7c\udcca\ud906\udf7a\ud95f\ude5d\ud89a\udf48\udb56\udca9\ud911\udf45\ud89c\udd80\ud9ce\udc59", "\u1022\u7b12\u0a4d", "\udaaf\uddca\ud8fe\udd20",
        33, 31662, 7876960, 5496186186624094324L, -100000L, false, true, (char) 12948, (char) 6883,
        Double.longBitsToDouble(0x3fe57e811804a1e5L), Double.longBitsToDouble(0x3fe2ec26791eb322L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 3, "\ud8df\udedf\ud910\udd2d\ud9dd\udef7\udad5\ude8d\u8cb6\uda8d\udfe0\ud8eb\ude3f\udb5a\udfa1\udb6d\ude6d\ud9d3\udd02\ud917\udca3\udb27\udc71\udb82\udd72\u321b\udaf9\udc59\ud9d5\udd36\ud926\udec1\uda94\udc2c\ud88c\udc0a\udb35\udf58\u4f53\ud80c\udc30\ud85b\udd1e\udaf7\udccb\ud8d5\udf73\ud89a\udf3f\udb56\udca9\udbc0\udf9d\uda55\udd72\ud9ce\udc59", "\u7a8a\u8e90\u09e5", "\ud904\udd86\ud8fe\udd20",
        7, 18019, -998756000, 5496186185130922100L, -19506L, true, true, (char) 2409, (char) 60935,
        Double.longBitsToDouble(0x3fe9f0bab4613e3aL), Double.longBitsToDouble(0x3fed9e695e806a7fL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.FlowSensitiveInlineVariables|checkLeftOf|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.FlowSensitiveInlineVariables|checkRightOf|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.FlowSensitiveInlineVariables|enterScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.FlowSensitiveInlineVariables:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FlowSensitiveInlineVariables|exitScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.FlowSensitiveInlineVariables:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FlowSensitiveInlineVariables|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FlowSensitiveInlineVariables:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FlowSensitiveInlineVariables|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FlowSensitiveInlineVariables:com.google.javascript.jscomp.AbstractCompiler",
    "C|com.google.javascript.jscomp.FlowSensitiveInlineVariables|<init>|com.google.javascript.jscomp.AbstractCompiler",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
