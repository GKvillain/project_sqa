package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class GlobalNamespace_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 6, "\ud901\ude6c\udb90\udd99\ud889\udd20\udb6e\ude18\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud85b\udcda", "\u0f5b\u72b0\u7420\ua7ab\u1f60\u1da9\u9c8a\u5907\u20f7\u9f97\u0aa6\ud4d1\ua5d7\u79de\u132e\u9d47\u523b\u316d\u8565\u2cdf\u186f", "\ub9ec\uda25\udf26\udb11\udfa8",
        25, 75222, 829271481, -5611924816211424682L, 50198L, false, false, (char) 4070, (char) 22526,
        Double.longBitsToDouble(0x3fd57d208bc137deL), Double.longBitsToDouble(0x3feb3f7cb4652eecL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 6, "\ud901\ude6c\udb90\udd99\ud889\udd20\udb6e\ude18\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud85b\udcda", "\u0f5b\u72b0\u7420\ua7ab\u1f60\u1da9\u9c8a\u5907\u20f7\u9f97\u0aa6\ud4d1\ua5d7\u9143\u1334\u9d47\u523b\u316d\u8565\u2cdf\u186f", "\ub9ec\uda25\udf26\udb11\udfa8",
        25, 75222, 829271481, -5611924816211424682L, 50198L, false, false, (char) 4070, (char) 28352,
        Double.longBitsToDouble(0x3fdb7f86dbc137deL), Double.longBitsToDouble(0x3feb3f7cb4652eecL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:\ud919\udf6c\udb90\udd99\ud907\udf3f\ud985\ude5a\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud971\udce5 |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 6, 6, "\ud919\udf6c\udb90\udd99\ud907\udf3f\ud985\ude5a\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud971\udce5", "\uc55b\u72b0\u7420\ua7ab\u1f60\u1da9\u9c8a\u42cb\u20f7\u9f97\u0aa6\ud4d1\ua5d7\u79de", "\uda03\udff6\udbc2\udd64\ud8d8\udcc2\ud8eb\udead\ud8b5\ude88\ud8d8\udf3e\udadf\udd43\ud8f8\udc68\udb11\udcdf\udb11\udfa8\udbe7\udfe8\ud904\udf53\udac0\udca2\ub386\uda90\udce4\uda30\udf03\u8d05",
        29, 89124, -771196675, -7210380277777560096L, 39727L, true, false, (char) 29321, (char) 50120,
        Double.longBitsToDouble(0x3fe62806bb356a7cL), Double.longBitsToDouble(0x3fd175ba4dbd2090L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:\ud901\ude6c\udb90\udd99\ud889\udd20\udb6e\ude18\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud85b\udcda |this=com.google.javascript.jscomp.GlobalNamespace:@?\012",
        Z.run(T, 1, 10, 3, 6, "\ud901\ude6c\udb90\udd99\ud889\udd20\udb6e\ude18\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud85b\udcda", "\u0f5b\u72b0\u7420\ua7ab\u1f60\u1d26\u9c8a\u5907\u20f7\u9f97\u0aa6\ud4d1\ua5d7\u8081\u1305\u9d47\u77dc\u9895\u0ed6\u2cdf\u186f", "\ub9ec\uda25\udf26\udb11\udfa8",
        25, 75222, 829271481, -5611924816211424682L, 50198L, false, false, (char) 4070, (char) 22526,
        Double.longBitsToDouble(0x3fd57d208bc137deL), Double.longBitsToDouble(0x3feb3f7cb4652eecL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 3, 14, "\ud901\ude6c\udb8c\ude99\ud889\udd20\udb6e\ude18\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud85c\udfe6\ud8e2\uddf9\ud9c7\udd7b", "\u7420\u5fbb\u1f60\u1da9\u9c8a\u5907\u20f7\u9f97\u0aa6\ud4d1\ua5d7\u79de\u132e\u9d47\ua499\u316d\u8565\ub9a7\u8a17\u8922\u4b41\uc41f\u2f58\u7fbf\u660d\u1759\u304e\ubbce\u0d52\u5ac1\ucfde\u9c3f\u54a0\uac48\u9c76\uc33f\u342e", "\uda06\udd75\udb60\udf41\udb97\udf64",
        43, 27200, -58930368, 6656302908251462182L, 70527L, false, true, (char) 10857, (char) 12891,
        Double.longBitsToDouble(0x3fe560513e17b6f0L), Double.longBitsToDouble(0x3fe650bcb0253215L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:\ud901\uddb8\ud886\udd94\ud889\udd20\udb6e\ude18\ud96c\uddde\ud896\ude0f\ud9ff\udcdc\ud97b\udffb\ud85b\udce6 |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 11, 6, "\ud901\uddb8\ud886\udd94\ud889\udd20\udb6e\ude18\ud96c\uddde\ud896\ude0f\ud9ff\udcdc\ud97b\udffb\ud85b\udce6", "\u0f5b\u72b0\u7420\u4435\ua809\u1da9\u9c8a\u5907\u40ac\u704d\u0aa6\u258d\ua5d7\u79de\u132e\u4211\u523b\u316d\ud3a7\u2cdf\u078c", "\ub9ec\uda25\udf26",
        48, 80820, -1266582414, -1243828100386674938L, 4852L, false, true, (char) 22526, (char) 26463,
        Double.longBitsToDouble(0x3fc7f55e1e4e9e80L), Double.longBitsToDouble(0x3fb94bbb3eac6198L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 14, 1, "\udb05\udcfe\udb90\udd88", "\uc056\ucb59", "\ud85b\udcda",
        6, 48509, 1424556805, -1401067196130696289L, -71209L, true, true, (char) 21276, (char) 10651,
        Double.longBitsToDouble(0x3fcf91ab7ed2cf1cL), Double.longBitsToDouble(0x3fdc60b11b0f212eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 8, "\ud901\ude6c\uda1c\udd9f\ud889\udd20\udb6e\ude18\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud85b\udcda", "\u7a52\u89f1\u41b7\u414d\u1ece\u18aa\u2a77\u5907\u251d\u52f5", "\ud8a0\udf52\udbb4\udcec\udb95\udefc\ud884\udfd9\ud9ff\udd05\ud801\udce2\uda8d\udebe\ud8eb\ude95\uda77\udf8c\ud8d8\udf3e\udab7\ude43\ub9ec\uda25\udf26\udb11\udfa8\ud811\ude9d\ud904\udf53\udac0\udca2\ub386\uda90\udce4\uda30\udf03\uda39\udf6f\udb8b\udc55\uda4a\udc05\uda02\udf14\ud959\udf71\ud955\udce8\udbc0\ude2a\uda58\ude80",
        38, 58025, -774069684, 7991486019429350444L, 38943L, true, false, (char) 52175, (char) 27530,
        Double.longBitsToDouble(0x3fd879da0295c666L), Double.longBitsToDouble(0x3fae5bd817c2f5a0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 6, "\ud815\uddbc\udb90\udd99\u3b4a\udb64\udd9f\udb68\udddc\udbef\udf5d\ud888\udc23\ud83b\ude88\ud931\udec2", "\u7140\ubf3a\ud585\ua7ab\u5a7c\u252f\u65eb\u5907\u20f7\ud1d9\u0aa6\ud4d1\ua5d7\u1e35\u132e\u1ee4\u519c\u5aea", "\ud90f\udc15\udb7e\udd30\ud9fc\udec4",
        10, 71253, -1833075217, -6845320571025316172L, -72303L, false, false, (char) 37026, (char) 1057,
        Double.longBitsToDouble(0x3fb1d12350fba9e0L), Double.longBitsToDouble(0x3fd369ae1b091cc0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 4, "\ud901\ude6c\udb90\udd99\ud889\udd20\udb6e\ude18\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud85b\udcda", "\u0f5b\u93cb\u064e\uc8af\u4f52\u1da9\u455e\u5907\u1f34\u9f76", "\ud8a0\udf52\udbb4\udcec\udb95\udefc\ud884\udfd9\ud9ff\udd05\ud801\udce2\uda8d\udebe\u99d3\ud8b5\ude88\ud82b\ude88\udadf\udcc0\ub9ec\uda25\udf26\ud82f\uddad\ud811\ude9d\ud904\udf53\udac0\udca2\ub43d\uda88\udc04\uda30\udf03\u8d05\u017f\ud894\uddca\ud9f3\ude47\ud959\udf71\ud955\udce8\udb44\udd98\ud919\udc62",
        6, 5834, 1487551409, 762191860522469561L, -28476L, false, true, (char) 4014, (char) 49068,
        Double.longBitsToDouble(0x3fe56a2f1bae8f73L), Double.longBitsToDouble(0x3fe8516c6fdd4fbcL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 3, 6, "\ud901\ude6c\udb90\udd99\ud8ad\ude20\udb6e\ude18\udb68\udddc\ud8ba\udc72\ud884\udcef\ud8a4\udc85\ud85b\udcda", "\ua879\u72b0\u7420\ua7ab\u1f60", "\ud8a9\udca7\ud960\udf26\ud854\udc33\ud83a\udc7e\udbde\udc5a\ud8a0\udf52\udbb4\udcec\udb95\udefc\ud998\udc02\ud934\udfc5\uda1e\udd5a\uda8d\udebe\uc4b8\ub182\udb60\ude18\udab6\udea4\ub9ec\ud9d1\udf1c",
        48, 24900, 335486039, 6428632198951133045L, -31786L, false, true, (char) 25050, (char) 4070,
        Double.longBitsToDouble(0x3fb457402abe9040L), Double.longBitsToDouble(0x3fde09befecfdf2cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 1, 6, "\ud901\ude6c\udb90\udd99\ud889\udd20\udb6e\ude18\udb68\udddc\udb89\udec4", "\u6b2e", "\ud957\ude10\ud8fa\udf6a\udbc2\ude73\ud977\ude68\udaa5\udea8\udb58\udf7a",
        26, 85237, -1467543232, -8739939482892512004L, -45310L, true, false, (char) 29358, (char) 59070,
        Double.longBitsToDouble(0x3fb2f6bdf02cf1f0L), Double.longBitsToDouble(0x3fe5be871964e7daL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 7, "\ud908\ude54\udb90\udd99\ud889\udd20\ud89e\udfb0\ud825\udd05\udb32\udcbc\udb6a\ude21\ud8b4\udd68\ud85b\udcda", "\u0f69\u72b0\u7420\ua7ab\u1f60\u8260\u900b\u8157\u0abe\u33ab\u26a7\ud4d1\ua5d7\u9475\uad10\u9754\u3ab2\u9e89\u857b\u2cdf\u186f", "\ub9ec\ud86b\udf7d\u9425",
        56, 75227, 829271481, -5611924817243037354L, -21992L, false, false, (char) 13896, (char) 7383,
        Double.longBitsToDouble(0x3fc137d877826fbcL), Double.longBitsToDouble(0x3feb3bf4b7652e37L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.GlobalNamespace:@? |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 5, "\ud901\ude6c", "\u9d76\uc056\ucb59\u97cd\u4388\u6b9d\u5464\ubeb7\uc14f\u72b0\u7420\ua7ab\ub842\u1942", "\udae2\udf27\ud854\udc33",
        36, 40796, -539443485, 4154968849651301537L, -45310L, true, false, (char) 29358, (char) 59070,
        Double.longBitsToDouble(0x3fb2f6bdf02cf1f0L), Double.longBitsToDouble(0x3fe586871964e7daL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 6, "\ud901\ude6c\udb90\udd99\udbca\udce1\uda93\udeec\uda8f\udfe4\ud83f\udd3c\ud884\udd56\ud8a4\udc85\ud85b\udcda", "\u0f5b\u4218\u339c\ua7ab\ub043\u2136\u9c8a\u8e63\u3952\u65d6\u0aa6\ud4d1\ua5d7\u79de\u700b\ub7ee\u5291\u316d\ua3a6\u2cdf\u656e", "\ub9ec\uda25\udf26\udb11\udfa8",
        30, 75222, 829271481, -5611924816211424682L, 50198L, false, false, (char) 4070, (char) 22526,
        Double.longBitsToDouble(0x3fd57d208bc137deL), Double.longBitsToDouble(0x3feb3f7cb4652eecL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 6, "\ud901\ude6c\udb90\udd99\ud889\udd20\udb6e\ude18\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud85b\udcda", "\u0f5b\u1afc\uc0ec\u6e2b\u1f60\u1da9\u9c8a\u5907\u20f7\u9f97\u0aa6\u6294\ua5d7\u79de\u132e\u9d47\u523b\u1179\u8565\u2cdf\u186f", "\ub9ec\uda25\udf26\udb11\udfa8",
        25, 75222, 829271481, -5611924816496637354L, 50198L, false, false, (char) 4070, (char) 22526,
        Double.longBitsToDouble(0x3fd57d208bc137deL), Double.longBitsToDouble(0x3feb3f7cb4652eecL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=java.lang.Boolean:false |this=com.google.javascript.jscomp.GlobalNamespace:@?\012",
        Z.run(T, 2, 12, 12, 6, "\ud901\ude6c\udb90\udd99\ud889\udd20\udb6e\ude18\udb68\udddc\udb37\udd60\ud81b\ude43\ud876\udc8d\ud85a\ude4a", "\u2eef\u72b0\ua64d\u1e54\u08e6\u7983\u3e7d\u4ee8\ua98e\u9f97\u9eba\u72e2\u3c5a\u79de\u132e\u9d47\u523b\u316d\ucd3a\u2cdf\u186f", "\ub9ec\uda25\udf26\udb12\udf8a",
        20, 75222, 827895225, -5611924816211424682L, 50198L, false, false, (char) 1766, (char) 18505,
        Double.longBitsToDouble(0x3fd57d208bc137deL), Double.longBitsToDouble(0x3feb3f7cb4fe49dbL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.GlobalNamespace:@? |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 9, 12, "\ud89f\udd44\udb90\udd99\ud889\udd20\uda7e\udeed\udb68\udddc\udb11\ude60\ud884\udd49\ud8a4\udc85\ud85b\udcda", "\u0f5b\u2681\ud5aa\u5171\u1f62", "\uda93\udfa0\ud8e6\udeb3\udb2e\ude32",
        33, 86692, -948731570, 4155024876567966881L, -3838L, true, false, (char) 19387, (char) 21542,
        Double.longBitsToDouble(0x3fb2f6bdf02cf1f0L), Double.longBitsToDouble(0x3fe586871910e7daL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.GlobalNamespace:@? |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 14, 6, "\ud901\ude6c\udb90\udd99\ud889\udd20\udb6e\ude18\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud85b\udcda", "\u0f5b\u72b0\u7420\ua7ab\u1f60\u7554\u9c8a\ua689\u2116\ua3a9\u69f5\u794e\ub922\u6645\u132e\u9d47\u523b\u316d\u8565\u2cdf\u186f", "\ub9ec\ud8ce\udcfa\udb2e\udf21",
        25, 10790, 829271335, -5611924816211424682L, 50198L, false, false, (char) 4070, (char) 22526,
        Double.longBitsToDouble(0x3fd57d208bc137deL), Double.longBitsToDouble(0x3feb3f7cb4652eecL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 13, 6, "\ud901\ude6c\udb90\udd99\ud889\udd20\udb6e\ude18\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud85b\udcda", "\u0f5b\u72b0\u7420\ua7ab\u1f60\u1da9\u9c8a\u5907\u20f7\u9f97\u0aa6\ud4d1\u54f4\u77ed\u38d6\u9d47\u523b\u316d\u8565\u2cdf\u186f", "\ub9ec\uda25\udf26\udb11\udfa8",
        25, 75222, 829271481, -5611924816211424682L, 50198L, false, false, (char) 19401, (char) 22644,
        Double.longBitsToDouble(0x3fd57d208bc137deL), Double.longBitsToDouble(0x3feb3f7b94652eecL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:\ud919\udf6c\ud8d1\ude6d\udb2e\udfb0\ud985\ude5a\udb68\udddc\udbf3\udd7e\ud884\udd49\ud8a4\udc85\ud971\udce5 |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 2, 6, "\ud919\udf6c\ud8d1\ude6d\udb2e\udfb0\ud985\ude5a\udb68\udddc\udbf3\udd7e\ud884\udd49\ud8a4\udc85\ud971\udce5", "\ua947\u8082\uabc2\ua7ab\ub5d2\u2eaa\u9c8a\u42cb\u20f7\u9f97\ub33d\u2229\ub3a1\u79de", "\uda83\udcff\udbc2\udd64\ud8d8\udcc2\ud8eb\udead\ud8b5\ude88\ud8d8\udf3e\udadf\udd43\ud8fd\udec3\udb11\udcdf\udb11\udfa8\udbe7\udfe8\ud904\udf53\udac0\udca2\ub386\uda90\udce4\uda30\udf03\u8d05",
        29, 89124, -771196675, -7210380277777560096L, 39727L, true, false, (char) 29321, (char) 50120,
        Double.longBitsToDouble(0x3fe62806bb356a7cL), Double.longBitsToDouble(0x3fd175ba4e6c26a0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:\udafa\udc1c\ud802\ude12\ud907\udf3f\udbff\ude57\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud971\udce5 |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=com.google.javascript.jscomp.GlobalNamespace:@? |this=com.google.javascript.jscomp.GlobalNamespace:@?\012",
        Z.run(T, 2, 10, 8, 1, "\udafa\udc1c\ud802\ude12\ud907\udf3f\udbff\ude57\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud971\udce5", "\uc55b\u72b0\u7420\ua7ab\u1f60\u1da9\u9c8a\u42cb\u20f7\u9f97\u0aa6\u0dd7\ua335\u79de", "\uda03\udff6\udbc2\udd64\ud8d8\udcc2\ud8eb\udead\ud93f\ude8d\ud8d8\udf3e\udadf\udd43\ud8f8\udc68\udb11\udcdf\udb11\udfa8\udbe7\udfe8\ud904\udf53\udac0\udca2\ub386\uda90\udce4\uda30\udf03\u8d05",
        29, 89124, -771196675, -7210380277777560096L, 3269L, false, false, (char) 55814, (char) 1471,
        Double.longBitsToDouble(0x3fe0daad8e6dd4adL), Double.longBitsToDouble(0x3fcab3369b438694L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:\ud919\udf6c\udb90\udd99\ud907\udf3f\ud985\ude5a\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud971\udce5 |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=java.lang.String:\ud919\udf6c\udb90\udd99\ud907\udf3f\ud985\ude5a\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud971\udce5 |this=com.google.javascript.jscomp.GlobalNamespace:@?\012",
        Z.run(T, 2, 10, 10, 6, "\ud919\udf6c\udb90\udd99\ud907\udf3f\ud985\ude5a\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud971\udce5", "\uc55b\u72b0\u7420\ua7ab\u1f60\u1da9\u9c8a\u42cb\u20f7\u9f97\u0aa6\ud4d1\ua5d7\u79de", "\uda03\udff6\udbc2\udd64\ud8d8\udcc2\ud8eb\udead\ud8b5\ude88\ud8d8\udf3e\udadf\udd43\ud8f8\udc68\udb11\udcdf\udb11\udfa8\udbe7\udfe8\ud904\udf53\udac0\udca2\ub386\uda90\udce4\uda30\udf03\u8d05",
        29, 89124, -771196675, -7210380277777560096L, 39727L, true, false, (char) 29321, (char) 26824,
        Double.longBitsToDouble(0x3ecaecd5a8000000L), Double.longBitsToDouble(0x3f975ba4dbd20900L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:\ud9bf\udefd\udb19\udc72\ud92d\udc3f\ud97f\uddd6\ud9ea\udddd\udb37\udd60\ud884\udd49\ud8a4\udc85\ud971\udce5 |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 13, 3, "\ud9bf\udefd\udb19\udc72\ud92d\udc3f\ud97f\uddd6\ud9ea\udddd\udb37\udd60\ud884\udd49\ud8a4\udc85\ud971\udce5", "\u1137\u72b0\u0eac\ua888\u1f60\u1da9\u9c8a\u42cb\u20f7\u9f97\u0aa6\ud4d1\ua5d7\u79de", "\uda03\udff6\udbc2\udd64\ud8d8\udcc2\uda2d\udd2d\ud8b5\ude88\ud8d8\udf3e\udadf\udd43\ud8f8\udc68\uda83\uddf9\uda7f\ude92\ud868\udfbd\ud8e9\udc19\uda71\udec6\ub386\ud8aa\udd51\ud9fe\udc86\ud80e\udc47",
        33, 89124, -771196675, -7210380277777560096L, 39727L, false, true, (char) 29321, (char) 50120,
        Double.longBitsToDouble(0x3fea92e697d1523cL), Double.longBitsToDouble(0x3fd7ef097dbd20c8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\ud919\udf6c\udb90\udd99\ud907\udf3f |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 1, 14, "\ud919\udf6c\udb90\udd99\ud907\udf3f", "\ucb59\u97cd\ud1ba\u165e\u8d13", "\ud8ed\udccc\udbc2\ude73\ud977\ude68",
        22, 37578, 737177719, -562540885018826677L, -88988L, false, true, (char) 5364, (char) 11806,
        Double.longBitsToDouble(0x3fc4273534114d1cL), Double.longBitsToDouble(0x3fe7ff95ceddcc88L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=null |this=com.google.javascript.jscomp.GlobalNamespace:@?\012",
        Z.run(T, 2, 5, 5, 8, "\ud901\ude6f", "\u9d76\uc056\ucb59", "\ud85b\udcda",
        4, 48416, 1575551749, -1217089617716760266L, -66491L, false, true, (char) 41939, (char) 26813,
        Double.longBitsToDouble(0x3fbe1990facdce88L), Double.longBitsToDouble(0x3fc48f9160394b1cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.GlobalNamespace:@? |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=com.google.javascript.jscomp.GlobalNamespace:@? |this=com.google.javascript.jscomp.GlobalNamespace:@?\012",
        Z.run(T, 2, 8, 8, 2, "\ud957\udc23\ud8ae\udc7e\ue4d1\udb6e\ude18\ud928\uddc9\u344b\ud884\udcef\ud842\uddc8\udb34\udd99", "\u4856\u72da\u54ec\ua7ab\u19c6", "\udb0a\udd79\ud9f9\udeaa\uda0f\udfd5\ud931\ude1c\ud9c7\udd08\ud8a0\udf52\ub3aa\ud908\udd32\ud997\udf85\ud934\udfc5\uda1e\udd37\ud93c\udf75\uc4e8\ud80b\udfb5\uda46\ude0c\udab6\udea4\ub9ec\ud9d1\udf1c",
        48, 22652, -755033001, 4816487806549329654L, -20323L, false, true, (char) 60377, (char) 4070,
        Double.longBitsToDouble(0x3fd475d00aafa4d0L), Double.longBitsToDouble(0x3fde09bef2cfdf2cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 6, "\ud901\ude6c\udb90\udd99\ud889\udd20\udb6e\ude18\udb68\udddc\udb37\udd60\ud884\udd49\ud8a4\udc85\ud85b\udcda", "\u0f5b\u72b0\u7420\ua7ab\u1f60\u1da9\u9c8a\u5907\u20f7\u9f97\u0aa6\ud4d1\ua5d7\u79de\u132e\u9d47\u00a2\u316d*\u2cdf\u186f", "\ub9ec\uda25\udf26\udb11\udfa8",
        25, 67840, 829271481, -5611924816211424682L, 50198L, false, false, (char) 4070, (char) 22526,
        Double.longBitsToDouble(0x3fd57d208bc137deL), Double.longBitsToDouble(0x3feb3f7cb4652eecL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 13, 6, "\ud920\udf8b\ud986\udfc7.\udb6e\ude18\udb68\udddc\udb8a\udf8a\udab3\udeba\uda21\udcbd\ud8af\udc28", "\u9d09\u9a31\u7420\ua7ab\u433b\ub256\u5732\u58e4", "\ud83a\udc7e\udb2a\udf03\udba7\udccf",
        43, 52707, 136436478, 9034455743738468614L, -42831L, true, true, (char) 13379, (char) 44947,
        Double.longBitsToDouble(0x3fb939f6a5088450L), Double.longBitsToDouble(0x3fe8415654ec9588L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:\ud920\udf8b\ud986\udfc7 |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 13, 6, "\ud920\udf8b\ud986\udfc7.\uda64\udd14\udb68\ude78\udb8a\udf8a\udb9a\udd2c\ud8c2\ude55\ud8af\udc28", "\u9d09\u9a31\u7420\ua7ab\u9163\ub256\u5732\u58e4", "\ud83f\udec2\udb2a\udf03\udba7\udccf\ud9ec\udd62\udbad\ude65\uda78\ude3e\ud8f8\udc77\ud8e3\udf4b\ud90e\ude40\ud8eb\ude80\ud8af\udd88\ud8d8\udf3e\udadf\udd43\uda1e\udd5d\uda25\udf26\udb26\udcc1\udbd1\udf3d\udb9d\udf34\ud830\udd0e\ud86f\udf45\uda0c\udcba\uda37\udee6\ud8b4\udf41\ud820\udc2f\udaa2\udf62\ud8ef\uddbe\ud8eb\udf9e\ud9e0\ude7a\ud996\udeee",
        -3, 75943, -1543075185, -2421045610557027590L, 15052L, true, false, (char) 45340, (char) 64892,
        Double.longBitsToDouble(0x3fe74b85ba86325fL), Double.longBitsToDouble(0x3f5368a23035ba00L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.GlobalNamespace|ensureGenerated||new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|getAllSymbols||new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|getNameForest||new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|getNameIndex||new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|getOwnSlot|java.lang.String|new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|getParentScope||new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|getReferences|com.google.javascript.jscomp.GlobalNamespace$Name|new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|getRootNode||new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|getScope|com.google.javascript.jscomp.GlobalNamespace$Name|new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|getSlot|java.lang.String|new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|getTopVarName|java.lang.String|new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|getTypeOfThis||new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|hasExternsRoot||new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|isGlobalNameReference|java.lang.String,com.google.javascript.jscomp.Scope|new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|isGlobalScope|com.google.javascript.jscomp.Scope|new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|isGlobalVarReference|java.lang.String,com.google.javascript.jscomp.Scope|new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
