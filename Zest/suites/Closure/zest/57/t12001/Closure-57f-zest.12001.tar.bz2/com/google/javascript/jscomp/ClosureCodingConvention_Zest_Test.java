package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class ClosureCodingConvention_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 4, 1, "\ud83c\udd18\ud9d9\udd5d\udb1f\udc82\ud917\udd45\uda14\udfdd\udaad\ude89\ud897\ude2e\ud9fe\udc72\ud952\uddc7\ubebd\udae1\udd24\udb11\udc34\udad8\udc11\ud9a2\udd7e\u39aa\uda0b\udf02\udb18\udcf3\ud8d3\ude95\ud911\udd49\udb95\ude70\uda84\uddba", "\u0612", "\udb74\ude67\ud836\udc27\uda6b\udfbd\udb4e\udd2a\ue164\ud994\udea1\udbc0\udf4f\udb12\udd2d\u0444\uda20\udc43\udb1c\udca6\udac1\udd44\ud9de\udc55\ud953\udffd\udb3f\udd77\ud8bd\udf59\ud830\udfd9\ud934\ude2a\udb40\ude65\udada\udf85\ud956\udd9b\uda40\udd66\ud836\udc98",
        42, 71215, -1415391782, 7280208083941442366L, 57385L, false, false, (char) 37030, (char) 60786,
        Double.longBitsToDouble(0x3fe4b6debe324ad6L), Double.longBitsToDouble(0x3fd4d9377cffe23cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 4, 1, "\ud83c\udd18\uda8f\udcf7\udb1f\udc82\ud917\udd45\uda14\udf79\udaad\ude89\ud897\ude2e\udbd6\udfbe\ud952\uddf6\ubebd\udae1\udd24\udb11\udc34\udad8\udc11\ud9a2\udd7e\u39aa\uda0b\udf02\udb18\udcf3\ud8d3\ude95\ud911\udd49\udb95\ude70\udbe5\ude8b", "\u0612", "\udb74\ude67\ud836\udc27\uda6b\udfbd\udb4e\udd2a\ue164\ud994\udea1\udbc0\udf4f\udb12\udd2d\u0444\uda20\udc43\udb1c\udca6\udac1\udd44\uda03\udcdb\ud953\udffd\udb3f\udd77\ud8bd\udf59\ud830\udfd9\ud934\ude2a\udb3f\udc65\udada\udf85\ud956\udd9b\uda40\udd66\udbbb\ude9a",
        -3, 71215, -1415391782, 7280208083941442366L, 57385L, true, true, (char) 37041, (char) 60786,
        Double.longBitsToDouble(0x3fe4b6debe324ad6L), Double.longBitsToDouble(0x3fd4d9377cffe23cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 4, 1, "\ud83c\udd18\ud9d9\udd5d", "\u04b1\u620d", "",
        -5, 15200, 53006, 8137441576179868138L, -99944L, false, false, (char) 47789, (char) 6029,
        Double.longBitsToDouble(0x3fc5ba680a3737fcL), Double.longBitsToDouble(0x3fa38c019feee040L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:goog.global |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 1, "\ud9f7\udfd7\udb64\udd29\udb1f\udc82\ud917\udd45\uda14\udfdd\udaad\ude89\ud845\udf0f\ud9fe\udcb0\ud821\ude2f\ubf05\udae1\udd24\uda55\udc16\ud86b\udd0d\ud881\udc9b\udad0\udc73\ud97d\udd2b\udb18\udcf3\ud8d3\ude95\ud911\udd49\udb95\ude70\udbf3\udccd", "\u6367", "\udb74\ude67\ud836\udc27\uda6b\udfbd\udb4e\udd2a\ue164\ud994\udea1\udaa9\udebc\uda46\udec0\u03d7\uda20\udc43\udb1c\udca6\udac1\udd44\ud9de\udc55\ud953\udffd\udb3f\udd77\ud848\udca7\ud8ec\udeda\ud840\ude87\ud8ac\udf8f\udada\udfa8\u715f\uda40\udd66\uf49c",
        58, 71215, -1415391782, 7280208083941442366L, 4906L, false, false, (char) 37030, (char) 7283,
        Double.longBitsToDouble(0x3fe66edb66324ad6L), Double.longBitsToDouble(0x3fcd3e6ef9ffc478L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 1, "\ud83c\udd18\ud9d9\udd5d\udb1f\udc82\ud917\udd45\uda14\udfdd\udaad\ude89\ud897\ude2e\ud9fe\udc0e\ud952\uddc7\ubebd\udae1\udd24\udb11\udc34\udad8\udc11\ud9a2\udd7e\u39aa\ud819\udc68\ud887\udf05\ud8f4\udc12\ud911\udd49\udb24\udd17\uda7e\uddab", "\u0612", "\udb74\ude67\udbc7\udefb\uda8a\udd18\udb4e\udf2a\ue164\ud994\udf06\udbc0\udf4f\udb12\udd2d\u0444\uda20\udc43\udb1c\udca6\udac1\udd44\ud9de\udc55\ud953\udffd\udb3f\udd77\ud8bd\udf59\ud830\udfd9\ud934\ude2a\udb40\ude65\udada\udf85\udad6\udd1a\uda40\udd66\ud836\udc98",
        42, 71215, -1415391782, 7293155932870132542L, 57385L, false, false, (char) 37030, (char) 60786,
        Double.longBitsToDouble(0x3fe4b6debe324ad6L), Double.longBitsToDouble(0x3fd4d9377cffe23cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:goog.exportProperty |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 1, "\ud841\udd18\ud9d9\udd5d\udb1f\udc82\ud917\udd45\uda14\udfdd\udaad\ude89\ud897\ude2e\ud9fe\udc72\ud952\uddc7\ubebd\udae1\udd24\udb11\udc34\udad8\udc11\ud9a2\udd7e\u39aa\uda0b\udf02\udb18\udcf3\ud927\udfff\ud911\udd64\udb95\ude70\uda84\uddba", "\u9611", "\udb46\udeb9\ud836\udc27\uda6b\udfbd\udb4e\udd2a\ue164\ud994\udea1\udbc0\udf4f\udb12\udd2d\u0444\uda20\udc43\udb13\udda6\udac1\udd44\ud892\udf31\ud9e7\udd63",
        54, 61714, 638437787, -4416423992863388456L, -25822L, false, true, (char) 19733, (char) 11237,
        Double.longBitsToDouble(0x3fe5755d13636508L), Double.longBitsToDouble(0x3fdfb22414632e6eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 1, "\ud83c\udd18\ud9d9\udd5d\udb91\udc7b\ud917\udd45\uda14\udfdd\udaad\ude89\ud897\ude2e\ud9fe\udc72\ud952\uddc7\ubebd\udae1\udd24\udb11\udc34\udad8\udc11\ud9a2\udd7e\u39aa\uda0b\udf02\udb18\udcf3\ud8d3\ude95\ud911\udd49\udb95\ude70\ud809\udcbc", "\u0612", "\udb74\ude67\ud836\udc27\uda6b\udfbd\udb4e\udd2a\ue164\ud994\udea1\udbc0\udf4f\udb12\udd2d\u0444\uda20\udc43\udb1c\udca6\ud801\udf64\ud9de\udc55\ud953\udffd\udb3f\udd77\ud8bd\udf59\ud830\udfd9\ud934\ude2a\udb40\ude65\udada\udf85\ud956\udd9b\uda40\udd66\ud836\udc98",
        42, 71215, -1415391782, 7280208083937182526L, 57385L, false, false, (char) 37030, (char) 60786,
        Double.longBitsToDouble(0x3fe4b6debe324ad6L), Double.longBitsToDouble(0x3fd4d9377cffe23cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 1, "\ud83c\udd18\ud9d9\udd5d\u307a\ub200\000\000\ud897\udd6d\ud9fe\udc72\u00b9\uda1b\ude20\uda45\udf16\udb10\udfa7\udad8\udc11\ud9a2\udd7e\000\ud906\udce2\udb18\udcf3\ud8d3\ude95\ud911\udd49\udb95\ude70\uda84\uddba", "\u0612", "\udb74\ude67\ud836\udc27\uda6b\udfbd\udb4e\udd2a\ue164\ud994\udea1\udbc0\udf4f\udb12\udd2d\u0444\uda20\udc43\udb1c\udca6\udac1\udd44\000\ud94d\udc06\udb3f\udd77\ud8bd\udf59\ud830\udfd9\ud934\ude2a\udb40\ude65\udada\udf85\ud956\udd9b\uda40\udd66\ud836\udc98",
        25, -1000, -1415446528, 7280208083941442366L, 57385L, false, false, (char) 37030, (char) 302,
        Double.longBitsToDouble(0x3e48c80000000000L), Double.longBitsToDouble(0x3f426ef9ffc40000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 1, "\ud83c\udd18\ud9d9\udd5d\udb1f\udc82\ud917\udd45\uda14\udfdd\udaad\ude89\ud897\ude2e\ud9fe\udc72\ud952\uddc7\ubebd\udae1\udd24\udb11\udc34\udad8\udc11\ud9a2\udd7e\u39aa\uda0b\udf02\udb18\udcf3\ud8d3\ude95\ud911\udd49\udb95\ude70\uda84\uddba", "\u2e19", "\udb74\ude67\ud836\udc27\uda6b\udfbd\udb4e\udd2a\ue164\ud994\udea1\udbc0\udf4f\udb12\udd2d\u0444\uda20\udc43\udb1c\udca6\udac1\udd44\ud9de\udc55\ud953\udffd\udb3f\udd77\ud8bd\udf59\ud830\udfd9\ud934\ude2a\udb40\ude65\udada\udf85\ud956\udd9b\uda40\udd66\ud836\udc98",
        42, 71215, -1415391782, 7280208083941442366L, 57385L, false, false, (char) 37030, (char) 60786,
        Double.longBitsToDouble(0x3fe4b6debe324ad6L), Double.longBitsToDouble(0x3fd4d9377cffe23cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 9, "\ud83c\udd18\ud9d9\udd5d\ud8e3\udd55\ud917\udd44\uda14\udfdd\udaad\ude89\ud897\ude2e\ud9fe\udc72\ud952\uddc7\ubebd\udae1\udd24\udb11\udc34\ud94c\ude56\udae1\udf4f\ud8d6\udfc8\uda0b\udf02\udb18\udcf3\ud8d3\ude95\ud911\udd49\udb95\ude70\udbc9\udc05", "\u0612", "\u613e\ud97b\udd63\uda6b\udf3f\udb4e\udd2a\ue164\u6208\udbe0\ude0b\udb13\udc84\udbf2\udca0\uda20\udc43\udb1c\udca6\udac1\udd44\ud9de\udc55\udad5\uddfa\udb3f\udd77\ud8bd\udf59\ud830\udfd9\udbfb\udc1e\ud9db\udf60\u954c\ud956\udd9b\uda40\udd66\ud836\udc98",
        42, 71215, -1415391782, 7280208083941442366L, 34619L, false, false, (char) 37030, (char) 60786,
        Double.longBitsToDouble(0x3fe4b6debe324ad6L), Double.longBitsToDouble(0x3fd4d9377cffe23cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 1, "\ud83c\udd18\ud9d9\udd5d\udb1f\udc82\ud917\udd45\uda14\udfdd\udaad\ude89\ud897\ude2e\ud9fe\udc72\ud952\uddc7\ud974\udd3f\uda68\uddb5\udb11\udc34\udad8\udc11\ud9a2\udd7e\udb80\udc61\ud8af\uddaf\ud848\udcdf\ud8d3\ude95\ud911\udd49\udb95\ude70\uda84\uddba", "\u0612", "\udbc5\udc66\ud836\udc27\uda6b\udfbd\udb4e\udd2a\ud967\udc10\ud994\udea1\udbc0\udf4f\udb12\udd2d\u0444\ud88d\ude7b\udbf3\udf64\udac1\udd25\ud9de\udc55\ud953\udffd\udb3f\udd77\ud91a\udef5\ud98b\udc0c\ud934\ude50\udb40\ude65\udada\udf85\ud956\udd9b\uda40\udd66\ud836\udc98",
        42, 71215, -1415391782, 7280208083941442366L, -88859L, false, false, (char) 37030, (char) 60786,
        Double.longBitsToDouble(0x3fe4b6debe324ad6L), Double.longBitsToDouble(0x3fd4d9377cffe23cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 1, "\ud83c\udd18\ud9d9\udd5d\udb1f\udc82\ud917\udd45\uda14\udfdd\udaad\ude89\ud897\ude2e\ud9fe\udc72\ud952\uddc7\ubebd\udae1\udd24\udb11\udc34\udad8\udc11\ud9a2\udd7e\u39aa\uda0b\udf02\udb18\udcf3\ud8d3\ude95\ud911\udd49\udb95\ude70\uda84\uddba", "\u0612", "\udb74\ude67\ud836\udc27\uda6b\udfbd\udb4e\udd2a\ue164\ud994\udea1\udbc0\udf4f\udb12\udd2d\u0444\uda20\udc43\udb1c\udca6\udac1\udd44\ud9de\udc55\ud953\udffd\ud902\udcb9\ud8b6\udee8\udba0\udfe6\ud934\ude2a\udb40\ude65\udada\udf85\ud956\udd9b\uda40\udd66\ud836\udc98",
        42, 71215, -1415391782, 7280208083941442366L, 57385L, false, false, (char) 37030, (char) 60786,
        Double.longBitsToDouble(0x3fe4b6debe324ad6L), Double.longBitsToDouble(0x3fd4d9377cffe23cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.google.common.collect.RegularImmutableList:@? |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 1, "\ud83c\udd18\ud9d9\udd5d\udb1f\udc82\ud917\udd45\uda14\udfdd\udaad\ude89\ud897\ude2e", "\u4982\u289e", "\ud9a2\udd7e\u39aa\uda0b\udf02",
        52, 95134, -1502053744, -3224453003322874707L, -56953L, false, false, (char) 4344, (char) 24804,
        Double.longBitsToDouble(0x3fea2aa7ccb8f10eL), Double.longBitsToDouble(0x3fe749d22fdac0b7L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:goog.exportProperty |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\0121=java.lang.String:goog.global |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\012",
        Z.run(T, 2, 10, 12, 1, "\u70ee\ud870\udd54", "\u3ac7\u74d3\uc5ff\000\000\ubfef\u78df\u45d8\ub6d0\u2639\ua560\ube12\ucae3\u927f\ucbe7\u3f04\uc969", "\ud81b\udd77",
        -4, 34764, -1721939369, -1355649051389288644L, -51844L, false, true, (char) 8488, (char) 52780,
        Double.longBitsToDouble(0x3fdda3a481e3a1b2L), Double.longBitsToDouble(0x3feda3cc7466339bL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:goog.abstractMethod |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 5, "\ud83c\udd18\ud932\udced", "\u08d2", "\ud8d7\udde4\ud971\udc05\u5daf\ucf0e\udad1\udea7\udad8\udc11\ud9cd\udc34\ud906\udf14",
        9, 43976, 1837632206, -6451271398827462380L, -92572L, true, false, (char) 4012, (char) 50952,
        Double.longBitsToDouble(0x3fddf65eb048abb4L), Double.longBitsToDouble(0x3fe96da1ccedd350L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:goog.exportSymbol |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 1, "\ud83c\udd18\ud829\uddb2", "\u04b1\u620d\000\000\000\ubfef\ucf0e\u45d8\uc4cf\u2639\u1b61\u5025\uca4a\ub6ca\u8873", "\ud90e\udff7\udacb\udf17\udba4\udcd5\udb8f\udcb2\ud95b\udc53\ud96b\udc7d\uda57\udc24\ud839\udc5b\ud88a\udd08\uda3f\udcab\ud8c9\udd4c\ud903\uded2\udbe0\udca0\ud884\udc01\udbdc\udfe4\ud9d6\udee4",
        50, 65517, -1412873448, -5782245821051914781L, 39941L, true, false, (char) 21952, (char) 56744,
        Double.longBitsToDouble(0x3fe0e4963833f0a7L), Double.longBitsToDouble(0x3fad86ee0262fb00L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:goog.global |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 0, 1, "\udb0b\udf74\uda08\uddb4\ud957\udf9d\uda5b\udc78\udbc4\udfd6\udaad\ude89\000\u4228\ud983\udcf5\u5d2b\ucf0e\udb4c\udea5\udb51\udd79", "\u5025", "\ud911\udd49\udb95\ude70\uda84\uddba\ud90e\udfdc\udacb\udf17\udb5d\udc40\ud94d\udd77\udac1\uddaf\ud934\ude94\ud8e9\udcd4\udb67\udd7d\ud8d9\udf50\ud995\udcb6\udac8\ude70\udb9e\udeda\udaf0\udd27\ud92b\uddfd",
        47, 7062, -71290727, 4707428465127403258L, 33031L, true, false, (char) 693, (char) 6822,
        Double.longBitsToDouble(0x3fc8c1ea44c5935cL), Double.longBitsToDouble(0x3fe7cd7b1d45b844L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:goog.global |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 6, 1, "\ud8a6\udf40\udb8f\ude11", "\u9146\u68ed", "\udafd\udd7e\u5d60\uda39\udf5f\udb23\udeac\ud81a\udd91\udbf9\udd2f\uf857\uda48\udea5\uda48\udc4b\ud8d3\ude95\ud911\udd49\udb95\ude70\uda84\uddba\ud90a\ude3a\udaeb\udf0a\udb72\uded7\ud812\udf7a\ud83e\ude29\ud99f\ude63\uda74\udc60\ud889\uddf2\udbc6\udd8c\u4983\ud80e\uddcb\ud8ff\ude30\ud98e\udfd5\ud8fd\udf62\uda12\udf01\udbb3\ude77\ud8e2\udf38\ud9e2\udd17\ud944\udff5",
        -5, 19936, -960360594, 2329509075180627237L, 43857L, true, false, (char) 18901, (char) 24906,
        Double.longBitsToDouble(0x3fd44198e9dea86cL), Double.longBitsToDouble(0x3fe54c117a2b2c42L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\0121=java.lang.String:goog.exportProperty |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\012",
        Z.run(T, 2, 2, 10, 1, "\udab2\udd13\ud9d9\udd5d", "\u3aa0\u480d\000\000\000\ubfef\ucf0e\u45d8", "\u39aa\uda0b\udf02",
        53, 41331, -1502053744, -3224453003322874707L, -56953L, false, true, (char) 37613, (char) 13966,
        Double.longBitsToDouble(0x3fe5105cdca34053L), Double.longBitsToDouble(0x3fc75c6b89aa7434L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 1, "\ud85a\udc18\ud9d9\udd5d", "\u84fc\u5885\000\000\000\u6a44\ubdab\u9e09", "\ud9fc\udf38\udaa4\udff5\udbcf\udddf\ud8d3\ude95\ud911\udd49\ud8f8\udd4d\uda84\uddba\ud90e\udf6e\ud965\ude43\ud83d\udf41\udae5\udea4\uda7e\ude7a\ud9df\udf19\ud9dc\udebd\ud85d\udc6e\ud85b\ude45\ud825\ude0b\u13fc\ud8b0\udf5f\ud910\udd3c\uda75\udce5\udae7\udc0c\ud94c\udd38\ud98f\ude57\udb76\udc48\ud97f\ude42\udb37\udd3e\ud9fa\udfd1\ud988\uddff",
        38, 49249, -97464405, 8669548309853998285L, -40591L, true, true, (char) 24833, (char) 17163,
        Double.longBitsToDouble(0x3fe0666f8b35d454L), Double.longBitsToDouble(0x3fdfa2335d6398c6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 12, "\ud9f8\udc03\ud82e\udfb1\ud8fb\udd77\ud933\ude07\ud820\udc99\uda18\udf70\ud845\udf0f\ud9fe\udcb0\udb73\udcc7\udb47\ude82\ud86f\udecb\uda54\udfcd\ud86b\udd0d\udb72\udf14\udbe9\udc63\ud97d\udd55\udb76\udd02\ud8d3\ude95\udbe9\ude98\uda62\udf74\ud864\udd1f", "\u8fbc", "\udb74\ude67\ud925\udf9f\ud824\uddaa\udb4c\udfe0\ue164\ud994\udea1\udaa9\udebc\uda46\udec0\u03d7\uda20\udc43\udb1c\udca6\udb66\udd2f\udbcb\udee6\ud953\udffd\udb3f\udd77\uda12\udcc8\ud8ec\ude58\u8fda\uda4b\ude5f\udae7\udf0a\udb94\udf21\uda40\udd66\uf49c",
        58, 71215, -1415391782, 310606185608889150L, 4877L, false, false, (char) 37030, (char) 7283,
        Double.longBitsToDouble(0x3fe66edb66324ad6L), Double.longBitsToDouble(0x3fcd3e6ef9c07478L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:goog.global |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 2, 1, "\ud9f7\udfd7\udb64\udd29\udb1f\udc82\ud917\udd45\uda14\udfdd\udaad\ude89\ud845\udf0f\ud954\udddb\ud821\ude2f\ud9a4\udefe\udae1\udd24\uda55\udc16\ud86b\udd0d\ud881\udc9b\udad0\udc73\ud97d\udd2b\udb18\udcf3\ud8d3\ude95\ud911\udd49\udb95\ude70\udbf3\udccd\ud90e\udfc0\udacb\udf17\ud855\udc0d\ud9ce\uddc4\udbdd\udf49\udb32\ude66\ud836\udc27\uda6b\udfbd\udb4e\udd2a\ue164\ud994\udea1\udb36\udc03\uda4b\udf37\u03f6", "\u97a8\u73ef\ud404\u2540\ua7b2", "\ud8ac\udf8f\udada\udfa8\u715f\uda40\udd66",
        58, 77193, 1443616059, 8886400148742621630L, 1838L, false, false, (char) 7272, (char) 29241,
        Double.longBitsToDouble(0x3fe92506b4e97e22L), Double.longBitsToDouble(0x3fe3ff88f2d3d585L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.google.common.collect.RegularImmutableList:@? |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\0121=com.google.common.collect.RegularImmutableList:@? |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\012",
        Z.run(T, 2, 8, 8, 14, "\ud841\udd18\ud9d9\udd5d\udb1f\udc82\ud917\udd45\udada\udfe0\udaad\ude89\ud897\ude2e\ud9fe\udc72\ud952\uddc7\ud91b\ude52\udab3\ude38\udb11\udc34\udb60\udd0f\ud9a2\udd7e\u39aa\uda0b\udf02\udb18\udcf3\udb14\udfe3\udb2c\udde3\udb48\ude89\udb8a\uddf5", "\u9611", "\udbc1\udeb7\ud92e\udc12\uda6b\udfbd\udb4e\udd2a\ud945\uddb6\ud994\ude65\ud904\ude31\ud88b\udf08\u6faa\ud811\uddf1\uda38\udd44\udb10\udc73\udb85\udc7d\ud9e7\udd63",
        54, 29242, -1302514046, -4438573598770361128L, 17947L, true, false, (char) 19675, (char) 11237,
        Double.longBitsToDouble(0x3fd5caba263cd41eL), Double.longBitsToDouble(0x3fd004341da4b7aeL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\0121=void |this=com.google.javascript.jscomp.ClosureCodingConvention:@?\012",
        Z.run(T, 2, 2, 2, 1, "\ud83c\udd18\ud9d9\udd5d\udb1f\udc82\ud917\udd45\uda14\udfdd\udaad\ude89\ud897\ude2e\ud9fe\udc72\ud952\uddc7\ubebd\udae1\udd24\udb11\udc34\udad8\udc11\ud857\udc5a\ud92a\udfa8\ud891\udfe3\udbf8\udd67\udb00\udcf4\ud907\udf47\udb95\ude70\uda84\uddba", "\u2e19\ub8b3\u99fe", "\uda6b\udfbd\udb4e\udd2a\ue164\uda91\udedf",
        9, 1996, 409240276, 5017753429051889395L, -42237L, true, false, (char) 22326, (char) 56275,
        Double.longBitsToDouble(0x3fcb1856a82978f8L), Double.longBitsToDouble(0x3fd14916bc78bf2eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 4, 1, "\ud83c\udd18\ud9d9\udd5d\udb1f\udc82\ud917\udd45\uda14\udfdd\uda79\udf2f\ud99a\ude57\ud9fe\udc72\ud952\uddc7\ubebd", "\uc4cf\u0639\ua581\u5025\u1bdc\ub6ca\u5ace\uac0a\uc969\u6f03\u12d7\u0612\ub8b3\u99fe\ua9e5\u19c8\u540f\u3a50\u467c\u314d\u2876\u95c5", "\ud870\udf8f",
        27, 76569, -1131668489, 8687195589082605079L, 12071L, false, false, (char) 61511, (char) 44671,
        Double.longBitsToDouble(0x3fe1e628c9c235baL), Double.longBitsToDouble(0x3fda0ec4156e84bcL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.ClosureCodingConvention|extractClassNameIfGoog|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,java.lang.String|static",
    "M|com.google.javascript.jscomp.ClosureCodingConvention|applySingletonGetter|com.google.javascript.rhino.jstype.FunctionType,com.google.javascript.rhino.jstype.FunctionType,com.google.javascript.rhino.jstype.ObjectType|new:com.google.javascript.jscomp.ClosureCodingConvention:",
    "M|com.google.javascript.jscomp.ClosureCodingConvention|applySubclassRelationship|com.google.javascript.rhino.jstype.FunctionType,com.google.javascript.rhino.jstype.FunctionType,com.google.javascript.jscomp.CodingConvention$SubclassType|new:com.google.javascript.jscomp.ClosureCodingConvention:",
    "M|com.google.javascript.jscomp.ClosureCodingConvention|describeFunctionBind|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ClosureCodingConvention:",
    "M|com.google.javascript.jscomp.ClosureCodingConvention|endsWithPrototype|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ClosureCodingConvention:",
    "M|com.google.javascript.jscomp.ClosureCodingConvention|extractClassNameIfProvide|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ClosureCodingConvention:",
    "M|com.google.javascript.jscomp.ClosureCodingConvention|extractClassNameIfRequire|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ClosureCodingConvention:",
    "M|com.google.javascript.jscomp.ClosureCodingConvention|getAbstractMethodName||new:com.google.javascript.jscomp.ClosureCodingConvention:",
    "M|com.google.javascript.jscomp.ClosureCodingConvention|getAssertionFunctions||new:com.google.javascript.jscomp.ClosureCodingConvention:",
    "M|com.google.javascript.jscomp.ClosureCodingConvention|getClassesDefinedByCall|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ClosureCodingConvention:",
    "M|com.google.javascript.jscomp.ClosureCodingConvention|getExportPropertyFunction||new:com.google.javascript.jscomp.ClosureCodingConvention:",
    "M|com.google.javascript.jscomp.ClosureCodingConvention|getExportSymbolFunction||new:com.google.javascript.jscomp.ClosureCodingConvention:",
    "M|com.google.javascript.jscomp.ClosureCodingConvention|getGlobalObject||new:com.google.javascript.jscomp.ClosureCodingConvention:",
    "M|com.google.javascript.jscomp.ClosureCodingConvention|getObjectLiteralCast|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ClosureCodingConvention:",
    "M|com.google.javascript.jscomp.ClosureCodingConvention|getSingletonGetterClassName|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ClosureCodingConvention:",
    "M|com.google.javascript.jscomp.ClosureCodingConvention|identifyTypeDeclarationCall|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ClosureCodingConvention:",
    "M|com.google.javascript.jscomp.ClosureCodingConvention|extractClassNameIfGoog|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
