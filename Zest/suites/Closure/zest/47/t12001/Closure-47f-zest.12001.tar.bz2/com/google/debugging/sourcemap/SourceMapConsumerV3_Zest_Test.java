package com.google.debugging.sourcemap;
import org.junit.Test;
import static org.junit.Assert.*;
public class SourceMapConsumerV3_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 6, "\ud809\udeee\uda1e\udc3e\ud9c3\udc06\ud860\udc1f", "\ub31b\u1449", "\udb67\ude50\ud8c2\udc6a\ud90d\udc2e\ud9c3\udc7e\uda95\udea4\ud888\ude83\uda12\uddcf",
        56, 31061, -1442875782, 6731356893874233011L, -46701L, false, true, (char) 60505, (char) 18865,
        Double.longBitsToDouble(0x3fdbe9b5db7072faL), Double.longBitsToDouble(0x3fcff7177b708b80L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 5, "\ud809\udeee\uda1e\udc3e\ud9c3\udc06\ud860\udc1f", "\ub31b\u1449", "\udb67\ude50\ud8c2\udc6a\ud90d\udc2e\ud9c3\udc7e\uda95\udea4\ud888\ude83\uda12\uddcf",
        56, 31061, -1442875782, 6731356893874233011L, -46701L, false, true, (char) 60505, (char) 18865,
        Double.longBitsToDouble(0x3fdbe9b5db7158faL), Double.longBitsToDouble(0x3fcff7177b708b80L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 16, "\ud809\udeee\ud88d\uddb6\ud9be\ude4c\udb97\udd3b", "\ub31b\ud2a6", "\udb67\ude50\ud8c2\udc6a\ud90d\udc2e\ud82f\udc43\udb3e\udf06\ud888\ude83\uda12\uddcf",
        56, 31061, -1105685427, 5096261346426697410L, -69196L, true, false, (char) 7131, (char) 41683,
        Double.longBitsToDouble(0x3fcff7177b708b80L), Double.longBitsToDouble(0x3fe25b262cd2d798L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 16, 11, "\ud8b2\uddc2\udb58\ude73\u407e\uda87\udce7", "\ub31b\u1449\u3ad7\uada6\u606d", "\ud9c2\udffd\uda95\udea4\ud92c\udeb4\udb49\ude57\uda7f\udc7f\ud84c\udcc1\ud9fa\udd68\ud92a\udeef\ud846\udeb1\udbcc\udeaa\ud893\ude8f\ud94e\udc06\ud95e\udc73\udaf4\uddae\ud925\udd21\udb26\udd84",
        43, 71356, 77090621, -80294096327555763L, -52906L, true, false, (char) 40454, (char) 6914,
        Double.longBitsToDouble(0x3fee74d1d0b0ee6dL), Double.longBitsToDouble(0x3fb0e4f4eaeca048L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 5, 12, "\ud841\udc69\udad8\udf80\ud9c2\udfae\ud860\udc1f", "\u808a\u5a25", "\udb67\ude50\ud8c2\udc6a\ud90d\udc2e\ud9c3\udc7e\uda95\udea4\ud888\ude83\uda12\uddcf",
        56, 31061, -1442875782, 6731356894435927276L, -46701L, false, true, (char) 60529, (char) 18865,
        Double.longBitsToDouble(0x3fda5a3a4b7072faL), Double.longBitsToDouble(0x3fcff7177b708b80L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 8, 6, "\ud809\udeee\uda1e\udc3e\ud9c3\udc06\ud975\udd0a", "\uccfe\uaa97\uab3f\ua3a7", "\ud90d\udc2e\ud9c3\udc7e",
        1, 35473, -475356293, 6756734794385541701L, -7182L, true, false, (char) 18597, (char) 20229,
        Double.longBitsToDouble(0x3fe76341505474e8L), Double.longBitsToDouble(0x3fc3a0429d02192cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 6, 13, "\ud809\udeee\udad5\uddf7\ud8ee\udcff\ud854\udfdc", "\ub293\u25c3", "\udb64\udd50\ud8c2\udc6a\ud90d\udc2e",
        20, 49051, 155102816, -2041639958442885505L, -64794L, false, true, (char) 31773, (char) 18597,
        Double.longBitsToDouble(0x3fee6ed1bc3072afL), Double.longBitsToDouble(0x3fa7309c79d02140L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 3, 6, "\ud809\udeee\uda1e\udc3e\ud9c3\udc06\ud860\udc1f\udab4\ude95\ud94a\udd35\ud9aa\udf1c\ud9cb\udcf4\udaca\udc81", "\u095f\u0541\ua262\u69f3\u2d69\u39e6\u7da1\u43cc\ub88b\u9c25\u4eff\ubb14\u65d6\u6bcd\u12cb\ub856\u2de1\u2140\u39c1\ubedc\u24e1\u81c7\ua7ae\u2c38\ud431\ub44d\u8e85\u912b\u654b\u7a07\u0777\u2be8\uc48e\ua041\u8f5c\u538c\u7f77\u47d4\u4d80\u8a9d\uc5dd\ud19d\u9810\uaa81\ubba3\u115f\u13c4\u3923", "\ud867\uddcc\udb48\udfd8\uda58\udf4f\u46fb",
        23, 46340, -2031906834, -1970663640501749634L, 70719L, true, true, (char) 48970, (char) 39213,
        Double.longBitsToDouble(0x3fbb128e827d13d8L), Double.longBitsToDouble(0x3fee61bac4066685L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 7, 15, "\ud809\udeee\uda1e\udc3e\ud9c3\udc06\ud860\udc1f", "\ub31b\u1449", "\udb67\ude50\ud8c2\udc6a\ud90d\udc2e\ud9bd\ude9d\uda95\udea4\ud888\ude83\uda12\uddcf",
        56, 31061, -1442875782, 6731356893874233011L, 12781L, true, true, (char) 60505, (char) 18865,
        Double.longBitsToDouble(0x3fdbe9b5db7072faL), Double.longBitsToDouble(0x3fcff7177b708b80L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 6, "\u5db5\uda1e\udc3e\udbca\ude67\ud910\udfe2", "\ub31b\u1449", "\udb73\ude50\ud973\udd82\udbf6\udddc\ud9c2\udfbb\uda95\udea4\uda3f\udf5f\ud880\udc2f",
        50, 94601, -1442871645, 6731356891816599219L, 14661L, false, true, (char) 60505, (char) 2335,
        Double.longBitsToDouble(0x3fdbe9b5d57072faL), Double.longBitsToDouble(0x3fed6e00715c22dbL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 11, 8, "\ud809\udeee\uda1e\udc3e\ud9c3\udc06\ud860\udc1f\udab4\ude95\ud8e2\ude67", "\u3b20\uada6\u606d\u095f\u2002\u700d\u69f3\u2d69\u39e6\u7da1\u9a9c\ub8f0\u9c25\u4eff\u701c\u97b9\u52b2\u1446\u04bf\ub3a0\u2140\u3a55\u2038\ubb61\u305c\u4439\u7b95", "\ua8c3\uecff\uda51\ude48\ud8ed\udc45\udb27\udd9b\u8bd4",
        14, 76095, 808254067, -8524353571234452092L, 58570L, false, false, (char) 25275, (char) 13845,
        Double.longBitsToDouble(0x3fc0844321117470L), Double.longBitsToDouble(0x3fd680063f11ffeaL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 10, 6, "\ud809\udeee\uda1e\udc3e\ud9c3\udc06\ud860\udc1f", "\ub31b\u1449", "\udb67\ude50\ud8c2\udc6a\uda93\udc31\ud9c3\udc7e\udaed\ude2f\udb17\udccb\ud9ea\udeeb",
        56, 31061, -1442875782, 6731356892937409715L, -46701L, false, true, (char) 60505, (char) 18865,
        Double.longBitsToDouble(0x3fdbe9b5db7072faL), Double.longBitsToDouble(0x3fcff700eb72ec30L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 10, 8, 6, "\ud809\udeee\uda1e\udc3e\ud9c3\udc06\ud860\udc1f", "\ub31b\u1449", "\udb67\ude50\ud8c2\udc6a\ud90d\udc2e\ud9c3\udc7e\uda95\udea4\udb9a\udc6c\uda19\udf71",
        19, 31132, -1442875782, 6731356893874233011L, -46701L, false, true, (char) 60556, (char) 18865,
        Double.longBitsToDouble(0x3fdbe9b5db7072faL), Double.longBitsToDouble(0x3fcff7177b708b80L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 10, 4, "\ud809\udeee\uda1e\udc3e\ud9c3\udc06\ud934\udcaf", "\ua25b\u800d\u8632\u9476\u5ff3\u095f", "\uda95\udea4\udb3f\udc0e\u6b26\uda7f\udc05\ub0b2\ud9fa\udd68\ud92a\udeef\ud94f\udd8e",
        33, 32688, 1946515760, 149876988094269341L, 96316L, false, false, (char) 13662, (char) 65350,
        Double.longBitsToDouble(0x3fde5d578f8281ccL), Double.longBitsToDouble(0x3fcf383275e3600cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 3, 6, "\ud809\udeee\uda1e\udc3e\ud9c3\udc06\ud860\udc1f", "\u193f\u4f1f", "\udb67\ude50\ud8c2\udc6a\ud90d\udc2e\ud9c3\udc7e\uda95\udea4\ud888\ude83\uda12\uddcf",
        56, 31061, -1442875782, 6731356893874233011L, -46701L, false, true, (char) 60505, (char) 18865,
        Double.longBitsToDouble(0x3fdbe9b5db7072faL), Double.longBitsToDouble(0x3fcff7177b708b80L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 8, 13, "\ud809\udeee\uda1e\udc3e\ud9c3\udc06\ud860\udc1f", "\ub31b\u2236", "\ud810\udc4b\ud8c2\udc6a\ud90d\udc2e\ud9c3\udc7e\uda99\udcc6\ud888\ude83\uda12\uddcf\udbe6\udda9",
        16, 91138, -595948451, -2732867088120548018L, -16641L, false, false, (char) 61599, (char) 3377,
        Double.longBitsToDouble(0x3fdb8397d1ff7176L), Double.longBitsToDouble(0x3fe6e11704738fdaL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\012",
        Z.run(T, 1, 5, 1, 1, "\ud809\udeee\uda1a\udfde\udbb2\udc92\udbd4\udfcc", "\u8b8f\u298f", "\udb67\ude50\ud8c2\udc6a\ud914\ude36\ud9c3\udc7e\udbda\udc9d\udb04\ude81\uda12\uddcf\udae2\udcd8\ud84c\udcf1",
        -2, 48950, -524280231, 3618671913377953611L, 45729L, false, false, (char) 37844, (char) 18454,
        Double.longBitsToDouble(0x3fef259f2e9d8067L), Double.longBitsToDouble(0x3fb52df917e71790L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 8, 6, "\000\000\000\000", "\u91be", "\udbd0\udd2c\udb67\ude50\ud8c2\udc6a\032\ud9c3\udc7e\uda95\udea4\ud888\ude83\uda12\uddcf\uda7f\udc05\ud84c\udcc1\ud9fa\udd68\ud92a\udeef\ud846\udeb1\udbcc\udeaa\ud893\ude8f\ud94e\udc06\ud95e\udc73\udae2\udeae",
        35, 47432, 585146623, 6444649810837576963L, 2020L, false, true, (char) 32023, (char) 32088,
        Double.longBitsToDouble(0x3fad6b8d2b38ad40L), Double.longBitsToDouble(0x3fccf41b3ac840f8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 10, 16, 6, "\ud809\udeee\uda1e\udc3e\ud9c3\udc06\ud976\ude2b", "\u00db", "",
        -5, -1000, 0, 6210612430898051060L, 77143L, true, true, (char) 41513, (char) 43017,
        Double.longBitsToDouble(0x3fe3d732556e00ffL), Double.longBitsToDouble(0x3fc66bad40010c00L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 16, "\ud809\udeee\ud89c\udc21\ud9be\ude4c\udb97\udd3b", "\ub31b\ud2a6", "\udb67\ude50\ud8c2\udc6a\udae9\udcfd\ud82f\udc43\udb3e\udf06\ud888\ude83\uda12\uddcf",
        52, 42109, -1105685427, 5096261346426697410L, -69196L, true, false, (char) 7131, (char) 41683,
        Double.longBitsToDouble(0x3fcff7177b708b80L), Double.longBitsToDouble(0x3fe25b262cd2d798L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 1, 16, "\ud809\udeee\ud88d\uddb6\ud9be\ude4c\uda66\udda3", "\ub31b\ud2a6\u3ad7\uada6\u606d", "\ud82f\udc43\udb3e\udf06\ud888\ude83\ud84f\udc8e\uda7f\udc49\ud84c\udcc1\udae0\udc6a\udbfa\udedc\udb3d\udf7a\uda2c\udde5\ud8b2\udefe\ud94e\udc06\ud95e\udc73\udab3\uddfb\uda06\udecd\udb26\udd5a",
        43, 57436, -677844405, 4862379968327096746L, 35203L, true, true, (char) 8726, (char) 30379,
        Double.longBitsToDouble(0x3fbb06f046848f00L), Double.longBitsToDouble(0x3fe450201782e799L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 10, 1, 13, "\001", "\u8fe7", "\u99db",
        29, 33438, 16343281, 0L, -100000L, false, false, (char) 12913, (char) 35236,
        Double.longBitsToDouble(0x3fbff8ea80000000L), Double.longBitsToDouble(0x3fb3799280000000L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\012",
        Z.run(T, 1, 5, 5, 12, "\ud842\udc8a\ud8c3\udc5d\u0a30\u0e9b", "\u7fc5\u5a25\u3ad7\uada6\u606d\u095f\u0541", "\udbfd\udc6b\ud99d\ude8e\uda7f\udc05\ud84c\udcc1",
        -2, 48158, 1698358508, -2722603878956716083L, -69196L, true, true, (char) 26953, (char) 28469,
        Double.longBitsToDouble(0x3fcff7177b708b80L), Double.longBitsToDouble(0x3fe3ae9bcddbc5c8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 10, 0, 11, "\001\uda1e\udc3e\ud9c3\udc06\ud860\udc1f", "\ub31b\u1449", "\udb67\uddce\020\000\000\000\uda71\udc58\ud83d\udea2",
        -1, 31132, 16742010, 6731192594195291827L, -46701L, false, true, (char) 60551, (char) 18865,
        Double.longBitsToDouble(0x3fdbe9b5db7072faL), Double.longBitsToDouble(0x3f47176000000000L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\012",
        Z.run(T, 1, 7, 10, 4, "\ud809\udeee\uda1e\udc3e\ud9c3\udc06\ud94a\udfaf", "\u74f4\u800d\u8632\u9476\u8f1d\u6b83", "\udb47\udfa3\udae5\ude2f\u6b26\ud8b5\udd61\ud928\udc88\udb72\udd96\udb7e\udd47\ud9dd\udd95",
        0, 32684, 1946515760, 149876988094299549L, 36924L, true, true, (char) 51609, (char) 18225,
        Double.longBitsToDouble(0x3fed43c977c17db5L), Double.longBitsToDouble(0x3fcf383275e3600cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 1, "\ud809\udeee\uda1a\udfde\udbb2\udc92\udbd4\udfcc", "\u8b8f\u298f", "\udb67\ude50\ud8c2\udca0\ud914\ude36\ud9c3\udc7e\udbda\udc9d\ud938\udcdb\uda12\uddba\udae2\udcd8\ud84c\udcf1",
        -2, 48950, -524280231, 3618731287005853515L, 45729L, false, true, (char) 37798, (char) 5654,
        Double.longBitsToDouble(0x3fe7c7c9918c8067L), Double.longBitsToDouble(0x3fb52df917e71790L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\0121=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 2, 5, 10, 12, "\udb8c\udfef\ud8c3\udc5d\u0a30\u0e9b", "\u7fc5\u5a25\u3ad7\uada6\u606d\u8eaa\u0541", "\ud8a8\ude07\ud99d\ude8e\uda7f\udc05\ud92e\udf32",
        -1, 92772, -1912371596, 76450011771039077L, -69196L, false, true, (char) 42401, (char) 33648,
        Double.longBitsToDouble(0x3fcff715bb708b80L), Double.longBitsToDouble(0x3fe3ae9bcddbc5c8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\0121=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\012",
        Z.run(T, 2, 5, 5, 12, "\ud842\udd0a\ud8c3\udc5d\udbe0\ude2f\u0e9b", "\u7fc5\u5a25\u3ad7\uada6\u498a\u095f\u3cf5", "\udbfd\udc6b\ud99d\ude8e\udacd\udea1\ud84c\udcc1\ud9fa\udd68",
        -2, 42508, -1191820634, 8263876516675156272L, -82961L, true, true, (char) 28469, (char) 20551,
        Double.longBitsToDouble(0x3fe6e117b675d379L), Double.longBitsToDouble(0x3fddbc5c8ff51a5eL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 1, "\ud809\udeee\uda1a\udfde\udbb2\udc92\udb8e\udf44", "\u5e2e\u298f", "\udb67\ude50\ud8c2\udca0\ud914\ude36\ud9c3\udc7e\udbda\udc9d\ud938\udcdb\uda12\uddba\udae2\udcd8\ud84c\udcf1",
        -2, 48950, 394337881, 3618730684312590685L, 45846L, false, true, (char) 23462, (char) 5936,
        Double.longBitsToDouble(0x3fd6498957c5876eL), Double.longBitsToDouble(0x3fb52df917e71790L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 7, 10, "\ud809\udeee\uda1a\udfde\udbb2\udc92\udbd4\udfcc", "\u50a9\u9305", "\udb77\udcd1\ud97b\udea0\uda14\udcd7\ud9c2\udfe9\udbda\udc9d\udb6d\ude35\uda12\uddba\ud82d\uddbd\ud84c\udcc0",
        -2, 32374, -524280140, 3618731287005875787L, 45729L, true, false, (char) 37957, (char) 60694,
        Double.longBitsToDouble(0x3fd5d2632454dcceL), Double.longBitsToDouble(0x3f4bc5ed5adbc800L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 2, 1, "\ud809\udeee\uda1a\udfde\udbb2\udc92\udbd4\udfcc", "\u8b8f\u298f", "\udb67\ude50\ud84a\udec3\udaad\udc01\ud9aa\ude1b\udbda\udc9d\ud938\udcdb\uda12\uddba\udae2\udcd8\ud84c\udcf1",
        -2, 48950, -524280231, 3618731287005853515L, 45729L, false, true, (char) 37798, (char) 5548,
        Double.longBitsToDouble(0x3fe7c7c9918c8067L), Double.longBitsToDouble(0x3fb52df917e71790L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 13, 2, "\ud809\udeee\uda1a\udfde\udbb2\udc92\udbd4\udfcc", "\u8b8f\u298f", "\udb91\udf05\u8781\ud911\udc02\ud9c3\udc7e\udbda\udc9d\ud938\udcdb\uda12\uddba\udae2\udcd8\ud84c\udcf1",
        -2, 48950, -524280231, 3635932046910781259L, 45729L, false, true, (char) 37798, (char) 48179,
        Double.longBitsToDouble(0x3fe7c7c9918c8067L), Double.longBitsToDouble(0x3fb52df917e71790L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 14, 6, "\ud809\udeee\uda1a\udfde\ud88e\udcc0\udbd4\udfcc", "\u8b8f\uce4b", "\udb67\ude50\ud8c2\udca0\ud914\ude36\ud9c3\udc7e\udbda\udc9d\ud938\udd60\uda12\uddba\udae2\udcd8\ud84c\udcf1",
        -2, 48950, -524280231, 3618731287005853515L, 45729L, false, true, (char) 37798, (char) 62229,
        Double.longBitsToDouble(0x3fe7c7cdf688ffe2L), Double.longBitsToDouble(0x3fd20b7389cc5d8cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 12, "\udb8c\uddef\ud8c3\udc5d\u0a30\udacf\udce1", "\u7fc5\u5a25\u6207\uacf9\u606d\u8eaa\u0541", "\ud8a8\ude07\udbb3\udef8\udadd\udfa5\udacf\udcb7",
        -5, 81409, -1912371711, -5111696758959791081L, -41090L, false, true, (char) 22956, (char) 8636,
        Double.longBitsToDouble(0x3fe3ae9bc9dbc5c8L), Double.longBitsToDouble(0x3fc3ce0f3ff6159cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 8, 12, "\udb8c\udfef\uda4d\ude23\udbe5\ude08\ud9ce\udc95\ud859\udcc8\u0700\udb48\ude09", "\uada6\u606d", "\ud9c3\udc7e\udb36\uded7\ud8a8\ude07\uda42\udf83\uda7e\udfb8\ud92e\udf32\ud88b\udc09\ud951\ude03\ud913\ude14\u1af1\ud8c3\udc27\ud9d1\udc48\ud95e\udcbe\ud858\udd7f\udad8\udfd7\udbf1\udf97\ud886\udf0d\ud901\udc3c\uda1d\uddf4",
        0, 60999, -1783444730, 3188454643134103791L, 64355L, false, false, (char) 6362, (char) 46823,
        Double.longBitsToDouble(0x3fecc3709e275fe3L), Double.longBitsToDouble(0x3fc5348b75dac790L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 4, "\uda7e\udf68\uda1a\udfde\udbb2\udc92\udbd4\udfcc", "\u8b8f\u298f", "\udb67\ude50\ud84a\udec3\udaad\udc01\ud9aa\ude1b\udbda\udc9d\ud938\udcdb\uda12\uddba\udae2\udcd8\ud84c\udcf1",
        -2, 48950, 1572871769, 4617760643061149474L, 45729L, false, true, (char) 37799, (char) 5548,
        Double.longBitsToDouble(0x3fe7c7c9918c8067L), Double.longBitsToDouble(0x3fb52df917e7bf90L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 6, "\ud809\udeee\uda1e\udc3e\ud9c3\udc06\ud860\udc1f", "\ub31b\u1449", "\udb67\ude50\ud8c2\udc6a\ud90d\udc2e\ud9c3\udc7e\uda95\udea4\ud888\ude83\uda12\uddcf",
        56, 31061, -1442875782, 6731356893874233011L, -46701L, false, true, (char) 60505, (char) 18865,
        Double.longBitsToDouble(0x3fdbe5e4ab7072faL), Double.longBitsToDouble(0x3fcff7177b708b80L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 8, 6, "{\000\000\000", "\u91be", "\udbd0\udd2c\ud9ab\ude52\ud8c2\udc6a\u7159\ud9c3\udc7e\uda8e\udfa4\ud888\ude83\uda12\uddcf\uda98\uddd3\ud809\ude02\udb3a\udf80\ud92a\udeef\ud846\udeb1\ud852\udd8c\ud8df\ude85\uda0c\ude87\ud95e\udcaa\u0daf",
        35, 47432, 585146560, 6444649810837576963L, 2020L, false, true, (char) 32023, (char) 32088,
        Double.longBitsToDouble(0x3fad6b8d2b38ad40L), Double.longBitsToDouble(0x3fccf41b3ac840f8L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 8, 6, "{\udb8e\udea6\uda6b\uddb8\uda1f\udddb", "\u91be", "\udbd9\udc95\ud9ab\ude52\udb44\udd4a\u7159\ud9c3\udc7e\uda8e\udfa4\ud888\ude83\ud975\udc53\uda98\uddd3\ud809\ude02\udb3a\udf80\ud92a\udeef\ud87b\uddcf\ud852\udd45\ud8df\ude85\ud9f7\udd4a\ud95e\udcaa\u0daf",
        35, 47432, 585146560, 6444649810837576963L, 19860L, true, true, (char) 31013, (char) 32088,
        Double.longBitsToDouble(0x3fad6b8d2b38ad40L), Double.longBitsToDouble(0x3fccf41b3ac840f8L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 5, 6, "{\udb4f\udd2c\u3253\udadc\udd2d\ud81c\udc91\ud94a\udd35\udbc8\udf5f\udbee\udee1\udb70\udf20\udbd0\udd2c\ud9ab\ude52\ud999\udc54\udaee\udd5f\u8fa3\uda55\ude0b", "\u91d6\u8b8e\u324a\u9c25\u4eff\u5a78\ud79d\ub348\u1302\u4f9e\uce05\u2140\ub39b\u38eb\u26fd", "\u8d54\ud26c\udb5c\ude55\ud884\udec1\u67f3\ud915\udd52\ud9f3\udd17\ud812\udddc\uda9a\udf4e\udb1a\ude16",
        8, 55808, -1646176775, -3120034098214112150L, 87018L, false, false, (char) 62035, (char) 51418,
        Double.longBitsToDouble(0x3fc5f88357a2e980L), Double.longBitsToDouble(0x3fd0768ed7fefcd2L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 5, 6, "{\udbe0\ude41\ud88f\udc73\000", "\u91be", "\udbed\udd1b\ud9ab\ude52\ud8c2\udc6a\u7159\ud9c3\udc7e\udb0d\uddc3\ud998\udf74\uda12\uddcf\uda98\uddd3\ud809\ude02\udb3a\udf80\ud92a\udeef\ud846\udeb1\ud852\udd8c\ud8df\ude85\uda0c\ude87\udabd\udc9f\udbfb\udc0f",
        50, 79491, -436509737, 6451570798447762691L, -71410L, true, false, (char) 30189, (char) 15848,
        Double.longBitsToDouble(0x3fde16f364b995f8L), Double.longBitsToDouble(0x3fad6b8d2b38ad40L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 8, 6, "{\uda0b\uddb7\u00e0\000", "\u91be", "\udbd0\udd2c\ud9ab\ude52\ud8c2\udc6a\ud8fc\udf49\uda68\ude97\uda8e\udfa4\ud888\ude83\uda12\uddcf\uda98\uddd3\ud809\ude02\udb3a\udf80\ud92a\udeef\ud846\udeb1\ud852\udd8c\udbb7\udcf4\u30af\udbc9\udd5c\udb9d\udc83",
        5, 54740, 585146595, 6444649810837576963L, 2020L, false, true, (char) 32023, (char) 32088,
        Double.longBitsToDouble(0x3fad6b8d2b38ad40L), Double.longBitsToDouble(0x3fccf41b3ac840f8L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 8, 6, "{\udaa4\udfb2\udbcb\udd09\udac9\udfa6\ud89a\uded4\uda3a\udeeb\udaea\udf37\ud9d7\udd55\udba1\udf2d\ud882\ude98\ud9e2\udeb7\uda26\udf5c\ud973\udfe4\udb56\udfcb\ud81e\udf17\ud8c4\udf7b\uda12\uddcf", "\u324a\u9c25\u707a", "\ud83c\udfbc\ud95e\udcaa\ud903\udeec\ud9a1\udf58\ud8f9\udde4\uda1e\udd48\ud90d\udc21\ud863\udeb1\ud870\ude28\ud860\ude43\ubd70\ud26c\udb3e\udd55",
        51, 76740, -1965779910, -6856261270178318471L, 3595L, false, true, (char) 47968, (char) 36655,
        Double.longBitsToDouble(0x3fcc936da4ef711cL), Double.longBitsToDouble(0x3fde5b73b4c02e7eL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 8, 6, "{A\000\000", "\u91be\u1449", "\ud9ab\ude52\ud8c2\udc6a\u7159\ud9c3\udc7e\uda8e\udfa4\ud888\ude83\uda12\uddcf",
        13, 67666, -1448107881, 6731356893874233011L, 67490L, false, true, (char) 22799, (char) 49340,
        Double.longBitsToDouble(0x3fd03596fd1f2986L), Double.longBitsToDouble(0x3fea3daa7473213cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 2, 15, "{\udb8e\udea6\uda6b\uddb8\udacd\uddd1\uda70\udd82\udac5\udf8e", "\u93bd\ud10f\ucd4a", "\ud9c3\udc7e\uda8e\udfa4\ud88a\ude84\udafa\udd55\uda8f\udc33\ud809\ude02",
        9, 550, 654983765, -7505593835080242356L, -38173L, false, false, (char) 32850, (char) 52881,
        Double.longBitsToDouble(0x3fec5acb7e8f94c3L), Double.longBitsToDouble(0x3fea3b727473213cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 8, 6, "{\udaa4\udfb2\udbcb\udd09\udac9\udfa6\ud89a\uded4\uda3a\udeeb\udaea\udf37\ud9d7\udd55\udba1\udf2d\ud882\ude98\ud9e2\udeb7\uda26\udf5c\ud973\udfe4\udb56\udfcb\ud81e\udf17\ud8c4\udf7b\uda12\uddcf\uda98\uddd3\ud809\ude02\udb3a\udf80\ud92a\udeef\ud9c8\udd92\ud852\udd8c\ud9e5\ude1c\ud83c\udfbc\ud95e\udcaa\ud903\udeec\ud9a1\udf58\ud8f9\udde4\uda1e\udd48\ud90d\udc21\ud863\udeb1\ud870\ude28\ud860\ude43\ubd70\ud26c\udb3e\udd55\ud884\udec1\u67f3\ud915\udd52\ud9f3\udd17\ud8eb\udd96\ud935\udcac\uda56\udec3\uda35\ude68\udbce\udf80\udab0\ude79\ud821\udec9\ud88f\udcf1\udace\udf43\ud9b7\udd8c\ud9ce\udccd\ud894\udc0a\uda07\udd10\ud8af\udee0\uda96\uddef\ud8c0\udd1a\ud9b6\udc2e\ud944\udc50\uda41\udd2a\ud839\ude08\ud9fc\udc0a\udb5b\ude9d\ud8e1\udf84\ud858\udd64\ua2ea", "\u7b37\u5f50\u7bbc\u0290\u9bbe\u05bf\ub045\u4815\ucd77", "\udbe5\ude15\ud816\udca1\udbd3\udf26\udac4\udfe7\ud9ff\udd86\uda60\udd48\ud887\udf0f\udb6f\udf68\udbb2\ude5e\udbcd\ude7f\ud890\udde7\ubda6\ud915\udd7b\ud94c\udd13",
        7, 9076, -719253081, 1195860439142346950L, -42565L, false, true, (char) 32577, (char) 32431,
        Double.longBitsToDouble(0x3fcea31ff408f6c4L), Double.longBitsToDouble(0x3fbef20e597e9ee8L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 8, 6, "{\udaa4\udfb2\udbcb\udd09\udac9\udfa6\ud89a\uded4\uda3a\udeeb\ud8d3\udecc\ud9d7\udcdf\udba1\udf2d\uda99\udce3\ud9e2\ude7f\uda26\udf5c\ud973\udfe4\udb56\udfcb\ud81e\udf17\ud8c4\udf7b\uda12\uddcf\udb11\udeca\u8502\udb3a\udf80\ud92a\udeef\ud9c8\udd92\uda3a\udd81\ud9e5\ude1c\ud83c\udfbc\ud95e\udcaa\ud903\udeec\ud9a1\udf58\ud8f9\udde4\uda1e\udd48\ud90d\udc21\ud863\udeb1\ud870\ude28\ud860\ude43\udb07\udf1c\uda16\udec8\udac6\ude73\ud884\udecd\u67f3\ud915\udd52\ud9f3\udd17\ud8eb\udd96\ud935\udcac\uda56\udec3\uda35\ude68\udbce\udf80\udab0\ude79\ud821\udec9\ud88f\udcf1\udace\udf43\ud9b7\udd8c\ud9ce\udccd\ud894\udc0a\uda07\udd10\ud8af\udee0\uda96\uddef\ud8c0\udd1a\ud9b6\udc2e\ud944\udc50\uda41\udd2a\ud839\ude08\ud9fc\udc0a\udb5b\ude9d\ud8e1\udf84\ud858\udd64\ua2ea", "\u7b37\u5f50\u7bbc\u0290\u9bbe\u05bf\u3964\u4815\ucd77", "\udb8c\udd49\ud801\uded4\udbd3\udf26\ud873\udc7b\ud9ff\udd86\uda60\udd48\ud8c5\udd0e\u7143\udb7c\udf40\udbcd\ude7f\ud890\udde7\ubda6\ud915\udd7b\ud829\udf82",
        43, 9057, -719253081, 1195860439142346950L, -42565L, false, true, (char) 32577, (char) 32431,
        Double.longBitsToDouble(0x3fcea31ff408f6c4L), Double.longBitsToDouble(0x3fbef20e597e9ee8L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 8, 6, "{\udaa4\udfb2\udbcb\udd09\udac9\udfa6\ud89a\uded4\uda3a\udeeb\udaea\udf37\ud9d7\udd55\udba1\udf2d\ud882\ude98\ud9e2\udeb7\uda26\udf5c\ud973\udfe4\udb56\udfcb\udb9a\ude74\ud8c4\ude98\uda12\uddcf\uda98\uddd3\ud809\ude02\udb3a\udf80\ud92a\udeef\ud9c8\udd92\ud852\udd8c\ud9e5\ude1c\ud83c\udfbc\ud95e\udcaa\ud903\udeec\ud9a1\udf58\udb72\udc7f\ud9e6\udffa\u18e2\ud863\udf48\ud870\ude28\ud860\ude43\ubd70\ud26c\udb3e\udd55\ud884\udec1\u67f3\ud915\udd52\ud9f3\udd17\ud8eb\udd96\ud935\udcac\uda56\udec3\uda35\ude68\udbce\udf80\udab0\ude79\ud821\udec9\ud88f\udcf1\udace\udf43\ud9b7\udd8c\ud9ce\udccd\ud894\udc0a\uda07\udd10\ud8af\udee0\uda96\uddef\ud8c0\udd1a\ud9b6\udc2e\ud944\udc50\uda41\udd2a\ud839\ude08\ud9fc\udc0a\ud9a0\udf41\ud8e1\udf84\ud858\udd64\ua2ea", "\u7b37\u5f50\u7bbc\u0290\u9bbe\u05bf\ub045\u4815\ucd77", "\udbe5\ude15\ud816\udca1\udbd3\udf26\udac4\udfe7\ud9ff\udd86\uda60\udd48\ud887\udf0f\udb6f\udf68\udbb2\ude5e\udbcd\ude7f\ud890\udde7\ubda6\ud915\udd7b\ud94c\udd13",
        7, 9076, -719253081, 1195860439142346950L, -42565L, false, true, (char) 32577, (char) 32431,
        Double.longBitsToDouble(0x3fcea31ff408f6c4L), Double.longBitsToDouble(0x3fbef20e597e9ee8L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 8, 6, "{\udaa4\udfb2\udbcb\udd09\udac9\udfa6\ud89a\uded4\uda3a\udeeb\udaea\udf37\ud9d7\udd55\udba1\udf2d\ud882\ude98\ud9e2\udeb7\uda26\udf5c\ud973\udfe4\udb56\udfcb\ud81e\udf17\ud8c4\udf7b\uda12\uddcf\uda98\uddd3\ud809\ude02\udb3a\udf80\ud92a\udeef\ud9c8\udd92\ud852\udd8c\ud9e5\ude1c\ud83c\udfbc\ud95e\udcaa\ud903\udeec\ud9a1\udf58\ud8f9\udde4\uda1e\udd48\ud90d\udc21\ud863\udeb1\u83da\ud9da\udce7\udae6\ude58\uda23\udcd2\udb3e\udd55\ud884\udec1\ud871\udd7d\ud915\udd52\ud9f3\udd17\ud8eb\udd96\ud935\udcac\uda56\udec3\uda35\ude68\udbce\udf80\udab0\ude79\ud821\udec9\ud88f\udcf1\udace\udf43\ud9b7\udd8c\ud9ce\udccd\ud894\udc0a\uda07\udd10\ud8af\udee0\uda96\uddef\ud8c0\udd1a\ud9b6\udc2e\ud944\udc50\uda41\udd2a\ud839\udebf\ud9fc\udc0a\udb5b\ude9d\ud8e1\udf84\ud858\udd64\ua2ea", "\u7b37\u5f50\u7bbc\u8586\u9b82\u05bf\ub045\u4815\ucd77", "\udbe5\ude15\ud816\udca1\udbd3\udf26\udac4\udfe7\ud9ff\udd86\uda60\udd48\ud887\udf0f\udb6f\udf68\udbb2\ude5e\udbcd\ude7f\ud890\udde7\ubda6\ud915\udd7b\ud94c\udd13",
        7, 9076, -719253081, 1195860439142346950L, -42565L, false, true, (char) 32577, (char) 32431,
        Double.longBitsToDouble(0x3fcea31ff408f6c4L), Double.longBitsToDouble(0x3fbef20e597e9ee8L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 5, 6, "{\udb4f\udd2c\u3253\udadc\udd2d\ud81c\udc91\ud94a\udd35\udbc8\udf5f\ud9e1\udd1b\udac8\udfe3\udbd0\udd2c\ud9ab\ude52\020\udaca\udfa5\u8fa3\uda55\ude0b", "\u91d6\u8b8e\u2167\000\u8f68\u5a78\ud79d\ub348\u1302\u4f9e\uce05\u2140\ub39b\u38eb\u26fd", "\u8d54\ud26c\udb5c\ude55\udb61\uddef\000\000\ud9f3\udc64\ud812\udddc\uda9a\udf4e\udb1a\ude16",
        8, 36616, -1646198784, -3120034098214112150L, 87018L, false, false, (char) 62035, (char) 51418,
        Double.longBitsToDouble(0x3fc5f88357a2e980L), Double.longBitsToDouble(0x3fd0768ed000fcd2L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 15, 6, "{\ud813\udcaa=\000", "\u9f73\u1aad", "\ud9ab\ude52\ud8c2\udc6a\u7159\ud9c3\udc7e\ud9ef\ude14\ud888\udf12\uda12\uddcf\uda98\uddd3\ud809\ude02\udb3a\udf80",
        -2, 9243, 1324614885, 8259434333018564656L, -771L, false, true, (char) 28469, (char) 22799,
        Double.longBitsToDouble(0x3fe6e60f0503596fL), Double.longBitsToDouble(0x3fe47ca61f47b54eL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 15, 6, "{\ud813\udcaa=\udbf0\ude18", "\u9f73\u1aad", "\ud9ab\ude52\ud8c2\udc6a\u7159\ud9c3\udc7e\ud9ef\ude14\ud888\udf12\uda12\uddcf\uda98\uddd3\ud809\ude02\udb3a\udf80",
        -2, 9243, -1510734619, 8259434040960788528L, -32047L, true, true, (char) 58445, (char) 6066,
        Double.longBitsToDouble(0x3fe5f7353dfbf5e4L), Double.longBitsToDouble(0x3fdcae31902b2ff0L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 8, 12, "\001\011\udaac\udd75\ud801\udd0c", "\u45cc\u31e9\u3f48", "\ud97d\udeb0\udb55\ude69\udb59\udde3\udb52\udc51\uda4e\udcfa\ud961\udfa1\udbfb\udf01\uda49\udfa1\ud9fa\udd68\udb3b\udc18\udae3\udca4\ud9e1\udd4e\ud9b9\udf28\ud94e\udc06\uda2b\ude51\ud916\ude10\ud962\udf2b\udb26\udd84\ud886\udf0d\ud9f9\udd78\ud8f1\udde0\ud8e9\udc5d\ud912\udde5\uda6e\ude53\udaf9\udd68\u3ac0\ud8ab\uddc2\u67f3\ud915\udd52\ud9f3\udd17\ud812\udddc\udae3\udc0b\udada\ude92\udbfe\udf1c\ud835\uddbd\ud976\udca6\udbe8\udda9\udb1c\udca5\uda25\udef7\uda8f\udf51\ud8ea\uddc2\uea46\ud8b5\ude73\ud838\udc85\ud9ee\udd7b\ud873\udcfa\ud9af\udd3e\ud9f6\udfe7",
        -2, 76157, -575208860, 2956653277013585753L, 32513L, true, false, (char) 42170, (char) 10163,
        Double.longBitsToDouble(0x3fd6293a1c64c412L), Double.longBitsToDouble(0x3fb33aa0fb7d19a0L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\0121=null |this=com.google.debugging.sourcemap.SourceMapConsumerV3:@?\012",
        Z.run(T, 2, 7, 7, 6, "\ud809\udeee\uda07\udc53\udbb2\udc92\udbd4\udfcc", "\u50a9\u9305", "\udb77\udcd1\ud97b\udea0\uda14\udcd7\ud9c2\udfe9\udbda\udc9d\udb6d\ude35\ud819\udcbe\ud82d\uddbd\ud84c\udcc0",
        0, 32303, -355102348, 3671344529007693387L, -3167L, true, false, (char) 37957, (char) 60694,
        Double.longBitsToDouble(0x3fd5d2632454dcceL), Double.longBitsToDouble(0x3f4bc5ed5adbc800L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 15, 6, "{\uda1f\udfc4=4", "\u26af\uad5e", "\ud9ab\ude52\ud8c2\udc6a\udaae\udf5d\ud9b0\udc87\udb6f\udd94\ud8ae\udee4\uda12\uddcf\uda98\uddd3\ud980\udc97\ud994\udeb6",
        19, 82533, 1324660591, 8259434333018564656L, -771L, true, false, (char) 29960, (char) 22799,
        Double.longBitsToDouble(0x3fe6e60f0503596fL), Double.longBitsToDouble(0x3fe47ca61d77b54eL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 14, 6, "{\ud813\udcaa=/", "\u500b\u7d0b", "\ud9ab\ude52\ud8c2\udc6a\u7159\ud9c3\udc7e\ud9ef\ude14\ud936\udfea\uda4d\udf58\uda98\uddd3\ud809\ude02\udb3a\udf80",
        -2, 40479, 1324614885, 8259434333018564656L, -771L, false, true, (char) 24059, (char) 19482,
        Double.longBitsToDouble(0x3fe6e60f0503596fL), Double.longBitsToDouble(0x3fe47ca61f47b54eL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 4, 5, "{\ud813\udcaa=!\udbde\udf8e\ud94a\udcb3\udb5a\udc72\udbaa\ude63", "\ub568\u095f\u7159\ua262\ucff5\u5edb\u2494\u4340\u4c41\uca70", "\ud852\udd8c\ud8df\ude85\udb69\udfcf\udae6\uddd0\u0daf",
        8, 73288, -1042243500, 9208840721879211332L, 68121L, true, false, (char) 42866, (char) 21900,
        Double.longBitsToDouble(0x3fe8892d4d9e34b1L), Double.longBitsToDouble(0x3feac5073e218291L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 15, 6, "{\ud903\udee2:\udbf0\ude18", "\u9f73\u1aad", "\ud9ab\ude52\ud8c2\udc6a\u7159\ud9c3\udc7e\ud9ef\ude14\ud888\udf12\uda12\uddcf\uda98\uddd3\ud809\ude02\udb3a\udf80",
        -2, 9243, -1510734619, 8259434040960788528L, -32047L, true, true, (char) 58445, (char) 6066,
        Double.longBitsToDouble(0x3fe5f7353dfbf5e4L), Double.longBitsToDouble(0x3fdcae31902b2ff0L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 8, 14, "{-\000\000", "\u91be\u1449", "\ud9ab\ude52\ud8c2\udc6a\u7159\ud9c3\udc7e\uda8e\udfa4\ud888\ude83\uda12\uddcf",
        13, 67666, -1448107881, 6731356893874267059L, 67490L, false, true, (char) 22907, (char) 8636,
        Double.longBitsToDouble(0x3fd03596fd1f2986L), Double.longBitsToDouble(0x3fea3daa7473213cL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 4, 5, "{\ud813\udcaa=!\udbde\udf8e\"\udb23\uddd1\udbaa\ude63", "\u410b\u095f\u7159\u1850\ucff5\u5edb\u2494\u4340\u4c41\uca70", "\ud852\udd8c",
        32, 46304, 2119303775, -7250369213792161308L, 68121L, true, false, (char) 42866, (char) 21900,
        Double.longBitsToDouble(0x3fe8892d4d9e34b1L), Double.longBitsToDouble(0x3feac5073e218291L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 8, 6, "{\\\000\000", "\u91be", "\udbd0\udd2c\ud9ab\ude52\ud8c2\udc6a\u7159\ud9c3\udc7e\uda8e\udfa4\ud888\ude83\uda12\uddcf\uda98\uddd3\ud809\ude02\udb3a\udf80\ud92a\udeef\ud846\udeb1\ud852\udd8c\ud8df\ude85\uda0c\ude87\ud95e\udd1e\u0daf",
        35, 47432, 585146560, 6444649810837576963L, 2020L, false, true, (char) 32023, (char) 32088,
        Double.longBitsToDouble(0x3fad6b8d2b38ad40L), Double.longBitsToDouble(0x3fccf41b3ac840f8L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 15, 6, "{\uda1f\udfc4=0", "\u493f\uad5e", "\ud9ab\ude52\ud8c2\udc6a\udaae\udf5d\ud9b0\udc87\udb6f\udd94\ud8ae\udee4\uda12\uddcf\udb5e\udd19\ud980\udc97\ud994\udeb6",
        19, 82533, 1324660591, -3485953495163676680L, -771L, true, false, (char) 29960, (char) 22799,
        Double.longBitsToDouble(0x3fe0fdf1dd03596fL), Double.longBitsToDouble(0x3fe47ca61d77b54eL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 15, 6, "{\uda1f\udfc4=0\udbde\udf8e\ud82c\udd4d\uda12\udc9f", "\u302f\u608d", "\ud9b0\udc87\udb6f\udd94\ud8ae\udee4\uda12\uddcf\udb5e\udd19\ud980\udc97\ud994\udeb6\ud92a\udf45\ud840\udcf8\ud87f\udc16\ud867\udcea\udbe9\udf91\udae6\uddd0\ud87b\udd49\ud98f\uddd3\udb26\udd91",
        57, 54775, -1799152381, 63157659815333239L, -60225L, false, true, (char) 63284, (char) 52072,
        Double.longBitsToDouble(0x3fcb5d01b7db6f94L), Double.longBitsToDouble(0x3fc770112892f414L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 15, 6, "{\ud813\udcaa={", "\u9f73\u1aad", "\ud9ab\ude52\ud8c2\udc6a\u7159\ud9c3\udc7e\ud9ef\ude14\ud888\udf12\uda12\uddcf\uda98\uddd3\ud809\ude02\udb3a\udf80",
        -2, 9243, 1324614885, 8259434333018535216L, -771L, false, true, (char) 28469, (char) 22799,
        Double.longBitsToDouble(0x3fe6e60f0503596fL), Double.longBitsToDouble(0x3fe47ca61f47b54eL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 15, 6, "{\uda1f\udfc4=.", "\u493f\uad5e", "\ud9ab\ude52\ud8c2\udc6a\udaae\udf5d\ud9b0\udc87\udb6f\udd94\ud8ae\udee4\uda12\uddcf\udb5e\udd19\ud980\udc97\ud994\udeb6",
        19, 82533, 1324660591, -3485953495163676680L, -771L, true, false, (char) 29960, (char) 22799,
        Double.longBitsToDouble(0x3fe0fdf1dd03596fL), Double.longBitsToDouble(0x3fe47ca61d77b54eL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 15, 6, "{\uda1f\udfc4=+\u0e41\ud929\udd8b\ud8a0\ude1b", "\u302f\u608d", "\ud9b0\udc87\udb6f\udd94\ud8f0\uddc0\udab8\udfd0\udbc1\udf40\ud980\udc97\ud994\udeb6\ud92a\udf45\ud840\udcf8\ud87f\udc16\uda85\udf39\ud81f\ude09\ud9c3\udeca\ud87b\udd49\ud98f\uddd3\udb26\udd91\udb27\udc73\uda17\udd30\uda6f\udcfb\uda39\udf4b\ud9be\udfac",
        40, 34955, -1970916588, 6659045114599594057L, -67569L, true, false, (char) 23518, (char) 34755,
        Double.longBitsToDouble(0x3fedc0849c08adfcL), Double.longBitsToDouble(0x3fd36af2364becd2L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 15, 6, "{\ud813\udcaa={\udbde\udfe2\ud8d2\uded6\udb5a\udc72\udbaa\ude63\ud8c3\udfd7\udbd8\udef4\ud9ab\ude52\ud8c2\udc6a\u7159\ud9c3\udc7e\ud9ef\ude14\ud888\udf12\uda12\uddcf", "\u324a\u0426\u4eff", "\uda15\udd18\udae6\uddd0\u88af\ud925\udd21\udb26\udd84\ud918\uddcb\ud87c\uded1\ud863\udf6f\uda83\udd2b\uda16\udedd\ud876\udde2\udb3c\udf7d\udb83\udc93",
        50, 35992, 1399691742, 8796202712092202660L, 37070L, false, true, (char) 7461, (char) 186,
        Double.longBitsToDouble(0x3fe1b878d53cb241L), Double.longBitsToDouble(0x3fdb9445eb07cb6cL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 1, 1, "{\uda1f\udfc4=[", "\u493f\uad5e", "\udb29\uddbe\uda6e\ude3d\udb37\udd5f\ud9b0\udc56\udb6f\udd94\ud8ae\udee4\uda12\uddcf\ud9f0\udc02\udb68\ude08\udb36\udd4e\ud92a\udf45\uda87\ude9c\uda7b\ude04\ud875\udeb9\udbe9\udf91\udae6\uddd0\ud87b\udd49\ud98f\uddd3\udb26\udd91\udafd\udc85\ud8f1\uddb8\udba7\ude13\ud870\uddd8\ud9a5\udf9f\udb95\udd92\udad3\uded6\ud821\udd62\ud883\ude7d\ud831\uded2\uda65\udf50\uda36\udc17\ud9b9\udc62",
        46, 78811, -459259155, 4460329346258489150L, 3262L, true, false, (char) 7269, (char) 54020,
        Double.longBitsToDouble(0x3fd1b1107e50d5a6L), Double.longBitsToDouble(0x3fd207c2deeb5a96L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 1, 8, "{\uda1f\udfc4=[\udbde\udf8e\ud929\udd8b\ud94e\udd72", "\u191e\u0cab", "\ud9b0\udc56",
        -4, 15015, -475356293, 3829076590937523710L, 69412L, true, false, (char) 3598, (char) 48822,
        Double.longBitsToDouble(0x3fefc67cfa5ff93cL), Double.longBitsToDouble(0x3fecebf292191c61L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 4, 5, "{\ud8d9\udcad=(\udbde\udf8e\ud94a\udcb3\udb5a\udc72\udba5\udd23", "\ub568\u095f\u7159\ua262\ucff5\u5edb\u214b\u4340\u4c41\uca70", "\udbce\udfc7\ud8df\udeaf\udb69\udfcf\udae6\uddd0\u0daf",
        8, 95944, 1432834252, -2997732090564331975L, -68836L, false, false, (char) 53558, (char) 21900,
        Double.longBitsToDouble(0x3fe8892d4d9e34b1L), Double.longBitsToDouble(0x3fe135473972428cL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=!com.google.debugging.sourcemap.SourceMapParseException\012",
        Z.run(T, 1, 9, 8, 4, "{}\000\000", "\u91be\u1449", "\ud9ab\ude52\ud8c2\udc6a\u7159\ud9c3\udc7e\uda8e\udfa4\ud888\ude83\uda12\uddcf",
        23, 95047, -1404745283, 6738575170530747315L, 67490L, false, true, (char) 22907, (char) 8636,
        Double.longBitsToDouble(0x3fd03596fd1f2986L), Double.longBitsToDouble(0x3fea3daa7473213cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.debugging.sourcemap.SourceMapConsumerV3|getOriginalMappingForEntry|com.google.debugging.sourcemap.SourceMapConsumerV3$Entry|new:com.google.debugging.sourcemap.SourceMapConsumerV3:",
    "M|com.google.javascript.jscomp.SourceMap|addMapping|com.google.javascript.rhino.Node,com.google.debugging.sourcemap.FilePosition,com.google.debugging.sourcemap.FilePosition|new:com.google.javascript.jscomp.SourceMap:com.google.debugging.sourcemap.SourceMapGenerator",
    "M|com.google.debugging.sourcemap.SourceMapConsumerV3|compareEntry|java.util.ArrayList,int,int|new:com.google.debugging.sourcemap.SourceMapConsumerV3:",
    "M|com.google.debugging.sourcemap.SourceMapConsumerV3|createReverseMapping||new:com.google.debugging.sourcemap.SourceMapConsumerV3:",
    "M|com.google.debugging.sourcemap.SourceMapConsumerV3|getJavaStringArray|org.json.JSONArray|new:com.google.debugging.sourcemap.SourceMapConsumerV3:",
    "M|com.google.debugging.sourcemap.SourceMapConsumerV3|getMappingForLine|int,int|new:com.google.debugging.sourcemap.SourceMapConsumerV3:",
    "M|com.google.debugging.sourcemap.SourceMapConsumerV3|getOriginalSources||new:com.google.debugging.sourcemap.SourceMapConsumerV3:",
    "M|com.google.debugging.sourcemap.SourceMapConsumerV3|getPreviousMapping|int|new:com.google.debugging.sourcemap.SourceMapConsumerV3:",
    "M|com.google.debugging.sourcemap.SourceMapConsumerV3|getReverseMapping|java.lang.String,int,int|new:com.google.debugging.sourcemap.SourceMapConsumerV3:",
    "M|com.google.debugging.sourcemap.SourceMapConsumerV3|parse|java.lang.String|new:com.google.debugging.sourcemap.SourceMapConsumerV3:",
    "M|com.google.debugging.sourcemap.SourceMapConsumerV3|parse|java.lang.String,com.google.debugging.sourcemap.SourceMapSupplier|new:com.google.debugging.sourcemap.SourceMapConsumerV3:",
    "M|com.google.debugging.sourcemap.SourceMapConsumerV3|parse|org.json.JSONObject|new:com.google.debugging.sourcemap.SourceMapConsumerV3:",
    "M|com.google.debugging.sourcemap.SourceMapConsumerV3|parse|org.json.JSONObject,com.google.debugging.sourcemap.SourceMapSupplier|new:com.google.debugging.sourcemap.SourceMapConsumerV3:",
    "M|com.google.debugging.sourcemap.SourceMapConsumerV3|parseMetaMap|org.json.JSONObject,com.google.debugging.sourcemap.SourceMapSupplier|new:com.google.debugging.sourcemap.SourceMapConsumerV3:",
    "M|com.google.debugging.sourcemap.SourceMapConsumerV3|search|java.util.ArrayList,int,int,int|new:com.google.debugging.sourcemap.SourceMapConsumerV3:",
    "M|com.google.debugging.sourcemap.SourceMapConsumerV3|visitMappings|com.google.debugging.sourcemap.SourceMapConsumerV3$EntryVisitor|new:com.google.debugging.sourcemap.SourceMapConsumerV3:",
    "M|com.google.debugging.sourcemap.SourceMapConsumerV3|getOriginalMappingForEntry|com.google.debugging.sourcemap.SourceMapConsumerV3$Entry|new:com.google.debugging.sourcemap.SourceMapConsumerV3:",
    "M|com.google.javascript.jscomp.SourceMap|addMapping|com.google.javascript.rhino.Node,com.google.debugging.sourcemap.FilePosition,com.google.debugging.sourcemap.FilePosition|new:com.google.javascript.jscomp.SourceMap:com.google.debugging.sourcemap.SourceMapGenerator",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
