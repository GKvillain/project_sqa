package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class NameAnalyzer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 6, 11, "\ud997\udfda\ud8b7\udda1\u8285\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a", "\uce32\u4775\u8834\u9c38\uc6ba\u9d65\ub2f8\u5d11\u036e\ua8c1\uc09e\uc905\u4aa9\u804f\u6cef\ucc47\u3e9c", "\ud937\ude59\udb45\udf18\udbc8\udc95\ud944\ude6c\udbe7\udfbc\udb56\udc33\udb62\udcba\udb89\udeda\ud8f4\udfce\ud905\udd73\uda96\udd57\udb44\udee3\ud90d\udf61\udbd5\udccd\uda46\udcd6\uda02\udc92\ud9bd\udf11\udbf0\ude78\ud98e\udc5e",
        18, 74813, -980905733, -9127992254222526053L, 95629L, true, true, (char) 3620, (char) 59004,
        Double.longBitsToDouble(0x3fdfef2beca23860L), Double.longBitsToDouble(0x3fa6907240ef5520L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 6, 11, "\ud997\udfda\ud8b7\udda1\u8285\uda5a\udd4d\ud8e2\udeaf\ud9ac\udee4", "\uce32\u4775\u8834\u9c38\uc6ba\u9d65\ub2f8\u5d11\u01d9\u558e\uc09e\uc905\u4aa9\u804f\u6cef\ucc47\u3e9c", "\ud937\ude59\udb45\udf18\udbc8\udc95\ud944\ude6c\udbe7\udfbc\udb56\udc33\udb62\udcba\udb89\udeda\ud8f4\udfce\ud905\udd73\uda96\udd57\udb44\udee3\ud90d\udf61\udbd5\udccd\uda46\udcd6\uda02\udc92\ud9bd\udf11\udbf0\ude78\ud98e\udc5e",
        18, 74813, -980905733, -9127992254222526053L, 95629L, true, true, (char) 3620, (char) 59004,
        Double.longBitsToDouble(0x3fdfef2beca23860L), Double.longBitsToDouble(0x3fa6907240ef5520L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 13, 0, "\000\000\u8285", "\u00a0\u00d0\000\u5447\ud509", "",
        0, -988, 913899520, -4251447529631266277L, -99768L, false, false, (char) 0, (char) 51,
        Double.longBitsToDouble(0x3fcce5000002e800L), Double.longBitsToDouble(0x3fe6d7b001f8e16cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:<a name=\"\ud997\udfda\ud8b7\udda1\u81b5\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a\">\ud997\udfda\ud8b7\udda1\u81b5\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a</a> |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 11, "\ud997\udfda\ud8b7\udda1\u81b5\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a", "\uce32\u4775\u8834\u9c38\uc6ba\u9d65\u72f8\u5d11\u036e\ua8c1\uc09e\ud447\u364f\u804f\u6cef\ucc47\u3e9c", "\ud937\ude59\udb45\udf18\udbc8\udc95\ud944\ude6c\udbe7\udfbc\udb56\udc33\udb62\udcba\udb89\udedac\000\ud9e2\udf10\udb44\udee3\ud90d\udf61\udbd5\udccd\uda46\udcd6\uda02\udc92\ud9bd\udf11\udbf0\ude78\ud98e\udc5e",
        18, 74592, -980905733, -9127992254222526053L, 95629L, true, true, (char) 3620, (char) 59004,
        Double.longBitsToDouble(0x3fdfef2be0000060L), Double.longBitsToDouble(0x3fa6900000ef5520L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 14, "\ud997\udfda\ud8b7\udda1\u8230\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a", "\uce32\u4775\u8834\u9c38\uc6ba\u9d65\ub2f8\u5d11\u036e\ua8c1\uc09e\uc905\u4aa9\u804f\u6cef\ucc47\u3e9c", "\ud937\ude59\udb45\udf18\udbc8\udc95\ud93a\udef3\udbe7\udfbc\udb56\udc33\udb62\udcba\udb89\udeda\ud8f4\udfce\ud905\udd73\uda96\udd57\udb44\udee3\ud90d\udf61\ud8d1\udcab\udbe9\udeb7\ud878\udc8d\ud9bd\udf11\udbf0\ude78\ud98e\udc5e",
        18, 54990, -980905733, -9122785894866314853L, 95629L, true, true, (char) 3620, (char) 59004,
        Double.longBitsToDouble(0x3fdfef2be35e3860L), Double.longBitsToDouble(0x3fcb9551103bd548L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 12, 0, "\ud997\udfda\ud8b7\udda1\u8285\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a", "\uce32\u4775\u08ba\u4092\uc6ba\u9d65\ub2f8\u5d11\u036e\ua8c1\uc09e\uc905\u4aa9\u804f\u6cef\ucc47\u3e9c", "\ud937\ude59\udb3e\udd2d\udbc8\udc95\udb83\udd8d\udbe7\udf38\udb56\udc33\udb50\udcba\udb89\udeda\ud8f4\udfce\ud905\udd73\uda96\udd57\udb44\udee3\ud8eb\ude71\udbd5\udce8\uda46\udcd6\uda02\udc92\ud9bd\udf11\udbf0\ude78\ud98e\udc5e",
        18, 74813, -980905733, -9127992254222526053L, 95629L, true, true, (char) 62311, (char) 37783,
        Double.longBitsToDouble(0x3fdfef2beca23860L), Double.longBitsToDouble(0x3fa6907240ef5520L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 0, "\u605c\ud8b7\udd8e\ud816\udddf\uda5a\udd33\u0098\ud917\udc6d", "\uce32\u4775\u8834\000\000\u9d59\ub2f8\u5d11\u036e\ua8c1\uc09e\uc905\u4aa9\000\u6cef\ucc47\u3e9c", "\ud937\ude59\udb45\udf18\udb13\udea8\ud944\ude6c\udbe7\udfbc\udb56\udc33\udb62\udcba\udb89\udeda\ud8d7\ude6b\000\uda96\udd1c\000\000\000\uda0a\uddc5\uda02\udc92\ud9bd\udf11\udbf0\ude78\ud98e\udc5e",
        18, 74813, -980905733, -9127992254222526053L, 95629L, true, true, (char) 3620, (char) 15360,
        Double.longBitsToDouble(0x3fdfef2beca23860L), Double.longBitsToDouble(0x3fa6907200ef5520L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 9, 1, 11, "\udab8\uddcc\ud8bb\udf0c\udbf4\ude84\uda5a\udd4d\ud8e2\udeaf\udacd\udf2b", "\uce32\u4775\u8834", "\ucfac",
        16, 32735, 924699163, 270211923288148456L, -61722L, true, true, (char) 42791, (char) 61381,
        Double.longBitsToDouble(0x3f75c5a2d4508480L), Double.longBitsToDouble(0x3fe5f11a9eb818c7L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 13, "\ud997\udfda\ud8e6\udec2\u81ca", "\u00a0\u3b34\uc995\uce32\u4775", "\udbf7\udf16\ucfac\udb69\udd9d\udb7f\udf84\ud9f3\udd5a\uda31\udc88\ud9be\ude3d\udb7f\udf2f\ud8a2\udeac",
        47, 4607, -156653735, -2196776280472159752L, 51083L, false, false, (char) 61381, (char) 18797,
        Double.longBitsToDouble(0x3fda8a109d7c46a6L), Double.longBitsToDouble(0x3fe5c0c63ab06940L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 9, 3, 0, "\ud997\udfda\ud8b7\udda1\u8285\uda5a\udd4d\udb3a\udc1a", "\u4c7f\ucdf1\u4774u\u9c38", "\ud938\ude3d\ud8eb\uddad\uda91\uddfc\uda31\udca3\ud9be\ude3d\udb7f\udf2f\ud8a2\udeac\ud986\ude97\uda78\uded3\uae39\uda7d\udc7e\uda93\udd55\u27b5\ud937\ude59\ud90e\udc9d",
        55, 36261, 592704899, 1785579110544733880L, 8281L, false, false, (char) 27264, (char) 47102,
        Double.longBitsToDouble(0x3fe4df70bf9c5104L), Double.longBitsToDouble(0x3feedb28a1679650L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 7, 11, "\ud997\udfda\ud8b7\udda1\u8285\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a", "\uce32\u4775\u395f\u9c38\uc6ba\u9d65\ub2f8\u5d11\u036e\ua8c1\uc09e\uc905\uc7fe\u16e0\u6caf\ucc47\u3e9c", "\ud937\ude59\udb45\udf18\udbc8\udc95\ud944\ude6c\udbe7\udfbc\udb56\udc33\ud896\udc73\ud8a1\udf02\udb5c\uddff\uda15\udff8\udad8\udf26\uda56\ude87\ud885\udc44\ud8cf\uddfa\u724a\uda02\udc95\ud9bd\udf96\udbf0\ude78\ud98e\udc5e",
        18, 74813, -980905733, -9129988172769617509L, 95629L, true, true, (char) 5930, (char) 59004,
        Double.longBitsToDouble(0x3fdfef2beca23860L), Double.longBitsToDouble(0x3fe931072543f588L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 1, 9, 6, 11, "\ud997\udfda\ud8b7\udda1\u8285\udb9d\udecf\ud9c4\ude73\ud917\udcbc", "\uce29\u4775\u8834\u51a4\u29bb\u9d65\ub2f8\u5d11\u036e\ua8c1\uc09e\uc905\u4aa9\u804f\u6cef\ucc47\u3e9c", "\ud937\ude59\udb45\udf18\udbc8\udc95\ud944\ude6c\udbe7\udfbc\udb56\udc33\udb62\udcba\udb89\udeda\ud8f4\udfce\ud905\udd73\uda96\udd57\udb44\udee3\uda0d\ude6c\udbd5\udccd\udb06\udca1\ud9ea\udc0f\ud9bd\udf11\udbf0\ude78\ud98e\udc5e",
        14, 74813, -980905733, -9127992254222526053L, 95629L, true, true, (char) 3620, (char) 40835,
        Double.longBitsToDouble(0x3fdfef2beca23860L), Double.longBitsToDouble(0x3fa6907265df5520L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 6, 11, "\ud997\udfda\ud8b7\udda1\u8285\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a", "\uce32\u471a\u8834\u9c38\uc6ba\u9d65\ub2f8\uacf3\u036e\ua8c1\uc09e\uc905\u4aa9\u804f\u6cef\ucc47\u3e9c", "\ud937\ude59\udb45\udf18\udbc8\udc95\ud944\ude6c\udbe7\udfbc\ud91e\uddb8\udb13\udff5\udb86\udcd2\ud8f4\udfce\ud905\udd73\uda96\udd57\udb44\udee3\ud90d\udf61\udbd5\udccd\uda46\udcd6\uda02\udc92\ud9bd\udf11\udbf0\ude78\ud98e\udc5e",
        18, 17501, -980905758, -9127992255917024869L, 95629L, false, false, (char) 12611, (char) 59004,
        Double.longBitsToDouble(0x3fdfef2beca23860L), Double.longBitsToDouble(0x3fa6907240ef5520L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 9, 9, 11, "\ud997\udfda\ud8b7\udda1\u8285\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a", "\uce32\u4775\u8834\u9c38\uc6ba\u9d65\ub2f8\u5d11\u036e\ua8c1\uc09e\uc905\u4350\u804f\u6cef\ucc47\u3e9c", "\ud937\ude59\udb45\udf18\udaf1\udeeb\ud912\udc77\udbe7\udfbc\udb56\udc33\udb62\udcba\udb89\udeda\ud8f4\udfce\ud905\udd73\uda96\udd57\udb44\udee3\udb99\ude07\udbd5\udccd\uda46\udcd6\uda02\udc92\ud9bd\udf11\udbf0\ude78\ud98e\udc5e",
        18, 74813, -980905733, -9127992254222526053L, 95629L, true, true, (char) 3620, (char) 59004,
        Double.longBitsToDouble(0x3fdfef2beca23860L), Double.longBitsToDouble(0x3fa6907240ef5520L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:<a name=\"\uf29b\ud8b7\ude75\u8285\uda5a\udd4d\ud8e2\udeaf\udabb\udd5f\">\uf29b\ud8b7\ude75\u8285\uda5a\udd4d\ud8e2\udeaf\udabb\udd5f</a> |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 14, 3, 11, "\uf29b\ud8b7\ude75\u8285\uda5a\udd4d\ud8e2\udeaf\udabb\udd5f", "\uce32\u4775\u4e9d\u934a\u7b31\u5b94\uca09\u3d50\ub816\ua8c1\uc09e\u5dfa\u423d\u804f\u6cef\ucc47\u3e9c", "\ud937\ude59\udb45\udf18\udbc8\udc95\ud944\ude6c\udbe7\udfbc\udb56\udc33\udb62\udcba\udb89\udeda\ud8f4\udfce\ud954\udc4a\udb08\udebe\ud963\udd16\udaae\udca1\udbd5\udd1f\uda46\udcd6\uda02\udc92\uda15\udf10\udbf0\ude78\ud98e\udc5e",
        18, 74813, -980905733, -9127992254222526053L, 95629L, true, true, (char) 3620, (char) 59004,
        Double.longBitsToDouble(0x3fefd9f5f0e990f1L), Double.longBitsToDouble(0x3fa6907240ee8a20L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud997\udfda\ud8b7\udda1\u8285\ud919\ude46\ud8e2\udeaf\ud917\udd5a<li>\uce32\u4775\u8834\u9c38\uc6ba\u9d65\ub2f8\u5d11\u036e\ua8c1\uc09e\uc905\u4aa9\u804f\u00e7\000\u2b42</li>\012 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 11, "\ud997\udfda\ud8b7\udda1\u8285\ud919\ude46\ud8e2\udeaf\ud917\udd5a", "\uce32\u4775\u8834\u9c38\uc6ba\u9d65\ub2f8\u5d11\u036e\ua8c1\uc09e\uc905\u4aa9\u804f\u00e7\000\u2b42", "\ud937\ude59\udb45\udf18\udbc8\udc95\ud944\ude6c\udbe7\udfbc\udb56\udc33\udb62\udcba\udb89\udeda\ud8f4\udfce\ud905\udd73\uda96\udd57\udb44\udee3\ud90d\udf61\udbd5\udccd\uda46\udcd6\uda02\udc92\ud9bd\udf11\udbf0\ude78\ud98e\udc5e",
        18, -1000, -980905733, 23322188594282496L, 95629L, true, true, (char) 45347, (char) 59004,
        Double.longBitsToDouble(0x3fdfef2beca23860L), Double.longBitsToDouble(0x3fa6907240ef5520L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=null |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 9, 10, 9, "\ud97d\udcf4\ud984\udc5c\udbf9\udd0c\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a\udadb\udeb8\ud9bb\ude1a\udbe3\ude65\udb43\udf1a\ud9a7\ude6f\ud91e\udc2e\uda9a\ude67\ucfac\udb69\udd9d\udb7f\udf84\ud9f3\udd5a\uda31\udc88\ud9be\ude3d\udb7f\udf2f\ud8a2\udeac\ud986\ude97\uda78\uded3\ud851\udecc\ud9cf\udca5\udb90\ude6b\ud9c6\udeea\ud9ff\udeee\udb45\udf55\udbc8\udc95\ud944\ude6c\udbe7\udfbc\ud8fb\udd45\u0766", "\u4af7\u1cd1\u5eb8\u475b\u19d5\u22d4\uc8b5\u0de0\u6ce5\u62a1\u92ac\u6b10\u6baf\ua544", "\ud9a7\udf06\uda4b\udcc8\ud8b6\udce8\udbfe\udfa8\ud8e4\udfa7\ud8ca\udc41\udbb2\udf8b\ud952\uddbc\uda7d\udd02\uda67\ude61",
        54, 10499, 1613391413, 1589549828618057356L, 68272L, false, false, (char) 12495, (char) 62460,
        Double.longBitsToDouble(0x3fd4b30c22f2017aL), Double.longBitsToDouble(0x3feef06126c0d468L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud997\udfda\ud8b7\udda1\u8285\uda5a\udd4d\uda8b\udfe2\ud910\udd00<li>\uce32\u4775\u8834\u9c38</li>\012 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 11, "\ud997\udfda\ud8b7\udda1\u8285\uda5a\udd4d\uda8b\udfe2\ud910\udd00", "\uce32\u4775\u8834\u9c38", "\udb69\udd9d\udb7f\udf84",
        58, 90616, 95046120, 4212110014809369689L, 40558L, true, true, (char) 2315, (char) 56164,
        Double.longBitsToDouble(0x3fe3d53b99d5ceafL), Double.longBitsToDouble(0x3fe4126529e74ddfL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 12, 5, "\ud997\udfda\ud8b7\udda1\u8285\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a\ud8fe\ude2b\ud9bb\ude9a\udbe3\ude65\udb43\udf1a", "\uc566\u92d4\ub2f8\u5d11\u036e\ua8c1\uc09e\uc905\u4aa9", "\udbad\udd40\ud9b0\udce8",
        41, 60883, 1285927381, 5611303173386034145L, -97352L, false, false, (char) 36735, (char) 18860,
        Double.longBitsToDouble(0x3fd63f880dc5ca58L), Double.longBitsToDouble(0x3fe1db7b8bf234ceL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.NameAnalyzer$JsName:\ud997\udfda\ud8b7\udda1\u8285\uda5a\udd4d\ud8e2\udeaf\udb07\udc47 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 12, 11, "\ud997\udfda\ud8b7\udda1\u8285\uda5a\udd4d\ud8e2\udeaf\udb07\udc47", "\ua684\u6da9\u8818\ubad1\uc6ba\u9d65\ub2f8\u5d11\u036e\ua8c1\ua5f4\uc905", "\uda78\uded3\ud851\udecc\udaaa\udd0c\ud84f\udcc0\u2792\ud937\ude59\udb45\udf18\udbc8\udc95\ud944\ude6c\udbe7\udfbc\udb2d\udf33\udb62\udcba\udb89\udeda\ud8f4\udfce\ud905\udd73\ud83d\udd2f\udb44\udee3\ud90d\udf61\udbd5\udccd\udba1\udd23\ud9ee\uddf8\ud9bd\udf11",
        27, 87274, -1824310387, -6493102297461518085L, 95629L, true, true, (char) 3620, (char) 59004,
        Double.longBitsToDouble(0x3fdfef2beca23860L), Double.longBitsToDouble(0x3fa6d3f240ef5520L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 6, 11, "\ud997\udfda\ud8b7\udda1\u8285\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a", "\uce32\u4775\u8834\u9c38\uc6ba\u9d65\ub2f8\u5d11\u036e\ua8c1\uc09e\uc905\u4aa9\u804f\u6cef\ucc47\u3e9c", "\ud937\ude59\udb45\udf18\udbc8\udc95\ud944\ude6c\udbe7\udfbc\udb56\udc33\udb62\udcba\udb89\udeda\ud8f4\udfce\ud905\udd73\uda96\udd57\udb44\udee3\ud90d\udf61\udbd5\udccd\uda46\udcd6\uda02\udc92\ud9bd\udf11\udbf0\ude78\ud98e\udc5e",
        18, 74813, -980905733, -9127992254222526053L, 95629L, true, true, (char) 3620, (char) 59004,
        Double.longBitsToDouble(0x3fdfef2beca23860L), Double.longBitsToDouble(0x3fa6907240ef5520L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 9, 2, 11, "\ud8bd\udc8f\ud8b7\udda1\u8285\ud9dd\udd2e\ud8e2\udeaf\ud917\udd5a", "\uce32\u513c\u8a3c\u6ac4\uc6ba\u9d65\ub2f8\u5d11\u036e\ua8c1\uc09e\uc905\uc2f6\u804f\u6cef\ucc47\u3e9c", "\ud937\ude59\ud980\udf16\udbd9\uddb9\ud944\ude6c\udbe7\udfbc\udb56\udc33\udb62\udcba\udb89\udeda\ud8dc\udcce\ud905\udd73\uda96\udd57\udb41\udde3\ud90d\udf61\udbd5\udccd\uda46\udcd6\uda02\udc92\udb32\udd2c\udb92\udf41\ud840\udcb9",
        18, 74813, -980905733, -9127992254222526053L, 95629L, true, true, (char) 3620, (char) 59004,
        Double.longBitsToDouble(0x3fdfef2beca23860L), Double.longBitsToDouble(0x3fa6907240ef5520L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 8, 3, "\ud997\udfda\ud8b7\udda1\u8285\udba4\udf03\udae9\udcf1\udb1b\udcba\ud9ae\udfab\ud9bb\udde9\udbe3\ude65\udb6a\udc1a\ud9a7\ude6f\ud91e\udc2e\ud909\udd00\udae3\udfa5\udb70\udf2a\udb58\udc44", "\ubfdb\uaf15\u41b2\u7262\u6cef\ucc47\u3e9c\u9905\u9d7e\u111e\u5300\ub2c3\u0e58\u8d23\u741c", "\ud8e9\udc70\ud8ac\udeab\ud856\ude5f\ud966\udcc9\ud90d\udf61\udbd5\udccd\uda46\udce1\uda02\udc92\udb95\udc3a\ud935\udfaa\ud98e\udc4f\ud9cf\ude0c\uda18\udc8d",
        36, 91063, 780966356, 2110689666838307648L, -58521L, true, false, (char) 13501, (char) 47744,
        Double.longBitsToDouble(0x3fa6907240ef5520L), Double.longBitsToDouble(0x3fc859e23ac84a58L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=void |a0=java.lang.StringBuilder:<li>\u00d0\uc6d4\u99c0\uc59e\u3b34\uc995\ub5eb\u4775:\000\000\u9d65\ub2f8\u5d11\u994a</li>\012 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 4, 0, 10, "", "\u00d0\uc6d4\u99c0\uc59e\u3b34\uc995\ub5eb\u4775:\000\000\u9d65\ub2f8\u5d11\u994a", "\000\000\000\udbbe\udfdf\ud851\udecc\udaaa\udd0c\ud84f\udcc0\ud930\ude84\ud937\ude59\udb45\udf18\udbc8\udc95\ud944\ude6c\udbe7\udfbc\ud816\ude28\udb62\udcba\udb89\udeda\ud8f4\udfce\ud905\udd73\uda96\udd57\udb44\udee3\ud90d\udf61\udbd5\udccd\000\uda02\udc2b\ud9bd\udf11\udbf0\ude78\ud98e\udc5e",
        18, 74813, -980905733, 241239723081728L, 95629L, true, true, (char) 45098, (char) 58993,
        Double.longBitsToDouble(0x3fdfef2beca23860L), Double.longBitsToDouble(0x3f20720000000000L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud997\udfda\ud8b7\udda1\u8285<li>null</li>\012 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=void |a0=java.lang.StringBuilder:\ud997\udfda\ud8b7\udda1\u8285<li>null</li>\012 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud997\udfda\ud8b7\udda1\u8285", "\u00a0\u3b34\uc995\000\u4775", "\udbba\udf18\000\udb69\udd9d\udb7f\udf84\ud9f3\udd5a\uda31\udc88\ud9be\ude3d\udb7f\udf2f\ud8a2\udeac",
        47, 4607, -156653735, -2203365391664416264L, -100000L, false, false, (char) 61158, (char) 18797,
        Double.longBitsToDouble(0x3fda8a109d7c4600L), Double.longBitsToDouble(0x3fe5c0c63f4c9a60L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 0, "\ud997\udfda\ud8b7\udda1\udaea\udfea\udacd\udc00\uda61\uded2\ud917\udd06", "\u5306\ua057\ucb6c\uc55d\ubf38\u9d65\ub2f8\u5d11\u9e63\ua8c1\uc3d0\uc871\u4ecf\u804f\u64ef\u90f3\u5413", "\uda6b\udc93",
        52, 43599, -1583141371, 2545648316713510590L, 51732L, true, true, (char) 15631, (char) 56748,
        Double.longBitsToDouble(0x3fef91a6729bee17L), Double.longBitsToDouble(0x3fe43288216ee2d5L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 6, 11, "\ud997\udfda\ud8b7\udda1\u00d0\000\ud8d8\ude0c\u00ed", "\uce32", "\ud824\ude11\uda9a\ude57",
        -2, 11576, 0, -7311371777709903598L, -72418L, true, false, (char) 54067, (char) 42878,
        Double.longBitsToDouble(0x3feacdd6badaf6a9L), Double.longBitsToDouble(0x3ebb000000000000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 1, 3, 11, "\ud997\udfda\ud8b7\udda1\u81b5\uda5a\udd4d", "\u3b34\u217b\uce32\u4775\u444a\u9c38\uc6ba\u9d65\u72f8\u5d11\u036e\ua8c1\uc09e\ud447\u364f\u804f\u6cef\ucc47\u3e9c\u9905\u3807\ua4ac\u6ecd\u9050\u5f78\u8cfe", "\udb83\udd91\u00d6\000\ud9e2\udf10\udb44\udee3",
        10, 93454, -1773080815, -1014812505117144227L, -21490L, true, true, (char) 28739, (char) 14046,
        Double.longBitsToDouble(0x3feb462c419b8152L), Double.longBitsToDouble(0x3fd122e8c7a731b6L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 3, 3, 9, "\ud997\udfda\ud8b7\udda1\u81b5\uda5a\udd4d", "\u3b34\u217b\u63c2\ucab8\u88df\u9c38\uc6ba\ud6ef\u2464\u5d11\u036e\ua8c1\uc09e\u56f2\u364f\u804f\u6cef\ucc47\u3e9c\u9905\u3807\ua4ac\u6ecd\u9050\u8e95\u903e", "\u8306c\uda84\udec7",
        47, 25218, 1359280795, -2101748888039788783L, 82708L, false, true, (char) 47657, (char) 14617,
        Double.longBitsToDouble(0x3fc94eed55fa5a64L), Double.longBitsToDouble(0x3feb462c419b8152L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 4, 4, 14, "\ud9e9\ude05\ud8aa\ude64\ud892\udf37\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a", "\uce32\u5044\u7180\u9c38\uc6ba\u9d65\ub2f8\u5d11\u036e\u569c\ud708\uc940\u4aa9\u804f\u6cef\ucc47\u3e9c", "\ud937\ude2f\udb45\udf18\udbc8\udc95\ud93a\udef3\udbe7\udfbc\udb56\udc33\udb62\udcba\udb26\udf9b\ud8f4\udfce\ud905\udd73\udbbc\uddbb\ud81f\udc2e\ud90d\udf61\ud8d1\udcab\udbd0\udc4b\ud82b\udc98\udbd0\udeda\udbf0\ude78\ud98e\udc5e",
        18, 54990, -980905733, -9122785894866314853L, 95629L, true, true, (char) 15139, (char) 59004,
        Double.longBitsToDouble(0x3fdfef2be35e3860L), Double.longBitsToDouble(0x3fcb9551103bd548L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 1</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 4, 9, 14, "\ud997\udfda\ud8b7\udda1\u8230\uda5a\udd4d\ud81b\udd4a\udb9f\udd5e", "\u4fc5\ucce6\u8834\u9c38\uc6ba\u9d65\ub2f8\u5d11\u036e\ua8c1\uc09e\uc905\u4aa9\u804f\u6cef\ucc47\u3e9c", "\ud937\ude59\udb9a\udc82\udbd5\udf95\ud93a\udef3\udbe7\udfbc\udb56\udc33\udb62\udcba\udb89\udeda\ud8f4\udfce\ud905\udd73\uda96\udd57\uda1d\uddf0\ud90d\udf61\ud8d1\udcab\udbe9\udeb7\ud878\udc8d\ud9bd\udf11\udbf0\ude78\ud98e\udc5e",
        18, 54990, -980905733, -3529826086978416602L, 95629L, true, true, (char) 3620, (char) 59004,
        Double.longBitsToDouble(0x3fdfef2be35ee660L), Double.longBitsToDouble(0x3fcb9551103bd548L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.NameAnalyzer$JsName:\ud997\udfda\ud8b7\udda1\u8230\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:1 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 10, 3, 10, "\ud997\udfda\ud8b7\udda1\u8230\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a", "\ua7f3\u4775\u11ed\u73b4\ua42a\u7900\ub382\u5a4c\u03a9\ua8c1\uc09e\uc905\u4aa9\u163d\u6c5a\ucacc\u3de5", "\ud937\ude59\udb45\udf18\uda5a\ude37\ud937\uddee\udbe7\udfbc\udb56\udc33\u7ef9\ud8dd\ude72\ud8f4\udf88\ud905\udd73\uda96\udd57\udb44\udee3\ud90d\udf61\ube5b\udbe9\udeb7\ud878\udc8d\ud9bd\udf11\udbf0\ude78\ud98e\udc5e",
        53, 29693, -980905733, -9122785894866347365L, 95629L, true, true, (char) 3620, (char) 59004,
        Double.longBitsToDouble(0x3fdfe88be35e3860L), Double.longBitsToDouble(0x3fcb9551103bd548L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 4, 3, 14, "\ud997\udfda\ud8d3\udcb9\udbf3\udf71\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a", "\uce32\u4775\u8834\u9c38\uc6ba\u9d65\ub2f8\u5d11\u426d\ua8c1\uc09e\uc905\u4aa9\u804f\u6cef\u480c\u3e9c", "\ud937\ude59\udb45\udf18\udbc8\udc95\ud93a\udef3\udbe7\udfbc\udb56\udc33\udb62\udcba\udb89\udeda\ud8f4\udfce\ud905\udd73\uda96\udd57\udb44\udee3\ud90d\udf61\ud8d1\udcab\udbe9\udeb7\ud878\udc8d\ud9bd\udf11\udbf0\ude78\ud98e\udc5e",
        18, 54990, -980905733, -9122785894866314853L, 95629L, true, true, (char) 3620, (char) 59004,
        Double.longBitsToDouble(0x3fdfef2be4396660L), Double.longBitsToDouble(0x3f903c2f81deaa40L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 9, 1, 11, "\udab8\uddcc\ud8bb\udf0c\udbf4\ude84\uda5a\udd4d\ud8e2\udeaf\udacd\udf2b\uda5b\udcb9\udbe5\udfc4\udbe3\ude65\udb43\udf1a\ud9a7\ude6f\ud91e\udc2e\uda9a\ude67\ucfac\ud8d1\udcfb\udb5a\udcba\ud9f3\udd5a", "\uc905\u4aa9\u804f\u6cef\ucc47\u3e9c\u9905\u3807\ub6ce\u6ecd\u9050\u5f78\ucf86\u741c\ua8de\u37e3\u27cc\u61b0\u698a\u0793\u9bf1\u2f9e\u4bf3\u53da\ua055\u28ac\u06d0", "\ud91c\udc8b\uf236\ud89e\ude83\udbcc\udf8c\ud89e\udfb9\udb63\udf87\udb60\udc35\ud921\udc64\ud8ed\udd71\ud839\udc62",
        40, 56291, 1974579516, -463813429350064571L, -500L, false, true, (char) 30174, (char) 41565,
        Double.longBitsToDouble(0x3fe3c7469200ecfbL), Double.longBitsToDouble(0x3fdc5ef41afd86eaL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 1, 1, 11, "\udab8\uddcc\ud8bb\udf0c\udbf4\ude84\uda5a\udd4d\ud8e2\udeaf\udacd\udf2b", "\u120d\u4775\u8834", "\u8099\udb69\udd9d\udb7f\udf84",
        1, 90616, 95046120, 4212110014809369689L, -61722L, true, true, (char) 42791, (char) 61381,
        Double.longBitsToDouble(0x3f75c5a2d4508480L), Double.longBitsToDouble(0x3fde7d47a4d8aa98L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.NameAnalyzer$JsName:\udb48\ude32\ud8bb\udf0c\udbf4\ude84\ucfba\ud915\ude4c\udacd\ude61 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:1 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 10, 3, 11, "\udb48\ude32\ud8bb\udf0c\udbf4\ude84\ucfba\ud915\ude4c\udacd\ude61", "\uce32\u4775\u8834", "\ucfac",
        16, 32735, 924699163, 270211923288148456L, 20837L, false, true, (char) 51679, (char) 36735,
        Double.longBitsToDouble(0x3fecd141d8f9b040L), Double.longBitsToDouble(0x3fe774950287194dL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 2</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 1, 9, 11, "\udab8\uddcc\ud8bb\udf0c\udbf4\ude84\uda5a\udd4d\ud8e2\udeaf\udacd\udf2b", "\uce32\u4775\u8834", "\ucfac",
        16, 32735, 924699163, 270211923288148456L, -61722L, true, false, (char) 61728, (char) 61381,
        Double.longBitsToDouble(0x3f75c5a2d4508480L), Double.longBitsToDouble(0x3fe5f11a9eb818c7L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.NameAnalyzer$JsName:\ud997\udfda\ud8e6\udec2 |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=com.google.javascript.jscomp.NameAnalyzer$JsName:\ud997\udfda\ud8e6\udec2 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 10, 10, 7, "\ud997\udfda\ud8e6\udec2", "\u99c0\u00a0\u3b34\uc995\u567e\u4775\u8834\u9c38\u7963\u9d65\ub2f8\u5d11\u036e\ua441\uc09e\uc905\u4aa9\u804f\u6cef\ucc47\u077b\u9905\u3807\ua4ac\u6ecd\u9050\u5f78\ucf86\u741c\u0643\u1559\u5943\u4a8b\uade0\uc947\uc2b3\u4906\u9cf0\u50cb\u4e3e\u93c6\u88a3\u848b\ub1df\u6bbb\ua742\ubfab\ub4c0\u4612\u30c1\ua90d\u1152\uad8f\ua412\ud10c\u8847\ubd40\u98e5\u251f\ub364\u6364\ua487\u2e12\ua1d3\ua193\u1d4d\u5c61\u1409\u5bd4\u6726\u9018\u5d06\u55a8\u7764\u3b14\u87a0\u5e63\u54cc\u17b3Y\u39bd\u7fdc\u5d8e\u800d", "\ud8f4\udef9\ud9a4\udcdf\ud9ae\ude97\ud8d0\ude7e\uda5a\udc41\ud86b\ude34\udaba\udd97\ud944\udc77\udb8d\udc21\ud81f\ude83\uda91\udeb8\udb22\udc24\ud9dc\uddc3\ud8d0\udf32\ud864\uddac\udb16\udd89\ud996\udebe\ud80f\udf31\uda88\ude9b",
        51, 51387, 1627285027, 50440026532456855L, -28332L, false, true, (char) 59243, (char) 30595,
        Double.longBitsToDouble(0x3fd4f7abb17612e8L), Double.longBitsToDouble(0x3fc772ddc51afe34L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 4, 3, 0, "\ud997\udfda\ud8b7\udda1\u8285\uda5a\udd4d\udb3a\udc1a", "\u4c7f\ucdf1\u4774u\u9c38", "\udb73\uded9\ud8eb\udda3\uda91\uddfc\uda31\udca3\ud9e8\udc3c\udb7f\udf2f\ud8a2\udeac\ud94c\udc6d\uda4e\ude1e\uae39\uda7d\udc7e\udbc4\udced\u279a\ud937\ude59\ud90e\udc9d",
        55, 36261, 593998211, 1785579110544733880L, 8281L, false, false, (char) 27264, (char) 47102,
        Double.longBitsToDouble(0x3fe4df70bf9c5104L), Double.longBitsToDouble(0x3feedb28a1679650L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=null |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 10, 10, 9, "\ud97d\udcf4\ud984\udc5c\udbf9\udd0c\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a\udadb\udeb8\ud9bb\ude1a\udbe3\ude65\udb43\udf1a\ud9a7\ude6f\ud91e\udc2e\uda9a\ude67\ucfac\udb69\udd9d\udb7f\udf84\ud9f3\udd5a\uda31\udc88\ud9be\ude3d\udb7f\udf2f\udb04\udddc\ud9bb\udfad\uda78\uded3\ud851\udecc\ud965\udfbd\udb90\ude6b\ud9c6\udeea\ud9ff\udeee\udb45\udf55\udbc8\udc95\ud944\ude6c\udbe7\udfbc\ud8fb\udd45\u0766", "\u4af7\u1cd1\u5eb8\u475b\u19d5\u22d4\uc8b5\u0de0\u6ce5\u62a1\u92ac\u6b10\u6baf\ua544", "\ud9a7\udf06\uda4b\udcc8\ud8b6\udce8\udbfe\udfa8\ud8e4\udfa7\ud8ca\udc41\udbb2\udf8b\ud952\uddbc\uda7d\udd02\uda67\ude61",
        54, 10499, 1613391413, 1589549828618057356L, 68272L, false, false, (char) 12495, (char) 62460,
        Double.longBitsToDouble(0x3fd4b30c22f2017aL), Double.longBitsToDouble(0x3fee2db926c0d468L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:2 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 1, 3, 2, "\ud93a\udc22\ud91a\udd67\ud808\udf5c\uda5a\ude0f\ud8e2\udeaf\ud917\udd5a\ud8fe\ude2b\ud943\udee1\udbe3\ude65\udb43\udf1a", "\uc6ba\u9d65\u72f8\u5d11\u036e\ua8c1\uc09e\ud447\u364f\u804f", "\udaaa\udd0c\ud84f\udcc0\u2792\ud937\ude59\udb45\udf18\udbc8\udc95\ud944\ude6c\udae7\udf9c\udaf1\ude59\uda1a\ude6a\ud86e\udd13\u00d6",
        -5, 77232, -300448782, 5838066560116528774L, -12295L, true, true, (char) 2680, (char) 47657,
        Double.longBitsToDouble(0x3fec699dd5009343L), Double.longBitsToDouble(0x3fcf74bc6da31620L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:1 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 4, 3, 8, "\ud997\udfda\ud8b7\udda1\uda6f\udea6\uda5a\udd6a", "\ucf2c\u9f0b\uce32\u5e9c\u444a\u9c38\uc6ba\u9d65\u72f8\u5d11\u036e\ucfdd\ub8d8\ud447\u364f\u804f\u7115\ucc47\u3e9c\u9905\u3807\u07db\u543a\ud015\u5f78\u8cfe", "\udb83\udd91\ud819\udd88\udab9\uddb5\ud9e2\udf10\udb44\udee3",
        10, 93454, -1773080815, -1014812505117144227L, -21490L, true, true, (char) 28739, (char) 37342,
        Double.longBitsToDouble(0x3feb462c419b8152L), Double.longBitsToDouble(0x3fd122e8c87731b6L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 6, 11, "\ud997\udfda\ud8b7\udda1\u8285\uda5a\udd4d\ud8e2\udeaf\ud917\udd5a", "\uce32\u4775\u8834\u9c38\uc6ba\u9d65\ub2f8\u5d11\u036e\ua8c1\u2dbb\uc89f\u4aa9\u804f\u6cef\ucc47\u3e9c", "\ud937\ude59\udb45\udf18\udbc8\udc95\ud944\ude6c\udbe7\udfbc\udb56\udc33\udb62\udcba\udb89\udeda\udaaf\udcab\ud8ca\udf5e\uda96\udd57\udb44\udee3\ud90d\udf61\udbd5\udccd\uda46\udcd6\uda02\udc92\ud9bd\udf11\udbf0\ude78\ud98e\udc5e",
        18, 74813, -980905733, -9127992254222526053L, 95629L, true, true, (char) 3620, (char) 59004,
        Double.longBitsToDouble(0x3fdfef2beca23860L), Double.longBitsToDouble(0x3fa6907240ef5520L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String:<html><body><style type=\"text/css\">body, td, p {font-family: Arial; font-size: 83%} ul {margin-top:2px; margin-left:0px; padding-left:1em;} li {margin-top:3px; margin-left:24px; padding-left:0px;padding-bottom: 4px}</style>OVERALL STATS<ul><li>Total Names: 0</li>\012<li>Total Classes: 0</li>\012<li>Total ... |this=com.google.javascript.jscomp.NameAnalyzer:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NameAnalyzer:@?\012",
        Z.run(T, 2, 9, 3, 0, "\ud997\udfda\ud8b7\udda1\u8285\uda5a\udd4d\udb3a\udc1a", "\u4c7f\ucdf1\u4774u\u9c38", "\ud8fe\ude5f\ud8eb\ude31\uda18\udeee\ud947\ude17\udbb6\udec6\udb8e\udcc9\ud8a2\udeac\ud986\ude97\uda78\uded3\uda21\ude93\udb6e\udfcb\uda5f\udffd\ud96f\udf04\udb66\udf9b\udb36\udef6",
        44, 14734, -715460857, 3149044284274195110L, 8281L, false, false, (char) 27264, (char) 47102,
        Double.longBitsToDouble(0x3fe4df70bf9c5104L), Double.longBitsToDouble(0x3feedb28a1679650L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.NameAnalyzer|appendListItem|java.lang.StringBuilder,java.lang.String|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|calculateReferences||new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|collapseReplacements|java.util.List|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|countOf|com.google.javascript.jscomp.NameAnalyzer$TriState,com.google.javascript.jscomp.NameAnalyzer$TriState|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|createName|java.lang.String|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|createNameInformation|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|createNameInformation|java.lang.String,com.google.javascript.jscomp.Scope,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|getDependencyScope|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|getEnclosingFunctionDependencyScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|getHtmlReport||new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|getName|java.lang.String,boolean|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|getRhsSubexpressions|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|getSideEffectNodes|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|isExternallyReferenceable|com.google.javascript.jscomp.Scope,java.lang.String|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|nameAnchor|java.lang.String|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.NameAnalyzer|nameLink|java.lang.String|new:com.google.javascript.jscomp.NameAnalyzer:com.google.javascript.jscomp.AbstractCompiler,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
