package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeCheck_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 14, 3, "\udb9d\udf89\ud858\udef3\udbb2\ude33\ud899\ude7a\uce08\u98c3\ud986\ude39\udbb3\udd58\ud87e\ude9c\udaf7\uddb1\ud827\udde9\udb33\ude0d\ud967\ude5e\udbf9\udcd5\udb10\udc50", "\u49ca\u8c3a\ubf40\u15ed\u0eb5\u0970\u5334\ubd59\ud386", "\udafd\udd96\ud8a6\udc91\udafe\udccf\uda78\ude44\u1a71\ud9b0\udfe3\udb57\udfe0",
        26, 74995, 1172526033, 6727405987309136183L, 78360L, true, true, (char) 22517, (char) 47043,
        Double.longBitsToDouble(0x3fdfce86dd3b94faL), Double.longBitsToDouble(0x3fc27f9ccca3881cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 14, 3, "\000\udb19\udf2c\000\000\000\000\ud986\uddfd\udbb3\udd58\u00b7\udaf7\udd35\ud827\udde9\udab8\udcfc\ud967\ude5e\udbf9\udcd5\udaf0\ude50", "\ub667\u9ac7\000\000\u3aaa\u0970\u5334\ubd59\ud386", "\udafd\udd96\ubb16\000\ud98a\udf85\u1a71\ud97b\udfe3\udb57\udfe0",
        26, 74995, 1172526033, 6727405987309136183L, 97854L, true, false, (char) 54889, (char) 45338,
        Double.longBitsToDouble(0x3fc27f9ccca3881cL), Double.longBitsToDouble(0x3fd8ebfad70e152cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 14, 3, "\udb9d\udf89\ud858\udef3\udbb2\ude33\ud899\ude7a\uce08\u98c3\ud986\ude39\udbb3\udd58\ud87e\ude9c\udaf7\uddb1\ud827\udde9\udb33\ude0d\ud967\ude5e\udbf9\udcd5\udb10\udc50", "\u49ca\u8c3a\u5e61\u1570\u0eb5\u0970\u5334\u9dc5\ud386\u35e9\u7f30\u42f5\u486e\u33e5", "\ud9b0\udfe3\udb57\udfe0\udac4\udd6c",
        44, 16033, 1566346266, 2694746003755568003L, 1481L, false, true, (char) 45338, (char) 55673,
        Double.longBitsToDouble(0x3fe947103e024c58L), Double.longBitsToDouble(0x3fe82058a0721778L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 14, 3, "\udb9d\udf89\ud858\udef3\udbb2\ude33\ud899\ude7a\ud884\udeef\u98bb\ud986\ude39\udbb3\udd58\ud87e\ude9c\udaf7\uddb1\ud827\udde9\udb33\ude0d\ud967\ude5e\udad2\udd15\ud85c\ude13", "\u8d8a\u9ea9\ubf33\u39e4\u0eb5\u0970\u5334\ubd59\ud386", "\udafd\udd96\ud8a6\udc91\udafe\udccf\uda78\ude44\u1a71\ud9b0\udfe3\udb57\udfe0",
        26, 74995, 1172526033, 6727405985715300663L, 78360L, true, true, (char) 22517, (char) 47043,
        Double.longBitsToDouble(0x3fdfce86d13b94faL), Double.longBitsToDouble(0x3fe78d7f1bf04fcfL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 14, 3, "\udb9d\udf89\ud858\udef3\udbb2\ude33\ud899\ude7a\ud8bd\udeec\u9950\ud986\ude39\udbb3\udcae\ud87e\ude9c\udaf7\uddb1\ud827\udde9\udb33\ude0d\udbb1\ude63\udbf9\udcd5\udb10\udc50", "\u49ca\u8c3a\ubf40\u15ed\u0eb5\u0970\u5334\ubd59\ud386", "\udafd\udd96\ud8a6\udc8d\udafe\udccf\uda78\ude44\u1a71\ud9b0\udfe3\udb57\udfe0",
        26, 18054, 1164228748, 6727405987309136183L, 78360L, true, true, (char) 22517, (char) 47043,
        Double.longBitsToDouble(0x3fdfce86dd3b94faL), Double.longBitsToDouble(0x3fc27f9ccca3881cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 14, 3, "\udb9d\udf89\ud858\udef3\udb95\udcb3\ud899\ude6a\uce08\u98c3\ud986\ude39\udbb3\udd58\ud87e\ude9c\udaf7\uddb1\udad5\ude12\uda35\ude5f\uc3f5\udbf9\udcd5\udb10\udc50", "\u49ca\u8c3a\ubf40\u15ed\u0eb5\u0970\u0535\ubd59\ud386", "\udafd\udd96\ud8a6\udc91\udafe\udccf\uda78\ude44\u1a71\ud9b0\udfe3\udb57\udfe0",
        26, 74995, 1172526033, 6727405987309136183L, 78360L, true, true, (char) 22517, (char) 47043,
        Double.longBitsToDouble(0x3fdfce86dd3b94faL), Double.longBitsToDouble(0x3fc27f9ccca3881cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 5, 3, "\udb9d\udf89\ud858\udef3\udbb2\ude33\ud899\ude7a\uce08\ud8d8\udc3b\u1719\udb82\ude40\ud88c\ude16\ud9ad\udee3\ud827\udde9\udb33\ude0d\ud967\ude5e\udbf9\udcd5\udb10\udc50", "\u0559\u8c3a\ubf40\u15ed\u0eb5\u0970\u5334\ubd59\ud386", "\udafd\udd96\ud8a6\udc91\udafe\udccf\uda78\ude44\u1a71\ud9b0\udfe3\udb57\udfe0",
        26, 74995, 1172526033, 6727405987309136183L, 78360L, true, true, (char) 22517, (char) 47043,
        Double.longBitsToDouble(0x3fdfce86dd3b94faL), Double.longBitsToDouble(0x3fc27f9ccca3881cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 12, 3, "\udb9d\udf89\ud858\udef3\udbb2\ude33\ud899\ude7a\uce08\u98c3\ud986\ude39\udbb3\udd58\ud87e\ude9c\udaf7\uddb1\ud827\udde9\udb33\ude0d\ud967\ude5e\udbf9\udcd5\udb10\udc50", "\u49ca\u8c3a\u743d\u15ed\ud74c\u33ca\u67a0\ubd59\ud386", "\udafd\udd96\ud8a6\udd02",
        45, 8731, 276910456, 8542155208740043061L, -64134L, true, true, (char) 12520, (char) 53513,
        Double.longBitsToDouble(0x3fe938632cde5317L), Double.longBitsToDouble(0x3fba4ad6c7e74368L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 14, 3, "\ud882\udcfc\ud858\udef3\udbb2\ude33\ud899\ude7a\uce08\u98c3\ud986\ude39\udbb3\udd58\ud87e\ude9c\ud9b5\uddb0\uda2d\udf6d\uda54\udf99\ud8e9\ude24\udbf9\udd47\udad3\udd1a", "\u49ca\u5a27\ua6dd\u362a\ub171\u0991\u5334\ubd59\ud386\u0cfa\u7f30\ua470\u66e8\u952e\u4d2f\ubd07", "\udac4\udd6c\ud90e\uddf8\udb0e\udc0f\ud8fc\ude67\udaf9\udcda\ud9de\ude13\udb06\udd9b\uda1d\udc0c\ud81f\udf6c\ud95c\udf05",
        10, 37453, -502801261, 447993856819414578L, 45839L, false, false, (char) 27234, (char) 46007,
        Double.longBitsToDouble(0x3fc06462917015bcL), Double.longBitsToDouble(0x3f912fe7378e63a0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.TypeCheck|visitCall|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|check|com.google.javascript.rhino.Node,boolean|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkDeclaredPropertyInheritance|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.FunctionType,java.lang.String,com.google.javascript.rhino.JSDocInfo,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkEnumInitializer|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkInterfaceConflictProperties|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,java.lang.String,java.util.HashMap,java.util.HashMap,com.google.javascript.rhino.jstype.ObjectType|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkNoTypeCheckSection|com.google.javascript.rhino.Node,boolean|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|checkPropertyAccess|com.google.javascript.rhino.jstype.JSType,java.lang.String,com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|doPercentTypedAccounting|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|ensureTyped|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|ensureTyped|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|ensureTyped|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|getFunctionType|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|getJSType|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|getNativeType|com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|getTypedPercent||new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
    "M|com.google.javascript.jscomp.TypeCheck|hasUnknownOrEmptySupertype|com.google.javascript.rhino.jstype.FunctionType|static",
    "M|com.google.javascript.jscomp.TypeCheck|visitCall|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypeCheck:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReverseAbstractInterpreter,com.google.javascript.rhino.jstype.JSTypeRegistry",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
