package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class NodeUtil_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 5, 1, "\udbcd\udd1c\ud99e\uddbf\ud9f6\uddb0\udb37\uddea\uda33\uddc3\u8215\udb00\udfe8\udbea\ude3c\udacb\udf6b\uda61\udd6a\ud821\udc53\udb83\udc3a\udbfa\udf95\uda9d\udefd\ud977\udd64\udb1c\ude0c\ud9cd\udc18\ud99e\udd55\ud966\ude9c\udb58\ude2e\ud8c4\udc74", "\u5912\ub6d6\u9ddb\ud059\u5837\u8978", "\u05ba",
        47, 59578, -1483120775, 803991531552892290L, -83850L, false, true, (char) 65348, (char) 63218,
        Double.longBitsToDouble(0x3feb7d16a6c2d5aaL), Double.longBitsToDouble(0x3fc2a1a80030a690L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 5, 1, "\udbcd\udd1c\ud99e\uddbf\ud9f6\uddb0\udb37\uddea\uda33\uddc3\u8215\udb00\udfe8\udbea\ude3c\udacb\udf6b\uda61\udd6a\ud821\udc53\udb83\udc3a\uda1e\udec6\ud986\udc48\ud9a8\udce0\udb1c\ude0c\ud9cd\udc18\ud99e\udd55\ud966\ude9c\udb58\ude2e\uda55\udd1d", "\u5912\ub6d6\u9ddb\ud059\u5837\u8978", "\u05ba",
        33, 59578, -1483120775, 803991531552892290L, -83850L, false, true, (char) 65348, (char) 63218,
        Double.longBitsToDouble(0x3feb7d16a6c2d5aaL), Double.longBitsToDouble(0x3fc2a1a80030a690L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 15, 1, "\udbcd\udd1c", "\uaaad\u8a20\u180c\u1968\ua4d7\u4a5e\u8bef\u1620\ucca3\uc3f3\u48e8\u8f06", "\ud99e\udd55",
        17, 62720, 1326955467, -7078559435089375636L, -57322L, true, false, (char) 13221, (char) 25181,
        Double.longBitsToDouble(0x3fec6fb7e0e0d9f6L), Double.longBitsToDouble(0x3fd34f051289429cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 5, 1, "\udbcd\udd1c\ud99e\uddbf\ud9f6\uddb0\udb37\uddea\uda33\uddc3\u8215\u40b1\000\uda98\udf8c\uda61\udd6a\ud821\udc53\udb83\udc3a\ud90e\udd3e\u00e4\ud977\udd64\udb1c\ude0c\ud9cd\udc18\ud99e\udd55\ud966\ude9c\udb58\ude2e\ud8c4\udc74", "\000\ub6d6\u9ddb\ud059\u5837\u8978", "\u05ba",
        47, -1000, 0, 792633533488293250L, -83850L, false, true, (char) 65348, (char) 0,
        Double.longBitsToDouble(0x3fe8000006c2d5aaL), Double.longBitsToDouble(0x3fc2a1a80030a690L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 1, 15, "\udbcd\udd1c\ud99e\uddbf\ud9f6\uddb0\udb37\uddea\uda33\uddc3\u8215\udb00\udfe8\udbea\ude3c\udacb\udf6b\uda61\udd6a\ud821\udc53\udb83\udc3a\udbfa\udf95\uda9d\udefd\ud977\udd64\udb1c\ude0c\ud9cd\udc18\ud99e\udd55\ud966\ude9c\udb58\ude2e\ud8c4\udc74", "\u5912\ub6d6\u9ddb\ud059\u5837\u8978", "\u05ba",
        47, 59578, -1483120775, 803991531552892290L, -83850L, false, true, (char) 65348, (char) 63218,
        Double.longBitsToDouble(0x3feb7d16a6c2d5aaL), Double.longBitsToDouble(0x3fc2a1a80030a690L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 10, 4, "\udbcd\udd1c", "\u50b7\u8a20\u180c\u056c\ua4d7\ud25d\u8bef\u1620\u41ca\ud074\u899a\u9f7e\u9b49", "\ud94c\udc2f\udb58\ude2e\ud8c4\udc74\udbe4\udde8\ud9bd\udfbf\uda3d\udf15\udaba\udedc\udb0d\udf2c\ud827\udefe",
        8, 93597, 2130327776, -6823475039464957628L, -36283L, true, true, (char) 4794, (char) 50955,
        Double.longBitsToDouble(0x3fafb7151ea874e0L), Double.longBitsToDouble(0x3feab79fbfcb07cfL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 5, 1, "\014\ud99e\uddbf\ud9f6\uddb0\ud964\udde0\uda33\uddc3\ud8e5\uded7\udaf0\udfe8\udbea\ude3c\udacb\udf6b\uda61\udd6a\ud821\udc53\udb83\udc3a\udbfa\udf95\uda9d\udefd\ud977\udd64\udb1c\ude0c\ud9cd\udc18\ud99e\udd55\ud966\ude9c\uf800\000", "\u5912", "\000\ud85b\ude5d\000\000\000\000\udb51\udcc8",
        54, -879, 0, -2030030097L, 4678L, true, true, (char) 63218, (char) 212,
        Double.longBitsToDouble(0x3fe0000004950d40L), Double.longBitsToDouble(0x3f885349b701e4c0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 1, "\udbcd\udd1c\ud99e\uddbf\ud9f6\uddb0\udb37\uddea\uda33\uddc3\u8215\udb00\udfe8\udbea\ude3c\udacb\udf6b\uda61\udd6a\ud821\udc53\udb83\udc3a\udbfa\udf95\uda9d\udefd\udaf5\udd74\ud8f7\udf5d\ud9cd\udc76\ud99e\udd55\ud966\ude9c\udb58\ude2e\ud8c4\udc74", "\u5912\ub6d6\u9ddb\ud059\u5837\u8978", "\u05ba",
        47, 59578, -1483120775, 803991531552892290L, -83850L, false, true, (char) 65348, (char) 63218,
        Double.longBitsToDouble(0x3feb7d16a6c2d5aaL), Double.longBitsToDouble(0x3fc2a1a80030a690L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 5, 1, "\udbcd\udd1c\ud99e\uddbf\ud9f6\uddb0\udb37\uddea\uda33\uddc3\u8215\udb00\udfe8\udbea\ude3c\udacb\udf6b\uda61\udd6a\ud821\udc53\udb83\udc3a\udbfa\udf95\uda9d\udefd\ud977\udd64\udb1c\ude0c", "\u624f\ucb02\ua188\u4345\u90cc\u5912\ub6d6\u9ddb\ud059", "\ud975\udff3\ud95f\udf9f\u05ba\udb7f\udf2b\udb0c\udc16\ud92c\ude43\ud821\udd6e\uda5d\udf76\ud852\udfd2\udaf5\ude6b\udb3a\udc5b\udab8\ude07\ud949\ude7f\ud90e\udcf0\udbcd\udf89\ud8c5\udf09\uda9e\udfaf\ud8da\udf00\udbff\udf82\ud96a\uddcb\ud946\udc61\ud8c4\udd8a\udac0\udced\ud93c\ude1f\u9e33\ud8ac\udc1d\u0b27\ud817\udf43\ud8ab\udea1\ud88e\ude8e\ud9ae\udf12\uda68\ude76\udbaa\ude98\udaf5\udc9a\uda8b\udf0e\ud9c6\ude4c\uda25\ude4b\ud916\udcbd\udb9b\udcea\ud975\udf3f\ud87b\udde3\ud80f\udf01\ud955\udfd2\ud9fb\udc50\udb23\udd27\ud8bd\uddc7\udb9c\ude52\ud9ef\udd65\ud99d\udddc\ud84e\udf54\ud8ea\udffd\udbe2\udd53\uda2b\udf57\u4f66",
        -1, 93218, 2107196798, -5295710447430977052L, 15611L, true, false, (char) 29071, (char) 29857,
        Double.longBitsToDouble(0x3fe94b1bb6df72ebL), Double.longBitsToDouble(0x3feedc3ef07f63e0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 5, 1, "\udbc8\udeba\ud99e\uddbf\ud9f6\uddb0\udb37\uddea\ud9cf\udd7d\ud859\udeaf\uda53\udd52\udbfb\udf06\udb2d\udd9b\uda41\udf56\ud9f8\udd0c\ud9d4\udc5d\ud844\udfac\uda74\udeb6\ud992\ude0e\uda74\ude25\ud869\udd4f\ud846\ude76\ud866\udfa1\ud97a\udd3e\udb23\udfd0", "\u5912\u7ce1\ucb74\u9342\ub95f\u8978", "\udbc2\udf01",
        53, 60423, -1483120775, -9091824224668269033L, -83850L, false, true, (char) 1093, (char) 63190,
        Double.longBitsToDouble(0x3fd95a2d4b85aa16L), Double.longBitsToDouble(0x3fe5ff72480c29a4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 15, 6, "\udbcd\udd1c\ud99e\uddbf\udaff\udf87\ud9c6\udc84\uda33\uddc3\u8215\udb00\udfe8\uda8b\ude19\udac1\uddd6", "\uc478\ud074\u48e8\ua835\u5214\u8abc\u7fe4\u0a6f\ucb22\ua188\u4345", "\ud9dc\udecd\udb0d\udf2c\uda99\ude73\ud85b\udeff\ud885\udc4f\ud975\udff3\ud95f\udf9f",
        8, 70947, 220629823, -6369955224455992822L, 42467L, false, true, (char) 49799, (char) 52735,
        Double.longBitsToDouble(0x3fefe91b036fa2d4L), Double.longBitsToDouble(0x3fe616ad54950d40L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 7, 2, "\udbcd\udd1c\ud99e\uddbf\ud9f6\uddb0\udb37\uddea\uda33\uddc3\ud971\ude61\udb00\udf6e\udbea\ude3c\udacb\udf6b\uda61\udd6a\ud821\udc53\udb83\udc3a\udbfa\udf95\uda9d\udefd\ud977\udd64\udb1c\udde3\ud9cd\udc18\ud99e\udd55\ud966\ude9c\udbf1\udf41\ud8c4\udc74", "\u5912\ub6d6\u9ddb\u52a6\u5837\u8978", "\u05ba",
        47, 93077, -1488135564, 803991532945401218L, -83850L, false, true, (char) 65348, (char) 63218,
        Double.longBitsToDouble(0x3fe37d16a53cfc4fL), Double.longBitsToDouble(0x3fc2a1a80030a690L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 5, 1, "\udbcd\udd1c\ud99e\uddbf\ud9f6\uddb0\udb37\uddea\uda33\uddc3\u8215\u40b1\000\uda98\udf8c\uda61\udd6a\ud821\udc53\udb83\udc3a\ud90e\udd3e\u00e4\ud977\udd64\udb1c\ude0c\ud9cd\udc18\ud99e\udd55\ud966\ude9c\udb58\ude2e\ud8c4\udc74", "\000\ub6d6\u9ddb\u6389\ua795\u8978", "\u05ba",
        47, -1000, 0, 792633533485388674L, -83850L, false, true, (char) 65348, (char) 0,
        Double.longBitsToDouble(0x3fe8000006c2d5aaL), Double.longBitsToDouble(0x3fc2a1a80030a690L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 5, 1, "\udbc9\udd48\ud99e\uddbf\ud9f6\uddb0", "\u180c\u1968", "\uda61\udcdd\ud821\udc53\udb90\udf17\udbfa\udf95\uda9d\udefd\ud977\udd64\udb34\udcfa\udbe3\udfe6\ud99e\udd55\udbbb\udea8\udab6\ude95\ud8c4\udc77\ud8b6\udd90\udbc4\udc2c\udb65\uddba\ud9dc\udecd\udb0d\udf2c\ud820\udcfb\ud85b\ude98\ud885\udc4f\ud975\udff3\ud95f\udf9f\ud9de\udc46\ud8ee\udf90\uda8b\udfef\ud92c\ude71\ud928\udeb2\udab2\ude3e\ud852\udfd2\ud9e4\udfc4\udb3b\udf8a\udb91\ude14\ud949\ude7f\ud90e\udcf0\udbcd\udf89\ud8c5\udf09\ud990\udd08\ud800\ude9e\udb8a\udc30",
        43, 8644, 1798992018, -3799269186663578337L, -5648L, false, false, (char) 10029, (char) 63092,
        Double.longBitsToDouble(0x3fe49501ae7f8f04L), Double.longBitsToDouble(0x3fe272bd967dcb3cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.NodeUtil|isValidDefineValue|com.google.javascript.rhino.Node,java.util.Set|static",
    "M|com.google.javascript.jscomp.NodeUtil|callHasLocalResult|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|canBeSideEffected|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|canBeSideEffected|com.google.javascript.rhino.Node,java.util.Set|static",
    "M|com.google.javascript.jscomp.NodeUtil|checkForStateChangeHelper|com.google.javascript.rhino.Node,boolean,com.google.javascript.jscomp.AbstractCompiler|static",
    "M|com.google.javascript.jscomp.NodeUtil|constructorCallHasSideEffects|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|constructorCallHasSideEffects|com.google.javascript.rhino.Node,com.google.javascript.jscomp.AbstractCompiler|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsCall|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsFunction|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsType|com.google.javascript.rhino.Node,int|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsType|com.google.javascript.rhino.Node,int,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.NodeUtil|copyNameAnnotations|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|evaluatesToLocalValue|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|evaluatesToLocalValue|com.google.javascript.rhino.Node,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.NodeUtil|functionCallHasSideEffects|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|functionCallHasSideEffects|com.google.javascript.rhino.Node,com.google.javascript.jscomp.AbstractCompiler|static",
    "M|com.google.javascript.jscomp.NodeUtil|isValidDefineValue|com.google.javascript.rhino.Node,java.util.Set|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
