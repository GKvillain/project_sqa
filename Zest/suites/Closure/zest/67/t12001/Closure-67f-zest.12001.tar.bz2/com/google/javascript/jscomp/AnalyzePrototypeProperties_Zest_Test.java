package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class AnalyzePrototypeProperties_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.util.ArrayList:[valueOf, length, toString] |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\0121=com.google.javascript.jscomp.AnalyzePrototypeProperties$NameInfo:\ud85d\ude8f\udb0d\uded5\ud9dd\ude18\ud8d2\ude87\ud8fe\udffb\ud9d5\udf87\udabe\udd0f |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\012",
        Z.run(T, 2, 0, 1, 2, "\ud85d\ude8f\udb0d\uded5\ud9dd\ude18\ud8d2\ude87\ud8fe\udffb\ud9d5\udf87\udabe\udd0f", "\u18d9", "\uda3d\udeed\u7078\ud8f8\udf8e\udb36\udc12\ud904\udd60\ud946\udc5c\uda29\ude35\ud8eb\udff9\ud8b6\udd56\udabd\udfd6\ud9e2\udf51\udb88\udd99\udac9\udcd2\udb10\uded5\ud98a\udc8f\ud903\udd31\uda7b\ude9e\ud96c\udf08\ufc73",
        39, 61829, -2064470882, -1400999697992358843L, 68564L, false, true, (char) 22745, (char) 43984,
        Double.longBitsToDouble(0x3feb4909c48fc4feL), Double.longBitsToDouble(0x3f87fb3afdc26840L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.util.ArrayList:[valueOf, length, toString] |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\0121=com.google.javascript.jscomp.AnalyzePrototypeProperties$NameInfo:\ud85d\ude8f\udb0d\uded5\udabe\uddbe\ud8d2\ude87\ud8fe\udffb\ud9d5\udf87\udabe\udd0f |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\012",
        Z.run(T, 2, 0, 1, 2, "\ud85d\ude8f\udb0d\uded5\udabe\uddbe\ud8d2\ude87\ud8fe\udffb\ud9d5\udf87\udabe\udd0f", "\u8386", "\udb94\udee8\u7078\ud8f8\udf8e\udb35\udfc6\ud904\udd60\ud946\udc5c\uda29\ude35\ud907\udee5\ud8ce\ude2d\ud83c\uded7\ud978\udfc7\udab6\udfb7\ud911\uddb1\udad3\udfc8\ud8ae\udf75\ud903\udcda\uda54\ude4d\uda44\ude89\udbc7\ude48\udae4\udf30\udae7\udeb7",
        18, 94068, -1900246540, 6597125318123159076L, 68564L, false, true, (char) 22745, (char) 43984,
        Double.longBitsToDouble(0x3feb4909c48fc4feL), Double.longBitsToDouble(0x3f87fb3afdc26840L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.AnalyzePrototypeProperties$NameInfo:\ud85d\ude8f\udb0d\uded5\ud9dd\ude18\ud8d2\ude87\ud8fe\udffb\ud9d5\udf87\udabe\udd0f |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\0121=com.google.javascript.jscomp.AnalyzePrototypeProperties$NameInfo:\ud85d\ude8f\udb0d\uded5\ud9dd\ude18\ud8d2\ude87\ud8fe\udffb\ud9d5\udf87\udabe\udd0f |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud85d\ude8f\udb0d\uded5\ud9dd\ude18\ud8d2\ude87\ud8fe\udffb\ud9d5\udf87\udabe\udd0f", "\u18d9", "\uda3d\udeed\u7078\ud8f8\udf8e\udb36\udc12\ud904\udd60\ud946\udc5c\uda29\ude35\ud8eb\udff9\ud8b6\udd56\udabd\udfd6\ud9e2\udf51\udb88\udd99\udaf6\uded2\udb10\uded5\ud98a\udc8f\ud903\udd31\uda7b\ude9e\ud96d\ude48\ud91c\udc3f",
        46, 36432, -2064469661, -1400999697992358843L, 68564L, false, true, (char) 22745, (char) 43984,
        Double.longBitsToDouble(0x3feb4909c4307c20L), Double.longBitsToDouble(0x3f87fb3afdc26840L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.util.ArrayList:[valueOf, length, toString] |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\0121=java.util.ArrayList:[valueOf, length, toString] |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud85d\ude8f", "\ub2ba\u8fdb\u4e33\u4ae2\ud6df\u5b96\u18d9\u4660\uc16c\u78d4\u796c\u883f\u04a8\000\u7cf5\000", "\000\ud9e2\ude9b\udb88\udd99\udac9\udcd2\udb10\uded5\ud98a\udc8f\ud903\udd31\uda7b\ude9e\ud96c\udee5\ufc73\ud9fb\udc3c\udae7\udeb7\uda29\udd5d\uda9f\udd0d\ud8bf\udd98\ud88d\udd65\udb67\udf67\udbd4\uddb2\ud939\udc7d\uda41\udc0c\udaae\ude4f\ud8a5\udff5\udb2d\udcdf\udbf7\udfdb\ud908\udc9c\udb24\udeea\uda3a\udfd4\ud877\udd44\udacc\udef9",
        5, 24378, -944887903, 5218908528125902213L, 74549L, true, true, (char) 27984, (char) 64537,
        Double.longBitsToDouble(0x3fe35933758a3a94L), Double.longBitsToDouble(0x3fdf07f1535f7a3cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\ud85d\ude8f\udb0d\uded5\udb70\udd38\ud8d2\ude87\uda34\udd0f\ud9d5\udf87\udabe\udd0f", "\u18d9\u8d7c\ud7a5", "\ud8f8\udf8e\uda46\udc7a\ud904\udcc0",
        18, 78511, -338874070, 1319326277650014613L, -56897L, true, true, (char) 30523, (char) 12713,
        Double.longBitsToDouble(0x3fe36e1314422ef2L), Double.longBitsToDouble(0x3fa1d02a1a6a9640L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\ud85d\ude8f\uda58\udef9\ud9de\udedf\ud8d2\ude87\ud8fe\udffb\ud9d5\udf87\udabe\udd0f", "\u18d9", "\udb7a\ude8b\udb5c\udfe5\ud83b\udf24\ud971\udd90\ud806\udcd7\ud9e5\uded9\uda29\ude35\ud8eb\udff9\ud8b6\udd56\udabd\udfd6\ud9e2\udf51\udb1f\udd44\ud8cb\udf47\u7f29\uda75\uded7\u2080\uf7ad\ud955\udf92\ufc73",
        39, 61829, -2064470882, -1400999697992358843L, 84183L, false, true, (char) 9922, (char) 43984,
        Double.longBitsToDouble(0x3feb4909c48fc4feL), Double.longBitsToDouble(0x3f87fb3bfdc26840L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.AnalyzePrototypeProperties$NameInfo:\ud85d\ude8f\udb0d\uded5\ud9dd\uddef\ud8d2\ude87\ud8fe\udffb\uda5a\ude2a\ud869\udd63 |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 1, "\ud85d\ude8f\udb0d\uded5\ud9dd\uddef\ud8d2\ude87\ud8fe\udffb\uda5a\ude2a\ud869\udd63", "\u18d9\u8d7c\uc16c\u4250\ud30b\u8b7f\u884c\ua8f8\u88eb\uac48", "\udace\udc31\ud9e2\udeee\uda78\udc11",
        26, 16572, -1738394575, 3383015058773765373L, -38663L, false, true, (char) 56072, (char) 33648,
        Double.longBitsToDouble(0x3fe19c21ec45ec8eL), Double.longBitsToDouble(0x3fe43475e6245b8dL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.util.ArrayList:[valueOf, length, toString] |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\0121=java.util.ArrayList:[valueOf, length, toString] |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud85d\ude8f\udb0d\uded5\ud9dd\ude18\ud8d2\ude87\ud8fe\udffb\ud9d5\udf87\udabe\udd0f", "\u18d9", "\uda3d\udeed",
        34, 32282, 0, 0L, -21878L, false, false, (char) 57827, (char) 7136,
        Double.longBitsToDouble(0x3fed0c9c37912177L), Double.longBitsToDouble(0x3fe7e68b9c31fd77L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.AnalyzePrototypeProperties$NameInfo:\ud85d\ude8f\ud9ed\ude24\udae1\udca1\ud900\udd72\ud945\udd5a\udb62\udc3a\uda0e\udd98\ud859\udfc8\udb14\ude4e\ud893\ude01\ubf68\udb87\udea6\uda3d\udeed |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\0121=com.google.javascript.jscomp.AnalyzePrototypeProperties$NameInfo:\ud85d\ude8f\ud9ed\ude24\udae1\udca1\ud900\udd72\ud945\udd5a\udb62\udc3a\uda0e\udd98\ud859\udfc8\udb14\ude4e\ud893\ude01\ubf68\udb87\udea6\uda3d\udeed |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\012",
        Z.run(T, 2, 1, 1, 2, "\ud85d\ude8f\ud9ed\ude24\udae1\udca1\ud900\udd72\ud945\udd5a\udb62\udc3a\uda0e\udd98\ud859\udfc8\udb14\ude4e\ud893\ude01\ubf68\udb87\udea6\uda3d\udeed", "\uba42\u761b\u9e39\u0b59\u2a63\u3e75\u7efa\u8925\u6b25\uc958\u17c3", "\ud907\udea4\ud96c\udf08\ufc73\udacc\uddb1\uda18\uddd4\ud81e\udd8a\uda9f\udd0d\ud8bf\udd98\ud907\udd13\udb12\udcb1",
        28, 61708, 62115725, -4218934129351661987L, -50616L, false, true, (char) 14965, (char) 63201,
        Double.longBitsToDouble(0x3fd4761d81423218L), Double.longBitsToDouble(0x3fc1de70c922ee00L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.util.ArrayList:[valueOf, length, toString] |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\0121=com.google.javascript.jscomp.AnalyzePrototypeProperties$NameInfo:\ud85d\ude8f\udb0d\uded5\ud9dd\ude18\ud8d2\ude87\ud8fe\udffb\ud9d5\udf87\udabe\udd0f |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\012",
        Z.run(T, 2, 0, 1, 2, "\ud85d\ude8f\udb0d\uded5\ud9dd\ude18\ud8d2\ude87\ud8fe\udffb\ud9d5\udf87\udabe\udd0f", "\u18d9", "\uda3d\udeed\u7078\ud8f8\udf8e\udb36\udc12\ud904\udd60!\uda29\udd6e\ud8eb\udff9\ud8b6\udd56\ud9fe\udd97\ud9b6\udd9b\udb88\udd99\udac9\udcd2\udb10\uded5\ud98a\udc8f\ud903\udd31\uda7b\ude5c\ud96c\udf08\ufc73",
        39, 61829, 15903902, -1400999917035690939L, 68564L, false, true, (char) 22745, (char) 43984,
        Double.longBitsToDouble(0x3feb4909c48fc4feL), Double.longBitsToDouble(0x3f87fb3afdc26840L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.util.ArrayList:[valueOf, length, toString] |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 1, "\ud85d\ude8f\udb0d\uded5\ud9dd\ude18\ud90f\udf05\udb7f\udcb7\udb25\udff5\uda3a\udcfe", "\uace3\u00b8\u8dd0\u05d6\u79fa\u7078", "\ud946\udc5c",
        46, 80930, -1749435070, -5842221412387929283L, 17711L, true, false, (char) 10155, (char) 47502,
        Double.longBitsToDouble(0x3fdf6af0289d8896L), Double.longBitsToDouble(0x3fd23760833dada4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.util.ArrayList:[valueOf, length, toString] |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\0121=com.google.javascript.jscomp.AnalyzePrototypeProperties$NameInfo:\ud85d\udf13\udb0d\uded5\ud9dd\ude18\ud8d2\ude87\ud8fe\udffb\ud9d5\udf87\udabe\udd0f |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\012",
        Z.run(T, 2, 0, 1, 2, "\ud85d\udf13\udb0d\uded5\ud9dd\ude18\ud8d2\ude87\ud8fe\udffb\ud9d5\udf87\udabe\udd0f", "\u18d9", "\uda3d\udeed\u7078\uda02\udc51\udbef\udc21\ud915\udcc9\ud946\udc5c\uda29\ude35\ud8eb\udff9\ud8b6\udd56\udabd\udfd6\ud9e2\udf51\udb88\udd99\udac9\udcd2\udb10\uded5\ud98a\udc8f\ud903\udd31\uda7b\ude9e\ud96c\udf08\ufc73",
        39, 61829, -2064470882, -1400999697992358843L, 68564L, false, true, (char) 22745, (char) 43984,
        Double.longBitsToDouble(0x3feb4909c48fc4feL), Double.longBitsToDouble(0x3f87fb3afdc26840L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.util.ArrayList:[valueOf, length, toString] |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\0121=com.google.javascript.jscomp.AnalyzePrototypeProperties$NameInfo:\ud85d\ude8f\udb0d\uded5\ud9dd\ude18\ud8d2\ude87\ud8fe\udffb\ud9d5\udf87\uff79 |this=com.google.javascript.jscomp.AnalyzePrototypeProperties:@?\012",
        Z.run(T, 2, 0, 1, 1, "\ud85d\ude8f\udb0d\uded5\ud9dd\ude18\ud8d2\ude87\ud8fe\udffb\ud9d5\udf87\uff79", "\u18d9\u8d7c", "\ud9c1\udd89",
        56, 90036, 418592959, 5174411813902887879L, -46818L, true, true, (char) 47398, (char) 43159,
        Double.longBitsToDouble(0x3fb9c85dd42d9398L), Double.longBitsToDouble(0x3fa8febba6dc2620L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.AnalyzePrototypeProperties|getAllNameInfo||new:com.google.javascript.jscomp.AnalyzePrototypeProperties:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.JSModuleGraph,boolean,boolean",
    "M|com.google.javascript.jscomp.AnalyzePrototypeProperties|getNameInfoForName|java.lang.String,com.google.javascript.jscomp.AnalyzePrototypeProperties$SymbolType|new:com.google.javascript.jscomp.AnalyzePrototypeProperties:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.JSModuleGraph,boolean,boolean",
    "M|com.google.javascript.jscomp.AnalyzePrototypeProperties|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.AnalyzePrototypeProperties:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.JSModuleGraph,boolean,boolean",
    "C|com.google.javascript.jscomp.AnalyzePrototypeProperties|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.JSModuleGraph,boolean,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
