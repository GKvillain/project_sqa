package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class ProcessClosurePrimitives_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 11, 6, "\ud9c8\udcc9\udbe4\uddf7\udb1a\udd6a\uda3c\uddc8\ud845\ude06\ud853\udc48\ud8db\udf07\udb5e\udf91\udb2d\uddc2\ud864\udc64\udb3d\udd85\udb14\udd1a\ud970\uded2", "\ubfd6\u477f\ud717\ub48a\ub73f", "\ud929\ude60\ud87a\udef0\uda0f\ude9f\uda6d\ude22\ud914\udc7b\ud8dc\ude98\ud924\udd7f\ud914\uddc4",
        3, 95202, 2111708643, 2768498785121132413L, 91643L, false, true, (char) 55325, (char) 25601,
        Double.longBitsToDouble(0x3fef162e0d3cde79L), Double.longBitsToDouble(0x3fe13df08df7247dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 7, "\udafd\udd7f\udbe4\uddf7\ud9ac\udf75\uda3c\uddc8\ud9fe\udf68\ud9a9\udec2\ud8db\udf8a\uda4b\udda8\udb2d\uddc2\ud864\udc64\udb61\ude2a\udb1d\uddaf\ud970\uded2", "\u1bf9\u477f\ud717\ub48a\u59a3\u9cd5\u2ab5\u2ee1\u3a26\u8780", "\ud8dc\ude98\udbb0\udd85\ud914\uddc4\ud85f\ude79",
        3, 40495, -2095446307, -3088942143084712874L, 41926L, false, false, (char) 25601, (char) 27043,
        Double.longBitsToDouble(0x3fd3cde7944f7ddeL), Double.longBitsToDouble(0x3fdf7247da39006eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 11, 6, "\ud840\udd4c\udbe4\uddf7\udb1a\udd6a\uda3c\uddc8\ud845\ude06\ud853\udc48\ud9e9\uddf5\udb5e\udf99\uda9d\uddb4\ud85b\uddff\udb3d\ude01\udb14\udd1a\ud970\uded2", "\u90c3\u6e9d\ubc7a\u9b9a\u906e", "\ud929\ude60\uda30\udd2b\uda0f\ude9f\uda6d\ude22\ud914\udc7b\ud8dc\ude98\ud965\uded8\ud90c\udfc0",
        3, 82482, 760191425, 5215302062643797885L, 91643L, false, true, (char) 55374, (char) 25601,
        Double.longBitsToDouble(0x3fcc58b824f37938L), Double.longBitsToDouble(0x3fec0a0a19f194bcL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 11, 6, "\ud9c8\udcc9\udbe4\uddf7\udb1a\udd6a\ud97a\udd26", "\u779c\ucac4\u9c1f\ua6ae\u1e6a\u52aa", "\uda0c\udcec\udb3d\ude25\udb0f\udf35\udafc\udcb5\udbbf\udc41\ud8b5\udd36\ud9b8\udd33\udb96\udfc1\ud928\udd95\ud8d8\udeff\uda03\udc84",
        36, 22023, 1001146132, -8199304274995542100L, -61098L, true, true, (char) 11480, (char) 1512,
        Double.longBitsToDouble(0x3fefc0c1f333b68dL), Double.longBitsToDouble(0x3fd9a84d9b8e0b52L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 3, 6, "\ud84d\udf4d\udbe4\uddf7\udb1a\udd6a\uda3c\uddc8\ud845\ude06\ud853\udc48\udac8\udebd\udb8f\udf58\udb2d\uddc2\ud864\udc64\udb3d\udd85\udb14\udd1a\ud970\uded2", "\ubfd6\ud37e\u6504\ub48a\ub73f\u6c3c\u93ad\u7d25\u3a26\ua3d8\u5e25\u9e2d\u75cd\u2957\u01ce\u5120\u5255\ubb10\u4483\u5c39\uc443\u116f\u8846\u02e8\u2e14\u1c26\u0f18\u2567\u22a9\u369b\u1333\u8e0b\u3f51\u262c\ub71a\u82c8\u2a87\u85b3\ub2ae\u5c3f\u0cae\ud77e\u5a6f\u5597\u8d74\u9fce\u32b0\uaca0\u4509\u5e16\ud535\uaf3d\u12f6", "\ud87c\udefa\udb75\ude57\ud987\udc6e\ud8c8\udce7\ud999\udd3f",
        16, 31904, 689981660, -4263816971008506559L, -14438L, true, true, (char) 62789, (char) 49581,
        Double.longBitsToDouble(0x3feca0919e4dc1b4L), Double.longBitsToDouble(0x3fd00f81a5c049d6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 6, "\ud9c8\udcc9\udbe4\uddf7\ud856\udd42\udafb\udffb\udbde\udd52\uda90\ude84\udbe6\ude17\u6449\ud8e8\ude81\ud877\udd93\udb3d\udd85\udb14\udd1a\ud970\uded2", "\u70ec\u9947\u0244\u2b6d\ub73f\u6b8e\u86f0\u2ee1", "\udac6\udc4f\ud98e\udd46\uda22\udc13\udbf4\ude99\ud95c\ude38\uda14\uddf4\uda72\udf80\udb9f\udd4d\uda74\udd3d\udb14\udcea\ue629\ud801\udc23\ud873\udef8\ud9ab\udc35\ud81a\uddf9\ud8b6\udde8\ud971\uded4\ud974\udf59\udbac\udd12\ud973\ude0a\udba0\udec0\ud8a8\udf31\ud817\udcff\uff42\udb67\uded0\ud944\udfd6\ud892\udd01\u7390\udbb7\ude50\u3e15\udbf6\uddbb\udbde\udce0\ud8c6\udc17",
        52, 22663, 1092447702, -5229991174188901434L, 82054L, false, false, (char) 62430, (char) 15063,
        Double.longBitsToDouble(0x3fe7760930580dafL), Double.longBitsToDouble(0x3fc399a04c4a2c60L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 6, "\ud9c8\udcc9\udbfa\ude02\ud874\udfb7\uda3c\uddc8\ud845\ude06\ud853\udc48\ud8db\udf07\udb5e\udf91\udb2d\uddc2\ud864\udc64\udb3d\udd85\udb14\udd1a\ud970\uded2", "\u9e5b\u9b58\ua205\ub48a\ub804", "\ud929\ude60\ud87a\udef0\uda0f\ude9f\uda6d\ude22\ud914\udc7b\ud8dc\ude98\ud924\udd7f\ud914\uddc4",
        3, 95202, 2111708643, 2768498785121132413L, -36383L, true, true, (char) 55325, (char) 25601,
        Double.longBitsToDouble(0x3fef162e0d3cde79L), Double.longBitsToDouble(0x3fe13df08df7247dL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 11, 6, "\ud9c8\udcc9\udbe4\uddf7\udb1a\udd6a\uda3c\uddc8\ud845\ude06\ud853\udc48\ud8db\udf07\udb5e\udf91\udb2d\uddc2\ud864\udc64\udb3d\udd85\udb14\udd1a\ud970\uded2", "\ubfd6\u477f\u0117\ub48a\ub73f", "\ud929\ude60\ud87a\udef0\uda0f\ude9f\uda6d\ude22\ud912\udf7b\udaa7\ude7e\udb7d\udfd1\ud914\uddc4",
        3, 95202, 2111708643, 2768498785121132413L, 91643L, false, true, (char) 55325, (char) 41038,
        Double.longBitsToDouble(0x3fef162cad3cde79L), Double.longBitsToDouble(0x3fe13df08df7247dL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.ProcessClosurePrimitives|getEnclosingDeclNameNode|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.ProcessClosurePrimitives:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.ProcessClosurePrimitives|getExportedVariableNames||new:com.google.javascript.jscomp.ProcessClosurePrimitives:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.ProcessClosurePrimitives|handleCandidateProvideDefinition|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ProcessClosurePrimitives:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.ProcessClosurePrimitives|isNamespacePlaceholder|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.ProcessClosurePrimitives|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ProcessClosurePrimitives:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.ProcessClosurePrimitives|processBaseClassCall|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ProcessClosurePrimitives:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.ProcessClosurePrimitives|processProvideCall|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ProcessClosurePrimitives:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.ProcessClosurePrimitives|processProvideFromPreviousPass|com.google.javascript.jscomp.NodeTraversal,java.lang.String,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ProcessClosurePrimitives:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.ProcessClosurePrimitives|processRequireCall|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ProcessClosurePrimitives:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.ProcessClosurePrimitives|processSetCssNameMapping|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ProcessClosurePrimitives:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.ProcessClosurePrimitives|registerAnyProvidedPrefixes|java.lang.String,com.google.javascript.rhino.Node,com.google.javascript.jscomp.JSModule|new:com.google.javascript.jscomp.ProcessClosurePrimitives:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.ProcessClosurePrimitives|reportBadBaseClassUse|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,java.lang.String|new:com.google.javascript.jscomp.ProcessClosurePrimitives:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.ProcessClosurePrimitives|trySimplifyNewDate|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ProcessClosurePrimitives:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.ProcessClosurePrimitives|verifyArgument|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ProcessClosurePrimitives:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.ProcessClosurePrimitives|verifyArgument|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,int|new:com.google.javascript.jscomp.ProcessClosurePrimitives:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.ProcessClosurePrimitives|verifyProvide|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ProcessClosurePrimitives:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
