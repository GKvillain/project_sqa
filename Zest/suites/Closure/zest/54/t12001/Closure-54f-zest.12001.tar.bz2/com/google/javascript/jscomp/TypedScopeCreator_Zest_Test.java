package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypedScopeCreator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 3, 1, "\udadf\udd87\uda4e\udd50\ud85e\udfb0\udbac\udcb0\udbca\ude80\udb59\udfc1\ud455\uda2c\udc27", "\u737d\ud4cd\u1ea6\u7d05\u11c5\u958f\u0b89\u392d\u36d7", "\udac2\udd04\ud8fe\udfef",
        25, 86171, -222494291, -8723920915427091466L, 33194L, false, false, (char) 1472, (char) 17183,
        Double.longBitsToDouble(0x3fe87cbcc65bf8fcL), Double.longBitsToDouble(0x3fe335606a91ee5eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 3, 1, "\udadf\udd87\uda4e\udd50\ud92d\ude17\uda81\udfd8\udbca\ude80\udb59\udfc1\ud455\uda2c\udc27", "\u737d\ud4cd\u1ea6\u7d05\u11c5\u958f\u0b89\u392d\u36d7", "\udac2\udd04\ud976\uddcc",
        44, 86043, -222494291, -8723920915427091466L, 33194L, false, false, (char) 1472, (char) 47391,
        Double.longBitsToDouble(0x3fec9f153ea06a3cL), Double.longBitsToDouble(0x3fe335606a91ee5eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 7, 7, "", "\u389e\u47cf\u14fe\000\u5aaa\ub0ce\u808e", "\u112b\udbdc\udc0d\udb90\udeda\ud855\udc8a\ud99b\ude82\u107b\uda39\udda3\udadd\udd76\ud916\udec6\ud846\uddb4\udac2\udd04\ud8fe\udfef\ud9a5\uddc0\ud3e3\ud858\uddb8\ud99e\udccf\ud891\udd1a\uf8ef\ud8f3\ude50\ud8f9\ude3d\ud8f8\udeae\udb9e\udebc\ud896\udea5\u5e5b\udbeb\udef5\udbaf\ude3a\udaa2\uddfa\ud8a7\udeb9\udb1e\udc81\u63cf\uda31\udd4b\udaf8\udf51\ud962\udd43\ud8d2\ude89\uda04\udca1\uda2f\udcbb\ud80e\udf2d\ud829\ude14\udb9d\udc92\ud842\udcab\udbed\udff1\udbc2\udd79\uda09\udfd0",
        47, 31596, -2127903151, 5773749734428943872L, -66875L, true, false, (char) 61680, (char) 10698,
        Double.longBitsToDouble(0x3fd7f8bc4cf1802cL), Double.longBitsToDouble(0x3fef7e55864efdf7L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 0, 6, "\ud85a\udde4\uda4e\udd50\ud85e\udfb0\udbac\udcb0\udbca\ude80\udb59\udfc1\ud455\uda2c\udc27", "\u737d\ud4cd\u1ea6\u7d05\u11c5\u945f\u0b89\u392d\u36d7", "\udac2\udd04\uda15\uddfb",
        45, 7211, -222494291, -8723920915427091466L, -61503L, false, false, (char) 15015, (char) 22360,
        Double.longBitsToDouble(0x3fe335606a91ee5eL), Double.longBitsToDouble(0x3fd945fbd4552fa4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 7, 9, "\udb48\udc60\ud988\udcc5\udaee\udefb\udbac\udcb0\udbca\ude80\udb59\udfc1\uf755\uda2c\udc27\ud92c\udcb6\ud894\udd6a\ud9d6\ude55\ud90e\ude30\ud9a0\ude86", "\u958f", "\udadd\udd76",
        5, 70148, 1728251956, 7318646010657393071L, 30643L, false, false, (char) 41700, (char) 63210,
        Double.longBitsToDouble(0x3fedb69cb82c4949L), Double.longBitsToDouble(0x3fa19b458e4e7630L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 3, 1, "\ud816\ude95\uda35\uddde\ud85e\udfb0\udbac\udcb0\udbca\ude80\udb59\udfc1\ud455\uda2c\udc27", "\u73fe", "\udab6\udce6\ud8c8\uddd6\uce95\ud801\uddd9\uda39\ude4c\udadd\udd76\ud916\udec6\ud846\uddb4\udac2\udd04\ud8fe\udfef\ud979\udec1\uda1c\udc16\ud8af\udda4\ud9d4\udd6f\udb2d\udf49\udb75\udc52\ud8f3\ude50\ud8f9\ude3d\ud8f8\udeae\uda1c\udfdb\ud8a1\ude21\ud9be\udeef",
        51, 61648, -218932483, 8188463054413277653L, 8734L, false, true, (char) 59590, (char) 49435,
        Double.longBitsToDouble(0x3fdd0b9ccf903fb0L), Double.longBitsToDouble(0x3fe55fbe09b80070L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 5, 15, "\udb78\udd32\udb9f\udf9a\udac4\udfb6\udbac\udcb0\udbca\ude80\ud90e\udffc\ud9f6\ude70\uda86\uddf7\udaee\udcce\uda98\udd99\ud9d6\ude55\ud90e\ude30", "\u11c5\u958f\u3c6c\ub5f1\u28d0\u2d08\u2406\u050e\u8653\uafaf\u977d\u78c6\u45f7", "\udb04\ude90\udb09\udd37\ud97f\udf4d\ue014\ud896\udea5\ud9c2\udc2f\u0d5c\uda13\udc4b\uda55\ude74\ud904\uddbb\ud9d6\udc1c\ud8c2\udf88\udbaa\udf93\udaff\udc48\udbfb\udc31\ud8fe\udcdf\udb2d\udc67\ud810\udfee\ud991\udfc3\udb4f\udd62\uda55\uddbd\udb4f\udf98\ud3c2\ud8b6\udd0f\uda68\ude73\udb4b\ude81\uda84\udfcc\ud9cb\udde3\udb5a\udcf3\uda1c\udeb9\ud8ec\udd63",
        29, 88467, 316725232, 5157781543391290350L, -15976L, false, true, (char) 65090, (char) 40607,
        Double.longBitsToDouble(0x3fd84fc0aa7fe26eL), Double.longBitsToDouble(0x3fd2b4dcd3d0b5e8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 3, 1, "\udadf\udd87\ud950\udd51\ud85e\udfb0\udbac\udcb0\udbca\ude80\udb59\udfc1\ud455\uda2c\udc27", "\u737d\ud4cd\u1ea6\u7d05\u11c5\u958f\u0b89\u392d\u36d7", "\ud886\ude0b\udbc2\udc82",
        25, 86101, -222494291, -8723920915427091466L, 33194L, false, false, (char) 1472, (char) 17183,
        Double.longBitsToDouble(0x3fe87cbcc65bf8fcL), Double.longBitsToDouble(0x3fe335606a91ee5eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.rhino.jstype.FunctionType|setPrototype|com.google.javascript.rhino.jstype.PrototypeObjectType|new:com.google.javascript.rhino.jstype.FunctionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.Node",
    "M|com.google.javascript.rhino.jstype.FunctionType|setPrototypeBasedOn|com.google.javascript.rhino.jstype.ObjectType|new:com.google.javascript.rhino.jstype.FunctionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.TypedScopeCreator|createInitialScope|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypedScopeCreator:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.TypedScopeCreator|createScope|com.google.javascript.rhino.Node,com.google.javascript.jscomp.Scope|new:com.google.javascript.jscomp.TypedScopeCreator:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.TypedScopeCreator|declareNativeFunctionType|com.google.javascript.jscomp.Scope,com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.TypedScopeCreator:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.TypedScopeCreator|declareNativeType|com.google.javascript.jscomp.Scope,java.lang.String,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypedScopeCreator:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.TypedScopeCreator|declareNativeValueType|com.google.javascript.jscomp.Scope,java.lang.String,com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.TypedScopeCreator:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.TypedScopeCreator|getNativeType|com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.TypedScopeCreator:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.TypedScopeCreator|patchGlobalScope|com.google.javascript.jscomp.Scope,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypedScopeCreator:com.google.javascript.jscomp.AbstractCompiler",
    "C|com.google.javascript.jscomp.TypedScopeCreator|<init>|com.google.javascript.jscomp.AbstractCompiler",
    "C|com.google.javascript.jscomp.TypedScopeCreator|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CodingConvention",
    "M|com.google.javascript.rhino.jstype.FunctionType|addRelatedExtendedInterfaces|com.google.javascript.rhino.jstype.ObjectType,java.util.Set|new:com.google.javascript.rhino.jstype.FunctionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.Node",
    "M|com.google.javascript.rhino.jstype.FunctionType|addRelatedInterfaces|com.google.javascript.rhino.jstype.ObjectType,java.util.Set|new:com.google.javascript.rhino.jstype.FunctionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.Node",
    "M|com.google.javascript.rhino.jstype.FunctionType|addSubType|com.google.javascript.rhino.jstype.FunctionType|new:com.google.javascript.rhino.jstype.FunctionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.Node",
    "M|com.google.javascript.rhino.jstype.FunctionType|appendVarArgsString|java.lang.StringBuilder,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.rhino.jstype.FunctionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.Node",
    "M|com.google.javascript.rhino.jstype.FunctionType|canBeCalled||new:com.google.javascript.rhino.jstype.FunctionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.Node",
    "M|com.google.javascript.rhino.jstype.FunctionType|setPrototype|com.google.javascript.rhino.jstype.PrototypeObjectType|new:com.google.javascript.rhino.jstype.FunctionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.Node",
    "M|com.google.javascript.rhino.jstype.FunctionType|setPrototypeBasedOn|com.google.javascript.rhino.jstype.ObjectType|new:com.google.javascript.rhino.jstype.FunctionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.Node",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
