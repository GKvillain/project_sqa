package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class DisambiguateProperties_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.DisambiguateProperties$Property:@? |this=com.google.javascript.jscomp.DisambiguateProperties:@?\012",
        Z.run(T, 1, 4, 3, 6, "\ud9a3\udd75\udac2\ude96\uda29\udd8a\ud839\udc6e\uda3c\udc28\ud834\udff0\ud937\udd0e\ud851\udcc6\udbdb\udee6\ud810\udf95\uda91\udcd0\uda24\udd90\udb04\udeb5", "\u7f61\ubae7\u7b41\u62f5\u4deb", "\u458c\udb44\udeb8\udbd6\udd05\ud86f\udf0c\ud89a\udf52\udaeb\udd32\udabc\uded2\u5660\ud973\udfb7\ubc8b",
        3, 37158, -1618052209, 6572808399103162663L, -27836L, true, true, (char) 58164, (char) 54163,
        Double.longBitsToDouble(0x3fe7c0f4cd3fff66L), Double.longBitsToDouble(0x3fe6321502d21439L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.DisambiguateProperties$Property:@? |this=com.google.javascript.jscomp.DisambiguateProperties:@?\012",
        Z.run(T, 1, 4, 3, 6, "\ud9a3\udd75\ud82e\udd4b\uda29\udd8a\ud839\udc6e\uda3c\udc28\ud834\udff0\ud937\udd0e\ud851\udcc6\udbdb\udee6\ud810\udf95\uda91\udcd0\uda24\udd90\udb04\udeb5", "\u7f61\uba65\u7b41\u62f5\u4deb", "\udb73\udf0f\udb44\udeb8\udbd6\udd05\ud86f\udf0c\ud89a\udf52\udaeb\udd32\udabc\uded2\u5660\ud973\udfb7\ubc8b",
        3, 37158, -1618052209, 6572808399103162663L, -27836L, true, true, (char) 58164, (char) 54163,
        Double.longBitsToDouble(0x3fcf03d339422f90L), Double.longBitsToDouble(0x3fe636e7d2d21439L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.DisambiguateProperties$Property:@? |this=com.google.javascript.jscomp.DisambiguateProperties:@?\012",
        Z.run(T, 1, 4, 3, 6, "\ud9a3\udd75\udac2\ude96\uda29\udd8a\ud839\udc6e\uda3c\udc28\uda07\ude1a\udb3b\ude55\ud851\udcc6\udbdb\udee6\ud810\udf95\uda91\udcd0\uda24\udd90\udb04\udeb5", "\u7f61\ubae7\u7b41\u62f5\u871a", "\u458c\udb44\udeb8\udbd6\udd05\ud86f\udf0c\ud89a\udf52\udaeb\udd32\udabc\uded2\u5660\ud973\udfb7\ubc8b\ud9ba\udd0b\ud85a\ude6f\udbff\udddf\ud856\udfca\uda74\udfd1\ud9e0\ude8e\udb15\udc13\ud84e\udd76\udac1\udfe1\udae0\udcce\ud812\udd07\uda86\udf8d\udbb9\udeee\ud882\udd2c\ud852\udff7\ud93c\udf55\udadc\ude32\uda96\udc4a\udb3b\ude0b\ud9dd\udcab\ud93a\uddf4\udada\udea3\udbec\udff2\ud817\udc62\ud86c\uddaa\ud8c0\udd9b",
        28, 7565, -1908132043, 1945443224042209232L, 32203L, false, false, (char) 42917, (char) 56896,
        Double.longBitsToDouble(0x3fe51f8452c62e25L), Double.longBitsToDouble(0x3fc6b2bedf8bff58L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 3, 6, "\ud9a3\udd75\udac2\ude96\ud95d\udc01\ue771\uda3c\udc28\ud834\udff0\ud937\udd0e\udad6\udc69\udbdb\udee6\ud810\udf95\uda91\udcd0\uda24\udd90\udb04\udeb5", "\ub401\u2e4f\u659e\u6312\u4deb", "\u458c\udb44\udeb8\udbd6\udd05\ud929\uddc9\ud89a\udf37",
        38, 95207, -1825546340, -8585832601147790855L, -40582L, true, true, (char) 60920, (char) 54366,
        Double.longBitsToDouble(0x3fcfa5a7f44579f0L), Double.longBitsToDouble(0x3fe21f79bae4364bL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 0, 6, "\ud9a3\udd75\ud9c0\ude95\uda29\udd8a\ud839\udc6e\uda3c\udc28\ud834\udff0\ud937\udd0e\ud851\udcc6\udbdb\udee6\ud810\udf95\uda91\udcd0\uda24\udd90\udb04\udeb5", "\u7f61\ubae7\000\u622c\u4deb", "\u458c\udb44\udeb8\ud9fc\udcde\ud86f\udf0c\udad2\udf4e\udaeb\udd32\udabc\uded2\000\000\u9292",
        3, 37158, -1618052209, 6572808399103162663L, -34236L, true, true, (char) 58164, (char) 10900,
        Double.longBitsToDouble(0x3fe7c0f0053fff66L), Double.longBitsToDouble(0x3fe6321502d21439L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 5, 4, "\ud94d\udd2b\udb0c\udc9e\uda1d\udf25\u3cfd\uda3c\udcdc\ud835\udc12\udbde\udfd7\u226d\ud897\udf0f\uda41\udf34\uda91\udcd0\uda24\udd90\udb9c\udcc4", "\u7b5c\u1ba5\u7b72\u62f5\u4deb\u161d\ud647\uaac6\u5bdf\u1bb2\u5dd4\uc736\ud319\u8207\ucc2a\u268e\u2f5a\u9d96\u22e5", "\uda74\udfd1\ud9e0\ude8e\ud810\ude35\ud9a3\udfb4\udb10\udc18\udae0\udd70\ud812\udd07\uda86\udf8d\udb3d\uddcf\uda88\udc89\ud852\udfa4\ud8ec\udfcd\udad6\uddf9\uda0f\udf55\udbd5\udcc1\ud9be\udd8f\uda99\udffa\uda3c\ude0f\ud9f9\udfb2\udb40\udfbd\ud936\udc0b",
        20, 11305, -1036204925, -1356203599051981593L, 8965L, true, true, (char) 45249, (char) 22790,
        Double.longBitsToDouble(0x3fe2afb4a55a89d3L), Double.longBitsToDouble(0x3feafd1fe2639f48L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 6, "\ud9a3\udd75\udac2\ude96\uda29\udd8a\ud839\udc6e\uda3c\udc28\ud834\udff0\ud937\udd0e\ud851\udcc6\udbdb\udee6\ud810\udf95\uda91\udcd0\uda24\udd90\udb04\udeb5", "\u7f61\ubae7\u7b41\u62f5\u4deb", "\u458c\udb44\udeb8\udbd6\udd05\ud86f\udf0c\ud89a\udf52\udaeb\udd32\udabc\uded2\u5660\ud973\udfb7\ubc8b",
        3, 37158, -1618052209, 6572808399103162663L, -27836L, true, true, (char) 58164, (char) 54163,
        Double.longBitsToDouble(0x3fe7c0f4cd3fff66L), Double.longBitsToDouble(0x3fe6321502d21439L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DisambiguateProperties:@?\012",
        Z.run(T, 1, 9, 3, 6, "\ud9a3\udd75\udac2\ude96\uda29\udd8a\ud839\udc6e\uda3c\udc28\udb62\ude67\ud937\udd0e\ud851\udcc6\ud9d2\udf0a\udbf7\udca4\udb1b\udf50\uda42\udc41\udb04\udeb5", "\ud08f\u7b92\u6b76\u62f5\u2b71", "\ud800\udd4f\udb44\udeb8\udbd6\udd05\ud86f\udf0c\ud89a\udf52\udaeb\udd32\udabc\uded2\u5660\ud973\udfb7\uda29\udc07\ud9ba\udda6\ud85a\ude6f\udbec\udd72",
        40, 17503, 1585245437, -1209430830791027133L, 44551L, false, false, (char) 54163, (char) 19857,
        Double.longBitsToDouble(0x3fd3fff6658c8540L), Double.longBitsToDouble(0x3fe950924fbc5358L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 7, 6, "\ud957\udf92\udac2\ude96\uda29\udd8a\ud839\udc6e\uda3c\udc28\ud834\udff0\ud937\udd0e\ud851\udcc6\udbdb\udee6\ud810\udf95\uda22\uddda\udaaf\udd6c\udbbe\udebe", "\u1845\u05cb\u6b4e\u275f\u4deb\ud4ed\ud647\uaac6\u68df\ub172\ua8e7\u6e7f\u03b1", "\ud973\udfb7\ubc8b\ud806\udd11\ud85a\ude6f\udbff\udddf\ud856\udfca\uda74\udfd1\ud9e0\ude8e\udb15\udc13\ud84e\udd76\udac1\udfe1\udae0\udcce\ud874\udd19\uda86\udf8d\udbb9\udeee\ud882\udd2c\ud852\udff7",
        29, 52989, -1641159155, 8181417597214521663L, -60662L, true, true, (char) 20714, (char) 30692,
        Double.longBitsToDouble(0x3fe33e95445c85dfL), Double.longBitsToDouble(0x3fe57f8a9eed734eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.DisambiguateProperties$Property:@? |this=com.google.javascript.jscomp.DisambiguateProperties:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 6, "\ud9a3\udd75\udac2\ude96\uda29\udd8a\ud96a\ude27\ud9ab\udc3b\ud839\udd95\ud937\udd0e\ud851\udcc6\udbdb\udee6\ud810\udf95\uda91\udcd0\uda24\udd90\udb04\udeb5", "\u7f61\ubae7\u7b41\u62f5\u4deb", "\udb13\udd27\udb44\udeb8\udbd6\udd05\ud86f\udf0c\ud89a\udf52\udaeb\udd32\udae7\udc70\ud944\udc30\ud973\udfb7\ubc8b",
        3, 37158, -1014072433, 6572889689949174055L, -27838L, true, true, (char) 58164, (char) 54163,
        Double.longBitsToDouble(0x3fe7c0f4cfc8c7d5L), Double.longBitsToDouble(0x3fe63211bad21439L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.DisambiguateProperties$Property:@? |this=com.google.javascript.jscomp.DisambiguateProperties:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 2, "\ud86b\uddac\udb42\udd5e\ud8af\udfd2\ud839\udc6e\uda3c\udc28\ud834\udff0\ud937\udd0e\ud851\udcc6\udb2d\udedd\ud810\udf95\uda91\udcd0\udb61\ude30\udb04\ude12", "\u7f61\ubae7\u7b41\u62f5\u4deb", "\udad0\udf92\ud9cb\udf64\udbe0\udd44\ud86f\udf0c\ud89a\udf52\udaeb\udd32\udabc\uded2\u5660\ud973\udfb7\ubc8b",
        3, 37028, -1618052209, 6572808905909303591L, 11346L, false, false, (char) 29391, (char) 37981,
        Double.longBitsToDouble(0x3fe6321502d21439L), Double.longBitsToDouble(0x3fe8748fb6ec176fL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.google.common.collect.HashMultimap:{} |this=com.google.javascript.jscomp.DisambiguateProperties:@?\012",
        Z.run(T, 1, 5, 9, 6, "\ud9a3\udd75\udac2\ude96\uda29\udd8a\ud839\udc6e\uda3c\udc28\ud834\udff0\ud937\udd0e\ud851\udcc6\udbdb\udee6\ud810\udf95\uda91\udcd0\uda24\udd90\udb04\udeb5", "\u7f61\ubae7\u7b41\u62f5\u4deb", "\u458c\udb44\udeb8\udbd6\udd05\ud86f\udf0c\ud89a\udf52\udaeb\udd32\udabc\uded2\u5660\ud973\udfb7\ubc8b",
        3, 37158, -1618052209, 6572808399103162663L, -27836L, true, false, (char) 19462, (char) 54163,
        Double.longBitsToDouble(0x3fe7c0f4cd3fff66L), Double.longBitsToDouble(0x3fe6321502d21439L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DisambiguateProperties:@?\0121=com.google.javascript.jscomp.DisambiguateProperties$Property:@? |this=com.google.javascript.jscomp.DisambiguateProperties:@?\012",
        Z.run(T, 2, 9, 4, 6, "\ud9a3\udd75\udac2\ude96\uda29\udd8a\udb57\udc5c\uda3c\udc6f\uda49\ude7c\ud937\udd0e\ud851\udcc6\udbdb\udee6\ud810\udf95\ud832\udfc1\ud920\uddc5\udb04\udeb5", "\u7f61\ubae7\u7b41\u62f5\u4deb", "\u458c\ud95e\udde6\udbd6\uddd3\ud86f\udf0c\ud89a\udf52\udaeb\udd32\udabc\uded2\u5660\ud973\udfb7\ubc8b",
        31, 60646, -1618064753, 6572808399103162663L, -27836L, true, true, (char) 58164, (char) 54163,
        Double.longBitsToDouble(0x3fe7c0f4cd3fff66L), Double.longBitsToDouble(0x3fe6321502d21439L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.google.common.collect.HashMultimap:{} |this=com.google.javascript.jscomp.DisambiguateProperties:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 3, "\ud9a3\uddce\udac2\ude96\udb44\uddb8\udaf3\udfe0\ud8fd\udcfe\udb33\udf09\ud83e\udee5\ud814\ude88\udbdb\udee6\ud810\udf95\uda91\udcd0\uda24\udd90\udb04\udeb5", "\u7f61\ubae7\u7b41\u6005\u3cfd", "\uda7b\udfc0\udac5\udebc\udbd6\udd05\ud93b\ude53\ud896\udedc\udb26\ude32\udabc\uded2\u5660\ud96d\uddb7\ubc8b\ud4e5\ud867\udec2\udbff\udddf\uda25\udfd3\udb67\udf6b\udb8b\udfdd\udb17\udd26\ud84e\udd76\ud849\uded5\udae0\udcce",
        46, 2944, -10080520, 4782170487540792006L, 25469L, false, true, (char) 55040, (char) 27348,
        Double.longBitsToDouble(0x3fefe216fb8294c5L), Double.longBitsToDouble(0x3fe82730fc4d9debL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.DisambiguateProperties$Property:@? |this=com.google.javascript.jscomp.DisambiguateProperties:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 8, "\ud9a3\udd75\udac2\ude96\uda29\udd8a", "\u3529", "\udbdb\udee6\ud810\udf95\uda91\udcd0\uda24\udd90\udb04\udeb5\uda60\udfdb\uda0e\ude3a",
        14, 77197, -950655382, 8096625271155846742L, -12862L, false, false, (char) 8662, (char) 29742,
        Double.longBitsToDouble(0x3fedf0f9dedf186bL), Double.longBitsToDouble(0x3fc8b769e724e9f8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.DisambiguateProperties:@?\0121=void |this=com.google.javascript.jscomp.DisambiguateProperties:@?\012",
        Z.run(T, 2, 9, 9, 4, "\udb77\udd39", "\u70a6\u3add\u1aa1\u9ca1\u00d5\u3e66\u28ee\u47e3\u484e\u1dd9\ud1af\u9f5b\ua47e", "\ud881\udc68",
        22, 50186, -1487213274, 1061283413632288364L, 70160L, false, true, (char) 8156, (char) 59694,
        Double.longBitsToDouble(0x3fc8b774435783c4L), Double.longBitsToDouble(0x3fe14c81e40cb9b7L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.DisambiguateProperties$Property:@? |this=com.google.javascript.jscomp.DisambiguateProperties:@?\0121=void |this=com.google.javascript.jscomp.DisambiguateProperties:@?\012",
        Z.run(T, 2, 4, 9, 6, "\ud983\ude00\udac2\ude96\ud8e1\ude87\ud96a\ude27\ud9ab\udc3b\ud975\ude88\ud937\udd0e\ud851\udcc6\udbdb\udec6\ud810\udf95\uda91\udcd0\ud97f\udc7e\uda96\udc6c\uda60\udfdb\uda0e\ude3a\ud8c8\udf99\ud93e\udebd\ud85c\udf13\ud881\udc68\ud830\udc7b\ud833\udc04\ud9dc\udc30\uda68\uddd6\udb44\udeb7\udbd6\udd05\ud86f\udf0c\ud885\udc52\udb32\uddd6\udaf4\udf40\ud944\udc30\udaff\udfa6\ubc8b\ud97a\udd0b\ud85a\ude6f\ud83f\udfff\ud869\uddb9\uda74\udfd1", "\ube9c\u9b7b\u6927\ub023\u6e04\u31e2\ub13f\u92be\uba4a\u1490", "\ud93d\udcbd",
        54, 11775, -2020180574, 4827833466691470950L, -78581L, false, true, (char) 49463, (char) 62435,
        Double.longBitsToDouble(0x3fe3a88e7d992ea4L), Double.longBitsToDouble(0x3fe524cff400f5ddL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.google.common.collect.HashMultimap:{} |this=com.google.javascript.jscomp.DisambiguateProperties:@?\0121=com.google.javascript.jscomp.DisambiguateProperties$Property:@? |this=com.google.javascript.jscomp.DisambiguateProperties:@?\012",
        Z.run(T, 2, 5, 4, 2, "\uda54\udc2c\udac2\udf5b\uda55\udd8a\u3578\ud965\udea3\ud9d9\udee1\ud96e\ude89\ud851\udcc6\udbdb\udee6\ud810\udff3\uda91\udcd0\uda24\udd90\udabe\udeb2", "\u4928\ubb0e\u1110\u1cdb\u3f15\ud4ed", "\ud8d5\udec2",
        29, -679, -1280748421, 1780333230470683881L, 96931L, true, true, (char) 59331, (char) 58171,
        Double.longBitsToDouble(0x3fec79583859c38eL), Double.longBitsToDouble(0x3fc42086f3f4b4fcL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.DisambiguateProperties$Property:@? |this=com.google.javascript.jscomp.DisambiguateProperties:@?\0121=com.google.common.collect.HashMultimap:{} |this=com.google.javascript.jscomp.DisambiguateProperties:@?\012",
        Z.run(T, 2, 4, 5, 8, "\ud9a3\udd75\udac2\ude96\uda29\udd8a\ud96a\ude27\ud9ab\udc3b", "\u07a5\ud672\ubeba\u0f16", "\uda60\udfdb\uda0e\ude3a\ud8c8\udf99\ud93e\udebd\ud85c\udf13\ud881\udc68\ud830\udc7b\udb60\ude7b\ud9f0\ude4b\udb13\udd27\udb44\udeb8\udbd6\udd05\ud86f\udf0c\ud89a\udf52\udaeb\udd32",
        29, 29823, -1999044931, 3142995738491206694L, 62703L, true, false, (char) 54366, (char) 21052,
        Double.longBitsToDouble(0x3f91577668799560L), Double.longBitsToDouble(0x3fee8e7cf3f36cf7L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.DisambiguateProperties$Property:@? |this=com.google.javascript.jscomp.DisambiguateProperties:@?\0121=com.google.javascript.jscomp.DisambiguateProperties$Property:@? |this=com.google.javascript.jscomp.DisambiguateProperties:@?\012",
        Z.run(T, 2, 4, 4, 4, "\ud9a3\udd75\udac2\ude96\uda29\udd8a\ud96a\ude27\ud9ab\udc3b\ud839\udd95\ud937\udd0e\ud851\udcc6\udbdb\udee6\ud810\udf95\udab8\uddd0\uda24\udd90\udb04\udeb5", "\u7f61\ubae7\u7b41\u62f5\u4deb", "\udb13\udd27\udb44\udeb8\ud842\ude66\ud86f\udf3b\udabb\ude62\ud8e2\udcdd\ub570\ud92c\udccb\ud973\udf26\ubc8b",
        3, 45534, -1014072433, 6572889689952115751L, -27838L, true, true, (char) 58164, (char) 54163,
        Double.longBitsToDouble(0x3fe7c0f4cfc8c7d5L), Double.longBitsToDouble(0x3fe63211bad21439L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.google.common.collect.HashMultimap:{} |this=com.google.javascript.jscomp.DisambiguateProperties:@?\0121=com.google.common.collect.HashMultimap:{} |this=com.google.javascript.jscomp.DisambiguateProperties:@?\012",
        Z.run(T, 2, 5, 5, 6, "\ud9a3\udd75\udac2\ude96\uda29\udd8a\udb57\udc5c\uda3c\udc6f\uda49\ude7c\ud937\udd0e\ud848\uddc6\udbdb\udee6\udbe3\udf94\ud832\udfc1\ud920\uddc5\udb04\udeb5", "\u7edc\ubae7\u7b41\u62f5\u4deb\ud4ed", "\ud948\uddb9\udbd6\udda0\udaee\udef4\udbab\udf83\udaa0\udf5d\udaae\udcf7\u5660\ud973\udfb7\ubc8b\ud878\udc69\ud871\ude2f\udbf3\udcdf\ud856\udfca\udb74\udf71\udaf3\ude79\ud9ca\udd5d\ud956\udead\udac1\udfe1\udae0\udcce\ud812\udd07\uda86\udf8d\udbb9\udeee\ud882\udd2c\ud830\udcf7\ud8e1\ude47\ud814\udcc8\udaad\udee3\ud9b0\udfc2\ud90a\udc13\ud9c3\udd9c\udbbf\uddff\ud9b9\ude52\udaf4\udfec\udb8e\udc5a\ud806\udff9\ud854\udf41\ud823\ude56\ud876\ude03\ud90c\udc39\udbeb\udd85\ud9d9\udd6d\ud895\udf52\udb4f\udf50\udace\udee0\udad1\udcae\udb34\udf63\ud81d\udd95\ud858\uddcd\udabb\ude3f\udbbd\udf75\uda5d\udd9a\uda77\udf0d\ud961\udc9b\ud959\ude16\ud8e8\udcd6\uda9b\ude0c\udbd4\ude27\ud85e\ude36\ud9b8\ude71\udbdb\udcab\ud94f\udc64\udb0d\ude33\ud8ab\udc2f\udb8b\udfbb\udaf7\ude2c\ud80f\udf47\udbb7\udca0\udb53\udeb2\udab1\ude2b\ud99d\udc47\ud8ee\udfe5\ud856\uded3\udac0\ude3c\ud893\udcae\udb48\udeab",
        6, 10939, 1456604237, 3554399182663944184L, 34259L, true, false, (char) 52834, (char) 42238,
        Double.longBitsToDouble(0x3febe447a83ae206L), Double.longBitsToDouble(0x3fa51a93026adec0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.DisambiguateProperties$Property:@? |this=com.google.javascript.jscomp.DisambiguateProperties:@?\0121=com.google.javascript.jscomp.DisambiguateProperties$Property:@? |this=com.google.javascript.jscomp.DisambiguateProperties:@?\012",
        Z.run(T, 2, 4, 4, 8, "\ud9a3\udd75\udac2\ude96\uda3b\udf8a\uda41\udc72\uda3c\udc6e\uda07\ude1a\ud8c0\uded0\udbac\udf8d\ud9af\udc18\ud867\udc4b\uda43\udeb9\ud9f1\udd7a\udb04\udeb5\udaca\udc28\uda3b\ude76\ud8c8\udf99\uda39\udcfe\ud88e\udc48\ud881\udc68\ud8c4\udef9\uda95\uddb3\ud8f9\udd94\u458c\ud8d5\udf42\udb92\udfac\uda8c\udc7b\ud89a\udf01\uda10\ude0c\udabc\ude37\ud9c8\udc37\ud81f\udd5b\u442d\ud8dc\udf11\ud8d4\uddb1\udafb\udf9e\udb87\udd33\udbc4\udf91", "\u574a\u8173\u468f", "\uda2b\udd7e",
        -2, 50314, -569497057, -725507641937730993L, 97198L, false, true, (char) 30820, (char) 22526,
        Double.longBitsToDouble(0x3fd706288b919f30L), Double.longBitsToDouble(0x3fe4f4c633e83f68L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.DisambiguateProperties$Property:@? |this=com.google.javascript.jscomp.DisambiguateProperties:@?\012",
        Z.run(T, 1, 4, 3, 6, "\ud9a3\udd75\udac2\ude96\uda29\udd8a", "\u1a7f", "\ud92c\ude8e\ud9f8\udf5c",
        26, 66728, 1983249588, -3080295032838810538L, 59693L, false, false, (char) 50463, (char) 64177,
        Double.longBitsToDouble(0x3fcd4d08a0997a08L), Double.longBitsToDouble(0x3fe6189564622f42L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.DisambiguateProperties|addInvalidatingType|com.google.javascript.rhino.jstype.JSType,com.google.javascript.jscomp.JSError|new:com.google.javascript.jscomp.DisambiguateProperties:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.DisambiguateProperties$TypeSystem,java.util.Map",
    "M|com.google.javascript.jscomp.DisambiguateProperties|buildPropNames|com.google.javascript.jscomp.graph.UnionFind,java.lang.String|new:com.google.javascript.jscomp.DisambiguateProperties:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.DisambiguateProperties$TypeSystem,java.util.Map",
    "M|com.google.javascript.jscomp.DisambiguateProperties|forConcreteTypeSystem|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.TightenTypes,java.util.Map|static",
    "M|com.google.javascript.jscomp.DisambiguateProperties|forJSTypeSystem|com.google.javascript.jscomp.AbstractCompiler,java.util.Map|static",
    "M|com.google.javascript.jscomp.DisambiguateProperties|getProperty|java.lang.String|new:com.google.javascript.jscomp.DisambiguateProperties:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.DisambiguateProperties$TypeSystem,java.util.Map",
    "M|com.google.javascript.jscomp.DisambiguateProperties|getRenamedTypesForTesting||new:com.google.javascript.jscomp.DisambiguateProperties:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.DisambiguateProperties$TypeSystem,java.util.Map",
    "M|com.google.javascript.jscomp.DisambiguateProperties|getTypeWithProperty|java.lang.String,java.lang.Object|new:com.google.javascript.jscomp.DisambiguateProperties:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.DisambiguateProperties$TypeSystem,java.util.Map",
    "M|com.google.javascript.jscomp.DisambiguateProperties|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.DisambiguateProperties:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.DisambiguateProperties$TypeSystem,java.util.Map",
    "M|com.google.javascript.jscomp.DisambiguateProperties|recordInvalidationError|com.google.javascript.rhino.jstype.JSType,com.google.javascript.jscomp.JSError|new:com.google.javascript.jscomp.DisambiguateProperties:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.DisambiguateProperties$TypeSystem,java.util.Map",
    "M|com.google.javascript.jscomp.DisambiguateProperties|renameProperties||new:com.google.javascript.jscomp.DisambiguateProperties:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.DisambiguateProperties$TypeSystem,java.util.Map",
    "C|com.google.javascript.jscomp.DisambiguateProperties|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.DisambiguateProperties$TypeSystem,java.util.Map",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
