package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class Compiler_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 13, 6, "\ud926\ude69", "\ua9ff", "\ud9be\uddf3\ud9e4\udfad\uda5b\udf62\udb14\udf12\ud972\udfa8\uda5b\udf0e\ud987\udd4a\uda18\udf3b\ud9cd\udf25\udbc6\ude7b",
        32, 14980, 1485426708, 42455536391546899L, -94697L, true, false, (char) 19650, (char) 47210,
        Double.longBitsToDouble(0x3fe3284fa36fcf1eL), Double.longBitsToDouble(0x3fcf8472f5d0daccL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 13, 6, "\ud925\udf64", "\ua9ff", "\ud9be\uddf3\udaaa\ude70\uda5b\udf62\udb14\udf12\ud972\udfa8\uda5b\udf0e\ud987\udd4a\uda18\udf3b\ud9cd\udf25\udbbb\udea4",
        49, 14980, 1485426708, 42320296461330451L, -98273L, false, false, (char) 19650, (char) 47210,
        Double.longBitsToDouble(0x3fe3284fa36fcf1eL), Double.longBitsToDouble(0x3fcf9a12f5d0daccL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 13, 6, "\ud926\ude69", "\ua9ff", "\ud9be\uddf3\ud9e4\udfad\ud90e\udf1c\udb14\udfb2\ud972\udfa8\uda5b\udf0e\ud987\udd4a\uda18\udf3b\ud9cd\udf25\udbc6\ude7b",
        32, 14980, 1485426708, 42455536391546899L, -94697L, true, false, (char) 19650, (char) 47210,
        Double.longBitsToDouble(0x3fe3284fa680cf1eL), Double.longBitsToDouble(0x3fcf933675d0daccL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 6, "\ud926\ude69", "\u2417", "\ud9be\uddf3\ud9e4\udfad\uda3b\udd52\udb22\udf79\ud989\udf72\uda5b\udf0e\ud9a1\udc48\uda18\udf3b\ud9cd\udf25\uda6b\ude2e\uea02\u251b\udad9\udf60\ud8b4\udc95",
        8, 91620, -1851564726, -7911519987522946418L, 37829L, true, true, (char) 51346, (char) 60454,
        Double.longBitsToDouble(0x3fa96defba075f00L), Double.longBitsToDouble(0x3fe2c471cf3afdf3L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 13, 6, "\ud813\ude7e\udba3\udc99\ud80b\uddac\ud957\udcb9\uda71\ude65\ud893\udc3c", "\uafca\u28f6\u3162\u2a73\u09bf", "\udbc6\ude7b\u95c6\udab4\udd51",
        -2, 86950, -581048301, -2423248373057590455L, 69852L, false, false, (char) 10479, (char) 61360,
        Double.longBitsToDouble(0x3fecb65e9d2dbb68L), Double.longBitsToDouble(0x3fda14a4c4f1b6acL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 13, 6, "\ud926\ude69", "\u5159\ucb58\ua0f0\u292c\uc392\uafca\u28f6\u079b\u8c31\u8c38\u9dc2\u6da3\u95a2\ucea1\u5730\u9103\ua5c8", "\udb2f\udcc3",
        -1, 14718, 167031329, -3522348836865983633L, 13503L, false, true, (char) 2538, (char) 33468,
        Double.longBitsToDouble(0x3fef6d8e8661f40fL), Double.longBitsToDouble(0x3febd2830f7b58f3L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 13, 6, "\ud926\ude69", "\ua9ff", "\ud9be\uddf3\u33a2\uda5b\udf62\udb14\udf12\ud972\udfa8\uda5b\udf0e\ud987\udd4a\uda18\udf3b\ud9cd\udf25\udbc6\ude7b",
        32, 42148, 0, -581048301L, -94697L, true, false, (char) 19650, (char) 47210,
        Double.longBitsToDouble(0x3fe3284fa36fcf1eL), Double.longBitsToDouble(0x3fcf8472f5d0daccL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 11, 3, 6, "\ud926\ude69", "\u38cb\u9c80\ua0f0", "\uda5b\udf62\udb14\udf12\ud9b0\udfa7\uda5b\udf0e\ud987\udd4a\uda18\udf3b\ud9cd\udf25\udbc6\ude7b\ue9c6\ud960\udd46\udac1\udd50\udb87\udd8b\ud9e5\ude08\uda82\ude76\udb2f\udcc3",
        -1, 14718, 167031329, -3522348836865983633L, -97612L, true, false, (char) 54507, (char) 48599,
        Double.longBitsToDouble(0x3fe9528e544d792dL), Double.longBitsToDouble(0x3fd08fc1515e2642L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 13, 6, "\ud853\uddde", "\u677e\ub6c5\ua0f0", "\ud938\udc90\ud80f\ude22\uda32\uddaa\uda5a\uddc8\ud987\udd4a\ud970\udf47\ud9cd\udf25\udbc6\ude7b\ue9c6\ud960\udd46\ud9ce\udf1a\udb6c\udd26\ud8c3\udef0\uda81\udd69\ud9c1\udccc",
        -1, 14718, -676373724, -3522377845082776721L, 11988L, true, false, (char) 62869, (char) 2658,
        Double.longBitsToDouble(0x3fd45e5c72762fdeL), Double.longBitsToDouble(0x3fd2544ec74a8ac2L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\012",
        Z.run(T, 1, 3, 12, 13, "\ud926\ude69", "\ua9ff", "\ud9be\uddf3\udbc7\udd00\uda5b\udf55\udb14\udf12\ud972\udfa8\uda5b\udf0e\ud987\udd4a\uda18\udf3b\ud9cd\udf25\udbc6\ude7b",
        32, 14980, 1485426708, 42455536391546899L, -94697L, true, false, (char) 19650, (char) 47365,
        Double.longBitsToDouble(0x3fe3284fa36f26e2L), Double.longBitsToDouble(0x3fcf8472f5d0daccL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 10, 7, "\ud926\ude69", "\ua9d1\u03c2\ua14b\u292c\u83a6\uce4f\u28f6\ua51e\u8c31\u6348\ubb1d\u9a0d\u1a7b\ub7d8\ud493\u4662", "\uda82\ude76\ud8ee\ude70",
        11, 73159, -536247597, -5226529974618406651L, -96087L, true, true, (char) 62504, (char) 60566,
        Double.longBitsToDouble(0x3fc0ebd9c52e3ddcL), Double.longBitsToDouble(0x3fe3507e98e98faaL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 13, 6, "\ud926\ude69", "\ua9ff\ucb58\ua0f0\u292c\uc392\uafca\u28f6", "\ud987\udd4a\uda18\udf3b\ud9cd\udf25\udbc6\ude7b\ue9c6\ud960\udd46\ud86d\ude6f\ud984\udcfe",
        29, 79522, -1856246967, -7911519987522946418L, 37829L, true, true, (char) 62866, (char) 22235,
        Double.longBitsToDouble(0x3fe08742fb7a7298L), Double.longBitsToDouble(0x3fbf60e5c17d9360L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 13, 6, "\ud926\ude69", "\ua9ff", "\ud9be\uddf3\ud9e4\udfad\uda5b\udf62\udb14\udf12\ud972\udfa8\uda5b\udf0e\ud987\udd4a\uda18\udf3b\ud9cd\udf25\udbc6\ude7b",
        32, 14980, 1485426708, -2047214690708360971L, 39025L, true, false, (char) 19650, (char) 47210,
        Double.longBitsToDouble(0x3fe32c7e14f3cf1eL), Double.longBitsToDouble(0x3f9a5691ae86d660L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 2, 6, "\ud926\ude69", "\ua9ff", "\ud9be\uddf3\ud9e4\udfad\uda5b\udf62\udb14\udf12\ud972\udfa8\uda5b\udf0e\udb05\ude0a\uda18\udea4\ud9cd\udf25\ud9af\udc23",
        54, 993, 1485398804, 42358782069434387L, 34329L, true, false, (char) 35279, (char) 56591,
        Double.longBitsToDouble(0x3f9f85f492891ac0L), Double.longBitsToDouble(0x3fcf8472e1d0daccL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 6, "\ud926\ude69", "\ua9ff", "\ud9be\uddf3\ud9e4\udfad\uda2b\ude35\udb14\udf12\ud972\udfa8\uda5b\udf0e\ud987\udd4a\uda18\udf3b\ud9cd\udf25\udbc6\udf44",
        32, 14980, 1485426708, 42455536391546899L, -94697L, true, false, (char) 19650, (char) 18019,
        Double.longBitsToDouble(0x3fe3284acb6fcf1eL), Double.longBitsToDouble(0x3fcf8472f5d0daccL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 10, 6, "\ud921\udfec", "\ua9ff", "\ud9be\uddf3\ud861\udeec\ud967\udcf5\ud974\udfe1\ud9e1\udd76\ud934\uddab\ud898\udd38\uda9e\udd95\udbc9\udc67\udbb0\udcd2",
        32, 16915, 1485395495, 4870314336932689322L, -94782L, true, false, (char) 19650, (char) 47210,
        Double.longBitsToDouble(0x3fe32e1ccd10da1eL), Double.longBitsToDouble(0x3fc81151d5d0daccL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 11, 10, "\uda22\udf87", "\ua9ff\ucb58", "\ud810\udfa3\uda5b\udf62\udb14\udf12\ud972\udfa8\uda5b\udf0e\ud874\udeb9\uda73\udf03\udbfb\udcc1\udbc6\ude7b",
        32, 85908, -462130109, 4658592431655148986L, -94697L, true, false, (char) 19650, (char) 255,
        Double.longBitsToDouble(0x3fe3284fa36fcf72L), Double.longBitsToDouble(0x3fcf8472f5d0daccL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 13, 6, "\ud926\ude69", "\ua9ff\ucb58\ua0f0\u292c\u558b\ubd3e\uac76", "\ud987\udd4a",
        12, 68992, 2072815894, 3381850385719928972L, 85622L, true, false, (char) 32536, (char) 51623,
        Double.longBitsToDouble(0x3fe3ec8adc8e9234L), Double.longBitsToDouble(0x3fcec679e9942520L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 13, 6, "\udbe3\udfe7", "\uc089", "\ud9be\uddf3\ud9e4\udfad\uda5b\udf62\udb14\udf12\ud972\udfa8\uda5b\udf0e\ud805\udd77\ud997\udf71\ud9cd\udf25\ud981\udf3a",
        18, 14980, 1485426708, 42455536391546899L, -94697L, true, false, (char) 19650, (char) 12139,
        Double.longBitsToDouble(0x3fe3284fa36fcf1eL), Double.longBitsToDouble(0x3fcf8472f5d0daccL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=void |this=com.google.javascript.jscomp.Compiler:@?\012",
        Z.run(T, 2, 7, 7, 6, "\ud926\ude69", "\ua9ff", "\ud9be\uddf3\ud9e4\udfad\uda5b\udf62\udb14\udf12\ud972\udfa8\uda5b\udf0e\ud987\udd4a\udaba\udd1a\ud8d8\udeac\uda2d\udc9d",
        32, 14980, 1485426708, 5284645505328606577L, -94697L, true, false, (char) 19650, (char) 47210,
        Double.longBitsToDouble(0x3fe3284fa36fcf1eL), Double.longBitsToDouble(0x3fdfc2397e3a3824L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 6, "\ud926\ude69", "\ua9ff", "\ud9be\uddf3\udb68\udc70\uda5b\udf62\ud88d\udcd2\ud986\udd09\uda5b\udf0e\ud987\udd4a\uda18\udf3b\ud9cd\udf25\udbc6\ude7b",
        32, 14980, 1485426708, 42455536391546899L, -94697L, true, false, (char) 19650, (char) 47210,
        Double.longBitsToDouble(0x3fe3284fa36fcf1eL), Double.longBitsToDouble(0x3fcf8472f5d0daccL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 15, 6, "\udaeb\udeb9", "\uaafe", "\ud823\udf58\ud88d\udc18\ud852\udfac\ud849\udfdc\udbf5\udf61",
        16, 62020, -62468093, -5440191001392237229L, 27604L, false, true, (char) 17006, (char) 59560,
        Double.longBitsToDouble(0x3fd5cdd247fb4bc8L), Double.longBitsToDouble(0x3fe3ec8ada8e9234L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 6, "\ud926\ude69", "\u2417", "\ud9be\uddf3\ud9e4\udfad\uda3b\udd52\udb22\udf79\ud989\udf72\uda5b\udf0e\ud9a1\udc48\udbbc\udc29\uda15\udea7\uda6b\ude2e\uea02\u251b\ud87c\uddf2\ud98a\udfba",
        4, 91620, -960015798, -7911426331466089842L, 37829L, false, true, (char) 7448, (char) 24329,
        Double.longBitsToDouble(0x3fa94bcc3a075f00L), Double.longBitsToDouble(0x3fe2c471cf3afdf3L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 14, 6, "\ud926\ude69", "\u2417", "\ud9c4\udc26\ud9e4\udfad\uda3b\udd52\udb22\udf79\ud989\udf72\uda5b\udf0e\ud9a1\udc48\uda18\udf3b\ud8d2\udce4\uda6b\ude0e\uea02\u251b\udad9\udf60\ud8b4\udc95",
        8, 91620, 876895562, -7920363758977107314L, 37829L, true, true, (char) 51346, (char) 60454,
        Double.longBitsToDouble(0x3fe996defb2a9097L), Double.longBitsToDouble(0x3fe2c471cf3afdf3L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 0, "\udbe3\udda4\udb96\udcc5\ud80b\uddac\ud86a\udda2\uda71\ude85\ud893\udc3c", "\uafca\u28f6\u3528\u239c\u09bf\u710b\u67a3", "\udab4\udd51\ud8da\udc62",
        36, 24828, 1060404952, -7972726722331909418L, -42813L, true, false, (char) 54080, (char) 39726,
        Double.longBitsToDouble(0x3fe0a21d593041c5L), Double.longBitsToDouble(0x3fd1e8e992b3738cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 3, 11, 10, "\udb38\udcb1\uda00\udf00\ud80b\uddbd\ud957\udcb9\uda71\ude65\uda55\udf3d\ud9be\uddf3\ud916\udce7\uda27\udd41", "\ub1d2\u09bf\ubd2c", "\uea03\ua88c\000\000\ud9e5\ude08\uda82\ude76\udb2f\udcc3\uda37\udc04\udbac\udeec",
        44, 78237, -243370310, 1449132535036596817L, -75753L, true, false, (char) 64483, (char) 27805,
        Double.longBitsToDouble(0x3fe7c4e336c99bdaL), Double.longBitsToDouble(0x3fd43ca7c4d9f5c8L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=void |this=com.google.javascript.jscomp.Compiler:@?\012",
        Z.run(T, 2, 3, 3, 6, "\ud926\ude69", "\u38cb\ud6e1\ua0f0", "\uda5b\uded1\udb14\udf12\ud9d8\udc9f\uda5b\udf0e\ud987\udd4a\uda18\udf3b\ud9b9\udc70\udbc6\ude7b\ue9c6\ud960\udd46\ud8fd\udf45\udb87\udd8b\ud9e5\ude08\uda82\ude76\udb2f\udcc3",
        14, 98533, 167031329, -3522348838949994385L, -97612L, true, false, (char) 54507, (char) 48629,
        Double.longBitsToDouble(0x3fe9528e544d792dL), Double.longBitsToDouble(0x3fd08fc1515e2642L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 9, 8, "\ud853\uddde", "\u2d87\ucb5f\ua0f0\u292c\u80e7\u0f80\ubf72\u1701\u6f84\u3a85\u35f2\u2ed7\u5399\ucf28\u2dca\u3ba2\u3417\u2d4f\u57b2\u48d5\u52e2\u0852\u2c1c\u11d9\u78f6\u2dd1\u5c38\u56db\u6988", "\udba7\udfab\ud9ce\udfa3\ud819\udc79\uda0a\udd09\udab9\udda6",
        23, 55880, -1583852231, -5011388834282709137L, -85343L, true, true, (char) 64117, (char) 37893,
        Double.longBitsToDouble(0x3fec4fe4d96078f5L), Double.longBitsToDouble(0x3fd00a2218dce948L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 12, 13, "\ud926\ude69", "\ua9ff", "\ud9be\uddf3\udbc7\udd00\uda5b\udf55\udb14\udf12\ud972\udfa8\uda5b\udf0e\ud987\udd4a\uda18\udf3b\ud9cd\udf25\ud83f\ude7d",
        32, 14980, 1485426708, 42455536391546899L, -78835L, true, false, (char) 19650, (char) 47365,
        Double.longBitsToDouble(0x3fe3284fa02d7ae2L), Double.longBitsToDouble(0x3fea28313d824a52L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 15, 6, "\ud926\ude69", "\uc1e6", "\ud9f7\udef0\u1760\uda00\ude0d\ud904\ude28\ud972\udfa8\uda5b\udf0e\udb05\ude0a\uc330\ud9cd\udf25\ud9af\udc23",
        51, 993, 1485398804, 42358782069434387L, 34329L, true, false, (char) 35279, (char) 56591,
        Double.longBitsToDouble(0x3f9f85f492891ac0L), Double.longBitsToDouble(0x3fcf8472e1d0daccL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 14, 6, "\ud926\ude69\uda00\udf00\ud80b\uddbd\ud8cb\uddd3\uda89\udd2a\ud963\udca4\ud9c4\udc26\ud9e4\udfad\uda3b\udd52\udb22\udf79\ud989\udf72\uda5b\udf0e\ud9a1\udc48\uda18\udf3b\ud8d2\udce4\uda6b\ude0e\uea02\u251b\udad9\udf60\ud8b4\udc95", "\u6b3c\u9cd9\u0a03\u9ded\u6075\u3d9e\u2dd1\ubaa2\uab26\u6451\u0bf3\u6c5d\u0ca3\u92b7", "\udb54\udc42\ud83a\udf83\udb97\udfb8\ud902\udf7d\ud90e\udec7\ud8dc\udf5e\ud8bc\udf86\ud9d4\udd88\ud95a\udfa6\udbef\udf0d\udb85\udff5\uda4c\uddfe\udb5a\udec6\ud9bf\uddb5\uda0f\udf88\udbe7\udcb7\ud881\udf64\udbed\udec6\udae2\udf7e\uda97\udca3\ud99a\udeac\ud8d0\ude37\ud8e2\udf5c\uda09\udec3\ud906\ude68\ud88c\udc8e\udbc4\udeed\ud90f\udd99\ud86d\udef8\ud996\udd0e\uda65\udf52",
        47, 77383, 766169695, 5956335446115228360L, -83844L, true, true, (char) 64920, (char) 63533,
        Double.longBitsToDouble(0x3fe1377cf7457b59L), Double.longBitsToDouble(0x3fc5370c58361b3cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 6, "\ud926\ude69", "\ua9ff", "\ud9be\uddf3\uda0d\udf91\uda5b\udf62\udb14\udf12\ud972\udfa8\uda5b\udf0e\udade\udc1f\uda14\udcc0\ud9cd\udf25\udbc6\ude7b",
        32, 14980, 1485426708, 42455536139888659L, -94697L, true, false, (char) 19650, (char) 47210,
        Double.longBitsToDouble(0x3fe3284fa36fcf1eL), Double.longBitsToDouble(0x3fcf8472f5d0daccL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.Compiler:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 3, 11, 10, "\udb38\udcb1", "\ua965", "\ud9be\uddf3\ud804\udcde\uda27\udd41\udb14\udf12\ud9b0\udf68\udac9\ude5c\ud9b2\udc41\ud8c4\udfb0\ud9aa\ude60\ud8a7\udd68",
        28, 46169, -83886080, -5179282173562541559L, -94697L, true, false, (char) 19650, (char) 47210,
        Double.longBitsToDouble(0x3fe7b04fa6bae0f7L), Double.longBitsToDouble(0x3fe2ef8bf62cb046L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.Compiler|parseInputs||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|acceptConstKeyword||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|acceptEcmaScript5||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|addChangeHandler|com.google.javascript.jscomp.CodeChangeHandler|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|addIncrementalSourceAst|com.google.javascript.jscomp.JsAst|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|addNewScript|com.google.javascript.jscomp.JsAst|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|addNewSourceAst|com.google.javascript.jscomp.JsAst|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|addToDebugLog|java.lang.String|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|areNodesEqualForInlining|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|buildKnownSymbolTable||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|check||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|checkFirstModule|java.util.List|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile||new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile|com.google.javascript.jscomp.JSSourceFile,[Lcom.google.javascript.jscomp.JSModule;,com.google.javascript.jscomp.CompilerOptions|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile|[Lcom.google.javascript.jscomp.JSSourceFile;,[Lcom.google.javascript.jscomp.JSModule;,com.google.javascript.jscomp.CompilerOptions|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|compile|[Lcom.google.javascript.jscomp.JSSourceFile;,[Lcom.google.javascript.jscomp.JSSourceFile;,com.google.javascript.jscomp.CompilerOptions|new:com.google.javascript.jscomp.Compiler:",
    "M|com.google.javascript.jscomp.Compiler|parseInputs||new:com.google.javascript.jscomp.Compiler:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
