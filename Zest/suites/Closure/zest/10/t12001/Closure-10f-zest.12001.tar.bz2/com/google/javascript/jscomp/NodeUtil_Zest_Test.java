package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class NodeUtil_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 11, 9, "\uda3b\udf8f\u4851\ud915\udeda\ud9bc\udca1\udaa2\udf35\ud84a\udd20\u4e75\uda02\udd16\udb22\udc7d\udab9\udd36\udb76\udd64\ud8df\ude64\u643e\ud8b2\udc5f\ud977\ude28\ud984\udf2c", "\u53f9\u0c5b\u2261\u0b8f\ua960\u010a\u28c7\uc80f", "\udbc9\udefd\ud8b5\udfc2\uda10\ude65\udaab\udd4b",
        5, 47844, 1160061316, 5632750257137051057L, 56508L, false, true, (char) 30180, (char) 50362,
        Double.longBitsToDouble(0x3f7df284f56eb900L), Double.longBitsToDouble(0x3fe89b1c2e5bbb6cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 11, 9, "\uda3b\udf8f\u4851\ud915\udeda\ud9bc\udca1\udaa2\udf35\ud84a\udd20\u4e75\uda02\udd16\udb22\udc7d\udab9\udd36\udb76\udd64\ud8df\ude64\u643e\ud8a0\udd19\ud977\uddeb\ud984\udf2c", "\u53f9\u0c5b\u2261\u0b8f\ua960\u010a\u28c7\u8d56", "\udbc9\udefd\ud834\udc01\udb2a\udc04\udaab\udd4b\udb66\ude1b\ud944\udcdf\ud871\udd97\ud91c\udd1f\ud889\udc58\udaa0\udec0\ud9be\ude96",
        2, 99504, -2083392513, 6924738129348372466L, 35066L, true, false, (char) 18269, (char) 36504,
        Double.longBitsToDouble(0x3fe2dddb6337b6dbL), Double.longBitsToDouble(0x3fe3f37f2a61751eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 14, 11, "\uda22\uddc1\udb11\uddd9\ud915\udec9\ud9bc\udca1\udaa2\udf35\udba8\udf57\ud967\udd03\udb9d\uddba\u61e2\uda02\ude50\uda99\udeee\ud9f0\udd16\ud984\udfba\ud8d0\uddc0\ud8ac\udf56\ueb3a", "\u5fde\u2ac6\u2261\u0b8f\ua960\ub638\u5dda\uabce\u02de\uc1c6\u9514\u771d\u0424\u28bd\ua8b7\u6077\u7da6\u4ad3\uaaf1\u8ad9\ua00b\u1a1a\u66a1\u30d1\u1efe\u3fdf\u2188\u9093\u4a42\ud7e7\u2eca\u3908\ubb74\u01cf\u6e58\uaf68\u729d\u5e14\u5f87\u8f4e\u0b7d\u0bec\u0e9b\u8cf1\u3d77\u2204", "\ud838\udcb4\udab6\udef3\ud8b5\ude29\uef96\udbf2\ude09\ud82b\udfda\udb16\udc3c\ud9ac\ude67\udae9\udc95\udbdf\udd86\ud8d1\udd5f\ud9c8\ude7c\ud975\udd15\ud8d3\udeba",
        28, 76793, -578835784, 8965800496086859071L, -60919L, true, false, (char) 21358, (char) 22808,
        Double.longBitsToDouble(0x3faf29ecb7cd11c0L), Double.longBitsToDouble(0x3fe18a9ed9c1f1bfL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 11, 9, "\uda3b\udf8f\u4851\ud915\udeda\ud9bc\udca1\udaa2\udf35\ud84a\udd20\u4e75\uda02\udd16\udb22\udc7d\udab9\udd36\udb76\udd64\ud8df\ude64\u643e\ud8b2\udc5f\ud977\ude28\ud984\udf2c", "\u53f9\u0c5b\u2261\u0b8f\ua960\u010a\u28c7\uc80f", "\udbc9\udefd\ud8b5\udfc2\ud9e1\udc9e\udaab\udd82",
        5, 47844, 1680482692, 5632750257137051057L, 56508L, false, true, (char) 30180, (char) 50362,
        Double.longBitsToDouble(0x3f7df284f56eb900L), Double.longBitsToDouble(0x3fe89b1c2e5bbb6cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 12, 9, "\uda3b\udf8f\u4851\ud915\udeda\ud9bc\udca1\udaa2\udf35\ud84a\udd20\u4e75\uda02\udd16\udb22\udc7d\udab9\udd36\udb76\udd64\ud8df\ude64\u643e\ud8b2\udc5f\ud977\ude28\ud984\udf2c", "\u53f9", "\uda50\udd48\udb79\udd7b\ud89c\udcbf\uda60\ude39\u4c2d\u34c6\udaa0\ude8b\udbc9\udefd\ud8b5\udfc2\uda10\ude65\udaab\udd4b\udb66\ude1b\udbb4\udcd7\ud871\udd97\u8c84\ud889\udc58\udaa0\udec0\ud9be\ude96",
        2, 99504, 255, 6924565901159802866L, 35066L, true, false, (char) 18269, (char) 36504,
        Double.longBitsToDouble(0x3fe2dddb63ce8642L), Double.longBitsToDouble(0x3feb487e7c412b87L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 8, 10, "\uda3b\udf7f\ud9d3\udef1\ud915\udeda\ud9bc\udca1\udbf0\udebc\ud84a\udd20\udb2d\udda1\ud9ce\ude21\ud8bf\udde4\ud9b0\udf92\uda40\udd29\ud8df\udd9c\u643e\udbc6\udc69\ud967\udc53\udbe9\ude3a\udae9\udd3e\udbe1\udfaf\u4a78\ud826\udf22", "\ua960\u010a\u28c7\ub0fe\u1691\u4030\ud029\u16c1\u78e1\ud3fb\u0a78\u4793\u13cf\u26e5\u9e7d\u61ab\ua539\u52b0\u5fc7", "\uda3b\ude7b\ud843\udf20\udb87\ude3b\udabd\ude86\udaa4\udf2e\uc53c\udab9\udc7a\udace\udc76\ud9d9\udc37\ud800\udf99\u0790\ud829\udf35\uda90\ude51\ud87b\udfe2\uda00\ude42\uda41\uded5\udad9\ude3b\ud972\udd6b\uda39\ude01\ud85a\uddb1\ud86b\udde2\ud947\udd98\udb5e\udd1c\uda17\uddce\ud8b9\udd30\udafa\ude85\uda0e\udca6\ud934\udf6f\ud801\udc7a\ud956\udd1f",
        54, 5864, 570563057, 8041893128606809116L, 50725L, true, true, (char) 20327, (char) 54840,
        Double.longBitsToDouble(0x3fe9cf4df40cd6beL), Double.longBitsToDouble(0x3feee288546082e9L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 11, 9, "\uda3b\udf8f\u4851\ud915\udeda\ud9bc\udca1\udaa2\udf35\ud84a\udd20\u4e75\uda02\udd16\udb95\udcf7\udaa6\udd3f\udb99\udc74\ud8df\ude64\u643e\ud8b2\udc5f\ud977\ude28\ud984\udf2c", "\u53f9\u0c5b\u2261\u0b8f\ua960\u010a\u28c7\uc80f", "\udbc9\udefd\ud8b5\udfc2\uda10\ude65\udaab\udd4b",
        5, 47844, 1160061316, 5632750257137051057L, 56508L, false, true, (char) 30180, (char) 50362,
        Double.longBitsToDouble(0x3f7f0e84c0f04d00L), Double.longBitsToDouble(0x3fe89b1c2e5bbb6cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 7, "\uda3b\udf8f\u4851\ud915\udeda\ud87c\udc78\udb97\ude8f\ud9da\ude98\u4e75\uda3e\udd14\ud908\udea1\uda58\udff5\uda39\udcc4\udaf9\udc12\uda90\udeb8\ud8b2\udc5f\ud977\ude28\ud984\udf2c\udac1\udcbf", "\u322c", "\udb79\udd7b\ud89c\udcbf\ud8d0\ude31\uda71\ude5b\udb3a\udf22\uc3b3\ud8c2\udc38\ud8b5\udfc2\uda10\ude65\uda30\udfd4\udb4e\udfad\ud8f4\udc1f\ud86c\udff9\ud91c\udd1f\ud889\udc58\uda18\uddfc\ud83d\ude5c\ud91a\uded1\uda80\udec8\ud9fd\udce7",
        37, 50210, -733172205, 2783770363982694879L, -88959L, true, false, (char) 6287, (char) 50830,
        Double.longBitsToDouble(0x3fe791bfa4b0bea8L), Double.longBitsToDouble(0x3f96c9ea40474500L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 13, 9, "\uda3b\udf8f\u4851\ud915\udeda\ud9bc\udca1\udaa2\udf35\ud84a\udd20\u4e75\uda02\udd16\udb22\udc7d\udab9\udd36\udb6a\ude4c\ud8df\ude64\u643e\ud8b2\udc5f\ud977\ude28\ud984\udf2c", "\u53f9\u0c5b\u2261\u0b8f\ua960\u010a\u28c7\uc80f", "\udbc9\udefd\ud8b5\udfc2\uda10\ude65\udaab\udd4b",
        5, 47844, 1160061316, 5632750257137051057L, 56508L, false, true, (char) 30180, (char) 50362,
        Double.longBitsToDouble(0x3f7df284f56eb900L), Double.longBitsToDouble(0x3fe89b1c2e5bbb6cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 11, 9, "\uda3b\udf8f\udbf5\udc50\ud915\udeda\ud9bc\udca1\udaa2\udf35\ud84a\udd20\uda88\udcee\uda02\udcd5\udad8\udd57\uda81\uddaa\udb76\udd64\ud8df\ude64\u643e\ud8b2\udc5f\ud977\ude28\ud984\udf2c", "\u53f9\u0c5b\uc336\u4def\ua929\u010a\u28c7\uc80f", "\udbc9\udefd\ud8b5\udfc2\uda10\ude65\udaab\udd4b",
        5, 47844, 1166937476, 5632750257137051057L, 56508L, true, false, (char) 30180, (char) 50362,
        Double.longBitsToDouble(0x3f7df284f56eb900L), Double.longBitsToDouble(0x3fe89b1c2e5bbb6cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 14, 7, "\uda3b\udf8f\ud91f\udc52\udb3d\udece\udac0\udd4d\uda84\udec6\ud8e2\udd28\u4ec5\ud94d\udc33\udb22\udc7d\udab9\udd36\udb76\udd64\ud934\udd5e\udaff\udc10\ud8b2\udc70\ud977\ude28\ud984\udf2c\udac1\udcbf\udbe1\udfaf\ud868\udd02\uda86\udffa\ud858\uddf8\uda50\udd48\uda82\ude7e\ud89c\udcbf\uda60\ude39", "\u872d\ud029\u81dc", "\udb57\udc1b\ud944\udcdf\ud871\udd97\ud91c\udd1f\ud889\udc58\udaa0\udec0",
        36, 24345, -1228280084, -8948103737246153413L, -98583L, false, false, (char) 168, (char) 18269,
        Double.longBitsToDouble(0x3fe89b1c2e5bbb6cL), Double.longBitsToDouble(0x3fd6444fea5b8e2cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 11, 9, "\ud8c7\udd1e\uda1d\udca0\ud87c\udd4c\udbb4\udc6a\udb04\udd3c\udbad\udeeb\u4a72\ud862\udfde\udbae\udfc2\ud8e2\udc1b\ud802\udf16\ud926\ude3d\u643e\ud8b2\udc5f\ud977\ude28\ud984\udf2c", "\u5448\u0c5b\u2261\u0b8f\ua960\u5708\u2fcd\u6d70", "\udbc9\udefd\ud8b5\udfc2\uda1e\udeab\uda3a\udf2a",
        31, 85747, 70209615, 5632598299197629873L, -60216L, false, false, (char) 38952, (char) 2059,
        Double.longBitsToDouble(0x3febde534866d454L), Double.longBitsToDouble(0x3f7df284f56eb900L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:FALSE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 9, "\ud8cb\udc62", "\uac5f\u37d5\u79c3", "\ud835\ude26\udb0e\udc97",
        16, 82998, 2119898862, -1921981326549581451L, -47270L, false, true, (char) 62019, (char) 194,
        Double.longBitsToDouble(0x3fb191d769e0e630L), Double.longBitsToDouble(0x3fe5099ded62caa2L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:FALSE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 9, 3, "\uda3b\udf8f\u4851\ud915\udeda\ud9bc\udca1\udaa2\udf35\uda53\ude8b\udb8c\udfa6\uda02\udce7\udb22\udc7d\udab9\udd36\udb76\udd64\ud8df\ude64\u643e\ud8b2\udc5f\ud864\ude3d\ud8ee\udd15", "\u9a44\u0c5b\u2261\u0b8f\ua960\u010a\u28c7\uc80f\uc156\u4e32\ud029\u7dc7\u965c\ud3fb\u0a78\uca34", "\ud889\udc58\udaa0\udec0\ud81a\udf83\uda46\udcfa",
        4, 34487, 1612291236, -3861370548402214021L, 64871L, false, true, (char) 36504, (char) 41415,
        Double.longBitsToDouble(0x3fb900844633aa30L), Double.longBitsToDouble(0x3fe6e3ab34aafda9L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:TRUE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 9, 9, "\uda3b\udf8f\u4851\ud915\udeda\ud9bc\udca1\udaa2\udf35\ud84a\udd20\u4e75\uda02\udd16\udb22\udc7d\udab9\udd36\udb76\udd64\ud8df\ude64\u643e\ud8b2\udc5f\ud977\ude28\ud984\udf2c", "\u53f9\u0c5b\u2261\u0b8f\ua960\u1e01\u28c7\uc80f", "\udbc9\udefd\ud8b5\udfc2\uda10\ude65\udaab\udd4b",
        5, 47844, 1160061316, 5632750257137051057L, -96776L, true, true, (char) 8309, (char) 2059,
        Double.longBitsToDouble(0x3febde534866d40dL), Double.longBitsToDouble(0x3f7df284f56eb900L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:TRUE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 10, 4, "\uda8d\udd5d\udbfe\udccf\udbe2\udea0\ud9bc\udca1\uda89\udf74\ud8fb\ude99\ud9fc\udd55\udbfe\udc9a\udb22\udc7d\udab9\udd36\udb76\udd64\udae5\ude60\u383e\ud989\udf64\ud8c9\ude31\ud984\udf2c", "\ubc00\uae9a\ua2e7\ua47f\ud0eb\u996d\u28cd\u3c97", "\udb74\udf6e\ud8b5\udfc2\udb99\udd1e\ued8b\ud999\udc51\ud95f\udf42\ud871\udd97\ud9d8\udee3\uda04\ude89\ud81e\udc54\ud9ff\uddea\u90ac\uda76\udd9c",
        8, 49724, -899045492, -5735708528549433329L, 11576L, true, true, (char) 41415, (char) 1699,
        Double.longBitsToDouble(0x3fe87bac8d8a997dL), Double.longBitsToDouble(0x3fe77d93e272d8abL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:TRUE\0121=com.google.javascript.rhino.Node:TRUE\012",
        Z.run(T, 2, 5, 5, 9, "\uda54\udc85\u4851\ud915\udeda\ud9bc\udca1\udaa2\udf35\ud84a\udd20\u4e75\uda02\udd16\udb22\udc7d\udab9\udd36\uda34\udd1d\ud8df\ude64\u643e\ud8b2\udc5f\ud977\ude28\ud984\udf2c", "\u96f8\u0c5b\u2261\u0b8f\ucf5a\u5f29\u128e\uc80f", "\udbc9\udefd\ud8b5\udfc2\ud9e1\udc9e\udaab\udd82",
        5, 24284, 1680482616, 5632750257137051057L, -96730L, true, false, (char) 22871, (char) 27749,
        Double.longBitsToDouble(0x3fbb729a4336a2a0L), Double.longBitsToDouble(0x3f7df284f56eb900L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:FALSE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 9, "\ud812\udf39\udbe6\udc3b\ud915\udeda\ud9bc\udca1\udaa2\udf35\ud8da\udeee\u4e75\uda02\udd16\udb22\udc7d\udab9\udd36\udb76\udd64\ud8df\ude64\u643e\ud8b2\udc5f\udb6e\udc83\ud961\udcdf", "\ua6c1\ua440\u2261\u0b8f\ua960\u010a\u28c7\uc80f", "\udbc9\udefd\ud8b5\udfc2\ud9e1\udc9e\udaab\udd82",
        5, 47844, 1680482692, -6415297937799846479L, 56508L, false, true, (char) 30180, (char) 50362,
        Double.longBitsToDouble(0x3f7f32b0bbeeb900L), Double.longBitsToDouble(0x3fe89b1c2e5bbb6cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:TRUE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 9, "\uda3b\udf8f\u4851\ud915\udeda\ud9bc\udca1\udaa2\udf35\ud847\udf67\u4e75\uda0d\udc16\udb22\udc7d\udab9\udd36\udb76\udd64\ud8df\ude64\uda09\udf66\ud87d\uddf0\udb03\ude0a\udae4\udcb9\udac1\udcbf\uda39\udd02", "\u8f95\u4644\uaa27\uc025\u28c5\u9878\uc076\u1aef\ud029\ud0b9\u4148\ud432\u0a78\uca34\u303b\u541f\ub994", "\udb32\ude27\ud921\udfcc\ud82b\udc55\udb23\ude90\ud93c\udd9c\ud886\udce8\ud8ef\udfbe\udace\uddfd",
        51, 30429, -2105689649, -7640343348564510934L, -65509L, true, false, (char) 5720, (char) 17401,
        Double.longBitsToDouble(0x3feec256098361e8L), Double.longBitsToDouble(0x3fea8a1a1d6f4ddfL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:TRUE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 16, 4, "\uda93\udf1a\u4851\ud915\udeda\ud9bc\udca1\udab1\udc9b\ud867\udf8d\ud8c5\udded\uda02\udd16\udae4\ude7e\udab9\udd46\ud824\udf3a\ud8df\uddec\u643e\ud8b2\udc5f\ud977\ude28\ud984\udf2c", "\u215e\u15ea\u2261", "\ud89c\udcbf\uda60\ude39\u4c2d\u34c6\udaa0\ude8b\udbc9\udefd\ud8b5\udfc2\uda10\ude65\udaab\udd4b\udb66\ude1b\udbb4\udcd7\ud871\udd97\u8c84\udab5\udd3b\uda58\udfc4\ud8bf\ude5c\ud87f\udec7\uda80\udec8\u00ff\udb15\udda9\uda19\udcc9\ud886\udce8\ud8ef\udfbe\udace\uddfd\ud997\udfc7\ud8e8\udee1",
        31, 10454, 730295145, -2691643766599443156L, -15889L, true, false, (char) 42952, (char) 58141,
        Double.longBitsToDouble(0x3fe4931cafb69d9dL), Double.longBitsToDouble(0x3fda0f0d354b214aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:FALSE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 12, 9, "\uda42\udeea\u4851\ud915\udeda\ud9bc\udca1\udaa2\udf35\ud84a\udd20\u4e75\uda02\udd16\udb22\udc7d\udab9\udd36\udb76\udd64\uda57\udea0\u255d\ud8ee\udcfb\uda9b\udc9a\ud984\udf2c", "\u53f9", "\uda50\udd48\udb79\udce5\ud89c\udcbf\uda60\ude39\u4c2d\u34c6\udaf7\udc31\ud85e\uddea\ud8b5\udfc2\uda10\ude65\udaab\udd4b\udb66\ude1b\udbb4\udcd7\ud871\udd97\u8c84\ud889\udc58\udaa0\udec0\ud9be\ude96",
        2, 99504, 255, 6924566536814962674L, 35066L, false, false, (char) 18269, (char) 55192,
        Double.longBitsToDouble(0x3fe2dddb63ce8642L), Double.longBitsToDouble(0x3feb487e7c412b87L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:FALSE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 8, 9, "\uda0f\udff3\ud8c0\uddb9\ud915\udeda\ud9bc\udca1\ud9ec\udf3a\ud84a\udd20\udb0c\udf91\uda02\udd16", "\ua084\u1aea\u20d6\u61bb\ub8e1\u9138\u2845", "\uda86\udffa\ud858\uddf8",
        -1, 15425, 957709610, -92576349322982355L, -92384L, false, true, (char) 31290, (char) 42957,
        Double.longBitsToDouble(0x3fec0c8efb9a6247L), Double.longBitsToDouble(0x3fe80314c67a5fd7L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:FALSE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 14, 7, "\ud9a5\udf83\ud96c\udd68\ud9bb\udc75\udac0\udd37\uda84\udec6\ud8e2\udd28\u4ec5\ud94d\udc33\udb22\udc7d\udab9\udd36\udb76\udd64\ud91e\udc33\ud856\udd63\ud8c0\ude70\ud977\ude28\ud984\udf2c\udac1\udcbf\udbe1\udfaf\ud868\udd02\uda86\udffa\ud858\uddf8\uda50\udd48\uda82\ude7e\ud89c\udcbf\uda60\ude39", "\u872d\ud029\u81dc", "\udb57\udc1b\ud944\udcdf\ud871\udd97\ud91c\udd1f",
        4, 10124, 100930554, 2593397901745584094L, 95269L, false, true, (char) 50400, (char) 21885,
        Double.longBitsToDouble(0x3f7df284f56eb900L), Double.longBitsToDouble(0x3fe89b1c2e5bbb6cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:FALSE\0121=com.google.javascript.rhino.Node:FALSE\012",
        Z.run(T, 2, 5, 5, 9, "\uda0f\udc21\uda93\udecb\ud87c\udd4c\udbb4\udc6a\udb04\udd3c\udbad\udeeb\u4a72\ud862\udfde\udbae\udfc2\ud8e2\udc1b\ud802\udf16\ud926\ude3d\u643e\ud8b2\udc5f\ud977\ude28\ud984\udf2c", "\u5448\u0c5b\u2261\u0b8f\ua960\u5708\u2fcd\u6d70", "\ud981\udef9\ud8b5\udfc2\uda1e\udeab\uda3a\udf2a",
        31, 85747, 70209615, 5632598299197629873L, -60216L, false, false, (char) 29753, (char) 8823,
        Double.longBitsToDouble(0x3febdc9f3c6be8ceL), Double.longBitsToDouble(0x3f7c6e82b789b900L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:FALSE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 9, "\ud8c7\udd1e\uda1d\udca0\uba25\udbc0\ude5b\udb04\udd3c\udbad\udeeb\u4a63\ud878\udfd1\ud8d2\uddaa\u0a1a\udac0\udce0\ud926\ude3d\u643e\ud8bb\udd5f\ud977\ude28\ud984\udf2c", "\u5448\u0c5b\u189a\ubae8\ua960\u5708\u2fcd\u6d70", "\udbc9\udefd\ud8b5\udfc2\uda1e\udeab\uda3a\udf2a",
        31, 85747, 70209615, 5632598299197629873L, -60216L, false, false, (char) 38952, (char) 45636,
        Double.longBitsToDouble(0x3febde533866d454L), Double.longBitsToDouble(0x3f7df284f56eb900L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:TRUE\012",
        Z.run(T, 1, 5, 16, 9, "\ud97d\udeae", "\u0a3c\u74dc\u340e\u5146\u409f\u92b5\ua28d\u40e8\u08d7\ud4af\u9deb\u93a9\u7303\u2365\ud792\u2f5c\ud757\u2782\u061f\u8f61\u9fc6\u9a26\ub442\uca99\u9d26\u5f75\u2bef\u8f27\uc6fe\u8c2f\ud5d5\ub1f1\ub805\u8895\u3476\ub308\u4ed0\u9ac7\u08cc\u80b1\ua586\u3784\u2fed\u5819\u3715\u81ca\ud1c2\u25c5\ua467\u8933\u1c47\uc89f\ua818\u972a\u17b9\u0d7e\u3a53\u97f0\u02fe\u9bd2\u0877\u373d\u8f87\ucd35\ub7f0\u4c38\u4e63\ub2c1\uba8f\u96d5\u0540\u38fc\u87c2\u598f\u9442\ub3c4\u0666\u1870", "\uda29\udd2c\udb45\ude79\ud9e8\ude80\ud8a0\udc51\ud9f9\ude2f\uda98\udcca\ud8b6\ude21\uda59\udd7f\udb5f\udde9\uda01\ude09\udb6d\udf0b\udab0\udf3c\udb0a\ude09\udbb5\udebb\uda8a\ude8e\udabb\udd4a\uf9bd\ud935\udcb2\ud901\udd3d\udbfa\udcdc\udbb4\ude11\ud9a9\ude71\udb91\udc60\ud837\uddd0\uda3e\ude04\ud9b6\udd5d\ud9a9\udc99\udbcd\ude7c",
        39, 83147, -1598471007, 2837986296909071366L, -48148L, true, true, (char) 29604, (char) 23849,
        Double.longBitsToDouble(0x3feb322afa92560aL), Double.longBitsToDouble(0x3fdbf81a272eded2L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:FALSE\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 7, 12, "\ud8cb\udc62", "\uac5f\u37d5\u79c3", "\ud835\ude26\udb0e\udc97",
        16, 81862, 2129577984, -1921981326549581451L, -47270L, false, true, (char) 61833, (char) 194,
        Double.longBitsToDouble(0x3fb191d769e0e630L), Double.longBitsToDouble(0x3fe5099ded62caa2L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 11, 9, "\uda3b\udf8f\u4851\ud915\udeda\ud9bc\udca1\udaa2\udf35\ud84a\udd20\u4e75\uda02\udd16\udb22\udc7d\udab9\udd36\udb76\udd64\udba5\ude27\uda4f\uddb4\ud8cf\ude94\ud977\ude28\ud984\udf2c", "\u53f9\u0c5b\u2261\u0b8f\ua960\u010a\u28c7\uc80f", "\udbc9\udefd\ud8b5\udfc2\uda10\ude65\udaab\udd4b",
        5, 80876, 1160061368, 5632750257137051057L, 56508L, false, true, (char) 37681, (char) 57746,
        Double.longBitsToDouble(0x3f7df3e4f56eb900L), Double.longBitsToDouble(0x3fe89b1c2e5bbb6cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.NodeUtil|mayBeString|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|mayBeString|com.google.javascript.rhino.Node,boolean|static",
    "M|com.google.javascript.jscomp.NodeUtil|allResultsMatch|com.google.javascript.rhino.Node,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.NodeUtil|anyResultsMatch|com.google.javascript.rhino.Node,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.NodeUtil|arrayToString|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|booleanNode|boolean|static",
    "M|com.google.javascript.jscomp.NodeUtil|callHasLocalResult|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|canBeSideEffected|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|canBeSideEffected|com.google.javascript.rhino.Node,java.util.Set|static",
    "M|com.google.javascript.jscomp.NodeUtil|checkForStateChangeHelper|com.google.javascript.rhino.Node,boolean,com.google.javascript.jscomp.AbstractCompiler|static",
    "M|com.google.javascript.jscomp.NodeUtil|constructorCallHasSideEffects|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|constructorCallHasSideEffects|com.google.javascript.rhino.Node,com.google.javascript.jscomp.AbstractCompiler|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsFunction|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsType|com.google.javascript.rhino.Node,int|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsType|com.google.javascript.rhino.Node,int,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.NodeUtil|copyNameAnnotations|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|mayBeString|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|mayBeString|com.google.javascript.rhino.Node,boolean|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
