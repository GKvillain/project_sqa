package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class CodeGenerator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 1, 4, 3, 2, "\uda2e\udf54\udacc\udfed\udb72\udeab", "\u81c4\u4df8", "\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\udf55\udbad\udfaa\udaff\ude57\ud953\ude95\udba8\udc62\ud99f\udd76\udb50\udd15\uda26\uddc2\ud9e3\uddc6\udb9e\udc67\udbd7\udf9c\udb76\udd9b\udbe4\udf9d\udb12\ude53\ud9f3\udee6\ud877\uddf5\udb4c\udfcc\udbe5\udcc7\uda35\udeed\ud832\udee0\ud84f\udd2c\ud961\udfd3\udaf2\udf2b\ud9e8\udf94\ud911\udc15\udbc5\udc7d\udb59\udf31\udbce\udfe5\ud8a4\uddc1\uda5c\udeae\ud9b7\udedd\udb54\ude96\udb3c\udd2a\udbdc\udc83\udbdc\udf1f\ud8ea\udc4f\udbc2\udca9\ud843\udc8c\udaa5\ude89\udbe3\udf8c\udbc1\udd7d\ud98a\ude8e\udb2e\udca3\uda75\udfa6\udb84\udc28\ud9a0\udfc1\ud944\udf7a\udbb9\udf19\ud936\udccf\ud932\udd09\ud8ef\udcdc\ud841\udcc7\udadc\udfde",
        24, 3576, -612960584, 1102989251203772766L, 876L, false, false, (char) 26953, (char) 18832,
        Double.longBitsToDouble(0x3fe1d5ff1b968eb1L), Double.longBitsToDouble(0x3fe61778dd1a96a5L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 2, "\uda2e\udf54\udacc\udfed\ud811\udcda", "\u81c4\u4df8", "\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\udf55\udbad\udfaa\udaff\ude57\ud953\ude95\udba8\udc62\ud99f\udd76\udb50\udd15\uda26\uddc2\ud9e3\uddc6\udb9e\udc67\udbd7\udf9c\udb76\udd9b\udbdc\udd80\udb3c\udcbc\ud9f3\udee6\ud877\uddf5\udb4c\udfcc\udbe5\udcc7\uda35\udeed\ud832\udee0\ud84f\udd2c\ud961\udfd3\udaf2\udf2b\ud9e8\udf94\ud911\udc15\udbc5\udc7d\udb59\udf31\udbce\udfe5\ud8a4\uddc1\uda5c\udeae\ud9b7\udedd\udb54\ude96\udb3c\udd2a\udbdc\udc83\udbdc\udf1f\ud8ea\udc4f\udbc2\udca9\ud843\udc8c\udaa5\ude89\udbe3\udf8c\udbc1\udd7d\ud98a\ude8e\udb2e\udca3\uda75\udfa6\udb84\udc28\udb8d\udf77\udad0\udcfa\udbb9\udf19\ud936\udccf\ud932\udd09\ud902\ude26\ud84a\udfdc\udadc\udfde",
        24, 3576, -612960584, 1102989251203772766L, 876L, false, false, (char) 32282, (char) 18812,
        Double.longBitsToDouble(0x3fe1d5ff1b968eb1L), Double.longBitsToDouble(0x3fe61778dd1a96a5L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 1, 4, 3, 2, "\uda32\udfdb\udacc\udfed\udb07\udfac", "\u81c4\u4df8", "\ud91b\udeb8\udba4\udcec",
        17, 20435, -1284058391, -2012656697414116529L, -11580L, true, false, (char) 60615, (char) 39009,
        Double.longBitsToDouble(0x3fe24b7c648c3c71L), Double.longBitsToDouble(0x3fe2660039a87e43L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 2, "\uda2e\udf54\udacc\udfed\udb72\udeab", "\ubf6b\u3a84", "\uda1b\udce3\u2423\ud949\udf77\ud87a\ude7b\udbd9\udcaa\udaff\ude57\ud953\ude95\udba8\udc62\ud99f\udd76\ud92e\udd84\uda26\uddc2\ud9e3\uddc6\udb9e\udc67\udb4f\uded8\udb76\udd8d\udbe4\udf9d\udb12\ude53\ud9f3\udee6\ud877\uddf5\udb4c\udfcc\udbe5\udcc7\uda35\udeed\ud832\udee0\ud84f\udd2c\ud961\udfd3\udaf2\udf2b\ud9e8\udf94\ud911\udc15\udbc5\udc7d\udb59\udf31\udb29\udf32\udae8\udc79\ud862\udf46\ud9b7\udedd\udb54\ude96\udb3c\udd2a\ud806\udd87\udbdf\udd1f\ud8ea\udc4f\udbc2\udca9\ud843\udc8c\udaa5\ude89\udbe3\udf8c\udbc1\udd7d\ud98a\ude8e\udb2e\udca3\uda75\udfa6\udb84\udc28\ud9a0\udfc1\ud944\udf7a\udbb9\udf19\ud936\udccf\ud932\udd09\ud8f8\udcdc\ud841\udcc7",
        26, 66544, -1876272424, 5466270599474354889L, -66455L, false, true, (char) 42481, (char) 64824,
        Double.longBitsToDouble(0x3fe8f293963abfe3L), Double.longBitsToDouble(0x3fecb4758ec2ef1bL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 3, 2, "\uda2e\udf54\udacc\udfed\udb72\udeab", "\u750d\u4df8", "\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\udf55\udafa\udfc7\udb82\udd23\u9284\udba8\udc62\ud99f\udda6\udb50\udd15\uda26\uddc2\ud9e3\uddc6\udb9e\udc67\udbd7\udf9c\udb76\udd9b\udbe4\udf9d\udb12\ude53\ud9f3\udee6\udb5d\udfc8\udb4c\udfcc\udbe5\udcc7\uda35\udeed\ud80c\udfe0\ud84f\udd2c\ud961\udfd3\udaf2\udf2b\ud9c5\udf55\ud911\udc15\u6a69\ud9fb\udf2b\udb9b\udd2a\ud8a4\uddc1\uda5c\udeae\ud9b7\udecd\udb54\ude96\udb3c\udd2a\udbdc\udc83\udbdc\udf1f\udad7\udc05\udbc2\udca9\ud83b\uddc0\udaa5\ude89\udbe3\udf8c\udb9f\ude7d\ud98a\ude8e\udb2e\udca3\uda75\udfa6\udb84\udc28\ud9a0\udfc1\udbf3\udd92\ud8bd\udeef\ud979\udc24\udba9\udc39\ud8ea\udc82\ud841\udcc7\udadc\udfde",
        24, 2512, 707545167, 1102989250971597150L, 876L, false, false, (char) 26953, (char) 18832,
        Double.longBitsToDouble(0x3fe1d5ff1b968eb1L), Double.longBitsToDouble(0x3fe61778dd1a96a5L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 3, 2, "\uda81\udf3f\u0081\udb72\udeab", "\u5fc4\u4df8", "\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\udf55\udbad\udfaa\udaff\ude57\u1b4f\000\000\000\uda26\udd4e\ud9e3\uddc6\udb9e\udc67\udbd7\udf9c\udb76\udd9b\udbe4\udf9d\udb12\ude53\ud9f3\udee6\ud877\uddf5\udb4c\udfcc\udbe5\udcc7\uda35\udeed\ud832\udee0\ud94c\udd6a\000\udaf2\udf2b\ud9e8\udf94\ud911\udc15\udbc5\udc7d\udb59\udf31\udbce\udfe5\udb40\udccf\uda5c\udeae\ud9b7\udedd\udb54\ude96\udb3c\udd2a\udbdc\udc83\udbdc\udf1f\ud8cc\udce5\udb8a\udf2e\ud971\uddb7\udaa5\ude89\udbe3\udf8cv\000\udb2e\udca3\uda75\udfa6\udb84\udc28\ud9a0\udfc1\udbdd\udc67\uda84\udda2\ud936\udccf\ud932\udd09\ud8ef\udcdc\ud841\udcc7\udadc\udfde",
        24, 3576, -612960584, 1102988284836131166L, 876L, false, false, (char) 63759, (char) 63261,
        Double.longBitsToDouble(0x3fe1d5ff1b968eb1L), Double.longBitsToDouble(0x3fe61778dd1a96a5L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 3, 2, "\uda2e\udf54\udacc\udfed\udb7f\udf71", "\u81c4\u4df8", "\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\udf55\udbad\udfaa\udaff\ude57\ud953\ude95\udba8\udc62\ud99f\udd76\udb50\udd15\uda26\uddc2\ud9e3\uddc6\udb9e\udc67\udbd7\udf9c\udb76\udd9b\udbe4\udf9d\udb12\ude53\ud9f3\udee6\ud877\uddf5\udb4c\udfcc\udbe5\udcc7\uda35\udeed\ud832\udee0\ud84f\udd2c\ud8f1\udfdb\udaf2\udf2b\ud9e8\udf94\ud911\udc15\udbc5\udc7d\udb59\udf31\udbce\udfe5\ud8a4\uddc1\uda5c\udeae\ud9b7\udedd\udb54\ude96\udb3c\udd2a\udbdc\udc83\udbdc\udf1f\ud8ea\udc4f\ud8c0\udfea\ud800\udfb1\uda79\udf60\udbe3\udf8c\udbc1\udd7d\ud98a\ude8e\udb2e\udca3\uda75\udfa6\udb84\udc28\ud9a0\udfc1\ud944\udf7a\udbb9\udf19\ud936\udccf\ud932\udd09\ud8ef\udcdc\ud841\udcc7\udadc\udfde",
        24, 3576, -612960584, 1102989251203772766L, 876L, false, false, (char) 26953, (char) 18832,
        Double.longBitsToDouble(0x3fe1d5ff1b968eb1L), Double.longBitsToDouble(0x3fe61778dd1a96a5L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 1, 12, 14, 15, "\uda2e\udfc1\udacc\udfed\ud80d\udeb9\ud993\udffa\u50a3\ud89f\udf0b\udb4a\udc8c\udb92\udc64\uda31\udec1\ud91b\udeb8\udba4\udcec\uda8d\udff8", "\ua731\u7c47\u8594", "\uda26\uddc2\ud9e3\uddc6",
        -2, 85396, -1880208853, -3554927611066878022L, -72749L, true, false, (char) 21408, (char) 55713,
        Double.longBitsToDouble(0x3fe5073ca15d481fL), Double.longBitsToDouble(0x3fd3ab8e2a41d074L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 3, 2, "\uda2e\udf54\udacc\udfed\udb72\udeab", "\u57b2\ud295", "\ud91b\udeb8\ud983\udddc\uda8e\udc2c\ud87a\udf55\ud986\udda3\udaff\ude57\ud971\udd8d",
        9, 74300, -984355701, -6961114270775098628L, 50699L, false, true, (char) 63334, (char) 8023,
        Double.longBitsToDouble(0x3fb3c1b9e207baf8L), Double.longBitsToDouble(0x3feaf40a1c78b909L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 1, 5, 3, 2, "\uda2e\udf54\udacc\udfed\udb72\udeab", "\u81c4\u4df8", "\udaa7\udcbd\udba4\udd10\uda8d\udff8\ud87a\udf55\udbad\udfaa\ud981\ude58\ud953\ude95",
        9, 38141, -984355701, -6961114270775101188L, 23304L, false, true, (char) 61125, (char) 22020,
        Double.longBitsToDouble(0x3fb3c1b9e207baf8L), Double.longBitsToDouble(0x3fb7a050f5073ca0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 8, 12, "\uda2e\udf54\ud880\udf0f\udb72\uddf3", "\u9657\u4dc3", "\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\udf55\ud8bc\udf37\udaff\ude57\ud953\ude95\udba8\udc62\ud99f\udd76\udb50\udd1f\uda26\uddc2\ud9e3\uddc6\udb9e\udc67\udbd7\udf9c\udb76\udd9b\udbe4\udf9d\udb12\ude53\ud9f3\udee6\ud877\uddf5\udb4c\udfcc\udbe5\udcc7\uda35\udeed\ud832\udee0\ud84f\udd2c\ud961\udfd3\udbb0\uddc9\ud94b\udf7b\ud911\udc15\udbc5\udc7d\udb59\udf31\udbce\udfe5\ud8a4\uddc1\uda6f\udcb6\ud9b7\udedd\ud99f\udd3b\ud8c0\udce3\uda22\udfef\udbdc\udf1f\ud8ea\udc4f\udbc2\udca9\ud843\udc8c\udaa5\ude89\uda21\udc8b\ud981\udc5a\ud98a\ude8e\udb2e\udca3\uda75\udfa6\udb84\udc28\ud9a0\udfc1\ud944\udf7a\udba7\udf19\ud936\udccf\ud932\udd09\ud8ef\udcdc\ud841\udcc7\udadc\udfde",
        24, 12625, -612960544, 1102989251203775742L, 876L, false, false, (char) 42204, (char) 25936,
        Double.longBitsToDouble(0x3fe9bdff1bc76a66L), Double.longBitsToDouble(0x3fe61778dd1a96a5L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 1, 11, 3, 2, "\ud8ad\udefd\udb46\udcfc\udb5b\uddd1\ud993\udffa\u50a3\ud89f\udf0b\udb4a\udc8c", "\u41cd\u4228\u4e86\u7600\u0706\ua731\u7c47\u3bff\u0f8c\u1701\ub4f4\u6872\ub47b\ua236\ua7d0\u6117\ub407\u6f58\ucdbb\u2a15\u560a\u6b6c\u4c1b\u0514\u950d\u3dd3\u6006\ua7f1\u520e\u09d7\ua866\u23d6\u21ea\uaffe\ube71\u1c4f\u8f64\u3b54\u016d\ub422\u0226\u8823\ub4b3\u3932\u6c36\u2701\u86b6\u1596\u7592\u7b13\ua5a4\u1142\u6cf9\u7175\u50cf\u3846", "\udb2f\udc90\udbb4\udfc7\udb23\udde8\udbf1\udc70\ud9e9\udfcf\ud906\udf9d",
        15, 69894, -1900978630, -1217331352796010814L, 50214L, true, true, (char) 44038, (char) 57697,
        Double.longBitsToDouble(0x3fd6da62f8395104L), Double.longBitsToDouble(0x3fa6d59e79c2c3e0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 1, 10, 14, 2, "\ud827\ude12\uda0f\udf6a\ud9d2\udf10\udbd2\uded6\udbf1\udc76\ud89f\udf0b\udb4a\udc8c\udb92\udc64\ud8b9\udec5\ud91b\udeb8\udba4\udc67\uda8d\udff8\ud87a\udf55", "\u7c47\uc8b5\u0f16\u6c0a\u9b8d\u345e\ua9b0\ua236\uc92e\u60e9\u61f4\u5358\ucdbb\ubaf8\u0e06\u7c9c\u715a\u0514\u950d\u3dd3", "\udbc5\udc7d\udbb3\udedc\udbce\udfe5\ud8a4\uddc1\ud800\uddf4\ud898\udfe8\udb54\ude96\udb3c\udd2a\udbdc\udc83",
        8, 3082, 1575729953, 7012138497230881551L, 81366L, false, false, (char) 57999, (char) 64146,
        Double.longBitsToDouble(0x3fde9dba6f2bc6a2L), Double.longBitsToDouble(0x3fec9712e3cee26eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 3, 2, "\uda2e\udf54", "\u691c\u2fd6\u81c4", "\uda31\udec1\u3912\000\000\000\000\udafd\ude5e\ud953\ude95\udba8\udc62\ud99f\udd76\udb50\udd15",
        44, 13588, 0, 3749198914688076331L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e07a050c0000000L), Double.longBitsToDouble(0x3fe5073ca05d481fL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\udbc3\ude71\udacc\udfe9\udb72\udeab\\u6949\012",
        Z.run(T, 1, 15, 3, 2, "\udbc3\ude71\udacc\udfe9\udb72\udeab", "\uc27e\u4df8", "\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\udf55\udbad\udfaa\udaff\ude57\ud953\ude95\udba8\udc62\udbe9\udc70\udb50\udd15\uda26\uddc2\ud9e3\uddc6\udb9e\udc67\udbd7\udf9c\udb76\udd9b\udbe4\udf9d\udb12\ude53\ud9f3\udee6\ud877\uddf5\udb4c\udfcc\udbe5\udcc7\uda35\udeed\ud832\udee0\ud84f\udd2c\ud961\udfd3\udaf2\udf2b\ud9e8\udf94\ud911\udc15\udbc5\udc7d\udb59\udf31\udbce\udfe5\ud8a4\uddc1\uda5c\udeae\ud9b7\udedd\udb54\ude96\udb3c\udd2a\udbdc\udc83\udbdc\udf1f\ud8ea\udc4f\udbc2\udca9\ud843\udc8c\udaa5\ude89\udbe3\udf8c\udbc1\udd7d\ud98a\ude8e\udb2e\udca3\uda75\udfa6\ud929\udd3a\ud833\udede\ud944\udf7a\udbb9\udf19\ud936\udccf\ud932\udd09\ud8ef\udcdc\ud841\udcc7\udadc\udfde",
        24, 3576, -612960584, 1102989251203772766L, 876L, false, false, (char) 26953, (char) 54927,
        Double.longBitsToDouble(0x3fe1d50a73968eb1L), Double.longBitsToDouble(0x3fc85de3746a5a94L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 14, 15, "\uda2e\udf54\udacc\udfed\udb27\udfe6\ud836\ude7e\u50a3\ud8d5\udfc0\udb4a\udc8c\udb92\udc64\uda31\udec1\ud91b\udeb8\udaac\udf32\ud89f\udde2\uda29\udd23\udbad\udfaa\udaff\ude57\ud953\ude95\udb4b\udf9c\udbb9\udd77\udbe1\ude07\uda30\udec1", "\ua236\ua7d0\ua963\ub407\u6f58", "\udbe5\udcc7\uda35\udeed\ud832\udee0\uda09\ude28\ud9df\udf60\uda19\ude16\udac5\uddc2\udb8d\udc53\uda5b\udc00\udb59\udf31",
        4, 49764, -787769892, 1095973364459664507L, -40461L, false, true, (char) 10615, (char) 51794,
        Double.longBitsToDouble(0x3fe682ef5b0f6150L), Double.longBitsToDouble(0x3fc8ae0d11d8bcc4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 4, 4, 9, "\uda2e\udf54\udacc\udfed\ud811\udcda", "\u81c4\u23fc", "\ud94b\udc9d\udba4\udcec\uda8d\udff8\ud87a\udf55\udbad\udfaa\udaff\ude57\ud953\ude95",
        9, 74300, -984355701, -6961114270775101188L, -88876L, true, false, (char) 11755, (char) 48989,
        Double.longBitsToDouble(0x3fe52883f58dc077L), Double.longBitsToDouble(0x3fb3c1b9e207baf8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 2, "\uda2e\udf54\udacc\udfed\uda2a\udd78", "\u821d\u4df8\u4369\u4933\u41cd\u4228\u8c0f\u5be5\u06dd\ub831\u7c47\u3bff\u0f8c\u1701\ub4f4\u6872\ub47b\ua236\ua7d0\uabeb\u1b50", "\udb4c\udfcc\udbe5\udcc7",
        0, 58845, -1193098915, -1712853050058117856L, 23433L, false, true, (char) 30787, (char) 18143,
        Double.longBitsToDouble(0x3fc9e41375cc4034L), Double.longBitsToDouble(0x3fdf8d10b8f61e6aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 7, 2, "\uda2e\udf54\udacc\udfed\ud811\udcda", "\u81c4\u4df8\u4369\ubc8f\u41cd\u4228\u4e86\u7600\u0706\ua731\u7c47", "\uda27\udf07\udb6a\uddd9\ud9e3\uddc6\udb9e\udc67\udbd7\udf9c\udb76\udd9b\udbdc\udd80\udb3c\udcbc\ud9f3\udee6\ud877\uddf5\udb4c\udfcc\udbe5\udcc7\uda35\udeed\ud832\udee0\ud84f\udd2c\ud961\udfd3\udaf2\udf2b",
        2, 1033, 1870429676, 7846687577101556218L, -70181L, true, true, (char) 25629, (char) 14009,
        Double.longBitsToDouble(0x3fd6ab20c6421e64L), Double.longBitsToDouble(0x3fe682ef5b0f6150L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 2, "\uda2e\udf54\udacc\udfed\ud811\udcda", "\u81c4\u4df8", "\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\udf55\udbad\udfaa\udaff\ude57\ud953\ude95\udba8\udc62\ud99f\udd76\udb50\udd15\uda26\uddc2\ud9e3\uddc6\udb9e\udc67\udbd7\udf9c\udb76\udd9b\udbdc\udd80\ud818\udcea\ud9f3\udee6\ud877\uddf5\udb4c\udfcc\udbe5\udcc7\uda35\udeed\ud832\udee0\ud84f\udd2c\ud961\udfd3\udaf2\udf2b\ud9e8\udf94\ud911\udc15\udbc5\udc7d\udb59\udf31\udbce\udfe5\ud8a4\uddc1\uda5c\udeae\ud9b7\udedd\udb54\ude96\udb3c\udd2a\udbdc\udc83\udbdc\udf1f\ud8ea\udc4f\udbc2\udca9\ud843\udc8c\udaa5\ude89\udbe3\udf8c\udbc1\udd7d\ud98a\ude8e\udb2e\udca3\uda75\udfa6\uda22\udf57\udb8d\udf77\udad0\udcfa\udbb9\udf19\ud936\udccf\ud932\udd09\ud902\ude26\ud84a\udfdc\udadc\udfde",
        24, 3576, -612960584, 1102989251203772766L, 876L, false, false, (char) 32282, (char) 18812,
        Double.longBitsToDouble(0x3fe1d5ff1f6561b1L), Double.longBitsToDouble(0x3fd58e82fd55a660L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 14, "\uda2e\udf54\udacc\udfb1\ud811\udcda", "\u81c4\u5e32", "\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\udf55\udbad\udfaa\udaff\ude57\ud881\udf71\ud890\udc58\ud99f\udd76\udb50\udd15\uda26\uddc2\ud911\udfba\uda9c\uddd1\udbd7\udf9c\udb70\udf9b\udbdc\udd80\udb3c\udcbc\ud9f3\udee6\ud877\uddf5\udb4c\udfcc\udbe5\udcc7\uda35\udeed\ud832\udee0\ud84f\udd2c\ud961\udfd3\udaf2\udf2b\ud9e8\udf94\ud911\udc15\udbc5\udc7d\ua49a\udbcf\udf9b\ud8a4\uddc1\uda5c\udeae\ud9b7\udedd\udb54\ude96\udb3c\udd2a\udbdc\udc83\udbdc\udf1f\ud8ea\udc4f\udbc2\udca9\ud843\udc8c\udaa5\ude89\udbe3\udf8c\udbc1\udd7d\ud98a\ude8e\udb2e\udca3\uda75\udfa6\udb84\udc28\udb8d\udf77\udad0\udcfa\udbb9\udf19\ud936\udccf\ud932\udd09\ud902\ude26\ud84a\udfdc",
        26, 66544, -1876272424, -2632645661760251167L, -66455L, false, false, (char) 4348, (char) 32282,
        Double.longBitsToDouble(0x3fe8f292f63abfe3L), Double.longBitsToDouble(0x3fe6fda58ec2ef70L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |a0=java.lang.StringBuilder:\uda2e\udf54\udacc\udfed\ud951\udc92\\ud320\012",
        Z.run(T, 2, 11, 15, 2, "\uda2e\udf54\udacc\udfed\ud951\udc92", "\u81c4\u4df8", "\ud9ee\ude57\ud8e4\udca1\udbc7\udfed\ud885\udfd9\udbad\udfaa\udaff\ude57\ud953\ude95\udba8\udc62\ud9a5\udf76",
        4, 86284, -913557252, 4355531524067021964L, -9492L, false, true, (char) 54048, (char) 22020,
        Double.longBitsToDouble(0x3fb3c1b9f143aaf8L), Double.longBitsToDouble(0x3fdeadf08d41cf76L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 13, "\uda2e\udf54\udacc\udfed\ud811\udcda", "\u4f21\u25d4", "\ud91b\udeb8\udbb4\udc15\ud803\udc16\ud87a\uded0\udbad\udfaa\ud83e\ude57\ud953\ude95\udba8\udc62\ud99f\udd76\udb50\udd15\uda26\uddc2\ud8fa\ude5e\ud87a\ude65\uda37\uddc5\udb76\udd9b\ud96a\ude81\udb3c\udcbc\ud9e4\udee6\ud877\uddf5\udb4c\udfcc\udbe5\udcc7\uda35\udeed\ud832\udee0\ud84f\udd2c\ud89c\udd10\udaf2\udf2b\ud9e8\udf94\ud911\udc15\udbc5\udc7d\udb59\udf31\udbce\udfe5\ud8a4\uddc1\uda5c\udeae\ud9b7\udedd\udb54\ude96\udb3c\udd2a\udbdc\udc83\udbdc\udf1f\udb3e\udcf9\udb58\udf9c\ud843\udc26\udaa5\ude89\udb71\udf93\udbc1\udd7d\ud9c4\udf4b\udb2e\udca3\uda75\udfa6\udb84\udc28\udb8d\udf77\udae4\udfdd\udbb9\udf19\ud92d\udf83\ud932\udd09\ud902\ude26\ud84a\udfdc\udadc\udfde",
        24, 3576, -612960584, 1102989251203772766L, 876L, false, false, (char) 32282, (char) 18812,
        Double.longBitsToDouble(0x3fe1d5ff1bbd8eb1L), Double.longBitsToDouble(0x3fc85de377225a94L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 4, 12, 14, "\uda50\udd05\udacc\udfed", "\u2fed\u81c4\u4df8\u4369\ubc8f\u41cd\u4228\u4e86\u7600\u0706\ua731", "\ud99f\udd76\udb50\udd15\uda26\uddc2\ud9e3\uddc6\udb9e\udc67\udbd7\udf9c\udb76\udd9b\udbdc\udd80\udb3c\udcbc\ud9f3\udee6\ud877\uddf5\udb4c\udfcc\udbe5\udcc7\uda35\udeed\ud832\udee0\ud84f\udd2c\ud961\udfd3\udaf2\udf2b\ud9e8\udf94\ud911\udc15\udbc5\udc7d\udb59\udf31\udbce\udfe5\ud8a4\uddc1\uda5c\udeae\ud9b7\udedd\udb54\ude96\udb3c\udd2a\udbdc\udc83\udbdc\udf1f",
        50, 27953, 1632640720, -5527672597636887355L, 51315L, false, false, (char) 64146, (char) 26014,
        Double.longBitsToDouble(0x3fe9970a69dcc0c2L), Double.longBitsToDouble(0x3fd6978d177729e4L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 13, 10, "\uda2e\udf54", "\u7573\u2fed\u81c4", "\uda31\udec1\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\udf55\udbad\udfaa\udaff\ude57\ud953\ude95\udba8\udc62\ud99f\udd76\udb50\udd15",
        44, 87748, 1014101208, 3749198914688076331L, 20892L, true, false, (char) 22020, (char) 19254,
        Double.longBitsToDouble(0x3fb03dd7c2f40a18L), Double.longBitsToDouble(0x3fe5073ca15d481fL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 0, "\uda2e\udf54\udacc\udfed\ud811\udcda", "\u81c4\u4df8", "\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\udf55\udbad\udfaa\udaff\ude57\ud953\ude95\udba8\udc62\ud975\udf76\udb50\udd15\uda26\uddc2\ud9e3\uddc6\udb9e\udc67\udbd7\udf9c\udb76\udd9b\udbdc\udd80\udb3c\udcbc\ud9f3\udee6\ud877\uddf5\udb4c\udfcc\udbe5\udcc7\uda35\udeed\ud832\udee0\ud84f\udd2c\ud961\udfd3\udaf2\udf2b\ud9e8\udf94\ud911\udc15\udbc5\udc7d\udb59\ude6a\000\ud8a4\udcf2\uda5c\udeae\ud9b7\udedd\udb54\ude96\u00e3\udba1\udff0\udbdc\udf1f\ud8ea\udc4f\udbc2\udca9\ud843\udc8c\udaa5\ude89\udbe3\udf8c\udbc1\udd7d\ud98a\ude8e\udb2e\udca3\uda75\udfa6\udb84\udc28\udb8d\udf77\udad0\udcfa\udbb9\udf19\ud936\udccf\ud932\udd09\ud902\ude26\ud84a\udfdc\udadc\udfde",
        24, 3576, -612960584, 1102989251203772766L, 876L, false, false, (char) 32282, (char) 18812,
        Double.longBitsToDouble(0x3fe000071b968eb1L), Double.longBitsToDouble(0x3fe61778dd1a96a5L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 12, 11, 6, "\uda2e\udf54\udacc\udfed\ud82b\udfda", "\u81ec\u4df8", "\ud9c5\uddac\udb9f\udd15\uda8d\udff8\ud87a\udf55\udbad\udfaa\udaff\ude57\udb19\udfb7\uda43\udee9\udadd\uddef\udb50\udd06\uda91\ude97\ud8a4\udf51\uda67\udc4b\ue127\udb76\udd9b\udbdc\udd80\ud8ef\udcaa\ud9f3\udee6\ud877\uddf5\ud96d\udcdc\udb83\udf0b\uda35\udeed\ud832\udee0\ud84f\udd2c\ud961\udfd3\udaf2\udf2b\ud9e8\udf94\ud911\udc15\udbc5\udc7d\udb59\udf31\udb77\uddf9\ud9f7\udc7f\uda5c\udeae\ud8c4\udec8\udb78\uddce\udb3c\udcd5\udbdc\udc83\udbdc\udf1f\ud8ea\udc4f\udbc2\udca9\ud843\udc8c\udaa5\ude89\udbe3\udf8c\udbc1\udd7d\ud98a\ude8e\udb2e\udca3\uda75\udfa6\udb84\udc28\udb8d\udf77\udad0\udcfa\udbb9\udf19\ud936\udccf\ud932\udd09\ud902\ude26\ud99f\udecd\uda08\udf3a",
        39, 32392, -616199141, 1102989251203772766L, 876L, false, false, (char) 47213, (char) 25119,
        Double.longBitsToDouble(0x3fe1d5ff1b968eb1L), Double.longBitsToDouble(0x3fe50fabc51a96a5L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 2, "\007\000\000", "\u81c4", "\uda31\udec1\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\udf55\udbad\udfaa\udaff\ude57\ud953\ude95\udba8\udc62\ud99f\udd76\udb50\udd15",
        44, 73412, 1014101208, 3749198914688076331L, 20892L, true, false, (char) 22020, (char) 19254,
        Double.longBitsToDouble(0x3fb03dd7c2f40a18L), Double.longBitsToDouble(0x3fe5073ca15d481fL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 2, "\ud9ac\ude69\udb55\udcba\ud9ae\ude3f\ud97f\udc80\udafa\ude00\ud89f\udf0b\ud89e\udde1\uda27\udc9b\ud86b\ude2d\ud91b\udf76\uda89\ude1f\ud921\udd04\ud9db\udc7d\ud911\uddcd\ud960\ude2e\ud953\ude9e\udba8\udd62", "\ub69c\u2ceb\u613a\u6abd\u8187\u018a\ua5e5\u1499\u7245\ub8c2\u80fb", "\ud94d\udee4\udbb8\udeb2\udadf\udcf2\udbe6\udc4f\udad4\udfd4\ud819\udf5e\udb8b\ude85\uda09\udc11",
        -5, 25949, 1810971406, -4035228376032995614L, -43396L, false, true, (char) 22318, (char) 34484,
        Double.longBitsToDouble(0x3fe15e30d4e8d014L), Double.longBitsToDouble(0x3fde8b06545f1530L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 0, 0, "", "\u0ad2\u691c\u2fd6\u81c4\u4df8\u00fb\000\u3900\u26d1\u20ff\u1ef6\u0833\000\u7c47\u3bff\u0f8c\u1701\ub4f4\uc531\000\ubc2d\ua7f1\uc659\u7a6a\ub598\ucb93\u2934\u7615\u4708\u1305\u240a\u41d0\u968d\ud0a4\u12dd\ua982\uc843\u6448", "\ud8a8\ude0e",
        41, 33610, 1500769857, -4530045501971553933L, -29943L, true, true, (char) 15397, (char) 38054,
        Double.longBitsToDouble(0x3fe4c0569a9457dfL), Double.longBitsToDouble(0x3fe058e2e89fd18eL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 2, "\uda32\udfdb\udacc\udfed\udb07\udfac\ud993\udffa\udb46\udf3d\ud98e\udd6f\uda32\udde8\udbfa\udc3e\uda31\udf01\ud829\udcb8\udb7d\udffa\uda8b\udf48\uda64\udfac\ud955\udf2e\uda76\udcaa\udbf7\ude0e\ud80c\ude4e\ud8af\uddfe\ud9cc\udff2\ud9e9\ude15\udba5\udf8e\udba0\uddd8\udbaa\udcc6\udb76\uddbc\ud944\uddcd\uda73\udfde\ud857\udf06\ud9b2\udf74\udb38\udc14\ud8ed\udc9c\udaf5\udfb0\udb2c\udfdd\ud9d6\udff8\udaf0\udebc\u449a\udb2a\udf16\ud929\udda5\uda31\udfff\u131a\ud8b1\udfb0", "\u958e\u9b11\u3aab\u85ef\u4330\u84b1\u707a\u5ee2", "\uda7c\udf23\udb6f\udecd\udbd9\udd99\ud9e1\udd5f\ud89b\ude2a\udaa2\udc93\ud82b\uddd7",
        40, 95324, -1842167225, 454904831050918967L, -77221L, false, true, (char) 44553, (char) 40461,
        Double.longBitsToDouble(0x3fe559446c72b351L), Double.longBitsToDouble(0x3fe05622dd3a49e5L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 4, 4, "\ud97c\udd47", "\u691c\u6125\ud357\u519f\u4993\u6b59\u4a28", "\ud973\udefe\uda25\ude29\udaf5\uddd4\ud976\udd1c\udba8\udc62\ud99f\udd76\udb50\udd15\uda26\uddc2\udba5\udf8e\udba0\uddd8\udbaa\udcc6\ud906\uddc4\udaf6\udf87\udb4d\udded\udaa5\udd0a\uda8e\udf15\udbce\udc5b\uda8f\ude53\ud8ef\udde3\ud8c8\udf60\udb14\uddde\udb90\udc59\udba9\uddc1",
        33, 2275, -154083948, -7433328607368937028L, -76019L, true, false, (char) 26388, (char) 37070,
        Double.longBitsToDouble(0x3fd4b5ac5984d7aaL), Double.longBitsToDouble(0x3fd997136d9b4eaaL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 1, 11, 3, 2, "\udb05\ude39\udad1\udd72\udb07\udfac", "\u81c4\u4df8", "\ud91b\udeb8\udba4\udcec",
        17, 64467, -1284058391, -2012656697414116529L, -11580L, true, false, (char) 60615, (char) 39009,
        Double.longBitsToDouble(0x3fe24b7c648c3c71L), Double.longBitsToDouble(0x3fe2660039a87e43L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 0, 0, "\000\000\000", "\u5fc4", "\000",
        30, 15341, -736564593, 7848085300654908280L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fcb19319230f1c4L), Double.longBitsToDouble(0x3fe159a039000043L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 14, 15, "\uda2e\udfc1\udacc\udfed\ud80d\udeb9\ud993\udffa\ud868\udc0c\ud8f7\udd3c\ud8f0\ude52\udb92\udc64\uda31\udec1\ud91b\udeb8\udba4\udcec\uda8d\udff8", "\ua731\u7c47\u8594", "\uda26\uddc2\ud9e3\uddc6",
        -2, 85396, -1880208853, -3554927613020440646L, -83164L, false, true, (char) 20520, (char) 55700,
        Double.longBitsToDouble(0x3fe5073ca15d481fL), Double.longBitsToDouble(0x3fd3ab8e2a41d01eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 13, 8, "\ud927\udd64\ud817\udc97\ud9ae\udf69\udb1b\udf82\uda17\udf98\ud89f\udf0b", "\ubc8f\u2095\uc610\u51e5\u8a96\u9602\u48c6\u8e4f\u30d4\u27f2\u4305", "\ud9f3\udd67\ud846\udeaf",
        29, 98967, -64915526, 5510086398220964796L, -58122L, false, true, (char) 33726, (char) 8667,
        Double.longBitsToDouble(0x3fee6dc357daf21bL), Double.longBitsToDouble(0x3fd8d08adef4b410L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 14, 15, "\000\udacc\udf6c\udb27\udfe6\ud836\ude7e\u50a3\ud8d5\udfc0\udb4a\udc8c\udb92\udc64\uda31\udec1\ud91b\udeb8\udaac\udf32\ud89f\udde2\uda29\udd23\udbad\udfaa\udaff\ude57\ud953\ude95\udb4b\udf9c\udbb9\udd77\udbe1\ude07\uda30\udec1", "\ua236\ua7d0\ua963\ub407\u6f58", "\udbe5\udcc7\uda35\udeed\ud832\udee0\uda09\ude28\ud9df\udf60\uda19\ude16\udac5\uddc2\udb8d\udc53\uda5b\udc00\udb59\udf31",
        4, 49764, 759260, 1080863910030505083L, -40461L, false, true, (char) 10615, (char) 51794,
        Double.longBitsToDouble(0x3fe682ef5b0f6150L), Double.longBitsToDouble(0x3fc8ae0d11d8bcc4L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 15, 9, "\ud8ce\ude05\udb8b\udd53\udbf3\udfa9\ud836\ude7e", "0", "\ud91b\udeb8\udbf5\udd2b\ud89f\udde2\ud9c6\udc50\udabd\udcb0\ud92c\ude4d\ud906\ude1a\udb4b\udf9c\uda67\udfcf\ud807\ude9e\uda30\udec1\ud9c6\uddd7\ud838\uddaa\udbd7\udf9c\udb76\udd9b\uda46\udccd\uda59\udeb6\ud9f3\udee6\ud9fb\udf8f\udb50\udca8\udbe5\udcc7\uda35\udeed\ud832\udee0\uda60\uddf5\ud921\uddf4\udb46\ude90\u366c\udb9b\udc43\ud846\udff1\udbd9\udeac\ud841\udc54\udbd0\udd77\udb1d\udf28\ud9c6\udf5b\udb65\udfd4\udb3c\udd2a\udbde\udc84\udbdc\udf1f\u968e\ud9ee\udd33\ud843\udc9d\udb6c\uddae\udb82\udd5c",
        20, 45024, -2064897868, 6961285644574151390L, -99257L, true, true, (char) 37177, (char) 56781,
        Double.longBitsToDouble(0x3fda07c66dbe8e98L), Double.longBitsToDouble(0x3fa3a5728457adb0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 14, 0, "\uda2e\udf54\u0081\ud8f9\udc1c\ud836\udddf\u50a3\ud8d5\udfc0\udb49\udfad\udb92\udc64\uda31\udec1\ud91b\udeb8\udaac\udf32\ud89f\udde2\uda29\udd23x", "\ub215", "\000",
        35, 60208, 872928396, 9098197222797205928L, -50336L, false, false, (char) 20736, (char) 21408,
        Double.longBitsToDouble(0x3fb7a050f5073ca0L), Double.longBitsToDouble(0x3fd5d481fc06a2baL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 14, 15, "\uda1d\udf54\uc581\udb27\udfe6\000\000\ud897\udccb\u00df\udb92\udc64\\\ud90d\udda6\udaac\udf32\udb6e\udc96\u29d4\u2378", "", "",
        0, 96779, -913557252, 4355531523194093708L, -100000L, false, false, (char) 49663, (char) 39940,
        Double.longBitsToDouble(0x3fd4f068f881eebeL), Double.longBitsToDouble(0x3fb7a050f5073ca0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 14, 15, "\uda2e\udf54\udacc\udfed\udb27\udfe6\ud49f\000\ud8d5\udecb\u00df\000\ud9b8\ude5b\ud91b\udeb8\udaac\udf32@\000\udba5\udc32\udaff\ude57\ud953\ude95\udb4b\udf9c\udbb9\udd77\udbe1\ude07\000", "\ua236\ua7d0\ua963", "\udbfc\udfef",
        9, 36480, -409708450, 5197082090777985373L, 80557L, false, false, (char) 2965, (char) 65156,
        Double.longBitsToDouble(0x3fc8edf747e9b394L), Double.longBitsToDouble(0x3fea2104dddc10daL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 13, 9, "\uda2e\udf99\udabd\udcfb\ud811\udcda", "\u81c4\u23fc", "\ud94b\udc9d\udba4\udcec\uda8d\udff8\ud87a\udf55\udbad\udfaa\udaff\ude57\ud953\ude95",
        9, 74248, -984355701, -6961114269000910596L, 76311L, true, false, (char) 11755, (char) 48989,
        Double.longBitsToDouble(0x3fe52883f58dc077L), Double.longBitsToDouble(0x3fb3c1b9e207baf8L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 0, "\000\udacc\udfb1\ud811\udcda", "\u81c4\u5e32", "\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\ude6b\udbad\udfaa\udaff\ude57\ud881\udf71\ud890\udc58\ud99f\udd76\udb50\udd15\uda26\uddc2\ud911\udfba\uda9c\uddd1\udbd7\udf9c\udb70\udf9b\udbdc\udd80\udb3c\udcbc\ud9f3\udee6\ud877\uddf5\udb4c\udfcc\udbe5\udcc7\uda35\udeed\ud832\udee0\ud84f\udd2c\ud961\udfd3\udaf2\udf2b\ud9e8\udf94\ud911\udc15\udbc5\udc7d\u08c7\udb98\uddeb\ud8a4\uddc1s\ud9b7\udedd\udb54\ude96\udb3c\udd2a\udbdc\udc83\udbdc\udf1f\ud8ea\udc4f\udbc2\udca9\ud843\udc8c\udaa5\ude89\udbe3\udf8c\uc476\000\udb18\udc0b\uda75\udfa6\udb84\udc28\udb8d\udf77\udad0\udcfa\udbb9\udf19\ud936\udccf\000\ud902\uddb1\ud84a\udfdc",
        26, 66544, -1876272424, -2632645661760251167L, -66455L, false, false, (char) 4348, (char) 32282,
        Double.longBitsToDouble(0x3fe8f292f63abfe3L), Double.longBitsToDouble(0x3fe6fda58ec2ef70L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 14, "\uda2e\udf54E\000", "", "\udb89\udf64\uda31\udec1\ud91b\udeb8",
        36, -1000, 1827308544, -4647675817607297031L, -62141L, false, false, (char) 55573, (char) 60615,
        Double.longBitsToDouble(0x3e48e89514000000L), Double.longBitsToDouble(0x3fc1879eb0acd01cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 14, "\000", "\u7573\u2fed\u2240", "\uda31\udec1\ud91b\udeb8\udba4\udcec\000\ud859\ude6b\udbad\udfaa\udaff\ude57\ud881\udf71\ud890\udc58\ud99f\udd76\udb15\udc8a\uda26\uddc2",
        -5, 6882, 872928396, 9098173029755236264L, -82592L, false, false, (char) 55713, (char) 42548,
        Double.longBitsToDouble(0x3fd5d481f27571c4L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 12, 12, 7, "\udbbe\ude2f", "\u473b\u0f3e\u93c7\uc9ea", "\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\ude79\udbad\udfaa\udaff\ude57\ud95e\ude79\udba7\udff0\ud99f\udd76\udb50\udd15\udbaf\udce5\uda56\udfe2\udb9d\udfbf\udbd7\udf9c\udb76\udd9b\udbdc\udd80\udb59\udcbc\ud9d8\udfac\uda16\udf47\ud91f\udf90\u0a17\uda35\udeed\ud832\udee0\udb1f\udd13\udaac\udd3a\udbb2\udcbd\udbc8\udd84\uda94\udef7\ud8bf\ude85\uda3b\udfcc\ud9fc\ude18\ud857\udf51\ud94a\udfc6\ud888\udd3e\ud867\udf5c\ud8c8\udec8\udafd\udd88\ud8d9\udf0d\udb76\udd63\udac5\udcf2\ud8b2\uddb4\ud97a\udf44\udb6b\udcd1\ud986\udebc\uda22\ude54\ud8b7\ude54\ud903\udec2\ud874\udf03\ud84f\udc3d\udab2\udd1b\uda01\udcc5\udb76\udf6c\ud95a\udf17\ud924\udf98\ud823\uddd1\uda24\udf2e",
        -3, 79641, 692229773, -2677384268737587096L, -14766L, false, true, (char) 53937, (char) 59827,
        Double.longBitsToDouble(0x3fb1779f8b3b1ff8L), Double.longBitsToDouble(0x3fc79da29f1926f8L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 13, 10, "\uda2e\udf4e\udacc\udfed\ud811\udcda", "\u81c4\u4df8", "\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\udf55\udbad\udfaa\udaff\ude57\ud953\ude95\udba8\udc62\ud99f\udd76\udb50\udd15\udabf\udd6d\udbaa\uddde\udb8b\ude76\udbd7\udf9c\udb76\udd9b\udbba\udf61\udb3c\udcbc\ud9f3\udee6\ud877\uddf5\udad9\udfcc\udbe5\udcc7\uda35\udeed\ud832\udee0\udb32\udefe\ud9e7\uded3\uda30\uddec\ud86f\udfc9\ud980\udf48\udaaf\udc55\udaaa\ude15\ud8b5\udd1c\udbb3\uddb7\udb1c\udff1\uda0d\udea7\u21c1\ud900\udddf\ud86f\udc1b\ud9fc\udd01\ud9e6\udee1\ud816\udf4f\udaf5\udf4e\ud83c\udfb6\udab6\udd9f\ud9fa\uddf7\ud875\ude38\udaba\udd01\udb10\udf7e\ud929\udd9a\ud90f\udda4\ud923\udc9a\ud91a\udeba\ud913\udeaf\ud86d\udd13\ud9e6\udcbb\uda64\udd63\ud93d\udcdd",
        26, 25235, 193342352, -3562345362425846795L, 23006L, true, true, (char) 247, (char) 56687,
        Double.longBitsToDouble(0x3fe130179ca633b5L), Double.longBitsToDouble(0x3fcc2700ec4dd8b4L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 2, "\007\000\000", "\u81c4", "\udaaf\udcec\udb32\uddb7\ud95a\udeba\ud945\ude4f\udb35\udeb1\udbad\udfa3\udaff\ude57\ud953\ude95\uda43\udc8f\udad5\udd90\udb31\udd29",
        44, 73412, 1014101208, 3749198914688076331L, 20892L, true, false, (char) 22020, (char) 19254,
        Double.longBitsToDouble(0x3fb03dd7fe040a18L), Double.longBitsToDouble(0x3fe5073ca15d481fL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 0, "", "", "",
        32, 89120, 11386079, 71203252028309504L, -100000L, false, false, (char) 1920, (char) 65447,
        Double.longBitsToDouble(0x3fefbd7e9000c347L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 2, "4\000\000", "\u81c4", "\uda31\udec1\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\udf55\udbad\udfaa\uda50\udcff\udb1b\udd74\udbb1\uddbb\ud99f\udd76\udb50\udd15",
        44, 73412, 1014101208, 3749198914688076331L, 20892L, true, false, (char) 22020, (char) 19254,
        Double.longBitsToDouble(0x3fb03dd7c2f40a18L), Double.longBitsToDouble(0x3fe5073ca15d481fL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud927\udd64\ud817\udc97\ud9ae\udf69\udb1b\udf82\uda17\udfca\ud821\udcec\\u83be\0121=void |a0=java.lang.StringBuilder:\ud927\udd64\ud817\udc97\ud9ae\udf69\udb1b\udf82\uda17\udfca\ud821\udcec\\u83be\012",
        Z.run(T, 2, 15, 15, 5, "\ud927\udd64\ud817\udc97\ud9ae\udf69\udb1b\udf82\uda17\udfca\ud821\udcec", "\ubc8f\u2095\uc610\u51e5\u8a96\u9602\u48c6\u52ed\u30d4\u27f2\u4305", "\ud9f3\udd67\ud846\udeaf",
        29, 98967, -2061404230, 5487203074460881852L, -58122L, false, true, (char) 33726, (char) 8667,
        Double.longBitsToDouble(0x3fee6dc357daf21bL), Double.longBitsToDouble(0x3fe8bcd7877a5a08L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 14, 15, "8\udacc\udf6c\udb27\udfe6\ud836\ude7e\u50a3\ud8d5\udfc0\udb4a\udc8c\ud86b\udd11\uda1c\ude87\udbbc\udfa8\udaac\udf32\ud89f\udde2\uda29\udd23\udbad\udfaa\udaff\ude57\ud953\ude95\udb4b\udf9c\udbb9\udd77\udbe1\ude07\uda30\udec1", "\ua236\u7e54\u99fd\ub407\u6f58", "\udbe5\udcc7\uda35\udeed\ud832\udee0\uda09\ude28\ud81b\udf08\ue02c\ud9ab\udf19\ud926\udce9\uda53\ude36\udb59\udf31",
        4, 49764, 759260, 1080863910030505083L, -40461L, false, true, (char) 10615, (char) 51794,
        Double.longBitsToDouble(0x3fdd038eb2995402L), Double.longBitsToDouble(0x3fe6f69354762f31L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 14, 15, "\000\000\000\000\u50a3\ud8d5\udfc0\udb4a\udc8c\udb92\udc64\uda31\udec1\ud91b\udeb8\udaac\udf32\ud89f\udde2\uda29\udd23\udbad\udfaa\ud88d\udffe\udbf2\udf39\udb4b\udf9c\udbb9\udd77\udbe1\ude07\udbe0\udc78", "\ua236\ua7d0\ua963", "\udbfc\udfef",
        26, 60096, -409708450, 5197082090777985373L, 80736L, false, false, (char) 2965, (char) 46468,
        Double.longBitsToDouble(0x3fc8edf740000000L), Double.longBitsToDouble(0x3fe80000050010daL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 14, 15, "\u65fb", "\u92b4\u2f54\u827a", "\uda31\udec1\ud91b\udeb8\udaac\udf32\ud89f\udde2\uda29\udd23\udbad\udfaa\udaff\ude57\ud953\ude95\udb4b\udf9c\udbb9\udd77\udbe1\ude07",
        9, 87748, 1008366552, 3749198914689176875L, -3814L, true, false, (char) 39940, (char) 22494,
        Double.longBitsToDouble(0x3fb03dd7c2f40a18L), Double.longBitsToDouble(0x3fe5073ca15d481fL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 0, 15, "\000\000\udb0d\udc26\ud836\ude7e\u50a3\000\000\000\000\ud91b\udea6\udaac\udf32\ud89f\udde2\ud813\udc1d\uda18\udf7f\uda33\ude59\000\000\udbb9\udd77\udbe1\ude07\u5073", "\ua236\ua7d0\ua963", "\udbfc\udfef",
        26, 60096, 22622, 5197082090777985373L, 96429L, false, false, (char) 2965, (char) 65156,
        Double.longBitsToDouble(0x3f3bee8fd3600000L), Double.longBitsToDouble(0x3fea2104dddc10daL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 14, 0, "\ud9e2\uddd0G\ud8f9\udc1c\ud836\udddf\u50a3\ud900\udc75\ud9e0\udec0\udb92\udc64\uda31\udec1\ud91b\udeb8\ud985\udee0\ud89f\udde2\uda29\udd23x", "\ub215", "\000",
        35, 60208, 872928396, 9098197222797205928L, -50336L, false, false, (char) 20736, (char) 21408,
        Double.longBitsToDouble(0x3fb7a050f5073ca0L), Double.longBitsToDouble(0x3fd5d481fc06a2baL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 10, 10, 13, "\016\ud93e\udc0a\ud8d6\ude63\udba9\udfb0\u50ba\ud89f\udf0b\udad0\udc8f\udb97\udc2a\uda31\udeda\ud91b\udeb8\udb9c\uddf1\uda8d\udff8\ud87a\ude6b\udbad\udfaa\ud8cb\udfc7\ud9bc\udfee\ud890\udc58\ud803\udd8f\udb50\udd15\uda26\uddc2\ud911\udfba\ud87d\ude41\uda7c\udeb8\ud98f\udf79\uda43\uddef\udb3c\udcbc\udb6b\udee2", "\u560a\u6b6c\u4c1b\u0514\u950d\ub9f8\u77f2\u2cf1\u520e\u08c7\u2ef0\u38d4\u76a5", "\udb3c\udd2a\ud9e4\udf1d\udbba\udcc7\ud8ea\udc29\udbbf\udfa9\ud843\udc8c\udaa5\ude89\ud921\udf8b\uc476\000\ua194\uda33\udf0c\udb02\udd46\udb8d\udf77\udad0\udcfa\udbb9\udf19",
        46, -1000, -941589248, -8954911776245797160L, 54328L, false, false, (char) 30295, (char) 16556,
        Double.longBitsToDouble(0x3fe84df0020c17dcL), Double.longBitsToDouble(0x3fe236d5aecddf4dL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 12, 12, 7, "\udbbe\ude2f", "\u473b\u0f3e\u93c7\uc9ea", "\ud91b\udeb8\udba4\udcec\uda8d\udff8\uda70\udc95\uda9a\udfdc\udb2b\ude02\ud934\udd87",
        25, 74300, -984355701, 6657771003577744111L, 10504L, false, true, (char) 9313, (char) 37086,
        Double.longBitsToDouble(0x3fe6dd06498fc824L), Double.longBitsToDouble(0x3fb7a050f5073ca0L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 2, "4\ud923\udcd1\u00f4", "\u81c4", "\uda31\udec1\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\udf55\udbad\udfaa\uda50\udcff\udb1b\udd74\udbb1\uddbb\ud99f\udd76\udb50\udd15",
        44, 73412, 1014101208, 3749198914688076331L, 20892L, true, false, (char) 22020, (char) 19254,
        Double.longBitsToDouble(0x3fb03dd7c2f40a18L), Double.longBitsToDouble(0x3fe5073ca15d481fL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 0, 0, 0, "4", "", "\ud89f\udf0b",
        15, 69267, 682333276, -2873796760937706859L, 64864L, false, true, (char) 51065, (char) 23673,
        Double.longBitsToDouble(0x3fd50288dd39868eL), Double.longBitsToDouble(0x3fc17d915dd3154cL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 0, 4, 0, "4", "", "\uda57\udf07",
        40, 57392, 682333276, -2873796760937706859L, -2954L, false, true, (char) 51065, (char) 8203,
        Double.longBitsToDouble(0x3fd87dc0cd39868eL), Double.longBitsToDouble(0x3fc17d915d52814cL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 1, 12, 3, 2, "\uda2e\udf54\udacc\udfed\udb72\udeab", "\u81c4\u2fda", "\ud91b\udeb8\udba4\udcec\uda8d\udff8\ud87a\udf55\udbad\udfaa\udaff\ude57\ud953\ude95\udba8\udc62\ud99f\udd76\udb50\udd15\uda26\uddc2\ud9e3\uddc6\udb9e\udc67\udbd7\udf9c\udb76\udd9b\udbe4\udf9d\udb12\ude53\ud9f3\udee6\ud877\uddf5\udb4c\udfcc\udbe5\udcc7\uda35\udeed\ud832\udee0\u228b\ud961\udfcb\udaf2\udf2b\ud9e8\udf94\ud911\udc15\udbc5\udc7d\udb59\udf31\udbce\udfe5\ud8a4\uddc1\uda5c\udeae\ud9b7\udedd\udb54\ude96\udb3c\udd2a\udbdc\udc83\udbdc\udf1f\ud8ea\udc4f\udbc2\udca9\ud843\udc8c\udaa5\ude89\udbe3\udf8c\udbc1\udd7d\ud98a\ude8e\udb2e\udca3\uda75\udfa6\udb84\udc28\ud9a0\udfc1\ud944\udf7a\udbb9\udf19\ud936\udccf\ud932\udd09\ud8ef\udcdc\ud841\udcc7\udadc\udfde",
        24, 3576, -612960584, 1102989251203772766L, 876L, false, false, (char) 26953, (char) 18832,
        Double.longBitsToDouble(0x3fe1d5ff1b968eb1L), Double.longBitsToDouble(0x3fe61778dd1a96a5L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 5, 5, 3, "\uda42\udeb5\uda41\udd08\udb07\udfac", "\u96e7\u5ce0", "\uda4b\udec2\udba4\udcec\ud91d\udf90\ud8ea\ude7c\ud989\udf22",
        32, 44495, -1271899172, -5426470771526954115L, 98404L, true, false, (char) 4349, (char) 2644,
        Double.longBitsToDouble(0x3fe64f421f2def82L), Double.longBitsToDouble(0x3fe9e2bd5c2af3e0L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 14, "\uda2e\udf54E\000\000\000\ud8c5\udcc2\udad0\udc8f\udb89\udf64\uda31\udec1\ud91b\udeb8\udba4\udcec\000\ud99a\udf1c\udbbe\uded7\udaff\ude57\ud881\udf71\ud875\uddce\udbc8\udfa5\ud9a0\udd95\udbd8\ude09\ud927\udeb9\uda79\udde2\udb2e\udea0\uda1c\udf92\udafe\ude0b\ud85d\udc4f\ud84f\uddbb\udac2\uddec\udb1f\udfd0\uda22\udf4b\udae0\udc9c\udbd7\ude3b\udad9\udf21\udb91\ude34\uda7e\udeeb\udbf2\udf6d\uda7e\udffd\ud9c1\udd5a\ud832\udca4\ud8e3\udc2c\udbdd\ude86\ud957\udeda\uda38\ude7d\udbae\udd9b\ud8d9\ude32\ud8fb\ude53\ue3a4\ud931\udcb3\uda0a\uddfb\ud8fc\udffe\ucefd\udb96\ude54\udb36\udc31\udad1\udd7d\u0769\udaf3\udc12\ud84a\udec5\uda31\udd00\ud8f7\udf45\udb2f\udc46\uda54\udd3b\ud97c\udc71\ud911\udc2d\udbc5\udf04\ud829\udcb0\uda47\udcf4\uda3b\udda8\ud942\udcd3\ud85c\udd19", "\uacc1\u34db\u3b74\u4637\ub08d\u6eff\ub2f5", "\uda1a\udc54",
        2, 43406, 728571474, -1185562962710454957L, 36254L, false, true, (char) 21552, (char) 51541,
        Double.longBitsToDouble(0x3fd796af253d450cL), Double.longBitsToDouble(0x3fd0ff3caa69ace2L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 14, "\ud860\udf4dE\000\udad0\udc07\000\ud8c5\udcc2\udad0\udc8f\udb89\udf64\uda31\udec1\ud91b\udeb8\udba4\udcec\000\udab9\udd4b\ud807\udcb8\udaff\ude49\ud881\udf71\ud99a\udda0\ud969\udd7d\ud98d\udce5\udbd8\ude09\ud927\udeb9\uda79\udde2\udb2e\udea0\ud9ca\udf89\udafe\ude0b\ud85d\udc4f\ud84f\uddbb\udbe2\udc9c\udb0c\udf93\uda33\udc24\udae0\udc9c\udbd7\ude3b\udad9\udf21\udb91\ude34\uda7e\udeeb\udbf2\udf6d\uda7e\udffd\ud9c1\udd5a\ud832\udca4\ud8e3\udc2c\udbdd\ude86\ud957\udeda\uda38\ude7d\udbf6\udd9f\ud8d9\ude32\ud8fb\ude53\uda2c\udffe\udb0b\udcb0\uda0a\uddfb\ud8fc\udffe\ucefd\udb76\udc44\ud8c5\udcc5\uce73\ud809\udc59\udbef\udd18\ud84a\udea7\uda31\udd00\ud8f7\udf45\udb2f\udc46\uda54\udd3b\ud97c\udc71\ud911\udc2d\udac4\udf24\udac0\udfcc\ud923\udfde\uda3b\udda8\ud942\udcd3\ud85c\udd19", "\uacc1\u34db\u3b74\u4637\ub08d\u3b71\ua1c3", "\uda1a\udc28\udb67\udc70\ud8bb\udc09\ud868\udce1\udb11\udfcb\ud976\uddd9\udae8\udc16",
        1, 56572, -1691197980, 7706272638674848121L, 86097L, false, true, (char) 23788, (char) 13956,
        Double.longBitsToDouble(0x3fbc602ef6f87cf8L), Double.longBitsToDouble(0x3fad21623f633bf0L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 2, "41\000", "\u81c4\u4df8\u4369\ubc8f\u41cd\u4228\u4e86\u7600\u0706\u449a\ud320\u6158\u0f8c\u1701\ub4f4\u3072\ub67a\ua236\u369a", "\ud9f3\udecb\ud877\uddf5\udb4c\udfcc\ud3ef\uda45\udf3d\ud832\udee0\udaa4\uddd6\u39be\udbe5\ude81\udba4\udec8\uda62\udd3e\ud8f8\udc6a\ud912\udf1e\ud9ad\ude8b\ud8e0\udfba\ud832\udfab\ud8e2\udffe\ud81a\ude89\ud9c0\udda5\ud821\udcbd\ud830\udf63\ud95f\udf13",
        1, 98871, 72609709, -7395765675932834297L, -91838L, true, false, (char) 21620, (char) 59165,
        Double.longBitsToDouble(0x3fd911540abacc7eL), Double.longBitsToDouble(0x3fea7a83f81df1a2L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 14, "\ud860\udf4dE\000\udad0\udc07\000\ud8c5\udcc2\udad0\udc8f\udb89\udf64\uda31\udec1\ud91b\udeb8\udba4\udcec\000\udab9\udd4b\ud807\udcb8\udaff\ude49\ud881\udf71\ud99a\udda0~\ud98d\udce5\udbd8\ude09\ud927\udeb9\uda79\udde2\udb2e\udea0\ud9ca\udf89\udafe\ude0b\ud85d\udc4f\ud84f\uddbb\udbe2\udc9c\udb0c\udf93\uda33\udc24\udae0\udc9c\udbd7\ude3b[\ud90c\udd66\uda7e\udeeb\udbf2\udf6d\uda7e\udffd\ud9c1\udd5a\ud832\udca4\ud8e3\udc2c\udbdd\ude86\ud957\udeda\uda38\ude7d\udbf6\udd9f\ud8d9\ude32\ud8fb\udd9e\uda2c\udffe\udb0b\udcb0\uda0a\uddfb\ud8fc\udffe\ucefd\udb76\udc44\ud8c5\udcc5\uce73\ud809\udc59\udbef\udd18\ud84a\udea7\"\000\udb2f\udc46\uda54\udd3b\ud97c\udc71\ud911\udc2d\udac4\udf24\000\ud923\udefc\uda3b\udda8\ud942\udcd3\ud85c\udd19", "\uacc1\u34db\u3b74\u4637d\000\000", "\uda1a\udc28\uda61\udc6d\ud8bb\udc09\ud868\udce1\udb11\udfcb\ud976\uddd9\udae8\udc16",
        1, 56572, -1691197980, 7706272640243124601L, 86097L, false, true, (char) 23788, (char) 13956,
        Double.longBitsToDouble(0x3fbc602ef6f87cf8L), Double.longBitsToDouble(0x3fad21623f633bf0L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 0, "\uda1d\udf4dE\000\000\000\ud8c5\udcc2\udaa1\udc8f\udb89\udf64\uda31\udec1\uda17\udeb6\udba4\udcec\000\ud99a\udf1c\udbbe\uded7\udaff\ude57\ud881\udf71\ud875\uddce\ud9b5\udd5b\000\000\u1189\000\ud90a\udc04\000\000\u1884\ud84f\uddbb\udac2\uddec\udb1f\udfd0\uda22\udf4b\udae0\udc9c\udbd7\ude3b\udad9\udf21\udb91\ude34\uda7e\udeeb\udbf2\udf6d\uda7e\udffd\ud9c1\udd5a\ud832\udca4\ud8e3\udc2c\u00bf\ud94f\ude46\uda38\ude7d\udbae\udd9b\ud8d9\ude32\ud8fb\ude53\ue3a4\ud931\udcb3\uda0a\uddfb\ud8fc\udffe\ucefd\udb96\ude54\udb36\udc31\udad1\udd7d\u0769\uda5f\udc08\ud84a\udec5\uda31\udd00\ud8f7\udf45\udb2f\udc46\\\000\000\000\000\000\000\ud942\udcd3\000", "", "\ud85f\ude67\ud8e4\udef6\udabf\ude19\udbf3\udc13\udadc\udd27\ud867\udf6f\ud914\ude21\uda1a\udc54\udb67\udc70\u4a36\ud868\udce1",
        29, -1000, -310552274, 1806484143845606908L, 19261L, true, false, (char) 0, (char) 7386,
        Double.longBitsToDouble(0x3fd34d671d1af02cL), Double.longBitsToDouble(0x3fd95b595194d856L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 0, 15, "\000\000\000\000\000\000\000\000\000\000\udaac\ude9d\ud89f\udde2\ud813\udc1d\uda18\udf7f\uda33\ude59\000\000\udbb9\udd77\udbe1\ude07\u5073", "\ua236\ua7d0\ua963", "\udbfc\udfef",
        26, 60096, 22622, 5197082090777985373L, 78181L, true, true, (char) 28602, (char) 17914,
        Double.longBitsToDouble(0x3fea2104dddc10daL), Double.longBitsToDouble(0x3fe3030bbf913646L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 0, 0, 0, "43", "\u2fed\u81c4", "\udbfa\ude46\udac8\ude85\udba4\udc95\ud9be\ude90\ud872\udc88\udbad\udfaa\uda50\udcff\udb1b\udd74\uda6a\ude78\udb13\udc6f\udb50\udd63",
        41, 33218, 299478649, 269023953633878705L, -75169L, true, false, (char) 24738, (char) 59688,
        Double.longBitsToDouble(0x3fa0c7a0c43c88b0L), Double.longBitsToDouble(0x3fe612c1be8bd412L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 13, 10, "43", "\u80e8", "\udb92\udc64\udbfa\ude46\ud9b2\udc78\ud913\udc5d\ud9be\ude90",
        7, 44235, 292030457, 2922074267672209744L, 84306L, true, false, (char) 54708, (char) 9836,
        Double.longBitsToDouble(0x3fecb2435f01d73fL), Double.longBitsToDouble(0x3fe01aa719b866eaL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.CodeGenerator|isSimpleNumber|java.lang.String|static",
    "M|com.google.javascript.jscomp.CodeGenerator|add|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|add|com.google.javascript.rhino.Node,com.google.javascript.jscomp.CodeGenerator$Context|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|add|java.lang.String|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addAllSiblings|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addArrayList|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addCaseBody|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addExpr|com.google.javascript.rhino.Node,int,com.google.javascript.jscomp.CodeGenerator$Context|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addIdentifier|java.lang.String|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addJsString|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addList|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addList|com.google.javascript.rhino.Node,boolean|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addList|com.google.javascript.rhino.Node,boolean,com.google.javascript.jscomp.CodeGenerator$Context|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addNonEmptyStatement|com.google.javascript.rhino.Node,com.google.javascript.jscomp.CodeGenerator$Context,boolean|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|appendHexJavaScriptRepresentation|int,java.lang.Appendable|static",
    "M|com.google.javascript.jscomp.CodeGenerator|appendHexJavaScriptRepresentation|java.lang.StringBuilder,char|static",
    "M|com.google.javascript.jscomp.CodeGenerator|isSimpleNumber|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
