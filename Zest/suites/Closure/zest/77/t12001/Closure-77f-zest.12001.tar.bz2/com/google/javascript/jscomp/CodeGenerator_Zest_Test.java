package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class CodeGenerator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 10, 0, "\ud934\udf7d\ud975\ude5b\udbbe\ude1c\ud815\udf45\ud865\uded5\uda72\udef9", "\ucfa3\u3037\u7ef6\u8a89\u8edd", "\ud92e\udc7a\uda16\udeb8\ud9ec\ude87\udb68\udd4a\ud94d\udd00",
        51, 47273, -653449614, -8252875217371386176L, 23453L, true, false, (char) 65339, (char) 7744,
        Double.longBitsToDouble(0x3fd02ae7d261b978L), Double.longBitsToDouble(0x3fed3630d3c789a1L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 10, 0, "\ud934\udf7d\ud975\ude5b\udbbe\ude1c\ud815\udf45\ud865\uded5\uda72\udef9", "\ucfa3\u3037\u7ef6\u8a89\u9660", "\uda44\ude86\uda16\udeb8\ud9ec\ude87\udb68\udd4a",
        18, 53846, -1068733727, -2806544723635345993L, 73390L, true, false, (char) 56586, (char) 9216,
        Double.longBitsToDouble(0x3feba1ec66229a42L), Double.longBitsToDouble(0x3fe95aa6e6a1e66bL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 10, 0, "\ud870\udf61\ud975\ude5b\udbbe\ude1c\ud815\udf45\ud865\uded5", "\u4abe\ucfa3", "\u1b1a\udafd\udd20\ud896\ude94\ud97b\udcd7\ud92e\udc7a\uda16\udeb8\ud9ec\ude87\udb68\udd4a\ud94d\udd00\uda69\uddd0\ud911\udf1c\ud973\udc26\udb43\udefc\ud9e8\udced\ud87c\ude56\udbe2\udd11\udb5c\udf2d\u0324",
        47, 48551, -971362000, -8529448644851883065L, 20889L, false, false, (char) 16189, (char) 5294,
        Double.longBitsToDouble(0x3fca3384c5f01264L), Double.longBitsToDouble(0x3fa7818644e886d0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:\u1007\\ud934\\udf7d\\udba3\\ude74\\udbbe\\ude1c\\ud828\\udf2d\\ud89a\\udd56\\uda75\\udefd\\ud8f0\\ude46\\u72b9\\uda89\\udef6\\udb35\\udf95\\ud9cb\\udcdc\\ua4b0\\udb8c\\udcd8\\ud896\\uddab\u1007\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 12, "\ud934\udf7d\udba3\ude74\udbbe\ude1c\ud828\udf2d\ud89a\udd56\uda75\udefd\ud8f0\ude46\u72b9\uda89\udef6\udb35\udf95\ud9cb\udcdc\ua4b0\udb8c\udcd8\ud896\uddab", "\ua7f7\u7d24\u65b4\u3f27\u2a16\u1f61\u6848", "\ud87c\ude56\ud967\udd42\udb5c\udeab\ud85c\udc22\ud91d\udeda\u22ee\udaec\udf5f\udac3\udf8e",
        28, 84026, -2088581348, -1911270651291130136L, 49524L, false, true, (char) 4103, (char) 3782,
        Double.longBitsToDouble(0x3fe1cfcb51dd825bL), Double.longBitsToDouble(0x3fe298b7cc809440L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 12, "\ud891\ude12\udacc\udc64\udbbe\ude1c\ud815\udf45\ud8ba\ude9f\uda72\udf7c", "\uc7d5\u3100\u7ef6\u8a89\u7c3d", "\udbfb\udea0\uda16\udeae\ud9ec\ude87\udb68\udd4a\ud94d\udd00\ud85d\udf7c\udbd7\udf1f",
        -4, 943, -1112408827, 7362478100051745251L, 76218L, true, true, (char) 7905, (char) 4737,
        Double.longBitsToDouble(0x3fb067d558794be8L), Double.longBitsToDouble(0x3fe1897d6007f324L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 10, 0, "\ud99f\udfca\ud9f6\udedd\udbbe\ude1c\ud815\udf45\ud865\udee2\uda6a\udff9", "\ucfa3\u3037\u95f6\u52ee\u8edd", "\ud92e\udc7a\uda49\udfc5\ud9ec\ude87\udb68\udd4a\udbe6\udd4e",
        30, 31087, 1464991389, 912799974139284153L, 6922L, true, false, (char) 65339, (char) 47958,
        Double.longBitsToDouble(0x3fd4c6b9dd4bb978L), Double.longBitsToDouble(0x3fed3630d3c789a1L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 0, "\ud934\udf7d\ud975\ude5b\udbbe\ude1c\udb65\ude2d\udb36\udd3f\uda72\udf11", "\ucfa3\u3e7f\u3541\ucf24\u87dd", "\ud92e\udc7a\uda16\udeb8\ud9ec\ude87\udb68\udd4a\ud94d\udd00",
        51, 47273, -653449614, -8252875217013854784L, 23453L, true, false, (char) 65339, (char) 7744,
        Double.longBitsToDouble(0x3fd02ae7d261b978L), Double.longBitsToDouble(0x3fed3630d3c789a1L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:\uff3b\\ud934\\udf7d\\u00c7\\udb9e\\udf4e\\ud815\\udf45\\ud865\\uded5\\uda72\\udef9\uff3b\0121=java.lang.String:\uff3b\\ud934\\udf7d\\u00c7\\udb9e\\udf4e\\ud815\\udf45\\ud865\\uded5\\uda72\\udef9\uff3b\012",
        Z.run(T, 2, 0, 0, 0, "\ud934\udf7d\u00c7\udb9e\udf4e\ud815\udf45\ud865\uded5\uda72\udef9", "\ucfa3\u3037\u7ef6\u8a89\u8edd", "\ud92e\udc7a\uda16\ude28\ud833\ude2b\udb68\udcfa\ud94d\udd00",
        51, 47273, -653449614, -8252875217371386176L, 23392L, true, false, (char) 65339, (char) 7744,
        Double.longBitsToDouble(0x3fd02ae7d261b978L), Double.longBitsToDouble(0x3fc4d8c34f1e2684L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 10, 0, "\ud934\udedb\ud975\ude5b\udbbe\ude1c\ud815\udf45\ud865\uded5\uda72\udef9", "\ucfa3\u3037\u7ef6\u8a89\u8edd", "\ud92e\udc7a\ud86a\udf22\ud9ec\udef2\udb68\udd4a\ud8cb\udcc0\ud8c8\udd90\ud862\udd5d\ud840\ude05\ud839\ude93\ud9e8\udced\ud87c\ude56\udbe2\udd11\udb5c\udf2d\u0324\ud91d\udeda\u22ee\ud9f9\uddc6\ud8a0\udcac\uda62\uddc5\udb93\udc0e\udbfd\uddde\ud9a8\udf31\uda95\udc69\ud842\udcf6\udbe3\udf4e\udaea\uddfd\ufc88",
        56, 1389, -1894951171, -7952760955250960168L, 83705L, true, false, (char) 22546, (char) 59063,
        Double.longBitsToDouble(0x3fcfa2e6c9962f78L), Double.longBitsToDouble(0x3fdf637724eb3ac0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 10, 2, "\udabc\udf81\ud975\ude5b\ud9ac\ude1b\ud815\udf45\ud865\uded5\uda72\udef9\ud9b8\ude4a", "\u3037\u7ef6", "\ud896\ude94\ud97b\udcd7\ud92e\udc7a\uda16\udeb8\uda17\udf07\udb5f\udd09\ud94d\udd00\uda69\uddd0\ud889\udd27\ud973\udc26\ud839\udef7\ud9e8\udced\udafa\udc4f\uda6b\udc54\ud9ee\udd9f",
        6, 90752, -591608574, 1203096822401290150L, 92157L, false, false, (char) 58502, (char) 22060,
        Double.longBitsToDouble(0x3fcc53d5c1c8cf4cL), Double.longBitsToDouble(0x3fd75cd03198774aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 9, 0, "\udbf8\udc5a\ud975\uddd0\udbbe\ude1c\ud901\uddd4\ud9f8\udcb6\uda5e\uddb7", "\uad56\ub4d1\ud3f9\u13cc\u095f", "\ud836\udd7b\u349a\udb73\udeab\ud9cd\ude3c\ud96e\udfb1",
        51, 48297, -1337252238, -8252916204244291904L, 78946L, true, false, (char) 10326, (char) 58984,
        Double.longBitsToDouble(0x3fd022db9261b978L), Double.longBitsToDouble(0x3fed3630d451eba1L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 10, 0, "\uda1d\ude68\ud975\ude5b", "\u70e1", "\ud9a1\udf0f\uda86\udd0b",
        43, 11825, 858490262, 1646676750230818795L, -97915L, false, true, (char) 16913, (char) 5491,
        Double.longBitsToDouble(0x3fa4eedc20652260L), Double.longBitsToDouble(0x3fe70dc4b672c04cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 0, "\ud933\udd69\ud8f7\udc3c\udbbe\ude1c\ud815\udf45\ud865\uded5\uda72\udef9", "\ucfa3\u3037\u7ef6\u8a89\u8edd", "\ud919\udf7b\uda16\udeb8\ud9ec\ude87\udb68\udd4a\ud94d\udd00\uda69\uddd0\udbd7\udf1f\ud973\udc26\ud839\udef7\ud8f5\udef3\ud944\udf2a",
        47, 2213, 983064358, 8679531216971656160L, 76218L, true, true, (char) 43336, (char) 156,
        Double.longBitsToDouble(0x3fe899158df2a778L), Double.longBitsToDouble(0x3fe078ee516d494bL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 9, 0, "\ud8e6\udcf9\udae2\udfe6\ud838\ude08\uda8a\uddf1\ud865\uded5\uda72\udef9", "\ua4a5\u3683\u3b7f\u14f4\u8edd", "\uda09\ude88\uda16\udeb8\ud9ec\ude87\uda95\uddef\udba0\udf9e",
        27, 32473, -653417737, -3797467368352870455L, 38691L, false, true, (char) 20660, (char) 7744,
        Double.longBitsToDouble(0x3fd02ae7d155b978L), Double.longBitsToDouble(0x3fb97186897c3870L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\uff3b\\ud934\\udf7d\\ud975\\ude5b\\udbbe\\ude1c\\ud815\\udf45\\ud865\\uded5\\uda72\\udef9\uff3b\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 0, "\ud934\udf7d\ud975\ude5b\udbbe\ude1c\ud815\udf45\ud865\uded5\uda72\udef9", "\ucfa3\u3037\u7ef6\u00e4\u6315", "\ud92e\udc7a\uda16\udeb8\ud9ec\ude87\ucb50\000",
        -5, 30736, -653449728, -8252875217371386176L, 23453L, true, false, (char) 65339, (char) 7744,
        Double.longBitsToDouble(0x3fd000000261b978L), Double.longBitsToDouble(0x3fed3630d3c789a1L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:\uff3b\\ud934\\udf7d\\ud975\\ude5b\\0\\u728f\\ud865\\uded5\\uda72\\udef9\uff3b\0121=java.lang.String:\uff3b\\ud934\\udf7d\\ud975\\ude5b\\0\\u728f\\ud865\\uded5\\uda72\\udef9\uff3b\012",
        Z.run(T, 2, 0, 0, 0, "\ud934\udf7d\ud975\ude5b\000\u728f\ud865\uded5\uda72\udef9", "\ub2a3\u6136\u244c\u8500\u1213", "\ud92e\udc7a\uda16\udeb8\ud9ec\ude87\udb68\udd4a\ud94d\udd00",
        45, 19912, -653449614, -8252875217975377920L, 23453L, true, false, (char) 65339, (char) 15168,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e3e3c4d08000000L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 7, 11, "\udbd2\udce5", "\u2fab\uae93\u61bd\u7af5\ucec0\ucfd6\u3037\u7ef6\u89a6\u8edd\u7c8a", "\ud9fe\udf83",
        0, 12353, -328765239, -6082584062062728479L, -93102L, false, false, (char) 11684, (char) 12277,
        Double.longBitsToDouble(0x3fe753ee5fb06d83L), Double.longBitsToDouble(0x3fdee7b91b2864faL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 5, 12, 12, "\ud934\udf7d\ud975\ude5b\udbbe\ude1c\ud815\udf45\ud865\uded5\uda72\udef9", "\ucfa4\u3037\u7ef6\u3ee0\u8edd", "\ud92e\udc7a\uda16\udeb8\ud9ec\ude87\uda58\ude79\udb1c\udeee",
        8, 65889, -653449614, -8252875217371386176L, 23453L, true, false, (char) 65339, (char) 7744,
        Double.longBitsToDouble(0x3fd02ae7d261b978L), Double.longBitsToDouble(0x3fed3630d3c789a1L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 0, "\ud935\udf6b\udac6\udd42\uda54\udc45\udbf4\ude92\ud8c7\udd05\uda72\udef9", "\ucfa3\u3037\u7ef6\u8a89\u8edd", "\ud92e\udc7a\uda16\udeb8\ud9ec\ude87\ud867\uddcf\udac0\udc64",
        1, 12713, 1851078964, -8252875848731578688L, 23453L, true, false, (char) 28179, (char) 7594,
        Double.longBitsToDouble(0x3fd02ae7dd97b978L), Double.longBitsToDouble(0x3febac7c10a789a1L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 15, 2, "\ud934\udf7d\ud975\ude5b\udbbe\ude1c\ud815\udf45\ud865\uded5\ud98b\udffc", "\u3a8d", "\udbea\udce7\udafd\udd20\ud896\ude94\ud97b\udcd7\udbf2\uddaf\uda16\udeb8\ud9ec\ude87\udb68\udd4a\ud94d\udd00\uda69\uddd0\udbd7\udf1f\ud805\udf28\ud839\udef7\ud9e8\udced\ud87c\ude56\udbe2\udd11\udb5c\udf2d\u0324",
        3, 48426, -971362000, -8529448642940918841L, -44640L, false, false, (char) 51915, (char) 51516,
        Double.longBitsToDouble(0x3fe0d3195181d3f0L), Double.longBitsToDouble(0x3fe5447b79e04b5cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:\u373d\\ud934\\udf7d\u373d\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 0, "\ud934\udf7d", "\u3f48\u70e1\u7fc0\u6c9e\000\000\000\000\000\u8e15\u00eb", "",
        8, 45633, 0, 5919542080413127174L, -100000L, false, false, (char) 14141, (char) 56586,
        Double.longBitsToDouble(0x3fe800045ba83a98L), Double.longBitsToDouble(0x3fd02ae7d261b978L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:\000\\u3aca\\0\\0\\0\\ud845\\udcc2\\uda72\\udef9\000\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 0, "\u3aca\000\000\000\ud845\udcc2\uda72\udef9", "\ucfa3\u3037\u7ef6\u8a89\u8edd", "\000\uda16\udeb8\ud833\ude02\000\ud8e2\udc02",
        -5, 26136, 0, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e3e380000000000L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 11, 11, 2, "\udb2e\udf60\ud973\udf4e\uda39\udd1a\ud815\udf45\ud865\uded5\uda72\udef9", "\u591f\u154b\u7e45\u8a89\u8edd", "\ud9c3\udd08\uda40\ude6c\ud9ec\ude87\ud91c\udd83\udbd8\udf77",
        -2, 62538, -643831801, -8252875217371386176L, 23453L, true, false, (char) 51301, (char) 62900,
        Double.longBitsToDouble(0x3fd02ae17661b978L), Double.longBitsToDouble(0x3fed3630d3c789a1L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 10, 0, "\ud80f\udd31\ud975\ude5b\udbbe\ude1c\ud815\udf45\uda69\udcbd\ud9c3\udd06\ud8ea\udf46\u72b9\uda89\udef6\udae9\udcce", "\u8edd\u7c8a\u9a1c\u2ed9\ua7f7\ube07\u7aaf\u5986\u5d62\u8f17\u68c7\u77f4\u6f11\u0281\u1abf\uae8b\u7522\u2947\ubbb3", "\ud8ab\udd85\ud8ec\ude75\ud94b\udfc2\uda3f\uddba\udb22\udfd1\uda44\udc0a\ud94c\udd16\u09aa",
        39, 84262, -294682044, 868891869155403768L, -97802L, true, false, (char) 50047, (char) 6845,
        Double.longBitsToDouble(0x3fea30fc2f9ce898L), Double.longBitsToDouble(0x3febe40feadf23dcL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 0, "\ud870\udf61\ud975\ude5b\uda08\udc42\ud92a\udf44\ud865\uded5", "\u4abe\ucfa3", "\u1be2\udafd\udd20\ud896\ude94\ud97b\udcd7\ud92e\udc7a\uda16\udeb8\ud9ec\ude87\udb68\udd4a\ud94d\udd00\uda69\uddd0\ud911\udf1c\ud824\udebf\ud866\udf19\ud9e8\udced\ud87c\ude56\uda4e\uddc7\udb5c\udf2d\u0324",
        47, 48551, -971362000, -8529448644851883065L, 20889L, false, false, (char) 16189, (char) 64414,
        Double.longBitsToDouble(0x3fca3384c5f01264L), Double.longBitsToDouble(0x3fa7818644e886d0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\ue40b\\ud842\\udee0\\ud975\\ude5b\\udbbe\\ude1c\ue40b\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 0, "\ud842\udee0\ud975\ude5b\udbbe\ude1c", "\u7fc0\u611c\u4abe\ucfa3\u3037\u7ef6\u24bc\u8edd\u7c8a\u9a1c\u2ed9\ua7f7\ube07\u7aaf\u5986\u5d62\u12f2\u41d6\u7e6b\u3a8c\u0281\u1abf\uae8b\u7522", "\ud9f9\uddc6\ud8a0\udcac",
        -5, 9880, 7460921, -7897343421860238122L, 96399L, false, true, (char) 58379, (char) 13499,
        Double.longBitsToDouble(0x3fe6d0fe7237bb7aL), Double.longBitsToDouble(0x3fb2e4a4b47b9030L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 8, 14, "\udb17\udfb3\ud9ec\udca5\udafe\udc3d\ud8b6\uddab\ud865\uded5", "\u4f68\u3c69\u299e", "\ud811\udd2b\ud896\ude94\ud97b\udcd7\uda1c\udf32\uda16\ude9d\ud9ec\ude87\ud8fe\udc89\ud93b\udc56\udb1b\uddc9\ud911\udf1c\ud932\udf37\udb43\udefc\ud9f4\ude25\ud87c\ude56\udbe2\udd11\udb06\udd01\uda1d\udeb1\ud9b3\udd9c\udb91\ude72",
        7, 53357, -1615667492, -2225044018882096173L, -36407L, true, true, (char) 40183, (char) 6421,
        Double.longBitsToDouble(0x3fa7818624e886d0L), Double.longBitsToDouble(0x3fee16fd36db5be4L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 8, "\ud851\ude61\ud975\ude5b\udbbe\ude1c\ud815\udf45\uda8d\ude28", "\u4abe\ucfa3", "\ud972\uddda\udb04\uddff\ud8cf\udf5d\ud97b\udd52\ud92e\udc7a\uda16\udeb8\ud9ec\ude87\udb68\udd4a\ud94d\udd00\uda69\uddd0\udaba\udcd1\ud973\udc8d\udbfa\ude57\ud91c\udd8e\ud824\ude88\udbe2\udd8e\udb5b\udf8c\u0324",
        53, 15615, 1998205232, -8529448868190182457L, 85107L, true, true, (char) 52087, (char) 5294,
        Double.longBitsToDouble(0x3fca3384c5f01264L), Double.longBitsToDouble(0x3fec340dd34e886dL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 9, 4, "\ud9bb\udcc7\uda25\ude40\udbbe\ude4a\udb0b\udf80\udba7\udfe0\ud953\ude61\uda42\udd72\ud93c\udd1a\ud9f0\udf01\udad7\uddf3\uda1e\ude25\uda5a\udc01\ud8f7\udffc\uda02\uddae\udbcc\udf07\ud8bf\udfd3", "\u7aaf\ubf52\u8934\u6362\u8a06\u2268\ubcee\u8c5c\ua162\u82b5\u5d30\u6d33\u4586\u146a\u0b5b\u8d07\u6883\u2a38\u76c0\u99f8\u53bf\ud5e7\u2519\u9677\u3d08\u1093\u9de0\u418d\u4f6c\u162a\u2d10\u37b6\ub16f\u07e3\u8aeb\u4b37", "\ud92f\uddab",
        24, 69292, 682133982, 7804090858185992017L, -21507L, true, false, (char) 64453, (char) 54764,
        Double.longBitsToDouble(0x3fe1317b1f9800bbL), Double.longBitsToDouble(0x3fe109c937131957L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:\000\\u3aca\\udb04\\udc01\\0\\0\\ud879\\udd9c\\u6d11\\0\\0\\0\\0\\0\\udbec\\udeb5\\udb8c\\udcd8\\ud896\\uddab\000\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 0, "\u3aca\udb04\udc01\000\000\ud879\udd9c\u6d11\000\000\000\000\000\udbec\udeb5\udb8c\udcd8\ud896\uddab", "\ua7f7\u7d24\u65b4\u3f27\uc76b\000\000", "\ud87c\ude56\ud967\udd42\uda8c\udea3\ud962\udf05\000\000\000\udac3\udf27",
        28, 49706, 0, 0L, -99980L, false, true, (char) 0, (char) 56576,
        Double.longBitsToDouble(0x3fe1cfcb51dd825bL), Double.longBitsToDouble(0x3fe298b7cc809440L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String:\u1007\\ud934\\udf7d\\udba3\\ude74\\u7ece\\0\\ud89a\\udd56\\uda75\\udefd\\ud8f0\\ude46\\u72b9\\udb49\\udd35\\udb35\\udf65\\ud9cb\\udcdc\\ua4b0\\udb8c\\udcd8\\ud896\\uddab\u1007\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 12, "\ud934\udf7d\udba3\ude74\u7ece\000\ud89a\udd56\uda75\udefd\ud8f0\ude46\u72b9\udb49\udd35\udb35\udf65\ud9cb\udcdc\ua4b0\udb8c\udcd8\ud896\uddab", "\ua7f7\u7d24\u65b4)\ub38d\u1f61\u6848", "\ud87c\ude56\ud967\udd42\udb5c\udeab\u32fb\ud91d\udeda\u22ee\udaec\udf5f\udac3\udf8e",
        28, 84026, -2088581348, -1911270651291130136L, 49524L, false, true, (char) 4103, (char) 3782,
        Double.longBitsToDouble(0x3fe1cfcb51dd825bL), Double.longBitsToDouble(0x3fe298b7cc809440L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String:\u6663\\ud934\\udf7d\\ud954\\udfce\\ud98f\\udf46\\ud980\\udcbf\\ud87d\\udea2\\uda75\\udefd\\ud8f0\\ude46\\u72b9\\uda89\\udef6\\udb35\\udf95\\ud9cb\\udcdc\\ua4b0\\udb8c\\udcd8\\ud896\\uddab\u6663\0121=java.lang.String:\u6663\\ud934\\udf7d\\ud954\\udfce\\ud98f\\udf46\\ud980\\udcbf\\ud87d\\udea2\\uda75\\udefd\\ud8f0\\ude46\\u72b9\\uda89\\udef6\\udb35\\udf95\\ud9cb\\udcdc\\ua4b0\\udb8c\\udcd8\\ud896\\uddab\u6663\012",
        Z.run(T, 2, 0, 0, 12, "\ud934\udf7d\ud954\udfce\ud98f\udf46\ud980\udcbf\ud87d\udea2\uda75\udefd\ud8f0\ude46\u72b9\uda89\udef6\udb35\udf95\ud9cb\udcdc\ua4b0\udb8c\udcd8\ud896\uddab", "\ua7f7\u7d24\u3e98\ua81d\u1d48\u1f61\u6848", "\ud87c\ude56\ud967\udd42\udb5c\udeab\ud85c\udc22\ud91d\udf30\u22ee",
        40, 20823, -271322317, -7524619384254183652L, 53880L, true, false, (char) 26211, (char) 52014,
        Double.longBitsToDouble(0x3fefeda0493cdd89L), Double.longBitsToDouble(0x3fe1cfcb51dd825bL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 12, 12, 12, "\ud954\udd61\udb6e\uddad\ud808\ude54", "\u99c2\u7725", "\ud81d\udc3e\ud9c1\ude37",
        40, 96833, -1519972570, -787794065577132901L, -75291L, true, false, (char) 28612, (char) 10790,
        Double.longBitsToDouble(0x3fc43c5e80f7089cL), Double.longBitsToDouble(0x3fefc2a99afb8fd6L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:\u1007\\ud934\\udf7d\\udba3\\ude74\\udbbe\\ude1c\\ud828\\udf2d\\ud89a\\udd56\\uda75\\udefd\\ud8f0\\ude46\\u72b95\\udb35\\udf65\\ud9cb\\udcdc\\ua4b0\\udb8c\\udcd8\\ud896\\uddab\u1007\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 12, "\ud934\udf7d\udba3\ude74\udbbe\ude1c\ud828\udf2d\ud89a\udd56\uda75\udefd\ud8f0\ude46\u72b95\udb35\udf65\ud9cb\udcdc\ua4b0\udb8c\udcd8\ud896\uddab", "\ua7f7\u7d24\ub655\u3f27\u2a16\u1f61\u6848", "\ud87c\ude56\ud967\udd42\udb5c\udeab\ud85c\udc22\ud91d\udeda\u22ee\udaec\udf5f\udac3\udf8e",
        28, 84026, -2088581348, -1911270651291130136L, 49524L, false, true, (char) 4103, (char) 3782,
        Double.longBitsToDouble(0x3fe1cfcb51dd825bL), Double.longBitsToDouble(0x3fe298b7cc809440L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.String:\ud96e\\ud934\\udf7d\\udba3\\ude74\\udbbe\\ude1c\\ud828\\udf2d\\ud89a\\udd56\\uda75\\udefd\\ud8f0\\ude46\\u72b9\\uda89\\udef6\\udb35\\udf95\\ud9cb\\udcdc\\ud8cd\\udefd\\udba1\\udde1\\ud896\\uddab\\ud8f6\\udc6c\\ud8da\\uddac\\ud92c\\udd2b\\u9d45\\udb63\\udc4f\\ud9f2\\uddb3\\ud811\\ude66\\udbd7\\udf1f\\ud973\\udc26\\uaad9\\ud9e8\\udca1\\ud87c\\ude56\\ud96...\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 6, "\ud934\udf7d\udba3\ude74\udbbe\ude1c\ud828\udf2d\ud89a\udd56\uda75\udefd\ud8f0\ude46\u72b9\uda89\udef6\udb35\udf95\ud9cb\udcdc\ud8cd\udefd\udba1\udde1\ud896\uddab\ud8f6\udc6c\ud8da\uddac\ud92c\udd2b\u9d45\udb63\udc4f\ud9f2\uddb3\ud811\ude66\udbd7\udf1f\ud973\udc26\uaad9\ud9e8\udca1\ud87c\ude56\ud967\udd42\udb03\ude5e\ud87c\udee7\ud91d\udeda\u22ee\udaec\udf5f\udac3\udf8e\u523f\uda3c\udc62\udb83\udfc5\udb52\udfe7\udb51\udfdb\ud84e\udc30\ud947\udd3e\udad1\udcc7\ud808\udd14\ud928\uddd8\ud9cb\uded1\uda46\udf37\ud9a6\udff9\uda06\udf02\ud8b1\udf73\uda26\udc74\uda0b\udf53\ud958\uddfa\ud983\ude66\uda7e\udf1b\udb40\udd64\ud855\udd49\ud9d0\udf11\ud86c\udc54", "\ua8f4\u74d4\u59f6\u7904\uc4ce\u23eb\uc9ae", "\udac4\udf8e\ud9b9\udde5\ud838\udc59",
        -5, 22139, 515648783, 5853166058172426279L, 7970L, true, false, (char) 55662, (char) 58466,
        Double.longBitsToDouble(0x3fdfbacee7d80080L), Double.longBitsToDouble(0x3fe237cb5b96b274L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:\000\\u3aca\\udb99\\udd8b\\udbbe\\ude1c\\ud828\\udf2d\\ud89a\\udd56\\u0011\\0\\0\\0\\0\\ud9cb\\udcdc\\ua4b0\\0\\0\000\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 12, "\u3aca\udb99\udd8b\udbbe\ude1c\ud828\udf2d\ud89a\udd56\021\000\000\000\000\ud9cb\udcdc\ua4b0\000\000", "\ua7f7", "\ud8e2\udc2b\000",
        -5, -1000, 1176567808, 2662804356866417998L, 38328L, false, false, (char) 0, (char) 52991,
        Double.longBitsToDouble(0x3fe998150800efd3L), Double.longBitsToDouble(0x3e45e00000000000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:\u5eaf\\u3aca\u5eaf\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 12, "\u3aca", "\000", "\000\000\uda89\udef6\udb35\udf95\ud9cb\udcdc\ua4b0\udb8c\udcd8\ud896\uddab\ud8f6\udc6c\ud8da\uddac\uda16\udeb8\u9d45\udb63\udc4f\ud9f2\uddb3\ud82e\ude55\udbd7\udf1f\uda71\udc25\uaad9\ud840\ude93",
        -2, 35021, 0, -3481282513324874840L, -100000L, false, false, (char) 24239, (char) 33666,
        Double.longBitsToDouble(0x3e49884000000000L), Double.longBitsToDouble(0x3f941ea1000d0040L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:\u23a2\\ud934\\udf4a\\udba3\\ude74\\udbbe\\ude1c\u23a2\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 9, 13, "\ud934\udf4a\udba3\ude74\udbbe\ude1c", "\u8bc4", "\uda89\udef6\udb35\udf95\ud9cb\udcdc\ua4b0\ud9dd\udfac",
        28, 84577, 95924566, -8365408199550716375L, 2359L, false, false, (char) 9122, (char) 59070,
        Double.longBitsToDouble(0x3fe5bec86ea7ec1eL), Double.longBitsToDouble(0x3fd4e24f407aaac4L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 5, 5, 12, "\udb1b\udfab\ud853\udfa6\udb12\udc96\ud815\udf45\ud8ba\ude9f\uda80\uddcb", "\u2bb3\u3046\uc742\u89d6\u7c3d", "\ud801\udfae\uda70\udfc6\udbee\udde7\udad6\udc54\udaa3\udefc\ud85d\udf0e\udbd7\udf1f",
        29, 990, -1112408827, 7363885633849104036L, 90720L, true, true, (char) 26849, (char) 62729,
        Double.longBitsToDouble(0x3fdf1aad578a9a58L), Double.longBitsToDouble(0x3fe1897e5807f324L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:\000\\ud99f\\udfca\\ud9f6\\udedd\\u00ce\\ud815\\udf45 \\uda5a\\uddec\000\0121=java.lang.String:\000\\ud99f\\udfca\\ud9f6\\udedd\\u00ce\\ud815\\udf45 \\uda5a\\uddec\000\012",
        Z.run(T, 2, 0, 0, 0, "\ud99f\udfca\ud9f6\udedd\u00ce\ud815\udf45 \uda5a\uddec", "", "\ud92c\udc2e\udbf4\udcec\udafd\udd20\ud811\udff1\ud97b\udcd7\ud92e\udc7a\uda49\udfc5",
        7, 51048, 28672, 0L, -100000L, true, false, (char) 0, (char) 41215,
        Double.longBitsToDouble(0x3fcbbd85bec27e2cL), Double.longBitsToDouble(0x3f31262a60000000L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 12, 12, 11, "\ud99f\udfca\ud9f6\udedd\udbbe\ude1c\ud815\udf45\ud865\udee2\uda6a\udff9\ud8f0\ude46\u72b9\uda89\udef6\udae9\udcce\ud92c\udc2e\udbf4\udcec\udafd\udd20\ud982\udfbc\udb0d\uddbb\ud9ed\udd82\uda4a\udc24\ud9c0\udc34\udb68\udd32\udbe6\udd4e", "\u161b\u71c1\uacdc\u52bf\ub22b\uae8b", "\u2338\udbaf\udc88",
        22, 23471, -153747825, 7226700517419057042L, 91783L, false, false, (char) 40277, (char) 19965,
        Double.longBitsToDouble(0x3fea71a868fd4b08L), Double.longBitsToDouble(0x3fc4bf22827b3eb8L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 0, "\u5e53", "\uc6f9\ub6d1\ua153\u258b\u4a86\ucfa3\u5124\u6e58\u198b\uccf0\u7c8a", "\ud9f3\udf4e",
        26, 4477, 1378250793, -5145685805988287775L, -87096L, false, true, (char) 57313, (char) 22332,
        Double.longBitsToDouble(0x3fc33483723e7b68L), Double.longBitsToDouble(0x3fe88915bd02ae7dL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 6, "\ud91b\udee6", "\ua958\u3f4c\u25ce\u77cc\u4abe\ucfa3\u3e50\u3541\ucf24\u87dd\u7c8a", "\uda16\udeb8",
        7, 13605, 1378250793, 4942227828672034589L, -93271L, false, true, (char) 34089, (char) 26074,
        Double.longBitsToDouble(0x3fe0edf687b00aeeL), Double.longBitsToDouble(0x3fed41d4c502ae7dL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 0, "\ud934\udf7d\ud975\ude5b\udbbe\ude1c\u00b6\000\000", "\ucfa3", "\udaf8\udcde\udafb\ude20\ud896\ude94\ud97b\udcd7\ud92e\udc7a\uda16\udeb8\ud9ec\ude87\udb68\udd4a\ud931\udd00\uda69\uddd0\udbd7\udf1f\ud973\udc26\ud839\udef7\u292f\ud87c\udea7\udbe2\udd11\udb5c\udf2d\u0324\ud91d\udeda\u22ee\ud9f9\uddc6\ud88c\udd06\udb00\udc8a",
        22, 3268, -1282132354, -8366572842497134553L, 93429L, true, true, (char) 55754, (char) 59144,
        Double.longBitsToDouble(0x3fe7c590a1f5cd47L), Double.longBitsToDouble(0x3feda1a03f22ae19L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 0, "\ud934\udf7d\ud975\ude5b\udbae\udc1c\udb5b\udec0\udb36\udd3f\uda72\udf11\ud8f0\ude46\u72b9\uda89\udef6\udb66\ude66\udb4d\udfce\udaf8\udcde\ud875\ude1d\ud896\ude94\ud97b\udcd7\ud92e\udc7a\uda16\udeb8\ud9ec\ude87\udb68\udd4a\ud94d\udd00\uda69\uddd0\udbd7\udf1f\ud973\udc26\ud839\udef7\u292f\ud87c\udea7\udbe2\udd11\udb5c\udf2d\u0324\ud91d\udeda\u22ee\ud9f9\uddc6\udbb6\udc3f\udabd\udd90\ud962\udf97\udb73\udd26\ud835\ude69\uda25\udce5\udadb\udf0b\ud8fb\uddc2\ud885\udd39\ud96f\udce1\udbad\udf0a\uda8c\udd92\udb3c\ude21\udbb3\udd53\ud891\udee0", "\u1e69", "\uda6e\udc65\ud9b9\udeb7",
        27, 79142, 1057309123, 785145394473986151L, -94823L, false, true, (char) 12293, (char) 22565,
        Double.longBitsToDouble(0x3fe488ebebf70303L), Double.longBitsToDouble(0x3fe9b2c9ad526294L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 0, "", "\u2957", "\uda72\udf11",
        43, 49869, 924981, 0L, 21656L, true, true, (char) 38880, (char) 12374,
        Double.longBitsToDouble(0x3fd9005a8c5317d0L), Double.longBitsToDouble(0x3fea82511829ddb8L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 0, "\000\ud975\udd94\udbbe\ude1c\udb65\ude2d\udb36\udd3f%", "\ucfa3", "\000\udafb\udd58\ud811\udff1\000\ud92e\udc55\uda16\udeb8\ud9ec\ude87\udb68\udd4a\ud94d\udd00\uda69\uddd0\udbd7\udf1f\ud973\udc26\000\u5b6b\ud970\udea1\udbe2\udd11\udb5c\udf2d\u0324\ud91d\udeda\u22ee\ud9f9\uddc6\ud8a0\udcac\ud832\ude3f",
        39, 6335, -162438228, -5785453857171962831L, 86408L, true, false, (char) 25748, (char) 65203,
        Double.longBitsToDouble(0x3febad2904c4c3beL), Double.longBitsToDouble(0x3fe4ad52a35693b0L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.String:\ud09d\\ud990\\udd29\\udbb5\\ude39\\udb9e\\udf4e\\ud815\\udf45\\ud865\\uded5\\uda8f\\udd0c\\udbaf\\udef5\\ud8a2\\udf2f\\udb25\\udd5b\\udac3\\ude8f\\ud926\\udd2e\\udbea\\udce7\\udafd\\udd20\\udbc4\\udfeb\\ud904\\udc98\\ud99c\\udc31\\udb51\\ude10\\ud833\\udef6\\udb68\\udcfa\\ud94d\\udd00\\uda69\\uddd0\\udaad\\udd37\\ud973\\udc26\\uda2b\\udf38\\uda04\\udc9...\0121=java.lang.String:\ud09d\\ud990\\udd29\\udbb5\\ude39\\udb9e\\udf4e\\ud815\\udf45\\ud865\\uded5\\uda8f\\udd0c\\udbaf\\udef5\\ud8a2\\udf2f\\udb25\\udd5b\\udac3\\ude8f\\ud926\\udd2e\\udbea\\udce7\\udafd\\udd20\\udbc4\\udfeb\\ud904\\udc98\\ud99c\\udc31\\udb51\\ude10\\ud833\\udef6\\udb68\\udcfa\\ud94d\\udd00\\uda69\\uddd0\\udaad\\udd37\\ud973\\udc26\\uda2b\\udf38\\uda04\\udc9...\012",
        Z.run(T, 2, 0, 0, 0, "\ud990\udd29\udbb5\ude39\udb9e\udf4e\ud815\udf45\ud865\uded5\uda8f\udd0c\udbaf\udef5\ud8a2\udf2f\udb25\udd5b\udac3\ude8f\ud926\udd2e\udbea\udce7\udafd\udd20\udbc4\udfeb\ud904\udc98\ud99c\udc31\udb51\ude10\ud833\udef6\udb68\udcfa\ud94d\udd00\uda69\uddd0\udaad\udd37\ud973\udc26\uda2b\udf38\uda04\udc97\ud87c\udeb0", "\ua0be\u4b0d\ua856\u183c\u9475\u4eaa", "\ud98f\udefc\uda32\udce9\ud973\udd32\uda22\udc4f",
        -2, 95762, -1316788294, -5618542659100427271L, -16192L, false, true, (char) 53405, (char) 52852,
        Double.longBitsToDouble(0x3febd7a96b7f9784L), Double.longBitsToDouble(0x3fd9ceacfc967cc8L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.String:\uca41\\ud934\\udf7d\\u00c7\\udb9e\\udf4e\\ud815\\udf45\\ud865\\uded5\\r\uca41\0121=java.lang.String:\uca41\\ud934\\udf7d\\u00c7\\udb9e\\udf4e\\ud815\\udf45\\ud865\\uded5\\r\uca41\012",
        Z.run(T, 2, 0, 0, 0, "\ud934\udf7d\u00c7\udb9e\udf4e\ud815\udf45\ud865\uded5\015", "", "\ud926\udd2e\udbea\udce7\udafd\udd20\ud896\ude94\ud97b\udcd7\ud92e\udc7a\uda16\ude28",
        -2, 1032, 1378250793, -5145835339569665311L, -93271L, false, false, (char) 51777, (char) 57953,
        Double.longBitsToDouble(0x3fcbbd85bec27e2cL), Double.longBitsToDouble(0x3fed41d4c502ae7dL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.String:\000\\0\\0\\0\\0\\udbfe\\ude21\\0\000\0121=java.lang.String:\000\\0\\0\\0\\0\\udbfe\\ude21\\0\000\012",
        Z.run(T, 2, 0, 0, 0, "\000\000\000\000\udbfe\ude21\000", "", "",
        47, 90340, 383385800, -6528231632858513408L, -100000L, true, false, (char) 0, (char) 28713,
        Double.longBitsToDouble(0x3fe0329130e1b896L), Double.longBitsToDouble(0x3fe3960005b7d90dL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.String:\u7b9b\\ud934\\udf7d\\u00c7\\udb9e\\udf4e\\ud815\\udf45\\u0013\\0\u7b9b\0121=java.lang.String:\u7b9b\\ud934\\udf7d\\u00c7\\udb9e\\udf4e\\ud815\\udf45\\u0013\\0\u7b9b\012",
        Z.run(T, 2, 0, 0, 0, "\ud934\udf7d\u00c7\udb9e\udf4e\ud815\udf45\023\000", "\ucfa3", "\udbea\udce7\udb98\udd4b\ud896\ude94\ud97b\udcd7\ud92e\udc7a\uda16\ude28\ud833\ude2b\udb88\udf0a\000\u5200\udbbd\udc3e\ud973\udc26\ud839\udef7\ud9e8\udced\ud87c\ude56\udbe2\udcd4\udb5c\udf2d\u0324",
        3, 48426, -971362000, -8529535506669984825L, 22300L, true, false, (char) 31643, (char) 33142,
        Double.longBitsToDouble(0x3fe65b767beba1adL), Double.longBitsToDouble(0x3fde982f97b3f0fcL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.String:\u0ded\\ud934\\udf7d\\n\\udb9e\\udf4e\\ud815\\udf45\\udb63\\udef4\\ud850\\udd46\u0ded\0121=java.lang.String:\u0ded\\ud934\\udf7d\\n\\udb9e\\udf4e\\ud815\\udf45\\udb63\\udef4\\ud850\\udd46\u0ded\012",
        Z.run(T, 2, 0, 0, 0, "\ud934\udf7d\012\udb9e\udf4e\ud815\udf45\udb63\udef4\ud850\udd46", "\ucfa3\u6b88\ud507\u8a89\u8edd", "\ud92e\udc7a\uda16\ude28\ud806\udc2b\udb68\udcfa\ud94d\udd00\uda69\uddd0\udbd7\udf1f\ud973\udc26",
        11, 43528, 1432528206, 7795135018057855149L, 23816L, false, true, (char) 3565, (char) 50880,
        Double.longBitsToDouble(0x3fee3c4d0fccbdd6L), Double.longBitsToDouble(0x3fc8737619a0ea84L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 4, 4, 2, "\udb5f\udf45\ud9d9\udfab\ud99f\udf19\ud9b8\udc36\ud953\udd49\uda82\udd1f\ud9b8\ude4a", "\u3037\ud1ff\u0618\ub8d8\ucc0a\u6a86\u0129", "\ud968\udf09\ud94d\udd00\uda50\ude19\ud888\ude17\ud909\udd44\ud839\udef7\ud9e8\udced",
        4, 7476, -1619706032, 4222229858812486568L, 14128L, false, true, (char) 61553, (char) 26721,
        Double.longBitsToDouble(0x3fc254b9a2454284L), Double.longBitsToDouble(0x3fbc1c6f2715a570L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 9, 0, "", "\ub5e5", "\015\ud8f0\uddbf\ud829\udf61\ud819\udebf\ud852\ude35",
        1, 60084, 383396808, -6557240047459765639L, -39710L, false, false, (char) 6529, (char) 64042,
        Double.longBitsToDouble(0x3e4e300000000000L), Double.longBitsToDouble(0x3fee4e5a60005f30L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 9, 0, "\ud8e6\udcf9\udae2\udfe6\uda76\udd07\000\ud867\udcb3\uda5a\uddf9", "\ua4a5\u3683\u3b7f\u14f4\u8edd", "\uda09\ude88\uda16\udeb8",
        7, 30946, -1900613044, -483702880482623263L, 36701L, true, false, (char) 54893, (char) 20660,
        Double.longBitsToDouble(0x3fed41d4c502ae7dL), Double.longBitsToDouble(0x3fc55b9791971868L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 9, 0, "\000\udae2\udfd6\000\uda8a\uddf1\ud865\uded5\uda72\udef9", "\ua4a5\u3683\u3b7f\u14f4\u8edd", "\uda09\ude88\uda16\udeb8\ud9ec\ude87\uda95\uddef\udba0\udf9e",
        27, 32473, 247, 0L, 38752L, false, false, (char) 20660, (char) 15000,
        Double.longBitsToDouble(0x3fd02ae7d155b978L), Double.longBitsToDouble(0x3fb9718680000000L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=java.lang.String:\uf1b3\\ud8e6\\udcf9\\u0010\\ud816\\udd0a\\uda8a\\uddf1\\ud865\\uded5\\r\uf1b3\012",
        Z.run(T, 2, 4, 0, 0, "\ud8e6\udcf9\020\ud816\udd0a\uda8a\uddf1\ud865\uded5\015", "\u00f3\u78ba\u3b7f\u14f4\u8edd", "\uda09\ude88\uda16\udeb8\ud9ec\ude87",
        36, 33452, -112620853, -6994313555964222729L, 38691L, false, true, (char) 61875, (char) 15000,
        Double.longBitsToDouble(0x3fd02ae7d155b978L), Double.longBitsToDouble(0x3fb97186897c3870L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 9, 0, "\u00f9\000\000\000\ud845\udcc2\000", "", "\ud915\uddb7\uda96\udfad\udafd\udd20\ud896\ude94\ud97b\udcd7\uda09\ude88\uda16\udeb8",
        7, 30946, -1900613044, -483702882111114015L, 36701L, true, false, (char) 54893, (char) 20660,
        Double.longBitsToDouble(0x3fed41d4c502ae7dL), Double.longBitsToDouble(0x3fc55b9791971868L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.String:\u06a7\\ud934\\udf7d\\ud975\\ude5b\\0\\u728f\\udbed\\udcc8\\uda72\\udef9\\ud8f0\\ude46\\u72b9\\uda82\\uddf6\\udabf\\uddce\\ud8b4\\udfd5\\u8500\\udb98\\udd4b\\ud896\\ude94\\udbc1\\udf1a\\ud92e\\udc7a\\uda16\\udeb8\\ud9ec\\ude87\\udb68\\udd4a\\ud94d\\udd00\\uda69\\uddca\\udbbd\\udc3e\\udaea\\udda2\\ud839\\uded5\\ud95e\\udc0e\\ud889\\ude3f\\udbe2\\udd11\\ud...\0121=java.lang.String:\u06a7\\ud934\\udf7d\\ud975\\ude5b\\0\\u728f\\udbed\\udcc8\\uda72\\udef9\\ud8f0\\ude46\\u72b9\\uda82\\uddf6\\udabf\\uddce\\ud8b4\\udfd5\\u8500\\udb98\\udd4b\\ud896\\ude94\\udbc1\\udf1a\\ud92e\\udc7a\\uda16\\udeb8\\ud9ec\\ude87\\udb68\\udd4a\\ud94d\\udd00\\uda69\\uddca\\udbbd\\udc3e\\udaea\\udda2\\ud839\\uded5\\ud95e\\udc0e\\ud889\\ude3f\\udbe2\\udd11\\ud...\012",
        Z.run(T, 2, 0, 0, 0, "\ud934\udf7d\ud975\ude5b\000\u728f\udbed\udcc8\uda72\udef9\ud8f0\ude46\u72b9\uda82\uddf6\udabf\uddce\ud8b4\udfd5\u8500\udb98\udd4b\ud896\ude94\udbc1\udf1a\ud92e\udc7a\uda16\udeb8\ud9ec\ude87\udb68\udd4a\ud94d\udd00\uda69\uddca\udbbd\udc3e\udaea\udda2\ud839\uded5\ud95e\udc0e\ud889\ude3f\udbe2\udd11\udb5c\udf2d\u0324\u00a8\000\000\ud88c\udd06\udac6\udd35\udbdb\udc0b\ud81e\udd53\ud9ef\ude54\ud9dc\udf19\ud959\ude6d\udbbc\ude67\ud8c7\ude90\ud957\udf88\ud8f4\udc17\ud9aa\udd0e\ud8dd\udd53\ud842\udd24\uda9f\udf67\ud80a\udd9f\ud914\udd96\ud807\udda4", "\u37e5\u14a6\uccd1\u60b9", "\udb6c\udd14\ud9aa\udd16\ud992\udcd3\uda1f\udd7b\ud97f\udc84\uda26\uddcf\udaea\udd86\ud80e\udfbe\udbac\udc99\ud8f8\udff0\udb11\ude64\udada\ude28\uda98\uddbf\udbd2\uded6\udb11\udc5c\ud9f4\udf93\ud848\udc0c\ud908\ude2c\ud85c\udd7c\ud8d7\udf3a\udab8\udd40\ud8a6\ude93\ud9f3\udd38\ud219\ud838\udc1c\udbeb\udeaf",
        26, 39163, -2007507879, -5516256243366409207L, -85080L, false, false, (char) 1703, (char) 49458,
        Double.longBitsToDouble(0x3fe221b40426c347L), Double.longBitsToDouble(0x3fc70bdda0c2cfacL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 13, 13, 0, "\ud935\udf6b\udac6\udd42\uda54\udc45\udbf4\ude92\uda8a\udeb0\u4dd8", "\ubec0\u8f52\u7e90\u8a89\u8edd", "\ud92e\udc7a\uda16\udeb8\ud9ec\ude87\ud867\uddcf\udac0\udc64",
        1, 12713, 1851078964, -8252875848731578688L, 23453L, true, false, (char) 28179, (char) 28439,
        Double.longBitsToDouble(0x3fd02ae22e5e6d78L), Double.longBitsToDouble(0x3fd2d962e36076c4L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.String:\u9cf7\\\000\udb3d\udf5d\ud8b6\uddab\ud865\uded5\\0\\udb3d\\udf5d\\ud8b6\\uddab\\ud865\\uded5\u9cf7\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 14, "\\\000\udb3d\udf5d\ud8b6\uddab\ud865\uded5", "\u4f68\u3c69\u299e", "\ud811\udd2b\ud896\ude94\000\000\uda16\ude9d\ud9ec\ude87\ud8fe\udc89\ud93b\udc56\udb1b\uddc9\ud911\udf1c\ud932\udf37\udb43\udefc\ud9f4\ude25\ud87c\ude56\udbe2\udd11\udb06\udd01\001\ud97a\udddd\udb91\ude72",
        7, 53357, -1615667492, -2225044018882096173L, -36407L, true, true, (char) 40183, (char) 6421,
        Double.longBitsToDouble(0x3fa7818624e886d0L), Double.longBitsToDouble(0x3fee16fd36db5be4L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 9, 4, "\ud9e3\udcbb\uda25\ude40\udb7a\ude48\udb0b\udf80\udba7\udfe0\ud953\ude61\uda42\udd72\ud93c\udd1a\ud9f0\udf01\udad7\uddf3\uda1e\ude25\uecf2\ud8f7\udfd3[\udbcc\udebc\ud8bf\udfd3", "\u7aaf\ubf52\u8934\u6362\000\000\ubb0a\u8c5c\ua162\u82b5\u5d30\u6d33\u4586\u146a\u0b5b\u8d07\u6883\u2a38\u76c0\u99f8\u53bf\ud5e7\u2519\u9677\uac4e\u204b\u9de0\u418d\u5759\u162a\u2d10\u37b6\ub16f\u07e3\u8aeb\u4b37", "\ud92f\uddab",
        24, 69292, 682133982, 7804090858185992017L, -21507L, true, false, (char) 64453, (char) 37100,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe109c807131957L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.String:\ud96e\\ud934\\udf7d\\udb99\\ude74\\udbbe\\ude1c\\ud828\\udf2d\\ud89a\\udd56\\uda75\\udefd\\ud8f0\\ude46\\u72b9\\uda89\\udef6\\udb35\\udf95\\ud9cb\\udcdc\\ud8cd\\udefd\\udba1\\udde1\\ud811\\udf08\\0\\ud8ae\\udc56\\ud92c\\udd2b\\u9d45\\udb63\\udc4f\\ud9f2\\uddb3\\ud811\\ude66\\udbd7\\udf1f\\ud973\\udc26\\uaad9\\ud9e8\\udca1\\ud87c\\ude56\\ud967\\udd42\\ud...\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 6, "\ud934\udf7d\udb99\ude74\udbbe\ude1c\ud828\udf2d\ud89a\udd56\uda75\udefd\ud8f0\ude46\u72b9\uda89\udef6\udb35\udf95\ud9cb\udcdc\ud8cd\udefd\udba1\udde1\ud811\udf08\000\ud8ae\udc56\ud92c\udd2b\u9d45\udb63\udc4f\ud9f2\uddb3\ud811\ude66\udbd7\udf1f\ud973\udc26\uaad9\ud9e8\udca1\ud87c\ude56\ud967\udd42\ud83b\ude5a\ud87c\udee7\ueba8\000\000\ud87e\udc1e\u523f\uda3c\udc62\udb83\udfc5\udb52\udfe7\udb51\udfdb\ud84e\udc30\ud947\udd3e\udad1\udcc7\ud808\udd14<\ud9cb\uded1\uda46\udf37\000\000\ud98e\udda6\000\000\000\ud944\ude01\uda7e\udf1b\udb40\udd64\000\ud809\udca4\ud86c\udc54", "\ua8f4\u74d4\u59f6\u7904\u67af\u23eb\uc9ae", "\udac4\udf8e\uf8a7\000",
        20, 22139, 11535, 5852990664592959527L, 7970L, true, false, (char) 55662, (char) 58466,
        Double.longBitsToDouble(0x3fdfbacee7d80080L), Double.longBitsToDouble(0x3fe237cb58000000L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.String:\000\\u3aca\\udbd2\\udcc2\\udbbe\\ude1c\\ud828\\udf2d\\udb80\\udf29\\udb47\\uddb7\ua7f7\\u44d4\\uda0b\\ude10\\ud980\\uddb0\\ud9a5\\udd24\\ua4b0\\ud8ae\\udd57\\ud817\\udd29\000\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 12, "\u3aca\udbd2\udcc2\udbbe\ude1c\ud828\udf2d\udb80\udf29\udb47\uddb7\"\u44d4\uda0b\ude10\ud980\uddb0\ud9a5\udd24\ua4b0\ud8ae\udd57\ud817\udd29", "\ua7f7", "\ud8e2\udc2b\000",
        -5, -1000, -1899639808, 690549198389696769L, 38328L, false, false, (char) 0, (char) 10749,
        Double.longBitsToDouble(0x3fee9cf55b701550L), Double.longBitsToDouble(0x3eb1abc000000000L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.String:\uf5d3\\u3aca\\udb99\\udd8b\\udbbe\\ude1c\\ud828\\udf2d\\ud89a\\udd56\\u0011\\0\\0\\udaa9\\ude85\\t\\ud9cb\\udcdc\\ua4b0\\ud858\\udeeb\\ucd63\uf5d3\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 12, "\u3aca\udb99\udd8b\udbbe\ude1c\ud828\udf2d\ud89a\udd56\021\000\000\udaa9\ude85\011\ud9cb\udcdc\ua4b0\ud858\udeeb\ucd63", "\ua7f7", "\ud8e2\udc2b\000",
        -5, -1000, 1176567808, 2662804356866417998L, -100000L, false, true, (char) 62931, (char) 61395,
        Double.longBitsToDouble(0x3fec800005780000L), Double.longBitsToDouble(0x3fe03b96cced5356L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.String:\u9a7b\\u3aca\\udb99\\udd8b\\udbbe\\ude1c\\udae5\\udc8a\\ud977\\ude01\\u00b1i\\0\\0\\0\\ud9cb\\udcdc\\ud88c\\udf42;\\0\u9a7b\0121=java.lang.String:\u9a7b\\u3aca\\udb99\\udd8b\\udbbe\\ude1c\\udae5\\udc8a\\ud977\\ude01\\u00b1i\\0\\0\\0\\ud9cb\\udcdc\\ud88c\\udf42;\\0\u9a7b\012",
        Z.run(T, 2, 0, 0, 12, "\u3aca\udb99\udd8b\udbbe\ude1c\udae5\udc8a\ud977\ude01\u00b1i\000\000\000\ud9cb\udcdc\ud88c\udf42;\000", "\u9a92", "\ud9a0\ude33\u6700\ud9d0\udc07\000\u1422\ud9e8\udca1\ud87c\ude56\ud94d\udd21\udb5c\udeab\ud85c\udc22\ud91d\udeda\000\000\udac3\udf27\ud949\udcf7",
        -4, 2112, -1223897736, 2114371076640380251L, 29591L, true, false, (char) 39547, (char) 57696,
        Double.longBitsToDouble(0x3fe1d64be5c4e467L), Double.longBitsToDouble(0x3fee12bc9bad07bdL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 0, "\000\000\000\000\000\000", "\ucfa3", "\udaf8\udcde\udafb\ude20\ud896\ude94\ud97b\udcd7\ud92e\udc7a\uda10\udd28\ud9ec\ude87\udb68\udd4a\ud931\udd00\uda69\uddd0\udbd7\udf1f\ud973\udc26\ud809\uddbe\000\000\000\udb5c\udf2d\u0324\ud91d\udeda\u22ee\ud9f9\uddc6\ud88c\udd06\udb00\udc8a",
        23, 3268, -1282132354, -8366572842077704153L, 93429L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe7c59001f5cd47L), Double.longBitsToDouble(0x3feda1a03f22ae19L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 0, "\000\000\udb9f\udc1c\u00b6\000\000", "\ucfa3", "\000",
        51, 87283, 671088640, 407584719336118672L, -48032L, true, false, (char) 42028, (char) 9080,
        Double.longBitsToDouble(0x3fbcb01300000000L), Double.longBitsToDouble(0x3fc811aef67ce90cL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 2, 0, "V\ud975\udd94\udbbe\ude1c\udb65\ude2d\udb36\udd3f%", "\ucfa3", "\000\udafb\udd58\ud811\udff1\000\ud92e\udc55\uda72\udca4\ud9c4\udfb9\udb68\udd4a\ud94d\udd00\uda69\uddd0\udbd7\udf1f\ud973\udc26",
        35, 43528, 1426105759, -1428236756803915555L, 23816L, false, true, (char) 13988, (char) 5569,
        Double.longBitsToDouble(0x3fc8f1342fec63b8L), Double.longBitsToDouble(0x3fcbe00f2eb24f7cL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.String:\uf472\\0\\0\\0\\0\\udbfe\\ude21\\0\\0\\0\\0\\ud904\\udf43\\ud839\\udc1f\\udbed\\udc54\\udaf2\\ude20\\ud893\\ude1f\\0\\0\\0\\udb1c\\ude43o\\ud94d\\udd00\\uda69\\uddd0\\udbab\\udf29\\ud973\\udc26\\udae9\\udd40\\ud9ab\\udf2e\\uda7c\\ude7c\uf472\0121=java.lang.String:\uf472\\0\\0\\0\\0\\udbfe\\ude21\\0\\0\\0\\0\\ud904\\udf43\\ud839\\udc1f\\udbed\\udc54\\udaf2\\ude20\\ud893\\ude1f\\0\\0\\0\\udb1c\\ude43o\\ud94d\\udd00\\uda69\\uddd0\\udbab\\udf29\\ud973\\udc26\\udae9\\udd40\\ud9ab\\udf2e\\uda7c\\ude7c\uf472\012",
        Z.run(T, 2, 0, 0, 6, "\000\000\000\000\udbfe\ude21\000\000\000\000\ud904\udf43\ud839\udc1f\udbed\udc54\udaf2\ude20\ud893\ude1f\000\000\000\udb1c\ude43o\ud94d\udd00\uda69\uddd0\udbab\udf29\ud973\udc26\udae9\udd40\ud9ab\udf2e\uda7c\ude7c", "\u4d72", "\udabc\udeb6\ud888\udd10\uda60\udc28\uda6e\udfcc\udb9f\udcbe\ud9a7\udf17\ud8ff\udd4a\uda21\udcb7\uda19\udfbb\ud9ee\udd4a\ud90d\ude17\ud818\udd6b\udaac\udfb8\ud838\udd8a\ud9eb\udc89\udb79\udd64\ud84d\uddc2",
        -1, 86254, -667721103, -6265189504215904237L, -13541L, true, false, (char) 62578, (char) 59482,
        Double.longBitsToDouble(0x3fed9e331755fc38L), Double.longBitsToDouble(0x3fd88be3606cae30L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.String:\ufaaa\\ud934\\udf7d\\n\\udb9e\\udf4e\\ud815\\udf45\\udb63\\udef4\\ud850\\udd46\\ud8f0\\ude2c\\uda92\\udeb3\\uda89\\udef6\\ud9cf\\udf01\\ud929\\udf23\\udbea\\udce7\\udafd\\udd20\\ud9da\\udefa\\udba2\\udeac\\udac6\\udec6\\uda16\\udecd\\ud806\\udc2b\\udb68\\udcfa\\ud964\\udf00\\uda69\\uddd0\\udbd7\\uded0\\ud973\\udc26\ufaaa\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 0, "\ud934\udf7d\012\udb9e\udf4e\ud815\udf45\udb63\udef4\ud850\udd46\ud8f0\ude2c\uda92\udeb3\uda89\udef6\ud9cf\udf01\ud929\udf23\udbea\udce7\udafd\udd20\ud9da\udefa\udba2\udeac\udac6\udec6\uda16\udecd\ud806\udc2b\udb68\udcfa\ud964\udf00\uda69\uddd0\udbd7\uded0\ud973\udc26", "\u0281\u11cf\uae5b\u7522\u4b0d", "\ud88c\uddf9\udb5b\udfe0",
        59, 99211, -1739717016, 6072553751180399086L, 95093L, true, false, (char) 64170, (char) 43592,
        Double.longBitsToDouble(0x3fe581966996fd78L), Double.longBitsToDouble(0x3fc3af31afdab29cL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.String:\u379f\\\000\udb3d\udf5d\ud8b6\uddab\\0\\udb3d\\udf5d\\ud8b6\\uddab\u379f\0121=java.lang.String:\u379f\\\000\udb3d\udf5d\ud8b6\uddab\\0\\udb3d\\udf5d\\ud8b6\\uddab\u379f\012",
        Z.run(T, 2, 0, 0, 3, "\\\000\udb3d\udf5d\ud8b6\uddab", "\u7c05\u4f68\u96ed\u3427\u7ece\u99b6\u0655\u7c8a\000", "\ud8b2\udc4a",
        43, 86191, -1205710330, -4607627852225670030L, -11872L, false, true, (char) 14239, (char) 56586,
        Double.longBitsToDouble(0x3f5026f171247000L), Double.longBitsToDouble(0x3fd4997e55eb9fbcL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.String:\ud96e\\ud934\\udf7d\\udb99\\ude74\\udbbe\\ude1c\\ud828\\udf2d\\ud89a\\udd56\\uda75\\udefd\\ud8f0\\ude46\\u72b9\\uda89\\udef6\\udb35\\udf95\\ud9cb\\udcdc\\ud8cd\\udefd\\udba1\\udde1\\ud811\\udf08\\0\\0\\ud92c\\udc9b\\u9d45\\udb63\\udc4f\\ud9f2\\uddb3\\ud92b\\ude93\\udbd7\\udf1f\\ud973\\udc26\\uaad9\\ud9e8\\udca1\\ud87c\\ude56\\ud967\\udd42\\ud83b\\ude5a\\...\0121=java.lang.String:\ud96e\\ud934\\udf7d\\udb99\\ude74\\udbbe\\ude1c\\ud828\\udf2d\\ud89a\\udd56\\uda75\\udefd\\ud8f0\\ude46\\u72b9\\uda89\\udef6\\udb35\\udf95\\ud9cb\\udcdc\\ud8cd\\udefd\\udba1\\udde1\\ud811\\udf08\\0\\0\\ud92c\\udc9b\\u9d45\\udb63\\udc4f\\ud9f2\\uddb3\\ud92b\\ude93\\udbd7\\udf1f\\ud973\\udc26\\uaad9\\ud9e8\\udca1\\ud87c\\ude56\\ud967\\udd42\\ud83b\\ude5a\\...\012",
        Z.run(T, 2, 0, 0, 6, "\ud934\udf7d\udb99\ude74\udbbe\ude1c\ud828\udf2d\ud89a\udd56\uda75\udefd\ud8f0\ude46\u72b9\uda89\udef6\udb35\udf95\ud9cb\udcdc\ud8cd\udefd\udba1\udde1\ud811\udf08\000\000\ud92c\udc9b\u9d45\udb63\udc4f\ud9f2\uddb3\ud92b\ude93\udbd7\udf1f\ud973\udc26\uaad9\ud9e8\udca1\ud87c\ude56\ud967\udd42\ud83b\ude5a\ud87c\udee7\ueba8\000\000\ud87e\udc1e\u523f\uda3c\udc62\udb83\udfc5\udb52\udfe7\udb51\udfdb\ud84e\udc30\ud947\udd3e\udad1\udcc7\ud808\udd14<\ud9cb\uded1\uda46\udf37\000\000\ud98e\udda6\000\000\000\000\uda68\udf54\udb40\udd64\000\ud809\udca4\ud86c\udc54", "\ua8f4\u10ae\u59f6\u7904\u67af\u23eb\uc9ae", "\000\000\000",
        20, 22139, 11535, 5852990665721380864L, 7970L, true, false, (char) 55662, (char) 58466,
        Double.longBitsToDouble(0x3fdfbacee7d80080L), Double.longBitsToDouble(0x3fe237cb58000000L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 10, 6, "\u93f6\ud8ec\udfcb\udbcf\udfd8\ud828\udf2d\ud89a\udd56\udb71\udefb\ud8f0\ude46\u72b9\uda89\udef6\udb35\udf95\ud9cb\udcdc\ud8cd\udefd\udba1\udde1\ud811\udf08\000\ud8ae\udc56\ud92c\udd2b\u9d45\udb63\udc4f\ud9f2\uddb3\ud810\udf66\uda76\ude4e\ud881\udde7\ud819\udc0d\ua5f0\ud87c\ude56\ud967\udd42\ud8d7\udf4b\ud87c\udee7\ueba8\000\000\ud87e\udc1e\u523f\uda3c\udc62\udb83\udfc5\udb52\udfe7\udb51\udfdb\ud84e\udc30\udaf4\udcde\ud9f5\udc76\ud808\udd14<\ud9cb\uded1\uda46\udf37\000\uda65\udedc\ud82d\ude0f\000\000\000\ud944\ude01\uda7e\udf1b\udb40\udd64\000\ud809\udca4\udb99\udef6", "\ua8f4\u74d4\u59f6\u7904\u67af\u23eb\uc9ae", "\udac4\udf8e\ud9fe\udda76",
        20, 22139, 11535, 5852990665448597543L, 7970L, true, false, (char) 55662, (char) 10851,
        Double.longBitsToDouble(0x3fdfbe2807d80080L), Double.longBitsToDouble(0x3fe237cb58000000L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.String:\000\\u3aca\\udbd2\\udcc2\\udbbe\\ude1c\\ud828\\udf2d\\udb80\\udf29\\udb47\\uddb7\ua7f7\\u44b3\\ud9d7\\udeb6\\ud980\\uddb0\\ud9a5\\udd24\\ua4b0\\ud8ae\\udd57\\ud817\\udd29\000\0121=java.lang.String:\000\\u3aca\\udbd2\\udcc2\\udbbe\\ude1c\\ud828\\udf2d\\udb80\\udf29\\udb47\\uddb7\ua7f7\\u44b3\\ud9d7\\udeb6\\ud980\\uddb0\\ud9a5\\udd24\\ua4b0\\ud8ae\\udd57\\ud817\\udd29\000\012",
        Z.run(T, 2, 0, 0, 0, "\u3aca\udbd2\udcc2\udbbe\ude1c\ud828\udf2d\udb80\udf29\udb47\uddb7\"\u44b3\ud9d7\udeb6\ud980\uddb0\ud9a5\udd24\ua4b0\ud8ae\udd57\ud817\udd29", "\ua7f7", "\ud8e2\udc2b\000",
        -5, -1000, -1899639808, 690549196947718145L, 38328L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fee980003701550L), Double.longBitsToDouble(0x3eb1abc000000000L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.String:\uefd3\\u3aca\\udb99\\udd8b\\udbc5\\udfa5\\ud828\\udf2d\\ud89a\\udd56\\u0011\\ud9bd\\uddee\000\000\000\u1422\ud9e8\udca1\ud87c\ude56\\udaa9\\ude85\\t\\ud9cb\\udcdc\\ua4b0\\udbea\\udea0\\ud97e\\udc74\uefd3\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 12, "\u3aca\udb99\udd8b\udbc5\udfa5\ud828\udf2d\ud89a\udd56\021\ud9bd\uddee'\udaa9\ude85\011\ud9cb\udcdc\ua4b0\udbea\udea0\ud97e\udc74", "\u20a8\u7d55", "\000\000\000\u1422\ud9e8\udca1\ud87c\ude56",
        9, 17427, -2142166533, 8930866153903882294L, 43468L, true, true, (char) 61395, (char) 25488,
        Double.longBitsToDouble(0x3fc701a0181dcabcL), Double.longBitsToDouble(0x3fcdaa6ad976bc68L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.String:\uf5d3\\u3aca\\udb99\\udd8b\\udbbe\\ude1c\\ud828\\udf2d\\ud89a\\udd56\\u0011\\0\\0\\udaa9\\ude85\\t\\ud9cb\\udcdc\\ua4b0\\ud858\\udeeb\\ucd63\uf5d3\0121=java.lang.String:\uf5d3\\u3aca\\udb99\\udd8b\\udbbe\\ude1c\\ud828\\udf2d\\ud89a\\udd56\\u0011\\0\\0\\udaa9\\ude85\\t\\ud9cb\\udcdc\\ua4b0\\ud858\\udeeb\\ucd63\uf5d3\012",
        Z.run(T, 2, 0, 0, 0, "\u3aca\udb99\udd8b\udbbe\ude1c\ud828\udf2d\ud89a\udd56\021\000\000\udaa9\ude85\011\ud9cb\udcdc\ua4b0\ud858\udeeb\ucd63", "\ua7f7", "\ud8e2\udc2b\000",
        -5, -1000, 1176567808, 2662804356866417998L, -100000L, false, true, (char) 62931, (char) 61395,
        Double.longBitsToDouble(0x3fec800005780000L), Double.longBitsToDouble(0x3fe03b96cced5356L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.String:\000\\u3aca\\udbd2\\udcc2\\udbbe\\ude1c\\ud828\\udf2d\\udb80\\udf29\\udb47\\uddb7\ua7f7\\u44b3\\ud9d7\\udeb6\\uee8d\\ud94b\\udd17\\ua4b0\\ud8ae\\udd57\ua7f7\000\0121=java.lang.String:\000\\u3aca\\udbd2\\udcc2\\udbbe\\ude1c\\ud828\\udf2d\\udb80\\udf29\\udb47\\uddb7\ua7f7\\u44b3\\ud9d7\\udeb6\\uee8d\\ud94b\\udd17\\ua4b0\\ud8ae\\udd57\ua7f7\000\012",
        Z.run(T, 2, 0, 0, 0, "\u3aca\udbd2\udcc2\udbbe\ude1c\ud828\udf2d\udb80\udf29\udb47\uddb7\"\u44b3\ud9d7\udeb6\uee8d\ud94b\udd17\ua4b0\ud8ae\udd57\"", "\ua7f7", "\ud8c6\udc2b\000",
        -5, -1000, 0, 690548277824716800L, 23648L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fee980000001550L), Double.longBitsToDouble(0x3e45e00000000000L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.String:\uefd3\\u3aca\\udb99\\udd8b\\udbc5\\udfa5\\ud828\\udf2d\\ud89a\\udd56\\u0011\\ud9bd\\uddee\000\000\000\u1422\ud9e8\udca1\uda02\udc21\\ud8e0\\udf00\\udb3a\\udc31\\ud9e9\\udee8\\ua4b0\\udbea\\udea0\\ud97e\\udc74\uefd3\0121=java.lang.String:\uefd3\\u3aca\\udb99\\udd8b\\udbc5\\udfa5\\ud828\\udf2d\\ud89a\\udd56\\u0011\\ud9bd\\uddee\000\000\000\u1422\ud9e8\udca1\uda02\udc21\\ud8e0\\udf00\\udb3a\\udc31\\ud9e9\\udee8\\ua4b0\\udbea\\udea0\\ud97e\\udc74\uefd3\012",
        Z.run(T, 2, 0, 0, 12, "\u3aca\udb99\udd8b\udbc5\udfa5\ud828\udf2d\ud89a\udd56\021\ud9bd\uddee'\ud8e0\udf00\udb3a\udc31\ud9e9\udee8\ua4b0\udbea\udea0\ud97e\udc74", "\u20a8\u1ed0", "\000\000\000\u1422\ud9e8\udca1\uda02\udc21",
        38, 5875, -2142887429, 8930866153903882294L, 43468L, true, true, (char) 61395, (char) 19321,
        Double.longBitsToDouble(0x3fc70321f81dcabcL), Double.longBitsToDouble(0x3fcdaa6ad976bc68L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 10, 0, "\ud934\udf7d\udbb3\udd5a\udbdb\udeb5\ud815\udf45\ud865\uded5\uda72\udef9", "\ucfa3\u3037\u7ef6\u8a89\u8edd", "\udac6\ude47\ud97e\udf2c\ud9e7\udffe\udb68\udd4a\ud94d\udd00",
        51, 54265, -799232597, -8252875216614969664L, 38691L, true, false, (char) 65339, (char) 7744,
        Double.longBitsToDouble(0x3fd02ae7d261b978L), Double.longBitsToDouble(0x3fed3630d3c789a1L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.String:\000\\udb83\\udf63\\udb09\\uddb5\\ud994\\ude2a\\uda51\\udf2c\\ud993\\udfc0\\u39af\\0\\udb5b\\udc7d\\ud883\\udc3c>\\0\\udbec\\udeb5\\udb8c\\udcd8\\ud896\\uddab\000\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 0, "\udb83\udf63\udb09\uddb5\ud994\ude2a\uda51\udf2c\ud993\udfc0\u39af\000\udb5b\udc7d\ud883\udc3c>\000\udbec\udeb5\udb8c\udcd8\ud896\uddab", "\uc5fa\u972d\u6f50\u3fce\u033c\u1eab\uae17", "\ud87c\ude56\ud967\udd42\uda8c\udea3\ud962\udf05\udaef\ude77\uda88\uddff\u2114\udac3\udf27",
        28, 49706, 0, -7955881418967639846L, -99989L, false, true, (char) 0, (char) 56576,
        Double.longBitsToDouble(0x3fe65fcb51dd825bL), Double.longBitsToDouble(0x3fe298b7cc809440L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.String:\uc3dd\\ud934\\udf7d\\udb0e\\udcea\\udbbe\\udd4e\\ud828\\udf2d\\ud89a\\udd56\\u0011\\0\\u72b9\\uda89\\udef6\\udb35\\udf95\\0\\0\\udba1\\udd1f\\u0002\\ud85e\\udc0e\\0\\0\\udbf9\\udf1b\\udb63\\udc4f\\ud8e2\\udc2b\\0\\udbd7\\ude3e\\ud973\\udc26\\udbe9\\udeb8\\0\\0\\u8003\\0\\ud84f\\udd27\\ueba8\\udb81\\udde0\\udaec\\udf5f\\udac3\\udf8e\\u523f\\uda3c\\udc62\\udb8...\0121=java.lang.String:\uc3dd\\ud934\\udf7d\\udb0e\\udcea\\udbbe\\udd4e\\ud828\\udf2d\\ud89a\\udd56\\u0011\\0\\u72b9\\uda89\\udef6\\udb35\\udf95\\0\\0\\udba1\\udd1f\\u0002\\ud85e\\udc0e\\0\\0\\udbf9\\udf1b\\udb63\\udc4f\\ud8e2\\udc2b\\0\\udbd7\\ude3e\\ud973\\udc26\\udbe9\\udeb8\\0\\0\\u8003\\0\\ud84f\\udd27\\ueba8\\udb81\\udde0\\udaec\\udf5f\\udac3\\udf8e\\u523f\\uda3c\\udc62\\udb8...\012",
        Z.run(T, 2, 0, 0, 0, "\ud934\udf7d\udb0e\udcea\udbbe\udd4e\ud828\udf2d\ud89a\udd56\021\000\u72b9\uda89\udef6\udb35\udf95\000\000\udba1\udd1f\002\ud85e\udc0e\000\000\udbf9\udf1b\udb63\udc4f\ud8e2\udc2b\000\udbd7\ude3e\ud973\udc26\udbe9\udeb8\000\000\u8003\000\ud84f\udd27\ueba8\udb81\udde0\udaec\udf5f\udac3\udf8e\u523f\uda3c\udc62\udb83\udfc5\ud883\udd7f\000\ud81e\uddce\ud947\udd3e\udad1\udcc7\ubdf8\ud96d\udfd2\ud9cb\uded1\u00dd\ud98c\udda6\udaef\ude77\ud8b1\udf73\uda26\udc74\uda0b\udf53\ud958\uddfa\000\uda7e\ude54\ud943\ude85\000\ud809\udca4\ud86c\udc54", "\000", "",
        -5, -1000, -1572470784, 9004425822572945252L, -100000L, false, false, (char) 50141, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fec28f00027513aL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 6, "\udbd7\uddac\uda0c\ude48\udbbe\ude1c\udaec\udf4f\udb36\udcee\uda64\ude11\ud8f0\ude46\udae8\udfcc\uda13\udde3\000\000\udaf7\udffa\udafb\ude20\ud896\ude94\ud97b\udcd7\udb3b\ude41\uda46\udc1d\ud893\udf88\udb68\udd4a\udad9\uddb5\ud8da\udd31\uda0c\udf51\ud8fe\udc45\udb81\udd98\ud806\udedc\udb35\udc29\ud81b\udcd1\udb5e\ude08\udb2a\udd0e\ud9b6\udd04\u0777\ud9d1\uddbf\udbd0\udeb1\ud94d\udef8\ud8a5\udd4e\ud9db\ude55\ud811\udd01\ub873\udae5\udedb\udaac\udd0c\ud867\udc5b\ud97b\uddba\u141f\ud920\ude09\ud8de\udebf\ud9ff\udf3a\udb62\udf35\ud90e\udc08\uda62\udc20\ud855\udf16\udb5a\ude8d\u51c0\ud988\ude74\udaa8\uddae\udbe6\udd85\ud9c5\udfbd\ud9e6\udca6\uda95\udf74\ud884\udd8c\uda50\udd1c\udba2\udf53\udb43\udde3\udbf2\udd5c\uda54\udd62\udbc1\udf64\ud865\udd84\udabc\udd42\udbf7\uddb5\ud8ca\ude01\uda12\udd07\uda95\udd05\ud9f6\udf12\udaa0\uddc3\uda12\udcb5\udb0b\udefe\uda96\udf31\ud9e8\udec2\ud864\udd74\udaf0\udcee\udab5\udc7d\ud9b1\udc38\ud910\udc47\udace\udcac\ud870\udf85\ud90c\uddd3\udab1\ude6d\udbf7\udc5b\ud9de\udf79\udbc7\udc3a\udb1d\udf51\udb26\udd62\ud965\udd90", "\u4ec8\u82d6\ud23c\ubf86\u4fe8\u0407", "\udbee\udfe6\uda2a\udee1\uda16\udd77\udb77\ude0e\ud842\udf1e\ud87c\udf69\udbf3\ude99\udbcc\udc00\udaf4\udd7b\uda6a\udefe\ud9d0\udc31\uda6d\udcaf\ud9c8\uded9",
        13, 43720, 608852634, 132667571256194447L, -65270L, false, false, (char) 28287, (char) 37033,
        Double.longBitsToDouble(0x3fdf9d0bd563aa66L), Double.longBitsToDouble(0x3fdcc2a167b1c4f8L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.String:\000\\udb83\\udf63\\udb09\\uddb5\\ud994\\ude2a\\uda51\\udf2c\\ud993\\udfc0\\u39af\\0\\udb5b\\udc7d\\ud883\\udc3c>\\0\\udbec\\udeb5\\udb8c\\udcd8\\ud896\\uddab\000\0121=java.lang.String:\000\\udb83\\udf63\\udb09\\uddb5\\ud994\\ude2a\\uda51\\udf2c\\ud993\\udfc0\\u39af\\0\\udb5b\\udc7d\\ud883\\udc3c>\\0\\udbec\\udeb5\\udb8c\\udcd8\\ud896\\uddab\000\012",
        Z.run(T, 2, 0, 0, 8, "\udb83\udf63\udb09\uddb5\ud994\ude2a\uda51\udf2c\ud993\udfc0\u39af\000\udb5b\udc7d\ud883\udc3c>\000\udbec\udeb5\udb8c\udcd8\ud896\uddab", "\uc5fa\u972d\u6f50\u9299\u033c\u1eab\uae17", "\ud87c\ude56\ud967\udd42\uda8c\udea3\ud962\udf05\udaef\ude77\uda88\uddff\u2114\udac3\udf27",
        28, 49706, 0, -7955881418967639846L, -99989L, false, true, (char) 0, (char) 56576,
        Double.longBitsToDouble(0x3fe65fcb51dd825bL), Double.longBitsToDouble(0x3fe298b7cc809440L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.String:\000\\0\\udb0e\\udcea\\udb9e\\udf4e\\ud828\\udf2d\\ud89a\\udd56\\u0011\\0\\u72b95\\udb0c\\udc65\\0\\0\\udaa7\\udf02\\0\\ud85e\\udc0e\\0\\0\\udbf9\\udf1b\\udb35\\ude4f\\ud8e2\\udc2b\\0\\ud9e4\\ude04\\ud973\\udc26\\0\\0\\0\\0\\0\\ud84f\\udd27\\ueba8\\udb81\\udde0\\udaec\\udf5f\\udac3\\udf8e\\uda3c\\ude32\\uda3c\\udc62\\0\\0\\0\\0\\0\\0\\ubdf8\\ud96d\\udfd2\\ud826\\u...\0121=java.lang.String:\000\\0\\udb0e\\udcea\\udb9e\\udf4e\\ud828\\udf2d\\ud89a\\udd56\\u0011\\0\\u72b95\\udb0c\\udc65\\0\\0\\udaa7\\udf02\\0\\ud85e\\udc0e\\0\\0\\udbf9\\udf1b\\udb35\\ude4f\\ud8e2\\udc2b\\0\\ud9e4\\ude04\\ud973\\udc26\\0\\0\\0\\0\\0\\ud84f\\udd27\\ueba8\\udb81\\udde0\\udaec\\udf5f\\udac3\\udf8e\\uda3c\\ude32\\uda3c\\udc62\\0\\0\\0\\0\\0\\0\\ubdf8\\ud96d\\udfd2\\ud826\\u...\012",
        Z.run(T, 2, 0, 0, 0, "\000\udb0e\udcea\udb9e\udf4e\ud828\udf2d\ud89a\udd56\021\000\u72b95\udb0c\udc65\000\000\udaa7\udf02\000\ud85e\udc0e\000\000\udbf9\udf1b\udb35\ude4f\ud8e2\udc2b\000\ud9e4\ude04\ud973\udc26\000\000\000\000\000\ud84f\udd27\ueba8\udb81\udde0\udaec\udf5f\udac3\udf8e\uda3c\ude32\uda3c\udc62\000\000\000\000\000\000\ubdf8\ud96d\udfd2\ud826\udccc\u00dd\udb08\udc03\udaef\ude77\ud8b1\udf73\u2a47\ud9ea\udc75\ud958\uddfa\000\uda7e\ude54\ud943\ude85\000\ud809\udca4\ud86c\udc54", "\000", "",
        -5, -1000, -1572470784, 9004425822572945252L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe800f00027513aL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.String:\u700d\\ud934\\udf7d\\u00c7\\udb9e\\udf4e\\ud815\\udf45\\udb1e\\udc4f\\uda65\\udda7\\ud8f0\\ude46\\u72b9\\uda89\\udef6\\udae9\\udcce\\ud926\\udd2e\\udbea\\udce7\\udafd\\udd20\\ud896\\ude94\\ud97b\\udcd7\\ud92e\\udc7a\\uda16\\ude28\\ud833\\ude2b\\udb68\\udcfa\\ud94d\\udd00\\u2ffa\\udbd7\\ude5a\\ud973\\udc26\\ud839\\udef7\\ud9e8\\udced\\ud88c\\ude56\\udbe...\0121=java.lang.String:\u700d\\ud934\\udf7d\\u00c7\\udb9e\\udf4e\\ud815\\udf45\\udb1e\\udc4f\\uda65\\udda7\\ud8f0\\ude46\\u72b9\\uda89\\udef6\\udae9\\udcce\\ud926\\udd2e\\udbea\\udce7\\udafd\\udd20\\ud896\\ude94\\ud97b\\udcd7\\ud92e\\udc7a\\uda16\\ude28\\ud833\\ude2b\\udb68\\udcfa\\ud94d\\udd00\\u2ffa\\udbd7\\ude5a\\ud973\\udc26\\ud839\\udef7\\ud9e8\\udced\\ud88c\\ude56\\udbe...\012",
        Z.run(T, 2, 0, 0, 0, "\ud934\udf7d\u00c7\udb9e\udf4e\ud815\udf45\udb1e\udc4f\uda65\udda7\ud8f0\ude46\u72b9\uda89\udef6\udae9\udcce\ud926\udd2e\udbea\udce7\udafd\udd20\ud896\ude94\ud97b\udcd7\ud92e\udc7a\uda16\ude28\ud833\ude2b\udb68\udcfa\ud94d\udd00\u2ffa\udbd7\ude5a\ud973\udc26\ud839\udef7\ud9e8\udced\ud88c\ude56\udbe2\udcd4\udb5c\udf2d\u0324\ud9ab\udcb5\ud867\udf88\uda19\uddac\ud88c\uddac\ud90a\udeb6\udb09\uddca\udb5b\udd64\uda0e\udea1\udae7\udf98\udbff\udeee\udad3\udf22\ud878\udd3c\ud963\udfed\udbba\udf48\ud96e\udd2c\uda2b\udd0f\udbb8\udfd0\uda2d\udf1e\udbe9\udf45\ud8ca\ude76\ud917\udef0\ud95f\udf42\ud844\udcc4\udab0\udef5\ud809\udd7b\udbd8\udd8e\udb08\udccf\ud8e0\udc75\uda5c\udced\u5956\ud85a\udd70\ud9e8\udfc8\udbf5\udd5a\uda36\udfc1\uda00\udea5\ud961\uddc9\ud83a\udd9c\ud978\udf01", "\u0861\u234e\u554a\u4c6b\uad8f\u5f68", "\ud865\udf39\uda10\udfaf\ud92a\udcaa\udadf\ude3e\ueb1b\uda3c\udfc0\udac2\udd85\ud854\udc82\ud868\uddf6\udabf\udf8a\uda6c\udd5a\ud8b1\udf29\uda10\udd36\ud9ae\udcea\ud812\udcbe\udb95\udf2d\ud8ea\ude32\udada\udf38\ub447\ud939\ude28\ub4c4\udb57\udd85\uda49\udeb0\ud8bf\udebe\ud86a\udedd\udb5b\ude45\ud9f1\udd60\udb3a\udd82\udac5\uddeb\ud814\udf2e\udbba\udc30\ud968\udfe0\udb38\udd2f",
        44, 35548, -1745293238, 8375914704508409599L, -37866L, false, true, (char) 28685, (char) 61898,
        Double.longBitsToDouble(0x3fe572b836a94a8dL), Double.longBitsToDouble(0x3fd6f89c93b49882L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 0, "\000\000$\000\000\000\000\u7224\uda89\udef6\udb66\ude66", "\u87dd\u7c8a\u9a1c\u2ed9\ua07a\u8beb\u7aaf\uc185\u5d62\u1f61\u6848\u1645\uc887\000\000", "\ud91d\udeda\u22ee\ud9f9\uddc6\udb6d\udcfd\udb00\udc8a\ud8f1\udef8\ud9c1\ude4a\udbdb\ude36\ud90d\udf7c\uda2c\udf9c\uda72\udf34\ud90d\udf57\u5a33\000\ud944\ude01\udb37\udcca\udbb7\udd05\udae0\udd42\uda66\ude91\ud8e6\udd40\ud8ff\uddbd",
        0, 7353, -1476047175, -8634586789065170209L, 54918L, false, true, (char) 45733, (char) 41673,
        Double.longBitsToDouble(0x3feea3c0694ea084L), Double.longBitsToDouble(0x3fe23472bc18ef5bL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.String:\uca41\\ud883\\ude90\\r\\udbef\\ude97\\ud316\\ud865\\uded5\\r\uca41\0121=java.lang.String:\uca41\\ud883\\ude90\\r\\udbef\\ude97\\ud316\\ud865\\uded5\\r\uca41\012",
        Z.run(T, 2, 0, 0, 4, "\ud883\ude90\015\udbef\ude97\ud316\ud865\uded5\015", "", "\ud926\udd2e\udbea\udce7\udafd\udd20\ud896\ude94\ud9ff\udf7a\udb0e\udfb1\uda27\udd65",
        53, 1525, -2107152627, -6454220379525453087L, -93271L, false, false, (char) 51777, (char) 57953,
        Double.longBitsToDouble(0x3fcbbd85bec27e2cL), Double.longBitsToDouble(0x3fed41d4c502ae7dL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.String:\u9cf7\\>\udbdf\udd2e\udb6b\udcbc\ud865\uded5>\\udbdf\\udd2e\\udb6b\\udcbc\\ud865\\uded5\u9cf7\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 14, "\\>\udbdf\udd2e\udb6b\udcbc\ud865\uded5", "\u4f68\u231e\u299e", "\ud811\udd2b\ud896\ude94\000\000\uda16\ude9d\ud9ec\ude87\ud8fe\udc89\ud9c5\udd4c\udb1b\uddc9\udbe4\udfa5\ud932\udf37\udb43\udefc\ud9f4\ude25\ud87c\ude56\udbe2\udd11\udb06\udd01\001\ud97a\udddd\udb11\udfc3",
        7, 53357, -1615667492, -2225044018882096173L, -36407L, true, true, (char) 40183, (char) 6421,
        Double.longBitsToDouble(0x3fa7818624e886d0L), Double.longBitsToDouble(0x3fee16fd36db5be4L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.String:\uadf3\\>\udbdf\udd2e\udb6b\udcbc\ud865\uded5\udb0e\ude47\udb05\uded6\ud945\ude9d>\\udbdf\\udd2e\\udb6b\\udcbc\\ud865\\uded5\\udb0e\\ude47\\udb05\\uded6\\ud945\\ude9d\uadf3\0121=java.lang.String:\uadf3\\>\udbdf\udd2e\udb6b\udcbc\ud865\uded5\udb0e\ude47\udb05\uded6\ud945\ude9d>\\udbdf\\udd2e\\udb6b\\udcbc\\ud865\\uded5\\udb0e\\ude47\\udb05\\uded6\\ud945\\ude9d\uadf3\012",
        Z.run(T, 2, 0, 0, 8, "\\>\udbdf\udd2e\udb6b\udcbc\ud865\uded5\udb0e\ude47\udb05\uded6\ud945\ude9d", "\u7ece\u09ac\u0655\u7c8a\000\uc0ce\ua841\ube07", "\udb1b\uddc9\udbe4\udfa5\ud932\udf37\udb43\udefc\ud9f4\ude25\ud87c\ude56",
        47, 85589, 1, -7501589605134415196L, -87165L, false, false, (char) 44531, (char) 46322,
        Double.longBitsToDouble(0x3fe1c7676797d054L), Double.longBitsToDouble(0x3fded957f1a3384cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.CodeGenerator|strEscape|java.lang.String,char,java.lang.String,java.lang.String,java.lang.String,java.nio.charset.CharsetEncoder|static",
    "M|com.google.javascript.jscomp.CodeGenerator|add|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|add|com.google.javascript.rhino.Node,com.google.javascript.jscomp.CodeGenerator$Context|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|add|java.lang.String|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addAllSiblings|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addArrayList|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addCaseBody|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addExpr|com.google.javascript.rhino.Node,int,com.google.javascript.jscomp.CodeGenerator$Context|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addExpr|com.google.javascript.rhino.Node,int|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addIdentifier|java.lang.String|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addLeftExpr|com.google.javascript.rhino.Node,int,com.google.javascript.jscomp.CodeGenerator$Context|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addList|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addList|com.google.javascript.rhino.Node,boolean|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addList|com.google.javascript.rhino.Node,boolean,com.google.javascript.jscomp.CodeGenerator$Context|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addNonEmptyStatement|com.google.javascript.rhino.Node,com.google.javascript.jscomp.CodeGenerator$Context,boolean|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|appendHexJavaScriptRepresentation|int,java.lang.Appendable|static",
    "M|com.google.javascript.jscomp.CodeGenerator|strEscape|java.lang.String,char,java.lang.String,java.lang.String,java.lang.String,java.nio.charset.CharsetEncoder|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
