package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class PeepholeSubstituteAlternateSyntax_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 6, "\ud891\udf3d\ud8a6\udcee\udb00\udd4f\udb77\udd6c\udad7\udcfa\ud936\udc69\ud89c\ude47\ud886\udfdf", "\ub48f\ucf80\u943c\u7d9d\ub388\u19a4\uc0cf", "\ud955\udedd\udacc\udf19\ud870\udc33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\ud8a9\udf86\ud89e\ude8d\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        28, 64830, 481106467, -2169066986065222418L, -42135L, true, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 6, "\ud891\udf3d\ud801\udc3b\ud986\udefa\udb77\udd6c\udad7\udcfa\ud936\udc69\uda56\udeaa\udacd\ude5f", "\ub48f\ucf80\u937c\u768d\u5b40\uadcf\uc272", "\ud955\udedd\udacc\udf19\ud870\udc33\ud8d7\udda2\uda01\udff3\ud995\udef2\udb43\uddd8\ud9fa\ude5b\udb36\udd56\ud9e4\udd3d\ud86f\ude6f\uda44\uddce\udb43\udee4\uda84\udfd5\ud822\udcb2\ud8a9\udf86\ud89e\ude8d\ud9ca\udfa2\udbc1\ude4d\ud8fc\udc14",
        26, 27342, 481106467, 5108750011770453445L, -42135L, true, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80cbe4285c5dfL), Double.longBitsToDouble(0x3fdb548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 6, "\ud891\udf3d\ud8a6\udcee\udb00\udd4f\udb77\udd6c\udad7\udcfa\u3415\uda78\udd60\ud85a\udc15", "\ub48f\ucf80\u8bf3\ub35f\u9e8c\u5f84\ub8fa", "\ud955\udedd\udacc\udf19\uda9d\ude38\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\uda52\udf5b\ud89e\uddf4\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        49, 64830, 481106467, -2169066986065222418L, 88937L, false, true, (char) 50986, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 6, 6, "\ud891\udf3d\udbf8\udc57\u7704\udb77\ude10\udae3\udc79\uda96\udfb1\ud80d\udd67\ud9c7\udc2f", "\ub48f\ucf80\u3db8\u7cbe\ub388\u19a4\u58d0\ucd2e", "\udae6\udd19\ud870\udc33\ud9aa\ude2b\uda72\uddcb\udb65\udcdb\ud88b\udc9a\ud928\udf91\udbe9\udfc3\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\uda14\udefc\ud8b9\udc19\udb33\udc36\udb25\ude55\udbc3\udc17\udbb5\udcd7\ud960\udc1b\uda27\udd4a\udb6e\udf4b",
        11, -469, 2131550729, -3180953696608675689L, -51635L, true, true, (char) 22572, (char) 12342,
        Double.longBitsToDouble(0x3fdb016e77ab6b26L), Double.longBitsToDouble(0x3fc0e8bd0a2cfbecL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\012",
        Z.run(T, 2, 6, 3, 15, "\ud891\udf3d\ud8a6\udcee\udb00\udd4f\udb77\udd6c\udad7\udcfa\udaeb\udea4\ud853\udca2\ud886\udfdf", "\ub48f\u4b0f\ua1cb\u7d9d\u18de\u19a4\ud2d0", "\ud955\udedd\udacc\udf19\ud870\udc33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\ud8a9\udf86\ud89e\ude8d\udb33\udc3f\ud9e9\udc36\udbb5\uddb0",
        28, 64830, 481106467, -2214947407269059346L, 71273L, true, true, (char) 3345, (char) 44384,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 10, 3, "\ud891\udf3d\ud8a6\udcee\udb00\udd4f\udb77\udd6c\udad7\udcfa\ud936\udc69\ud89c\ude47\ud886\udfdf", "\ub48f\ucf80\ud3a4\u7d9d\ub388\u19a4\uc0cf", "\ud955\udedd\udacc\udf19\ud870\udc33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\ud8a9\udf86\ud89e\ude8d\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        28, 64830, 481106467, -2169066986065222418L, -42135L, true, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 6, 6, "\ud891\udf3d\ud8a6\udcee\udb00\udd4f\udb60\udc24\udad7\udcfa\ud936\udc69\ud89c\ude47\ud886\udfdf", "\ub48f\u38b1\u6a1b\u7d9d\ub388\u19a4\uc0cf", "\ud955\udedd\udacc\udf19\ud870\udc33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\ud8a9\udf86\ud89e\ude8d\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        28, 64830, 481106467, -2169066986065222418L, -76183L, true, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 6, "\ud891\udf3d\ud8a6\udcee", "\u3a8c\u80e0\u0660\u38af\u2430\u6967\u3f86\u12ce\u943c\u7d9d\ub388\u19a4\uc0cf\ucd2e\u9ab3\ucece\u2bab\u1a42\u209c", "\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\ud8a9\udf86",
        1, 98565, 1341372738, 3849349026312738637L, 89917L, false, true, (char) 1748, (char) 22614,
        Double.longBitsToDouble(0x3fe048ac03777f0cL), Double.longBitsToDouble(0x3fc2fa7b4a8d8ab0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 6, "\ud891\udf3d\ud89b\uddee\ud9b8\ude4c\000\udad7\udcfa\ud936\udc69\ud89c\ude47\ud886\udfdf", "\ub48f\ucf80\u943c\u7d9d\ub388\u1922\uc0cf", "\ud955\udedd\udacc\udf19\ud870\udc33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud93c\udfb6\ud881\ude3f\udb22\udf10\uda84\udfd5\ud822\udcb2\ud8a9\udf86\ud89e\ude8d\uc2d5\ud89d\uddb6\udbb5\uddb0",
        28, 64830, 481106467, -2169066986065222418L, -42135L, true, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 6, 6, "\ud891\udf3d\ud8a6\udcee\udb00\udd4f\udb77\udd6c\udad7\udcfa\ud936\udc69\ud89c\ude47\ud886\udfdf", "\ub48f\ucf80\u943c\u7d9d\ub388\u19a4\uc0cf", "\ud955\udeac\uda77\udd10\ud897\udc1f\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\ud865\udd62\udbe9\udf3f\ud8f4\udde3\ud916\udd22\uda39\udc23\udbcb\udfa8\ud9ee\udc5d\ud822\udcb2\ud9d3\udedc\ud89e\ude2d\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        35, 16999, 212671011, -5083504614854220562L, -42135L, true, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 14, 10, "\ud891\udf3d\ud8a6\udcee\udb2d\udd53\udb77\udd6c\udb96\udf39\udb83\ude0b\ud87f\udcca\udb72\uddcd", "\ub48f\ucf80\u9453\u7d9d\ub388\u0b02\u6bf3", "\ud955\udedd\udacc\udf19\ud88a\udf3e\udbb5\ude96\uda04\udf5c\ud906\ude2c\ud88b\udc69\u995c\udbe9\udf3f",
        39, 91379, 1802934795, 3748654208416557337L, 67246L, true, true, (char) 3898, (char) 3256,
        Double.longBitsToDouble(0x3fc6ce26088fc70cL), Double.longBitsToDouble(0x3fd121cad9ddc3caL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 6, 6, "", "\u17d2", "\ud936\udc69\ud89c\ude47\ud886\udfdf\udbf6\udc60\uda22\udce1\udbcb\udc89\udb9b\udccd",
        13, 35447, -1357114520, 7668587288716400463L, 24125L, false, true, (char) 29766, (char) 40709,
        Double.longBitsToDouble(0x3fb365d226023910L), Double.longBitsToDouble(0x3fe61eb3df5d6775L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 6, "\ud891\udf3d\ud8a6\udcee", "\u9f91\u15c9\u0660\u38af\u2430\u6967\ub48f\ucf80\u943c\u7d9d\u4f17\u1a07\uc0cf\ucd2e\u9ab3\ucece\u2bab\u1a42\u209c", "\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\udab1\uddd1\uda38\udf48\ud81d\udc56\udb50\udd03\ud822\udcb2\ud8a9\udf86",
        1, 98565, 1341372738, 3849349026301400909L, 89835L, false, true, (char) 59875, (char) 22646,
        Double.longBitsToDouble(0x3fe048ac03777f0cL), Double.longBitsToDouble(0x3fb1b4f6951f4560L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 6, 6, "\ud891\udf3d\ud8a6\udcee\ud855\udf3a\uda01\udca0\udad7\udcfa\ud840\udd6e\ud964\udde6\ud9fc\udcdf", "\u8101\ucf18\u943c\u06b2\ub388\u19a4\uc0cf", "\ud914\udebd\ud9b6\udd1f\ud88f\udd27\ud882\udc7e\uda72\ude4d\udb65\udcdb\udb57\udedf\udb67\udd88\udbe9\udf3f\udbb7\udf46",
        51, 8993, -1406509868, 3346712485422679835L, -44883L, false, false, (char) 43750, (char) 26620,
        Double.longBitsToDouble(0x3feb01cbddb053a5L), Double.longBitsToDouble(0x3fe048a8ab773d0cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 6, "\ud8b0\udf16\ud8a6\udcee\udb00\udd4f\udb77\udd6c\udad7\udcfa\ud936\udc69\ud89c\ude47\ud886\udfdf\udbf6\udc60\uda22\udce1\udbcb\udc89\udb9b\udccd\uda7e\udcc3\ud8b1\udc3b\uda7b\udea3\uda20\uddc7\udbd5\udc8d\u0c5e\ud9bc\udf1d\ud955\udedd\udacc\udf19\ud870\udc33\uda5b\ude2a\udb50\udc34\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\ud8a9\udf86", "\u6804\u61db\u7574\uc0df\u9c1f\uc082\u9c84\u2efb\u989d\ucf24\u058a", "\udbfd\udece\ud8f4\udc06\ud9a9\udc5e\uda5c\udc72\ud829\ude5d\udb59\udc30\ubd1d\ud89e\ude61\ud86f\udde6\udbe7\udeb2\ub533\ud9bc\udc92\ud877\udfbf\u2e08\udbd4\udf90\uda0e\udd75\udac5\udd50\ud806\udcf3\udb7f\udcd5\ud8ba\ude51\ud8d3\udff1\udb6d\ude87",
        45, 32084, -1164653061, 1100593362739136203L, -86857L, true, false, (char) 8162, (char) 3890,
        Double.longBitsToDouble(0x3fde42c8aee06612L), Double.longBitsToDouble(0x3fb4065257f4b950L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 8, 4, "\ud891\udf3d\ud8a6\udcee\udb00\udd4f\udb77\udd6c\udad7\udcfa\ud936\udc69\u5244\ud886\udfdf", "\ub48f\ucf80\u943c\u649d\ub388\u19a4\uc0cf", "\ud955\udedd\udacc\udf19\ud870\udc33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud908\udd85\udbf7\udf93\ud89e\ude8d\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        28, 64830, 481106467, -2169066986065222418L, -42135L, true, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 1, 6, 6, "\ud891\udf3d\ud8a6\udcee\udb00\udd4f\udb77\udd6c\udad7\udcfa\ud936\udc69\ud878\ude16\ud886\udfdf", "\ub48f\ucf80\u943c\u7d9d\ub388\u19a4\uc0cf", "\ud955\udedd\u7213\uda4f\ude6f\ud882\udccd\uda72\ude4d\udb65\udcdb\uda6a\ude0f\udb67\udd55\udbe9\udf3f\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\ud8a9\udf86\ud89e\ude8d\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        28, 64830, 481106467, -2169066986065222418L, -42135L, true, true, (char) 27761, (char) 14756,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 5, "\ud891\ude86\ud8a6\udcee\udb00\udd4f\udb77\udde6\ud85f\ude1d\ud960\uddc3\udbcf\udeeb\udbdc\udf26\ud83a\udc62\uda22\udce1\udbaa\ude79\uda0c\ude63\uda7e\udcc3\ud8b1\udc3b\uda7b\udea3\uda20\uddc7\udbd5\udc8d\u0c5e\ud9bc\udf1d\ud9ce\uded3\udacc\udf19", "\ubb8a\u9eff\u56f2\ud413\ub152\ua49d\u00c7\uac26\u017c\u90a2\u6777\u28d5\u928a\u708e\u68b0\u61db\u7574", "\udb6e\udf4b\ud961\udd7a\ud980\udc0c",
        39, 8503, 1655478423, 7753591771436627713L, 14949L, true, false, (char) 44062, (char) 30678,
        Double.longBitsToDouble(0x3fdf8a61be631f5cL), Double.longBitsToDouble(0x3fe3c3038768b06eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 0, "\ud891\udf3d\001\000\000\ud8ed\udf65\000\000\ud981\udce0", "\ub48f\u73d9\u943c\u7d9d\ub388\u19a4\uc0cf", "\ud955\udedd\udacc\udf19\ud868\ude33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf3f\u00a1\ud916\udd22\uda39\udc23\udb43\udee4\uda98\udd1f\000\ud8a9\udeca\ud89e\ude8d\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        28, 64830, 481106467, -2169066986065222418L, -42135L, false, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c7001de3aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 6, "\ud891\udf3d\ud8a6\udcee\ud934\udd49\u9023\000\udbab\ude95\ud89c\ude47\ud886\udfdf", "\ub48f\ucf80\u943c\u7d9d\ub388\u19a4\u20cb", "\ud955\udedd\udacc\udf19\ud870\udc33M\000\udbd7\udcd4\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\ud897\ude86\ud89e\ude8d\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        28, 64830, 481106467, -2169066986065222418L, -42135L, true, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 6, 6, 6, "\ud891\udf3d\ud8a6\udcee\udb00\udd4f\udb77\udd6c\udad7\udcfa\udb02\ude0f\udb6d\udf2b\ud886\udfdf", "\ub48f\ucf80\u943c\uaa0f\u54d9\u092d\uc0be", "\ud955\udedd\udacc\udf19\ud870\udc33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\ud8a9\udf86\ud89e\ude8d\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        28, 64830, 481106467, -2169066986065222418L, -42135L, true, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd3332c79L), Double.longBitsToDouble(0x3fea88144079240cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 12, 6, "\ud891\udf3d\ud8a6\udcee\udb00\udd4f\udb77\udd6c\udad7\udcfa\ud936\udc69\ud89c\ude47\ud886\udfdf", "\ub48f\ucf80\u943c\u7d9d\ub388\u19a4\uc0cf", "\ud955\udedd\udacc\udf19\ud870\udc33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf19\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\ud8a9\udf86\ud89e\ude8d\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        28, 64830, 481106467, -2169066986065222418L, -42135L, true, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 6, 6, "\ud9f0\ude2d\ud8a6\udcee\udbca\udf96\ud9ce\uded0\udad7\udcfa\ud936\udc69\ud89c\ude47\ud886\udfdf", "\ub48f\u71c2\uc966\u7d8a\ub388", "\udadf\udd8b\udb8b\udfeb\ud9f6\udd2e\ud8fd\udce1\ud870\udc4c\ud870\udc08\uda72\ude4d\udb65\udcdb\ud88b\udc9a",
        31, 87715, 2066526881, 6630965195077230044L, -23943L, true, true, (char) 25783, (char) 60398,
        Double.longBitsToDouble(0x3fe6a87549421fdeL), Double.longBitsToDouble(0x3fe45a7f9f4d356bL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 6, "\000\ud8a6\udced\udb00\udd4f\udb53\udd6c\udad7\udcfa\ud936\udc69:\ud886\udfdf", "\000\000\000\000\u77ff\000\uc0cf", "\ud955\udedd\udacc\udf19\ud870\udc33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\ud979\udde4\udb22\udf10\uda98\udd1f\udb4f\udf29\000\000\udb33\udcb5B\000",
        43, 64830, 481106467, -2169066986074528530L, -42135L, true, true, (char) 54385, (char) 0,
        Double.longBitsToDouble(0x3e342e2ef8000000L), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 6, "\udb05\uded8\ud879\udd19\udb9e\udcd5", "\u3c00\u0660\u38af\u2430\u6967\u155e\ucfa4\u943c\u76cc\u2654\u19a4\u5920\u05c4\u29fa\u5170", "\uda58\udc0a\uda72\uddf6",
        8, 78224, 341451957, 6074716408550726589L, 71484L, false, true, (char) 38875, (char) 8427,
        Double.longBitsToDouble(0x3fd56e351b60c47eL), Double.longBitsToDouble(0x3fcaa1ca25087f78L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 15, 6, "\ud891\udf2e\ud8a6\udcee\udb00\udd4f\udb77\udd6c\udad7\udcfa\ud936\udc69\ud89c\ude47\ud886\udfdf", "\ub48f\ucf80\u943c\u7d9d\ub388\u19a4\uc0cf", "\ud955\udedd\udacc\udf19\ud870\udc33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\ud8a9\udf86\ud89e\ude8d\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        28, 64830, 481106467, -2169066986065222418L, -42135L, true, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 6, 6, "\000", "", "\ud936\udc69\uda56\udeaa\udacd\ude5f\udbf6\udca9\uda22\udce1\udbcb\udc89\udb9b\udccd",
        21, 58539, 443489260, -2715034540689155942L, 24125L, false, true, (char) 29766, (char) 40709,
        Double.longBitsToDouble(0x3fec04ba44669c75L), Double.longBitsToDouble(0x3faeda44873ea160L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 6, 13, 6, "\ud891\udf3d", "\u1a3f\ud419\u7e76\u8cba\u020d\u063a\u331b\ub48f\ucf80\u3db8\u8149\ub3af", "\u0c5e\ud9bc\udf1d\ud955\udedd\udae6\udd19\ud870\udc33\ud9aa\ude2b\ud9c4\udce8\udb65\udc76\ud88b\udc9a",
        48, 87847, 2066526881, 6630965195077230044L, -23943L, true, true, (char) 16561, (char) 253,
        Double.longBitsToDouble(0x3fe2b40570421fdeL), Double.longBitsToDouble(0x3fce422bfd34d5acL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 15, 4, "\udbad\udc6a\u83d2\u7704\udb77\ude10\udae3\udc79\uda96\udfb1\ud80d\udd67\ud9c7\udc2f", "\ub48f\ucf80\u3db8\u7cbe\ub388\u19a4\u58d0\ucd2e", "\udafb\udce3\ud9dd\uddb9\ud997\udcd4\uda72\uddcb\udb65\udcdb\ud88b\udc9a\ud928\udf91\udb98\udec4\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\uda14\udefc\ud8b9\udc19\udb33\udc36\udb25\ude55\ud8b8\ude13\udbb5\udd00\ud960\udc1b\uda27\udd4a\udb6e\udf4b",
        11, -469, 2131550729, -1857739831091895559L, -51635L, true, true, (char) 22572, (char) 12342,
        Double.longBitsToDouble(0x3fdb016e77ab6b26L), Double.longBitsToDouble(0x3fb9caba1459f7d8L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\012",
        Z.run(T, 2, 1, 3, 15, "\ud891\udf3d\ud8bb\udeee\udb00\udd4f\udb77\udd6c\udad7\udcfa\udaeb\udea4\ud853\udca2\ud886\udfdf", "\ub48f\u4b0f\ua1cb\u7d9d\u18de\u19a4\ud2d0", "\ud955\udedd\udacc\udf19\ud870\udc33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\ud8a9\udf86\ud89e\ude8d\udb33\udc3f\ud9e9\udc36\udbb5\uddb0",
        28, 64830, 481106467, -2214947407269059346L, 71273L, true, true, (char) 3345, (char) 44384,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\012",
        Z.run(T, 2, 3, 3, 15, "\u81f5\ud872\udf54\ud995\ude3a\ud9db\ude3b\udad7\udcfa\udab5\uddad\uda31\udd91\ud9fd\udc49", "\u4c83\u4b0f\ua1cb\u7d9d\u18de\u19a4\uc589", "\ud955\udedd\ud890\udf89\ud821\udcae\ud882\udc66\uda72\ude4d\ud85e\uddb8\ud88b\udcf6\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\uda29\udf64\udb43\udee4\uda84\udfd5\udba0\udd91\ud8a9\udeea\ud89e\ude02\udbc4\udfa8\ud819\udd5e\udbb5\uddb0",
        28, 64830, 481106467, -2214947407269059346L, 71273L, true, true, (char) 32517, (char) 44384,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c75abde3aL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 7, 15, "\ud920\udc85\ud8a6\udcee\udb00\udd4f\udb77\udd6c\udad7\udcfa\udaeb\udea4\ud853\udca2\ud886\udfdf\udbf6\udc60\uda22\udce1\udbcb\udc89\ud9e5\ude92\ud8ee\udfb4\ud8b1\udc3b\udb6b\ude1b", "\u6e20\u9ab3\ucece\u6f05\u3e5f\uca7d\ub022\u18a3\uc7f9\ucc7f\u4c31", "\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\ud8a9\udf86\ud85c\udf42\ud8ab\udeb7\udb55\udf4b\udbb5\uddb0\uda8f\uddf8\udb59\ude27\uda68\udfd3\ud8dc\udf42\ud961\udd7a\ud980\udc0c",
        40, 22935, 1656557538, 7753591771436627713L, 14949L, true, false, (char) 30576, (char) 30892,
        Double.longBitsToDouble(0x3fe4bf2198da40ddL), Double.longBitsToDouble(0x3fdf319219b73ceeL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 10, 3, "\ud891\udf3d\ud8a6\udceeF\udb77\udd49\udad7\udcfa\ud936\udc69\u013a\ud886\udfdf", "\ub48f\ucf80\ud3a4\u7d9d\ub388\u19a4\uc0cf", "\ud955\udedd\udacc\udf19_\000\000\000\ud88b\udc3d\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\u9ddc\ud9e2\udf10\uda84\udfd5\ud822\udcb2\ud8a9\udf86\ud89e\ude8d\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        28, 64830, 11344419, 0L, -100000L, false, false, (char) 39129, (char) 44367,
        Double.longBitsToDouble(0x3fe80b580285c5dfL), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 10, 0, "\u00c0", "\u199b\u9f91\u15c9", "\udbf6\udc60\uda22\udce1\udbcb\udc89\u0086\ud830\udcbc\ud939\udcff",
        16, 76896, 1493456719, -6089736027650392029L, 14021L, true, false, (char) 2966, (char) 41954,
        Double.longBitsToDouble(0x3fe61eb3df5d6775L), Double.longBitsToDouble(0x3f4a24c000000000L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=void |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\012",
        Z.run(T, 2, 1, 1, 6, "\ud891\udf3d\ud9e3\udcf1\udabf\udc13\000", "\ub350\u59f4\u0a58\u5222\u7092\uc082\u8720\u7d9d\u99a4\u1922\uc0cf\u0b2f\u766f\uce13\u2bab\u1a42\u58ab\uc086\u5054\ubd15\ucc7f\u4c31\ua49d\uc536\ua5a1\u55a7\u1824\u1f16\u6505\u9b10\uc2d5\u6647\u54ad\u30e1\uc0df\u9c1f\u9964\u841b\u506a\u989d\ucf24\u058a\u0a2b\ub44f", "\udb5a\udce6\uda71\udd3c\udb46\udf9c\ud87e\udee0\uda2d\udcda",
        27, 4842, -1686911738, 8461779005283153539L, 14095L, false, false, (char) 3785, (char) 18830,
        Double.longBitsToDouble(0x3fde1878ee89ba52L), Double.longBitsToDouble(0x3fbbd1eb4b123358L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 6, "\000", "\000\u9f91\u15c9", "\udbf5\udfb5\uda22\udce1\udbcb\udc89",
        31, 47143, -217719553, -5836665115286680832L, -40263L, true, true, (char) 58258, (char) 29766,
        Double.longBitsToDouble(0x3fe2fc05344d9748L), Double.longBitsToDouble(0x3fc808e45b0f59ecL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 6, "\024", "\u199b\u9f91\u15c9", "\uda5e\udef5\uda23\udfd2\udbcb\udc89\udb9b\udccd",
        13, 35447, -1343875992, 7668587288716203855L, 24125L, false, true, (char) 29766, (char) 40709,
        Double.longBitsToDouble(0x3fb365d226023910L), Double.longBitsToDouble(0x3fe61eb3df5d6775L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 0, "\ud891\udf3d\001\000\000\ud8ed\udf65<\000\ud981\udce0", "\ub48f\u73d9\u943c\u7d9d\ub388\u19a4\uc0cf", "\ud955\udedd\udacc\udf19\ud868\ude33\ud882\udc7e\uda72\ude4d\ud89d\udcd7\ud88b\udc9a\udb67\udde3\udbe9\udf3f\u00a1\ud916\udd22\uda39\udc23\udb43\udee4\uda98\udd1f\000\ud8a9\udeca\ud89e\ude8d\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        42, 60988, 1380411666, -2169066663942675218L, -42135L, false, true, (char) 27761, (char) 6794,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd1fcec7001a23aL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 0, "\ud891\udf3d\001\000\000\ud8ed\udf65\013\000\ud981\udce0", "\ub48f\ubf65\u1888\u1696\u4826\u2231\uc0cf", "\ud955\udedd\udacc\udf19\ud868\ude33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udae5\udd8c\ud850\udca8\ud916\udd22\uda39\udc23\udb43\udee4\uda98\udd1f\udab2\udc4c\uda95\udf5f\ud89e\ude8d\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        28, 64830, 481106467, -2169066986065222418L, -42135L, false, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c7001de3aL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 0, "\ud891\udf3d>\000\000\ud8ed\udf65\000\000\ud981\udce0", "\ub48f\u73d9\u943c\u7d9d\ub388\u5467\uc210\ucd2e\u9ab3", "\ud913\ude5d\ud882\udcad\u4955\udb65\udcdb\ud88b\udc9a\udb67\udde3",
        29, 57217, 1543891838, 7678247983804416980L, -100000L, false, true, (char) 60398, (char) 53450,
        Double.longBitsToDouble(0x3fd421fde5169fe6L), Double.longBitsToDouble(0x3fea69ab5cb67130L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 0, "\ud891\udf3d\001\000\000\ud8ed\udf65\000\000\ud981\udce0", "\u146b\u73d9\u943c\u7d9d\ub388\u19a4\uc0cf", "\ud955\udedd\udacc\udf19\ud868\ude33\ud882\udc7e\udbd2\ude02\udb88\udd55\ud869\udda9\udb67\udde3\udbea\udf3f\u00a1\udacb\udfb7\ud97c\udf4c\ud8e6\udc3a\uda8f\udce5\udbe2\udfd0\udb93\udfb2\ud839\ude00\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        28, 39422, -546388758, -2169066071237188370L, -42135L, false, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c7001de3aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 9, "C\ud8a6\udced\udb00\udd4f\udb53\udd6c\udad7\udcfa\ud936\udc69:\ud886\udfdf", "\000\000\000\000\u77ff\000\uc0cf", "\ud955\udedd\udacc\udf19\ud870\udc33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\ud979\udde4\udb22\udf10\uda98\udd1f\udbba\udffe\uda3e\ude06\000\udb33\udcb5B\000",
        43, 64830, 481106467, -2169066986074528530L, -42135L, true, true, (char) 31857, (char) 47155,
        Double.longBitsToDouble(0x3e342e2ef8000000L), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 6, "\000\ud8a6\udced\udb00\udd4f\udb53\uddce\uda35\ude68\udb12\ude1a\010\ud886\udfdf", "\000\000\000\000\u77ff\000\uc0cf", "\ud955\udedd\udacc\udf19\ud870\udc33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\ud979\udde4\uda1f\udf23\uda98\udd1f\udb4f\udf29\000\000\udb33\udcb5B\000",
        43, 64830, 481106467, 2298503844277003502L, -42135L, true, true, (char) 54385, (char) 0,
        Double.longBitsToDouble(0x3e342e2ef8000000L), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 0, "\udb00\udf3d\udb10\udc72\udb9b\udd96\014\ud8ed\udf65\ud891\udda4\ud844\udc9c\udb59\udfb3", "\ubf8f\u7466\ub93c\u7d9d\ub388\u19a4\uc0cf\ucd2e\u5401\u1326", "\ud882\udc7e\uda72\ude4d",
        44, 59437, 353576117, -664050923768643436L, -58364L, false, false, (char) 26504, (char) 113,
        Double.longBitsToDouble(0x3fd000000360c47eL), Double.longBitsToDouble(0x3febbfb591421f41L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 0, "\ud891\udf3d\001\000\000\ud8ed\udf65<\000\ud981\udce0", "\ub48f\u73d9\ua6be\u701a\ub388\u19a4\uc0cf", "\ud955\udedd\udacc\udf19\ud868\ude33\ud882\udc7e\uda72\ude4d\ud87e\udd1b\ud88f\ude5f\udb67\udde3\udbe9\udf3f\u00a1\ud916\udd22\uda39\udc23\udb43\udee4\uda98\udd1f\000\ubecc",
        1, 98565, 1341372738, 2101952370026356300L, -61362L, true, true, (char) 1748, (char) 22614,
        Double.longBitsToDouble(0x3fe048ac00008e0cL), Double.longBitsToDouble(0x3fc2fa7b4a8f3f98L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 0, "\ud891\udf3d\ud9f0\udeb9\015\000\ud8ed\udf65<\000\ud981\udce0", "\ub48f\u73d9\u943c\u7d9d\ub388\u19a4\uc0cf", "\ud955\udedd\udacc\udf19\ud868\ude33\ud882\udc7e\uda72\ude4d\ud89d\udcd7\ud88b\udc9a\udb67\udde3\udbe9\udf3f\u00a1\ud916\udd22\uda39\udc23\udb43\udee4\uda98\udd1f\000\ud8a9\udeca\ud89e\ude8d\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        42, 49828, 1380411666, -2169066663942675218L, -42135L, false, true, (char) 27761, (char) 6794,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd1fcec7001a23aL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 0, "\ud891\udf3d\001\000\000\ud8ed\udf65\ud958\udd70\"\ud981\udce0", "\ub48f\u73d9\u943c\u7d9d\ub388\u19a4\uc0cf", "\ud955\udedd\udacc\udf19\ud868\ude33\ud882\udc7e\uda72\ude4d\ud89d\udcd7\ud88b\udc9a\udb67\udde3\udbe9\udf3f\u00a1\udb09\udd5c\uda39\udc23\udb43\udee4\udbe2\ude85\ud9a9\udf07\ud8a9\udf72\ud89e\ude8d\ud830\udd1d\ud89d\uddf8\udb7d\udc58",
        -3, 10396, 1749068578, -2169066801381628690L, -7991L, true, false, (char) 41627, (char) 26724,
        Double.longBitsToDouble(0x3fd1fcec7001a23aL), Double.longBitsToDouble(0x3feb632c6167581dL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 2, "\ud891\udf3d\ud992\udc09\udb1b\udd5d\u932d\uf51e\011\000\ud981\udce0\u7cf2", "\ubf65\u1888\u1696\u4826\u2231\uae7c\ucd2e\ua58a\uc5ed\u2bab", "\udb43\udc20\udb65\udf67\ud88b\udc9a\udb67\udde3\uda1a\udc85\ud8e0\udd42\ud916\udd22\uda39\udc23\ud95c\udc5c",
        15, 86566, 1498690076, 7248976264234613855L, 25992L, false, false, (char) 10762, (char) 24422,
        Double.longBitsToDouble(0x3fe890e724eee1e5L), Double.longBitsToDouble(0x3fe6440832641580L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 0, "\ud9f6\udc40\001\000\000\ud8ed\udf65\013\000\ud981\udce0", "\ub48f\ubf65\u1888\u1696\u4826\u2231\uc0cf\ucd2e\u10ec\ucece\u2bab\ud441\u209c\ubb8a\u4eb1\u4955\ucc0e\u76f1\u5930\uabcb\u9589\u00b9\u199f\u7a4e\u73fb\u9b10\ub09a\u6804\u61db\u7574\uc0df\u9c1f", "\ud980\udc0c\udaf4\udd85\u2866\uda89\ude67\ud944\udcfa\ucb94\udbfd\udece",
        0, 2808, 1822994535, -5819780937689278941L, -34242L, false, false, (char) 22357, (char) 39372,
        Double.longBitsToDouble(0x3fe298de490f2e66L), Double.longBitsToDouble(0x3fea74a941e35d06L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 0, "\ud891\udf3d\udaf5\udc24\udb6a\ude63'\ud8ed\udf65\013\000\ud981\udce0", "\ub48f\ubf65\u1888\u1696\u4826\u2231\uc0cf", "\ud955\udedd\udacc\udf19\ud868\ude33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udae5\udd8c\ud850\udca8\ud916\udd22\uda39\udc23\udb43\udee4\ud9ac\udcf0\udab2\udc4c\uda95\udf5f\ud89e\ude8d\udb33\udcb5\ud811\udf3d\udbb5\udddc",
        28, 64830, 481106467, -2169066986065222418L, -42135L, false, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3fd0548c7001de3aL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 0, "\u9202>\000\000\ud8ed\udf65\000\udabb\ude7c\udb35\ude5f", "\ub48f\u73d9\u943c\u8cc3\ub39c\u5467\uc210\ucd2e\u9ab3", "\ud913\ude5d\udbd9\udfd9\ud935\ude7b\udb65\udcbd\ud88b\udc9a\udb67\udde3",
        29, 57217, 1543891838, 7678247983804416980L, -100000L, false, true, (char) 60398, (char) 5579,
        Double.longBitsToDouble(0x3fd42333a5169fe6L), Double.longBitsToDouble(0x3fea69ab587e7130L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 15, 6, "\000\ud8a6\udced\udb00\udd4f\ud8f3\udf1e\uda35\ude68\udb12\ude1a\010\ud886\udfdf\udbf6\udc60\u009f\000\udac8\udfe3\ud900\uddec\u1755\udbbc\udf77\000\ud9af\udc9a\u0c5e\uda1a\udf2c", "\u1a42\u209c\uabf0\u1962\uc7d5\ucc7f", "\ud916\udd22\ud979\udde4\ud9fc\udd23\uda98\udd1f\udb4f\udf29\000\000\udb33\udcb5B\ud90f\udf87",
        35, 39924, 1838894607, 2899829502286816143L, -42135L, true, true, (char) 21106, (char) 36368,
        Double.longBitsToDouble(0x3e4f88737c000000L), Double.longBitsToDouble(0x3fe79d463899123fL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 6, "\uda3b\udf01\udb1e\udc5f\uda33\udddc\udb53\ude16\uda35\ude68\udb12\ude1a\014\ud886\udfdf", "\000\000\ud382M\u77ff\000\uc0cf", "\ud955\udedd\udacc\udf19\ud870\udc33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbcd\udd3c\ud8f4\udde3\ud916\udd22\ud905\udfbc\ud8e2\udf64\uda98\udd1f\udb4f\udf29\000\000\udb33\udcb5B\000",
        51, 26430, -616600829, 2298503844277003502L, -42135L, true, true, (char) 54385, (char) 0,
        Double.longBitsToDouble(0x3e115f3be0000000L), Double.longBitsToDouble(0x3fceca9b0187d6e8L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 11, "\ud891\udf3d\ud9f0\udeb9\015\000\ud84d\ude95\ud90b\udce4\uda04\udfe4\ud981\udce0", "\ub48f\u73d9\u943c\u7d9d\ub388\u19a4\uc0cf", "\ud955\udedd\udacc\udf19\ud868\ude33\ud882\udc7e\uda72\ude4d\ud89d\udcd7\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ubaa1\ud916\udd22\uda39\udc23\udb43\udee4\udaf8\udf50\udad6\uded3\udaa2\udfc3\ud89e\ude8d\ud9b7\udf58\udbc7\udd1d\udb89\ude8a",
        0, 49828, 1380411666, -2169066663942675218L, -42051L, false, true, (char) 27761, (char) 6794,
        Double.longBitsToDouble(0x3fe80b5cd285c5dfL), Double.longBitsToDouble(0x3feb6ee63af52c81L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 0, "\ud891\udf3d\udb25\ude13\015\000\ud8ed\udf65\\\000\ud981\udce0", "\ub48f\u73d9\uc29d\u3681\u212a\ub1ab\u4021", "\udb82\udfb2\udb09\udc50\ud9c9\udf10\ud882\udc7e\uda72\ude4d\ud89d\udcd7\ud88b\udc9a\ud85d\udd49\ud990\udfd9\ud9ed\udcef\uda2b\udf6d\ud947\udd24\udaed\udfb9\uda61\udfb0\ud98b\udf22\ud9f9\udf90\ud89e\ude8d\udb33\udcb5\ud89d\uddf8\ud9ed\udfde",
        37, 40941, 1264628798, -7304888051328911286L, -19214L, true, false, (char) 41536, (char) 26724,
        Double.longBitsToDouble(0x3fd1fcec7001a23aL), Double.longBitsToDouble(0x3fe3ae8dc765b38fL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 8, 0, "\ud891\udf3d\udaee\udc98\012\000\ud8ed\udf65\ud958\udd70\udab8\udd1e\ud9cc\udfbe", "\ub48f\u9d55\u7a60\u7d9d\ub388\u19a4\u55fd", "\ud955\udedd\udacc\udf19\ud868\ude33\ud882\udc7e\uda72\ude4d\ud89d\udcd7\ud88b\udce6\udb67\udde3\ud9bb\udf69\ud90a\udd39\uda7d\udcff\uda39\udc23\udbec\udf65\udbed\udd8c\ud81f\udf04\udabd\uddbc\udb15\udefb\ud830\udd1d\ud89d\uddf8\ud9ca\udc80",
        -3, 10396, 1749068578, -2169066801381628690L, -1065L, true, false, (char) 41627, (char) 26724,
        Double.longBitsToDouble(0x3fd1fcec7001a23aL), Double.longBitsToDouble(0x3fd6c658cb34876cL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 0, "\ud891\udf3d\001\ud975\udc19\"\ud8ed\udf65\ud958\udd70\"\ud981\udce0", "\ub48f\u73d9\u943c\u7d9d\ub388\u19a4\uc0cf", "\ud955\udedd\udacc\udf19\ud868\ude33\ud882\udc7e\uda72\ude4d\ud89d\udcd7\ud88b\udc9a\udb67\udde3\udbe9\udf3f\u00a1\ud959\udfa5\uda01\udefd\udb3d\udf20\udbe2\ude85\ud9a9\udf07\ud8a9\udf72\ud89e\ude8d\ud830\udd1d\ud89d\uddf8\udb7d\udc58",
        -3, 10396, 1749068578, -2169066801381628690L, -7991L, true, false, (char) 41627, (char) 26724,
        Double.longBitsToDouble(0x3fd1fcec7001a23aL), Double.longBitsToDouble(0x3feb632c6167581dL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 6, "\ud891\udf3d\ud992\udc09\udb1b\udd5d\u932d\uf51e\011\000\ud981\udce0", "\u7d6d\ubf65\u1888\u1696\u4826\u2231\uae7c", "\ud91d\uddfd\udacc\udf19\udb0e\udf64\ud9ac\udf4d\udb43\udc20\udb65\udf67\ud88b\udc9a\udb67\udde3\uda1a\udc85\ud8e0\udd42\ud916\udd22\uda39\udc23\ud95c\udc5c\ud8ae\udf8a\udad2\udd58\uda95\udf5f\udabf\udf6e\udae4\udee8\ud927\udc77\u9e6a",
        57, 54751, 484704308, -2169073583143901970L, -42044L, true, true, (char) 32261, (char) 3837,
        Double.longBitsToDouble(0x3fd704bcdba2ee96L), Double.longBitsToDouble(0x3fdbe9cca268dbceL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 0, "\udb35\udcc9\udaf5\udc58\udb6a\ude63'\ud8ed\udf65\013\000\ud981\udce0", "\ub48f\ubf65\u1888\u1696\u4826\u2231\uc0cf", "\ud955\udedd\udacc\udf19\ud868\ude33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udae5\udd8c\ud850\udca8\ud916\udd22\uda39\udc23\udb43\udee4\ud9ac\udcf0\udab2\udc4c\uda95\udf5f\ud89e\ude8d\udb33\udcb5\ud811\udf3d\udbb5\udddc",
        28, 64830, 481106467, -2169066986065222418L, -42135L, false, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd2e0c5dfL), Double.longBitsToDouble(0x3fd0548c7001de3aL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 2, "\u9202>\000\000\ud8ed\udf65\000\ud922\udef8\ud938\udf80", "\ub48f\u73d9\u943c\u8cc3\ub39c\u5467\uc210\ucd2e\u9ab3\ud306\u0959\u3e1c", "\udb65\udcbd\ud88b\udc9a\udb67\udde3\ud861\udc9f",
        37, 4838, 1787731420, 3748547211419527449L, -55872L, false, true, (char) 60071, (char) 32892,
        Double.longBitsToDouble(0x3fe45a7f9f4d356bL), Double.longBitsToDouble(0x3fc84e260ae9f8a0L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 0, "\ud891\udf3d\udaee\udc98\012\000\ud8ed\udf65\udb0a\udf66\udab8\uddcc\ud9cc\udfbe", "\ub48f\u9d55\u81ef\u5497\u59eb\u19a4\u55fd", "\udb89\udf4f\udbef\udcb2\uda59\udeaf\ud82f\ude6f\uda72\ude4d\ud89d\udcd7\ud88b\udce6\udb67\udde3\ud834\udc69\ud90a\uddd1\uda7d\udcff\uda39\udc23\udbec\udf65\udbed\udd8c\ud81f\udf04\ud91e\udf2e\ud906\udeb1\udbdf\ude5b\ud891\uddab\ud9ca\udc80",
        -3, 10396, -2103727326, 8675141423861736686L, 11066L, false, true, (char) 28728, (char) 4673,
        Double.longBitsToDouble(0x3fec80d07285c5dfL), Double.longBitsToDouble(0x3fd1fcec7001a23aL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 6, "\ud891\udf3d\ud8a6\udcee\udb00\udd4f\udb77\udd6c\udad7\udcfa\ud936\udc69\ud89c\ude47\ud886\udfdf", "\ub48f\ucf80\u943c\u7d9d\ub388\u19a4\uc0cf", "\ud955\udedd\udacc\udf19\ud870\udc33\ud882\udc7e\uda72\ude4d\udb65\udcdb\ud88b\udc9a\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\uda39\udc23\udb43\udee4\uda84\udfd5\ud822\udcb2\ud8a9\udf86\ud89e\ude8d\udb33\udcb5\ud89d\uddf8\udbb5\uddb0",
        28, 64830, 481106467, -2169066986065222418L, -42135L, true, true, (char) 27761, (char) 44367,
        Double.longBitsToDouble(0x3fe80b5cd2d3c5dfL), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 6, 6, "\000\000\000\000\000\000\000\000", "\000\000\000\000\u77ff\000\u69cf", "\ud8c8\udee3\udacc\udf19\ud870\udc33\ud882\udc7e\ud8e7\udcc7\udb33\ude18\udbb5\udd3a\u00b5\udbe9\udf3f\ub2a1\000\000\000\000\000\000\000\udb33\udcb5B\000",
        43, 64830, 481106467, -2169066986074528530L, -42144L, false, false, (char) 151, (char) 0,
        Double.longBitsToDouble(0x3e342e2ef8000000L), Double.longBitsToDouble(0x3fd0548c70f3de3aL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 14, "\udbac\udd09\ud8a6\udcee\u360d\udb77\udd6c\udaf2\udfd6\udaeb\udea4\ud853\udca2\ud886\udfdf\udbf6\udc60\uda22\udce1\udbcb\udc89\ud9e5\ude92\ud976\udf21\u81d4\udb64\udebb\u22bc\u07c6\udb16\udf6f\u703e\ud955\udea2\u97ff\udac2\udd55\uda41\uddd8\ud8f6\udf9e\udb65\udc1c\ud88b\udcbe\udb67\udde3\udbe9\udf3f\ud8f4\udde3\ud916\udd22\ud9e1\udc6d\ud8bc\udd40\ud989\udf2a\ud822\udd3a\ud8cb\udd86\ud85c\udf42\ud9b6\udfb8\udb55\udf4b\udbb5\uddb0\uda8f\uddf8\ud943\ude1c\uda68\udfd3\ud8dc\udf42\ud96a\udd7a\udabf\ude2b\ud89b\udeaa\uaa9a\ud9b1\uded4\ud944\udd0a\ucb94\udbfd\udece\ud8f4\udc06\udbc0\udfd6", "\u1378\u7773\u1d10\u7581\ub864\u18b0\u1c87", "\ud8c3\udef6\ud890\udd2b\u9f5f",
        47, 21538, 1617423761, 915756201374998652L, -74L, false, false, (char) 33102, (char) 19094,
        Double.longBitsToDouble(0x3fd0aae5f445428eL), Double.longBitsToDouble(0x3fddebe56842d534L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 5, "\ud891\udf3d>\000\ue79b\ud8ed\udf65\000\000\ud981\udce0", "\ub48f\u73d9\u943c\u7d9d\ub388\u5467\uc210\ucd2e\u9ab3", "\ud913\ude5d\ud882\udcad\ud810\udd52\udb65\udcdb\ud88b\udc9a\udb67\udde3",
        41, 57217, 1543891838, 7678247983804416980L, -100000L, false, true, (char) 60398, (char) 53450,
        Double.longBitsToDouble(0x3fd421fde5169fe6L), Double.longBitsToDouble(0x3fea69ab5cb67130L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 6, "\udaed\udef5\udb25\ude13\015\000\ud8ed\udf65\\\ud820\udc0f\udb75\udea9\udbf6\udc60\uda22\udce1\udbcb\udc89\ud9f2\ude39\uda18\udd2b\ud914\ude0a\ud900\ude5e\udaae\uded4\udb20\ude22\ud9ab\ude3f\ud9c9\udff0\udb82\udfb2\udb09\udc50\ud9c9\udf10\ud882\udc7e\uda72\ude4d\ud89d\udcd7\ud88b\udc9a", "\ud6d3\u9a62\u8091\u4bb1\uab6e\ub9eb\u963d\u9b10\ub09a\u6804", "\uda76\udf9f\ud892\udcaf",
        2, 82785, -1208834460, -8210939490653046016L, -77511L, true, true, (char) 26724, (char) 36838,
        Double.longBitsToDouble(0x3f4a23a8630ae000L), Double.longBitsToDouble(0x3fef5c0c649bf79aL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 8, "\udbe7\udcb3\ud8a6\udced\udb00\udd4f\udb53\uddce\uda35\ude68\udb12\ude1a\010\ud886\udfdf\udbf6\udc60\u009f\uda09\udec7\ud8c5\udef7\u0098\000\udbf2\udf39\000\ufb42\ud929\udec7\uda1a\udf2c\ud955\udedd\udacc\udf19\ud870\udc33\udbef\udcde\ud9e3\udeee\udbeb\udc62\ud8f1\udc50\uda2d\ude1b\ud870\ude5f\ud9c0\udca4\ud83b\udcbf\ud979\uddf4\uda1f\udf23\udbac\ude09\udb4f\udf71\000\000\udb33\udcb5B\000\udb13\udea8\udb4f\udf82\uda68\udfd3\ud8bf\udef3\u3d72\ud980\udc0c\udaf4\udd85\u28dd\u0097\000\u9493\udbfd\udece\uaf22\ud8ee\udd76\udbb2\udc1a\udae2\udd23\udb3e\udfc8\udb32\ude8f\udbaf\udd6d\udb5e\udcdc\uda42\udd56\ud801\udc76\ud855\udff6\uda33\udeb0\uda45\udd28\udaf3\ude7e\ud895\udf18\ud5cc\ud842\udf6f\udbb9\udc83\ud967\udcb5\uda84\udcc0\uda9f\udf08\ud958\udf1c\udbc5\udea6\ud900\udc42\udae3\uded0\udb24\udd55\udb3e\ude24\ud9ae\udd79\uda99\udd50\ud9dd\udc45\ud8fe\udfca\udb05\ude19", "\u565b\u8642\u4e7c\u3ccf\uc350\u4832\uc6ea\uccb1\ua0c6\u8a35\ub762", "\ud8df\udfd2\ud9b9\ude32\ud8ad\udf63\uda0d\udf7e",
        43, 33288, 259561178, -7982081387115815620L, -68247L, false, true, (char) 59172, (char) 6760,
        Double.longBitsToDouble(0x3fd5fdb0da9c2b68L), Double.longBitsToDouble(0x3fddec25a43a5f30L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 0, "\ud9f6\ude66\001\ud8af\udfd3\ub496\u7fb9\034\000\ud90f\udf87", "\ub48f\ubf65\u08ee\u1696\u4826\u2231\uc0cf\ucd2e\u10ec\ucece\u9526\u0fb4\ud5b9\uae8d\u4eb1\u4955\ucc0e\u76f1\u5930\uabcb\u9589\u00b9\u199f\u7a4e\u73fb\u456a\u4e9d\u68ac\u61db\u7574\uc0df\u9c1f", "\ud980\udc0c\udaf4\udd85\ud8c9\udca4\uda89\ude67\ud944\udcfa\ucb94\udbfd\udece",
        0, 2808, 1822994535, -5819780937689278941L, -34242L, false, false, (char) 22357, (char) 39372,
        Double.longBitsToDouble(0x3fe298de490f2e66L), Double.longBitsToDouble(0x3fea74a941e35d06L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 11, "\ud891\udf3d\ud98a\udf86\ud975\udc19\"\ud8ed\udf65\ud958\udd70\"\ud981\udce0", "\ub202\ud1f5\u0531\u3980\ud1dc\uaaa3\ub7cf\ucd2e\u5a86\ucece\u2bab\ud441\u209c\u1f16\u551e\u4b6c\u18fe\u4c31\u9105\u71f5\uc590\u8ca8\u66d9\u77d3\u6619\u9b52\uca0c\u6804\u7e48\u3cbe\u8375\u5b50\u998f\u2fc1", "\u2930\ud8a9\uddb8\ud944\udcfa\ucb94\ud99b\udf9e",
        -4, 4856, 1478028908, -2520993903849549108L, -84523L, true, false, (char) 62086, (char) 19300,
        Double.longBitsToDouble(0x3fee47d8772937c6L), Double.longBitsToDouble(0x3fcd38e0fca770f0L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 2, "\u9202>\ud82d\udcd5>\ud8ed\udf65\000\ud922\udef8\uda93\udfcd", "\ub48f\u73d9\u943c\u8cc3\ub39c", "\ud859\ude60\ud9bc\udf1d\uda81\udfe7\ud9d6\udcea\ud913\ude5d\udbd9\udfd9\ud935\ude7b\udb65\udcbd\ud88b\udc9a",
        31, 82698, -853391752, 6630964954559061468L, -23943L, false, false, (char) 54688, (char) 60398,
        Double.longBitsToDouble(0x3fef013d49420d53L), Double.longBitsToDouble(0x3fe45a7f9f4d356bL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 6, 12, "\udab4\ude42>\ud82d\udcd5>\ud8ed\udf65\000\ud922\udef8\uda93\udfcd", "\ub48f\u45a1\u3dba\u8cc3\u2ee0", "\ud859\ude60\ud9bc\udf1d\ud8f4\udd2c\uda07\udf93\ud913\ude5d",
        -4, 68305, 1735771813, 31023632957514935L, 74093L, false, true, (char) 58848, (char) 60612,
        Double.longBitsToDouble(0x3fde35f6d2414a4cL), Double.longBitsToDouble(0x3fed041269b0623fL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|tryFoldSimpleFunctionCall|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|addParameterAfter|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|areMatchingExits|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|areSafeFlagsToFold|java.lang.String|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|areValidRegexpFlags|java.lang.String|static",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|consumesDanglingElse|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|containsUnicodeEscape|java.lang.String|static",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|getBlockExpression|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|getBlockReturnExpression|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|getBlockVar|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|getExceptionHandler|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isExceptionPossible|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isFoldableExpressBlock|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isHigherPrecedence|com.google.javascript.rhino.Node,int|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isLowerPrecedence|com.google.javascript.rhino.Node,int|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isLowerPrecedenceInExpression|com.google.javascript.rhino.Node,int|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|tryFoldSimpleFunctionCall|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
