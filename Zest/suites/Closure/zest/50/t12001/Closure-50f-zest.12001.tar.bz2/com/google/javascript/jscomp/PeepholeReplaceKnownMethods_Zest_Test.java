package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class PeepholeReplaceKnownMethods_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 12, 7, "\uda34\uddc4\uda7b\udc0e\udb30\uddce\ud849\udf6e\ud9a8\udd16\ud961\udeaf\ud960\udefe\ud999\udc21\udbdf\ude4c", "\u1de1\u2678\u8378\u0f92\u4b1e\ud278\ud352\u9df2\u79c9\u5c6b\u7ee4\u84f0\u45e9\u7008", "\ud84d\udfce\ud9b6\udcfb\ud97c\udced\ud838\udc99\ud83b\udccb\ud808\udfcb\udb0f\udcdb\udbaa\udcf1\udb37\udfc6\udbe6\udc85\ud817\udff2\uda36\udcba\ud959\ude33\udb58\udc7f",
        55, 74464, 29355323, -4974167420755287952L, -83859L, false, true, (char) 54801, (char) 13378,
        Double.longBitsToDouble(0x3fe5293d90cd01bdL), Double.longBitsToDouble(0x3fb5aaaabc947910L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 12, 7, "\uda34\uddc4\uda7b\udc0e\udb30\uddce\ud849\udf6e\ud9a8\udd16\ud961\udeaf\udb15\udc40\ud999\udc26\udbdf\ude4c", "\u1de1\u2678\u8378\u0f92\u4b1e\ud278\ud352\u9df2\u79c9\u5c6b\u7ee4\u3ae0\u7e8e\ub589", "\ud84d\udfce\uda6c\udc95\ud97c\udced",
        34, 72263, -1118662727, -9037769801279735460L, -23451L, false, true, (char) 46616, (char) 22257,
        Double.longBitsToDouble(0x3fe947c87d3b5adcL), Double.longBitsToDouble(0x3fd1601bf0e175f0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:\ud85d\udfb9\ud9bd\uddfe\ud8e1\udcd4\ud849\udf6e\ud9a8\udd16\ud94c\udecd\ud960\udefe\ud999\udc21\udbdf\ude4c |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\012",
        Z.run(T, 1, 1, 12, 7, "\ud85d\udfb9\ud9bd\uddfe\ud8e1\udcd4\ud849\udf6e\ud9a8\udd16\ud94c\udecd\ud960\udefe\ud999\udc21\udbdf\ude4c", "\u1de1\u2678\u8378\u0f92\u4b1e\ud278\ud352\u9df2\u9d22\u96cd\u7ee4\u84f0\u45e9\u7008", "\ud84d\udfce\udb4a\udd05\ud97c\udced\ud838\udc99\ud83b\udccb\ud808\udfcb\udb0f\udcdb\udbaa\udcf1\udb37\udfc6\udbe6\udc85\ud817\udff2\uda36\udcba\ud959\ude33\udb58\udc7f",
        55, 74464, 29355323, -4974167420755287952L, -83859L, false, true, (char) 54801, (char) 13378,
        Double.longBitsToDouble(0x3fe5293840cd01c8L), Double.longBitsToDouble(0x3fb5aaaabc947910L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 10, 11, "", "\uc2ee\u43a9\u65c8\u7705\u5e82\u392f\ub7b8\u5a6a\ua4ba\u5731\u2678\u9f72\u49c7\u4b1e\u8b78\u6800\000\000\u5b7a\u7ee4\u64f0\u7d55\u7008\uaa49\u5b69\ubfa2\u53db", "\000\000\000\ud90f\udf87\udb37\udfc6\udbe5\udfa1\ud800\udda6\000\ud959\ude33\udb58\udc7f\ud902\udf57",
        4, 64323, -1174405098, -3994868311184080367L, 40166L, true, true, (char) 15170, (char) 0,
        Double.longBitsToDouble(0x3fc9a00000000000L), Double.longBitsToDouble(0x3e49fcebb0000000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 2, 10, "\uda34\uddc4\uda7b\udc0e\udb30\uddce\ud849\udf6e\ud9a8\udd16\ud961\udeaf\ud960\udefe\ud999\udc21\udbdf\ude4c", "\u1de1\u2678\u8378\u0f92\u4b1e\ud278\ud352\u3723\u0820\u1a12\u7f6f\u84f0\u45e9\u7008", "\ud84d\udfce\ud9b6\udcfb\ud97c\udced\ud838\udc99",
        23, 12273, -2104269760, -506662259543805991L, -32838L, true, false, (char) 48016, (char) 30829,
        Double.longBitsToDouble(0x3fee0058f068f90fL), Double.longBitsToDouble(0x3fd3b5adca2c037eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 12, 1, "\uda34\ude34\uda7b\udc0e\udb30\uddce\uda91\udd29\ud89c\udc32\ud961\udeaf\ud960\udefe\ud999\udc21\udbdf\ude4c", "\u1de1\u6978\u8378\u0f92\u4b1e\ud278\ud352\u9df2\u79c9\u43c2\u7ee4\u84f0\u45e9\u7008", "\ud84d\udfce\ud9b6\udcfb\ud97c\udced\ud838\udc99\ud83b\udccb\ud808\udfcb\udb0f\udcdb\ud942\udd9d\udb49\udc42\udbe6\udc85\ud817\udff2\uda36\udcba\ud959\ude33\ud85e\udd62",
        42, 74464, 29355323, -4974167420755287952L, -83859L, false, true, (char) 54801, (char) 13378,
        Double.longBitsToDouble(0x3fe5293d90cd01bdL), Double.longBitsToDouble(0x3fb5aaaabc947910L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 11, 7, "\udb71\udc4b\uda7b\udc0e\udb3d\udc52\ud849\udf6e\ud9a8\udd16\ud961\udeaf\ud960\udefe\ud999\udc21\udbdf\ude4c", "\u1de1\u2678\u8378\u0f92\u4b1e\ud278\u9307\u7f8c\u1846\u9f45\u5c91\u84d0\u45e9\u7008", "\ud84d\udfce\ud9b6\udcfb\ud97c\udced\ud838\udc99\ud83b\udccb\ud808\udfcb\udb0f\udcdb\ud857\ude2d\udb37\udfc6\uf1f0\u8dc3\uda35\udfd4\ud873\udcf0\ud9e7\udc90",
        24, 74503, -793121477, 2500047470765009152L, -83859L, true, false, (char) 61418, (char) 49941,
        Double.longBitsToDouble(0x3fe5293d95aa01bdL), Double.longBitsToDouble(0x3fb5aaaabc947910L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\012",
        Z.run(T, 1, 14, 3, 0, "\uda34\uddc4\udaa8\ude0e\udb30\uddce\ud849\udf6e\ud9a8\udd16\ud887\udf4b\ud842\ude0c\udbca\udcdc\udbdf\ude4c\u3a9e\uda1a\udddc\ud954\udf0e\uda94\udf50\uda37\uded9\ud9d5\udfd4\ud9e6\udde0\u208d\ud9df\udc5c\ud9e3\ude65\u96f0\ud9f8\udcd6\ud8d3\ude8e\ud9d3\ude38\ud9fa\ude6f", "\u5b69\ubfa2\u54ab\u9961\ud47a", "\udb0f\udcdb\udbaa\udcf1\udb37\udfc6\uda08\ude17",
        20, 45675, -1639875594, 852285161711754250L, -88697L, false, true, (char) 7017, (char) 19216,
        Double.longBitsToDouble(0x3fd77cb6893590faL), Double.longBitsToDouble(0x3feba7ae6555f3d6L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\012",
        Z.run(T, 1, 1, 1, 7, "\uda34\uddc4\uda7b\udc0e\udbf6\uddd1\ud849\udf6e\ud9a8\udd16\ud961\udeaf\ud960\udefe\ud999\udc21\udbdf\ude4c", "\u1de1\u2678\u8378\u0f92\u4b1e\ud278", "\u96e5",
        -1, 99244, 457600157, 3293353699881208837L, -96092L, false, false, (char) 13986, (char) 46618,
        Double.longBitsToDouble(0x3fef7074e16f8397L), Double.longBitsToDouble(0x3fc7d62871017238L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 12, 7, "\uda34\uddc4\uda7b\udc0e\udb30\udd54\ud849\udf6e\ud9a8\udd16\ud961\udeaf\ud960\udefe\ud999\udc21\udbdf\ude4c", "\uba80\u25ad\u8378\u0f92\u4b1e\u8209\ud2da\u9df2\u79c9\u5c58\u0355\u84c9\u45e9\u7008", "\udbb0\udfd4\udb3b\udd5a\u7068\ud838\udc99\ud83b\udccb\ud808\udfcb\udb0f\udd1f\udbaa\udcf1\udb37\udfc6\udbe6\udc85\ud817\udff2\uda36\udcba\ud959\ude33\udb58\udc7f",
        34, 74373, 29355323, 9205134531042082025L, -83859L, false, true, (char) 54801, (char) 13378,
        Double.longBitsToDouble(0x3fe5293d95ab01bdL), Double.longBitsToDouble(0x3fb59f1c3c947910L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\012",
        Z.run(T, 1, 14, 12, 7, "\uda34\uddc4\uda7b\udc0e\udb30\uddce\ud849\udf6e\ud9a8\udd16\ud961\udeaf\ud960\udefe\ud999\udc21\udbdf\ude4c", "\u1de1\u2678\u8378\u0f92\u4b1e\ud278\ud352\u9df2\u7def\u13c9\u7ee4\u84f0\u45e9\u7008", "\ud84d\udfce\ud9b6\udcfb\ud97c\udced\ud838\udc99\ud83b\udccb\ud808\udfcb\udb0f\udcdb\udbaa\udcf1\udb37\udfc6\udbe6\udc85\ud817\udff2\uda36\udcba\ud959\ude33\udb58\udc7f",
        55, 74464, 29355323, -4974167420755287952L, -83859L, false, true, (char) 54801, (char) 13378,
        Double.longBitsToDouble(0x3fe5293d90cd01bdL), Double.longBitsToDouble(0x3fb5aaaabc947910L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 12, 7, "\ud85d\udfb9\ud9bd\uddfe\ud8e1\udcd4\ud849\udf6e\ud9a8\udd16\ud94c\udecd\ud953\udd38\ud999\udc48\udbdf\ude4c", "\u1de1\u2678\u8378\u0f92\u4b1e\ud278\ud352\u9df2\u9d22\u96cd\u7ee4\u84f0\u45e9\u7008\uaa49\u5b69\ubfa2\ud57b\u9961\ud47a\ub41c\u28b2\u8f98\u8106\u3e6b\uc50e\ud766\u705d\u201d\u9d1a\u3386\uc417\ubf4d\u3b45\uaeba\ud3bb\uc20a\u7dad\uce76\ua02f\uacc1\u23a9\uaa90\u2e6c\ubaf1\u7913\u76cb\u98b5\uc6a1\u16f4\ub5ea\u7c0a\u1e78\u7892\uc7b5\u08d6\ua78d\ua10d\u043c\u13b0\u1ea2\u53da\ua7ff\uaf7d\u568c\ud3d9\u867c", "\ua073\uda0d\udd05\u548c\ud875\udf60\uda83\udddc\uda49\udcdb\udaca\udf7e\ud9ae\udf6f\ud805\udeee\udaad\udec9\ud9d0\udccc\ud92d\udcad\udb58\udf1f\ud914\ude1e\uda33\uddcd\uda10\udf8b",
        15, 20641, 1289731100, -4628365083574621884L, 27715L, true, false, (char) 14046, (char) 36046,
        Double.longBitsToDouble(0x3fe984092b2b9c5bL), Double.longBitsToDouble(0x3fe7ca330a2a2764L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\012",
        Z.run(T, 1, 1, 10, 11, "", "\uc2ee\u43a9\u65c8\u7705\u5e82\u3046\ub7b8\u5a6a\ua4ba\u5731\u2678\u9f72\u49c7\u4b1e\u8b78\u6800\000\000\u4559\u7efd\u64f0\u7d55\u7008\uaa49\u5b69\ubfa2\ub7a8", "\000\000\000\ud90f\udf87\udb37\udfc6\udbe5\udfa1\ud800\udda6\000\ud959\ude33\udb58\udc7f\ud902\udf57",
        4, 64323, -1174405098, -3994868311184080367L, 40166L, true, true, (char) 15170, (char) 0,
        Double.longBitsToDouble(0x3fc9a00000000000L), Double.longBitsToDouble(0x3e49fcebb0000000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 1, "\uda34\uddc4\uda7b\udc0e\udbf6\uddd1\ud849\udf6e\ud9a8\udd16\ud8d1\udc47\uaec5\ud999\udc1c\udbdf\ude4c", "\u4ff4\u2678\u8378\u0f92\u4b1e\ud278", "\udbe8\uddd3",
        -1, 99244, 457600157, 3293353703083494405L, 93982L, false, false, (char) 13986, (char) 46618,
        Double.longBitsToDouble(0x3fef7074e1a4a5d9L), Double.longBitsToDouble(0x3fc7d62871017238L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\uda34\uddc4\uda7b\udc0e\ud861\udfd1\ud849\udf6e\ud9a8\udd16\ud961\udeaf\ud960\udefe\ud999\udc21\udb2a\udce3 |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\0121=java.lang.String:\uda34\uddc4\uda7b\udc0e\ud861\udfd1\ud849\udf6e\ud9a8\udd16\ud961\udeaf\ud960\udefe\ud999\udc21\udb2a\udce3 |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\012",
        Z.run(T, 2, 1, 1, 7, "\uda34\uddc4\uda7b\udc0e\ud861\udfd1\ud849\udf6e\ud9a8\udd16\ud961\udeaf\ud960\udefe\ud999\udc21\udb2a\udce3", "\u1de1\u2678\u8378\ua729\u4b1e\ud278\ud352", "\uda07\uded6\ud8d3\ude8e\ud9d3\ude38\udb8b\udcf8",
        53, 5323, -1753215164, -5129102997694349872L, 61254L, true, true, (char) 16073, (char) 50546,
        Double.longBitsToDouble(0x3fb034bb4a520b58L), Double.longBitsToDouble(0x3fe13822a8080026L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 12, 7, "\uda34\uddc4\uda7b\udc0e\udb30\udd54\ud849\udf6e\ud9a8\udd16\udafa\udcfb\udb2b\udf06\ud999\udc02\udbdf\ude4c", "\uba80\u25ad\u8378\u0f92\u4b1e\u8209\u540e\ud193\u79c9\u5c58\u0355\u84c9\u45e9\ua34b", "\udbb0\udf2f\udb3b\udd5a\u7068\ud838\udc99\ud83b\udccb\ud808\udfcb\udb0f\udd1f",
        45, 78009, -1243312924, -2082077385278434053L, 90505L, false, true, (char) 23031, (char) 18455,
        Double.longBitsToDouble(0x3fd1601bf9d2ff7eL), Double.longBitsToDouble(0x3fe08e4388f3cb68L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 2, 0, "\uda34\uddc4\uda7b\udc0e\udb6c\udd52\ud849\udf6e\ud9a8\udd16\ub8cb\uda13\udc3e\ud9ce\udde1\udb75\udd22", "\u2253\u7cbe\ub630\u5334\u315d\u8209\u5830\u855b\u4c76\u9232\u2dad\u3978\u45e9", "\udb3f\udda1\uda76\udd97\ud92c\uddda\ud97c\ude5d",
        34, 70015, -1118662727, -9037769508402693796L, -23451L, false, true, (char) 46616, (char) 1265,
        Double.longBitsToDouble(0x3fdffc557a76ad6eL), Double.longBitsToDouble(0x3fd1601bf9d2ff7eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\0121=new com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\012",
        Z.run(T, 2, 14, 14, 11, "\uda34\uddc4\uda64\udca3\udb30\ude2b\ud849\udf6e\ud9a8\udd16\ud961\udeaf\ud960\udefe\ud999\udc21\ud96f\ude54\u3a9e\udb9a\ude48\ud9c4\udfeb\uda94\ude85\uda9c\udece\ud9d5\udfd4", "\ud2da\u9df2\u79c9\u1ac5\u0355\u84c9\u45e9\u7008\uaa49\u141e\u916d\u5325\ub714\u7aa5\ub41c\u28b2\u8fdc\u80fd", "\ud9bd\uddfc\uda36\udcba\ud959\ude33\udb58\udc7f\udb8e\udd27\udaf7\udd67\ud971\udd55\ud8df\udc9d\udb72\udda2\uda2d\udef7\udae5\ude2c\u3008",
        14, 45812, 29182629, 8966725864756748374L, 66064L, false, false, (char) 35975, (char) 47595,
        Double.longBitsToDouble(0x3fd43c11557987f2L), Double.longBitsToDouble(0x3fb019dce3527a98L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 7, "\ud85e\udc1f\ud9bd\uddfe\ud990\udc2c\ud849\udf6e\ud9a8\udd16\ud94c\udecd\ud953\udd38\ud999\udc48\udbed\ude53", "\u1de1\u2678\u8378\u0f92\u4b1e\ua6eb\u877c\u9df2\u9d22\u96cd\u7ee4\u84f0\u45e9\u7008\uaa49\u957d\uc00a\u10a3\u9959\ud47a\u545d\u1e9d\u8fa5\u80fd\u3e6b\uc50e\ud766\u705d\u201d\u9d1a\u3386\uc417\ubf4d\u3b45\uaeba\ud3bb\uc20a\u7dad\uce76\ua02f\uacc1\u23a9\uaa90\u2e6c\ubaf1\u7913\u76cb\u98b5\uc6a1\u0ec8\ub5ea\u8539\u1e78\ucf25\uc72b\u08d6\ua78d\ua10d\u043c\u13b0\u1ea2\u53da\ua7ff\uaf7d\u568c\ud3d9\ua47f", "\ua073\uda0d\udd05\udb35\ude3b\ud875\ude8f\uda83\udddc\uda49\udcdb\udae8\udcfa\ud9ae\udf6f\ud805\udeee\u7ce4\ud9d0\udd60\ud92d\udcad\ud8e0\udc84\ud914\udec6\uda33\uddcd\uda10\udf8b",
        15, 20641, 541139690, -4702274199359149756L, -31392L, false, true, (char) 6978, (char) 42060,
        Double.longBitsToDouble(0x3feb77db7860146eL), Double.longBitsToDouble(0x3fe984092b2b9c5bL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\0121=null |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\012",
        Z.run(T, 2, 1, 1, 7, "\ud85d\udfb9\ud9bd\uddfe\ud8e1\udcd4\ud849\udf6e\ud9a8\udd16\ud94c\udecd\ud953\udd38\ud999\udc48\udbdf\ude4c", "\u1de1\u2678\u8378\u0f92\u4b1e\ud278\ud352\u9df2\u9d22\u96cd\u7ee4\u84f0\u45e9\u7008\uaa49\u5b69\ubfa2\ud57b\u9961\ud47a\ub41c\u28b2\u8f98\u8106\u3e6b\uc50e\ud766\u705d\u201d\u9d1a\u3386\uc417\ubf4d\u3b45\uaeba\u400c\u1009\u7dad\uce76\u9c09\uacbb\u23a9\uaa90\u2e6c\u59a7\u7913\u76cb\u98b5\uc6a1\u16f4\ub5ea\u7c0a\u1e78\u7892\uc7b5\u08d6\ua78d\ua10d\u043c\u13b0\u1ea2\u53da\ua7ff\uaf7d\u568c\ud3d9\u867c", "\ua073\uda0d\udd05\u548c\ud875\udf60\uda83\udddc\uda49\udcdb\udaca\udf7e\ud9ae\udf6f\ud805\udeee\udaad\udec9\ud9d0\udccc\ud92d\udcad\udb58\udf1f\ud914\ude1e\uda33\uddcd\uda10\udf8b",
        15, 20641, 1289731100, -4628365083574621884L, 27715L, true, false, (char) 14046, (char) 36046,
        Double.longBitsToDouble(0x3fe984092b3dc75bL), Double.longBitsToDouble(0x3fe7ca33094d2764L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 12, 7, "\uda34\uddc4\u1cd6\000\000\ud975\udc7a\ud961\udeaf\ud8eb\udf84\ud999\udc21\udbdf\ude4c", "\u1de1\u2678\u8378\u0f92\u4b1e\ud278\ud352\u9df2\u79c9\u5c6b\u7ee4\u84f0\u45e9\u7008", "\ud84d\udfce\ud9b6\udcfb\ud97c\udced\ud838\udc99\ud83b\udccb\u8c12\udb0f\udcdb\udbaa\udcf1\udb37\udfc6\udbe6\udc85\ud817\udff2\uda36\udcba\ud959\ude33\udb58\udc7f",
        55, 74464, 60731, 9396224L, -83859L, false, true, (char) 54801, (char) 13378,
        Double.longBitsToDouble(0x3fe5293d90cd01bdL), Double.longBitsToDouble(0x3fb5aa803c947910L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:\000 |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\012",
        Z.run(T, 1, 1, 9, 0, "\000", "", "\u7db7",
        1, 65344, 1451209012, -4179307494402636600L, -51649L, false, false, (char) 62720, (char) 44733,
        Double.longBitsToDouble(0x3fec8e7b089a88f4L), Double.longBitsToDouble(0x3fc5f7018d9400c0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:\ufeb3 |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\0121=java.lang.String:\ufeb3 |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ufeb3", "\u0a3b\ua743\u2e9e\u155f\u4ed3\ub839\ua62d\u1935", "\uda40\udcd9\ud9d5\udfd4\ud9e6\udde0\u208d\ud8e5\ude3f\uda75\uddce\udbe8\uddd3\uda07\uded6\ud8d3\ude8e\ud9d3\ude38\ud9fa\ude6f\ud9fa\udf17\u029b\u2ec8\udb87\udf37\ud9b2\udc82",
        11, 3454, -1321006684, 8481830043965139145L, -67152L, false, true, (char) 4472, (char) 59988,
        Double.longBitsToDouble(0x3fea73a3cdc786caL), Double.longBitsToDouble(0x3fa4f4f9199dc540L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:\udaf8\udf96=\000\udb2d\udc76\u7db7\ud960\ude88\ud999\udc21\udbdf\ude4c\udac3\udd17\ud87b\udd8c\udae3\udeb5\ud8bb\udce4\ud91d\udcbf\uda80\udf99\udb50\udff5\u208d\ud9df\udc5c\udb7c\udcb1\ud8f5\udc2c\uda45\ude53\ud812\udeb9\udb66\udc79\u4ef3\udaf9\udc6e\uda83\udcfe\u95e5\ud915\udd8a\ud843\udc34\ud978\udcf7\udafb\ude98\ud84f\udf49\ud93a\udf3c\udbd5\udd60\udaba\udf3b\ud843\udd2e\udb10\ude36\udbb2\udd12\ud856\udf88\ucfc5\ud967\udc2f |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\012",
        Z.run(T, 1, 1, 9, 5, "0\udaf8\udf96=\000\udb2d\udc76\u7db7\ud960\ude88\ud999\udc21\udbdf\ude4c\udac3\udd17\ud87b\udd8c\udae3\udeb5\ud8bb\udce4\ud91d\udcbf\uda80\udf99\udb50\udff5\u208d\ud9df\udc5c\udb7c\udcb1\ud8f5\udc2c\uda45\ude53\ud812\udeb9\udb66\udc79\u4ef3\udaf9\udc6e\uda83\udcfe\u95e5\ud915\udd8a\ud843\udc34\ud978\udcf7\udafb\ude98\ud84f\udf49\ud93a\udf3c\udbd5\udd60\udaba\udf3b\ud843\udd2e\udb10\ude36\udbb2\udd12\ud856\udf88\ucfc5\ud967\udc2f", "\u1f00\u52f6\u077f\ua749\u0637\u0e05\u9782\u536a\u9853\ub3ca", "\ud91d\udd48\udb56\udc46\udabe\udebe\udb66\ude0a\u178e\uda8f\udda1\uda5e\udf05\uee32\u8e51\uda52\udc94\udb3b\ude7e",
        18, 61190, -1959305181, -5368252584772146586L, 75489L, true, false, (char) 21689, (char) 29899,
        Double.longBitsToDouble(0x3fb6a670445debe0L), Double.longBitsToDouble(0x3fe14de9f39deffcL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:0 |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\012",
        Z.run(T, 1, 1, 13, 0, "0", "\000\u30e3\u7db7", "\udbdf\ude4c\udac3\udd17\ud87b\udd8c\udae3\udeb5\ud8bb\udce4\ud91d\udcbf\uda80\udf99\udb50\udff5\u208d\ud9df\udc5c\udb7c\udcb1\ud8f5\udc2c\uda45\ude53\ud812\udeb9\udb66\udc79\u4ef3\udaf9\udc6e\uda83\udcfe\u95e5\ud915\udd8a\ud843\udc34\ud978\udcf7\udafb\ude98\ud84f\udf49\ud93a\udf3c\udbd5\udd60\udaba\udf3b\ud843\udd2e\udb10\ude36\udbb2\udd12\ud856\udf88\ucfc5\ud967\udc2f\uda90\uddd1\udaa3\udf18\uda62\ude79\u2aa6\ud8f9\udfb5\uda1e\udf85\ud88f\udc7b\udb82\udded",
        16, 9714, 1907605905, -1341384554082276762L, -52099L, false, false, (char) 59161, (char) 1181,
        Double.longBitsToDouble(0x3fe719c5d1340b55L), Double.longBitsToDouble(0x3fd644b24b90bf1cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String: |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\0121=java.lang.String: |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\012",
        Z.run(T, 2, 1, 1, 0, "", "\u7968\u0a3b\ua743", "\ud936\ude1b\udbdf\udecd\udba8\udc6a",
        58, 50481, -184549244, -727963068668881579L, -100000L, false, false, (char) 45243, (char) 22081,
        Double.longBitsToDouble(0x3fdf12edced8a62cL), Double.longBitsToDouble(0x3fc3af21bef86d18L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:0 |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\0121=java.lang.String:0 |this=com.google.javascript.jscomp.PeepholeReplaceKnownMethods:@?\012",
        Z.run(T, 2, 1, 1, 2, "0", "\000\u30e3\u2c96", "\udbdf\ude4c\udac3\udd17\uda19\udf7b\udae3\udeb5\ud8bb\udce4\ud91d\udcbf\uda80\udf99\udb50\udff5\u208d\ud9df\udc5c\udaf7\udfea\ud8f5\udc43\uda45\ude53\ud812\udeb9\udb66\udc79\u4ef3\udaf9\udc6e\uda83\udcfe\u95e5\ud915\udd8a\udaa5\uddf8\ud86c\uddb6\udafb\ude98\ud84f\udf49\ud93a\udf3c\udbd5\udd60\udaba\udf3b\ud843\udd2e\udb10\ude36\udbb2\udd12\ud856\udf88\ucfc5\ud967\udc2f\uda90\uddd1\udaa3\udf18\uda62\ude79\u2aa6\ud8f9\udfb5\uda1e\udf85\ud88f\udc7b\udb82\udded",
        46, 86250, 1907605905, -1341384554082287829L, -52099L, false, false, (char) 59161, (char) 1181,
        Double.longBitsToDouble(0x3fe719c5d1340b55L), Double.longBitsToDouble(0x3fd644b24b90bf1cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.PeepholeReplaceKnownMethods|tryFoldArrayJoin|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeReplaceKnownMethods:",
    "M|com.google.javascript.jscomp.PeepholeReplaceKnownMethods|normalizeNumericString|java.lang.String|new:com.google.javascript.jscomp.PeepholeReplaceKnownMethods:",
    "M|com.google.javascript.jscomp.PeepholeReplaceKnownMethods|optimizeSubtree|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeReplaceKnownMethods:",
    "M|com.google.javascript.jscomp.PeepholeReplaceKnownMethods|tryFoldKnownMethods|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeReplaceKnownMethods:",
    "M|com.google.javascript.jscomp.PeepholeReplaceKnownMethods|tryFoldKnownNumericMethods|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeReplaceKnownMethods:",
    "M|com.google.javascript.jscomp.PeepholeReplaceKnownMethods|tryFoldKnownStringMethods|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeReplaceKnownMethods:",
    "M|com.google.javascript.jscomp.PeepholeReplaceKnownMethods|tryFoldParseNumber|com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeReplaceKnownMethods:",
    "M|com.google.javascript.jscomp.PeepholeReplaceKnownMethods|tryFoldStringCharAt|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeReplaceKnownMethods:",
    "M|com.google.javascript.jscomp.PeepholeReplaceKnownMethods|tryFoldStringCharCodeAt|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeReplaceKnownMethods:",
    "M|com.google.javascript.jscomp.PeepholeReplaceKnownMethods|tryFoldStringIndexOf|com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeReplaceKnownMethods:",
    "M|com.google.javascript.jscomp.PeepholeReplaceKnownMethods|tryFoldStringSubstr|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeReplaceKnownMethods:",
    "M|com.google.javascript.jscomp.PeepholeReplaceKnownMethods|tryFoldStringSubstring|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeReplaceKnownMethods:",
    "M|com.google.javascript.jscomp.PeepholeReplaceKnownMethods|tryFoldStringToLowerCase|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeReplaceKnownMethods:",
    "M|com.google.javascript.jscomp.PeepholeReplaceKnownMethods|tryFoldStringToUpperCase|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeReplaceKnownMethods:",
    "C|com.google.javascript.jscomp.PeepholeReplaceKnownMethods|<init>|",
    "M|com.google.javascript.jscomp.PeepholeReplaceKnownMethods|tryFoldArrayJoin|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeReplaceKnownMethods:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
