package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class CodeConsumer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 13, 9, 2, "\ud913\udd6b\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\uc38e\u75d6\uc8bb\u5447\u3d41\u5d9e\u8588\u8cd6\uab64\uca5a", "\udbf4\udce2\ud859\udc2d\ud97d\uded7",
        54, 34504, -1750828665, -4230430406224792130L, -68055L, false, true, (char) 50681, (char) 42609,
        Double.longBitsToDouble(0x3fe5be7f59da84afL), Double.longBitsToDouble(0x3f92868cc1be6aa0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 13, 9, 2, "\ud913\udd6b\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\u8ff7\u7508\uc8bb\u5447\u3d41\u5d9e\u8588\u8cd6\uab64\uca5a", "\udbf4\udce2\ud859\udc2d\ud97d\uded7",
        54, 34504, -1750828665, -4230430406224792130L, -68055L, false, true, (char) 50681, (char) 42609,
        Double.longBitsToDouble(0x3fe5be7f59da84afL), Double.longBitsToDouble(0x3f92868cc1be6aa0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 13, 9, 2, "\ud901\udd46\ub152\udb08\udee2\uaffa\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\uc38e\u75d6\uc8bb\u5447\u3d58\u5d9e\ucd14\u8cd6\uab64\uca5a", "\udbf4\udce2\ud859\udc2d\ud812\udd61",
        54, 34504, 1201228679, -4230430406224792130L, 38441L, true, false, (char) 50681, (char) 42609,
        Double.longBitsToDouble(0x3fe5be7f59da84afL), Double.longBitsToDouble(0x3f92868cc1be6aa0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 13, 9, 2, "\ud913\udd6b\ud993\ude0a\uda6c\udf88\u4a11\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud921\udd41\ucd0e\ud844\udfa4\ud863\udc83\ub743\uda79\udd93\uda9d\ude95\udb09\udd1b\udbf3\udece\udb53\udc4b", "\uc38e\u75d6", "\udb9e\udc8c",
        31, 24549, 1114244185, 3551498292890807280L, -4685L, true, true, (char) 27482, (char) 20785,
        Double.longBitsToDouble(0x3fc5fd3608035e2cL), Double.longBitsToDouble(0x3fd872de9bed2f48L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 8, 9, 2, "\ud913\udd6b\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\uc38e\u75d6\uc8bb\u5447\u93da\u5d9e\u8588\u8cd6\uab64\uca5a", "\udbf4\udce2\ud859\udc2d\ud910\uddcd",
        19, 34504, -1750828665, -4230430406224792130L, -68055L, false, true, (char) 50681, (char) 42609,
        Double.longBitsToDouble(0x3fe5be7f59da84afL), Double.longBitsToDouble(0x3f92868cc1be6aa0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 13, 9, 2, "\ud913\udd6b\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda04\ude3f\udaea\udf72\u0c2a\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\uc38e\u75d6\uc8bb\u5447\u3d41\u5d9e\u8588\u8cd6\uab64\ud79b", "\udbf4\udce2\ud859\udc2d\ud97d\uded7\uda58\udee7\ud928\udcc6\u926b\udb81\udfec\ud8a6\udd19\udaa7\uddc1\ud9d0\udcd7\uda3b\udc98\ud840\udd5b\ud8f2\udf8b\udba0\udd88\udb0c\udfc3\udbd9\udde0\udbda\udc7a\uda51\udf72\udab0\udeb1",
        54, 77141, 1055466035, -3130581249917497185L, -61199L, true, false, (char) 54503, (char) 4660,
        Double.longBitsToDouble(0x3febcfd866e445e7L), Double.longBitsToDouble(0x3fe17aa088a91d00L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 13, 9, 2, "\ud913\udd6b\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udcdf\uda3c\udc75\udaf9\udca5\udbd9\udc52\ud8e7\udc61\ud9f2\uddad\ud99b\udcf2\udabb\udd35\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\udac3\udec3\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\uc38e\u75d6\uc8bb\u5447\u3d41\u5d9e\u8588\u8cd6\uab64\uca5a", "\udbf4\udce2\ud859\udc2d\ud97d\uded7",
        54, 34504, -1750828665, -4230430406224792130L, -68055L, false, true, (char) 30925, (char) 42609,
        Double.longBitsToDouble(0x3fe76787590f8f7cL), Double.longBitsToDouble(0x3f92868cc1be6aa0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 14, 9, 2, "\ud913\udd6b\uda35\udcdc\udb08\udc57\uaffa\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud931\udf41\ud9a1\udca4\ud844\udf73\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\u2fb5\u0d5d\uc8bb\u5447\u3d41\u5d9e\u8588\u8cd6\uab64\uca5a", "\udbf4\udce2\ud859\udc2d\ud97d\uded7",
        0, 34504, -1750828665, -4230430406224792130L, -62459L, false, true, (char) 22596, (char) 37762,
        Double.longBitsToDouble(0x3fe9dfcb4a8b5371L), Double.longBitsToDouble(0x3f7127d5ea554e80L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 9, 2, "\ud913\udd6b\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\uc38e\u75d6\uc8bb\u5447\u3d41\u5d9e\u8588\u82e0\uab64\uca5a", "\udbf4\udce2\ud859\udc2d\ud97d\uded7",
        23, 16812, -1750797522, -4230430406224792130L, -68055L, false, true, (char) 50681, (char) 42609,
        Double.longBitsToDouble(0x3fe5be7f59da84afL), Double.longBitsToDouble(0x3f92868cc1be6aa0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 3, 9, 2, "\ud913\udd6b\uda19\udcfd\udbd9\udc5f\uafd0\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8f3\udff9\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\u2e74\u7537\uc8bb\u5447\u3d41\u5d9e\u8588\u8cd6\uab64\uca5a", "\udbf4\udce2\ud859\udc2d\ud97d\uded7",
        54, 34504, -1750828665, -4230430406224792130L, -2716L, false, true, (char) 16035, (char) 36489,
        Double.longBitsToDouble(0x3f92868cc1be6aa0L), Double.longBitsToDouble(0x3f9039e8a37cb2a0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 0, 9, 2, "\ud913\udd6b\uda6b\udf1f\ud97c\udfcf\ud953\udd28\udb45\udf72\ud86d\udcdc\uda3c\udc75\udaf9\udc52\udbc7\udf41\udb15\udfc5\uda04\ude60\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub7a8\ud87c\udf36\ud8da\udfa1\uda6f\udf2f\udbd4\udcaa\udb53\udc4b", "\u1c4f\u57a8\ud72a\u2c06\u3d41\u5d9e\u8588\u8cd6\uab64\uca5a\u2dad\u91ec\u33c2\u384a\u8db6\u60bc\u086a\u7dd7\uc860\u0810\u39a2", "\ud8f1\udcb3\ud8f2\udf8b\udba0\udd88\udb0c\udfc3\udb4d\udefb\uda94\udcfe\uda51\udf72\ud843\udfb1",
        54, 20317, -30977685, -4112574679715287741L, -91203L, false, true, (char) 49324, (char) 28174,
        Double.longBitsToDouble(0x3fc1802476c233b4L), Double.longBitsToDouble(0x3fc30ed3dd6b19d4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 8, 1, 2, "\ud8aa\udfa6\ud993\uddbf\udb13\udfbb\uaffa\ud8e6\udc84\udae1\udc9c\ud90d\udf57\ud904\udf23\ud87e\udc80\ud8dc\uddf9\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\ud9a6\udf2d\udbf3\udf05\udb53\udc4b", "\uc38e\u75d6\uc8bb\u5447\u3d41\u5d9e\u8588\u8cd6\uab64\uca5a", "\udbf4\udce2\ud859\udc2d\ud97d\uded7",
        54, 34504, -1750828665, -4230430406224792130L, -85906L, false, true, (char) 22596, (char) 5279,
        Double.longBitsToDouble(0x3fc92e561da141d4L), Double.longBitsToDouble(0x3fe9f068b349929dL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 12, 9, 2, "\ud90b\udd4e\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud90d\udcec\ud8dc\udeb6\uda04\ude3f\ud928\udd74\u0c2a\uda16\udfa9\ud975\udcad\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\uc38e\u75d6\uc8bb\u5447\u3d41\u5d9e\u8588\u8cd6\uab64\uca5a", "\udbf4\udcc2\ud859\udc2d\udb13\udd21",
        29, 63025, -1750825337, -4230430406224792130L, -68055L, false, true, (char) 33785, (char) 48607,
        Double.longBitsToDouble(0x3fedbe7f5d91e005L), Double.longBitsToDouble(0x3fc08fffd837cd54L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 10, 9, 1, "\ud903\udc3c", "\u430d\u3497\u1dea\u9b86\ub308\u7d16\u53ce\u3e3d\u5f60\u7663\u2e30\u4cc2\ub892\u1447\ub147", "\udb52\udd48\ud8da\udfa1\u7eeb\udbf3\udf8f\u8e75\udbab\udc42\ud894\ude58\ud9bc\udfe3",
        -4, 45822, 2127748314, 8970933478501246222L, 84409L, true, false, (char) 3895, (char) 14672,
        Double.longBitsToDouble(0x3fb4da440ff169c8L), Double.longBitsToDouble(0x3fe3cf69e866d908L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 3, 0, 2, "\udb6e\udd57", "\u9539\u47c8\u224c\u83b6", "\ud8dc\uddf9\uda04\ude3f\ud928\udd74\ud89a\ude16\ud9ba\udc3d\ud961\ude96",
        5, 62256, -869485142, -5687833941497947864L, 74204L, true, false, (char) 58002, (char) 21686,
        Double.longBitsToDouble(0x3fd0c20775c9551aL), Double.longBitsToDouble(0x3fd920dbbbd646daL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 2, 9, 2, "\ud901\udd46\ub152\udb08\udee2\uaffa\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda04\ude3f\ud928\udd74\u0c2a\udba4\udce9\ud94a\udf34\ud8fc\ude5a\ucd0e\ud844\udfa4\ud863\udc83\uda23\udf9d\ud8a7\udf61\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\uc38e\u4248\uc982\u5447\u3d58\u5d9e\ucd14\ud615\ubacf\u87ca", "\udbf4\udce2\ud859\udc2d\ud812\udd61\uda9d\ude4c\uda7b\udcb4",
        9, 78166, -1779059266, -3411775182387796843L, -92631L, true, false, (char) 50681, (char) 42609,
        Double.longBitsToDouble(0x3fe5be7f5ed2b1afL), Double.longBitsToDouble(0x3fedb369760df355L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ud913\udd6b", "\u2f50\u47c8\u224c\u9c5d", "\ud8bf\udcbf\uda04\ude2f\ud928\udd4f\udb75\udc22\ud9b9\udf93\ud961\uddc2",
        9, 7656, -869499214, -5687833941508095960L, 41809L, false, false, (char) 6531, (char) 53125,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e3f380000000000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 13, 12, 1, "\ud913\uddb9\ud993\ude0a\uda6c\udf88\ud906\uddd5\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8d5\udcf9\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud921\udd41\ud8b1\udd2c\ud844\udf65\ud863\udc83\ub743\ud880\udf92", "\uc43f\u58dd\u39b4\u0ea7\u7d01\u6c0d\u2272\u512b\u3c98\u5d9e\u8588\uc30f\u3f4b\u35a6\u2dad\u91ec", "\ud97d\uded7\udafb\udc3b\udbad\udcfb\uda50\udf60",
        13, -119, -726650777, -48921613356325832L, 31068L, false, true, (char) 15550, (char) 60727,
        Double.longBitsToDouble(0x3feace079db340a0L), Double.longBitsToDouble(0x3feb0c1752ab9738L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 13, 13, 3, "\ud913\udd6b\ud993\ude0a\uda6c\udf88\u4a11\udb45\udee0\udb2f\ude09\ud999\uddd4\ud9a7\ude45\ud873\udd12\ud8dc\uddf9\uda36\udf7d\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude3f\ud921\udd41\ucd0e\ud844\udfa4\ud8b7\udded\ud96a\udd12\udbfd\udf2e\uda9d\udf41\udb09\udd1b\udbf3\udece\udb53\udc4b", "\uc38e\u75d6", "\udb9e\udc8c",
        22, 31995, 1107458137, 3551498290625883120L, 66829L, true, true, (char) 30298, (char) 50081,
        Double.longBitsToDouble(0x3fc5f4be68035e2cL), Double.longBitsToDouble(0x3fd872de9bec4148L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 15, 9, 2, "\udba1\udeba\udb67\udddb\uda7e\ude74\ud8eb\uded3\uda26\udf1c\ud86d\udcdc\uda3c\udc75\udaf9\udc52\udacf\udd76\ud8dc\uddf9\uda04\ude3f\ud928\udd74\udb0b\udf6e\ud9ba\udc6b\ud961\ude96\ud921\udd41\ucd0e\ud844\udfa4\ud863\udc83\ub743\uda79\udd93\uda9d\ude95\udb09\udd1b\udbf3\udece\uda13\udc4b", "\ub471\u75d6", "\udb40\udd18",
        31, 24549, 1114244185, 3551498292900895216L, -4685L, true, true, (char) 27482, (char) 20785,
        Double.longBitsToDouble(0x3fc5fd361ed75e2cL), Double.longBitsToDouble(0x3fee06d14df697d4L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 2, 15, 4, "\udab2\udff9\ud889\udd7f\ud992\ude56\u4a11\udb45\udf7f\ud86d\udcdc\uda3c\udc75\uda90\udf99\udb53\uddd0\ud8cb\udcc5\udb0f\uded8\ud928\udd51\u0c2a\ud9b9\udf93\udb67\udd16\ud924\udfc0\u8535\uda41\udd42\ud9dd\ude40\ub743\uda69\ude93\uda9d\ude95\udb09\udd1b\udbf3\udece\udb53\udc4b", "\uc38e\u75d6\u0c72\u512b\u3c98", "\udbd6\udc42\uda2d\udfc8\uda3a\udc56\ud8fc\ude41\udad9\ude71\udb35\udd17",
        14, 84412, -678721361, 704322957746674731L, -43637L, true, false, (char) 46643, (char) 22870,
        Double.longBitsToDouble(0x3fc80b185a8a478cL), Double.longBitsToDouble(0x3fe79fcef084ff2aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 8, 9, 2, "\udbc6\udd44\ud993\ude0a\ud806\udf54\ud9c7\udfbc\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\ude4e\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud9a9\ude0d\ud89f\udec8\udbf3\udf7d\udb23\udc4b", "\uc38e\u75d6\uc8bb\u5447\u93da\u5d9e\u8588\u8cd6\uab64\uca5a", "\udbf4\udce2\u8793\ud863\udca7",
        19, 34504, -1750828665, -4230430406224792130L, -68055L, false, true, (char) 50681, (char) 42609,
        Double.longBitsToDouble(0x3fe5be7f59da84afL), Double.longBitsToDouble(0x3f92868cc1be6aa0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 8, 0, 2, "\ud913\udd6b\udb7f\ude09\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda04\ude3f\ud928\udd74\ud92b\ude1e\uca8d\ud8f6\uddc1\ud906\udee6\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud93c\udd42\udb9b\uddc7\udbd1\udcce\udb53\udc4b", "\uc38e\u75d6\u4e11\u5447\u9db2\u5e22\u8588\u8fd6\u5018\u7329", "\ud93a\ude03",
        20, 80200, 1230587828, 3257690446966847879L, 50082L, false, false, (char) 62779, (char) 13644,
        Double.longBitsToDouble(0x3fe9c3e864c96823L), Double.longBitsToDouble(0x3fc92e560fa5786cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 2, 3, 10, "\ud913\udd6b\ud993\ude0a\udb14\udc44\uaffa\udb81\udf7b\ud9ee\udfc0\ud836\udf74\udbf2\udf24\udbf6\udda3\ud8e7\udc61\ud9f2\uddad\ud85f\udc14\ud885\udfd1\ud9b9\udf93\ud961\ude96\udb30\udf96\ucd0e\udac3\udec3\ud990\uddfa\ub743\ud87c\udf36\ud8da\udfa1\uda13\udce3\udbf3\udece\uda4f\udf89", "\uc38e\u75d6\uc8bb\u8b4b\u3d41", "\u11ba\uda49\udc76\udbf4\udc54\udaf2\udea0\udbec\uddce\ud88f\uddbe",
        15, 95128, -678721361, -8914521419421874826L, 31046L, false, false, (char) 3644, (char) 22425,
        Double.longBitsToDouble(0x3fe9c3e864c96823L), Double.longBitsToDouble(0x3fea1da151945b08L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 9, 9, 2, "\ud913\udd6b\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udcdf\uda3c\udc75\udaf9\udca5\udbd9\udc52\ud8e7\udc61\ud9f2\uddad\ud99b\udcf2\udabb\udd35\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\udac3\udec3\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\ude4b", "\uc38e\u75d6\uc8bb\u5447\u3d41\u5d9e\u8588\u8cd6\uab64\uca5a", "\udbf4\udce2\ud859\udc2d\ud97d\uded7",
        54, 34504, -1750828665, -4230430406224792130L, -68055L, false, true, (char) 30925, (char) 42609,
        Double.longBitsToDouble(0x3fe765d8410f8f7cL), Double.longBitsToDouble(0x3f92868cc1be6aa0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 13, 12, 2, "\ud913\udd6b", "\u860e\u93a9M\u9c47\u1402\u4b2d\u3858\u21ae\ud0ba\uccb8\u2e33\u4519\ub892\u5290\ub715\u339c\u0bf3\u677b\u5b06\ub7c6", "\udbfa\udea7\ud87b\uddb3\ud9bc\udfa8",
        16, 3977, 1204567855, 8959860752164447502L, 32185L, true, false, (char) 56738, (char) 14672,
        Double.longBitsToDouble(0x3fd3db8103fc5a72L), Double.longBitsToDouble(0x3fe3cf69e828d908L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 6, 8, 5, "\ud913\udd6b\ud993\ude0a\udb13\udfbb\udbda\ude91\udbb7\udf75\ud86d\udcdf\uda3c\udc75\udaf9\udca5\udbd9\udc52\ud8e7\udc61\ud9f2\uddad\ud99b\udcf2\ud8d6\udc83\ud816\udf6c\ud961\ude09\ud931\udf41\ucd0e\udac3\udec3\uda2e\udc87\ub743\ud87c\udf36\udb83\udd35\udb09\udd89\udbf3\udece\udb53\udc4b", "\uc38e\u75d6\uc8bb\u5447\u3d41\u5d9e\u8588\u8cd6\u024e\u05bd", "\udbdb\udee2\ud9c3\udfa3\ud97d\uded7",
        42, 34504, -1750828665, -4230430406224792130L, 37204L, false, true, (char) 26577, (char) 5356,
        Double.longBitsToDouble(0x3fc92e5601e6de60L), Double.longBitsToDouble(0x3fe6c41c9bd4aa9dL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 0, 0, 2, "\ud913\udd6b\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udc1f\uda3c\udc75\udaf9\udca5\udbd9\udc52\ud8e7\udc61\ud9f2\uddad\ud99b\udcf2\udabb\udd35\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\uda65\udeb4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb06\udde2", "\u617b\u75d6\uc8bb\u1021\000\000\u84a3\u8cd6\uab64\uca5a", "\udbf4\udce2\ud859\udc2d\ud97d\uded7",
        54, 34504, -1750828665, -4230430406224792130L, -68055L, false, true, (char) 30925, (char) 42609,
        Double.longBitsToDouble(0x3fe76787590f8f7cL), Double.longBitsToDouble(0x3f92868cc1be6aa0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 10, 3, 14, "\ud913\udd6b\u3be9\ud8a9\udc36\ub017\udb45\udf7f\ud86d\udcdf\uda09\udfb2\udae7\uddfd\udbd9\udc52\ufcca\ufd08\uda57\udcfe\udabb\udd35\ud9b9\udf93\ud961\ude96\ud931\udf41\udb02\ude16\udac3\udec3\ud863\udc83\ub743\ud87c\udf36\ud926\udcd3\ud853\udc5a\udbf3\udece", "\u93a4\u36ca", "\ud9bf\udf86\udb9e\udd35\ud93d\udcaf\u605a\ud88e\udc3f\ud924\udc07\udb38\udeac\ud815\udf58\ud98f\udd0b",
        38, 11808, -374310872, -2915086176670367232L, -1174L, false, true, (char) 52002, (char) 3645,
        Double.longBitsToDouble(0x3fed273fa3387d0cL), Double.longBitsToDouble(0x3fc92d047e2dcac0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 3, 2, "\ud94c\udc6b\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda04\ude3f\ud928\udd74\uda78\uddec\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\u1ae0\u609c\uc993\u5447\u3d41\u2fa1\u8588\u82e0\uab64\uca5a", "\udb41\udea8\ud974\udc4b\ud97d\udf66",
        23, 16812, -1748928978, -4230430406224792130L, -68055L, false, true, (char) 50681, (char) 42609,
        Double.longBitsToDouble(0x3fe5be7f59da84afL), Double.longBitsToDouble(0x3f92868cc1be6aa0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 9, 2, "\u0ca3\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\uc38e\u75d6\uc8bb\u5447\u3d41\u5d9e\u8588\u82e0\uab64\uca5a", "\udbf4\udce2\ud859\udc2d\ud97d\uded7",
        23, 16812, -1750797522, -4230430406224792130L, -68055L, false, true, (char) 50681, (char) 42609,
        Double.longBitsToDouble(0x3fe5be7f59da84afL), Double.longBitsToDouble(0x3f92868cc1be6aa0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 15, 9, "\ud913\udd6b\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\uc38e\u75d6\uc8bb\u5447\u3d41\u5d9e\u8588\u82e0\uab64\uca5a", "\udbf4\udce2\ud859\udc2d\ud97d\uded7",
        23, 16812, -1750797522, -4230430406224792130L, -68055L, false, true, (char) 50681, (char) 42609,
        Double.longBitsToDouble(0x3fe5be7f59da84afL), Double.longBitsToDouble(0x3f92868cc4d8aaa0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 10, 11, 2, "\ud94b\udfb9\uda6b\udf6f\ud97c\udfcf\ud953\udd28\udb45\udf72\ud850\udeeb\uda3c\udc75\udaf9\udc52\ud8fb\udc59\ud86c\udc10\uda04\ude41\ud928\udd74\u0c2a\ud82b\udd0d\ud960\udd2e\udb7c\udf06\ud93e\uddbf\udbf8\udea7\ud863\udd4f\ub7a8\udaa5\udd5b\ud8a7\udf2d\uda0b\udd28\ud8af\udfc3\ud968\udfa8", "\u56e6\uca77\ud72a\u2699\u7b59\u5d9e\u63ab\u1ad4\u21ea\uca5a\uccaa\u923d\uc5d5\u8ac9\u426d\u39d0\u7062\ua24a\uc860\u9d19\u60fb", "\uda60\uddab\udb28\udfc4\udba0\udd88\udb0c\udfc3\udb4d\udefb\ud8c4\udce0\uda51\udf72\ud843\udfb1",
        54, 20317, -30977685, -4112574680939597757L, -59682L, true, true, (char) 37366, (char) 47797,
        Double.longBitsToDouble(0x3fc30ed3c96b19d4L), Double.longBitsToDouble(0x3fd3d3534ceb15f0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 8, 1, 2, "", "", "\ud8e5\udf85\udae1\udc9c\ub3a7\ud8cf\udcc7",
        55, -1000, -1370581248, 378901762783416187L, -100000L, false, false, (char) 38877, (char) 59058,
        Double.longBitsToDouble(0x3fd2acc2c2516200L), Double.longBitsToDouble(0x3fbe99e6b1b17348L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 0, 1, 2, "\ud8aa\udfa6\ud993\uddbf\ud8a6\ude12\uaffa\ud8e6\udc84\udae1\udc9c\ud8fe\udc2e\ud904\udf23\ud84e\udc80\ud8dc\uddf9\uda04\ude3f\ud928\udd74\u0c2a\ud837\udc2a\uda36\uddf7\ud931\udf41\u6e48\ud844\udfa4\ud863\udc83\ub743\udac9\uddd7\ud8da\udfa1\ud9a6\udf2d\ud820\ude9a\udaff\udf89", "\uc38e\u75d6\uc8bb", "\ud93d\udcaf\u605a\ud8cf\udc5f\udb32\udf6a\uda9c\udd41\ud815\udfdb\ud8f3\udefd\udbf4\udce3\ud859\udc2d\ud97d\uded7\uda9d\ude4c\uda7b\udcb4\uda50\udf60\ud8f4\ude80\ud8ad\udf7e\ud994\udd86\ud9d4\udf50\uda3b\udc98\ud840\udd5b\ud8f2\udf3e\udb6d\udd86\ud9a0\udc2d\ud9a2\ude0a\ud940\udd5c\uda76\udf77\uda96\udd45\ud987\udd74\udbde\udd01\u2518",
        18, 44037, 592628489, -1274351024937922009L, 86493L, true, false, (char) 37537, (char) 60657,
        Double.longBitsToDouble(0x3fc3a551f3c3bb54L), Double.longBitsToDouble(0x3fd4a9da43998024L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 1, 1, 2, "\ud8aa\udfa6\ud993\uddbf\udb13\udfbb\uaffa\ud8e6\udc84\udae1\udc9c\ud90d\udf57\ud904\udf23\ud87e\udc80\ud8dc\uddf9\uda04\ude3f\ud928\udd74\ud9cb\uddae", "\ub892\u5290\u8e03\u339c\u0bf3\u677b\u724d\u05bc\u8f6d\u58dd\ua3c6", "\udbfd\udec0\ud852\udf8a\ud888\udf6a\udb9e\udd35\ud96c\udd6d\u605a",
        9, 81181, 2015996912, 7570763910257144915L, -69455L, true, true, (char) 1602, (char) 49392,
        Double.longBitsToDouble(0x3fdbec54a1192beaL), Double.longBitsToDouble(0x3fe87084cd3a4848L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 8, 8, 2, "\ud8aa\udfa6\ud993\uddbf\udb13\udfbb\uaffa\ud8e6\udc84\uda71\udd04\ud806\ude04\udaa9\udd4e\ud900\udcc0\ud8d2\udf95\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud9e7\udf3c\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\ud9a6\udf2d\udbf3\udf05\udb53\udc4b", "\uc38e\u75d6\uc8bb\u5447\u3d41\u5d9e\u8588\u8cd6\u552b\u4591", "\udbf4\udce2\ud859\udc2d\udb9f\ude66",
        22, 34504, -1750828665, -4230430406224792130L, -85906L, false, true, (char) 33520, (char) 3249,
        Double.longBitsToDouble(0x3fc929bbdda141d4L), Double.longBitsToDouble(0x3fe9f068b149929dL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud913\udd6b", "\u2f50\u47c8\u224c\ub882", "\ud970\uddb8\uda1a\udcc1\ud928\udd4f\udb75\udc22\ud9b9\udf93\ud963\udcc2",
        24, 7656, -869499214, -5687833941508095960L, 41809L, false, false, (char) 6531, (char) 53125,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e1ce00000000000L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=java.lang.Boolean:false |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 10, 10, 4, "\ud936\udf98\ud993\ude0a", "\u43d5\u7a4b\u99b9\u7f4e\u5b33\u4367\u9663", "\ud9b9\udf93\ud961\ude3f\ud92d\ude41\udb3c\udd53\ud8e5\uddd2\ud8b7\udded\ud96a\udd12",
        11, 15877, -75872917, -8864819030930659210L, 84057L, false, true, (char) 28864, (char) 11777,
        Double.longBitsToDouble(0x3fef3e278939ba32L), Double.longBitsToDouble(0x3fe603e2b8c3000dL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 2, 15, 4, "\udab3\udc29\ud889\udd7f\ud992\ude56\u4a11\udb45\udf7f\ud86d\udcdc\uda3c\udc75\uda90\udf99\udb53\uddd0\ud83d\udf54\udb56\udebe\ud928\udd51\u0c2a\ud9b9\udf93\udb67\udd16\ud924\udfc0\u8535\uda41\udd42\ud9dd\ude40\ub743\uda69\ude93\uda9d\ude95\udb09\udd1b\udbf3\udece\udb53\udc4b", "\uc38e\u75d6", "\udb9e\udc8c",
        31, 24549, 1114244185, -8338004723398067855L, -4685L, true, true, (char) 27482, (char) 10116,
        Double.longBitsToDouble(0x3fc5fd2ac8035e2cL), Double.longBitsToDouble(0x3fa584e364397a40L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 2, 2, 4, "\udab2\udff9\ud889\udd7f\ud992\ude56\u4a11\udb45\udf7f\ud86d\udcdc\uda3c\udc75\uda90\udf99\udb53\uddd0\udbbb\udd3d\udaef\udef2\ud941\udf0c\u0c2a\ud9b9\udf93\udb67\udd16\ud924\udfc0\u8535\uda41\udd42\ud9dd\ude40\ub743\uda69\ude93\uda9d\ude95\udb09\udd1b\udbf3\udece\udb53\udc4b", "\u28cf\u75d6\u0c72\u512b\u3c98", "\udbd6\udc42\uda2d\udfc8\uda3a\udc56\ud8fc\ude41\udad9\ude71\udb35\udd17",
        14, 84412, -678721361, 704322957746674731L, -43637L, true, false, (char) 46643, (char) 22870,
        Double.longBitsToDouble(0x3fc80b185a8a478cL), Double.longBitsToDouble(0x3fe79fcef084ff2aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 3, 2, "\ud94c\udc6b\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda04\ude3f\ud928\udd74\uda78\uddec\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\u1ae0\u609c\u130f\u9f56\u3d41\u2fa1\u8588\u82e0\uab64\u5977", "\udb4a\udd32\ud974\udc4b\ud97d\udf66\udb73\udff6\udb2d\udc1e\ud914\udc09\ud8f4\ude80\ud8ad\udf7e\udaa7\uddc1\ud9d0\udcd7\uda3b\udc98\ud840\udd5b\ud8f2\udf8b\udba0\udd88\udb0c\udfc3\udb4d\udefb\uda94\udcfe\uda51\udf72\udab0\udeb1\udbaa\udf52",
        36, 55010, -2077870411, 2879245681709262064L, -52645L, false, false, (char) 10514, (char) 37818,
        Double.longBitsToDouble(0x3fd33a2ba1da258cL), Double.longBitsToDouble(0x3fda7a7c0fdd6676L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 3, 2, "\ud94c\udc6b\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud89d\udf7e\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda04\ude3f\ud928\udd74\uda78\uddec\ud983\udf98\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\ud981\ude83", "\u1ae0\u609c\uc993\u5447\u3d41\u2fa1", "\ud8ce\uddda\ud9c2\ude02\uda6e\ude29\ud8f3\udefa\udb41\udea8\ud974\udc4b\ud97d\udf66\udb73\udff6\udb2d\udc1e\ud914\udc09\ud8f4\ude80\ud8ad\udf7e\udaa7\uddc1\ud9d0\udcd7\uda3b\udc98\ud840\udd5b\ud8f2\udf8b\udba0\udd88\udb0c\udfc3\udb4d\udefb\uda94\udcfe\uda51\udf72\udab0\udeb1",
        54, 46517, -599217167, 172527750890173357L, 41741L, true, true, (char) 42049, (char) 14033,
        Double.longBitsToDouble(0x3fede4a07cdb5d9bL), Double.longBitsToDouble(0x3fef9afe5600c00bL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 3, 2, "\ud94c\udc6b\ud9e7\ude14\uda32\ude4a\ud8b5\udffe\ud9b3\ude7e\ud86d\udcdc\ud8d3\udf62\udaf9\udcc9", "\u3e3d\u5f60\uc74b\u2e33\u4519\ub892\u5290\u3945\u339c\u0bf3\u677b\u724d\ub7c6\uc43f\u58dd\ua3c6\uab2a\u1ae0\u609c\uc993\u5447\u3d41\u2fa1\u8588", "\udb56\udf04\ud815\udf58\ud8f3\udefd",
        -3, 23801, -2052032329, 5528941551147895055L, -9230L, true, true, (char) 34433, (char) 62779,
        Double.longBitsToDouble(0x3fd3a484896d0a18L), Double.longBitsToDouble(0x3fc92d047325cac0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 3, 2, "\ud94c\udc6b\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda04\ude3f\ud928\udd74\uda78\uddec\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\u1ae0\u609c\uc993\u5447\u3d41\u2fa1\u8588\u82e0\uab64\uca5a", "\udb41\udea8\ud974\udc4b\ud97d\udf66",
        23, 16812, -1748928978, -4230430406224792130L, -97601L, true, true, (char) 2884, (char) 12392,
        Double.longBitsToDouble(0x3fc92e561da14260L), Double.longBitsToDouble(0x3f7127d5ea554e80L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 3, 4, "\u0ca3\ud993\ude0a", "\u47c8\u224c\u5953\u12ed", "\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\u0939\ud931\udf7a\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b\udbab\udc02\ud88a\udfb3\ud9bc\udfa8\udbfd\udec0\ud852\udf8a\ud882\udd0b\udab8\ude50\ud85d\udee5\u6014\udbe4\udc3a",
        54, 12720, 319819765, -3369998810121129360L, 5944L, true, false, (char) 9266, (char) 54310,
        Double.longBitsToDouble(0x3fe7d4a4fd28a6e5L), Double.longBitsToDouble(0x3fc192beb2574298L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 1, 1, 6, "\u0ca3\u0239\uda4f\udcbc\ud8a1\udfb0\ud8fb\udc87\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\ud8dc\uddf9\uda81\udea8\u276c\u20e5", "\ud77a\u0ee8\u3945\u339c\u0bf3\u677b\u724d\ub7c6\uc43f\u58dd\ua3c6", "\udbfd\uded2\ud852\udf8a\ud978\ude09\udb9e\udccf\ud93d\udcaf\u605a",
        34, 81181, -1825985552, 858347104533378131L, -69455L, false, false, (char) 42828, (char) 5531,
        Double.longBitsToDouble(0x3fdbec54a1192beaL), Double.longBitsToDouble(0x3fc2ba14d4e92120L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 15, 9, "\ud955\ude29\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udcdc\udb24\udfab\ud834\ude77\ud87c\udc4d\ud8dc\uddec\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\ud8fe\udde1", "\uc38e\ub9b1\u4b05\u0aff\u3d41\u5d9e\u8588\u82e0\uab64\uca5a\u2dad\u83ff\u7b97\u65a1\u8e70\u231c\u2b9f", "\ud8ad\udf7e\udaa7\uddc1\ud9d0\udcd7\uda3b\udc98\ud840\udd5b\ud8f2\udf8b\udba0\udd88\udb0c\udfc3\udb4d\udefb\uda94\udcfe\uda51\udf72\udab0\udeb1\udbbe\udc9c\u2a2b\udbf3\udffb\ud8d2\udd0a\uda83\uddf8\ud98f\ude3f\ud8d1\udc98\ud9c3\udc26\ud9c9\udc67\udb12\ude72\ud90c\ude81",
        2, 66547, 398736748, -5820191905553096486L, -29234L, true, true, (char) 26986, (char) 2298,
        Double.longBitsToDouble(0x3fc977858db3749cL), Double.longBitsToDouble(0x3fd71be250c6060aL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 8, 1, 2, "\\", "\u8896", "\ub3a7\ud8cf\udcc7<",
        -5, 88752, 88219941, 5726766159632672797L, 90464L, false, false, (char) 59058, (char) 36182,
        Double.longBitsToDouble(0x3fd28b1000f4cf34L), Double.longBitsToDouble(0x3fe1b1734fcd7988L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 3, 14, "", "", "\ud8e5\udf85\udada\udc5a\udb67\udefc\ud8c6\ude61",
        55, -1000, -1370581248, 378901762783416187L, -69233L, false, false, (char) 38877, (char) 59058,
        Double.longBitsToDouble(0x3fd2acc2c2516200L), Double.longBitsToDouble(0x3fbe99e6ba0177c8L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 15, 15, 4, "\udab3\udc29\udac4\udd2b\ud99a\udf8c\u4a11\udb45\udf7f\ud86d\udcdc\uda3c\udc75\uda90\udf99\udb53\uddd0\ud83d\udf54\udb56\udebe\ud928\udd51\u0c2a\ud9b9\udf93\udb67\udd16\ud924\udfc0\u8535\uda41\udd42\ud9dd\ude40\ud8a0\udd85\uda69\ude93\uda9d\ude95\udb09\udd1b\udbf3\udece\udb53\udc4b", "\uc38e\u75d6", "\udb9e\udc8c",
        31, 24549, 1114244185, -8338004723398067855L, -4615L, true, true, (char) 27482, (char) 10116,
        Double.longBitsToDouble(0x3fc5fd2ac8035e2cL), Double.longBitsToDouble(0x3fa584e370797a40L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 15, 15, 4, "\udaeb\udf29\ud889\ude23\ud9a0\ude56\u4a11\ud8b9\ude48\ud86d\udc32\uda3c\udc75\uda90\udf99\udb53\uddd0\ud83d\udf54\udb56\udebe\ud928\udd51\u0c2a\ud9b9\udf93\udb67\udd16\ud924\udfc0\u8535\uda41\udd42\ud9dd\ude40\ub743\uda69\ude93\uda9d\ude95\udb09\udd1b\udbf3\udece\udb53\udc4b", "\uc38e\u75d6", "\udb9e\udc8c\ud93d\udcaf\u605a\udbd6\udc42\ud8f9\ude0f\ud884\udc6a\ud8fc\ude41",
        36, 81847, 1007205894, -1632858897745475409L, -60021L, true, false, (char) 23398, (char) 14389,
        Double.longBitsToDouble(0x3fdfd95d909b8be2L), Double.longBitsToDouble(0x3fe4f1c726a7b196L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 0, 3, 4, "\u0ca3O", "\u46c9", "\u0099",
        -5, -1000, -1370581248, 378901762783416187L, 23136L, true, false, (char) 35294, (char) 26887,
        Double.longBitsToDouble(0x3fd2acc000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 2, 1, 2, "\\\000\uda44\udd98\ud877\udcd9", "\u8dbb\u7347<\ub38e\u81f3\ube67\u95ac\ud07e\u76e7\ub5e2", "\ud8dc\udc1e\ud993\udd8b\ud9bc\udf39\udab4\udf6d\ud981\udc20\ud8e9\udd23\ud96c\ude90\ud8ca\ude74\udb9a\udc84\ud96b\udfac\uda1e\udca6\udb62\ude4e\ud95a\udeba\uda08\udc5c\ud96f\udf2c\ud9b0\ude1e",
        25, 2749, -1837531855, 3754161031871207740L, 11417L, true, true, (char) 37537, (char) 63232,
        Double.longBitsToDouble(0x3fd5ff8242bb3d44L), Double.longBitsToDouble(0x3fef715394792ce9L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 12, 12, 4, "\u0ca3O", "\u98e4\u7407", "\ud8a5\udc41\udb08\udd74\uda04\ude8e\ud928\udd74\u0c2a\uda1e\udc26\u0865\ud931\udf7a\ud9db\udc82\ud884\udc50",
        -2, 38984, 64576, -5837900966349679050L, -71857L, false, true, (char) 39417, (char) 4471,
        Double.longBitsToDouble(0x3fddb3dc43ea5d1aL), Double.longBitsToDouble(0x3fe18252f2fcfa8aL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 1, 12, 10, 2, "\ud913\udd6b\ud993\ude0a\udb13\udfbb\uaffa\udb45\udf7f\ud86d\udcdc\uda3c\udc75\udaf9\udc52\ud851\udf8f\udad0\uddf3\uda04\ude3f\ud928\udd74\u0c2a\ud9b9\udf93\ud961\ude96\ud931\udf41\ucd0e\ud844\udfa4\ud863\udc83\ub743\ud87c\udf36\ud8da\udfa1\udb09\udcde\udbf3\udece\udb53\udc4b", "\uc38e\u75d6\uc8bb\u5447\u3d41\u5d9e\u8588\u8cd6\uab64\uca5a", "\udbf4\udce2\ud859\udc2d\ud97d\uded7",
        54, 34504, -1750828665, -4230430406224792130L, -68055L, false, true, (char) 50681, (char) 42609,
        Double.longBitsToDouble(0x3fe5be7f59da84afL), Double.longBitsToDouble(0x3feccc3460c661b9L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 2, 1, 2, "", "", "\ud8e5\udf85\udae1\udc9c\ub3a7\ud8cf\udcc7",
        55, 43800, -1370581248, 378901762783416187L, -100000L, false, false, (char) 38877, (char) 59058,
        Double.longBitsToDouble(0x3fd2acc2c2516200L), Double.longBitsToDouble(0x3fbe99e6b1b17348L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 8, 1, 2, "$\000\uda37\udd30\u8841\ud809\udd57\udae8\udc9f\ud969\udfff", "\000\u3e2d\u5f60\u95ac", "\uda18\udc0e\ua509\ud918\udfbd\udbad\udc8c\ub777\ud8be\udf97\ud89b\udf87\udbd4\udc9d\ud9b8\udeb1\udb0d\udfac\ud8ca\udcba",
        23, 96304, 194402443, -3910663723212054076L, 11103L, true, false, (char) 44256, (char) 32963,
        Double.longBitsToDouble(0x3fc7206e17eca438L), Double.longBitsToDouble(0x3fcd356faa5cdc38L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 1, 1, 2, "$\000\uda37\udd30\u8841\ud809\udd57\udae8\udc9f\ud969\udfff", "\000\u3e2d\u5f60\u95ac", "\uda18\udc0e\ua509\ud918\udfbd\udbad\udc8c\ub777\ud8be\udf97\ud89b\udf87\udbd4\udc9d\ud9b8\udeb1\udb0d\udfac\ud8ca\udcba",
        23, 96304, 194402443, -3910663723212054076L, 11103L, true, false, (char) 44256, (char) 32963,
        Double.longBitsToDouble(0x3fc7206e17db6438L), Double.longBitsToDouble(0x3fe52d5bea97370eL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 1, 1, 2, "_\000\uda37\udd30\u8841\ud809\udd57\udae8\udc9f\udac1\udd54", "\u5baf\ua827\u3aff\u589e", "\uda18\udc0e\ua509\ud918\udfbd\udbad\udc8c\ub777\ud8be\udf97\ud89b\udf87\udbd4\udc9d\ud9b8\udeb1\udb0d\udfac\ud8ca\udcba",
        23, 96304, 194402443, -3910563779323076156L, 11103L, true, false, (char) 44256, (char) 32963,
        Double.longBitsToDouble(0x3fc7206e17db6438L), Double.longBitsToDouble(0x3fe52d5bea97370eL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=java.lang.Boolean:true |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 1, 10, 4, "_\000\uda37\udd30\u8841\ud8af\udf9e\udae8\udc9f\udac1\udd54\ud8cf\udd24\ud838\udef8\ud82c\udde9\uda9a\udf6a\udbb3\udda1\udbff\ude95\ud934\udd32\000\uda18\udc0e", "\ub97e", "\ud9fa\udf4f\udb33\ude0a\udb4f\udddf\udb0d\udfac\ud8ca\udcba\ud854\ude2d\udbcc\udffa\uda6d\udd9d\udab1\udf0d\ud850\udf8e\udaff\udf52\uda85\udc11\ud8ac\uddc1\udae6\udc1f\ud8f5\udc40\ud8e7\udc7c\udb0c\udf51\uda53\udd46\uda53\udcc2\ud9db\uddb6\ud975\udf79\uda5f\udde3",
        13, 70228, 297964647, 8570231798686454371L, -1039L, true, true, (char) 61907, (char) 501,
        Double.longBitsToDouble(0x3fe676601adb0e1fL), Double.longBitsToDouble(0x3fe8a0b9361920c0L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 8, 3, 14, "+", "\u6569", "\udba2\udd74\uda40\udc1f\ud94b\udc7c\ud96d\udc3e\uda04\udf11\ud957\udf38\u0c2a",
        24, 51477, 3653995, -5548268818501647645L, 48816L, true, false, (char) 40745, (char) 18732,
        Double.longBitsToDouble(0x3fc99dd0a3ba2f48L), Double.longBitsToDouble(0x3fc3da5c8708baecL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 1, 3, 14, "+", "\u6569", "\udba2\udd74\uda40\udc1f\ud94b\udc7c\ud96d\udc3e\uda04\udf11\ud957\udf38\u0c2a",
        24, 51477, 3653995, -5548268818501647645L, -7504L, true, false, (char) 40745, (char) 18732,
        Double.longBitsToDouble(0x3fc99dd0a3ba2f48L), Double.longBitsToDouble(0x3fc3da5c8708baecL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 3, 14, "+", "\u33db", "\udba2\udd74\uda40\udc1f\uf687\ud96d\udc3e\uda04\udf11\ud957\udf38\udb30\udca0",
        3, 33991, -230339982, -5548268818501647645L, 48816L, true, false, (char) 40745, (char) 50751,
        Double.longBitsToDouble(0x3fc99dd0a3ba2f48L), Double.longBitsToDouble(0x3fc3da5c8708baecL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\0121=void |this=com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:@?\012",
        Z.run(T, 2, 3, 3, 14, "+\ud800\ude0b\ud843\udfb7\u91cc\ud8e5\udf85\udbff\udd7b\udba2\udd74\uda40\udc1f\uf687\ud9d4\udef2\uda03\udf6f\ud919\udc13\udb22\udf87\ud858\udf6c", "\uc3a5\ua55a\u7ef2\u501a\ub005\u0b97\u78c2\u6b1a\u7377\u4801\ud616\u1d87\u2131\u8085\u5792\u3771\u297e\u27d3\u86e6\u8e01\u5562\ud504\u5e4f\u01fb\u9b2b\u1c8b\u01e0\u8c7b\u7097\uc138", "\ud916\udf9b\udbb8\udca9",
        4, 43592, 69177401, 7954935638104537125L, 23409L, true, true, (char) 17178, (char) 41088,
        Double.longBitsToDouble(0x3fed895ba32f2adfL), Double.longBitsToDouble(0x3fb064065e018038L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.CodeConsumer|addNumber|double|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|add|java.lang.String|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|addIdentifier|java.lang.String|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|addOp|java.lang.String,boolean|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|append|java.lang.String|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|appendBlockEnd||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|appendBlockStart||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|appendOp|java.lang.String,boolean|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|beginBlock||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|beginCaseBody||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|breakAfterBlockFor|com.google.javascript.rhino.Node,boolean|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|continueProcessing||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|endBlock||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|endBlock|boolean|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|endCaseBody||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|endFile||new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
    "M|com.google.javascript.jscomp.CodeConsumer|addNumber|double|new:com.google.javascript.jscomp.CodePrinter$CompactCodePrinter:boolean,boolean,int,boolean,com.google.javascript.jscomp.SourceMap$DetailLevel",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
