package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class SourceFile_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 14, 7, "\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb", "\u772d\u6850\u17fe\ubaee\u57e3\u1b70\u3d56\u37ff\u8790\u1a01\u0a2b\uce37\u201c\u927c\u317c\u5263\ud45b\uceef\u0ea2\ud0e1\u56ff\u5ad8\u5de5\u2f06\ubaea\u3ff5\u622d\u975b\u3d12\u3263\ud497\u96e0\u73e1\u1851\u9ccc\ud523\ud572\ub39b\u1aa4\ubb57", "\udbae\udc57\ud8f7\udda1\ud826\udf74\uda6a\ude66\ud874\uddf8\udbe3\udf68\udb3e\udeb9\udb9f\udc37\ud839\ude4c\ud9b3\udde2\ud9b8\udeef",
        57, 90705, -286939404, 9061083506431094068L, 78333L, false, false, (char) 13904, (char) 21597,
        Double.longBitsToDouble(0x3fd1eef23efd6f58L), Double.longBitsToDouble(0x3fe5dd5cd7514660L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 14, 7, "\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb", "\u1c9b\u0d49\u17fe\ubaee\u57e3\u1b70\u3d56\u37ff\u8790\u1a01\u0a2b\uce37\u201c\u927c\u317c\u5263\u99fc\ucf61\u0ea2\ud0e1\u56ff\u5ad8\u5de5\u2f06\ubaea\u3ff5\u622d\u975b\u3d12\ua584\ud497\u96e0\u73e1\u1851\u9ccc\ud523\ud572\ub3cd\u1aa4\ub9dc", "\udbae\udc57\ud8f7\udda1\ud826\udf74\uda5d\udd52\ud874\ude07\udbe3\udf68\udb3e\udeb9\udb9f\udc37\udbf3\udfbf\ud9b3\udde2\ud98b\udcf6\udbfa\udc38",
        30, 596, 2109697905, 70348075027085963L, 68274L, true, false, (char) 15042, (char) 16794,
        Double.longBitsToDouble(0x3fe032bacfe2375dL), Double.longBitsToDouble(0x3fd64a2f9b77ce46L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 14, 7, "\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb", "\u772d\u6850\u17fe\ubaee\u57e3\u1b70\u3d56\u37ff\u8790\u1a01\u0a2b\uce37\u201c\u927c\u317c\u5263\ud45b\uceef\u0ea2\ud0e1\u56ff\u5ad8\u5de5\u2f06\ubaea\u3ff5\u622d\u975b\u3d12\u3263\ud497\u96e0\u73e1\u1851\u9ccc\ud523\ud572\ub39b\u1aa4\ubb57", "\udbae\udc57",
        1, 83075, -218379477, -5214906426587013669L, -72713L, false, false, (char) 38612, (char) 59582,
        Double.longBitsToDouble(0x3fe7a5cf2f71eee5L), Double.longBitsToDouble(0x3fd347dbf51601f2L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 7, "\udbbb\udc7f\ud9a6\udfc1", "\u9e2f\u772d\u6850\u17ba", "\ud833\uded5\udab1\udd39\udbcd\ude3c\udb0b\udf37\u48b4\ud81d\udd51\ud924\udd19\ud94e\udd2e\udbcb\udffb\udb1a\udcb1",
        31, 79453, 416946708, 3424625011708239859L, -38251L, false, true, (char) 45326, (char) 47943,
        Double.longBitsToDouble(0x3fd056d09cecc8b4L), Double.longBitsToDouble(0x3fa608510fbd3700L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 14, 7, "\udb2a\udf85", "\u2b00\u9e2f", "\udadf\uddb2\ud803\udfa3\udaa4\udf85\ud833\uded5\udab1\udd39\ud800\ude55",
        -5, 22104, -994090907, -6838066563061812074L, -88415L, false, true, (char) 11952, (char) 42063,
        Double.longBitsToDouble(0x3fe270c6d7f32f86L), Double.longBitsToDouble(0x3fc3c0193b2edf08L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.SourceFile:\ud9c9\udeb4\ud99a\udfbd\ud9a8\uddeb\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 6, 14, "\ud9c9\udeb4\ud99a\udfbd\ud9a8\uddeb", "\u772d\ud0e7\u8c27\u459a\u5878\u1b70\u3d56\ub0fe\u8790\u1a01\u0a2b\uce37\u201c\u3a39\u317c\u5263\ud45b\uceef\u0ea2\ud0e1\u56ff\u5ad8\u5de5\u176e\u4726\u0c67\ucdb2\u0e25\u3d12\u9f20\u30a1\ua8b3\u7497\u1851\u9ccc\ud523\ud572\ub39b\u1aa4\ubb57", "\udbae\udc57\ud8f7\udda1\ud826\udf74\uda6a\ude66\ud874\uddf8\udbe3\udf68\udb3e\udeb9\udb9f\udc37\ud839\ude4c\ud89f\ude39\ud9b8\udf68",
        57, 90705, -286939404, 9061083506431094068L, 78333L, false, false, (char) 13904, (char) 21597,
        Double.longBitsToDouble(0x3fe0f7791f7eb7acL), Double.longBitsToDouble(0x3fe5dd5cd7514660L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 14, 7, "\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb", "\u1751\u6850\u17fe\ubaee\u57e3\u1b70\u3d56\u37ff\u8790\u1a01\u0a2b\uce37\u201c\u927c\u311f\u7edf\u702e\u78fc\uacdc\ucff5\u56ff\u5ad8\u5de5\u2f06\ubaea\u13f8\u9bce\u975b\u3d12\ubb2f\u0ead\u438c\u0cf0\uc83b\u9ccc\ub76a\u2a0c\u1d3b\u1aa4\ubb57", "\udb96\ude8d\uda9c\udcf5\uda8b\udd9c\uda6a\ude66\ud874\uddf8\ud941\udd2c\udb3e\udf0c\udb9f\udc37\ud839\ude4c\ud9b3\udde2\ud9b8\udeef\udbfa\udc38\uda05\udfdb\udbe5\uddf1\ud831\udeda",
        28, 27132, 207620614, -1200612470111552316L, 78333L, false, false, (char) 13904, (char) 21597,
        Double.longBitsToDouble(0x3fd1eef23efd6f58L), Double.longBitsToDouble(0x3fe5dd5e2f324edeL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SourceFile$Preloaded:\udb2a\udf85\udbf1\udce6\ud9a8\uddeb\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 14, 7, "\udb2a\udf85\udbf1\udce6\ud9a8\uddeb", "\ubbd5\u4891\ub2af", "\udb9a\ude6b\udab1\udd39\udbcd\ude3c\udb0b\udf37\u48b4\ud81d\udce7\ud924\udd19\u2a51\udbb6\ude8a\udb1a\udcb1",
        26, 76212, 416966739, 3424625012798758899L, -52768L, false, true, (char) 42510, (char) 47612,
        Double.longBitsToDouble(0x3fb9e0cae3de27b8L), Double.longBitsToDouble(0x3fe872a74a19e3c2L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SourceFile$OnDisk:\udb2a\udf85\udb9f\udd0c\ud9a8\uddeb\012",
        Z.run(T, 1, 8, 5, 7, "\udb2a\udf85\udb9f\udd0c\ud9a8\uddeb", "\u39b0\u1ded\u17fe\ubaee\u57e3\ua3eb", "\udaed\udd40\u48b4\ud81d\udce7\ud924\udd19\ud94e\udd2e\udbcb\udffb\udb1a\udcb1\ud998\udd91\udb70\udc3f\udbd2\ude8c",
        41, 82459, -1211988834, 4137416946757765438L, 54059L, true, true, (char) 6864, (char) 33998,
        Double.longBitsToDouble(0x3fcf7a6e196e27d0L), Double.longBitsToDouble(0x3fe5daa3336366d1L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.SourceFile:\ud992\udcd3\ud9a6\udfaf\ud9a8\uddeb\udabe\ude38\uda04\ude3a\udad3\udead\ud8e1\udee2\udadf\uddb2\ud803\udfa3\udaa4\udf85\udae1\udecc\udab1\udd39\udbcd\ude3c\udb0b\udf37\u48b4\ud81d\udce7\ud924\udd19\ud94e\udd2e\udbcb\udffb\udb1a\udcb1\ud998\udd91\ud80d\ude31\udb47\udf4f\ud9e0\udeb3\ud8b2\udd45\udb7a\udf2f\ud8ca\ude2d\udaef\udde4\ud936\udf5f\udbe6\udc1c\udbe7\udeee\ud9e3\ude70\udb4b\udef9\ud822\uddde\ud9e8\udcbc\udb5d\udf1d\ud841\udd32\udad3\udcf3\udb91\ude9d\udab6\udf90\udbe3\udfbc\udad0\ude0c\0121=null |this=com.google.javascript.jscomp.SourceFile:\ud992\udcd3\ud9a6\udfaf\ud9a8\uddeb\udabe\ude38\uda04\ude3a\udad3\udead\ud8e1\udee2\udadf\uddb2\ud803\udfa3\udaa4\udf85\udae1\udecc\udab1\udd39\udbcd\ude3c\udb0b\udf37\u48b4\ud81d\udce7\ud924\udd19\ud94e\udd2e\udbcb\udffb\udb1a\udcb1\ud998\udd91\ud80d\ude31\udb47\udf4f\ud9e0\udeb3\ud8b2\udd45\udb7a\udf2f\ud8ca\ude2d\udaef\udde4\ud936\udf5f\udbe6\udc1c\udbe7\udeee\ud9e3\ude70\udb4b\udef9\ud822\uddde\ud9e8\udcbc\udb5d\udf1d\ud841\udd32\udad3\udcf3\udb91\ude9d\udab6\udf90\udbe3\udfbc\udad0\ude0c\012",
        Z.run(T, 2, 14, 14, 7, "\ud992\udcd3\ud9a6\udfaf\ud9a8\uddeb\udabe\ude38\uda04\ude3a\udad3\udead\ud8e1\udee2\udadf\uddb2\ud803\udfa3\udaa4\udf85\udae1\udecc\udab1\udd39\udbcd\ude3c\udb0b\udf37\u48b4\ud81d\udce7\ud924\udd19\ud94e\udd2e\udbcb\udffb\udb1a\udcb1\ud998\udd91\ud80d\ude31\udb47\udf4f\ud9e0\udeb3\ud8b2\udd45\udb7a\udf2f\ud8ca\ude2d\udaef\udde4\ud936\udf5f\udbe6\udc1c\udbe7\udeee\ud9e3\ude70\udb4b\udef9\ud822\uddde\ud9e8\udcbc\udb5d\udf1d\ud841\udd32\udad3\udcf3\udb91\ude9d\udab6\udf90\udbe3\udfbc\udad0\ude0c", "\u343d\u6485", "\ud8f7\udda1\ud930\udd99\ud835\uddfe\ud874\uddf8\udbe3\udf68\u8f73\udb9f\udc37\ud839\ude4c\uda9e\uddce\ud996\udcfc",
        57, 92625, -933861128, 8197834158974338L, 59215L, false, true, (char) 43905, (char) 15042,
        Double.longBitsToDouble(0x3feb1fd1b7605b3dL), Double.longBitsToDouble(0x3fce9f5452736ed8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SourceFile$Generated:\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 7, "\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb", "\u772d\u6850\u17fe\ubaee\u57e3\u1b70\u3d56\u37ff\u8790\u1a01\u0a2b\uce37\u201c\u927c\u317c\u5263\ucf16\u373c\ua871\ud0e1\u56ff\u5ad8\uc8dc\u8dd1\uba8d\u3ff5\u622d\u975b\u3d12\u3263\ud497\u96e0\u73e1\u1851\u9ccc\ud523\ud572\ub39b\u1aa4\u65c5", "\udbf2\udd09\ud8f7\udda1\ud826\udf74",
        43, 30980, 442572251, -2145397344189543093L, -47274L, false, false, (char) 38612, (char) 59582,
        Double.longBitsToDouble(0x3fe7a5cf2f71eee5L), Double.longBitsToDouble(0x3fd347dbf51601f2L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.SourceFile:\udb7a\udcef\uda35\uddea\ud9a8\uddeb\0121=null |this=com.google.javascript.jscomp.SourceFile:\udb7a\udcef\uda35\uddea\ud9a8\uddeb\012",
        Z.run(T, 2, 1, 14, 7, "\udb7a\udcef\uda35\uddea\ud9a8\uddeb", "\u772d\u6850\u17fe\ubaee\u57e3\u1b70\ua234\u04cc\u8790\u1a01\u0a2b\u0555\u201c\u927c\u317c\u5263\ud45b\uceef\u0ea2\ud0e1\u25a4\u3ab4\u6b50\u2f06\ubaea\u3ff5\u622d\u975b\u3d12\u3263\ud3f3\u96e0\u73e1\u1851\u9ccc\u1c98\ud572\ub39b\u1aa4\ubb57", "\ud946\ude96\ud8f7\udda1\ud826\udf74\uda6a\ude76\ud9bb\udebb\udbe3\udf68\u7b09\ud978\udebe\ud839\ude7e\ud9b3\udde2\ud9b8\udeef",
        44, 22210, 384681501, 1368585466255138041L, 78333L, false, true, (char) 13904, (char) 46941,
        Double.longBitsToDouble(0x3fda37c4dca30944L), Double.longBitsToDouble(0x3fe5dabfd7514660L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 7, "\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb", "\u772d\u6850\u17fe\ubaee\u57e3\u1b70\u3d56\u37ff\u8790\u1a01\u0a2b\uce37\u201c\u927c\u317c\u5263\ud45b\uceef\u0ea2\ud0e1\u56ff\u5ad8\u5de5\u2f06\ubaea\u730c\u94c4\u5573\u3d12\u3263\ud497\u96e0\u73e1\u1851\u9ccc\ud523\ud572\ub39b\u1aa4\ubb57", "\udbae\udc57\ud8f7\udda1\ud826\udf74\uda6a\ude66\ud874\uddf8\udbe3\udf68\udb3e\udeb9\udb9f\udc37\ud839\ude4c\ud9b3\udde2\ud9b8\udeef",
        57, 90705, -286939404, 9061083506431094068L, 78333L, false, false, (char) 13904, (char) 21597,
        Double.longBitsToDouble(0x3fd1eef23efd6f58L), Double.longBitsToDouble(0x3fe5dd5cd7514660L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SourceFile$Preloaded:\ud92f\udc5e\ud855\ude3a\ud88c\ude5e\0121=null |this=com.google.javascript.jscomp.SourceFile:\ud92f\udc5e\ud855\ude3a\ud88c\ude5e\012",
        Z.run(T, 2, 4, 14, 7, "\ud92f\udc5e\ud855\ude3a\ud88c\ude5e", "\u772d\u95df\u17fe\ubaee\u57e3\u1b70\u3d56\u37ff\uced2\u9f2d\ua972\uce37\u201c\u73ac\u317c\u5263\ud45b\uceef\u4100\ud0e1\u56ff\u5ad8\u5de5\u2f06\ubaea\u3ff5\u622d\u975b\u3d12\u3263\ud0bc\u96e0\u73e1\u1851\u9ccc\u0897\ud572\ub39b\u1aa4\ubb57\u6485", "\ud8f7\udda1\ud8c1\udd7a\uda6a\ude66\ud874\uddf8\udbe3\udf68\udb3e\udeb9\udb9f\udc37\ud839\ude4c\ud9b3\udde2\ud9b8\udeef",
        -4, 90705, -286939404, 9061083506431094068L, 78333L, false, true, (char) 1106, (char) 21580,
        Double.longBitsToDouble(0x3fd1eef23efd6f58L), Double.longBitsToDouble(0x3fda1ab9aea27c84L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.SourceFile:\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 2, 7, "\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb", "\u772d\u6850\u17fe\ubaee\u57e3\u1b70\u3d56\u37ff\u8790\u1a01\u0a2b\uce37\u201c\u927c\u317c\u5263\ud45b\uceef\u0ea2\ud0e1\u56ff\u5ad8\u5de5\u2f06\ubaea\u3ff5\u622d\u975b\u3d12\u3263\ud497\ub614\u73e1\u1851\u9ccc\ud523\ud572\u390b\u1aa4\ubb57", "\udbae\udc57\ud8f7\udda1\ud826\udf74\uda6a\ude66\ud874\uddf8\udbe3\udf68\udb3e\udeb9\udb9f\udc37\ud839\ude4c\ud9b3\udde2\ud9b8\udeef",
        57, 90705, -286939404, 9061083506431094068L, 78333L, false, false, (char) 19792, (char) 21597,
        Double.longBitsToDouble(0x3fd1eef23efd6f58L), Double.longBitsToDouble(0x3fe5dd5cd7514660L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.SourceFile:\udb2a\udf85\uda04\udfd0\ud9d8\udc0c\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 7, "\udb2a\udf85\uda04\udfd0\ud9d8\udc0c", "\u1c9b\u0d49\u17fe\ubaee\u8325\ucb22\u99cd\u91d2\u8790\u1a01\u0a2b\uce37\u201c\u927c\u317c\u5263", "\u211b\udb7f\udffe\ud85e\udc5c\ud8ca\ude2d\udaef\udde4\ud936\udf5f\udbe6\udc1c\u291f\ud987\udfe3\ud9c3\udf79\udb77\ude1a\uda4b\ude7c\ud8a0\udcca\ud841\udd32\udad3\udcf3\udb91\ude9d\udab6\udf90\udbcb\udebc\udb5a\udf0a\udb49\udce7\udb50\udd3f\udbd5\ude3b\ud8a1\udcfe\udac5\udc82\udbae\udc57",
        1, 83075, 85200134, -5214906362162504229L, -81135L, true, true, (char) 38612, (char) 59582,
        Double.longBitsToDouble(0x3fe7a5cf2f71eee5L), Double.longBitsToDouble(0x3fd347dbf11601f2L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SourceFile$Preloaded:\udb2a\udf6d\ud9a6\udfc1\udae8\udff5\0121=com.google.javascript.jscomp.SourceFile$Preloaded:\udb2a\udf6d\ud9a6\udfc1\udae8\udff5\012",
        Z.run(T, 2, 3, 3, 7, "\udb2a\udf6d\ud9a6\udfc1\udae8\udff5", "\u1c9b\u0d49\u5979\ube1d\u0821\u87e1\u3f5f\u37ff\u8808\u1a01\uae51\uce4f\u201c\u1201\u1b48\u5289\u9cfb\uc4c5\u8b15\u1e15\uca96\u8338\ubedd\u2f06\u3bba\u3ff5\uc62c\u975b\u3d12\u0ebc\u87e7\ubb25\uacfa\u1851\u9ccc\u03be\u625a\ua28a\u9905\ub9dc", "\ud99b\udefd\udaf8\udcfc\ud99b\udf51\uda91\udeb7\ud874\ude07\ud875\udc51\udb3e\ude6a\udb9f\udc57\udbf3\udfbf",
        44, 41759, -1720367548, -5051544232361875724L, 89233L, true, true, (char) 7838, (char) 40369,
        Double.longBitsToDouble(0x3fa5f7ab0bbce180L), Double.longBitsToDouble(0x3fd28411c997e5d8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 5, "\udb19\udd33\ud886\udec8\uda3c\ude0b\ud818\udc5d\udaac\udc2e\uda62\udd6c\udb10\udf26", "\u57e3\u4c53\u6b61\u0c7e\uc223\u1a01\u0a2b", "\udbcb\udffb\udaa5\udd37\ud989\udd80\ud9b2\udf1b",
        44, 62646, 13213683, -5205452404183855413L, -94337L, false, true, (char) 46606, (char) 6864,
        Double.longBitsToDouble(0x3fa608510fbd3700L), Double.longBitsToDouble(0x3fcb513e995c22e0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SourceFile$Preloaded:\ud9ae\udc18\ud9a7\udc99\ud9a8\uddeb\udaa6\ude38\udaac\udc2e\uda62\udd6c\udb10\udf26\ud9fb\ude00\0121=com.google.javascript.jscomp.SourceFile$OnDisk:\ud9ae\udc18\ud9a7\udc99\ud9a8\uddeb\udaa6\ude38\udaac\udc2e\uda62\udd6c\udb10\udf26\ud9fb\ude00\012",
        Z.run(T, 2, 4, 8, 13, "\ud9ae\udc18\ud9a7\udc99\ud9a8\uddeb\udaa6\ude38\udaac\udc2e\uda62\udd6c\udb10\udf26\ud9fb\ude00", "\u1b70\ud2a3\ub5da\u8790\u1a01\u0a2b\u399c\u206e", "\ud998\udd91\udbea\ude40",
        44, 62646, 13213683, -5205452404183855413L, -94337L, true, true, (char) 46606, (char) 6864,
        Double.longBitsToDouble(0x3fd2c10a2821972aL), Double.longBitsToDouble(0x3fd7d89c1576a8ccL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 0, "", "\u17be\ua1e3\u797a\u1c9b\u0d49\u17fe\ubaee\u57e3\u1b70\u3d56\u37ff\u8790\u26eb\000\000\000\000\u317c\u5263\u99fc\ucf61\u0ea2\ud0e1\uc983\u4c0d\u5de5\u2f06\ubaea", ",",
        -5, 61312, 1725037243, 68270200236012040L, 95349L, true, true, (char) 12942, (char) 9320,
        Double.longBitsToDouble(0x3fea2ca3c8b8ddb8L), Double.longBitsToDouble(0x3fe0000002f22ac4L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SourceFile$OnDisk:\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 7, "\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb", "\u772d\u6850\u17fe\u3091\u716d\ube25\u3d56\u37ff\u8790\u1a01\u0a2b\ud724\u201c\u927c\u317c\u5263\u6e5d\ub1cb\u0f22\ud0e1\u56ff\u5ad8\u5de5\u2f06\ubaea\u3ff5\u622d\u975b\u3d12\u3263\ud497\u96e0\u73e1\u1851\u913c\u9f53\ud572\ub39b\u1aa4\ubb57", "\ud992\udd9a",
        26, 11960, -218379477, -5214906426587013669L, -72713L, false, false, (char) 38612, (char) 59582,
        Double.longBitsToDouble(0x3fe7a5cf2f71eee5L), Double.longBitsToDouble(0x3fd347dbf51601f2L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SourceFile$OnDisk:\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb\0121=null |this=com.google.javascript.jscomp.SourceFile:\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb\012",
        Z.run(T, 2, 7, 14, 7, "\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb", "\u772d\u6850\u17fe\uba4f\u57e3\u1b70\u3d56\u33f9\u87a6\u1a01\ub108\uce37\u201c\u927c\u317c\u5263\ud45b\uceef\ua3f6\uaf63\u6276\u305a\u6e95\u2f06\ubaea\u3ff5\u622d\u975b\u3d12\u3263\uc1c0\u12bd\u397b\u1851\u9ccc\ud523\u8d11\u08f9\u1aa4\u6c43", "\udbae\udcba",
        12, 86138, -218379477, -5214906426587013669L, -35526L, false, false, (char) 23043, (char) 10374,
        Double.longBitsToDouble(0x3fe2228487499975L), Double.longBitsToDouble(0x3fe7a5cf2f71eee5L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SourceFile$OnDisk:\udbbb\udc7f\0121=com.google.javascript.jscomp.SourceFile$OnDisk:\udbbb\udc7f\012",
        Z.run(T, 2, 8, 8, 0, "\udbbb\udc7f", "\u43fb\u219a", "\udb63\udea7\udbd7\udd13\u2d87\udbd4\udebb\ud8a1\udf78\ud99b\udd4e\udb8b\ude84\ud963\udcce\ud836\udd9f\udb4a\ude40\udada\udf8a\udb3d\udfbf",
        -3, 78018, 881248489, 3477258587959899886L, -68314L, false, true, (char) 49832, (char) 45431,
        Double.longBitsToDouble(0x3fdb0919720ada12L), Double.longBitsToDouble(0x3fe3b6a8842c10a2L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SourceFile$Generated:\udbac\udd36\ud9a6\udfc1\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 12, 7, "\udbac\udd36\ud9a6\udfc1", "\u7018\u5975\u3d59\u17cb\u5e5d\u5850\u1b70\u3d56\u37ff\u8790\u1a01\u0407\ubae9\u42ad\u927c", "\udae0\udd04\udbb4\udf8a\u211b\ud8d7\udc2a\ud85d\udff8\ud8ca\ude2d",
        42, 23833, 1829317008, 406112339700420994L, 84069L, true, true, (char) 52564, (char) 44717,
        Double.longBitsToDouble(0x3fd4e2e6226600a6L), Double.longBitsToDouble(0x3fe05e4e6801218fL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SourceFile$Generated:\udb2a\udf85\0121=com.google.javascript.jscomp.SourceFile$Generated:\udb2a\udf85\012",
        Z.run(T, 2, 9, 9, 7, "\udb2a\udf85", "\u2b00\u9e2f", "\udadf\uddb2\ud803\udfa3\udaa4\udf85\ud833\uded5\udab1\udd39\ud800\ude55",
        -5, 22104, -994090907, -6838066563061812074L, -88415L, false, true, (char) 11952, (char) 42063,
        Double.longBitsToDouble(0x3fe270c6d7f32f86L), Double.longBitsToDouble(0x3fc3c0193b2edf08L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.SourceFile:\ud9c9\udeb4\ud99a\udfbd\udad2\udd41\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 15, 10, "\ud9c9\udeb4\ud99a\udfbd\udad2\udd41", "\u772d\ud0e7\u8c27\u459a\u7120\u1b70\u3d56\ub0fe\u8790\u1a01\u0a2b\uce37\u201c\u3a39\u317c\u5263\ud45b\uceef\u0ea2\u1ffe\u56ff\u5ad8\u5de5\u176e\u4726\u0c67\ucdb2\u0e25\u3d12\u9f20\u30a1\ua8b3\u7497\uc024\u9ccc\ud523\ud572\ub39b\u1aa4\ubb57", "\udbae\udc57\udb55\udeb0\ud8be\udd86\uda6a\ude66\ud874\uddf8\udbe3\udf68\udb3e\udeb9\udb9f\udc37\ud839\ude4c\ud89f\ude39\ud9b8\udf68",
        57, 90705, -286939404, 821327369124572468L, 78333L, false, false, (char) 13904, (char) 21597,
        Double.longBitsToDouble(0x3fe0f7791f7eb7acL), Double.longBitsToDouble(0x3fe5dd5cd019c760L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.SourceFile:\ud992\udcd3\ud9a6\udfaf\ud9a8\uddeb\udabe\ude38\uda04\ude3a\udad3\udead\ud8e1\udee2\udadf\uddb2\ud803\udfa3\udaa4\udf85\udae1\udecc\udab1\udd39\udbcd\ude3c\udb0b\udf37\u48b4\ud81d\udce7\ud924\udd19\ud94e\udd2e\udbcb\udffb\udb1a\udcb1\ud998\udd91\ud80d\ude31\udb47\udf4f\ud9e0\udeb3\ud8b2\udd45\udb7a\udf2f\ud8ca\ude2d\udaef\udde4\ud936\udf5f\udbe6\udc1c\udbe7\udeee\ud9e3\ude70\udb4b\udef9\ud822\uddde\ud9e8\udcbc\udb5d\udf1d\ud841\udd32\udad3\udcf3\udb91\ude9d\udab6\udf90\udbe3\udfbc\udad0\ude0c\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 0, 14, "\ud992\udcd3\ud9a6\udfaf\ud9a8\uddeb\udabe\ude38\uda04\ude3a\udad3\udead\ud8e1\udee2\udadf\uddb2\ud803\udfa3\udaa4\udf85\udae1\udecc\udab1\udd39\udbcd\ude3c\udb0b\udf37\u48b4\ud81d\udce7\ud924\udd19\ud94e\udd2e\udbcb\udffb\udb1a\udcb1\ud998\udd91\ud80d\ude31\udb47\udf4f\ud9e0\udeb3\ud8b2\udd45\udb7a\udf2f\ud8ca\ude2d\udaef\udde4\ud936\udf5f\udbe6\udc1c\udbe7\udeee\ud9e3\ude70\udb4b\udef9\ud822\uddde\ud9e8\udcbc\udb5d\udf1d\ud841\udd32\udad3\udcf3\udb91\ude9d\udab6\udf90\udbe3\udfbc\udad0\ude0c", "\u343d\u6485", "\ud8f7\udda1\ud930\udd99\ud835\uddfe\ud874\uddf8\udbe3\udf68\u8f73\udb9f\udc37\ud839\ude4c\udaec\udeb4\ud996\udcf7",
        -4, 33264, -933861128, 8197834158974338L, 59215L, false, true, (char) 43905, (char) 15042,
        Double.longBitsToDouble(0x3feb1fd1b7605b3dL), Double.longBitsToDouble(0x3fce9f5452736ed8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SourceFile$OnDisk:\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 5, "\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb", "\u772d\u6850\ud553\ua39e\u3d3f\u1b70\u3d56\u37ff\u8790\u192a\u2064\uce37\u201c\u53ac\u314b\u5263\uc7fa\u8ade\ua871\ud0e1\u56ff\u5ad8\uc8dc\u8dd1\u1667\ubd02\u6274\u8e53\u3a15\u3263\ud497\u96e0\u73e1\u1851\u9ccc\ud523\u8425\u6299\u1aa4\u65c5", "\udbf2\udd09\uda82\udf47\ud8a0\uddb2",
        21, 87980, 442572251, -2145397872470520501L, -47274L, false, true, (char) 38612, (char) 59582,
        Double.longBitsToDouble(0x3fe7a5cf2f71eee5L), Double.longBitsToDouble(0x3fd347dbf51601f2L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.SourceFile:\udb7a\udcef\uda35\uddea\ud9a8\uddeb\0121=void |this=com.google.javascript.jscomp.SourceFile:\udb7a\udcef\uda35\uddea\ud9a8\uddeb\012",
        Z.run(T, 2, 1, 1, 7, "\udb7a\udcef\uda35\uddea\ud9a8\uddeb", "\u64cf\u4bf1\u24fc\ubaee\u57e3\u1b70\ua234\u04cc\u8790\u1a01\u0a2b\u0555\u201c\u927c\ubb76\u5bd6\ud45b\uceef\u0ea2", "\ud93c\udc75\u4cdf\ud8fc\ude8e",
        0, 68533, 279098998, -3210938803968265989L, 29559L, true, true, (char) 35066, (char) 50536,
        Double.longBitsToDouble(0x3fe8a999db450832L), Double.longBitsToDouble(0x3fe5da5aeb0c492aL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SourceFile$Preloaded:\ud958\udf6b\ud855\ude3a\ud88c\ude5e\udad5\udc8d\uda04\ude3a\udad3\udead\ud972\udce9\udadf\uddb2\udaed\udf97\udaa4\udf94\ud833\uded5\udab1\udd39\udbcd\ude3c\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 11, 7, "\ud958\udf6b\ud855\ude3a\ud88c\ude5e\udad5\udc8d\uda04\ude3a\udad3\udead\ud972\udce9\udadf\uddb2\udaed\udf97\udaa4\udf94\ud833\uded5\udab1\udd39\udbcd\ude3c", "\u5d88\uce37", "\ud8bb\udfa2\ud966\udde7\ud875\udf25\udbd2\udef1\udb48\udedb\udb7f\udffe\ud85e\udc5c\ud8ca\ude2d",
        42, 23833, 1829317040, 7231172437799515766L, 29723L, true, true, (char) 35066, (char) 50536,
        Double.longBitsToDouble(0x3fe8a999deb80832L), Double.longBitsToDouble(0x3fe5da5e9b0c492aL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SourceFile$Preloaded:\ud92e\udfe0\ud855\ude3a\ud8b4\ude2a\0121=com.google.javascript.jscomp.SourceFile$Preloaded:\ud92e\udfe0\ud855\ude3a\ud8b4\ude2a\012",
        Z.run(T, 2, 4, 4, 7, "\ud92e\udfe0\ud855\ude3a\ud8b4\ude2a", "\u772d\ua6bc\ud0bc", "\ud833\uded5\udab1\udd39\udb3b\uded3\ud85a\udf49\udb08\udf38\udb05\ude50\ud924\udd19\ud94e\udd2e\ue4d1\udb1a\udcb1\ud998\udd91\uda7c\udd6f\ud88a\udf72\udb48\udedb\udb7f\udffe",
        56, 79451, -955711170, -7955633062320461392L, 77782L, false, false, (char) 1132, (char) 29450,
        Double.longBitsToDouble(0x3fe5daa6579bbab2L), Double.longBitsToDouble(0x3fe044b79399a9cfL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SourceFile$OnDisk:\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb\0121=com.google.javascript.jscomp.SourceFile$OnDisk:\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb\012",
        Z.run(T, 2, 7, 7, 7, "\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb", "\u772d\u6850\u17fe\uba4f\u57e3\u1b70\u3d56\u33f9\u87a6\u1a01\ub108\uce37\u201c\u927c\u317c\u5263\ud45b\uceef\ua3f6\uaf63\u6276\u305a\u6e95\u2f06\ubaea\u3ff5\u622d\u975b\u3d12\u3263\uc1c0\u12bd\u8052\ua35a\ua27d\ud3f3\u14fc\u08f9\u1aa4\u6c43", "\udbae\udcba",
        12, 86138, -218379477, -5214906426587013669L, -35526L, false, false, (char) 23043, (char) 10374,
        Double.longBitsToDouble(0x3fe2228487499975L), Double.longBitsToDouble(0x3fe7a5cf2f71eee5L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.SourceFile$OnDisk:\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb\0121=null |this=com.google.javascript.jscomp.SourceFile:\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb\012",
        Z.run(T, 2, 7, 14, 7, "\udb2a\udf85\ud9a6\udfc1\ud9a8\uddeb", "\u772d\u6850\u17fe\ubaee\ua788\ua50a\u4a09\u37e9\u8790\u1a01\u0a2b\uce37\u4e02\u92a7\u317c\u6733\ud45b\uceef\u0ea2", "\udbb3\udddf\udaec\udfe1\uda80\udfeb",
        0, 58325, 279099123, -3210938803968265989L, 29723L, true, true, (char) 35066, (char) 57146,
        Double.longBitsToDouble(0x3fe8ab0f6b450832L), Double.longBitsToDouble(0x3fe5da585b0c492aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.SourceFile|getLine|int|new:com.google.javascript.jscomp.SourceFile:java.lang.String",
    "M|com.google.javascript.jscomp.SourceFile|clearCachedSource||new:com.google.javascript.jscomp.SourceFile:java.lang.String",
    "M|com.google.javascript.jscomp.SourceFile|findLineOffsets||new:com.google.javascript.jscomp.SourceFile:java.lang.String",
    "M|com.google.javascript.jscomp.SourceFile|fromCode|java.lang.String,java.lang.String|static",
    "M|com.google.javascript.jscomp.SourceFile|fromCode|java.lang.String,java.lang.String,java.lang.String|static",
    "M|com.google.javascript.jscomp.SourceFile|fromFile|java.io.File|static",
    "M|com.google.javascript.jscomp.SourceFile|fromFile|java.io.File,java.nio.charset.Charset|static",
    "M|com.google.javascript.jscomp.SourceFile|fromFile|java.lang.String|static",
    "M|com.google.javascript.jscomp.SourceFile|fromFile|java.lang.String,java.nio.charset.Charset|static",
    "M|com.google.javascript.jscomp.SourceFile|fromGenerator|java.lang.String,com.google.javascript.jscomp.SourceFile$Generator|static",
    "M|com.google.javascript.jscomp.SourceFile|fromInputStream|java.lang.String,java.io.InputStream|static",
    "M|com.google.javascript.jscomp.SourceFile|fromInputStream|java.lang.String,java.lang.String,java.io.InputStream|static",
    "M|com.google.javascript.jscomp.SourceFile|fromReader|java.lang.String,java.io.Reader|static",
    "M|com.google.javascript.jscomp.SourceFile|getCode||new:com.google.javascript.jscomp.SourceFile:java.lang.String",
    "M|com.google.javascript.jscomp.SourceFile|getCodeNoCache||new:com.google.javascript.jscomp.SourceFile:java.lang.String",
    "M|com.google.javascript.jscomp.SourceFile|getCodeReader||new:com.google.javascript.jscomp.SourceFile:java.lang.String",
    "M|com.google.javascript.jscomp.SourceFile|getLine|int|new:com.google.javascript.jscomp.SourceFile:java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
