package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class NodeUtil_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 1, "\uc751", "\u484c\u1940", "\udab1\udf38\udbf8\udef5\ud837\udf9b\ud910\udd5c\ud9f6\udf86\ud8d7\udf6e\uda8d\udf77\uda15\udd2d",
        41, 4265, 568804649, 8380265112512959432L, -36469L, false, false, (char) 37462, (char) 22530,
        Double.longBitsToDouble(0x3f975521103ed500L), Double.longBitsToDouble(0x3fed9db8dbad95c7L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 1, "\uc751", "\u484c\u1940", "\udab1\ude78\udbf8\udef5\ud837\udf9b\ud910\udd5c\ud9f6\udf86\ud8d7\udf6e\uda8d\udf77\uda15\udd2d",
        41, 4265, 568804649, 8380265112512959432L, -36469L, false, false, (char) 37462, (char) 22530,
        Double.longBitsToDouble(0x3f975521103ed500L), Double.longBitsToDouble(0x3fed9db8dbad95c7L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 11, "\uc751\ud993\udd95\udb1a\udea9\uda06\udff7\uda0c\udd31\udbdf\udfc1\uda41\udc21\udab1\udf38\udbf8\udef5\ud837\udf9b\ud910\udc5c\ud9f6\udf86\ud8d7\udf6e\ud9a2\udffa\ud942\udcf6\udbe1\udc10\ud820\ude9b\ud9d1\udf28\uda23\udd92\u8dd7\ud808\uddeb\ud821\udc2d\ud8e4\udfb2\ud81f\udc07\ud893\udd39\ud80e\udef9\ud944\udd5b\uf78a\ud8f1\udc35\ud9c2\udd70\udb32\udcc1\udaee\ude5f\udb4d\udc1f\udaab\udc05\ud9a6\uddd0\uca3f\ud868\udf5d\udb21\udeb6\udb5a\udcaa\ud86d\udf19\udbf7\ude3c\u029e\ud84a\ude49\ud846\udd96", "\u612c\uc3bb\u2bf4\ua09b\u6b81\u7621\u7900\u206e", "\ud8a8\udc72\udba0\udf60\ud8ca\udfd6\ud9b1\udfdd\ud902\udc0d\ud87b\udf47\udbeb\udd1c\uda5d\udcc1\uda8c\uddc6\udab5\udfe4\ud854\udfcf\udb0f\ude3e\ud93a\ude4f\udbd1\udf05\udafa\udf14\ud8b3\udcff\ud887\ude64\ud9f9\udcb2\ud85a\udc5e\ud868\udf94\ud99c\udf33\udb47\ude33\ud9da\ude0e\udbda\ude50\udb7d\udd22\ud8c9\udc3d\udb32\ude25\uda91\udc9c\udae3\udfc8\ud9ef\udfc0",
        52, 45093, -454688111, 530827535035652520L, -84170L, false, false, (char) 5326, (char) 45051,
        Double.longBitsToDouble(0x3fe88f84302c1419L), Double.longBitsToDouble(0x3fd916ed96cbd4beL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 9, 14, "\uc7f5\udab8\udc9a\udb1a\udea9\udb0d\uddf9\uda93\udf2d\udbdf\udfc1\uda41\udc21\u8196", "\ud291\ub333\ud65b\ub7f3\u5122\u5871\u7daa\u9d57", "\ud808\uddeb",
        30, 52037, 1402429756, -1283868299537701848L, 2141L, false, false, (char) 54990, (char) 47476,
        Double.longBitsToDouble(0x3fd6e5be9860c8e2L), Double.longBitsToDouble(0x3fedc844632730daL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 7, 1, "\uc751", "\u484c\u1940", "\udab1\udf38\udbf8\udef5\ud9d6\ude6b\ud834\udc61\ud9f7\udc60\ud8d7\udf6e\uda8d\udf77\uda15\udd2d",
        41, 66401, 568804649, 6950713032181825732L, 39762L, true, false, (char) 44344, (char) 5930,
        Double.longBitsToDouble(0x3fed9db8dbad95c7L), Double.longBitsToDouble(0x3fdf40e3483e8442L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 17, 1, "\uc751", "\u475a\u1940\u858c\uad74\u766b\u8d95", "\ud9f6\udffc\ud8d7\udf6e\uda8d\udf77\uda1f\udc2d\uda8d\udd3f\udb70\udf56\ud9d1\udf28\uda23\udd92\u8dd7\ud808\uddeb",
        30, 38188, 1402406869, -1283897226142440408L, -77319L, true, false, (char) 11419, (char) 35489,
        Double.longBitsToDouble(0x3fead4787438a390L), Double.longBitsToDouble(0x3fc1d7fddbe58844L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "\uc750", "\ucb4c\ucd3e", "\udab1\udf38\udbf8\udef5\ud837\udf9b\ud910\udd5c\ud9f6\udf86\ud8d7\udf6e\uda8d\udf77\uda15\udd2d",
        41, 4265, 568804649, 8380265112512959432L, -36469L, false, false, (char) 37462, (char) 22530,
        Double.longBitsToDouble(0x3f975521103ed500L), Double.longBitsToDouble(0x3fed9db8dbad95c7L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 7, 1, "\ud904\udcd9", "\u95e3\ubcca\u455b\uad74\u766b", "\ud910\udd5c\ud9f6\udf86\ud8d7\udf6e\uda8d\udf77\uda15\udd2d\ud8ce\udf7a\ud820\ude9b\ud9d1\udf0c",
        35, 90512, -1128671774, 95943491288068348L, 75686L, false, false, (char) 22530, (char) 15313,
        Double.longBitsToDouble(0x3fee3b323fb3b78dL), Double.longBitsToDouble(0x3fed6cae3e87ef04L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 7, 1, "\uc751", "\u484c\u1940", "\udab1\udf38\udbf8\udef5\ud837\udf9b\ud910\udd5c\ud9f6\udf86\ud8d7\udf6e\uda8d\udf77\uda15\udd2d",
        41, 4265, 568804649, 8380265112512959432L, 98613L, false, false, (char) 37462, (char) 22530,
        Double.longBitsToDouble(0x3f975521103ed500L), Double.longBitsToDouble(0x3fed9db8dbad95c7L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 7, 1, "\uc751", "\ua0bc\u1974", "\udb64\ude91\udbf8\udef5\ud837\udf9b\ud924\ude5c\ud9f6\udf86\ud8d7\udf6e\uda8d\udf77\uda15\udd2d",
        41, 4265, 568804649, 1895081647520248849L, -36469L, false, false, (char) 37462, (char) 34818,
        Double.longBitsToDouble(0x3f975521103ed500L), Double.longBitsToDouble(0x3fed9db8dbad95c7L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 7, 1, "\ud9fc\udf12", "\u71a8\u891f", "\udab1\udf38\udbf8\udef5\ud9d0\udde7\ud910\udcac\ud9f6\udf86\ud8d7\udfdc\uda8d\udf77\uda15\udd2d",
        23, 4408, 568804649, 8380265112512959340L, -36469L, false, false, (char) 37462, (char) 22530,
        Double.longBitsToDouble(0x3f975521103ed500L), Double.longBitsToDouble(0x3fed9db8dbad95c7L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 10, 13, "\uc751", "\u484c\u383f", "\udab1\udf38\udbf8\udef5\ud837\udf9b\ud910\udd16\ud9ca\udea0\ud92e\ude09\udab3\udf53\ud9b7\udddc",
        41, 4265, 1375618345, 8376655660652106696L, -36469L, false, false, (char) 57931, (char) 22530,
        Double.longBitsToDouble(0x3f9755210d2f8720L), Double.longBitsToDouble(0x3fed9db8dbad95c7L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 7, 1, "\ud853\ude4d", "\u484c\u1940", "\udab1\udf38\udbf8\udef5\ud837\udf9b\ud910\udd5c\ud9f6\udf86\ud8d7\udf6e\uda8d\udf77\udb0b\udd28",
        41, 4265, 568804649, 8380265112512959432L, -36469L, false, false, (char) 37614, (char) 22530,
        Double.longBitsToDouble(0x3f975521103ed500L), Double.longBitsToDouble(0x3fed9db8dbad95c7L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 3, 8, "\uc751", "\u484c\u1940", "\udab1\udf38\udbf8\udef5\ud837\udf9b\ud910\udd5c\ud9f6\udf86\udb88\ude6b\uda8d\udf77\udb0b\udedb",
        36, 9407, 568804649, 8380265112512959432L, -36469L, false, false, (char) 37462, (char) 22530,
        Double.longBitsToDouble(0x3fc38aa42207d928L), Double.longBitsToDouble(0x3fed9db8dbad95c7L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 7, "\uc7b6\udab8\udc9a\udb1a\udea9\uda06\udff7\uda93\udf2d\udbdf\udfc1", "\uc377\u4ff5\ud291\u18a9\ud612\ub7f3\u5122", "\ud9d1\udf28\uda23\udd92\u8dd7",
        51, 16585, -725847812, 6023291637741825606L, 23991L, true, false, (char) 14312, (char) 12162,
        Double.longBitsToDouble(0x3fd6133a93773be4L), Double.longBitsToDouble(0x3fd7845e577d8404L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.NodeUtil|evaluatesToLocalValue|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|evaluatesToLocalValue|com.google.javascript.rhino.Node,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.NodeUtil|isBooleanResultHelper|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|arrayToString|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|callHasLocalResult|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|canBeSideEffected|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|canBeSideEffected|com.google.javascript.rhino.Node,java.util.Set|static",
    "M|com.google.javascript.jscomp.NodeUtil|checkForStateChangeHelper|com.google.javascript.rhino.Node,boolean,com.google.javascript.jscomp.AbstractCompiler|static",
    "M|com.google.javascript.jscomp.NodeUtil|constructorCallHasSideEffects|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|constructorCallHasSideEffects|com.google.javascript.rhino.Node,com.google.javascript.jscomp.AbstractCompiler|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsCall|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsFunction|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsType|com.google.javascript.rhino.Node,int|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsType|com.google.javascript.rhino.Node,int,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.NodeUtil|copyNameAnnotations|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|functionCallHasSideEffects|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|evaluatesToLocalValue|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|evaluatesToLocalValue|com.google.javascript.rhino.Node,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.NodeUtil|isBooleanResultHelper|com.google.javascript.rhino.Node|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
