package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class Normalize_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 8, 4, "\ud941\udcca\ud8ee\ude6a\u1706\uda5f\udf1b\udafe\ude22\ud848\udcd7", "\u6901\u1bb9\u8b89\u169b\u47e7\u4528\u8e63\u2c92", "\uda97\udc1a\ud947\udda7\udb8e\ude3b\udbe9\udfb2",
        0, 69236, -946151101, 639573041915289167L, 36775L, true, false, (char) 27432, (char) 58735,
        Double.longBitsToDouble(0x3fd91efe288bdba2L), Double.longBitsToDouble(0x3feb122d5a426d0bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 8, 4, "\ud941\udcca\ud8ee\ude6a\u1706\uda5f\udf1b\udafe\ude22\ud848\udcd7", "\u6901\u1bb9\u7175\ud6ae\u47e7\u4528\u8e63\u2c92", "\uda97\udc1a\ud947\udda7\udb8e\ude3b\udbe9\udfb2",
        0, 69236, -772153021, 639729833991396943L, 36775L, true, false, (char) 27432, (char) 58735,
        Double.longBitsToDouble(0x3fd91efe288bdba2L), Double.longBitsToDouble(0x3feb122d5a426d0bL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 4, "\ud941\udcca\ud8ee\uddd0\u1706\uda5f\udf1b\udafe\ude22\ud848\udcd7", "\u6901\u1bb9\u8b89\u169b\u47e7\u4528\u8e63\u2c92", "\uda97\udc1a\ud947\udda7\udb8e\ude3b\udbe9\udfb2",
        0, 69236, -946151101, 639573041915289167L, 36775L, true, false, (char) 27432, (char) 58735,
        Double.longBitsToDouble(0x3fd91efe288bdba2L), Double.longBitsToDouble(0x3feb122d5a426d0bL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 4, "\ud9f0\ude99\ud9e8\ude70\u1706\udb93\udd16\udacf\udc2e\ud831\udcfc", "\u6901", "\udb5c\udc85\uda53\ude1d\ud9aa\udee5\ud80b\udf76\ud8d8\udcad\udb54\udd2d\uda3e\udc94\ud8ab\udc41\ud947\udda7\ud966\udd07\uda32\udcf6",
        8, 12425, 1869118846, 639573312498215962L, 36775L, false, false, (char) 27432, (char) 58735,
        Double.longBitsToDouble(0x3fe2842714457dafL), Double.longBitsToDouble(0x3febe11d5cd85ea8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 7, 8, 8, "\ud941\udcca\ud8ee\ude6a\u1706\uda5f\udf1b\udafe\ude22\ud848\udcd7", "\u6901\u1bb9\u8b89\u169b\u47e7\u4528\u8e63\u2c92", "\ud93a\udc80\ud947\udda7\udb8e\ude3b\udbe9\udfb2",
        0, 93108, -946079374, 639573041915289167L, 36775L, true, false, (char) 27432, (char) 58735,
        Double.longBitsToDouble(0x3fd91efe288bdba2L), Double.longBitsToDouble(0x3feb122d5a426d0bL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\ud941\udcca\uda0c\udcb8\u16aa\000\u94d6\ud81e\udc0e", "\u6901", "\ud920\udde3\uda4a\ude37\ud9aa\udee5\ud80b\udf76\ud8d8\udcad\ud84a\udcc4\udb40\udc36j\ud947\udda7\u9be8\000\uda0d\udd19\udb9c\udeac\ud893\uddf0\udb9a\udcd0",
        31, 3065, 100663296, -3415322485623252338L, -100000L, false, false, (char) 7437, (char) 53069,
        Double.longBitsToDouble(0x3fd6f6d62d73bc28L), Double.longBitsToDouble(0x3fd6a0623d4e5d82L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 8, 4, "\ud941\udd46\ud905\udf6a\u1706\udbcc\udd0c\uda11\uded4\ud9b0\udd7e", "\u6901\u1bb9\u8b89\u169b\u47e7\u4528\u7e52\u6edb", "\uda97\udc1a\ud947\udda7\udb8e\ude3b\udbe9\udfb2\uda0d\udd90\udb9c\udeac\ud893\uddf0\udb9a\udcd0\ud99b\ude80",
        5, 96279, -788627893, 7135279119044084331L, 1963L, false, false, (char) 61513, (char) 13100,
        Double.longBitsToDouble(0x3fdc73661c48e80eL), Double.longBitsToDouble(0x3feb9f40962414d3L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 8, 4, "\ud941\udcca\ud8ee\ude6a\u1706\uda5f\udf1b\udafe\ude22\ud848\udcd7", "\u6901\u1bb9\u8b89\u169b\u47e7\u4528\u8e63\u2c92", "\uda97\udc1a\ud947\udda7\udb8e\ude3b\udbe9\udfb2",
        0, 69236, -946151101, 639573041915289167L, 36775L, true, false, (char) 27432, (char) 58735,
        Double.longBitsToDouble(0x3fd91efe288bdba2L), Double.longBitsToDouble(0x3feb122d5a426d0bL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\012",
        Z.run(T, 1, 11, 11, 4, "\ud941\udcca\ud8ee\ude6a\u1706\uda5f\udf1b\udafe\ude22\ud848\udcd7", "\u6901\u1bb9\u8b89\u169b\u47e7\u4528\u8e63\u2c92", "\uda97\udc1a\ud947\udda7\udb8e\ude3b\udbe9\udfb2",
        7, 8090, 1973084483, 639572809987055183L, 1447L, false, false, (char) 27432, (char) 58735,
        Double.longBitsToDouble(0x3fd91efe288bdba2L), Double.longBitsToDouble(0x3feb122d5a426d0bL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 8, 4, "\ud941\udcca\udbda\uddc0\udb34\udc11\ud973\udd54\udafe\udd90\ud848\udcd7", "\u6901\u1bb9\u8b89\u169b\u47e7\u4528\u8e63\u2c92", "\uda97\udc1a\ud947\udda7\udb8e\ude3b\udbe9\udfb2",
        26, 69280, -946151101, -8675789635332150264L, 25330L, true, false, (char) 27454, (char) 58735,
        Double.longBitsToDouble(0x3fd91efe288bdba2L), Double.longBitsToDouble(0x3feb122d5a426d0bL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 6, "\ud941\udd12\ud863\udf0f\udb27\ude19\udb9c\udfbb\uda79\udd0d\ud848\udcaa\ud909\udc02\udbb0\udc0c\uda8d\udf17\udb54\udecb\ucf13\ud950\uddf6\uda4a\ude37", "\u2d33\uc6dc\u88a6\ud311", "\udbe9\udfb2\uda8b\udcc7\udb9c\udeac\uda47\udc80\udbbd\udf6a\ud99b\ude80\ud85e\ude2d\ud854\udcee\udb34\udf8a\udb8d\udd1b\udb7a\udd77\ud8b6\udfc8",
        -3, 78578, 1833329218, 1031539361340304155L, 24316L, true, true, (char) 12647, (char) 43626,
        Double.longBitsToDouble(0x3fa5263d39db7d80L), Double.longBitsToDouble(0x3f8e233d0b98e740L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 6, 2, "\ud941\udcca\ud8ee\ude6a\u1706\uda5f\udf1b\udafe\ude22\ud848\udcd7", "\u6901\u1bb9\u7175\ud6ae\u47e7\u4528\u1664\u013e", "\ud8b1\udca6\ud947\udde4\udb8e\ude3b\udbe9\udfb2\uda0d\udd90\ud903\ude01\uda8b\udeef\udbbd\udf6a\ud99b\ude80",
        5, 96279, -795191733, 7135279119044084331L, -51941L, false, true, (char) 53069, (char) 592,
        Double.longBitsToDouble(0x3fdd5ccde3632eccL), Double.longBitsToDouble(0x3fdd4c2e7adb8bd0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=new com.google.javascript.jscomp.Normalize:@?\012",
        Z.run(T, 2, 11, 11, 2, "\ud9f0\ude99\ud9e8\ude70\u1706\udb93\udd16\ud8a5\udca1\ud970\udc3a", "\u6901\u5df6\ub447", "\ud8e4\udc95\ud80b\udfe1\ud8d8\udcad\uda30\ude5b\udbac\udef9\ud8a1\udc41\ud96a\udea7",
        2, 89822, 1596831381, -5181727992611600493L, 75130L, true, true, (char) 47018, (char) 62813,
        Double.longBitsToDouble(0x3fe9f82aa26b6305L), Double.longBitsToDouble(0x3fe2842710cb59f6L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 8, "\ud941\udcca\udb3a\udf21\u1706\uda5f\udf1b\udafe\ude20\ud848\udcd7", "\u0c11\u1bb9\u8b89\u169b\u8eea\u44e5\u8e63\u2c92", "\ud93a\udc80\ud947\udda7\udb8e\ude3b\udbe9\udfb2\uda0d\udd90\ud8e2\uddef\ud923\udc83\u93ea\ud86c\udea8\ud85e\udd7b\ud817\udeaf\udbbe\udf7f\udb94\udc63\udb7a\udd77\udaa3\udc7e",
        35, 49522, 1377232343, -5270816335723708686L, -88330L, false, false, (char) 48189, (char) 53698,
        Double.longBitsToDouble(0x3fedadb040a5243bL), Double.longBitsToDouble(0x3fc5fde609418bccL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 11, 7, 11, "\ud941\udcca\ud8ee\ude6a\u1706\uda5f\udf1b\udafe\ude22\ud8c4\uddd0", "\u7652\u1bb9\u8b89\u169b\u47e7\u4528\u8e63\u2c92", "\ud951\udf7a\ud947\udda7\udb8e\ude3b\udbe9\udfb2\ud8e0\udc19\ud9de\udd05\ud8c2\uddfd",
        30, 65807, 654053171, 451791831023900235L, 64459L, true, true, (char) 12823, (char) 7437,
        Double.longBitsToDouble(0x3fe2136858e3d229L), Double.longBitsToDouble(0x3fe02bbb2ed67106L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 7, 4, "\ud941\udd46\ud905\udf6a\u1706\udbcc\udd0c\uda11\uded4\ud9b0\udd7e", "\u6901\u1bb9\u8b89\u169b\u47e7\u4528\u7e52\u6edb", "\uda97\udc1a\ud947\udda7\udb8e\ude3b\udbf6\udc04\udaf3\udd7f\ud85d\udc1d\ud910\udff5\ud8b7\udda2\ud99b\udc3b",
        5, 96279, -788627893, 7135279119044084331L, 1963L, false, false, (char) 61513, (char) 31788,
        Double.longBitsToDouble(0x3fdc7614fc48e80eL), Double.longBitsToDouble(0x3feb9f40962414d3L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\012",
        Z.run(T, 1, 11, 8, 4, "\ud941\udcca\ud8ee\ude6a\u1706\uda5f\udf1b\udafe\ude22\ud848\udcd7", "\u6901\u1bb9\u8b89\u169b\u47e7\u4528\u8e63\u2c92", "\uda97\udc1a\ud947\udda7\udb8e\ude3b\udbe9\udfb2",
        0, 36932, -946151101, 639573040556334671L, 36775L, true, false, (char) 27432, (char) 58735,
        Double.longBitsToDouble(0x3fd91efe2249726aL), Double.longBitsToDouble(0x3fef4154e6426d0bL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 8, 8, "\udac4\udc67\ud9f4\udfbf", "\u2e88\u09e5\u78b0\ua3d6\ua16a\u43d3\ub95f\u5f74", "\ud9dc\udf69\ud8d8\udcad\udac6\udcc4\ud97f\udd01\udad1\udf27\ud947\udda7\ud9b4\ude8d\uda6d\udf82\ud894\udcb8\udb9c\udeac\ud893\uddf0\udb9a\udcd0\ud99b\ude80\ud85e\ude2d\ud817\udeaf\udbbe\udf7f\udb94\udc63\udb7a\udd77\udaa3\udc7e\ud80a\udc60\ud867\udf2e\udb35\udfae\ud9c0\udefa\udaa3\udc18\ud96a\udd99\ud8f2\ude8f\ud9bd\udda3\uda93\udded\udbb0\udf32\ud82b\ude7d\ud8c3\uddb7\ud954\uddaf",
        48, 86050, -705243527, -515152136327450656L, 27429L, false, true, (char) 10386, (char) 31768,
        Double.longBitsToDouble(0x3feec5b34e6fdb86L), Double.longBitsToDouble(0x3fb434308feaa1d8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 8, "\ud941\udcca\udb3a\udf21\u1706\uda5f\udf1b\udafe\ude20\ud848\udcd7", "\u0c11\u1bb9\u8b89\u169b\u8eea\u44e5\u8e63\u30a0", "\ud93a\udc80\ud947\udda7\udb8e\ude3b\udbe9\udfb2\uda0d\udd90\ud8e2\uddef\ud805\ude35\u93ea\ud86c\udea8\ud85e\udd7b\ud817\udeaf\udbbe\udf7f\udb94\udc63\udb7a\udd77\udaa3\udc7e",
        35, -1000, 1377232128, -5270816335723708686L, -88330L, false, false, (char) 48189, (char) 53698,
        Double.longBitsToDouble(0x3fedadb040a5243bL), Double.longBitsToDouble(0x3ea8250620000000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.Normalize|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Normalize:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.Normalize|addToFront|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Normalize:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.Normalize|doStatementNormalizations|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Normalize:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.Normalize|extractForInitializer|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Normalize:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.Normalize|moveNamedFunctions|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Normalize:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.Normalize|normalizeLabels|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Normalize:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.Normalize|removeDuplicateDeclarations|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Normalize:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.Normalize|reportCodeChange|java.lang.String|new:com.google.javascript.jscomp.Normalize:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.Normalize|shouldTraverse|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Normalize:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.Normalize|splitVarDeclarations|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Normalize:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.Normalize|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Normalize:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "C|com.google.javascript.jscomp.Normalize|<init>|com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.Normalize|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Normalize:com.google.javascript.jscomp.AbstractCompiler,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
