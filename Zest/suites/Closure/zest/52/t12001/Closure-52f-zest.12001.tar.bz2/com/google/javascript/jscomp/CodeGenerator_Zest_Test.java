package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class CodeGenerator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 8, 1, "\uda91\udc92\ud801\udd48\udb59\udd19\udac4\ude31\udb0c\udf15\ud8e4\udff0\ud9e6\udecb\uda4d\ude27\udb59\udd86", "\u564c\u4542\u7410\u0e95\ud3e3\u7b0a\u2393\u997b\u5ef8", "\ud988\uded1\ud846\ude97\uda71\udfb9\ud9cb\udc42\ud8f5\ude73\ud991\udfed\ud922\udc90\u48ed\ud94e\udd34\ud96d\udec0\uda88\udcdd\ud870\udf07\ud9ba\udfaf\udac2\udf72\udaed\udd7d\udb77\udc9c",
        1, 38447, -1265257712, 4084824999977952741L, -26063L, true, true, (char) 1514, (char) 12917,
        Double.longBitsToDouble(0x3feca9c86cc5b455L), Double.longBitsToDouble(0x3febf127334c591bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 5, 12, "\uda91\udc92\ud801\udd48", "\u6ca1\ua43e", "\udb59\udd86\ud95c\udfc4\ud9f9\udd60",
        19, 17610, -247526003, 8929173199406916961L, 43113L, true, true, (char) 30441, (char) 3386,
        Double.longBitsToDouble(0x3fef5b59f4bfa285L), Double.longBitsToDouble(0x3febbb38426d1a09L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 1, 14, 13, 11, "\uda91\udc92\ud801\udd48\ud843\udc74\udab7\udd7b\udb0c\udf15\udb43\udcbf\ud9e6\udecb\uda4d\ude27\udb59\udd86", "\u11c0\u2542\u7410\u882c\u2813\u656b\u7f6d\u125f\uc1de", "\ub945\udafb\udfcb\udb16\udfda\udbe2\udeed\ud98a\udd5d\u76a4\ud958\ude64\ud91b\udfad\ud94e\udd74\ud96d\udec0\ud81c\udf08\udb4c\udffb\ud890\udc93\ud82c\udf27\udaed\ude5d\udaab\udfb6",
        9, 20608, -2100917378, -8552749233356323090L, -77209L, false, true, (char) 14826, (char) 6801,
        Double.longBitsToDouble(0x3fb74c58cfafb118L), Double.longBitsToDouble(0x3fea180ceb6b381bL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 8, 1, "\uda91\udc92", "\u986a<\u5066\u680f\u6d9b\u0b12\u4cba\ua8cc\u564c\u4542\u7410\u0e95\u042a\u7b0a\u2393\u997b\u5ef8\u289b\u7ecf", "\uda71\udf86\ud9cb\udc42\ud8f5\ude73\uda44\udcf6\ud871\ude39\u7684\udaaf\udf19\u8df5",
        6, 78882, -1132675158, 1617762174451689501L, 67580L, true, true, (char) 41694, (char) 60231,
        Double.longBitsToDouble(0x3fde538b0611eaa4L), Double.longBitsToDouble(0x3fd8cfcb2e379b02L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 1, 5, 8, 1, "\uda91\udc92\ud801\udd48\uda2b\ude86\udac4\ude31\ud8d5\uddf8\u9773\ud9c5\udce6\uda4d\uded8\udb59\udd86", "\u6dd0\u4542\u7410\u0e95\ud3e3\u822c\u2403\u85ed\u060e", "\ud988\udef0\ud846\ude97\uda71\udfb9\ud9cb\udc42\ud8f5\ude73\ud9eb\udef6\ud8af\udf30\u48ed\ud94e\udd34\ud999\udeb5\udb16\udd05\ud870\udf07\udb43\uded2\ud893\udd4e\uda59\udc10\ud840\udd3e",
        39, 85169, -1265299283, 4084824999977952741L, -26063L, false, true, (char) 23885, (char) 44363,
        Double.longBitsToDouble(0x3fe0d74fa4c5b4c2L), Double.longBitsToDouble(0x3febf12733397ee4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 12, 1, "\uda91\udc6a\ud801\udd48\ud818\ude10\ud843\udf70", "\ube3f", "\ud95c\udfc4\ud9f9\udd60",
        2, 17610, -247526003, 8929173197410972001L, 43314L, true, true, (char) 30441, (char) 3386,
        Double.longBitsToDouble(0x3fef5b59f4bfa285L), Double.longBitsToDouble(0x3febbb3842393509L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 8, 1, "\uda91\udc92\ud801\udd48\udb59\udd19\udac4\ude31\udb0c\udf15\ud8e4\udff0\uda5a\ude25\uda4d\ude27\uda93\udf62", "\u564c\u4542\u7410", "\ud960\udd86\udada\ude61\ud904\udd57\ud9c0\udd73\uda5e\ude7c\udaf6\udece\ud988\uded1\ud846\ude97\uda71\udfb9\ud9cb\udc42\uda91\udee0\ud989\udd62\ud922\udc90\u48ed\ud94e\udd34\ud96d\udec0\uda88\udcdd\ud870\udf07\ud9ba\udfaf\udac2\udf72\udbb7\udd82\udb77\udc9c\udad4\ude40\udad4\udc12\ud8c9\ude9e\udb25\udfef\udaa7\uded1\ud9d1\udfbc\ud895\uddd7\ud88c\udcf2\udbd3\udf0d\ud8a3\udd40\ud9ee\udd1b\uda9f\ude8e\ud938\udcbe\ud9a0\udeb0\udbe9\udceb",
        55, 23636, -2139737364, 6982312492759489294L, 18406L, true, true, (char) 413, (char) 1245,
        Double.longBitsToDouble(0x3fdf0f7098723606L), Double.longBitsToDouble(0x3fe3adf7aaf40918L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 8, 1, "\uda91\udc92\ud801\udd48\udb6c\udc9d\udac4\ude31\udb0c\udf15\ud8e4\udff0\ud9e6\udecb\uda4d\ude27\udb59\udd86", "\u564c\u4542\u7410\u1346\u9cd0\u7b0a\u2393\u698d\u5ef8", "\ud988\uded1\ud846\ude97\uda71\udfb9\ud9cb\udc42\ud8f5\ude73\ud991\udfed\ud922\udc90\u48ed\uda51\uddf6\ud94e\ude43\uda88\udcdd\ud870\udf07\ud9ba\udfaf\udac2\udf72\udaed\udd7d\udb77\udc9c",
        1, 38447, -1265257712, 4084824999977952741L, -26063L, true, true, (char) 1514, (char) 12917,
        Double.longBitsToDouble(0x3feca9c86c61001cL), Double.longBitsToDouble(0x3febf127334c591bL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 10, 14, "\uda91\udc92\ud801\udd48\udb59\udd19\udac4\ude31\udb0c\udf15\ud8e4\udff0\ud9e6\udecb\uda4d\ude27\udb59\udd86", "\u564c\u8e2c\u86e7\u5810\ud3e3\u7b0a\u2393\u997b\u5ef8", "\ud988\uded1\ud846\ude97\udbd4\uddab\ud9cb\udcc3\ud8f5\ude73\ud991\udfed\ud922\udc90\u48ed\ud94e\udd34\ud96d\udec0\uda88\udcdd\ud870\udf07\ud9ba\udfaf\udac2\udf72\udb00\udf3d\udb77\udc9c",
        1, 38447, -1265257712, 4084824999977952741L, -26063L, true, true, (char) 1514, (char) 12917,
        Double.longBitsToDouble(0x3feca9c86cc5b455L), Double.longBitsToDouble(0x3febf127334c591bL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 8, 1, "\uda91\udc1a\ud801\udd48\udb59\udd19\udac4\ude31\udb0c\udf15\ud8e4\udff0\ud9e6\udecb\uda4d\ude27\udb59\udd86", "\u25d9\ua57b\u7410\u0e95\ud3e3\u7b0a\ub050\u271d\u5ef8", "\ud988\uded1\ud846\ude97\uda71\udfb9\ud9cb\udc42\ud8f5\ude73\ud9c7\ude68\ud922\udc90\u48ed\uda5b\udc9b\ud966\udf73\uda88\udcf6\ud870\udf07\ud9ba\udfaf\udac2\udf72\uda33\udf28\udb77\udc9c",
        51, 38677, -1265257712, 4084824999977952741L, -26063L, true, false, (char) 64488, (char) 12932,
        Double.longBitsToDouble(0x3feca9c86cc5b455L), Double.longBitsToDouble(0x3febf127334c591bL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 8, 1, "\uda91\udc92\ud801\udd48\udaf1\ude65\ud8d0\udeb5\udadd\udca5\ud8e4\udf7d\ud9e6\udecb\uda4d\ude27\udb59\udd86", "\u564c\u4542\u7410\u0e95\ud3e3\u7b0a\u2393\u997b\u5ef8", "\ud988\uded1\ud87c\udc97\uda71\udfb9\ud9cb\udc42\ud8f5\ude73\ud991\udfed\ud922\udc90\u48ed\udbde\uddfd\ud978\udf64\uda88\udcdd\ud870\udf07\ud9ba\udfaf\udac2\udf72\udaed\udd7d\udb77\udc9c",
        1, 38447, -1265257712, 4085042883668878821L, -26063L, true, true, (char) 1514, (char) 12917,
        Double.longBitsToDouble(0x3feca9c86cc5b455L), Double.longBitsToDouble(0x3febf127334c591bL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 8, 0, "", "\ubfd3", "\ud8e4\udff0\000\uda4d\uddfe\udb59\udd86",
        12, 64464, -391245328, 300263783345884557L, 76481L, false, false, (char) 31818, (char) 6947,
        Double.longBitsToDouble(0x3fdd1b9183013772L), Double.longBitsToDouble(0x3f3acfa5fd142800L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 8, 1, "\000\u2925\udb59\udd19\udac4\ude31\ud009\000\ud9e6\udecb\uda4d\ude27\ud87a\ude81", "\u42be", "",
        34, 18264, -1407451016, -7089281342424219515L, 60128L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e45017578000000L), Double.longBitsToDouble(0x3fc9dde640d250b0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 1, 4, 6, 1, "\uda91\udc92\ud801\udd48", "\u6ca1\ua43e", "\udb59\udd86\ud95c\udfc4\ud9f9\udd60",
        2, 17610, -247526003, 8934038536363880801L, -29158L, true, true, (char) 30441, (char) 62521,
        Double.longBitsToDouble(0x3fef5b59f4bfa285L), Double.longBitsToDouble(0x3febbb3846803509L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 1, 13, 8, 1, "\uda91\udc92\ud801\udd48\udb59\udd19\udab5\udc31\udb0c\udf15\ud8e4\udff0\ud9e6\udecb\uda4d\ude27\udb59\udd86", "\u564c\u4542\u7410\u7fc3\u9821\u2662\u2393\u997b\u1791", "\u4ef9\uda11\ude9d\uda6a\udcb3\ud9cb\udc42\ud8f5\ude73\ud991\udfed\ud922\udc90\u48ed\ud804\udf90\ud96d\udec0\uda88\udcdd\ud870\udf07\ud9ba\udf6d\uda8b\uddf7\ud9b7\udea0\udb77\udc27",
        1, 98679, 1872891749, 8535591702064408037L, 8753L, true, true, (char) 1992, (char) 35390,
        Double.longBitsToDouble(0x3feca9ce54c5b455L), Double.longBitsToDouble(0x3febf127334c591bL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 8, 1, "\u1ff8", "\ub869\u825b\ua43e\u83e3\uaa0d\u76fe\u5bb5\u3a12\u1320\ubf13\u05e6\u0e95\u15fd\u0a14\u773b\u6334\u2109\u72a8\ubcb0", "\ud8a2\udf38\ud87c\udd90\uda56\udc7b\ud9e4\ude8e\udbcb\udfb3\ud9df\ude2a\udaa9\udccd\ud807\udcf4\uda92\ude86\ud870\udf07\udad5\udd6a\uda0a\udc0c\ud8fb\udcdb\ud814\udc48\udabc\ude1d\udb10\udf31\ud8e3\udeac\ud9a6\udd0b\ud9e7\ude10\ud9ac\udd8b\udb62\udce0\udad2\udf07\uda36\udcc2\ud9b6\udebf\ud8f3\udc8a\uda9f\udef1\ud938\udcbe\ud8a6\uddb3\ud8e9\udf79\udbe2\udf61\udb42\ude37\ud969\udeb1\uda6c\udd6e\udb7c\ude76\ud9fe\udd3a\ub0f5\uda43\udfa7\ud85c\udfea\udaeb\udd41\ud8c4\udc15\udbe6\ude41\udba7\udf4a\uda95\udc02\udaea\udd7c\ud8f4\udd93\ud927\udc3a\ud97b\udca2\ud845\uddc3\ud906\udc29\uda39\udfc8\uda9e\udca2\ud9c2\ude6a\ud920\udd28\ud86c\udfe5\ud860\udeff\udb77\udceb\uda5a\udf41\uda3f\ude80\udb52\ude34\udb73\udcec",
        1, 40685, 1634143021, 7549364508140724815L, 21824L, true, true, (char) 55167, (char) 61950,
        Double.longBitsToDouble(0x3feede37e6586c58L), Double.longBitsToDouble(0x3fee6be827f97010L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 1, 13, 8, 6, "\udb2a\udc3d\ubd48\udb59\udd19\udac4\ude31\udb0c\udf15\udbb8\udc79\ud883\udc64\udbce\udc80\udaf3\udce0", "\u564c\u4542\u9f7e\u0e76\ud3e3\u1121\u2393\u997b\u5ef8", "\udbdb\udeec",
        -2, 76669, -269544128, -7769645255012748492L, -1913L, true, true, (char) 45701, (char) 856,
        Double.longBitsToDouble(0x3fe1908687aa5201L), Double.longBitsToDouble(0x3fe105e3e71d1673L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 5, 12, "\uda91\udc92\ud801\udd48", "\u6ca1\ua43e\ube3f\u6d9b\u0b12\u4c09\u8322\u5a2c\u4542\u7410\u0e95\u3ce4\u1aab\u245c\u997b\u5ef8\u289b\u9d20\u86dc\u668e\u3037\u1a31\u4f95", "\ud919\ude40\ud9e7\udd6a\ud89e\ude8b\ud9f1\ude9a\ud9b5\udc58\udbb4\udc6e\ud815\uddc0\ud961\ude2e\udac3\udf00\uda3c\ude2c\ud9e7\udea0\uda4e\udef4\u659b\ud83e\udeed\uda26\uddce\udb9b\udc2e\udb65\udf12\ud85a\uddd4\udbed\udfe7\udb4e\udf46\uda37\uddcc\udb31\ude7e",
        54, 81472, -1806685829, -5930046621117362437L, 84805L, false, false, (char) 20550, (char) 47504,
        Double.longBitsToDouble(0x3fd4c8889d8dcfeeL), Double.longBitsToDouble(0x3fe89547d49a33d6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 11, 1, "\ud9af\udcbe", "\ucc93\ub1ca\ub425\ube0a\u173c\u3bc1\u700f\u4a49", "\ud987\udc94\ud9d0\udf04",
        5, 32391, 1121257207, -729812875433159873L, 15593L, false, false, (char) 43404, (char) 57609,
        Double.longBitsToDouble(0x3fee495c8dc90625L), Double.longBitsToDouble(0x3fe9ffb94d6edb5fL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 5, 12, "\uda91\udc92\ud801\udd48", "\u6ca1\ua43e", "\udb59\udd86\ud917\udea1\ud9f9\udd60\ud898\ude70\udb6e\udc90\ud893\udf15\ud955\udf27\udb1a\ude20\ud827\udc3f\ud85e\udf4b\ud904\udd57\ud89d\udfe8\udbc1\udfd1",
        54, 96519, 436801399, 522622848244298903L, 99310L, true, true, (char) 4203, (char) 34761,
        Double.longBitsToDouble(0x3fd1fa118d345416L), Double.longBitsToDouble(0x3f8ff8aa0d9a6940L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 5, 12, "\uda91\udc92\ud801\udd48\udb59\udd19\udac4\ude31\udb0c\udf15", "\u6d9b\u0b12\u4807\u8322", "\ud987\udcae\ud9d0\udf04",
        15, -761, -1650601737, -5109195768750031407L, 15691L, true, false, (char) 30335, (char) 54389,
        Double.longBitsToDouble(0x3fe7a719feea6bafL), Double.longBitsToDouble(0x3fc67a7fe9e249a0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 5, 11, "\ue3a5\ud801\uddf2", "\ubf7c\ub1b1", "\udb01\udec4\uda01\udefa\ud91c\udf32",
        57, 17610, -568934771, 8929217179872028001L, 43113L, true, true, (char) 30426, (char) 44089,
        Double.longBitsToDouble(0x3fef59180cbfa285L), Double.longBitsToDouble(0x3fd8449644da344cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 13, 5, 12, "\udad7\udef2\udad5\udcd3", "\u6ca1", "\uda4d\ude27\udbe7\udd83\ud95c\udfc4\u871a\ud9b8\udd06\ud87d\udccd\ud8ff\uddb2\ud9d0\udeda\uda43\udeb6\ud826\udfda\udada\udf2a\ud904\udd57\ud95b\udcdf\udbc1\udfd1\udaeb\ude68\ud988\uded1\udb16\udcfc\ud99b\udd2f",
        33, 48915, -69866165, -873126259968892234L, 72833L, false, true, (char) 56465, (char) 41779,
        Double.longBitsToDouble(0x3fa72554a10c5830L), Double.longBitsToDouble(0x3fd47c3600269c46L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 5, 12, "\uda90\ude92\ud801\udd48", "\uc6dc\u73de\u48b6\u842d\u1528\u89fb\u8322\u1ac4\u6c92\u4a3f\u9e48\u345c\uae83\u03d0\u9cf2\u05c9\u26f3\u3ef9\u10c1\u4d36\u241c\u096f\u1e98", "\uda0a\udf30\u6a80\uda85\udf65\udba7\udeb0\ud811\ude6e\u13c4\udb8a\udfc3",
        15, 37369, -754351254, -3444285740984564880L, 59711L, false, false, (char) 4075, (char) 31496,
        Double.longBitsToDouble(0x3fe02b34e5d89321L), Double.longBitsToDouble(0x3fea0e95937f878aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 14, 13, 4, "\uda91\udc92\ud801\udd48\udacf\udc59\udb15\ude06\ud979\udc9b\ud88a\udd0e\ud823\udfaf\uda4d\ude0b\ud880\udc79", "\u35c0\u2542\u7410\u882c\u2813\u656b\u7f6d\u125f\uc1de\u2854\u9d20\u5446\ub6a8\u4ef1\u6f79\u82e2\u155f\u2bdf\u9244\u32c0", "\udb3c\udd59\ud890\udc93\ud82c\udf27\udaed\ude5d\udaab\udfb6\udb08\udeb9\ud93e\udd2d\udb1f\udc1c\udbde\udec0\udaf1\udebd\ud976\ude20\ud976\udcfe\udb33\udcf2\udb61\udfaf\ud838\udff0\ud8a1\udfc8\ud96a\ude0d\ud9d3\ude91\udafc\ude28\uc914",
        50, 8537, -814628471, 229544295229940668L, -81713L, true, false, (char) 46784, (char) 35863,
        Double.longBitsToDouble(0x3fcbfaada305e864L), Double.longBitsToDouble(0x3fda872250eff3d2L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 14, 13, 11, "\uda91\udc92\ud801\udd48\ud843\udc74\udab7\udd7b\udb0c\udf15\udb43\udcbf\ud9e6\udecb\uda4d\ude27\udb59\udd86", "\u11c0\u2542\u7410\u882c\u7fc7\u656b\u7f6d\u9093\u85eb", "\ud871\uddc7\udafb\udfb3\ud8ae\udd33\udbe2\udeed\ud96d\udd6e\udbf7\uded9\ud958\ude64\ud91b\udfad\ud94e\udd74\ud96d\udec0\ud81c\udf08\udb4c\udffb\ud890\udc93\ud82c\udf27\udaed\ude5d\udaab\udfb6",
        9, 20608, -2100917378, -8552749231849150738L, -90659L, false, true, (char) 14826, (char) 6801,
        Double.longBitsToDouble(0x3fb74c58cfafb118L), Double.longBitsToDouble(0x3fea180ceb6b381bL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 9, 11, "\uda91\udc92\ud80b\udd4d\ud843\udc74\udbbd\udf11\udb0c\udf15\udb43\udcbf\ud9e6\udecb\ufb8a\uda05\udec4", "\u6222\u64f4\u73c5\u882c\u2813\u656b\u7f6d\u125f\uc250\u2854", "\udafb\udfcb\udb16\udfda",
        47, 34790, -14426447, 4608402066193608886L, 98156L, true, true, (char) 13055, (char) 31656,
        Double.longBitsToDouble(0x3feffada08d79378L), Double.longBitsToDouble(0x3fe14430b624ef62L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 10, 7, "\uda91\udc92", "\u986a\u57eb\u4fee\u680f\u8c44\u0b12\u6178\u335d\u55de\u4542\u88fa\u0ec3\u042a\u7b0a\u2393\u997b\u5ef8\u289b\u7ecf", "\uda71\udf90\ud9cb\udc42\ud8f5\ude73\uda44\udcf6\ud871\ude39\udb1c\ude43\ud9f5\udc1c\u8df5",
        3, 78882, -1132675158, 1617762174451689501L, 67580L, true, true, (char) 9006, (char) 61976,
        Double.longBitsToDouble(0x3feb609a6b083849L), Double.longBitsToDouble(0x3fe53e8c871bcd81L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 8, 9, "\uda91\udc92\ud801\udd48\uda2b\ude86\udaeb\udcc5\ud8d5\ude36\u9773\ud80c\udf2a\ud964\udda0", "\u8322\u6dd0\u4542\u82e8\u77fc\ud3e3\u53c8\u9152\u9562\u060e\u289b", "\ud846\ude97\uda71\udfb9\ud9cb\udc42\ud8f5\ude73\ud9eb\udef6\ud8af\udf30",
        49, 18883, 1518448992, 5165004337264529138L, 67800L, true, true, (char) 59330, (char) 9281,
        Double.longBitsToDouble(0x3fd6189f715af4f0L), Double.longBitsToDouble(0x3fe92da4ade59e76L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 11, 12, "\uda91\udc92\ud9be\udee6\udb59\udc33\udab6\udfa8\ud8d5\uddf8\u9773\ud9c5\udce6\uda4d\uded8\udb59\udd86", "\u6dd0\u4542\u7410\u0e95\ud3e3\u822c\u2403\u20ed\u599c", "\ud988\udef0\ud846\ude97\uda71\udfb9\ud9cb\udc42\ud8f5\ude73\ud9eb\udef6\ud8af\udf30\u48ed\ud94e\udd34\ud999\udeb5\udb16\udd05\ud870\udf07\udb43\uded2\ud893\udd4e\uda59\udc10\uda53\udf3a",
        -2, 63751, -1265299414, 4084824999977952741L, -26063L, false, true, (char) 23885, (char) 44363,
        Double.longBitsToDouble(0x3fe0d74fa4c5b4c2L), Double.longBitsToDouble(0x3febf12733397ee4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 1, "\uda91\udc92\ud801\udd48\uda2b\ude86\udac4\ude31\ud929\udf62\ud9c7\udf37\ud9bb\udd09\uda4d\uded8\udb59\udd86", "\u6dd0\u4542\u7410\u0e95\ud3e3\u822c\u92f3\uc98b\u060e", "\ud988\udef0\ud846\ude97\uda1c\udc34\uda79\ude20\ud8d4\ude11\ud9eb\udef6\ud9e8\udf74\ud866\udf0a\ud94e\udd34\ud999\udeb5\udb16\udd05\ud870\udf07\udb43\uded2\ud893\udd4e\uda59\udc10\ud8b8\udec9",
        57, 85169, -1265299283, 4084824999977952741L, -26063L, false, true, (char) 23885, (char) 44363,
        Double.longBitsToDouble(0x3fe0d74fa4c5b4c2L), Double.longBitsToDouble(0x3febf12733397ee4L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 4, 1, "\uda91\udc6a\ud801\udd48\u5069\ud847\udc77\udb8e\udfec\ud911\udff0\ud9e6\udecb\uda4d\ude27\udb59\udd86\ud95c\udfc4\ud9f9\udd60\ue349\udb6e\udce0\ud987\udcae\ud9d0\udf04\udbe5\udf1d\ud94d\udef0\uda3f\udc53", "\uaacf\u5d34\u4226\u642f", "\ud927\udf98",
        40, 22295, 199251803, -1035743554514028413L, -61063L, false, false, (char) 53826, (char) 60211,
        Double.longBitsToDouble(0x3fbc0f1033a23868L), Double.longBitsToDouble(0x3fcdb0a5544657f4L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 8, 1, "\uda91\udc92\ud801\udd48\ud9c9\udfac\000\udad8\udf0c\uda58\udfea\ud9e6\udecb\uda4d\ude27\udb59\udd86", "\u564c\u4542\u7410\u1346\ub309\u7a92\u2393\u698d\u5ef8", "\ud988\uded1\ud846\ude97\uda71\udfb9\ud9cb\udc42\ud8f5\ude73\ud991\udfed\ud922\udc90\u48ed\uda51\uddf6\ud94e\ude43\uda88\udcdd\000\ud9ba\udfaf\udac2\udf72\udaed\udd60\udb77\udc9c",
        58, 77744, -1265257712, 4084824999977952741L, -26063L, true, true, (char) 1514, (char) 12917,
        Double.longBitsToDouble(0x3feca9c86c61001cL), Double.longBitsToDouble(0x3febf127304c591bL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 0, 1, "\000\u2925\udb6c\udc9d\udac4\ude31\udb0c\udf15\ud8e4\udff0\ud9e6\udecb\uda4d\ude27\udb59\udd86", "\u555c", "\udad0\udee5",
        44, 87568, -1650601938, -5104973644099371567L, 15691L, true, false, (char) 3840, (char) 61249,
        Double.longBitsToDouble(0x3fd405d5e99c0064L), Double.longBitsToDouble(0x3fe9a4a1611d502aL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 8, 1, "\ud90e\udd7b\ud801\udd48\udb6c\udc9d\udb2a\uddd3\ud9b3\udd7d\ud908\udf94\uda10\udf80\uda4d\udefb\udb59\udd86\ud95c\udfc4\ud9f9\udd60\ud834\udca4\udba7\uddda\ud987\udcae\udad0\udee5\ud8f6\udc51\ud9e9\udda3\udada\ude61\ud886\udd58\ud89d\udfe8\ud8aa\uddb0\uda68\udff9\ud988\uded1\ud846\ude97\uda71\udfb9\ud9cb\udc42\ud8f5\ude73\ud991\udfed\ud922\udc90\u48ed\udae3\udd5f\ud94e\ude2c\ud931\udcf4\ud9ea\udf51\udb25\ude88\udac2\ude56\udaed\uddef", "\u35d6", "\udb87\udd43\ud987\uddb9",
        9, 81675, -1852820821, 4111119038969288597L, 7861L, false, false, (char) 31011, (char) 40345,
        Double.longBitsToDouble(0x3fccbded700f8bc0L), Double.longBitsToDouble(0x3fcda833faeb69e8L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 8, 0, "", "\u3358", "\ud8e0\udc6f\ud9e6\udecb\uda4d\ude27\udb59\udd86",
        50, 27275, -391245328, 300263783345884557L, 43314L, true, true, (char) 39, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e31c9a848000000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 8, 1, "\uda91\udc92\ud801\udd48\udb6c\udc9d\udac4\ude31\udb0c\udf15\ud8e4\udff0\ud9e6\udecb\uda4d\ude27\udb59\udd86\ud95c\udfc4\ud9f9\udd60\ud886\udc90\udb6e\udc90\ud987\udcae\udad0\udee5\ud8f6\udc51\ud960\udd86\udada\ude61", "\u289b\u9d20\u86dc\u8652", "\ud8f5\ude73\ud991\udfed\ud922\udc90\u48ed",
        38, 94747, 282079200, 5909019792865279914L, 8573L, false, false, (char) 1384, (char) 30696,
        Double.longBitsToDouble(0x3fe8877e76b2b495L), Double.longBitsToDouble(0x3fde538b0611eaa4L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 8, 1, "\uda91\udc92\ud801\udd48\u00a3\000\000\ud8e0\udc6f8\uda4d\ude27\udb59\udd86", "\000\000\000\ubb26\uc1c6\u7b0a\u2393\u698d\u5e27", "\udbc6\uded0\ud846\ude97\uda71\udfb9\000\ud8f5\ude73\ud991\udfed\035\udbea\udef5\uda51\uddf6\ud94e\ude43\ud964\udcf1\ud82d\udcd5\ud9ba\udfaf\udac2\udf72\udb7b\udd79\udb77\udc9c",
        1, 38447, -1265257712, 4084824999977952741L, -26063L, false, true, (char) 1514, (char) 12917,
        Double.longBitsToDouble(0x3feca9c86c61001cL), Double.longBitsToDouble(0x3febf127334c591bL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 8, 0, "\000\000\000\uda8d\udea6\udb08\udf13\ud8e4\udff0\ud98a\udfbd\000\000", "\u445c\uc052\000\000\ub309\u52e9\ud02e", "\u0080\000\000\000",
        -5, 49240, -1809055744, 5776556141352640797L, -100000L, false, false, (char) 48783, (char) 51776,
        Double.longBitsToDouble(0x3fd64940320f0dc2L), Double.longBitsToDouble(0x3e165692a0000000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 1, "\uda91\udc92\ud801\udd48\udb59\udd19\udac4\ude31\udb0c\udf15\ud8e4\udff0\ud9e6\udecb\udb60\ude91\uda04\udf22", "\u564c\u8e2c\u86e7\u5810\ud3e3\u7b0a\u30cb\ua7a1\u5ef8\u1c1a\u912b\ua0f7\u907e\u6724\u49d6\u4d02\u4a37\u0ef4", "\ud96d\udec0\uda88\udcdd\ud870\udf07\ud9ba\udfaf\udab5\udfe9\udb00\udf3d\udb77\udc9c\udb02\uddc0\udac5\udf63\ud8c0\ude59",
        34, 7277, 766675720, -3638590941940881637L, 55396L, true, true, (char) 51482, (char) 63587,
        Double.longBitsToDouble(0x3fea62c8dc6fd363L), Double.longBitsToDouble(0x3fe769cdc746b2ddL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 0, 0, "\uda91\udc92\ud801\udd48\u8c1f\000\udb0c\udf0e\ud8e4\udff0\ud9e6\udecb\uda4d\ude27\udb59\udd86", "\u564c\u8e2c\u86e7\u5810\ud3e3\u7b0a\u2393\u997b\u261d", "\ud988\uded1\ud846\ude97\udbd4\uddab\ud9cb\udcc3\ud8f5\ude73\ud991\udfed\ud922\udc90\u48ed\ud94e\udd34\ud96d\udec0\uda88\udcdd\ud870\udf07\ud9ba\udfaf\udac2\udf72\udb00\udf3d\udb77\udc9c",
        1, 38447, -1265257712, 4084824999977952741L, -26063L, true, true, (char) 1514, (char) 12917,
        Double.longBitsToDouble(0x3feca9c86cc5b455L), Double.longBitsToDouble(0x3febf127334c591bL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 10, 14, "\uda91\udc92\000\000\uda8d\udea6\udb0c\udf15\ud8e4\udff0\ud9e6\udecb\uda4d\ude27\udb59\udd86", "\u564c\u8e2c\u86e7\u5810\ud3e3\u7b0a\u2393\u997b\ubdd1", "\ud988\uded1\ud846\ude97\udbd4\uddab\ud9cb\udcc3\u00ce\ud975\udcb9\ud922\udc90\u48ed\ud94e\udd34\ud96d\udec0\u2fe0\000\ud98b\udc05\udac2\udf72\udb00\udf3d\uda84\ude9c",
        1, 38447, -1265257712, 4084824999977952741L, -26063L, true, true, (char) 1514, (char) 12917,
        Double.longBitsToDouble(0x3feca9c86cc5b455L), Double.longBitsToDouble(0x3febf127334c591bL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 10, 14, "\000", "\u986a\u6ca1\ua43e\ube3f\u6d9b\u0b12\u4c09\u8322\u564c\u8e2c\u86e7\u5810\ud3e3\u7b0a\u2393\u997b\u5ef8\u289b\u9d20", "\udbd4\uddab\ud9cb\udcc3\ud8f5\ude73\ud991\udfed\ud922\udc90\u48ed\ud94e\udd34\ud96d\udec0\uda88\udcdd\ud870\udf07\ud9ba\udfaf\udac2\udf72\udb00\udf3d\udb77\udc9c",
        1, 38447, -1265257712, 4084824999977952741L, -26063L, true, true, (char) 1514, (char) 12917,
        Double.longBitsToDouble(0x3feca9c86cc5b455L), Double.longBitsToDouble(0x3febf127334c591bL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 10, 0, "\ub800\000\000\000\000\uda8c\udc05\000\000\000", "", "\ue235\ud9ad\udc80",
        53, 87568, -1650601938, -5109195768750031407L, 15691L, true, false, (char) 26376, (char) 47615,
        Double.longBitsToDouble(0x3fdc1f6a699dde64L), Double.longBitsToDouble(0x3fe9a4a160000000L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 10, 14, "\uda91\udc92\udab3\udd41\udb59\udd19\udac4\ude31\007\ud8e4\udff0\ud9e6\udecb\uda4d\ude27\udb59\udd86", "\000\u2fda\u86e7\u5810\u9b28\u7b0a\u2393\u997b\u5ef8", "\ud988\uded1",
        56, 6489, -281930303, -7769645255012748492L, 71511L, true, true, (char) 45701, (char) 860,
        Double.longBitsToDouble(0x3f10d0f540000000L), Double.longBitsToDouble(0x3fe105e3e5dd1673L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 14, 14, 1, "\uda91\udc1a\ud801\udd48\udb59\udd19\ud975\ude33\udb0c\udf15\ud8e4\udff0\u7947\uda4d\ude27\udb59\udd86", "\u25d9\ua57b\u7410\u0e95\ud3e3\u7b0a\ub050\ua5b6\uad00", "\ud988\uded1\ud846\ude97\uda71\udfb9\ud9cb\udc42\ud8f5\ude73\ud9c7\ude68\ud922\udc90\u48ed\uda5b\udc9b\ud967\udc02\uda88\udcf6\ud870\udf07\ud9ba\udfaf\udac2\udf72\uda33\udf28\udb77\udc9c",
        51, 38677, -1265257712, 4084824999977952741L, -26063L, true, false, (char) 64488, (char) 12932,
        Double.longBitsToDouble(0x3feca9c86cc5b455L), Double.longBitsToDouble(0x3febf127334c593cL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 15, 1, "\ud909\udcb5\ud802\ude8b\udb59\udd19\udac4\ude31\udb0c\udf15\ud8e4\udff0\ud9e6\udecb\uda4d\ude27\udb59\udd86", "\u25d9\ua57b\u7410\u0e95\ud3e3\u7b0a\ub050\u271d\u5ef8", "\ud988\uded1\ud846\ude97\uda71\udfb9\ud9cb\udc42\ud929\uddcd\ud9b5\udeae\ud922\udc90\u48ed\uda5b\udc9b\ud997\udcd1\uda58\udccd\ud870\udefb\ud9ba\udfaf\udac2\udf72\uda33\udf28\udb77\udc9c",
        51, 38677, -1265257712, 4084824999977952741L, -26063L, true, true, (char) 64407, (char) 12932,
        Double.longBitsToDouble(0x3feca9c86cc5b455L), Double.longBitsToDouble(0x3febf127334c591bL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 9, 9, "\ud881\udc12\ud801\udd48\udb96\udf18\ud9fd\udec8\udb0c\udf15\udbf7\ude3c\udad7\ude18\udad5\ude29\uda60\udfed", "\u25d9\ua57b\u4a05\uce8b\u461e\u4de2\u7ae3\u25b0\u0de3\u289b", "\ud84b\udfc5\uda71\udfb9\ud9cb\udc42\ud8f5\ude73\ud9c7\ude68\ud922\udc90\u48ed\udbfd\udd8c\u7387",
        5, 13562, 914145194, -8607631094905670244L, -52228L, true, true, (char) 41694, (char) 60231,
        Double.longBitsToDouble(0x3fde538b0611eaa4L), Double.longBitsToDouble(0x3fc345b652766c54L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 0, "i\000\udb36\udcfa\udac4\ude31\007\000\ud98a\udf85\uda4d\ude27\u0084", "\u14d9\ua57b\u7410\000\u2282\u7b0a\ub050\000\000", "\ud988\uded1w\uda71\udfb9\ud9cb\udc42\ud8f5\ude73\ud9c7\ude68\ud922\udc90\u48ed\uda5b\udc9b\000\000\000\000\udac2\udf52\uda33\udf28\udb77\udc9c",
        30, -1000, -1265257712, 4084824999977952741L, -26063L, true, false, (char) 64488, (char) 12932,
        Double.longBitsToDouble(0x3feca9c86cc5b455L), Double.longBitsToDouble(0x3febf127334c591bL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 15, 1, "\ud86d\udf1f\udb4e\udfd1\uda39\ude69\ud8d0\udeb5\uda2f\udcae\ud8e4\udf7d\udbde\ude88\u923d\ud869\udd01", "\u564c\u86f0\u4088\u0e95\ud3e3\u7b0a\u2393\u997b\u5ef8", "\ud988\uded1\ud87c\udc97\uda71\udfb9\ud9cb\udc42\ud8f5\ude73\ud991\udfed\ud922\udc90\u48ed\udbde\uddfd\ud978\udf64\uda88\udcdd\u0b76\ud810\udf18\ud976\udedc\udade\udd16\udb77\udc9c",
        1, 57931, -1265257712, 4085042883668878821L, -91599L, false, false, (char) 9918, (char) 7407,
        Double.longBitsToDouble(0x3feca9c86cc5b455L), Double.longBitsToDouble(0x3febf12735fc6e1bL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 12, 12, 1, "\uda91\udc92\ud801\udd48\udaf1\ude65\ud8d0\udeb5\udadd\udca5\ud8e4\udf7d\ud9e6\udecb\uda4d\ude27\udb59\udd86", "\ub677\ud4bf\u7410\u0e95\ud3e3\u7b0a\u2393\u997b\u6158", "\ud988\uded1\ud87c\udc97\uda71\udfb9\ud9de\udff7\ud8f5\ude73\ud991\udfed\ud922\udc90\u48ed\udbde\uddfd\ud978\udf64\uda88\udcdd\ud870\udf07\ud9ba\udfaf\udac2\udf72\udaed\udd7d\udb77\udc9c",
        1, 38447, -1265257712, 4085042883668878821L, -26063L, true, true, (char) 1514, (char) 34963,
        Double.longBitsToDouble(0x3feca9c86cc5b455L), Double.longBitsToDouble(0x3febf127334c591bL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 3, "\000\ud858\udd25\udb59\udd19\udac4\ude31", "\000", "\u7726\udba1\udf4f",
        2, 7010, 958691, -990901287950843390L, 43314L, true, true, (char) 30440, (char) 29497,
        Double.longBitsToDouble(0x3fd41edea10d1960L), Double.longBitsToDouble(0x3fd24cd0b47af11aL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 15, 11, "\000\u2925\udb59\udd19\udac4\ude31\ud009\000\ud8f0\udecf\u32ad\ud87a\ude78\000\ud8fa\uddcf\udbd2\udd4e\uad96", "\u69db", "\ue0db\udab5\udd55\ud831\udce6\udb49\ude92\udbd2\udfe8\udbf2\udf4f\ud88f\udfc2\ud9cb\udc42\udbc2\ude29\ud9eb\ude1f\uda35\udd21\ud977\udc2c\ud97c\ude33\ud9b6\udcf4\ud851\udfd2\ud971\udf8b\udbca\udcb4\udb31\udeda\ud824\udd8d",
        11, 11932, -1600356163, 3070141713992908729L, -39253L, false, false, (char) 48017, (char) 21069,
        Double.longBitsToDouble(0x3f87841b01a17340L), Double.longBitsToDouble(0x3fd29687b025c6a4L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 7, 1, "\u1ff8", "\ub869\u825b\ua43e\u83e3\uaa0d\u76fe\u5bb5\u3a12\u1320\ubf13\u05e6\u0e95\u15fd\u0a14\u773b\u6334\u2109\u7942\u9886", "\ud8a2\udf38\ud87c\udd90\uda56\udc7b\ud9e4\ude8e\udbcb\udfb3\ud9df\ude2a",
        42, 27530, 282089865, 5909019794781653674L, -96636L, false, true, (char) 37985, (char) 4770,
        Double.longBitsToDouble(0x3fe954e82d90f7aaL), Double.longBitsToDouble(0x3fe831d8b6dd777aL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 14, 14, 0, "\uda91\udc92\ud80b\udd4d\ud843\udc74\udbbd\udf11\udb0c\udf15\udb43\udcbf\ud9e6\udecb\ufb8a\uda05\udec4", "\u6222\u64f4\u73c5\u882c\u2813\u656b\u7f6d\u125f\uc17d\u2854", "\udafb\udfcb\udb16\udfda",
        47, 87846, -214720870, 569967003496502309L, 98156L, true, true, (char) 13055, (char) 31656,
        Double.longBitsToDouble(0x3feffada08d79378L), Double.longBitsToDouble(0x3fe14430b624ef62L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 9, 11, "\u00e1\000\000\udbbd\udf11\000\000\ud9a6\udf93\ufb8a\uda05\udec4", "\u6222\u64f4\u73c5\u882c\u2813\u9892\u7f3f\u125f\uc250\u2854", "\udafb\udfcb\udb16\udfda",
        47, 34790, 177, 4608401778430800054L, -100000L, false, false, (char) 63743, (char) 39703,
        Double.longBitsToDouble(0x3e1fa00000000000L), Double.longBitsToDouble(0x3feffada08009378L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 9, 0, "\uda46\udfa3#\u8c00\udbbd\udf11\udb0c\udf15\udb43\udcbf\ud9e6\udecb\ufb8a\uda05\udec4", "\u6222\u009c\000\000\000\u6cbd\u7f6d\u05a2\uc250\u2854", "\udafb\udfcb\udb16\udfda",
        47, 34790, 2350769, 93459723939840L, 98156L, true, true, (char) 13055, (char) 31656,
        Double.longBitsToDouble(0x3fe802da08d79378L), Double.longBitsToDouble(0x3fe14430b000ef62L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 9, 11, "\000\ud80b\udd4d\ud843\udc74\udbbd\udf11\udb0c\udf15\udb43\udcbf\ud9e6\udecb\ufb8a\uda05\udec4", "\000", "\ud847\ude03\uf643",
        15, 50886, -1743225467, 5431139924600320313L, -99809L, true, false, (char) 20810, (char) 29311,
        Double.longBitsToDouble(0x3fc9cc0c1ac71684L), Double.longBitsToDouble(0x3fd43ff2316c7fe8L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 9, 11, "\000", "\u3fdb\u6ca1\u0c8d\u85ec\u0811\u9d55\u9683\ucb3f\u6222\u64f4\u73c5\u882c\u2813\u656b", "\ud837\udd6d\udbc1\udf8a\udb13\udd9b\ub945\udafb\udfcb",
        32, -368, -979260210, -61961116989500093L, 74435L, false, true, (char) 860, (char) 42948,
        Double.longBitsToDouble(0x3fe80005a5d3252cL), Double.longBitsToDouble(0x3fcfba557ffd6d04L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 9, 11, "\udaa3\udd89\ud918\udd21\ud843\udc74\ud881\udf81\udb0c\udf15\udb43\udcbf\ud9e6\udeb5\ufb8a\uda05\udec4\udbd9\udd31\ud8b0\udccb\udbc1\udce2\ubfe0\ud987\udc63\ud847\ude03\uda40\udec5\ud973\udf38\ud8e7\ude27\ud99f\udf65\udbff\udd85\udbc2\udc49\udb13\udd9b\ub945\udafb\udfcb\udb16\udfda\udbe2\udeed\ud98a\udd5d\u76a4\udb60\udd07\uf30d\ud94e\udd74\ud9c6\ude24\ud802\udf8f\udb4c\udffb\udb43\udd93\ud82c\udf27\udaed\ude5d\udaa4\udd99\udaf8\udda7\ud93e\udd2d\ud8a4\udeac\udbb4\ude10\ud841\udfe4\udb22\ude90\ud836\udc7e\uda66\ude1f\udb5c\udcca\udbea\udca4\ud9b7\ude57\ud899\udfad\uda61\ude4c\ud9bc\udc2b\udba2\ude00\ud88e\udfdf\udab8\udf40\ud89b\uded1\uefe2\ud884\udc07\ud805\udfe0\udb28\udc1d\ud834\udfbd\ud999\udd1a\ud992\udfe9\ud9b3\ude9f\ud9ff\udcff\u8d61\uda64\uddab\udbb2\udf68\ud95d\uddec\ud902\udddf\ud939\udeb9\ud9d8\udfd7\ud8d0\udd88\ud86e\udc21\ud9dd\udce9\ud8a8\udc0d\udbf1\udf34\udb8c\udfab\ud971\udf8c\uda38\uded4\uda3b\udfbe\uda07\ude33\uda24\udfd9\ud9d5\udec5", "\u645f\u5ed6\u7969\u7cd2\u8365\u474f", "\udade\ude0d\udbb4\udf57\uda9c\udd61\udad8\udfdf\ud961\ude82\ud8f1\uddb1\ud865\udf30\ud944\udcf9\udaca\udf87\ud9a2\udcd9\ud938\udd38\ud8f3\udc2b\udb3a\udc6d\udaa2\udd05\ud83a\udfe8\ud8b5\udf25\ud88c\udf98\ud8e5\udcfa\ucb2e",
        15, 68175, 2100089351, -7270206204259599729L, 98854L, false, true, (char) 56646, (char) 49826,
        Double.longBitsToDouble(0x3fe3623d1a28e82eL), Double.longBitsToDouble(0x3fe6264eefc0c039L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 10, 7, "\u9936", "\u986a\u57eb\u4fee\u680f\u8c44\u0b12\u6178\u335d\u55de", "\ud9d0\udf32",
        26, 87568, -1650601938, -5109195768760189444L, -21619L, false, false, (char) 31458, (char) 13539,
        Double.longBitsToDouble(0x3fd405d5e99dde64L), Double.longBitsToDouble(0x3faa4a160af62fa0L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 0, "", "\000", "",
        -5, 50824, 1421883866, -7322761166388758746L, -100000L, false, false, (char) 3469, (char) 52150,
        Double.longBitsToDouble(0x3fd617beac000000L), Double.longBitsToDouble(0x3fc3c8d402167674L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 5, 5, 1, "\ud8d8\udc16\ud801\udd48\udb0d\udf8b\udac4\ude31\ud929\udf62\ud9c7\udf37\ud9bb\udd09\uda4d\uded8\udb59\udd86", "\u6dd0\u4542\ub5b2\u0e71\ud3e3\u822c\u92f3\uc98b\u060e", "\ud988\udef0\ud846\ude97\uda1c\udc34\uda79\ude20\ud8d4\ude11\ud9eb\udef6\ud9e8\udf74\ud866\udf0a\ud94e\udd34\ud9a5\udfbd\uda2b\udc4f\udaef\udd7a\udb43\ude7b\ud893\udd4e\uda59\udc10\ud8b8\udec9",
        57, 85169, -1261170259, 4084824999977952741L, -26063L, false, true, (char) 23885, (char) 44363,
        Double.longBitsToDouble(0x3fe0d74fa4c5b4c2L), Double.longBitsToDouble(0x3febf12733397ee4L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 4, 1, "\uda91\udc6a\ud801\udd48\u5069\ud847\udc77\udb8e\udfec\ud911\udff0\ud9e6\udecb\uda4d\ude27\udb59\udd86\ud95c\udfc4\ud9f9\udd60\ue349\udb6e\udce0\ud987\udcae\ud9d0\udf04\udbe5\udf1dx\uda0b\udc25", "\uaacf", "\udb2e\udf85\ud98d\udf53\ud800\udff5\ud927\udf98\udaa2\udef6\udb8a\udd6e\ud87e\udc0e\ud862\udfe1\udacc\udd9a\u59cc\udbf6\udc0c\ud84f\udf75\u67e7\udaa9\udc2e\ud876\udd13\udbfd\udca4\udbb9\udc9f\udb53\udf36\udaab\udead\udbea\udd0a\ud8fc\udf8d\ud8a6\ude55\ud8ad\udc1f\udade\udcd8\udb4f\udecd\uda03\udfd1\ud972\uddc8\ud931\ude00\uda16\uddc9\uda4c\udddf\udbe8\udfac\ud958\udcda\udaab\udcb3\uda56\udca8\ud8b3\udfb3\udb24\udf4e\udb6e\udd72\ud8d7\uddd7\udb6d\udea3\udbc2\udefb\uda1c\udcac\ud9f0\udd71\ud83b\udf3f\uc54b\ud846\udc2d",
        35, 82117, 633795156, -2282039040024421242L, 69315L, false, true, (char) 11437, (char) 52039,
        Double.longBitsToDouble(0x3fbced6f0fff2998L), Double.longBitsToDouble(0x3fed9f269b1ae2e5L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 10, 1, "\000\u2925\udb6c\udc9d\udac4\ude31\ud8ea\udea3\ud816\udda0\ud83b\udc64\u2489\udb56\udcf2", "\u9dc3\u4542\u7410\u1346\u9f50\u534d\u0363\u698d\u5ef8\u289b\u9d20\u00bf\u85db\u90e2\u4d7b\u4d02\u4a37\ub505\u877a\ube70\u6239\u8972\u8606\u88c2\u98d6\u976e\uc31b\u3f33\ua5bf\u6092\ud53a", "\u38ab\ud873\uddd2\udb01\udeca\ud944\udc0b\ud9eb\udd75\udb31\udd47\udbad\udecd\uda30\udc8f\ud945\udf74\udafe\ude0c\ud9a6\udc96\udbd2\udd22\udbdd\ude61\ud8b2\udc07\ud92c\udde9\udad1\udd81\ud835\ude34",
        56, 64888, -1276486812, -7737003182174412038L, 27622L, true, true, (char) 28045, (char) 48667,
        Double.longBitsToDouble(0x3fe31dbcc57dcb24L), Double.longBitsToDouble(0x3fe83cfc9eaaab17L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 8, 1, "\uda91\udc92\udb5f\udcf8T\000\udb6a\udd14\ud91c\udfc58\uda4d\ude27\udb59\udd86", "\000\000\000\ubb26\uc1c6\u838a\u2393\u698d\u5e27", "\udbc6\uded0\ud946\udd38\uda71\udfb9\000\ud8f5\ude73\ud87a\ude03\u00d0\udbea\udef5\uda51\uddf6\ud94e\ude43\ud964\udcf1\ud82d\udcd5\ud9ba\udfaf\udac2\udf72\udb7b\udd79\udb77\udc9c",
        1, 38447, -1265257712, 4084824999977952741L, -26063L, false, true, (char) 1514, (char) 12917,
        Double.longBitsToDouble(0x3feca9c86c61001cL), Double.longBitsToDouble(0x3febf127334c591bL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 11, 11, "\udb65\ude3a\ue5e2\u00a3\000\000\ud8e0\udc6f8\ud9f5\ude9c\udb05\udc30\ud95d\udc54\ud800\udd43h", "\ubb26\u999a\u12ab\u4986\u698d\u5e27\uad21\u80aa\u768d\u8652\u923b\u325a\u4d02\u0a9c\u1409\u70eb\u56f4\u7fdd\uc107\u4596", "\uda3c\udc82\ud83b\udc9c\u9f1a\udad4\udc12\ud8c9\ude9e\ud8be\ude09\udb87\udd43\uda6a\udc6b\ud933\udd5b\udbf4\udc33\uda56\ude22\udae3\udc58\ud9cc\udc8b\udafd\udea8\ud93d\udce7\u9a35\udad8\udd44\udaf1\uddac\udb24\udec3\ud90e\udced\udbcb\udd39\udb27\udfd0",
        -4, 86124, 92665729, 4873451976657254602L, 82462L, true, false, (char) 24885, (char) 26414,
        Double.longBitsToDouble(0x3fa8645b920f0db0L), Double.longBitsToDouble(0x3fe9a41d0b97708fL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 1, "\uda91\udc92#\ud964\udcf1\udac4\ude31\udb0c\udf15\ud8e4\udff0\ud9e6\udecb\udb60\ude91\udb93\udec9", "\u564c", "\ud9ad\udc80\udbe5\udf1d\ud960\udd86\uda89\ude38\uda09\udea6\ud89d\udfe8\udbf1\udeaa\udbb5\udf18\udbe2\ude7d\ud83c\udff1\udbd4\uddab\ud9cb\udcc3\ud8f5\ude73",
        27, 63733, -1434542601, 82939610195013984L, -30830L, false, true, (char) 64275, (char) 62719,
        Double.longBitsToDouble(0x3fe7d2da0c649403L), Double.longBitsToDouble(0x3fc01a67db2f70bcL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 1, "\uda91\udc92\ud801\udd48\udb59\udd19\udac4\ude31\udb0c\udf15\ud8e4\udff0\ud9e6\udecb\udb60\ude91\uda04\udf22\ud9f9\udfd9\ud9f9\udd60\ud886\udc90\ud9c3\udfe7\ud90a\udebe\ud9ad\udcac\udbe5\udf1d\ud960\udd86\uda89\ude38\uda09\udea6\ud89d\udfe8\udbf1\udeaa\udbb5\udf18\udbe2\ude7d\ud83c\udff1\udbd4\uddab\ud9cb\udcc3\ud8f5\ude73\ud991\udfed\ud922\udc90\u48ed\ud94e\udd34\ud96d\udec0\uda88\udcdd\ud870\udf07\ud9ba\udfaf\udab5\udfe9\udb00\udf3d\udb77\udc9c\udb02\uddc0\udac5\udf63\ud8c0\ude59\udb71\udfc4\udadc\udc79\ud987\uddb9\ud895\uddd7\udb11\udf06\uda05\udc27\udae3\udc58\ud99a\udf1f", "\u1e6c\u50d8\uab80", "\uda0f\udd12",
        15, 35688, 1160377938, -1591210064769658614L, -14399L, false, false, (char) 33540, (char) 29341,
        Double.longBitsToDouble(0x3fe1c967bb7bbe29L), Double.longBitsToDouble(0x3fe13d0dc381eb1fL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 1, "\ub8e1\000\ud964\udcf1\udac4\udda6\007\ud8e4\udff0\ud9e6\udecb\000\ud9c9\udc64", "\u564c\u8e2c\u86e7\u5810\ud3e3\u7b0a\u30cb\ua7a1\u5ef8\u1c1a\u912b\ua0f7\u90c6\u66eb\u00c1\u57ff\u7334\u0e57", "\ud96d\udec0\uda88\udcdd\ud870\udf07\ud9ba\udfaf\udab5\udfe9\udb00\udf3d\udb77\udc9c\udaf9\uddc0\udac5\udf63\ud89d\udc59",
        -5, -1000, 766675712, -3638590941940881637L, 55396L, true, true, (char) 46165, (char) 0,
        Double.longBitsToDouble(0x3fe80000046fd363L), Double.longBitsToDouble(0x3fe76805c746b2ddL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 9, 11, "\000\000\000\000\000\000\ud9a6\udf93\ufb8a\uda05\udec4", "\u6222\u64f4\u73c5\u882c\u2813\u9892\ud000\000\ud0e3\u7139", "",
        37, 44012, 1616909632, -4205890576224092160L, -34464L, true, true, (char) 38, (char) 0,
        Double.longBitsToDouble(0x3fd0000000c73568L), Double.longBitsToDouble(0x3e1fa00000000000L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 9, 11, "\000#\000\000\000\000\000\000\000", "\000", "\000\uf600",
        15, 50886, -1744798331, 80248968212736L, -99809L, true, false, (char) 20810, (char) 23935,
        Double.longBitsToDouble(0x3e48000000000000L), Double.longBitsToDouble(0x3fd43ff2316c7fe8L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 9, 11, "\udaa3\udd89\ud918\udd21\ud843\udc74\ud881\udf81\udb0c\udf15\udb43\udcbf\ud9e6\udeb5\ufb8a\uda05\udec4\udbd9\udd31\ud8b0\udccb\udbc1\udce2\ubfe0\ud987\udc21\ud847\ude03\uf643\000\ud8e7\ude27\ud99f\udf65\udbff\udd85\udbc2\udc49\udb13\udd9b\uda37\udc7a\udafb\udfcb\udb16\udfda\udbe2\udeed\ud98a\udd5d\u76a4\udb60\udd07\uf30d\ud94e\udd74\ud9c6\ude24\ud802\udf8f\udb4c\udffb\udb43\udd93\ud82c\udf27\udaed\ude5d\udaa4\udd99\ud91c\udcd8\000\000\udbb4\ude10\ud841\udfe4\udb22\ude90\ud836\udc7e\uda66\ude1f\udb28\uddca\udbea\udca4\ud9b7\ude57\ud899\udfad\uda61\ude4c\ud9bc\udc2b\udba2\ude00\ud88e\udfdf\udab8\udf40\ud89b\uded1\uefe2\ud884\udc07\ud805\udfe0\u5f96\000\000\000\ud9b3\ude9f\ud9ff\udcff\u8d61\uda64\uddab\udbb2\udf68\ud95d\uddec\ud902\udddf\ud939\udeb9\ud9d8\udfd7\ud8d0\udd88\ud86e\udc21\ud9dd\udce9\ud8a8\udc0d\udbf1\udf34\udb8c\udfab\ud81a\udd60\000\000\ud9f0\udd18\uda24\udfd9\udafc\udfc0", "\u645f\u5ed6\u7969\u0c18\u00ca\u44a9", "\udade\ude0d\udacf\udc67\uda9c\udd61\udad8\udfdf\ud961\ude82\ud8f1\uddb1\ud865\udf30\ud944\udcf9\udbad\ude39\ud9a2\udc5d\ud938\udd38\ud8f3\udc2b\udb3a\udc6d\udaa2\udd05\ud83a\udfe8\ud873\udf24\ud88c\udf98\ud8e5\udcfa\ucb2e",
        15, 68175, 2100089351, -7270206204259599729L, -99802L, false, true, (char) 20551, (char) 0,
        Double.longBitsToDouble(0x3fe3623d1a28e82eL), Double.longBitsToDouble(0x3fe6264eefc0c039L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 6, 1, "\uda91\udc6a\ud801\udd48\u5069\ud847\udc77\udb8e\udfec\ud911\udff0\uda50\udec0\uda4d\ude27\udb59\udd86\ud95c\udfc4\ud9f9\udd60\ue349\udb6e\udce0\ud987\udcae\udbed\udff3\u7319\011\udba0\uddb2", "\uaacf\u5d34\u4226\u642f\u2188\u23f6\u0fce\u2b61\ubaef\u5d6e\ucd50\u941d\ud59e\u0c5a\u2527\u67e7\u041d", "\udbb9\udc9f\udb53\udf36\ud9c8\udeba\uda2b\udc7c\ud882\udcfa\ud8e6\uddcd\ud8ad\udc1f\uda58\udf37",
        33, 20772, -1048232585, -7226392940242226346L, -99128L, false, true, (char) 37135, (char) 51673,
        Double.longBitsToDouble(0x3fe4f58bf0ad5640L), Double.longBitsToDouble(0x3fca149d204ee42cL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 1, "\ub8e1\000\ud964\udcf1\udb6c\udfda'\ud8e4\udff0\ud9e6\udecb\000\ud9c9\udc64", "\u564c\u8e2c\u86e7\u5810\ud3e3\u7b0a\u30cb\ua7a1\u5ef8\u1c1a\ua01b\ua0f7\u90c6\u66eb\u00c1\u57ff\u7334\u0e57", "\ud96d\udec0\uda88\udcdd\ud870\udf07\ud9ba\udfaf\udab5\udfe9\udb00\udf3d\udb77\udc9c\udaf9\uddc0\udac5\udf63\ud89d\udc59",
        -5, -1000, 768838400, -3638590941940881637L, 55396L, true, true, (char) 46165, (char) 0,
        Double.longBitsToDouble(0x3fe80000046fd363L), Double.longBitsToDouble(0x3fe76805c746b2ddL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 10, "\uda37\ude85\010\ud964\udcf1\ud86f\udf3c\007\ud8e4\udff0\ud9e6\udecb\000\ud958\ude2c", "\u564c\u8e2c\u86e7\u5810\ud3e3\u7b0a\u30cb\ua7a1\u5ef8\u1c1a\u912b\ua0f7\ub97b\u66eb\uc9a3\u57ff\u7334\u0e8a\u789f", "\udaaa\udddd\ud870\udf07\ud9ba\udfaf\udab5\udfe9",
        42, 46242, -750911388, -2580569734574178101L, -100000L, false, true, (char) 20099, (char) 46236,
        Double.longBitsToDouble(0x3fe55ff540fc4093L), Double.longBitsToDouble(0x3fe6f9c86a1f9b54L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 6, 1, "\uda91\udc6a\ud801\udd48\u5069\ud8f4\udfef\udad9\udda1\ud911\udff0\uda50\udec0\uda4d\ude27\udb59\udd86\ud95c\udfc4\ud9f9\udd60\ue349\udb6e\udce0\ud987\udcae\udbed\udff3\udb43\udc1e\015\udba0\uddb2", "\uaacf\ud4d8\u4226\u642f\u2188\u23f6\u0fce\u2b61\ubaef\u5d6e\ucd50\u941d\ud59e\u0c5a\u2527\u67e7\u041d", "\udbb9\udc9f\udb53\udf36\ud9c8\udeba\uda2b\udc7c\ud882\udcfa\ud8e6\uddcd\ud8ad\udc1f\uda58\udf37",
        33, 20772, -1048232585, -7226392940242226346L, -99128L, false, true, (char) 37135, (char) 51673,
        Double.longBitsToDouble(0x3fe4f58bf7d67b40L), Double.longBitsToDouble(0x3fd1ff7be02640baL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 8, 1, "\uda73\udc2f\ud801\udd48\uda1b\udcbb\udac4\ude31\udb0c\udf15\udbeb\udc74\udbf7\udf6e\uda4d\ude27\udb59\udd86\ud95c\udfc4\ud9f9\udd60\ud886\udc90\udb6e\udc90\ud987\udcae", "\u7b0a\u2393\u997b\u5ef8\u289b\u9d20\u86dc\u8652\u90e2\u4955\u4d02\u4a37\u0ef4\u789f\u3280\u049d\u4bcd\u1763\uccfb\u73a0\u9313\uc295\ub1d6\u35d6\u09ae\ud1e1\ub13c\u2931\ud4f7\ud20f\uafab\u949a\u65e6\u2bf3\u9d1a\ub7f8\ubfd2", "\udbd9\ude61\ud8a3\udd98\uda76\ude60\udbd0\udf7b\ud88f\udf95\ud949\udc3b\ud96f\udf86\ud8aa\udce9",
        36, 43962, 275177401, 2117676098944091466L, 20020L, false, false, (char) 50391, (char) 9720,
        Double.longBitsToDouble(0x3fda72c9a07b485aL), Double.longBitsToDouble(0x3fb5a8ed0a65e5f8L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 4, 4, 1, "\uda91\udc92\ud9be\udee6\udb59\udc33\udab6\udfa8\ud8d5\uddf8\u9773\ud98c\udde6\uda4d\uded8\udb59\udd86\ud95c\udfc4", "\u408e\u7385\u0e95\ud24c\u4ac4\u2403\u20ed\u599c\u289b\u3f43\u86fb\u8652\u90e2\u4955", "\ud84e\udc61",
        31, 18883, 1518448992, 1222665813455081010L, 67800L, true, true, (char) 60373, (char) 45821,
        Double.longBitsToDouble(0x3fe1890c9b42a786L), Double.longBitsToDouble(0x3fc65699f5e10050L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 10, 0, "\ub800\000\000\000\000\000\000\000\000", "", "\ue235\ud9ad\udc80",
        53, 87568, -1650601938, -5109195768750031407L, 15691L, true, false, (char) 26376, (char) 47615,
        Double.longBitsToDouble(0x3fdc1f6a699dde64L), Double.longBitsToDouble(0x3fe9a4a160000000L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 3, "3\ud858\udd25", "\u6ca1\ua3e2", "\udb59\uddb1",
        12, 74504, -391245328, -6905495620198424349L, -2210L, false, false, (char) 36170, (char) 62754,
        Double.longBitsToDouble(0x3fd86b917f013772L), Double.longBitsToDouble(0x3fd41edea10d1960L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 10, 1, "\015", "\u986a\ucc86\u47e9\u14b5\ubf47\ud67d\u9281\000\u9dc3\u4542\u4d07\u0a73\u875b\u05da\u0363\u698d\u5ef8\u5aa5\u9d20", "\uda71\udfb9",
        -5, 7454, 1344959284, -6571630241152914942L, -39286L, false, true, (char) 20575, (char) 24041,
        Double.longBitsToDouble(0x3fd02cef58d5c9b6L), Double.longBitsToDouble(0x3fe020145c28770bL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 10, 1, "\000\u2925\udb6c\udc9d\udac4\ude31\ud8ea\udea3\ud816\udda0\ud83b\udc64\u2489\udb56\udcf2\ud985\uddb9\000\uda42\udc98\udb6e\udc90\uda09\udfb6\udad0\udee5\ud836\udc71\ud98c\uddc8\ud92e\ude5f\ud886\udd58\ud89d\udfe8\udbc1\udfd1\udaeb\ude68\u00bf\ud846\ude20\uda71\udfb9\udbcb\udd42\ud8f5\ude73\ud991\udfed\ud838\udfbd\ud85a\udf79\uda63\ude7d\udb9f\ude9b\ud824\udc4a\udacf\udfbe\ud869\udffe\ud9f3\udf68\ud98b\udc90\udbf1\udd07\ud81c\udf83\ud834\uddff\ud9c6\udfc0\udbda\udfa8\ud891\udefc\uda70\udee2\u38ab\ud873\uddd2\udb01\udeca\ud944\udc0b\ud9eb\udd75\udb31\udd47\udbad\udecd\uda30\udc8f\ud945\udf74\udaf2\udd0c\ud9a6\udc96\udbd2\udd22\udbdd\ude61\ud8b2\udc07\ud92c\udde9\udad1\udd81\ud835\ude34\udb4e\uded7\ud977\udd2e\ud879\udde8\ud841\ude45\uda25\udd1f\udb92\udd7c\uda5d\udce5\udae6\udc99\udbe4\ude42\uda9e\ude5c\uda39\udf45\ud901\udfce\u6e06\ud8fc\ude1b\ud963\udde4\udbcc\udd74\ud9ac\udc17\uda96\udc53\udb39\udc03\ud9ff\uddea\udbd2\udfa2\udace\udd24\ua01e\udb79\udfe0\ud9c3\udeb9\ud803\uddb0\ud810\udeb2\ud8d0\udce9\udbbd\udffb\ud897\udea4\udbaf\udc37\ueeb6\ud8c0\udec3\uda32\udcb7", "\uae06\u0ba1\u39d3\u8f4e\u45a1\ud41f\uc2f6\u1e65\u5fa2\uc730\u1a04\u0cf9\ud23a", "\ud9b1\udfed\ud8cf\udc2d\ud935\udfa0",
        34, 71998, 1071917312, 2193532902974849135L, 40635L, false, false, (char) 9230, (char) 5029,
        Double.longBitsToDouble(0x3fec2e354478b4b5L), Double.longBitsToDouble(0x3fac710e70f1fdf0L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 1, "\ud91b\udcd3\\\ud964\udcf1\udac4\ude31\udb0c\udf15\ud8e4\udff0\ud9e6\udecb\udb60\ude91\udb93\udec9", "\u564c", "\ud9ad\udc80\udb7e\udc69\ud960\udd86\uda89\ude38\uda09\udea6\ud89d\udfe8\udbf1\udeaa\ud887\ude3b\u59d8\ud821\udee6\udbd4\uddab\ud9cb\udcc3\ud8f5\ude73",
        19, 49849, -1434542601, 82939610195013984L, -30830L, false, true, (char) 64275, (char) 62719,
        Double.longBitsToDouble(0x3fc67a45aadbae04L), Double.longBitsToDouble(0x3fd0e078f0a847b2L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 1, "\ub8e1\000\ud964\udcf1\udac4\udda6\"\ud9ae\udcd4\ud9aa\udc3f\000\ud9c9\udc64", "\u564c\u8e2c\ub383\u5810\ud3e3\u7b0a\u30cb\ua7a1\u5ef8\u1c1a\u912b\ua0f7\u90c6\u7621\u6293\u7148\u57e5\u9c91", "\ud96d\udec0\uda88\udcdd\udb96\udf1b\ud9ba\udfaf",
        5, 90437, -1811690758, -3225139854254802560L, -100000L, false, false, (char) 35583, (char) 16003,
        Double.longBitsToDouble(0x3fa3bbbe1a01b250L), Double.longBitsToDouble(0x3fcf922f3fceac34L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 1, "\ub8e1\000\ud968\uddda\ud8ee\udd5b\012\ud8e4\udf80\ud9e6\udecb\000\uda39\udeca", "\u564c\u8e2c\u86e7\u5810\ud3e3\u7b0a\u6e26\u6756\ucf02\u1c26\u912b\ua0f7", "\ud9ff\udc5c",
        38, 35329, -352297678, -6161313826577448925L, 28477L, false, false, (char) 42785, (char) 26787,
        Double.longBitsToDouble(0x3fc97b85e002d254L), Double.longBitsToDouble(0x3f60e00000000000L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 0, 0, 0, "3", "\000", "\000",
        -2, 81675, 30502, 8940771159846031856L, -100000L, false, false, (char) 0, (char) 25262,
        Double.longBitsToDouble(0x3fa75e8e7859d9d0L), Double.longBitsToDouble(0x3fd86b917f013772L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 3, "3\udae0\udf13\ud8a2\udc01\ud961\udf41\udb15\udeac", "\u6d72\u513e\u7ddc\u663a\u564c\u06bd\u48f4\u1a28\u060f\uc656\u2393\u8e7a\u5ead\uce82\uac95\uc5bd\u3a5f\u7d87", "\udb22\udd85\ud8c8\udf85\ud822\udd7a",
        26, 57680, -491293990, -7469214234740023898L, 60399L, false, true, (char) 51354, (char) 18166,
        Double.longBitsToDouble(0x3f41991a05f98000L), Double.longBitsToDouble(0x3feae11a3ce6e7ccL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 10, 1, ">", "\u986a\ucc86\u47e9\u14b5\ubf47\ud67d\u9281\000\u9dc3\u4542\u4d07\u0a73\u875b\u038f\u9d12\u698d\u5ef8\u5aa5\u9d20", "\ud990\udd05",
        -5, 54942, 551687917, -6571629824541087230L, -39286L, false, true, (char) 20575, (char) 24041,
        Double.longBitsToDouble(0x3fd02cef58d5c9b6L), Double.longBitsToDouble(0x3fe020145c28770bL)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 0, 5, 5, "3", "\000", "\ubbed",
        -1, 58024, 671119142, 8940771237155443184L, 31072L, false, false, (char) 36170, (char) 62754,
        Double.longBitsToDouble(0x3fd86b917f013772L), Double.longBitsToDouble(0x3fef8be1a707bd1eL)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 10, 1, "\ub8e1\udbcf\udec6\ud99e\udd5c\ud9fb\udf36<\ud8e4\udff0\ud9e6\udecb\000\ud9c9\udc64", "\u564c\u8e2c\u86e7\u5810\ud3e3\u7b0a\u30cb\ua7a1\u408c\uc5a4\ua01b\ucb01\u06b4\u7a37\u86fc\u57ff\u7d79\u0e57", "\ud96d\udec0\uda88\udcdd\ud870\udf07\ud9ba\udfaf\udab5\udfe9\udb00\udf3d\ud91b\udead\ud82a\udf2d\ud940\udfd0\ud89d\udc59",
        -5, -1000, 1968021248, -3638528707864762597L, 55396L, true, true, (char) 46165, (char) 0,
        Double.longBitsToDouble(0x3fe80000046fd363L), Double.longBitsToDouble(0x3fb04db07a359158L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 6, "\ud992\udc3c\011\ud964\udcf1\udac4\udda6\"", "\000\u8772\u31a1\u2144\u564c\u34f8\ub383\u5810\ud3e3", "\uda09\udea6",
        32, 98154, 150052498, -5215820645178268218L, -599L, true, false, (char) 15201, (char) 55674,
        Double.longBitsToDouble(0x3fd417e00cc9f3b4L), Double.longBitsToDouble(0x3fd600110fc1a6f6L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 1, "\ud947\udf0d>\ud985\uddc9\ud8ee\udd5b\012\ud8e4\udf80\udb7d\udfc7\000\uda39\udeca", "\u564c\u2baa\u186e\u64cd\ud47e", "\ud8f3\udc9a",
        34, 98166, 150052498, -5215820645178233609L, 60305L, true, true, (char) 32691, (char) 11316,
        Double.longBitsToDouble(0x3fdb8eb9c40d54fcL), Double.longBitsToDouble(0x3fd85247c8ff96f6L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 9, 11, "\udaa3\udd89\ud918\udd21\000\000\000\udb43\udcbf\ud9e6\udeb5\ufb8a\uda05\udec4\ue5c1\ud964\udcf1\udbc1\udce2\u9f9c\000\ud847\ude03\uf643\000\ud8e7\ude27\ud99f\udf65\u6eb4\udbc1\udf51\ud946\udff5\uda37\udc7a\u0091\udb16\udfda\udbe2\udeed\ud98a\udd5d\u76a4\udb60\udd07\uf30d\ud94e\udd74\ud9c6\ude24\ud802\udf8f\udb4c\udffb\udb43\udd93\ud82c\udf27\000\uda74\udd9a\ud91c\udcd8\000\000\udbb4\ude10\ud841\udfe4\u694d\000\000\udb28\udd14\udbea\udca4\ud9b7\ude57\ud899\udfad\uda61\ude4c\ud9bc\udc2b\udba2\ude00\ud88e\udfdf\udab8\udf40\ud89b\uded1\uefe2\ud884\udc07\ud805\udfe0\u5f96\000\000\000\ud9b3\ude9f\ud9ff\udcff\u8d61\uda64\uddab\udbb2\udf68\ud95d\uddec\ud902\udddf\udb2d\udeb3\ud9d8\udfd7\ud8d0\udd88\ud86e\udc21\ud9dd\udce9\ud8a8\udc0d\udbf1\udf34\udb8c\udfab\ud81a\udd60\000\000\000\uda24\udf91\udafc\udfc0", "\u2ddc\u5ed6\u008b", "\udb06\udc02",
        22, 82898, 1746754539, -4395513234415676745L, -10406L, false, true, (char) 13879, (char) 8590,
        Double.longBitsToDouble(0x3fe1a691c2000064L), Double.longBitsToDouble(0x3feb780005c19690L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 1, "\ub8e1\000\ud964\udcf1\udac4\udda6\"\ud9db\udcab\ud9d4\udf33\"\ud9c9\udc64", "\u564c\u8e2c\ub383\u5810\ud3e3\u7b0a\u30cb\ua7a1\u5ef8\u1c1a\u912b\ua0f7\u682f\u2860\u8252\u7148\u57e5\u9c91", "\ud96d\udec0\uda88\udcdd\udb96\udf1b\ud9ba\udfaf",
        5, 90437, -1811690758, -3225139854254802560L, -100000L, false, false, (char) 35583, (char) 16003,
        Double.longBitsToDouble(0x3fa3bbbe1a01b250L), Double.longBitsToDouble(0x3fcf922f3fceac34L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 10, 1, "\ud947\udf0d>\ud985\uddc9\udaee\ude5b>\ud8e4\udf80\udb7d\udfc7\000\uda39\udeca", "\u564c\u2baa\u186e\u64cd\ud47e", "\ud8f3\udc9a",
        34, 98166, 150052498, -5215820645178233609L, 60305L, true, true, (char) 32691, (char) 11316,
        Double.longBitsToDouble(0x3fdb8eb9c40d54fcL), Double.longBitsToDouble(0x3fd85247c8ff96f6L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 8, 0, "0", "\u986a\u6ca1\u8ff7\000\u6d72\u0b12\u7726\u61de\u564c\u4542\u0a11\u0e95\ud3e3\u7b0a", "\ud89d\udfe8\udbc1\udfd1\ud852\udec9\ud92c\uddbf\u56e9\ud954\udfb0\uda3a\udc44\udaf2\udf78\ud8e7\udcd6\uaca6\ufdc1",
        56, 60314, -990287593, 3801962160437025476L, -21151L, true, false, (char) 53875, (char) 24964,
        Double.longBitsToDouble(0x3fdc4e6e6d3db1f8L), Double.longBitsToDouble(0x3fe465aba3a266a8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.CodeGenerator|isSimpleNumber|java.lang.String|static",
    "M|com.google.javascript.jscomp.CodeGenerator|add|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|add|com.google.javascript.rhino.Node,com.google.javascript.jscomp.CodeGenerator$Context|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|add|java.lang.String|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addAllSiblings|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addArrayList|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addCaseBody|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addExpr|com.google.javascript.rhino.Node,int,com.google.javascript.jscomp.CodeGenerator$Context|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addExpr|com.google.javascript.rhino.Node,int|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addIdentifier|java.lang.String|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addJsString|java.lang.String|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addLeftExpr|com.google.javascript.rhino.Node,int,com.google.javascript.jscomp.CodeGenerator$Context|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addList|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addList|com.google.javascript.rhino.Node,boolean|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addList|com.google.javascript.rhino.Node,boolean,com.google.javascript.jscomp.CodeGenerator$Context|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addNonEmptyStatement|com.google.javascript.rhino.Node,com.google.javascript.jscomp.CodeGenerator$Context,boolean|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|isSimpleNumber|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
