package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class FunctionToBlockMutator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 9, 8, "\ud9ed\udd29\ud917\ude5d\ufc2b\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\uda28\uddf5\u91dc\ud86f\udd5b\ud9d5\udc16", "\u1658\ub193\u0232\u03eb\ub92b\u0421\ub0bc", "\032\uda49\udefa\ud9f5\uddae\udaca\udd0e\ud97c\ude5e\uda4f\udc23\udabf\uddbe\ud868\udfbe\ud97a\udc0f\u2def\ud826\udf02\ud88b\udc82\udbd8\udf48\udabc\uddd7\ud9b7\ude69",
        34, 72543, -1875069804, 5046283698886143083L, 69112L, false, true, (char) 24913, (char) 52982,
        Double.longBitsToDouble(0x3fe0971c3582e031L), Double.longBitsToDouble(0x3fe52889721f2ce5L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 9, 8, "\ud9ed\udd29\ud917\ude5d\ufc2b\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\uda28\uddf5\udbd3\ude92\udb27\udd44\ud9d5\udc16", "\u1658\ub193\u0232\u03eb\ub92b\u0421\ub0bc", "\032\uda49\udefa\ud9f5\uddae\udaca\udd0e\ud97c\ude5e\uda4f\udc23\udabf\uddbe\ud868\udfbe\ud97a\udc0f\u2def\ud826\udf02\ud88b\udc82\udbd8\udf48\udabc\uddd7\ud9b7\ude69",
        34, 72543, -1875069804, 5046283698886143083L, 69112L, false, true, (char) 24913, (char) 52982,
        Double.longBitsToDouble(0x3fe0971c3582e031L), Double.longBitsToDouble(0x3fe52889721f2ce5L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 9, 8, "\ud935\udeff\uea9b\ufc2b\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\uda28\uddf5\u91dc\ud86f\udd5b\ud9d5\udc16", "\u1658\ub193\u60ec\u0479\ub92b\u0421\ub0bc", "\032\uda49\udefa\ud9f5\uddae\udaca\udd0e\ud97c\ude5e\uda4f\udc23\udabf\uddbe\ud868\udfbe\ud97a\udc0f\u2def\ud826\udf02\ud9a9\udf90\udbd8\udf44\udabc\uddd7\ud9b7\ude69\udab9\udd36\uda19\udd8c\udb13\uddf4\uda03\udcf9\udaad\ude47\ud9c0\udc34\uda4d\udf00\ud861\udfc7\ud97d\udc1a\ud97a\udd0a\ud846\udc32\ud8b5\ude85",
        53, 77559, -1563949919, 1919227472427540338L, 39996L, false, false, (char) 46490, (char) 21202,
        Double.longBitsToDouble(0x3fe47b6998201c5aL), Double.longBitsToDouble(0x3fe5943ab0291f9dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.RenameLabels:@?\012",
        Z.run(T, 1, 15, 14, 6, "\uda68\udfe7\ud929\udddd\udb87\udef9\udbd7\udc43\ud919\udf4c\udb48\udf66\udbc0\udd18\udaa2\udc6a\u91dc\ud9ed\udc5f\ud8f0\udd43", "\u8b38\u2681\ua916\u06de\ub92b\u68d0\u4599", "\032\uda49\udefa\udb6b\udf6f\udab8\udd2f",
        3, 92249, -1003409083, 803148257315591317L, 84713L, false, true, (char) 37816, (char) 24167,
        Double.longBitsToDouble(0x3fa6b9b9222762f0L), Double.longBitsToDouble(0x3fe72951dfecac8dL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 8, 8, "\ud9ed\udd29\ud917\ude5d\ufc2b\udbfa\udd96\uda33\udf79\uda52\udea9\ud85c\udeb2\ud8fe\udfc7\u91dc\ud86f\udd5b\ud97d\udfe9\udbf7\udea2\ud92c\udfc9\uda5f\udf3c\udac7\udcec", "\ub924\u8021\ubb0f\ub70d\u0b28\u6179\ubc33\u6b26\u1158\ub70a\u6d19\u7262\ud471\u4627", "\ud895\udc7d\uda38\udf97",
        5, 22389, 895248191, -6385863584639352284L, 16426L, false, true, (char) 61223, (char) 54286,
        Double.longBitsToDouble(0x3fc901912ae1f0f8L), Double.longBitsToDouble(0x3fe0971c3582e0a6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 13, 12, "\ud9ed\udd29", "\u033c\u5910\u7012\u3267\u898a\u642c\u76d2\ubbbd\u802f\u059d\uadf6\ub193\u0232\ub1da\u6cac", "\ud960\uded6\udbf3\udd3c\ud98b\udf89\ud91e\ude37",
        -5, 15025, 665467089, 8759301133051179333L, -29195L, false, true, (char) 16527, (char) 2699,
        Double.longBitsToDouble(0x3fcf35d7ec2b8d70L), Double.longBitsToDouble(0x3fa6b9b92cb69d10L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 9, 8, "\ud9ed\udd29\ud917\ude5d\ufc2b\udbfa\udd96\udaf8\udc0b\udb24\udca5\ud9f1\udedd\uda28\uddf5\u91dc\udb3e\udfc3\uda8c\udf14", "\u1658\ub193\u0232\u03eb\ub92b\u0421\u85c7", "\udbf5\udd4a\uda49\udefa\uda09\udea7\ud96d\udee3\ud97c\ude5e\uda4f\udc23\udabf\uddbe\ud868\udfbe\ud97a\udc0f\u2def\ud815\udd02\ud88b\udc82\udbd8\udf48\udabc\uddd7\ud9b7\ude69\udab9\udd36\uda19\udd8c\ud8f5\udc70\udab8\udd78\ud969\udded\uda4f\udfef\udaea\udc47\ud861\udfc7\ud97d\udc1a\ud97a\udc9c\ud846\udc32",
        24, 96053, -862795233, 2545439149926599891L, 55273L, false, false, (char) 26383, (char) 8596,
        Double.longBitsToDouble(0x3fe55275698185c6L), Double.longBitsToDouble(0x3fc7e22bc8f9de38L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 14, 6, "\ud9ed\udcca\ud917\ude5d\uda91\uddae\ud8e7\udc2e\uda24\udeb0\udb24\udca5\ud9f1\udedd\uda28\uddf5\u91dc\ud86f\udd5b\ud9d5\udc16", "\u9b5f\u9b3f\ub8b6\u6b5f\ub92b\u1c48\ub0bc\u5ee9\u0b28\u6049\ub3dd\u6b26\uc657\ub70a\u12c4\u5d47\u5588", "\ud826\udf02\ud88b\udc82\udbd8\udf48\udabc\uddd7\ud9b7\ude69\udbbc\udd16\udb49\ude40\u5e36\ud89a\udc61\u47cb\ud9bf\udfe9\uda53\udf84\uda69\udea5\ud84e\udd45\ud97a\udd0a\ud846\udc32\ud8b5\ude85",
        53, 82271, 2109442337, 3400265078033221434L, 28251L, true, false, (char) 24881, (char) 65474,
        Double.longBitsToDouble(0x3fe46763561ef8c3L), Double.longBitsToDouble(0x3fc009d8a79493bcL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.RenameLabels:@?\012",
        Z.run(T, 1, 14, 10, 8, "\ud9ed\udd29\ud917\ude5d\ufc2b\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\uda28\uddf5\u91dc", "\ubb37\u738a\u1658\ub193\u0232\u5c8a\ub92b\u0421\ub0bc\u5ee9\u0b28\u6049\ub3dd\u6b26\uc657\ub70a\u7a18\u7262\ub04b\u11a4\uc2fa\u8644\u10ff\u1b08\u23de\u2598\uaa95\u420c\u981d\u534a\u00ce\u63f8\u83ba\u05e6\u88ec\u30f8\ucc5e\u51df\u63db\u22f1\u3dc2\u0483\u5c9f\ud559\u24ea\u715d\ucdfa\u6ad7\u4b95\u1bf4\u2a7f\u0f0e\ucb9c\u75ef\u59a8\u4857\u9fb7\uc141\uac4c\u62ae", "\ud8cd\udf62\ud934\ude9a\udbc7\udfb5\udaf0\udc60\ud88b\ude32\ud955\udd06",
        59, 87580, 856526470, -7777325935196096004L, 84584L, true, true, (char) 44321, (char) 24258,
        Double.longBitsToDouble(0x3fe2b08f4770aa34L), Double.longBitsToDouble(0x3fcb1fb19254c69cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 9, 8, "\ud9ed\udd29\ud85a\ude7d\ufccc\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\ud8c3\udf03\u9268\ud86f\udd5b\ud9d5\udc16", "\u1658\ub193\u0232\u03eb\ub92b\u0421\ub0bc", "\ud8ee\udc10\uda49\udefa\ud9f5\uddae\udaca\udd0e\ud97c\ude5e\uda4f\udc23\udabf\uddbe\ud868\udfbe\ud97a\udc0f\u2def\ud847\ude12\ud9fb\ude10\udbd8\ude65\udabc\uddd7\ud9b7\ude69",
        26, 72543, 669524884, 5046284021008690283L, 69112L, false, true, (char) 35483, (char) 52982,
        Double.longBitsToDouble(0x3fd12e386b05c1b2L), Double.longBitsToDouble(0x3fe52889721f2ce5L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 4, 14, "\ud9ed\udd29\ud917\ude5d\ufc2b\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\uda28\uddf5\u91dc\ud86f\udd5b", "\u743c\u1658\ub193\u0232\u03eb", "\udba7\udef0\ud960\uded6\udbf3\udd3c\udbea\udf19\uda49\udefa\ud9f5\uddae\udaca\udd0e\ud97c\ude5e\uda4f\udc23",
        7, 12662, 477715253, -2951942195608890999L, 27021L, true, false, (char) 21322, (char) 61695,
        Double.longBitsToDouble(0x3fb2a40f235a3040L), Double.longBitsToDouble(0x3fe9e55f9b6883bfL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 4, 12, "\ud9ed\udd29\ud917\ude5d\ufc2b\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\uda28\uddf5\ud857\udf35\udaaf\udd4c\ud9d5\udc16", "\u1658\ub193\u0232\u87e9\ub92b\u0d17\u37b7", "\032\uda49\udefa\ud9f5\uddae\udaca\udd0e\ud97c\ude5e\uda4f\udc23\udabf\uddbe\ud868\udfbe\ud97a\udc0f\u2def\ud826\udf02\ud88b\udc82\udbd8\ude98\udabc\uddd7\ud9b7\ude69",
        34, 72543, -1875069804, 5046283698886143083L, 69112L, false, true, (char) 24913, (char) 52982,
        Double.longBitsToDouble(0x3fe0971c3582e031L), Double.longBitsToDouble(0x3fe52889721f2ce5L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 9, 8, "\ud9ed\udd29\ud917\ude5d\ufc2b\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\u0090\ud9ab\uddd5\ud86f\udd5b\ud9d5\udc16", "\u1658\u7c8a\000\u0393\ub92b\u0421\u8658", "\ud800\udd59\000\uda23\udc84\000\000\ud9c5\udf21\udb2d\udcbb\ud868\udfbe\ud97a\udc0f\u2def\udabc\udd8c\ud86c\udf36\udbd8\udf48\udabc\uddcd\ud9b7\ude69",
        34, 44559, -1879048192, 5046283698886143083L, 69112L, false, true, (char) 24913, (char) 52982,
        Double.longBitsToDouble(0x3fe0971c3582e031L), Double.longBitsToDouble(0x3ea7200000000000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 9, 8, "\udacd\udd42\uda15\udd65\ufc2b\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\uda8c\ude88\uda31\udc33\udb48\udde6\ud849\udfb1", "\u1658\ub193\u0232\u03eb\ub92b\u0421\ub0bc", "\uf289\udb35\udfed\ud9f2\ude5a\udaca\udd0e\ud97c\ude5e\uda4f\udc23\udabf\uddbe\ud868\udfbe\ud97a\udc0f\u2def\ud826\udf02\ud88b\udc82\udbd8\udf48\udabc\uddd7\ud9b7\ude69",
        34, 72543, -1876206956, 2665836214388356024L, 69112L, false, true, (char) 24913, (char) 52982,
        Double.longBitsToDouble(0x3fe0971c3582e031L), Double.longBitsToDouble(0x3fe52889721f2ce5L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 9, 8, "\ud9ed\udd29\ud917\ude5d\ufc2b\udbfa\udd96\udb6e\udfe0\ud88e\udc55\ud9f1\udedd\uda28\uddf5\u91dc\ud86f\udd5b\ud8cd\udc12", "\u1658\u566e\u0232\u03eb\ub92b\u0421\ub0bc", "\032\uda49\udefa\ud9f5\uddae\udaca\udd0e\ud97c\uded6\ud8c9\ude96\udabf\uddbe",
        -4, 26621, 1862717284, -7980711104676398772L, 41834L, true, false, (char) 3335, (char) 21322,
        Double.longBitsToDouble(0x3fc2879a212a40f0L), Double.longBitsToDouble(0x3fbad18239e55f98L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.RenameLabels:@?\012",
        Z.run(T, 1, 14, 0, 8, "\ud935\udeff\uea9b\ufc2b\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\uda28\uddf5\u91dc\ud86f\udd5b\ud9d5\udc16", "\u1658\ub193\u60ec\u0479\ub92b\u0421\ub0bc", "\032\uda49\udefa\ud9f5\uddae\udaca\udd0e\ud97c\ude5e\uda4f\udc23\udabf\uddbe\ud868\udfbe\ud97a\udc0f\u2def\ud826\udf02\ud9a9\udf90\udbd8\udf44\udabc\uddd7\ud8ad\ude64\udab9\udd36\uda19\udd8c\udb13\uddf4\uda03\udcf9\udaad\ude47\ud9c0\udc34\uda4d\udf00\ud861\udfc7\ud8ca\udea1\ud97a\udcb0\ud846\udc32\ud8b5\ude85",
        53, 77559, -1563949919, 1919227472427540338L, 39996L, false, false, (char) 46490, (char) 21202,
        Double.longBitsToDouble(0x3fe47b6998201c5aL), Double.longBitsToDouble(0x3fe5943ab0291f9dL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 9, 8, "\ud935\udeff\uea9b\ufc2b\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\uda28\uddf5\u91dc\ud86f\udd5b\ud9d5\udc16", "\u1658\ub193\u60ec\u0479\ub92b\u0421\ub0bc", "\032\uda49\udefa\ud9f5\uddae\udaca\udd0e\ud97c\ude5e\uda4f\udc23\udabf\uddbe\ud868\udfbe\ud97a\udc0f\ud868\udd7b\ud826\udf02\ud9a9\udf90\udbd8\udf44\udabc\uddd7\ud9b7\ude69\udab9\udd36\uda19\udd8c\udb13\uddf4\udae9\udf69\ud994\udf76\udb49\uded2\uda4d\udf00\ud861\udfc7\ud97d\udc1a\ud97a\udd0a\ud866\ude32\ud8b5\ude85",
        53, 77559, -1563949919, 1919227472427540338L, 39996L, false, false, (char) 46490, (char) 21202,
        Double.longBitsToDouble(0x3fe47b6998201c5aL), Double.longBitsToDouble(0x3fe5943ab0291f9dL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 9, 8, "\ud935\udeff\uea9b\ufc2b\udbfa\udd96\ud809\uddc4\udb24\udc9b\ud9f1\udedd\ud9f1\udc7a\u91fa\ud86f\udd5b\ud9d5\udc16", "\u1658\u61b1\uc954\u5f98\u7ab3\u0421\ub071", "\032\uda49\udefa\udb1c\udc01\u90da\ud9ac\ude81\uda4f\udc23\udabf\uddbe\ud868\udfbe\ud97a\udc0f\u2def\ud826\udf02\ud8a7\ude5f\udbc8\udfc4\udabc\uddd7\ud9b7\ude69\udab9\udd36\uda19\udd8c\udb13\uddf4\uda03\udcf9\udaa0\udc6a\ud9c0\udc34\uda4d\udf00\udbcc\udcc0\udb37\udc17\ud885\udd8f\ud833\udf17\ud8b5\ude47",
        53, 77559, 2002524321, 1919227472427540570L, 22246L, false, false, (char) 46292, (char) 21202,
        Double.longBitsToDouble(0x3fd8f6d338fdb612L), Double.longBitsToDouble(0x3fe5969d70291f9dL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.RenameLabels:@?\012",
        Z.run(T, 1, 15, 9, 8, "\ud935\udeff\uea9b\ufc2b\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\uda28\uddf5\ud926\udddc\ud86f\udd5b\ud9d5\udc16", "\u1658\ub193\u6078\u0479\ub92b\u0421\ub0bc", "\032\uda49\udefa\ud9f5\uddae\udaca\udd0e\ud97c\ude5e\uda4f\udc23\udabf\uddbe\ud868\udfbe\ud97a\udc0f\u2def\ud973\udedf\ud9a9\udf90\udbd8\udf44\udabc\uddd7\udadb\udd3b\ud896\udfae\uda19\udd8c\udb13\uddf4\uda03\udcf9\udaad\ude47\ud9c0\udc34\uda6d\ude1f\udb01\ude02\ud97d\udc1a\ud97a\udd0a\ud846\udc32\ud8b5\ude85",
        53, 77559, -1563949919, 1919227472427540338L, 39996L, false, false, (char) 46490, (char) 20189,
        Double.longBitsToDouble(0x3fe829e6e020c3ceL), Double.longBitsToDouble(0x3fe5943ab0291f9dL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 9, 8, "\ud935\udeff\uea9b\ufc2b\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\uda28\uddf5\u91dc\ud86f\udd5b\ud9d5\udc16", "\u1658\ub193\u60ec\u0479\ub92b\u0421\ub0bc", "\032\uda49\udefa\ud9f5\uddae\udaca\udd0e\ud97c\ude5e\uda4f\udc23\udabf\uddbe\ud868\udfbe\ud97a\udc0f\ud93f\udd09\ud826\udf02\ud9a9\udf90\udbd8\udf44\udabc\uddd7\ud9b7\ude69\udab9\udd36\uda19\udd8c\udb13\uddf4\uda03\udcf9\udaad\ude47\ud9c0\udc34\uda4d\udf00\ud861\udfc7\ud97d\udc1a\ud97a\udd0a\ud846\udc32\ud8b5\ude85",
        7, 77559, -1563949919, 1919227472427540338L, 39996L, false, false, (char) 46490, (char) 21202,
        Double.longBitsToDouble(0x3fe47b6998201c5aL), Double.longBitsToDouble(0x3fe5943ab0291f9dL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.RenameLabels:@?\0121=new com.google.javascript.jscomp.RenameLabels:@?\012",
        Z.run(T, 2, 15, 14, 3, "\uda68\udfe7\ud9a1\udf46\uda46\udccc\ud9f7\udcc3\ud919\udf4c\udb48\udf66\udbc0\udd18\udaa2\udc6a\u91dc\ud9ed\udc5f\ud8f0\udd43", "\u1406\u369a\ua449\u0734\u9446\ub66d\u3626\u2099\u5fae\uafce\ub3dd\uca1b\u05eb\u2f44\u6d19\u7262\ub04b\ucf3d\u3125", "\ud8c6\udf1f\ud823\udced\udada\udc84\ud86d\udcb6",
        52, 68252, 181821660, -255331573673030869L, 82852L, true, true, (char) 42488, (char) 64807,
        Double.longBitsToDouble(0x3febd5a167af2eceL), Double.longBitsToDouble(0x3fe772951a840ac6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.RenameLabels:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 13, 12, "\ud9ed\udd29", "\u033c\u5910\u7012\u3267\u898a\u642c\u76d2\ubbbd\u802f\u059d\u30ae\u012f\u0232\ub1da\u6cac\u0421\u580d", "\ud98b\udf89\ud91e\ude37\ud9f5\uddae\ud86a\udd65\ud9ab\udfb3\udb9e\ude72\udabf\uddbe\ud868\udfbe\ud97a\udc0f\udbe7\udcee\ud826\udf02\ud88b\udc82\udbd8\udf48\udabc\uddd7\ud9b7\ude69",
        40, 72349, 71195127, -1610795725583889312L, 32644L, true, true, (char) 14776, (char) 12503,
        Double.longBitsToDouble(0x3fdfb68a6f56a4fcL), Double.longBitsToDouble(0x3fead0db6c73de40L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.RenameLabels:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 9, 8, "\ud9ee\ude21\uda68\udf24\uda01\uded6\u78e4\udaf8\udc0b\udb24\udca5\ud9f1\udedd\udab6\udf3d\udbfc\ude9f\udb46\udfef\uda8c\udf14\ud9b7\ude0d\udad1\udcfe\u482d\udae2\uddbf\uda54\udfce\uda77\udf59\udb6f\udd7d\udbb0\uddc3\uda92\uddf0\ud9a8\udccd\uc8d0\udbf5\udd4a\udac4\udef8\uda09\udea4\ud927\udee0\ud97c\ude5e", "\ud0f4\u11a4\uc2fa\u4044\ub830\u1b08", "\udab9\udd36\uda19\udd8c\ud8f5\udc70\udaa1\udd78\udae8\udc8e\ud91b\ude94\ud937\udc5a\ud862\udc8a\ud97d\udc1a\ud97a\udc9c\ud846\udc32\ud92a\uddff\udbdf\udc7c\ud869\uddcf\udbb8\udd80\uda89\udfae\ud8d9\udf7f\udb50\ude05\udb72\ude85",
        37, 41120, -2050559318, 1251509770767967423L, -31525L, true, true, (char) 46274, (char) 48665,
        Double.longBitsToDouble(0x3fe4679132bb902fL), Double.longBitsToDouble(0x3fdd0d610c6fbae0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.RenameLabels:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 10, 8, "\ud9ed\udd29\ud917\ude5d\ufc2b\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\uda28\uddf5\u91dc", "\ubb37\u738a\u1658\ub193\u0232\u5c8a\ub92b\u0421\ub0bc\u5ee9\u81ac\u6049\ub3dd\u6b26\uc657\u9874\ud53b\u7262\ub04b\u11a4\uc2fa\u8644\u10ff\u1b08\u33ec\u2598\u31c5\u5f73\u1be1\u534a\u00ce\u63f8\u83ba\u05e6\u88ec\u30f8\ucc5e\u51df\u63db\u22f1\u3dc2\u0483\u5c9f\ud559\u24ea\u715d\ucdfa\u6ad7\u4b95\u1bf4\u2a7f\u0f0e\ucb9c\u75ef\u1b23\ub209\ub675\uc141\uac4c\u62ae", "\ud8cd\udf62\ud934\ude9a\udbc7\udfb5\udaf0\udc60\ud88b\ude32\ud955\udd06",
        59, 87580, 856526470, -7777325935196096004L, 84584L, true, true, (char) 44321, (char) 24258,
        Double.longBitsToDouble(0x3fe2b08f4770aa34L), Double.longBitsToDouble(0x3fcb1fb19254c69cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.FunctionToBlockMutator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 9, 8, "\ud9ed\udd29\ud85a\ude7d\udbc8\udd51\udbfa\udcb7\udac5\udee2\udb24\udca5\ud9f1\udedd\ud90e\udf96\uda90\udceb\udadd\udf06\ud9e7\udf70", "\u1658\ub193\u0232\u8ffc\u0eac\u01bf\ub0bc", "\ud8ee\udc10\uda49\udefa\ud8b0\ude0a\udaa3\ude7a\uda4f\udcc6\ud9f3\udf36\udbce\uded3\ud9bd\ude61\uda99\udc85\udad2\udd3d\udbe3\udd02\udade\udd1b\u3221\ud929\udf84\ud982\udcb5",
        22, 71838, -2031606892, 7230373456229123081L, -30256L, false, true, (char) 4251, (char) 46274,
        Double.longBitsToDouble(0x3fe23818909c053dL), Double.longBitsToDouble(0x3fe5288b421f2ce5L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.RenameLabels:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 4, 14, "\ud817\udcde\ud90b\udffe\ufc2b\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\uda28\uddf5\u91dc\ud86f\udd5b", "\u7441\u1658\ub193\u0232\u03eb", "\udba7\udef0\ud960\uded6\udbf3\udd3c\udbea\udf19\uda49\udefa\ud9f5\uddae\udaca\udd0e\ud97c\ude5e\uda4f\udc23",
        7, 12662, 477715253, -2951942195249534583L, 27021L, true, false, (char) 21322, (char) 61695,
        Double.longBitsToDouble(0x3fb2a40f235a3040L), Double.longBitsToDouble(0x3fe9e55f9b6883bfL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 9, 0, "", "", "",
        -5, 22943, 647793815, -8594150602683917450L, -37589L, false, false, (char) 14655, (char) 3900,
        Double.longBitsToDouble(0x3fb16f9cafe6a9d0L), Double.longBitsToDouble(0x3fe806d86d85331bL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.RenameLabels:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 2, 12, "\ud9ed\udd29", "\u033c\u5910\u7012\u3267\u898a\u642c\u76d2\ubbbd\u802f\u059d\u30ae\u012f\u0232\ub1da\u6cac\u0421\u580d", "\ud98b\udf89\ud91e\ude37\ud9f5\uddae\ud86a\udd65\ud9ab\udfb3\udb9e\ude72\udabf\uddbe\ud868\udfbe\ud97a\udc0f\udbe7\udcee\ud826\udf02\ud88b\udc82\udbd8\udf48\udabc\uddd7\ud9b7\ude69",
        40, 72349, 71195127, -1610795725583889401L, 32644L, true, true, (char) 14776, (char) 12503,
        Double.longBitsToDouble(0x3fdfb68a6f56a4fcL), Double.longBitsToDouble(0x3fead0db6873de40L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.RenameLabels:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 5, 12, "\u6c6a", "\u033c\u5910\u4612\ud494\u898a\u4bbf\u4617\ubbbd\u802f\u0648\u30ae\u20b3\u0232\ub1da\u6c2a\u1e58\u580d", "\ud98b\udf89\ud91e\ude37\ud9f5\ude00\ud86a\udd65\ud9ab\udfb3\udb9e\ude72\udabf\uddbe\ud868\udfbe\ud856\udec5\uda52\udfa7\ud826\udf02\ud88b\udc82\udbd3\udc65\udabc\uddd7\ud9b5\ude68",
        40, 72349, 71194927, -1610795725583889312L, 65003L, false, true, (char) 59940, (char) 64114,
        Double.longBitsToDouble(0x3fd17bc21bf6e2feL), Double.longBitsToDouble(0x3fd32b05b34179a4L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.RenameLabels:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 12, "\ud9ed\udd29", "\u033c\u5910\u7012\u3267\u898a\u642c\u76d2\ubbbd\u802f\u059d\u30ae\u012f\u0232\ub1da\u6cac\u0421\u580d", "\ud98b\udf89\ud91e\ude37\ud9f5\uddae\ud86a\udd65\ud9ab\udfb3\udb9e\ude72\udabf\uddbe\ud868\udfbe\ud97a\udc0f\udbe7\udcee\ud826\udf02\ud88b\udc82\udbd8\udf48\udabc\uddd7\udb37\udc67",
        40, 72349, 71195127, -1610795725583889312L, 32644L, true, true, (char) 14776, (char) 12503,
        Double.longBitsToDouble(0x3fdfb68a6f56a4fcL), Double.longBitsToDouble(0x3fead27a5473de40L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.RenameLabels:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 11, 12, "\udbe0\udd63\udba6\ude7f\ufc4c\udbfa\udd96\uda08\udfe4\udb1c\udf8d\ud9f1\udeea\ud9ca\udde6\udba1\udf7f\udb5f\udd95\ud9af\uded3\ue351\ud9f4\ude8f\uda0b\udf76", "\ub1da\u6cac\u9797\u57ca", "\ud98b\udf89\ud91e\ude37\ud9f5\uddae\ud86a\udd65\ud9ab\udfb3\udb9e\ude72\udabf\uddbe\ud868\udfbe\ud97a\udc0f\udbe7\udcee\ud826\udf02\uda80\uddfc\udbd8\udf48\udabc\uddd7\ud9b7\ude69",
        40, 22798, 71195127, 1742888388955655264L, 32644L, true, true, (char) 14776, (char) 41174,
        Double.longBitsToDouble(0x3fda1ba97f56a4fcL), Double.longBitsToDouble(0x3fead0db6ce9b8cbL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.FunctionToBlockMutator:@?\0121=new com.google.javascript.jscomp.FunctionToBlockMutator:@?\012",
        Z.run(T, 2, 12, 12, 10, "\ud817\udcde\ud90b\udffe\udac1\uddcd\udbfa\udd24\uda33\udf79\udb24\udca5\uda68\udde6\uda28\udddf\u91dc\ud86f\udd5b", "\u73c5\u1658\ub193\u0232\u03eb", "\udbd5\uddc6\ud915\ude6e\udbf3\udd3c\udbea\udf19\uda49\udefa\ud9f5\uddae\udba4\udf5b\ud963\udee1\uda4f\udc23",
        28, 14882, -595913938, -2951942195249534583L, 39260L, true, false, (char) 10059, (char) 39066,
        Double.longBitsToDouble(0x3fb2a40f235a3040L), Double.longBitsToDouble(0x3fe9e55f9b6883bfL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.FunctionToBlockMutator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 6, 14, "\udb89\udf3d\ud956\udec3\u2b1d\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\ud92e\udfd8\udb10\ude60\ud86f\udd5b\ud808\ude70\ud841\udd07\udad1\uddb5\u482d\udae2\uddbf", "\u3b85\u0421\u0b71", "\udaad\udeb1",
        7, 29755, -592851399, -6975668042714336552L, -61033L, true, true, (char) 36626, (char) 13785,
        Double.longBitsToDouble(0x3fe8577d682d7372L), Double.longBitsToDouble(0x3fe65b4e89f7a153L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.RenameLabels:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 2, 12, "\ud9ed\udd29", "\u033c\u5910\u7012\u3267\u898a\u642c\u76d2\ubbbd\u802f\u059d\u30ae\u012f\u0232\ub1da\ub4a1\u2420\u580d", "\ud98b\udf89\ud91e\ude37\ud9f5\uddae\ud86a\udd65\ud9ab\udfb3\udb9e\ude72\udabf\uddbe\ud868\udfbe\ud97a\udc0f\udbe7\udcee\ud826\udf02\ud88b\udc82\udbd8\udf48\udaec\udf10\ud9b7\ude3c",
        3, -1000, 0, -1610796627527021561L, 32644L, true, true, (char) 14776, (char) 12503,
        Double.longBitsToDouble(0x3fcf6d14c0000000L), Double.longBitsToDouble(0x3fead0000073de40L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.RenameLabels:@?\0121=new com.google.javascript.jscomp.RenameLabels:@?\012",
        Z.run(T, 2, 15, 15, 12, "\ud9ed\udd29", "\uc543\u58ef\u7012\u3267\u898a", "\udb4c\udf13\ue300\ud8ed\udfed\uda0b\udf76\ud9fe\udcc2\uda54\udfce\ud910\udde6\ud97c\udeb1\udbb0\uddc3\ud8de\udc76\ud960\uded6\udbf3\udd3c\ud98b\udf89\ud91e\ude37\ud9f5\udd86\ud86a\udd65\udbef\udfb5\udb9e\ude72\udbfd\udd3c",
        6, 26621, -1020648348, -7980711104676398772L, -426L, false, true, (char) 3439, (char) 1664,
        Double.longBitsToDouble(0x3fd1c4f03ba4087cL), Double.longBitsToDouble(0x3fb83a696b029cd8L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.FunctionToBlockMutator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 6, 14, "", "\u4b42\u033c\u591b\u8d2a\u325a\ub777\u0473\u76d2\u428e\u56c6\u9fe1\000\u3509\u0a7e\u03eb\u3b85\u0421\u0b71\u7d4a\uca09\u3009\ub402\u6b26\u5457", "\udae7\udf1a\udb93\udf1f\000\000\ud9c8\udfbe\uda81\udca5\ud8b2\udf28\udabc\uddd7\ud9b7\ude69\udab9\udd36\ud9f8\udf9c\ud8c5\udec2\udbc6\udc34\udb63\udc84\ud898\udc1f\uda73\udc31",
        21, 31419, -1935606851, 1757090529433822443L, -34262L, false, false, (char) 15272, (char) 39758,
        Double.longBitsToDouble(0x3fe2bce7a6c2529eL), Double.longBitsToDouble(0x3fea6c18a00e46a4L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 9, 8, "\ud9ed\udd29\ud917\ude5d\ufc2b\udbfa\udd96\ud885\udf82\udb24\udca5\ud9f1\udedd\uda9f\udd51\udb82\udd0a\uda6a\ude70\ud9d5\udc16", "\u1658\ub193\u0232\u03eb\ub92b\u0421\ub0bc", "\032\uda49\udefa\ud9f5\uddae\udaca\udd0e\ud97c\ude5e\uda4f\udc23\udabf\uddbe\ud868\udfbe\ud97a\udc0f\u2def\ud826\udf02\ud88b\udc82\udbd8\udf48\uda4d\udee1\ud9b7\ude7a",
        34, 72543, -1875069804, 5046283698886143083L, 69112L, false, true, (char) 24913, (char) 55709,
        Double.longBitsToDouble(0x3fe0971c3582e031L), Double.longBitsToDouble(0x3fe52889721f2ce5L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.FunctionToBlockMutator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 6, 14, "\udb89\udf3d\ud956\udec3\u2b1d\udbfa\udd96\uda33\udf79\udb24\udca5\ud9f1\udedd\ud92e\udfd8\udb10\ude60\ud86f\udd5b\ud808\ude70\ud841\udd07\udad1\uddb5\u482d\udae2\uddbf", "\u3b85\u0421\u0b71", "\udaad\udeb1",
        7, 29755, -592851399, -6975668042714336552L, -61033L, false, false, (char) 36626, (char) 13785,
        Double.longBitsToDouble(0x3fe8577d682d7372L), Double.longBitsToDouble(0x3fe65b4e89f7a153L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.FunctionToBlockMutator|makeLocalNamesUnique|com.google.javascript.rhino.Node,boolean|new:com.google.javascript.jscomp.FunctionToBlockMutator:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier",
    "M|com.google.javascript.jscomp.FunctionToBlockMutator|addDummyAssignment|com.google.javascript.rhino.Node,java.lang.String|static",
    "M|com.google.javascript.jscomp.FunctionToBlockMutator|aliasAndInlineArguments|com.google.javascript.rhino.Node,java.util.LinkedHashMap,java.util.Set|new:com.google.javascript.jscomp.FunctionToBlockMutator:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier",
    "M|com.google.javascript.jscomp.FunctionToBlockMutator|convertLastReturnToStatement|com.google.javascript.rhino.Node,java.lang.String|static",
    "M|com.google.javascript.jscomp.FunctionToBlockMutator|createAssignStatementNode|java.lang.String,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.FunctionToBlockMutator|fixUnitializedVarDeclarations|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FunctionToBlockMutator:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier",
    "M|com.google.javascript.jscomp.FunctionToBlockMutator|getLabelNameForFunction|java.lang.String|new:com.google.javascript.jscomp.FunctionToBlockMutator:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier",
    "M|com.google.javascript.jscomp.FunctionToBlockMutator|getReplacementReturnStatement|com.google.javascript.rhino.Node,java.lang.String|static",
    "M|com.google.javascript.jscomp.FunctionToBlockMutator|hasReturnAtExit|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.FunctionToBlockMutator|mutate|java.lang.String,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,java.lang.String,boolean,boolean|new:com.google.javascript.jscomp.FunctionToBlockMutator:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier",
    "M|com.google.javascript.jscomp.FunctionToBlockMutator|replaceReturnWithBreak|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,java.lang.String,java.lang.String|static",
    "M|com.google.javascript.jscomp.FunctionToBlockMutator|replaceReturns|com.google.javascript.rhino.Node,java.lang.String,java.lang.String,boolean|static",
    "C|com.google.javascript.jscomp.FunctionToBlockMutator|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier",
    "M|com.google.javascript.jscomp.RenameLabels|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.RenameLabels:com.google.javascript.jscomp.AbstractCompiler",
    "C|com.google.javascript.jscomp.RenameLabels|<init>|com.google.javascript.jscomp.AbstractCompiler",
    "C|com.google.javascript.jscomp.RenameLabels|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier,boolean",
    "M|com.google.javascript.jscomp.FunctionToBlockMutator|makeLocalNamesUnique|com.google.javascript.rhino.Node,boolean|new:com.google.javascript.jscomp.FunctionToBlockMutator:com.google.javascript.jscomp.AbstractCompiler,com.google.common.base.Supplier",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
