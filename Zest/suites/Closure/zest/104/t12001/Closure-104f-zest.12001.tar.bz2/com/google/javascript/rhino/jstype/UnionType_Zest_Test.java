package com.google.javascript.rhino.jstype;
import org.junit.Test;
import static org.junit.Assert.*;
public class UnionType_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\u9904] |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 11, 10, "\u9904", "\ucf80\u997d\uce53\u3341\u0228", "\ud8f3\udc22",
        14, 98633, 1168108448, -5009081417969114918L, -42994L, false, true, (char) 1391, (char) 12003,
        Double.longBitsToDouble(0x3fe90dad7acd0bbfL), Double.longBitsToDouble(0x3fe58ace92395f1bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 10, "\udb53\udd7a\ud88c\udda9\uda17\udc95\ud3b4\ud953\uddcf\ud858\udcc3\udb8c\uddf8\uda44\ude24\udbd5\udc17\uda14\ude21\u57b0\ud8c2\ude79\udb2b\udda2\udaa5\udd80\ud8d9\udeb9\udb33\udfbb", "\u3aae\u20e2\u5760\u24a1\u2dd0\u8814\u260e\u3da6\u8aff\u4ad6\u709f\u1dcd", "\udb03\udf39",
        24, 90949, 1811118804, -3037964472517389774L, -23611L, false, false, (char) 559, (char) 1586,
        Double.longBitsToDouble(0x3fa525464cbd34a0L), Double.longBitsToDouble(0x3fe3f435f5a14c86L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 11, 10, "\u9904", "\ucf80\u98e5\uce53\u3341\u0228", "\ud9f3\udf44",
        35, 12133, -992983061, -5018090524189335334L, -42994L, false, true, (char) 1391, (char) 33423,
        Double.longBitsToDouble(0x3fe9086e47a226bfL), Double.longBitsToDouble(0x3fe546a4c9395f1bL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\u70bc] |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\0121=java.lang.Boolean:false |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 4, 10, "\u70bc", "\u8f80\u997d\uce53\u33b3\u0228", "\udafe\uddb5\uda42\udc20\u27bb\ud954\udfd6\ud8d9\udee4\uda79\uddf9\ud8f0\udc54\udb45\ude12\udbc6\udce5\udbc8\ude56\ud9f2\udf62\ud8ba\ude8e\ud955\udf3f\ud9c7\udce4\udb43\uddfe\uda3b\udcd3\ud83c\udc18",
        49, 55425, -468011308, -2338029867624127104L, 92392L, false, false, (char) 2770, (char) 11889,
        Double.longBitsToDouble(0x3fe1cb9bdadfaff5L), Double.longBitsToDouble(0x3fe8ed5376332dfbL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 11, 13, "\u9904\uda1f\udda2\uda06\udefd", "\uce53\u3341\u0228\u9ec7\u897b\ua07f\u19b3\u3ae1\u0625\u3899\u2e1d\u7c02\u1991", "\ud961\udc1b\ud9da\udf3f\udb3d\udf32\ud9c7\udce4\udb43\uddfe\ud8c8\udfd2\ud83c\udc18\udb58\udc4b\ud896\udfbd\udaab\udc9b\udb88\udef3\udb2f\ude23\udbaf\udfdc\udb36\udc5c\ud9da\udd38\ua7fd",
        28, 8948, 1360465442, -4862440170542916415L, 2496L, true, false, (char) 16084, (char) 18306,
        Double.longBitsToDouble(0x3fe0f7f9f6cf9f79L), Double.longBitsToDouble(0x3fd2f0805d44e3c6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\u9904] |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\012",
        Z.run(T, 1, 7, 11, 10, "\u9904", "\ucf80\u997d\uce53\u3341\u0228", "\ud8f3\udc22",
        14, 98633, 1168108448, -5009081417969114918L, -42994L, false, true, (char) 1391, (char) 12003,
        Double.longBitsToDouble(0x3fe90dad7acd0bbfL), Double.longBitsToDouble(0x3fe58ace92395f1bL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\u9904] |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 2, 10, "\u9904", "\ucf80\u997d\uce53\u3341", "\ud8df\udc89",
        15, 96303, -473438254, 5015722030406576893L, 15286L, true, true, (char) 49847, (char) 57947,
        Double.longBitsToDouble(0x3fd4641c495f337eL), Double.longBitsToDouble(0x3fd9e7a306789072L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\u9904\uda1f\udda2] |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 9, 10, "\u9904\uda1f\udda2", "\ua4be\u6d4d\uaff9\u0228\u390e\u27e1\u9e51\u19b3\u621e\u0625\u3899\ud7e4", "\udbc6\udce5\udbc8\ude56\ud9f2\udf62\ud8ba\ude8e\ud955\udf3f",
        38, 28352, 197104417, 6472388229153391281L, 95247L, true, false, (char) 31327, (char) 41176,
        Double.longBitsToDouble(0x3fe2b15c895a6ed5L), Double.longBitsToDouble(0x3fc75fd9a1bab5fcL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 10, 11, 10, "\u9904\ud9f9\udd54\ud8d6\ude15\udbf0\uded4\ud953\ude39\ud95a\udfe4\udb8c\uddf8\uda44\ude24\ube06", "\u19b3\u621e\u0625\u3899", "\ud983\udee9\udbfe\udf03\udbc8\ude56\ud9f2\udf62\ud8ba\ude8e\ud955\udf3f\ud9c7\udce4\udb43\uddfe\ud8c8\udfd2\uda01\udd7b\udbd0\udf30\ud911\udefa\ud8eb\uddaf",
        6, 79711, -786143499, 2805639951122502483L, 19353L, false, true, (char) 26985, (char) 5704,
        Double.longBitsToDouble(0x3fea580a84ef5996L), Double.longBitsToDouble(0x3fe93c44cdb76313L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\udbf2\udd43] |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 0, 2, "\udbf2\udd43", "\ucf80\u997d\uce53\u8e41\uc27a", "\ud8f3\udc22",
        14, 98633, 1170643872, -5009081417969114918L, -42994L, false, true, (char) 1391, (char) 12003,
        Double.longBitsToDouble(0x3fe90dad7acd0bbfL), Double.longBitsToDouble(0x3fe58ace919aabf6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 12, 10, "\u9904", "\ucf80\u997d\uce53\u5a6e\ua3a1\u9ec7\u897b\u7eb9\u19b3\u621e\u0625\u3899\ud7e4\u596e", "\udbc8\ude56\ud9f2\udf62",
        12, 95334, 344156967, -5355032432103943391L, -57156L, true, false, (char) 33599, (char) 61086,
        Double.longBitsToDouble(0x3fd1d6d2328c32c2L), Double.longBitsToDouble(0x3fec44c1015cc41cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\u9904] |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 6, 11, "\u9904", "\ucf80\u997d\ua11c\u3380\u0228", "\udb4c\udfd2\udb98\udce5\ud900\ude2b\ud971\udfba\ud8d9\udee4",
        40, 33374, -662980505, -5827308643702518116L, -62031L, false, false, (char) 18640, (char) 38539,
        Double.longBitsToDouble(0x3fe58ace92395f1bL), Double.longBitsToDouble(0x3fd5b86096d87bd6L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 15, 10, "\udba3\udf7a", "\ucf80\u9aed\ucdea\u7ca1\u90ab\u9ec7\u897b\u7eb9\u4c27\u9fd0\u34b7\u9806\u2c74\u2677\u3e8b\ua070", "\ud8d2\udeb5\ud955\udf3f\ud9c7\udce4",
        47, 40233, 1546262382, 6853214954806786617L, 85285L, true, true, (char) 18527, (char) 13967,
        Double.longBitsToDouble(0x3fe42005d0c5c920L), Double.longBitsToDouble(0x3fd9070975052fd4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 14, 11, 15, "\u9904\uda1f\udda2\ud8d6\ude15\ud83e\uddba", "\u3341\u0228", "\ud8f3\udc22",
        14, 98633, 1168108448, -5009081417969114918L, -42994L, false, true, (char) 1391, (char) 12003,
        Double.longBitsToDouble(0x3fe90dad7acd0bbfL), Double.longBitsToDouble(0x3fe58ace923983bdL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 1, 11, 10, "\u9904", "\ucf80\u997d\u36b0\u3341\u0228", "\ud93e\udc2c",
        14, 98633, 1168108448, -5009081417969114918L, -42994L, false, true, (char) 1391, (char) 12003,
        Double.longBitsToDouble(0x3fe90dad7acd0bbfL), Double.longBitsToDouble(0x3fe58ace92395f1bL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\udba8\ude9a\uda83\udfae\ud9da\udd73\udbac\uddb1\ud969\ude70\ud88e\udd4d\udb3c\udd09\udaf4\udfe3\ud834\udd84\ud8f4\udf7f\ud8f3\udc22\udb84\ude98\ud86a\udd31\ud86b\udf9d\ud8ed\udceb] |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 5, 13, "\udba8\ude9a\uda83\udfae\ud9da\udd73\udbac\uddb1\ud969\ude70\ud88e\udd4d\udb3c\udd09\udaf4\udfe3\ud834\udd84\ud8f4\udf7f\ud8f3\udc22\udb84\ude98\ud86a\udd31\ud86b\udf9d\ud8ed\udceb", "\u1d56\ub1cf\u535c", "\ud805\udd7f\udbb7\udcbd\udb45\udd1c\ud8c8\udfd2\ud83c\udc18\ud90a\udd45\udb34\udd36\ud8dc\udd65\ud89a\udde5\ud888\udfc5\uda22\ude98\udb0c\udf2f\udb84\udc48\udbfc\uddfb\ud919\udef2\ud858\udc18\uda33\ude6f\ud8ab\uddae\ud9d6\ude27\ud91b\udf10\ud975\udf20\udb8f\uddf4\udaa6\ude15\ua278\ud9c4\udc08\uda9f\udce4\u8e79\ud9f3\ude8a\udb44\udca0\ud842\udf3a\ud936\ude9a\ud9d6\udf1e\ud850\udf07\ua470\udaa7\ude3f\ud984\udfaf\ud974\udeb5",
        41, 76821, 1632379512, 1712113501797083565L, 70410L, true, true, (char) 50791, (char) 19782,
        Double.longBitsToDouble(0x3fcbfc08b0b06954L), Double.longBitsToDouble(0x3fc05b7094fa636cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 12, 11, 10, "\u9904", "\u8cb2\u997d\u0e82\u33c2\u7a60", "\ud8a4\udf3c",
        -1, 98633, -1936069728, -5009082467558146180L, -43063L, true, false, (char) 8613, (char) 44841,
        Double.longBitsToDouble(0x3fe90dad7acd0bbfL), Double.longBitsToDouble(0x3fdb159d2472be36L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\udbae\udf04] |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 12, 10, "\udbae\udf04", "\ucf80\u997d\uce53\u3341\u0228", "\ud8f3\udc22",
        14, 98633, 1168108448, -2843049390039772731L, -14236L, true, true, (char) 59581, (char) 49793,
        Double.longBitsToDouble(0x3fe5701d704641c4L), Double.longBitsToDouble(0x3fed7ccdfa601483L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 13, 15, 10, "\u9904", "\ucf80\u997d\uce53\u3341\u0228", "\ud8f3\udc91\udb84\ude98\ud8de\udfbd\udbb5\udf5e",
        23, 84605, 1367034759, -2847479587160375894L, 28213L, false, false, (char) 53001, (char) 1391,
        Double.longBitsToDouble(0x3fe300a41b21b5afL), Double.longBitsToDouble(0x3fe6685dfab159d2L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 11, 12, "\udaae\udcc7\uda1f\udda2\udbe0\udc5b\uda25\udfbe\udab5\uddce\udb63\udcfe\u3418\ud9e7\ude06\ud9c7\udf93\ud925\ude33\uda98\udd5b\ud905\ude96", "\uc8da\uce87", "\udbc6\udce5\ud900\ude52\uda41\udd1a\ud8ba\ude8e\ud962\udc3f\ud9c7\udce4\ud951\udf6f\ud836\udc26\ud83c\udc18\ud883\ude7f\udb39\udf2c\ud8f7\udfc0\ud842\udc43\ud8b8\udc5a\ud816\udce6\ud829\udf50\uda2d\udfb3\ud87b\udeb3\ud9de\udd64\ud838\udd99\ud95f\udee4\uda47\udf67\udb18\udeac\ud960\udfda\udb67\uddfa\ud8c2\udecb\ud9b3\udc2e\ud840\udc02\udabb\udf55\uda31\udfa5\uda95\udff5\uda59\udcef",
        1, 26897, 399884352, 8230231325373481964L, -53691L, false, false, (char) 24055, (char) 8304,
        Double.longBitsToDouble(0x3fe718ff01a22c17L), Double.longBitsToDouble(0x3fbb3bb83208ec48L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 11, 10, "\ud99c\udcdc", "\ucf80\u997d\uce53\u3341\u0228", "\ud8f3\udc22\uda80\udcf5\ud9c3\ude4a\ud88b\udeb4",
        4, 84778, -440644729, -2847479914634854998L, 28213L, false, false, (char) 53001, (char) 1391,
        Double.longBitsToDouble(0x3fe300a41b21b5afL), Double.longBitsToDouble(0x3fe6685dfab159d2L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\ud824\udd02] |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 1, 6, "\ud824\udd02", "\u6ad9\u146e\uce53\u7c6d\ua800\ub20b\u897b\u97e4\u19b3\ua970\u05d3\u2399\u6d94\u0f6a\ub4b1\u15d1", "\ud986\ude6c\ud8c9\udf41\ud993\udc2a\uda1d\ude51\u4b24\uda4c\udfd4\udb60\udf1a\ud8f7\ude6d\ud9de\udccf\u4ed1\ud801\udebb\udb7d\uddbf\u5e57\uda90\ude28\ud898\udef3\ud806\udfed\ud907\ude72\ud8aa\udca5\udbae\udf60",
        50, 28181, -1001282318, -7785292757624380426L, -2962L, false, true, (char) 56100, (char) 50301,
        Double.longBitsToDouble(0x3fe4c5eda380bc40L), Double.longBitsToDouble(0x3fd0ddec34acfa98L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\uda08\udccd] |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 10, 10, "\uda08\udccd", "\u42c3\ua3e4\ucdbe\u3341\u0228", "\ud8f3\udc22",
        -4, 98633, 1168108448, -5009081419981332262L, -42994L, false, true, (char) 1391, (char) 39395,
        Double.longBitsToDouble(0x3fe90dad7acd0bbfL), Double.longBitsToDouble(0x3fe58ace92395f1bL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\u9904\uda1f\udda2\ud8d6\ude15\ud83e\uddba\ud953\ude58\ud95a\udfe4\udb45\udd54\ud8c2\udf72\udbf1\ude08\udbce\ude56\ud8f3\udc14\udb84\ude98\ud900\ude2b\ud971\udfba\ud8d9\udee4\uda79\uddf9\ud8f0\udc54] |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 14, 10, "\u9904\uda1f\udda2\ud8d6\ude15\ud83e\uddba\ud953\ude58\ud95a\udfe4\udb45\udd54\ud8c2\udf72\udbf1\ude08\udbce\ude56\ud8f3\udc14\udb84\ude98\ud900\ude2b\ud971\udfba\ud8d9\udee4\uda79\uddf9\ud8f0\udc54", "\u20bd\u6f87", "\ud9b6\uddbe\udb43\uddfe\ud8c8\udfd2\ud83c\udc18\udb58\udc4b\ud8aa\udda5",
        8, 41260, 2142255135, -4500902100947355354L, -44744L, true, true, (char) 55375, (char) 49318,
        Double.longBitsToDouble(0x3fdfc8f49a6429fcL), Double.longBitsToDouble(0x3fdc29edf91cc486L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\u9904] |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 13, 10, "\u9904", "\u3885\u997d\uce53\u3347\u0228", "\ud8ef\ude18",
        14, 98633, 1168108448, 7736387002466099418L, 67030L, false, true, (char) 13867, (char) 40247,
        Double.longBitsToDouble(0x3fe097f83a8cb45cL), Double.longBitsToDouble(0x3fe90dad7acd0bbfL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\0121=java.lang.Boolean:false |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\012",
        Z.run(T, 2, 4, 4, 10, "\ud99f\udeaf", "\u8f80\u997d\u5d7a", "\ud874\ude47",
        22, 45549, 943300570, 6901107006604486956L, 3473L, false, false, (char) 819, (char) 63159,
        Double.longBitsToDouble(0x3fe7b8e4388fe1c8L), Double.longBitsToDouble(0x3fd447cbdafbad0aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.NullPointerException\0121=null |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 7, 13, "\udb09\udd46\ud9dc\udc60\uda06\udefd\ud89d\udc0a\uf654\ud95a\udfe4\udb8c\uddf8\uda44\ude24\ube06\ud8df\udc89\ud8ae\udde1\udb84\ude98\udbdf\udefa", "\u2e1d\u0248\u39e5\u50d6\u1e9a", "\udb3d\udf32\ud9c7\udce4\udb43\uddfe\ud8c8\udfd2\ud83c\udc18\udb58\udc4b\ud896\udfbd\udaab\udc9b\udb88\udef3\udbef\udc62\udbaf\udfbe\uf2c0\udbcd\udc20\uda95\uddf7",
        28, 8948, 1360465442, -4862440170542916415L, 2496L, true, false, (char) 49231, (char) 18306,
        Double.longBitsToDouble(0x3fe0f7f9f6cf9f79L), Double.longBitsToDouble(0x3fd2f0805d44e3c6L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 10, 13, "\udb84\ude71\ud88e\udef0\uda24\udda5", "\u84de\u3341\u0228\u9ec7\u897b\ua07f\u19b3\u3ae1\u0625\u3899\u2e1d\u7c02\u1991", "\ud961\udc1b\ud9ab\udf3f\udb3d\udf32\ud9cd\udfe4\ud9bc\udf68\udb16\udeb1\u8bcb\ud961\uddda\ud896\udfbd\udbe5\uded8\udb62\ude56\udb2f\ude23\udbaf\udfdc\udb36\udc5c\ud9da\udd38\ua7fd",
        28, 8948, 1360465442, -4862440170542916415L, 2496L, true, false, (char) 16084, (char) 18306,
        Double.longBitsToDouble(0x3fe0f7f9f6cf9f79L), Double.longBitsToDouble(0x3fdb1816ed44e3c6L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 0, "\u9904\uda1f\udda2\uda06\udefd", "\uce53\u8019\u0228\u9ec7\u9a12\u00ca\u19b3\u3ae1\u0625\u3899\u2e1d\u7c02\u1991", "\ud961\udc1b\ud9da\udf3f\udb3d\udf32\ud9c7\udce4\udb43\uddfe\ud8c8\udfd2\ud83c\udc18\udb22\udc50\ud896\udfbd\udaab\udc9b\udb88\udef3\udb2f\ude23\udbaf\udfdc\udb36\udc5c\ud9da\udd38\ua7fd",
        28, 8948, 1360465442, -4862440170542916415L, 2496L, true, false, (char) 16084, (char) 30349,
        Double.longBitsToDouble(0x3fe0f7f9f6cf9f79L), Double.longBitsToDouble(0x3fd2f0805d44e3c6L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\u9904] |this=com.google.javascript.rhino.jstype.UnionType:!toString:java.lang.ClassCastException\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 11, 10, "\u9904", "\ucf80\u997d\uce53\u3341\u0228", "\ud8f3\udc22",
        14, 98633, 1168108448, -5009081417969114918L, -26477L, true, false, (char) 64957, (char) 49847,
        Double.longBitsToDouble(0x3fe5701d754641c4L), Double.longBitsToDouble(0x3fed7ccdfa601483L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.rhino.jstype.UnionType|meet|com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
    "M|com.google.javascript.rhino.jstype.UnionType|canAssignTo|com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
    "M|com.google.javascript.rhino.jstype.UnionType|canBeCalled||new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
    "M|com.google.javascript.rhino.jstype.UnionType|contains|com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
    "M|com.google.javascript.rhino.jstype.UnionType|equals|java.lang.Object|new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
    "M|com.google.javascript.rhino.jstype.UnionType|findPropertyType|java.lang.String|new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
    "M|com.google.javascript.rhino.jstype.UnionType|forgiveUnknownNames||new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
    "M|com.google.javascript.rhino.jstype.UnionType|getAlternates||new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
    "M|com.google.javascript.rhino.jstype.UnionType|getLeastSupertype|com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
    "M|com.google.javascript.rhino.jstype.UnionType|getPossibleToBooleanOutcomes||new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
    "M|com.google.javascript.rhino.jstype.UnionType|getRestrictedTypeGivenToBooleanOutcome|boolean|new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
    "M|com.google.javascript.rhino.jstype.UnionType|getRestrictedUnion|com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
    "M|com.google.javascript.rhino.jstype.UnionType|getTypesUnderEquality|com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
    "M|com.google.javascript.rhino.jstype.UnionType|getTypesUnderInequality|com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
    "M|com.google.javascript.rhino.jstype.UnionType|getTypesUnderShallowInequality|com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
    "M|com.google.javascript.rhino.jstype.UnionType|hashCode||new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
    "M|com.google.javascript.rhino.jstype.UnionType|meet|com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.rhino.jstype.UnionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.util.Set",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
