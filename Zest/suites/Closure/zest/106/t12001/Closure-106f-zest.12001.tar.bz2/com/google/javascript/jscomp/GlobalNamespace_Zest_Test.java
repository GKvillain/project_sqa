package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class GlobalNamespace_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.GlobalNamespace:@?\012",
        Z.run(T, 1, 9, 9, 3, "\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\ud96d\udc1c\uda73\udfcf\ud929\udde5\ud911\udfd0\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8de\udc80\udba2\ude62", "\u0302\u504d\u6034\ub49c\u9654\ub3d6\u0434\u3323\u9dd7\uc144\ub7a7", "\udb04\uded0\ud930\udc0a\ud9d7\udfd5\uda2f\udee9\uda45\udec6\ud91b\uddb4\udb1e\udeb7\udbd1\udd2d\uda28\udcbd\ud80a\udfac",
        43, 51442, 1699808095, 3525879201897048847L, 90989L, true, false, (char) 61133, (char) 60420,
        Double.longBitsToDouble(0x3fd1024fdeda49caL), Double.longBitsToDouble(0x3fdc51b3b61525beL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.GlobalNamespace:@?\012",
        Z.run(T, 1, 9, 9, 3, "\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\ud96d\udc1c\udbc3\ude97\ud929\udde5\ud947\udcd2\udbea\ude36\ud8e4\udf32\uda55\udf01\udb54\uddb4\ud8e9\ude7e\udba2\ude62\ud964\ude15\udafe\udd6a\ud982\udd04\ud9cb\ude84\ud8d3\udc8a\ud86d\udcd1\udad0\udc24\ud8a8\ude1b\ud8aa\udc36\udade\udc5f\ud893\udcf4\udbf7\udf87\ud898\udc48\ud8f0\udd1a\ud97c\udfae\udb04\uded0\uda28\uddad", "\u00f6\u2a9e\u11e7", "\ud80a\udfac\ud962\udfa9\ud916\ude6b\ud9f4\udd57\ud8a2\udf56\udab0\udf69\u3e6d\ud962\udce1",
        53, 31981, 620622268, 2658611488557361005L, -61866L, false, false, (char) 62033, (char) 10866,
        Double.longBitsToDouble(0x3fb694ce0400f4e0L), Double.longBitsToDouble(0x3fd468533d88ff8cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 1, 0, 9, 3, "\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\ud96d\udc1c\uda73\udfcf\udb78\udee9\ud911\udfd0\uda38\udc2f\ue7d1\ud9ec\udc06\udac2\udffc\ud8de\udc80\udba2\ude62", "\u0302\u504d\u6034\ub49c\u9654\ub3d6\u0434\u6613\u9dd7\u3144\ub7a7", "\ud895\uded8\ud93c\udf7a\ud9d7\udfd5\ud883\udf53\uda3d\udfda\ud91b\uddb4\udb1e\udeb7\udbd1\udd2d\uda28\udcbd\ud80a\udfac",
        43, 51442, 1699808095, 3525879201897048847L, -28845L, true, false, (char) 61133, (char) 60420,
        Double.longBitsToDouble(0x3fd1024fdeda49caL), Double.longBitsToDouble(0x3fdc51b3b61525beL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.GlobalNamespace:@?\0121=new com.google.javascript.jscomp.GlobalNamespace:@?\012",
        Z.run(T, 2, 9, 9, 3, "\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\udaa5\udd18\uda73\udfcf\ud929\udde5\ud911\udfd0\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8de\udc80\ud826\udd7f", "\u0302\u504d\u6034\ub49c\u7034\ub370\u0434\u3323\u9dd7\uc144\ub7a7", "\ud9e7\udc66\ud930\udc0a\ud92b\udee0\uda2f\udf2d\udbca\udd08\ud9f4\udf3a\udb6d\udf3c\ud8b1\udf71\uda24\udc5d\ud80a\udfac",
        41, 51442, 1699808095, 3525879201897048847L, 90989L, true, false, (char) 61133, (char) 60420,
        Double.longBitsToDouble(0x3fd1024fdeda49caL), Double.longBitsToDouble(0x3fdc51b3b61525beL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 9, 3, "\ud848\udf9c", "\u538f\u52bf", "\ud929\udde5\ud911\udfd0\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc",
        4, 5403, -223096098, -2887915369856297274L, 22333L, false, false, (char) 15540, (char) 11367,
        Double.longBitsToDouble(0x3fe4c645bab17791L), Double.longBitsToDouble(0x3fe00834a71bd896L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 1, 12, 9, 3, "\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\ud96d\udc1c\uda73\udfcf\ud929\udde5\ud911\udfd0\ud9d6\udcdf\udb2a\ude4d\ud9eb\udfcc\ud86b\udf2f\ud9a3\udf98\ud8a0\udcb3", "\u0302\u4fda\u6034\u95e9\u9b24\ub3d6\u0434\u3323\u9dd7\uc144\ub7a7", "\udb04\uded0\ud930\udc0a\ud9d7\udfca\uda2f\udee9\ud980\udc03\ud91b\udd85\udb1e\udeb7\udbd1\udd2d\uda28\udcbd\ud80a\udfac",
        43, 5234, 1699808095, 3525879201897048847L, 90989L, true, false, (char) 61133, (char) 60420,
        Double.longBitsToDouble(0x3fd1024fdeda49caL), Double.longBitsToDouble(0x3fdc51b3b61525beL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 1, 15, 10, 3, "\ud9f9\udcbc\uda79\udc70\udaa0\udceb\ud92b\udcd9\ud921\udfa3\ud96d\udc1c\uda73\udfcf\ud929\udde5\ud911\udfd0\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8de\udc80\udba2\ude62", "\u0302\u504d\u6034\ub49c\u1365\ub3d6\u5fc3\u51dc\u9dd7\uc144\ub7a7", "\uda33\udfae\u2b78\udaf8\ude0f\uda2f\udeea\uda45\udec6",
        35, 57588, -2045131683, 9087174773207981316L, 68306L, true, false, (char) 33084, (char) 7165,
        Double.longBitsToDouble(0x3fe4583014ee2d03L), Double.longBitsToDouble(0x3fe4a8ea242582a8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 9, 3, "\udafa\udf74\ud974\udce3\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\ud96d\udc1c\uda73\udfcf\ud929\udde5\ud911\udfd0\u99e8\ud960\udf91\udad3\uddfa\udac2\udff9\uda8e\udc78\udba2\ude62", "\u5e7e\u504d\u1e5e\u642e\ud006\ub3d6\uc3dd\u3323\u9dd7\uc144\ub7a7", "\udb04\uded0\ud930\udc0a\ud9d7\udfd5\uda2f\udee9\uda45\udec6\ud91b\uddb4\udb1e\udeb7\udbd1\udd2d\uda28\udcbd\uda86\udd35",
        36, 51442, 1699808095, 3525879201897048847L, 90989L, true, false, (char) 61226, (char) 60420,
        Double.longBitsToDouble(0x3fd1024fdeda49caL), Double.longBitsToDouble(0x3fdc51b3b61525beL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\ud950\udddd\uda73\udfcf\ud929\udde5\ud911\udfd0\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8de\udc80\udba2\ude62 |this=com.google.javascript.jscomp.GlobalNamespace:@?\012",
        Z.run(T, 1, 3, 6, 3, "\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\ud950\udddd\uda73\udfcf\ud929\udde5\ud911\udfd0\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8de\udc80\udba2\ude62", "\u0282\u504d\u6034\ub49c\u9654\ub3d6\u8434\u2876\u9dd7\uc144\ub7a7", "\udb04\uded0\ud930\udc0a\ud9d7\udfd5\uda2f\udee9\udabf\ude43\ud94b\udfe6\udb1e\udeb7\udbd1\udd2d\uda28\udcbd\ud80a\udfac",
        43, 51442, 1699808095, 3525879201897048847L, 90989L, true, true, (char) 19891, (char) 53259,
        Double.longBitsToDouble(0x3fd1024fdeda49caL), Double.longBitsToDouble(0x3fdc51b3b61525beL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 1, 14, 9, 3, "\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\ud96d\udc1c\uda73\udfcf\ud8b1\udc4c\ud911\udfd0\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8de\udc80\udba2\ude62", "\u0302\u504d\u6034\ub49c\u9654\ub3d6\u0434\u3323\u9dd7\uc144\ub7a7", "\udb04\uded0\ud930\udc0a\ud9d7\udfd5\uda2f\udee9\uda45\udec6\ud91b\uddb4\udb1e\udeb7\udbd1\udd2d\uda28\udcbd\ud80a\udfac",
        43, 51442, 1699808095, 3525879201897048847L, 90989L, true, false, (char) 61133, (char) 60420,
        Double.longBitsToDouble(0x3fd1024fdeda49caL), Double.longBitsToDouble(0x3fdc51b3b61525beL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 9, 3, "\ud9f9\udcc0\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\ud96d\udc1c\uda74\udc17\ud929\udde5\ud8f5\uded0\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8f7\udeb6\udb85\udf3a", "\u0302\u5033\u6034\ub49c\u9654\ub3d6\u0434\u3323\u9dd7\uc144\u4b69", "\ud8e8\uddb4\uda9e\udda1\ud9c3\udc9e\udb7a\udcc6\uda45\udec6",
        46, 57588, -2045131683, 9087174773207981316L, 68306L, true, true, (char) 54725, (char) 7165,
        Double.longBitsToDouble(0x3fe4583015f3fe03L), Double.longBitsToDouble(0x3fe4ad4fec2582a8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 1, 13, 9, 2, "\ud9f9\udcbc\uda79\udc70\ud8fc\udc8f\udb1d\ude28\u1357\ud9a6\udc53\ud984\udc57\ud929\ude5f\ud911\udfd0\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8de\udc80\udba2\ude62", "\u0302\u504d\u40b8\u9c43\ua89d\u5a17\u555b\u66b1\u9e36\u2cdd\uc8f1", "\udb04\uded0",
        20, 53447, -1528449976, 1163465628494601067L, 46339L, true, true, (char) 25888, (char) 13284,
        Double.longBitsToDouble(0x3fd720c386bf118cL), Double.longBitsToDouble(0x3fbd195458798770L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 3, "\udbd5\udd8b\udbdb\udf4c\udb34\uddb9\udb1d\udeca\ud921\udfa3\udaa4\udc38\uda73\udfcf\udaf5\udf02\ud928\udd09\u5e04\ud960\udf91\udb2f\udfd1\udb9a\udd88\udb7a\udff1\udba2\ude62", "\u9b39\u6c27\u2c65\ub49c\u42c1\ubf12\u8617\u1bf8\u8d9f\ub1ea\u82b1", "\udadb\uddd5\udb6c\udd11\udb40\ude8a\udad2\udd39\ud850\udf76\udb85\udf20\udb1e\udeb7\udbd1\udd2d\uda28\udcbd\ud810\udfac",
        43, 50770, 1699808211, 3525879201897048847L, 90989L, true, false, (char) 61133, (char) 60420,
        Double.longBitsToDouble(0x3fd1024fdeda49caL), Double.longBitsToDouble(0x3fdc51b3b61525beL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 1, 0, 9, 0, "\ud8c6\udc20\ud950\ude59\ud8e7\udc8f", "\ua9b7\u0c8e", "\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8de\udc80\udba2\ude62\ud964\ude15\ud94b\udde9\ud982\udd04\ud9cb\ude84\ud8d3\udc8a\ud86d\udcd1\udad0\udc24\ud8a8\ude1b\ud8aa\udc36\udade\udc5f\uda3f\udc8a\uda85\udc22\ud898\udc48\udbed\udccb",
        15, 46987, -2075171102, 3173749739500188744L, -92981L, false, false, (char) 5038, (char) 42856,
        Double.longBitsToDouble(0x3fd047e1c5e2e1e6L), Double.longBitsToDouble(0x3fc6eb2de11a0d48L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 9, 3, "\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\ud96d\udc1c\uda73\udfcf\ud929\udde5\ud911\udfd0\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8de\udc80\ud99c\udc69", "\u0302\u504d\u6034\ub49c\u9654\ub3d6\u0434\u3323\u9dd7\uc144\ub7a7", "\udb04\uded0\ud930\udc0a\ud9d7\udfd5\uda2f\udee9\uda45\udec6\ud91b\uddb4\udb1e\udeb7\udbd1\udd2d\uda28\udcbd\ud80a\udfac",
        16, 90192, 1699808095, -5236718300000657465L, 90989L, true, false, (char) 61133, (char) 60420,
        Double.longBitsToDouble(0x3fd1024fdeda49caL), Double.longBitsToDouble(0x3fdc51b3b61525beL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 9, 3, "\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\udb62\ude17\udb05\udde5\ud91c\udee7\ud947\udcd2\udbea\ude36\ud8e4\udf32\uda55\udf01\udb54\uddb4\ud8e9\ude7e\udba2\ude62\ud964\ude15\udafe\udd6a\udb57\udccd\ud9af\udfb2\ud863\uddc0\ud86d\udcd1\udad0\udc24\ud8a8\ude1b\ud8aa\udc36\u9c4c\ud88a\ude5d\udbf7\udf4b\ud898\udc48\ud8f0\udd1a\ud97c\udfae\uda8a\uded3\ud955\ude24", "\u00f6\u8146\u5e16", "\ud80a\udfac\ud962\udfa9\ud916\ude6b\ud9f4\udd57\ud8a2\udf56\udab0\udf69\udaa9\ude79\ud962\udce1",
        53, 31981, 620622268, 3667417805088352099L, -61866L, true, false, (char) 62033, (char) 10866,
        Double.longBitsToDouble(0x3fb694ce0400f4e0L), Double.longBitsToDouble(0x3fd669bced88ff8cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.GlobalNamespace:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 5, "\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\ud9fe\udf85\ud856\udcdf\udafc\ude78\udada\udf72\udbea\udda8\ud8e4\udf32\uda55\udf01\udb54\uddb4\ud8e9\ude7e\udba2\ude62\ud964\ude15\udafe\udd6a\ud982\udd04\ud9cb\ude84\udb15\udf8b\ud95a\udd78\ud81d\udf21\ud8fc\udd59\uda70\udd4d\ud8c7\udfd9\ud893\udcf4\udbf7\udf87\ud898\udc48\udac9\udea6\udb86\uddec\udbe2\udf05\udb09\udf3a", "\u00f6\u2a9e\u11e7", "\ud80a\udfac\udb75\udcb2\ud8f7\ude44\ud9f4\udd57\udbc3\udd07\udab0\udf69\u3e6d\ud98e\udee1",
        53, 31981, 609576543, 2658611487282292589L, -16911L, false, false, (char) 20736, (char) 63921,
        Double.longBitsToDouble(0x3fb694d70400f4e0L), Double.longBitsToDouble(0x3feb46f99ec47f2cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 1, 0, 9, 3, "\ud9f9\udcbc\uda79\udc70\ud8b0\ude45\udbab\udffe\uc5c5\udbd0\udfa0\udb1d\udc5f\ud9a4\udeca\ud81c\udd42\udbea\udde1\ud8e4\udf32\uda55\udf01\udb54\uddb4\udb8f\udc31\ud9e4\udd01\ud88b\udda0\ud81c\udec8\ud982\udd04\ud9cb\ude84\ud8d3\udc8a\ud86d\udcd1\udad0\udc24\ud8a8\ude1b\ud8aa\udc36\udade\udc5f\ud893\udcf4\udbf7\udf87\udbc9\udce0\udab5\udce7\ud976\ude50\uda82\udc5f\uda28\uddad", "\u00f6\u2a9e\u11e7", "\ud861\udf79\ud96e\udde8\ud916\ude6b\ud9f4\udd57\ud8a2\udf56\udab0\udf69\u3e6d\ud962\udce1",
        53, 31981, 620622268, 2658611488557323885L, -61866L, false, false, (char) 62033, (char) 10866,
        Double.longBitsToDouble(0x3fb694ce0400f4e0L), Double.longBitsToDouble(0x3fd468533d88ff8cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 1, 12, 9, 3, "\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\ud8a5\udd0c\ud921\udfa3\ud96d\udc1c\udbc3\ude97\ud929\udde5\ud947\udcd2\udbea\ude36\ud8e4\udf32\uda55\udf01\udbfd\ude01\udb39\udd8e\udba2\ude62\ud964\ude15\udafe\udd6a\ud982\udd04\ud9cb\ude84\ud8d3\udc8a\ud86d\udcd1\uda25\udde8\udaf8\udf8b\ud8d1\udc32\ud81b\udf53\ud893\udcf4\udbf7\udf87\ud898\udc48\ud8f0\udd1a\ud992\uddae\udb04\uded0\ud905\udde1", "\u00f6\u2a9e", "\uda28\udcbd\udb16\udc92\ud962\udfa9\ud916\ude6b\ud9f4\udd57\ud8a2\udf56\udab0\udf69\u3e6d\ud962\udce1\udbe2\uddd2",
        31, 77268, 619006224, -6176713910408725051L, 23740L, false, false, (char) 29041, (char) 15250,
        Double.longBitsToDouble(0x3fc003d3851a14ccL), Double.longBitsToDouble(0x3fe623fe35964b3aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 1, 11, 9, 3, "\ud9f9\udcbc\uda10\udc7c\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\ud96d\udc1c\udbc3\ude97\ud929\udde5\ud947\udcd2\udbea\ude36\ud8e4\udf32\uda55\udf01\udb54\uddb4\ud8e9\ude7e\udba2\ude62\ud964\ude15\udafe\udd6a\ud982\udd04\ud9cb\ude84\ud8d3\udc8a\ud86d\udcd1\udad0\udc24\ud8a8\ude1b\ud8aa\udc36\udade\udc5f\ud9b7\udcf9\udbf7\udf87\ud898\udc48\ud8f0\udd1a\ud97c\udfae\udb04\uded0\uda28\uddad", "\u7741\u4b99\u11e7\u23e3\u4ec6\u3ae3\u316d\uac23\u9b73\u5a72", "\ud962\udce1\u1f32\udaee\udfce\ud81a\udfea\uda6c\udf3c\udb4b\uddf6\ud87f\udc08",
        22, 42372, -1067521439, 5996699172447512666L, 26485L, false, false, (char) 64947, (char) 58166,
        Double.longBitsToDouble(0x3fe5324f82f8c1c8L), Double.longBitsToDouble(0x3fea43e32f75a0a9L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 3, "\ud88e\udf52\uda81\udd85\ud9b4\udc69\udb3f\udd75\ud81b\udf45\ud96d\udc1c\uda73\udfcf\udb78\udee9\udb07\udf33\uda38\udc2f\ud9ba\udf71\ud9eb\udfd7\udac2\udffc\ud8de\udc80\udba2\ude62", "\u0302\u504d\u6034\ub49c\u04ba\u92e8\u0434\uaebf\u8b09\u4c3a\ub7a7", "\ud895\udf35\ud93c\udf7a\ud9d7\udfd5\ud883\udf53\uda3d\udfda\udafe\udc67\uda0c\udd93\udbd1\udd2d\uda28\udcbd\ud80a\udfac",
        43, 81890, 1699808209, 3510766689451174671L, -28845L, true, false, (char) 61133, (char) 60420,
        Double.longBitsToDouble(0x3fa0127ef6d4efc0L), Double.longBitsToDouble(0x3fdc51b3b61525beL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=java.lang.Boolean:false |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 2, 15, 15, 3, "\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\udaa5\udd18\uda73\udfcf\ud929\udde5\uda27\udcd6\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8de\udc80\ud826\udd7f", "\u0302\u504d\u6034\ub49c\u7034\ub370\u0434\u3323\u9dd7\uc144\ub7a7", "\ud9e7\udc66\ud930\udc0a\ud92b\udee0\uda2f\udf2d\udbc0\udd08\ud9f4\udf3a\udb6d\udf3c\ud839\uddd6\udae5\udd42\u44d6",
        38, 30189, 1699808095, 3525879201897048847L, 90989L, true, false, (char) 61133, (char) 60420,
        Double.longBitsToDouble(0x3fd1024fdeda49caL), Double.longBitsToDouble(0x3fe628d9db692cffL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=java.lang.String:\ud8c1\udd38 |this=com.google.javascript.jscomp.GlobalNamespace:@?\012",
        Z.run(T, 2, 0, 3, 3, "\ud8c1\udd38", "\u538f\u52bf", "\ud8e4\udfa4\ud911\udf4a\u99e8\udbe3\udcd1\ud9eb\udf31\ud9d3\udc04",
        4, 5403, -223096098, -2887915369856297274L, 31011L, false, false, (char) 32653, (char) 39723,
        Double.longBitsToDouble(0x3fdc782ed594733aL), Double.longBitsToDouble(0x3fe4c645bab17791L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 1, 11, 7, 3, "\udb80\ude7b\udb9c\udd99", "\u52bf\ua9b7\u0c8e\u9cd9\u3e0f\uc576\ua633\ua52f\u285c\u98b6\u8506\ud4be\ub8c5\ud275\u3db7\u86cb\u9ea3\u852e\ub473\u9b6a\u2239\u9a10\uc144\u19a3\uba81\u2c27\u5472\u02de\ub6a3\u8921\u6e7c", "\ud9ee\udcde\ud868\udded\ud9ad\udd59\udb3d\udfc5\ud82b\udeac\ud95c\udd8f\ud845\uddd6\udb61\udc01\ue3e5\ud937\udf1d\ud90b\ude8c\ud9d8\udfa3\ud8be\ude95\ud8ce\ude92\udb58\udef5",
        30, 36591, 962843284, 5780635607826178871L, -64023L, true, true, (char) 18985, (char) 34383,
        Double.longBitsToDouble(0x3fdb5f1af63a2e06L), Double.longBitsToDouble(0x3fbde8e230881468L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 2, 12, 11, 13, "\ud848\udf9c", "\u538f\u52bf", "\ud929\udde5\ud911\udfd0\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc",
        4, 5403, -223096098, -2887915369856297274L, 22333L, false, false, (char) 15540, (char) 11367,
        Double.longBitsToDouble(0x3fe4c645bab17791L), Double.longBitsToDouble(0x3fe00834a71bd896L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 6, 3, "\udbda\udc1f\uda79\udc70\udaa0\udceb\ud92b\udcd9\ud921\udfa3\ud96d\udc1c\udaca\udd3a\ud929\udde5\ud911\udfd0\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8de\udc80\udba2\ude62", "\u0302\u504d\u6034\ub49c\u1365\ub3d6\u5fc3\u98f8\u86fd\uc144\ub7a7", "\uda33\udfae\u2b78\udaf8\ude0f\uda2f\udeea\uda45\udec6",
        35, 57588, -2045131683, 9087174773207981316L, 68306L, true, false, (char) 33084, (char) 7165,
        Double.longBitsToDouble(0x3fe4583014ee2d03L), Double.longBitsToDouble(0x3fe4a8ea21ef82a8L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 2, 12, 12, 2, "\ud9f9\udcbc\ud93b\udc12\ud94c\ude4d\ud81a\udd0d\u0393\u56bc\udb1a\udcd6\ud92c\ude2b\ud8a8\ude46\ud8cf\ude73\ud8f3\udeb4\ud9ec\udc06\ud935\udf72\udbc4\udeae\udb69\udf38\ud964\ude15\ud94b\udde9\udaa9\uddf7\ud99d\udc84\udb9e\udd97\ud9ac\udd7f", "\u4a63\u02a0\u9e36\u2cdd\uc8f1\u04fa\ua820\ucbf2\u1be6\u4447\u3a5d\u0a5b", "\ud861\udf3f\uda26\udeff\ud80f\ude6d\ud950\udead\ud916\ude6b\udbb6\udd61\udbf6\udca2\ud977\udde6\udb7b\udffc\udbc4\udcc7\udb77\ude35\udaaa\udcee\ud978\ude7c\udb24\udf8d\ud86c\udc3d\ud97c\uddb3\uda7b\udc46\udbcb\udc5c\ud98c\ude0d\ud9ed\udd68\ud9a3\udca0\udb4d\udf77\udb5a\udd3a\ud8ff\udedc\ud996\uddf8\udabd\udd62\ud8f2\udcab\ud905\udf2f\ud8fd\uddf1\udb96\udfe5\udabc\ude7f\ud850\udcd0\udb91\udfb0\ud845\udd9e\uda2d\uddf9\uda85\udc85\ud957\ude57\ud9fd\uddea\u4149",
        35, 36366, 1194646906, 3826519274639640315L, -985L, true, true, (char) 8032, (char) 28626,
        Double.longBitsToDouble(0x3f4ab7664a77a400L), Double.longBitsToDouble(0x3fa6fd9ea6bf70c0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 8, 3, "\udbd5\udd8b\udbdb\udf4c\udb34\uddb9\udb1d\udeca\ud921\udfa3\udaa4\udc38\ud9ce\udd7c\uda7d\udee4\udab5\uddfd\ud84f\udec2\uda16\uddc9\ud863\udfcb\ud911\udcfa\ud919\udce5\uda81\udec0", "\u6b34", "\ud86d\udcd1\udbe2\ude1b\uda58\udc17\udb9a\udf46\udbad\udc4f\ud8e1\udd95",
        50, 98202, 109467635, 6557100384346150395L, 88352L, true, false, (char) 25834, (char) 58725,
        Double.longBitsToDouble(0x3fe0e130545dc673L), Double.longBitsToDouble(0x3fd4f8619a08fc38L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 11, "\udbd5\udd8b\udbdb\udf4c\udadc\udeed\udb1d\udee2\ud9d0\udefb\udaa4\udc8c\uda73\udfcf\udaf5\udf02\ud928\udd09\u5e04\ud960\udf91\udb2f\udfd1\udb9a\udd88\udb7a\udff1\udba2\ude62", "\u9b39\u6c27\u2c65\ub49c\ub528\ubf12\u8617\u1bf8\u8d9f\ub1ea\u82b1", "\udadb\uddd5\udb6c\udd11\udb40\ude8a\udad2\udd39\ud836\udc28\uda4c\udc84\udb1e\udeb7\udbd1\udd2d\uda28\udcbd\ud810\udfac",
        43, 50770, 1699808211, 3525879201897048847L, 90989L, true, false, (char) 61133, (char) 60420,
        Double.longBitsToDouble(0x3fd1024fdeda49caL), Double.longBitsToDouble(0x3fdc51b3b61525beL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=java.lang.Boolean:false |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 2, 0, 0, 3, "\000", "\u4973\u657a\u737e\u0c8e\uccc9\uaa5b\u008f", "\udb9a\udd88",
        0, 5403, -223096098, -2887915369853217082L, -14046L, true, true, (char) 4329, (char) 61711,
        Double.longBitsToDouble(0x3fd396289b2c0000L), Double.longBitsToDouble(0x3f4d4c48586c0000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 2, 0, 0, 5, "\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\ud9fe\udf85\ud856\udcdf\udafc\ude78\udada\udf72\udbea\udda8\ud8e4\udf32\uda55\udf01\udb54\uddb4\ud8e9\ude7e\udba2\ude62\ud964\ude15\udafe\udd6a\u00c6\ud997\udeca\udb15\udf8b\ud95a\udd78\ud81d\udf21\u00e6\000\ud8c7\udfc2\ud893\udcf4\udbf7\udf87\ud898\udc48\udac9\udea6\udb86\uddec\udbe2\udf05\udb09\udf3a", "\u00f6\u2a9e\u11e7", "\ud80a\udfac\udb75\udcb2\ud8f7\ude44\ud9f4\udd57\udbc3\udd07\udab0\udf69\u2e8b\000",
        -5, 32704, 609576543, 2658611487282292589L, -16911L, false, false, (char) 20736, (char) 63921,
        Double.longBitsToDouble(0x3fb694d70400f4e0L), Double.longBitsToDouble(0x3feb46f99ec47f2cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 3, "\uda5e\uddda\uda81\udcff\udaa7\udc31\udb3f\udd51", "\u0c8e\u52d6\u8875\u67d1\u504b\uac8d\ud15b", "\ud964\ude15\ud9ef\uddd3\u3f1e\ud9c9\ude0b\ud8d3\udc8a\ud86d\udcd1\uda63\ude6d\ud849\udd72\ud8aa\udc36\ud848\udf8f\ud88e\ude26",
        31, 15512, 110403608, 2704749135543082223L, 74361L, true, true, (char) 27954, (char) 32516,
        Double.longBitsToDouble(0x3fd4f8619a08fc38L), Double.longBitsToDouble(0x3fe78b879f720c38L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=com.google.javascript.rhino.JSDocInfo:JSDocInfo |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 2, 0, 13, 3, "\ud8a0\ude3c\uda81\udd85\ud9b4\udc69\udb3f\udd75\ud81b\udf45\ud969\udce1\uda73\udfcf\udb7d\udee9\udb07\udf33\uda38\udc2f\ud9ba\udf71", "\u9902\uc543\u6307\u3508", "\ud8d3\udc8a\ud86d\udcd1\uda63\ude6d\ud849\udcb7\ud8aa\udc36\ud848\udf8f\ud88e\ude26\ud9de\udf4d",
        20, 9767, 629748482, 2780723106015125904L, 11688L, false, true, (char) 19943, (char) 38752,
        Double.longBitsToDouble(0x3fb771934a7c30c8L), Double.longBitsToDouble(0x3fd047e1c5e2e1e6L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\udaa5\udd18\uda73\udfcf\ud929\udde5\uda27\udcd6\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8de\udc80\ud826\udd7f |this=com.google.javascript.jscomp.GlobalNamespace:@?\0121=java.lang.String:\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\udaa5\udd18\uda73\udfcf\ud929\udde5\uda27\udcd6\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8de\udc80\ud826\udd7f |this=com.google.javascript.jscomp.GlobalNamespace:@?\012",
        Z.run(T, 2, 3, 3, 3, "\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\udaa5\udd18\uda73\udfcf\ud929\udde5\uda27\udcd6\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8de\udc80\ud826\udd7f", "\u0302\u504d\u6034\ub49c\u7034\ub370\u0434\u3323\u9dd7\uc144\ub7a7", "\ud9e7\udc66\ud930\udc0a\ud92b\udee0\uda2f\udf2d\udbc0\udd08\ud9f4\udf3a\udb6d\udf3c\ud839\uddd6\udae5\udd42\u44d6",
        38, 37459, 1699808095, 3525879201897048847L, 90989L, true, false, (char) 61133, (char) 60420,
        Double.longBitsToDouble(0x3fd1024fdeda49caL), Double.longBitsToDouble(0x3fe628d9db692cffL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 2, 12, 12, 2, "\ud9f9\udcbc\ud93b\udc12\ud94c\ude4d\ud81a\udd0d\u0393\ud905\udc33\udaf0\uddc0\ud92c\ude2b\ud8a8\ude46\ud8cf\ude73\ud8f3\udeb4\ud9ec\udc06\ud935\udf72\udb56\udf76\udb72\udc06\ud964\ude15\ud953\udfe9\udaa9\uddf7\ud99d\udc84\udb9e\udd97\ud8dd\udc17", "\u3055\u0fea\u9e36\u2cdd\uc8f1\u04fa\ua820\ucbf2\u1be6\u4447", "\udb70\uddb4",
        30, 43861, -1282466927, 5965176409993785672L, -75546L, false, true, (char) 2665, (char) 10914,
        Double.longBitsToDouble(0x3fdf9eb2d43e5f4eL), Double.longBitsToDouble(0x3f944564852a4bc0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 2, 0, 0, 3, "\000", "\u4973\u4cd8\u2125\u0c8e\ua9d3\uce56\ua387", "\ud83b\udc73\uda5c\udd1d",
        3, 11808, -72282042, -7024965046879137862L, -69973L, true, true, (char) 61711, (char) 24514,
        Double.longBitsToDouble(0x3fb3a8c038855688L), Double.longBitsToDouble(0x3fe48b78401dd3e9L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=null |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 2, 13, 13, 0, "\uda17\udce8\ud852\udcf8\ud9d1\ude9c\udb3f\udd75\ud81b\udf45\ud969\udce1", "\u8875\u9bc5", "\ud8c3\udd68\ud8de\udccc\ud969\udf03\ud807\udf4c\udbc6\udc8c",
        55, 57642, 173761518, 9199857105556275258L, 22333L, false, true, (char) 49806, (char) 40039,
        Double.longBitsToDouble(0x3fe4c407b8b794e5L), Double.longBitsToDouble(0x3fe81034a4992589L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.GlobalNamespace:@?\012",
        Z.run(T, 1, 9, 6, 3, "\ud9f9\udcbc\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud916\udca3\ud980\udece\uda73\udfcf\ud929\udde5\ud911\udfd0\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8de\udc80\ud951\ude19", "\u0302\u504d\u6034\ub49c\ub03f\u5439\ua56e\u2ddb\u9dd7\u3b58\u363f", "\udb04\uded0\ud991\ude3a\ud9f8\ude69\udaab\udee7\ud991\udf4c\ud91b\uddb4\udb1e\udeb7\udbd6\udc2d",
        -4, 67020, 1689371377, -8604555410595052705L, -47731L, true, true, (char) 37089, (char) 59405,
        Double.longBitsToDouble(0x3fa2c1547bcfa480L), Double.longBitsToDouble(0x3fd10cb78eda49caL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 2, 11, 11, 3, "\ud9f9\udc63\uda79\udc70\ud8e7\udc8f\udb1d\ude28\ud921\udfa3\udaa5\udd18\uda73\udfcf\ud929\udde5\uda27\udcd6\u99e8\ud960\udf91\ud9ec\udc06\udac2\udffc\ud8de\udc80\ud826\udd7f", "\u0302\u504d\u2234\ub49c\u9b76\ub370\u0434\u3323\u9dd7\uc144\ub7a7", "\ud9cd\ude98\ud930\udc0a\ud92b\udee0\uda2f\udf2d\udbc0\udd08\ud9f4\udf3a\udb48\udd09\ud9fe\udf14\udae5\udcfe\u44d6",
        38, 30189, 1699808095, 3525879201897048847L, 4960L, false, true, (char) 49657, (char) 48094,
        Double.longBitsToDouble(0x3fd1024fdeda49caL), Double.longBitsToDouble(0x3fe628d9db692cffL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\0121=java.lang.Boolean:true |this=com.google.javascript.rhino.JSDocInfoBuilder:@?\012",
        Z.run(T, 2, 11, 11, 3, "\ud9f9\udc63\uda66\uddd9\ud801\ude0b\udb1d\ude28", "\u0c8e\u74b2\uae4d\ub6e5\u0ba8\uacbc\u845b\u98b6\u60ed\u4b1b\ub8c5\u0302\u504d\u2234\ub49c\u9b76\ub370\u2f76\u0f8b\ud44d\uc119", "\udbcc\udd56\ud9cd\ude98\ud930\udc0a",
        22, 83092, 914050515, -197687829187380888L, -38294L, true, true, (char) 65425, (char) 64111,
        Double.longBitsToDouble(0x3feafc4630746551L), Double.longBitsToDouble(0x3fe87987778b0602L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.rhino.JSDocInfoBuilder|recordBlockDescription|java.lang.String|new:com.google.javascript.rhino.JSDocInfoBuilder:boolean",
    "M|com.google.javascript.jscomp.GlobalNamespace|getNameForest||new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|getNameIndex||new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|getTopVarName|java.lang.String|new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|isGlobalNameReference|java.lang.String,com.google.javascript.jscomp.Scope|new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|isGlobalScope|com.google.javascript.jscomp.Scope|new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|isGlobalVarReference|java.lang.String,com.google.javascript.jscomp.Scope|new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|process||new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.GlobalNamespace|scanNewNodes|com.google.javascript.jscomp.Scope,java.util.Set|new:com.google.javascript.jscomp.GlobalNamespace:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "C|com.google.javascript.jscomp.GlobalNamespace|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node",
    "C|com.google.javascript.jscomp.GlobalNamespace|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node",
    "M|com.google.javascript.rhino.JSDocInfoBuilder|addAuthor|java.lang.String|new:com.google.javascript.rhino.JSDocInfoBuilder:boolean",
    "M|com.google.javascript.rhino.JSDocInfoBuilder|addReference|java.lang.String|new:com.google.javascript.rhino.JSDocInfoBuilder:boolean",
    "M|com.google.javascript.rhino.JSDocInfoBuilder|build|java.lang.String|new:com.google.javascript.rhino.JSDocInfoBuilder:boolean",
    "M|com.google.javascript.rhino.JSDocInfoBuilder|hasAnySingletonTypeTags||new:com.google.javascript.rhino.JSDocInfoBuilder:boolean",
    "M|com.google.javascript.rhino.JSDocInfoBuilder|hasAnyTypeRelatedTags||new:com.google.javascript.rhino.JSDocInfoBuilder:boolean",
    "M|com.google.javascript.rhino.JSDocInfoBuilder|recordBlockDescription|java.lang.String|new:com.google.javascript.rhino.JSDocInfoBuilder:boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
