package com.google.javascript.rhino;
import org.junit.Test;
import static org.junit.Assert.*;
public class IR_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 5, "\udbb3\udf46", "\u86dc\u977a\u59f7\ub267\ud4b3\ud153\ua9cf\ubc2a", "\ud9ce\udeac\ud8f2\uddc0\udbdd\ude36\uda1c\udf13",
        12, 37141, 1391617301, 7542425600469204019L, -21183L, true, false, (char) 35990, (char) 2385,
        Double.longBitsToDouble(0x3fc5eaddd510c814L), Double.longBitsToDouble(0x3fe3ef26bee01775L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 5, "\udbb3\udf46\uda46\udc93\udb71\udd6e\ud81d\ude6a", "\uc5aa\u12af\u270a\u4969\ubc2a\u1c58\ua204\u7cd0\u298a\u5649\u647a\u5d77\u58a4\u5a37\uc097\uacff\u72d8", "\uda96\udcd6\udbe3\udd72\ud8f6\udfa5\ud9cf\udd7a\uda76\udfa1\ud9c7\udd80\udb4e\udffe\uda16\ude64\ud896\udfa6\ud966\udefa\uda2f\udc30\uda71\udf28\u4e73\uda13\udce0\ud9bf\ude15",
        30, 42596, 1453404873, -1542976666464814061L, 88993L, true, false, (char) 33142, (char) 21084,
        Double.longBitsToDouble(0x3fe8cf14bc68e916L), Double.longBitsToDouble(0x3fe53e75582f6358L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 9, 5, "\udbb3\udf46", "\u86dc\u977a\u59f7\ub267\ud4b3\ud153\ua9af\u81a9", "\ud9db\udca9\ud8f2\uddc0\udbdd\ude36\uda1c\udf13\ud8dd\ude1f",
        26, 38301, 1756107807, 4956066474697142607L, 35310L, true, true, (char) 22238, (char) 35990,
        Double.longBitsToDouble(0x3fb6f43d457ab770L), Double.longBitsToDouble(0x3fd4432054fbc9aeL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 5, "\udbb3\udf46", "\u86dc\u977a\u59f7\ub267\ud4b3\ud153", "\ud9ae\udc3d",
        35, -856, 639498627, 8396538575931998614L, -43239L, true, true, (char) 26385, (char) 58591,
        Double.longBitsToDouble(0x3fd4f44c77ecb116L), Double.longBitsToDouble(0x3feb91e683e13eb5L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 12, 5, "\udb63\udf3e", "\u86dc\u977a\u59f7\ub267\ud4b3\ud153\ua9cf\ubc2a", "\ud9ce\udeac\ud8f2\uddc0\udbaa\ude07\uda1c\udeaa",
        12, 37141, 1391617301, 7542425561814498355L, -21183L, true, false, (char) 5479, (char) 2385,
        Double.longBitsToDouble(0x3fc5eaddd510c814L), Double.longBitsToDouble(0x3fe3ef26bee01775L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 16, "\udbb3\udf46", "\u86dc\u977a\u59f7\u3e4f\ud4b3\u1d7a\ua9cf\ubc2a", "\ud9ce\udeac\ud8f2\uddc0\udbdd\ude36\uda1c\udf13",
        12, 37141, 1391617301, 7542425600469204019L, -21183L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e44000000000000L), Double.longBitsToDouble(0x3fe3ef26bee01775L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 16, 11, "\udbb3\udf46", "\u3fcb\u5c53\u59f7\ub267\ud4b3\ud153\ua9cf\ubc2a\u2bc0\uc3c1", "\udbdd\ude36\uda1c\udf13\ud8dd\ude1f\ud81a\udfe7\ud962\uddf8",
        7, 99147, 1267446095, -2443235099245416590L, 97793L, true, false, (char) 2385, (char) 38813,
        Double.longBitsToDouble(0x3fd4432054fbc9aeL), Double.longBitsToDouble(0x3fe700bbaac534f9L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 16, "\udbb6\udf57", "\u86dc\u977a\u59f7\u90fc\u6ac3\uacd7\u8114\uccff", "\uda21\uddf5\ud8f2\udd2b\udbdd\ude36\uda1c\udf13",
        2, 79742, 1391621098, 4120620250893352157L, -63233L, false, true, (char) 29334, (char) 22238,
        Double.longBitsToDouble(0x3fe49431585bd0f5L), Double.longBitsToDouble(0x3fc5eaddd510c814L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BLOCK\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 15, "\udb03\udc51", "\u86dc\ua133\u3534\ub267\ud4b3\ud153", "\ud8e0\ude78",
        12, 24715, -1207388674, 8396538577341284758L, -60947L, true, true, (char) 26385, (char) 16975,
        Double.longBitsToDouble(0x3fd4f44c74d04116L), Double.longBitsToDouble(0x3feb96f0ba583eb5L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 5, "\udbb3\udf46", "\ucb4d\u1d8e\ua85b\ub267\ud4b3\ud153\ua9cf\ubc2a", "\udafc\uddd1\ud8f2\uddb6\udbdd\ude36\uda0b\udc13",
        15, 37072, 1391617301, 7542425600469204019L, 58738L, false, true, (char) 23449, (char) 22248,
        Double.longBitsToDouble(0x3fe073215f6d3797L), Double.longBitsToDouble(0x3fbb342faa219028L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BLOCK |a0=[Lcom.google.javascript.rhino.Node;:[[]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 14, 5, "\udbb3\udf46", "\u86dc\u977a\u59f7\ub267\ud4b3\ud153\ua9cf\ubc2a", "\ud9ce\udeac\ud8f2\uddc0\udbdd\ude36\uda1c\udf13",
        12, 37141, 1391617301, 7542425600469204019L, -21183L, true, false, (char) 35990, (char) 2385,
        Double.longBitsToDouble(0x3fc5eaddd510c814L), Double.longBitsToDouble(0x3fe3ef26bce01775L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BLOCK\012",
        Z.run(T, 1, 8, 0, 6, "\udbb3\udf46", "\u86dc\u977a\u59f7\ub267\ud4b3\ud153\ua9cf\ubc2a", "\ud9ce\udeac\ud8f2\uddc0\udbdd\ude36\uda1c\udf13",
        12, 37141, 1391617301, 7542425600469204019L, -21183L, true, false, (char) 35990, (char) 2385,
        Double.longBitsToDouble(0x3e4510c814000000L), Double.longBitsToDouble(0x3fe3ef26be000000L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BREAK\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 12, 9, "\udbb3\udf46\uda46\udc93\udb71\udd6e", "\u59f7\u16e5", "\udb02\udc5c\ud86b\udd81\ud8e0\ude78\ud83a\udd83\ud9ce\udeac",
        36, 14481, 424313238, 1644285308342147213L, -94849L, true, false, (char) 62997, (char) 11818,
        Double.longBitsToDouble(0x3feb96f0b9e0fab5L), Double.longBitsToDouble(0x3fc42ee64eda18acL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BLOCK\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 10, "\udbb3\udf46\uda46\udc93\udb71\udd6e\ud8c5\udd8e\ud8b9\udc5e\ud9e8\udd8d\u3ad1\uda90\udc0f\udb50\udec2\udb19\udda0\ud8a0\udecd\ud8e0\ude78\ud83a\udd83\ud9ce\udeac\ud8f2\uddc0\udbdd\ude36\uda1c\udf13\ud8dd\ude1f\ud81a\udfe7\ud962\uddf8\ud897\udc4a\uda7c\udc40", "\u31c5\u5559\u843b\u7ea9\ub762\ubbf7\u8513\u3e4a\ub75e\u3bdb\u2895\u1bc7\ube8e\ua708\u5db6\uc55b\u9591\u82da\ub02c\u82ab\u69b1", "\ud847\uddc4",
        41, 74346, -138753735, 6716516883345562629L, -90286L, true, true, (char) 15289, (char) 47322,
        Double.longBitsToDouble(0x3fb9f1e4d1ce4860L), Double.longBitsToDouble(0x3fee30987ba0c0beL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:ARRAYLIT |a0=[Lcom.google.javascript.rhino.Node;:[[]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 12, 9, "\udbb3\udf46", "\u86dc\u977a\u59f7\u754d\ud4b3\ud153\ua9cf\ubc2a", "\ud9ce\udeac\ud8f9\uddc0\udbdd\ude36\uda1c\udf13",
        12, 37141, 1391617301, 7542425600469204019L, -21183L, true, true, (char) 56689, (char) 64058,
        Double.longBitsToDouble(0x3fc5eaddd510c814L), Double.longBitsToDouble(0x3fdb4e4d7dc02e38L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BLOCK\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 12, 5, "\udbb3\udf46", "\000", "\ud829\udeb4\ud9dd\ude96\udb50\udec2\udaf6\ude5b\ud8a0\udecd\ud8e0\ude78\u0be8\ud89e\ude2e\ud8f2\uddc0\udbdd\ude36\uda1c\udf13\ud8dd\ude1f",
        40, -1000, 0, 4956066255653810511L, 35310L, true, true, (char) 22238, (char) 35990,
        Double.longBitsToDouble(0x3ecea00000000000L), Double.longBitsToDouble(0x3fb10c8153ef2000L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BLOCK |a0=[Lcom.google.javascript.rhino.Node;:[[]]\0121=com.google.javascript.rhino.Node:BLOCK |a0=[Lcom.google.javascript.rhino.Node;:[[]]\012",
        Z.run(T, 2, 10, 10, 15, "\udbb3\udf46", "\u86dc\u1a37\u5ad8\ub267\ud4b3\ud153\ua9cf\ubc2a", "\ud9ce\udeac\ud8f2\uddc0\udbdd\ude36\uda1c\udf13",
        12, 37141, 1391617301, 7542425600469204019L, -21183L, true, false, (char) 35990, (char) 2385,
        Double.longBitsToDouble(0x3fc5eaddd510c814L), Double.longBitsToDouble(0x3fe3ef26bee01775L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BLOCK\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 13, 5, "\ud9a1\udfa8\ud8d7\udefc\ud8be\udddd", "\u4f82\u6ece\u7b44\u5dd2\uaa28\u5aeb\ud15b\u3089\u1264", "\ud932\udfd9\uda8d\udc6a\ud9d0\ude22\udb84\ude65\uda12\udf4c",
        7, 31279, -568860001, -4951212432647982138L, 22752L, false, true, (char) 50884, (char) 44967,
        Double.longBitsToDouble(0x3fe811395ca0e918L), Double.longBitsToDouble(0x3fe62e7815713cb4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BLOCK\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 10, 2, "\udbb3\udf46", "\u4a59", "\ud87d\udead\uda90\udc21\ud963\udcaa\udb19\udda0\uda58\udfa9\ud909\udf25\ud83a\udd83\ud9ce\udeac\ud904\udc48\udbdd\ude36\uda1c\udf13\ud8dd\ude1f",
        26, 99381, 1756107807, -6597796138847588017L, 32750L, false, true, (char) 40330, (char) 35990,
        Double.longBitsToDouble(0x3fd5bd0f5a71a782L), Double.longBitsToDouble(0x3fd0f18014fbc9aeL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 5, "\ud951\ude5f", "\u6d03\uc4a4\u73b1\u2fae\ud4b3\ud153\ua9cf\u30e2", "\ud9ce\ude52\ua95c\ud8d0\ude49\uda1c\udeb2\ud8dd\ude1f\udb54\udfc1\udb6c\udced",
        7, 32691, 1064098691, -2969440898780909059L, 97793L, true, false, (char) 40528, (char) 44497,
        Double.longBitsToDouble(0x3fec6192727d9ba3L), Double.longBitsToDouble(0x3fe702be71c261e1L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 12, 5, "\u7c1c", "\u86dc\ud243", "\udbed\udf61\uda0b\udf94\ud870\udf79\ud899\uddf9\ud836\udc41\ud819\udec1\ud9ce\ude8e\udb73\ude81\udb01\udcaa\uda66\udee6\ud8dd\ude1f\ud81a\udfe7\ud9cf\udff8\ud89f\udf7f\udb5e\ude52",
        31, 71999, 1052092093, 5925949724106097825L, -4859L, true, false, (char) 32781, (char) 46164,
        Double.longBitsToDouble(0x3fe69a27a4100eb9L), Double.longBitsToDouble(0x3fe4956b7e218f42L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:ARRAYLIT |a0=[Lcom.google.javascript.rhino.Node;:[[]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 9, 6, "\udbb3\udf46\uda46\udf9b\ud923\udf46", "\uc1f8\u6150", "\udb19\udda0\ud8a0\udecd\ud8e0\ude78\udb02\udd46\ud9ac\udeac",
        36, 14481, 424313238, -3878253731325619990L, 35310L, false, false, (char) 15674, (char) 36123,
        Double.longBitsToDouble(0x3fcf0432a21855c4L), Double.longBitsToDouble(0x3fd93e186e57542aL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BLOCK\0121=com.google.javascript.rhino.Node:BLOCK\012",
        Z.run(T, 2, 8, 8, 11, "\ud928\udf1f\uda45\udfb6\udb71\udd6e\ud81d\ude6a\ud8b9\udc5e\ud9e8\udd8d\u3ad1\uda49\uddd0\ud857\udf02\ud954\udc1c\udb9f\udfe5", "\u5110\u80b2\u4174\u878f\u7fd2", "\uda8d\udf0a\udb7c\ude8a\udad5\uddc2\udac3\ude24",
        41, 81013, 907322147, 411322242500147291L, -60841L, true, true, (char) 2407, (char) 48557,
        Double.longBitsToDouble(0x3fdd55e133177bfeL), Double.longBitsToDouble(0x3fea7dec2b36d0e5L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BLOCK\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 5, "\udbb3\udf46", "\u86dc\u977a\u59f7\ub267\ud4b3\ud153\ua9af\u81a9", "\ud9db\udca9\ud8f2\uddc0\udbdd\ude36\uda1c\udf13\ud8dd\ude1f",
        30, 38301, 1749485706, 4956066474697142607L, 35310L, true, true, (char) 22238, (char) 35990,
        Double.longBitsToDouble(0x3fb6f43d457ab770L), Double.longBitsToDouble(0x3fd4432054fbc9aeL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 9, 12, "\udbb3\udf46", "\u86dc\u977a\u59f7\ub267\ud4b3\ud153\u7bc8\u9aee", "\ud9dc\udda9\udbfc\udfc4\ud9fa\udfdd\uda18\uddd2\ud8dd\ude1f\ud8b0\udd71\ud980\uddf3\udb93\udffb",
        17, 97095, -561912929, 4518781075421213665L, 94965L, true, false, (char) 38813, (char) 35916,
        Double.longBitsToDouble(0x3fed6b805c74bce1L), Double.longBitsToDouble(0x3fef567cacb97803L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BREAK\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 5, "\udbb3\udf46", "\ua32e\u977a\u59f7\u2f26\u668a\u0e69", "\ud81d\uddfd",
        21, 27684, -685901437, 8396538573939507606L, -43239L, true, true, (char) 38148, (char) 26723,
        Double.longBitsToDouble(0x3fe9659b7ca19697L), Double.longBitsToDouble(0x3fd3dee5cb391b44L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BLOCK\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 7, 5, "\udb63\udf13\udb40\udfc0\uda83\ude54\ud813\ude8e", "\u6a63\u5a54\ub070\uaa28\u0c77\u2ad6\ua895", "\ud9bb\udd28",
        29, 9793, 790665357, 5977101907935302678L, -59858L, false, false, (char) 40106, (char) 29334,
        Double.longBitsToDouble(0x3fc42a47a83c3c98L), Double.longBitsToDouble(0x3fe0102badaf56eeL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BLOCK\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 16, "\udb63\udf3e", "\u86dc\u977a\u59f7\ub267\ud4b3\ud153\ua9cf\ubc2a", "\ud9ce\udeac\ud8f2\uddc0\udbaa\ude07\uda1c\udeaa",
        12, 37141, 1391617301, 22085875760179L, -21183L, true, false, (char) 5479, (char) 2385,
        Double.longBitsToDouble(0x3fc5eaddd510c814L), Double.longBitsToDouble(0x3fe3ef26bee01775L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BLOCK |a0=[Lcom.google.javascript.rhino.Node;:[[]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 7, 15, "\udbb3\udf46", "\u86dc\u977a\u59f7\ua718\ud4b3\u1d7a\ua9cf\ubc2a", "\ud9ce\udeac\udbc9\udcc5\ud93c\udfcd\uda1c\udf13",
        12, 37141, 1391617301, 7542425600469204019L, -21183L, false, true, (char) 56, (char) 0,
        Double.longBitsToDouble(0x3e44000000000000L), Double.longBitsToDouble(0x3febef26bfefa84fL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:ARRAYLIT |a0=[Lcom.google.javascript.rhino.Node;:[[]]\0121=com.google.javascript.rhino.Node:ARRAYLIT |a0=[Lcom.google.javascript.rhino.Node;:[[]]\012",
        Z.run(T, 2, 5, 5, 11, "\udbb3\udf46", "\u3fcb\u3cff\u59f7\ub267\ud4b3\ud153\ua9cf\ubc2a", "\ud9ce\udeac\ud8f2\uddc0\udbdd\ude36\uda1c\udf13",
        12, 37141, 1391617301, 7542425600469204019L, -21183L, true, false, (char) 35990, (char) 62479,
        Double.longBitsToDouble(0x3fc5e13eb510c814L), Double.longBitsToDouble(0x3fe3ef26bee01775L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BLOCK\0121=com.google.javascript.rhino.Node:BREAK\012",
        Z.run(T, 2, 8, 11, 16, "\udbb6\udf57", "\u86dc\u977a\u59f7\u90fc\u6ac3\uacd7\u02c9\uccff", "\uda28\udcf5\ud8f2\udd2b\udbdd\ude36\uda1c\udf13",
        2, 79742, 1391621098, 4120620250893352157L, -63233L, false, true, (char) 29334, (char) 22238,
        Double.longBitsToDouble(0x3fe49431585bd0f5L), Double.longBitsToDouble(0x3fc5eaddd510c814L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.Node:BREAK\0121=com.google.javascript.rhino.Node:BREAK\012",
        Z.run(T, 2, 11, 11, 9, "\ud82c\udd62\ud8b2\udf77\udb71\udd6e", "\u5d67\u1553", "\udb02\udc5c\ud86b\udd81\ud8e0\ude78\ud83a\udd83\ud9ce\udeac",
        13, 14481, 424313238, 6999628217671642765L, 24064L, false, true, (char) 31699, (char) 23009,
        Double.longBitsToDouble(0x3fe5254e6619a76eL), Double.longBitsToDouble(0x3fee8362f91083c4L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 5, "\udbb3\udf46", "\u86dc\u88d4\u59f7\ub267\ud4b3\ud153\u1300\u7419", "\ud897\ude90\ud8f2\uddc0\udbdd\ude36\uda1c\udf13",
        12, 37141, 1391617301, 8263001541644939114L, -21183L, true, false, (char) 35990, (char) 2385,
        Double.longBitsToDouble(0x3fc5eaddd510c814L), Double.longBitsToDouble(0x3fe3ef26bee01775L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.rhino.IR|blockUnchecked|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.rhino.IR|tryCatch|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.rhino.IR|tryFinally|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.rhino.IR|add|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.rhino.IR|and|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.rhino.IR|arraylit|[Lcom.google.javascript.rhino.Node;|static",
    "M|com.google.javascript.rhino.IR|assign|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.rhino.IR|binaryOp|int,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.rhino.IR|block||static",
    "M|com.google.javascript.rhino.IR|block|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.rhino.IR|block|[Lcom.google.javascript.rhino.Node;|static",
    "M|com.google.javascript.rhino.IR|breakNode||static",
    "M|com.google.javascript.rhino.IR|breakNode|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.rhino.IR|call|com.google.javascript.rhino.Node,[Lcom.google.javascript.rhino.Node;|static",
    "M|com.google.javascript.rhino.IR|caseNode|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.rhino.IR|catchNode|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.rhino.IR|blockUnchecked|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.rhino.IR|tryCatch|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.rhino.IR|tryFinally|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
