package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class CheckGlobalThis_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 3, "\udb0a\uddba", "\u0d55\u5a25\u6374\u42b8\u170f\u866c\u681b\u8aed\u95e1\u4dfb", "\uda74\udd05\ud913\udeae\udace\udf6b\udb16\ude2d\ud814\udc05\udb44\udc55\ud991\uddda\udb9b\udc1b\uda2c\udf76\ud9af\udd7a\ud99a\udd7d\udb0b\udf3a\uda97\udf02\udb21\udee4\uda62\udd3a\ud8ff\udc2a\uda09\udc86\ud85a\udffc\udb5e\udfe1\ud9b5\udec7",
        -5, 86450, 2126707933, 4440765929412204321L, 41801L, true, false, (char) 5614, (char) 22877,
        Double.longBitsToDouble(0x3fd4f1e869c90a86L), Double.longBitsToDouble(0x3fd91bc7211de0b4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 2, "\udb0a\uddba", "\u0d55\u5a25\u6374\u42b8\u170f\u866c\u681b\u8aed\u95e1\u4dfb", "\uda74\udd05\ud913\udeae\udace\udf6b\udb16\ude2d\ud814\udc05\udb44\udc55\ud991\uddda\udb9b\udc1b\uda2c\udf76\ud9af\udd7a\ud99a\udd7d\udb0b\udf3a\uda97\udf02\udb21\udee4\ud89c\udc18\ud986\udf62\ud8d4\udc57\uabd9\udb5e\udfe1\ud9b5\udec7",
        59, 86450, 2126707933, 4440765929412204321L, 41801L, true, false, (char) 5614, (char) 22877,
        Double.longBitsToDouble(0x3fd4f1e869c90a86L), Double.longBitsToDouble(0x3fd91bc7211de0b4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 3, "\udb0a\uddba", "\u0d55\u5a25\u6374\u42b8\u170f\u866c\u681b\u8aed\u95e1\u4dfb", "\uda74\udd05\ud913\udeae\udace\udf6b\udb16\ude2d\ud814\udc05\udb44\udc55\ud991\uddda\udb9b\udc1b\udbb9\udf90\ud9af\udd7a\ud99a\udd7d\udb0b\udf3a\uda97\udf02\udb21\udee4\uda62\udd3a\ud8ff\udc2a\uda09\udc86\ud85a\udffc\udb5e\udfe1\ud9b5\udec7",
        -5, 57762, 2126707847, 4440765929412204321L, 41801L, true, false, (char) 5614, (char) 22877,
        Double.longBitsToDouble(0x3fd4f1e869c90a86L), Double.longBitsToDouble(0x3fd91bc7211de0b4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 4, "\udb0a\uddba", "\u0d55\u5a25\u6374\u42b8\u170f\u866c\u681b\u8aed\u95e1\u4dfb\ud1a4\u2044\ubc8d\u1085\ubc29\u1d7b\u0a5c\u9a4f\u53ad\u15b9\u75e4", "\udb0b\udf3a\udaa6\udc29\udaf5\udcae\uda62\udd3a\ud8ff\udc2a",
        3, 92173, 1005140058, -5643358445141332349L, 95805L, false, true, (char) 54464, (char) 23614,
        Double.longBitsToDouble(0x3fea49b5898681efL), Double.longBitsToDouble(0x3fe0bdbb2ce1a791L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\0121=java.lang.Boolean:false |this=com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 2, 4, 2, 4, "\udb19\udddc", "\u79a1\u5a25\u6374\u42b8\u170f\u866c\u681b\u8aed\u95e1\u4dfb", "\uda74\udd05\ud913\udeae",
        19, 94982, 2060736712, -1920888696371441851L, -39769L, false, true, (char) 21868, (char) 1673,
        Double.longBitsToDouble(0x3fe5e79cfb45da11L), Double.longBitsToDouble(0x3fb6a118feb99e58L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 3, "\udb0a\ude2f", "\u0d55\u5a25\u6374\u42b8\u170f\u866c\u8570\u550d\u95e1\u4dfb", "\uda74\udd05\ud913\udeae\udace\udf6b\udb16\ude2d\ud814\udc05\udb44\udc55\ud991\uddda\udb9b\udc1b\uda2c\udf76\ud9af\udd7a\ud99a\udd7d\udb0b\udf3a\uda97\udf02\udb21\udee4\uda62\udd3a\ud8ff\udc2a\uda09\udc86\ud85a\udffc\udb5e\udfe1\ud88b\uddb1",
        2, 86450, 2126707805, 4440765929412204321L, -97380L, true, false, (char) 58860, (char) 64004,
        Double.longBitsToDouble(0x3fd91bc7211de0b4L), Double.longBitsToDouble(0x3fe03a023507b093L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 4, "\uda4b\udff0\ud8d1\udfe2\ud804\udd30\udb6f\udf02", "\ub16a\u9fb7\u866c\u681b\u8aed\u0a54\u4dfb\ud1a4\u8fba\ubc8d", "\udb16\ude2d\ud817\ude01\udb44\udc55",
        -4, 21981, -965749029, 680400801081295873L, 25734L, true, false, (char) 21868, (char) 59615,
        Double.longBitsToDouble(0x3fe5e79cfb45da84L), Double.longBitsToDouble(0x3fb6a118db29df48L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\0121=new com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 2, 4, 4, 4, "\ud827\ude08", "\u3e38\u5418\u6374\uc31b\u1ec0\u5f3c\u681b\u8aed\u95e1\u215c", "\ud881\udccb\ud955\udf2f\udb60\uded4\ud8d4\udf3b\ud814\udc05\udb44\udc55\udb1a\udfc0\ud95b\udc33\uda19\ude2c\ud9af\udd26\ud8e4\ude42\ud971\udd1a\ud85b\udc32\uda68\udef5\ud91e\uddc3\udb3b\ude90\uda3e\ude64\ud8eb\udff4\udb25\ude8e\ud9bb\udf18\udb87\udc38\ud95e\ude78\ud973\udc55\udb4a\udc02\uda1a\udfbe",
        13, 30281, -1218117242, -6372076603283702559L, 87093L, true, true, (char) 64039, (char) 16899,
        Double.longBitsToDouble(0x3fc1de0b4874b1c4L), Double.longBitsToDouble(0x3fe78152195e9e9cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.CheckGlobalThis:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\ud9b4\udc4d\ud8d2\udc40", "\u5a25\u6374\u42b8\u170f\u866c\u3d24\u8aed\u95e1\u4dfb", "\uda74\udd05\ud913\udeae\udace\udf6b\udb16\ude2d\ud814\udc05\udb44\udc55\ud991\uddda\uda6d\udea4\uda2c\udf8c\ud9af\udd7a\ud99a\udd7d\udb0b\udf3a\uda97\udf02\ud8e2\udee5\udad6\udd64\ud8ff\udc2a\uda09\udc86\ud85a\udffc\udb5e\udfe1\ud9b5\udec7",
        25, 40194, 2126707933, 4440765929412204321L, -68073L, false, true, (char) 36220, (char) 9331,
        Double.longBitsToDouble(0x3fe1e05d92d57e88L), Double.longBitsToDouble(0x3fd4f1e869c90a86L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\0121=new com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 2, 4, 4, 3, "\udb0a\uddba", "\u0d55\u6746\ubcee\u42b8\u170f\u866c\u681b\ud544\u0481\u851e", "\ud968\udf12\uda0e\udfcd\udace\udf74\udb16\ude2d\ud814\udc05\u9d87\ud97b\udc84\udb7e\udc2c\uda05\uddc3\ud9af\udd7a\ud99a\udd7d\udb0b\udf3a\uda97\udeed\udaca\ude4c\uda62\udd3a\ud8ff\udc2a\uda09\udc86\ud9bf\udeee\ud9ea\udf76\ud9b5\udec7",
        23, 6591, 2126707933, 4440765929412204321L, 41801L, true, false, (char) 5614, (char) 22877,
        Double.longBitsToDouble(0x3fd4f1e869c90a86L), Double.longBitsToDouble(0x3fd91bc7211de0b4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=com.google.javascript.jscomp.CheckGlobalThis:@?\0121=java.lang.Boolean:false |this=com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 2, 2, 2, 3, "\udb0a\uddba", "\u0d55\u5a25\u6374\u42b8\u170f\u866c\u681b\u8aed\u95e1\u4dfb", "\udbe0\udec9",
        21, 60951, -1152115258, 8276834267419836482L, 79015L, true, false, (char) 63664, (char) 52952,
        Double.longBitsToDouble(0x3fe75dae4dd5ff96L), Double.longBitsToDouble(0x3fcca7349af3ce7cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 1, 4, 4, 2, "\udb0a\uddba", "\u5b42\u5a3f\u6374\u42b8\u2b59\ua707\u681b\u8aed\u95e1\u4dfb", "\uda74\udd05\ud913\udeae\udace\udf6b\udb16\ude2d\ud814\udc05\udb44\udc55\ud991\uddda\udb9b\udc1b\ud83d\udd5d\ud99e\udf43",
        37, 42545, -1626204999, -29635226138364971L, 82182L, true, true, (char) 8242, (char) 38728,
        Double.longBitsToDouble(0x3fcba9333459fb08L), Double.longBitsToDouble(0x3fe909ed02f9a945L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckGlobalThis:@?\012",
        Z.run(T, 1, 4, 1, 4, "\udb0a\uddba", "\u0d55\u5a25\u6374\u42b8\u170f\u70da\u681b\u8aed\u95e1\u4dfb\ud1a4\u2044\ubc8d\u1085\ubc29\u1d7b\u0a5c\u9a4f\u68a0\u0622\u7558", "\udb0b\udf3a\udaa6\udc29\udaf5\udcae\udbed\udec0\ud8e3\udced",
        3, 24709, -503470786, -7236225621814767731L, 95805L, false, true, (char) 54464, (char) 55184,
        Double.longBitsToDouble(0x3fea49b5898681efL), Double.longBitsToDouble(0x3fdfef7659734640L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 3, "\udb0a\uddba", "\u81dd\u8ed8\u6374\u42b8\u170f\u866c\u681b\u8aed\u95e1\u4dfb", "\uda74\udd05\ud913\udeae\udace\udf6b\udbaf\udfaa\u3b72\udb43\udf98\ud991\uddda\udb9b\udc1b\uda2c\udf76\ud9af\udd7a\ud99a\udd7d\udb0b\udf3a\uda97\udf02\udb21\udee4\uda62\udd3a\ud8ff\udc2a\uda09\udc86\ud85a\udffc\udb5e\udfe1\ud9b5\udec7",
        -5, 86450, 2126707933, 4440765929412204321L, -16733L, true, true, (char) 19588, (char) 53684,
        Double.longBitsToDouble(0x3fd4f1ec09c90a86L), Double.longBitsToDouble(0x3fd91bc7211de0b4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.CheckGlobalThis|shouldTraverse|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckGlobalThis:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
    "M|com.google.javascript.jscomp.CheckGlobalThis|getFunctionJsDocInfo|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckGlobalThis:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
    "M|com.google.javascript.jscomp.CheckGlobalThis|shouldReportThis|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckGlobalThis:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
    "M|com.google.javascript.jscomp.CheckGlobalThis|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckGlobalThis:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
    "C|com.google.javascript.jscomp.CheckGlobalThis|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
    "M|com.google.javascript.jscomp.CheckGlobalThis|shouldTraverse|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckGlobalThis:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
