package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class CheckSideEffects_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 1, "\udb9c\udf05\ud8a2\udf7c\uda53\ude1e", "\u0597\uca58\u7ad1", "\udad7\udeb5\uda4a\udff5\ud8da\udd1e\udbcd\udd81\ud9a2\ude46\uda23\udfad\udbe7\udf2b",
        39, 88329, -1819392190, -6302047448742196292L, -89183L, true, true, (char) 26814, (char) 7836,
        Double.longBitsToDouble(0x3fc5cda1d67ac938L), Double.longBitsToDouble(0x3fc3d0a58dd40f20L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 1, "\udb9c\udf05\ud8a2\udf7c\uda53\ude1e", "\u0597\uca58\u7ad1", "\udad7\udeb5\uda4a\udff5\ud8da\udd1e\udbcd\udd81\ud9a2\ude46\uda23\udfad\udbe7\udf2b",
        33, 25049, -1259352974, 4004673798687198140L, -89183L, true, true, (char) 26814, (char) 7836,
        Double.longBitsToDouble(0x3fc5cda1d67ac938L), Double.longBitsToDouble(0x3fc3d0a58dd40f20L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckSideEffects:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 4, "\udb9c\udf05\ud8a2\udf7c\uda53\ude1e", "\u0597\uc263\u7ad1", "\udad7\udeb5\uda4a\udff5\udbcc\udeb6\ud895\udcee\ud9c4\udd81\ud9d8\udcd3\ud8d9\udcb9",
        11, 88329, -1819392190, -6302047448742196292L, -52575L, true, true, (char) 37099, (char) 49893,
        Double.longBitsToDouble(0x3fb414a9ecf59270L), Double.longBitsToDouble(0x3fe14141637503c6L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 5, 1, "\udb9c\udf05\ud8a2\udf7c\uda53\ude1e", "\u5496\uca58\u7ad1", "\udad7\udeb5\uda4a\udff5\ud8da\udd1e\udbcd\udd81\ud9a2\ude46\uda23\udfad\udbe7\udf2b",
        39, 66121, -1812272469, -6302047448742196292L, -89183L, true, true, (char) 26814, (char) 7836,
        Double.longBitsToDouble(0x3fc5cda1d67ac938L), Double.longBitsToDouble(0x3fc3d0a58dd40f20L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 1, "\ud996\udce1\ud8c1\udd71", "\ua8b8\u5a7a\u28b7", "\udb86\udf06\udb67\udc3d\uda32\udcf5\ud8da\udd1e\udbcd\udd81\ud834\udcaf\ud9be\udecb\ud86b\udef0\ud915\ude67\uda58\udc0e",
        55, 17236, 739281852, -3795637446421567280L, 71289L, true, true, (char) 52036, (char) 27761,
        Double.longBitsToDouble(0x3fc3d0a58dd40f20L), Double.longBitsToDouble(0x3fd84afd85fedeaeL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 4, "\udb9c\udf05\ud8a2\udf7c\uda53\ude1e", "\u0597\uca58\u7ad1", "\udad7\udeb5\uda4a\udff5\ud8da\udd1e\udbcd\udd81\ud9a2\ude46\uda23\udfad\udbe7\ude81",
        47, 88329, -1819392190, -6302047448742196292L, -89183L, true, true, (char) 26814, (char) 7836,
        Double.longBitsToDouble(0x3fc5cda1d67ac938L), Double.longBitsToDouble(0x3fc3d0a58dd40f20L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\0121=new com.google.javascript.jscomp.CheckSideEffects:@?\012",
        Z.run(T, 2, 4, 5, 4, "\udb9c\udf05\ud8a2\udf7c\ud9f1\udfcc", "\u0597\u6ff9\u0c38\ua699\u2133\u856d", "\udbcd\udd81\ud9a2\ude46\ud881\udebc\ud89e\ude09\ud913\udcc7\ud907\udf9f\udbc8\udcdd\uda0b\udc14\udaa3\udf3b\ud90d\udde5\u16c7\udb75\udd37\ud87c\ude6f\udb12\udc52",
        24, 20174, 1407142046, -7029073700760010599L, -91376L, false, false, (char) 17256, (char) 16351,
        Double.longBitsToDouble(0x3fdf301c9402e7e6L), Double.longBitsToDouble(0x3fec090b560360a9L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 2, "\udb77\udecd\ud8a2\udf7c\uda53\ude1e", "\u0597\uca58\u7ad1", "\udad7\udeb5\uda4a\udff5\ud99c\udcf7\udbcd\udd81",
        58, 96489, 2137331882, 8785051279422367953L, -10204L, false, true, (char) 23530, (char) 41234,
        Double.longBitsToDouble(0x3fec388bfbcd94f1L), Double.longBitsToDouble(0x3fe06b847cae6d0eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 1, "\udb9c\udf05\ud8a2\udf7c\uda53\ude1e", "\u0597\uaffb\u7ad1", "\udad7\udeb5\u36f7\uda04\udffd\ud97e\udd91\ud9a2\ude46\uda23\udfad\udbfe\ude2b",
        39, 88329, -1818318432, -6302047448738919492L, -89183L, true, true, (char) 26760, (char) 7836,
        Double.longBitsToDouble(0x3fc5cda1d67ac938L), Double.longBitsToDouble(0x3fc3d0a58dd40f20L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckSideEffects:@?\0121=new com.google.javascript.jscomp.CheckSideEffects:@?\012",
        Z.run(T, 2, 5, 5, 3, "\ud9be\udde3\ud88a\udd2e\ud898\udd00", "\u0597\uca58\u7ad1\u0657\u2133\u856d\u26f1\u4c2e\uba46\u0584\u0bed\ua6a7\u2e17\u8097\u86ba\ud193", "\udbd9\udfa3",
        36, 76061, 1829678605, -5598268260674142818L, 40149L, true, true, (char) 39239, (char) 23094,
        Double.longBitsToDouble(0x3fd975f09995a3e0L), Double.longBitsToDouble(0x3fec5c7171ea48aaL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\0121=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\012",
        Z.run(T, 2, 4, 4, 1, "\udb9c\udf05\ud8a2\udf7c\udbd4\udebb", "\u254c\u6c28", "\udb86\udfe2\udae5\udd66\uda4a\udff5\ud8da\udd1e",
        1, 215, 824864960, 9179892607494047128L, 12830L, false, true, (char) 48454, (char) 35667,
        Double.longBitsToDouble(0x3fd50cb5370e22feL), Double.longBitsToDouble(0x3fee6ca78e0d708fL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckSideEffects:@?\0121=new com.google.javascript.jscomp.CheckSideEffects:@?\012",
        Z.run(T, 2, 5, 5, 1, "\udb9c\udf05\ud8a2\udf7c\ud9f9\udfb0", "\u00f8\uca58\u7ad1", "\udad7\udeb5\uda4a\udff5\uda96\udf9b\uda55\udd21\ud9a2\ude46\uda23\udfad\udbe7\udf2b",
        51, 1204, -1819392190, -6302047448742196292L, 66721L, true, true, (char) 26814, (char) 7836,
        Double.longBitsToDouble(0x3fe51c707558adc0L), Double.longBitsToDouble(0x3fc3d0a589d40f20L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckSideEffects:@?\012",
        Z.run(T, 1, 5, 5, 1, "\udb9c\udf05\ud8a2\udf7c\uda53\ude1e", "\u0597\uca58\u7ad1", "\udad7\udeb5\uda4a\udff5\ud8da\udd1e\udbcd\udd81\ud9a2\ude46\uda23\udfad\udbe7\udf2b",
        33, 25049, -1259352974, 4004673799011797436L, -48032L, false, true, (char) 26722, (char) 7836,
        Double.longBitsToDouble(0x3fc5cda1d67ac938L), Double.longBitsToDouble(0x3fc3d0a58dd40f20L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.CheckSideEffects:@?\012",
        Z.run(T, 1, 5, 0, 3, "\udb9c\udf11\ud8a2\udf7c\uda53\ude1e", "\u37fe\u701c\ucfbc", "\udad7\udeb5\uda4a\udff5\ud9c5\udd38\ud895\udcee",
        9, 59131, 1915115013, -8429670181554134040L, -43705L, false, true, (char) 16845, (char) 45735,
        Double.longBitsToDouble(0x3fd9eb24e450519eL), Double.longBitsToDouble(0x3feba81e3733f425L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 1, "\udb9c\udf1b\ud8a2\udf7c\udb1e\udee9", "\u2735\u259d\u7ad1\ua632", "\uda4a\udff5\ud8da\udd1e\udbbe\udefb\ud9a2\ude46\uda23\udfad\udb5c\udc46\ud913\udd01\uda81\udf9c\udbc8\udcdd\uda19\udc14\udb15\ude54\ud917\udcbf\u16c7\udb75\udd37\ud87c\ude6f\ud909\udc7a\udb94\udc19\udb9c\uddbc\ud806\udd33\ud8dd\ude7f\ud900\udce0\uda21\udd19\u884b\ud9a7\uddf6\uda51\udde1\udadd\udc80\udbe1\udf37\ud929\uddf0\ud826\ude10\udb7f\udea5\udb6a\ude97\ud83f\udeca\udbba\uddbb\ud8a4\udd11\udb2c\udca3",
        21, 19537, 1926271341, 8302207748683448849L, 80608L, false, true, (char) 33229, (char) 55987,
        Double.longBitsToDouble(0x3fe43c8f05a2facbL), Double.longBitsToDouble(0x3fafea186909ee00L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CheckSideEffects:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 5, "\ud9e7\udcf5\ud8a4\udf38\ud8e8\uddd3", "\u0597\uca58\u7ad1", "\uda88\udf1f\uda68\udd0d\ud8da\udd1e\udbcd\udd81\ud9a2\ude46\ud884\udcbc\udbe7\udf2b",
        43, 88329, -1819392190, -1209320695322072293L, -89183L, true, true, (char) 35006, (char) 51228,
        Double.longBitsToDouble(0x3fc5cda1d67ac938L), Double.longBitsToDouble(0x3fc3d0a591d40f20L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 1, "\udb9c\udf05\ud8a2\udf7c\uda53\ude1e", "\u0889\u8c74\ub06a", "\udad7\udeb5\uda4a\udff5\ud8da\udd1e",
        1, 55302, -1818710511, 9179892581724243352L, 12830L, false, true, (char) 35142, (char) 12070,
        Double.longBitsToDouble(0x3fdbfcb5370e22feL), Double.longBitsToDouble(0x3fee6ca78e0d708fL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.CheckSideEffects|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckSideEffects:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.CheckSideEffects|addExtern||new:com.google.javascript.jscomp.CheckSideEffects:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.CheckSideEffects|hotSwapScript|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckSideEffects:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.CheckSideEffects|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckSideEffects:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.CheckSideEffects|protectSideEffects||new:com.google.javascript.jscomp.CheckSideEffects:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "C|com.google.javascript.jscomp.CheckSideEffects|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
    "M|com.google.javascript.jscomp.CheckSideEffects|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CheckSideEffects:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CheckLevel,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
