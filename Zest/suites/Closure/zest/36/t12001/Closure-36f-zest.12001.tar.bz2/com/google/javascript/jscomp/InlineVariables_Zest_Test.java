package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class InlineVariables_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.InlineVariables$IdentifyConstants:@? |this=com.google.javascript.jscomp.InlineVariables:@?\0121=com.google.javascript.jscomp.InlineVariables$IdentifyConstants:@? |this=com.google.javascript.jscomp.InlineVariables:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud8a9\udd03", "\u3426\ua992\u2de0\u5f4e\u19e3\u0e03\ud750\uaccd\u76ee", "\ud890\ude76\udb6f\ude36\ud907\udef0\udab3\udc3f\ud865\udd86\ud8db\udd26",
        9, 29189, -76777499, 1943265323463237859L, 87325L, false, true, (char) 26725, (char) 53302,
        Double.longBitsToDouble(0x3fec9ca9945eac62L), Double.longBitsToDouble(0x3fd9b33d7b2f9baeL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\ud8a9\udd03", "\u3426\ua992\u2de0\u5f4e\u19e3\u0e03\ud750\u57da\u7640", "\ud890\ude30\udb6f\ude36\ud907\udef0\udab3\udc3f\ud865\udd86\ud8db\udd26",
        48, 29189, -76777499, 1943265323463237859L, 87325L, false, true, (char) 2149, (char) 32303,
        Double.longBitsToDouble(0x3fec9ca9945eac62L), Double.longBitsToDouble(0x3fd9b33d7b2f9baeL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\ud8a9\udd03\udab2\uddb9\udb5c\udf31\ud859\udf16\udb59\udf6b\uda07\udfc3\ud965\udfd5\udaae\udcb9\ud82a\udc4c\ud84b\udf61\ud94f\udec3\ud89a\udd72\udbd9\ude2d\uda12\udd13", "\u00cd\u27cf", "\ud857\udf24\uda84\udd50\udbd3\udf9f\udaf4\uddc1\ud848\udc07\uda6e\udfc7\udbe6\udeb7\ud83a\udf45\ud86d\udd79\ud9d0\udd09\uda14\udea5",
        25, 40423, -735298850, 5802447970329776602L, 31154L, false, true, (char) 5384, (char) 29008,
        Double.longBitsToDouble(0x3fd77d880001632cL), Double.longBitsToDouble(0x3fc7674c08250b20L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=com.google.common.base.Predicates$ObjectPredicate$1:ALWAYS_TRUE |this=com.google.javascript.jscomp.InlineVariables:@?\0121=com.google.common.base.Predicates$ObjectPredicate$1:ALWAYS_TRUE |this=com.google.javascript.jscomp.InlineVariables:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud8a9\udd03", "\u3426", "\ua400\000\uda4d\uddbf\udae6\udca9\ud88e\udfc7\ud89a\ude02\udbd9\ude2d",
        5, 33023, 1961531219, 202877075193856L, 60789L, false, false, (char) 104, (char) 21253,
        Double.longBitsToDouble(0x3fd84fb6c00035eeL), Double.longBitsToDouble(0x3fd00000017af95aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "\ud8a9\udd03\udab2\uddb9\udb5c\udf31\ud859\udf16\ud8f3\udf78\udaeb\ude22\udb01\udcaa\udb15\udc2a\uda4d\uddbf\ud84d\udfbc\ud8a9\udd7d\ud89a\ude02\ud91f\udde7\uda18\udceb\udbd2\ude77", "\u8765\u4df2\uc592\u1981\ud7c7\u6a78\u6d7a\ub8b8\u4500\uaed7\u58bd\uc03a\u2d50\u4c79\u21cf\u3228\u7dbf\u0b9d\u7e22\u13d8\u5c29\ub4fd\u15cd\u977e\u8ddf\uc9e2\u5fc0\ud5c9\u700a\u5a7a\ub34f\u7311\u331a\u903c\u8e68\u0a48\u6c91", "\ud92f\udc46\u934b\uda03\uded9",
        42, 81328, 129513713, 6583829017750521889L, -32717L, false, false, (char) 8689, (char) 7270,
        Double.longBitsToDouble(0x3fd7ab7407c4ccf4L), Double.longBitsToDouble(0x3fdd2781358df264L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.InlineVariables$IdentifyLocals:@? |this=com.google.javascript.jscomp.InlineVariables:@?\0121=com.google.javascript.jscomp.InlineVariables$IdentifyLocals:@? |this=com.google.javascript.jscomp.InlineVariables:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud8a9\udd03", "\u33d5\ua992\u2de0\u5f4e\u19e3\u0e03\u1910\u5efd\u7708", "\udb31\udd48\udb6f\ude36\ud907\udef0\udab3\udc3f\ud865\udd86",
        43, 22619, -618695811, -2203254293216633468L, 25243L, true, true, (char) 46514, (char) 26725,
        Double.longBitsToDouble(0x3fef35a287939532L), Double.longBitsToDouble(0x3fb7ab18abbec6b8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\ud8a9\udd03", "\u7ad9\uaa39\u33d6\u06c5\u19e3\u0e03\ud750\uaccd\u76ee", "\ud890\ude76\udb6f\ude36\ud907\udef0\udab3\udc3f\ud865\udd86\ud8db\udd26",
        56, 6720, 335571534, 1943265280513564899L, 87325L, false, true, (char) 26725, (char) 53029,
        Double.longBitsToDouble(0x3fec9caa745eac62L), Double.longBitsToDouble(0x3fd9b33d7b2f9baeL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.google.common.base.Predicates$ObjectPredicate$1:ALWAYS_TRUE |this=com.google.javascript.jscomp.InlineVariables:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 0, "\ud8b5\udd09\udab2\uddb9\udb98\udf10\ud963\udcf0\uda1c\udc7a\udb45\udf76\ud965\udfd5", "\u0e23\u1a19\u0d6b\u661f\ud0e3\u5431\uc9e4\u00cd\u035e\ub1ae\u448a\u1981\u82c8", "\uda4c\udd22\udbee\udc93\udb60\udfc5\ud8fd\ude83\ubbde\ud9f8\ude43\uda14\udea5\ud82d\udf6c\ud96b\udea4\udb5a\udfb5\uda57\udd49\ud9ce\udec8\u057c\udb9f\ude6d\ud881\udcaf\ud9e8\udf35\ud965\udd55\ud842\udd37\ud8a0\udc31",
        56, 66742, 90993529, -3328547094105821407L, -41381L, false, true, (char) 17042, (char) 50964,
        Double.longBitsToDouble(0x3fe85558be5fc605L), Double.longBitsToDouble(0x3fdfe37ff4818abaL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\udb36\ude02\ud9fd\udda1\ud801\ude29\ud98a\ude96\ud878\udf50\udb29\udf25\udb96\ude0e\udaae\udcb9\uda4d\uddbf\ud84d\udfbc\ud8a9\udd7d\ud89a\ude02\udbd9\ude2d\uda12\udd13\ud890\ude76\ud93f\udcbe\ud8fa\uddb0\udb33\udfff\ud91e\ude18\udbfc\uddf2\ud857\udeb1\uda84\udd50\udbd3\udf9f\udb65\udf1a\uda2c\uddac\udbee\udc93\udb68\udcb5\ud9fe\udd75\udb58\udea7\ud980\udf3a\ud9e9\udfdc\ud82d\udf6c\ud8f0\udea6\udbe9\udd01\uda2f\udcf2\ud84a\udfaa\udb82\udc90\ud8e6\udc68\ud822\udfc8\ud971\udeba\ud946\ude3b\ud8f1\udf66\ud885\udd59\uda4c\uddd5\ud93a\udf3b\uda56\ude13\ud94a\ude89\ud87b\udccc\ud8bf\udfbc\udbe5\udcde\ud918\udcda\udb1e\udf00\udb61\udda9\udbf1\ude99\udbe9\ude86\udb5a\udeb7\udb45\ude78\udac7\udc2d\udb01\ude43", "\u147b\u1a1f\u2220\u6861\u508d\u8a99\ucd09\u71d4\ud485\u8880\ud3dc", "\udb5d\uddaf\uda35\udd37\uda8b\ude6f\ud973\udd1a\udb7d\udcbc",
        26, 20492, 507483277, -5069801212539898148L, 91903L, false, true, (char) 9154, (char) 19410,
        Double.longBitsToDouble(0x3fee3167f7dd09a1L), Double.longBitsToDouble(0x3fe0afa43aaca0a0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.InlineVariables$IdentifyConstants:@? |this=com.google.javascript.jscomp.InlineVariables:@?\0121=com.google.javascript.jscomp.InlineVariables$IdentifyConstants:@? |this=com.google.javascript.jscomp.InlineVariables:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud8a9\udd03", "\u3426\ua992\u2de0\u5f4e\u19e3\u0e03\ud750\u78d6\u27e8", "\ud890\ude76\udb6f\ude36\ud907\udef0\udab3\udc3f\ud865\udd86\ud8db\udd26",
        9, 29189, -76777499, 1943265323463237859L, 87325L, false, true, (char) 26725, (char) 53302,
        Double.longBitsToDouble(0x3fec9ca9945eac62L), Double.longBitsToDouble(0x3fd9b33d7b2f9baeL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.InlineVariables|getFilterForMode||new:com.google.javascript.jscomp.InlineVariables:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.InlineVariables$Mode,boolean",
    "M|com.google.javascript.jscomp.InlineVariables|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.InlineVariables:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.InlineVariables$Mode,boolean",
    "C|com.google.javascript.jscomp.InlineVariables|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.InlineVariables$Mode,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
