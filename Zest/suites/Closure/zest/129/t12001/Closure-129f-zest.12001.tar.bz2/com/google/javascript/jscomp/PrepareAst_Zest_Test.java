package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class PrepareAst_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PrepareAst:@?\012",
        Z.run(T, 1, 2, 0, 1, "\ud915\udc3c\ud821\udfe9\udbf9\ude27\ud879\ude1f\ud86f\udc85\uda70\udc10\udacf\udef1\udb76\udde1\ud922\udc1f\ud8ec\ude1a", "\ub166\u345f\u1bd7\u3848\u6b2f\ua164\uafa4\uadaa\u2384", "\ud947\udd04\ud96c\udcce\ud857\udd34\ud929\udc6f\ud92b\udf8d\udb28\udf12\u54d3\ud922\udd2d\uda24\udfdb\ud96b\udfce\udb0c\uddf5\ud8e2\udfee",
        23, 26138, -1014327815, 2957554406742470858L, -26869L, true, true, (char) 28679, (char) 40181,
        Double.longBitsToDouble(0x3feacce407758d80L), Double.longBitsToDouble(0x3fe3f959de285627L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PrepareAst:@?\012",
        Z.run(T, 1, 2, 0, 1, "\ud915\udc3c\ud821\udfe9\udbf9\ude27K\udba5\ude11\uda70\udc10\udacf\udef1\udb76\udde1\ud922\udc1f\ud8ec\ude1a", "\u0088\u345f\u1bd7\u3848\u6b2f\ua164\uafa4\uadaa\u2384", "\ud947\udd04\udb56\udcc3\ud857\udd34\ud929\udc6f\ud92b\udf8d\udb28\udf12\u54d3\ud922\udd2d\uda24\udfdb\ud96b\udfce\udb0c\uddf5\ubaf4",
        24, 26138, -1014327815, 2957554406742470858L, -26869L, true, true, (char) 28679, (char) 40181,
        Double.longBitsToDouble(0x3fe804e407758d80L), Double.longBitsToDouble(0x3fe3f959de285627L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PrepareAst:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 1, "\ud915\udc3c\ud821\udfe9\udbf9\ude27\ud879\ude1f\ud86f\udc85\uda70\udc10\udacf\udef1\udb76\udde1\ud922\udc1f\ud8ec\ude1a", "\ub166\u345f\u1bd7\u3848\u6b2f\ua164\uafa4\uadaa\u2384", "\ud947\udd04\ud96c\udcce\ud857\udd34\ud929\udc6f\ud92b\udf8d\udb28\udf12\u54d3\ud922\udd2d\uda24\udfdb\ud96b\udfce\ud95d\ude9b\ud8e2\udfee",
        23, 26138, -1240164871, 2957554406742470858L, -26869L, true, true, (char) 28679, (char) 40181,
        Double.longBitsToDouble(0x3feacce407758d80L), Double.longBitsToDouble(0x3fe3f959de285627L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PrepareAst:@?\012",
        Z.run(T, 1, 3, 2, 1, "\ud915\udc3c\ud821\udfe9\udbf9\ude27\ud879\ude1f\ud86f\udc85\uda70\udc10\uda63\udcf1\udb76\udde1\ud922\udc83\ud8ec\ude1a", "\ub166\u345f\u1bd7\u3848\u6b2f\ua164\u61b7\ud633\ua93b", "\ud947\udd04\ud8dd\udf86\ud831\udfe0\ud929\udc6f\uda1c\udde4\udb28\udf31\u54d3\ud922\udd2d\uda24\udfdb\ud96b\udfce\udb0c\uddf5\ud8e2\udfee",
        23, 25983, -1014327815, 2957554406742470858L, -26869L, true, true, (char) 28679, (char) 40181,
        Double.longBitsToDouble(0x3feacce407758d80L), Double.longBitsToDouble(0x3fe3f959de285627L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PrepareAst:@?\012",
        Z.run(T, 1, 3, 1, 0, "\ud915\udc3c\u90ea\udbf9\udeb2\ud879\ude1f\ud86f\udc85\uda70\udc10\udacf\udef1\udb76\udde1\ud922\udc1f\ud8ec\ude1a", "\ub166\u691d\u2c18\u05f9\u361e\ua164\uafa4\uadaa\u495d", "\ud947\udd04\ud96c\udcce\ud857\udd34\ud929\udc6f\ud9ee\udfed\udb28\uded3\ud8b2\ude7a\ud93d\udfda\uda24\udfdb\udabf\udfd9\udb0c\uddf5\ud8e2\udfee",
        23, 24842, -406513716, 6052409418327759355L, -66303L, true, true, (char) 28679, (char) 40181,
        Double.longBitsToDouble(0x3feacce401048d80L), Double.longBitsToDouble(0x3fe1cf2a480704dbL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PrepareAst:@?\012",
        Z.run(T, 1, 4, 3, 1, "\udaf2\udca5\uda7a\uddce\ud8e5\ude08\ud83e\udf6c\u89c1\uda1e\ude03\ud946\ude46\udb76\udd92\ud922\udc1f\ud8ec\ude1a", "\ub166\u0e98\u21d4\u8803\u6af0\ua164\uafa4\u2b8a\ua5bd", "\ud947\udd04\ud94e\udd55\ud857\udd34\ud929\udc6f\ud92b\udf8d\udb28\udf12\ud8a6\ude3b\ud8e7\udc0d\ud869\ude9f\udbca\ude09",
        52, 28380, -1688035486, 1494962743313010937L, 10794L, true, true, (char) 37647, (char) 58527,
        Double.longBitsToDouble(0x3fe8bf6f874de21eL), Double.longBitsToDouble(0x3feacce097758d80L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 1, "\ud915\udc3c\ud821\udfe9\udbf9\ude27\ud879\ude1f\ud86f\udc85\uda70\udc10\udacf\udef1\udb7f\ude66\ud922\udc1f\ud8ec\ude1a", "\ub166\u345f\u1bd7\u3848\u6b2f\ua164\ud226\ub694\u9194", "\ud947\udd04\ud96c\udcce\ud857\udd34\ud929\udc6f\ud92b\udf8d\udb28\udf12\u54d3\ud922\udd2d\uda24\udfdb\ud96b\udfce\udb0c\uddf5\ud8e2\udfee",
        23, 70498, -1014327815, 2957554406739980490L, -54687L, true, true, (char) 58094, (char) 47815,
        Double.longBitsToDouble(0x3fef494d1f758d80L), Double.longBitsToDouble(0x3fe3f959de285627L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 4, 4, "\ud8b1\udf30\ud812\udf40\udbf9\ude27\udb09\ude27\ud86f\udc85\uda70\udc10\udacf\udef1\udb76\udde1\ud922\udc1f\udbfd\ude4f", "\u9a73\u345f\u4e9e\u3848\u6b2f\ua164\uafa4\uadaa\u3463\ua54a", "\ud96c\udcce",
        3, 65848, 1909618960, 1439099734256423292L, 49321L, false, true, (char) 48404, (char) 16427,
        Double.longBitsToDouble(0x3fe65c46b4b29bcdL), Double.longBitsToDouble(0x3fdf914bf0218714L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 3, 2, "\ud915\udc3c\ud821\udfe9\udbf9\ude27\ud879\ude1f\uda38\udc0a\uda70\udc10\udacf\udef1\udb76\udde1\ud922\udc1f\ud8ec\ude1a", "\u0b3d\u345f\u1bd7\u3848\u6b2f\ua164\u9f4a\uadaa\u2384", "\ud986\ude83\ud96c\udcce\udae9\udd9d\udb76\udf6b\udad2\udc55\udb28\udf82\u54d3\ud922\udd2d\uda24\udfdb\ud96b\udfce\udb0c\uddf5\ud8e2\udfee",
        23, 3482, -1014327818, 2957554405974555987L, -26855L, true, true, (char) 28679, (char) 40181,
        Double.longBitsToDouble(0x3feacce407758d80L), Double.longBitsToDouble(0x3fe3f959de285627L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PrepareAst:@?\0121=void |this=com.google.javascript.jscomp.PrepareAst:@?\012",
        Z.run(T, 2, 4, 3, 1, "\ud915\udc3c\ud821\udfe9\udbf9\ude27\ud879\ude1f\ud86f\udc85\uda70\udc10\ud88b\ude50\ud881\udff7\udb02\udccf\ud8ee\udf89\ud8d6\udcd6\udab9\ude72\udaf5\udedb\ud9e5\udcaa\ud822\udfb7\ud897\udcf9\ud981\ude4e\udadc\ude4e\ud9b0\udf7f\udb1b\udcfb\ud8a6\udd1f\uda59\udeca", "\u1e05\u2777\u86c7\u08b1\u7fe8\u3aa1\u08d5\u0d94\u3cd3\u9956\uca89\u282b\u1622\u2cef\u50cc", "\uda3f\udf66\udaad\udc94\udab9\ude58\ud874\udc02\ud82b\udd36\ud962\uded5",
        29, 13896, -847988415, 165527186158143298L, 21404L, true, true, (char) 50037, (char) 28188,
        Double.longBitsToDouble(0x3fe13257777925ebL), Double.longBitsToDouble(0x3fec9640f88b98feL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PrepareAst:@?\0121=void |this=com.google.javascript.jscomp.PrepareAst:@?\012",
        Z.run(T, 2, 2, 2, 3, "\ud934\udc01\ud821\udfe9\udb61\udee1\ud9d8\udf80\ud86f\udc85\uda70\udc10\udacf\udef1\udb76\udde1\ud922\udc1f\udbec\udc8d", "\ub166\u345f\ua227\u07e0\u6b2f\ua164\uafa4\uadaa\u2384\u5feb\u9f1d\u4609\u5dfb\u85fc\u0d98\u08b1\u3e80\u064b\u2a50", "\ud97e\ude72\ud8e2\udfee\ud806\udcf9\udbfd\udd66\ud937\udc40\udb13\udf4a\ud8da\udf40\ud8c5\udd18\ud350\ud839\udea3\ud956\ude3e\uda11\udeb6\uda71\udc99\ud9d5\udc95\ud82d\udcf5\ud8b1\ude27\u6187",
        40, 98131, 1109971177, -5849160428696195910L, 93656L, false, false, (char) 60824, (char) 48348,
        Double.longBitsToDouble(0x3fbed0e3e47bd8f8L), Double.longBitsToDouble(0x3fe0c5a3bbd40037L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PrepareAst:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 3, "\ud915\udc3c\ud821\udfe9\udbf9\ude27\ud879\ude1f\ud86f\udc85\uda70\udc10\udacf\udef1\udb76\udde1\ud922\udc1f\ud8ec\ude1a", "\ub166\u345f\u1bd7\u3848\u6b2f\ua164\uafa4\ub939\u2648", "\ud947\udd04\ud96c\udcce\ud857\udd34\ud929\udc6f\ud92b\udf8d\udb28\udf12\ud869\udd72\ud922\udc8a\uda24\udfdb\ud96b\udfce\ud95d\ude9b\ud8e2\udfee",
        23, 26138, -1240164871, 2957554406742470858L, -26869L, true, true, (char) 28679, (char) 40181,
        Double.longBitsToDouble(0x3feacce407758d80L), Double.longBitsToDouble(0x3fe3f959de285627L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PrepareAst:@?\0121=new com.google.javascript.jscomp.PrepareAst:@?\012",
        Z.run(T, 2, 4, 4, 1, "\ud915\udc3c\ud821\udfe9\udbf9\ude27\ud879\ude1f\ud86f\udc85\uda70\udc10\udacf\udef1\udb76\udde1\ud937\udfa3\ud8ec\ude1a", "\ub166\u345f\u1bd7\u3848\u6b2f\ua164\uafa4\uadaa\u2384", "\ud947\udd04\ud96c\udcce\ud857\udd34\ud929\udc6f\ud92b\udf8d\udb28\udf12\u54d3\ud922\udd2d\uda24\udfdb\ud96b\udfce\ud95d\ude9b\ud8e2\udfee",
        23, 26138, -1240164871, 2957554406742470858L, -26869L, true, true, (char) 28679, (char) 25589,
        Double.longBitsToDouble(0x3feacc142f758d80L), Double.longBitsToDouble(0x3fe3f959de285627L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PrepareAst:@?\0121=void |this=com.google.javascript.jscomp.PrepareAst:@?\012",
        Z.run(T, 2, 3, 3, 4, "\ud915\udc3c\ud821\udfe9\ud84a\udf2e\ud8fd\udcd2\ud86f\udcd3\udb91\udddb\ud8ef\udf43\udb76\ude28\ud915\udfb9\ud8ec\ude1a", "\ub66d\u345f\u1bd7\u49ae\u9257\ua114\u5f22\u5653\u2384", "\ud9a5\udd13\ud918\udf81\ud857\udd65\ud929\udc6f\ud92b\udf8d\udb28\udf12\u54d3\udbae\udd12\uda33\uddc4\u92cc\udb86\udc3f\ud8ea\udceb",
        23, 26138, -1240164871, 2957554406742470858L, -26869L, true, true, (char) 48493, (char) 24094,
        Double.longBitsToDouble(0x3feb7750a775b761L), Double.longBitsToDouble(0x3fe3f959de285627L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.PrepareAst:@?\012",
        Z.run(T, 1, 4, 0, 0, "\ud915\udc3c\ud821\udfe9\udbf9\ude27\ud879\ude1f\ud86f\udc85\ud972\udc11\uda4e\udff1\ud8aa\udfda", "\u3940\u4a67\ub166\u345f\u1bd7\u68a0\ud581\u0cb3\ua545\u66f1\ua951\u0a5a", "\ud8dd\udf86",
        43, 43440, -1316065660, -2761632959909265751L, 49504L, false, true, (char) 6376, (char) 1090,
        Double.longBitsToDouble(0x3feb5a17c4179b62L), Double.longBitsToDouble(0x3fdf914bf0218714L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PrepareAst:@?\012",
        Z.run(T, 1, 2, 0, 0, "\ud915\udc3c\ud828\udee5\udbf9\ude27\ud879\ude1f\ud86f\udc85\uda70\udc10\udba4\udc1d\udb76\udde1\ud922\udc1f\ud8ec\ude1a", "\ub166\u345f\u1bd7\u3848\u6b2f\u8ae0\u487d\uadaa\u2384", "\ud947\udd04\ud96c\udcce\ud857\udd34\ud929\udc6f\ud92b\udf8d\udb28\udf12\u54d3\ud922\udd2d\uda24\udfdb\ud96b\udfce\udb0c\uddf5\ud8e2\udfee\ud80c\udd7d\udbfd\uddea\udb84\ude68\ud8ae\ude7b\ud8da\udf40\u9011\ucf5c\ud86f\udd95\ud8ee\ude15\udb95\ude43\uda71\udc99\ud8ac\ude01\udaee\udf92\ud8ac\uded4\udaf9\ude01\udb07\ude71\ud971\ude8b\ud80d\udf94\ud9b5\udc75",
        -4, 34749, 807902701, -6991788301028961047L, 32705L, true, false, (char) 34974, (char) 31017,
        Double.longBitsToDouble(0x3fec0bfa00050082L), Double.longBitsToDouble(0x3fd74668124f02d8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PrepareAst:@?\0121=void |this=com.google.javascript.jscomp.PrepareAst:@?\012",
        Z.run(T, 2, 3, 3, 0, "\ud915\udc3c\u90ea\ud95a\udf21\udb32\ude42\ud86f\udcfb\uda70\udc10\udacf\udef1\udb76\udde1\ud922\udc1f\ud8c5\udf86", "\ud7fd\u691d\ud294\u6aec\u361e\ua164\uafa4\uadaa\u495d", "\u9ac6\ud95c\udfd4\ud987\udce3\ud8fe\udc48\ud9ee\udfed\ud860\udeae\ud8b2\ude7a\ud93d\udfda\uda24\udfdb\udb29\udf8d\ud9c4\udef2\ud8bf\udcf6",
        12, 24761, -406513716, 6052409418943273467L, -53549L, true, true, (char) 14600, (char) 23818,
        Double.longBitsToDouble(0x3feacce401048d80L), Double.longBitsToDouble(0x3fe1cf2a4d0704dbL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PrepareAst:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\ud915\udc18\ud821\udfe9\udbf9\ude27\ud879\ude1f\ud86f\udc85\uda70\udc10\udacf\udef1\udb4f\udf75\ud922\udc1f\ud8ec\ude1a", "\ub166\u345f\u1bd7\u759e\u6b2f\ua164\uafa4\ub939\u2648", "\ud947\udd04\ud96c\udcce\ud857\udd34\ud94a\udd7f\ud942\udedd\udb28\udf12\ud869\udd72\ud922\udc8a\uda24\udfdb\ud96b\udfce\ud95d\ude9b\ud8e2\udfee",
        23, 26138, -1240164871, 2957554406742470858L, -26869L, true, true, (char) 28679, (char) 40181,
        Double.longBitsToDouble(0x3feacce407758d80L), Double.longBitsToDouble(0x3fe3f959de285627L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.PrepareAst:@?\012",
        Z.run(T, 1, 2, 2, 1, "\ud915\udc7a\ud821\udfe9\udbf9\ude27\ud879\ude1f\ud909\udfa4\ud811\udfdd\udacf\udef1\udb76\udde1\ud895\udc98\ud9cc\udddb", "\ub166\u345f\u1bd7\u3848\u6b2f\ua164\uafa4\uadaa", "\ud8a4\udca3\ud947\udd04",
        10, 35329, -747688337, -4790446720466784754L, -56873L, true, true, (char) 36863, (char) 48404,
        Double.longBitsToDouble(0x3fe7a03b476b88d6L), Double.longBitsToDouble(0x3fc6536c57e452fcL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.PrepareAst|normalizeBlocks|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PrepareAst:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.PrepareAst|normalizeNodeTypes|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PrepareAst:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.PrepareAst|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PrepareAst:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.PrepareAst|reportChange||new:com.google.javascript.jscomp.PrepareAst:com.google.javascript.jscomp.AbstractCompiler",
    "C|com.google.javascript.jscomp.PrepareAst|<init>|com.google.javascript.jscomp.AbstractCompiler",
    "C|com.google.javascript.jscomp.PrepareAst|<init>|com.google.javascript.jscomp.AbstractCompiler,boolean",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
