package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class FunctionTypeBuilder_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 9, 9, "\ud869\udf8e\uda2e\ude99\udab7\udea7\ud893\uddcb\udac9\udf78\ud9eb\udcaa\uda57\udf98\ud80c\udc78\uda98\udf8a\uc321\uda9f\udc56\u1456\udbeb\ude78\udacd\udc0f\ud9a7\udeac\udb9a\ude8c\udb15\ude35\udb00\udc30\ud86a\ude1c\uda03\udede\udb94\udcec\ud99b\udd7d\ud924\udf48\uda14\udeac\udb59\udc3f\ud801\udc94\ud8f3\ude79\udb90\udcb4\udb27\udfe9\ud97d\udf1d\ud904\udf69\uda82\udd7a\uda70\udc3a\ud879\ude14\udad7\ude68", "\u934e\u61b1\u65a3\u7ec3\u7c2a\uab46", "\uda30\udcee\ud818\udf6e\uda88\udcc3\ud9b0\udf11\ud950\udfbd\uda3c\ude26\ud992\udffc\ud991\udec1\udb75\udd55\uda7e\udd93\udb73\ude17\uda92\udf64\ud9fc\ude4a\ud9fb\udd91\uda65\udec4\ud947\ude0f\ud866\ude1f\uda07\udea9\uda0b\uddf3\ud864\udd46\udb7c\udd6c",
        13, 73816, 786465663, -1670258151967996188L, -4363L, true, true, (char) 14712, (char) 22153,
        Double.longBitsToDouble(0x3fa106f0b5135110L), Double.longBitsToDouble(0x3fc66a6ee774bfdcL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 9, 9, "\ud869\udf8e\uda2e\ude99\udab7\udea7\ud893\uddcb\udac9\udf78\ud9eb\udcaa\uda57\udf98\ud80c\udc78\uda98\udf8a\uc321\uda9f\udc56\u1456\udbeb\ude78\udacd\udc0f\ud9a7\udeac\udb9a\ude8c\udb15\ude35\udb00\udc30\ud86a\ude1c\uda03\udede\udb94\udcec\ud99b\udd7d\ud924\udf48\uda14\udeac\udb59\udc3f\ud801\udc94\ud8f3\ude79\udb90\udcb4\udb27\udfe9\ud97d\udf1d\ud904\udf69\uda82\udd7a\uda70\udc3a\ud879\ude14\udad7\ude68", "\u934e\u61b1\u65a3\u7ec3\u7c2a\uab46", "\uda30\udcee\ud818\udf6e\uda88\udcc3\ud9b0\udf11\ud950\udfbd\uda3c\ude26\ud992\udffc\ud991\udec1\udb75\udd55\uda7e\udd93\udb73\ude17\uda92\udf64\ud9fc\ude4a\ud9fb\udd91\uda65\udec4\udb6b\udf40\ud890\udcf5\uda07\udea9\uda0b\uddf3\ud864\udd46\udb7c\udd6c",
        13, 73816, 786465663, -1670258151967996188L, -4363L, true, true, (char) 14712, (char) 51081,
        Double.longBitsToDouble(0x3fe472f833513511L), Double.longBitsToDouble(0x3fc66a6ee774bfdcL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "\ud869\udf8e\uda2e\ude99\udab7\udea7\ud893\uddcb\udac9\udf78\ud9eb\udcaa\uda57\udf98\ud80c\udc78\uda98\udf8a\uc321\uda9f\udc56\u1456\ud8ee\udd3a\udacc\udf47\ud9a7\udeac\udb9a\ude8c\udb15\ude35\udb00\udc30\ud86a\ude1c\uda03\udede\000\ud997\udfab\ud924\udf48\uda14\udeac\udb59\udc3f\ud801\udc94\ud8f3\ude79\udb90\udcb4\udb27\udfe9\ud97d\udf1d\ud904\udf69\uda82\udd7a\u00c7\000\udace\uddc6", "\u934e", "\ud806\udde3\ud9ee\ude5a\u8cdd\ud87b\udc2b\udb80\udc53\uda30\udcee\ud818\udf6e\uda88\udcc3\ud9b0\udf11\ud97e\ude93\ud2c4\ud992\udffc\ud991\udec1",
        -5, 84696, 12138310, -1657324664175096098L, 82855L, true, false, (char) 10021, (char) 14461,
        Double.longBitsToDouble(0x3fee4116aa1924d2L), Double.longBitsToDouble(0x3fc5fe40dad21358L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 9, 9, "\ud869\udf8e\uda2e\ude99\udb7b\udfad\uda02\udfc1\udac9\udf78\ud9eb\udcaa\uda57\udf98\ud80c\udc78\uda98\udf8a\uc321\uda9f\udc56\u1456\udbeb\ude78\udacd\udc0f\ud9a7\ude68\uda1c\uddcc\udb45\udce2\ud81d\udce6\ud86a\udd75\uda03\udede\udb94\udcec\ud99b\udd7d\ud924\udf48\uda14\udeac\udb59\udc3f\ud801\udc94\ud8f3\ude79\udb90\udcb4\udb27\udfe9\ud97d\udf1d\ud904\udf69\uda82\udd7a\uda70\udc3a\ud879\ude14\udad7\ude68", "\u934e\u61b1\u65a3\u7ec3\u2056\u3f0a", "\ud801\udc74\udb4a\ude32",
        21, 44206, 1729979111, 9051729444896577142L, -65706L, false, false, (char) 53960, (char) 12396,
        Double.longBitsToDouble(0x3fe34da1c15b2fc2L), Double.longBitsToDouble(0x3fec27eee0ff118cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 9, 9, "\ud869\udf8e\ud92e\udda7\ud8f2\udd6a\ud893\uddcb\ud941\udc55\udb6a\udeeb\ud8aa\udfed\ud83e\ude5b\ud857\ude95\uc38d\uda9f\udc56\u1456\ud99c\udd2c\udaaa\udc3d\ud9a7\ude49\udbca\uddc3\udb15\ude06\udb00\udc30\ud86a\ude1c\uda03\udede\udb94\udcec\ud99b\udd7d\ud924\udedf\uda14\udeac\udb59\udc3f\ud801\udc94\ud85b\ude8c\ud913\udc99\udb0b\udf2e\ud97d\udf1d\udb0b\ude64\uda82\udd7a\uda76\udd3f\ud879\ude14\udad7\ude68", "\u934e\u9820\u99cc\u7ec3\u85f1\ubce5", "\udba8\udeb6\udafd\udcbc",
        4, 48139, -1932731760, 9029948991428753496L, 66622L, true, false, (char) 50320, (char) 45577,
        Double.longBitsToDouble(0x3fe6f74eb15bb259L), Double.longBitsToDouble(0x3fdb9bfbd0982f7aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 9, "\ud869\udf8e\udb8d\ude7b\udab7\udea7\ud893\uddcb\udac9\udf78\ud9eb\udcaa\uda57\udf98\ud80c\udc78\uda98\udf8a\uc321\uda9f\udc56\u1456\udbeb\ude78\udacd\udc0f\ud9a7\udeac\udb9a\ude8c\udb15\ude35\udb00\udc30\ud86a\ude1c\uda03\udede\udb94\udcec\ud99b\udd7d\ud924\udf48\uda14\udeac\udb59\udc3f\ud801\udc94\ud8f3\ude79\udb90\udcb4\udb27\udfe9\ud97d\udf1d\ud904\udf69\uda82\udd7a\ud99d\udcb1\ud879\ude14\uda79\ude59", "\u9325\u61b1\u65a3\u7ec3", "\udbb1\udde5\udbaa\udd09\uda30\udcee\ud818\udf6e\uda88\udcc3\ud9b0\udf11\ud950\udfbd\uda3c\ude26\ud992\udffc\ud991\udec1\udb75\udd55\uda7e\udd93\ud91f\ude0d\uda92\udf64\ud9fc\ude4a\ud9fb\udd91\uda65\udec4\ud947\ude0f\ud866\ude1f\ud8bc\udcd8",
        49, 41921, 1340082351, -7322769573167368472L, 34415L, false, false, (char) 45983, (char) 54239,
        Double.longBitsToDouble(0x3fd338f45925a9caL), Double.longBitsToDouble(0x3fcc15b530883784L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 9, 9, "\ud869\udf8e\uda2e\ude99\udab7\udea7\ud893\uddcb\udac9\udf78\uda56\udd7f\ud9f6\udf5f\ud817\udc3e\uda98\udf8a\uc321\uda9f\udc56\u1456\udbeb\ude78\udacd\udc0f\ud9a7\udeac\udb9a\ude8c\udb15\ude35\udb00\udc30\ud86a\ude1c\uda03\udede\udb94\udcec\ud99b\udd7d\ud924\udf48\uda14\udeac\udb59\udc3f\ud801\udc94\ud8f3\ude79\udb90\udcb4\udb27\udfe9\ud97d\udf1d\ud904\udf69\uda82\udd7a\ud8ea\ude1f\ud866\uddaf\udad7\ude68", "\u934e\u61b1\u65a3\u7ec3\u7c2a\uab46", "\uda30\udcee\ud818\udf6e\uda88\udcc3\ud9b0\udf11\ud950\udfbd\uda05\udcab\ud992\udffc\ud991\udec1\udb75\udd55\uda7e\udd93\udb73\ude17\uda92\udf64\ud9fc\ude4a\uda81\udd94\uda65\udec4\ud947\ude0f\ud866\ude1f\uda07\udea9\uda0b\uddf3\ud864\udd46\udb7c\udd6c",
        13, 73816, 786465663, -1670258151967996188L, -4363L, true, true, (char) 14712, (char) 22153,
        Double.longBitsToDouble(0x3fa106f0b5135110L), Double.longBitsToDouble(0x3fc66a6ee774bfdcL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 9, 9, "\ud91d\udee8\uda2e\ude99\udab7\udea7\ud893\uddcb\udac9\udf78\ud9eb\udcaa\uda57\udf98\ud80c\udc78\ud8dd\udec0\uc321\uda9f\udc56\u1508\udb55\ude6e\udad4\udf7e\ud9a7\udeac\udb9a\ude8c\udb15\ude35\u7032\ud86a\ude1c\ud9ad\udc12\udb94\udcec\ud99b\udd7d\ud924\udf48\uda14\udeac\udb59\udc3f\ud801\udc94\ud8f3\ude79\udb90\udcb4\udb27\udfe9\ud97d\udf1d\ud904\udf69\uda82\udd7a\uda70\udc3a\ud879\ude14\udad7\ude68", "\u934e\ub143\u65a3\u7ec3\u7c2a\u94c2", "\uda30\udcee\ud818\udf6e\uda88\udcc3\ud9b0\udf11\ud882\udf7a\uda3c\ude26\ud992\udffc\ud991\udec1\udb75\udd55\uda7e\udd93\udaea\udd74\uda91\udd76\ud9fc\ude4a\ud9fb\udd91\uda65\udec4\ud947\ude0f\ud866\ude1f\uda07\udea9\uda0b\uddf3\ud864\udd46\udb7c\udd6c",
        13, 73816, 786465663, -1670258155709315356L, -4363L, true, true, (char) 19648, (char) 16225,
        Double.longBitsToDouble(0x3fc90377ad44d444L), Double.longBitsToDouble(0x3fc66a6ee774bfdcL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.rhino.jstype.FunctionType|resolveInternal|com.google.javascript.rhino.ErrorReporter,com.google.javascript.rhino.jstype.StaticScope|new:com.google.javascript.rhino.jstype.FunctionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.Node",
    "M|com.google.javascript.jscomp.FunctionTypeBuilder|addParameter|com.google.javascript.rhino.jstype.FunctionParamBuilder,com.google.javascript.rhino.jstype.JSType,boolean,boolean,boolean|new:com.google.javascript.jscomp.FunctionTypeBuilder:java.lang.String,com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.jscomp.Scope",
    "M|com.google.javascript.jscomp.FunctionTypeBuilder|buildAndRegister||new:com.google.javascript.jscomp.FunctionTypeBuilder:java.lang.String,com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.jscomp.Scope",
    "M|com.google.javascript.jscomp.FunctionTypeBuilder|getOrCreateConstructor||new:com.google.javascript.jscomp.FunctionTypeBuilder:java.lang.String,com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.jscomp.Scope",
    "M|com.google.javascript.jscomp.FunctionTypeBuilder|inferFromOverriddenFunction|com.google.javascript.rhino.jstype.FunctionType,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FunctionTypeBuilder:java.lang.String,com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.jscomp.Scope",
    "M|com.google.javascript.jscomp.FunctionTypeBuilder|inferInheritance|com.google.javascript.rhino.JSDocInfo|new:com.google.javascript.jscomp.FunctionTypeBuilder:java.lang.String,com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.jscomp.Scope",
    "M|com.google.javascript.jscomp.FunctionTypeBuilder|inferParameterTypes|com.google.javascript.rhino.JSDocInfo|new:com.google.javascript.jscomp.FunctionTypeBuilder:java.lang.String,com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.jscomp.Scope",
    "M|com.google.javascript.jscomp.FunctionTypeBuilder|inferParameterTypes|com.google.javascript.rhino.Node,com.google.javascript.rhino.JSDocInfo|new:com.google.javascript.jscomp.FunctionTypeBuilder:java.lang.String,com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.jscomp.Scope",
    "M|com.google.javascript.jscomp.FunctionTypeBuilder|inferReturnStatementsAsLastResort|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FunctionTypeBuilder:java.lang.String,com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.jscomp.Scope",
    "M|com.google.javascript.jscomp.FunctionTypeBuilder|inferReturnType|com.google.javascript.rhino.JSDocInfo|new:com.google.javascript.jscomp.FunctionTypeBuilder:java.lang.String,com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.jscomp.Scope",
    "M|com.google.javascript.jscomp.FunctionTypeBuilder|inferTemplateTypeName|com.google.javascript.rhino.JSDocInfo|new:com.google.javascript.jscomp.FunctionTypeBuilder:java.lang.String,com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.jscomp.Scope",
    "M|com.google.javascript.jscomp.FunctionTypeBuilder|inferThisType|com.google.javascript.rhino.JSDocInfo,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FunctionTypeBuilder:java.lang.String,com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.jscomp.Scope",
    "M|com.google.javascript.jscomp.FunctionTypeBuilder|inferThisType|com.google.javascript.rhino.JSDocInfo,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.FunctionTypeBuilder:java.lang.String,com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.jscomp.Scope",
    "M|com.google.javascript.jscomp.FunctionTypeBuilder|isFunctionTypeDeclaration|com.google.javascript.rhino.JSDocInfo|static",
    "M|com.google.javascript.jscomp.FunctionTypeBuilder|isOptionalParameter|com.google.javascript.rhino.Node,com.google.javascript.rhino.JSDocInfo|new:com.google.javascript.jscomp.FunctionTypeBuilder:java.lang.String,com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.jscomp.Scope",
    "M|com.google.javascript.jscomp.FunctionTypeBuilder|isVarArgsParameter|com.google.javascript.rhino.Node,com.google.javascript.rhino.JSDocInfo|new:com.google.javascript.jscomp.FunctionTypeBuilder:java.lang.String,com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.rhino.Node,java.lang.String,com.google.javascript.jscomp.Scope",
    "M|com.google.javascript.rhino.jstype.FunctionType|resolveInternal|com.google.javascript.rhino.ErrorReporter,com.google.javascript.rhino.jstype.StaticScope|new:com.google.javascript.rhino.jstype.FunctionType:com.google.javascript.rhino.jstype.JSTypeRegistry,java.lang.String,com.google.javascript.rhino.Node",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
