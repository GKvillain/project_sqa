package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class PeepholeSubstituteAlternateSyntax_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 9, 12, "\ud86e\ude56\ud9a8\udf2b\ud9fd\udf78\ud809\udf90\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb33\udf7f", "\u10ee\u78e7\u7834\u05b1\u7f3c\ua793\ua7c3\u5d8b\u349b\uacf4\u82a5\u3a7a\ua101\u269f\u0dd2\u3b39\u2dd1\u253f\u3a59\u6bda\u7098\ub065", "\udbdc\udd0b\ud876\uddbe\ud9a6\udd50\ud915\udfb0\ud9cd\udf5a\udae5\ude39\udb5f\udf81\ud872\udea4\uda27\udfda\udbaa\udef5\udacb\udfd6\ud81e\udecd\ud9ca\udea0\ud93a\udc73\ud945\udeb1\ud9f1\udfe9\ud9f6\udc03\udb2d\udcfd\ud9f5\udd41",
        53, 53600, -1804583093, -1539711999891486262L, -5140L, false, false, (char) 16354, (char) 52660,
        Double.longBitsToDouble(0x3fd629e663fedca8L), Double.longBitsToDouble(0x3fc040d793ab6c4cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 9, 12, "\u55eb\ud9a8\udf2b\ud9fd\udf78\ud809\udf90\ud8c3\udc26\ud9b3\udd6a\ud978\udc83\ud9dc\udd74\udb33\udf7f", "\u10b6\u78e7\u7834\u05b1\u7f3c\ua793\ua7c3\u5d8b\u349b\uacf4\u82a5\u3a7a\ua101\u269f\u0dd2\u3b39\u2dd1\u253f\u01a3\000\u7098\ub065", "\udbdc\udd0b\ud876\uddbe\ud9a6\udd50\ud915\udfb0\ud9b5\udc5a\udae5\ude39\udb5f\udf81\ud872\udea4\uda27\udfda\udbaa\udef5\udacb\udfd6\ud81e\udecd\ud8b4\udc94\ud93a\udc73\ud945\udeb1\ud9f1\udfe9\ud9f6\udc03\udb2d\udcfd\ud9f5\udd41",
        53, 53600, -1804583093, -1539711999891486262L, -5140L, false, false, (char) 16335, (char) 52660,
        Double.longBitsToDouble(0x3fd629e663fedca8L), Double.longBitsToDouble(0x3fc040d793ab6c4cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 9, 12, "\ud878\udfcc\ud860\udf73\ud9e6\udf9a\ud809\udf90\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb2e\udc7f\ud858\udfb9\ud8ff\udf2c\udb8e\udd15\udbd1\udd34\uda24\udd92\ud9e6\udd31\udbf3\udf4b\uda38\udf7b\ud86e\udd86\u6f09\ud985\udec5\ud8f0\udf47\uda5c\udf47\udb3a\udd0b\ud806\uddfe\ud8e1\udeb3\ud854\uded6\udb5f\udf69\ud87d\udd58\uda2e\udc7f\ud8f7\udee2", "\u9abd\u9b36\u4400\ub8ad\u3e4b", "\ud980\udf54\ud9d0\udf94\udb5f\udf81\ud872\udea4\uda27\udfda\udbaa\udef5\udacb\udfd6\ud81e\udecd\ud9ca\udea0\ud93a\udc73\uda22\uddc3\ud9f1\udf83\ud88e\udc70\ud934\ude91",
        48, 27443, -1116175051, 2036896833734458338L, 54404L, false, false, (char) 42267, (char) 47802,
        Double.longBitsToDouble(0x3fd8a515e8c53cccL), Double.longBitsToDouble(0x3fc8e54512081af0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 9, 12, "\ud86e\ude56\ud9a8\udf2b\ud9fd\udf78\ud809\udf90\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb33\udf7f", "\u10ee\u78e7\u7834\u05b1\u7f3c\ua793\ua7c3\u5d8b\u349b\uacf4\u82a5\u3a7a\ua101\u269f\u0dd2\u3b39\u2dd1\u253f\u3a59\u6bda\u7098\ub065", "\udbdc\udd0b\ud876\uddbe\ud9a6\udd50\uda36\udc3f\udbab\udc3a\ud814\udc06\udb5f\udf81\ud872\udea4\uda27\udfda\udbaa\udef5\udacb\udfd6\ud81e\udecd\ud9ca\udea0\ud93a\udc73\ud945\udeb1\ud9f1\udfe9\ud9f6\udc03\udb2d\udcfd\ud9f5\udd41",
        53, 53600, 1152466763, 8697536386293507907L, -5140L, false, false, (char) 16354, (char) 52660,
        Double.longBitsToDouble(0x3fd629e663fedca8L), Double.longBitsToDouble(0x3fc040d793ab6c4cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 9, 12, "\ud86e\ude56\ud9a8\udf2b\u816b\udb85\udea4\ud814\udc6a\udb33\udc6c\ud86a\ude6e\ud9dc\udd74\udb33\udf7f\ud886\ude90", "\u5a93\u77ea\u05b1\uab4e\u10f8\ua7c3\u5d8b", "\uda5c\udf47\udb40\udd73",
        10, 55557, 1937042683, -4398966166793415235L, 86786L, false, true, (char) 40840, (char) 51516,
        Double.longBitsToDouble(0x3fe226eb6b6dc76dL), Double.longBitsToDouble(0x3fe7b42fe1ff2364L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 1, 9, 12, "\ud86e\ude56\uda23\udf29\udaae\udea7\ud80a\udc31\udb55\udc8f\ud9b3\ude52\ud978\udc83\udb30\udd7f\udb33\udfdb", "\u10ee\u78e7\u7834\u05b1\u7f3c\ua793\ua7c3\u5d8b\u349b\uacf4\u82a5\u3a7a\ua101\u269f\u0dd2\u5917\u2dd1\u253f\u3a59\u6bda\u7098\ub065", "\udbdc\udd0b\ud876\uddbe\ud9a6\udd50\ud915\udfb0\ud9cd\udf5a\udae5\ude39\udb5f\udf81\udb25\udd1d\udb72\udcaa\udbea\udcf6\ud98d\ude34\ud8da\udf8d\ud9ca\udea0\ud84e\udf7e\ud945\udefa\ud9f1\udfe9\udb99\ude1f\ud905\udcdf\ud9f5\udda3",
        53, 53600, -1804583093, -1527327100916217398L, -5140L, false, false, (char) 16354, (char) 52660,
        Double.longBitsToDouble(0x3fd629e663fedca8L), Double.longBitsToDouble(0x3fc040d793ab6e4cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 9, 12, "\ud86e\ude56\ud9a8\udf2b\ud9fd\udf78\ud809\udf90\udb55\udc8f\ud820\ude14\ud99c\udcd8\ud9dc\udd74\udb33\udf7f", "\u10ee\u78e7\u7834\u05b1\u7f3c\ua793\ua7c3\u5d8b\u9957\uacf4\u82a5\u3a7a\ua101\u271a\u0dd2\u3b39\u2dd1\u253f\u5b89\u3e20\u7098\ub065", "\udbdc\udd0b\ud876\uddbe\ud9a6\udd50\ud915\udfb0\ud9cd\udf5a\udae5\ude39\udb5f\udf81\ud872\udea4\uda27\udfda\udbaa\udef5\udacb\udfd6\ud81e\udecd\ud9ca\udea0\ud93a\udc73\ud945\udeb1\ud9f1\udfe9\ud9f6\udc03\udb2d\udcfd\ud9f5\udd41",
        53, 53600, -1804583093, 1846994919891126730L, -5140L, false, false, (char) 16354, (char) 52660,
        Double.longBitsToDouble(0x3fd629e663fedca8L), Double.longBitsToDouble(0x3fc040d793ab6c4cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 9, 12, "\ud86e\ude56\ud9a8\udf2b\ud9fd\udf78\ud809\udf90\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb33\udf7f", "\u10ee\u78e7\u7834\u05b1\u7f3c\ua793\ua7c3\u5d8b\u349b\uacf4\u82a5\u3a7a\ua101\u269f\u0dd2\u3b39\u5ca7\u253f\u3a59\u6bda\u06d7\ub065", "\udbdc\udd0b\ud876\uddbe\ud9a6\udd50\ud915\udfb0\ud9cd\udf5a\udae5\ude39\udb5f\udf81\ud872\udea4\uda27\udfda\udbaa\udef5\udacb\udfd6\ud81e\udecd\ud9ca\udea0\ud93a\udc73\ud945\udeb1\ud9f1\udfe9\ud9f6\udc03\udb2d\udcfd\ud9f5\udd41",
        53, 53600, -1804583093, -1539711999891486262L, -5200L, false, false, (char) 16354, (char) 52660,
        Double.longBitsToDouble(0x3fd629e663fedca8L), Double.longBitsToDouble(0x3fc040d793ab6c4cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 9, 12, "\ud86e\ude56\ud9a8\udf2b\ud9fd\udf78\ud808\ude90\udb55\udc71\ud9b3\ude52\ud978\udc83\ucbe1\udb33\udf7f", "\u10ee\u78e7\u7834\u05b1\u7f3c\ua793\ua7c3\u5d8b\u349b\u711a\000\u3a7a\u8790\u269f\u7d85\u57a4\u2dd1\u253f\000\uc1c6\u7098\u1160", "",
        25, 13671, -889154448, -5481667807856820224L, -43603L, true, true, (char) 50777, (char) 38364,
        Double.longBitsToDouble(0x3fec50b001e448f5L), Double.longBitsToDouble(0x3fc1b0f66aa26de8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 9, 12, "\ud86e\ude56\ud9a8\udf2b\ud9fd\udf78\ud809\udf90\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb33\udf7f", "\u10ee\u78e7\u7834\u05b1\u7f3c\ua793\ua7c3\u5d8b\u349b\uacf4\u82a5\u3a7a\ua101\u269f\u0dd2\u3b39\u2dd1\u253f\u3a59\u6bda\u7098\ub065", "\udbdc\udd0b\ud876\uddbe\ud9a6\udd50\ud915\udfb0\ud9cd\udf5a\udae5\ude39\udb5f\udf81\ud872\udea4\uda27\udfda\udbaa\udef5\udacb\udfd6\ud81e\udecd\ud9ca\udea0\ud93a\udc73\ud945\udeb1\ud9f1\udfe9\ud9f6\udc03\udb2d\udcfd\ud9f5\udd41",
        53, 53600, -1804583093, -1528471692520732214L, -5140L, false, false, (char) 16354, (char) 52660,
        Double.longBitsToDouble(0x3fd629e663fedca8L), Double.longBitsToDouble(0x3fc040d793ab6c4cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 3, 12, "\uda8b\udf45\ud9a8\ude55\udb25\udc6b\ud80a\udc11\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb33\udf7f", "\u37e0\u7c66\u7834\u05b1\u7f3c\ua793\ua7c3\u5d8b\u349b\uacf4\u82a5\u3a7a\ua101\u3446\ub5d2\u3b39\u2dd1\u253f\u3a59\u6bda\u7098\ub065", "\udbdc\udd0b\ud876\uddbe\ud9a6\udd50\ud915\udfb8\ud9cd\udf5a\udae5\ude39\udb3c\udf81\ud872\udea4\uda27\udfda\udbaa\udef5\udacb\udfd6\ud81e\udecd\ud9ca\udea0\ud93a\udc73\ud945\udeb1\ud9f1\udfe9\ud9f6\udc03\udb2d\udcfd\ud9f5\udd41",
        53, 53600, -1804583093, -1539712000813976287L, 36578L, false, false, (char) 16354, (char) 52660,
        Double.longBitsToDouble(0x3fd629e663fedca8L), Double.longBitsToDouble(0x3fc040d795fcda68L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 5, 6, "\ud86e\ude56\udb68\udc0b\udba0\udd9d\uda23\udd7c\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb33\udf7f\ud886\ude90\uda8c\udcec\ubd07\udbd1\udd34\ud894\udd8a\ud9e6\udd31\udbf3\udf54\uda38\udf7b\ud973\ude43", "\uacf4\u82a5\u1910", "\udb58\udfc8\udbfb\udffa\ud87d\udd58\uda2e\udc7f",
        32, 81110, 341736728, -2491315915800637884L, 5599L, true, false, (char) 7265, (char) 45559,
        Double.longBitsToDouble(0x3fe751233b97ab9cL), Double.longBitsToDouble(0x3fec50b001e448f5L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 9, 11, "\ud86e\ude56\ud9a8\udf2b\ud9fd\udf78\ud809\udf90\udb55\udc8f\udaea\udd6f\ud978\udc83\ud9dc\udd74\udb33\udf7f", "\u10ee\u78e7\ucd3d\u05b1\u7f3c\ua793\u5ea8\u5d8b\u349b\uacf4\u82a5\u3a5e\ua101\u269f\u0dd2\u3b39\u65de\u253f\u3a59\u6bda\u7098\ub065", "\udbdc\udd0b\ud876\uddbe\ud9a6\udd50\uda0c\udf6a\udbec\udcfb\udae5\ude39\udb5f\udf81\ud872\udea4\uda38\ude15\udbaa\udef5\ud824\udda9\ud81e\udecd\udbf8\ude76\ud93a\udc73\ud945\udeb1\ud8a4\udc23\ud9f6\udc03\ud8b5\ude20\ud932\ude6f",
        52, 53595, -1804583093, -1539711999891486262L, 60396L, false, false, (char) 16354, (char) 52660,
        Double.longBitsToDouble(0x3fd629e663fedca8L), Double.longBitsToDouble(0x3fc040d793a8c44cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax$FoldArrayAction:SAFE_TO_FOLD_WITHOUT_ARGS |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\012",
        Z.run(T, 1, 11, 9, 12, "\udbd9\udc4b\ud95b\udeb7\ud9fd\udf78\ud809\udf90\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb33\udf7f", "\u10ee\u78e7", "\udbf3\udf54\uda48\udf8a\ud973\ude43\ud8c9\udf9d\ud985\udec5",
        41, 32015, 498001740, -8764161929439364491L, 56227L, false, true, (char) 35560, (char) 40840,
        Double.longBitsToDouble(0x3fd60b7dcc89badaL), Double.longBitsToDouble(0x3feb6e3b6ef685fcL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax$FoldArrayAction:SAFE_TO_FOLD_WITHOUT_ARGS |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\012",
        Z.run(T, 1, 11, 6, 12, "\ud86e\ude56\ud9a8\udf2b\ud9fd\udf78\ud809\udf90\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb33\udf7f", "\u10ee\u78e7\u7834\u05b1\u7f3c\ua793\ua7c3\u5d8b\u349b\uacf4\u82a5\u3a7a\ua101\u269f\u0dd2\u3b39\u2dd1\u253f\u3a59\u6bda\u7098\ub065", "\udbdc\udd0b\ud876\uddbe\ud9a6\udd50\uda36\udc3f\udbab\udc3a\ud814\udc06\udb5f\udf81\ud872\udea4\uda27\udfda\udbaa\udef5\udacb\udfd6\ud81e\udecd\ud9ca\udea0\ud93a\udc73\ud945\udeb1\ud9f1\udfe9\ud9f6\udc03\udb2d\udcfd\ud9f5\udd41",
        53, 53600, 1152466763, 8697536385882793795L, -5140L, false, false, (char) 16354, (char) 52660,
        Double.longBitsToDouble(0x3fd629e663fedca8L), Double.longBitsToDouble(0x3fc040d793ab6c4cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 9, 4, "\udbc1\udfb0\ud9b6\udc65\ud9fd\udf78\ud809\udf90\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9dc\udd74\uda23\uddf4\ud886\ude90\uda10\udc2f", "\u7834\u05b1", "\ud973\ude43\ud8c9\udf9d\udb65\udd08\ud8f0\udf84\uda08\udddd\ud8a0\udfd4\ud931\udd12\ud91a\udc6d\udb58\udfc8\udbfb\udffa\ud87d\udd58\uda2e\udc7f\ud8f7\udee2\ud8e3\udf48\udab0\uddd7",
        42, 57244, -2047075475, 4923040180601084415L, -38604L, false, true, (char) 39788, (char) 7474,
        Double.longBitsToDouble(0x3fd0dae5a6ba35faL), Double.longBitsToDouble(0x3fdaa4c327142c00L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 9, 9, "\ud9af\udd17\ud9bf\udc82\ud9fd\udf78\ud809\udf90\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9d8\udf53\udaf8\udf97", "\u10ee\u78e7\u7834\u05b1\u7f3c\ua793\ua7c3\u5d8b\u349b\uacf4\u82a5\u3a7a\ua101\u269f\u0dd2\u3b39\u2dd1\u253f\u3a59\u6bda\u7098\ub065", "\udbdc\udd0b\ud876\uddbe\ud9a6\udd50\uda36\udc3f\udbab\udc3a\ud814\udc06\udb5f\udf81\ud872\udea4\uda27\udfda\udbaa\udef5\udb97\udf1d\ud9e1\ude73\udb81\udfb5\ud93a\udc73\ud945\udeb1\ud9f1\udfe9\ud9f6\udc03\udb2d\udcfd\ud9f5\udd41",
        53, 53600, 1152466763, 8697536386293507907L, -20140L, false, false, (char) 16354, (char) 52660,
        Double.longBitsToDouble(0x3fd629e663fedca8L), Double.longBitsToDouble(0x3fc040d793ab6c4cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 10, 12, "\ud86e\ude56\ud9a8\udf2b\u816b\udb85\udea4\ud9c0\udc00\uda29\udc67\ud86a\ude6e\ud9dc\udd74", "\uc86b\u10f5", "\ud864\udcfc\udad8\udf5b\ud971\udf88\ud8fc\ude1a\udab2\udc73\ud816\udd75\uda8d\udcf0\uda5c\udf2e\u3edc\ud817\udc57\udbfa\ude7d\udb58\udfc8\udbfb\udffa\ud87d\udd58\udb4c\udeca\udb4c\udd4c\ud8e3\udf48\udab0\uddd7",
        8, 99479, -2047075475, 2550327071703322111L, 4496L, false, false, (char) 48964, (char) 24994,
        Double.longBitsToDouble(0x3fbfd33a37bd0078L), Double.longBitsToDouble(0x3fe778c494d07ceaL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 9, 12, "\ud895\udc04\ud9a8\udf2b", "\u8d6c\uca93\u5ad0\u0b69\ud0c0\u3e04\ud4e5\u10ee\uaf69J\u783c", "\ud973\ude43\ud852\udc5e\ud93b\udda1",
        41, 32015, 889374540, 2472527287850089077L, 48035L, true, true, (char) 39906, (char) 3770,
        Double.longBitsToDouble(0x3febc9454c0e843cL), Double.longBitsToDouble(0x3feb6e3bc6f685fcL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 9, 12, "\ud9b7\uddc9\ud9b2\uddd0\ud87c\udc97\ud809\udf51\udb55\udc8f\ud820\ude14\ud99c\udcd8\ud8ad\udc9d\udb33\udf7f\ud886\ude90\uda8c\udcec\udb67\udc43\udbd1\udd34\ud894\udd8a\ud9e6\udd31\udbf3\udf54\udb6c\udd76\udbff\udf0f\ud999\udd92\uda9b\udc5b\ud964\udf4f\uda5c\udf47\udb3a\udd0b\ud806\uddfe\udb5e\udd27\udb58\udfc8\udbfb\udffa\uda23\ude57\uda2e\udc7f\ud941\udee3\udad0\udd31\udab0\uddd7\ud971\udf01", "\ub8e8\u2f9a\u6ce1]\u68ec\u7665\u3be5\u8909\u5dac\u103d\u873d\u5b4f\u7969\u4a5c\ua08b\u103e\u2bd6\uc835\u54ea", "\ud8db\ude2c\udabc\udd9a\ud9aa\ude25\ud93b\uddb5\uda03\udfdf\ud9b8\udd7a\ud8c3\ude1b\ud9fe\ude50\ud891\udce5",
        35, 34634, -523367190, 575752537608452089L, 99L, false, true, (char) 16858, (char) 1820,
        Double.longBitsToDouble(0x3fb852e20dd10ce8L), Double.longBitsToDouble(0x3fcd8706c0c1794cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 13, 4, "\ud86e\ude56", "\ubaca\u750f\u2303\u17ec\u567d\uca0e\u0334\ud4e5\u10ee", "\ud9e6\udd31\udbf3\udf54\uda38\udf7b\ud973\ude43\ud8c9\udf9d",
        47, 94241, 1539778015, 2138901184610529577L, 75150L, true, true, (char) 2167, (char) 16104,
        Double.longBitsToDouble(0x3fe0c6cb81608061L), Double.longBitsToDouble(0x3fe226eb6b6dc76dL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 9, 12, "\ud859\udc6b\ud9a8\udf2b\ud9fd\udf78M\udb24\udc8f\ud9b3\ude52\ud978\udc83\ud857\ude6b\udb33\udf7f", "\000\000", "\udbf3\udf54\uda38\udf7b\ud973\ude43",
        -5, 71688, 620841241, 6613296218022799180L, -82197L, true, false, (char) 12040, (char) 55472,
        Double.longBitsToDouble(0x3fdbdf9510005daaL), Double.longBitsToDouble(0x3fd8ed100c31b2e0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 9, 12, "\ud86e\ude56\ud9a8\udf2b\ud9fd\udf78\ud809\udf90\000\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb33\udf7f", "\u6000\u78e7\u7834\u05b1\u7f3c\ua793\ua7c3\u5d8b\u349b\uacf4\u82a5\u3a7a\ua101\u269f\u0dd2\u3b39\u2dd1\u253f\u3a59\u6bda\u7098\ub065", "\udbdc\udd0b\ud876\uddbe\ud9a6\udd50\ud915\udfb0\ud9cd\udf5a\udae5\ude39\udb5f\udf81\ud872\udea4\uda27\udfda\udbaa\udef5\udacb\udfd6\ud81e\udecd\ud9ca\udea0\ud93a\udc73\ud945\udeb1\ud9f1\udfe9\ud9f6\udc03\udb2d\udcfd\ud9f5\udd41",
        53, 53600, -1804583093, -1528471692520732214L, -5140L, false, false, (char) 16354, (char) 52660,
        Double.longBitsToDouble(0x3fd629e663fedca8L), Double.longBitsToDouble(0x3fc040d793ab6c4cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 9, 12, "\ud86e\ude56\ud9a8\udf2b\ud9fd\udf78\ud809\udf90\udb55\udc8f\ud9b3\ude52\u1c2b\000\000", "\u10ee\u78e7\u7834\u05b1\u7f3c\ua793\ua7c3\u5d8b\u349b\uacf4\u82a5\u3a7a\ua101\u269f", "\ud87d\udd58\uda2e\udc7f\ud8f7\udee2\ud8e3\udf48\udab0\uddd7\ud971\udf56\ud9d8\udeee\000\udbac\ude15\ue1ff\ud9a6\udd50\ud915\udfb0\ud9cd\udf5a\udae5\ude39\udb5f\udf81\ud872\udea4\uda27\udfda\udbaa\udef5\udacb\udfd6",
        40, 30581, 1649574568, 3154045987406877300L, 15007L, true, false, (char) 2029, (char) 14237,
        Double.longBitsToDouble(0x3fea5ce52f189470L), Double.longBitsToDouble(0x3fdcaeac96480c1eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 12, "\ud86e\ude56\ud9a8\udf2b\ud996\udcc4\ud809\udf90\udae9\ude1a\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb09\ude1a", "\ua8a7\u78e7\u7834\u05b1\u7f3c", "\ud8c9\udf9d\ud985\udec5\ud8f0\udf47\uda5c\udf47\udb3a\udd0b",
        7, 58589, -1229788100, 5679187963503809370L, 86786L, false, true, (char) 44808, (char) 55223,
        Double.longBitsToDouble(0x3fe1712bc36dc76dL), Double.longBitsToDouble(0x3fe7b42fe30b2364L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 4, 9, 12, "", "\u1e18", "\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb33\udf7f\ud886\ude90\uda8c\udcec\ubd07\udbd1\udd34\ud894\udd8a",
        47, 68692, 2086876199, 4190699329121936694L, -15751L, true, true, (char) 17171, (char) 36567,
        Double.longBitsToDouble(0x3fe3ac32fcfbe1c3L), Double.longBitsToDouble(0x3feca003a5bdc2f3L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 1, 10, "\u0bbe", "\ubaca\u750f\u30f0\uab22\ua81c\u2258\u0334\ud4e5\u4a6c", "\ud9e6\udd31\udbf3\udf54\uda38\udf7b\ud973\ude43\ud8c9\udf9d",
        47, 94241, 1539778015, -5737613088683757271L, 91043L, true, false, (char) 22151, (char) 43872,
        Double.longBitsToDouble(0x3fe25ecb8310d367L), Double.longBitsToDouble(0x3fe226eb6b6dc76dL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax$FoldArrayAction:SAFE_TO_FOLD_WITHOUT_ARGS |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 9, 12, "\udbd9\udc4b\ud95b\udeb7\ud9fd\udf78\ud809\udf90\ud8b8\udfc1\ud9b3\udd78\ud8e0\udc96\ud8c8\uddc6\udb81\udf0f", "\u10ee\u78e7", "\udbf3\udf54\uda48\udf8a\ud973\ude43\ud8c9\udf9d\ud844\udea6",
        41, 32015, 498001740, -8764161929439364491L, 56227L, false, true, (char) 14684, (char) 40840,
        Double.longBitsToDouble(0x3fd60b7dcc89badaL), Double.longBitsToDouble(0x3f818edbbdabaf80L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax$FoldArrayAction:SAFE_TO_FOLD_WITHOUT_ARGS |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 6, 12, "\ud80c\udc04\udb20\uddeb\ud8ec\ude46\ud809\udf7d\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb33\udf7f", "\u10ee\u78e7\u7834\u05b1\u7f3c\ua793\uc797\u5d8b\u349b\uacf4\u82a5\u3a7a\u762d\u2f37\u7393\u4fda\u2dd1\u253f\u3a59\u70b1\u710f\ub065", "\udbdc\udd0b\ud876\uddbe\ud9a6\udd50\uda36\udc3f\udbab\udc3a\ud814\udc06\udb5f\udf81\ud872\udea4\uda27\udfda\udbaa\udef5\udacb\udfd6\ud81e\udecd\ud9ca\udea0\ud93a\udc73\ud945\udeb1\ud9f1\udfe9\ua7fb\udb2d\udcfd\ud9f5\udd41",
        53, 53600, 1152466763, 8697536385882793795L, -5140L, false, false, (char) 16354, (char) 52660,
        Double.longBitsToDouble(0x3fd629e663fedca8L), Double.longBitsToDouble(0x3fc040d793ab6c4cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 4, "\udbc1\udfb0\ud9b6\udc65\ud9fd\udf78\ud809\udf90\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9dc\udd74\ud926\uddb6\ud880\udf87\uda10\udc5a", "\u7834\u05b1", "\ud89d\udc99\ud9e2\udc03\ue10b\ud904\uddf7\uda08\udddd\ud8a0\udfd4\ud931\udd12\ud91a\udc6d\uda48\ude40\udbfc\udc58\uda56\udfc4\udb3c\udcf2\udb1f\udfb8\ud8e3\udf85\udab0\uddd7",
        42, 57244, -2047075475, 4923040180601084415L, -38604L, false, true, (char) 39788, (char) 7474,
        Double.longBitsToDouble(0x3fd0dae5a6ba35faL), Double.longBitsToDouble(0x3fdaa4c327142c00L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 4, "\udbc1\udfb0\ud9b6\udc65\ud9fd\udf78\u68ba\uda6d\udd37\ud9b3\ude52\ud978\udc83\ud9dc\udd74\uda23\uddf4\ud886\ude90\uda10\udc2f", "\u7834\u4712", "\ud87b\udde1\ud8b4\udecf\udb65\udd08\ud8f0\udf84\uda08\udddd",
        20, 25145, -517868993, -1236540484889321347L, 49626L, false, true, (char) 35560, (char) 40840,
        Double.longBitsToDouble(0x3fd60b7dcc89badaL), Double.longBitsToDouble(0x3feb6c9f16f685fcL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 4, "\ud91b\udf27\ud9bd\udff8\ud9fd\udf78\ud809\udf90\udb55\udc8f\ud840\udcdc\udbf4\udceb\ud92f\udeba\ud9fb\uddd5\udb16\ude2c\ud9e3\ude0e", "\u7834\u05b1\u7f3c\ua793", "\udb65\udd08\ud8f0\udf84\uda08\udddd\ud8a0\udfd4\ud931\udd12\ud91a\udc6d\udb58\udfc8\udbfb\udffa",
        24, 71485, -782575198, -2778516951761369576L, 27420L, true, true, (char) 65515, (char) 4968,
        Double.longBitsToDouble(0x3fbc3ec801665800L), Double.longBitsToDouble(0x3fd384573873de72L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 2, 1, 4, "\udbc1\udfb0\ud9b6\udc65\ud9fd\udf78\udb6b\udd61\udb40\udf03\ud9a3\udc82\ud978\udc83\ud9dc\udd74\uda23\uddf4\ud886\ude90\uda9d\udd42", "\u8dce\u3792", "\ud973\ude43\ud8c9\udf9d\udb65\udd08\ud8f0\udf84\uda08\udddd\ud8a0\udfd4\ud931\udd12\ud91a\udc6d\udb58\udfc8\udbfb\udffa\ud87d\udd58\uda2e\udc7f\ud8f7\udee2\ud8e3\udf48\udab0\uddd7\ud971\udf56\udb83\udfe4\ud8a5\udc3c\udad8\udefc\ud876\uddbe",
        49, 31684, 2011622024, -1232389588934284105L, 74917L, false, true, (char) 55689, (char) 20172,
        Double.longBitsToDouble(0x3fea2ad2dd805865L), Double.longBitsToDouble(0x3fe0550c0dad07daL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 5, "\udbf3\udccc\ud9e9\udfbf", "\u74f2\u30f0\u9912\u4b38\ub96d\ua9b6", "\udbbd\udc46\ud85e\udf0e\ud9e6\udd31\udbf3\udf54\uda38\udf7b\ud908\udd6e\ud90e\udc4b\udb65\udd34\ud908\udc02\ud860\udcb0\ud995\udc9e\ud950\udd0d",
        42, 40075, -1824202108, -4516805050253986411L, 92160L, true, false, (char) 44747, (char) 15646,
        Double.longBitsToDouble(0x3fd932ee1017f766L), Double.longBitsToDouble(0x3fa665c053845730L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax$FoldArrayAction:SAFE_TO_FOLD_WITHOUT_ARGS |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 4, "\udbc1\udfb0\ud9b6\udc65\ud9fd\udf78\ud809\udf90\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9dc\udd74\uda23\uddf4\ud886\ude90\uda10\udc2f", "\u7834\u05b1", "\ud973\ude43\ud8c9\udf9d\udb65\udd08\ud8f0\udf84\uda08\udddd\u0aaf\ud8fa\udd4d\ud91a\udc4d\udb58\udfc8\udbfb\udffa\ud87d\udd58\uda2e\udc7f\ud8f7\udee2\ud8e3\udf48\udab0\uddd7",
        42, 57244, -2047075475, 4923040180601084415L, -38604L, false, true, (char) 39788, (char) 7474,
        Double.longBitsToDouble(0x3fd0dae5a6ba35faL), Double.longBitsToDouble(0x3fdaa4c327142c00L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 9, 12, "\ud859\udc6b\ud9a8\udf2b\ud9fd\udf78M\ud8f0\udee3\udbf9\ude7c\ud978\udc83\ud857\ude6b\udb33\udf7f\u9661\ud8dc\udc0d\ud9b2\udc85J\ud9be\udedf\ud9e6\udd31\udbf3\udf54\uda38\udf7b", "\u53ff\uacf4\u82a5\ua0d7\u0d88\u269f\ud742\u36bb", "\udbb5\udd3a\ud8e3\udf48\u6aed\ud909\udd94\uda79\udd7c",
        16, 16089, -425218200, 4380028761401270333L, -9646L, false, true, (char) 18062, (char) 24605,
        Double.longBitsToDouble(0x3fef273ef8152fc7L), Double.longBitsToDouble(0x3fe2762ebe17f268L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 10, 11, "\ud88c\ude12\ud9a8\udf2b\ud9fd\udf78M\udb24\udc8f\ud9b3\ude52\ud978\udc83\ud95a\udf2d\udb33\udf7f\ud955\udff8\000\000\000\ud9be\udedf\ud9e6\udd31\udbf3\udf54\uda38\udf7b\ud973\ude43\000\ud957\ude2a\ud8f0\udf47\uda5c\udf47\udb3a\udd0b\ud806\uddfe", "\u3b39\u2dd1\u8c9b\u813b\u6bda\u60d2", "\udb8c\udeb3\udbdb\udf26\ud9b4\udf07\udb4d\ude04",
        -1, 67104, 449403841, -7629700461495775603L, -235L, false, true, (char) 46930, (char) 43634,
        Double.longBitsToDouble(0x3fb0da8d60974420L), Double.longBitsToDouble(0x3fa7e77a6fd81c40L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 12, "\ud86e\ude56\ud9a8\udf2b\ud996\udcc4\ud809\udf90\udae9\ude1a\ud9b3\ude52\ud8eb\ude3d\ud9dc\udd0b\udb09\ude1a", "\ua8a7\u78e7\u7834\u05b1\u7f3c", "\ud8c9\udf9d\ud985\udec5\ud8f0\udf47\uda5c\udf47\udb3a\udd0b",
        7, 58589, -1229788100, 5679187963503809370L, 86786L, false, true, (char) 44808, (char) 55223,
        Double.longBitsToDouble(0x3fe1712bc36dc76dL), Double.longBitsToDouble(0x3fe7b42fe30b2364L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax$FoldArrayAction:SAFE_TO_FOLD_WITHOUT_ARGS |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax$FoldArrayAction:SAFE_TO_FOLD_WITHOUT_ARGS |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\012",
        Z.run(T, 2, 11, 11, 12, "\udbd9\udc4b\ud95b\udeb7\ud921\ude0b\ud8da\ude29\ud9fd\uddfc\ud9b3\udd78\ud8e0\udc96\u51ed\udbb1\ude38", "\u10ee\u78e7", "\udbf3\udf54\ud913\udeee\ud999\udcf0\ud8c9\udf9d\ud844\udea6",
        41, 32015, 498001740, 4173287424308676244L, 56227L, false, true, (char) 14684, (char) 40840,
        Double.longBitsToDouble(0x3fd60b7dcc89badaL), Double.longBitsToDouble(0x3feace3b6ef6aebeL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax$FoldArrayAction:SAFE_TO_FOLD_WITHOUT_ARGS |this=com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 8, 12, "\ud80c\udc04\udb20\uddeb\ud8ec\ude46\ud809\udf7d\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb33\udf7f", "\u10ee\u78e7\u7834\u05b1\u7f3c\ua793\uc797\u5d8b\u349b\uacf4\u82a5\u3a50\u762d\u2f37\u7393\u4fda\u34ed\u9ff2\u3a59\u70b1\u710f\ub065", "\udbdc\udd0b\ud876\uddbe\ud9a6\udd50\uda36\udc3f\udbab\udc3a\ud814\udc06\udb5f\udf81\ud872\udea4\uda27\udfda\udbaa\udef5\udacb\udfd6\ud81e\udecd\ud9ca\udea0\ud93a\udc73\ud945\udece\ud9f1\udfe9\ua7fb\udb2d\udcfd\ud9f5\udd41",
        53, 53600, 1152466763, 8697536385882793795L, -5140L, false, false, (char) 16354, (char) 52660,
        Double.longBitsToDouble(0x3fd629e663fedca8L), Double.longBitsToDouble(0x3fc040d793ab6c4cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 1, 1, 12, "\ud3d1\udb20\uddfb\ud8d8\ude46\ud9d2\udf02\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb33\udf7f", "\u9948\ud09b\u786b\u05b1\ua405\u96cd\u1409\u5d8b\u349b\uacf4\u82a5\u3a50\u762d\u2f37\u7393\u4fda\u34ed\u9ff2\u3a59\u70b1\u710f\ub065\u9b36\u02d0\ub8e8\u26fa\u4f9f", "\ud9cd\udd92",
        3, 6541, 1278389085, 1585348062840931210L, -6758L, false, false, (char) 63780, (char) 55714,
        Double.longBitsToDouble(0x3fe3cc9e2efa693aL), Double.longBitsToDouble(0x3fd885215e2d394aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 9, 12, "\ud86e\ude56\ud9a8\udf2b\ud9fd\udf78\uda8d\udeec\ud80c\udf11\ud9c8\udc28\ud978\udc83\ud9dc\udd74\udb33\udf7f", "\u10ee\u78e7\u7834\u05b1\u7f3c\ua793\ua7c3\u5d8b\u349b\uacf4\u7ab7\u72aa\u8347\u52af\u0d10\u3b39\u079c\u147a\u023c\u133c\u7098\u9b02", "\udbdc\udd0b\ud876\uddbe\ud9a6\udd50\ud915\udfb0\ud9cd\udf5a\udb04\uddc4\udb5f\udf81\ud872\udea4\uda1a\udfd3\udbaa\udef5\udacb\udfd6\u644a\u4016\ud93a\udc27\ud945\udeb1\ud9f1\udfe9\ud9f6\udc03\udb2d\udcfd\udb39\ude23",
        56, 86677, 819454709, -1536760764653647414L, 35629L, true, true, (char) 20132, (char) 26689,
        Double.longBitsToDouble(0x3fc040d793ab6c4cL), Double.longBitsToDouble(0x3fbe7876a26f3268L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 9, 12, "\uda37\uded7\udbcf\ude3a\uda51\udf38\udb5c\ude39\015\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb33\udf7f\ud886\ude90", "\u78e7", "\udbf3\udf54\uda38\udf7b\ud973\ude43\ud8c9\udf9d\ud985\udec5\ud8f0\udf47\uda5c\udf47\udb3a\udd0b\ud806\uddfe\udb5e\udcac\udb58\udfc8\udbfb\udffa\ud87d\udd58\uda2e\udc7f\ud8f7\udee2",
        36, 13864, -580054688, -4076586404526941331L, 83252L, true, true, (char) 39877, (char) 7265,
        Double.longBitsToDouble(0x3f93d878765670a0L), Double.longBitsToDouble(0x3fd6f51d87142c00L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 0, "\ud86e\ude56\ud9a8\udf2b\ud996\udcc4\ud809\udf90\udae9\ude1a\ud9b3\ude52\ud978\udc83\ud9dc\udd74\ud9cb\uddbc\ub2cb\ud8b3\udeba\ud8de\udde5\udbd1\udd34\ud894\udd8a\ud9e6\udd31\udbf3\udf54\ud8c6\uddc3\ud973\ude43\ud8c9\udf9d\ud985\udec5\ud8f0\udf47\uda5c\udf47\ud906\udcb1\udb93\udd56\u6c4e\udb03\udfed\uda0f\udd8d\ud89c\udef5\uda2e\udc7f\ud9c0\udfc6\uda98\ude8a\udafa\uddca\ud915\udde4\ud9d8\uded8\ud900\udd5b\udbae\uddf7\ud907\udfdb\uda7c\udd28\ud81a\udd55\uda16\udc66\udba2\ude7c\udbb5\udfad\udb8f\ude43\udbcf\uded1\udb07\uddf7\udb40\udef4\ud95c\ude50\ud9a7\ude9f\uda96\udf82\ud92c\ude40\ud862\udf63\ud921\udd51\uda1f\udd7f\ud9b9\udd38\ud95c\udf37\u598e\ud871\ude95\ud9ef\udef9\ud8a6\udd63\ud914\udf6a\ud8b4\udf47\uda54\udf1c\udaaa\ude1a\ud874\uded2\ud85a\udcf5\ud847\ude24\ud801\udf6b\uda8f\udc0a\uda7b\udc5c\uda6e\udc7e\uda94\udc93\ud9e5\ude59", "\u03ee\u710f\u86e4\ub909", "\ud9d0\udd9e\uda91\uddf6\udbd9\udcb2\ud938\udf8a\ud803\udca5\ud98f\udf16\ud8ef\udfdc\udac1\udf61\udbbc\udf6f\udaae\udcc6\ud8e9\udf9d\udb53\ude19",
        26, 58833, 891216119, -1406005787129725275L, 32459L, true, false, (char) 13018, (char) 21997,
        Double.longBitsToDouble(0x3fefb7093a7c7427L), Double.longBitsToDouble(0x3fcd47ebde015d1cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 9, 12, "\ud859\udc6b\ud9a8\udf2b\uda31\udf72M\ud8f0\udee3\udbf9\ude7c\ud978\udc83\ud857\ude6b\udb33\udf7fX\ud8dc\udc0d\ud9b2\udc85J\ud9be\udedf\uda40\udf1f\ud9fc\udcde'", "", "\udae1\uddea\udb37\udd5e",
        -1, 55557, 6462954, -108001792L, -100000L, false, true, (char) 40840, (char) 48012,
        Double.longBitsToDouble(0x3fd6bc0c89037a96L), Double.longBitsToDouble(0x3f82c0ba00000000L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 10, 11, "\ud88c\ude12\ud9a8\udf2b\ud9fd\udf78M\udb24\udc8f\000\udb5e\udc0e\ud95a\ude4c\udb33\udf7f\ud955\udff8\000\000\000\ud9be\udedf\000\udbc0\udce0\uda38\udf7b\000\000\000\ud8de\ude2e\uda5c\udf47\udb3a\udd0b\uda68\udd2e", "\u3b39", "\udbb5\ude2a\ud8e3\udf48\udb7f\udcfd\uda31\udfa9",
        -5, 43445, 1493172224, 6498324173553664L, -100000L, false, false, (char) 56063, (char) 42154,
        Double.longBitsToDouble(0x3fd7da9e94974a54L), Double.longBitsToDouble(0x3fd98258ac2de278L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 3, 0, "\ud859\udc6b\ud9a8\udf2b\uda31\udf72M\ud8f0\udee3\udbf9\ude7c\ud978\udc83\ud857\ude6b\udb33\udf7fX\udb0a\udd85\ud9b2\udc87J\ud891\uddaa\uda03\uddf9\ud907\udf52\012", "", "\udae1\uddea\udb37\udd5e",
        -1, 55557, 6462954, -108001792L, -100000L, false, true, (char) 21296, (char) 48012,
        Double.longBitsToDouble(0x3fd6bc0c89037a96L), Double.longBitsToDouble(0x3f82c0ba00000000L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 3, 0, "\ud859\udc6b\ud9a8\udf2b\uda31\udf72M\ud8f0\udee3\udbf9\ude7c+\ud857\ude6b\udb33\udf7fX\udb0a\udd85\ud9b2\udc87J\ud891\uddaa\uda03\uddf9\ud907\udf52\000", "", "\udae1\uddea\udb37\udd5e",
        -1, 55557, 6462954, -108001792L, -100000L, false, true, (char) 21296, (char) 48012,
        Double.longBitsToDouble(0x3fd6bc0c89037a96L), Double.longBitsToDouble(0x3f82c0ba00000000L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 14, 4, "\ud87b\udc56\ud9a8\udf2b\udb0d\udf96\ud809\udfe1\udb55\udc8f\ud9b3\ude52\ud978\udc83\ud9dc\udd74\udb33\udf7f", "\u9352\u78e7\u7834\u05b1\u7f3c\ua793\ud1fa\u5d8b\u349b\u7c11\u82a5\u3a7a\uab59\u268b\uce68\u8c6d\u2dd1\u253f\u5300\u6bda\u7098\ub065", "\udbdc\udd0b\ud876\uddbe\ud9a6\udd50\ud8fe\udc95\ud9cd\udf5a\ud831\ude3f\udb5f\udf81\ud980\udecb\uda01\udfc1\ud94a\udea3\udafc\udd0f\ud8b0\udfb4\ud82b\udd63\udb52\udc1d\ud9ab\udc6c\udb6a\udf9a\ud9f5\udf79\udb2d\udcfd\udba2\ude38",
        42, 53633, -1804583093, -1539711999891486262L, -65812L, false, false, (char) 40162, (char) 28324,
        Double.longBitsToDouble(0x3fd0cf9be219f014L), Double.longBitsToDouble(0x3fe4b48bd2f32907L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 9, 12, "\ud859\udc6b\ud9a8\udf2b\ud8af\udff1\011\udb24\udc8f\ud9b3\ude52\ud978\udc83\ud857\ude6b\udb33\udf7f", "\000\000", "\ud8c8\udf26\uda38\udf7b\ud973\ude43",
        56, 6921, 631453918, 6613296218022799180L, -82197L, true, false, (char) 12040, (char) 55472,
        Double.longBitsToDouble(0x3fdbdf9510005daaL), Double.longBitsToDouble(0x3fd8ed100c31b2e0L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 0, "\ud8a2\udd59\ud869\udda1\ud991\udf17\ud809\udf90\udae9\ude1a\ud9b3\ude52\ud9a7\udf40\ud9ac\ude82\uda33\uded1\ud838\ude50\ud8b3\udeba\ud8de\udde5\udbd1\udd34\ud894\udd8a\ud9e6\udd31\udbf3\udf54\ud8c6\uddc3\ud973\ude43\ud8c9\udf9d\ud985\udec5\ud8f0\udf47\uda5c\udf47\ud906\udcb1\udb93\udd56\udad5\udc8f\udb03\udfed\uda0f\udd8d\ud89c\udef5\uda2e\udc7f\ud9c0\udfc6\uda98\ude8a\udafa\uddca\ud915\udde4\ud9d8\uded8\ud900\udd5b\udbae\uddf7\ud907\udfdb\uda7c\udd28\ud81a\udd55\uda16\udc66\udba2\ude7c\udbb5\udfad\udb8f\ude43\udbcf\uded1\udb07\uddf7\udb40\udef4\ud95c\ude50\udb7d\udeea\uda96\udf82\ud92c\ude40\ud862\udf63\ud921\udd51\uda1f\udd7f\ud9b9\udd38\ud95c\udf37\ud80c\udce8\ud865\udd66\ud843\udf63\ud86a\udebf\ud914\udf3c\ud8b4\udf47\uda54\udf1c\uda39\udcc1\ud9be\udfa5\u2cb6\ud9b5\udf69\ud801\udf36\uda8f\udc0a\uda7b\udc5c\uda6e\udc7e\uda94\udc93\ud9e5\ude59", "\u03ee\u710f\u86e4\ub909", "\ud9d0\udd9e\uda91\uddf6\udbd9\udcb2\udbc9\uddbe\udbad\udee2\ud955\udf19\ud8ef\udfdc\udac1\udf61\udba3\udda1\udaae\udcc6\ud8e9\udf9d\ud8d0\udc38",
        1, 58833, 891216119, -1406005787129725275L, 32459L, true, false, (char) 13018, (char) 21997,
        Double.longBitsToDouble(0x3fefb7093a7c7427L), Double.longBitsToDouble(0x3fcd47ebde015d1cL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 9, 12, "\udbb3\udc38\ud919\udd7f\udb42\ude62\ud933\udd7f\udb55\udc8f\ud96e\udc4f\ud978\udc83\ud9dc\udd74\udb33\udf7f", "\u10ee\u78e7\u7834\u05b1\u7f3c\ua793\ua7c3\u5d8b\u349b\u9f07\u983a\u3a7a\ua101\u269f\u0dd2\u3b39\u2dd1\u253f\u3a59\u6bda\u7098\ub065", "\udbdc\udd0b\ud97a\uddc0\ud9a6\udd50\udad9\ude12\ud9cd\udf5a\udae5\ude39\uda89\udf32\udbcc\udc4a\uda27\udfda\udbaa\udef5\udacb\udfd6\ud81e\udecd\ud9ca\udea0\ud93a\udc73\ud945\udeb1\ud9f1\udfe9\ud9f6\udc03\udb2d\udcfd\ud9f5\udd41",
        53, 53600, -1804583093, -1539711999891486262L, -5140L, false, false, (char) 16354, (char) 13493,
        Double.longBitsToDouble(0x3fd629e663fedca8L), Double.longBitsToDouble(0x3fc040d793ab6c4cL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 4, 9, 12, "\\", "\ubaca\u750f\u30f0\uaaaa\u0406\u2e98\u0334\ud4e5\u10ee", "\ud9e6\udd31\uda77\udd5a\uda38\udf66\ud973\ude43\ud8c9\udf9d",
        47, 94241, 1539778015, 2138901184610529577L, 25507L, false, true, (char) 13774, (char) 49273,
        Double.longBitsToDouble(0x3fefe089aaa28ca0L), Double.longBitsToDouble(0x3fed5c0e3ebab7e9L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 8, 12, "\ud859\udc6b\ud90b\udd29\udae7\udd4d\ud999\udeed\ud8f0\udee3\udbf9\ude7c\ud978\udc83\ud857\ude6b\udaf6\udd80<\ud8dc\udc0d\ud9b2\udc85J\ud9be\udedf\ud8a9\udf74\ud9bc\ude2c\ud967\ude1f", "", "\uda3f\udde6\udb37\udd5e",
        49, 55685, 6462954, 63776072349517312L, -100000L, false, true, (char) 25447, (char) 7434,
        Double.longBitsToDouble(0x3fd6bc0c89037a96L), Double.longBitsToDouble(0x3fab302e8a1e2a00L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 9, 12, "\\\ud9a8\ude42\ud92e\udd04", "\u93e6\ua57e\u0647\u2e98\u0334\uc157\u10ee\u78e7\u7834\u05b1\u3be7\u3b0c\ua753\u5d8b\u349b\u1d90\u82a5", "\udb9f\udccc\ud861\udd8a\udbf6\ude80\udac8\udefd\ud8ea\ude5e\ud91d\udc7d",
        31, 11132, -2117612894, -5194541897238311710L, 63406L, false, false, (char) 41832, (char) 33975,
        Double.longBitsToDouble(0x3fe8184092feb518L), Double.longBitsToDouble(0x3fc5cb5798e61240L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 11, 11, "\ud911\ude68\udb52\udea6\udb54\udc41>\udb24\udc8f\ud9b3\ude52\ud8ee\udc1e\udb36\udf9f\udb33\udf7f", "\000\000", "\ud893\udcb5\udb41\udc1f\ud95f\udf44\000",
        43, 94241, 1932862943, 2138823175119532329L, -45661L, true, true, (char) 12222, (char) 35470,
        Double.longBitsToDouble(0x3fe0c6cb86e3eca4L), Double.longBitsToDouble(0x3fe36407e12b0d48L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 0, "\ud86e\ude56\ud9a8\udf2b\ud996\udcc4\ud809\udf90\udae9\ude1a\ud9b3\ude52\ud978\udc83\ud9dc\udd74\ud9cb\uddbc\ueaf1\ud8b3\udeba\udaa1\udce6\udbbc\udd7e\u00a2\ud9e6\udd18\udbf3\udf54\000\000\000\000\ud8f0\udf47\uda53\udd68\ud906\udcb1\udb93\udd56\ue5fd\udb03\udfed\uda0f\udd8d\ud89c\udef5\uda2e\udc7f\ud9c0\udfc6\uda98\ude8a\udafa\uddca\ud915\udde4\ud9d8\uded8m\000\000\u3b72\ud81a\udc7d\uda16\udc66\udba2\ude7c\udbb2\udead\udb8f\ude43\udbcf\uded1\000\udb15\udc69\ud95c\ude50\ud9a7\ude9f\uda96\udf82\ud92c\ude40\ud862\udf63\ud91e\udf51\uda1f\udd7f\ud9b9\udd38\ud95c\udf37\u598e\ud871\ude95\ud9ef\udef9\ud8a6\udd63\ud914\udf6a\ud8e8\udea1\000\000\000\ud85a\udcf5\ud847\ude24\ud801\udf6b\uda8f\udc0a\uda7b\udc5c\uda6e\udc7eP\ud9e5\ude45", "\u03ee\u710f\u86e4\ub909", "\u00a8\uda91\uddf6\udbd9\udcb2\ud938\udf8a\ud803\udca5\ud98f\udf16\ud8ef\udfdc\udac1\udf61\udbbc\udf6f\udaae\udcc6\ud8e9\udf9d\000",
        17, 58833, 891216119, -1406005787129725275L, 29685L, true, false, (char) 13018, (char) 21997,
        Double.longBitsToDouble(0x3fefb000027c7427L), Double.longBitsToDouble(0x3fcd47ebde015d1cL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 4, 0, "", "\u302b\ubaca\u4331\u30f0\uaaaa\u0406\uace5", "\ud8de\udde5\udbd1\udd34\ud894\udd8a\ud9e6\udd31\udbf3\udf54",
        46, 62222, 684188982, 7538946612001851673L, 90284L, false, true, (char) 125, (char) 46339,
        Double.longBitsToDouble(0x3fce9bf68d693834L), Double.longBitsToDouble(0x3fdbdf9513445daaL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 8, 12, "\ud859\udc6b\ud936\udfaa\udbae\udf8b\ud999\udece\ud8f0\udee3\u688d\ud871\udf88\ud958\udf8c\ud96f\udd41\"\ud8dc\udc0d\ud9b2\udc85\udabb\udf67\udbea\udc9d\ud8a9\udf7d\ud9bc\ude2c\udbac\udc53", "\uc24a\u1cc2\u6491\ua000\ub382\u271f\ube5e\u750c\uae5e\ubc3d\u1ed2\u4946\u94ab\uaebc\u8a5b\u3138\ucd65\ua1ee\u46b5\u2ed5\u65fa\uab8d\u45ea\ucc5e\ucb2b\ud529\ucecd\u24d7\u05c1\u0549\ube19\u5cbb\u6a65\ub995", "\u58f4\ud8a4\udf64\ud83e\udf30\udba3\uded8\ud838\udffb\udac4\udf2e\uda79\udd8e\udbc3\ude71\ud811\udc3e\udb0e\udde5\ud99b\uddbb\uda47\udef5\udb19\udce2\udada\udddd\uc1b1\uda41\udc54\ud99f\ude3d\ud8ef\udfcf\ud8d7\udefc\ud95c\udc34\uda8d\ude59\ud8f3\udc18\udade\udfa2\ud88e\udc02\ud92a\uddd1\ud899\uded8\ud84f\ude31\udb13\udfe7\udb58\uddd2\udba5\uded3\ud9de\udebf\uda1f\udf02\ud874\udf62\udb19\uddde\ud862\udc4c",
        27, 2587, 1637461227, 6609610503957663214L, 73782L, false, true, (char) 62965, (char) 20978,
        Double.longBitsToDouble(0x3fd291052a3bc746L), Double.longBitsToDouble(0x3fc4257f7dacb53cL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 1, 8, 12, "\udb0e\udd47\ud90b\udd29\ud85d\udd48\ud999\udeed\ud8f0\udee3\udbf9\ude7c\uda47\uddeb\udae7\udc30\udbb4\udfb9g\ud8dc\udc0d\ud9b2\udc85J\ud9be\udedf\ud8a9\udf74\ud9b4\udd2c\ud967\ude1f", "", "\uda3f\udde6\udb37\udd5e",
        49, 55685, 6462954, 7413650664218166957L, -100000L, false, true, (char) 25447, (char) 7434,
        Double.longBitsToDouble(0x3fd6bc0c89037a96L), Double.longBitsToDouble(0x3fab302e8a1e2a00L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 13, "\ud859\udc6b\ud899\ude22\uda25\udf22\ud999\udeed\ud8f0\udee3\ud9c6\udf80\ud9fe\uddc6\ud857\ude6b\udaf6\udd80<\ud8dc\udc0d\ud9b2\udc85J\ud9be\udedf\ud8a9\udf74\ud823\udfe0\ud859\ude33", "", "\udaab\uddfe\udb37\udd5e\udbeb\ude80\udb5e\udd2c\udb33\uddef\ud941\udc0d\udb7f\udd9e\000",
        13, 76518, -211852381, -4555345214085503427L, -60839L, true, false, (char) 64661, (char) 65508,
        Double.longBitsToDouble(0x3fea4fe0061eb4bfL), Double.longBitsToDouble(0x3fea0ec380672c22L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 0, "\ud86e\ude56\ud9a8\udf2b\ud996\udcc4\ud809\udf90\udae9\ude1a\ud837\udff5\000\000\000\000\ud8b3\udeba\udaa1\udce6\udbbc\udd7e\u00a2\ud9e6\udd18\udbf3\udf54\000\000\000\000\ud8f0\udf2e\uda53\udd68\ud906\udcb1\udb93\udd56\ue5fd\u49d5\udaf3\udc98\ud89c\udef5\uda2e\udc7f\ud9c0\udfc6\uda98\ude8a\udafa\uddca\ud915\udde4\ud9d8\uded8m\000\000\u3b72\ud81a\udc7d\uda16\udc66\udba2\ude7c\000\u1800\000\000\000\000\udaa4\udfb2\uda96\udf82\udbc4\udf2d\ud862\udead\ud8c8\udf46\uda1f\udd7f\ud9b9\udd38\ud95c\udf37\u598e\ud871\ude95\ud9ef\udef9\ud8a6\udd63\ud914\udf6a\ud8e8\udea1\000\000\000\ud85a\udcf5\u2d66\000\uda8f\udc0a\uda63\udd5c\uda6e\udc7eP\ud9e5\ude45", "\u03ee\u710f\u86e4\u6dc7", "\u00a8\uda91\uddf6\udbd9\udcb2\ud938\udf8a\ud8c2\udee4\ud919\ude2c\ud8ef\udfdc\udac1\udf61\000\ud810\udc07\000\000",
        17, 58833, 891216119, -1406005787129725275L, -98613L, true, false, (char) 13018, (char) 21997,
        Double.longBitsToDouble(0x3fefb000027c7427L), Double.longBitsToDouble(0x3fcd47ebde015d1cL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 4, 0, "\\", "\ubaca\u750f\u30f0\uaaaa\u0406\u2e98\u0334\ud4e5\u10ee", "\ud9e6\udd31\uda77\udd5a\uda38\udf66\ud973\ude43\ud8fe\udd97",
        39, 94299, 1539778015, 2138901184610529577L, 25507L, false, true, (char) 13774, (char) 49273,
        Double.longBitsToDouble(0x3fefe089aaa28ca0L), Double.longBitsToDouble(0x3fed5c0e3ebab7e9L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 8, 12, "\ud859\udc6b\ud936\udfaa\udbae\udf8b\ud999\udece\ud8f0\udee3\u688d\ud871\udf88\ud958\udf8c\ud96f\udd41\"\ud8dc\udc0d\ud9b2\udc85\udabb\udf67\udbea\udc9d\"\000\udbac\udc53", "\uc24a\u1cc2\u6491\ua000\ub382\u271f\ube5e\u750c\uae5e\ubc3d\u1ed2\u4946\u94ab\uaebc\u8a5b\u3138\ucd65\ua1ee\u46b5\u2ed5\u65fa\uab8d\u45ea\ucc5e\ucb2b\ud529\ucecd\u24d7\u05c1\u0549\ube19\u5cbb\u6a65\ub995", "\u58f4\ud8a4\udf64\ud83e\udf30\udba3\uded8\ud838\udffb\udac4\udf2e\uda79\udd8e\udbc3\ude71\ud811\udc3e\udb0e\udde5\ud99b\uddbb\uda47\udef5\udb19\udce2\udada\udddd\uc1b1\uda41\udc54\ud99f\ude3d\ud8ef\udfcf\ud8d7\udefc\ud95c\udc34\uda8d\ude59\ud8f3\udc18\udade\udfa2\ud88e\udc02\ud92a\uddd1\ud899\uded8\ud84f\ude31\udb13\udfe7\udb58\uddd2\udba5\uded3\ud9de\udebf\uda1f\udf02\ud874\udf62\udba5\udcc3\ud862\udc4c",
        27, 2587, 1637461227, 6609610503957663214L, 73782L, false, true, (char) 62965, (char) 20978,
        Double.longBitsToDouble(0x3fd291052a3bc746L), Double.longBitsToDouble(0x3fc4257f7dacb53cL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 0, "\\\udb59\udf41\ud9b7\udd55\ud809\udf90\udb55\udc8f\ud9b3\ude52\ud9b0\udc7f\ud9dc\udd74\udb33\udf7f\ud886\ude90\uda8c\udcec\ubd07\udbd1\udd34\ud8f3\udeb9\ud9ff\udf71\uda77\udddc\uda72\udf44\ud973\ude43\ud8fe\udd97\udb5c\ude02", "\u3a7a\ua101\u482b\u3373\u3ab3\u1f61\u8cdf\u8a47", "\udb10\udf31\udb05\udfa1\udaf5\udd7c\ud828\udc06",
        28, 35980, 1419460680, -1640882249885625477L, 87229L, true, false, (char) 58562, (char) 8646,
        Double.longBitsToDouble(0x3fee15970aa1323dL), Double.longBitsToDouble(0x3fef827e2e5208d8L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 5, "\ud86e\ude56\ud9a8\udf2b\ud996\udcc4\ud809\udf90\udae9\ude1a\ud9b3\ude52\ud978\udc83\ud9dc\udd74\ud9cb\uddbc\ueaf1\ud8b3\udeba\udaa1\udce6\udbbc\udd7e\u00a2\ud9e6\udd18\udbf3\udf54\000\000\000\000\ud8f0\udf47\uda53\udd68\ud906\udcb1\udb93\udd56\ue5fd\udb03\udfed\uda0f\udd8d\ud9ef\udded\udb15\uddda\ud9ae\ude7a\uda98\ude8a\udafa\uddca\ud9e1\udfba\udbbc\udf5e\udbd2\udcad\ud8c4\ude56\015\u3b72\ud81a\udc7d\uda16\udc66\udba2\ude7c\udbb2\udead\udb8f\ude43\udbcf\uded1\000\udb15\udc69\ud95c\ude50\ud9a7\ude9f\uda96\udf82\ud92c\ude40\ud862\udf63\ud91e\udf51\uda1f\udd7f\ud9b9\udd38\ud822\udf90\udb7a\udcd2\ud871\ude95\ud9ef\udef9\ud8a6\udd63\ud914\udf6a\ud8e8\udea1\000\000\000\ud85a\udcf5\ud847\ude24\ud801\udf6b\uda8f\udc0a\uda7b\udc5c\uda6e\udc7eP\ud9e5\ude45", "\u03ee\u710f\u86e4\ub909", "\udbc2\udea8\udb6f\ude6b\ud989\udc75\ud938\udf8a\ud803\udca5\ud98f\udf16\ud8a9\udfef\udac1\udfed\udbbc\udf6f\udaae\udcc6\ud8e9\udf9d\000",
        17, 39905, 882305026, -1406005237373911387L, 29685L, true, false, (char) 13018, (char) 15123,
        Double.longBitsToDouble(0x3fefb000027c7427L), Double.longBitsToDouble(0x3fef51faf780579fL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 0, "\ud86e\ude56\udb03\udcb6\ud9b2\udfcd\ud827\udf35\udae9\ude1a\ud837\udff5\000\000\000\000\ud8b3\udeba\udaa1\udce6\udbbc\udd7e\u00a2\ud9e6\udd18\udbf3\udf54\000\000\000\000\ud8f0\udf2e\uda53\udd68\ud806\udcd1\udbfc\udf1a\ue5fd\u49d5\udaf3\udc98\ud89c\udef5\uda2e\udc7f\ud9c0\udfc6\udbd6\udee8\udafa\uddca\uda37\ude15\udaba\udec8\ud85b\udf49\uda9b\uddf0\012\u3b72\ud81a\udc7d\uda16\udc66\ud8c2\udc76\ud808\ude8c\u1800\000\000\000\000\udaa4\udfb2\uda96\udf82\udbc4\udf2d\ud862\udead\ud8c8\udf46\uda1f\udd7f\ud9b9\udd38\ud95c\udf37\u598e\ud871\ude95\ud9ef\udef9\ud8a6\udd63\ud914\udf6a\ud8e8\udea1\000\000\000\ud85a\udcf5\u2d66\000\uda8f\udc0a\uda63\udd5c\uda6e\udc7eP\ud9e5\ude45", "\u03ee\u710f", "\uda7e\udd9e\ud939\udcb6\u00a8\uda91\uddf6\udbd9\udcb2\udb2a\udf83\ud8c2\udee4\ud919\ude2c\ud8ef\udfdc\ud851\ude63\ud83d\udd69\u7de0",
        -5, -1000, 1404755712, -8047880370842050313L, 80571L, false, false, (char) 1387, (char) 52814,
        Double.longBitsToDouble(0x3fbd599976d07898L), Double.longBitsToDouble(0x3fefb000027c7427L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 9, 12, "\udaca\udd60\ud9a8\udf2b\uda31\udf72M\ud8f0\udee3\udbf9\ude7c\ud978\udc83\ud857\ude6b\udb33\udf7f\udab4\udd87\ud8dc\udc0d\ud9b2\udc85'\ud9be\udef4\uda40\udf1f\ud9fc\udcde'", "", "\udae1\uddea\udb37\udd5e",
        -1, 55557, 6462954, -108001792L, -100000L, false, true, (char) 2527, (char) 7408,
        Double.longBitsToDouble(0x3fef8a6d845cb1c4L), Double.longBitsToDouble(0x3f82c0ba00000000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isFoldableExpressBlock|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|areSafeFlagsToFold|java.lang.String|static",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|areValidRegexpFlags|java.lang.String|static",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|consumesDanglingElse|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|containsUnicodeEscape|java.lang.String|static",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|getBlockExpression|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|getBlockReturnExpression|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|getBlockVar|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isLowerPrecedenceInExpression|com.google.javascript.rhino.Node,int|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isPropertyAssignmentInExpression|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isReturnExpressBlock|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isSafeToFoldArrayConstructor|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isVarBlock|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|makeForwardSlashBracketSafe|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|maybeReplaceChildWithNumber|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,int|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|optimizeSubtree|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:",
    "M|com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax|isFoldableExpressBlock|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.PeepholeSubstituteAlternateSyntax:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
