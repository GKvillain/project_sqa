package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class ProcessCommonJSModules_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 3, 4, "\ud8c4\udc31\udab1\udd96\udb35\ude19\udac8\udd5a\ud9db\ude5f\udb0f\udffe\ud8fc\uddaa\u7102\udbdc\ude23\uda19\udfd6\udbeb\udc62\udbd4\udd95\ud801\udd36\uda86\udc72\ud961\udeed\ud881\udd3e\udb1f\udd7c\u966b\ud995\ude05\ud8a0\udce0\ud86e\udd16\udb69\udd55\udbe9\udf33\ud961\udef3\udb25\ude22\u2a84\ub910\ud804\udc8b\ud925\udf25\uda90\udd5b\ud800\udfe9", "\uafa3\ua003\u75f4\u82fb\u9d09\u0e81\u02b8\ud29f\u1023\u9c84\u8c46\u3556\u18a4\u1501\uce3e\ud150\u6d3d", "\ud925\udca3\udba5\udd43\udbcf\udf0b\ud865\udd99\udaca\uddd3\udbf4\ude02\ud968\udf22",
        -5, 44173, -615099856, -7154537883062292970L, -70282L, false, false, (char) 10840, (char) 62587,
        Double.longBitsToDouble(0x3fe46c2be93377b7L), Double.longBitsToDouble(0x3fd67d83530ec80aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 3, 4, "\ud8c4\udc31\udab1\udd96\udb35\ude19\udac8\udd5a\ud9db\ude5f\udb06\udd59\ud8e7\udf39\u7102\udbdc\ude23\uda19\udfd6\udbeb\udc62\udbd4\udd95\ud801\udd36\uda86\udc72\ud961\udeed\ud881\udd3e\udb1f\udd7c\u966b\ud995\ude05\ud8a0\udce0\udaa8\udf22\udb69\udd55\udbe9\udf33\ud961\udef3\udb25\ude22\u2a84\ub910\ud804\udc8b\ud925\udf25\uda90\udd5b\ud800\udfe9", "\uafa3\ua003\u75f4\u82fb\u54b4\u0e81\u02b8\ud29f\u1023\u9c84\u8c46\u3556\u18a4\u1501\uce3e\ud150\u6d3d", "\udac5\udc79\udba5\udd43\udbcf\udf0b\ud865\udd99\udaca\uddd3\udbf4\ude02\ud968\udf22",
        -5, 44173, -615099856, -7154537883062292970L, -70282L, false, false, (char) 10840, (char) 62587,
        Double.longBitsToDouble(0x3fe46c2be93377b7L), Double.longBitsToDouble(0x3fd67d83530ec80aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 3, 4, "\ud8c4\udc31\udab1\udd96\udb35\ude19\udac8\udd5a\uda2a\uddc5\udb0f\udffe\ud8fc\uddaa\ud83f\udf32\ud84a\udcc4\uda19\udfd6\udbeb\udc62\udbd4\udd95\ud801\udd36\uda86\udc72\ud961\udeed\ud881\udd3e\udb1f\udd7c\u966b\ud995\ude05\ud8a0\udce0\ud86e\udd16\udb69\udd55\udbe9\udf33\ud961\udef3\uda57\udcda\ud96a\udfc4\udb35\udfaa\ud31c\ud925\udf25\uda90\udd5b\ud8ca\udfcf", "\u51eb\ud3a3\u75e4\uaa1c\u8656\u87e2\u8dee\ud2e3\u64fa\u9c84\u02fa\u351e\u18a4\u1501\u045d\u96b1", "\uda6b\udcca\ud925\udca3\udb6b\udd65\udbcf\udef4\ud865\udd99\udaca\uddd3\udbf4\ude02\ud95a\udefb",
        50, 21549, 2115062277, 8243603030583551293L, 24576L, false, false, (char) 31888, (char) 57809,
        Double.longBitsToDouble(0x3fd67d83530ec80aL), Double.longBitsToDouble(0x3fe029fd5a5fdf89L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=java.lang.String:module$\ud8c4\udc31\udab1\udd96\udb35\ude19\udac8\udd5a\ud947\udff9\udbf1\udd14\ud90a\udf6d\u7102\udbb7\udce1\udb0d\ude26\ud887\udcae\udbd4\udd95\ud801\udd36\udaae\ude72\ud961\udeed\ud881\udd3e\udb1f\udd7c\uda1e\udd28\ud98e\udc54\ud8a0\udce0\ud86e\udd16\udb69\udd55\udbe9\udf33\ud961\udef3\udb25\ude22\u2a84\u7107\ud804\udc8b\ud925\udf25\uda90\udd5b\ud800\udfe9\012",
        Z.run(T, 2, 6, 5, 4, "\ud8c4\udc31\udab1\udd96\udb35\ude19\udac8\udd5a\ud947\udff9\udbf1\udd14\ud90a\udf6d\u7102\udbb7\udce1\udb0d\ude26\ud887\udcae\udbd4\udd95\ud801\udd36\udaae\ude72\ud961\udeed\ud881\udd3e\udb1f\udd7c\uda1e\udd28\ud98e\udc54\ud8a0\udce0\ud86e\udd16\udb69\udd55\udbe9\udf33\ud961\udef3\udb25\ude22\u2a84\u7107\ud804\udc8b\ud925\udf25\uda90\udd5b\ud800\udfe9", "\uafa3\u576c\ucf9e\u8174\u5898\u9bbc\u02e1\ud29f\u1023\u9c84\u8c46\u3556\u18a4\u1501\uce3e\ud150\ub451", "\ud925\udca3\udba5\udd43\udbcf\udf0b\ud865\udd99\udab0\udc47\udaf9\udce5\ud9bb\udfb2\ud986\udf96\udabc\udefe\udb82\udc06",
        25, 24390, 28758755, -2242567829165101686L, 9578L, true, false, (char) 30954, (char) 16797,
        Double.longBitsToDouble(0x3fd87640578df320L), Double.longBitsToDouble(0x3fe616a094bc8c89L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 4, "\uda9b\udc47\udaa0\ude79\udb35\ude19\udac8\udc89\ud9db\ude5f\udb0f\udffe\ud8fc\uddaa\u7102\udbdc\ude23\ud9e7\udff5\uda72\udcf9\udbd4\udd95\ud801\udd36\uda86\udc72\ud90c\udc4e\ud881\udde1\udbf0\udd63\ud964\udfc9\ud995\ude05\ud8a0\udce0\ud86e\udd16\udb5a\udf55\udbe9\udf33\ud989\udef3\udb25\ude22\u2a39\ue981\udbdf\udcf8\ud94b\udc91\uda7c\udcd7\ud800\udfe9", "\uafa3\ua003\u75f4\u83b5\u1029\u0e81\u79b1\ud2d8\u1023\u21da\u8c46\u3556\u18a4\u1501\uce3e\ud150\u9ea4", "\ud925\udcb9\ud92a\udf55\ud877\udec5\ud8db\udf9a\ud971\udcc7\udbf4\ude02\ud968\udf22",
        -5, 44173, -1936960976, -8128077853758640459L, -70282L, false, false, (char) 10840, (char) 62587,
        Double.longBitsToDouble(0x3fe46c2be9963998L), Double.longBitsToDouble(0x3fd67274530ec80aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 1, 6, 3, 4, "\udb71\udd56", "\u2cbc", "\ud8fc\uddaa\u7102\udbdc\ude23\uda19\udfd6\udbeb\udc62\udbd4\udd95\ud801\udd36\uda86\udc72\ud961\udeed\ud881\udd3e\udb1f\udd7c\ud960\ude2d",
        2, 2304, 789741136, 1671033338014209121L, 26414L, true, true, (char) 60858, (char) 64087,
        Double.longBitsToDouble(0x3fbf10859d438848L), Double.longBitsToDouble(0x3fbdd83023e3f2b8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=java.lang.String:\uafa3\ua003\u75f4\u2f22\u9c93\u0e81\u02b8\ud29f\u1023\u9c84\u8bc0\u3556\u18a4\ub100\u7e3e\u217d\000 |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 2, 6, 0, 0, "\ud8c4\udc31\udab1\udd96\udb35\ude19\udac8\udd5a\ud9db\ude5f\udb0f\udffe\ud8fc\uddaa\u7102\udbdc\ude23\013\udbea\udf87\udae0\udffc\000\uda86\udc72\ud961\udeedK\udb1f\udd7c\u966b\ud995\ude05\ud8a0\udce0\ud86e\udd16\ub3f8\000\000\u73ef\u2a84\ub910\u2c8b\ud925\udf25\uda90\udd5b\ud800\udfe9", "\uafa3\ua003\u75f4\u2f22\u9c93\u0e81\u02b8\ud29f\u1023\u9c84\u8bc0\u3556\u18a4\ub100\u7e3e\u217d\000", "\ud925\udca3",
        39, 99757, 1724977034, 7535599330477118332L, -58880L, true, false, (char) 39938, (char) 54538,
        Double.longBitsToDouble(0x3fe0b4e5aae3a3ffL), Double.longBitsToDouble(0x3f9601b61c98c880L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 4, "\ud920\udfda\udab1\uddb8\udb35\ude19\udac8\udd5a\ud9db\ude5f\udb0f\udffe\ud8fc\uddaa", "\u3a25\u9850\u1cb6\u3c0f\u0796\uc903\u6af3\ucda8\u4e34\u14ca\ub3dc", "\udbe9\udf33\ud961\udef3\udb25\ude22\u2a99\ub910\ud804\udc8b\udbc3\uddb2\uda85\ude3a\ud800\udfe9\udbc3\udce9\ucdfa\uda19\udc2c\ud8c2\udc56\ud963\ude5a",
        11, 89486, -331489812, -979644154445063145L, -84455L, false, false, (char) 30622, (char) 49746,
        Double.longBitsToDouble(0x3fcc69cc00208764L), Double.longBitsToDouble(0x3fd7d0bfe66b8636L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=new com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 2, 6, 6, 6, "\ud8c4\udc31\udab1\udd96\udb35\ude19\udac8\udd5a\ud9db\ude5f\udb0f\udffe\ud8fc\uddaa\u7102\udbdc\ude23\uda19\udfd6\udbeb\udc62\udbd4\udd95\ud801\udd36\uda86\udc72", "\u5315", "\ud8a0\udce0\ud86e\udd16\udb69\udd55\udbe9\udf33\ud961\udef3\udb25\ude22\u2a84\ub910\ud804\udc8b\ud925\udf25\uda90\udd5b\ud800\udfe9\udbc3\udce9\ucdfa\uda19\udc2c\ud8c2\udc56\ud963\ude5a\udb71\uded1\ud9f9\udf51\udba3\udcc1\udb8c\ude07\ud9f6\udf9e\udb00\udd23\ud847\udf51",
        10, 94124, 1314921408, 2439047619054293000L, 11130L, false, true, (char) 18726, (char) 47535,
        Double.longBitsToDouble(0x3fec2b5ffd2dd9bfL), Double.longBitsToDouble(0x3fec54bffbaa66d1L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:\uafa3\ua003\u75f4\u82fb\u9d09\u0e81\u02b8\000\u0fda\u9c84\u8c46\u3556\u18a4\u1501\uce3e\ud150\u6d3d |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 4, "\ud8c4\udc31\udab1\udd96\udb35\ude19\udac8\udd5a\ud9db\ude5f\udb0f\udffe\ud8fc\uddaa\u7102\udbdc\ude23\uda19\udfd6\udbeb\udc62\udbd4\udd95\ud801\udd36\uda86\udc72\u008a\ud881\udd3e\udb1f\udd7c\u966b\ud995\ude05\ud8a0\udce0\ud86e\udd16\udb69\udd55\uda4b\udc63\ud956\udd8b\udb25\ude22\u2a84\ub910\ud804\udc8b\ud925\udf25\uda90\udd5b\ud800\udfe9", "\uafa3\ua003\u75f4\u82fb\u9d09\u0e81\u02b8\000\u0fda\u9c84\u8c46\u3556\u18a4\u1501\uce3e\ud150\u6d3d", "\ud925\udca3\udba5\udd43\udbcf\udf0b\ud865\udd99\udaca\uddd3\udbf4\ude02\ud968\udf22",
        -5, 33405, -615099904, -7154537881518723562L, -70282L, false, false, (char) 10840, (char) 62587,
        Double.longBitsToDouble(0x3fe46c2be93377b7L), Double.longBitsToDouble(0x3fd67d83530ec80aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:module$\ud8c4\udc31\udab1\udd96\uda16\udecb\uda88\udd81\ud928\ude3c\udb0f\udffe\ud8fc\uddaa\u7102\udbdc\ude23\uda19\udfd6\udab1\ude4b\uda58\udca9\ub548\uda86\udc72\ud961\udeed\ud98a\udc3b\ud8ba\ude1d\ud953\udceb\ud973\udf26\ud8a0\udce0\ud86e\udd16\udb69\udd55\udbe9\udf33\ud961\udef3\udb25\ude22\u2a84\ub910\ud804\udc8b\ud925\udf25\uda90\udd5b\ud800\udfe9\0121=java.lang.String:\ua76a\ua003\u75f4\u82fb\ubf31\u86fd\u1e7a\u0fed\u1023\u9c84\u8c46\u3556 |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 2, 4, 0, 4, "\ud8c4\udc31\udab1\udd96\uda16\udecb\uda88\udd81\ud928\ude3c\udb0f\udffe\ud8fc\uddaa\u7102\udbdc\ude23\uda19\udfd6\udab1\ude4b\uda58\udca9\ub548\uda86\udc72\ud961\udeed\ud98a\udc3b\ud8ba\ude1d\ud953\udceb\ud973\udf26\ud8a0\udce0\ud86e\udd16\udb69\udd55\udbe9\udf33\ud961\udef3\udb25\ude22\u2a84\ub910\ud804\udc8b\ud925\udf25\uda90\udd5b\ud800\udfe9", "\ua76a\ua003\u75f4\u82fb\ubf31\u86fd\u1e7a\u0fed\u1023\u9c84\u8c46\u3556", "\udbbe\udcbc\ud91b\udde6\ud87e\udc9b\uda1b\udf8d\ud8b7\udcd0\ud925\udca3\udba5\udd43\udbcf\udf0b\ud865\udd99",
        22, 46500, -726856272, 5150815463320723109L, -98388L, false, true, (char) 42466, (char) 52327,
        Double.longBitsToDouble(0x3fcc98c8918397dcL), Double.longBitsToDouble(0x3f8490e5a3615f40L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:\uafa3\ua003\u81b9\000\u9093\u0e81\u02b8\ud29f\u1023\u9c84\u8c46\u3556\u18a4\u1501\uce3e\ud150\u6d3d |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=java.lang.String:\ud8c4\udc31\udab1\udd96\udb35\ude19\udac8\udd5a\ud9db\ude5f\000\ud8fc\udd47\u7102\udbdc\ude23\uda19\udfd6\udbeb\udc62\u73fb\udadc\udd2d\uda86\udc72\ud961\udeed\ud867\udcf3\udb1f\udd7c\u966b\ud995\ude05\ud8a0\udce0\ud86e\udd16\udb69\udd55\udbe9\udf33\ud961\udef3\udb25\ude22\u2a84\ub910\ue4a6\ud925\udea9\uda90\udd5b\ud800\udfe9 |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 2, 0, 0, 4, "\ud8c4\udc31\udab1\udd96\udb35\ude19\udac8\udd5a\ud9db\ude5f\000\ud8fc\udd47\u7102\udbdc\ude23\uda19\udfd6\udbeb\udc62\u73fb\udadc\udd2d\uda86\udc72\ud961\udeed\ud867\udcf3\udb1f\udd7c\u966b\ud995\ude05\ud8a0\udce0\ud86e\udd16\udb69\udd55\udbe9\udf33\ud961\udef3\udb25\ude22\u2a84\ub910\ue4a6\ud925\udea9\uda90\udd5b\ud800\udfe9", "\uafa3\ua003\u81b9\000\u9093\u0e81\u02b8\ud29f\u1023\u9c84\u8c46\u3556\u18a4\u1501\uce3e\ud150\u6d3d", "\ud925\udca3\udba5\udd43\udbcf\udf0b",
        9, 46442, 1858245500, -3121823915933212832L, 52112L, false, true, (char) 51915, (char) 30434,
        Double.longBitsToDouble(0x3f9601b61c98c880L), Double.longBitsToDouble(0x3fb8397de0524390L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 4, "\ud8c4\udc31\udab1\udd96\udb35\ude19\udac8\udd5a\ud9db\ude5f\ud9c5\udd79\ud8fc\udde0\u7102\udbdc\ude23\uda19\udfd6\udbeb\udc62\udbd4\udd95\ud801\udd36\uda86\udc72\ud961\udeed\ud881\udd3e\udb1f\udd7c\u966b\ud995\ude05\ud8a0\udce0\ud86e\udd16\udb69\udd55\udbe9\udf33\ud961\udef3\udb25\ude22\ud9ca\udc58\ud951\ude05\ud804\udc8b\ud925\udf25\uda90\udd5b\ud800\udfe9", "\uafa3\ua003\u75f4\u82fb\u9d09\u0e81\u02b8\ud29f\u1023\u9c84\ua445\u35da\u18a4\u1501\uce3e\uae0c\u699e", "\ud925\udca3\udb97\udf02\ud9c7\ude2d\ud865\udd99\udaca\uddd3\udbf4\ude02\ud968\udf22",
        -5, 67781, -615099856, -7154537883062292970L, -70282L, false, false, (char) 10840, (char) 62587,
        Double.longBitsToDouble(0x3fe46c2be9c913b7L), Double.longBitsToDouble(0x3fd67d83530ec80aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=java.lang.String:module$\u2cbc\u1d5f\u2472\u00c4\u6e54 |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 2, 6, 2, 7, "\ud8c4\udc74", "\u2cbc\u1d5f\u2472\u00c4\u6e54", "\udadc\uddda\udbdd\udc24\ud801\udd36\uda86\udc72\ud961\udeed\ud881\udd3e",
        33, 64845, 1411686672, -2368054681993576880L, -94783L, false, true, (char) 42151, (char) 62295,
        Double.longBitsToDouble(0x3fea81b35ca61db2L), Double.longBitsToDouble(0x3fbf10859d438848L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 4, "\ud8c4\udc31\udab1\udd96\udb35\ude19\udae2\udf37\ud9db\ude5f\udb0f\udffe\ud8fc\uddaa\u7102\udbdc\ude23\uda19\udfd6\ud95a\udd5a\udbd4\udcbf\ud801\udd36\ud8e8\udf43\ua313\uaf0f\ud9b3\udfcb\u966b\ud995\ude05\ud8a0\udce0\ud86e\udd16\udb69\udd55\udbe9\udf33\ud961\udef3\udb25\ude22\u2a84\ub910\ud804\udc8b\ud925\udf25\uda90\udd5b\ud800\udfe9", "\uafa3\ucb45\u80ae\u82fb\u9d09\u0e81\u02b8\ud29f\u1023\u9c84\u8c46\u3556\u18a4\u1501\uce3e\ud150\u6d3d", "\ud925\udca3\udba5\udd43\udbcf\udf0b\ud865\udd99\ud94c\udd20\udbf4\ude02\ud968\udf22",
        -5, 44173, -615099856, -7154537883062292970L, -70282L, false, false, (char) 10840, (char) 62587,
        Double.longBitsToDouble(0x3fe46c2be93377b7L), Double.longBitsToDouble(0x3fd67d83530ec80aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:module$\u1d5f\u2472 |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=java.lang.String:module$\ud8c4\udc31\uda6d\udc34\012",
        Z.run(T, 2, 2, 5, 4, "\ud8c4\udc31\uda6d\udc34", "\u1d5f\u2472", "\udbdc\ude23\uda19\udfd6\udbeb\udc62\uda71\udf9e\u95ff\uc524\ud9f2\ude97\ud881\udd3e\udb1f\udd7c\u966b\udad0\udf83\uaef7",
        5, 16246, -1473506207, -7893352848352734670L, 78000L, false, false, (char) 33426, (char) 3249,
        Double.longBitsToDouble(0x3fbdd8302f707ab8L), Double.longBitsToDouble(0x3feb483a491074dcL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:module$\ud8c4\udc31\udab1\udd96\udb35\ude19\udac8\udd5a\ud947\udff9\udbf1\udd14\ud90a\udf6d\ud865\uded7\ud8d4\udd5a\uda6a\udd22\ud871\udead\udbd4\udd95\ud801\udd36\udaae\ude72\ud961\udeed\ud881\udd3e\udb1f\udd7c\uda1e\udd28\ud98e\udc54\ud8a0\udce0\ud86e\udd16\udb69\udd55\udbe9\udf33\ud961\udef3\udb25\ude22\u2a84\u7107\ud804\udc8b\ud925\udf25\uda90\udd5b\ud800\udfe9\0121=java.lang.String:module$\ud8c4\udc31\udab1\udd96\udb35\ude19\udac8\udd5a\ud947\udff9\udbf1\udd14\ud90a\udf6d\ud865\uded7\ud8d4\udd5a\uda6a\udd22\ud871\udead\udbd4\udd95\ud801\udd36\udaae\ude72\ud961\udeed\ud881\udd3e\udb1f\udd7c\uda1e\udd28\ud98e\udc54\ud8a0\udce0\ud86e\udd16\udb69\udd55\udbe9\udf33\ud961\udef3\udb25\ude22\u2a84\u7107\ud804\udc8b\ud925\udf25\uda90\udd5b\ud800\udfe9\012",
        Z.run(T, 2, 5, 5, 4, "\ud8c4\udc31\udab1\udd96\udb35\ude19\udac8\udd5a\ud947\udff9\udbf1\udd14\ud90a\udf6d\ud865\uded7\ud8d4\udd5a\uda6a\udd22\ud871\udead\udbd4\udd95\ud801\udd36\udaae\ude72\ud961\udeed\ud881\udd3e\udb1f\udd7c\uda1e\udd28\ud98e\udc54\ud8a0\udce0\ud86e\udd16\udb69\udd55\udbe9\udf33\ud961\udef3\udb25\ude22\u2a84\u7107\ud804\udc8b\ud925\udf25\uda90\udd5b\ud800\udfe9", "\uafa3\u0c34\ua7ef\u8174\u5898\u9bbc\u02e1\ud29f\u1023\u9c84\u8c46\u3556\u18a4\u9eec\uce3e\ud150\ub451", "\ud925\udca3\udba5\udd43\udbcf\udf0b\udb3c\udd94\udab0\udc47\udaf9\udce5\ud9bb\udfb2\ud986\udf96\udabc\udefe\udb82\udc06",
        25, 24390, -1025238958, 1377434159288488504L, 9578L, true, false, (char) 30954, (char) 16797,
        Double.longBitsToDouble(0x3fd87640538df320L), Double.longBitsToDouble(0x3fe616a094bc8c89L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=null |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 2, 1, 1, 4, "\uda9b\udc47\ua1df\udb87\udde8\u6730\ud9db\ude28\udb0f\udffe\ud8fc\uddaa\u7102\udbdc\ude23\ud9e7\udff5\uda72\udcf9\udbd4\udd95\ud801\udd36\uda86\udc72\ud90c\udc4e\ud881\udde1\udbf0\udd63\udb30\udfcf\ud995\ude05\ud8a0\udce0\ud86e\udd16\udb5a\udf55\udbe9\udf33\ud989\udef3\udb25\ude22\u2a39\ue981\udbdf\udcf8\udbe3\udd7d\ua265\ud800\udfe9", "\uafa3\ua003\u75f4\u83b5\u1029\u0e81\u79b1\ud2d8\u1023\u21da\u8c46\u3556\u18a4\u1501\uce3e\ud150\u9ea4", "\ud925\udcb9\ud92a\udf55\ud877\udec5\ud8db\udf9a\ud971\udcc7\udbf4\ude02\ud968\udf22",
        -5, 44173, -1936960976, -8128077853758640459L, -70282L, false, false, (char) 10908, (char) 62587,
        Double.longBitsToDouble(0x3fe46c2be9963998L), Double.longBitsToDouble(0x3fd67274530ec80aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=new com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 2, 7, 7, 6, "\uda9b\udc47\udaa0\ude79\udb35\ude19\ud8cb\uddaa\uda15\udd76\udb10\udc5c\udbf2\ude16\ud99d\udff4\udbb1\udece\ud9e7\udff5\u7a10\udbd4\udd95\ud801\udd36\uda86\udc72\ud90c\udc4e\ud881\udde1\udbf0\udd63\ud964\udfc9\ud995\ude05\ud8a0\udce0\ud86e\udd16\udb5a\udf55\udbe9\udf33\ud989\udef3\udb25\ude22\u2a39\udbda\udebe\udbdf\udcf8\ud94b\udc91\uda7c\udcd7\ud800\udfe9", "\uafa3\ub3b4\u8b11\u8db1\u1e7e\u5ec6\u3e10\ud37d\u1023\u21da\u8c46\u1782\ub728\u1501\ucea0\u7bdd\u9ea4", "\ud925\udcb9\ud92a\udf55\ud95d\udf98",
        20, 146, -11627652, -3121823916957999264L, -78960L, false, false, (char) 48616, (char) 30434,
        Double.longBitsToDouble(0x3f9601b61c98c880L), Double.longBitsToDouble(0x3fb8396a20524390L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:module$\u410e\ubbd3\u0c54\u3eea\u3c0f\u4b96 |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=java.lang.String:module$\ud8c4\udc74\udb99\ude4b\udb35\udd9f\ud92c\udc0d\ud980\udf3b\udb0f\udffe |this=com.google.javascript.jscomp.ProcessCommonJSModules:@?\012",
        Z.run(T, 2, 2, 2, 0, "\ud8c4\udc74\udb99\ude4b\udb35\udd9f\ud92c\udc0d\ud980\udf3b\udb0f\udffe", "\u410e\ubbd3\u0c54\u3eea\u3c0f\u4b96", "\udb1f\udd7c",
        30, 8672, -668796208, 3391913064779527160L, 84984L, false, false, (char) 62370, (char) 60858,
        Double.longBitsToDouble(0x3fed30ed90a58c97L), Double.longBitsToDouble(0x3fed43884a5f87f0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ProcessCommonJSModules:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 3, 4, "\ud8c4\udc31\uc7d8\000\000\ud9db\ude5f\udb0f\udffe\ud8fc\uddaa\u7102\000\uda19\udfd6\ud85f\udddc\000\ud801\udd32\udb62\udea0\ud961\ude63\ud881\udd3e\udb1f\udd7c\u966b\ud995\ude05\ud8a0\udce0\ud823\ude51\000\udbe4\uded2\udb99\udd6e\000\u2a84\000\000\000\ud913\udda8\ud800\udfe9", "\uafa3", "\udb71\uded1\u0c76\000\udb8c\udd32\ud9f6\udf9e\udaf5\uddda\ud847\udf51\000\ud8a4\udeb2\uda92\udfc5\udb64\uddf1\010\000\000\000\000\000\udba5\udcbe\000\u008a\000\000\000\ud986\udf96\u1ea5\udb23\uddd1\u00b4\000",
        -5, 97638, -436782876, 5220310097183419402L, -100000L, false, false, (char) 0, (char) 48983,
        Double.longBitsToDouble(0x3fe7e1ca0b17af48L), Double.longBitsToDouble(0x3fc5e4c7c2e7a9f4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.ProcessCommonJSModules|normalizeSourceName|java.lang.String|new:com.google.javascript.jscomp.ProcessCommonJSModules:com.google.javascript.jscomp.AbstractCompiler,java.lang.String",
    "M|com.google.javascript.jscomp.ProcessCommonJSModules|getModule||new:com.google.javascript.jscomp.ProcessCommonJSModules:com.google.javascript.jscomp.AbstractCompiler,java.lang.String",
    "M|com.google.javascript.jscomp.ProcessCommonJSModules|guessCJSModuleName|java.lang.String|new:com.google.javascript.jscomp.ProcessCommonJSModules:com.google.javascript.jscomp.AbstractCompiler,java.lang.String",
    "M|com.google.javascript.jscomp.ProcessCommonJSModules|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ProcessCommonJSModules:com.google.javascript.jscomp.AbstractCompiler,java.lang.String",
    "M|com.google.javascript.jscomp.ProcessCommonJSModules|toModuleName|java.lang.String|static",
    "M|com.google.javascript.jscomp.ProcessCommonJSModules|toModuleName|java.lang.String,java.lang.String|static",
    "C|com.google.javascript.jscomp.ProcessCommonJSModules|<init>|com.google.javascript.jscomp.AbstractCompiler,java.lang.String",
    "C|com.google.javascript.jscomp.ProcessCommonJSModules|<init>|com.google.javascript.jscomp.AbstractCompiler,java.lang.String,boolean",
    "M|com.google.javascript.jscomp.ProcessCommonJSModules|normalizeSourceName|java.lang.String|new:com.google.javascript.jscomp.ProcessCommonJSModules:com.google.javascript.jscomp.AbstractCompiler,java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
