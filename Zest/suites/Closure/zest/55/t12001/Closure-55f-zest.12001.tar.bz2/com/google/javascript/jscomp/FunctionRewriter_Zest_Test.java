package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class FunctionRewriter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.FunctionRewriter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 2, "\ud8c3\uded3\uda12\udf29", "\u1d09\u01e0\u8f44\u97b2", "\ud849\ude4c\u0c67\uda3a\udc59\ud94e\udf0d",
        4, 17478, 574840001, -1614371626026413246L, -43581L, true, true, (char) 20278, (char) 3362,
        Double.longBitsToDouble(0x3fdeee2674870ca8L), Double.longBitsToDouble(0x3fd4094d6a084eecL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.FunctionRewriter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 2, "\ud8c3\uded3\ud9ea\ude24", "\u1d09\u01e0\u8f44\u97b2", "\ud849\ude4c\u0c67\uda3a\udc59\ud94e\udf0d",
        4, 17478, 574840001, -1614371626026413246L, -43581L, true, true, (char) 20278, (char) 3362,
        Double.longBitsToDouble(0x3fdeee2674870ca8L), Double.longBitsToDouble(0x3fd4094d6a084eecL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.FunctionRewriter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 1, "\ud84b\uddbc\ud966\udf25\ud90a\udc00\uda17\udc4a\udb7b\udf4d\uda07\ude38\udb97\ude9e\ud9fd\udeeb\ud84c\ude9e\udbda\ude51\ud849\ude4c\udac4\udd0b\uda3a\udc59\ud94e\udf0d\ud911\udf76\udbe8\ude7e\udba1\udec5\u083d\ud879\ude83\ud898\udcbd\u0583\udadf\udfc2\ud90a\udf57\udbc8\udfa1\uab3a\ud94d\udfa9\ud9ef\ude5f\ud932\udd3d\ud8e0\udc28\ud9c5\udf76\ud988\udec2\ud900\udff2\ud939\udf93\udae8\udd4f\ud82a\udccf\uda64\udcd5\u0d69\uda1d\ude5e\ud9fc\udc28\udb2d\udfa1\ud86e\ude75", "\u57e1\u78f4\u72c0", "\ud887\udc23\ud8b4\udd29\udb77\udd1a\udb41\ude16\ud8fa\udc55\ud86a\udf78\u75d7\ud827\udc38\udb47\udd6d\uda29\udcaa\ud9b2\udc11\ud841\udf96\uda00\ude6c\ud849\udc26\uda62\udcc6\udb1c\ude0b\udb93\udf19\udb16\udeff\ud98d\udd24\udabe\udff9\ud90d\udd8f",
        55, 44602, 1559337724, 3593112522480846171L, -46327L, true, true, (char) 52210, (char) 37980,
        Double.longBitsToDouble(0x3fb799833b12c908L), Double.longBitsToDouble(0x3fe1365c6b9f87f8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 0, "\ud8c3\uded3", "\u757a\u1d09\ub5e0\u8f44\u97b2\u2382\uc04a\u4e80\uba2f\u0dfe", "\udbe8\ude7e\udba1\udec5\u083d\ud879\ude83\ud898\udcbd",
        40, 25936, 1623948707, 2688612805484688043L, -43581L, true, true, (char) 20278, (char) 3362,
        Double.longBitsToDouble(0x3fdeee2674870ca8L), Double.longBitsToDouble(0x3fd4094d6a084eecL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.FunctionRewriter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 2, "\ud8c3\uded3\uda12\udf29", "\u1d09\u01e0\u8f44\u97b2", "\ud849\ude4c",
        23, 63958, 1968269932, 6860206926013831102L, -60689L, false, false, (char) 51826, (char) 46008,
        Double.longBitsToDouble(0x3fe10663fda35fa1L), Double.longBitsToDouble(0x3fe8d3065aab4ce2L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.FunctionRewriter:@?\0121=new com.google.javascript.jscomp.FunctionRewriter:@?\012",
        Z.run(T, 2, 3, 3, 1, "\ud8c3\uded3", "\u757a\u1d09\u01e0\u8f44\u3e78\u2e3f\u90e2\ub9c1\uba1f\u0dfe", "\udbe8\udea8\udba1\udec5\u083d\udb22\ude57",
        57, 83460, 1604411936, 6974806588236422938L, -59564L, true, false, (char) 28659, (char) 20278,
        Double.longBitsToDouble(0x3fd3503ed39fdbeaL), Double.longBitsToDouble(0x3fe21c32a54094d6L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 2, "\ud8c3\uded3\uda12\udf29", "\u1d09\u01e0\u4b8b\u373e", "\ud849\ude4c\u0c5e\uda23\udf04\ud94e\udf0d",
        4, 17478, -1226711871, -1614371948148960446L, 70096L, false, false, (char) 56644, (char) 16357,
        Double.longBitsToDouble(0x3fe55a6715f4097bL), Double.longBitsToDouble(0x3fb8c0a62ffccfa0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 2, "\ud8c3\uded3\uda12\udf29", "\u18b6\u01e0\u8f44\u9810", "\ud934\udeb4\udbdc\udfab\uda3a\udc59\ud94e\udf0d",
        4, 17478, 574840001, -1614512364605287614L, -55084L, false, false, (char) 6265, (char) 25727,
        Double.longBitsToDouble(0x3fb3149d15f84bd8L), Double.longBitsToDouble(0x3fb8c0b7effccfa0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.FunctionRewriter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 2, "\ud8c3\uded3\uda12\udf29", "\u1d09", "\ud9fd\udeeb\ud84c\ude9e",
        46, 22489, -271340197, 361000515822738467L, 69918L, true, false, (char) 48081, (char) 55237,
        Double.longBitsToDouble(0x3fe3dee6a08c632cL), Double.longBitsToDouble(0x3fe10663fda35fa1L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.FunctionRewriter:@?\0121=new com.google.javascript.jscomp.FunctionRewriter:@?\012",
        Z.run(T, 2, 3, 3, 1, "\uda6d\udc06", "\u757a\u1d09\u0606\ua31d\u3e78\u2e3f\u90e2\ub9c1\uba1f\u0dfe", "\udbe8\udea8\udba1\udec5\u083d\udb22\ude57",
        57, 83460, 1604411936, 6974806588236422938L, -59564L, true, false, (char) 28659, (char) 27776,
        Double.longBitsToDouble(0x3fd3503ed39fdbeaL), Double.longBitsToDouble(0x3fe21c32a54094d6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.FunctionRewriter|isReduceableFunctionExpression|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.FunctionRewriter|parseHelperCode|com.google.javascript.jscomp.FunctionRewriter$Reducer|new:com.google.javascript.jscomp.FunctionRewriter:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FunctionRewriter|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FunctionRewriter:com.google.javascript.jscomp.AbstractCompiler",
    "C|com.google.javascript.jscomp.FunctionRewriter|<init>|com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FunctionRewriter|isReduceableFunctionExpression|com.google.javascript.rhino.Node|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
