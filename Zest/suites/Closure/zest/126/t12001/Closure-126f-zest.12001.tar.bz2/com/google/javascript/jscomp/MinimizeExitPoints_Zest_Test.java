package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class MinimizeExitPoints_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 6, "\ud81d\uddcd\ud95a\uddae\uda7f\uddcd\udbf5\udf89\udadb\udf40\uda85\uddf0", "\u91fa\u29dd\u47b3\ub576\ucdf6\u46bf\u39c8\u296a\ub6ee\u6757\u1938\u547b\ub098\u5525\u681d\u247c\u41b5\u5535\u0bbd\u2900\u07e3\uc57b\u9337\uad49\uc1e5\ubb46\u63c2\ua35a\u4c0c\u19ea\ucc39\ua29e\u4d72\u9ff7\u0bfe", "\ud830\udec4\ud873\udd2b\ud91d\uddff\uda8c\udd51\uda72\udcbd\u5381\uda0a\udcc7\uda96\udd30\ud980\uddd8\ud811\ude72\ud96f\udd1c\ub296\ud9a5\udeab\udbf4\ude84\udb9e\ude73\udbe7\udf02",
        29, 47338, -426809919, 3024607623894993417L, 11284L, true, false, (char) 24603, (char) 13804,
        Double.longBitsToDouble(0x3fdaaa57382dfd5eL), Double.longBitsToDouble(0x3fd8e84ee5d452c4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 6, "\ud81d\uddcd\ud95a\uddae\uda7f\uddcd\udbf5\udf89\udadb\udf40\uda85\uddf0", "\u91fa\u29dd\u47b3\ub53e\ucdf6\u46bf\u39c8\u296a\ub6ee\u6757\u1938\u547b\ub098\u5525\u681d\u247c\u1e04\u5535\u0bbd\u2900\u07e3\u444b\u9337\uad49\uc1e5\ubb46\u63c2\ua35a\u4c0c\u19ea\ucc39\ua29e\u4d72\u9ff7\u0bfe", "\ud830\udec4\ud873\udd2b\ud91d\udd85\uda8c\udd51\uda72\udcbd\u5381\uda0a\udcc7\uda96\udd30\ud980\uddd8\ud811\ude72\ud96f\udd1c\ub296\udb55\udf44\udbf4\ude5e\udb9e\ude73\udbe7\udf02",
        29, 47338, -426809919, 3024607623894993417L, 11284L, true, false, (char) 24603, (char) 13804,
        Double.longBitsToDouble(0x3fdaaa57382c555eL), Double.longBitsToDouble(0x3fc1d09dc9f06550L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 4, 6, "\ud81d\uddcd\ud95a\uddae\uda7f\uddcd\udbf5\udf89\udadb\udf40\uda85\uddf0", "\u91fa\u29dd\u47b3\ub576\ucdf6\u46bf\u39c8\u296a\ub6ee\u6757\u1938\u547b\ub098\u5525\u681d\u247c\u41b5\u5535\u0bbd\u7e00\u07e3\uc57b\u9337\uad49\uc1e5\ubb46\u63c2\ua35a\u4c0c\u19ea\ucc39\ua29e\u5fd0\u9ff7\u0bfe", "\ud830\udec4\ud873\udd2b\ud91d\uddff\uda8c\udd51\uda72\udcbd\u5381\uda0a\udcc7\uda96\udd30\ud980\uddd8\ud811\ude72\ud96f\udd1c\ud96f\udf05\ud882\ude53\ud802\uddb7\uda86\udf55\udbef\udd58",
        29, 47338, -426809919, 3024607623894993417L, 11284L, true, false, (char) 24603, (char) 13804,
        Double.longBitsToDouble(0x3fdaaa57382dfd5eL), Double.longBitsToDouble(0x3fd8e84ee5d452c4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 6, "\ud847\ude82\ud94a\udf76\uda7f\uddcd\udbf5\udf89\udadb\udf40\uda11\udd99\ud863\udda6\ud8aa\udebe\u0f38\ud9bf\udc72\uda37\uddf0\udb1b\udf43", "\u39c8\u296a\ub6ee\uacf8\u3669\u547b\ub098\u11e4", "\ud92f\udd74\ud97e\ude3f\udaeb\udfb7",
        23, 95804, 1672724305, 4591560224522873958L, -26406L, false, false, (char) 26625, (char) 57246,
        Double.longBitsToDouble(0x3feb36948a5d423fL), Double.longBitsToDouble(0x3fd35815317323a2L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 6, 6, "\ud8ee\uddeb\udaaa\udd8e\uda6c\udefc\udbf5\udf89\ud949\udd78\uda85\uddf0", "\u91fa\u29dd\u47b3\u3d77\uce64\u080f\ud03f\u2919\ub6ee\uc390\ua057\u547b\ub098\u5525\u5469\ud28e\u271f\u49f3\ubebc\u2900\ub9b4\u90cb\u9337\uad49\u4ce4\u4932\ud6c1\ua35a\u9e1f\u19ea\ucc39\ua29e\u3a50\u9ff7\u0bfe", "\ud94a\udef1\udb7b\udc74\ud91d\ude01\uda8c\udd92\uda72\udcbd\u5381\uda0a\udcc7\uda96\udd30\udad8\udc04\udbee\ude86\ud931\udc58\ub296\ud9a5\udeab\udbf4\ude84\udb9e\ude73\udbe7\udf02",
        29, 60626, -1209637439, 3745183563547207389L, 11284L, false, true, (char) 43630, (char) 13804,
        Double.longBitsToDouble(0x3fdaaa5738a9fd5eL), Double.longBitsToDouble(0x3fd8e84eedb852c4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 5, 0, "\ud81d\uddcd\ud95a\uddae\udb07\ude91\udbf5\udf40\udadb\udf40\uda85\uddf0", "\u91fa\u29dd\u47b3\ub576\ucdf6\u46bf\u39c8\u296a\ub6ee\u6757\u1938\u547b\ub098\u5525\u681d\u4b31\uca4d\u5535\u0bbd\u2900\u07e3\u9d2f\u15e3\u1029\u4333\ubb46\u63c2\ua35a\u4c0c\u19ea\ucc39\ua29e\u4d72\u9ff7\u0bfe", "\ud830\udec4\ud873\udd2b\ud91d\uddff\uda8c\udd51\uda72\udcbd\u5381\uda0a\udcc7\uda96\udd30\ud980\uddd8\ud811\ude72\udb18\ude4f\ub22c\ud9a5\udeab\udbf4\ude84\udb9e\ude73\udbe7\udf02",
        29, 47338, -426809919, 3024607623894993417L, 11284L, true, false, (char) 24603, (char) 13804,
        Double.longBitsToDouble(0x3fdaaa57382dfd5eL), Double.longBitsToDouble(0x3fd8e84ee5d452c4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 5, 0, "\uda3f\udcff\ud8b1\udf59\ud947\udd84\ud9da\udf76\udadb\udf40\uda85\uddf0", "\u61a5\uba4c\u47b3\ub576\ucdf6\u46bf\u39c8\u296a\ub6ee\u0fed\u1938\u547b\ub098\u5525\u681d\u247c\u41b5\u5535\u5168\u2900\u07e3\uc57b\u9337\uad49\uc1e5\ubb46\u63c2\ua35a\u4c0c\u043a\ucc14\ua29e\u4d72\u9ff7\u078d", "\ud961\ude10\ud873\udd2b\ud91d\uddff\uda8c\udd51\uda72\udcbd\u5381\uda0a\udcc7\uda96\udd30\ud980\uddd8\ud811\ude72\ud96f\udd1c\ub296\ud9a5\udeab\udbf4\ude84\udb9e\ude73\udbe7\udf02",
        22, 47338, -426809919, 3024607623894993417L, 11284L, true, false, (char) 24603, (char) 13804,
        Double.longBitsToDouble(0x3fdaaa57382dfd5eL), Double.longBitsToDouble(0x3fd8e84ee5d452c4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.MinimizeExitPoints:@?\012",
        Z.run(T, 1, 6, 2, 6, "\ud81d\uddcd\ud95a\uddae\ud96d\udc7a\ud9a9\udef3\ud99d\udc18\uda85\uddf0", "\u91fa\u29dd\u47b3\ub576\ucdf6\u4ea6\u39c8\u296a\uc603\u1a6e\u1938\u547b\ub098\uba4dh\u247c\u41b5\u5535\u0bbd\u2900\u07e3\u5a39\u9337\u5b2d\uc1e5\ubb46\u63c2\ua35a\u4c0c\u19ea\ucc39\ua29e\u4d72\u9ff7\u0bfe", "\ud935\udfa1\ud972\udfcc\ud833\udd03\uda83\ude0d\uda72\udcbd\u5381\uda0a\udcc7\uda96\udcea\ud980\uddd8\ud811\ude72\ud96f\udd1c\ub296\ud9a5\udeab\udbf4\ude84\udb9e\ude73\udbe7\udf02",
        -3, 70739, 643368087, 3020677660099676681L, -34579L, true, true, (char) 23325, (char) 19142,
        Double.longBitsToDouble(0x3fd8e845a5d452c4L), Double.longBitsToDouble(0x3fd605359a35ff46L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 3, 4, "\ud81d\uddcd\ud8e1\udd12\uda7f\udda8\udbf5\udf89\udadb\udf40\uda85\uddf0", "\u3a46\uc13e\u47b3\u7c47\ud727\uabf8\u39c8\ub8c8\ud317\uc9d8\u1938\u04b9\u3499\u5525\u681d\u247c\u41b5\uc08a\ua26f\u7b13\uca68\u3339\u0c6e\u1294\u5c31\u5143\u915c\u8a2f\u40ca\u19ea\ucc39\ua29e\u4d72\u9ff7\u0bfe", "\udafa\udca8\udab5\uddbb\ud91d\uddff\udb0a\udd50\uda72\udcbd\u5381\uda0a\udcc7\ud8dc\udd93\ud906\udce9\uda15\udc11\ud96f\udd1c\u2b84\ud9a5\udeab\udac3\udeec\ud957\udf2b\uda46\ude43",
        46, 58402, 2043519170, 7535765408045012835L, -42539L, true, true, (char) 8731, (char) 21198,
        Double.longBitsToDouble(0x3fae52b9c2a89bd0L), Double.longBitsToDouble(0x3fd4f84eeb8288daL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.MinimizeExitPoints:@?\012",
        Z.run(T, 1, 6, 4, 6, "\ud81d\ude25\ud95a\uddae\uda7f\uddcd\udbf5\udf89\udadb\udf40\uda85\uddf0", "\u91fa\u29dd\u47b3\ub576\ucdf6\u46bf\u39c8\u296a\ub6ee\u8d42\u191b\u547b\ub098\u5525\u681d\u247c\u41b5\u5535\u0bbd\u7e00\u07e3\uc57b\u9337\uad49\uc1e5\ubb46\u63c2\ua35a\u4c0c\u19ea\ucc39\ua29e\u5fd0\u9ff7\u0bfe", "\ud830\udec4\ud873\udd2b\ud91d\uddff\uda8c\udd51\uda72\udcbd\udbfc\udf80\uda0a\udcc7\uda96\udd30\ud980\uddd8\ud811\ude72\ud96f\udd1c\ud96f\udf05\ud882\ude53\ud802\uddb7\uda86\udf55\udbef\udd58",
        29, 47338, -423349311, 3024607623894993417L, 11284L, true, false, (char) 24603, (char) 13804,
        Double.longBitsToDouble(0x3fdaaa56382dfd5eL), Double.longBitsToDouble(0x3fd8e84ee5d452c4L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.MinimizeExitPoints:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 5, "\ud847\ude82\ud94a\udf76\uda7f\uddcd\udbf5\udf13\udadb\udf40\uda11\udd99\udaa6\udea8\udaf1\udf8e\u0f38\ud9bf\udc72\uda37\uddf0", "\u7bd9\u39c8\u296a\ub6ee\uacf8\u3669\u547b", "\ud886\uddb1\ud809\uded6",
        46, 89860, 877720350, -5161552617474636898L, -67310L, false, false, (char) 11522, (char) 42009,
        Double.longBitsToDouble(0x3fb610b494af6b58L), Double.longBitsToDouble(0x3fdff68496cda522L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.MinimizeExitPoints:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 6, "\ud847\ude82\ud94a\udf76\uda7f\uddcd\udbf5\udf89\udadb\udf40\uda11\udd99\ud863\udda6\ud8aa\udebe\u0f38\ud9bf\udc72\uda37\uddf0\udb1b\udf43", "\u39c8\u296a\ub6ee\uacf8\u3669\u5856\u862f\u120e", "\ud92f\udd74\ud97e\ude3f\udaeb\udfb7",
        0, 35032, 1672724305, 4591560224522873958L, -26406L, false, false, (char) 26625, (char) 57246,
        Double.longBitsToDouble(0x3feb36948a5d423fL), Double.longBitsToDouble(0x3fd35815317323a2L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.MinimizeExitPoints:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 2, "\ud81d\uddcd\ud95a\uddae\ud96d\udc7a\ud9a9\udef3\ud99d\udc18\uda85\uddf0", "\u91fa\u29dd\u47b3", "\ud910\udc8c\ud9cd\ude5a\udb0a\udee1\udad5\udd10\uda2c\udeb9\ud814\udf79\ud942\udde5",
        48, 45833, 1216434809, 5132203696005666536L, 61164L, true, false, (char) 57321, (char) 37184,
        Double.longBitsToDouble(0x3fed92659a4a3fb8L), Double.longBitsToDouble(0x3fec1b9bfa76060cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.MinimizeExitPoints:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 3, 5, "\ud847\ude82\ud94a\udf76\uda7f\uddcd\ud9ad\udd7f\uda9e\udef2\uda11\udd99\udb78\udeb1\udaf1\udf8e\ud90a\udc1a\ud9e4\udc1e\uda71\udcf7", "\u7bd9\u39c8\u296a\u4a30\u016b\u3669\u547b", "\ud886\uddb1\ud809\uded6",
        46, 89860, 877720350, -4242818293491055810L, -67310L, false, false, (char) 11522, (char) 42009,
        Double.longBitsToDouble(0x3fb610b4b4af6b58L), Double.longBitsToDouble(0x3fe8a7a7fbb1cb80L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.MinimizeExitPoints:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 1, "\ud847\ude82", "\u0b7c\u250d\uae81\u49e8\u71b4\u7d4b\u29dd\u3eb3\ub576", "\uda04\udda8\ud941\udfba\ud8bf\udfe5\ud831\udcbb\ud9f9\udc27\ud918\udde5\uda0a\udf0f\udb38\udf85\ud955\udf19",
        54, 78696, 758095860, 3769780197081905982L, -83441L, false, true, (char) 60445, (char) 11522,
        Double.longBitsToDouble(0x3fc0d8726f8c170cL), Double.longBitsToDouble(0x3fe150c281ff6849L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.MinimizeExitPoints:@?\0121=new com.google.javascript.jscomp.MinimizeExitPoints:@?\012",
        Z.run(T, 2, 6, 6, 3, "\ud847\ude82\ud950\udffa\uda7f\uddd3\udbf5\udf13\udadb\udf40\uda11\udd99\udaa6\udea8\uda84\udcb8\ud823\ude01\udb9b\udd27\ud8a6\udf90\udb1b\uded2", "\u39c8\u296a\ub6ee\uacf8\u3669\u547b\ub098\ub1e8\u6fd7", "\udabc\ude9d\ud8e9\ude33\ud92d\udf05\ud804\udce7\ud873\udd31\ud924\udf73",
        24, 74915, 1121116294, -1338747386087245163L, -45574L, false, true, (char) 41795, (char) 16750,
        Double.longBitsToDouble(0x3fc6eb6b40dcf2e8L), Double.longBitsToDouble(0x3fe27c1933ef5ce8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 5, 6, "\ud9ad\ude64\ud95a\udda7\uda7f\uddcd\udbf5\udf89\udadb\udf40\uda85\uddf0", "\u91fa\u29dd\u47b3\ub576\ucdf6\u46bf\u39c8\u296a\ub6ee\u6757\u1938\u6d10\uc809\ubb96\u67d8\u247c\u41b5\u5535\u0bbd\u2900\u07e3\uc57b\u9337\uad49\uc1e5\ubb46\u63c2\ua35a\u4c0c\u19ea\ucc39\ua29e\u4d72\u9ff7\u0bfe", "\ud830\udec4\ud873\udd2b\ud91d\uddff\uda8c\udd51\uda72\udcbd\u5381\ud87c\udce1\ud819\udf71\ud980\uddd8\ud830\udc72\ud96f\udd1c\ub296\ud9a5\udeab\udbf4\ude84\udb9e\ude73\udbe7\udf02",
        29, 71530, 1793635675, 3024607976082311689L, 11284L, true, false, (char) 24603, (char) 13753,
        Double.longBitsToDouble(0x3fdaaa573075c3a8L), Double.longBitsToDouble(0x3feda49d0a828d97L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.MinimizeExitPoints:@?\012",
        Z.run(T, 1, 6, 2, 6, "\ud81d\uddcd\ud95a\uddae\ud96d\udc7a\ud9a9\udef3\ud99d\udc18\uda85\uddf0", "\u91fa\u29dd\u47b3\ub576\ucdf6\u4ea6\u39c8\u296a\uc603\u1a6e\u1938\u547b\ub098\uba4dh\u247c\u41b5\u5535\u0bbd\u2900\u07e3\u5a39\u9337\u5b2d\uc1e5\u6e29\u63c2\ua35a\u4c0c\u19ea\ucc39\ua29e\u4d72\u9ff7\u0bfe", "\ud935\udfa1\ud972\udfcc\ud833\udd03\uda83\ude0d\ud941\udd25\ud9a5\udd06\uda44\udd91\udb80\ude0d\ud980\uddd8\ud811\ude72\ud96f\udd1c\ub296\ud9a5\udeab\udbf4\ude84\udb9e\ude73\udbe7\udf02",
        -3, 70739, 643368087, 3020677660099676681L, -34579L, true, true, (char) 23325, (char) 19142,
        Double.longBitsToDouble(0x3fd8e845a5d452c4L), Double.longBitsToDouble(0x3fa529ace2657c60L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.MinimizeExitPoints|tryMinimizeExits|com.google.javascript.rhino.Node,int,java.lang.String|new:com.google.javascript.jscomp.MinimizeExitPoints:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.MinimizeExitPoints|matchingExitNode|com.google.javascript.rhino.Node,int,java.lang.String|static",
    "M|com.google.javascript.jscomp.MinimizeExitPoints|moveAllFollowing|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.MinimizeExitPoints|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.MinimizeExitPoints:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.MinimizeExitPoints|tryMinimizeIfBlockExits|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,int,java.lang.String|new:com.google.javascript.jscomp.MinimizeExitPoints:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.MinimizeExitPoints|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.MinimizeExitPoints:com.google.javascript.jscomp.AbstractCompiler",
    "C|com.google.javascript.jscomp.MinimizeExitPoints|<init>|com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.MinimizeExitPoints|tryMinimizeExits|com.google.javascript.rhino.Node,int,java.lang.String|new:com.google.javascript.jscomp.MinimizeExitPoints:com.google.javascript.jscomp.AbstractCompiler",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
