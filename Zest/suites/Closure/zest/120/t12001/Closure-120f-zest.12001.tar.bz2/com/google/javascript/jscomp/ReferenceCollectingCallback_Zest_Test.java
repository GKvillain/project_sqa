package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class ReferenceCollectingCallback_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 3, "\uda5f\udf5a\ud87d\udf99\ud9b5\ude08\uda7d\ude6d\ud8ba\udc12\uda42\udedd\udb1c\udef3\ud82c\udcb2\ud87e\udc85\udb71\udd8f\ud8b3\udda9\uda3f\udc31\udb96\udcde\ud966\udd8f\ud8b3\ude83", "9\u458c\ube3d\u6a76\u9e21\u941e\u2620\u1b3d\ua9d9\u5d88\u8848\u7562", "\uda21\udc78\ud809\udc86\ud8ab\uddeb\ud879\ude96\udac3\udd5f\ud89b\udd94\ud90d\udd61\uda9b\udc43\ud98c\udf41\udbf0\udd0f\udb50\ude52\udb46\udcd3",
        21, 57293, 943670004, 5604825986005404210L, -48372L, true, true, (char) 49956, (char) 53523,
        Double.longBitsToDouble(0x3fd235b7ebdae3c8L), Double.longBitsToDouble(0x3fe35e1f434b0022L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 3, "\uda5f\udf5a\ud87d\udf99\ud9b5\ude08\uda7d\ude6d\ud8ba\udc12\uda42\udedd\udb1c\udef3\ud82c\udcb2\udbe3\udc8f\uda78\udf45\uda66\udcf4\uda10\ude19\udb96\udcde\ud966\udd8f\ud8b3\ude83", "9\u458c\ube3d\u6a76\u9e21\u941e\u2620\u1b3d\ua9d9\u5d88\u8848\u7562", "\uda21\udc78\ud809\udc86\ud8ab\uddeb\ud879\ude96\udac3\udd5f\ud89b\udd94\ud90d\udd61\uda9b\udc43\ud98c\udf41\udbf0\udd0f\udb50\ude52\udb46\udcd3",
        21, 57293, 943670004, 5604825986005404210L, -48372L, true, true, (char) 49956, (char) 53523,
        Double.longBitsToDouble(0x3fd235b7ebdae3c8L), Double.longBitsToDouble(0x3fe35e1f434b0022L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 10, 3, "\uda5f\udf5a\ud87d\udf99\ud9b5\ude08\uda7d\ude6d\ud8ba\udc12\uda42\udedd\udb1c\udef3\ud82c\udcb2\ud87e\udc85\udb71\udd8f\ud8b3\udda9\uda3f\udc31\uda03\udc35\udbaf\uddd5\ud82e\uded1", "9\u458c\ube3d\u6a76\u9ded\u941e\u2620\u3610\ua9ac\u5d88\u8848\u7562", "\uda21\udc78\ud809\udc86\ud8ab\uddeb\ud879\ude96\udac3\udd5f\ud89b\udd94\ud90d\udd61\uda9b\udc43\ud97f\udfb5\uda9a\ude90\udbd2\udd5b\udb46\udcd3",
        21, 57293, 943670004, 5604825986005404210L, -87028L, true, true, (char) 49754, (char) 53523,
        Double.longBitsToDouble(0x3fd235b7ebdae3c8L), Double.longBitsToDouble(0x3fe35e1f434b0022L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 3, "\uda5f\udf5a\ud87d\udf99\uda00\uddee\uda7d\ude6d\ud8ba\udc12\uda42\udedd\udb1c\udef3\ud82c\udcb2\ud87e\udc85\udb71\udd8f\ud8b3\udda9\uda3f\udc31\udb96\udcde\ud966\udd8f\ud8b3\ude83", "9\u458c\ube3d\u6a76\u9e21\u941e\u2620\u1b3d\ua9d9\u5d88\u8848\u7562", "\uda21\udc78\ud809\udc86\ud8ab\uddeb\ud879\ude96\udac3\udd5f\ud89b\udd94\ud90d\udd61\uda9b\udc43\ud98c\udf41\udbf0\udd0f\udb50\ude52\ud97b\udfd0",
        21, 57293, 943670004, 5604825985384647218L, -48372L, true, true, (char) 49956, (char) 53523,
        Double.longBitsToDouble(0x3fd235b7ebdae3c8L), Double.longBitsToDouble(0x3fe35e1f434b0022L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=new com.google.javascript.jscomp.ReferenceCollectingCallback:@?\012",
        Z.run(T, 2, 0, 11, 3, "\uda5f\udf5a\ud87d\udf99\ud9b5\ude08\uda7d\ude6d\ud8ba\udc12\uda42\udedd\udb1c\udef3\ud82c\udcb2\ud87e\udc85\udb71\udd8f\ud8b3\udda9\uda3f\udc31\udb96\udcde\ud966\udd8f\ud8b3\ude83", "9\u458c\ube3d\u6a76\u9e21\u941e\u2620\u1b3d\ua9d9\u5d88\u8848\u7562", "\uda21\udc78\ud809\udc86\ud8ab\uddeb\ud879\ude96\udac3\udd5f\ud89b\udd94\ud963\udc9d\ud842\udc4c\ud90c\uddae\udbf0\udd0f\udb50\ude52\udb46\udcd3",
        21, 57293, 943670004, 5604825986005404210L, -48372L, true, true, (char) 60003, (char) 62291,
        Double.longBitsToDouble(0x3fd235b7ebdae3c8L), Double.longBitsToDouble(0x3fe35e1f434b0022L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 5, "\uda5f\udf5a\ud87d\udf99\ud9b5\ude08\uda7d\ude6d\ud8ba\udc12\ud9b7\uddf6\udb00\udd9f\ud82c\udcb2\udbfc\udc84\u80e8\ud8d2\udf9b", "\uaff7\uc055\u1c5f\uca899\ua0c1\ube3d\u6a76\u9e21\u73dc\u037d\u1b3d\ua9d9", "\ud944\udf9d\ud8e6\udedf",
        6, 66520, 1771589197, -1154583721059613192L, -49039L, false, false, (char) 11659, (char) 48913,
        Double.longBitsToDouble(0x3f930872d0e21880L), Double.longBitsToDouble(0x3fefa20352bc52b6L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.util.HashMap$KeySet:[] |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 3, "\uda5f\udf5a\ud87d\udf99\ud9bd\uddad\uda7d\ude6d\ud8ba\udc12\uda42\udf4d\uda23\ude12\ud82c\udcb2\udb04\udd7e\udb71\udd8f\ud8b3\udda9\udb01\udcd3\ud927\udc87\ud966\udd8f\uda66\udd8c", "\u2c15\ucbe7\u69c2\u8eae\u1dfa\u941e\u4669\ucc3d\ua9d9\u5d88\uc40e\ucab7", "\uda21\udc78\udb98\udd15\ud8b6\udf90\ud847\udfbd\udac3\udd5f\ud89b\udd94\uda3e\udcf9\ud9cb\udea4\ud98c\uded4\uda2c\udc12\udb3d\udea7\udb46\udcd3",
        21, 57293, 943670004, 5604825792731875890L, -48372L, false, false, (char) 35623, (char) 36103,
        Double.longBitsToDouble(0x3fd235b7ea03f5c8L), Double.longBitsToDouble(0x3fe35e1f414b0022L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 9, 1, "\udaf1\udd7f\ud892\ude69\ud9b5\ude08\uda7d\ude6d\ud8ba\udc12\uda42\udedd\udb1c\udef3\ud82c\udcb2\ud87e\udc85\udb71\udd8f\ud8b3\udda9\uda3f\udc31\udb96\udd40\ud966\udd8f\ud944\udda9", "9\u458c\ube3d", "\ud8f3\udf3a\ud8bd\ude2a\ud919\udd61\ud8e8\udf0e\udbe9\ude02\udaa9\udecc",
        10, 47704, 54975061, -6344762667000264632L, 42668L, true, false, (char) 10549, (char) 18235,
        Double.longBitsToDouble(0x3fd153276585190aL), Double.longBitsToDouble(0x3f930872d0e21880L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 3, "\ud891\udd27\ud87e\udc68\ud9b5\ude08\uda7d\ude6d\ud8ba\udc12\uda42\udedd\udb1c\udef3\ud82c\udcb2\ud87e\udc85\udb71\udd8f\ud8b3\udda9\ud94a\udfb7\ud947\udef8\u892b\udb97\udfa4", "9\u458c\ube3d\u6a76", "\ud86f\udf5f\ud919\udd61\ud8e8\udf0e\udbe9\ude02\udaa9\udecc\ud944\udf9d\ud8e6\udeac\ud99a\ude86\udb99\udcb4\ud998\udf20\ud8ab\uddeb",
        52, 28813, -491562257, 3636201946023459605L, -44685L, true, false, (char) 21598, (char) 17778,
        Double.longBitsToDouble(0x3fe8696e72f4cd1dL), Double.longBitsToDouble(0x3fd052c024649b96L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=com.google.javascript.jscomp.ReferenceCollectingCallback$ReferenceCollection:@? |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\012",
        Z.run(T, 2, 0, 4, 3, "\uda5f\udf5a\000\ud9b5\udd14\uda7d\ude6d\ud8ba\udc12\uda42\udedd\udb1c\udef3\ud82c\udcb2\ud87d\udf94\udb71\udd8f\ud89d\udfa9\uda3f\udc31\udb96\udcde\ud966\udd8f\ud8b3\ude83", "9", "\udab3\udcb7\uda59\ude3d",
        8, 89457, -31898242, 7600348660941675065L, -44107L, false, true, (char) 48290, (char) 33233,
        Double.longBitsToDouble(0x3fe5a6c7464dba25L), Double.longBitsToDouble(0x3fcdfe08a9a13b4cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=void |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\012",
        Z.run(T, 2, 0, 0, 3, "\uda5f\udf5a\ud87d\udf99\ud9b5\ude08\uda7d\ude6d\ud8ba\udc12\uda42\udedd\udb1c\udef3\ud82c\udcb2\uda67\ude1a\udb71\udd8f\ud8b3\udda9\uda3f\udc31\udb96\udcde\ud966\udd8f\ud8b3\ude83\ud967\udf5f\udada\uddf0\udaad\udeea\ud9af\udc89\ud8ef\udf12\uda47\udea2\uda59\ude3d\ud904\udf22", "\ua9d9", "\udb52\udd63\udb2e\udedd",
        6, 66520, 1771589197, -2816974934999969100L, -49039L, false, false, (char) 11659, (char) 48913,
        Double.longBitsToDouble(0x3fc40e7d1a1c415cL), Double.longBitsToDouble(0x3fefa20352bc52b6L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 6, 3, "\uda5f\udf5a\udb34\udf07\ud9b5\ude08\ud9d3\udc4a\uda3d\ude8c\uda42\udeca\udb27\udc21\udabb\udc6a\ud87e\udc85\udb71\udd8f\ud8b3\udda9\uda3f\udc31\udb7c\udcde\ud836\uddc7\ud8b3\ude83", "9\u458c\ube3d\u0bf1\u9ea6\u941e\u2620\u1b3d\ua9d9\u5d88\u8848\u7562", "\udabc\udda6\ud8fb\udca1\ud8ab\uddeb\ud879\ude96\udac3\udd5f\ud89b\udd94\ud90d\udd61\ud819\udec1\ud9a4\udde3\udbf0\udd0f\udb50\ude52\udb46\udcd3",
        34, 68557, 943670004, 5604825984671746610L, -21571L, true, false, (char) 12507, (char) 45433,
        Double.longBitsToDouble(0x3fd4360e127caa32L), Double.longBitsToDouble(0x3fe43fd34ded71e4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 7, "\ud816\udc03\uda60\udea7\udb4f\udc48\uda8f\udd6d\ud8ba\udc12", "\ub79d", "\udab3\udfff\ud99b\udeb1\udb96\udcde\ud96c\ude8f\ud87d\udd7f\ud8c7\uddb6\uda2e\udd58\ud8d5\udf3a\ud9af\udc89\ud93f\udd59\ud970\udf55\ud8cb\udc15\ud904\udf22\ud869\udf91\uda29\udd69\ud8e8\udf0e\ud94d\udef4\udaaf\udfcd\ud857\udff3\ud8e6\udeac\udae6\udf31\udbed\udc7e\uda36\udc84",
        12, 34058, -263883187, 5679946155037078376L, 18078L, true, false, (char) 15700, (char) 174,
        Double.longBitsToDouble(0x3fe5e295b70d2dceL), Double.longBitsToDouble(0x3fdf4cd1df14707eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 10, 3, "\udb80\udfc9\u1c0b\ud9b5\ude08\uda7d\ude6d\ud8ba\udc12\uda42\udedd\udb1c\udef3\ud82c\udcb2\ud815\udfef\ud95b\udf20\ud8b7\udc29\uda3f\udc31\udb96\udcde\ud966\udd8f\ud8b3\ude83\ud888\udf53\udb87\udc22\udaad\udec6\ud9af\udc89\ud8ef\udf12\udab3\udcb7\uda59\ude3d", "\u1b3d\uc3fa\u5d88\u8848", "\ud99a\ude86\uda21\udc78\ud95a\udcb1\ud8ab\uddeb\ud879\ude96\uda09\udd62\ud89b\udd94",
        20, 70845, -777637182, 7949496497386613639L, 93212L, true, true, (char) 4114, (char) 36809,
        Double.longBitsToDouble(0x3fe1926e459be3bbL), Double.longBitsToDouble(0x3fee014d0cb1476bL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=java.util.HashMap$KeySet:[] |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\012",
        Z.run(T, 2, 11, 3, 7, "\ud94d\udf51\udb6e\udcbd\ud869\udcfa\u74a5\ud8ba\udc12\uda42\udedd\udb1c\udef3\ud82c\udcb2\udbe3\udc8f\uda78\udf45\uda66\udcf4\uda10\ude19\udb96\udce7\ud966\udd8f\ud8b3\ude83\ud967\udf5f\udada\uddf0\udaad\udeea\ud9af\udc89\ud8ef\udf12", "\u941e\u2620\u1b3d\ua9d9\u5d88\u8848", "\ud99a\ude86\uda21\udc78\udaf9\udc7e\ud8ab\uddeb\ud879\ude96\udac3\udd5f\ud89b\udd94",
        20, 565, 141701826, 1208328177238859399L, -34788L, true, true, (char) 4114, (char) 61897,
        Double.longBitsToDouble(0x3fe27333b64df08aL), Double.longBitsToDouble(0x3fee7e4704b36321L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 9, 7, "\uda5f\udf5a\ud87d\udf99\uda4f\udd0d\uda7d\ude6d\ud8ba\udc12\udaca\udeea\ud8d7\udf2b\ud8f6\udee9\ud829\udda0\ud948\ude8a\ud8b3\udda9\uda3f\udc31\uda03\udc35\udba4\uddd5\ud82e\uded1\ud925\uddc5\udada\udde4\udaad\udeea\ud9af\udc89\ud8ef\udf12\udab3\udcb7", "\u5033\u80aa\uc84d\u7211\u8848\ucfe3\ub1bb\u2e37\u98bc\uad76\u5608", "\udb1b\udd9b\udb4b\udf28\uda97\ude0c\ud97f\udfb5\uda9a\ude90\udbd2\udd5b\ud8e9\ude06",
        10, 57293, 943386100, -319327429596083662L, -87028L, true, true, (char) 49754, (char) 20455,
        Double.longBitsToDouble(0x3fd235b8fbdae3c8L), Double.longBitsToDouble(0x3fdf1c3e86960044L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=java.util.HashMap$KeySet:[] |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\012",
        Z.run(T, 2, 4, 3, 0, "\uda5f\udf5a\ud87d\udf99\ud9b5\ude08\uda7d\ude6d\ud8ba\udc12\uda42\udedd\udb1c\udef3\ud82c\udcb2\ud87e\udc85\udb71\udd8f\ud8b3\udda9\uda3f\udc31\uda03\udc35\udbaf\uddd5\ud82e\uded1", "\u0e26\ud5ac\u3886\u8949\ua624\u941e\u2620\u3610\ua9ac\u5d88\u8848\uadb5", "\udb78\udfcd\ud809\udc86\uda5a\udfa2\u7590\udac3\udd5f\ud89b\udd94\ud90d\udd61\uda9b\udc43\ud97f\udfb5\ud849\udc29\udbd2\udd9d\udb46\udcd3",
        21, 57293, 943670004, 6237034304442453878L, -61024L, true, false, (char) 39387, (char) 55067,
        Double.longBitsToDouble(0x3fe21b00b898587bL), Double.longBitsToDouble(0x3fd235b7edf00dc8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=null |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\012",
        Z.run(T, 2, 4, 4, 3, "\uda5f\udf5a\ud87d\udf99\uda00\uddee\uda7d\ude6d\ud8ba\udc12\uda42\udedd\udb1c\udef3\ud82c\udcb2\ud87e\udc85\udb71\udd8f\ud8b3\udda9\uda3f\udc31\udb96\udcde\ud966\udd8f\ud8b3\ude83", "9\u458c\ube3d\u6a76\u9e21\u941e\u2620\u1b3d\ua9d9\u5d88\u8848\u7562", "\uda21\udc78\ud809\udc86\ud8ab\uddeb\ud879\ude96\udac3\udd5f\ud89b\udd94\ud90d\udd61\uda9b\udc43\ud98c\udf41\udbf0\udd0f\udb50\ude52\ud97b\udfd0",
        21, 57293, 943670004, 5604825985384647218L, -76157L, true, true, (char) 55891, (char) 11117,
        Double.longBitsToDouble(0x3fed1ffb6dfa633eL), Double.longBitsToDouble(0x3fd318804c31260eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.util.HashMap$KeySet:[] |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=java.util.HashMap$KeySet:[] |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\012",
        Z.run(T, 2, 3, 3, 3, "\uda5f\udf5a\ud87d\udf99\uda00\uddee\uda7d\ude6d\ud8ba\udc12\uda42\udedd\udb1c\udef3\ud82c\udcb2\ud87e\udc85\udb71\udd8f\ud8b3\udda9\uda3f\udc31\udb96\udcde\uda43\udc9d\ud88f\udf22", "9\u458c\ube3d\u6a76\u9e21\u941e\u2620\u1b3d\ua9d9\u5d88\u8848\u7562", "\uda21\udc78\ud809\udc86\ud8ab\uddeb\ud879\ude96\udae5\udc5f\ud89b\udd94\ud90d\udd61\uda9b\udc43\ud98c\udf41\ud96b\udd6c\udb2d\udfb1\ud97b\udfd0",
        21, 57293, 943670004, 4724274530547862066L, -75765L, true, false, (char) 12507, (char) 48317,
        Double.longBitsToDouble(0x3fe21b070898587bL), Double.longBitsToDouble(0x3fd235b7ebdae3c8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=new com.google.javascript.jscomp.ReferenceCollectingCallback:@?\012",
        Z.run(T, 2, 11, 11, 3, "\uda5f\udf5a\ud87d\udf99\ud9b5\ude08\uda7d\ude6d\ud8ba\udc12\uda42\udedd\udb1c\udef3\ud82c\udcb2\ud87e\udc85\udafc\ude94\udbd3\udcd6\uda2d\udd34\udb96\udcde\ud966\udd8f\ud8c9\ude83", "9\u458c\ube3d\u6a76\u9e21\u941e\u2620\u1b3d\ua9d9\u4088\u2c23\u9d23", "\uda21\udc78\ud809\udc86\ud8ab\uddeb\ud879\ude96\udac3\udd5f\ud89b\udd94\ud963\udc9d",
        47, 226, 281298662, 4641767038748333044L, 8301L, false, false, (char) 36809, (char) 762,
        Double.longBitsToDouble(0x3fe4672977c02973L), Double.longBitsToDouble(0x3fc6666d65bbe9dcL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.util.HashMap$KeySet:[] |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=java.util.HashMap$KeySet:[] |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\012",
        Z.run(T, 2, 3, 3, 11, "\uda60\udf63\ud87d\udf99\udaa2\udd2e\udaa3\udc5d", "\u399f\ub439\u340c\ub06c\u37d1\u3d51\u71ad\uaff7\uc055", "\udaad\udeea\ud9af\udc89\udada\udcfd\udac7\udd9b\uda3e\udd06\ud904\udf22\ud86a\udc56\ud919\udd61\udae6\ude6e\udbde\udf79\udaa9\udecc\ud944\udf9d",
        14, 36781, 1851122686, 7608917661634271289L, 66323L, true, false, (char) 9787, (char) 14601,
        Double.longBitsToDouble(0x3fef17cf43ec6262L), Double.longBitsToDouble(0x3fa370c91a829740L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.ReferenceCollectingCallback:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 3, "\udac2\ude6a\ud87d\udf81\ud9b5\ude08\uda7d\ude6d\ud83f\udc14\uda42\udedd\udb1c\udef3\ud82c\udcb2\ud87e\udc85\udb71\udd8f\ud8b3\udda9\uda3f\udc31\udb96\udcde\ud966\udd8f\ud8b3\ude83", "9\u44d8\ube3d\u6a76\u9e21\u941e\u2620\u1b3d\ua9d9\u5d88\u5d06\u7515", "\uda21\udc78\ud809\udc86\ud8ab\uddeb\udbde\ude88\udac3\udd5f\ud89b\udd94\ud90d\udd61\uda9b\udc43\ud98c\udf41\udbf0\udd0f\udb50\ude52\udb46\udcd3",
        21, 57293, 943670004, 5604825986005404210L, -48372L, true, true, (char) 49956, (char) 53523,
        Double.longBitsToDouble(0x3fd235b7ebdae3c8L), Double.longBitsToDouble(0x3fe35e1f434b0022L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|addReference|com.google.javascript.jscomp.Scope$Var,com.google.javascript.jscomp.ReferenceCollectingCallback$Reference|new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|enterScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|exitScope|com.google.javascript.jscomp.NodeTraversal|new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|getAllSymbols||new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|getReferences|com.google.javascript.jscomp.Scope$Var|new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|getScope|com.google.javascript.jscomp.Scope$Var|new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|hotSwapScript|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|isBlockBoundary|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|shouldTraverse|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "M|com.google.javascript.jscomp.ReferenceCollectingCallback|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.ReferenceCollectingCallback:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
    "C|com.google.javascript.jscomp.ReferenceCollectingCallback|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior,com.google.common.base.Predicate",
    "C|com.google.javascript.jscomp.ReferenceCollectingCallback|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ReferenceCollectingCallback$Behavior",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
