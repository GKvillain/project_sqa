package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class NodeUtil_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 6, 10, "\uadec", "\u8bfe\u089e\ud619\uc29e\u0589\ub02d\u71b4\u194d\ud022\u3ed6", "\udb99\udcd1\udb9a\udceb\ud921\ude25\ud85d\udf8d\udb26\udd5b\ud9b4\uded6\ud869\udf00",
        16, 39773, -2059618887, 4343572611993107006L, 37096L, true, true, (char) 28454, (char) 59590,
        Double.longBitsToDouble(0x3fea299bf87a8e08L), Double.longBitsToDouble(0x3f8d9ef8eb7c1b40L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 6, 10, "\uadec", "\u8bfe\u089e\ud619\uc29e\u0589\ub02d\u71b4\u194d\ud022\u3ed6", "\uda1f\ude54\ud8e8\udf82\ud921\udeb8\ud85d\udf8d\udb26\udd5b\ud9a8\uded6\ud869\udf00",
        16, 39773, -2059618887, 4343572611993107006L, 37096L, true, true, (char) 28454, (char) 59590,
        Double.longBitsToDouble(0x3fea299bf87a8e08L), Double.longBitsToDouble(0x3f8d9ef8eb7c1b40L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$1:false\012",
        Z.run(T, 1, 1, 6, 1, "\uadec", "\u8bfe\u089e\ud619\uc29e\u0589\ub02d\u71b4\uc069\uc5b0\u3ed6", "\udb99\udcd1",
        25, 22780, 1580401152, 734588951681846663L, 94262L, true, false, (char) 13957, (char) 20056,
        Double.longBitsToDouble(0x3fc1729b5515c560L), Double.longBitsToDouble(0x3fec428bc133ed3aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 14, 8, "\uadec", "\u8bfe\u089e\u4bb9\uc09f\u7b2a\ucb54\u71b4\u31ce\ud022\u3f9c", "\udb99\udcd1\udb9a\udceb\ud921\ude25\ud962\udf87\udb26\udd5b\ud9b4\uded6\ud869\udf00",
        16, 81893, 1782467791, -6846927274446831372L, 44947L, true, true, (char) 26880, (char) 13934,
        Double.longBitsToDouble(0x3fe00fe920ccb7faL), Double.longBitsToDouble(0x3fea29985692a3aaL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 10, "\uadec", "\u8bfe\u089e\ud619\uc29e\u0589\ub02d\u71b4\u96bb\u1f1a\uaff1", "\udb99\udcd1\udb9a\udceb\uda9f\ude24\ud85d\udf8d\udb26\udd5b\ud9b4\uded6\ud869\udf00",
        16, 39773, -2059618887, 4343572611993107006L, 37096L, true, true, (char) 28454, (char) 59590,
        Double.longBitsToDouble(0x3fea299bf87a8e08L), Double.longBitsToDouble(0x3f8d9ef8eb7c1b40L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 0, 1, "\000", "\u8bfe\ua49d\ud619\uc29e\u0589\u79f4\u5c00", "",
        -5, -1000, 0, 1288776704L, 97120L, false, false, (char) 0, (char) 125,
        Double.longBitsToDouble(0x3fee78000525e6f6L), Double.longBitsToDouble(0x3fc736f1611e1400L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 0, 15, 10, "\uadec", "\u8bfe\u089e\ud619\uc29e\u4852\u9d9c\ud163\ub2c7\ud022\u3ed6", "\udb99\udcd1\udb9a\udceb\ud921\ude25\ud9ad\udf95\udb26\udd5b\ud9b4\uded6\ud869\udf00",
        49, 39784, -2059618887, 2710404215288035902L, 37096L, true, true, (char) 28454, (char) 59590,
        Double.longBitsToDouble(0x3fea299bf87a8e08L), Double.longBitsToDouble(0x3fed3e7be793ab4fL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 0, 6, 11, "\udafc\udc25\ud916\uddbc\uda53\udc3e", "\u43fc\uc36c\ub832\u6891\u619d\ua651\ud00d\u3ed6\u8ffd\u8356\u941f\uc684\u871a\u9975\u9b85\u63b3\u9ee1\u8e22\u2745\u3a72\u2c6a\u318c\u69d6\ub2d2\u7328\ub6a1\u87c1\u156f\u0649\u21b7\u40d2\u2205\ub4b3\ud414\uae1b\ucdfc\u02f1\u535c\u60a9\u545d\u7e6b\u8a73\u41c6\ud182\u34e0\u52f3\u4b09", "\udab3\udccf\ud992\ude39\ud8a7\udd03\ud86c\uddfe\udbbe\udd80",
        4, 89186, -1163026724, -3120522831666328724L, 61881L, true, false, (char) 8972, (char) 27074,
        Double.longBitsToDouble(0x3fbc41b0b279fc58L), Double.longBitsToDouble(0x3fc7cf42aa5fdce8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 6, 10, "\000", "", "",
        44, -1000, 0, 66991044457136128L, 73206L, false, true, (char) 49039, (char) 7506,
        Double.longBitsToDouble(0x3f25ae8001d6c000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 0, 13, "\uadcf", "\u610c\u089e\ud619\uc29e\u3a89\ub02d\u3726\u7557\u9676\u2c53", "\udb99\udcd1\udb9a\udceb\ud921\ude25\ud85d\udf8d\udb26\udd5b\ud8ed\udd43\ud860\udc4f\ud8fa\ude55",
        55, 48945, 2078636009, 3897572816619985287L, -90459L, false, true, (char) 41284, (char) 65008,
        Double.longBitsToDouble(0x3fc996ff4d14cdfcL), Double.longBitsToDouble(0x3fbea38220767be0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 6, 2, "\uadec\ud8de\ude21\ud8da\udf62\uda6e\udf89\udbe0\udd8f\udbd5\udcf9\ud9de\uddbf\udbef\udffe\ud842\udfc3\uda9d\uddb0\udb5b\ude55\udaae\udc41\ud9ad\udd0a\udb61\uddd6\ud8ac\uddcd\udb99\udcd1\udb9a\udceb\ud921\ude25\ud85d\udf8d\udb26\udd5b\ud9b4\uded6\ud869\udf00\udaf0\uddb0\udb94\udd8f", "\u1c92\u1d64\ub2e1\ub5d3", "\ud99f\uddc2\udb9e\udfd4",
        3, 50154, -261235698, -4813569901772223145L, -8767L, false, false, (char) 51661, (char) 38313,
        Double.longBitsToDouble(0x3f65c05271862b00L), Double.longBitsToDouble(0x3f932241c2cd5a00L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 1, 10, "\udaf5\uddf0", "\u5423\u08b1\ud619\uc29e\u0589\ub02d\u61d1\u194d\ud022\u3ed6", "\ud842\udcd2\uda16\udeee\ud921\ude25\ud85d\udf8d\udb26\udd5b\ud9b4\uded6\udaff\udd8c",
        16, 39773, -2059618887, 4343572611993107006L, 37096L, true, true, (char) 28454, (char) 59590,
        Double.longBitsToDouble(0x3fea299bfd47a6b3L), Double.longBitsToDouble(0x3f8d9ef8eb7c1b40L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 5, 6, "\uadec", "\u155c\u089e", "\udb3d\uded6\udb1e\udf19\ud80e\uddda\ud9df\udc6f\udaae\udc57\ud9ab\ude0a\udb61\uddd6",
        4, 62710, 1288776805, 1276753264531145451L, -80153L, true, false, (char) 35306, (char) 25418,
        Double.longBitsToDouble(0x3fdb9b78b9370430L), Double.longBitsToDouble(0x3febd8d9d862011bL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$1:false\012",
        Z.run(T, 1, 1, 6, 10, "\uda93\udfa3", "\u8bfe\u089e\ub3fc\u54ee\uc362\u3639\u71b4\u194d\ud022\u3ed6", "\udb99\udcd1\udb9a\udceb\ud921\ude25\ud85d\udf8d",
        53, 35295, 1569292669, -1804056900291298011L, -65255L, false, false, (char) 20056, (char) 20837,
        Double.longBitsToDouble(0x3fd457158f10a2f0L), Double.longBitsToDouble(0x3fd33ed3a4031648L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 0, 9, "\uadec", "\u8bfe\u3caf\u325e\uc29e\u0589\ub02d\u71b4\u194d\ud022\u3ed6", "\udb99\udcd1\ud925\udc71\ud9cf\uddc6\ud85d\udf8d\udb26\udd5b\ud9b4\uded6\ud869\udf00",
        16, 50541, 0, 16841278L, -51733L, true, true, (char) 6008, (char) 13934,
        Double.longBitsToDouble(0x3fe00fe92000b7faL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$2:true\012",
        Z.run(T, 1, 1, 6, 9, "\uadec\ud9ca\udf78\udbf1\ude3e\ud813\udffd\ud821\uddb8\udbd5\udd79\ud834\udf8a\udb3d\uded6\udb3d\udfdd\ud811\udd28\udab1\udff8\ud954\udfda\ud9a9\udfb0\ud91d\udd31\ud8ac\uddcd", "\u1f0c\u2a0f\u25c1\u435d\u0a88", "\ud9ee\udc33\ud8c5\udc3a\uda7a\ude4e\uda12\udf25\u3339",
        32, 95744, -1174170690, 3124517335356113184L, 3050L, false, false, (char) 51779, (char) 31563,
        Double.longBitsToDouble(0x3fea756c1b5ec4d6L), Double.longBitsToDouble(0x3f57e448fe8a8000L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$1:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 1, "\uadec", "\u8bfe\u089e\ud619\ub29d\u0589\ub02d\u71b4\uc069\uc5b0\u3ed6", "\udb99\udcd1",
        25, 22780, 1580401152, 734588951681846663L, 94262L, true, false, (char) 13957, (char) 20056,
        Double.longBitsToDouble(0x3fc1729b5515c560L), Double.longBitsToDouble(0x3fec428bc133ed3aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$3:unknown\012",
        Z.run(T, 1, 1, 6, 1, "\uae27", "\ua7d8\u21a8\u21f5\ua419\u0589\ub02d\u71b4\uc069\u84dd\ud3ee", "\ud870\udc46",
        11, 82887, 1580401152, 734588951681846663L, 94262L, true, false, (char) 13957, (char) 20056,
        Double.longBitsToDouble(0x3fc1729b5515c560L), Double.longBitsToDouble(0x3fec428bc133ed3aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$2:true\012",
        Z.run(T, 1, 1, 0, 1, "\ud807\udcd4\ud913\udf21\ud9a7\udc48\ud875\udcac\ud98d\udda4\uf311\udbd0\uded9\uda30\uddc7\udb0d\udfe1\ud80e\uddda\udab1\udff8\ud89b\ude15\ud9ad\udd0a\ud86c\udd98\ud9c3\udf38\udb99\udd99\udb9a\udceb\ud921\ude25", "\u4376\ud569\u7221\u039c\u501b\u67b8\u1150\u4c8a", "\udb54\ude0f\u855b\ud85b\udf27\uda47\udeff",
        13, 42349, -21047744, 1375667626233929962L, -77589L, true, false, (char) 47824, (char) 12557,
        Double.longBitsToDouble(0x3fe9fdc17d83cfcdL), Double.longBitsToDouble(0x3fdefb999c87968aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$2:true\012",
        Z.run(T, 1, 1, 12, 1, "\uadec\ud8de\ude21\ueb13\ud9d2\udfd9\ud81e\udc49\udbd5\udd65\ud834\udf8a\udb3d\uded6\udaff\udccb\ud80e\uddda\udab1\udff8\ud89b\ude15\ud9ad\udd0a\ud952\udc8b\ud8ac\uddcd\ud9d5\udc0a\udbab\udca8\udbe1\udc7a\ud96c\udd30\udb26\udd5b\uda65\udc2e\ud999\udce4\ud8ca\udc5b\ud95f\udc83\ud9fa\udd49\ud97a\udfd4\uda7a\ude5b\ud9f1\ude11\u3339\ud826\ude12\udb0f\ude6c\udb02\uddea\udbf2\ude19\udbf0\uddf5\udb72\udfba\uda02\udec7\udbb2\ude92\udb39\udca5\ud969\udee3\ud998\udd2f\ud8d4\ude94\ud850\ude02\ud976\udeac\uda73\udcd4", "\u090c\ua7ba\ua497\u5dfd\ua635", "\uda3e\ude7d\ud83a\udccb\udb90\ude74\udb2e\udd85\ud8c4\udeac\u2fea\udb1a\udfe9\ud919\udf9b\ud985\udeab\ud9f4\udc21\ud809\udc67\ud8da\ude8b\ud91b\udd5b\ud999\udf9f",
        12, 93406, 1470667748, -9132368692985967108L, 52889L, true, false, (char) 33198, (char) 50032,
        Double.longBitsToDouble(0x3fe6cf9695057870L), Double.longBitsToDouble(0x3fd5c424569f8e78L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$2:true\012",
        Z.run(T, 1, 1, 6, 1, "\uadec", "\u8bfe\u089e\u9e3d\uc29e\uc0d5\ub02d\u71b4\uc069\u8c3f\u3ed6", "\udb99\udcd1",
        10, 22780, 1580401152, 734588951681846663L, 94262L, true, false, (char) 13957, (char) 20056,
        Double.longBitsToDouble(0x3fc1729b5515c560L), Double.longBitsToDouble(0x3fec428bc133ed3aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 14, 8, "\uadec", "\u0401\u089e\u4bb9\uc09f\u5a97\u8c78\u71b4\u31ce\ud022\u3f9c", "\udb99\udcd1\udb9a\udceb\ud921\ude25\ud962\udfa6\udb26\udd5b\ud9b4\uded6\ud869\udf00",
        4, 81976, -113357617, -6846964232640413452L, 44947L, true, true, (char) 26880, (char) 13934,
        Double.longBitsToDouble(0x3fe00fe920ccb7faL), Double.longBitsToDouble(0x3fb14cc2bd9db6d0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\012",
        Z.run(T, 1, 0, 0, 0, "", "", "",
        -5, -1000, 1773797376, 228741209344L, -82424L, false, false, (char) 45478, (char) 31120,
        Double.longBitsToDouble(0x3fe9ff3090000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\0121=java.lang.Double:NaN\012",
        Z.run(T, 2, 0, 16, 15, "\uadec\ud8de\ude21\udbf1\ude6e\udbb5\udf26\ud821\uddb8\udbd5\udd79\ud834\udf8a\ud84b\udcfd\uda86\udf56\u33d8\uda6b\ude80\uda9c\udc57\ud9ad\udd0a\udb61\uddd6\ud8ac\uddcd\udb99\udcd1\udb9a\udceb\ud921\ude25\ud9ad\udf95\udb26\udd5b", "\u0bc9\ubf77\u6767\u96da\u1c92\ubab9\ub29e\ub5d3", "\ud99f\uddc2\udb9e\udfd4\uda59\udc8d\ud839\udd9e",
        53, -925, 792796134, 5600991230864563738L, -40583L, false, true, (char) 34417, (char) 32247,
        Double.longBitsToDouble(0x3fe8cd5c34f52490L), Double.longBitsToDouble(0x3fe4439d7588e388L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\0121=java.lang.Double:NaN\012",
        Z.run(T, 2, 0, 16, 11, "\uae42", "\u8bfe\u089e\ud619\uc29e\u4852\u9d9c\ud163\ub2c7\u4990\u148b", "\udb99\udcd1\udb9a\udceb\ud921\ude25\ud9ad\udf95\udb26\udd5b\ud9b4\uded6\ud869\udf00",
        49, 16456, 1075902855, 2710404215288035902L, 37096L, true, true, (char) 28454, (char) 967,
        Double.longBitsToDouble(0x3fea299bf87a8e08L), Double.longBitsToDouble(0x3fed3e7be793ab4fL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$2:true\012",
        Z.run(T, 1, 1, 6, 10, "\uda93\udfa3", "\u8bfe\u089e\ub3fc\u54ee\uc362\u3639\u71b4\u194d\u084e\u3ed6", "\ud859\udeeb\udb9a\udceb\ud921\ude25\ud85d\udf8d",
        9, 35295, 1569292669, -1804056900291298011L, -65255L, false, false, (char) 20056, (char) 20837,
        Double.longBitsToDouble(0x3fd457158f10a2f0L), Double.longBitsToDouble(0x3fd33ed3a0031648L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$1:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 14, "\uda93\udfa3", "\u8bfe\u089e\ub3fc\u4030\uc1c5\ucf33\u71b4\u194d\ud022\u3ed6", "\udb99\udcd1",
        25, 34268, 1580401152, 734588951299116423L, 34863L, false, false, (char) 27997, (char) 64899,
        Double.longBitsToDouble(0x3fe1f1e23c6201f6L), Double.longBitsToDouble(0x3fc1729b5515c560L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$2:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 13, "\uda01\udc36\ud9ca\udf82\udbf1\ude3e\ud813\udffd\ud821\uddb8\ud9f2\udda6\ud9b8\udd33\ud8c4\udfaf\udb3d\udf8e\ud831\udc8e\udab1\udff8\ud954\udfda\udab5\udea2\udb12\uddbc\udb92\udf7d", "\u1f0c\u2a0f\u25c1\u435d\u0a88", "\ud9ee\udc33\ud8c5\udc3a\uda7a\ude4e\ud849\udeda\ud8b8\udfb3",
        12, 11013, -1174170773, 3124517335356113184L, 3050L, false, false, (char) 51779, (char) 31563,
        Double.longBitsToDouble(0x3fea756c1b5ec4d6L), Double.longBitsToDouble(0x3f57e449248a8000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$2:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 9, "\ud8cd\uddfd\uda00\udd9d\udbf1\ude3e\ud813\udffd\ud821\uddb8\udbd5\udd79\ud834\udf8a\udb3d\uded6\udb7e\udffd\ud811\udd28\udab1\udff8\udbd3\udd5a\ud9c2\uddf5\ud91d\udd31\ud8ac\uddcd", "\u1f90\u2a0f\u25c1\u435d\u686c", "\ud991\udfee\ud8c5\udc71\ud9bd\udcfe\uda12\udf25\u3339",
        32, 95744, -1174170690, -5810624325346950880L, 3050L, false, false, (char) 13915, (char) 5570,
        Double.longBitsToDouble(0x3fef30f31b5e47a8L), Double.longBitsToDouble(0x3f57e448fe8a8000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$1:false\0121=com.google.javascript.rhino.jstype.TernaryValue$1:false\012",
        Z.run(T, 2, 1, 1, 1, "\udb04\udcf8", "\u051e\u089e\u62df\ucac5\u10dd\ub02e\u71b4\uc069\u0810\u767a\u59ef", "\udb9a\udceb\ud921\ude25\ud85d\udf8d\ud8b0\uddce\u5485\ud8cf\udcc5\ud9ab\udcac\udbfc\udcfe\ud9fa\udd54\ud97a\udfd4\uda81\udcd0\ud9f1\ude11\u3339\ud8ca\ude59\ud8b2\udd26\udb1d\ude37\ud9b6\udcea\uda41\uddf6\uda5a\ude30\ud8ea\udd3a\ud8a7\udde2\ud9bf\udd50\ub3b8\uda68\udd8f\ud909\udcdc\ud94f\udd92\uda8a\uddea\ud899\udde4\udbda\udd95\ud8b0\udc13\uda44\udf28\uda07\udf90\ud9d2\udc5a\ud82a\udfe3\ud934\udf6b\udb99\udf89\ud99b\udfc6\udb89\udd00",
        1, 35964, -157621239, 2416532837169113379L, 52556L, true, true, (char) 51469, (char) 36482,
        Double.longBitsToDouble(0x3fd992b3169e57c2L), Double.longBitsToDouble(0x3fd7a1208f5fe874L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$1:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 1, "\uadec", "\u8bfe\u089e\ud619\ub29d\u0589\ub02d\u71b4\uc069\uc5b0\u3ed6", "\udb99\udcd1",
        25, 22780, 1580401152, 734588951681846663L, 94262L, true, false, (char) 13957, (char) 20056,
        Double.longBitsToDouble(0x3fc1729b5515c560L), Double.longBitsToDouble(0x3fec428bc133ed3aL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$1:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 1, "\uadec", "\u8bfe\u089e\u2712\ucbce\u70cc\u43a1\u969d\uc069\uc5b0\u3ed6", "\ud8e2\udeb7",
        15, 22780, 1580401152, 734588951681846663L, -15567L, true, false, (char) 5601, (char) 6874,
        Double.longBitsToDouble(0x3fe1f1e23c6201f6L), Double.longBitsToDouble(0x3fc1729b5515c560L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$1:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 13, "\u99ef\ud8de\ude21\udb07\udc13\ud869\udd45\ud821\uddb8", "\u9d2c\u4b15\u138d\u4741\uc5b0\u70e9\u0f3f", "\udbfe\udf5e",
        43, 53152, 171034818, 8073362630860197600L, -88399L, false, false, (char) 6874, (char) 62821,
        Double.longBitsToDouble(0x3feb1009c48b94daL), Double.longBitsToDouble(0x3fd457158f10a2f0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$1:false\0121=com.google.javascript.rhino.jstype.TernaryValue$1:false\012",
        Z.run(T, 2, 1, 1, 12, "\uadec\ud8de\ude21", "\u089e\ud619\ub29d\u0589\ub02d\u71b4\uc069\uc5b0\u3ed6\ubebe\u32a4\u7df5\u3f70\u6554\u39a5\u1cd7\u435d\uc743\u7c87\u53ae\u501b\u67b8", "\u3339\ud826\ude12\udb0f\ude6c\ud840\udca8\ud98d\udca9\udbd6\udf30",
        42, 49866, 884767044, 2265358156593167566L, 69881L, true, true, (char) 50488, (char) 10493,
        Double.longBitsToDouble(0x3fee401f31d7f159L), Double.longBitsToDouble(0x3fee2e8362555cf5L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$2:true\0121=com.google.javascript.rhino.jstype.TernaryValue$2:true\012",
        Z.run(T, 2, 1, 1, 2, "\uadec\ud8de\ude21\udbf1\ude6e\ud813\udffd\ud821\uddb8\udbd5\udd79\ueb8a\udb3d\uded6\udaff\udccb\ud80e\uddda", "\u3ed6\ubebe\u32a4\u7df5\u3f70\u6554\u36fa\uc3d8\u435d\ub074", "\ud9fa\udd54\ud97a\udfd4\uda7a\ude5b\ud9f1\ude11\u3339",
        32, 58008, 216746291, -8857619145484334955L, -21171L, true, false, (char) 56747, (char) 23162,
        Double.longBitsToDouble(0x3fe30a41fd344cd7L), Double.longBitsToDouble(0x3fc9f4a3b7f21e24L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$2:true\0121=com.google.javascript.rhino.jstype.TernaryValue$2:true\012",
        Z.run(T, 2, 1, 1, 13, "\uda01\udc36\ud9ca\udf82\udbf1\ude3e\ud813\udffd\ud821\uddb8\ud9f2\udda6\ud992\uded7\ud93e\udfac\udb3d\udfe6\ud831\udc8e\udab1\udff8\ud954\udfda\udab5\udea2\udb12\uddbc\udb92\udf7d", "\u1ee2\u2a07\ud14e\u435d\u0a88", "\udbe5\udf2a\ud8c5\udc62\udb22\ude42\ud849\udeda\ud8b8\udfb3",
        12, 11013, -1174170773, 3124517335356113184L, 3050L, false, false, (char) 51779, (char) 31563,
        Double.longBitsToDouble(0x3feecd6c1b5ec476L), Double.longBitsToDouble(0x3f57e449248a8000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$3:unknown\0121=com.google.javascript.rhino.jstype.TernaryValue$3:unknown\012",
        Z.run(T, 2, 1, 1, 16, "\uda01\udc36\uda02\udc82\udbf1\ude3e\ud813\udffd\ud821\uddb8\ud9f2\udda6\ud9b8\udd33\ud8c4\udfaf\udb3d\udf8e\ud831\udc8e\udab1\udff8\ud954\udfda\ud8dc\udc54\udb12\uddbc\udb92\udf7d", "\u1f0c\u2a0f\u25c1\u435d\u8eae", "\ud9ee\udc33\ud8c5\udc3a\uda75\udc4e\ud9b6\uddf2\ud890\udc3b",
        11, 11013, -1174170773, 3124517335356113184L, 3050L, true, false, (char) 51779, (char) 31563,
        Double.longBitsToDouble(0x3fea756c1b5ec4d6L), Double.longBitsToDouble(0x3f57e449248a8000L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 6, 10, "\uadec", "\u8bfe\u089e\ud619\uc29e\u0589\ub02d\u71b4\u194d\ud022\u3ed6", "\udb99\udcd1\udb9a\udceb\ud921\ude25\ud85d\udf8d\udb26\udd5b\ud9b4\uded6\ud869\udf00",
        16, 39773, -2059618887, 4343572611960207934L, -100000L, true, true, (char) 26880, (char) 13934,
        Double.longBitsToDouble(0x3fe00fe920ccb7faL), Double.longBitsToDouble(0x3fea299bf87a8e08L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 0, 0, 0, "", "\u5485", "\ud9f3\uddb9\udabc\udf09\u00ad\ud902\udce4\ud80e\uddda\udb07\udf49\udaae\udc57\ud9ad\uddd0\udb61\udd78\u373f\000\ud888\udd73\udbc2\udede\uda09\ude5a\ud8d7\udebb\udabe\udca6\udb22\udc20\ud8da\udd6a",
        26, 97892, -1802469316, 2862819636433777987L, -28599L, false, true, (char) 65332, (char) 10964,
        Double.longBitsToDouble(0x3fe8b7c5825c7e56L), Double.longBitsToDouble(0x3fe7b894cfbab2bdL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$2:true\0121=com.google.javascript.rhino.jstype.TernaryValue$2:true\012",
        Z.run(T, 2, 1, 1, 14, "\uda94\udc94\ud915\udd21\udbf1\ude4e", "\ub3fc\u4030\uc1c5\ucf33\u8242\u3704\ud76a\u3ed6", "\uda4a\udc81",
        9, 34268, 590545408, 734588294169120135L, 34863L, false, false, (char) 27997, (char) 64899,
        Double.longBitsToDouble(0x3fe1f1e23e6201f6L), Double.longBitsToDouble(0x3fc172891515c560L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$2:true\0121=com.google.javascript.rhino.jstype.TernaryValue$2:true\012",
        Z.run(T, 2, 1, 1, 5, "\uda01\udc36\ud9ca\udf82\udbf1\ude3e\ud813\udffd\udb3b\udee5\ud9f2\udda6\ud9b8\udd33\ud8c4\udfaf\udbdf\udd50\ud831\udc8e\udab1\udff8\uda04\ude92\ud87e\udeab\udb50\udc5d\udb92\udf7d", "\u1f0c\u2a0f\u25c1\u435d\u0a88\u27d0\ub650\u1efa", "\ud827\udf8d\ud8b8\udfb3\udbee\udc61\udadc\udc19\udb13\ude57\ud88b\udf30\u3240\udbb4\udfa5\ud9f5\udca1\ud9a9\udef4\ud8b6\udfba\u92a3\ud9ad\udfc5\udbc4\udece\udaff\udc15\uda59\udd20\udb0d\udcc3",
        10, 17404, -237952332, -3488258286773660498L, 54792L, true, true, (char) 17300, (char) 65517,
        Double.longBitsToDouble(0x3fe071d525cc3e53L), Double.longBitsToDouble(0x3fe7813746e37960L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=com.google.javascript.rhino.jstype.TernaryValue$2:true\0121=com.google.javascript.rhino.jstype.TernaryValue$2:true\012",
        Z.run(T, 2, 1, 1, 6, "\uda01\udc36\ud9ca\udf82\udbf1\ude3e\ud813\udffd\udb3b\udee5\ud9f2\udda6\ud9b8\udd33\ud8c4\udfaf\ud8f3\uddfb\uda69\ude56\ud243\udb1d\ude27\ud87e\udf34\udb50\udc5d\udb92\udf7d", "\u1f0c\u2a0f\u25c1\u435d\ud074\u274b\u5fcc\ud469", "\ud827\udf8d",
        13, 52082, -1996452067, -87012694714488087L, -98095L, false, true, (char) 18484, (char) 52805,
        Double.longBitsToDouble(0x3fef222a061e0973L), Double.longBitsToDouble(0x3fc0ae199c10a3e4L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\012",
        Z.run(T, 1, 0, 0, 0, "\014", "\u8bfe\000\000\000\000\u357a\u71b4", "\"",
        -5, 13143, 22, 5535253797182894164L, 16930L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd25e6f6a000116L), Double.longBitsToDouble(0x3fb1e14f11f1e238L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 0, 4, "\000\udb1b\udf12\u009c\000\ud8af\udc37\013\udb2f\udc97\udaf5\uddda\ud8e6\udf37\ud80e\uddda\ud8d4\udfaa\udaae\udc57", "\u8fb0\ub19d\000\u1a9c\ucd23\u7b33\uc16e\u1ac3\uc2ce\ub95a", "\ud94d\ude7b\ud882\udcad\ud856\udd1b\u7259\uda27\udd26\ud9f1\udf70\udad4\udf80\ud843\udeed\udafa\ude37\ud8e3\ude4c\udb17\udd4f\ud811\udca0\udb0d\udda5\ud807\udc67\udaa8\ude0f\u05f1\ud807\udd9c\ud8a9\udfbe\uda92\udd2b\ud84d\udc1d\udbea\udfcc\ud8d4\ude44\ud895\udd5a\ud9a7\udd8b\udaf0\udfb8F\udb06\ude1a\uda43\udd45\ud9cb\udf50\udbea\udfe5\ud900\udcd9\udbe5\udd62\uda9d\udfd6\ud806\ude96",
        27, 46483, -809442267, 9060736970659745165L, -44030L, true, false, (char) 61435, (char) 31226,
        Double.longBitsToDouble(0x3fb907ea0c135148L), Double.longBitsToDouble(0x3febb522e11c24edL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 0, 0, 0, "\014", "\u8bfe\u5e4d\000\u997a\ucff9\u3d29\u71b4", "\"",
        33, 69615, 31331, 5535253795528896596L, 60786L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd25e6f6a000116L), Double.longBitsToDouble(0x3fb1e14f11f1e238L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 0, 0, 0, "\014\udac8\udfe3\ud8e1\ude46", "\000\000\u4eaf\u357a\u71b4X\u2b8c\"", "\ud96a\udda8\ud9c5\udf18\ud921\ude25\ud84a\udc04\ud8e2\udd9d\u0087\udb6a\ude75\uda46\udc7e\ud8cc\udc13\ud9c5\ude57\ud94f\udf6b\ud9ef\udcc9",
        50, 83717, -2010179439, -4324242497472893481L, 26369L, false, true, (char) 60103, (char) 17281,
        Double.longBitsToDouble(0x3fe9cf531221e746L), Double.longBitsToDouble(0x3fe8808963c6292fL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 4, "\ud879\udfc2\udb1b\udf12\u009c\000\ud8af\udc37\013\udb2f\udc97\udaf5\uddda\ud8e6\udf37\ud80e\uddda\ud8d4\udfaa\uda98\udd6c", "\u8fb0\ub19d\000\u1a9c\ucd23\u7b33\uc16e\u1ac3\uc2ce\ub95a", "\ud94d\ude7b\ud882\udcad\ud856\udd1b\u7259\uda27\udd26\ud9f1\udf70\udad4\udf80\ud843\udeed\udafa\ude37\ud8e3\ude4c\udb17\udd4f\ud811\udca0\udb0d\udda5\ud807\udc67\udbb3\udc4e\u05f1\ud807\udd9c\ud8ca\udfbe\uda92\udd2b\ud84d\udc1d\udbea\udfcc\ud8d4\ude44\ud895\udd5a\ud9a7\udd8b\udaf0\udfb8F\udb06\ude1a\uda43\udd45\ud9cb\udf50\udbea\udfe5\ud900\udcd9\udbe5\udd62\uda9d\udfd6\ud806\ude96",
        27, 46483, -809442267, 9060736970659745165L, -44030L, true, false, (char) 61435, (char) 31226,
        Double.longBitsToDouble(0x3fb907ea0c135148L), Double.longBitsToDouble(0x3febb522e53324edL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\0121=java.lang.Double:NaN\012",
        Z.run(T, 2, 0, 0, 0, "\014\udac9\udcdc\ud8e1\ude46", "\000\000\u6cff\u357a\u71b4X\u2b8c\"", "\ud96a\udda8\ud9c5\udf18\ud921\ude25\ud84a\udc04\ud8e2\udd9d\u0087\udb6a\ude75\uda46\udc7e\ud8cc\udc13\ud9c5\ude57\ud94f\udf6b\ud9ef\udcc9",
        50, 83717, -2010179439, -4324242497472893481L, 26369L, false, true, (char) 60103, (char) 17281,
        Double.longBitsToDouble(0x3fe9cf531221e746L), Double.longBitsToDouble(0x3fe8808963c6292fL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\012",
        Z.run(T, 1, 0, 14, 8, "0\udac8\udfe3\ud8e1\ude46\ud807\uddfd\u00ad\ud8a5\udfce\ud8d4\udfbd\ud824\udec5\ud962\udf74\udab7\uddae\u00a1\uda84\udfc1\udad8\udf2e\ud8c1\udd39\udbbf\ude77\ud96a\udda8\ud9c5\udfc3\udb39\udc3f\udbb0\udd24\ud8b2\udced", "\u7ae0", "\ud93f\ude35",
        41, 11880, -455627283, -8633654950603443108L, 44652L, true, true, (char) 44850, (char) 60103,
        Double.longBitsToDouble(0x3f897eebce7a9880L), Double.longBitsToDouble(0x3fe10f3a3310112cL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Double:NaN\0121=java.lang.Double:NaN\012",
        Z.run(T, 2, 0, 16, 8, "0\udac8\udfe3\ud8e1\ude46\ud807\uddfd\u00ad\ud8a5\udfce\ud8d4\udfbd\ud824\udec5\u4119\udab7\ude36\u00a1\uda84\udfc1\udad8\udf2e\ud8c1\udd39\udbbf\ude77\ud96a\udda8\ud9c5\udfc3\udb39\udc3f\udbba\udd24\udb56\udc66", "\u304a", "\ud9ef\udcdd",
        27, 80885, 110815027, 7179569126265431967L, -2732L, true, true, (char) 16744, (char) 18382,
        Double.longBitsToDouble(0x3fe097224a3c7271L), Double.longBitsToDouble(0x3fea39c8868ae0c6L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\012",
        Z.run(T, 1, 0, 0, 0, "\u00a0", "\u59fe\u00ad\ubda0\u6fd8\u6f66\u357a\u7186", "\"",
        43, 79354, -1862270925, 8336866904303464532L, 73154L, true, false, (char) 0, (char) 60255,
        Double.longBitsToDouble(0x3f860834000022c0L), Double.longBitsToDouble(0x3fba5ae7128cc780L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Double:0.0\0121=java.lang.Double:0.0\012",
        Z.run(T, 2, 0, 0, 0, "\u00a0", "\u59fe\u00ad\ubda0\u6fd8\u6f66\u357a\u79a3X\u2b8c\"\u59cc\uabd0\u24a4\u0967", "\ud923\udd3eK\uda77\udf1a\udb98\udf10\ud8cc\udc13\ud9c5\ude57\ud862\ude56\u32b8\udbe5\udef8\ud91e\uddda\ud9d9\udf9f",
        10, 7812, 882839085, -7992464623131829253L, -1378L, false, true, (char) 36911, (char) 31360,
        Double.longBitsToDouble(0x3fe82b5af41ea86bL), Double.longBitsToDouble(0x3fefcd307d300346L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.NodeUtil|getStringNumberValue|java.lang.String|static",
    "M|com.google.javascript.jscomp.NodeUtil|isStrWhiteSpaceChar|int|static",
    "M|com.google.javascript.jscomp.NodeUtil|arrayToString|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|callHasLocalResult|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|canBeSideEffected|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|canBeSideEffected|com.google.javascript.rhino.Node,java.util.Set|static",
    "M|com.google.javascript.jscomp.NodeUtil|checkForStateChangeHelper|com.google.javascript.rhino.Node,boolean,com.google.javascript.jscomp.AbstractCompiler|static",
    "M|com.google.javascript.jscomp.NodeUtil|constructorCallHasSideEffects|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|constructorCallHasSideEffects|com.google.javascript.rhino.Node,com.google.javascript.jscomp.AbstractCompiler|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsCall|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsFunction|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsType|com.google.javascript.rhino.Node,int|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsType|com.google.javascript.rhino.Node,int,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.NodeUtil|copyNameAnnotations|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|evaluatesToLocalValue|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|evaluatesToLocalValue|com.google.javascript.rhino.Node,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.NodeUtil|getStringNumberValue|java.lang.String|static",
    "M|com.google.javascript.jscomp.NodeUtil|isStrWhiteSpaceChar|int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
