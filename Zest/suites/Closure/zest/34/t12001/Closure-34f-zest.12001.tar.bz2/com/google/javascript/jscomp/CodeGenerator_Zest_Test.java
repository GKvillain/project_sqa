package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class CodeGenerator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud8d1\udd5b\uda51\udec7\udbc3\ude5e\\u7d98\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 18, 8, "\ud8d1\udd5b\uda51\udec7\udbc3\ude5e", "\ub796", "\u8642\uda70\udf0d\udb0d\udcb9\udbb9\udd2b\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\u38cd\udb2b\udfac\uda1c\udf49\ud876\udc3a",
        19, 37802, -991644919, 9206296640640470537L, -2214L, true, true, (char) 32152, (char) 19206,
        Double.longBitsToDouble(0x3fd14c85c9c29ac6L), Double.longBitsToDouble(0x3fe22ef61df25a5fL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud8d1\udd5b\uda51\udec7\udbc3\ude5e\\u7d98\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 18, 8, "\ud8d1\udd5b\uda51\udec7\udbc3\ude5e", "\u7ac6", "\u8642\udbca\udc20\udb0d\udc50\udb32\ude48\ud86d\udce9\udaaa\udff6\ud93d\udcc6\udb50\udc37\u38cd\udb2b\udfac\uda1c\udf49\ud876\udc3a",
        22, 36799, -991644919, 9206296640640470537L, -2214L, true, true, (char) 32152, (char) 19206,
        Double.longBitsToDouble(0x3fd14c85c9c29ac6L), Double.longBitsToDouble(0x3fe1355fe5f25a5fL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 18, 8, "\ud8d1\udd5b\uda51\udec7\udbc3\ude5e", "\ub796", "\u8642\uda70\udf0d\udb0d\udcb9\udbb9\udd2b\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\u38cd\udbfd\udea5\uda62\ude73\ud876\udc3a",
        19, 37802, -991644919, 9206296640640470537L, -2214L, true, true, (char) 32152, (char) 19206,
        Double.longBitsToDouble(0x3fd14c85c9c29ac6L), Double.longBitsToDouble(0x3fe22ef61df25a5fL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 15, 8, "\udb8d\udfbe\ud995\udefe\ud8ad\uddde", "\u1a83\u7895\u5a5b\u054f\u14ec\ucdf0\u0fff\u518e\u21db\u3876\u4ee1\ub61d\uabef", "\udbd4\udf67\ud810\udc3a\ud8d8\ude60\ud9e7\udd8c\udb3f\ude9f\ud9c1\udd5d",
        11, 60580, -1422337739, -6459112860304567388L, 10779L, false, true, (char) 13798, (char) 40913,
        Double.longBitsToDouble(0x3fd4c8e4b87ee4f2L), Double.longBitsToDouble(0x3fc7d26d701b17a0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud8d1\udd5b\ud96d\udf96\udbc3\ude5e\\u0075\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 8, "\ud8d1\udd5b\ud96d\udf96\udbc3\ude5e", "\ub796", "\000\000\000\udbb9\udd2b\udbdb\udf75\udaab\udc17\ud93d\udcc6\u80a0\ud874\udd79\udaf4\udcac\uda1c\udf49\ud876\udc3a",
        19, 37802, 14988041, 0L, -66714L, true, true, (char) 117, (char) 0,
        Double.longBitsToDouble(0x3fd1400009c29ac6L), Double.longBitsToDouble(0x3ec8740000000000L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud8d1\udd5b\uda51\udec7\udbc3\ude5e\\u0a44\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 15, 4, 8, "\ud8d1\udd5b\uda51\udec7\udbc3\ude5e", "\ub796\u7895\u2af3\u0ee4\u4130\u111d\u6226\u2d73\u21f1\u1b6b\u2071", "\uda1c\udf49\ud876\udc3a\udb27\udd23\ud887\udd31\ud8f6\udc6d",
        43, 7529, -1381770696, 8918959073257815915L, -59277L, false, true, (char) 2628, (char) 30984,
        Double.longBitsToDouble(0x3fdf25a5f70599c8L), Double.longBitsToDouble(0x3fb753dbc3a57168L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud8d1\udd5b\uda51\udec7\udbc3\ude5e\udb07\udd15\udad1\udfd0\ud976\udc9b\ud915\udf75\uda4b\udd2a\\u8363\0121=void |a0=java.lang.StringBuilder:\ud8d1\udd5b\uda51\udec7\udbc3\ude5e\udb07\udd15\udad1\udfd0\ud976\udc9b\ud915\udf75\uda4b\udd2a\\u8363\012",
        Z.run(T, 2, 15, 15, 15, "\ud8d1\udd5b\uda51\udec7\udbc3\ude5e\udb07\udd15\udad1\udfd0\ud976\udc9b\ud915\udf75\uda4b\udd2a", "\u8559\u107b", "\udb40\udfe7\ud89a\udcb1\ud950\ude97\ud92e\udf88",
        53, 12220, 1995931169, -2464654613399613758L, 68020L, false, false, (char) 33635, (char) 25118,
        Double.longBitsToDouble(0x3fe11efbaf13abf3L), Double.longBitsToDouble(0x3fd14c85c9c29ac6L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 1, 8, "\u54d8\ud810\udda7\ud978\udf9e", "\ub796", "\u8642\uda70\udf0d\ud9a0\udee3\udbb9\udd2b\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb4f\udfbf\u38cd\udb25\udeac\uda1c\udf49\ud9cd\ude66",
        32, 15591, -1919437376, 4815051091812432636L, -2214L, true, true, (char) 32152, (char) 15586,
        Double.longBitsToDouble(0x3fd14c85c9c29ac6L), Double.longBitsToDouble(0x3fe22a451df25a5fL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 18, 8, "\ud8d1\udd5b\uda51\udec7\u948f\udad1\udde8\udad1\udfd0\ud976\udc9b\ud915\udf75\ud85e\udcdf\u8642\uda8c\udd5c\ud875\udcee\uda76\udc8e\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\u38cd\udb2b\udfd1\uda1c\udf49", "\u105c\u3cfb\ucd71\u00fe\uc89a\u0cb9\u88d9\u8a85\u8d21\u28cd\ucd7c\u60e4\u877d\u00b5\u0ae4\u4388\u7ceb\u3fec\uc51c\u8943\ud727\u5582\u1bb3", "\udbfd\udd45\ud99f\udf12\ud9b6\ude45\udb1b\ude3c",
        37, 91314, -1621737370, 6354087206656948859L, 82775L, true, false, (char) 26009, (char) 5183,
        Double.longBitsToDouble(0x3fdeaa46f96426f4L), Double.longBitsToDouble(0x3fabfc8eb1570810L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 18, 8, "\ud8d1\udd5b", "\u0ef1\u7e8c\ub796\ub401\000\u7ce5", "\uda5e\udc0e",
        -5, -1000, 0, 429270859L, -100000L, false, false, (char) 31172, (char) 0,
        Double.longBitsToDouble(0x3fe84eeef805c4e4L), Double.longBitsToDouble(0x3fe04bfe18000000L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 18, 8, "\udb93\udee1\uda7d\ude71\udbc3\ude5e", "\ub796", "\u8642\uda70\udf0d\udb0d\udcb9\udbb9\udd2b\udb42\udca9\ud8ed\udf55\ud81b\ude39\ud89d\ude16\udab0\udc41\uda2a\uddad\uda04\uddd4\ud876\udc14",
        35, 37802, -991644919, 9206296640640470537L, -2214L, true, true, (char) 32152, (char) 19206,
        Double.longBitsToDouble(0x3fd14c85c9c29ac6L), Double.longBitsToDouble(0x3fe22ef61df25a5fL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 1, 4, 0, 0, "\000", "", "\000",
        -5, -1000, 0, 1796845162L, -49439L, true, false, (char) 43142, (char) 27164,
        Double.longBitsToDouble(0x3fea5fc800331996L), Double.longBitsToDouble(0x3f00240000000000L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 18, 8, "\ud8d1\udd5b\uda51\udec7\udbc3\ude5e", "\ub796", "\u8642\uda70\udf0d\udb0d\udcb9\udbb9\udd2b\udbdb\udf75\udaab\udc17\ud93d\udcc6\ud9f3\udf29\uda21\udffc\u57ab\uda03\udc48\ud876\udc3a",
        19, 37802, -1965310795, 7835006072111713801L, -2214L, true, true, (char) 34301, (char) 368,
        Double.longBitsToDouble(0x3fd14c85c9c29ac6L), Double.longBitsToDouble(0x3fe7fc035df25a5fL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 18, 12, "\ud8d1\udd5b\uda51\udec7\udbc3\ude5e", "\ub796", "\u8642\uda70\udf0d\udb0d\udcb9\udbb9\udd2b\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\u38cd\udb97\udc81\uda1c\udf11\ud876\udc3a",
        41, 37591, -991644919, 9166410181305650697L, 26202L, false, true, (char) 32152, (char) 19206,
        Double.longBitsToDouble(0x3fd14c85c9c29ac6L), Double.longBitsToDouble(0x3fe22ef61df25a5fL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 8, 18, "\udbdf\uddb3\u7e6c\ud90f\udf38", "\ub0a1", "\udbb3\udf09\ud8ec\udeeb\udba6\udfc0",
        59, 21474, -1234335095, 3899198467956179198L, -25119L, false, true, (char) 9110, (char) 57068,
        Double.longBitsToDouble(0x3fd380011613bbbeL), Double.longBitsToDouble(0x3fe02e2726097fc3L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 4, 12, 8, "\ud8d1\udd5b\uda51\udec7\udbc3\ude5e", "\ub796", "\u8642\uda70\udf0d\udb0d\udcb9\udbb9\udd2b\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\u38cd\udb2b\udfac\uda1c\udf49\ud876\udc3a",
        19, 37802, -991644919, 9206296640640470537L, -2214L, true, true, (char) 32152, (char) 19206,
        Double.longBitsToDouble(0x3fd14c85c9c29ac6L), Double.longBitsToDouble(0x3fe22ef61df25a5fL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 1, "\ud8d1\udd5b\uda51\udec7\udbc3\ude5e", "\ub796", "\udb55\udefa\ud9e6\udf17\udab8\udfa6\ud9a7\udea2\ud9f8\uddb5\udaab\udc17\ud93d\udcc6\udb50\udc37\ud840\udda5\ud87f\udd7a\udb46\udcc7\ud909\ude21",
        13, 58527, -991644682, 9206296640640470537L, -2214L, true, true, (char) 32152, (char) 19206,
        Double.longBitsToDouble(0x3fd14c85c9c29ac6L), Double.longBitsToDouble(0x3fe22ef61df25a5fL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 10, 12, 11, "\ud8d1\udd5b\uda51\udec7\udbc3\ude5e", "\u9adb\u68d7\u05a8\u6669\u9f11\u8559\u107b\u24dc\u21db\u1b6b\u2071\u3d9e\u536f\u86da\ud34f", "\ud8f5\udf95\ud9e7\udd8c\udb3f\ude9f\ud9c1\udd5d\ud93a\udd51\ud80b\udd80\udbfe\udd2e\uda58\udfcb\uda1a\udda3\uda44\udeeb\ud98f\udf98\ud9a0\udc14\ud9b5\udfa6",
        -2, -439, -267341797, 6593926552933559921L, 66297L, false, true, (char) 40767, (char) 47119,
        Double.longBitsToDouble(0x3fd451190f82e4fcL), Double.longBitsToDouble(0x3fe0fab08fa9271dL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 8, "\ud8d1\udd68\uda51\udec7\udbc3\ude5e", "\ub796", "\u8642\ud9cc\udfb6\ud818\udfcb\udbb9\udd2b\udbdb\udf75\ud871\udccc\uda1d\udd39\udb45\udce6\u38cd\udb2b\udfac\uda1c\udf49\ud876\udc3a",
        19, 82274, -1721483133, -8865361717211865288L, -74947L, false, true, (char) 17783, (char) 18637,
        Double.longBitsToDouble(0x3fe22ef61df25a5fL), Double.longBitsToDouble(0x3fa2c42dcd0f3e60L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud8d1\udd5b\uda51\udec7\u53c7\ud824\ude2c\udaa1\udea6\ud976\udc9b\\udfb9\012",
        Z.run(T, 1, 15, 18, 10, "\ud8d1\udd5b\uda51\udec7\u53c7\ud824\ude2c\udaa1\udea6\ud976\udc9b", "\u0ee4\u4130\u8559\ucf96\u24dc\u21db\uc402\u61a0\u3d9e\u3256\u09b6\u6801", "\ud876\ude4c\ud8bc\udd56\ud8f6\udc86\ud9c1\udd5d\ud93a\udd51\ud80b\udd80\udbfe\udd2e\uda58\udfcb\ud9d9\udc43\uda44\udeeb\ud98f\udf98\udbe1\udeb4\uda0e\udf97\udb28\udd8f\udab2\ude93\ud8b5\uddc3\ud8b6\udd7b\udadb\uddbe\u6daa\ud905\udc47",
        0, 4147, 1502185102, 7316828148863745846L, -17227L, true, true, (char) 57273, (char) 29310,
        Double.longBitsToDouble(0x3fd7c339ecb29478L), Double.longBitsToDouble(0x3fe4ec3f82082cd1L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 18, 8, "\ud8d1\udd5b\uda51\udec7\udbc3\ude5e", "\ub796", "\u8642\uda70\udf0d\udb0d\udcb9\udbb9\udd2b\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\u38cd\udb2b\udfac\uda1c\udf49\ud876\udc3a",
        19, 37802, -991644919, 9206296640640470537L, -2214L, true, true, (char) 32152, (char) 19206,
        Double.longBitsToDouble(0x3fd14c85c9c29ac6L), Double.longBitsToDouble(0x3fe22ef61df25a5fL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud8d1\ude03\uda51\udec7\udbc3\ude5e\uda75\uddac\udad1\udfd0\ud976\udc9b\ud915\udf75\ud988\udffd\uda06\udeac\uda70\udf0d\udb0d\udcb9\udbb9\udd2b\udbdb\udf75\uda84\udd83\ud8ec\udda9\ud9a8\udfee\ud945\udf7b\udb08\udf65\uda1c\udf49\ud875\udfc7\udb27\udd23\\ub503\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 7, 3, "\ud8d1\ude03\uda51\udec7\udbc3\ude5e\uda75\uddac\udad1\udfd0\ud976\udc9b\ud915\udf75\ud988\udffd\uda06\udeac\uda70\udf0d\udb0d\udcb9\udbb9\udd2b\udbdb\udf75\uda84\udd83\ud8ec\udda9\ud9a8\udfee\ud945\udf7b\udb08\udf65\uda1c\udf49\ud875\udfc7\udb27\udd23", "\u1672\u00fe\uc89a", "\udbfe\udd2e\ud83f\udd29\ud9eb\udc80\uda2a\udd91\ud8c1\udd51\uda8f\udfd2\ud8a8\ude92\ud929\udc71\uda43\udcc4\ud96b\udf73\uda3d\udc66\udb23\ude24\ud9f2\udc75\ud8ed\udc86\ud822\udcd7\uda9d\udeb8\ud970\udd5e\udb6e\udc13\uda3f\udd96\udbb3\udef0\uda96\udfc1\udb6a\udccc\uda16\udfe4\udbc0\udef9\udb73\udf81\uda54\udc95\ud986\udee6\uda23\udfd0",
        46, 57350, -152143463, -6653405499386625507L, -45754L, false, false, (char) 46339, (char) 18330,
        Double.longBitsToDouble(0x3fdcd65824145492L), Double.longBitsToDouble(0x3fcb1de5ad779c40L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 18, 8, "\ud8d1\udd5b\uda51\udec7\udbc3\ude5e", "\ub796", "\u8642\uda70\udf0d\udb0d\udcb9\udbb9\udd2b\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\u38cd\udb2b\udfac\uda1c\udf49\ud876\udc3a",
        19, 37802, -991644919, 9206296640640470537L, -2214L, true, true, (char) 32152, (char) 19206,
        Double.longBitsToDouble(0x3fd14c85c9c29ac6L), Double.longBitsToDouble(0x3fe22ef61df25a5fL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud8d1\udd5b\udbcb\udd83\udbcd\udf8a\udb07\udd15\udaae\udfd0\ud966\udce9\ud915\udf75\\uc97d\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 8, 6, "\ud8d1\udd5b\udbcb\udd83\udbcd\udf8a\udb07\udd15\udaae\udfd0\ud966\udce9\ud915\udf75", "\u4130\u54b6\ua137\u383e\u21db\u1b6b\u2071\u2c3b\u20e4\ub219\u7fe4\u2502\uc608\u3cfb\ucd71\u00fe\u7d0d\ua0b9\u190b\u8a85\u8d21\u28cd\ud77c\u6561\u98ce\u7112\u0cde\u6c4a\u587d\u7c53", "\ud84c\udffd\ud94e\udc9c\udb8f\udf93\ud81e\udde1\ud8d6\udd4c",
        9, 21510, -1173395719, -2591623820544203268L, -91110L, true, true, (char) 51581, (char) 61142,
        Double.longBitsToDouble(0x3fcf8f64e67dd2acL), Double.longBitsToDouble(0x3fe14605da6e94d7L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 18, 8, "\ud8d1\udd5b\uda51\udec7\udbc3\ude5e", "\ub796", "\u8642\uda70\udf0d\udb0d\udcb9\udbb9\udd2b\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\ud8eb\udd1b\ud94f\ude4f\uda1c\udf49\ud876\udc3a",
        11, 37802, -999247095, 9206296640640470537L, -2214L, true, true, (char) 32152, (char) 19206,
        Double.longBitsToDouble(0x3fd14c85c9c29ac6L), Double.longBitsToDouble(0x3fe22ef61df25a5fL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 5, 6, "\ud995\ude91\uda51\udec7", "\ub6dc\ub796\u3095\ua8f3", "\udaf6\uddef\ud9c8\udc3e",
        27, 73980, -377713126, -497506333709031605L, 14069L, true, false, (char) 62045, (char) 22661,
        Double.longBitsToDouble(0x3fe84eeefe05c4e4L), Double.longBitsToDouble(0x3fe04bfe1a38823fL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 11, 5, 3, "\ud8d1\udd5b", "\u64f8\ub6dc\u5d7b\u4eac\u2af3\u2472", "\udbb9\udd2b\udbdb\udf75\udaae\udf55\ud93c\udf21",
        56, 54183, -1250146737, -4283979894893453287L, 82653L, true, true, (char) 6890, (char) 52684,
        Double.longBitsToDouble(0x3fe1c411fa06ada3L), Double.longBitsToDouble(0x3feb5f664623df75L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 12, 11, 8, "\ud8d1\udd5b\uda51\udec7\udbc3\ude5e", "\ub796", "\u8642\uda70\udf0d\udb0d\udcb9\udbb9\udd2b\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\u38cd\udb2b\udfac\uda1c\udf49\ud876\udc3a",
        19, 37802, -991644919, 9206296640640470537L, -2214L, true, true, (char) 32152, (char) 19206,
        Double.longBitsToDouble(0x3fd14c85c9c29ac6L), Double.longBitsToDouble(0x3fe22ef618f25a5fL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud8d1\udd5b\uda51\udec7\uda1e\udd09\\u4b06\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 3, 8, "\ud8d1\udd5b\uda51\udec7\uda1e\udd09", "\ub796\u7895", "\uda70\udf0d\udb0d\udcb9\udbb9\udd2b\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\u38cd\udb2b\udfac\uda1c\udf49\ud876\udc3a\udb27\udd23",
        2, 73081, 2143507973, -9061438126066247112L, -1845L, true, false, (char) 19206, (char) 44400,
        Double.longBitsToDouble(0x3fcc29ac69177b0cL), Double.longBitsToDouble(0x3fdf25abb576a6e2L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 18, 14, "\ud934\ude5e\udaa7\ude41\ud9f2\udd12\udb07\udce8\udad1\udfd0\ud878\udc99\udb64\ude74\uda4b\udd2a\udafd\udfaf\udb33\udf5d\uda81\udf6e\ud8e6\udecd\udbdb\udf75\udaab\udc17", "\u3d9e\u4582\ub219\ud34f\u0b21", "\ud9e7\udd8c\ud80c\udd84\ud9c1\udd5d\ud832\udd4b\ud8ce\ude7e\ud917\udc38\uda87\udc51",
        41, 71952, 268547974, -695966729313969485L, 14950L, false, false, (char) 64196, (char) 22187,
        Double.longBitsToDouble(0x3fd2fedaf7765642L), Double.longBitsToDouble(0x3fcf312ade166f68L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud8b6\udd2d\udb89\udd6d\udbc3\udece\ud805\udd14\udad1\udfd0\ud976\udc9b\ud915\udf75\uda4b\udd2a\u8642\\u85f1\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 13, 16, "\ud8b6\udd2d\udb89\udd6d\udbc3\udece\ud805\udd14\udad1\udfd0\ud976\udc9b\ud915\udf75\uda4b\udd2a\u8642", "\u47f6\u24dc\u21db\ube61", "\ud99f\udf21\uda60\udeb3\udb9d\udc0f\udb27\udd23\ud873\udfe7\ud8f5\udf8d\ud9e7\udd8c\udb3f\ude9f\ud9c1\udd5d\ud93a\udd51\ud80b\udd80\udbfe\udd2e\uda58\udfcb\uda1a\udda3\uda44\udeeb\ud98f\udf98\uf803\udafb\udeb5\ud993\udf6e\uda56\udd16\udbb9\ude10\ud946\udea5",
        4, 78387, 962019696, 8085985156022947082L, 30123L, false, true, (char) 34289, (char) 58036,
        Double.longBitsToDouble(0x3fa9968c780493b0L), Double.longBitsToDouble(0x3fd095c452b60490L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\uda2f\udcdd\\u29c9\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 8, 3, "\uda2f\udcdd", "\u124e\ub6dc", "\udb6a\udef3\udb79\udc43\ud879\ude20\ud896\ude20",
        0, 49786, -870548416, -1622179512540692320L, 88211L, true, true, (char) 10697, (char) 31172,
        Double.longBitsToDouble(0x3fe7e1a8b309ddbaL), Double.longBitsToDouble(0x3fe7cee80e097f05L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 5, 5, 2, "\ud8d1\uddc8\ud934\ude19\uda4f\udf44", "\ua8b0\u7956\u2af3\u0ee4\u4130\u8559\u107b", "\uda26\udc58\ud8e4\udf50\ud869\udd82\ud919\uddd1\ud9dd\udcd9\uda57\udfc6\udabf\uddb6\ud873\udf60\ud8f5\udf8d\ud9d4\ude8c\udb3f\ude9f",
        47, 56449, -545947797, -6056323201655595245L, 75181L, false, false, (char) 10449, (char) 1304,
        Double.longBitsToDouble(0x3fedb9f13e86fbfcL), Double.longBitsToDouble(0x3fe85cff39e0d04aL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 4, 4, 8, "\ud8d1\udd5b\uda51\udec7\udbc3\ude3f", "\u3f99", "\u8642\udaff\udc55\udae2\udf61\udbb9\udd2b\ud9c5\ude4b\ud9e0\udfaa\uda36\udfab\ud95d\uddf6\u3965\udb7b\udd1d\udbe1\uddfd\ud875\udffa",
        19, 37802, -991644919, -5069854998322524610L, -2214L, true, true, (char) 32152, (char) 19206,
        Double.longBitsToDouble(0x3fe8a642e497dd6fL), Double.longBitsToDouble(0x3fe22ef61b8a5a5fL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 12, 12, 8, "\ud8cd\udf3a\ud9fd\uded8\uda9d\udc1b\udbc7\udf75\udb26\ude9e", "\u2af3\ubb87", "\ud973\udf2c\udbdb\udf75\ud87c\udf1e\ud93d\udcc6",
        20, 19859, 127884851, 4483103394820710524L, -2182L, true, true, (char) 35233, (char) 52669,
        Double.longBitsToDouble(0x3fe1c411fa06ada3L), Double.longBitsToDouble(0x3fd83ddc58472b9eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 11, 11, 8, "\ud9ce\udea6\uf1bd\udbc3\udf27\udb07\udd15\udb19\udc74\udbd0\udf08\uda71\udc6d\ud801\udefa\ud86e\ude63\ud83b\ude4e\000\udbbc\udf2b", "\u1b6b\u80a0\u45a1\u3175", "\udb27\udd23\ud873\udfe7\ud9c8\udf16\000\000\000\u8206\udabb\udf78\000\uda52\udce3\ud861\udce9\uda07\udd06\000",
        19, 19450, 1986417087, 9061255411407546622L, 79626L, true, true, (char) 19204, (char) 33315,
        Double.longBitsToDouble(0x3feb863c97ae3889L), Double.longBitsToDouble(0x3fe194490f3a98afL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud891\udc77\ud96d\udf96\udbc3\ude5e\udb07\udd15\udad1\udfd0\ud8d8\udd6c\uda8a\udc9a\u00e2\udadf\udf4e\uda97\ude1c\000\ud8ac\udced\ud88d\udf50\udaec\udc37\ud93d\udcdc\u80a0\uda20\udd0f\udaa8\udcbb\udbfe\udeaa\ud998\udd74\\ueec2\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 8, 9, "\ud891\udc77\ud96d\udf96\udbc3\ude5e\udb07\udd15\udad1\udfd0\ud8d8\udd6c\uda8a\udc9a\u00e2\udadf\udf4e\uda97\ude1c\000\ud8ac\udced\ud88d\udf50\udaec\udc37\ud93d\udcdc\u80a0\uda20\udd0f\udaa8\udcbb\udbfe\udeaa\ud998\udd74", "\u169f\000\u43d1\u2785\u8206\u37f6\000\000\u28cd\ud5c8\u284c\ubed7\u65d2\u40b8\u7836\u1265\u8348\u2682\uaa3e\u4c35\u2ad3\u1397\u9038\ua3ad\ub56f\u2e4c\u1c0f\ub9f1\uab94\uc920\u3d05\u9b16\u4095\u9685\u0a81\u9fa2\u8e36\u216a\u250e\ua768\u33bc\uaff6\u0157\u8a94\u2c47", "\ud996\ude64\uda4e\udc9c\ud9a1\udfeb\ud917\udc51\ud8a4\udd74\ua924\ud9c0\ude04\udbe2\udc3b\udad6\udd82\uda66\ude07\uda92\udd6f\ud909\udda1\ud92a\udc5a\u05d2\udb6b\udf8e\ud944\udd73\ud87e\udf8e",
        30, 99263, -1511079450, 6466810684740527173L, 93117L, false, false, (char) 61122, (char) 42147,
        Double.longBitsToDouble(0x3fbc00062e1495e8L), Double.longBitsToDouble(0x3fe340aa6b473ee0L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 8, 16, "\ud80e\udf18\uda99\udd76\ud8c6\udc98\ud92d\ude75\ud82b\uddef\ud976\udc97\ud915\udf75\000\udb9e\uddcf\u0b94\000\udba6\udcf9\udbdb\udf4c", "\ub132\ub804\u2f64\u9a0f\ub079\u0b72\u1fb1\u44aa\000", "",
        37, 25097, 699868844, 1605218984224049806L, -100000L, false, true, (char) 52805, (char) 39602,
        Double.longBitsToDouble(0x3fe6a51c30c0d468L), Double.longBitsToDouble(0x3fe1d95a6e8fe48aL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 18, 8, "\ud8d1\udd5b\uda51\udec7\u948f\udad1\udde8\udad1\udfd0\ud976\udc9b\ud915\udf75\ud85e\udcdf\u8642\uda8c\udd5c\ud875\udcee\uda76\udc8e\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\u38cd\udb2b\udfd1\uda1c\udf49\ud876\udc3a\ud94d\udc17\udb8f\udf1c\ud8f5\udf8d\ud9e7\udd8c\udb3f\ude9f\ud9c1\udd5d\ud93a\udd51\ud80b\udd80\udbfe\udd2e\uda58\udfcb\uda1a\udda3\uda44\udeeb\u647a\ud9d3\udea6\ud8e2\udf97\uda49\uddf9\ud988\udf59\udb77\udcdc\udb7b\udc54\ud830\udd53\ud95f\udd7c\ud938\ude06\uda3c\udc43\udb04\udc9e\ud8e4\uddc9\ud8f8\ude1d\udbfd\udd45\ud99f\udf12\ud9b6\ude45\udb1b\ude3c\ud83a\ude73\ud985\ude7f\udaaa\udeb3\ud937\uddd8", "\u9998\u7a84", "\ud8d5\udcfa\uda41\udf2d",
        26, 20618, 1887508535, -1999606941609940735L, -19997L, false, false, (char) 26071, (char) 29660,
        Double.longBitsToDouble(0x3fd2df343478c07eL), Double.longBitsToDouble(0x3fbfde7eab13c738L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 18, 8, "\ud8d1\udd5b\uda51\udec7\u948f\udad1\udde8\udad1\udfd0\ud976\udc9b\ud915\udf75\ud85e\udcdf\u8642\uda8c\udd5ce\uda76\udc8e\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\u38cd\udb2b\udfd1\uda1c\udf49", "\u105c\u3cfb\ucd71\u00fe\uc89a\u0cb9\u88d9#\uc60d\u28cd\ucd7c\u60e4\u877d\u00b5\u0ae4\u4388\u7ceb\u3fec\uc51c\u8943\ud727\u5582\u1bb3", "\udbfd\udd45\ud99f\udf12\ud9b6\ude45\udb1b\ude3c",
        37, 91314, -1621737370, 6354087206656948859L, 82775L, true, false, (char) 26009, (char) 5183,
        Double.longBitsToDouble(0x3fdeaa46f96426f4L), Double.longBitsToDouble(0x3fabfc8eb1570810L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 18, 8, "\000\uda51\udec7\u948f\udad1\udde8\udad1\udfd0\ud976\udc9b\ud915\udf75\u00ab\ud9b5\udc3a\uda8c\udd5c\ud875\udcee\uda76\udc8e\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\u38cd\udb2b\udfd1\uda1c\udf49", "\u105c\u3cfb\ucd71\u00fe\uc89a\u0cb9\u88d9\u8a85\u8d21\u28cd\ucd7c\u60e4\u877d\u00b5\u0ae4\u4388\u5886\u3fec\uc51c\u8943\ud727\u5582\u1bb3", "\udbfd\udd45\ud99f\udf12\ud9b6\ude45\udb8b\udc85",
        37, 91314, -1621737370, 6354087206656948859L, 82775L, true, false, (char) 26009, (char) 5183,
        Double.longBitsToDouble(0x3fdeaa46f96426f4L), Double.longBitsToDouble(0x3fabfc8eb1570810L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 18, 8, "\000\u3f27\000\000\000\000\000\ud85e\udcdf\u1d42\uda8c\udd5c\ud875\udcee\uda76\udc8e\udbdb\udf75\udaab\udc17\ud933\ude21\000\000\000\000", "\u105c\u3cfb\ucd71\u00fe\uc89a\u0cb9\u88d9\u8a85\u8d21\u28cd\000\u60b7\u877d\u00b5", "\udb77\udcdc\udb7b\udc54\ud830\udd53",
        9, 45914, 1831, -1338464406110366582L, 65848L, true, true, (char) 10917, (char) 12377,
        Double.longBitsToDouble(0x3fe86e29024a39acL), Double.longBitsToDouble(0x3fb991da8004fab0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 7, 8, "\ud8d1\udd5b\ud8a5\udf31\000\000\udad1\udfd0\ud976\udc9b\ud915\udf75\ud85e\udcdf\u8642\uda8c\udd5c\ud875\udcee\uda76\udc8e\uc581\udaab\udc17\ud93d\udcc6\udb50\udc37\udb5b\udf53\000\000", "", "\ud9e7\udd8c\udb3f\ude9f\ud9c1\udd5d\ud93a\udd51\udbad\udf71",
        -5, 47216, 1298333716, -2394862903045718227L, -62165L, false, false, (char) 0, (char) 20268,
        Double.longBitsToDouble(0x3fec540190000052L), Double.longBitsToDouble(0x3fc5e00000000000L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 18, 3, "", "\u59a9\ub364\ub6dc", "\ud85e\udc34\u8642",
        50, 2677, 1226202176, 2392754460325393033L, 88248L, true, false, (char) 57467, (char) 32256,
        Double.longBitsToDouble(0x3fa26eb6309dd000L), Double.longBitsToDouble(0x3fe02e2726097fc3L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 18, 8, "\000\000\ud853\udf69\udad1\udde8\udad1\udfd0\ud976\udc9b\ud915\udf75\ud85e\udcdf\u8642\uda8c\udd5c\ud875\udcee\uda76\udc8e\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\u38cd\udb2b\udfd1\uda1c\udf49", "\u7684\u3cfb\ucd71\u00fe\uc89a\u0cb9\u88d9\u8a85\u8d21\u28cd\ucd7c\u60e4\u877d\u00b5\u0ae4\u4388\u7ceb\u3fec\uc51c\u8894\u3592\uc905\000", "\udbfd\udd45\ud99f\udf12\ud9b6\ude45\udb1b\ude3c",
        37, 91314, -1621737370, 6354087206656948859L, 82775L, true, false, (char) 26009, (char) 5183,
        Double.longBitsToDouble(0x3fdeaa46f96426f4L), Double.longBitsToDouble(0x3fabfc8eb1570810L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 10, 10, 18, "\ud8d1\udd5b\uda51\udec7\ud80d\udc8f\udad1\udde8\ud80f\udfd2\ud976\udc9b\ud915\udf75\ud85e\udcdf\u85ce\uda8c\udd5c\ud875\udcee\uda76\udc8e\u0eb4\udaaa\udfd9\ud93d\udcc6\udb58\udd37\u38cd\ud9ee\udcd4\uda1c\udf49", "\u105c\u3cfb\ucd71\ua313\uc890\u0cb9\u88d9\u8a85\u8d21\u28cd\ucd7c\ud1e3\u87bd\u00b5\u0ae4\u4388\u7ceb\u3fec\uc51c\ucf2f\u0615\u3d90\u63a5", "\udbfd\udd45\ud99f\udf12\ud9b6\ude45\udb1b\ude3c",
        37, 91314, -1621737370, 6354087206656948859L, 82775L, true, false, (char) 26009, (char) 5183,
        Double.longBitsToDouble(0x3fe2552379ef90bfL), Double.longBitsToDouble(0x3fabfca031570810L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 3, 7, "\udb93\udee1\uda7d\ude71\ud8d8\udf08", "\ub796\u7895\u2af3\ubcd1\u17b4\ubd82\u107b", "\uda73\udc8a\ud88b\udc4b\udab0\udc41\uda2a\uddad",
        40, 69100, 938735125, -6485624521876626802L, -74947L, true, true, (char) 44400, (char) 2628,
        Double.longBitsToDouble(0x3fe22ef61df25a5fL), Double.longBitsToDouble(0x3fd9d49fd8f408f4L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 8, 3, "", "\u36b0\000\000\ua9c7\u337e\u543f", "\000\uda37\udd9b\ud8c4\udee0\uda47\udc2c\ud951\udf89",
        -5, -1000, -710073344, 7399584405913600L, -100000L, false, false, (char) 28460, (char) 48004,
        Double.longBitsToDouble(0x3fb08692852234f8L), Double.longBitsToDouble(0x3fcc4afe04acf990L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud8d1\udd5b'\000\\u1aea\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 8, 6, "\ud8d1\udd5b'\000", "\000", "\uda3e\udc46\uda70\udf0d\udb36\udf69\ud959\uddd9\ud9a5\udd05\udaab\udc17\ud93d\udcc6",
        20, 78763, 135425875, 4530559193706399868L, -26506L, true, true, (char) 6890, (char) 52684,
        Double.longBitsToDouble(0x3fac411ff2a4c000L), Double.longBitsToDouble(0x3e48000000000000L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\000\udbbb\ude83\udbcd\udf8a\udb07\udd15\udaae\udfd0\ud966\udce9\ud915\udf75\\u59e4\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 8, 6, "\000\udbbb\ude83\udbcd\udf8a\udb07\udd15\udaae\udfd0\ud966\udce9\ud915\udf75", "\u4130\021\ua137\u0081\u2152\u1b6b\u2071\u2c3b\u20e4\000\u7f68\u2502\uc608\u3cfb\ucd71\u00fe\u7d0d\ua0b9\u190b\u8a85\u8d21\u28cd\ud77c\u42b6\u2adc\u7112\u0cde\u6c4a\u587d\u7c53", "\ud84c\udffd\ud94e\udc9c\udb8f\udf93\ud81e\udde1\ud8d6\udd4c",
        9, 21510, -1173395719, -2591623820544203268L, -91110L, false, false, (char) 23012, (char) 61142,
        Double.longBitsToDouble(0x3fcf8f64e67dd2acL), Double.longBitsToDouble(0x3f48176000000000L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\u8604\\u6952\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 8, 6, "\u8604", "\ub292\u2adc\u77e4\u7895\u8803\uc266\u4130\u54b6\ua137\u383e\ud159\u1b6b\u2071\u2c3b\u20e4\ub219\u7fe4\u2502\uc608\u3cfb\ucd71\u00fe\u7d0d\ua0b9\u190b\u8a85\u8d21\u28cd\ud77c\u6561\u98ce\u7112\u0cde\u6c4a\000\000\000\u6637\u9d04\u5e85\u385a\u7e1c\u9f75\u2ec6\u6bde\u4c14\u613d\u9357", "\uda8c\ude62\u59e4\000\ud877\udfdc\uda03\udde4\ud948\udfd7\ud979\udd0c\udaa9\udcda\ud9db\uddc4\ud8e7\udc69\uda94\udd33\ud898\ude1a\udbd6\udce2\udac1\udc47\ud916\uddd5\ud9c0\udda4\ud826\udc1c\udb83\uddc4\udad0\udd61\ud9f0\udfdc\ud86e\ude81\ud91b\udf6e\ud8a0\udf3f\udb45\udd9a\ud9b4\udf29\ud8b2\udd50\ud845\ude75\udbe0\udde8\ud818\udf2c\udb95\ude09\ud8ef\udf49\ud88a\udf91\ud830\udf2e\ud90c\udee3\uda16\udd35\udba9\ude67\ud9ea\ude59\ud999\udcfd\udb48\uded5\ud8cc\udc91\udbdc\udc7a\ud8bd\udf8f\ud912\uddbd\udbe3\ude7b\ud8c6\udd71\uda34\udd1f\ud8b1\udeae\udb12\udd08\udb8c\ude32\ud80d\ude91\udb01\ude7f\uda57\udc70\ud858\udea5",
        4, 47452, -1347901624, -2090137527382196035L, -81198L, true, true, (char) 26962, (char) 52192,
        Double.longBitsToDouble(0x3fc2dda73661e38cL), Double.longBitsToDouble(0x3fd92c2111e18212L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 13, 16, "\000\000\000\u2624\udad1\udfd0\ud976\udc9b\ud915\udf75\uda4b\udd2a\u8642", "\u47f6", "\ud80f\udf35",
        24, -805, 1243775683, -188101311017867050L, -56485L, true, false, (char) 23671, (char) 33442,
        Double.longBitsToDouble(0x3feb5bde3023df75L), Double.longBitsToDouble(0x3fe89d5f9d14c85cL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 18, 6, "\ud8d1\udd5b\uda51\udec7\u948f\udad1\udde8\udad1\udfd0\ud976\udc9b\ud915\udf75\ud85e\udc3f\u8642\uda8c\udd5ce\uda76\udc8e\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\u38cd\udb2b\udfd1\uda1c\udf49\ud876\udc3a\ud94d\udc17\udb8f\udf1c\ud8f5\udf8d\ud9e7\udd8c\udb3f\ude9f\ud9c1\udd5d\ud93a\udd79\ud80b\udd80#\uda31\udcb8\uda1a\udda3\uda44\udeeb\u647a\ud9d3\udea6\ud8e2\udf97\uda41\uddf9\ud988\udf59\udb77\udcdc", "\u8943\ud727\u5582\u1bb3", "\udbfd\udd45\ud99f\udf12\ud9b6\ude45\udb1b\ude3c",
        16, 1642, -1621737370, 6354087206656948859L, 82775L, true, false, (char) 3372, (char) 42545,
        Double.longBitsToDouble(0x3fe0f954032b593eL), Double.longBitsToDouble(0x3fb726679e3c1e90L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 18, 8, "\000\000\000\000\000\000\000\ud85e\udcdf\u00fe\000\000\uda5f\udc4e\udbdb\udf75\udaab\udc17\ud933\ude21\000\000\000\000", "", "\000\000\000\ud93a\udd4b\ud80b\udd80",
        16, 47216, 1298333716, 0L, -96116L, true, false, (char) 4028, (char) 56350,
        Double.longBitsToDouble(0x3fc5fcde764945f4L), Double.longBitsToDouble(0x3fe93a5801b70000L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 18, 8, "\000\000\000\000\000\000\000\ud85e\udc34\u00fe\000\000\ud91d\udc4d\000\000\000\000\000\000\000", "", "\000\000\000\ud93a\udd4b\udbad\udf71",
        46, 47216, 1298333716, 0L, -96116L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fc5e000000001f4L), Double.longBitsToDouble(0x3fe93a5801b70000L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud8d1\udd5b\uda51\udec7\udbc3\ude5e\\u7d98\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 18, 8, "\ud8d1\udd5b\uda51\udec7\udbc3\ude5e", "\ub796", "\u8642\uda70\udf0d\udb0d\udcb9\udbb9\udd2b\udbdb\udf75\udaab\udc17\ud93d\udcc6\u02a5\udbab\ude55\udb37\udfdf\uda12\udf07\ud876\udc3a",
        19, 37802, -991644919, 9206296641132187145L, -2214L, true, true, (char) 32152, (char) 19206,
        Double.longBitsToDouble(0x3fd14c85c9c29ac6L), Double.longBitsToDouble(0x3fe22ef61df25a5fL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 8, 7, "\ud8d1\udd5b\uda51\udec7\u948f\udad1\udde8\udad1\udfd0\ud976\udc9b\ud8e5\ude3c\ud85e\udcdf\ud85d\ude3f\uda8c\udd5c\ud991\udfde\ud84f\udd27\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\u38cd\uda2c\udc52\ud924\ude3f\ud876\udc3a\uda00\udd1e\udb8f\udf1c\ud8f5\udf8d\ud9e7\udd8c\ud9bf\udee2\ud9c1\udd5d\ud93a\udd51\ud80b\udd80\ud980\udd2f\ud909\udf0b\udaf3\udd96\udacd\ude12\uda03\udfa6\u8fca\udae0\ude37\uda49\ude06\udbf8\udda5\udb77\udcdc\udb7b\udc54\ud830\udd53\ud95f\udd7c\ud938\ude06\ud94c\udccb\ud8d0\udea5\ud94e\ude97\ud9fd\udce2\ud852\udfae\ud99f\udf04\ud9b6\ude45\udb1d\udfe8\ud8d1\ude27\ud9a3\ude3f\udac4\udd75\udbc6\udc8f\ud867\udd06\uda95\udde7\u5d06\ud934\udee2\ud8d8\udc6d\udbda\udcf3\uda8b\udea8\uda41\udf2d\udb6a\udf0f\ud843\udc4a\ud90b\uded8\ud98b\udf37\udae9\udd4c\udb3e\udfdb\udada\udef9\u86b7\ud88a\udc64\ud9bc\udd22\ud9cc\udf9c\udb8b\udfb2\ud891\udf01\ud8d0\udef2\udb49\udfb9", "\u5741\u09ba\u8133\u4062\u58a2\u1906\u4c27\u3b71\u2e4a\u3c80\u03bc\u2a18\ube23\uba40\u4e61", "\ud810\ude92\udac4\udd58\ud8e2\udc29",
        49, 3618, 766267571, 221027104006463387L, 99439L, true, true, (char) 34629, (char) 50926,
        Double.longBitsToDouble(0x3fdf5b62d0a44812L), Double.longBitsToDouble(0x3fd22b75a2e5b0b6L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=com.google.javascript.jscomp.CodeGenerator:@?\0121=void |this=com.google.javascript.jscomp.CodeGenerator:@?\012",
        Z.run(T, 2, 12, 12, 8, "\uda52\ude3c\ud9fd\uded8\uda9d\udc1b\ud932\udceb\udb32\udec8", "\u2af3\ubb87", "\ud973\udf2c",
        6, 14777, -1941598694, -2154831073893800030L, -42991L, true, false, (char) 36938, (char) 40353,
        Double.longBitsToDouble(0x3fe04bfda338823fL), Double.longBitsToDouble(0x3fe0356d1983ddc5L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 8, "\000\000\000\000\000\000\000\000\000\uda76\ude7b\ud875\udcee\uda76\udc8e\udbdb\udf75\udaab\udc17\ud933\ude21\000\000\000\000", "", "",
        -5, 7520, -1381770696, 8918959074342961003L, -100000L, false, true, (char) 0, (char) 27648,
        Double.longBitsToDouble(0x3feca3ea58d4a0ebL), Double.longBitsToDouble(0x3fb94ab1fc540190L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 8, 7, "\ud8d1\udd5b\uda51\udec7\u948f\udad1\udde8\udad1\udfd0\ud8a6\udf33\000\u00ab\ud843\udc41\u56e1e\ud84f\udd27\udbdb\udf75\udaab\udc17\ud93d\udcc6\udb50\udc37\u38cd\uda2c\udc52\ud917\udc3f\ud876\udc3a\uda00\udd1e\udb8f\udf1c\ud8f5\udf8d\ud9e7\udd8c\ud9bf\udee28\ud93a\udd51\ud80b\udd80\ud980\udd2f\udaed\udc1c\000\000\000\u8fca\udae0\ude37\udb9a\udfae\udbf8\udd7e\udb6e\udcdc\udb7b\udc54\ud830\udd53\ud95f\udd7c\ud938\ude06'\ud91d\udc4d\ud94e\ude97\ud9fd\udce2\uda8c\udfab\u00b7\000\000\ud8d1\ude27\ud9a3\ude3f\udac4\udd75\udbc6\udc8f\ud867\udd06\uda95\udde7\u5d06\ud934\udee2\ud8d8\udc6d\udbda\udcf3\000\uda41\ude9a\udb6a\udf0f\ud843\udc4a\ud90b\uded8\ud98b\udf37\udae9\udd4c\udb3e\udfdb\udada\udef9\u86b7\ud8e8\udc73\ud9bc\udd22\ud9cc\udf9cU\ud891\udf01\ud8d0\udef2\udb49\udfb9", "\u5741\u09ba\u8133\u4062\u58a2\u1906\u4c27\u3b71\000\u94ba\u03bc\u2a18\ube23\uba40\u4e61", "\ud810\ude92\udac4\udd58\ud8e2\udc29",
        49, 3618, 766267571, 221027104006463387L, 99439L, true, true, (char) 34629, (char) 89,
        Double.longBitsToDouble(0x3e04890240000000L), Double.longBitsToDouble(0x3fd22b75a2e5b0b6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.CodeGenerator|add|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|add|com.google.javascript.rhino.Node,com.google.javascript.jscomp.CodeGenerator$Context|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|add|java.lang.String|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|unrollBinaryOperator|com.google.javascript.rhino.Node,int,java.lang.String,com.google.javascript.jscomp.CodeGenerator$Context,com.google.javascript.jscomp.CodeGenerator$Context,int,int|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addAllSiblings|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addArrayList|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addCaseBody|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addExpr|com.google.javascript.rhino.Node,int,com.google.javascript.jscomp.CodeGenerator$Context|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addIdentifier|java.lang.String|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addJsString|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addList|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addList|com.google.javascript.rhino.Node,boolean|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addList|com.google.javascript.rhino.Node,boolean,com.google.javascript.jscomp.CodeGenerator$Context|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|addNonEmptyStatement|com.google.javascript.rhino.Node,com.google.javascript.jscomp.CodeGenerator$Context,boolean|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|appendHexJavaScriptRepresentation|int,java.lang.Appendable|static",
    "M|com.google.javascript.jscomp.CodeGenerator|appendHexJavaScriptRepresentation|java.lang.StringBuilder,char|static",
    "M|com.google.javascript.jscomp.CodeGenerator|add|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|add|com.google.javascript.rhino.Node,com.google.javascript.jscomp.CodeGenerator$Context|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|add|java.lang.String|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
    "M|com.google.javascript.jscomp.CodeGenerator|unrollBinaryOperator|com.google.javascript.rhino.Node,int,java.lang.String,com.google.javascript.jscomp.CodeGenerator$Context,com.google.javascript.jscomp.CodeGenerator$Context,int,int|new:com.google.javascript.jscomp.CodeGenerator:com.google.javascript.jscomp.CodeConsumer",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
