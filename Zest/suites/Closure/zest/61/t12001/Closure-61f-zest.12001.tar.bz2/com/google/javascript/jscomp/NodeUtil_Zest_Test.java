package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class NodeUtil_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 8, "\udabe\udf8a\ud9db\udda8\ud89c\udc81\udb1b\udf06\uda01\uddcd", "\u11f3\ua316\u735d\u7db4\u91df", "\u7847\ud98d\udd20\ud959\udfe1\ud840\udc54\ud9da\uddad\uda6a\udc8f\uda45\udcd9\udb1f\udfd2\ud87f\udc46",
        33, 92054, -1745728762, -2195987829296909422L, -22962L, true, false, (char) 39662, (char) 34966,
        Double.longBitsToDouble(0x3fe0ee06a8b5bce5L), Double.longBitsToDouble(0x3fe86cb98b287867L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 8, "\udabe\udf8a\ud9db\udda8\ud89c\udc81\udb1b\udf06\uda01\uddcd", "\u11f3\ua316\u735d\u7db4\u91df", "\u7847\ud877\uddb5\ud97d\udc85\ud840\ude0c\ud9da\uddad\uda6a\udc8f\uda54\udcd9\udb1f\udfd2\ud87f\udc46",
        33, 92054, -1745728762, -2195987829296909422L, -22962L, true, false, (char) 39662, (char) 58311,
        Double.longBitsToDouble(0x3fe0ee04a0b5bce5L), Double.longBitsToDouble(0x3fe86cb98b287867L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 8, "\udabe\udf8a\ud9db\udda8\ud89c\udc81\ud80b\ude2b\uda01\udc27", "\u11f3\u1baf\u6883", "\udb7a\udef1\ud843\udcde\uda89\udc1b\udaad\ude7f",
        35, 24204, -1403986276, 7664135129837767048L, 94488L, false, false, (char) 7508, (char) 20212,
        Double.longBitsToDouble(0x3fc692fe4e4b8618L), Double.longBitsToDouble(0x3f69fd6b12bc3900L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 9, 5, "\uda25\udd96\ud9db\udda8\ud89c\udc81\ud9a7\udceb\ud842\ude33", "\ucf0c\ua316\u735d\u7db4\u91df\uc0a4\uc5db", "\ud959\udfe1\ud8b8\udfe7\udb5c\udc8e",
        0, 84392, 132106017, -2826103380557441591L, 50278L, false, false, (char) 5401, (char) 55325,
        Double.longBitsToDouble(0x3fe895e1c8f9051aL), Double.longBitsToDouble(0x3fbf159c893b3b78L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 10, 9, "\udb2a\udce5\ud85d\udef2\ud8f8\ude1b\udb1b\ude87\uda01\uddcd", "\u11f3\u5ea5\u2364\u7db4\u5e06", "\ud9be\udd5a\ud98d\udcf1\ud980\udfe1\ud840\udc54\ud9da\uddad\uda6a\udc8f\uda45\udcd9\udb1f\udfd2\ud9ac\uddbd\ue4bf\ud931\ude0e\ud88f\udce4",
        50, 37538, -844366147, 7812226134811249732L, 22408L, true, false, (char) 26010, (char) 4671,
        Double.longBitsToDouble(0x3fc8933d5f439688L), Double.longBitsToDouble(0x3fb1de2119583830L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 8, "\udaf9\udf85\ud9db\udda8\ud89c\udc81\udb1b\udf06\uda3e\udfcc\ud97e\ude88\ud860\udf84\ud802\udd91\ud8a5\udcf1\ud884\udf5f\ud9bc\udf3a\ud873\udee5\udb7a\udef0\ud843\udcde\u7847\ud98d\udd20\ud959\udfe1\ud840\udc54\ud9da\uddad\uda6a\udc8f", "\u1fb1\u4018\u8286\uafb2\u4c95\u3f0a\u281d\u283b", "\u5566\uda88\ude28\udb3d\udc30\ud892\udcf7\udaa5\udfda\uda1f\udccb\ud86a\udd6a\ud8de\udf77\ud8eb\udefe",
        7, 69019, 147925032, 2807878656141324521L, -46044L, false, false, (char) 3987, (char) 27217,
        Double.longBitsToDouble(0x3feacd9297c495c2L), Double.longBitsToDouble(0x3fef7ac7a6b7fba6L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 6, 8, "\udac5\udeef\ud9db\udda8\ud8cd\udff5\ud87e\udc25\uee4a", "\u11f3\ua316\u735d\u7db4\u91df", "\u7847\ud98d\udd20\ud959\udfe1\ud840\udc54\ud9da\uddad\uda6a\udc8f\uda45\udcd9\udb1f\udfd2\ud87f\udc46",
        23, 24110, 1736442697, -4461842055874923630L, -22962L, true, true, (char) 39760, (char) 34966,
        Double.longBitsToDouble(0x3fe0ee06a8b5bce5L), Double.longBitsToDouble(0x3fe86cb98b2824beL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 6, 8, "\udabe\udf8a\ud9db\udda8\ud89c\udc81\udb1b\udf06\uda01\uddcd", "\u11f3\u34de\u735d\u7db4\u3735", "\u7847\ud82e\udeb2\ud95a\udc66\ud840\udc54\ud9da\uddad\uda6a\udc8f\u7266\ud82a\uded8\ud87f\udce6",
        33, 92054, -1745728762, -2195987829296909422L, -22962L, true, false, (char) 39662, (char) 34966,
        Double.longBitsToDouble(0x3fe0ee06a8b5bce5L), Double.longBitsToDouble(0x3fe86cb98fb1d6e4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 6, 8, "\ud873\udfc5\ud9db\udda8\ud89c\udc81\udb1b\udf06\uda01\uddcd", "\u11f3\ua316\u735d\u7db4\u91df", "\u7923\ud98d\udd20\ud98b\udc7d\ud840\udc54\ud9da\uddad\uda6a\udcc3\uda45\udcd9\udb87\udf70\ud87f\udc46",
        33, 32158, -1745728762, -2195987829296909422L, -22962L, true, false, (char) 39662, (char) 34966,
        Double.longBitsToDouble(0x3fe0ee06a8b5bc58L), Double.longBitsToDouble(0x3fe86cb98b287867L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 5, "\udabe\udf8a\ud9db\udda8\ud89c\udc81\udb1b\udf06\uda01\uddcd", "\u11f3\ua316\u735d\u7db4\u91df", "\u7847\ud98d\udd20\ud959\udfe1\ud840\udc54\ud9da\uddad\uda6a\udc8f\uda45\udcd9\udb1f\udfd2\ud87f\udc46",
        33, 92054, -1753682868, -2195987829296909422L, 31732L, true, false, (char) 39662, (char) 34198,
        Double.longBitsToDouble(0x3fe3e32648b5bce5L), Double.longBitsToDouble(0x3fe86cb98d287867L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 6, 3, "\udabe\udf8a\ud9db\udda8\ud89c\udc81\udb1b\udf06\uda01\uddcd\ud924\ude45\ud9f3\udc2a", "\u2585\u7db4", "\ud8a9\uded2\ud97b\udc65\udb67\udc24\udb50\ude6e\ud840\udc54\ud9da\uddad\uda6a\udc8f\udaf2\udfd9\udb1b\udfd0\ud87f\udc46\ue4bf\ud907\ude19\ud88f\udce4\uda23\udffb\uda8f\udef2\ud9e9\udc72",
        33, 41954, -1502657522, -4551695399110427107L, -65965L, false, true, (char) 24463, (char) 35592,
        Double.longBitsToDouble(0x3fd528a617564b80L), Double.longBitsToDouble(0x3fc11dc54e3b30a4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 8, "\u6e90\ud9db\ude1e\ud89c\udc81\udb1b\udf06\uda01\uddcd", "\u9183\u4431\u5ba9\u2aa5\u3cd0", "\ud8f7\udce4\ud9ab\udc45\ud959\udfe1\ud824\udea6\ud983\udfc6\uda6a\udccf\uda45\udcd9\udb1f\udfd2",
        48, 38578, 65945054, -1825564208867648479L, 4561L, false, true, (char) 52498, (char) 715,
        Double.longBitsToDouble(0x3fd2751b3c3b81aaL), Double.longBitsToDouble(0x3fc6b79cac365cc4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 8, "\udabe\udf8a\ud9db\udda8\ud89c\udc81\ud8c1\udc18\ud822\udc5b", "\u21de", "\ud9bc\udf3a\ud873\udee5\udb7a\udef0\ud843\udcde\u7847\ud98d\udd20\ud959\udfe1\ud83a\udd71\ud9da\uddad\uda6a\udc8f\uda45\udcd9\udb1f\udfd2\ud9db\udc54\ue4bf\ud907\ude19\ud88f\udce4\ud8bb\udee8\uda8f\udf52\ud9e9\udc72\udaad\ude8d\ud8c5\ude00\ud9dd\udd1c\udb53\udccb\ud851\udf81\udb4e\ude87\ud9d2\ude25",
        59, 94582, 233295686, -3693024135036013929L, -83730L, true, false, (char) 15237, (char) 6281,
        Double.longBitsToDouble(0x3fbaf3f9f2c22fa0L), Double.longBitsToDouble(0x3fb8a61fed11a160L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.NodeUtil|functionCallHasSideEffects|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|functionCallHasSideEffects|com.google.javascript.rhino.Node,com.google.javascript.jscomp.AbstractCompiler|static",
    "M|com.google.javascript.jscomp.NodeUtil|arrayToString|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|callHasLocalResult|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|canBeSideEffected|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|canBeSideEffected|com.google.javascript.rhino.Node,java.util.Set|static",
    "M|com.google.javascript.jscomp.NodeUtil|checkForStateChangeHelper|com.google.javascript.rhino.Node,boolean,com.google.javascript.jscomp.AbstractCompiler|static",
    "M|com.google.javascript.jscomp.NodeUtil|constructorCallHasSideEffects|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|constructorCallHasSideEffects|com.google.javascript.rhino.Node,com.google.javascript.jscomp.AbstractCompiler|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsCall|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsFunction|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsType|com.google.javascript.rhino.Node,int|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsType|com.google.javascript.rhino.Node,int,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.NodeUtil|copyNameAnnotations|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|evaluatesToLocalValue|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|evaluatesToLocalValue|com.google.javascript.rhino.Node,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.NodeUtil|functionCallHasSideEffects|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|functionCallHasSideEffects|com.google.javascript.rhino.Node,com.google.javascript.jscomp.AbstractCompiler|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
