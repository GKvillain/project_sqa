package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class FoldConstants_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 1, 2, 9, "\udaa3\udf7d\uda61\udd4e\ud858\udc29\ud855\udd97\uda23\udc8a", "\u8b5e\u0b84\u6fcb\ua516\u8337\u99b5\ub452\u629b", "\udab4\udc0d\udb69\uddc7\ud922\udc25\ud912\ude3f\ud968\uddf0",
        37, 83518, 1647822826, 3589372122351140446L, -66129L, true, false, (char) 16376, (char) 61881,
        Double.longBitsToDouble(0x3fefa0d4d58db9dbL), Double.longBitsToDouble(0x3fe1fce810ca4e37L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 1, 2, 9, "\udaa3\udf7d\ud989\ude8d\ud857\udfff\ud855\udd97\uda23\udc8a", "\u8b5e\u0b84\u6fcb\ua516\u502b\u6786\ub452\u629b", "\udab4\udc0d\udb69\uddc7\ud922\udc25\ud912\ude3f\ud968\uddf0",
        37, 83518, 1647822826, 3589372122351140446L, -87289L, true, false, (char) 16376, (char) 61881,
        Double.longBitsToDouble(0x3fefa0d4d552b9dbL), Double.longBitsToDouble(0x3fe1fce810ca4e37L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 8, 9, "\udaa3\udfcd\uda61\udd4e\ud854\ude08\ud91b\ude98\uda9e\udd87\ud893\udf00\uda54\udcae", "\ud5c4\ubec9\uc53b\u99b5\ub452", "\ud908\ude41\udab4\udc0d\udb69\uddc7\ud94a\ude73\uda69\udd5d\ud90f\ude96\udbf5\udfc6\udacb\udd69",
        32, 40691, -1888616866, -3594109839384544335L, -13794L, true, true, (char) 42637, (char) 55144,
        Double.longBitsToDouble(0x3fe1fce810ca4e37L), Double.longBitsToDouble(0x3fcedc188ad91e04L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 0, "\u6d59\000\ud845\udf82\u00bf\000", "\u8b5e\000x\000\000\u98e5\ub452\u626a", "\ud97b\udd04\udb69\uddc7\ud922\udc25\ud9d2\udc7e\ud981\udce0",
        37, 28110, 234, 3589372122351140446L, -66129L, true, false, (char) 16376, (char) 52754,
        Double.longBitsToDouble(0x3fefa0d4d58db9dbL), Double.longBitsToDouble(0x3f43a00000000000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 9, "\udaa3\udf7d\uda61\udd4e\ud858\udc29\ud855\udd97\uda23\udc8a", "\u8b5e\u1242\u6fcb\ua516\u8337\u99b5\ub452\u629b", "\udab4\udc0d\udb69\uddc7\ud922\udc25\ud912\ude3f\ud968\uddf0\udbf5\udfc6\udacb\udd88\udb07\uddb3\ud9e1\udddd\udab9\udfbb\ud9e9\udd34\u6b8f\ubdd0\udb09\udc50\ud92d\udd38\udb1d\udfd1\uda1b\udfb7\u56db",
        15, 82844, 1843639910, 3790448177755105893L, 97604L, true, true, (char) 44627, (char) 44711,
        Double.longBitsToDouble(0x3fc2b87e84778208L), Double.longBitsToDouble(0x3fecd710edcef207L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 2, 9, "\udaa3\udf7d\uda61\udd4e\ud858\udc29\ud855\udd97\uda23\udc8a", "\u8b5e\u0b84\u6fcb\ua516\u8337\u99b5\ub452\u629b", "\udab4\udc0d\udb69\uddc7\ud922\udc25\ud912\ude3f\ud968\uddf0",
        37, 83518, 1647822826, 3589372122351140446L, -66129L, true, false, (char) 16376, (char) 61881,
        Double.longBitsToDouble(0x3fefa0d4d58db9dbL), Double.longBitsToDouble(0x3fe1fce810ca4e37L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 9, "\udaa3\udf7d\uda61\udd4e", "\u3348\u71b3\u887c\ubb4c\u0b84\u6fcb\ua516\u8337\u9cea\u9d5a\u8154\u87e7\u96db\u90ca\u72e0\ub8d6\u0392\ua651\u3357\u96c6\u7c52\u7d76\u98f2\u3d07", "\udb09\udc50\ud92d\udd38\udb1d\udfd1\uda1b\udfb7\u56db\udbb7\udf23",
        57, 31453, -1279799594, 1506176929738078918L, 64173L, false, false, (char) 27604, (char) 26480,
        Double.longBitsToDouble(0x3fd3a6ecad207b48L), Double.longBitsToDouble(0x3fec73397fc46935L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 13, 6, "\udbee\ude70\ud978\udeee", "\u9dae\u71b3\u887c\u8b5e\u0b84\u8e9b\u7daf\u3561\u99b5\ub452\u629b\u87e7\u5f27\u81e6\u43aa\ub8d6\u5391\ua651\u895f\u74f2\u7c52\ua5c7\u98f2\u1d07\u989b\u06fe\u6c24\u5b2e\u41d2\u8839\uc6f2\u5ea6\u51c1\u5e14", "\udaec\udee8\ud986\udf1a\udb66\udccb",
        45, 79050, 480847409, 6869920569736130918L, 73283L, false, false, (char) 3298, (char) 44185,
        Double.longBitsToDouble(0x3fe4373e7b539cf9L), Double.longBitsToDouble(0x3feb2a63f4418772L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 1, 2, 3, "\udac2\udcce\ud936\ude3a", "\u0986\ucaf4\u7769\u9e1f\u0f94\u6fcb\ua516\u8337\u98e8\ubc6c\u952f\u9156\u42df\u48ac\u7e09\ube2c\u8e48\ua651", "\ud925\udf72\ud9e1\udddd\udab9\udfbb",
        58, 91393, -1867105185, 3944277229543505272L, 38637L, false, false, (char) 53658, (char) 23389,
        Double.longBitsToDouble(0x3fea1bbc46a279baL), Double.longBitsToDouble(0x3fe019373d5c277cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 3, 9, "\udaaa\udd90\uda61\udc95", "\u3348\u71b3\u887c\u8b5e\u5711\u6fda\ua516\ud4f0\u7244\u44bc\u629b\u87e7\u5f27\u4c40\u736b\ub8d6\u0392\ua651\u895f\u7566\ua1b9\u6301\u6a42\ub606", "\udb09\udc50\ud92d\udd38\udb1d\udfd1\uda50\udd76\u56db\udbf5\udf81",
        36, 99021, -1777382476, 3505985102626488979L, -68690L, true, false, (char) 59864, (char) 12732,
        Double.longBitsToDouble(0x3fc211d74d0aebf4L), Double.longBitsToDouble(0x3fe6f294c0c6738eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 2, 9, "\udaa3\udf9c\uda61\udd4e\ud858\udc29\ud855\udd97\uda23\udc8a", "\u8b5e\u0b84\u95cd\u70ca\u27c1\u99b5\ub452\u629b", "\udab4\udc0d\udb69\uddc7\ud909\udea6\ud912\ude3f\ud968\uddf0",
        37, 83518, 1647822826, 3589592024676695646L, -66009L, true, false, (char) 16376, (char) 44217,
        Double.longBitsToDouble(0x3fefa0d4d58db9dbL), Double.longBitsToDouble(0x3fe1fce810ca4e37L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 2, 9, "\ud9c1\udccb\udbb1\udcb4\ud858\udc29\ud855\udd97\udb00\udc01\udb60\udeb1\udbb5\udfd3\ud941\udf87\uda4f\uddb8\ud98e\udc6f\ud8af\udca9\ud86b\udda5\ud9f1\udfe2\udb9f\udfde\udbf2\udfc7\uda1d\udfdd\ud9f8\udcf4\udab4\udc06\udb69\uddc7\ud922\udc25\ud912\ude3f\ud968\udef0\udbd0\uddc6", "\u829c\u72d8\u2d07\u9869", "\ud92d\udd38\udbc4\udce0",
        36, 63575, 1612714186, -2940386530725737639L, -67078L, false, true, (char) 54746, (char) 51691,
        Double.longBitsToDouble(0x3fd58fc7368bd224L), Double.longBitsToDouble(0x3fe97871bd4bf84fL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 15, 2, "\udaa3\udf7d\uda61\udd4e\ud858\udc29\ud832\udf91\ud878\udf76\udb60\udeb1\ud837\ude13\ud940\udfd4\udbad\udfe4\ud98e\udc6f\uda8c\ude9b\ud86b\udda5\ud9f1\udfe2\udb9f\udfde\udbf2\udfc7\ud9ac\ude84\ud908\ude41\udab4\udc0d\udb69\uddc7\ud921\udfdc\udac8\ude3a\ud968\uddf0\udb73\udd33\udb32\ude3f", "\u98f2\u3d07\u9905\ua078", "\udb1d\udfd1\uda1b\udfb7\u56db\ud82d\udf4e\ud92e\udf95\ud9e1\udd06\ud979\udddd",
        -5, 29181, 697131322, -7171412926782331234L, -33393L, true, false, (char) 37898, (char) 6249,
        Double.longBitsToDouble(0x3fd057d50900925eL), Double.longBitsToDouble(0x3f7c30133ab44c00L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 6, 9, "\udaa3\udf7d\uda61\udd4e\ud858\udc29\ud855\udd97\udbbf\udcf7\udb60\udede\udbb5\udfd3", "\u6fcb\ua516\u8337\u99b5", "\udbc3\udc80\ud908\ude41\udab4\udc0d\udb69\uddc7\ud922\udc25\ud912\ude3f\ud968\uddf0\udbf5\udfc6\udacb\udd88\udb07\uddb3\ud9e1\udddd\uda0b\udc63\ud961\udde7\ud912\ude43\ud813\udfd0\udb09\udc50",
        42, 56876, -1660805747, 5636099071687725258L, -71084L, false, false, (char) 34313, (char) 29929,
        Double.longBitsToDouble(0x3fec0504da1dc989L), Double.longBitsToDouble(0x3fb4a3ef36119b88L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 2, 9, "\udaa3\udf7d\ud989\ude8d\ud857\udfff\ud855\udd97\uda23\udc8a", "\u8b5e\u0b84\u6fcb\u04b2\u3451\uc634\u46d2\u629b", "\udab4\udc0d\udb69\uddc7\ud922\udc25\ud912\ude3f\ud968\uddf0",
        37, 83518, 1647822826, 3589372122351140446L, 30755L, true, false, (char) 16376, (char) 6838,
        Double.longBitsToDouble(0x3fdddd3a81f4a5aeL), Double.longBitsToDouble(0x3fea48580aa76d80L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 9, "\udaa3\udfcd\udb47\ude02\ud87a\udf89\ud91b\ude98\udba5\udc17\ud98c\udfc7\ud8fd\udec5", "\u8c57\ubec9\u878e\u5f6c\u2d60\ubbd5\u64e8\u5f27\u4c17\u736b\u91cf\u2ee5\ud774\u895f\u37c9", "\udab9\udfbb\ud9e9\udd34\ud913\udfab\udb34\ude26\udbe5\ude7e\ud837\udf7f\udba7\udc58\uda1b\udf87\ud860\udec1\ubc1b\udafd\udd0e\ud952\uded7\udaba\uddb2\ud9a0\udd53\ud9ed\udeba\ud988\udf59\ud9ae\udc7c\ud920\udf5d\uda6b\uded6\u0830\ud8af\udd21\ud803\udddc\udb92\udefc\ud9ef\ude62",
        48, 63669, -792515366, -1882459211925565341L, -43496L, false, true, (char) 20446, (char) 62644,
        Double.longBitsToDouble(0x3fee906b3412fd1fL), Double.longBitsToDouble(0x3feb1e65f5a182b9L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 8, 9, "\udaa3\udfcd\uda61\udd4e\ud854\ude08\ud91b\ude98\uda9e\udd87\ud893\udf00\uda54\udcae\ud87c\ude01", "\ubec9\uc53b\u99b5\u2edb\u6488\u64e8", "\ud901\udec5\ud94a\ude73\uda64\ude5d\ud90f\ude96\udbf5\udfc6\udacb\udd69\ud933\ude09\uda06\ude3f",
        54, 66093, -1145078863, -8062948865896960190L, 77964L, true, false, (char) 62138, (char) 21047,
        Double.longBitsToDouble(0x3fcd2b77118037d0L), Double.longBitsToDouble(0x3fe6c1f6f874bd7aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 2, 0, "\ud926\udf72\000", "\000\u2981\u887c\u8b5e\000x\000\000\u98e5\ub452\u626a\u87e7\ubc25\u785c\u736b\ub8d6\ua933\u871c\ud799\u9fe1\u00ea\ua5f7\u98f2\u3d07", "\udb09\udc50\ud924\udd91\udb1d\udfd1\ud99b\udfb7\000\ud944\udde0",
        37, 25760, -303562180, 3570832216846319371L, 23641L, true, false, (char) 40852, (char) 61932,
        Double.longBitsToDouble(0x3fee233e982e563eL), Double.longBitsToDouble(0x3fdc261a7c11be44L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 2, 0, "\u6d59\000\ud845\udf82\u00bf\000", "\u8b5e\000x\000\000\u98e5\ub452\u626a", "\ud97b\udd04\udb69\uddc7\ud922\udc25\ud9d2\udc7e\ud981\udce0",
        37, 28110, 234, 3589372122351140446L, -66129L, true, false, (char) 38548, (char) 52754,
        Double.longBitsToDouble(0x3fefa0d4d58db9dbL), Double.longBitsToDouble(0x3f43a00000000000L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 2, 9, "\udaa3\udf4e\uda61\udd4e\udab7\ude25\ud855\udd97\uda23\udc8a", "\u8b5e\u0b84\u6fcb\ua516\u8337\u99b5\ub452\u629b", "\udab4\udc0d\udb69\uddc7\ud9e1\udd22\ud912\ude3f\ud968\uddf0",
        37, 83518, 1847055126, -2573241911109772397L, -66129L, false, false, (char) 16376, (char) 61881,
        Double.longBitsToDouble(0x3fefa0d4d58db9dbL), Double.longBitsToDouble(0x3fe1fce817ca4e37L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 11, 5, "\udaa3\udf7d", "\u830e\u3348\u71b3\u6ed6\ubb4c\u0b92\u6fcb\ua516\u8337\u9cea", "\ud9ac\ude84\u8b6f\ud9c4\udd82\udb69\udd3c\ud922\udc25\udbd2\udff2\uda92\ude69",
        -5, 13348, 1647822826, 3558691352708251230L, -65958L, true, false, (char) 16376, (char) 16129,
        Double.longBitsToDouble(0x3f9c6ca9b251e040L), Double.longBitsToDouble(0x3fe1fce810724edfL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "\000\000", "\u3348\u0a97\u8127\u5185\u0b17\u6fcb\ua516\u8337\u9cea\u07d3\u8154\u87e7\u96db\u90ca\000\ub837\u0392\ua651\u3357\u96c6\u7c52\000\u98f2\u3d07", "\udb09\udc50\ud92d\udd38\udafa\udfdd\ud99b\udfb7\udb0f\uded7\000",
        -5, 31453, 52950, 1506176929738078918L, 64173L, false, false, (char) 28129, (char) 26480,
        Double.longBitsToDouble(0x3fad376500000000L), Double.longBitsToDouble(0x3fec700007c46935L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 9, "\udaa3\udf7d\uda61\udd4e", "\u3348\u71b3\u887c\ubb4c\u0b84\u6fcb\ua516\u6c4d\u9cea\u9d5a\u8154\u87e7\u96db\u90ca\u72e0\ub8d6\u0392\ua651\u3357\u6faa\u80e0\ub865\u9962\u3d07", "\udb09\udc50\ud92d\udd38\udb1d\udfd1\uda1b\udfb7\u56db\udbb7\udf23",
        57, 31453, -1279799594, -3321681871009620746L, 64173L, false, false, (char) 27604, (char) 56198,
        Double.longBitsToDouble(0x3fd3a6ecaaf4588eL), Double.longBitsToDouble(0x3fec733fbfc46935L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 9, 3, "\udaa3\udf7d\uda61\udd4e", "\u81fa\u71b3\uc77b\ubb4c\u0b84\u6fcb\ua516\u8337\u9cea\u9cfb\u8154\u87e7\u96db\u90ca\u72e0\ub8d6\u542a\u70bb\u3357\u96c6\u7c52\u7d76\u98f2\u3d07", "\udb09\udc50\ud92d\udd38\udb1d\udfd1\uda1b\udfb7\u56db\ud887\udf2b",
        58, 31453, -1279799594, 1506176929722666950L, 64173L, false, false, (char) 27604, (char) 26480,
        Double.longBitsToDouble(0x3fd3a6eca8507b48L), Double.longBitsToDouble(0x3fec733a37c46935L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 4, 2, 9, "", "\u9ec3", "\000\000",
        -5, -1000, -603948936, -5188146771597882110L, -72864L, true, true, (char) 25861, (char) 15771,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3f1300001abda000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 9, "\udaa3\udf9c\uda61\udd4e\ud858\udc29\udaf4\udf61\udb66\udcaf", "\u8b5e\u9174\u95cd\u70ca\u27c1\u99b5\ub452\u629b", "\udab4\udc0d\udb69\uddc7\ud909\udea6\ud912\ude3f\ud968\uddf0",
        37, 72638, 1991915622, 3589459872827965022L, -66009L, true, false, (char) 16376, (char) 44202,
        Double.longBitsToDouble(0x3fefa0d4d58db9dbL), Double.longBitsToDouble(0x3fe1fce810ca4e37L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 9, "\udae4\udfed\udb39\uddae\ud87a\udf89\ud91b\ude98\udba5\udc17\ud98c\udfc7\ud8fd\udec5\udb92\udc38\udba2\udde4\ud90a\udff4\ud923\udcbe\udb01\udec8\uda43\udde1\ua265\ud930\udd71\udb35\udec9\ud908\ude41\udab4\udc0d\udb69\uddc7\ud9bf\udded\ud870\udd20\ud8f0\ude1d\udbf5\udfc6\ua7b2\udb51\ude89\ud9e1\udd5a\udab9\udfbb\ud9e9\udd34\ud913\udfab\udb34\ude26\udbe5\ude7e\ud837\udf7f\udba7\udc58\uda1b\udf87\ud860\udec1", "\ua4e3\u5fcb", "\ud988\udf59",
        55, 67239, 1833377894, 8984180804228042709L, -45946L, false, true, (char) 28507, (char) 62593,
        Double.longBitsToDouble(0x3fc709f1757858f0L), Double.longBitsToDouble(0x3feba7034dfd76b7L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 1, 1, 9, "\udaa3\udfcd\udb47\ude02\ud87a\udf89\ud91b\ude98\udba5\udc17\ud98c\udfc7\ud8fd\udec5", "\u8da1\ubec9\ua954\u80e9\uc8ff\u339f\u9abd\u2788\u4c17\u736b\u91cf\u2ee5\ud774\u895f\u37c9", "\udab9\udfbb\ud9e9\udd34\ud913\udfab\udb34\ude26\ud979\udd67\ud94c\udfe3\ud9e9\udd6a\uda54\udc87\ud860\udec1\ubc1b\udafd\udd0e\ud952\uded7\udaba\uddb2\ud8ee\udebb\ud9d3\uddda\ud91b\udf65\ud9ae\udc7c\ud93b\udcca\ud8a8\uddfa\u0789\ud8af\udd21\ud803\udddc\udb92\udefc\ud9ef\ude62",
        48, 63798, -792511052, -1882459211925565341L, -43496L, false, true, (char) 20446, (char) 62644,
        Double.longBitsToDouble(0x3fee906b33f1461fL), Double.longBitsToDouble(0x3fed2da3a5a182b9L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 9, "\udaa3\udfcd\udb47\ude02(\ud91a\udfed\udba5\udc17\ud98c\udfc7\ud8fd\udec5", "\u8c57\ubec9\u878e\u5f6c\u2d60\ubbd5\u00e3\u5f27\u4c17\u736b\u91cf\u2ee5\ud774\u895f\u37c9", "",
        1, 9277, -1145078863, -8039364340860407998L, -19912L, false, true, (char) 51954, (char) 17918,
        Double.longBitsToDouble(0x3fe303403f5d49dfL), Double.longBitsToDouble(0x3ecc600000000000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 2, 6, "\uda8e\udc9f\udb1d\uded4\ud845\udff7\u00bf\000\ud9e7\udc72\udbb5\udfd3\ud975\udd40\000x\000\000\ud909\udd5e\udb9f\udfcf\udbf2\udf96\ud9ac\ude84\ud853\udf69\ud97b\udd04\udb69\uddc7", "\u871c\uc586\u40fd\u00ea\ua5f7\u98f2\u2c07", "\udb09\udc50\ud924\udd91\udb1d\udfd1\ud99b\udfb7\000\ud94f\udf0b",
        40, 25760, -303562180, 3570832215831428875L, 23483L, true, false, (char) 40852, (char) 43693,
        Double.longBitsToDouble(0x3fe09244c02e563eL), Double.longBitsToDouble(0x3fdc261a7c11be44L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 0, "\uee3d\000", "\000\000\u887c\u8b5e\000x\000\000\u98e5\ub452\u4b6a\u87e7\ubc25\u785c\u736b\ub8d6\000\000\ud6a8\u9fe1\u00ea\ua5f7\u7071\u3d07", "\udb09\udc50\ud924\udd91\u00f4\ud99b\udf2a\000\ud944\udde0",
        37, 25760, -303562180, 40010108987834368L, 23641L, false, false, (char) 40846, (char) 61932,
        Double.longBitsToDouble(0x3fee233e982e563eL), Double.longBitsToDouble(0x3f3869f000000000L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 2, 11, "\000", "\u830e\u4fb2\uc04b\u0d3d\000\000\u95cd", "\ud9f1\udfe2",
        29, 67633, 1033608931, 0L, -34464L, false, false, (char) 37567, (char) 13610,
        Double.longBitsToDouble(0x3feb2040b20fa235L), Double.longBitsToDouble(0x3fd13952f14ad930L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 9, "\udaa3\udfcd\ud95b\udf04(\ud91a\udfed\ud8c4\udca9\udbea\udf0b\ud8fd\udec5\udb92\udc38\udba2\udde4\ud9de\udd3c\uda26\ude2b\udac2\udc8f\ud85b\udee1\ua265\ud8b7\udd9a\u00e3\ud908\ude41\udab4\udc0d\udb69\uddc7\ud9bf\udded\ud870\udd20\uda29\udf7a\ud86c\udd82\ud90d\udef2\udaff\udf46J\ud93c\udd5e\u28c0\ud913\udfab\udb34\ude26\udbe5\ude7e\ud837\udf7f\udba7\udc58\uda1b\udf87\ud860\udec1", "\ua4e3\u5fcb", "\ud982\udeb2",
        -5, 77726, 1737076879, -5985282229642300945L, -20168L, false, false, (char) 63886, (char) 29035,
        Double.longBitsToDouble(0x3fd1990adcfb8e0eL), Double.longBitsToDouble(0x3febc2ba4c365bdaL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 2, 6, "\uda8e\udc9f\udb1d\uded4\uda82\udf75\011\000\ud9e7\udc72\udbb5\udfd3\ud975\udd40\000x\000\000\ud909\udd5e\udb9f\udfcf\udbf2\udf96\ud9ac\ude84\ud853\udf69\udbd2\uddd1\udb65\ude75", "\u871c\uc586\u40fd\u00ea\ua5f7\u98f2\u2c07", "\udb09\udc50\ud924\udd91\udb1d\udfd1\ud99b\udfb7\000\ud94f\udf0b",
        40, 25760, -303562180, 3570832215831428875L, 23483L, true, false, (char) 40852, (char) 43693,
        Double.longBitsToDouble(0x3fe89244c02e563eL), Double.longBitsToDouble(0x3fdc261a7c11be44L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 9, "\udaa3\udfcd\000\000\ud91a\udfed\ud8c4\udc5b\udbea\udf0b\ud8fd\udec5p\udba2\udde4\ud9de\udd3c\uda26\ude2b\udac2\udc8f\ud85b\udee1\000\000\000\ud908\ude41\u9ba8\000\000\000\000\000\000\000\000\ud93c\udd5e\u28c0\ud913\udfab\udb34\ude26\udbe5\ude7e\ud837\udf7f\udba7\udc58\ud994\ude87\ud8b8\ude4c", "\ua4e3", "\000",
        -5, -1000, -1592590274, 7460688385942749574L, -69106L, false, true, (char) 3878, (char) 63886,
        Double.longBitsToDouble(0x3ec6e06640000000L), Double.longBitsToDouble(0x3fe0000007000049L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 6, "\uda0f\ude80\u37e5\uda82\udf75\011\000\uda1d\ude2f\udbab\uddb0\ud975\udd40\000x\000\000\ud909\udd5e\udb9f\udfcf\udbf2\udf96\ud815\udc38\ud853\udf69\udbd2\uddd1\udb65\ude75", "\u871c\uc586\u40fd\u00ea\ua5f7\u98f2\u2c07", "\udb09\udc50\ud924\udd91\udb1d\udfd1\ud99b\udfb7\000\ud94f\udf0b",
        36, 25760, -303562180, 3570832215831428875L, 23483L, true, false, (char) 40852, (char) 43693,
        Double.longBitsToDouble(0x3fe89244c02e563eL), Double.longBitsToDouble(0x3fdc261a7c11be44L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 2, 6, "\uda8e\udc9f\ud944\udc68\uda82\udf75'\000\ud9e7\udc72\udbb5\udfd3\ud975\udd40\000x\uda34\udf99\000\ud909\udd5e\udb9f\udfcf\udaec\ude7f\ud81c\udd96\ud853\udf69\udbd2\uddd1\udb65\ude75", "\u871c\uc586\u40fd\u57ea\ua5f7\u98f2\u2c07", "\udb09\udc50\ud924\udd91\udb1d\udfd1\ud9d3\udfb7\000\ud94f\udf0b",
        40, 25760, -303562180, 3570832215831428875L, 23483L, true, false, (char) 40852, (char) 30652,
        Double.longBitsToDouble(0x3fe89246c02e563eL), Double.longBitsToDouble(0x3fe83f29c6a5669bL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 2, 6, "\uda8e\udc9f\udb1d\uded4\uda82\udf75\011\"\ud9e7\udc72\udbb5\udfd3\ud99c\udee7\000x\000\000\ud909\udd5e\udb9f\udfcf\udbf2\udf96\ud9ac\ude84\ud853\udf69\udb98\uddf3\udb65\ude75", "\u569e\uc586\u40fd\u00ea\ua5f7\u71ef\u2c07", "\uda23\udc5d\ud924\udd91\udb1d\udfd1\ud99b\udfb7\000\ud94f\udf0b",
        40, 25760, -303562180, 3570832215831428875L, 23483L, true, false, (char) 40852, (char) 43693,
        Double.longBitsToDouble(0x3fe89244c02e563eL), Double.longBitsToDouble(0x3fdc261a7c11be44L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 9, "\udaa3\udfcd\000\000\ud91a\udfed\ud8c4\udc5b\udbea\udf0b\ud8fd\udec5p\udba2\udde4\ud9de\udd3c\uda26\ude2b\udac2\udc8f\ud85b\udee1\000\000\000\ud908\ude41\u9ba8\000\ud8bf\udc3e\u009c\000\ud933\udd88\012\000\000\ud93c\udd5e\u28c0\ud8ed\udd57\udb34\ude14\udbe5\ude7e\ud837\udf7f\udba7\udc58\ud994\ude87\ud8b8\ude4c", "\ua4e3", "\000",
        -5, -1000, -1592590274, 7460688385942749574L, -63772L, false, true, (char) 183, (char) 36889,
        Double.longBitsToDouble(0x3fbf63bb38000760L), Double.longBitsToDouble(0x3f9e1736a5b28700L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 6, "\uda24\udd86\ud963\ude1a\uda82\udfda\011\000\uda1d\ude2f\udbab\uddb0\ud975\udd40\000x\000\000\ud909\udd5e\udb9f\udfcf\udbf2\udf96\uda0b\uddd3\ud853\udf69\udbd2\udde5\udb65\ude75\ud922\udc25\ud9d2\udc7e\udb64\uddf1\uda7a\ude1e\ud97a\ude9c\u00ea\ud9e1\udddd\udbf0\ude6b\udb8b\udc50\ud88c\udd34\udb25\udf2f\udb09\udc50\ud924\udd91\uda70\ude76\ud986\udf61\000\ud94f\udf0b\udad9\udcfe\udac2\udd84\u792b\uda61\udfe6\uda40\udcf0\ud84d\ude65\udb2b\udc36\ud99a\udcc8\ud850\udec3\uda0f\ude37\ud800\udf9e\ud8cc\ude48\ud878\udfd2\udb59\ude13\udaa9\uddd7\ud9c6\ude91\udb3a\udca0\ud860\udf5c", "\ubb27", "\ud87a\udeed\ud862\udc95\uda69\udd5b\uda3c\udd51\ud8dd\udd58\udbe6\udce0\udae2\uddc7\u34de\udae3\udd1d\ueba2\udba4\udc02\u7028\ud9d2\udd8d\ud811\udd40\udba4\udc48\ud839\udd97",
        18, -250, -1826426950, -8051436625254967119L, -48305L, true, true, (char) 30418, (char) 17487,
        Double.longBitsToDouble(0x3feafd1478ad1a90L), Double.longBitsToDouble(0x3fddb2a66dda5ef2L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 6, "\uda89\udcad\ud944\udc68\uda82\udf75'\ud84d\udf25\ud9ea\uddeb\udbb5\udfd3\ud975\udd40\000x\uda34\udf99\000\ud909\udd5e\udb9f\udfcf\udaec\ude7f\ud81c\udd96\ud87a\ude4f\udbd2\uddd1\udb65\ude75", "\uad3b\uc586\u40fd\u5def\ua081\u98f2\uc45e", "\udb09\udc50\ud924\udd91\udb1d\udfd1\ud927\udfc1\000\ud94f\udf0b",
        40, 25760, -294843844, 3570832215831428875L, 23483L, true, false, (char) 40852, (char) 30652,
        Double.longBitsToDouble(0x3fe89246c02e563eL), Double.longBitsToDouble(0x3fe83f29c6a5669bL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 2, 6, "\udb76\udfd5\udaaa\ude7f\uda51\udfa6\ud940\uddc9<\ud9e7\udc72\udbb5\udfd3\ud975\udd40\000x\uda34\udf99\000\ud909\udd5e\udb9f\udfcf\ud950\udcd0\ud9b1\ude8c\ud853\udf69\udbd2\uddd1\udb65\ude75", "\u871c\uc586\u40fd\u57ea\ua5f7\u98f2\u2c07", "\udb09\udc50\ud924\udd91\udb1d\udfd1\ud9d3\udfb7\000\ud94f\udf0b",
        40, 25760, -303562180, 506414143463283563L, 23483L, true, false, (char) 40852, (char) 30652,
        Double.longBitsToDouble(0x3fe89246c02e563eL), Double.longBitsToDouble(0x3fe83f29c6a5669bL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 2, 6, "\uda8e\udc9f\udb1d\uded4\uda82\udf75\011\"\ud9e7\udc72\udbb5\udfd3\ud99c\udee7\ud906\udc02x\000\\\ud909\udd5e\udb9f\udfcf\udbf2\udf96\ud9ac\ude84\ud853\udf69\udb98\uddf3\udb65\ude75", "\u569e\uc586\u40fd\u00ea\ua5f7\u9123\u2c07", "\uda23\udc5d\ud924\udd91\udb1d\udfd1\ud9a0\udeb7\000\ud94f\udf0b",
        40, 25760, -303562180, 3570832215831428875L, 23483L, true, false, (char) 40852, (char) 43693,
        Double.longBitsToDouble(0x3fe89244c02e563eL), Double.longBitsToDouble(0x3fdc261a7c11be44L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 6, "\ud97b\udd5a\udb48\udc03\uda82\udf75\uda8b\udded|\ud9e7\udc72\udbb5\udfd3\ud99c\udee7\000x\000\000\uda19\udee6\udb9c\udccf\udbf2\udf96\ud9ac\ude84\ud853\udf69\udb98\uddf3\udb94\udd2c", "\u56c2\uc586\u40fd\u00ea", "\ud9e5\udc34\uf18c\udaef\uddcf\uda23\udc5d\ud924\udd91\udb1d\udfd1\uda49\ude0dB\u251d\ud950\udd14\uf880\ud80b\uddea",
        18, 34715, 920101076, 5011433648669584779L, -87625L, true, true, (char) 54968, (char) 23149,
        Double.longBitsToDouble(0x3fe2084439b1e68aL), Double.longBitsToDouble(0x3feb1af9b6555bb6L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 14, "\ud91b\udcc6\ud826\ude2c\uda05\udddc\011\"\ud9e7\udc72\udbfe\ude79\ud99c\udee7\ud8de\ude4bx\udab9\udde4\udbb4\udc7a\uda5f\udd12\udb9f\udfcf\udbf2\udf96\ud9ac\udf20\ud853\udf69\ud9ea\udddd\u6521", "\u07e0", "\ud845\uddd0\ud8ba\udce2\udbb4\udffe\ud8ff\udf3e\ud863\uddbf\udb2c\udfaa",
        36, 12830, 2138686643, -7133694070223767552L, -50682L, false, true, (char) 55599, (char) 4836,
        Double.longBitsToDouble(0x3fe8598c77aa3127L), Double.longBitsToDouble(0x3fda5ea77027cf74L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 9, "\udaa3\udfcd\000\000\ud91a\udfed\ud8c4\udc5b\udbea\udf0b\ud8fd\udec5p\udba2\udde4\ud9de\udd3c\uda26\ude2b\ud93d\uddc9\udaab\udc60\udb23\udfb6\ud944\udc60>\ud908\ude41\ud967\udc68\u885d\ud8bf\udc3e\u009c\000\ud933\udd88\012\ud986\udf43\u6fa8\ud93c\udd5e\u28c0\ud8ed\udd57\udb34\ude14\ud8ce\udd97\ud94a\udf6e\udba7\udc58\udbb4\udd4d\ud98b\udd6a", "\ua4e3", "\ud858\ude2e",
        -5, -1000, -1592590274, 7460688385942749574L, -63772L, false, true, (char) 183, (char) 36889,
        Double.longBitsToDouble(0x3fbf63bb38000760L), Double.longBitsToDouble(0x3f9e1736a5b28700L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 9, "\000\000\000\ud95c\udc0d\ud9e4\udd0c\000\ud8fd\ude22p\udba2\udde4\ud9de\udd3c\uda26\ude2b\udac2\udc8f\ud85b\udee1\000\000\000\uc2d6\u9ba8\000\000\000\000\000\000\000\000\ud8ae\udd57\u28c0\ud8ed\udd57\udb34\ude14\000\ud837\udf7f\ud9e5\udc57\ud994\ude87\ud8b8\ude4c", "\ua4e3", "\000",
        -5, -1000, -1592590274, 614180323328L, -100000L, false, true, (char) 3878, (char) 16351,
        Double.longBitsToDouble(0x3ec6e06640000000L), Double.longBitsToDouble(0x3fbf63bb38000760L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 9, "\udaa3\udfcdZ\000\ud91a\udfed\ud8c4\udc5b\ud91d\udf25\uda58\uddb6p\uda1f\udf24\ud986\uddb1\uda26\ude2b\udac2\udc8f\ud85b\udee1\udbe9\udd2f\udbb4\udf70\000\ud908\ude41\u9ba8\000\ud8bf\udc3e\u799c\000\ud933\udd88\012\000\000\ud93c\udd5e\u28c0\ud8ed\udd57\udb34\ude14\udbe5\ude7e\ud837\udf7f\ud89b\udd19\ud9b8\udda1\ud8b8\ude4c", "\ua4e3", "\000",
        -5, 41280, -1592590101, 7439577762689450374L, -63772L, false, true, (char) 64950, (char) 37071,
        Double.longBitsToDouble(0x3fbf63bb38000760L), Double.longBitsToDouble(0x3f9e1736a5b28700L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 9, "\udaa3\udfcd\udab5\udcba]\ud91a\udfed\ud8c4\udc5b\udbea\udf0b\ud8fd\udec5>\udba2\udde4\ud9de\udd3c\uda26\ude2b\ud93d\uddc9\udaab\udd06\udb23\udfc3\ud943\udfc9>\ud908\ude41\ud967\udc68\u885d\ud8bf\udc3e\u009c\000\ud933\udd88\012\ud986\udf43\u6fa8\ud93c\udd5e\u0bc0\ud8ed\udd57\udaaf\udf71\uda50\udc3c\ud96c\udca4\udba7\udc58\udbb4\udd4d\ud898\udf51", "\ua4e3\u00e4\u85a1\u7fbf\000\000\u3fbc\u9b45\u0186\u7daa\u1bec\u3a1b\ud52f", "\uda8a\udefd\udbbb\udc8a",
        49, 92086, -34554579, -837720107127673279L, -22313L, false, true, (char) 25974, (char) 4658,
        Double.longBitsToDouble(0x3fecc8f55b417f43L), Double.longBitsToDouble(0x3fd99356bb61028cL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 9, "\udaa3\udfcd\udab5\udcba]\udbcd\ude66\uda15\udfc3\udbea\udf0b\ud8fd\udec5>\udba2\udde4\ud9de\udd3c\uda26\ude2b\ud93d\uddc9\udaab\udd06\udb23\udfc3\ud943\udfc9>\ud908\ude41\ud967\udc68\u885d\ud8bf\udc3e\u009c\000\ud933\udd88\012\ud946\ude3c\u6fa8\ud93c\udd5e\u0bc0\ud8ed\udd57\udaaf\udf71\uda50\udc3c\ud96c\udca4\udba7\udc58\udbb4\udd4d\ud898\udf51", "\ua4e3\u00e4\u7607\u07c0\u8464\000\u3fbc\u9b45\u0186\u7daa\u1bec\u3a1b\ud52f", "\uda8a\udefd\udbbb\udc8a",
        49, 92086, -34554579, -837720107127673279L, -22313L, false, true, (char) 25974, (char) 4658,
        Double.longBitsToDouble(0x3fecc8f55b417f43L), Double.longBitsToDouble(0x3fd99356bb0b028cL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 12, 9, "\udac5\udca2\ud879\ude13\ud858\udc29\ud855\udd97\ud853\ude42\ud836\udea5\ud878\udc11", "\u922d\u33c4", "\udb9f\udfde\udbf2\udfc7\uda3a\udf1a\uda09\udd84\uf0eb\ud8d9\udceb\ud922\udc25\ud912\ude3f\ud947\ude21\udbf5\udfc6\udaa2\udd88\udb07\uddb3\ud9e1\udddd\uda7f\udfbb\udbe5\udee5\u6b4f\udbbb\udd2b\udb02\udfab\udb6e\ude58\udb32\udc13\ub603\ud9b2\uddf1\udae8\ude1b",
        54, 53242, 143892920, -6596383623620981959L, -23430L, true, false, (char) 27645, (char) 21472,
        Double.longBitsToDouble(0x3fcb4d4f584264ccL), Double.longBitsToDouble(0x3faa922b581905a0L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 2, 6, "\udbfe\udc34\ud944\udce4\ud889\udd98\015\000\ud9e7\udc72\udbb5\udfd3\ud975\udd40\000x\uda34\udf99\000\ud909\udd5e\udb9f\udfcf\udaec\ude7f\ud81c\udd96\ud861\udc2f\u35fe\udb65\ude75", "\u871c\uc586\u40fd\u57ea\u2c66\u98f2\u2c07", "\udb09\udc50\ud924\udd91\udb1d\udfd1\ud9d3\udfb7\000\ud94f\udf0b",
        40, 25760, -303562180, 3570832215831428875L, 23483L, true, false, (char) 40852, (char) 30652,
        Double.longBitsToDouble(0x3fe89246c02e563eL), Double.longBitsToDouble(0x3fe83f29c6a5669bL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 0, "\u5805\udaaa\ude7f\uda51\udfa6\uda9e\udc79<\ud9e7\udc72\ud917\udfa3\ud88a\udd4a\000\udb26\udc73\ud83a\udf6c\000\ud909\udd5e\udb9f\udfcf\ud950\udcd0\ud9b1\ude8c\ud853\udf69\udbd2\uddd1\udb65\ude75", "\u871c\uc586\u40fd\u57ea\ua5f7\u98f2\u2c07", "\udb09\udc50\ud924\udd91\udb1d\udfd1\ud9d3\udfb7\000\ud94f\udf0b\udb02\ude72\ud8c2\udfde",
        21, 40731, -94577813, -1551505864631116379L, -80490L, true, false, (char) 44672, (char) 27968,
        Double.longBitsToDouble(0x3fcff4658168c770L), Double.longBitsToDouble(0x3fe5937dc813ab2fL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 9, "\udbfe\udc34\ud944\udce4\ud889\udd98\015\000\ud9e7\udc72\udbb5\udfd3\ud975\udd40\000x\uda34\udf99\000\ud909\udd5e\udb9f\udfcf\udaec\ude7f\ud81c\udd96\ud861\udc2f\u35fe\udb65\ude75", "\u871c\uc586\u40fd\u57ea\u2c66\u4143\u2c07", "\udb09\udc50\ud924\udd91\udb1d\udfd1\ud9d3\udfb7\000\ud94f\udf0b",
        40, 25760, -303562180, 3570832215831428875L, 23483L, true, false, (char) 57285, (char) 30652,
        Double.longBitsToDouble(0x3fe89246c02e563eL), Double.longBitsToDouble(0x3fe83f29c6a5669bL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 6, "\uda8e\udc9f\udb1d\uded4\uda82\udf75\011\"\ud9e7\udc72\udbb5\udfd3\u6da8\udb2d\udc40\ud943\ude6c\000\\\ud909\udd5e\udb9f\udfcf\udbf2\udf96\ud9ac\ude84\ud853\udf69\udb98\uddf3\udb65\ude75", "\u565d\uc586\u40fd\u00ea\ua5f7\ubed8\u2c07", "\uda23\udc5d\ud924\ude7d\udb1d\udfd1\ud9a0\udeb7\000\ud94f\udf0b",
        40, 25760, -303562180, 3570832215831428875L, 38523L, true, false, (char) 40852, (char) 43693,
        Double.longBitsToDouble(0x3fe89244c02e563eL), Double.longBitsToDouble(0x3fdc261a7c11be44L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 4, 0, "", "\u4600\015", "\udbb5\udfd3",
        48, -1000, 120, 4401705685801238528L, -73042L, true, false, (char) 141, (char) 4922,
        Double.longBitsToDouble(0x3fca88e00a163000L), Double.longBitsToDouble(0x3fe4fdd8f875d5ffL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 4, 14, 5, "\\\ud9f9\ude7b\udb64\udf90", "\u3509\ub39f", "\ucd08",
        43, 97514, -1402850087, -8416218352852003023L, -100000L, false, false, (char) 25857, (char) 28839,
        Double.longBitsToDouble(0x3fe1ddc5a0018917L), Double.longBitsToDouble(0x3fe469523f61b72aL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 9, "\u9dae>\000\ud8bc\udec0\ud8c4\udc5b\udbb7\udcd4\ud8fd\udec5p\udba2\udde4\udbf8\udc0a\udbec\udc16\udb86\ude32\ud977\udc59\u00d6\u5100\000\ud8a1\udf4b\u9ba8\ud853\udf69\udb60\udc83\ud885\udf2c\ud9cb\udd72\ud933\udd56\uda0c\udc0f\000\000\ud93c\udd6a\u28c0\ud8ed\udd57\ud97e\udfd9\udbe5\ude7e\udbb0\udcbb\udba6\udfd0\udad3\udf05\ud8c8\udead", "\u54fd\017\000\ubd82", "\udba9\udca9",
        39, -610, -1399540015, -3026167341789972546L, 99095L, true, true, (char) 36889, (char) 49875,
        Double.longBitsToDouble(0x3fb1a9b8e20295d0L), Double.longBitsToDouble(0x3fe9e4368351faddL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 1, "\u9dae>\000\ud8bc\udec0\ud9b6\udc54\udbb7\udcd4\ud9e5\ude98\ud91d\udd79\udb44\uddd5", "\ub216\u7a70\u00d6\u5100\000\u8cee", "\udaf6\udd18",
        22, 97010, -496713963, -2506840997560844288L, 6764L, true, false, (char) 19304, (char) 36005,
        Double.longBitsToDouble(0x3feefd737195b796L), Double.longBitsToDouble(0x3fef6a9894d541d3L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 6, "\uda24\udd86\ud963\ude1a\uda82\udfda\011\000T\000\ud96f\udc16\000x\000\000\000\000\000\uda0b\uddd3\ud853\udf69\udbd2\udde5\udb65\ude75\ud922\udc25\ud9d2\udc7e\000\000\000\000\ud9e1\udddd\udbf0\ude6b\udb8b\udc50\ud88c\udd34\udb25\udf2f\udb09\udc50\ud924\udd91\uda70\ude76\ud986\udf61\000\ud94f\udf0b\udad9\udcfe\udac2\udd84\u792b\uda61\udfe6\uda40\udcf0\u00aa\000\000\uda23\udf30\uda0f\ude37\ud800\udf9e\ud8cc\ude48\ud878\udfd2\010\udaa9\udd7a\ud9c6\ude91\udb3a\udca0\ud860\udf5c", "\u832d", "\ud87a\udeed\ud862\udc95\uda69\udd5b\uda3c\udd51\ud8dd\udd58\udbe6\udce0\udae2\uddc7\u34de\udae3\udd1d\ueba2\udba4\udc02\u7028\ud9d2\udd8d\ud811\udd40\udba4\udc48\ud839\udd97",
        18, -250, -1826426950, -8051436625254967119L, -100000L, true, true, (char) 30418, (char) 17487,
        Double.longBitsToDouble(0x3feafd1478ad1a90L), Double.longBitsToDouble(0x3fddb2a66dda5ef2L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.FoldConstants|tryFoldStringJoin|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FoldConstants:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FoldConstants|areSafeFlagsToFold|java.lang.String|static",
    "M|com.google.javascript.jscomp.FoldConstants|areValidRegexpFlags|java.lang.String|static",
    "M|com.google.javascript.jscomp.FoldConstants|consumesDanglingElse|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FoldConstants:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FoldConstants|containsUnicodeEscape|java.lang.String|static",
    "M|com.google.javascript.jscomp.FoldConstants|error|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.jscomp.DiagnosticType,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FoldConstants:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FoldConstants|getBlockExpression|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FoldConstants:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FoldConstants|getBlockReturnExpression|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FoldConstants:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FoldConstants|getBlockVar|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FoldConstants:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FoldConstants|hasBreakOrContinue|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FoldConstants:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FoldConstants|isExpressBlock|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FoldConstants:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FoldConstants|isLowerPrecedenceInExpression|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,int|new:com.google.javascript.jscomp.FoldConstants:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FoldConstants|isPropertyAssignmentInExpression|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FoldConstants:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FoldConstants|isReturnExpressBlock|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FoldConstants:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FoldConstants|isVarBlock|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FoldConstants:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.FoldConstants|makeForwardSlashBracketSafe|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.FoldConstants|tryFoldStringJoin|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.FoldConstants:com.google.javascript.jscomp.AbstractCompiler",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
