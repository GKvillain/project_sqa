package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypedScopeCreator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 2, "\ud88f\ude0c\u2a42", "\u3835\u6dfe\u9b51\u8a3b\u347c\u33df\u88c3\ua68f", "\ud9f5\uddaf\uda10\uded9\u29d9\udbe2\udf7b\uda77\uddc5\ud919\udc04\ud98b\udd8c\udad5\udd8b\ud8d6\udcf5\ud934\ude3c\udbc4\udc8b\ud9d7\udfb3\uda23\udcc1\udb6e\udffd\uda1f\udd2d\ud837\udc27\u9719",
        23, 1479, 1632947618, -6012705966016000333L, -3259L, false, false, (char) 30922, (char) 75,
        Double.longBitsToDouble(0x3fc68697e0cdab24L), Double.longBitsToDouble(0x3fdcf9c5bd38adbaL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 2, "\ud88f\ude0c\ud8c6\udc5f", "\u3835\u6dfe\u9b51\u8a3b\u40ae\u31bb\u88c3\ua68f", "\ud9d0\udd5c\ud944\udfbd\uda46\udcad\udbe2\udf7b\uda77\uddc5\ud919\udc04\ud98b\udd8c\udad5\uddc8\ud8d6\udcf5\ud934\ude3c\udbc4\udc8b\ud9d7\udfb3\uda23\udcc1\udb6e\udffd\uda1f\udd2d\ud837\udc27\u9719",
        23, 1479, 1632947618, -6012705966016000333L, -19356L, false, false, (char) 25971, (char) 39676,
        Double.longBitsToDouble(0x3fce938b78788660L), Double.longBitsToDouble(0x3fd7b4e25a660ac8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 2, "\ud88f\ude0c\uac52", "\uc53d\u6e2c\ua351\u8a3b\u347c\u50e9\u798d\u4291\ub9d8\u1a21\u46c0\u0b17\u711a\u3605\ucc37\u3aca\u6d6c\uc4b2\uc4a3\ua774\u09eb\u2cdb\u583b\u5289\u4e30\u92d2\uafd8", "\ud96e\udf5e\ud84f\udedd\udae2\ude52\uda91\udfac\uda9b\udf5d\udbe8\udfa5\ud965\uddee",
        19, 31100, -1671745432, 6259178635885733532L, 57835L, true, true, (char) 56818, (char) 18227,
        Double.longBitsToDouble(0x3fe89fb40756a575L), Double.longBitsToDouble(0x3fe14cb340490984L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 2, 2, "\ud877\udcbf\u2a42", "\u3835\u6dfe\u9b51\u8a3b\u347c\u33df\u88c3\ua68f", "\ud9f5\uddaf\uda10\uded9\uda06\udeb7\udbe2\udf7b\uda77\uddc5\ud918\udf3e\ud98b\udd8c\udad5\udd8b\ud8d6\udcf5\ud934\ude3c\udbc4\udc8b\ud9d7\udfb3\uda23\udcc1\udaa9\ude94\uda1f\udccc\uda73\udf29\u9776",
        23, 1479, 1632947618, -6012705966016000333L, 59289L, false, false, (char) 30922, (char) 75,
        Double.longBitsToDouble(0x3fc68697e0cdab24L), Double.longBitsToDouble(0x3fdcf9c5bd38adbaL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 2, 2, "\ud88f\ude0c\u6ae6", "\u3835\u6dfe\ud34c\ua90b\ud2e8\uce57\u88c3\ua68f", "\ud9f5\uddaf\ud89c\udcbe\u2907\udbe2\udf7b\uda77\uddc5\udbef\udeae\udb04\udcdf\udad5\udd8b\ud8bb\udf69\udad1\udd4f\ud8c4\udcb5\ud889\udd66\uda23\udcc1\udb6e\udffd\uda1f\udd2d\ud837\udc27\u9719",
        23, 1479, 400482466, -6849738508046977976L, 79887L, false, true, (char) 30793, (char) 75,
        Double.longBitsToDouble(0x3fc68697e0cdaa08L), Double.longBitsToDouble(0x3fdcf9c5bd38adbaL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 2, 2, "\ud85c\udc2d\u2a42", "\u3835\u6dfe\u9b51\u8a3b\u347c\u33df\u88c3\ua68f", "\ud9f5\uddaf\uda10\uded9\u29d9\udbe2\udf7b\uda77\uddc5\ud919\udc04\ud98b\udd8c\udad5\udd8b\ud8d6\udcf5\ud934\ude3c\udbc4\udc8b\u00ed\uda23\udcc1\udb6e\udffd\uda1f\udd2d\ud837\udc27\u9719",
        50, 1479, 5557504, -738197504L, -68795L, false, false, (char) 30922, (char) 75,
        Double.longBitsToDouble(0x3fc68697e0cdab24L), Double.longBitsToDouble(0x3fdcf9c5bd38adbaL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 7, 1, 2, "\udba4\udfd7\u2a42", "\u04f2\u7ddb\u8af7\u8a3b\u347c\uca63\u88c3\ua68f", "\ud9f5\uddaf\uda10\uded9\u29d9\udbe2\udf7b\uda77\uddc5\ud919\udc04\ud811\udf0f\udb36\udf92\ud937\udcb7\ud9f8\uddd1\udbc4\udca7\ud9d7\udfb3\uda2f\udcc7\udb6e\udfda\uda1f\udd2d\ud837\udc27\ud8a0\udd16",
        7, 1479, 643091874, -6012775656155345229L, -3259L, false, false, (char) 30922, (char) 75,
        Double.longBitsToDouble(0x3fc68697e0cdab24L), Double.longBitsToDouble(0x3fdcf9c5bd38adbaL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 10, "\ud88f\ude0c\ud9a5\udc6e", "\u9a6a\u8b86\ua3b4\u8a3b\u347c\u50e9", "\udbed\udfbe\udb69\udf86\udb85\udf72\udb49\udf1b\udaa6\udc83\udbe2\udf21\uda8d\udcc5\ud919\udc04\ud98b\udd8c\udad5\udd8b\ud8d6\udcf5",
        18, 62811, 1074835693, 222387852695813566L, 65456L, true, true, (char) 50418, (char) 47510,
        Double.longBitsToDouble(0x3fda2920b790c2a8L), Double.longBitsToDouble(0x3fe59d64747cb5beL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 7, 1, 2, "\ud88f\ude0c\uac52", "\ub5c7\u49ad\ua351\u8a3b\u347c\u50e9\u798d\u4291\ub9d8\u4a21\u46c0\u4b17\u07d9\u9f47\ucc37\u3aca\u6d6c\uc4b2\uc4a3\ua774\ub766\u2cdb\u583b\u5289\u2b8e\u6f27\uafd8", "\ud96e\udf5e\ud84f\udedd\udae2\ude52\uda91\udfac\uda9b\udf5d\udbf6\udc4b\ud965\uddee",
        19, 31100, -1671745432, 4100828514472293186L, 57835L, true, true, (char) 56818, (char) 18227,
        Double.longBitsToDouble(0x3fe89fb40756a575L), Double.longBitsToDouble(0x3fe14cb340490984L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 6, "\ud88f\ude0c\udbef\udc73", "\u9a6a\u8b86\u02e3", "\ud982\ude65\ud871\uddf1\ud961\udf9f\uda1f\ude95\udb63\udf0c\udb85\udf72",
        50, 47675, 729493303, 4507172033451772401L, 89085L, false, true, (char) 35632, (char) 63778,
        Double.longBitsToDouble(0x3fcdae5bb24d0040L), Double.longBitsToDouble(0x3fdbe03165fdc496L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 2, "\ud88f\ude0c\ud9a5\udc6e", "\u9a6a\u8b86\u8368\u8a3b\u347c\u50e9", "\udbed\udfbe\udb69\udf86\udb85\udf72\udb43\udc1b\udaa6\udc83\udbe2\udf21\uda8d\udcc5\ud919\udc04\ud98b\udd8c\udad5\udd8b\ud8d6\udcf5\ud997\udc13\udbc4\udc47\ud9fb\udcb3",
        27, 81294, -1766655234, -3335626152165619953L, -44743L, false, true, (char) 62747, (char) 15169,
        Double.longBitsToDouble(0x3fbf2d6fb684e6f8L), Double.longBitsToDouble(0x3fec7176041a90b1L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 10, 10, "\u78bf\ud9a5\udd21\ud9ea\ude59\udb3a\udd4d\ud9d9\ude21\ud82f\udf2a\uda63\udf9c\uda68\udc26\u9933\udb67\udd22\udb41\udf89\uda74\udcdb\udbed\udfbe\udb69\udf86\udb85\udf72\udb49\udf1b\udab9\ude20\uda68\udda6\uda8d\udcc5\ud919\udc04\ud98b\udd8c\udad5\udd8b\ud8d6\udcf5\ud997\udc13\udbc4\udc47\udbfa\uddb5\uda23\udcc1\udb6e\udffd\ud955\udcc9\uda69\udef5\u9719\udbdb\uddc4\ud854\uddac\udafc\udf65\ud84f\udedd\udae2\ude52\udbe9\udf19", "\uad69\u27ad\u3746\ub9bf\u20f4\u916e\u7daf\u7bd6\u0497\u5ecd", "\ud879\udc65\udbd7\udf62\uda8b\udec1\uda2f\udc37\ud8c8\udeb0\ud93d\uddcc\udabe\udf58\udadb\udfb2\udadc\udfe7\ud889\udf6b\udb88\udd4f\ud939\ude60\uda05\udcef",
        24, 87485, 1801213964, -4157162128887610576L, -27794L, false, true, (char) 61649, (char) 65393,
        Double.longBitsToDouble(0x3fed24d009f10066L), Double.longBitsToDouble(0x3fef7b9edbc1b5b5L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 3, "\udb8c\udefd\ud929\udf72", "\u3869", "\udaf4\udc95\ud834\ude48\uda1f\ude1f\udbde\udfeb\udb9a\udc8a\udaed\udcba\udb69\udf86\ud9f5\uddaf\udb88\udce1\ud9ab\udf15\u2e20",
        9, 50665, 1547347997, 5909534826486141886L, -8778L, true, true, (char) 21667, (char) 49363,
        Double.longBitsToDouble(0x3fe7f7125ad22516L), Double.longBitsToDouble(0x3fe87e8c554700aaL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.TypedScopeCreator|createInitialScope|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.TypedScopeCreator:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.TypedScopeCreator|createScope|com.google.javascript.rhino.Node,com.google.javascript.jscomp.Scope|new:com.google.javascript.jscomp.TypedScopeCreator:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.TypedScopeCreator|declareNativeFunctionType|com.google.javascript.jscomp.Scope,com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.TypedScopeCreator:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.TypedScopeCreator|declareNativeType|com.google.javascript.jscomp.Scope,java.lang.String,com.google.javascript.rhino.jstype.JSType|new:com.google.javascript.jscomp.TypedScopeCreator:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.TypedScopeCreator|declareNativeValueType|com.google.javascript.jscomp.Scope,java.lang.String,com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.TypedScopeCreator:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.TypedScopeCreator|getBestJSDocInfo|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.TypedScopeCreator|getBestLValue|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.TypedScopeCreator|getBestLValueName|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.TypedScopeCreator|getNativeType|com.google.javascript.rhino.jstype.JSTypeNative|new:com.google.javascript.jscomp.TypedScopeCreator:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.TypedScopeCreator|getPrototypePropertyOwner|com.google.javascript.rhino.Node|static",
    "C|com.google.javascript.jscomp.TypedScopeCreator|<init>|com.google.javascript.jscomp.AbstractCompiler",
    "C|com.google.javascript.jscomp.TypedScopeCreator|<init>|com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.CodingConvention",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
