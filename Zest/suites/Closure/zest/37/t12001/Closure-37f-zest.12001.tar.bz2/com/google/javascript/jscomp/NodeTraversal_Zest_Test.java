package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class NodeTraversal_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.NodeTraversal:@?\012",
        Z.run(T, 1, 3, 8, 6, "\u431f", "\u78a9\u98e4\u7e32\u3b4a\u1816\u2fda\u8afb\u35f2\ud5c9\u1e1a\u0b6b\u51f3\u3322\u4ada\ua3e7\u3133", "\udb88\udfba\ud8fc\udd21",
        15, 9199, -454826218, -3555374983671315053L, 55666L, false, false, (char) 5656, (char) 44313,
        Double.longBitsToDouble(0x3fe63bb3bb51073aL), Double.longBitsToDouble(0x3fc0902d2e1b7b3cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.NodeTraversal:@?\012",
        Z.run(T, 1, 3, 8, 6, "\u431f", "\u78a9\u98e4\u7e32\u3b4a\u1816\u2fda\u8afb\u35f2\ud5c9\u1e1a\u0b6b\u51f3\u3322\u4ada\ua3e7\u3133", "\udb88\udfba\ud8fc\udd21",
        15, 25522, -454826218, -3555374983671315053L, 55666L, false, false, (char) 5656, (char) 44313,
        Double.longBitsToDouble(0x3fe63bb3bb51073aL), Double.longBitsToDouble(0x3fc0902d2e1b7b3cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.NodeTraversal:@?\012",
        Z.run(T, 1, 3, 8, 6, "\u431f", "\u78a9\u98e4\u0bc9\u3b4a\u1af1\u2559\u8b4a\u7dc9\ud5c9\u1e1a\u0b6b\u51f3\u3322\ub9ac\u5234\u3133", "\udb88\udfba\ud8fc\udd21",
        31, 93410, 608702225, -1113938834739854038L, 97752L, false, true, (char) 16309, (char) 44313,
        Double.longBitsToDouble(0x3fe63bb3bb51073aL), Double.longBitsToDouble(0x3fc0902d2e1b7b3cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:  \u431f\udbb5\udc55\ud976\udf16\ud9b9\udf96\udb6d\udda5\uda62\ude77\ud9a8\udd24\ud862\ude4e\ud9a0\udf94\ud8db\uddad\udaf4\udf13\ud8a6\udff8\u7315\ud855\udf4d\uda0b\udfb4\uda95\ude2d\ud9c2\udf2e\udb66\udc3b\udba0\udf70\ud8e7\udc74\ud95c\udd7f\ud8d2\udf20: NULL |this=com.google.javascript.jscomp.NodeTraversal:@?\0121=null |this=com.google.javascript.jscomp.NodeTraversal:@?\012",
        Z.run(T, 2, 1, 6, 3, "\u431f\udbb5\udc55\ud976\udf16\ud9b9\udf96\udb6d\udda5\uda62\ude77\ud9a8\udd24\ud862\ude4e\ud9a0\udf94\ud8db\uddad\udaf4\udf13\ud8a6\udff8\u7315\ud855\udf4d\uda0b\udfb4\uda95\ude2d\ud9c2\udf2e\udb66\udc3b\udba0\udf70\ud8e7\udc74\ud95c\udd7f\ud8d2\udf20", "\u94f1\u76f4\u52cf\ud244\u39af\u7169\ua739\u28ce\u8ac9\u52c9\u497d\uc3c7\ubf2c", "\ud843\udeeb\ud98c\udf25",
        54, 44024, -1787119971, -7646364464858621257L, -88148L, true, true, (char) 48951, (char) 55480,
        Double.longBitsToDouble(0x3f7248599d9f5880L), Double.longBitsToDouble(0x3fa3f09a014d4920L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 5, 2, "\u431f", "\ubf85\u52fd\u9d5e\u3b4a\u1816\u2fda\u8afb\u35f2\ua305\u776c\uaa26\ub778\u5944\u4ada\u3451\u3133", "\udb9e\udfc5\ud9b7\udd15",
        15, 9199, 1977829654, -3601757153155218029L, 55666L, true, true, (char) 5550, (char) 15376,
        Double.longBitsToDouble(0x3fe3e7c6af77073aL), Double.longBitsToDouble(0x3fcfb20d2e1b7b3cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 6, "\000", "\u78a9", "\ud9a8\udd24\udb24\udf19\udb32\udfba\ud8db\udd5a\udaf4\udf13K\u72db\ud859\udd6e\udbe4\ude95\ud877\uddff\ud9c2\udf2e\udb66\udc3b\udba0\udf70\ud8e7\udc74\ud95c\udd7f\udb88\udfba\ud8fc\udd21\udb7c\udd7a\udbdb\udd37\u1d7d\000\000\ud851\udd95\udbb2\udd5f\ud933\udd89\ud838\ude5c\u9145\u866d\ud8c0\udfdb\ud90f\ude8f\uda16\udf1c\ud876\udfaa",
        8, 46217, -431646749, -4714257885460269769L, 75049L, true, false, (char) 20877, (char) 51198,
        Double.longBitsToDouble(0x3fe1691afe7a7073L), Double.longBitsToDouble(0x3fde7a44974f9374L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.google.javascript.jscomp.NodeTraversal:@?\012",
        Z.run(T, 1, 9, 8, 6, "\u431f", "\u78a9\u98e4\u7e32\u3b4a\u1816\u2fda\u8afb\u35f2\ud5c9\u0888\u0b6c\u51f3\u4380\u4ada\u5b08\u13c5", "\ud917\udf4b\udb4b\udc89\udb7d\ude61\udbdb\udd37\u1d7d\ud90a\udff6\uda39\uddd9\ud851\ude8d\udbb2\udd5f\ud933\udd89\uda28\udef1\ud8d0\udc39\u8734",
        53, 26084, -1806720122, -2179420708512501601L, -77320L, false, false, (char) 27306, (char) 53180,
        Double.longBitsToDouble(0x3fb23c25f9f4b148L), Double.longBitsToDouble(0x3fec94d635575e18L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 8, 6, "\u431f", "\u1bc0", "\ud9a8\udd24\udb24\udff0",
        40, 51074, 281078295, -395423639692602310L, 82621L, true, true, (char) 34375, (char) 36573,
        Double.longBitsToDouble(0x3fe44fa8699c53a8L), Double.longBitsToDouble(0x3fefc42fcc3a5d7bL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:[source unknown]\012 |this=com.google.javascript.jscomp.NodeTraversal:@?\012",
        Z.run(T, 1, 2, 8, 6, "\u431f", "\u78a9\u98e4\u2fa2\u3aae\ud415\u2fda\u8afb\u35f2\ud5c9\u1e1a\u0b6b\u51f3\u3322\u79e2\u8337\u6ca2", "\udb88\udfba\ud8fc\udd21",
        15, 5067, -454826168, -3555374983671315053L, 55666L, false, false, (char) 5656, (char) 44313,
        Double.longBitsToDouble(0x3fe63bb3bb51073aL), Double.longBitsToDouble(0x3fc0902d2e1b7b3cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.NodeTraversal:@?\0121=null |this=com.google.javascript.jscomp.NodeTraversal:@?\012",
        Z.run(T, 2, 3, 8, 6, "\u431f", "\u933f\u98e4\u7e32\u40a2\u17b2\uc44a\u1dca\u399b\ud5f2\ud5a3\u0b59\u51f3\u3322\u4ada\ua3e7\u3133", "\udb88\udfba\ud8fc\udd21\udb7c\udd7a\udbdb\udd37\u1d7d\ud94f\ude17\ud865\udff9\ud851\ude8d\ud9fc\udf24\udbef\ude47",
        -3, 25099, 121301868, -474651125780229645L, -13159L, true, true, (char) 2754, (char) 21785,
        Double.longBitsToDouble(0x3fd05d38df02ae6cL), Double.longBitsToDouble(0x3fec18d8ac857a9fL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 8, 6, "\udb9d\udcb3", "\u78a9\u98e4\u7e32\u3b4a\u27f0\ub693\u8b46\u35f2\ud5c9\u1fe0\u3157\u9538\u3322\u4ada\u91d6\u5569", "\ud86d\ude8e",
        35, 35432, 472589199, -1953463732501166774L, 51288L, false, false, (char) 28462, (char) 5656,
        Double.longBitsToDouble(0x3fe2aa9edec7e942L), Double.longBitsToDouble(0x3fea8839d77a8169L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 9, 6, "\u431f\udbb5\udc55\uda7c\udfa4\ud83c\udd63\ud986\udf1f\uda5f\uddb8\udabd\udf8d", "\u8afb\u7cf1\ud5c9\u1e1a\u0b6b\u51f3\u3322\u4ada\ua3e7\uaaf6\u0b9d\u86f2\uafa5\uab1c\u0302\u94f1\u4340\u36d4\ud244\u39af\u7169\ua739\u28ce\u66f0\ud2fa\ub548\u492e\u8186\u69c9\u9e62\u6eed\u4f33\u467b", "\udb84\udd92\uda61\udc3d",
        58, 43962, -61642952, -7619157807767326010L, -36619L, false, false, (char) 63849, (char) 2875,
        Double.longBitsToDouble(0x3fd7bb7f797e5c7cL), Double.longBitsToDouble(0x3fba720e0e44f080L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.NodeTraversal:@?\012",
        Z.run(T, 1, 11, 8, 6, "\u431f", "\u6beb\u986f\u7e32\u3b4a\u1816\u2fda\u37f7\u14a6\ud5c9\u1e1a\u0b6b\u51f3\u3322\u4ada\ua3e7\u3133", "\uda4f\udd16\ud8fc\udd21",
        15, 9199, -454826218, -3555374983671315053L, 55666L, false, false, (char) 38849, (char) 47186,
        Double.longBitsToDouble(0x3fe63dbcc351073aL), Double.longBitsToDouble(0x3fc0902d2e1b7b3cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.NodeTraversal:@?\0121=null |this=com.google.javascript.jscomp.NodeTraversal:@?\012",
        Z.run(T, 2, 11, 8, 6, "\u431f", "\u78a9\u98e4\u7e32\u3b4a\u1816\u2fda\u8afb\u35f2\ud5c9\u1e1a\u0b6b\u51f3\u3322\u4ada\ua3e7\u3133", "\udb88\udfba\ud8fc\udd21",
        15, 9199, -454826218, -3555374983671315053L, 55666L, false, false, (char) 5656, (char) 44313,
        Double.longBitsToDouble(0x3fe63bb3bb51073aL), Double.longBitsToDouble(0x3fc0902d2e1b7b3cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.NodeTraversal:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 6, "\u431f", "\uc270\u9325\u84ac\u12fe\u3b52\ubd4d\u4b36\ubc5b\u1d86\ua155\u0b89\u66fc\u3322\ub283\ua3e7\u3133\u10b0\u50ae\u5afb\u98b1\u5da3", "\uda60\ude61",
        58, 1472, -1906155502, -3986564401944900245L, -26585L, true, false, (char) 44403, (char) 40394,
        Double.longBitsToDouble(0x3feb9199d49a3b48L), Double.longBitsToDouble(0x3fe124dd47be1986L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.NodeTraversal:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 6, "\udb62\udcc6", "\u78a9\u98e4\u7e32\u3b4a\u1816\u2fda\u8afb\u35f2\ud5c9\u1e1a\u0b6b\u51f3\u3322\u4ada\ua3e7\u3133\ub13e", "\ud8fc\udd21\udb7c\udd7a\udbdb\udd37\u1d7d\uda60\ude61\ud829\udf66\ud851\ude8d\udbb2\udd5f\ud933\udd89\ud838\ude5c\ud8d0\udc39",
        34, 47753, -556801916, 97288664392783249L, 71359L, false, true, (char) 63244, (char) 60536,
        Double.longBitsToDouble(0x3fea52e9545c9bb2L), Double.longBitsToDouble(0x3fe7fb485db609f4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 8, 6, "\u431f\udbb5\udc55", "\uca54\u3b1a\u7718\ub33d\u2fda", "\ud8a6\udff8\u7315\ud93f\udd2f\ud9a7\udc61\udb1b\udeea\ud9c1\udd20\udbae\ude82\ud95c\udc19\ud8af\udf6f\ud95c\udd7f\udb88\udfba\ud921\udcae\ud859\udc61\ud9e7\udd3a",
        49, 25430, -332387173, -3635088758771911662L, -54283L, true, true, (char) 25728, (char) 11694,
        Double.longBitsToDouble(0x3fc0902d2e1b7b3cL), Double.longBitsToDouble(0x3fd29244f0fb02deL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:  \u431f\udbb5\udc55\ud97a\udd37\ud884\udf68\udb6d\udda5\uda62\ude77\ud9a8\udd24\ud862\ude4e\ud9a0\udf94\ud8db\uddad\udaf4\udf13\ud8a6\udff8\u7315\ud855\udf4d\uda0b\udfb4\uda95\ude2d\ud9c2\udf2e\udb66\udc3b\udba0\udf70\ud89e\ude30\ud95c\udd7f\ud8d2\udf20: NULL |this=com.google.javascript.jscomp.NodeTraversal:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NodeTraversal:@?\012",
        Z.run(T, 2, 1, 12, 3, "\u431f\udbb5\udc55\ud97a\udd37\ud884\udf68\udb6d\udda5\uda62\ude77\ud9a8\udd24\ud862\ude4e\ud9a0\udf94\ud8db\uddad\udaf4\udf13\ud8a6\udff8\u7315\ud855\udf4d\uda0b\udfb4\uda95\ude2d\ud9c2\udf2e\udb66\udc3b\udba0\udf70\ud89e\ude30\ud95c\udd7f\ud8d2\udf20", "\u0b24\u7778\u52cf\ud244\u39af\u7169\ua739\u28ce\u8ac9\u52c9\u497d\uc3c7\ubf2c", "\ud843\udeb6\ud98c\udf25",
        54, 44024, -1787119971, -7646363760483984713L, -88148L, true, true, (char) 48951, (char) 55480,
        Double.longBitsToDouble(0x3f7248599d9f5880L), Double.longBitsToDouble(0x3fa3f09a014d4920L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.google.javascript.jscomp.NodeTraversal:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 10, 3, "\u431f\udb37\udc56\ud976\udf16\ud9b9\udf96\udb6d\udda5\uda62\ude77\ud9a8\udd24\ud862\ude4e\ud9a0\udf94\ud8db\uddad\udaf4\udf13\ud8a6\udff8\ud9e8\udeba\udb67\udf75\uda0b\udfb4\ud8eb\udf45\ud98e\udca0\udb66\udc3b\udba0\udf70\ud8e7\udc74\ud9ea\ude82\uda44\udf8d", "\u94f1\u76f4\u52cf\ud244\u39af\u7169\ua739\u28ce\u8ac9\u52c9\ud50a\u6f38\ubf2c", "\ud843\udeeb\ud98c\udf25",
        54, 87648, -1787130343, -7646364464858621257L, -88148L, true, true, (char) 48951, (char) 55480,
        Double.longBitsToDouble(0x3fdcc92166767d62L), Double.longBitsToDouble(0x3fa3f09a014d4920L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:  \ud928\udedb\udbb4\udffc\ud976\udf16\ud9b9\udf96\udb6d\udda5\uda62\ude77\ud9a8\udd24\ud83c\udf4e\ud9a0\udf94\ud8db\uddad\udaf4\udf13\udab0\udcec\udbfa\udfa6\ud855\udf4d\uda0b\udfb4\uda8f\udda9\ud905\udeab\udb65\udf9a\udba0\udf70\ud8e7\udc74\ud8e3\udfe4\ud82a\udf8b: NULL |this=com.google.javascript.jscomp.NodeTraversal:@?\0121=java.lang.String:[source unknown]\012 |this=com.google.javascript.jscomp.NodeTraversal:@?\012",
        Z.run(T, 2, 1, 2, 3, "\ud928\udedb\udbb4\udffc\ud976\udf16\ud9b9\udf96\udb6d\udda5\uda62\ude77\ud9a8\udd24\ud83c\udf4e\ud9a0\udf94\ud8db\uddad\udaf4\udf13\udab0\udcec\udbfa\udfa6\ud855\udf4d\uda0b\udfb4\uda8f\udda9\ud905\udeab\udb65\udf9a\udba0\udf70\ud8e7\udc74\ud8e3\udfe4\ud82a\udf8b", "\u94f1\u76f4\u4758\ud264\u39af\u7169\ua739\u28ce\u8ac9\u52c9\uabdd\uc3c7\ubf2c", "\ud843\udeeb\ud98c\udf25",
        54, 13288, 1769206986, -7646515532873992849L, -88082L, true, true, (char) 48951, (char) 55480,
        Double.longBitsToDouble(0x3f7248599d9f5880L), Double.longBitsToDouble(0x3fa3f09a014d4920L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:  \u431f\udbb5\udc55\ud901\udf17\ud9b9\udf96\udb6d\uddd7\uda62\ude77\ud9a8\udd24\ud862\ude4e\ud9a0\udf94\ud8db\uddad\udb83\udc5b\ud964\ude28\ud8f5\udc50\ud855\udf4d\uda0b\udfb4\uda95\ude2d\ud9d9\ude99\udbad\udcdf\uda79\udf1f\uda7b\udc6c\ud95c\udd7f\ud8d2\udf20: NULL |this=com.google.javascript.jscomp.NodeTraversal:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 14, 3, "\u431f\udbb5\udc55\ud901\udf17\ud9b9\udf96\udb6d\uddd7\uda62\ude77\ud9a8\udd24\ud862\ude4e\ud9a0\udf94\ud8db\uddad\udb83\udc5b\ud964\ude28\ud8f5\udc50\ud855\udf4d\uda0b\udfb4\uda95\ude2d\ud9d9\ude99\udbad\udcdf\uda79\udf1f\uda7b\udc6c\ud95c\udd7f\ud8d2\udf20", "\u487f\u76f4\u52cf\u26b7\u0600\ubbed\u7294\u6675\u6f20\ucafc\u497d\uc3c7\ubf2c", "\ud843\udeeb\ud829\udedd",
        54, 44024, -1787119971, -5699965000457898636L, -88148L, true, false, (char) 9033, (char) 35138,
        Double.longBitsToDouble(0x3fc13c9a437dd950L), Double.longBitsToDouble(0x3fcd16cb72317d14L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.NodeTraversal:@?\0121=null |this=com.google.javascript.jscomp.NodeTraversal:@?\012",
        Z.run(T, 2, 6, 6, 3, "\u431f\udbb5\udc55\ud976\udf16\ud9b9\udf96\udb6d\udda5\ud997\udde3\ud9a8\udd24\ud862\ude4e\ud8cb\udda8\udaed\udf12", "\u1e38\u1828\u7b62\uadd4\u4af7\ua3e7\u3133\ub13e\uaa10\u7dbc", "\udbe1\udf32\u1d7d\uda60\ude61\ud829\udf66\ud851\ude8d\udbb2\udd5f\udb43\udd06\ud853\udfd8\uda17\udea5\udb26\udd70\uda85\udff2\udb32\udd7e\uda81\uddb1",
        41, 71012, 2103143886, 1822560664765137085L, -15677L, false, false, (char) 12441, (char) 103,
        Double.longBitsToDouble(0x3fe261e7c5433b18L), Double.longBitsToDouble(0x3feab63a456111f1L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:  \ud91a\udde2\uda35\udc85\udba5\udf27\ud9b9\udf68\udb61\udca5\uda62\ude77\ud9a8\udd24\ud862\ude4e\ud9a0\udf94\ud8db\uddad\udaf4\udf13\ud8a6\udff8\u7315\ud855\udf4d\uda0b\udfb4\uda95\ude2d\ud9c2\udf2e\udb66\udc3b\udba0\udf70\ud8e7\udc74\ud95c\udd7f\ud8d2\udf19: NULL |this=com.google.javascript.jscomp.NodeTraversal:@?\0121=java.lang.String:  \ud91a\udde2\uda35\udc85\udba5\udf27\ud9b9\udf68\udb61\udca5\uda62\ude77\ud9a8\udd24\ud862\ude4e\ud9a0\udf94\ud8db\uddad\udaf4\udf13\ud8a6\udff8\u7315\ud855\udf4d\uda0b\udfb4\uda95\ude2d\ud9c2\udf2e\udb66\udc3b\udba0\udf70\ud8e7\udc74\ud95c\udd7f\ud8d2\udf19: NULL |this=com.google.javascript.jscomp.NodeTraversal:@?\012",
        Z.run(T, 2, 1, 1, 3, "\ud91a\udde2\uda35\udc85\udba5\udf27\ud9b9\udf68\udb61\udca5\uda62\ude77\ud9a8\udd24\ud862\ude4e\ud9a0\udf94\ud8db\uddad\udaf4\udf13\ud8a6\udff8\u7315\ud855\udf4d\uda0b\udfb4\uda95\ude2d\ud9c2\udf2e\udb66\udc3b\udba0\udf70\ud8e7\udc74\ud95c\udd7f\ud8d2\udf19", "\u94f1\u76f4\ud2cf\ud1e9\u39af\u7169\ua739\u28ce\u8ac9\u52c9\u497d\uc3c7\ubf2c", "\ud843\udeeb\ud98c\udf25",
        54, 44024, -1787119971, -7646364464858621257L, -88148L, true, true, (char) 48951, (char) 55480,
        Double.longBitsToDouble(0x3f7248599d9f5880L), Double.longBitsToDouble(0x3fa3f09a014d4920L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=com.google.javascript.jscomp.NodeTraversal:@?\0121=java.lang.Integer:0 |this=com.google.javascript.jscomp.NodeTraversal:@?\012",
        Z.run(T, 2, 9, 9, 6, "\u431f", "\uc270\u9325\u84ac\u12fe\u3b52\ubd4d\u4b36\ubc5b\u1d86\ua155\u0b89\u66fc\u3322\ub283\ua3e7\u3133\u10b0\u50ae\u5afb\u98b1\u5da3", "\ud819\udcbd",
        58, 1472, -1906155502, -3986564401944900245L, -26585L, true, false, (char) 44403, (char) 40394,
        Double.longBitsToDouble(0x3feb9199d49a3b48L), Double.longBitsToDouble(0x3fe124dd47be1986L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null |this=com.google.javascript.jscomp.NodeTraversal:@?\0121=null |this=com.google.javascript.jscomp.NodeTraversal:@?\012",
        Z.run(T, 2, 11, 11, 3, "\ud840\ude78\udbb1\uddfa\udb7c\udf1a\udbff\udf99\udb6d\uddd7\uda62\ude77\ud9a8\udd24\ud930\udd0a\udb77\uddff\ud88e\udf03\udbee\udee2\uda16\ude62\ud99b\uddef", "\u6c2c\u3f98\u3059\u62af\u9d50\uaa10\u729b\u6d3b\uaa38\u4dcd", "\udb5a\udffe\ud838\udc97\ud882\udc9a\ud98f\udee5\ud810\udc63\uda27\udd72\udb60\udf5e\uda85\udff2\udb32\udd7e\uda81\uddb1\uda38\udcea\uda8a\uddd4\ud9da\udd33\ud829\udec0\ud937\udc4f\uda9b\udcd1",
        12, 144, 1603650001, 2219857857208253139L, 4673L, false, true, (char) 40138, (char) 60992,
        Double.longBitsToDouble(0x3fe3309d447e42a2L), Double.longBitsToDouble(0x3fef7380ea1062f0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:[source unknown]\012 |this=com.google.javascript.jscomp.NodeTraversal:@?\0121=java.lang.String:[source unknown]\012 |this=com.google.javascript.jscomp.NodeTraversal:@?\012",
        Z.run(T, 2, 2, 2, 8, "\udb0c\udecc", "\u30a2\ub406\ucc1f\u1fc5\ua750\u1c0a\u8afb\u35f2\ud5c9\u311a\u0b6b\u51f3\u3322\u37a3\ua3e7\u3133\ub13e", "\ud8fc\udd21\udb7c\udd7a\ud973\udd44\u13c8\uda60\ude61\ud829\udf66\ud851\ude8d\udbb2\udd5f\ud933\udd89\ud838\ude5c\ud850\ude5a\udaec\uddf1\ud8c0\udfdb\uda40\udea0\ud87c\udd8e\udbfa\ude4f\udb34\udcd5\udbb9\udc17\udabd\udd41\ud873\udeda\udb0f\udc21\udafc\udd60\ud8ec\udd4a\ud88c\udf24\ud8a7\udef3\ud9e3\udd7c\uda48\udc92\ud884\udf12\udbfa\udd2d\ufe62\ud86e\udd1b\ud846\uddd6\ud9ee\udd41\ue2de\ud861\udfa5\udb1f\udf9c\uda14\ude01\ud9b7\ude0b\ud88e\udf73\ud966\udfff\udb3c\ude10\ud8b2\udf0f\ua2b4\udb38\udd2b\ud9dd\ude1c\ud85b\udd51\uda45\udcb2\ud99d\udd3b",
        49, 86997, 122416442, -3693135337717900639L, -44099L, false, false, (char) 39225, (char) 25455,
        Double.longBitsToDouble(0x3feb01f6f93872caL), Double.longBitsToDouble(0x3fd4a72e6b010928L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.NodeTraversal|traverseFunction|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.NodeTraversal:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.NodeTraversal$Callback",
    "M|com.google.javascript.jscomp.NodeTraversal|formatNodeContext|java.lang.String,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.NodeTraversal:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.NodeTraversal$Callback",
    "M|com.google.javascript.jscomp.NodeTraversal|formatNodePosition|com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.NodeTraversal:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.NodeTraversal$Callback",
    "M|com.google.javascript.jscomp.NodeTraversal|getCompiler||new:com.google.javascript.jscomp.NodeTraversal:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.NodeTraversal$Callback",
    "M|com.google.javascript.jscomp.NodeTraversal|getControlFlowGraph||new:com.google.javascript.jscomp.NodeTraversal:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.NodeTraversal$Callback",
    "M|com.google.javascript.jscomp.NodeTraversal|getCurrentNode||new:com.google.javascript.jscomp.NodeTraversal:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.NodeTraversal$Callback",
    "M|com.google.javascript.jscomp.NodeTraversal|getEnclosingFunction||new:com.google.javascript.jscomp.NodeTraversal:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.NodeTraversal$Callback",
    "M|com.google.javascript.jscomp.NodeTraversal|getInput||new:com.google.javascript.jscomp.NodeTraversal:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.NodeTraversal$Callback",
    "M|com.google.javascript.jscomp.NodeTraversal|getInputId||new:com.google.javascript.jscomp.NodeTraversal:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.NodeTraversal$Callback",
    "M|com.google.javascript.jscomp.NodeTraversal|getLineNumber||new:com.google.javascript.jscomp.NodeTraversal:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.NodeTraversal$Callback",
    "M|com.google.javascript.jscomp.NodeTraversal|getModule||new:com.google.javascript.jscomp.NodeTraversal:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.NodeTraversal$Callback",
    "M|com.google.javascript.jscomp.NodeTraversal|getScope||new:com.google.javascript.jscomp.NodeTraversal:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.NodeTraversal$Callback",
    "M|com.google.javascript.jscomp.NodeTraversal|getScopeDepth||new:com.google.javascript.jscomp.NodeTraversal:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.NodeTraversal$Callback",
    "M|com.google.javascript.jscomp.NodeTraversal|getScopeRoot||new:com.google.javascript.jscomp.NodeTraversal:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.NodeTraversal$Callback",
    "M|com.google.javascript.jscomp.NodeTraversal|getSourceName|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeTraversal|getSourceName||new:com.google.javascript.jscomp.NodeTraversal:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.NodeTraversal$Callback",
    "M|com.google.javascript.jscomp.NodeTraversal|traverseFunction|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.NodeTraversal:com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.NodeTraversal$Callback",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
