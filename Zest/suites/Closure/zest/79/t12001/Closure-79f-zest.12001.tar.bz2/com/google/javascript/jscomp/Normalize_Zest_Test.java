package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class Normalize_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 5, 8, "\udac6\udf6a\udb50\udfb5\ud8ea\udf77\udba1\ude44\udb89\uddcb\ud9bc\udf9d", "\u662d\u599f", "\udb24\uddd6\ud90b\ude60\udb0d\uddee\ud890\udc09\udbe3\udc42\ud8dc\udde1\ud8f4\ude53",
        52, 14207, 1666816779, -4665394859010955217L, -5827L, false, false, (char) 60740, (char) 45898,
        Double.longBitsToDouble(0x3fe719024e12dd5cL), Double.longBitsToDouble(0x3fd0355bee801d56L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 5, 8, "\udac6\udf6a\udb50\udfb5\ud8ea\udf77\udba1\ude44\udb89\uddcb\ud9bc\udf9d", "\u662d\u599f", "\udb24\uddd6\ud90b\ude60\udb0d\uddee\ud890\udc09\udbe3\udc42\ud9c2\udeb4\uda29\udcb3",
        21, 14207, 1666816779, -4665394859010955217L, -5827L, false, false, (char) 10913, (char) 16300,
        Double.longBitsToDouble(0x3fe71cf13612dd5cL), Double.longBitsToDouble(0x3fd0355bee801d56L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 5, 8, "\udac6\udf6a\ud9e0\udfbd\ud8ea\udf77\udbee\udcf8\udb89\uddcb\ud9bc\udf9d", "\u662d\u599f", "\udb24\uddd6\ud90b\ude05\udb0d\uddee\ud890\udc09",
        -1, 86446, 224076132, -5476130403950011021L, -22152L, true, false, (char) 37258, (char) 23415,
        Double.longBitsToDouble(0x3fcd86b2ce92c5e4L), Double.longBitsToDouble(0x3fed798756eb0a8aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 5, 8, "\udac6\udf6a\udb50\udfb5\ud8ea\udf77\udba1\ude44\udb89\uddcb\ud9bc\udf9d", "\u66bc\u599f", "\uda8c\udd61\ud904\udda4\udb0d\uddee\ud890\udc09",
        -1, 92537, 1939398285, 6938894638131698487L, -22152L, false, false, (char) 56465, (char) 35538,
        Double.longBitsToDouble(0x3fcf86b5be93b680L), Double.longBitsToDouble(0x3fe9480116e32049L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 5, 0, "\udac6\udf6a\udb50\udfb5\ud8ea\udf77\udba1\ude44\udb89\uddcb\ud9bc\udf9d", "\u662d\u8161", "\udb24\uddd6\ud90b\ude60\udb0d\uddee\ud890\udc09\udbe3\udc42\ud8dc\udde1\ud8f4\ude53\ud869\udc1f\ue0d7\udb5e\udce5\ud8ab\udc47\ud88d\ude2e\uda7e\udde8\udb79\ude14\udb4d\udf93\ud805\udfa6\udae9\ude26",
        38, 71226, 246118802, -162130412792583484L, -16164L, false, true, (char) 19959, (char) 7158,
        Double.longBitsToDouble(0x3fe84b4631916873L), Double.longBitsToDouble(0x3fd7a663b3a8ad14L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 12, 8, "\ud832\udd43\ud8d6\uded6\udb61\udc96\ud965\udf5a\ud939\uddf1\ud9bc\udee9", "\ud545\u59ba", "\ud9bb\ude34\ud99d\udf28\ud8c4\udc8d\ued0d\ud881\udc11\ud86b\udcf2\ud8f9\udffd",
        28, 78404, -235732226, -4665394459780192209L, -5964L, false, false, (char) 60740, (char) 45898,
        Double.longBitsToDouble(0x3fe719024e12dd5cL), Double.longBitsToDouble(0x3fd3555bee801d56L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 5, 0, "\udac6\udf6a\udb50\udfb5\ud8ea\udf77\udba1\ude44\000\000", "\u662d", "\ud8f8\uddb6\udb24\uddd6\ud90b\ude60)\000\000\000\u3500\000",
        -5, -1000, 0, 1369094285836975571L, -100000L, false, true, (char) 45864, (char) 227,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e4b4d9468000000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 13, 2, "\udac6\udf6a\udb50\udfb5\ud8ea\udf77\udba1\ude44", "\u35e8\u8837\u741a\u599f\ub312\u94dd\ud0f9\u16a0\u9924\ua7e1\u991a\u5ce6\u6806\ub940\u3374\u10cb\u5b5b\uaf8d\u6c24\u79eb\u9d03\u4cfa\u2851\uc5d4\ud3b1\u6165\ud570\uae3a\u313f\u2aa9\ubf4b\u3a01\u088b\u6961\u60aa", "\ud840\udf0f\uda8d\udd8f\ud8df\udebc\ud8a2\udd4a\udbfc\udcf6\u4211\ud998\udeb5\udada\uddcd\udb7e\ude40\udb32\udd59\ud81d\udf37\udaee\udc12",
        37, 74773, -385332890, 1067372351199509196L, 15003L, true, false, (char) 59234, (char) 3434,
        Double.longBitsToDouble(0x3fee3105c539f44bL), Double.longBitsToDouble(0x3fc1b502b904a1f8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 4, 8, "\udbe4\ude35\ud9d2\udd42\ud8b2\udf04\ud902\udd15", "\ud092\u8837\u662d\u3809\u8005\u2642\u1fff\u3425\u9924\u73e1\u991a\u5ce6\u6806\uc933\u3374\u10cb\u5b5b\ua741\u76e9\u47a6\u9299\u19de\u6d54\uc5d4\ud3b1\u0266\u2eaa\u3366\ua2de\u440c\u7e0a\ub46f\u4d51\ub29d\ub641", "\ud960\udf69\udb13\uddd2\ud9df\udeee\ud884\udddd\udbaf\ude25\ud94b\udff4\udb5f\ude12\u01b2\udaba\udd00\ud95f\udffb\u7266\uda54\udca0\ud95e\ude68\ud880\udd09\udbfb\ude68\ud8fc\ude42\ud95e\udd8a\ud823\uddc7\ud827\udeda\ud8e0\udd5b\ud8a8\uddad\udb46\udc3a\uda38\udd6c",
        49, 8547, 1351706726, 2003342383507703711L, -63734L, true, true, (char) 22271, (char) 6146,
        Double.longBitsToDouble(0x3fac0d34395d0080L), Double.longBitsToDouble(0x3fe8075195f9e7ceL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\012",
        Z.run(T, 1, 6, 5, 8, "\udac6\udf6a\udb84\udc90\uda89\udf49\udba1\ude44", "\u4470\u8837\u662d\u2d78\ud0bb\ucdbd\u9c5a\uc9b2\ub8e0\ua7e1\u991a\u6d23\ub4ff\ua5de\ubd10\u8626\u5b5b\ubafc\u36b6\u47a6\u6757\u67cd\u796d\u93c1\ud3b1\u2882\ub43f\u02b4\uacd8\ub9ba\u7c60\u55b2\u593e", "\ud80e\udfa3",
        7, 89172, -1842066363, -2650560839035308840L, -57277L, false, true, (char) 62696, (char) 22615,
        Double.longBitsToDouble(0x3fb9632dd331aa30L), Double.longBitsToDouble(0x3fdeee39df53bc4aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\012",
        Z.run(T, 1, 6, 4, 0, "\udac6\udf6a\udb50\udfb5\uda28\udf76\udba1\ude44\udb89\uddcb\ud81c\udfd6", "\u662d\u599f", "\udb24\uddd6\ud90b\ude60\udb0d\uddee\ud890\udc09",
        -1, 92537, 1514943745, 6977247364645116727L, -22152L, true, false, (char) 7306, (char) 23478,
        Double.longBitsToDouble(0x3fcf86b2de93b680L), Double.longBitsToDouble(0x3fe9480111642049L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 5, 7, 11, "\ud897\udd02\udb51\udc63\ud8ea\udf77\udba1\ude44\uda7f\udcf4\ud8fc\udf15", "\u662d\u599f\ub312\ub13b\ua5f2\u16a0\u9924\ua7e1\u03b3", "\ud869\udc1f\ue0d7\udb5e\udce5\ud8ab\udc47\ud9ce\udd58\ud84b\udf48\ud9b6\udfe1\udb4d\udfe6",
        8, 36905, -581155101, 6178540743098595587L, -37412L, true, true, (char) 33947, (char) 17027,
        Double.longBitsToDouble(0x3f855b34ed7c1b40L), Double.longBitsToDouble(0x3fef8b253d7b28efL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 0, "\udac6\udf6a\udb50\udfb5\ud8ea\udf77\udba1\ude44\udb89\uddcb\ud9bc\udf9d", "\u662d\u8161", "\udb24\uddd6\ud90b\ude60\udb0d\uddee\ud890\udc09\udbe3\udc42\ud8dc\udde1\uda9d\udc08\udbf5\udd6b\ue0d7\udb5e\udce5\ud8ab\udc47\ud88d\ude2e\uda7e\udde8\udb79\ude14\udb4d\udf93\ud805\udfa6\udae9\ude7e",
        38, 71226, 246118802, -162130412792583484L, -16164L, false, true, (char) 19959, (char) 7158,
        Double.longBitsToDouble(0x3fe84b4631916873L), Double.longBitsToDouble(0x3fd7a663b3a8ad14L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 3, 0, "\udac6\udf6a\udb50\udfb5\ud8ea\udf77\udba1\ude44\udb89\uddcb\ud9bc\udf9d", "\u662d\u8161", "\udb24\uddd6\ud90b\ude60\udb0d\uddee\ud890\udc09\udbe3\udc42\ud8dc\udde1\ud8f4\ude53\ud869\udc1f\ue0d7\udb5e\udce5\ud8ab\udc47\ud88d\ude2e\uda7e\udde8\udb79\ude14\udb4d\udf93\ud805\udfa6\udae9\ude26",
        38, 71226, 246118802, -162130412792583484L, -16164L, false, true, (char) 19959, (char) 7158,
        Double.longBitsToDouble(0x3fdca36c645733d8L), Double.longBitsToDouble(0x3fe09559e1126c4eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 0, "\udac6\udf6a\udb50\udfb5\ud8ea\udf77\ud87e\udd37\udb89\uddaf\ud9bc\udf9d", "\u4ff4\uac8c", "\udb24\uddd6\ud90b\ude60\udb0d\uddee\ud890\udc09\udbe3\udc42\ud8dc\udde1\ud821\udf42\ud869\udc90\ue0d7\udb5e\udce5\ud987\udca1\u9394\uda83\udf56\udb79\ude14\udb4d\udf93\ud805\udfa6\udae9\ude26",
        38, 37354, -174287209, -327288283073596637L, 78308L, false, true, (char) 19972, (char) 7158,
        Double.longBitsToDouble(0x3fe84b4631916873L), Double.longBitsToDouble(0x3fd7a663b9a8ad14L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 7, 7, "\ud956\udfa1\udb50\udfb7\ud8ea\udf77\udbfb\ude51\000\000\000\ud8ab\udef4\ud959\udcec\ud934\udf3b\000\ud8f8\uddb6\ud957\uddee\ud902\udd7c)\000\ud8c3\udc21\ud9d3\ude54\ud85c\udf0e\ud8a1\udc36\udbf1\udddd\udaa4\udedb\ud947\udfaf\ud844\udc6c", "\u6551\u1648\ub329\u00e3\u7da0\u41aa\u6fd3\u8fe1\ube24", "\udab2\udf1d",
        41, -88, 1518618999, 2572967867550811584L, -97274L, true, true, (char) 4600, (char) 7750,
        Double.longBitsToDouble(0x3fe137bd3279e6e4L), Double.longBitsToDouble(0x3fe908dd0ddc031cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 2, "\udac6\udf6a\udb50\udfb5\ud8ea\udf77\udb0f\udedb", "\u35e8\u8837\u741a\u599f\ub312\u94dd\ud0f9\u16a0\u9924\ua7e1\u991a\u5ce6\u6806\ub940\u3374\u10cb\u5b5b\u1030\000\u97ff\u9d03\u4cfa\u2851\uc5d4\000\000\000\u5a3a\u313f\u2aa9\ubf4b\u3a01\uc335\000\u60aa", "",
        30, 71616, 1339216392, 4987416863460282772L, -7964L, false, false, (char) 0, (char) 34186,
        Double.longBitsToDouble(0x3fe4ded6f0000000L), Double.longBitsToDouble(0x3fd19c70054acabeL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 12, 7, "\ud82f\udd80\udb50\udfb5\ud954\udf6c\ud988\uddf7\ud8cc\udd1b\ud8b7\ude01\udb87\ude9b\ud8c4\udd47\udb2f\udd37\ud934\udf3b\ud928\udf2e\ud909\udcad\udb85\uded3\ud90b\ude60\udb0d\uddee\ud890\udc09\udbe3\udc42\ud8dc\udde1\ud8f4\ude53", "\ua709\u4db8\uaf8d\u6c24\u79eb\u9d03", "\ud97d\udc47\uda42\udf1f\udbc2\udca3\ud93a\udd43\ud8d0\udd52\udbde\udc42\ud8fb\udca5\u212f\ud84a\udef5\udaf4\udfaa\udbf5\ude21\ud9bd\udcc3\ud8f0\udc71\uda67\udc8b\ud840\udf0f\uda8d\udd8f\ud870\udfc6\uda38\udc68\udb06\ude88\u4211\ud998\udeb5\udada\uddcd\udb7e\ude40\udb32\udd59\ud81d\udf37\udaee\udc12\ud958\udf12\udbce\udd9f\ud9de\udc0b\ud9c4\ude5f\udb1a\udffa\ud955\udce9\uda03\udea3",
        -2, 63197, 906314658, -843308076901259975L, -44359L, true, true, (char) 54507, (char) 48556,
        Double.longBitsToDouble(0x3fd313abfe8c4cfcL), Double.longBitsToDouble(0x3fd67ece4d89bee0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 10, 9, "\udad6\udcea\udb50\udfb5\ud8ea\udf77\udba1\ude44", "\u35e8\u3e70\u741a\u6582\ub312\u94dd\ud0f9\u35fd\ud5fd\uc5e2\u991a\u5ce6\u9934", "\udb5e\udce5\ud8ab\udc47\udb26\udc85\ud856\ude8c",
        14, 80667, -270538729, 1789770602603902855L, 96611L, false, true, (char) 6044, (char) 51647,
        Double.longBitsToDouble(0x3fed7278157ff384L), Double.longBitsToDouble(0x3fefe1b932c73e94L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 6, 5, 4, "\udac6\udf6a", "\u8b23\u503d\uac26\u4470\u281b\u662d\u2d78\ud0bb\ucdbd\u9c5a\uc9b2\ub8e0\ua7e1\u991a\u6d23\ub4ff\ua5de\ubd10\u8626\u5b5b\ubafc\u36b6\u47a6\u6757\u67cd\u796d\u93c1\u7a72\u2882\ub43f\u02b4\uacd8\ub9ba\u5054\uc77c\u2559\u0eef\u9317\u97f9\u3912\ucee2\uadc3\u3d5d\u2946\u4147", "\udbd5\ude37\udb03\udd2a\udad3\udf88\udaf0\udcb9\ud843\udc86\ud981\udee3\ud91c\udd97\uda02\udc88\udb6f\udf98\udb16\ude3e\ud921\udddc\u38a8\ud81a\udc80\ud815\udef1\ud909\ude49\ud933\udec7\uf2fb\udbfb\ude79\u0607\udbe6\udc8b\ud85e\uddde\ud851\udee5\udb55\udd5d\udbd6\udc48\udb7e\udfa5\udafd\udc96\uda55\udf7c\ud908\udd9a\ud899\udff9\uda19\udcd5\uda1e\udf66\udb0c\udef9\udb38\udfb2\udb67\ude07",
        -1, 21410, -1896044974, 1901781129566432022L, -15180L, true, false, (char) 29365, (char) 41211,
        Double.longBitsToDouble(0x3fc137025e82653cL), Double.longBitsToDouble(0x3fe21cf1a72cc88bL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 8, "\udac6\udf6a\uda45\udf91\uda89\udf49\ud926\udd46", "\u4470\u7c10\u4d37\u6f7b\u078a\u1251\u439f\u8e78\u1bb5\ua7e1\u991a\u6d23\ub4ff\u064c\u82df\u8626\u5b5b\ubafc\u36b6\u47a6\u5248\u2b7d\u4e0e\u93c1\ud3b1\u64a7\u1630\u031c\uacd8\ud696\u44c2\u3393\u593e", "\ud80e\udfa3",
        7, 6564, -1842066233, 7476100681969892584L, -57277L, false, true, (char) 62696, (char) 64313,
        Double.longBitsToDouble(0x3fdfd356c6d07700L), Double.longBitsToDouble(0x3fdd2eda4f53bc4aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=new com.google.javascript.jscomp.Normalize:@?\012",
        Z.run(T, 2, 6, 6, 0, "\uda98\udce6\udb7d\udef7\ud802\ude55\ud8ca\ude38\udb89\udd50\ud81c\udfd6", "\u662d\u599f", "\udb24\uddd6\udbda\udfa8\u5d71\udbda\ude8f",
        -1, 80806, -1386796961, 6977247364645116727L, 84296L, true, false, (char) 5325, (char) 16192,
        Double.longBitsToDouble(0x3fb279ea088f6d00L), Double.longBitsToDouble(0x3fefdee2e1649b13L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 0, "\udac6\udf6a\udb50\udfb5\uda28\udf76\udb9c\ude44\udb89\uddcb\ud81c\udfd6", "\u662d", "\ud8f8\uddbb\ud8b2\udc9c\ud90b\udd97\udb0d\uddee\ud890\udc09\udbe3\udc42\ud8dc\udde1\ud8f4\ude53\udb35\udf37",
        47, 2459, 1298245133, 1420860156565194963L, -42404L, false, true, (char) 19929, (char) 29101,
        Double.longBitsToDouble(0x3fe8ea6db7281fa3L), Double.longBitsToDouble(0x3fdf0085cffeb9a0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 5, 8, "\udac6\udf6a\udb50\udfb5\ud8ea\udf77\udba1\ude44\udb89\uddcb\ud9bc\udf9d", "\u662d\u599f", "\udb24\uddd6\ud90b\ude60\udb0d\uddee\ud890\udc09\udbe3\udc42\ud8dc\udde1\ud8f4\ude53",
        52, 14207, 1666816779, -4665394859010955217L, -5827L, false, false, (char) 160, (char) 45823,
        Double.longBitsToDouble(0x3fe719024e12dd5cL), Double.longBitsToDouble(0x3fd0355bee801d56L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new com.google.javascript.jscomp.Normalize:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 0, "\udac6\udf6a\udb50\udfb5\ud8ea\udf77\ud87e\udd37\udb89\uddaf\ud9bc\udf9d", "\u4ff4\uac8c", "\udb24\uddd6\ud90b\ude60\udb0d\uddee\ud890\udc09\udbe3\udc42\ud8dc\udde1\ud821\udf42\ud9f3\ude91\ue0d7\udb5e\udce5\ud987\udca1\u9394\uda83\udf56\udb79\ude14\udb4d\udf93\ud805\udfa6\udae9\ude26",
        38, 89474, -174287209, -327288283073596637L, 30025L, true, false, (char) 975, (char) 35332,
        Double.longBitsToDouble(0x3fd7a663b9a8ad14L), Double.longBitsToDouble(0x3fecb28024c06410L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.Normalize|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Normalize:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.VarCheck|createSynthesizedExternVar|java.lang.String|new:com.google.javascript.jscomp.VarCheck:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.Normalize|parseAndNormalizeSyntheticCode|com.google.javascript.jscomp.AbstractCompiler,java.lang.String,java.lang.String|static",
    "M|com.google.javascript.jscomp.Normalize|parseAndNormalizeTestCode|com.google.javascript.jscomp.AbstractCompiler,java.lang.String,java.lang.String|static",
    "M|com.google.javascript.jscomp.Normalize|removeDuplicateDeclarations|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Normalize:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.Normalize|reportCodeChange|java.lang.String|new:com.google.javascript.jscomp.Normalize:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "C|com.google.javascript.jscomp.Normalize|<init>|com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.VarCheck|getSynthesizedExternsInput||new:com.google.javascript.jscomp.VarCheck:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.VarCheck|getSynthesizedExternsRoot||new:com.google.javascript.jscomp.VarCheck:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.VarCheck|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.VarCheck:com.google.javascript.jscomp.AbstractCompiler",
    "M|com.google.javascript.jscomp.VarCheck|visit|com.google.javascript.jscomp.NodeTraversal,com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.VarCheck:com.google.javascript.jscomp.AbstractCompiler",
    "C|com.google.javascript.jscomp.VarCheck|<init>|com.google.javascript.jscomp.AbstractCompiler",
    "C|com.google.javascript.jscomp.VarCheck|<init>|com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.Normalize|process|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|new:com.google.javascript.jscomp.Normalize:com.google.javascript.jscomp.AbstractCompiler,boolean",
    "M|com.google.javascript.jscomp.VarCheck|createSynthesizedExternVar|java.lang.String|new:com.google.javascript.jscomp.VarCheck:com.google.javascript.jscomp.AbstractCompiler",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
