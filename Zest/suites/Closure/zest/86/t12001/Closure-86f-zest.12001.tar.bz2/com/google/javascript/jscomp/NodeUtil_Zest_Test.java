package com.google.javascript.jscomp;
import org.junit.Test;
import static org.junit.Assert.*;
public class NodeUtil_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 15, 14, "\ud8ea\udffd", "\u590e", "\uda7d\udcc7\ud836\udcf7\udaa8\udc67\ud8d8\ude05\ud8c6\uddb6\udafe\udd3a\udb73\udcfe\ud995\udd94\ud93f\uddf5\uda04\ude75\ud9a6\udfb7\ud951\udc89\udbac\uddc2\ud960\udec2\ud82d\udec1\ud8d8\udf79\ud93e\udf11\ud9ce\udd9f\uda2b\udf0e\uda38\udd08\udb51\udcbe\ud809\uded7\ud8b6\udfc7",
        5, 78915, -516303684, 6462225552099894096L, 2677L, false, false, (char) 15232, (char) 18865,
        Double.longBitsToDouble(0x3fe1dbfc2acd203dL), Double.longBitsToDouble(0x3fe75070d10bb8edL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 4, 0, "\ud8ea\udffd", "\u590e", "\uda7d\udcc7\ud836\udcf7\udaa8\udc67\ud8d8\ude05\udbf7\ude4e\ud94d\udd86\udb73\udcfe\ud995\udd94\ud93f\uddf5\uda04\ude75\ud993\udeb7\ud951\udc89\udbac\uddc2\ud960\udec2\ud82d\udec1\ud8d8\udf79\ud93e\udf11\000\000\000\udb38\udd7b\ud809\uded7\ud8b6\udfc7",
        5, 78915, -516303684, 6413248906152239952L, 2677L, false, false, (char) 15232, (char) 18865,
        Double.longBitsToDouble(0x3fe1dbfc2acd203dL), Double.longBitsToDouble(0x3fe75070d10bb8edL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 14, 1, "\ud8ea\udffd\ud8cb\ude8f\udb8a\udcd4\udbb3\udf1f\uda51\udcec\udaf9\udd51\uda7d\udcc7\ud836\udcf7\udaa8\udc67\uda67\udcec\ud96d\udc55\udafe\udd3a\udb3b\udffe\ud995\udd94\ud93f\uddf5\ud995\udf7f\ud9a6\udfb7", "\u1b6b\u43a0\u9cc1\ucacf\u3ff3\u7380\u75da\u18df\u973e\u03b4\u1a72\u94a2", "\ud939\udf4f\udb0d\ude1a\ud961\udff3\udb6d\udc12\ud877\ude08\udb7b\uddc6",
        53, 63157, -1192366358, 3891564224705712019L, -70310L, true, true, (char) 518, (char) 8388,
        Double.longBitsToDouble(0x3fe7481a3adcda7fL), Double.longBitsToDouble(0x3fd35b42cea1ada0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 14, "\ud8ea\udffd", "\u590e", "\uda7d\udcc7\ud836\udcf7\udaa8\udc67\ud839\uddd6\ud8d4\udc3a\udb10\udde0\udb73\udcfe\ud995\udd94\ud93f\uddf5\udbbb\udcd2\ud864\udd3e\ud963\udd96\udb6f\udf83\ud973\ude51\uda98\ude9a\ud8ea\ude63\ud93e\udf11\ud9ce\udd9f\uda2b\udf0e\uda38\udd08\udb51\udcbe\ud809\uded7\udbc7\ude4f",
        52, 78915, -516303684, 6462225552099894096L, 2677L, false, false, (char) 15232, (char) 18865,
        Double.longBitsToDouble(0x3fecf3fc2acdba7cL), Double.longBitsToDouble(0x3fe75070d10bb8edL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 12, 10, "\ud8ea\udffd", "\u590e", "\ud880\ude05\u848c\udaa8\udc67\ud8d8\ude05\ud8c6\uddb6\udb5e\udddc\udb73\udcfe\ud995\udd94\ud93f\uddf5\ud887\udf17\ud9c8\udda4\ud951\udc89\uda31\udedb\u8ca9\ud82d\ude38\ud8d8\udf79\ud93e\udf11\ud9ce\udd9f\u854c\ud8d5\udd3e\udb50\udd5d\ud809\uded7\ud8b6\udfc7",
        2, 78915, 177460412, -3872244164767678830L, 79948L, false, true, (char) 16430, (char) 55603,
        Double.longBitsToDouble(0x3fe0b43c1998bc9dL), Double.longBitsToDouble(0x3fe75074210bb8edL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 15, 14, "\ud8ea\udffd", "\u590e", "\uda7d\udcc7\ud836\udcf7\udaa8\udc67\ud8d8\ude05\ud8c6\uddb6\udafe\udd3a\udb73\udcfe\ud995\udd94\udabd\udeb5\uda04\ude4e\ud9a6\udfb7\ud951\udc89\udbac\uddc2\ud960\udec2\u00eb\ud8d8\udf0b\ud93e\udf11\ud9ce\udd9f\uda2b\udf0e\u00ac\uda9e\udf02\u91b2\ud888\udfc7",
        5, 9307, 0, -1151474944L, 2677L, false, false, (char) 15232, (char) 18865,
        Double.longBitsToDouble(0x3fe1dbfc2acd203dL), Double.longBitsToDouble(0x3fe75070d10bb8edL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 3, 14, "\ud8ea\udffd", "\u590e", "\ud9f8\udeb3\udb0e\udf23\uda90\uddaa\ud8d8\ude05\ud8c6\uddb6\udafe\udd3a\udb73\udcfe\ud995\udd94",
        -5, 15055, -380941042, 3665157731805439217L, 96885L, false, false, (char) 3426, (char) 52907,
        Double.longBitsToDouble(0x3fe0266ed0081a4dL), Double.longBitsToDouble(0x3fedccfb45c9fcd2L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 10, 15, "\udb9d\udd42", "\u590e", "\ud995\udecb\ud8ca\ude7d\udaa8\udd59\ud8d8\ude05\ud8c6\uddb6\udafe\udd3a\udb73\udcfe\ud995\udd94\ud93f\uddf5\uda04\ude75\ud9ad\udeb7\ud951\udc89\udbac\uddc2\ud960\udec2\ud82d\udec1\ud8d8\udf79\ud93e\udf11\ud9ce\udd9f\ud9c5\udfba\uda38\udd08\udb14\uddb9\u9751\u6199",
        31, 48011, -516303693, 6462225554083886416L, 59467L, false, false, (char) 15232, (char) 18865,
        Double.longBitsToDouble(0x3fe1dbfc2acd203dL), Double.longBitsToDouble(0x3fe75070d10bb8edL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 10, 14, "\ud8ea\udffd", "\uab92\u070c\u4afb\ud1c0\u1f7a\ua1ba\u8b4c\ua29b", "\ud995\udd94\ud93f\uddf5\uda04\ude75\ud9aa\uddb7\ud951\udc89\udadd\ude28\udbdb\udfc0\ud82d\udec1",
        56, 23241, 1490701411, -9129519347417811028L, 1669L, true, false, (char) 20677, (char) 44178,
        Double.longBitsToDouble(0x3fee7ad007e7e139L), Double.longBitsToDouble(0x3fea82cd77cdbb5dL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 15, 14, "\ud961\udfe1\ud8bf\udd74\udb8a\udcd4\udba5\udde8\uda51\udcec\udaf9\udd51\uda52\udfc7\ud836\udcf7\udaa8\udc67", "\uc21a\u26a2\u89b1\u6996\u0fe1\ua224\ubdd2\u9cfc\u1b6b\u43a0\u9cc1\u8579", "\uda38\udd08\udb51\udcbe\ud809\uded7",
        8, 62205, -1523505085, -2213285311429054489L, -43932L, true, false, (char) 18865, (char) 58816,
        Double.longBitsToDouble(0x3fe66901eeea0e1aL), Double.longBitsToDouble(0x3fd0bb8edfbf7d3aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 6, 2, "\uda66\udc2b", "\u590e", "\ud8c1\uddad\ud836\udcf7\udaa8\udc67\udb91\udd02\ud8b3\udfc8\udafe\udd3a\udb73\udcfe\ud8ea\udef4\udbbf\udf0d\uda04\ude75\ud9a6\udfb7\ud951\udc89\uda41\ude4c\ud8a1\ude02\ub67a\udb7a\ude71\ud93e\udf11\ud9ce\udd9f\uda2b\udf0e\ud8e1\ude9e\udb77\udde5\udb6e\udec9\udbc4\udf00",
        5, 23043, -516303705, 6462225552099894096L, 2677L, false, false, (char) 15232, (char) 18865,
        Double.longBitsToDouble(0x3fd3b7f8559a407aL), Double.longBitsToDouble(0x3fe752f0d26942efL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 5, 14, "\ud8e2\ude32", "\u590e", "\uda7d\udcc7\ud836\udcf7\udaa8\udc67\ud8d8\ude05\ud8c6\uddb6\uda92\udd44\udb73\udcfe\ud995\udd94\ud93f\uddf5\uda04\ude75\ud9a6\udfb7\udbfa\udc5d\udbc1\ude5d\ud960\udec2\ud82d\udec1\ud8d8\udf79\ud93e\udf11\ud9ce\udd9f\uda35\udf25\ud91c\ude22\ud980\udcc2\ud80d\udce4\ud8b6\udfc7",
        48, 23785, -588673574, 6462225144078000976L, 2677L, true, false, (char) 15232, (char) 19001,
        Double.longBitsToDouble(0x3fe1dbfc2acd203dL), Double.longBitsToDouble(0x3fe75070d59a39feL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 4, 6, "\ud8ea\udffd\ud8bf\udc9a\udb8a\udcd4\udba5\udde8\uda51\udcec\udaf9\udd51\uda7d\udc41\udbd0\udfbf\uda86\ude64\ud8d8\ude11\udad3\udf7c\ud90d\udc69\ud9bf\ude99\ud977\udcd1\ud93f\uddf5\uda04\ude75\udbc9\udff7\ud951\udce0\udbac\uddc2\ud960\udec2\ud82d\udec1\ud8d8\udf79\ud93e\udf11\ud993\ude03\uda96\udf74\udb8e\udf8d\udac8\udea2\ud809\uded7\ud8b6\udfc7\uda8c\udf26\ud919\udc97\ud828\udc63\uda7f\ude79\ud927\ude5f\udb0d\udd65\udab9\ude1f\uda82\ude57\uda6c\udeec\udb53\udfb1\udb7c\udc2b\udae8\udc36\ud870\udc22\ud87c\udcb6\udb51\udc2f\ud971\ude94", "\u3934\ucfb7\u14c8\u665f\u98e5", "\ud96b\udc11\uda74\udd51\ud819\udd2a",
        18, 3684, 1696912504, 4226628885056433607L, 57639L, false, true, (char) 29274, (char) 45866,
        Double.longBitsToDouble(0x3fd0a4fde865d210L), Double.longBitsToDouble(0x3fe7017eb6a37ac8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 15, 14, "\ud8ea\udffd", "\u590e", "\uda7d\udcc7\ud836\udcf7\udaa8\udc67\ud8d8\ude05\udbf6\udeee\uda2c\udfc8\udb6b\ude8b\ud995\udd94\ud93f\uddf5\udae3\udf06\ud9a6\udfb7\ud951\udc89\udbac\uddc2\ud960\udec2\ud82d\udec1\ud8d8\udf79\ud93e\udf11\ud9ce\udd9f\udaa9\udf0d\uda35\udd7e\ud930\uddae\ud809\udf7a\ud8b6\udfc7",
        5, 78915, -516303684, 6462225552099894096L, 68213L, false, true, (char) 34094, (char) 18865,
        Double.longBitsToDouble(0x3fe1ebce5baf38c1L), Double.longBitsToDouble(0x3fba8ce3d799ad68L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.javascript.jscomp.NodeUtil|evaluatesToLocalValue|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|evaluatesToLocalValue|com.google.javascript.rhino.Node,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.NodeUtil|callHasLocalResult|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|canBeSideEffected|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|canBeSideEffected|com.google.javascript.rhino.Node,java.util.Set|static",
    "M|com.google.javascript.jscomp.NodeUtil|checkForStateChangeHelper|com.google.javascript.rhino.Node,boolean,com.google.javascript.jscomp.AbstractCompiler|static",
    "M|com.google.javascript.jscomp.NodeUtil|constructorCallHasSideEffects|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|constructorCallHasSideEffects|com.google.javascript.rhino.Node,com.google.javascript.jscomp.AbstractCompiler|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsCall|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsFunction|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsType|com.google.javascript.rhino.Node,int|static",
    "M|com.google.javascript.jscomp.NodeUtil|containsType|com.google.javascript.rhino.Node,int,com.google.common.base.Predicate|static",
    "M|com.google.javascript.jscomp.NodeUtil|copyNameAnnotations|com.google.javascript.rhino.Node,com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|functionCallHasSideEffects|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|functionCallHasSideEffects|com.google.javascript.rhino.Node,com.google.javascript.jscomp.AbstractCompiler|static",
    "M|com.google.javascript.jscomp.NodeUtil|getAddingRoot|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|evaluatesToLocalValue|com.google.javascript.rhino.Node|static",
    "M|com.google.javascript.jscomp.NodeUtil|evaluatesToLocalValue|com.google.javascript.rhino.Node,com.google.common.base.Predicate|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
